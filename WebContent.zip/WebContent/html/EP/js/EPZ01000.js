/**
 * �{���GEPZ01000.js�a�}����js�C
 * �@�̡G
 * �\��G���Ѧh�ئa�}��ܤ覡�C
 * �����G2011/09/21�C
 * �����G
 * ��s�G
 *
 *           Date         Author                                                    Description
 *      ==============  ==========  ==============================================================================================================
 *			2011/09/21		���v��
 *			2011/09/27		���v��     	�����ǤJ�Ѽ�dispatcher
 *										�s�W��k�GgetAllSelectObject�BcheckData�Bdisplay4INPUT_ZIPCODE�Bdisplay4INPUT_ADDR
 *			2012/05/09		���v��     	�s�WinputType==4�]�a�F�ưȩҡ^
 * 
 *           public function                                                        Description
 *      =========================   =============================================================================================================
 *        	EPZ01000						�Q�� new EPZ01000(td_ID, inputType, addressLength) ���覡���ͤ@�ӿW�ߪ��a�}����
 *        
 *        								�̷�inputType�����P�A��������k���O�p�U�G
 *              
 *        								------------------------------ inputType=1 ------------------------------
 *        								EPZ01000.setCITY_NAME			�]�w�����O
 *        								EPZ01000.getCITY_NAME			���o�����O
 *        								EPZ01000.setTOWN_NAME			�]�w�m�����ϧO
 *        								EPZ01000.getTOWN_NAME			���o�m�����ϧO
 *        								EPZ01000.setINPUT_ZIPCODE		�]�w�l���ϸ�
 *        								EPZ01000.getINPUT_ZIPCODE		���o�l���ϸ�
 *        								EPZ01000.setINPUT_ADDR			�]�w�a�}
 *        								EPZ01000.getINPUT_ADDR			���o�a�}
 *        								EPZ01000.displayOnly            �����ܦa�}
 *        								EPZ01000.getAllSelectObject		���o���������DOM����
 *        								EPZ01000.checkData				�ˮ����
 *										EPZ01000.display4INPUT_ZIPCODE	�M�wINPUT_ZIPCODE����ܤ覡("1":���span, "2":��Jinput, ��L��J������)
 *										EPZ01000.display4INPUT_ADDR		�M�wINPUT_ADDR����ܤ覡("1":���span, "2":��Jinput, ��L��J������)
 *
 *        								------------------------------ inputType=2 ------------------------------
 *        								EPZ01000.setCITY_NAME			�]�w�����O
 *        								EPZ01000.getCITY_NAME			���o�����O
 *        								EPZ01000.setTOWN_NAME			�]�w�m�����ϧO
 *        								EPZ01000.getTOWN_NAME			���o�m�����ϧO
 *        								EPZ01000.setROAD_NAME			�]�w���W
 *        								EPZ01000.EPZ01000.getROAD_NAME	���o���W
 *        								EPZ01000.setADDR_NAME			�]�w���P���X���s
 *        								EPZ01000.getADDR_NAME			���o���P���X���s
 *        								EPZ01000.setINPUT_ZIPCODE		�]�w�l���ϸ�
 *        								EPZ01000.getINPUT_ZIPCODE		���o�l���ϸ�
 *        								EPZ01000.setINPUT_ADDR			�]�w�a�}
 *        								EPZ01000.getINPUT_ADDR			���o�a�}
 *        								EPZ01000.displayOnly			�����ܦa�}
 *        								EPZ01000.getAllSelectObject		���o���������DOM����
 *        								EPZ01000.checkData				�ˮ����
 *										EPZ01000.display4INPUT_ZIPCODE	�M�wINPUT_ZIPCODE����ܤ覡("1":���span, "2":��Jinput, ��L��J������)
 *										EPZ01000.display4INPUT_ADDR		�M�wINPUT_ADDR����ܤ覡("1":���span, "2":��Jinput, ��L��J������)
 *
 *        								------------------------------ inputType=3 ------------------------------
 *        								EPZ01000.setCITY_NAME			�]�w�����O
 *        								EPZ01000.getCITY_NAME			���o�����O
 *        								EPZ01000.setTOWN_NAME			�]�w�m�����ϧO
 *        								EPZ01000.getTOWN_NAME			���o�m�����ϧO
 *        								EPZ01000.setOFFICE_NAME			�]�w�a�F�ưȩ�
 *       								EPZ01000.getOFFICE_NAME			���o�a�F�ưȩ�
 *        								EPZ01000.setOFFICE_CODE			�]�w�a�F�ưȩҥN�X
 *        								EPZ01000.getOFFICE_CODE			���o�a�F�ưȩҥN�X
 *        								EPZ01000.setLAND_NAME1			�]�w�a�q
 *        								EPZ01000.getLAND_NAME1			���o�a�q
 *        								EPZ01000.setLAND_NAME2			�]�w�p�q
 *        								EPZ01000.getLAND_NAME2			���o�p�q
 *        								EPZ01000.setLAND_CODE			�]�w�a�q�p�q�N�X
 *        								EPZ01000.getLAND_CODE			���o�a�q�p�q�N�X
 *        								EPZ01000.displayOnly      		�����ܦa�}
 *        								EPZ01000.getAllSelectObject		���o���������DOM����
 *        								EPZ01000.checkData				�ˮ����
 *
 *        								------------------------------ inputType=4 ------------------------------
 *        								EPZ01000.setCITY_NAME			�]�w�����O
 *        								EPZ01000.getCITY_NAME			���o�����O
 *        								EPZ01000.setTOWN_NAME			�]�w�m�����ϧO
 *        								EPZ01000.getTOWN_NAME			���o�m�����ϧO
 *        								EPZ01000.setOFFICE_NAME			�]�w�a�F�ưȩ�
 *       								EPZ01000.getOFFICE_NAME			���o�a�F�ưȩ�
 *        								EPZ01000.setOFFICE_CODE			�]�w�a�F�ưȩҥN�X
 *        								EPZ01000.getOFFICE_CODE			���o�a�F�ưȩҥN�X
 *        								EPZ01000.displayOnly      		�����ܦa�}
 *        								EPZ01000.getAllSelectObject		���o���������DOM����
 *        								EPZ01000.checkData				�ˮ����
 **/

/**
 *	@public
 *	@class	�Q�� new EPZ01000(td_ID, inputType, addressLength) ���覡���ͤ@�ӿW�ߪ��a�}����
 *	@param	td_ID		�ۭq��tdID(���n)
 *	@param	inputType	�n���ͪ��a�}����(���n)
 *						1:�ϥ�3�X�l���ϸ��a�}��J�Φ�
 *						2:�ϥ�5�X�l���ϸ��a�}��J�Φ�
 *						3:�ϥΤg�a�y����J�Φ�
 *						4:�ϥΦa�F�ưȩҿ�J�Φ�
 *			addressLength	�a�}��쪺����(�w�]��60)	
 *
 *	@author ���v��
 *	@version 1.00
 */
EPZ01000.cache = {};
function EPZ01000(td_ID, inputType, addressLength){
	if(Object.isUndefined(EPZ01000.cache[inputType])){
		EPZ01000.cache[inputType] = {
		"townList":{} 
		,"roadList":{} 
		,"addrList":{} 
		,"officeList":{} 
		,"land1List":{} 
		,"land2List":{}
		,"zipCode_1":{}
		,"zipCode_2":{}
		,"officeCode_3":{}
		,"landCode_3":{}};
	}
	
	var td;

	/** �e������ */
	var CITY_NAME;	// �����O(A, B, C)
	var TOWN_NAME;	// �m�����ϧO(A, B, C)
	var INPUT_ZIPCODE;	// �l���ϸ�(A, B)
	var INPUT_ADDR;	// �a�}(A, B)
	
	var ROAD_NAME;	// ���W(B)
	var ADDR_NAME;	// ���P���X���s(B)
	
	var OFFICE_NAME;	// �a�F�ưȩ�(C)
	var OFFICE_CODE;	// �a�F�ưȩҥN�X(C)
	var LAND_NAME1;		// �a�q(C)
	var LAND_NAME2;		// �p�q(C)
	var LAND_CODE;		// �a�q�p�q�N�X(C)
	
	var zipCode_1 = EPZ01000.cache[inputType].zipCode_1;	// �l���ϸ�(for inputType == 1)
	var zipCode_2 = EPZ01000.cache[inputType].zipCode_2;	// �l���ϸ�(for inputType == 2)
	var officeCode_3 = EPZ01000.cache[inputType].officeCode_3;	// �a�F�ưȩҥN�X(for inputType == 3)
	var landCode_3 = EPZ01000.cache[inputType].landCode_3;	// �a�q�p�q�N�X(for inputType == 3)
	
	/** �e����ܪ��� */
	var span_INPUT_ZIPCODE;	// ��ܶl���ϸ�(A�BB)
	var span_INPUT_ADDR;	// ��ܦa�}(A�BB)
	var span_LAND_LOCATED;	// ��ܤg�a�y��
	var br;	// �ߤ@
	
	var isDisplay = false;
	var displaytype4ZIPCODE = "1";
	var displaytype4ADDR = "2";
	
	/** cache */
	var townList = EPZ01000.cache[inputType].townList;
	var roadList = EPZ01000.cache[inputType].roadList;
	var addrList = EPZ01000.cache[inputType].addrList;
	var officeList = EPZ01000.cache[inputType].officeList;
	var land1List = EPZ01000.cache[inputType].land1List;
	var land2List = EPZ01000.cache[inputType].land2List;
	
	/** �^�Ʀr�b������� */
	var asciiTable = "!\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
	var big5Table = "%uFF01%u201D%uFF03%uFF04%uFF05%uFF06%u2019%uFF08%uFF09%uFF0A%uFF0B%uFF0C%uFF0D%uFF0E%uFF0F%uFF10%uFF11%uFF12%uFF13%uFF14%uFF15%uFF16%uFF17%uFF18%uFF19%uFF1A%uFF1B%uFF1C%uFF1D%uFF1E%uFF1F%uFF20%uFF21%uFF22%uFF23%uFF24%uFF25%uFF26%uFF27%uFF28%uFF29%uFF2A%uFF2B%uFF2C%uFF2D%uFF2E%uFF2F%uFF30%uFF31%uFF32%uFF33%uFF34%uFF35%uFF36%uFF37%uFF38%uFF39%uFF3A%uFF3B%uFF3C%uFF3D%uFF3E%uFF3F%u2018%uFF41%uFF42%uFF43%uFF44%uFF45%uFF46%uFF47%uFF48%uFF49%uFF4A%uFF4B%uFF4C%uFF4D%uFF4E%uFF4F%uFF50%uFF51%uFF52%uFF53%uFF54%uFF55%uFF56%uFF57%uFF58%uFF59%uFF5A%uFF5B%uFF5C%uFF5D%uFF5E";
	
	/** ��l */
	var initial = function(){
		if(!window.Prototype){
			alert("prototype.js �����J");
			return;
		}
		
		if(inputType != "1" && inputType != "2" && inputType != "3" && inputType != "4"){
			alert("�ǤJ���Ѽƿ��~( inputType ���� 1, 2, 3, 4 �䤤�@��)");
			return;
		}
		
		var type = typeof(td_ID);
		if(type == "string"){
			if(window.JsUtils){
				td = JsUtils.getDOM(td_ID);
				if(!td){
					alert("���󤣦s�b");
					return;
				}
				td_ID = td.getAttribute("id");
				td = $(td_ID);
				if(!td_ID){
					alert("�������ݩ� id ���s�b");
					return;
				}
			}else{
				td = $(td_ID);
				if(!td){
					alert("������ (= " + td_ID + ") ���s�b");
					return;
				}
			}
		}else if(type == "object"){
			td = td_ID;
			
			td_ID = td.id; 
			if(!td_ID){
				td_ID = getID();
				td.id = td_ID;	
			}	
		}else{
			alert("�u��ǤJ ID �� DOM ����!");
			return;
		}
		
		// ���͹�����DOM����(by INPUT_TYPE)
		action.createContent();
		action.createCITY_NAME();
	};
	
	function getID(){
		var idx = 1;
		var id;
		while(true){
			id = "_addr_"+idx;
			if(!$(id)){
				break;
			}else{
				idx++;
			}
		}
		
		return id;
	}
	
	/** �ާ@ */
	var action = {
		// ����Content
		createContent:function(){
			if(isNaN(parseInt(addressLength, 10))){
				addressLength = 60;
			}	
		
			/** �ϥ�3�X�l���ϸ��a�}��J�Φ� */
			if(inputType == "1"){
				var config = {
					'id':td_ID + '_' + 'CITY_NAME'
					,'name':'CITY_NAME'
				};
				CITY_NAME = tableElement.createElement("select", config).disable();
				CITY_NAME.observe('change', action.cityChange);
				td.insert(CITY_NAME);
				
				var config = {
					'id':td_ID + '_' + 'TOWN_NAME'
					,'name':'TOWN_NAME'
				};
				TOWN_NAME = tableElement.createElement("select", config).disable();
				TOWN_NAME.observe('change', action.townChange);
				td.insert(TOWN_NAME);

				br = tableElement.createElement("br");
				td.insert(br);
				
				var config = {
					'id':td_ID + '_' + 'INPUT_ZIPCODE',
					'name':'INPUT_ZIPCODE',
					'type':'text',
					'class':'textBox2',
					'size':'3',
					'maxLength':'3'					
				};
				INPUT_ZIPCODE = tableElement.createElement("input", config);
				td.insert(INPUT_ZIPCODE);
				
				var config = {
					'id':td_ID + '_' + 'span_INPUT_ZIPCODE'
				};
				span_INPUT_ZIPCODE = tableElement.createElement("span", config);
				td.insert(span_INPUT_ZIPCODE);
				
				action4outer.display4INPUT_ZIPCODE("1");
				
				var config = {
					'id':td_ID + '_' + 'INPUT_ADDR'
					,'name':'INPUT_ADDR'
					,'type':'text'
					,'class':'textBox2'
					,'size':'45'
					,'maxLength':addressLength
				};
				INPUT_ADDR = tableElement.createElement("input", config);
				INPUT_ADDR.observe('change', action.addressChange);
				td.insert(INPUT_ADDR);
				
				var config = {
					'id':td_ID + '_' + 'span_INPUT_ADDR'
				};
				span_INPUT_ADDR = tableElement.createElement("span", config);
				td.insert(span_INPUT_ADDR);
			}
			/** �ϥ�5�X�l���ϸ��a�}��J�Φ� */
			else if(inputType == "2"){
				var config = {
					'id':td_ID + '_' + 'CITY_NAME'
					,'name':'CITY_NAME'
				};
				CITY_NAME = tableElement.createElement("select", config).disable();
				CITY_NAME.observe('change', action.cityChange);
				td.insert(CITY_NAME);
				
				var config = {
					'id':td_ID + '_' + 'TOWN_NAME'
					,'name':'TOWN_NAME'
				};
				TOWN_NAME = tableElement.createElement("select", config).disable();
				TOWN_NAME.observe('change', action.townChange);
				td.insert(TOWN_NAME);
				
				var config = {
					'id':td_ID + '_' + 'ROAD_NAME'
					,'name':'ROAD_NAME'
				};
				ROAD_NAME = tableElement.createElement("select", config);
				ROAD_NAME.observe('change', action.roadChange);
				td.insert(ROAD_NAME);
				
				var config = {
					'id':td_ID + '_' + 'ADDR_NAME'
					,'name':'ADDR_NAME'
				};
				ADDR_NAME = tableElement.createElement("select", config).disable();
				ADDR_NAME.observe('change', action.addrChange);
				td.insert(ADDR_NAME);

				br = tableElement.createElement("br");
				td.insert(br);
				
				var config = {
					'id':td_ID + '_' + 'INPUT_ZIPCODE',
					'name':'INPUT_ZIPCODE',
					'type':'text',
					'class':'textBox2',
					'size':'5',
					'maxLength':'5'
				};
				INPUT_ZIPCODE = tableElement.createElement("input", config);
				td.insert(INPUT_ZIPCODE);
				
				var config = {
					'id':td_ID + '_' + 'span_INPUT_ZIPCODE'
				};
				span_INPUT_ZIPCODE = tableElement.createElement("span", config);
				td.insert(span_INPUT_ZIPCODE);
					
				action4outer.display4INPUT_ZIPCODE("1");
				
				var config = {
					'id':td_ID + '_' + 'INPUT_ADDR'
					,'name':'INPUT_ADDR'
					,'type':'text'
					,'class':'textBox2'
					,'size':'45'
					,'maxLength':addressLength
				};
				INPUT_ADDR = tableElement.createElement("input", config);
				INPUT_ADDR.observe('change', function(){
					action.addressChange();
					var old_address = action4outer.getINPUT_ADDR();
					
					// �p�G�a�}�Q�M�šA�h�N�l���ϸ��@�_�M�šA�_�h�Ǩ��ݬd�߹������l���ϸ�(5�X)
					if(old_address){
						// �Φa�}���o������ 5 �X�l���ϸ�
						var actionName = "getZipCodeByINPUT_ADDR"; 
						var params = {"INPUT_ADDR":INPUT_ADDR.value};
						var successAction = function(resp){
							var new_ZIP_CODE = resp.ZIP_CODE;
							var old_ZIP_CODE = action4outer.getINPUT_ZIPCODE();
							
							// �p�G���d��l���ϸ��A�B��5�X
							if(new_ZIP_CODE && new_ZIP_CODE.length == 5){
								// �ӥB�P��l���ϸ����P�A�h�мg
								if(new_ZIP_CODE != old_ZIP_CODE){
									action4outer.setINPUT_ZIPCODE(new_ZIP_CODE);
								}
							}
							// �p�G��l���ϸ���5�X
							else if(old_ZIP_CODE && old_ZIP_CODE.length == 5){
								alert("���a�}�L�k�d�������5�X�l���ϸ��A�Ч�ΤU�Կ����o�l���ϸ��I");
							}
							// ��L
							else{
								action4outer.setINPUT_ZIPCODE("");
								alert("���a�}�L�k�d�������5�X�l���ϸ��A�Ч�ΤU�Կ����o�l���ϸ��I");
							}
						};
						var errorAction = function(){
							var old_ZIP_CODE = action4outer.getINPUT_ZIPCODE();
							
							// �p�G�쥻�S���l���ϸ� or �l���ϸ�����5�X�A�h�M�Ŷl���ϸ��A�åB���X���ܰT��
							if(old_ZIP_CODE && old_ZIP_CODE.length != 5){
								action4outer.setINPUT_ZIPCODE("");								
							}
						}
						action.ajaxPost(actionName, params, successAction, errorAction);
					}else{
						action4outer.setINPUT_ZIPCODE("");
					}
				});
				td.insert(INPUT_ADDR);
				
				var config = {
					'id':td_ID + '_' + 'span_INPUT_ADDR'
				};
				span_INPUT_ADDR = tableElement.createElement("span", config);
				td.insert(span_INPUT_ADDR);
			}
			/** �ϥΤg�a�y����J�Φ� */
			else if(inputType == "3"){
				var config = {
					'id':td_ID + '_' + 'CITY_NAME'
					,'name':'CITY_NAME'
				};
				CITY_NAME = tableElement.createElement("select", config).disable();
				CITY_NAME.observe('change', action.cityChange);
				td.insert(CITY_NAME);
				
				var config = {
					'id':td_ID + '_' + 'TOWN_NAME'
					,'name':'TOWN_NAME'
				};
				TOWN_NAME = tableElement.createElement("select", config).disable();
				TOWN_NAME.observe('change', action.townChange);
				td.insert(TOWN_NAME);
				
				var config = {
					'id':td_ID + '_' + 'OFFICE_NAME'
					,'name':'OFFICE_NAME'
				};
				OFFICE_NAME = tableElement.createElement("select", config).disable();
				OFFICE_NAME.observe('change', action.officeChange);
				td.insert(OFFICE_NAME);
				
				var config = {
					'id':td_ID + '_' + 'OFFICE_CODE'
					,'name':'OFFICE_CODE'
					,'type':'hidden'
				};
				OFFICE_CODE = tableElement.createElement("input", config);
				td.insert(OFFICE_CODE);
				
				var config = {
					'id':td_ID + '_' + 'LAND_NAME1'
					,'name':'LAND_NAME1'
				};
				LAND_NAME1 = tableElement.createElement("select", config).disable();
				LAND_NAME1.observe('change', action.land1Change);
				td.insert(LAND_NAME1);
				
				var config = {
					'id':td_ID + '_' + 'LAND_NAME2'
					,'name':'LAND_NAME2'
				};
				LAND_NAME2 = tableElement.createElement("select", config).disable();
				LAND_NAME2.observe('change', action.land2Change);
				td.insert(LAND_NAME2);
				
				var config = {
					'id':td_ID + '_' + 'LAND_CODE'
					,'name':'LAND_CODE'
					,'type':'hidden'
				};
				LAND_CODE = tableElement.createElement("input", config);
				td.insert(LAND_CODE);
				
				var config = {
					'id':td_ID + '_' + 'span_LAND_LOCATED'
				};
				span_LAND_LOCATED = tableElement.createElement("span", config);
				td.insert(span_LAND_LOCATED);
			}
			/** �ϥΦa�F�ưȩҿ�J�Φ� */
			else if(inputType == "4"){
				var config = {
					'id':td_ID + '_' + 'CITY_NAME'
					,'name':'CITY_NAME'
				};
				CITY_NAME = tableElement.createElement("select", config).disable();
				CITY_NAME.observe('change', action.cityChange);
				td.insert(CITY_NAME);
				
				var config = {
					'id':td_ID + '_' + 'TOWN_NAME'
					,'name':'TOWN_NAME'
				};
				TOWN_NAME = tableElement.createElement("select", config).disable();
				TOWN_NAME.observe('change', action.townChange);
				td.insert(TOWN_NAME);
				
				var config = {
					'id':td_ID + '_' + 'OFFICE_NAME'
					,'name':'OFFICE_NAME'
				};
				OFFICE_NAME = tableElement.createElement("select", config).disable();
				td.insert(OFFICE_NAME);
				
				var config = {
					'id':td_ID + '_' + 'OFFICE_CODE'
					,'name':'OFFICE_CODE'
					,'type':'hidden'
				};
				OFFICE_CODE = tableElement.createElement("input", config);
				td.insert(OFFICE_CODE);
								
				var config = {
					'id':td_ID + '_' + 'span_LAND_LOCATED'
				};
				span_LAND_LOCATED = tableElement.createElement("span", config);
				td.insert(span_LAND_LOCATED);
			}
			
			action4outer.displayOnly(false);
		}
		/**change�ƥ�*/
		// �����O
		,cityChange:function(){
			// �s�ʲ��Ͷm�����ϧO�U�Կ��
			action.createTOWN_NAME();
		}
		// �m�����ϧO
		,townChange:function(office_NM){
			if(inputType == "1"){
				// �s�ʧ�s�l���ϸ��B�a�}���
				var cityName = action4outer.getCITY_NAME();
				var townName = action4outer.getTOWN_NAME();

				if(cityName && townName){
					var zipCode = zipCode_1[cityName][townName];
					var addr;
					if(cityName != townName){
						addr = cityName + townName;
					}else{
						addr = cityName;
					}
					
					action4outer.setINPUT_ZIPCODE(zipCode);
					action4outer.setINPUT_ADDR(addr);
				}else{
					action4outer.setINPUT_ZIPCODE("");
					action4outer.setINPUT_ADDR("");
				}
				
			}else if(inputType == "2"){
				// �s�ʲ��͸��W�U�Կ��
				action.createROAD_NAME();
			}else if(inputType == "3" || inputType == "4"){
				// �s�ʲ��ͦa�F�ưȩҤU�Կ��
				action.createOFFICE_NAME(office_NM);
			}
		}
		// ���W
		,roadChange:function(){
			// �s�ʲ��ͪ��P���X���s�U�Կ��
			action.createADDR_NAME();
		}
		// ���P���X���s
		,addrChange:function(){
			// �s�ʧ�s�l���ϸ�
			var addrName = action4outer.getADDR_NAME();
			
			if(addrName){
				var zipCode = zipCode_2[addrName];
				action4outer.setINPUT_ZIPCODE(zipCode);
			}else{
				action4outer.setINPUT_ZIPCODE("");
			}
		}
		// �a�F�ưȩ�
		,officeChange:function(){
			// �s�ʲ��ͦa�q�U�Կ��
			action.createLAND_NAME1();
		}
		// �a�q
		,land1Change:function(){
			// �s�ʲ��ͤp�q�U�Կ��
			action.createLAND_NAME2();
		}
		// �p�q
		,land2Change:function(){
			// �s�ʧ�s�a�q�p�q�N�X
			action.getLandCode(); 
		}
		// �a�}
		,addressChange:function(){
			
			var old_addr = action4outer.getINPUT_ADDR().trim();
			var length = old_addr.length;
			
			var result = "";
			for ( var i = 0 ; i < length ; i ++ ) {
				var val = old_addr.charAt(i) ;            
				var j = asciiTable.indexOf(val) * 6 ;        
				result += ( j > -1 ? unescape(big5Table.substring( j , j + 6 ) ) : val );    
			}
			  
			INPUT_ADDR.value = result;
		}
		/** ���o�ݭn����� */
		// ���o�����������O(by INPUT_TYPE)
		,createCITY_NAME:function(){
			selection.clean(CITY_NAME);
			CITY_NAME.disable();

			var actionName = "getCityNameList"; 
			var params = {"INPUT_TYPE":inputType};
			var successAction = function(resp){
				var cityNameList = resp.CITY_NAME_List;
				selection.createAll(CITY_NAME, cityNameList, "CITY_NAME", "CITY_NAME", "�п��");
				if(CITY_NAME.length > 0){
					CITY_NAME.enable();
				}else{
					CITY_NAME.disable();
				}
			};
			var errorAction = function(){
				if(CITY_NAME.length > 0){
					CITY_NAME.enable();
				}else{
					CITY_NAME.disable();
				}
			}
			action.ajaxPost(actionName, params, successAction, errorAction);
		}
		// ���o�������m�����ϧO(by INPUT_TYPE)
		,createTOWN_NAME:function(){
			var cityName = action4outer.getCITY_NAME();
			
			// ���M�šB�M�w���\�M���Ѯɭn���檺�ʧ@
			var action_S;
			var action_E;
			if(inputType == "1"){
				selection.clean(TOWN_NAME);
				TOWN_NAME.disable();
				
				action4outer.setINPUT_ZIPCODE("");
				action4outer.setINPUT_ADDR("");
				
				action_S = function(){
					if(TOWN_NAME.length > 0){
						
						TOWN_NAME.enable();
					}else{
						TOWN_NAME.disable();
					}
					
					if(cityName){
						var addr = cityName;
						action4outer.setINPUT_ADDR(addr);
					}
				};
				
				action_E = action_S;
			}else if(inputType == "2"){
				selection.clean(TOWN_NAME);
				TOWN_NAME.disable();
				
				selection.clean(ROAD_NAME);
				ROAD_NAME.disable();
				
				selection.clean(ADDR_NAME);
				ADDR_NAME.disable();
				
				action4outer.setINPUT_ZIPCODE("");
				action4outer.setINPUT_ADDR("");
				
				action_S = function(){
					if(TOWN_NAME.length > 0){
						TOWN_NAME.enable();
					}else{
						TOWN_NAME.disable();
					}
					
					if(cityName){
						var addr = cityName;
						action4outer.setINPUT_ADDR(addr);
					}
				};
				
				action_E = action_S;
			}else if(inputType == "3"){
				selection.clean(TOWN_NAME);
				TOWN_NAME.disable();
				
				selection.clean(OFFICE_NAME);
				OFFICE_NAME.disable();
				
				selection.clean(LAND_NAME1);
				LAND_NAME1.disable();
				
				selection.clean(LAND_NAME2);
				LAND_NAME2.disable();
				
				action4outer.setOFFICE_CODE("");
				action4outer.setLAND_CODE("");
				
				action_S = function(){
					if(TOWN_NAME.length > 0){
						TOWN_NAME.enable();
					}else{
						TOWN_NAME.disable();
					}
				};
				
				action_E = action_S;
			}else if(inputType == "4"){
				selection.clean(TOWN_NAME);
				TOWN_NAME.disable();
				
				selection.clean(OFFICE_NAME);
				OFFICE_NAME.disable();
				
				action4outer.setOFFICE_CODE("");
				
				action_S = function(){
					if(TOWN_NAME.length > 0){
						TOWN_NAME.enable();
					}else{
						TOWN_NAME.disable();
					}
				};
				
				action_E = action_S;
			}
			
			if(cityName){
				if(townList[cityName]){
					var townNameList = townList[cityName];

					selection.createAll(TOWN_NAME, townNameList, "TOWN_NAME", "TOWN_NAME", "�п��");
					
					if(Object.isFunction(action_S)){
						action_S();
					}
				}else{
					var actionName = "getTownNameList"; 
					var params = {"CITY_NAME":cityName, "INPUT_TYPE":inputType};
					var successAction = function(resp){
						var townNameList = resp.TOWN_NAME_List;
						
						/** cache */
						action.cache_townList(cityName, townNameList);

						selection.createAll(TOWN_NAME, townNameList, "TOWN_NAME", "TOWN_NAME", "�п��");
						
						if(inputType == "1"){
							action.createZipCode_1(cityName, townNameList);
						}
						
						if(Object.isFunction(action_S)){
							action_S();
						}
					};
					var errorAction = function(){
						if(Object.isFunction(action_E)){
							action_E();
						}
					}
					action.ajaxPost(actionName, params, successAction, errorAction);
				}
			}else if(Object.isFunction(action_E)){
				action_E();
			}
		}
		// ���o���������W(inputType == "2")
		,createROAD_NAME:function(){
			var cityName = action4outer.getCITY_NAME();
			var townName = action4outer.getTOWN_NAME();
			
			// ���M�šB�M�w���\�M���Ѯɭn���檺�ʧ@
			selection.clean(ROAD_NAME);
			ROAD_NAME.disable();
			
			selection.clean(ADDR_NAME);
			ADDR_NAME.disable();
			
			action4outer.setINPUT_ZIPCODE("");
			action4outer.setINPUT_ADDR("");

			var action_S = function(){
				if(ROAD_NAME.length > 0){
					ROAD_NAME.enable();
				}else{
					ROAD_NAME.disable();
				}
				
				if(cityName){
					var addr = cityName;
					
					if(townName){
						addr = cityName + townName;
					}
					action4outer.setINPUT_ADDR(addr);
				}
			};
			
			var action_E = action_S;
			
			if(cityName && townName){
				var key = cityName + "_" + townName;
				if(roadList[key]){
					var roadNameList = roadList[key];
					
					selection.createAll(ROAD_NAME, roadNameList, "ROAD_NAME", "ROAD_NAME", "�п��");
					
					if(Object.isFunction(action_S)){
						action_S();
					}
				}else{
					var actionName = "getRoadNameList"; 
					var params = {"CITY_NAME":cityName, "TOWN_NAME":townName};
					var successAction = function(resp){
						var roadNameList = resp.ROAD_NAME_List;
						
						/** cache */
						action.cache_roadList(key, roadNameList);
						
						selection.createAll(ROAD_NAME, roadNameList, "ROAD_NAME", "ROAD_NAME", "�п��");
						if(Object.isFunction(action_S)){
							action_S();
						}
					};
					var errorAction = function(resp){
						if(Object.isFunction(action_E)){
							action_E();
						}
					}
					action.ajaxPost(actionName, params, successAction, errorAction);
				}
			}else if(Object.isFunction(action_E)){
				action_E();
			}
		}
		// ���o���������P���X���s(inputType == "2")
		,createADDR_NAME:function(){
			var cityName = action4outer.getCITY_NAME();
			var townName = action4outer.getTOWN_NAME();
			var roadName = action4outer.getROAD_NAME();
			addr = cityName + townName + roadName;
			
			// ���M�šB�M�w���\�M���Ѯɭn���檺�ʧ@
			selection.clean(ADDR_NAME);
			ADDR_NAME.disable();
			
			action4outer.setINPUT_ZIPCODE("");
			action4outer.setINPUT_ADDR("");
			
			var action_S = function(){
				if(ADDR_NAME.length > 0){
					ADDR_NAME.enable();
				}else{
					ADDR_NAME.disable();
				}
				
				if(cityName){
					var addr = cityName;
					
					if(townName){
						addr = cityName + townName;
						
						if(roadName){
							addr = cityName + townName + roadName;
						}
					}
					action4outer.setINPUT_ADDR(addr);
				}
			};
			
			var action_E = action_S;
			
			if(cityName && townName && roadName){
				var key = cityName + "_" + townName + "_" + roadName;
				if(addrList[key]){
					var addrNameList = addrList[key];
					
					selection.createAll(ADDR_NAME, addrNameList, "ADDR_NAME", "ADDR_NAME", "�п��");
					
					if(Object.isFunction(action_S)){
						action_S();
					}
				}else{
					var actionName = "getAddrNameList"; 
					var params = {"CITY_NAME":cityName, "TOWN_NAME":townName, "ROAD_NAME":roadName};
					var successAction = function(resp){
						var addrNameList = resp.ADDR_NAME_List;

						/** cache */
						action.cache_addrList(key, addrNameList);
						
						selection.createAll(ADDR_NAME, addrNameList, "ADDR_NAME", "ADDR_NAME", "�п��");
						action.createZipCode_2(addrNameList);

						if(Object.isFunction(action_S)){
							action_S();
						}
					};
					var errorAction = function(resp){
						if(Object.isFunction(action_E)){
							action_E();
						}
					}
					action.ajaxPost(actionName, params, successAction, errorAction);
				}
			}else if(Object.isFunction(action_E)){
				action_E();
			}
		}
		// ���o�������a�F�ưȩ�(inputType == "3" or "4")
		,createOFFICE_NAME:function(office_NM){
			var cityName = action4outer.getCITY_NAME();
			var townName = action4outer.getTOWN_NAME();
			
			// ���M�šB�M�w���\�M���Ѯɭn���檺�ʧ@
			selection.clean(OFFICE_NAME);
			OFFICE_NAME.disable();
			
			if(inputType == "3"){
				selection.clean(LAND_NAME1);
				LAND_NAME1.disable();
				
				selection.clean(LAND_NAME2);
				LAND_NAME2.disable();
				
				action4outer.setLAND_CODE("");
			}
		
			action4outer.setOFFICE_CODE("");
						
			var action_S = function(){
				if(OFFICE_NAME.length > 0){
					OFFICE_NAME.enable();
				}else{
					OFFICE_NAME.disable();
				}
				
				action.getOfficeCode();
				if(inputType == "3"){
					action.createLAND_NAME1();
				}
			};
			
			var action_E = action_S;
			
			if(cityName && townName){
				var key = cityName + "_" + townName;
				if(officeList[key]){
					var officeNameList = officeList[key];
					
					if(officeNameList.length == 1){
						selection.createAll(OFFICE_NAME, officeNameList, "OFFICE_NAME", "OFFICE_NAME", "");
					}else{
						selection.createAll(OFFICE_NAME, officeNameList, "OFFICE_NAME", "OFFICE_NAME", "�п��", office_NM);
					}
					
					if(Object.isFunction(action_S)){
						action_S();
					}
				}else{
					var actionName = "getOfficeNameList"; 
					var params = {"CITY_NAME":cityName, "TOWN_NAME":townName};
					var successAction = function(resp){
						var officeNameList = resp.OFFICE_NAME_List;
						
						/** cache */
						action.cache_officeList(key, officeNameList);
						
						action.createOfficeCode_3(key, officeNameList);
						
						if(officeNameList.length == 1){
							selection.createAll(OFFICE_NAME, officeNameList, "OFFICE_NAME", "OFFICE_NAME", "");
						}else{
							selection.createAll(OFFICE_NAME, officeNameList, "OFFICE_NAME", "OFFICE_NAME", "�п��", office_NM);
						}
						
						if(Object.isFunction(action_S)){
							action_S();
						}
					};
					var errorAction = function(resp){
						if(Object.isFunction(action_E)){
							action_E();
						}
					}
					action.ajaxPost(actionName, params, successAction, errorAction);
				}
			}else if(Object.isFunction(action_E)){
				action_E();
			}
		}
		// ���o�������a�F�ưȩҥN�X
		,getOfficeCode:function(){
			var cityName = action4outer.getCITY_NAME();
			var townName = action4outer.getTOWN_NAME();
			var officeName = action4outer.getOFFICE_NAME();
			
			var key;
			var officeCode = "";
			if(cityName && townName){
				key = cityName + "_" + townName;
				
				if(officeName){
					officeCode = officeCode_3[key][officeName];
				}
			}
			action4outer.setOFFICE_CODE(officeCode);
		}
		// ���o�������a�q(inputType == "3")
		,createLAND_NAME1:function(){
			action.getOfficeCode();
			var officeCode = action4outer.getOFFICE_CODE();
			
			// ���M�šB�M�w���\�M���Ѯɭn���檺�ʧ@
			selection.clean(LAND_NAME1);
			LAND_NAME1.disable();
			
			selection.clean(LAND_NAME2);
			LAND_NAME2.disable();
			
			action4outer.setLAND_CODE("");
			
			var action_S = function(){
				if(LAND_NAME1.length > 0){
					LAND_NAME1.enable();
				}else{
					LAND_NAME1.disable();
				}
			};
			
			var action_E = action_S;
			
			if(officeCode){
				if(land1List[officeCode]){
					var landName1List = land1List[officeCode];
					
					selection.createAll(LAND_NAME1, landName1List, "LAND_NAME1", "LAND_NAME1", "�п��");
					
					if(Object.isFunction(action_S)){
						action_S();
					}
				}else{
					var actionName = "getLandName1List"; 
					var params = {"OFFICE_CODE":officeCode};
					var successAction = function(resp){
						var landName1List = resp.LAND_NAME1_List;
						
						/** cache */
						action.cache_land1List(officeCode, landName1List);
						
						selection.createAll(LAND_NAME1, landName1List, "LAND_NAME1", "LAND_NAME1", "�п��");
						
						if(Object.isFunction(action_S)){
							action_S();
						}
					};
					var errorAction = function(resp){
						if(Object.isFunction(action_E)){
							action_E();
						}
					}
					action.ajaxPost(actionName, params, successAction, errorAction);
				}
			}else if(Object.isFunction(action_E)){
				action_E();
			}
		}
		// ���o�������p�q(inputType == "3")
		,createLAND_NAME2:function(){
			var officeCode = action4outer.getOFFICE_CODE();
			var landName1 = action4outer.getLAND_NAME1();
			
			// ���M�šB�M�w���\�M���Ѯɭn���檺�ʧ@
			selection.clean(LAND_NAME2);
			LAND_NAME2.disable();
			
			action4outer.setLAND_CODE("");
			
			var action_S = function(){
				if(LAND_NAME2.length > 0){
					LAND_NAME2.enable();
				}else{
					LAND_NAME2.disable();
				}
				
				action.getLandCode();
			};
			
			var action_E = action_S;
			
			if(officeCode && landName1){
				var key = officeCode + "_" + landName1;
				if(land2List[key]){
					var landName2List = land2List[key];
					
					if(landName2List.length == 1){
						selection.createAll(LAND_NAME2, landName2List, "LAND_NAME2", "LAND_NAME2", "");
					}else{
						selection.createAll(LAND_NAME2, landName2List, "LAND_NAME2", "LAND_NAME2", "");
					}
					
					if(Object.isFunction(action_S)){
						action_S();
					}
				}else{
					var actionName = "getLandName2List"; 
					var params = {"OFFICE_CODE":officeCode, "LAND_NAME1":landName1};
					var successAction = function(resp){
						var landName2List = resp.LAND_NAME2_List;
						
						/** cache */
						action.cache_land2List(key, landName2List);
						
						action.createLandCode_3(key, landName2List, landName1);
						
						selection.createAll(LAND_NAME2, landName2List, "LAND_NAME2", "LAND_NAME2", "");
						
						if(Object.isFunction(action_S)){
							action_S();
						}
					};
					var errorAction = function(resp){
						if(Object.isFunction(action_E)){
							action_E();
						}
					}
					action.ajaxPost(actionName, params, successAction, errorAction);
				}
			}else if(Object.isFunction(action_E)){
				action_E();
			}
		}
		// ���o�������a�q�p�q�N�X
		,getLandCode:function(){
			var cityName = action4outer.getCITY_NAME();
			var townName = action4outer.getTOWN_NAME();
			var officeName = action4outer.getOFFICE_NAME();
			
			var key;
			var officeCode = "";
			if(cityName && townName){
				key = cityName + "_" + townName;
				
				if(officeName){
					officeCode = officeCode_3[key][officeName];
				}
			}
			action4outer.setOFFICE_CODE(officeCode);
			
			var officeCode = action4outer.getOFFICE_CODE();
			var landName1 = action4outer.getLAND_NAME1();
			var landName2 = action4outer.getLAND_NAME2();
			
			var key;
			var landCode = "";
			if(officeCode && landName1){
				key = officeCode + "_" + landName1;
				
				if(landName2){
					landCode = landCode_3[key][landName1];
				}else{
					landCode = landCode_3[key][landName2];
				}
			}
			action4outer.setLAND_CODE(landCode);
		}
		/** �N��Ʀs���S�w���榡 */
		// �N���o��TOWN_NAME_List�A�ഫ��{city'name':{town'name':zipCode}}
		,createZipCode_1:function(cityName, townNameList){
			var name_code = {};
			var length = townNameList.length;
			for(var i = 0; i < length; i++){
				name_code[townNameList[i].TOWN_NAME] = townNameList[i].POSTCODE;
			}
			zipCode_1[cityName] = name_code;
		}
		// �N���o��ADDR_NAME_List�A�ഫ��{road'name':zipCode}
		,createZipCode_2:function(addrNameList){
			var length = addrNameList.length;
			for(var i = 0; i < length; i++){
				var addrName = addrNameList[i].ADDR_NAME;
				
				if(addrName){
					var zipCode = addrName.substring(0, 5);
					zipCode_2[addrName] = zipCode;
				}
			}
		}
		// �N���o��OFFICE_NAME_List�A�ഫ��{cityName_town'name':{office'name':officeCode}}
		,createOfficeCode_3:function(key, officeNameList){
			var name_code = {};
			var length = officeNameList.length;
			for(var i = 0; i < length; i++){
				var officeName = officeNameList[i].OFFICE_NAME;
				var officeCode = officeNameList[i].OFFICE_CODE;
				if(officeName && officeCode){
					name_code[officeName] = officeCode;
				}
			}
			officeCode_3[key] = name_code;
		}
		// �N���o��LAND_NAME2_List�A�ഫ��{officeCode_landName1:{landName2(landName1):landCode}}
		,createLandCode_3:function(key, landName2List, landName1){
			var name_code = {};
			var length = landName2List.length;
			for(var i = 0; i < length; i++){
				var landName2 = landName2List[i].LAND_NAME2;
				var landCode = landName2List[i].LAND_CODE;
				if(landCode){
					if(landName2){
						name_code[landName1] = landCode;
					}else{
						name_code[landName2] = landCode;
					}
				}
			}
			
			landCode_3[key] = name_code;
		}
		/** cache */
		// �m�����ϧO��cache {city'name':townNameList}
		,cache_townList:function(key, townNameList){
			townList[key] = townNameList;
		}
		// ���W��cache {cityName_town'name':roadNameList}
		,cache_roadList:function(key, roadNameList){
			roadList[key] = roadNameList;
		}
		// ���P���X���s��cache {cityName_townName_road'name':addrNameList}
		,cache_addrList:function(key, addrNameList){
			addrList[key] = addrNameList;
		}
		// �a�F�ưȩҪ�cache {cityName_town'name':officeNameList}
		,cache_officeList:function(key, officeNameList){
			officeList[key] = officeNameList;
		}
		// �a�q��cache {officeCode:landName1List}
		,cache_land1List:function(key, landName1List){
			land1List[key] = landName1List;
		}
		// �p�q��cache {officeCode_landName1:landName2List}
		,cache_land2List:function(key, landName2List){
			land2List[key] = landName2List;
		}
		/** �@�Ρ�Ajax */
		,ajaxPost:function( actionName, params, successAction, errorAction){

			Ajax.Responders.unregister(CSRUtil.defaultAjaxHandler);
			
			new Ajax.Request( 
				"/EPWeb/servlet/HttpDispatcher" + "/EPZ0_1000/" + actionName,
				{ parameters: params,
				  asynchronous: false,
				  onSuccess: function(response) {
					var resp = response.responseJSON;

					if(CSRUtil.isSuccess(resp)){
						if(successAction){
							successAction(resp);
						}
					}else if(errorAction){
						errorAction(resp);
					}
					Ajax.Responders.register(CSRUtil.defaultAjaxHandler);
				}}
			);
		}
	};
	
	/** ���椸�����;� */
	var tableElement = {
		// ����tr
		createTR:function(config){
			var tr = tableElement.createElement('tr', config);
			return tr;
		},
		// ����td
		createTD:function(config){
			var td = tableElement.createElement('td', config);

			return td;
		},
		// ���ͤ���
		createElement:function(elementNM, config){
			var element = new Element(elementNM);
			tableElement.addAttributes(element, config);

			return element;
		},
		// �N�ݩʳ]�w�����w������
		addAttributes:function(element, config){
			if(config){
				var key = Object.keys(config);
				key.each(
					function(key){
						var attribute = config[key];
						if(attribute){
							element.writeAttribute(key, attribute);
						}
					}
				);
			}
		}
	};
	
	/** �U�Կ��ާ@ */
	var selection = {
		// �̷ӶǤJ��ƻPid�A���ͤU�Կ��
		createAll:function(target, optionList, valueKey, textKey, initialText, choiceValue, isCode_CodeNM){
			if(target){
				if(initialText){
					selection.create(target, "", initialText, "");
				}
				if(optionList){
					for(var i = 0; i < optionList.length; i++){
						if(isCode_CodeNM){
							selection.create(target, optionList[i][valueKey], optionList[i][valueKey] + " " + optionList[i][textKey], choiceValue);
						}else{
							selection.create(target, optionList[i][valueKey], optionList[i][textKey], choiceValue);
						}
					}
				}
			}
		}
		// ���ͳ�@�U�Կ��(�p�G�U�Կ�檺value == ��ƪ�Value�A�h�N��option��ܰ_��)
		,create:function(target, optionValue, optionText, choiceValue){
			target.insert(new Element('option', {value: optionValue}).update(optionText));
			
			if(choiceValue && optionValue == choiceValue){
				target.options[target.length - 1].selected = true;
			}
		}
		// �M�ŤU�Կ��
		,clean:function(target){
			target.update();
		}
	};
	
	// �N�X�P�������
	var keyNM = {
		"CITY_NAME":"�����O",
		"TOWN_NAME":"�m�����ϧO",
		"INPUT_ZIPCODE":"�l���ϸ�",
		"INPUT_ADDR":"�a�}",
		"ROAD_NAME":"���W",
		"ADDR_NAME":"���P���X���s",
		"OFFICE_NAME":"�a�F�ưȩ�",
		"OFFICE_CODE":"�a�F�ưȩҥN�X",
		"LAND_NAME1":"�a�q",
		"LAND_NAME2":"�p�q",
		"LAND_CODE":"�a�q�p�q�N�X"
	};

	/** ���ѵ��~���ϥΪ���k */
	var action4outer = {
		// �����O
		setCITY_NAME:function(cityName){
			var old_value = action4outer.getCITY_NAME();
			
			if(cityName || cityName == "0"){
				CITY_NAME.value = cityName;
			}else{
				CITY_NAME.value = "";
			}
			
			if(CITY_NAME.selectedIndex < 0){
				alert("�]�w����(" + cityName + ")���b�i�����O�j�U�Կ��̭�");
				CITY_NAME.value = old_value;
			}else{
				action.cityChange();
			}
		}
		,getCITY_NAME:function(){
			return CITY_NAME.value;
		}
		// �m�����ϧO
		,setTOWN_NAME:function(townName){
			var old_value = action4outer.getTOWN_NAME();
			
			//----- �S���B�z(Ex:�x�_�������ϥj�F or �x�_�������ϫئ�) -----
			var cityName = action4outer.getCITY_NAME();
			var office_NM;
			if(cityName == "�x�_��" && townName.indexOf("������") >= 0){
				if(townName.length > 3){
					townName = "������";
				}
			}
			//-----
			
			if(townName || townName == "0"){
				TOWN_NAME.value = townName;
			}else{
				TOWN_NAME.value = "";
			}

			if(TOWN_NAME.selectedIndex < 0){
				alert("�]�w����(" + townName + ")���b�i�m�����ϧO�j�U�Կ��̭�");
				TOWN_NAME.value = old_value;
			}else{
				action.townChange(office_NM);
			}
		}
		,getTOWN_NAME:function(){
			return TOWN_NAME.value;
		}
		// �l���ϸ�
		,setINPUT_ZIPCODE:function(zipCode){
			if(zipCode || zipCode == "0"){
				INPUT_ZIPCODE.value = zipCode;
				span_INPUT_ZIPCODE.update(zipCode);
			}else{
				INPUT_ZIPCODE.value = "";
				span_INPUT_ZIPCODE.update();
			}
		}
		,getINPUT_ZIPCODE:function(){
			return INPUT_ZIPCODE.value;
		}
		// �a�}
		,setINPUT_ADDR:function(inputAddr){
			if(inputAddr || inputAddr == "0"){
				INPUT_ADDR.value = inputAddr;
				span_INPUT_ADDR.update(inputAddr);
				action.addressChange();
			}else{
				INPUT_ADDR.value = "";
				span_INPUT_ADDR.update();
			}
		}
		,getINPUT_ADDR:function(){
			return INPUT_ADDR.value;
		}
		// ���W
		,setROAD_NAME:function(roadName){
			var old_value = action4outer.getROAD_NAME();
			
			if(roadName || roadName == "0"){
				ROAD_NAME.value = roadName;
			}else{
				ROAD_NAME.value = "";
			}
			
			if(ROAD_NAME.selectedIndex < 0){
				alert("�]�w����(" + roadName + ")���b�i���W�j�U�Կ��̭�");
				ROAD_NAME.value = old_value;
			}else{
				action.roadChange();
			}
		}
		,getROAD_NAME:function(){
			return ROAD_NAME.value;
		}
		// ���P���X���s
		,setADDR_NAME:function(addrName){
			var old_value = action4outer.getADDR_NAME();
			
			if(addrName || addrName == "0"){
				ADDR_NAME.value = addrName;
			}else{
				ADDR_NAME.value = "";
			}
			
			if(ADDR_NAME.selectedIndex < 0){
				alert("�]�w����(" + addrName + ")���b�i���P���X���s�j�U�Կ��̭�");
				ADDR_NAME.value = old_value;
			}else{
				action.addrChange();
			}
		}
		,getADDR_NAME:function(){
			return ADDR_NAME.value;
		}
		// �a�F�ưȩ�
		,setOFFICE_NAME:function(officeName){
			var old_value = action4outer.getOFFICE_NAME();
			
			if(officeName || officeName == "0"){
				OFFICE_NAME.value = officeName;
			}else{
				OFFICE_NAME.value = "";
			}
			
			if(OFFICE_NAME.selectedIndex < 0){
				alert("�]�w����(" + officeName + ")���b�i�a�F�ưȩҡj�U�Կ��̭�");
				OFFICE_NAME.value = old_value;
			}else if(inputType == "3"){
				action.officeChange();
			}
		}
		,getOFFICE_NAME:function(){
			return OFFICE_NAME.value;
		}
		// �a�F�ưȩҥN�X
		,setOFFICE_CODE:function(officeCode){
			if(officeCode || officeCode == "0"){
				OFFICE_CODE.value = officeCode;
			}else{
				OFFICE_CODE.value = "";
			}
		}
		,getOFFICE_CODE:function(){
			return OFFICE_CODE.value;
		}
		// �a�q
		,setLAND_NAME1:function(landName){
			var old_value = action4outer.getLAND_NAME1();
			
			if(landName || landName == "0"){
				//----- �S���B�z(Ex:�x�_��������) -----
				var cityName = action4outer.getCITY_NAME();
				var townName = action4outer.getTOWN_NAME();
				
				var office_NM;
				if(cityName == "�x�_��" && townName == "������"){
					var officeName = action4outer.getOFFICE_NAME();
					
					if(officeName == ""){	// �п��
						var officeLength = OFFICE_NAME.length;
						for(var i = 0; i < officeLength; i++){
							OFFICE_NAME.options[i].selected = true;
							action.officeChange();
							LAND_NAME1.value = landName;
							
							if(LAND_NAME1.selectedIndex >= 0){
								break;
							}
						}
					}
				}
				//-----
				
				LAND_NAME1.value = landName;
			}else{
				LAND_NAME1.value = "";
			}
			
			if(LAND_NAME1.selectedIndex < 0){
				alert("�]�w����(" + landName + ")���b�i�a�q�j�U�Կ��̭�");
				LAND_NAME1.value = old_value;
			}else{
				action.land1Change();
			}
		}
		,getLAND_NAME1:function(){
			return LAND_NAME1.value;
		}
		// �p�q
		,setLAND_NAME2:function(landName){
			var old_value = action4outer.getLAND_NAME2();
			
			if(landName || landName == "0"){
				LAND_NAME2.value = landName;
			}else{
				LAND_NAME2.value = "";
			}
			
			if(LAND_NAME2.selectedIndex < 0){
				alert("�]�w����(" + landName + ")���b�i�p�q�j�U�Կ��̭�");
				LAND_NAME2.value = old_value;
			}else{
				action.land2Change();
			}
		}
		,getLAND_NAME2:function(){
			return LAND_NAME2.value;
		}
		// �a�q�p�q�N�X
		,setLAND_CODE:function(landCode){
			if(landCode || landCode == "0"){
				LAND_CODE.value = landCode;
			}else{
				LAND_CODE.value = "";
			}
		}
		,getLAND_CODE:function(){
			return LAND_CODE.value;
		}
		// �ھڶǤJ��boolean�ȨӨM�w�O�_�n������
		,displayOnly:function(isDisplayOnly){
			isDisplay = isDisplayOnly;
			if(isDisplayOnly === true){
				if(inputType == "1"){
					CITY_NAME.hide();
					TOWN_NAME.hide();
					br.hide();
					
					action4outer.display4INPUT_ZIPCODE("1");
					action4outer.display4INPUT_ADDR("1");
				}else if(inputType == "2"){
					CITY_NAME.hide();
					TOWN_NAME.hide();
					ROAD_NAME.hide();
					ADDR_NAME.hide();
					br.hide();
					
					action4outer.display4INPUT_ZIPCODE("1");
					action4outer.display4INPUT_ADDR("1");
				}else if(inputType == "3"){
					CITY_NAME.hide();
					TOWN_NAME.hide();
					OFFICE_NAME.hide();
					LAND_NAME1.hide();
					LAND_NAME2.hide();
					
					span_LAND_LOCATED.update(action4outer.getCITY_NAME() + action4outer.getTOWN_NAME() + action4outer.getOFFICE_NAME() + action4outer.getLAND_NAME1() + action4outer.getLAND_NAME2());
					span_LAND_LOCATED.show();
				}else if(inputType == "4"){
					CITY_NAME.hide();
					TOWN_NAME.hide();
					OFFICE_NAME.hide();
					
					span_LAND_LOCATED.update(action4outer.getCITY_NAME() + action4outer.getTOWN_NAME() + action4outer.getOFFICE_NAME());
					span_LAND_LOCATED.show();
				}
			}else{
				if(inputType == "1"){
					CITY_NAME.show();
					TOWN_NAME.show();
					br.show();
					
					action4outer.display4INPUT_ZIPCODE("1");
					action4outer.display4INPUT_ADDR("2");
				}else if(inputType == "2"){
					CITY_NAME.show();
					TOWN_NAME.show();
					ROAD_NAME.show();
					ADDR_NAME.show();
					br.show();

					action4outer.display4INPUT_ZIPCODE("1");
					action4outer.display4INPUT_ADDR("2");
				}else if(inputType == "3"){
					CITY_NAME.show();
					TOWN_NAME.show();
					OFFICE_NAME.show();
					LAND_NAME1.show();
					LAND_NAME2.show();
					
					span_LAND_LOCATED.hide();
				}else if(inputType == "4"){
					CITY_NAME.show();
					TOWN_NAME.show();
					OFFICE_NAME.show();
					
					span_LAND_LOCATED.hide();
				}
			}
		}
		// ���o��������쪫��(by inputType)
		,getAllSelectObject:function(){
			var selectObjs = {};
			if(inputType == "1"){
				selectObjs["CITY_NAME"] = CITY_NAME;
				selectObjs["TOWN_NAME"] = TOWN_NAME;
				selectObjs["INPUT_ZIPCODE"] = INPUT_ZIPCODE;
				selectObjs["INPUT_ADDR"] = INPUT_ADDR;
			}else if(inputType == "2"){
				selectObjs["CITY_NAME"] = CITY_NAME;
				selectObjs["TOWN_NAME"] = TOWN_NAME;
				selectObjs["ROAD_NAME"] = ROAD_NAME;
				selectObjs["ADDR_NAME"] = ADDR_NAME;
				selectObjs["INPUT_ZIPCODE"] = INPUT_ZIPCODE;
				selectObjs["INPUT_ADDR"] = INPUT_ADDR;
			}else if(inputType == "3"){
				selectObjs["CITY_NAME"] = CITY_NAME;
				selectObjs["TOWN_NAME"] = TOWN_NAME;
				selectObjs["OFFICE_NAME"] = OFFICE_NAME;
				selectObjs["OFFICE_CODE"] = OFFICE_CODE;
				selectObjs["LAND_NAME1"] = LAND_NAME1;
				selectObjs["LAND_NAME2"] = LAND_NAME2;
				selectObjs["LAND_CODE"] = LAND_CODE;
			}else if(inputType == "4"){
				selectObjs["CITY_NAME"] = CITY_NAME;
				selectObjs["TOWN_NAME"] = TOWN_NAME;
				selectObjs["OFFICE_NAME"] = OFFICE_NAME;
				selectObjs["OFFICE_CODE"] = OFFICE_CODE;
			}
			
			return selectObjs;
		}
		// �ˮ����
		,checkData:function(validator, doNotCheckColumn, title){
			if(!validator){
				alert("�жǤJ�ˮ֪���");
				return;
			}
			
			var mode = "";
			if(validator instanceof Validation){
				if(!Validation.methods["customize_returnFalse"]){
					Validation.addAllThese([
                		[ 'customize_returnFalse', '�Цۭq�T��',
                			function(obj){
                				return false;
                			}
                		]
                	]);
				}
				mode = "1";
			}else if(validator instanceof Validator){
				mode = "2";
			}else{
				alert("�ثe���ˮ֪���ȴ���validator�Bvalidation���");
				return;
			}
			
			if(!title){
				title = "";
			}
			
			$$('#' + td_ID + ' select').each( 
				function(text){ 
					text.style.backgroundColor = '';
				}
			);
	
			$$('#' + td_ID + ' input').each( 
				function(text){ 
					text.style.backgroundColor = '';
				}
			);
				
			var checkColumn = {};
			
			// ���o�n�ˮ֪����
			function getCheckColumn(columns){
				$w(columns).each(
					function(key){
						if(doNotCheckColumn){
							if(!doNotCheckColumn[key]){
								checkColumn[key] = key;
							}
						}else{
							checkColumn[key] = key;
						}
					}
				);
			}
			
			function returnFalse(){
				return false;
			}
			
			if(inputType == "1"){
				getCheckColumn('CITY_NAME TOWN_NAME INPUT_ZIPCODE INPUT_ADDR');
			}else if(inputType == "2"){
				getCheckColumn('CITY_NAME TOWN_NAME ROAD_NAME ADDR_NAME INPUT_ZIPCODE INPUT_ADDR');
			}else if(inputType == "3"){
				getCheckColumn('CITY_NAME TOWN_NAME OFFICE_NAME OFFICE_CODE LAND_NAME1 LAND_NAME2 LAND_CODE');
			}else if(inputType == "4"){
				getCheckColumn('CITY_NAME TOWN_NAME OFFICE_NAME OFFICE_CODE');
			}
			
			var dataKey = Object.keys(checkColumn);
			
			dataKey.each(
				function(key){
					var newKey = td_ID + '_' + key;
					
					// ��ܡG����span
					if(isDisplay){
						// �Ȼ��ˮֶl���ϸ��B�a�}
						if(inputType == "1" || inputType == "2"){
							if(key == "INPUT_ZIPCODE" && (displaytype4ZIPCODE == "1" || displaytype4ZIPCODE == "2")){
								if($(newKey).value.length == 0){
									if(mode == "1"){
										validator.define( "customize_returnFalse" , [{ id :newKey , errMsg : title + keyNM[key] + "���i����"}]);
									}else if(mode == "2"){
										validator.define(newKey, "", title + keyNM[key] + "���i����" , returnFalse);
									}
								}								
							}
							
							if(key == "INPUT_ADDR" && (displaytype4ADDR == "1" || displaytype4ADDR == "2")){
								
							}
						}
						// ���span
						else {
							var tmpKey = td_ID + '_span_LAND_LOCATED';
							if($(tmpKey).innerHTML.length == 0){
								if(mode == "1"){
									validator.define( "customize_returnFalse" , [{ id :newKey , errMsg : "�g�a�y�����i����"}]);
								}else if(mode == "2"){
									validator.define(newKey, "", "�g�a�y�����i����", returnFalse);	
								}							
							}
						}
					}
					// ��ܡG�U�Կ��B�a�}��input�F�l���ϸ���span->
					else{
						if(key != "INPUT_ZIPCODE" && key != "INPUT_ADDR" && key != "LAND_NAME2"){
							var tagType = $(newKey).tagName.toLocaleLowerCase();
							if(tagType == "select"){
								if($(newKey).length > 1 && $(newKey).selectedIndex === 0){
									if(mode == "1"){
										validator.define( "customize_returnFalse" , [{ id :newKey , errMsg : "�п�ܤ@��" + keyNM[key]}]);
									}else if(mode == "2"){
										validator.define(newKey, "", "�п�ܤ@��" + keyNM[key], returnFalse);		
									}						
								}
							}else if(tagType == "input"){
								if($(newKey).value.length == 0){
									if(mode == "1"){
										validator.define( "customize_returnFalse" , [{ id :newKey , errMsg : title + keyNM[key] + "���i����"}]);
									}else if(mode == "2"){
										validator.define(newKey, "", title + keyNM[key] + "���i����", returnFalse);
									}
								}
							}
						}else{
							if(key == "INPUT_ZIPCODE" && (displaytype4ZIPCODE == "1" || displaytype4ZIPCODE == "2")){
								if($(newKey).value.length == 0){
									if(mode == "1"){
										validator.define( "customize_returnFalse" , [{ id :newKey , errMsg : title + keyNM[key] + "���i����"}]);
									}else if(mode == "2"){
										validator.define(newKey, "", title + keyNM[key] + "���i����" , returnFalse);
									}
								}								
							}
						}
					}
					
				}
			);
			
			if(inputType == "1" || inputType == "2"){
				// ���ެO�_���ˮ����A���|�ˮ֪���
				var key = "INPUT_ADDR";
				var newKey = td_ID + '_' + key;
				if($(newKey).value.length == 0){
					if(checkColumn["INPUT_ADDR"]){
						if(mode == "1"){
							validator.define( "customize_returnFalse" , [{ id :newKey , errMsg : title + keyNM[key] + "���i����"}]);
						}else if(mode == "2"){
							validator.define(newKey, "", title + keyNM[key] + "���i����" , returnFalse);
						}
					}
				}else{
					var check = true;
					if(validation){
						var value = $(newKey).value;
						var maxLength = $(newKey).maxLength;
						if(!validation.checkInputLength(value, maxLength)){
							if(mode == "1"){
								validator.define( "customize_returnFalse" , [{ id :newKey , errMsg : title + keyNM[key] + "���׶W�L" + maxLength}]);
							}else if(mode == "2"){
								validator.define(newKey, "", title + title + keyNM[key] + "���׶W�L" + maxLength, returnFalse);
							}
							check = false;
						}
					}
					
					if(check){
						var cityName = action4outer.getCITY_NAME();
						var townName = action4outer.getTOWN_NAME();
						
						var address;
						if(inputType == "1"){
							address = cityName + townName;
						}else if(inputType == "2"){
							var roadName = action4outer.getROAD_NAME();
							address = cityName + townName + roadName;
						}
						
						var addr = action4outer.getINPUT_ADDR();
						if(address && addr.indexOf(address)!=0){
							if(!confirm(title + keyNM[key] + "�P�U�Կ�椣�P�A�T�w�n�H�����ǡH(�|�v�T�l���ϸ������T��)" )){
								if(mode == "1"){
									validator.define( "customize_returnFalse" , [{ id :newKey , errMsg : title + keyNM[key] + "���~�A�ЦA���ˬd"}]);
								}else if(mode == "2"){
									validator.define(newKey, "", title + keyNM[key] + "���~�A�ЦA���ˬd", returnFalse);
								}
							}
						}
					}
				}
			}
		}
		// �M�wINPUT_ZIPCODE����ܤ覡("1":���span, "2":��Jinput, ��L��J������)
		,display4INPUT_ZIPCODE:function(displayType){
			displaytype4ZIPCODE = displayType;
			if(INPUT_ZIPCODE){
				if(displayType == "1"){	// show���span
					INPUT_ZIPCODE.hide();
					
					span_INPUT_ZIPCODE.update(action4outer.getINPUT_ZIPCODE());
					span_INPUT_ZIPCODE.show();
				}else if(displayType == "2"){	// show��Jinput
					INPUT_ZIPCODE.show();
					span_INPUT_ZIPCODE.hide();
				}else{	// ������
					INPUT_ZIPCODE.hide();
					span_INPUT_ZIPCODE.hide();
				}
			}
		}
		// �M�wINPUT_ADDR����ܤ覡("1":���span, "2":��Jinput, ��L��J������)
		,display4INPUT_ADDR:function(displayType){
			displaytype4ADDR = displayType;
			if(INPUT_ADDR){
				if(displayType == "1"){	// show���span
					INPUT_ADDR.hide();
					
					span_INPUT_ADDR.update(action4outer.getINPUT_ADDR());
					span_INPUT_ADDR.show();
				}else if(displayType == "2"){	// show��Jinput
					INPUT_ADDR.show();
					span_INPUT_ADDR.hide();
				}else{	// ������
					INPUT_ADDR.hide();
					span_INPUT_ADDR.hide();
				}
			}
		}
	};
	
	/** ��l�� */
	initial();
	
	/** �]�w���ѵ��~���ϥΪ���k */
	if(inputType == "1"){
		// �]�w�����O
		this.setCITY_NAME = action4outer.setCITY_NAME;
		
		// ���o�����O
		this.getCITY_NAME = action4outer.getCITY_NAME;
		
		// �]�w�m�����ϧO
		this.setTOWN_NAME = action4outer.setTOWN_NAME;
		
		// ���o�m�����ϧO
		this.getTOWN_NAME = action4outer.getTOWN_NAME;
		
		// �]�w�l���ϸ�
		this.setINPUT_ZIPCODE = action4outer.setINPUT_ZIPCODE;
				
		// ���o�l���ϸ�
		this.getINPUT_ZIPCODE = action4outer.getINPUT_ZIPCODE;
		
		// �]�w�a�}
		this.setINPUT_ADDR = action4outer.setINPUT_ADDR;
				
		// ���o�a�}
		this.getINPUT_ADDR = action4outer.getINPUT_ADDR;
		
		this.display4INPUT_ZIPCODE = action4outer.display4INPUT_ZIPCODE;
		this.display4INPUT_ADDR = action4outer.display4INPUT_ADDR;
	}else if(inputType == "2"){
		// �]�w�����O
		this.setCITY_NAME = action4outer.setCITY_NAME;
		
		// ���o�����O
		this.getCITY_NAME = action4outer.getCITY_NAME;
		
		// �]�w�m�����ϧO
		this.setTOWN_NAME = action4outer.setTOWN_NAME;
		
		// ���o�m�����ϧO
		this.getTOWN_NAME = action4outer.getTOWN_NAME;
		
		// �]�w���W
		this.setROAD_NAME = action4outer.setROAD_NAME;
		
		// ���o���W
		this.getROAD_NAME = action4outer.getROAD_NAME;
		
		// �]�w���P���X���s
		this.setADDR_NAME = action4outer.setADDR_NAME;
		
		// ���o���P���X���s
		this.getADDR_NAME = action4outer.getADDR_NAME;
		
		// �]�w�l���ϸ�
		this.setINPUT_ZIPCODE = action4outer.setINPUT_ZIPCODE;
				
		// ���o�l���ϸ�
		this.getINPUT_ZIPCODE = action4outer.getINPUT_ZIPCODE;
		
		// �]�w�a�}
		this.setINPUT_ADDR = action4outer.setINPUT_ADDR;
				
		// ���o�a�}
		this.getINPUT_ADDR = action4outer.getINPUT_ADDR;
		
		this.display4INPUT_ZIPCODE = action4outer.display4INPUT_ZIPCODE;
		this.display4INPUT_ADDR = action4outer.display4INPUT_ADDR;
	}else if(inputType == "3" || inputType == "4"){
		// �]�w�����O
		this.setCITY_NAME = action4outer.setCITY_NAME;
		
		// ���o�����O
		this.getCITY_NAME = action4outer.getCITY_NAME;
		
		// �]�w�m�����ϧO
		this.setTOWN_NAME = action4outer.setTOWN_NAME;
		
		// ���o�m�����ϧO
		this.getTOWN_NAME = action4outer.getTOWN_NAME;
		
		// �]�w�a�F�ưȩ�
		this.setOFFICE_NAME = action4outer.setOFFICE_NAME;
		
		// ���o�a�F�ưȩ�
		this.getOFFICE_NAME = action4outer.getOFFICE_NAME;
		
		// �]�w�a�F�ưȩҥN�X
		this.setOFFICE_CODE = action4outer.setOFFICE_CODE;
		
		// ���o�a�F�ưȩҥN�X
		this.getOFFICE_CODE = action4outer.getOFFICE_CODE;
		
		if(inputType == "3"){
			// �]�w�a�q
			this.setLAND_NAME1 = action4outer.setLAND_NAME1;
			
			// ���o�a�q
			this.getLAND_NAME1 = action4outer.getLAND_NAME1;
			
			// �]�w�p�q
			this.setLAND_NAME2 = action4outer.setLAND_NAME2;
			
			// ���o�p�q
			this.getLAND_NAME2 = action4outer.getLAND_NAME2;
			
			// �]�w�a�q�p�q�N�X
			this.setLAND_CODE = action4outer.setLAND_CODE;
			
			// ���o�a�q�p�q�N�X
			this.getLAND_CODE = action4outer.getLAND_CODE;
		}
	}
	
	// �����ܦa�}(true/false)
	this.displayOnly = action4outer.displayOnly;
	
	// ���o��������쪫��(by inputType)
	this.getAllSelectObject = action4outer.getAllSelectObject;
	
	// �ˮ����
	this.checkData = action4outer.checkData;
};