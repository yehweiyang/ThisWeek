//----------------------------------------------------------------
// propertyHelper object �t�d�ഫ�U�������������ͪ����� html element
//----------------------------------------------------------------
var propertyHelper = function(){
	
	//------------------------------------------------------------
	// private properties and functions
	//------------------------------------------------------------
	/** java privitive type key works */
	var primitiveTypesFilter = 'int|double|short|long|float|char|byte|boolean|java.lang.String|java.lang.Integer|java.lang.Double|java.lang.Short|java.lang.Float|java.lang.Byte|java.lang.Long|java.lang.Boolean|java.math.BigDecimal|java.math.BigInteger';

	//------------------------------------------------------------
	// public properties and functions
	//------------------------------------------------------------
	return{
		propertyAsHTML:function(prop, editable, id){

			if(!prop){
				return InputHelper.create(prop, editable);
			}
			
			var theClass = prop['javaClass'];
			
			if(!theClass && Object.isArray(prop)){
				/** Array params */
				return new ArrayTable({data:prop, id:id, editable:editable});
			}else if(DateHelper.isDateProp(prop)){
				/** Date type value */	
				return new DateTable({data:prop, id:id, editable:editable});	
			}else if(prop && theClass){
				if(theClass.indexOf('List')!=-1){
					return new ListTable({data:prop, id:id, editable:editable});
				}else if(theClass.indexOf('[]')!=-1){
					return new ListTable({data:prop, id:id, editable:editable});
				}else if(theClass.indexOf('Map')!=-1){	
					return new MapTable({data:prop, id:id, editable:editable});
				}else{
					return new ObjectTable({data:prop, id:id, editable:editable});	
				}
			}else if(prop && typeof(prop) == 'object'){
				//view only
				return new ObjectTable({data:prop, id:id, editable:false});
			}else if(Object.isString(prop) 
				     && (prop.startsWith('{') || prop.startsWith('[')) 
				     && prop.isJSON()){
				//view only
				return new ObjectTable({data:prop.evalJSON(true), id:id, editable:false});						
			}else{	
				/** Normal input text field */
				return InputHelper.create(prop, editable);								
			}
		},
		
		isJSONProperty:function(prop){
			if(Object.isString(prop) 
				&& (prop.startsWith('{') || prop.isJSON()) ){
				return true;		
			}
			return false;
		},
		
		isPrimitiveType:function(t){
			return (t.search(primitiveTypesFilter) == 0 && t.indexOf('[]') == -1);
		}	
	}
}();

//----------------------------------------------------------------
// $P shortcut to propertyHelper.propertygetHTML function
//----------------------------------------------------------------
var $P = propertyHelper.propertyAsHTML.bind(propertyHelper);

//----------------------------------------------------------------
// $Obj function for resolving the execution result.
//----------------------------------------------------------------
var $Obj = function(result){
	
	if(result == null || result == undefined){
		// return is null
		return '<NULL>';
	}else if(result.map && result.map.returnMessage){
		// handle the result with return message
		var msg = result.map.returnMessage;
		var o  = result.map.resultObject;
	
		if(msg.returnCode != 0){
			
			var msgStr = 'ReturnCode :' + msg.returnCode + "\n";
			for(var i=0; i<msg.msgDescs.length; i++){
				msgStr += "message " + i + " :" + msg.msgDescs[i] + "\n"; 	
			}			
			
			throw new Error(msgStr);
		}
		return o;
	}else{
		return result;
	}	
};


//----------------------------------------------------------------
// Date helper utility
//----------------------------------------------------------------
var DateHelper = {
	
	isDateProp:function(v){
		if(v){
			var propClass = v['javaClass'];
			if(propClass && (propClass.indexOf('Date') != -1 || propClass.indexOf('Time') != -1)){
				return true;
			}
		}
		return false;
	},
	
	padZero:function(v){
		if(v < 10){
			return '0' + v;
		}
		return v;
	},	
	
	dToYYMMDD:function(time, dType){
		if(!time) return null;
		var d = new Date(time);
		
		var str = d.getFullYear();
		var mon = DateHelper.padZero(d.getMonth() + 1);
		str += '-' + mon;
		
		if(dType.indexOf('Date') != -1){
			return 	str + '-' + DateHelper.padZero(d.getDate());	
		}else{
			return 	str + '-' + DateHelper.padZero(d.getDate()) + ' ' + DateHelper.padZero(d.getHours()) + ':' + DateHelper.padZero(d.getMinutes()) + ':' + DateHelper.padZero(d.getSeconds());
		}			
	},
	
	YYMMDDToD:function(str, dType){
		var year;
		var mon;
		var d;
		var h;
		var m;
		var s;
		
		if(str == '<NULL>') return null;
		
		try{
			str = str.strip();
			if(str.indexOf('-')!=-1){
				if(dType.indexOf('Date') != -1){
					var tmps = str.split('-');
					year = tmps[0];
					mon = tmps[1]-1;
					d = tmps[2];
					return new Date(year, mon, d).getTime();
				}else{
					var tmps = str.split(' ');
					var tmps1 = tmps[0].split('-');
					year = tmps1[0];
					mon = tmps1[1]-1;
					d = tmps1[2];
					
					tmps1 = tmps[1].split(':');
					h = tmps1[0];
					m = tmps1[1];
					s = tmps1[2];
					return new Date(year, mon, d, h, m, s).getTime();
				}
			}		
		}catch(Error){}
		return null;		
	}
};

//----------------------------------------------------------------
// Helper to create input element
//----------------------------------------------------------------
var InputHelper = {
	create:function(v, editable){
		
		if(Object.isUndefined(v) || v == null){
			v = '<NULL>';	
		}
		
		var inText;
		if(v && v.length > 50){
			inText = new Element('textarea', {'cols':60, 'rows': (v.length/60 + 1), 'value':v});
		}else{
			inText = new Element('input', {'type':'text', 'value':v, 'readOnly':!editable});	
			inText.setStyle({'width':'100%'});
		}
		inText.observe('focus', this.onfocus);
		inText.observe('blur', this.onblur);
		return inText;
	},
	
	onfocus:function(event){
		event.element().setStyle({'backgroundColor':'#ddd'});
	},
	
	onblur:function(event){
		event.element().setStyle({'backgroundColor':''});
	}
};

//----------------------------------------------------------------
// TesterClient class
//----------------------------------------------------------------
function TesterClient(){
	
	//------------------------------------------------------------
	// private properties and functions
	//------------------------------------------------------------
	/** JSONRPC client ���� */
	var client;         
	
	/** �ثe���ժ��l�t�ΥN�� */
	var currentSysID;  
	
	/** JSONRPC client ��l�O�_���\ */
	var active;
	
	/** �ثe���ժ��Ҳ� */
	var target;
	
	/** ���ժ���ƶ� */
	var caseDatas;
	
	//------------------------------------------------------------
	//  public functions
	//------------------------------------------------------------
	return{
		
		setEndPoint:function(sysID){
			active = false;
			if(sysID){
				client = new JSONRpcClient("/" + sysID + "Web/html/DevTool/tester/index.jsp?rpc=");
			}else{
				client = new JSONRpcClient("index.jsp?rpc=");
			}
			active = true;
			currentSysID = sysID;
			
		},// end of setTarget
		
		getProxy:function(name){
			if(active) return client[name];
			throw new Error('���դ�������l�����A�Х���w�l�t��');
		},
		
		execute:function(){
			var result;
			var obj = this.getProxy(arguments[0]);
			var mm =  obj[arguments[1]] ;
			var args = [];
			for(var i=2;i<arguments.length;i++){
				args.push(arguments[i]);
			}	
	 		result = mm.apply(obj, args);
			return result;
		},
		
		findAndRegister:function(name){
			
			var c = this.execute('CathayModuleAgent', 'findAndRegister', name);
			if(c){
				var ms = [];
				var n = c.registerName;
				var l = c.methods.list;
				for(var i=0; i<l.length; i++){
					ms[i] = n + "." + l[i].methodName;
				}
				// add the mod into local rpc client
				client._addMethods(ms);
				target = c;
				caseDatas = {};
			}			
			return c;		
		},
		
		/**
		 * �� function �B�z���խ����������󪺲��͡A
		 * �G�󦹳B�z�����ഫ
		 */
		createVO:function(className){
			
			if(className=='java.util.List'){
				className = 'java.util.ArrayList';
			}else if(className=='java.util.Map'){
				className = 'java.util.HashMap';	
			}else if(className=='java.util.Set'){
				className = 'java.util.HashSet';
			}else if(className == 'java.sql.Date' 
				     ||className == 'java.sql.Timestamp'){
				return {
					javaClass: className,
					time: -1
				};	
			}else if(className.indexOf('[]')!=-1){
				return [];
			}else if(className.indexOf('DataSet')!=-1){
				// DataSet, �H TestWrappedDataSet json ���c�����^��
				return {
					    javaClass:"com.cathay.test.db.TestWrappedDataSet", 
					    DS_NAME:"DS_" + target.registerName.substring(0, 2).toUpperCase()
					   };					
			}else if(className.indexOf('service.authenticate.UserObject')!=-1){
				//UserObject �H com.cathay.test.auth.TestWrappedUserObject ���N
				className = 'com.cathay.test.auth.TestWrappedUserObject';				
			}
			
			return this.execute('CathayModuleAgent', 'createVO', className);
		},
		
		getTarget:function(){
			return target;
		},
		
		keepCaseData:function(key, data){
			caseDatas[key] = data;
		},
		
		getCaseData:function(key){
			return caseDatas[key];
		}
		
	}// end of return
	//-- end of public method declared ---------------------------
}
//----------------------------------------------------------------
// end of TesterClient class
//----------------------------------------------------------------

//----------------------------------------------------------------
// DateTable class
//----------------------------------------------------------------
function DateTable(config){
	var id = config.id;
	var theObj = config.data;
	var className = theObj['javaClass'];
	var editable = config.editable;
	var inText;
	var table;
	var time = theObj['time'];
	
	function build(){
		table = new Element('table',
			 {
			 	'id':id,
			 	'cellspacing': 1,
			 	'class': 'inputTable'
			 });
		var tbody = new Element('tbody');
		table.insert({bottom: tbody});
		
		//header row
		var tr = new Element('tr');
		tr.insert(Element('td', {'class':'tbYellow'}).update('javaClass'));
		tr.insert(Element('td', {'class':'tbYellow2'}).update(className));
		tbody.insert(tr);
		
		//time value row
		tr = new Element('tr');
		tr.insert(Element('td', {'class':'tbYellow'}).update('time'));
		inText = InputHelper.create(DateHelper.dToYYMMDD(time, className), editable);
		var td = new Element('td', {'class':'tbYellow2'}).insert(inText);
		td.insert(new Element('br'));
		if(className.indexOf('Date') == -1){
			td.insert(new Element('span', {'class':'tbBlue'}).update('�榡(YYYY-MM-DD HH:MM:SS)'));
		}else{
			td.insert(new Element('span', {'class':'tbBlue'}).update('�榡(YYYY-MM-DD)'));
		}
		
		tr.insert(td);
		tbody.insert(tr);
	}
	
	build();
		
	//------------------------------------------------------------
	//  public functions
	//------------------------------------------------------------		
	return{
		getHTML:function(){
			return table;	
		},
		
		value: inText.value,
		
		toObject:function(){
			return {'javaClass':className, 'time':DateHelper.YYMMDDToD(inText.value, className)};
		}		
	}
}
//----------------------------------------------------------------
// end of DateTable class
//----------------------------------------------------------------

//----------------------------------------------------------------
// ObjectTable class
//----------------------------------------------------------------
function ObjectTable(config){

	//------------------------------------------------------------
	// private properties and functions
	//------------------------------------------------------------
	var id = config.id;
	
	var theObj = config.data;
	
	var className = theObj['javaClass'];
	
	var editable = config.editable;
	
	// object type property, reference as a ObjectTable too.
	var objectProperties = {};
	
	var table;
	
	function build(){

		table = new Element('table',
			 {
			 	'id':id,
			 	'cellspacing': 1,
			 	'class': 'inputTable'
			 });
		var tbody = new Element('tbody');
		table.insert({bottom: tbody});

		var tr = new Element('tr');
		tr.insert(new Element('td', {'class':'tbYellow'}).update('javaClass'));
		tr.insert(new Element('td', {'class':'tbYellow2'}).update(className));
		tbody.insert(tr);
	
		for(var p in theObj){
			
			if(p=='') continue;

			if(p == 'javaClass'){
				continue;
			}			
			
			var pv = theObj[p];
			
			//ingore the javascript function property
			if(typeof(pv) == 'function') continue;
			
			tr = new Element('tr');
			
			var pvObject = $P(pv, editable);
			
			if(pvObject.toObject){
				var link = new Element('a', {'class':'action'}).update(p);
				var tb = pvObject.getHTML();
				link.observe('click', function(event){
						this.toggle();
				}.bind(tb));
				tr.insert(new Element('td', {'class':'tbYellow'}).insert(link));
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(tb));
				tb.hide();
			}else{
				tr.insert(new Element('td', {'class':'tbYellow'}).update(p));
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(pvObject));
			}
			
			tbody.insert(tr);
			objectProperties[p] = pvObject;
		}
		
	}
	
	build();
	
	//------------------------------------------------------------
	//  public functions
	//------------------------------------------------------------
	return {
		
		getHTML:function(){
			table.impl = this;
			return table;
		},
		
		toObject:function(){
			// �N Table Input �ର JSON ����		
			var obj = {'javaClass':className};
			for(var p in objectProperties){
				var pv = objectProperties[p];
				if(Object.isFunction(pv.toObject)){
					obj[p] = pv.toObject();
				}else{
					if(pv.value == '<NULL>'){
						obj[p] = null;
					}else{
						obj[p] = pv.value;		
					}
				}
			}
			
			return obj;
		}
	
	}// end of return
	//-- end of public method declared ---------------------------
}
//----------------------------------------------------------------
// end of ObjectTable class
//----------------------------------------------------------------

//----------------------------------------------------------------
// ArrayTable class
//----------------------------------------------------------------
function ArrayTable(config){

	var id = config.id;
	
	var theAry = config.data;
	
	var inputs = [];
	
	var editable = config.editable;
	
	var table;
	
	function addElement(){
		
		theAry = htmlToObject();
		theAry.push('<NULL>');
		
		var container = table.up(0);
		table.remove();
		inputs = [];
		build();
		container.appendChild(table);		
	}
	
	function build(){
		
		if(Object.isUndefined(theAry)
			|| theAry == null){
			theAry = [];		
		}

		table = new Element('table',
			 {
			 	'id':id,
			 	'cellspacing': 1,
			 	'class': 'inputTable'
			 });
		var tbody = new Element('tbody');
		table.insert({bottom: tbody});

		var tr = new Element('tr');
		if(editable){
			var addLink = new Element('a', {'class':'action'}).update('add');
			addLink.observe('click', function(){
				addElement();
			});			
		}
		
		tr.insert(new Element('td', {'class':'tbYellow', 'colspan':2}).insert(addLink||''));

		tbody.insert(tr);
	
		for(var i=0; i<theAry.length; i++){
			var pv = theAry[i];

			//ingore the javascript function property
			if(typeof(pv) == 'function') continue;
			
			tr = new Element('tr');
			
			var pvObject = $P(pv, editable);
				
			var dlink = new Element('a', {'class':'action'}).update('del');
			dlink.observe('click', function(i){
				this.remove();
				theAry.splice(i, 1);
				inputs.splice(i, 1);
			}.bind(tr, i));
			
			var td; // the property td

			td = new Element('td', {'class':'tbYellow2'}).update(i);
			tr.insert(td);
			
			if(pvObject.toObject){
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(pvObject.getHTML()));
			}else{
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(pvObject));	
			}
			
			inputs[i] = pvObject;
			
			if(editable){
				td.insert(dlink);	
			}	
			
			tbody.insert(tr);
		}
	}
	
	build();
	
	function htmlToObject() {
		// �N Table Input �ର JSON ����		
		var list = [];
		for(var i=0; i<inputs.length; i++){
			var pv = inputs[i];
			if(pv.value == '<NULL>'){
				list[i] = null;
			}else{
				list[i] = pv.value;		
			}
		}
			
		return list;		
	}
	
	//------------------------------------------------------------
	//  public functions
	//------------------------------------------------------------
	return {
		getHTML:function(){
			table.impl = this;
			return table;
		},
		
		toObject:function(){
			return htmlToObject();
		}		
	}// end of return
	//-- end of public method declared ---------------------------	
	
}
//----------------------------------------------------------------
// end of ArrayTable class
//----------------------------------------------------------------

//----------------------------------------------------------------
// ListTable class
//----------------------------------------------------------------
function ListTable(config){
	//------------------------------------------------------------
	// private properties and functions
	//------------------------------------------------------------
	var id = config.id;
	
	var theObj = config.data;
	
	var className = theObj.javaClass;
	
	var editable = config.editable;
	
	//object type elements
	var propertyList = [];
	
	var table;
	
	function addElement(){
		
		theObj = htmlToObject();
		
		var c = prompt("�п�J VO �� Class �W��, �Y�n��J�r��B�Ʀr��ơA�Ы�����", "");
		if(c){
			//tester move to window level reference
			var vo = tester.createVO(c);
			if(vo){
				theObj.list.push(vo);	
			}
		}else{
			theObj.list.push('<NULL>');			
		}
		
		var container = table.up(0);
		table.remove();
		propertyList = [];
		build();
		container.appendChild(table);
	}
	
	function build(){
		
		if(Object.isUndefined(theObj.list)
			|| theObj.list == null){
			theObj.list = [];		
		}

		table = new Element('table',
			 {
			 	'id':id,
			 	'cellspacing': 1,
			 	'class': 'inputTable'
			 });
		var tbody = new Element('tbody');
		table.insert({bottom: tbody});

		var tr = new Element('tr');
		if(editable){
			var addLink = new Element('a', {'class':'action'}).update('add');
			addLink.observe('click', function(){
				addElement();
			});			
		}

		
		tr.insert(new Element('td', {'class':'tbYellow'}).update('javaClass').insert(addLink||''));
		tr.insert(new Element('td', {'class':'tbYellow2'}).update(className));
		tbody.insert(tr);
	
		var listProps = theObj.list;
		
		if(!listProps) listProps = [];
	
		for(var i=0; i<listProps.length; i++){
			var pv = listProps[i];

			//ingore the javascript function property
			if(typeof(pv) == 'function') continue;
			
			tr = new Element('tr');
			
			var pvObject = $P(pv, editable);
				
			var dlink = new Element('a', {'class':'action'}).update('del');
			dlink.observe('click', function(propertyList, i){
				this.remove();
				propertyList.splice(i, 1);
				theObj.list.splice(i, 1);
			}.bind(tr, propertyList, i));
			
			var td; // the property td
			if(pvObject.toObject){
				var tb = pvObject.getHTML();
				var link = new Element('a', {'class':'action'}).update(i);
				link.observe('click', function(){
					this.toggle();
				}.bind(tb));
					
				td = new Element('td', {'class':'tbYellow'});
				td.insert(link);
				
				tr.insert(td);
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(tb));
				tb.hide();
			}else{
				td = new Element('td', {'class':'tbYellow2'}).update(i);
				tr.insert(td);
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(pvObject));
			}
			
			if(editable){
				td.insert(dlink);	
			}	
			
			tbody.insert(tr);
			propertyList[i] = pvObject;
		}
	}
	
	function htmlToObject(){
		// �N Table Input �ର JSON ����		
		var obj = {'javaClass':className};
		var list = [];
		for(var i=0; i<propertyList.length; i++){
			var pv = propertyList[i];
			if(Object.isFunction(pv.toObject)){
				list[i] = pv.toObject();
			}else{
				if(pv.value == '<NULL>'){
					list[i] = null;
				}else{
					list[i] = pv.value;		
				}
			}
		}
			
		obj.list = list;
			
		return obj;		
	}
	
	build();
	
	//------------------------------------------------------------
	//  public functions
	//------------------------------------------------------------
	return {
		
		getHTML:function(){
			table.impl = this;
			return table;
		},
		
		toObject:function(){
			return htmlToObject();
		}
	
	}// end of return
	//-- end of public method declared ---------------------------	
}
//----------------------------------------------------------------
// end of ListTable class
//----------------------------------------------------------------

//----------------------------------------------------------------
// MapTable class
//----------------------------------------------------------------
function MapTable(config){
	//------------------------------------------------------------
	// private properties and functions
	//------------------------------------------------------------
	var id = config.id;
	
	var theObj = config.data;
	
	var className = theObj.javaClass;
	
	var editable = config.editable;
	
	//object type elements
	var properties = {};
	
	var table;
	
	function putElement(){
		var c = prompt("�п�J Map Key �r��", "");
		if(c){
			
			theObj = transfer();
			theObj.map[c] = '';
			
			var container = table.up(0);
			table.remove();
			properties = {};
			build();
			container.appendChild(table);
		}
	}
	
	function build(){
		
		if(Object.isUndefined(theObj.map)
			|| theObj.map == null){
			theObj.map = {};
		}

		table = new Element('table',
			 {
			 	'id':id,
			 	'cellspacing': 1,
			 	'class': 'inputTable'
			 });
		var tbody = new Element('tbody');
		table.insert({bottom: tbody});

		var tr = new Element('tr');
		if(editable){
			var putLink = new Element('a', {'class':'action'}).update('put');
			putLink.observe('click', function(){
				putElement();
			});			
		}
		
		tr.insert(new Element('td', {'class':'tbYellow'}).update('javaClass').insert(putLink||''));
		tr.insert(new Element('td', {'class':'tbYellow2'}).update(className));
		tbody.insert(tr);
	
		var props = theObj.map;
		
		for(var p in props){
			var pv = props[p]

			//ingore the javascript function property
			if(typeof(pv) == 'function') continue;
			
			tr = new Element('tr');
			
			var pvObject = $P(pv, editable);
				
			var dlink = new Element('a', {'class':'action'}).update('del');
			dlink.observe('click', function(propertyList, p){
				this.remove();
				delete properties[p];
				delete theObj.map[p];
			}.bind(tr, properties, p));
			
			var td; // the property td
			if(pvObject.toObject){
				var tb = pvObject.getHTML();
				var link = new Element('a', {'class':'action'}).update(p);
				link.observe('click', function(){
					this.toggle();
				}.bind(tb));
					
				td = new Element('td', {'class':'tbYellow'});
				td.insert(link);
				
				tr.insert(td);
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(tb));
				tb.hide();
			}else{
				td = new Element('td', {'class':'tbYellow2'}).update(p);
				tr.insert(td);
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(pvObject));
			}
			
			if(editable){
				td.insert(dlink);	
			}	
			
			tbody.insert(tr);
			properties[p] = pvObject;
		}
	}
	
	function transfer(){
		// �N Table Input �ର JSON ����		
		var obj = {'javaClass':className};
		var map = {};
		for(var p in properties){
			var pv = properties[p];
			if(Object.isFunction(pv.toObject)){
				map[p] = pv.toObject();
			}else{
				if(pv.value != '<NULL>'){
					map[p] = pv.value;		
				}
			}
		}
			
		obj.map = map;
			
		return obj;		
	}
	
	build();
	
	//------------------------------------------------------------
	//  public functions
	//------------------------------------------------------------
	return {
		
		getHTML:function(){
			table.impl = this;
			return table;
		},
		
		toObject:function(){
			return transfer();
		}
	
	}// end of return
	//-- end of public method declared ---------------------------	
}
//----------------------------------------------------------------
// end of MapTable class
//----------------------------------------------------------------

//----------------------------------------------------------------
// CaseDataEditView class
//----------------------------------------------------------------
function CaseDataEditView(config){
	
	/** ���ո�ƻ����� */
	var dataDescTb;
	
	/** ��J�Ѽư� */
	var inputParamTb;
	
	/** �w�����G�� */
	var resultTb;
	
	/** �s�� button */
	var saveBtn;
	
	/** ���� button */
	var canelBtn;
	
	/** ���� button */
	var testBtn;
	
	var objectProperties = {};
	
	/** element container */
	var panel;
	
	var caseData = config.caseData;
	
	var caseID = caseData.CASE_ID;
	
	var caseSEQ = caseData.CASE_SEQ;
	
	var createTime = caseData.CREATE_TIME;
	
	var methodDesc = config.methodDesc;
	
	var className = caseData.className;
	
	var methodName = caseData.methodName;
	
	var methodHash = methodDesc.methodHash;
	
	var inputDescs = [];
	
	var outputDesc;
	
	var win = config.win;
	
	var tester = config.tester;
	
	var callback = config.callback;
	
	var editable = Object.isUndefined(config.editable)?true:config.editable;
	
	
	function build(){
		panel = new Element('div');
		panel.setStyle({'width':'100%', 'height':'100%'});
		
		//�ո�ƻ����� ------------------------------------------------------------------
		dataDescTb = new Element('table',{
			 	'cellspacing': 1,
			 	'class': 'inputTable'
			 });
		var tbody = new Element('tbody');
		dataDescTb.insert(tbody);
		
		var tr = new Element('tr');
		tr.insert(new Element('td', {'class':'tbYellow'}).update('�ҲզW��'))
			.insert(new Element('td', {'class':'tbYellow2'}).update(caseData.className));
		tbody.insert(tr);			
		
		tr = new Element('tr');	
		tr.insert(new Element('td', {'class':'tbYellow'}).update('��k�\��W��'))
			.insert(new Element('td', {'class':'tbYellow2'}).update(caseData.methodName));			
		tbody.insert(tr);

		tr = new Element('tr');	
		tr.insert(new Element('td', {'class':'tbYellow'}).update('��ƻ���'));
		
		var td = new Element('td', {'class':'tbYellow2'});
		var inText = new Element('textarea', {'cols':60, 'rows': 3, 'value':caseData.MEMO||''});
		tr.insert(td.insert(inText));	
		tbody.insert(tr);
		objectProperties['MEMO'] = inText;
		// end of �ո�ƻ����� ----------------------------------------------------------
		
		//�հѿ�J�ƻ����� --------------------------------------------------------------
		inputParamTb = new Element('table',{
			 	'cellspacing': 1,
			 	'class': 'inputTable'
			 });
		tbody = new Element('tbody');
		inputParamTb.insert(tbody);
		
		tr = new Element('tr');
		tr.insert(new Element('td', {'colspan':'4', 'align':'center'}).update('���ո�ưѼƿ�J'));
		tbody.insert(tr);
		
		tr = new Element('tr');
		tr.insert(new Element('td', {'class':'tbBlue', 'align':'center', 'width':50}).update('�Ѽ�<br/>����'));
		tr.insert(new Element('td', {'class':'tbBlue', 'align':'center'}).update('�Ѽƻ���'));
		tr.insert(new Element('td', {'class':'tbBlue', 'align':'center'}).update('�Ѽƫ��A'));
		tr.insert(new Element('td', {'class':'tbBlue', 'align':'center'}).update('�ѼƸ��'));
		tbody.insert(tr);		
		
		var params = caseData['INPUT_PARAMS'];
		if(params){
			 params = params.evalJSON();
		}
			 
		var paramDescs = methodDesc['paramDescs'];
		var inputElements = [];
		var inText;
		objectProperties['INPUT_PARAMS'] = inputElements;
		
		for(var i=0; i<paramDescs.length; i++){
			var paramDesc = paramDescs[i];
			var pType = paramDesc.paramType;
			var pValue = null;
			if(params) pValue = params[i];
			
			tr = new Element('tr');
			tr.insert(new Element('td', {'align':'center', 'class':'tbYellow'}).update(paramDesc.seq));
			inText = $P(paramDesc.paramCName, true);
			tr.insert(new Element('td', {'class':'tbYellow2'}).insert(inText));
			inputDescs.push(inText);
			
			if(propertyHelper.isPrimitiveType(pType)){
				inText = $P(pValue, editable);
				tr.insert(new Element('td', {'class':'tbYellow2'}).update(pType));
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(inText));
				inputElements.push(inText);
			}else{
				if(!pValue){
					pValue = tester.createVO(pType);
				}
								
				var link = new Element('a', {'class':'action'}).update(pType);
				var pvObject = $P(pValue, editable);
				var tb = pvObject.getHTML();
				link.observe('click', function(event){
						this.toggle();
				}.bind(tb));
				tb.hide();
				
				tr.insert(new Element('td', {'class':'tbYellow2'}).update(link));
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(tb));
				inputElements.push(pvObject);
			}
			
			tbody.insert(tr);
		}
		// end of �հѿ�J�ƻ����� ------------------------------------------------------
		
		// �չw�����G��J�� -------------------------------------------------------------
		resultTb = new Element('table',{
			 	'cellspacing': 1,
			 	'class': 'inputTable'
			 });
		tbody = new Element('tbody');
		resultTb.insert(tbody);
		
		tr = new Element('tr');
		tr.insert(new Element('td', {'colspan':'3', 'align':'center'}).update('�w�����G�Ѽƿ�J'));
		tbody.insert(tr);
		
		tr = new Element('tr');
		tr.insert(new Element('td', {'class':'tbBlue', 'align':'center'}).update('�Ѽƻ���'));
		tr.insert(new Element('td', {'class':'tbBlue', 'align':'center'}).update('�Ѽƫ��A'));
		tr.insert(new Element('td', {'class':'tbBlue', 'align':'center'}).update('�ѼƸ��'));
		tbody.insert(tr);				
		
		var returnDesc = methodDesc['returnDesc'];
		var returnParam = caseData['OUTPUT_PARAMS'];
		var returnType = returnDesc['paramType'];
		
		tr = new Element('tr');
		inText = $P(returnDesc.paramCName, true);
		tr.insert(new Element('td', {'class':'tbYellow'}).insert(inText));
		outputDesc = inText;
		
		if(propertyHelper.isPrimitiveType(returnType)){
			
			tr.insert(new Element('td', {'class':'tbYellow'}).update(returnDesc.paramType));
			inText = $P(returnParam, editable);
			tr.insert(new Element('td', {'class':'tbYellow2'}).insert(inText));
			objectProperties['OUTPUT_PARAMS'] = inText;
			
		}else if(returnDesc['paramType'] == 'void'){
			
			tr.insert(new Element('td', {'class':'tbYellow2', 'colspan':2}).update('void'));
			objectProperties['OUTPUT_PARAMS'] = 'java.lang.Void';
			
		}else{
			//Object type result
			if(returnParam && propertyHelper.isJSONProperty(returnParam)){
				
				returnParam = returnParam.evalJSON();
				
			}else if(!Object.isString(returnParam)){
				
				returnParam = tester.createVO(returnType);
				
			}
			
			var link = new Element('a', {'class':'action'}).update(returnType);
			var pvObject = $P(returnParam, editable);
			
			if(pvObject.getHTML){
				var tb = pvObject.getHTML();
				link.observe('click', function(event){
						this.toggle();
				}.bind(tb));
				tb.hide();				
				tr.insert(new Element('td', {'class':'tbYellow2'}).update(link));
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(tb));				
			}else{
				tr.insert(new Element('td', {'class':'tbYellow2'}).insert(pvObject));					
			}
			
			objectProperties['OUTPUT_PARAMS'] = pvObject;
		}	
		tbody.insert(tr);
		// end of �չw�����G��J�� ------------------------------------------------------
		
		saveBtn = new Element('input', {'type':'button', 'value':'�x�s', 'class':'button'});
		cancelBtn = new Element('input', {'type':'button', 'value':'����', 'class':'button'});
		testBtn = new Element('input', {'type':'button', 'value':'����', 'class':'button'});
		
		if(tester.getTarget().txBean){
			//TxBean ���i�q������
			testBtn.disabled = true;	
		}
		
		panel.insert(dataDescTb);
		panel.insert(inputParamTb);
		panel.insert(resultTb);
		panel.insert(saveBtn);
		panel.insert(cancelBtn);
		panel.insert(testBtn);
	}
	
	function getValue(v){
		if(v == '<NULL>'){
			return null;	
		}else{
			return v;	
		}
	}
	
	build();
		
	return {
		
		init:function(){
			saveBtn.observe('click', this.saveHandler.bind(this));
			cancelBtn.observe('click', this.cancelHandler.bind(this));
			testBtn.observe('click', this.testHandler.bind(this));
		},
		
		saveHandler:function(event){
			// save �Ѽƻ��������� /////////////////////
			var saveParams = [];
			for(var i=0; i<inputDescs.length; i++){
				saveParams.push({
					javaClass:'com.cathay.test.ParameterDescriptor',
					methodHash:methodHash,
					seq:i,
					declareClass:className,
					declareMethod:methodName,
					paramCName:inputDescs[i].value
				});
			}
			
			saveParams.push({
					javaClass:'com.cathay.test.ParameterDescriptor',
					methodHash:methodHash,
					seq:-1,
					declareClass:className,
					declareMethod:methodName,
					paramCName:outputDesc.value				
			});
			
			tester.execute('ParameterDAO', 'updateDescriptions', {javaClass:'java.util.ArrayList', list:saveParams});
			
			//save �ѼƤ��e���� //////////////////////
			var caseData = this.toObject();
			var executeFunc = 'updateCaseLog';
			if(caseData['CASE_SEQ'] == 'X'){
				delete caseData.CASE_SEQ;
				executeFunc = 'addCaseLog';
			}else{
				caseData.CREATE_TIME = createTime;	
			}
			
			tester.execute('CaseLogDAO', executeFunc, 
					function(result, ex){
						if(ex){
							alert(ex);
						}else{
							alert('�s�W����');
						}	
						if(callback){
							callback();	
						}
					}, 
					caseData);			
		},
		
		cancelHandler:function(event){
			win.close();
		},
		
		testHandler:function(event){
			
			var newCaseData = this.toObject();
			var params = newCaseData.INPUT_PARAMS;
			if(params){
				params = params.evalJSON();	
			}
			
			var regName = className.split('.').last();
			
			var proxyObj = tester.getProxy(regName);
			var fn = proxyObj[newCaseData.methodName];
			
			var result;
							
			try{
				result = fn.apply(proxyObj, params);
				result = $Obj(result);
			}catch(error){
				
				//sever side excpetion trace
				if(error.trace){
					alert(error.trace);
				}else{
					var msg = '';
					for(var p in error){
						msg += error[p];	
					}
					
					alert(msg);					
				}
				
				return;
			}	
			
			newCaseData.OUTPUT_PARAMS = Object.toJSON(result);
			
			//rebuild the view
			caseData = newCaseData;
			
			build();
			
			this.init();
			
			win.updateContent(this.getHTML());
		},
				
		getHTML:function(){
			return panel;			
		},
		
		//�N��J������ର����
		toObject:function(){
			var caseObj = {
					   'javaClass':'com.cathay.test.CASE_LOG', 
					   'CASE_ID':caseID, 
					   'CASE_SEQ':caseSEQ,
					   'className':className,
					   'methodName':methodName,
					   'MEMO':objectProperties['MEMO'].value.truncate(100)
					  };
			
			//��X�J�ѼƤ��i�ק�
			if(!editable){
				caseObj.INPUT_PARAMS = caseData.INPUT_PARAMS;
				caseObj.OUTPUT_PARAMS = caseData.OUTPUT_PARAMS;
				return caseObj;
			}
			
			if(Object.isFunction(objectProperties['OUTPUT_PARAMS']['toObject'])){
				caseObj.OUTPUT_PARAMS = Object.toJSON(objectProperties['OUTPUT_PARAMS'].toObject());
			}else if(typeof(objectProperties['OUTPUT_PARAMS']) == 'string'){
				caseObj.OUTPUT_PARAMS = objectProperties['OUTPUT_PARAMS'];
			}else{
				caseObj.OUTPUT_PARAMS = getValue(objectProperties['OUTPUT_PARAMS'].value);
			}
			
			var paramInputs = objectProperties['INPUT_PARAMS'];
			var params = [];
			for(var i=0; i<paramInputs.length; i++){
				if(Object.isFunction(paramInputs[i]['toObject'])){
					params.push(paramInputs[i].toObject());	
				}else{
					params.push(getValue(paramInputs[i].value));
				}	
			}
			caseObj.INPUT_PARAMS = Object.toJSON(params);
					  
			return caseObj;
		}		
	}
}
//----------------------------------------------------------------
// End of CaseDataEditView class
//----------------------------------------------------------------

//----------------------------------------------------------------
// UploadResultView class
//----------------------------------------------------------------
function UploadResultView(config){
	var table;
	
	var caseLogs = config.caseLogs || [];
	
	var methodDesc = config.methodDesc;
	
	function build(){
		table = new Element('table', {
			 	'cellspacing': 1,
			 	'class': 'inputTable'
		});
		
		var tbody = new Element('tbody');
		table.insert(tbody);
		
		var tr = new Element('tr');
		var tr = new Element('tr', {'class':'tbBlue', 'align':'center'});
		tr.insert(new Element('td').update(''));
		tr.insert(new Element('td').update(methodDesc['returnDesc'].paramCName));
		
		var title = new Element('tr', {'class':'tbBlue', 'align':'center'});
		title.insert(new Element('td').update('���ո�ƻ���'));
		title.insert(new Element('td').update('�w���^�ǵ��G(' + methodDesc['returnDesc'].paramType + ')'));
		
		var paramDescs = methodDesc['paramDescs'];
		for(var i=0; i<paramDescs.length; i++){
			tr.insert(new Element('td').update(paramDescs[i].paramCName));
			title.insert(new Element('td').update('�Ѽ�' + i + '(' + paramDescs[i].paramType + ')'));
		}

		tbody.insert(tr);
		tbody.insert(title);
		
		for(var i=0; i<caseLogs.length; i++){
			var caseLog = caseLogs[i];
			tr = new Element('tr', {'class':(i%2==0)?'tbYellow2':'tbBlue3'});
			tr.insert(new Element('td', {'width':'20%'}).update(caseLog.MEMO));
			tr.insert(new Element('td', {'width':'15%'}).update(caseLog.OUTPUT_PARAMS));
			
			var params = caseLog.INPUT_PARAMS;
			
			if(params){
				 params = params.evalJSON();
			}
			
			for(var x=0; x<paramDescs.length; x++){
				var pType = paramDescs[x].paramType;
				
				var pValue = null;
				if(params) pValue = params[x];
				
				if(!pValue){
					tr.insert(new Element('td').update('&#60;NULL&#62;'));
					continue;	
				}
				
				if(propertyHelper.isPrimitiveType(pType)){
					tr.insert(new Element('td').update(pValue));
				}else if(pType.indexOf('Date') != -1 || pType.indexOf('Time')!=-1){
					//now only date type is support
					tr.insert(new Element('td').update(DateHelper.dToYYMMDD(pValue['time'], pType)));	
				}else{
					tr.insert(new Element('td').update('Object Not support'));
				}
			}			
			
			tbody.insert(tr);
		}	
	}
	
	build();
	
	return{
		getHTML:function(){
			return table;	
		}	
	}	
}
//----------------------------------------------------------------
// End of UploadResultViewView class
//----------------------------------------------------------------

//----------------------------------------------------------------
// DiffView class
//----------------------------------------------------------------
function DiffView(prospect, result){
	var table;
	
	function build(){
		
		table = new Element('table', {
			 	'cellspacing': 1,
			 	'class': 'inputTable',
			 	'display': 'none'
		});
		
		var tbody = new Element('tbody');
		table.insert(tbody);
		document.body.appendChild(table);
		
		if(Object.isArray(prospect) 
		   || typeof(prospect) == 'object'){
			
			buildResultGrid(tbody, prospect, result);
			
		}else{
			
			// build with other way
			var tr = new Element('tr');
			tr.insert(new Element('td', {'class':'tbBlue', 'align':'center', 'width':'50%'}).update('�w�����G'));
			tr.insert(new Element('td', {'class':'tbBlue', 'align':'center', 'width':'50%'}).update('���浲�G'));
			tbody.insert(tr);
			
			var tr = new Element('tr');
			
			tr.insert(new Element('td').insert(safeView($P(prospect))));
			tr.insert(new Element('td').insert(safeView($P(result))));
			tbody.insert(tr);
			
		}

	}
	
	function buildResultGrid(tbody, prospect, result){
		
		var columnTitle = [];
		
		var metaObj;

		var theClass = prospect['javaClass'];
		
		if(theClass && theClass.indexOf('List')!=-1){
			
			prospect = prospect.list || [];
			result = result.list || [];
			
			metaObj = prospect[0];
		}else{
			metaObj = prospect;			
		}
		
		for(var p in metaObj){
			
			if(Object.isFunction(metaObj[p])){
				continue;	
			}
			
			columnTitle.push(p);
		}
		
		var columns = [];
		
		columnTitle.each(function(it){
			columns.push({header:'�w��', dataIndex:it});
			columns.push({header:'���', dataIndex:it + '_rt01'});
		});
		
		//merge the prospect and result
		
		var datas = [];
		
		if(Object.isArray(prospect)){
			
			if(typeof(prospect[0])!='object'){
				prospect = [prospect];
				result = [result];
			}
			
			if(prospect.length == result.length){
				
				for(var i=0; i<prospect.length; i++){
					datas.push(mergeObj(prospect[i], result[i]));	
				}
				
			}else if(prospect.length > result.length){

				for(var i=0; i<prospect.length; i++){
					
					var rObj = result[i] || {};
					
					datas.push(mergeObj(prospect[i], rObj));	
				}
				
			}else{
				
				var emptyObj = Object.clone(prospect[0]);
				for(var p in emptyObj){
					emptyObj[p] = '';	
				}

				for(var i=0; i<result.length; i++){
					
					var pObj = prospect[i] || emptyObj;
					datas.push(mergeObj(pObj, result[i]));	
				}
				
			}
			
		}else{
			
			datas.push(mergeObj(prospect, result));
			
		}
		
		var grid = new GridPanelUI({
			
			id: tbody.identify(),
			
			column: columns,
			
			listeners: [{
				
				name: 'afterRender',
				handler: function(){
					
					var tb = $(tbody.identify());
					
					var th = tb.select('th');
					th.each(function(it){
						it.setStyle({'fontWeight':'normal'});
					});
					
					var titleRow = new Element('tr');
					titleRow.addClassName('tbBlue');
					
					columnTitle.each(function(it){
						var td = new Element('td', {'colspan':'2', 'align':'center'});
						td.update('&nbsp;' + it + '&nbsp;&nbsp;&nbsp;');
						
						var box = new Element('input', {'type':'checkbox'});
						box.addClassName('textBox2');
						box.setStyle({'border':'0'});
						box.titleName = it;
						
						td.insert({top: box});						
						titleRow.insert(td);
					});
					
					tb.insert({top: titleRow});
					
					var buttonRow = new Element('tr');
					buttonRow.addClassName('tbYellow');
					var td = new Element('td', {'colspan':(columnTitle.length * 2)});
					td.setStyle({'padding':'5px'});
					buttonRow.insert(td);
					
					var btn = new Element('input', {'type':'button', 'value':'�U����ﵲ�G(�ФĿ���U�������)'});
					btn.addClassName('button');
					btn.setStyle({'padding':'2px', 'border':'1px solid #006600'});
					td.insert(btn);
					
					tb.insert(buttonRow);
					
					grid.getButtomContainer().setAttribute("align", "LEFT");
					
					btn.observe('click', function(e){
						
						var checkedBox = tb.select('input:checked');
						
						if(checkedBox.length == 0){
							alert('�Х��Ŀ����');
							return;
						}
						
						var titles = [];
						checkedBox.each(function(box){
							titles.push(box.titleName || '');
						});
						
						var className = $F('module_name');
						var seleM = $('methods');
						var opt = seleM.options[seleM.selectedIndex];
						
						var form = new Element('form', {'method':'post', 'action':UICore.webBase + '/html/QA/B0/QAB0_0100/downloadCompare.jsp', 'target':'_blank'});
						form.setStyle({'display':'none'});
						form.insert(
							new Element('input', {'type':'hidden', 'name':'className', 'value':className})
						).insert(
							new Element('input', {'type':'hidden', 'name':'methodName', 'value':opt.text})
						).insert(
							new Element('input', {'type':'hidden', 'name':'title', 'value':Object.toJSON(titles)})
						).insert(
							new Element('input', {'type':'hidden', 'name':'datas', 'value':Object.toJSON(grid.getRecords())})
						);												
						
						document.body.appendChild(form);
						form.submit();
						form.remove();							
						
					});
					
					var chkBtn = new Element('input', {'type':'button', 'value':'����/����'});
					chkBtn.addClassName('button');
					chkBtn.setStyle({'padding':'2px', 'border':'1px solid #006600', 'marginLeft':'10px'});
					td.insert(chkBtn);
					
					chkBtn.observe('click', function(e){
						
						var elem = e.element();
						var boxs = tb.select('input[type="checkbox"]');
						
						if(elem.checkedV){
							elem.checkedV = false;	
						}else{
							elem.checkedV = true;
						}
						
						boxs.each(function(box){
							box.checked = elem.checkedV;
						});
						
					});
					
				}
				
			}],
			
			page:{size: 10}
		
		});
		
		grid.render();
		
		grid.load(datas);
			
	}
	
	function mergeObj(prospect, result){
		
		var obj = {};
			
		for(var	p in prospect){
			
			var v = prospect[p];
			if(Object.isFunction(v)){
				continue;	
			}
			
			var elem = $P(v);
			
			obj[p] = elem.value || safeView(elem).innerHTML;
			
			elem = $P(result[p]);
			
			obj[p + '_rt01'] =  elem.value || safeView(elem).innerHTML;
		}
		
		return obj;

	}
	
	function safeView(view){
		if(Object.isFunction(view.getHTML)){
			return view.getHTML();
		}
		return view;
	}
	
	build();
	
	return{
		getHTML:function(){
			
			table.setStyle({'display':''});
			table.remove();
			
			return table;	
		}	
	}
}
//----------------------------------------------------------------
// end of DiffView class
//----------------------------------------------------------------

//----------------------------------------------------------------
// EditWin class
//----------------------------------------------------------------
var zIndexHolder = {};
zIndexHolder.indexCnt = 10;
function EditWin(){
	
	var win;
	var titleDiv;
	var contentDiv;
	var bottomDiv;
	var active;
	var winTitle;
	var iframe; //for block select element
	var x, y, w, h;
	var dragDiv;
	var dragTD;
	var sizer;
	var minW = 100;
	var minH = 100;
	var hs = 0;
	var callback;
	
	function build(){
		dragDiv = new Element('div');
		dragDiv.setStyle({
			'border':'solid 1px #000',
			'position': 'absolute'
		});
		
		iframe = new Element('iframe');
		iframe.setStyle({
			'frameborder': 0,
			'scrolling': 'no',
			'src':'javascript:false',
			'margin': 0,
			'width': '99%',
			'height': '99%',
			'position': 'absolute',
			'top': 0,
			'left': 0,
			'zIndex': -1
		});
		win = new Element('div');	
		win.setStyle({
			'position': 'absolute',
			'border': '2px solid #000',
			'zIndex': zIndexHolder.indexCnt++,
			'backgroundColor': '#C7E497'
		});

		titleDiv = new Element('div');
		titleDiv.setStyle({
			'border-bottom':'1px solid #000',
			'backgroundColor': '#C7E497'
		});
		titleDiv.update('<table width="100%" border="0"><tr><td width="95%" align="left" style="padding-left:10px; color:#336600;font-weight: bold;cursor:move;">���ո�ƽs�����</td><td align="right"><input type="image" src="' + base + 'close.gif" /></td></tr></table>');
		
		var closeBtn = titleDiv.select('input');
		closeBtn[0].observe('click', function(event){
			win.remove();	
			active = false;
			Event.stop(event);
			
			if(!Object.isUndefined(callback) && Object.isFunction(callback)){
				callback();	
			}
			
		});
		
		bottomDiv = new Element('div');
		bottomDiv.setStyle({
			'border-top':'1px solid #000',
			'backgroundColor': '#C7E4AA'
		});
		bottomDiv.update('<table width="100%" border="0" cellpadding="0" cellspacing="0" style=" border-collapse: collapse; padding:0; margin:0;" ><tr><td style="background:transparent url(' + base + 'bottom_mid.gif) repeat-x 0 0;height: 19px"></td><td style="background:transparent url(' + base +'bottom_right_resize.gif) no-repeat 0 0; width:9px; height:19px; cursor:se-resize;"></td></tr></table>');		
		sizer = bottomDiv.select('td')[1];
		sizer.observe('mousedown', startDrag);
		
		contentDiv = new Element('div');
		contentDiv.setStyle({
			'backgroundColor': '#F3FBC6',
			'overflow':'auto'
		});
		
		win.insert(titleDiv);
		win.insert(iframe);
		win.insert(contentDiv);
		win.insert(bottomDiv);
		dragTD = titleDiv.select('td')[0];
		dragTD.observe('mousedown', startDrag);
		win.observe('click', changeZindex);

	}
	
	function changeZindex(){
		if(win.style.zIndex < zIndexHolder.indexCnt){
			win.style.zIndex = zIndexHolder.indexCnt++;	
		}
	}
	
	function adjust(w, h){
		
		if(!w){
			w = win.getWidth();	
		}
		
		if(!h){
			h = win.getHeight();			
		}
		
		titleDiv.setStyle({
			'width':w
		});
		
		contentDiv.setStyle({
			'width':w,
			'height':h - hs
		});
		
		bottomDiv.setStyle({'width':w});
		bottomDiv.select('td')[0].setStyle({
			'width':(w-9)
		});
					
	}
    
    function startDrag(event){
    	event.element().stopObserving('mousedown', startDrag);
        x = Event.pointerX(event);
        y = Event.pointerY(event);
        
        var pos = win.positionedOffset();

	    dragDiv.setStyle({
	      	'width':win.getWidth(),
	       	'height':win.getHeight(),
	       	'left':pos.left,
	       	'top':pos.top,
	       	'zIndex':zIndexHolder.indexCnt++
	    });
        
        document.body.appendChild(dragDiv);
        dragDiv.show();
        
        if(event.element() == dragTD){
	        w = x - pos.left;
	        h = y - pos.top;
	    
	        Event.observe(document, 'mousemove', drag);
	        Event.observe(document, 'mouseup', stopDrag);
 	    }else{
 	    	w = pos.left;
 	    	h = pos.top;
 	    	Event.observe(document, 'mousemove', sizing);
 	    	Event.observe(document, 'mouseup', resize);
 	    }

    }	
    
    function sizing(event){
        x = Event.pointerX(event);
        y = Event.pointerY(event);
        Event.stop(event);
        
        var dy = y - h;
        var dx = x - w;
        if(dy < minH){
        	dy = minH;	
        }
        
        if(dx < minW){
        	dx = minW;	
        }
        
		dragDiv.setStyle({
			height:dy + 'px',
			width:dx + 'px'
		});
		win.hide();        
    }
    
    function resize(event){
    	Event.stopObserving(document, 'mousemove', sizing);
    	Event.stopObserving(document, 'mouseup', resize);
    	Event.stop(event);
    	
    	win.setStyle({
    		width: dragDiv.getWidth() + 'px',
    		height: dragDiv.getHeight() + 'px'
    	});

		adjust(dragDiv.getWidth(), dragDiv.getHeight());
		
		dragDiv.remove();
        //document.body.appendChild(win);
        win.show();
        sizer.observe('mousedown', startDrag);
        changeZindex();
        
    }
    
    function drag(event){

        x = Event.pointerX(event);
        y = Event.pointerY(event);
		Event.stop(event);    
		
		dragDiv.setStyle({
			top:(y - h) + 'px',
			left:(x - w) + 'px'
		});
		win.hide();
    }    
    
    function stopDrag(event){
    	Event.stopObserving(document, 'mousemove', drag);
    	Event.stopObserving(document, 'mouseup', stopDrag);
    	
        Event.stop(event);
        
        var pos = dragDiv.positionedOffset();
        win.setStyle({
        	top:pos.top,
        	left:pos.left
        });
        dragDiv.remove();
        //document.body.appendChild(win);
        win.show();
        dragTD.observe('mousedown', startDrag);
        changeZindex();
    }    
	
	build();
	
	return{
		
		updateContent: function(newContent){
			if(!active) return;
			contentDiv.update(newContent);
		},
		
		openWin:function(config){
			if(!active){
				win.style.width = config['width']||"750";
	        	win.style.height = config['height']||"550";
	        	win.style.left = config['left']||"150";
	        	win.style.top = config['top']||"100";
	        	document.body.appendChild(win);
	        	
	        	contentDiv.update(config.content);
	        	
	        	if(config.title){
	        		var td = titleDiv.select('td');
	        		td[0].update(config.title);	
	        	}
	        	
	        	hs = titleDiv.getHeight() + bottomDiv.getHeight();
	        	callback = config.callback || undefined;
	        	
			}else{
				this.updateContent(config.content);	
			}
			
			active = true;
			adjust();

		},
		
		close:function(){
			win.remove();	
			active = false;
		}
	}
}
//----------------------------------------------------------------
// end of EditWin class
//----------------------------------------------------------------