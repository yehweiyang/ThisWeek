/*
 * USE XMLHttpRequest to Load the js lib
 */
var CaseLoader = (function(){

	var d = document;
	var client;   //rpc client
	var CASE_ID;
	var CASE_SEQ;
	var fn;       //callback
	var caseLog;  //CASE_LOG data
	var CaseLogDAO;
	var EDIT_TXBEAN_CASE_LOG_ID = 'EDIT_TXBEAN_CASE_LOG_ID';  // name for edit case use
	var EDIT_TXBEAN_CASE_LOG_SEQ = 'EDIT_TXBEAN_CASE_LOG_SEQ';// name for edit case use
	
	//a global handle for Ajax.Request if needed
	var caseReqHandler = {
		onCreate: function(request, transport, json){
			//add edit case params to request header
			if(request.options){
						
				if(request.options.requestHeaders){
					request.options.requestHeaders.EDIT_TXBEAN_CASE_LOG_ID = CASE_ID;
					request.options.requestHeaders.EDIT_TXBEAN_CASE_LOG_SEQ = CASE_SEQ;
				}else{
					request.options.requestHeaders = {
						EDIT_TXBEAN_CASE_LOG_ID: CASE_ID,
						EDIT_TXBEAN_CASE_LOG_SEQ: CASE_SEQ
					};
				}
					
			}
		}
	};
	
	function tag(name){
		return d.getElementsByTagName(name);
	}
	
	function _loadCase(){
		
		if(!canLoad()) return;

		try{
			caseLog = CaseLogDAO.findCaseLogByPK(CASE_ID, CASE_SEQ);	
		}catch(error){
			alert('Fail to find the Case , CASE_ID = ' + CASE_ID + ' and CASE_SEQ = ' + CASE_SEQ);
			throw error;
		}			
		
  		var req = caseLog.INPUT_PARAMS;
  		req = eval(req)[0];
  		restore(req);
  		
  		//pass back the request in CASE_LOG
  		if(fn != undefined){
  			fn(req);
  		}
  		
  		//try to add hidden element in any forms
  		var forms = tag('form');
  		if(forms){
  			for(var i=0; i<forms.length; i++){
  				forms[i].appendChild(createHiddenEle(EDIT_TXBEAN_CASE_LOG_ID, CASE_ID));
  				forms[i].appendChild(createHiddenEle(EDIT_TXBEAN_CASE_LOG_SEQ, CASE_SEQ));
  				
  			}	
  		}
  		
  		//try to add Request Handler for Prototype AjaxRequest
  		if(Prototype){
  			Ajax.Responders.register(caseReqHandler);		
  		}
  		
	}
	
	function createHiddenEle(name, value){
		
		var elem = d.createElement('input');
		elem.type = 'hidden';
		elem.name = name;
		elem.value = value;
		
		return elem;
				
	}
	
	function restore(obj){
		for(var p in obj){
			
			var val = obj[p];
			if(typeof(val) == 'string' && (val.indexOf('{') == 0 || val.indexOf('[') == 0)){
				obj[p] = eval('(' + val + ')');
				restore(obj[p]);
			}
			
		}		
	}
	
	/* simple check if we can load the case from JSONRpc */
	function canLoad() {
		return (CASE_ID != undefined && CASE_SEQ != undefined && CaseLogDAO != undefined);
	}
	
	/* guess the host url from windonw location */
	function guessHostLoacation() {
	
		var matchs = window.location.toString().match(/(\/[\w]+Web\/)/);
		
		if(matchs){
			return matchs[0];
		}	
		
		return '';
	}
	
	/* for advance usage */
	function getProxy(regName){
		if(client != undefined){
			return client[regName];	
		}	
	}
	
	/* default page recovery function */
	function defaultRecovery() {
		
	}
	
	return {
		
		/* load javascript */
		js:function(libName){
			
			var host = guessHostLoacation();
			
			var jsText = new CaseLoader.Request().getText(host + 'html/DevTool/tester/index.jsp?js=' + libName);
			
			try{
				
				if(jsText){
					eval(jsText);
				}				
				
				client = new JSONRpcClient(host + 'html/DevTool/tester/index.jsp?rpc=');	
				
			}catch(err){
				alert('Fail to create JSONRpcClient from [' +  host + 'html/DevTool/tester/index.jsp?rpc=] from Lib :' + libName);
				return;	
			}
						
			CaseLogDAO = client['CaseLogDAO'];
			_loadCase();														

		},
		
		loadCase:function(caseID, caseSEQ, cbfn){
			
			CASE_ID = caseID,
			CASE_SEQ = caseSEQ;
			fn = cbfn;
			
			_loadCase();			
			
		}
		
	};
	
})();

//--------------------------------------------------------
//Request class define
CaseLoader.Request = function(){
	
	try{
		this._req = new XMLHttpRequest();
		return;
	}catch(e){}
		
	try {
	    this._req = new ActiveXObject('Microsoft.XMLHTTP');
	    return;
	}catch(e){}
			
	try {
	    this._req = new ActiveXObject('Msxml2.XMLHTTP');
	    return;
	}catch(e){}	
	
}

CaseLoader.Request.prototype = {
    _req: null,
    
    getText: function (url) {
        this._req.open("GET", url, false);
        try {
            this._req.send(null);
            if (this._req.status == 200 || this._req.status == 0)
                return this._req.responseText;
        } catch (e) {
            alert("Fail to load js : " + url);
            return null;
        };

        alert("Fail to load js : " + url);
        return null;
    }
};
//--------------------------------------------------------

CaseLoader.js('jsonrpc.js');