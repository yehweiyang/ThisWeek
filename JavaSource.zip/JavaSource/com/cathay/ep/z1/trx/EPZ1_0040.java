package com.cathay.ep.z1.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0Z002;
import com.cathay.ep.z1.module.EP_Z10040;
import com.cathay.util.FileStoreUtil;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 *  Date   Version Description Author
 * 2016/11/17  1.0 Created �_�ɪ�
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �t�ΥN�X�]�w
 * �{���W��    EPZ1_0040
 * �@�~�覡    ONLINE
 * ���n����    
 * (1) ��l 
 * (2) �d�� �w �ϥΪ̫��U���s��A�d�ߨt�ΥN�X�M��C
 * (3) �ظm�ɮ� �w �ϥΪ̫��U���s��A�i���ƧR���B�s�W�@�~�C
 * (4) �פJ �w �ϥΪ̫��U���s��A�i���ƶפJ�@�~�C
 * 
 * </pre>
 * @author �L�ç�
 * @since 2016/11/30  
 */
@SuppressWarnings("unchecked")
public class EPZ1_0040 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPZ1_0040.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        try {
            resp.addOutputData("KEY1_LIST", new EP_Z10040().queryKey1List(user));
        } catch (ErrorInputException e) {
            log.error("���o�N�X�����U�Կ�楢��", e);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPZ1_0040_MSG_001");//���o�N�X�����U�Կ�楢��
        }
        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPZ1_0040_MSG_011");//���o�����q�O����
        }
        return resp;
    }

    /**
     * ���o���N�X�U�Կ��
     * @param req
     * @return
     */
    public ResponseContext doGetKey2List(RequestContext req) {

        try {
            resp.addOutputData("KEY2_LIST", FieldOptionList.getName("EP", "Z1_KEY2_" + req.getParameter("KEY1")));
        } catch (Exception e) {
            log.error("���o���N�X�U�Կ�楢��", e);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPZ1_0040_MSG_002");//���o���N�X�U�Կ�楢��
        }
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            this.query(req.getParameter("KEY1"), req.getParameter("KEY2"), req.getParameter("SUB_CPY_ID"));
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�d�ߥ���", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");
        }
        return resp;
    }

    /**
     * �פJ
     * @param req
     * @return
     */
    public ResponseContext doImport(RequestContext req) {

        try {
            FileItem fileItem = FileStoreUtil.parseUploadStream(req); // �פJ�ɮ�
            String KEY1 = req.getParameter("KEY1");
            String KEY2 = req.getParameter("KEY2");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            Map reqMap = new HashMap();
            reqMap.put("UPL_FILE", fileItem);
            reqMap.put("KEY1", KEY1);
            reqMap.put("KEY2", KEY2);
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            Transaction.begin();
            try {
                new EP_Z10040().upload(reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPZ1_0040_MSG_003");//�פJ���\

            try {
                this.query(KEY1, KEY2, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�פJ���\�A���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPZ1_0040_MSG_004"); //�פJ���\�A���d�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage());
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPZ1_0040_MSG_005");//�פJ����
            }
        } catch (Exception e) {
            log.error("�פJ����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPZ1_0040_MSG_005");//�פJ����
        } finally {
            //�^�Ǫ��A�]�w
            try {
                Map map = new HashMap();
                //��J���~�T��
                map.put(IConstantMap.ErrMsg, msg);
                //��J�B�z�n��LIST
                map.put("rtnList", resp.getOutputData("rtnList"));

                EncodingHelper.send2iframe(req, map, msg);

            } catch (Exception e) {
                log.error("�^�ǶפJ���G����", e);
            }
        }
        return resp;
    }

    /**
     * �ظm�ɮ�
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {

        try {
            List<Map> List = VOTool.jsonAryToMaps(req.getParameter("List"));
            String KEY1 = req.getParameter("KEY1");
            String KEY2 = req.getParameter("KEY2");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            Map reqMap = new HashMap();
            reqMap.put("KEY1", KEY1);
            reqMap.put("KEY2", KEY2);
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            EP_Z0Z002 theEP_Z0Z002 = new EP_Z0Z002();
            Transaction.begin();
            try {
                theEP_Z0Z002.deleteDTEPZ002(reqMap, user);
                if (List.size() > 0) {
                    theEP_Z0Z002.insertDTEPZ002(reqMap, List, user);
                }
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPZ1_0040_MSG_006");//�ظm�ɮק���

            try {
                this.query(KEY1, KEY2, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�ظm�ɮק����A���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPZ1_0040_MSG_007"); //�ظm�ɮק����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�ظm�ɮץ���", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPZ1_0040_MSG_008 ");//�ظm�ɮץ���
            }
        } catch (Exception e) {
            log.error("�ظm�ɮץ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPZ1_0040_MSG_008 ");
        }

        return resp;
    }

    /**
     * �@�άd��
     * @param KEY1
     * @param KEY2
     * @throws ModuleException 
     */
    private void query(String KEY1, String KEY2, String SUB_CPY_ID) throws ModuleException {

        StringBuilder sb = new StringBuilder();
        sb.append(KEY1).append('_').append(KEY2);
        String KEY = sb.toString();
        sb.setLength(0);

        List<Map> rtnList = new ArrayList<Map>();
        try {
            Map DMAP = FieldOptionList.getName("EP", "Z1_DEF_" + KEY);//�w�q
            DMAP.put("BUTTON", MessageUtil.getMessage("EPZ1_0040_MSG_009"));
            rtnList.add(DMAP);
        } catch (Exception e) {
            log.error("�d�L�w�q�������`");
        }
        try {
            Map EMAP = FieldOptionList.getName("EP", "Z1_EXP_" + KEY);//�d��
            EMAP.put("BUTTON", MessageUtil.getMessage("EPZ1_0040_MSG_010"));
            rtnList.add(EMAP);
        } catch (Exception e) {
            log.error("�d�L�d�ҵ������`");
        }
        resp.addOutputData("rtnList", rtnList);

        rtnList.addAll(new EP_Z0Z002().queryDTEPZ002(KEY1, KEY2, null, SUB_CPY_ID));
        resp.addOutputData("rtnList", rtnList);
    }
}
