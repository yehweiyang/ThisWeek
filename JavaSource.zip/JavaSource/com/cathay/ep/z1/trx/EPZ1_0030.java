package com.cathay.ep.z1.trx;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.hr.DivData;
import com.cathay.common.hr.Employee;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.hr.Unit;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 *  Date   Version Description Author
 * 2013/11/11  1.0 Created ���կ�
 * 
 * UCEPZ1_0030_EMAIL�H�o�]�w
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    EMAIL�H�o�]�w
 * �{���W��    EPZ1_0030
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l 
 * (2) ���oEMAIL�H����T �V ��J�ӤH���ҥ󸹽X��s�ʨ��o��ID��T�C
 * (3) �d�� �w �ϥΪ̫��U�d�߫��s��A���oEMAIL�H�o�]�w��T�C
 * (4) �s�W �w ���ѨϥΪ̷s�WEMAIL�H�o�]�w��T�C
 * (5) �ק� �w ���ѨϥΪ̭ק�EMAIL�H�o�]�w��T�C
 * (6) �R�� �w ���ѨϥΪ̧R��EMAIL�H�o�]�w��T�C
 * 
 * </pre>
 * @author �¶��� 
 * @since 2013/11/21  
 */
@SuppressWarnings("unchecked")
public class EPZ1_0030 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPZ1_0030.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            String USER_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);

            resp.addOutputData("USER_CPY_ID", USER_CPY_ID);
            resp.addOutputData("ID_TYPE_LIST", FieldOptionList.getName("EP", "ID_TYPE_Z130")); //���o�ҥ����
            //�Y��true, �h�ѤH�Ƹ�ƨ��o��T
            resp.addOutputData("IS_FROM_HR", StringUtils.isNotBlank(FieldOptionList.getName("EP", "CPY_CTR", USER_CPY_ID)) ? "Y" : "N");

            //�̤����q�O���o�@��EMAIL�q������
            Map INFM_LIST = FieldOptionList.getName("EP", "INFM_Z130_" + USER_CPY_ID);//EMAIL�q���]�w���زM��
            boolean IS_ADM = user.getRoles().containsKey("RLZZ0EP");//EP�t�κ޲z��RLZZ0EP
            resp.addOutputData("IS_ADM", IS_ADM ? "Y" : "N");

            Map INFM_ADM_LIST = FieldOptionList.getName("EP", "INFM_ADM_Z130");

            Iterator entries = INFM_ADM_LIST.entrySet().iterator();
            StringBuilder sb = new StringBuilder();
            while (entries.hasNext()) {
                Entry thisEntry = (Entry) entries.next();
                if (IS_ADM) { //�S���q�����ظ�A�H���~�i�]�w
                    INFM_LIST.put(thisEntry.getKey(), thisEntry.getValue());
                } else {
                    sb.append(",").append(thisEntry.getKey());
                }
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(0);
            }
            resp.addOutputData("INFM_ADM", sb.toString());
            resp.addOutputData("INFM_LIST", INFM_LIST);
            sb.setLength(0);
        } catch (Exception e) {
            log.error("��l����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00029");//��l����
        }

        return resp;
    }

    /**
     * ���o�W�ٸ�T
     * @param req
     * @return
     */
    public ResponseContext doGetName(RequestContext req) {
        try {

            String ID_TYPE = req.getParameter("ID_TYPE");
            String ID = req.getParameter("ID");
            String hrNAME = null;
            String hrEMAIL = null;
            if ("1".equals(ID_TYPE)) { //�ӤH
                Employee emp = new PersonnelData().getByEmployeeID(ID, true);
                if (emp != null) {
                    hrNAME = emp.getName();
                    hrEMAIL = emp.getEmail();
                }
            } else if ("2".equals(ID_TYPE)) { //���)
                //hrNAME = new DivData().getUnit4ShortName(ID);
                //2018-03-13 �վ���W�٧���Ҳ�
                String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
                hrNAME = new EP_A10010().getDivName(user.getOpUnit(), SUB_CPY_ID);
                Unit unit = new DivData().getUnit(ID);
                if (unit != null) {
                    hrEMAIL = unit.getDivEmail();
                }

            }
            resp.addOutputData("hrNAME", hrNAME);
            resp.addOutputData("hrEMAIL", hrEMAIL);

        } catch (Exception e) {
            log.error("���o�W�ٸ�T����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPZ1_0030_UI_MSG_001"));//���o�W�ٸ�T����
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            resp.addOutputData("rtnList", query(req.getParameter("USER_CPY_ID"), req.getParameter("ID"), req.getParameter("NAME")));

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            DTEPZ103 Z103Vo = VOTool.jsonToVO(DTEPZ103.class, req.getParameter("record"));

            String USER_CPY_ID = req.getParameter("USER_CPY_ID");
            Transaction.begin();
            try {
                new EP_Z10030().insert(USER_CPY_ID, Z103Vo, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00004");//�s�W����
            try {
                resp.addOutputData("rtnList", query(USER_CPY_ID, Z103Vo.getID(), null));
            } catch (Exception e) {
                log.error("�s�W����,���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPZ1_0030_UI_MSG_002");//�s�W����,���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataDuplicateException dde) {
            log.error("", dde);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_DUP, "MEP00006");//�s�W���ѡA��Ƥw�s�b
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00005");//�s�W����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {
            DTEPZ103 Z103Vo = VOTool.jsonToVO(DTEPZ103.class, req.getParameter("record"));
            String USER_CPY_ID = req.getParameter("USER_CPY_ID");
            Z103Vo.setSUB_CPY_ID(USER_CPY_ID);

            Transaction.begin();
            try {
                new EP_Z10030().update(Z103Vo, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00007");//�ץ�����
            try {
                resp.addOutputData("rtnList", query(USER_CPY_ID, Z103Vo.getID(), null));
            } catch (Exception e) {
                log.error("�ץ�����,���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPZ1_0030_UI_MSG_003");//�ץ�����,���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00009");//�ץ����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00008");//�ץ�����
            }
        } catch (Exception e) {
            log.error("�ץ��@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00008");//�ץ�����
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {

            List<DTEPZ103> Z103vo_List = VOTool.jsonAryToVOs(DTEPZ103.class, req.getParameter("records"));

            Transaction.begin();
            try {
                new EP_Z10030().delete(Z103vo_List, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "MEP00010");//�R������

            //���d���
            try {
                resp.addOutputData("rtnList", query(req.getParameter("USER_CPY_ID"), req.getParameter("ID"), null));
            } catch (DataNotFoundException e) {
                log.error(e);
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00012");//�R�����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00011");//�R������
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00011"));//�R������
        }

        return resp;
    }

    /**
     *  �d��EMAIL�]�w�M��
     * @param USER_CPY_ID
     * @param ID
     * @param NAME
     * @return
     * @throws ModuleException
     */
    private List<Map> query(String USER_CPY_ID, String ID, String NAME) throws ModuleException {
        List<Map> rtnList = new EP_Z10030().queryList(USER_CPY_ID, ID, NAME);
        logSecurity(rtnList);
        return rtnList;

    }

}
