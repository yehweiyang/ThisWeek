package com.cathay.ep.z1.module;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.ep.z0.module.EP_Z0Z002;

/**
 * <pre>
 * DATE    Description Author
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �t�ΥN�X�]�w�d�ߺ��@�Ҳ�
 * �Ҳ�ID    EP_Z10040
 * ���n����    �t�ΥN�X�]�w�d�ߺ��@�Ҳ�
 * </pre>
 * @author �L�ç�
 * @since 2016/11/29
 */
@SuppressWarnings("unchecked")
public class EP_Z10040 {

    /**
     * �d�ߥN�X�����M��
     * @param user �ϥΪ̸�T
     * @return List<Map>
     * @throws ErrorInputException 
     */
    public Map queryKey1List(UserObject user) throws ErrorInputException {
        if (user == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z10040_MSG_001"));//�ϥΪ̸�T���o����
        }

        Map key1List = new HashMap();
        Map tempLIST = FieldOptionList.getFieldOptions("EP", "Z1_KEY1");
        Hashtable userRoles = user.getRoles();
        String DIV_NO = user.getDivNo();
        for (Object key : tempLIST.keySet()) {
            //�v�����o��������
            Map ROLE_LIST = FieldOptionList.getFieldOptions("EP", "Z1_KEY1_" + key);
            //�N�X�@�~���
            Map DIV_LIST = FieldOptionList.getFieldOptions("EP", "Z1_KEY1_" + key + "_DIV");
            for (Object roleKey : ROLE_LIST.keySet()) {
                if (userRoles.containsKey(roleKey)) {
                    for (Object divKey : DIV_LIST.keySet()) {
                        if (DIV_NO.equals(divKey)) {
                            key1List.put(key, tempLIST.get(key));
                            break;
                        }
                    }
                }
            }
        }
        
        return key1List;
    }

    /**
     * �פJ���
     * @param reqMap (UPL_FILE �W���ɮ�)
     * @param user �ϥΪ̸�T
     * @throws ModuleException 
     * @throws IOException 
     */
    public void upload(Map reqMap, UserObject user) throws ModuleException, IOException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, "EP_Z10040_MSG_002");//�פJ�ɮפ��o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_Z10040_MSG_001");//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        FileItem UPL_FILE = (FileItem) reqMap.get("UPL_FILE");
        String filetype = FilenameUtils.getExtension(UPL_FILE.getName());
        Sheet sheet1 = null;
        if ("xls".equalsIgnoreCase(filetype)) {
            HSSFWorkbook wb = new HSSFWorkbook(new POIFSFileSystem(UPL_FILE.getInputStream()));
            sheet1 = wb.getSheetAt(0);
        } else if ("xlsx".equalsIgnoreCase(filetype)) {
            XSSFWorkbook wb = new XSSFWorkbook(UPL_FILE.getInputStream());
            sheet1 = wb.getSheetAt(0);
        } else {
            throw new ModuleException(MessageUtil.getMessage("EP_Z10040_MSG_003")); //�ɮ׮榡���~
        }

        List<Map> insertList = new ArrayList();
        StringBuilder errMsg = new StringBuilder();
        String strKEY1 = MapUtils.getString(reqMap, "KEY1");
        String strKEY2 = MapUtils.getString(reqMap, "KEY2");
        for (int i = 1; i < sheet1.getPhysicalNumberOfRows(); i++) { //�Ĥ@�欰���Y�A�����~��B�z�U�@��
            Row row = sheet1.getRow(i);
            if (row == null) {
                continue;
            }
            String KEY1 = this.getCellValue(row.getCell(0));
            String KEY2 = this.getCellValue(row.getCell(1));
            String KEY3 = this.getCellValue(row.getCell(2));
            String VALUE1 = this.getCellValue(row.getCell(3));
            String VALUE2 = this.getCellValue(row.getCell(4));
            String VALUE3 = this.getCellValue(row.getCell(5));
            //�@���ˮ�
            if (!StringUtils.equals(strKEY1, KEY1)) {
                errMsg.append(MessageUtil.getMessage("EP_Z10040_MSG_004")); //�N�X�����P�e���W��Ƥ��@�P
                STRING.newLine(errMsg);
            }
            if (!StringUtils.equals(strKEY2, KEY2)) {
                errMsg.append(MessageUtil.getMessage("EP_Z10040_MSG_005")); //���N�X�P�e���W��Ƥ��@�P
                STRING.newLine(errMsg);
            }
            //KEY3����B���׻�<=45
            if (StringUtils.isBlank(KEY3) || KEY3.getBytes().length > 45) {
                errMsg.append(MessageUtil.getMessage("EP_Z10040_MSG_006", new Object[] { KEY3 })); //�N�X���׻�<=45{0}
                STRING.newLine(errMsg);
            }
            //�Y VALUE1���ȡAVALUE1���׻�<=150
            if (StringUtils.isNotBlank(VALUE1)) {
                if (VALUE1.getBytes().length > 150) {
                    errMsg.append(MessageUtil.getMessage("EP_Z10040_MSG_007", new Object[] { 1, VALUE1 })); //�N�X��{0}���׻�<=150{1}
                    STRING.newLine(errMsg);
                }
            }
            //�Y VALUE2���ȡAVALUE2���׻�<=150
            if (StringUtils.isNotBlank(VALUE2)) {
                if (VALUE2.getBytes().length > 150) {
                    errMsg.append(MessageUtil.getMessage("EP_Z10040_MSG_007", new Object[] { 2, VALUE2 })); //�N�X��{0}���׻�<=150{1}
                    STRING.newLine(errMsg);
                }
            }
            //�Y VALUE3���ȡAVALUE3���׻�<=150
            if (StringUtils.isNotBlank(VALUE3)) {
                if (VALUE3.getBytes().length > 150) {
                    errMsg.append(MessageUtil.getMessage("EP_Z10040_MSG_007", new Object[] { 3, VALUE3 })); //�N�X��{0}���׻�<=150{1}
                    STRING.newLine(errMsg);
                }
            }
            //�̥N�X�����B���N�X�۩w�ˮ֤��e
            Map dataMap = new HashMap();
            dataMap.put("KEY1", KEY1);
            dataMap.put("KEY2", KEY2);
            dataMap.put("KEY3", KEY3);
            dataMap.put("VALUE1", VALUE1);
            dataMap.put("VALUE2", VALUE2);
            dataMap.put("VALUE3", VALUE3);
            //���ʲ��޲z�@��B�G��A���ղ��ʴ���001����B002�ӤH
            String[] array = { "001_8300100", "001_8300200", "002_8300100", "002_8300200"};
            if (ArrayUtils.contains(array, KEY1) && "PERIOD".equals(KEY2)) {
                String tmpMsg = this.chkData1(dataMap);
                if (StringUtils.isNotBlank(tmpMsg)) {
                    errMsg.append(MessageUtil.getMessage("EP_Z10040_MSG_008", new Object[] { i, tmpMsg })); //��{0}��{1}
                }
            }
            insertList.add(dataMap);

        }

        if (errMsg.length() > 0) {
            throw new ModuleException(errMsg.toString());
        }
        new EP_Z0Z002().insertDTEPZ002(reqMap, insertList, user);

    }

    /**
     * @param cell
     * @return
     */
    private String getCellValue(Cell cell) {
        try {
            if (cell != null) {
                cell.setCellType(Cell.CELL_TYPE_STRING); //��������নString
                return cell.getStringCellValue().trim();
            }
        } catch (Exception e) {
            return "";
        }
        return "";
    }

    /**
     * �ˮ֤��ʲ����ղ��ʴ����פJ���
     * @param dataMap
     * @return tmpMsg 
     * @throws ErrorInputException 
     */
    private String chkData1(Map dataMap) throws ErrorInputException {

        StringBuilder tmpMsg = new StringBuilder();
        String VALUE1 = MapUtils.getString(dataMap, "VALUE1");
        String VALUE2 = MapUtils.getString(dataMap, "VALUE2");
        //VALUE1����B�ݬ����T�褸�~���榡
        if (StringUtils.isBlank(VALUE1) || !DATE.isDate(VALUE1)) {
            tmpMsg.append(MessageUtil.getMessage("EP_Z10040_MSG_009", new Object[] { 1, VALUE1 })); //�N�X��{0}�ݬ����T�褸�~���榡YYYY-MM-DD{1}
            STRING.newLine(tmpMsg);
        }
        //VALUE2����B�ݬ����T�褸�~���榡
        if (StringUtils.isBlank(VALUE2) || !DATE.isDate(VALUE2)) {
            tmpMsg.append(MessageUtil.getMessage("EP_Z10040_MSG_009", new Object[] { 2, VALUE2 })); //�N�X��{0}�ݬ����T�褸�~���榡YYYY-MM-DD{1}
            STRING.newLine(tmpMsg);
        }

        if (tmpMsg.length() == 0) {
            //VALUE1��<=VALUE2
            if (DATE.diffDay(VALUE2, VALUE1) > 0) {
                tmpMsg.append(MessageUtil.getMessage("EP_Z10040_MSG_010", new Object[] { VALUE1, VALUE2 })); //�N�X��1{0}��<=�N�X��2{1}
                STRING.newLine(tmpMsg);
            }
        }
        return tmpMsg.toString();
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}
