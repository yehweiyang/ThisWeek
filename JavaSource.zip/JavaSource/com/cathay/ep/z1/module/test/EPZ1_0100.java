/* �b 2010-03-25 �إ�*/
package com.cathay.ep.z1.module.test;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ModuleException;
import com.cathay.common.service.ConfigManager;
import com.cathay.common.util.DBFormat;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.CountManager;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.batch.ErrorLog;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.module.EP_BatchBean;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * 	
 */

public class EPZ1_0100 extends EP_BatchBean { //�~��BatchBean
	/** logger */
	private static Logger log = Logger.getLogger(EPZ1_0100.class);

	private boolean isDebug = false;//log.isDebugEnabled();

	/** �@�~�W�� */
	private static final String JOB_NAME = "JAEPE305";

	/** �{���W�� */
	private static final String PROGRAM = "EPZ1_0100";

	/** �~�ȧO */
	private static final String BUSINESS = "EP";

	/** ���t�ΦW�� */
	private static final String SUBSYSTEM = "Z1";

	/** ����g�� */
	private static final String PERIOD = "��";

	/** ������檺��� , �Y�]�� 0 �h������ , �ȷ|����@�� , �Ъ`�N��ƶq���j�p */
	private static final int FETCH_SIZE = Integer.parseInt(ConfigManager.getProperty("FETCH_SIZE"));

	/** �]�� true �������|�۰ʭp���ƤΰO���T�� , false �h�ȷ|�O���T�� */
	private static final boolean isNOT_WRITELOG = false;

	private static final String delete_sql_C101 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_deleteC101";
	private static final String query_sql_C02toC101 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_queryC02toC101";
	private static final String query_sql_D05toC101 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_queryD05toC101";
	private static final String insert_sql_C101 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_insertC101";
	
//	private static final String delete_sql_C202 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_deleteC202";
	private static final String query_sql_C202 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_queryC202";
	private static final String delete_sql_C202_2 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_deleteC202_2";
//	private static final String query_sql_D05toC202 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_queryD05toC202";
	private static final String query_sql_D03toC202 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_queryD03toC202";
	private static final String insert_sql_C202 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_insertC202";
	
	private static final String delete_sql_C204 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_deleteC204";
	private static final String query_sql_D03toC204 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_queryD03toC204";
	private static final String insert_sql_C204 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_insertC204";
	
	private static final String delete_sql_C203 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_deleteC203";
	private static final String query_sql_D04toC203 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_queryD04toC203";
	private static final String insert_sql_C203 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_insertC203";
	
	private static final String delete_sql_DKG002 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_deleteDKG002";
	private static final String query_sql_E07toDKG002 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_queryE07toDKG002";
	private static final String insert_sql_DKG002 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_insertDKG002";
	
	private static final String delete_sql_DKG003 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_deleteDKG003";
	private static final String query_sql_E08toDKG003 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_queryE08toDKG003";
	private static final String insert_sql_DKG003 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_insertDKG003";
	
	private static final String delete_sql_C301 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_deleteC301";
	private static final String delete_sql_C306 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_deleteC306";
	private static final String query_sql_E01toC301C306 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_queryE01toC301C306";
	private static final String insert_sql_C301 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_insertC301";
	private static final String insert_sql_C306 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_insertC306";
	
	private static final String delete_sql_C201 = "com.cathay.ep.z1.module.EP_Z10010Test.SQL_deleteC201";
	private static final String query_sql_D01toC201 = "com.cathay.ep.z1.module.EP_Z10010Test.query_sql_D01toC201";
	private static final String insert_sql_C201 = "com.cathay.ep.z1.module.EP_Z10010Test.insert_sql_C201";
	
	private static final String delete_sql_C105 = "com.cathay.ep.z1.module.EP_Z10010Test.delete_sql_C105";
	private static final String query_sql_C01toC105 = "com.cathay.ep.z1.module.EP_Z10010Test.query_sql_C01toC105";
	private static final String insert_sql_C105 = "com.cathay.ep.z1.module.EP_Z10010Test.insert_sql_C105";
	
	private static final String delete_sql_C104 = "com.cathay.ep.z1.module.EP_Z10010Test.delete_sql_C104";
	private static final String query_sql_C07toC104 = "com.cathay.ep.z1.module.EP_Z10010Test.query_sql_C04toC104";
	private static final String insert_sql_C104 = "com.cathay.ep.z1.module.EP_Z10010Test.insert_sql_C104";
	
	// User Add 
	/** �d�ߪ����� */
	private BatchQueryDataSet bqds_1;

	/** �s�W������ */
	private BatchUpdateDataSet buds_Insert_1;
	private BatchUpdateDataSet buds_Insert_2;

	/** ���~�T���O������ */
	private ErrorLog errorLog;

	/** �p�ƾ� */
	private CountManager countManager;

	/** �̿��~���h�Ũ��o���~����� */
	private ErrorHandler errorHandler;

	private DataSet queryDS;

	private BigDecimal oldRCV_YM = BigDecimal.ZERO;
	private BigDecimal oldINT_YM = BigDecimal.ZERO;
	private BigDecimal oldTRN_YM = BigDecimal.ZERO;
	
	
	private BigDecimal BD1911 = new BigDecimal("191100");
	private StringBuilder sb = new StringBuilder();
	
	
	public EPZ1_0100() throws Exception {
		//�]�� true �������|�۰ʭp���ƤΰO���T�� , false �h�ȷ|�O���T��*/
		super(FETCH_SIZE, JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isNOT_WRITELOG);

		//���~�T���O������
		errorLog = new ErrorLog(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM);
		//�����ưO������
		countManager = new CountManager(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD);

		errorHandler = new ErrorHandler();

		queryDS = this.getDataSet();
		bqds_1 = getBatchQueryDataSet();
		buds_Insert_1 = getBatchUpdateDataSet();
		buds_Insert_2 = getBatchUpdateDataSet(buds_Insert_1);
	}

	public void execute(String args[]) throws Exception {
//		ReturnMessage RetMsg = new ReturnMessage();
//		ZZ_X0Z004 zz_x0z004 = new ZZ_X0Z004("EPZ1_0100");//online call batch

		try {
//			//online call batch
//			zz_x0z004.startBatch(RetMsg);
//			if (RetMsg.getReturnCode() != ReturnCode.OK) {
//				log.fatal("zz_x0z004.startBatch ���~:" + RetMsg.getMsgDesc());
//			}
//			ZZ_X0Z007 zz_x0z007 = new ZZ_X0Z007("EPZ1_0100");
//			args = zz_x0z007.retrieveParam(null);

			importC101();
			
			importC202();
			
			importC204();
			
			importC203();
			
			importDKG002();
			
			importDKG003();
			
			MultiKeyMap mkm = new MultiKeyMap();
			importEPC301306(mkm);
			importEPC201(mkm);
			
			importC105();
			
			importC104();
			
		} catch (Exception e) {
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e);
		} finally {
			//online call batch
//			zz_x0z004.endBatch(RetMsg);
//			if (RetMsg.getReturnCode() != ReturnCode.OK) {
//				log.fatal("zz_x0z004.endBatch ���~:" + RetMsg.getMsgDesc());
//			}

			//��ƭp��Ш̻ݨD�@�վ�		
			if (isDebug)
				log.debug(countManager);
			//�g�J��ưO����
			countManager.writeLog();
			//�����Ҧ����s�u
			if (buds_Insert_1 != null)
				buds_Insert_1.close();
			if (bqds_1 != null)
				bqds_1.close();

			printExitCode(getExitCode());
		}
	}

	private void importC104() throws ModuleException{
		try {
			queryDS.clear();	
			DBUtil.executeUpdate(queryDS, delete_sql_C104,false);
		} catch (ModuleException e) {
			throw new ModuleException("EPZ1_0100(8)�G" + e);
		}
		try {
			queryDS.clear();			
			C07toC104();
		} catch (Exception e) {
			errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e.toString());
			log.debug(e.toString());
			throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
		}
	}	
	
	private void C07toC104() throws Exception{
		Integer ser_no=1;
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_C07toC104);
		
		buds_Insert_1.clearBatch();
		buds_Insert_1.preparedBatch(insert_sql_C104);
		oldTRN_YM = BigDecimal.ZERO;
		
		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				if(null==bqds_1.getField("RCV_NO")){
					BigDecimal newTRN_YM = new BigDecimal(bqds_1.getField("TRN_YM").toString().trim());
					if(0!=oldTRN_YM.compareTo(newTRN_YM)){
						ser_no=1;
					}
					oldTRN_YM = newTRN_YM;
					setDTEPC104_Fields(bqds_1, ser_no);
					ser_no++;
				}else{
					setDTEPC104_Fields(bqds_1, null);
				}
				
				
				buds_Insert_1.addBatch();
				
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

				Object RCV_NO = errMap.get("RCV_NO");


				errorLog.addErrorLog("INSERT DTEPC104 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO=" + RCV_NO + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}	
	
	private void setDTEPC104_Fields(BatchQueryDataSet bqds, Integer ser_no) throws DBException {
		
		String RCV_NO;
		BigDecimal TRN_YM = new BigDecimal(bqds.getField("TRN_YM").toString().trim()).add(BD1911);
		if(null!=ser_no){
			String PAY_KIND =  (String)(bqds.getField("PAY_KIND"));
			sb.append("99").append(TRN_YM.intValue()).append(PAY_KIND).append(STRING.fillZero(""+ser_no, 4));
			RCV_NO = sb.toString();
			sb.setLength(0);
		}else{
			RCV_NO = bqds.getField("RCV_NO").toString();
		}
		buds_Insert_1.setField("RCV_NO", RCV_NO);
		buds_Insert_1.setField("TRN_YM", TRN_YM);
		buds_Insert_1.setField("SLIP_SET_NO", bqds.getField("SLIP_SET_NO").toString().trim());
		
		String[] C203col = {"PAY_KIND", "CRT_NO", "CUS_NO", "DIV_NO", "ID", "CUS_NAME", "INV_NO"
				, "PASS_DAY", "PRP_S_DATE", "PRP_E_DATE", "PRP_AMT", "EXT_DATE", "ACNT_DATE"
				, "ACNT_ID", "ACNT_NAME", "ACNT_DIV_NO",  "SUB_CPY_ID"};

		for(String colkey : C203col){
			buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
		}
	}
	
	
	private void importC105() throws ModuleException{
		try {
			queryDS.clear();	
			DBUtil.executeUpdate(queryDS, delete_sql_C105,false);
		} catch (ModuleException e) {
			throw new ModuleException("EPZ1_0100(8)�G" + e);
		}
		try {
			queryDS.clear();			
			C01toC105();
		} catch (Exception e) {
			errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e.toString());
			log.debug(e.toString());
			throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
		}
	}
	
	private void C01toC105() throws Exception{
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_C01toC105);
		
		buds_Insert_1.clearBatch();
		buds_Insert_1.preparedBatch(insert_sql_C105);
		
		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				if(bqds_1.getField("EXT_YM").toString().startsWith("099")){
					continue;
				}
				
				setDTEPC105_Fields(bqds_1);
				buds_Insert_1.addBatch();
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

				Object EXT_YM = errMap.get("EXT_YM");
				Object EXT_TYPE = errMap.get("EXT_TYPE");

				errorLog.addErrorLog("INSERT DTEPC105 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "EXT_YM=" + EXT_YM + "; EXT_TYPE="+EXT_TYPE+"]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}		
	
	private void setDTEPC105_Fields(BatchQueryDataSet bqds) throws DBException {
		
		BigDecimal EXT_YM = new BigDecimal(bqds.getField("EXT_YM").toString().trim()).add(BD1911);
		buds_Insert_1.setField("EXT_YM", EXT_YM);
		sb.setLength(0);
		
		String[] C203col = {"SUB_CPY_ID", "EXT_TYPE"  ,"EXT_DATE"
				  ,"CNT"  ,"AMT"  ,"CHG_DATE"  ,"CHG_ID"  ,"CHG_NAME"};

		for(String colkey : C203col){
			buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
		}
	}
	
	
	private void importEPC201(MultiKeyMap mkm) throws ModuleException{
		try {
			queryDS.clear();	
			DBUtil.executeUpdate(queryDS, delete_sql_C201,false);
		} catch (ModuleException e) {
			throw new ModuleException("EPZ1_0100(8)�G" + e);
		}
		try {
			queryDS.clear();			
			D01toC201(mkm);
		} catch (Exception e) {
			errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e.toString());
			log.debug(e.toString());
			throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
		}
	}
	
	private void D01toC201(MultiKeyMap mkm) throws Exception{
		Integer ser_no=1;
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_D01toC201);
		oldINT_YM = BigDecimal.ZERO;
		
		buds_Insert_1.clearBatch();
		buds_Insert_1.preparedBatch(insert_sql_C201);
		
		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				log.debug("!!!!");				
				BigDecimal newINT_YM = new BigDecimal(bqds_1.getField("INT_YM").toString().trim());
				if(0!=oldINT_YM.compareTo(newINT_YM)){
					ser_no=1;
				}
				oldINT_YM = newINT_YM;
				
				setDTEPC201_Fields(bqds_1, ser_no, mkm);
				buds_Insert_1.addBatch();
				ser_no++;
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

				Object PAY_NO = errMap.get("PAY_NO");

				errorLog.addErrorLog("INSERT DTEPC301 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "PAY_NO=" + PAY_NO + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}	
	
	private void setDTEPC201_Fields(BatchQueryDataSet bqds, int ser_no, MultiKeyMap mkm) throws DBException {
		BigDecimal INT_YM = new BigDecimal(bqds.getField("INT_YM").toString().trim()).add(BD1911);
		String SUB_CPY_ID =  (String)(bqds.getField("SUB_CPY_ID"));
		sb.append(SUB_CPY_ID).append(INT_YM.intValue()).append("I").append(STRING.fillZero(""+ser_no, 4));
		String INT_NO = sb.toString();
		buds_Insert_1.setField("INT_NO", INT_NO);
		buds_Insert_1.setField("SUB_CPY_ID", SUB_CPY_ID);
		buds_Insert_1.setField("INT_YM", INT_YM);
		sb.setLength(0);
		
		String[] C203col = {"CRT_NO"  ,"CUS_NO"
				  ,"DIV_NO"  ,"ID"  ,"CUS_NAME"  ,"PMI_S_DATE"  ,"PMI_E_DATE"  ,"PASS_DAY"  ,"PMS_AMT"
				  ,"RAT_CD"  ,"PIM_RATE"  ,"PMI_AMT"  ,"PMI_TAX"  ,"INV_NO"  ,"INV_AMT"  ,"TAX_TYPE"
				  ,"ACNT_DATE"  ,"ACNT_ID"  ,"ACNT_DIV_NO"  ,"FLOW_NO"  ,"OP_STATUS"  ,"LST_PROC_DATE"
				  ,"LST_PROC_ID"  ,"LST_PROC_DIV"};

		for(String colkey : C203col){
			buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
		}
		
		String BLD_CD = STRING.objToStrNoNull(bqds.getField("BLD_CD"));
//		if(BLD_CD!=null && !BLD_CD.trim().equals("")){
//			BLD_CD = "0000"+BLD_CD;
//		}
		buds_Insert_1.setField("BLD_CD",  BLD_CD);
		
		
		String PAY_NO = ObjectUtils.toString(mkm.get(STRING.objToStrNoNull(bqds.getField("CRT_NO")), STRING.objToStrNoNull(bqds.getField("CUS_NO"))
				, STRING.objToStrNoNull(bqds.getField("OLD_RCV_NO"))));
		buds_Insert_1.setField("PAY_NO",  PAY_NO);
	}
	
	
	private void importEPC301306(MultiKeyMap mkm) throws ModuleException{
		try {
			queryDS.clear();	
			DBUtil.executeUpdate(queryDS, delete_sql_C301,false);
			queryDS.clear();	
			DBUtil.executeUpdate(queryDS, delete_sql_C306,false);
		} catch (ModuleException e) {
			throw new ModuleException("EPZ1_0100(8)�G" + e);
		}
		try {
			queryDS.clear();			
			E01toC301C306(mkm);
		} catch (Exception e) {
			errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e.toString());
			log.debug(e.toString());
			throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
		}
	}
	
	private void E01toC301C306(MultiKeyMap mkm) throws Exception{
		Integer ser_no=1;
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_E01toC301C306);
		oldRCV_YM = BigDecimal.ZERO;
		
		buds_Insert_1.clearBatch();
		buds_Insert_1.preparedBatch(insert_sql_C301);
		
		buds_Insert_2.clearBatch();
		buds_Insert_2.preparedBatch(insert_sql_C306);
		
		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				log.debug("!!!!");				
				BigDecimal newRCV_YM = new BigDecimal(bqds_1.getField("RCV_YM").toString().trim());
				if(0!=oldRCV_YM.compareTo(newRCV_YM)){
					ser_no=1;
				}
				oldRCV_YM = newRCV_YM;
				
				String PAY_NO = setDTEPC301_Fields(bqds_1, ser_no, mkm);
				String RCV_NO = STRING.objToStrNoNull(bqds_1.getField("RCV_NO"));
				if(RCV_NO!=null && !RCV_NO.trim().equals("")){
					buds_Insert_1.addBatch();
				}
				setDTEPC306_Fields(bqds_1, PAY_NO);
				buds_Insert_2.addBatch();
				ser_no++;
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

				Object PAY_NO = errMap.get("PAY_NO");

				errorLog.addErrorLog("INSERT DTEPC301 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "PAY_NO=" + PAY_NO + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

			int buds_INSERT_2_Ret[] = buds_Insert_2.executeBatch();

			Object errObject_2[][] = errorHandler.getErrorArray(buds_Insert_2.getBatchUpdateErrorArray(),
					buds_INSERT_2_Ret, buds_Insert_2.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_2.length; i++) {
				Map errMap = (Map) errObject_2[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(17)�G" + errObject_2[i][2]);

				Object PAY_NO = errMap.get("PAY_NO");

				errorLog.addErrorLog("INSERT DTEPC306 " + errObject_2[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "PAY_NO=" + PAY_NO + "]:"+errObject_2[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}			
			
		} //for loop end
	}
	
	private String setDTEPC301_Fields(BatchQueryDataSet bqds, int ser_no, MultiKeyMap mkm) throws DBException {
		BigDecimal RCV_YM = new BigDecimal(bqds.getField("RCV_YM").toString().trim()).add(BD1911);
		String SUB_CPY_ID =  (String)(bqds.getField("SUB_CPY_ID"));
		String PAY_KIND =  (String)(bqds.getField("PAY_KIND"));
		sb.append(SUB_CPY_ID).append(RCV_YM.intValue()).append(PAY_KIND).append(STRING.fillZero(""+ser_no, 4));
		String PAY_NO = sb.toString();
		buds_Insert_1.setField("PAY_NO", PAY_NO);
		buds_Insert_1.setField("SUB_CPY_ID", SUB_CPY_ID);
		buds_Insert_1.setField("RCV_YM", RCV_YM);
		buds_Insert_1.setField("PAY_KIND", PAY_KIND);
		sb.setLength(0);
		
		String[] C203col = {"RCV_NO","CRT_NO","CUS_NO", "PAY_TYPE" , "PAY_AMT", "CHK_CD", "COA_DATE"
				, "PMI_S_DATE", "PMI_E_DATE", "SWP_KIND", "SWP_DATE", "INV_NO", "ID", "CUS_NAME"
				,"PAY_S_DATE","PAY_E_DATE","INPUT_ID", "TRN_DATE", "TRN_SER_NO", "ACNT_DATE"
				, "SLIP_SET_NO", "TRN_KIND", "CHG_DATE", "CHG_ID"};

		for(String colkey : C203col){
			buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
		}
		
		String BLD_CD = STRING.objToStrNoNull(bqds.getField("BLD_CD"));
//		if(BLD_CD!=null && !BLD_CD.trim().equals("")){
//			BLD_CD = "0000"+BLD_CD;
//		}
		buds_Insert_1.setField("BLD_CD",  BLD_CD);
		
		if("2".equals(PAY_KIND)){
			mkm.put(STRING.objToStrNoNull(bqds.getField("CRT_NO")), STRING.objToStrNoNull(bqds.getField("CUS_NO"))
					, STRING.objToStrNoNull(bqds.getField("OLD_RCV_NO")), PAY_NO);
		}
		
		return PAY_NO;
	}
	
	private void setDTEPC306_Fields(BatchQueryDataSet bqds, String PAY_NO) throws DBException {
		buds_Insert_2.setField("PAY_NO", PAY_NO);
		
		String[] C203col = {"CSH_AMT", "CHK_AMT", "RMT_AMT", "TKD_AMT", "MAL_AMT", "PAY_AMT", "DACNT_AMT", "TMP_AMT", "ACNT_AMT"
				, "CHK_SET_NO", "INPUT_ID", "TRN_DATE", "TRN_SER_NO", "ACNT_DATE", "SLIP_SET_NO", "TRN_KIND", "CHG_DATE", "CHG_ID"};
				
		for(String colkey : C203col){
			buds_Insert_2.setField(colkey, (bqds.getField(colkey)));
		}
		
	}	
	
	private void importDKG002() throws ModuleException{
		try {
			queryDS.clear();	
			queryDS.setConnName("DS_DK");
			DBUtil.executeUpdate(queryDS, delete_sql_DKG002,false);
		} catch (ModuleException e) {
			throw new ModuleException("EPZ1_0100(8)�G" + e);
		}
		try {
			queryDS.clear();			
			E07toDKG002();
			
		} catch (Exception e) {
			errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e.toString());
			log.debug(e.toString());
			throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
		}
	}
	
	private void importDKG003() throws ModuleException{
		try {
			queryDS.clear();	
			queryDS.setConnName("DS_DK");
			DBUtil.executeUpdate(queryDS, delete_sql_DKG003,false);
		} catch (ModuleException e) {
			throw new ModuleException("EPZ1_0100(8)�G" + e);
		}
		try {
			queryDS.clear();			
			E08toDKG003();
			
		} catch (Exception e) {
			errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e.toString());
			log.debug(e.toString());
			throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
		}
	}	

	private void C02toC101(Map year2Serno) throws Exception{
		Integer ser_no=1;
		bqds_1.clear();
		//bqds_1.setField("YEAR_B", new BigDecimal(ROCYEAR).multiply(new BigDecimal("100")));
    	//bqds_1.setField("YEAR_E", (new BigDecimal(ROCYEAR).add(BigDecimal.ONE)).multiply(new BigDecimal("100")));
		searchAndRetrieve(bqds_1, query_sql_C02toC101);

		buds_Insert_1.clearBatch();
		buds_Insert_1.preparedBatch(insert_sql_C101);
		
		

		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				BigDecimal newRCV_YM = new BigDecimal(bqds_1.getField("RCV_YM").toString().trim());
				if(0!=oldRCV_YM.compareTo(newRCV_YM)){
					ser_no=1;
				}
				oldRCV_YM = newRCV_YM;
				setDTEPC101_Fields(bqds_1, ser_no);
				buds_Insert_1.addBatch();
				ser_no++;
				year2Serno.put(oldRCV_YM, ser_no);
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(14)�G" + errObject_1[i][2]);

				Object RCV_NO = errMap.get("RCV_NO");

				errorLog.addErrorLog("INSERT DTEPC101 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO=" + RCV_NO + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}
	
	
	
	private void importC101() throws ModuleException{
		try {
			DBUtil.executeUpdate(queryDS, delete_sql_C101,false);
		} catch (ModuleException e) {
			throw new ModuleException("EPZ1_0100(8)�G" + e);
		}
		Map<BigDecimal,Integer> year2Serno = new HashMap();
		try {
			queryDS.clear();			
			C02toC101(year2Serno);
			queryDS.clear();			
			D05toC101(year2Serno);
			
		} catch (Exception e) {
			errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e.toString());
			log.debug(e.toString());
			throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
		}
	}
	
	private void E08toDKG003() throws Exception{
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_E08toDKG003);

		buds_Insert_1.clear();
		buds_Insert_1.setConnName("DS_DK");
		buds_Insert_1.preparedBatch(insert_sql_DKG003);
		int serno=1;
		String DTMP_NO_OLD="";
		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				String DTMP_NO = STRING.objToStrNoNull(bqds_1.getField("DTMP_NO"));
				if(0!=DTMP_NO.compareTo(DTMP_NO_OLD)){
					serno=1;
				}
				DTMP_NO_OLD = DTMP_NO;
				
				setDTDKG003_Fields(bqds_1, serno);
				buds_Insert_1.addBatch();
				serno++;
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(14)�G" + errObject_1[i][2]);

				Object DTMP_NO = errMap.get("DTMP_NO");

				errorLog.addErrorLog("INSERT DTDKG003 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "DTMP_NO=" + DTMP_NO + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}

	private void setDTDKG003_Fields(BatchQueryDataSet bqds, int serno) throws DBException {
		String[] C203col = {"TMP_NO" ,"TMP_CD" ,"DACNT_ID","SLIP_DATE"
				 ,"SLIP_SET_NO" ,"DACNT_AMT" ,"SUB_ACNT_CODE" ,"TMP_D_KIND" ,"RTN_KIND" ,"ACPT_ID" ,"ACPT_ACNT_NAME"};
		String DTMP_NO = STRING.objToStrNoNull(bqds.getField("DTMP_NO"));
		DTMP_NO = DTMP_NO.replace("-", "").substring(2);
		DTMP_NO = "EP"+DTMP_NO+STRING.fillZero(""+serno, 4);
		
		String DDATE_ONE = STRING.objToStrNoNull(bqds.getField("DDATE_ONE")).split(" ")[0];
		String DDATE_TWO = STRING.objToStrNoNull(bqds.getField("DDATE_TWO")).split(" ")[1];
		
		String SLIP_SET_NO =  STRING.objToStrNoNull(bqds.getField("SLIP_SET_NO"));
		int int_SLIP_SET_NO=0;
		if(SLIP_SET_NO!=null && NumberUtils.isNumber(SLIP_SET_NO)){
			int_SLIP_SET_NO = Integer.parseInt(SLIP_SET_NO);
		}
		buds_Insert_1.setField("DTMP_NO", DTMP_NO);
		if(!"".equals(DDATE_ONE) && !"".equals(DDATE_TWO)){
			buds_Insert_1.setField("DACNT_IN_DATE", DDATE_ONE+" "+DDATE_TWO);
		}else{
			buds_Insert_1.setField("DACNT_IN_DATE", null);
		}
		buds_Insert_1.setField("SLIP_SET_NO", int_SLIP_SET_NO);
		String BAL_AMT = STRING.objToStrNoNull(bqds.getField("BAL_AMT"));
		if(!"".equals(BAL_AMT) ){
			buds_Insert_1.setField("BAL_AMT", new BigDecimal(BAL_AMT));
		}else{
			buds_Insert_1.setField("BAL_AMT", null);
		}
		for(String colkey : C203col){
			buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
		}
	}
	
	
	private void E07toDKG002() throws Exception{
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_E07toDKG002);

		buds_Insert_1.clearBatch();
		buds_Insert_1.setConnName("DS_DK");
		buds_Insert_1.preparedBatch(insert_sql_DKG002);

		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				setDTDKG002_Fields(bqds_1);
				buds_Insert_1.addBatch();
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(14)�G" + errObject_1[i][2]);

				Object TMP_NO = errMap.get("TMP_NO");

				errorLog.addErrorLog("INSERT DTDKG002 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "TMP_NO=" + TMP_NO + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}

	private void setDTDKG002_Fields(BatchQueryDataSet bqds) throws DBException {
		String[] C203col = {"TMP_NO" ,"SYS_NO" ,"TMP_CD" ,"SLIP_DATE" ,"ACNT_AMT" ,"BAL_AMT"
				 ,"SUB_ACNT_CODE" ,"TMP_IN_CD" ,"RESN_NO" ,"LST_CHG_ID" ,"LST_CHG_DATE" ,"ACPT_ID" ,"POLICY_NO"
				 ,"PAY_TIMES" ,"CAT_PREM" ,"APLY_NO" ,"RTN_RCPT_NO" ,"CST_NAME" ,"CHK_SET_NO" ,"CHK_STS_CODE" ,"MEMO" ,"CURR"};
		log.debug("=======" + STRING.objToStrNoNull(bqds.getField("TMP_NO")));		
		String SLIP_SET_NO =  STRING.objToStrNoNull(bqds.getField("SLIP_SET_NO"));
		int int_SLIP_SET_NO=0;
		if(SLIP_SET_NO!=null && NumberUtils.isNumber(SLIP_SET_NO)){
			int_SLIP_SET_NO = Integer.parseInt(SLIP_SET_NO);
		}
		buds_Insert_1.setField("SLIP_SET_NO", int_SLIP_SET_NO);
		for(String colkey : C203col){
			buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
		}
	}
	
	
	
	private void D05toC101(Map<BigDecimal,Integer> year2Serno) throws Exception{
		Integer ser_no=1;
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_D05toC101);
		oldRCV_YM = BigDecimal.ZERO;
		
		buds_Insert_1.clearBatch();
		buds_Insert_1.preparedBatch(insert_sql_C101);
		
		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				log.debug("!!!!");				
				BigDecimal newRCV_YM = new BigDecimal(bqds_1.getField("RCV_YM").toString().trim());
				if(0!=oldRCV_YM.compareTo(newRCV_YM)){
					ser_no=year2Serno.get(newRCV_YM);
					if(null==ser_no){
						ser_no=1;
					}
				}
				oldRCV_YM = newRCV_YM;
				bqds_1.setField("TURN_ACNT_DATE", null);
				bqds_1.setField("BDEBT_ACNT_DATE", null);
				setDTEPC101_Fields(bqds_1, ser_no);
				
				buds_Insert_1.addBatch();
				ser_no++;
				year2Serno.put(oldRCV_YM, ser_no);
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

				Object RCV_NO = errMap.get("RCV_NO");

				errorLog.addErrorLog("INSERT DTEPC101 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO=" + RCV_NO + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}

	private void importC202() throws Exception{
		try {
			//queryDS.clear();
			//DBUtil.executeUpdate(queryDS, delete_sql_C202,false);
			deleteC202();
		} catch (ModuleException e) {
			throw new ModuleException("EPZ1_0100(8-2)�G" + e);
		}
		try {
			queryDS.clear();
			D03toC202();
		} catch (Exception e) {
			errorLog.addErrorLog("EPZ1_0100(15-2)�G", e.getMessage());
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e.toString());
			log.debug(e.toString());
			throw new ModuleException("EPZ1_0100(16-2)�G" + e.getMessage());
		}
	}
	
	private void deleteC202() throws Exception{
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_C202);
		
		buds_Insert_1.clearBatch();
		buds_Insert_1.preparedBatch(delete_sql_C202_2);
		
		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				buds_Insert_1.setField("INV_NO",  STRING.objToStrNoNull(bqds_1.getField("INV_NO")));
				buds_Insert_1.setField("SUB_CPY_ID", (bqds_1.getField("SUB_CPY_ID")));
				buds_Insert_1.addBatch();
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

				Object RCV_NO = errMap.get("RCV_NO");

				errorLog.addErrorLog("DELETE DTEPC202 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO=" + RCV_NO + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}	
	
	private void D03toC202() throws Exception{
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_D03toC202);
		buds_Insert_1.clearBatch();
		buds_Insert_1.preparedBatch(insert_sql_C202);
		
		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				setDTEPC202_Fields(bqds_1,1);
				buds_Insert_1.addBatch();
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

				Object INV_NO = errMap.get("INV_NO");

				errorLog.addErrorLog("INSERT DTEPC202 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "INV_NO=" + INV_NO + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}

	private void importC204() throws ModuleException{
		try {
			queryDS.clear();
			DBUtil.executeUpdate(queryDS, delete_sql_C204,false);
		} catch (ModuleException e) {
			throw new ModuleException("EPZ1_0100(8-3)�G" + e);
		}
		try {
			queryDS.clear();
			D03toC204();
		} catch (Exception e) {
			errorLog.addErrorLog("EPZ1_0100(15-3)�G", e.getMessage());
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e.toString());
			log.debug(e.toString());
			throw new ModuleException("EPZ1_0100(16-3)�G" + e.getMessage());
		}
	}
	
	private void D03toC204() throws Exception{
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_D03toC204);
		buds_Insert_1.clearBatch();
		buds_Insert_1.preparedBatch(insert_sql_C204);
		
		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				setDTEPC204_Fields(bqds_1,1);
				buds_Insert_1.addBatch();
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

				Object INV_NO = errMap.get("INV_NO");

				errorLog.addErrorLog("INSERT DTEPC204 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO=" + INV_NO + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}
	
	private void importC203() throws ModuleException{
		try {
			queryDS.clear();
			DBUtil.executeUpdate(queryDS, delete_sql_C203,false);
		} catch (ModuleException e) {
			throw new ModuleException("EPZ1_0100(8-4)�G" + e);
		}
		try {
			queryDS.clear();
			D04toC203();
		} catch (Exception e) {
			errorLog.addErrorLog("EPZ1_0100(15-4)�G", e.getMessage());
			setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ� 
			log.fatal(e.toString());
			log.debug(e.toString());
			throw new ModuleException("EPZ1_0100(16-4)�G" + e.getMessage());
		}
	}

	private void D04toC203() throws Exception{
		bqds_1.clear();
		searchAndRetrieve(bqds_1, query_sql_D04toC203);
		buds_Insert_1.clearBatch();
		buds_Insert_1.preparedBatch(insert_sql_C203);
		
		for (prepareFetch(); fetchData(bqds_1); goNext()) {

			while (bqds_1.next()) {
				setDTEPC203_Fields(bqds_1,1);
				buds_Insert_1.addBatch();
			}

			int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

			Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(),
					buds_INSERT_1_Ret, buds_Insert_1.getBatchMapsArray(),
					ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

			for (int i = 0; i < errObject_1.length; i++) {
				Map errMap = (Map) errObject_1[i][1];

				if (isDebug)
					log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

				Object INV_YM = errMap.get("INV_YM");

				errorLog.addErrorLog("INSERT DTEPC203 " + errObject_1[i][2],
						"com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "INV_YM=" + INV_YM + "]:"+errObject_1[i][2]);

				errorLog.getErrorCountAndWriteErrorMessage();

			}

		} //for loop end
	}
	
	private void setDTEPC101_Fields(BatchQueryDataSet bqds, int ser_no) throws DBException {
		BigDecimal RCV_YM = new BigDecimal(bqds.getField("RCV_YM").toString().trim()).add(BD1911);
		String SUB_CPY_ID =  (String)(bqds.getField("SUB_CPY_ID"));
		String PAY_KIND =  (String)(bqds.getField("PAY_KIND"));
		sb.append(SUB_CPY_ID).append(RCV_YM.intValue()).append(PAY_KIND).append(STRING.fillZero(""+ser_no, 4));
		buds_Insert_1.setField("RCV_NO", sb.toString());
		buds_Insert_1.setField("SUB_CPY_ID", SUB_CPY_ID);
		buds_Insert_1.setField("RCV_YM", RCV_YM);
		buds_Insert_1.setField("PAY_KIND", PAY_KIND);
		sb.setLength(0);
		
		String[] C203col = {"CRT_NO","CUS_NO","PAY_S_DATE","PAY_E_DATE","ID","CUS_NAME","DIV_NO",
				"BLD_USR_ID","BLD_USR_NAME","EXT_DATE","EXT_TYPE","INV_AMT","SAL_AMT","TAX_AMT","TAX_TYPE",
				"SPR_AMT","PASS_DAY","PRP_S_DATE","RNT_AMT","PRP_AMT","PRP_SP_AMT","RJT_CD","ACNT_DATE",
				"ACNT_ID","ACNT_NAME","ACNT_DIV_NO","SLIP_LOT_NO","SLIP_SET_NO","TURN_ACNT_DATE",
				"TURN_ID","TURN_NAME","TURN_SLPLOT_NO","TURN_SLPSET_NO","BDEBT_ACNT_DATE",
				"BDEBT_ID","BDEBT_NAME","BDEBT_SLPLOT_NO","BDEBT_SLPSET_NO","TRN_KIND","FLOW_NO",
				"OP_STATUS","LST_PROC_DATE","LST_PROC_ID","LST_PROC_DIV","LST_PROC_NAME"};
		for(String colkey : C203col){
			buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
		}
		
		String BLD_CD = STRING.objToStrNoNull(bqds.getField("BLD_CD"));
//		if(BLD_CD!=null && !BLD_CD.trim().equals("")){
//			BLD_CD = "0000"+BLD_CD;
//		}
		buds_Insert_1.setField("BLD_CD",  BLD_CD);
		buds_Insert_1.setField("PAY_CD",  STRING.objToStrNoNull(bqds.getField("PAY_CD")));
		buds_Insert_1.setField("INV_NO",  STRING.objToStrNoNull(bqds.getField("INV_NO")));
	}
	
	private void setDTEPC202_Fields(BatchQueryDataSet bqds, int isnull) throws DBException {
		BigDecimal RCV_YM = new BigDecimal(bqds.getField("RCV_YM").toString().trim()).add(BD1911);
		String[] C203col = {"SUB_CPY_ID","CRT_NO","CUS_NO","PAY_KIND","CUS_NAME","ID","BLD_NAME",
				"PIN_CODE","PIN_NAME","FLD_NO","ROOM_NO","PRK_NO","INV_AMT","SAL_AMT","TAX_AMT","TAX_TYPE",
				"PAY_S_DATE","PAY_E_DATE","SLIP_DATE","SLIP_DIV_NO","INV_CD","SER_NO","CHK_NO","RCV_NO",
				"DIV_NO","TRN_KIND","CHG_DATE","CHG_DIV_NO","CHG_ID","CHG_NAME","APLY_NO"};
		
		buds_Insert_1.setField("INV_NO",  STRING.objToStrNoNull(bqds.getField("INV_NO")));
		buds_Insert_1.setField("RCV_YM", RCV_YM);
		for(String colkey : C203col){
			buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
		}
		String BLD_CD = STRING.objToStrNoNull(bqds.getField("BLD_CD"));
//		if(BLD_CD!=null && !BLD_CD.trim().equals("")){
//			BLD_CD = "0000"+BLD_CD;
//		}
		buds_Insert_1.setField("BLD_CD",  BLD_CD);
		buds_Insert_1.setField("INV_DATE", isnull==1?null:(bqds.getField("INV_DATE")));
		Integer SLIP_SEQ_NO = (bqds.getField("SLIP_SEQ_NO")==null || bqds.getField("SLIP_SEQ_NO").toString().trim().equals(""))
			?null:Integer.parseInt(bqds.getField("SLIP_SEQ_NO").toString().trim());
		buds_Insert_1.setField("SLIP_SEQ_NO", SLIP_SEQ_NO);
		buds_Insert_1.setField("APLY_DATE", (isnull==1 || isnull==2)?null:(bqds.getField("APLY_DATE")));
		buds_Insert_1.setField("PRT_DATE",  isnull==1?null:(bqds.getField("PRT_DATE")));
		buds_Insert_1.setField("D_ACNT_DATE",  isnull==2?null:(bqds.getField("D_ACNT_DATE")));
		buds_Insert_1.setField("D_ACNT_ID",  isnull==2?null:(bqds.getField("D_ACNT_ID")));
		buds_Insert_1.setField("D_ACNT_DIV_NO",  isnull==2?null:(bqds.getField("D_ACNT_DIV_NO")));
		buds_Insert_1.setField("D_SLPLOT_NO",  isnull==2?null:(bqds.getField("D_SLPLOT_NO")));
		buds_Insert_1.setField("D_SLPSET_NO",  isnull==2?null:(bqds.getField("D_SLPSET_NO")));
		buds_Insert_1.setField("D_CFM_DATE",  isnull==2?null:(bqds.getField("D_CFM_DATE")));
	}
	
	private void setDTEPC204_Fields(BatchQueryDataSet bqds, int isnull) throws DBException {
		BigDecimal RCV_YM = new BigDecimal(bqds.getField("RCV_YM").toString().trim()).add(BD1911);
		String[] C203col = {"SER_NO","SUB_CPY_ID","CRT_NO","CUS_NO","CUS_NAME","ID","INV_AMT","SAL_AMT","TAX_AMT","TAX_TYPE",
				"RJT_AMT","RJT_TAX","RJT_S_DATE","RJT_E_DATE","RJT_RNT_AMT","RJT_SPR_AMT","RJT_PRPSP_AMT","RJT_C104PRP_AMT",
				"R_ACNT_DATE","R_ACNT_ID","R_ACNT_NAME","R_ACNT_DIV_NO","R_SLPLOT_NO","R_SLPSET_NO","R_TRNSER_NO","PAY_TYPE",
				"ACPT_BANK_NO","ACPT_ACNT_NO","ACPT_ACNT_NAME","ACPT_ID","RMT_BANK_NO","RMT_ACNT_NO","TRN_KIND",
				"CHG_DATE","CHG_DIV_NO","CHG_ID","CHG_NAME"};
		
		buds_Insert_1.setField("INV_NO",  STRING.objToStrNoNull(bqds.getField("INV_NO")));
		buds_Insert_1.setField("RCV_YM", RCV_YM);
		for(String colkey : C203col){
			buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
		}
	}

	private void setDTEPC203_Fields(BatchQueryDataSet bqds, int isnull) throws DBException {
		BigDecimal INV_YM = new BigDecimal(bqds.getField("INV_YM").toString().trim()).add(BD1911);
		String[] C203col = {"SUB_CPY_ID","INV_CD_1","INV_SNO_1","INV_ENO_1","INV_LNO_1","SEQ_NO_1"
				,"INV_CD_2","INV_SNO_2","INV_ENO_2","INV_LNO_2","SEQ_NO_2"};
		
		buds_Insert_1.setField("INV_YM", INV_YM);
		for(String colkey : C203col){
			buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
		}
	}
	
}
