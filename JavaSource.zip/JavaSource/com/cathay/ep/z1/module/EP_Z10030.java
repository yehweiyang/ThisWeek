package com.cathay.ep.z1.module;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.hr.Employee;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.hr.Unit;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.vo.DTEPZ103_LOG;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/** 
 * <pre>
 * DATE    Description Author
 * 2013/11/11  Created ���կ�
 * //180410:�Y�d�L�ӤH���(�i��w��¾),��H���
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    EMAIL�H�o�]�w���@�Ҳ�
 * �Ҳ�ID    EP_Z10030
 * ���n����    EMAIL�H�o�]�w���@�Ҳ�
 * 
 * </pre>
 * @author �¶��� 
 * @since 2013/11/21  
 */

@SuppressWarnings("unchecked")
public class EP_Z10030 {

    /** log */
    private static final Logger log = Logger.getLogger(EP_Z10030.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.z1.module.EP_Z10030.SQL_queryList_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z1.module.EP_Z10030.SQL_queryMap_001";

    private static final String SQL_getMailList_001 = "com.cathay.ep.z1.module.EP_Z10030.SQL_getMailList_001";

    private static final String SQL_getMailByID_001 = "com.cathay.ep.z1.module.EP_Z10030.SQL_getMailByID_001";

    /**
     * @param SUB_CPY_ID �����q�O
     * @param ID �ҥ󸹽X
     * @param NAME �W��
     * @return rtnList �]�w_EMAIL�q�����@��DTEPZ103
     * @throws ModuleException
     */
    public List<Map> queryList(String SUB_CPY_ID, String ID, String NAME) throws ModuleException {

        //�ˮֶǤJ�Ѽ�
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z10030_MSG_001"));//�����q�O���o���ŭ�
        }
        //�H�ǤJ�ѼƬd��EMAIL�q�����@��(DTEPZ103)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotBlank(ID)) {
            sb.append("%").append(ID).append("%");
            ds.setField("ID", sb.toString());
            sb.setLength(0);
        }
        if (StringUtils.isNotBlank(NAME)) {
            sb.append("%").append(NAME).append("%");
            ds.setField("NAME", sb.toString());
            sb.setLength(0);
        }

        return VOTool.findToMaps(ds, SQL_queryList_001);

    }

    /**
     *  Ū���]�w_EMAIL�q�����@��
     * @param SUB_CPY_ID �����q�O
     * @param ID �ҥ󸹽X
     * @return rtnMap DTEPZ103�]�w_EMAIL�q�����@��
     * @throws ModuleException
     */
    public Map queryMap(String SUB_CPY_ID, String ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_001"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_002"));//�ҥ󸹽X���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("ID", ID);
        return VOTool.findOneToMap(ds, SQL_queryMap_001);

    }

    /**
     * ��EMAIL����Ū���q�����@�ɲM��
     * @param SUB_CPY_ID �����q�O
     * @param ITEM EMAIL����
     * @return rtnMap Map<�����q�O, List<DTEPZ103>> 
     * @throws ModuleException
     */
    public Map<String, List<DTEPZ103>> getMailList(String SUB_CPY_ID, String ITEM) throws ModuleException {
        //�ˮֶǤJ�Ѽ�
        if (StringUtils.isBlank(ITEM)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z10030_MSG_003"));//EMAIL���ؤ��o���ŭ�
        }

        DataSet ds = Transaction.getDataSet();

        StringBuilder sb = new StringBuilder();
        sb.append("%").append(ITEM).append("%");
        ds.setField("ITEM", sb.toString());
        sb.setLength(0);

        if (StringUtils.isNotBlank(SUB_CPY_ID)) {
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        }

        DBUtil.searchAndRetrieve(ds, SQL_getMailList_001);//�d�߸�ƨ�SUB_CPY_ID, ID �Ƨ�
        Map keyMap = null;
        List<DTEPZ103> tmpList = null;
        Map<String, List<DTEPZ103>> rtnMap = new HashMap<String, List<DTEPZ103>>();
        String keySUB_CPY_ID = null;
        while (ds.next()) {
            String rtnSUB_CPY_ID = (String) ds.getField("SUB_CPY_ID");
            DTEPZ103 EPZ103VO = VOTool.dataSetToVO(DTEPZ103.class, ds);
            //��SUB_CPY_ID���s
            if (keyMap == null) {
                keyMap = new HashMap();
                tmpList = new ArrayList();
                keyMap.put(rtnSUB_CPY_ID, null);
                keySUB_CPY_ID = rtnSUB_CPY_ID;
                tmpList.add(EPZ103VO);
                continue;
            }
            if (!keyMap.containsKey(rtnSUB_CPY_ID)) {
                rtnMap.put(keySUB_CPY_ID, tmpList);
                keyMap.put(rtnSUB_CPY_ID, null);
                tmpList = new ArrayList();
                keySUB_CPY_ID = rtnSUB_CPY_ID;
            }

            tmpList.add(EPZ103VO);
        }

        rtnMap.put(keySUB_CPY_ID, tmpList);

        return rtnMap;

    }

    /**
     * ��ID���oEMAIL�M��
     * @param SUB_CPY_ID �����q�O
     * @param DIV_NO ���N��
     * @param ID
     * @param EMAIL_KIND EMAIL����(1�ӤH2���3�ӤH�γ��)
     * @return
     * @throws ModuleException
     * @throws SQLException 
     */
    public List<Map> getMailByID(String SUB_CPY_ID, String DIV_NO, String ID, String EMAIL_KIND) throws ModuleException, SQLException {
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_001"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(EMAIL_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_004"));//EMAIL�������o���ŭ�
        } else {

            if (!("1".equals(EMAIL_KIND) || "2".equals(EMAIL_KIND) || "3".equals(EMAIL_KIND))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_005"));//EMAIL�������~
            } else {
                if (("1".equals(EMAIL_KIND) || "3".equals(EMAIL_KIND)) && StringUtils.isBlank(ID)) { //1�ӤH 3�ӤH�γ��
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_006"));//ID���o���ŭ�
                }
                if (("2".equals(EMAIL_KIND) || "3".equals(EMAIL_KIND)) && StringUtils.isBlank(DIV_NO)) { //2��� 3�ӤH�γ��
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_007"));//���N�����o���ŭ�
                }
            }

        }
        if (eie != null) {
            throw eie;
        }
        boolean IS_FROM_HR = false;
        //�P�_�O�_�i�ѤH�Ƹ�ƨ��oEMAIL, �Y�i�ѤH�ƼҲը��o�h�u���ϥΤH�ƼҲո��

        String CPY_CTR_NM = FieldOptionList.getName("EP", "CPY_CTR", SUB_CPY_ID);
        if (StringUtils.isNotBlank(CPY_CTR_NM)) {
            IS_FROM_HR = true; //�i�ѤH�ƨ��o
        }
        List<Map> rtnList = null;
        boolean noPersonMailToDiv = false;
        if (IS_FROM_HR) {
            if ("1".equals(EMAIL_KIND) || "3".equals(EMAIL_KIND)) {//1�ӤH 3�ӤH�γ��

                Employee emp = new PersonnelData().getByEmployeeID(ID, true);
                if (emp != null) { //�Y�L��Ƥ������~
                    String hrEMAIL = emp.getEmail();
                    if (StringUtils.isNotBlank(hrEMAIL)) {
                        Map tmpMap = new HashMap();
                        tmpMap.put("EMAIL", hrEMAIL);
                        tmpMap.put("ID", ID);
                        tmpMap.put("CHG_DIV_NO", emp.getDivNo());
                        tmpMap.put("NAME", emp.getName());
                        rtnList = initList(rtnList);
                        rtnList.add(tmpMap);
                    }
                } else {//180410:�Y�d�L�ӤH���(�i��w��¾),��H���
                    log.fatal("�d�L�ӤHmail,��H���H�c");
                    noPersonMailToDiv = true;
                }
            }
            if (noPersonMailToDiv || "2".equals(EMAIL_KIND) || "3".equals(EMAIL_KIND)) {//2��� 3�ӤH�γ��       
                Unit divUnit = new DivData().getUnit(DIV_NO);
                if (divUnit != null) {//�Y�L��Ƥ������~
                    String hrEMAIL = divUnit.getDivEmail();
                    if (StringUtils.isNotBlank(hrEMAIL)) {
                        Map tmpMap = new HashMap();
                        tmpMap.put("EMAIL", hrEMAIL);
                        tmpMap.put("ID", DIV_NO);
                        tmpMap.put("CHG_DIV_NO", DIV_NO);
                        tmpMap.put("NAME", divUnit.getDivShortName());
                        rtnList = initList(rtnList);
                        rtnList.add(tmpMap);
                    }
                }
            }
        }

        if (rtnList != null) {
            return rtnList;
        }

        //�H�ǤJ�ѼƬd��EMAIL�q�����@��(DTEPZ103)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if ("1".equals(EMAIL_KIND)) {//�ӤH
            ds.setFieldValues("IDs", new String[] { ID });
            
          //180410:�Y�d�L�ӤH���(�i��w��¾),��H���
            try {
                return VOTool.findToMaps(ds, SQL_getMailByID_001);
            } catch (DataNotFoundException dnfe) {
                log.fatal("�d�L�ӤHmail,��H���H�c");
                noPersonMailToDiv = true;
            }
        }
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (noPersonMailToDiv || "2".equals(EMAIL_KIND)) {//���
            ds.setFieldValues("IDs", new String[] { DIV_NO });
        } else if ("3".equals(EMAIL_KIND)) {//�ӤH�γ��
            ds.setFieldValues("IDs", new String[] { DIV_NO, ID });
        }
        return VOTool.findToMaps(ds, SQL_getMailByID_001);

    }

    /**
     * �s�WEMAIL�q�����@��
     * @param SUB_CPY_ID �����q�O
     * @param Z103Vo �]�w_EMAIL�q�����@��
     * @param user  �ϥΪ̸�T
     * @throws ModuleException
     */
    public void insert(String SUB_CPY_ID, DTEPZ103 Z103Vo, UserObject user) throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_001"));//�����q�O���o���ŭ�
        }
        if (Z103Vo == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_008"));//EMAIL�q�����@��Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_009"));//�ϥΪ̸�T���o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        //�s�WEMAIL�q�����@��DTEPZ103�G
        Timestamp UPD_TIME = DATE.currentTime();
        Z103Vo.setSUB_CPY_ID(SUB_CPY_ID);
        Z103Vo.setCHG_DATE(UPD_TIME);
        Z103Vo.setCHG_DIV_NO(user.getOpUnit());
        Z103Vo.setCHG_ID(user.getEmpID());
        Z103Vo.setCHG_NAME(user.getEmpName());
        VOTool.insert(Z103Vo);
        //�g�J�@��LOG��
        insertLog(Z103Vo, "I", user, UPD_TIME.toString());

    }

    /**
     * ��sEMAIL�q�����@��
     * @param Z103Vo �]�w_EMAIL�q�����@��
     * @param user �ϥΪ̸�T
     * @throws ModuleException
     */
    public void update(DTEPZ103 Z103Vo, UserObject user) throws ModuleException {

        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (Z103Vo == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_008"));//EMAIL�q�����@��Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_009"));//�ϥΪ̸�T���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //��sEMAIL�q�����@��DTEPZ103�G
        Timestamp UPD_TIME = DATE.currentTime();
        Z103Vo.setCHG_DATE(UPD_TIME);
        Z103Vo.setCHG_DIV_NO(user.getOpUnit());
        Z103Vo.setCHG_ID(user.getEmpID());
        Z103Vo.setCHG_NAME(user.getEmpName());
        //�g�J�@��LOG��
        insertLog(Z103Vo, "U", user, UPD_TIME.toString());
        VOTool.update(Z103Vo);

    }

    /**
     * �R��EMAIL�q�����@��
     * @param delList DTEPZ103��EMAIL�q�����@��List
     * @param user �ϥΪ̸�T
     * @throws ModuleException
     */
    public void delete(List<DTEPZ103> delList, UserObject user) throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (delList == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_008"));//EMAIL�q�����@��Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_009"));//�ϥΪ̸�T���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�R��EMAIL�q�����@�ɡG
        for (DTEPZ103 Z103Vo : delList) {
            //�g�J�@��LOG��
            insertLog(Z103Vo, "D", user, DATE.currentTime().toString());
            //�R��EMAIL�q�����@��DTEPZ103
            VOTool.delByPK(Z103Vo);
        }

    }

    /**
     * �s�WEMAIL�q�����@��
     * @param Z103Vo  EMAIL�q�����@��
     * @param DATA_TYPE  �������(I:�s�W,U:��s,D:�R��)
     * @param user �ϥΪ̸�T
     * @param UPD_TIME �@�~����ɶ�
     * @throws ModuleException
     */
    public void insertLog(DTEPZ103 Z103Vo, String DATA_TYPE, UserObject user, String UPD_TIME) throws ModuleException {

        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (Z103Vo == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_008"));//EMAIL�q�����@��Ƥ��o���ŭ�
        }
        if (StringUtils.isBlank(DATA_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_012"));//����������o���ŭ�
        } else if (!("I".equals(DATA_TYPE) || "U".equals(DATA_TYPE) || "D".equals(DATA_TYPE))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_010"));//��������ǤJ���~
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_009"));//�ϥΪ̸�T���o���ŭ�
        }
        if (StringUtils.isBlank(UPD_TIME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z10030_MSG_011"));//�@�~����ɶ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = Z103Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z10030_MSG_001"));//�����q�O���o���ŭ�
        }

        //�g�@��LOG��
        DTEPZ103_LOG Z103Vo_Log = VOTool.mapToVO(DTEPZ103_LOG.class, queryMap(SUB_CPY_ID, Z103Vo.getID()));
        Z103Vo_Log.setDATA_TYPE(DATA_TYPE);
        Z103Vo_Log.setUPD_DATE(Timestamp.valueOf(UPD_TIME));
        Z103Vo_Log.setUPD_ID(user.getEmpID());
        Z103Vo_Log.setUPD_NAME(user.getEmpName());
        VOTool.insert(Z103Vo_Log);

    }

    /**
     * ��wEIE���� 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * ��wLIST���� 
     * @param o
     * @return
     */
    private List<Map> initList(List<Map> o) {
        return o == null ? new ArrayList() : o;
    }
}
