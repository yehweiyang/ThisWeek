/* �b 2010-03-25 �إ�*/
package com.cathay.ep.z1.batch;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.ConfigManager;
import com.cathay.common.util.DATE;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.CountManager;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.batch.ErrorLog;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPZ002;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.ep.z1.module.EP_Z1Z002;
import com.cathay.rz.n0.module.RZ_N0Z001;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 *  
 */
@SuppressWarnings("unchecked")
public class EPZ1_0100 extends EP_BatchBean { // �~��BatchBean
    /** logger */
    private static Logger log = Logger.getLogger(EPZ1_0100.class);

    private boolean isDebug = false;// log.isDebugEnabled();

    /** �@�~�W�� */
    private static final String JOB_NAME = "JAEPE305";

    /** �{���W�� */
    private static final String PROGRAM = "EPZ1_0100";

    /** �~�ȧO */
    private static final String BUSINESS = "EP";

    /** ���t�ΦW�� */
    private static final String SUBSYSTEM = "Z1";

    /** ����g�� */
    private static final String PERIOD = "��";

    /** ������檺��� , �Y�]�� 0 �h������ , �ȷ|����@�� , �Ъ`�N��ƶq���j�p */
    private static final int FETCH_SIZE = 1000;// Integer.parseInt(ConfigManager

    // .getProperty("FETCH_SIZE"));

    /** �]�� true �������|�۰ʭp���ƤΰO���T�� , false �h�ȷ|�O���T�� */
    private static final boolean isNOT_WRITELOG = false;

    // private static final String delete_sql_C101 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC101";
    private static final String query_sql_C101 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC101";

    private static final String delete_sql_C101_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC101_2";

    private static final String update_sql_Z001 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_updateZ001";

    private static final String query_sql_C02toC101 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC02toC101";

    private static final String query_sql_D05toC101 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryD05toC101";

    private static final String insert_sql_C101 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_insertC101";
    
    private static final String query_sql_C101forUpd = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_C101forUpd";
    private static final String update_sql_C101 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_updateC101";

    // private static final String delete_sql_C202 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC202";
    private static final String query_sql_C202 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC202";

    private static final String delete_sql_C202_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC202_2";

    // private static final String query_sql_D05toC202 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryD05toC202";
    private static final String query_sql_D03toC202 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryD03toC202";

    private static final String insert_sql_C202 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_insertC202";

    // private static final String delete_sql_C204 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC204";
    private static final String query_sql_C204 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC204";

    private static final String delete_sql_C204_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC204_2";

    private static final String query_sql_D03toC204 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryD03toC204";

    private static final String insert_sql_C204 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_insertC204";

    // private static final String delete_sql_C203 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC203";
    private static final String query_sql_C203 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC203";

    private static final String delete_sql_C203_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC203_2";

    private static final String query_sql_D04toC203 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryD04toC203";

    private static final String insert_sql_C203 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_insertC203";

    // private static final String delete_sql_DKG002 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteDKG002";
    private static final String query_sql_DKG002 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryDKG002";

    private static final String delete_sql_DKG002_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteDKG002_2";

    private static final String query_sql_E07toDKG002 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryE07toDKG002";

    private static final String insert_sql_DKG002 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_insertDKG002";

    // private static final String delete_sql_DKG003 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteDKG003";
    private static final String query_sql_DKG003 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryDKG003";

    private static final String delete_sql_DKG003_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteDKG003_2";

    private static final String query_sql_E08toDKG003 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryE08toDKG003";

    private static final String insert_sql_DKG003 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_insertDKG003";

    // private static final String delete_sql_C301 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC301";
    // private static final String delete_sql_C306 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC306";
    private static final String query_sql_C301 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC301";

    private static final String delete_sql_C301_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC301_2";

    private static final String query_sql_C306 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC306";

    private static final String delete_sql_C306_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC306_2";

    private static final String query_sql_E01toC301C306 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryE01toC301C306";

    private static final String insert_sql_C301 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_insertC301";

    private static final String insert_sql_C306 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_insertC306";

//    private static final String query_sql_E01FAIL = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryE01FAIL";
//
//    private static final String delete_sql_E01FAIL = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteE01FAIL";
//
//    private static final String insert_sql_E01FAIL = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_insertE01FAIL";

    // private static final String delete_sql_C201 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC201";
    private static final String query_sql_C201 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC201";

    private static final String delete_sql_C201_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC201_2";

    private static final String query_sql_D01toC201 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_D01toC201";

    private static final String insert_sql_C201 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C201";

    // private static final String delete_sql_C105 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.delete_sql_C105";
    private static final String query_sql_C105 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC105";

    private static final String delete_sql_C105_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC105_2";

    private static final String query_sql_C01toC105 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_C01toC105";

    private static final String insert_sql_C105 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C105";

    // private static final String delete_sql_C104 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.delete_sql_C104";
    private static final String query_sql_C104 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC104";

    private static final String delete_sql_C104_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC104_2";

    private static final String query_sql_C07toC104 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_C04toC104";

    private static final String insert_sql_C104 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C104";

    // private static final String delete_sql_C302 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.delete_sql_C302";
    private static final String query_sql_C302 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC302";

    private static final String delete_sql_C302_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC302_2";

    private static final String query_sql_E05toC302 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_E05toC302";

    private static final String insert_sql_C302 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C302";

    // private static final String delete_sql_C303 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.delete_sql_C303";
    private static final String query_sql_C303 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC303";

    private static final String delete_sql_C303_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC303_2";

    private static final String query_sql_E06toC303 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_E06toC303";

    private static final String insert_sql_C303 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C303";

    // private static final String delete_sql_C305 =
    // "com.cathay.ep.z1.batch.EPZ1_0010.delete_sql_C305";
    private static final String query_sql_C305 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC305";

    private static final String delete_sql_C305_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC305_2";

    private static final String query_sql_E04toC305 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_E04toC305";

    private static final String insert_sql_C305 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C305";

    private static final String query_sql_Z998 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_Z998";

    private static final String query_sql_Z998_2 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_Z998_2";

//    private static final String query_sql_Z998_3 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_Z998_3";

    private static final String delete_sql_Z998 = "com.cathay.ep.z1.batch.EPZ1_0010.delete_sql_Z998";

    private static final String insert_sql_Z998 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_Z998";

    private static final String query_sql_B107 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryB107";

    private static final String delete_sql_B107_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteB107_2";

    private static final String query_sql_DKO060toB107 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_DKO060toB107";

    private static final String insert_sql_B107 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_B107";

    private static final String query_sql_B106 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryB106";

    private static final String delete_sql_B106_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteB106_2";

    private static final String query_sql_DKO090toB106 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_DKO090toB106";

    private static final String query_sql_DKO090toB106_2 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_DKO090toB106_2";

    private static final String insert_sql_B106 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_B106";

    private static final String query_sql_B201 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryB201";

    private static final String delete_sql_B201_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteB201_2";

    private static final String query_sql_B102toB201 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_B102toB201";

    private static final String insert_sql_B201 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_B201";

    private static final String query_sql_C102 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC102";

    private static final String delete_sql_C102_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC102_2";

    private static final String query_sql_C03toC102 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_C03toC102";

    private static final String insert_sql_C102 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C102";

    private static final String query_sql_C103 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC103";

    private static final String delete_sql_C103_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC103_2";

    private static final String query_sql_C06toC103 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_C06toC103";

    private static final String insert_sql_C103 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C103";

    private static final String query_sql_C206 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC206";

    private static final String delete_sql_C206_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC206_2";

    private static final String query_sql_DKO102toC206 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_DKO102toC206";

    private static final String insert_sql_C206 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C206";

    private static final String query_sql_C207 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC207";

    private static final String delete_sql_C207_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC207_2";

    private static final String query_sql_DKO103toC207 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_DKO103toC207";

    private static final String insert_sql_C207 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C207";

    private static final String query_sql_C208 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC208";

    private static final String delete_sql_C208_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC208_2";

    private static final String query_sql_DKO101toC208 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_DKO101toC208";

    private static final String insert_sql_C208 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C208";

    private static final String query_sql_C209 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC209";

    private static final String delete_sql_C209_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC209_2";

    private static final String query_sql_DKO104toC209 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_DKO104toC209";

    private static final String insert_sql_C209 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C209";

    private static final String query_sql_C205 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC205";

    private static final String delete_sql_C205_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC205_2";

    private static final String query_sql_DKO100toC205 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_DKO100toC205";

    private static final String insert_sql_C205 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C205";
    
    private static final String query_sql_C304 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_queryC304";

    private static final String delete_sql_C304_2 = "com.cathay.ep.z1.batch.EPZ1_0010.SQL_deleteC304_2";

    private static final String query_sql_E11toC304 = "com.cathay.ep.z1.batch.EPZ1_0010.query_sql_E11toC304";

    private static final String insert_sql_C304 = "com.cathay.ep.z1.batch.EPZ1_0010.insert_sql_C304";

    // User Add
    /** �d�ߪ����� */
    private BatchQueryDataSet bqds_1;

    /** �s�W������ */
    private BatchUpdateDataSet buds_Insert_1;

    private BatchUpdateDataSet buds_Insert_2;

    private BatchUpdateDataSet buds_Insert_3;

//    private BatchUpdateDataSet buds_Insert_4;

    /** ���~�T���O������ */
    private ErrorLog errorLog;

    /** �p�ƾ� */
    private CountManager countManager;

    /** �̿��~���h�Ũ��o���~����� */
    private ErrorHandler errorHandler;

    private DataSet queryDS;

    private BigDecimal oldRCV_YM = BigDecimal.ZERO;

    private BigDecimal oldINT_YM = BigDecimal.ZERO;

    private BigDecimal oldTRN_YM = BigDecimal.ZERO;

    private BigDecimal BD1911 = new BigDecimal("191100");

    private StringBuilder sb = new StringBuilder();
    
    private Map<String,String> nameMap = new HashMap();
    
    private Map<String,String> idMap = new HashMap();

    private static final String INPUT_COUNT_C02_toC101 = "C02Ū�����(C101)";

    private static final String OUTPUT_COUNT_C101_fromC02 = "C101�s�W���(C02)";

    private static final String ERROR_COUNT_C101_fromC02 = "C101���~���(C02)";

    private static final String INPUT_COUNT_D05_toC101 = "D05Ū�����(C101)";

    private static final String OUTPUT_COUNT_C101_fromD05 = "C101�s�W���(D05)";

    private static final String ERROR_COUNT_C101_fromD05 = "C101���~���(D05)";    
    
    private static final String INPUT_COUNT_D03_toC202 = "D03Ū�����(C202)";

    private static final String OUTPUT_COUNT_C202_fromD03 = "C202�s�W���(D03)";

    private static final String ERROR_COUNT_C202_fromD03 = "C202���~���(D03)"; 
    
    private static final String INPUT_COUNT_D03_toC204 = "D03Ū�����(C204)";

    private static final String OUTPUT_COUNT_C204_fromD03 = "C204�s�W���(D03)";

    private static final String ERROR_COUNT_C204_fromD03 = "C204���~���(D03)"; 
    
    private static final String INPUT_COUNT_D04_toC203 = "D04Ū�����(C203)";

    private static final String OUTPUT_COUNT_C203_fromD04 = "C203�s�W���(D04)";

    private static final String ERROR_COUNT_C203_fromD04 = "C203���~���(D04)"; 
    
    private static final String INPUT_COUNT_E07_toDKG002 = "E07Ū�����(DKG002)";
    
    private static final String OUTPUT_COUNT_DKG002_fromE07 = "DKG002�s�W���(E07)";

    private static final String ERROR_COUNT_DKG002_fromE07 = "DKG002���~���(E07)";
    
    private static final String INPUT_COUNT_E07_toC306 = "E07Ū�����(C306)";
    
    private static final String OUTPUT_COUNT_C306_fromE07 = "C306�s�W���(E07)";

    private static final String ERROR_COUNT_C306_fromE07 = "C306���~���(E07)";
    
    private static final String INPUT_COUNT_E08_toDKG003 = "E08Ū�����(DKG003)";

    private static final String OUTPUT_COUNT_DKG003_fromE08 = "DKG003�s�W���(E08)";

    private static final String ERROR_COUNT_DKG003_fromE08 = "DKG003���~���(E08)";
    
    private static final String INPUT_COUNT_E01_toC301C306 = "E01Ū�����(C301C306)";

    private static final String OUTPUT_COUNT_C301_fromE01 = "C301�s�W���(E01)";
    private static final String OUTPUT_COUNT_C301FAIL_fromE01 = "C301FAIL�s�W���(E01)";
    private static final String OUTPUT_COUNT_C306_fromE01 = "C306�s�W���(E01)";

    private static final String ERROR_COUNT_C301_fromE01 = "C301���~���(E01)";
    private static final String ERROR_COUNT_C301FAIL_fromE01 = "C301FAIL���~���(E01)";
    private static final String ERROR_COUNT_C306_fromE01 = "C306���~���(E01)";
    
    private static final String INPUT_COUNT_D01_toC201 = "D01Ū�����(C201)";

    private static final String OUTPUT_COUNT_C201_fromD01 = "C201�s�W���(D01)";

    private static final String ERROR_COUNT_C201_fromD01 = "C201���~���(D01)";
    
    private static final String INPUT_COUNT_C01_toC105 = "C01Ū�����(C105)";

    private static final String OUTPUT_COUNT_C105_fromC01 = "C105�s�W���(C01)";

    private static final String ERROR_COUNT_C105_fromC01 = "C105���~���(C01)";
    
    private static final String INPUT_COUNT_C07_toC104 = "C07Ū�����(C104)";

    private static final String OUTPUT_COUNT_C104_fromC07 = "C104�s�W���(C07)";

    private static final String ERROR_COUNT_C104_fromC07 = "C104���~���(C07)";
    
    private static final String INPUT_COUNT_E05_toC302 = "E05Ū�����(C302)";

    private static final String OUTPUT_COUNT_C302_fromE05 = "C302�s�W���(E05)";

    private static final String ERROR_COUNT_C302_fromE05 = "C302���~���(E05)";
    
    private static final String INPUT_COUNT_E06_toC303 = "E06Ū�����(C303)";

    private static final String OUTPUT_COUNT_C303_fromE06 = "C303�s�W���(E06)";

    private static final String ERROR_COUNT_C303_fromE06 = "C303���~���(E06)";
    
    private static final String INPUT_COUNT_E04_toC305 = "E04Ū�����(C305)";

    private static final String OUTPUT_COUNT_C305_fromE04 = "C305�s�W���(E04)";

    private static final String ERROR_COUNT_C305_fromE04 = "C305���~���(E04)";
    
    private static final String INPUT_COUNT_B102_toB201 = "B102Ū�����(B201)";

    private static final String OUTPUT_COUNT_B201_fromB102 = "B201�s�W���(B102)";

    private static final String ERROR_COUNT_B201_fromB102 = "B201���~���(B102)";
    
    private static final String INPUT_COUNT_C03_toC102 = "C03Ū�����(C102)";

    private static final String OUTPUT_COUNT_C102_fromC03 = "C102�s�W���(C03)";

    private static final String ERROR_COUNT_C102_fromC03 = "C102���~���(C03)";
    
    private static final String INPUT_COUNT_C06_toC103 = "C06Ū�����(C103)";

    private static final String OUTPUT_COUNT_C103_fromC06 = "C103�s�W���(C06)";

    private static final String ERROR_COUNT_C103_fromC06 = "C103���~���(C06)";
    
    private static final String INPUT_COUNT_DKO060_toB107 = "DKO060Ū�����(B107)";

    private static final String OUTPUT_COUNT_B107_fromDKO060 = "B107�s�W���(DKO060)";

    private static final String ERROR_COUNT_B107_fromDKO060 = "B107���~���(DKO060)";
    
    private static final String INPUT_COUNT_DKO090092_toB106 = "DKO090092Ū�����(B106)";
    private static final String INPUT_COUNT_DKO090060_toB106 = "DKO090060Ū�����(B106)";

    private static final String OUTPUT_COUNT_B106_fromDKO090092 = "B106�s�W���(DKO090092)";
    private static final String OUTPUT_COUNT_B106_fromDKO090060 = "B106�s�W���(DKO090060)";

    private static final String ERROR_COUNT_B106_fromDKO090092 = "B106���~���(DKO090092)";
    private static final String ERROR_COUNT_B106_fromDKO090060 = "B106���~���(DKO090060)";
    
    private static final String INPUT_COUNT_DKO102_toC206 = "DKO102Ū�����(C206)";

    private static final String OUTPUT_COUNT_C206_fromDKO102 = "C206�s�W���(DKO102)";

    private static final String ERROR_COUNT_C206_fromDKO102 = "C206���~���(DKO102)";
    
    private static final String INPUT_COUNT_DKO103_toC207 = "DKO103Ū�����(C207)";

    private static final String OUTPUT_COUNT_C207_fromDKO103 = "C207�s�W���(DKO103)";

    private static final String ERROR_COUNT_C207_fromDKO103 = "C207���~���(DKO103)";
    
    private static final String INPUT_COUNT_DKO101_toC208 = "DKO101Ū�����(C208)";

    private static final String OUTPUT_COUNT_C208_fromDKO101 = "C208�s�W���(DKO101)";

    private static final String ERROR_COUNT_C208_fromDKO101 = "C208���~���(DKO101)";

    private static final String INPUT_COUNT_DKO104_toC209 = "DKO104Ū�����(C209)";

    private static final String OUTPUT_COUNT_C209_fromDKO104 = "C209�s�W���(DKO104)";

    private static final String ERROR_COUNT_C209_fromDKO104 = "C209���~���(DKO104)";
    
    private static final String INPUT_COUNT_DKO100_toC205 = "DKO100Ū�����(C205)";

    private static final String OUTPUT_COUNT_C205_fromDKO100 = "C205�s�W���(DKO100)";

    private static final String ERROR_COUNT_C205_fromDKO100 = "C205���~���(DKO100)";
    
    private static final String INPUT_COUNT_E11_toC304 = "E11Ū�����(C304)";

    private static final String OUTPUT_COUNT_C304_fromE11 = "C304�s�W���(E11)";

    private static final String ERROR_COUNT_C304_fromE11 = "C304���~���(E11)";
    
    public EPZ1_0100() throws Exception {
        // �]�� true �������|�۰ʭp���ƤΰO���T�� , false �h�ȷ|�O���T��*/
        super(FETCH_SIZE, JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isNOT_WRITELOG);

        // ���~�T���O������
        errorLog = new ErrorLog(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM);
        // �����ưO������
        countManager = new CountManager(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD);

        initCountManager();        
        
        errorHandler = new ErrorHandler();

        queryDS = this.getDataSet();
        bqds_1 = getBatchQueryDataSet();
        buds_Insert_1 = getBatchUpdateDataSet();
        buds_Insert_2 = getBatchUpdateDataSet(buds_Insert_1);
        buds_Insert_3 = getBatchUpdateDataSet(buds_Insert_2);
//        buds_Insert_4 = getBatchUpdateDataSet(buds_Insert_2);
        
 

    }

    /**
     * ��l�p��
     * @throws ModuleException
     */
    private void initCountManager() throws ModuleException {

        countManager.createCountType("START");
        countManager.writeLog();
        countManager.clearCountTypeAndNumber();
        countManager.createCountType(INPUT_COUNT_C02_toC101);
        countManager.createCountType(OUTPUT_COUNT_C101_fromC02);
        countManager.createCountType(ERROR_COUNT_C101_fromC02);
        
        countManager.createCountType(INPUT_COUNT_D05_toC101);
        countManager.createCountType(OUTPUT_COUNT_C101_fromD05);
        countManager.createCountType(ERROR_COUNT_C101_fromD05);
        
        countManager.createCountType(INPUT_COUNT_D03_toC202);
        countManager.createCountType(OUTPUT_COUNT_C202_fromD03);
        countManager.createCountType(ERROR_COUNT_C202_fromD03);
        
        countManager.createCountType(INPUT_COUNT_D03_toC204);
        countManager.createCountType(OUTPUT_COUNT_C204_fromD03);
        countManager.createCountType(ERROR_COUNT_C204_fromD03);
        
        countManager.createCountType(INPUT_COUNT_D04_toC203);
        countManager.createCountType(OUTPUT_COUNT_C203_fromD04);
        countManager.createCountType(ERROR_COUNT_C203_fromD04);
        
        countManager.createCountType(INPUT_COUNT_E07_toDKG002);
        countManager.createCountType(OUTPUT_COUNT_DKG002_fromE07);
        countManager.createCountType(ERROR_COUNT_DKG002_fromE07);
          
        countManager.createCountType(INPUT_COUNT_E07_toC306);
        countManager.createCountType(OUTPUT_COUNT_C306_fromE07);
        countManager.createCountType(ERROR_COUNT_C306_fromE07);
        
        countManager.createCountType(INPUT_COUNT_E08_toDKG003);
        countManager.createCountType(OUTPUT_COUNT_DKG003_fromE08);
        countManager.createCountType(ERROR_COUNT_DKG003_fromE08);
        
        countManager.createCountType(INPUT_COUNT_E01_toC301C306);
        countManager.createCountType(OUTPUT_COUNT_C301_fromE01);
        countManager.createCountType(OUTPUT_COUNT_C301FAIL_fromE01);
        countManager.createCountType(OUTPUT_COUNT_C306_fromE01);
        countManager.createCountType(ERROR_COUNT_C301_fromE01);
        countManager.createCountType(ERROR_COUNT_C301FAIL_fromE01);
        countManager.createCountType(ERROR_COUNT_C306_fromE01);
        
        countManager.createCountType(INPUT_COUNT_D01_toC201);
        countManager.createCountType(OUTPUT_COUNT_C201_fromD01);
        countManager.createCountType(ERROR_COUNT_C201_fromD01);
        
        countManager.createCountType(INPUT_COUNT_C01_toC105);
        countManager.createCountType(OUTPUT_COUNT_C105_fromC01);
        countManager.createCountType(ERROR_COUNT_C105_fromC01);
        
        countManager.createCountType(INPUT_COUNT_C07_toC104);
        countManager.createCountType(OUTPUT_COUNT_C104_fromC07);
        countManager.createCountType(ERROR_COUNT_C104_fromC07);
        
        countManager.createCountType(INPUT_COUNT_E05_toC302);
        countManager.createCountType(OUTPUT_COUNT_C302_fromE05);
        countManager.createCountType(ERROR_COUNT_C302_fromE05);
        
        countManager.createCountType(INPUT_COUNT_E06_toC303);
        countManager.createCountType(OUTPUT_COUNT_C303_fromE06);
        countManager.createCountType(ERROR_COUNT_C303_fromE06);
        
        countManager.createCountType(INPUT_COUNT_E04_toC305);
        countManager.createCountType(OUTPUT_COUNT_C305_fromE04);
        countManager.createCountType(ERROR_COUNT_C305_fromE04);
        
        countManager.createCountType(INPUT_COUNT_B102_toB201);
        countManager.createCountType(OUTPUT_COUNT_B201_fromB102);
        countManager.createCountType(ERROR_COUNT_B201_fromB102);
        
        countManager.createCountType(INPUT_COUNT_C03_toC102);
        countManager.createCountType(OUTPUT_COUNT_C102_fromC03);
        countManager.createCountType(ERROR_COUNT_C102_fromC03);
        
        countManager.createCountType(INPUT_COUNT_C06_toC103);
        countManager.createCountType(OUTPUT_COUNT_C103_fromC06);
        countManager.createCountType(ERROR_COUNT_C103_fromC06);
        
        countManager.createCountType(INPUT_COUNT_DKO060_toB107);
        countManager.createCountType(OUTPUT_COUNT_B107_fromDKO060);
        countManager.createCountType(ERROR_COUNT_B107_fromDKO060);
        
        countManager.createCountType(INPUT_COUNT_DKO090092_toB106);
        countManager.createCountType(INPUT_COUNT_DKO090060_toB106);
        countManager.createCountType(OUTPUT_COUNT_B106_fromDKO090092);
        countManager.createCountType(OUTPUT_COUNT_B106_fromDKO090060);
        countManager.createCountType(ERROR_COUNT_B106_fromDKO090092);
        countManager.createCountType(ERROR_COUNT_B106_fromDKO090060);
        
        countManager.createCountType(INPUT_COUNT_DKO102_toC206);
        countManager.createCountType(OUTPUT_COUNT_C206_fromDKO102);
        countManager.createCountType(ERROR_COUNT_C206_fromDKO102);
        
        countManager.createCountType(INPUT_COUNT_DKO103_toC207);
        countManager.createCountType(OUTPUT_COUNT_C207_fromDKO103);
        countManager.createCountType(ERROR_COUNT_C207_fromDKO103);
        
        countManager.createCountType(INPUT_COUNT_DKO101_toC208);
        countManager.createCountType(OUTPUT_COUNT_C208_fromDKO101);
        countManager.createCountType(ERROR_COUNT_C208_fromDKO101);
        
        countManager.createCountType(INPUT_COUNT_DKO104_toC209);
        countManager.createCountType(OUTPUT_COUNT_C209_fromDKO104);
        countManager.createCountType(ERROR_COUNT_C209_fromDKO104);
        
        countManager.createCountType(INPUT_COUNT_DKO100_toC205);  
        countManager.createCountType(OUTPUT_COUNT_C205_fromDKO100);
        countManager.createCountType(ERROR_COUNT_C205_fromDKO100);
        
        countManager.createCountType(INPUT_COUNT_E11_toC304);
        countManager.createCountType(OUTPUT_COUNT_C304_fromE11);
        countManager.createCountType(ERROR_COUNT_C304_fromE11);
    }
    
    public void execute(String args[]) throws Exception {

        try {

            EP_Z1Z002 Z002 = new EP_Z1Z002();
          
            try{
                List<DTEPZ002> Z002List = Z002.getSysSetList("EPZ1_0100", "C101", "", "00"); 
                for(DTEPZ002 Z002bo : Z002List){
                    nameMap.put(Z002bo.getVALUE1(), Z002bo.getVALUE2());
                }
                
                if("P".equals(ConfigManager.getProperty("ebaf.ServerType"))){//P->��������
                    idMap.put("8300100", Z002.getSysSetList("EPZ1_0100", "C102P", "8300100", "00").get(0).getVALUE1());
                    idMap.put("8300200", Z002.getSysSetList("EPZ1_0100", "C102P", "8300200", "00").get(0).getVALUE1());
                }else{
                    idMap.put("8300100", Z002.getSysSetList("EPZ1_0100", "C102", "8300100", "00").get(0).getVALUE1());
                    idMap.put("8300200", Z002.getSysSetList("EPZ1_0100", "C102", "8300200", "00").get(0).getVALUE1());
                }
            }catch (DataNotFoundException e) {
                //�L��Ƶ������`
            }

            boolean exeAll = false;
            HashSet paraSet = new HashSet();
            if (args != null && args.length != 0 && args[0].length() > 0) {
                for (String str : args[0].split(",")) {
                    paraSet.add(str);
                    log.fatal(str);
                }
            } else {
                exeAll = true;
            }
            

            
            if (exeAll || paraSet.contains("A")) {
                deleteZ998("","");
            }
            if (exeAll || paraSet.contains("R")) {
                try {
                    queryDS.setField("SYS_CODE", "008");
                    DBUtil.executeUpdate(queryDS, update_sql_Z001, false);
                } catch (ModuleException e) {
                    throw new ModuleException("EPZ1_0100(8)�G" + e);
                }
                
                deleteZ998("DTEPC06","DTEPC103");
                importC103();
            }
            if (exeAll || paraSet.contains("B")) {
                deleteZ998("DTEPC02","DTEPC101");
                deleteZ998("DTEPD05","DTEPC101");
                importC101();// ��insertZ998
            }
            if (exeAll || paraSet.contains("B1")){
                updateC101_FLOW_NO();
            }
            if (exeAll || paraSet.contains("C")) {
                importC202();
                paraSet.add("E");
            }
            if (exeAll || paraSet.contains("D")) {
                importC204();
            }
            if (exeAll || paraSet.contains("E")) {
                importC203();
            }
            if (exeAll || paraSet.contains("H")) {
                deleteZ998("DTEPE01","C301_RCVNO");
                deleteZ998("DTEPE01","C301_PAYNO");
                MultiKeyMap mkm = new MultiKeyMap();
                importEPC301306(mkm);// ��insertZ998//���qZ998�dRCVNO
                importEPC201(mkm);
            }
            if (exeAll || paraSet.contains("F")) {
                deleteZ998("DTEPE07","DTDKG002");
                importDKG002();// ��insertZ998 //C306
            }
            if (exeAll || paraSet.contains("G")) {
                importDKG003();
            }
            if (exeAll || paraSet.contains("I")) {
                importC105();
            }
            if (exeAll || paraSet.contains("J")) {
                importC104();// ���qZ998�dRCVNO
            }
            if (exeAll || paraSet.contains("K")) {
                importC302();
            }
            if (exeAll || paraSet.contains("L")) {
                importC303();
            }
            if (exeAll || paraSet.contains("M")) {
                importC305();// ���qZ998�dTMPNO��PAYNO
            }
            if (exeAll || paraSet.contains("N")) {
                importB107();
            }
            if (exeAll || paraSet.contains("O")) {
                importB106();
            }
            if (exeAll || paraSet.contains("P")) {
                importB201();
            }
            if (exeAll || paraSet.contains("Q")) {
                importC102();
            }
            if (exeAll || paraSet.contains("S")) {
                importC206();
            }
            if (exeAll || paraSet.contains("T")) {
                importC207();
            }
            if (exeAll || paraSet.contains("U")) {
                importC208();
            }
            if (exeAll || paraSet.contains("V")) {
                importC209();
            }
            if (exeAll || paraSet.contains("W")) {
                importC205();
            }
            if (exeAll || paraSet.contains("X")) {
                importC304();//���qZ998�dRCVNO(E01->C301)
            }
        } catch (Exception e) {
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("",e);
        } finally {
            // online call batch
            // zz_x0z004.endBatch(RetMsg);
            // if (RetMsg.getReturnCode() != ReturnCode.OK) {
            // log.fatal("zz_x0z004.endBatch ���~:" + RetMsg.getMsgDesc());
            // }

            // ��ƭp��Ш̻ݨD�@�վ�
            log.fatal(countManager);
            // �g�J��ưO����
            countManager.writeLog();
            // �����Ҧ����s�u
            if (buds_Insert_1 != null)
                buds_Insert_1.close();
            if (bqds_1 != null)
                bqds_1.close();

            printExitCode(getExitCode());
        }
    }

    private void updateC101_FLOW_NO() throws Exception {
//        Integer ser_no = 1;
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C101forUpd);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(update_sql_C101);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                String RCV_NO = STRING.objToStrNoNull(bqds_1.getField("RCV_NO")).trim();
                BigDecimal RCV_YM = new BigDecimal(bqds_1.getField("RCV_YM").toString().trim());
                String OP_STATUS = STRING.objToStrNoNull(bqds_1.getField("OP_STATUS")).trim();
            //    String ACNT_ID = STRING.objToStrNoNull(bqds_1.getField("ACNT_ID"));
                String ACNT_DIV_NO = STRING.objToStrNoNull(bqds_1.getField("ACNT_DIV_NO")).trim();
                String ACNT_ID = idMap.get(ACNT_DIV_NO);
                if(StringUtils.isBlank(ACNT_ID)){
                    if("P".equals(ConfigManager.getProperty("ebaf.ServerType"))){//P->��������
                        ACNT_ID = "F225538209";
                    }else{
                        ACNT_ID = "F28119486B";
                    }
                }
                RZ_N0Z001 Z001 = new RZ_N0Z001();
                if(RCV_YM.compareTo(new BigDecimal("201300"))>=0){
                    String FLOW_NO = Z001.startFlow("EPC1_0002", "�s�W", "", ACNT_ID, ACNT_DIV_NO);
                    
            //        AuthUtil au = new AuthUtil();
            //        UserObject user = au.getUserObjByID(idMap.get(ACNT_DIV_NO));
                    
                    if("20".equals(OP_STATUS)){
                        Z001.assignOPStatus(FLOW_NO, "�w�Ю�","�w�Ю�","20", ACNT_ID, ACNT_DIV_NO);
                    }else if("40".equals(OP_STATUS)){
                        Z001.assignOPStatus(FLOW_NO, "��ʦ�","��ʦ�","40", ACNT_ID, ACNT_DIV_NO);
                    }else if("50".equals(OP_STATUS)){
                        Z001.assignOPStatus(FLOW_NO, "��b�b","��b�b","50", ACNT_ID, ACNT_DIV_NO);
                    }else if("30".equals(OP_STATUS)){
                        Z001.assignOPStatus(FLOW_NO, "�w�X�b","�w�X�b","30", ACNT_ID, ACNT_DIV_NO);
                    }
                    buds_Insert_1.setField("FLOW_NO", FLOW_NO);
                    buds_Insert_1.setField("RCV_NO", RCV_NO);
                    buds_Insert_1.addBatch();
                }
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(14)�G" + errObject_1[i][2]);

                Object RCV_NO = errMap.get("RCV_NO");

                errorLog.addErrorLog("update DTEPC101 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO="
                        + RCV_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }
    
    
    private void importC304() throws ModuleException {
        try {
            deleteC304();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            E11toC304();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC304() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C304);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C304_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("EXT_NO", STRING.objToStrNoNull(bqds_1.getField("EXT_NO")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object EXT_NO = errMap.get("EXT_NO");

                errorLog.addErrorLog("DELETE DTEPC304 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "EXT_NO="
                        + EXT_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void E11toC304() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_E11toC304);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_E11_toC304, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C304);

        // int serno=1;
        String oldSWP_YEAR = null;
        EP_Z0Z001 z001 = new EP_Z0Z001();
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                String oriSWP_YEAR = bqds_1.getField("SWP_YEAR").toString().trim();
                if (oldSWP_YEAR == null || !oldSWP_YEAR.equals(oriSWP_YEAR)) {
                    try {
                        z001.updateSER_NO("00", "023", oriSWP_YEAR, "1", "0");
                    } catch (Exception e) {
                        log.fatal("C304����, ��s�y�����ɥ���:  '00', '035', " + oriSWP_YEAR + ", 3");
                    }
                }
                int SER_NO = z001.createNextNumber("00", "023", oriSWP_YEAR, "1");
                setDTEPC304_Fields(bqds_1, SER_NO);
                buds_Insert_1.addBatch();
                oldSWP_YEAR = oriSWP_YEAR;
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C304_fromE11, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object EXT_NO = errMap.get("EXT_NO");

                errorLog.addErrorLog("insert DTEPC304 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "EXT_NO="
                        + EXT_NO + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C304_fromE11, errorCount);

        } // for loop end

    }

    private void setDTEPC304_Fields(BatchQueryDataSet bqds, int serno) throws DBException, ModuleException {
        String[] C203col = { "SUB_CPY_ID", "PAY_KIND","CRT_NO","CUS_NO","ID","CUS_NAME","BLD_CD",
                "PAY_TYPE","SWP_KD","SWP_DATE","SWP_AMT","S_ACNT_DATE" };

        String oriSWP_YEAR = bqds_1.getField("SWP_YEAR").toString().trim();
        String SUB_CPY_ID = (String) (bqds.getField("SUB_CPY_ID"));
        sb.append(SUB_CPY_ID).append(oriSWP_YEAR).append(STRING.fillZero("" + serno, 4));

        String EXT_NO = sb.toString();
        sb.setLength(0);
        buds_Insert_1.setField("EXT_NO", EXT_NO);
        
        
        String RCV_YM_Str = ObjectUtils.toString(bqds.getField("RCV_YM"), "0").trim();
        BigDecimal RCV_YM = new BigDecimal(RCV_YM_Str).add(BD1911);
        String PAY_KIND = ObjectUtils.toString(bqds.getField("PAY_KIND"), "");
        
        sb.append(RCV_YM_Str).append("@").append(PAY_KIND).append("@").append(bqds.getField("CRT_NO"))
        .append("@").append(bqds.getField("CUS_NO")).append("@").append(bqds.getField("OLD_RCV_NO"));
        String OLD_KEY = sb.toString();
        sb.setLength(0);
        
        String RCV_NO = getNEW_KEY("DTEPE01", "C301_RCVNO", OLD_KEY, query_sql_Z998_2);
        
        if (RCV_NO == null || RCV_NO.trim().equals("")) {
            int SER_NO = new EP_Z0Z001().createNextNumber("00", "023", "" + RCV_YM.intValue(), "ERROR");
            RCV_NO = "00" + RCV_YM.intValue() + "E" + STRING.fillZero("" + SER_NO, 4);
        }
        
        
        String PAY_NO = getNEW_KEY("DTEPE01", "C301_PAYNO", OLD_KEY, query_sql_Z998_2);

        buds_Insert_1.setField("RCV_NO", RCV_NO);
        buds_Insert_1.setField("PAY_NO", PAY_NO);
        
        
        buds_Insert_1.setField("RCV_YM", RCV_YM);
        
        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

        String S_SLPSET_NO = ObjectUtils.toString(bqds.getField("S_SLPSET_NO"), "0").trim();
        buds_Insert_1.setField("S_SLPSET_NO", S_SLPSET_NO);
        
    }
    
    
    
    private void importC205() throws ModuleException {
        try {
            deleteC205();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            DKO100toC205();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC205() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C205);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C205_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {
            while (bqds_1.next()) {
                buds_Insert_1.setField("SUB_CPY_ID", STRING.objToStrNoNull(bqds_1.getField("SUB_CPY_ID")));
                buds_Insert_1.setField("INV_NO", STRING.objToStrNoNull(bqds_1.getField("INV_NO")));
                buds_Insert_1.setField("INPUT_DATE", STRING.objToStrNoNull(bqds_1.getField("INPUT_DATE")));
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object SUB_CPY_ID = errMap.get("SUB_CPY_ID");
                Object INV_NO = errMap.get("INV_NO");
                Object INPUT_DATE = errMap.get("INPUT_DATE");

                errorLog.addErrorLog("DELETE DTEPC205 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                        + " SUB_CPY_ID=" + SUB_CPY_ID + "; INV_NO=" + INV_NO + "; INPUT_DATE=" + INPUT_DATE + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void DKO100toC205() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_DK");
        searchAndRetrieve(bqds_1, query_sql_DKO100toC205);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_DKO100_toC205, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C205);
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC205_Fields(bqds_1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C205_fromDKO100, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object SUB_CPY_ID = errMap.get("SUB_CPY_ID");
                Object INV_NO = errMap.get("INV_NO");
                Object INPUT_DATE = errMap.get("INPUT_DATE");

                errorLog.addErrorLog("insert DTEPC205 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                        + " SUB_CPY_ID=" + SUB_CPY_ID + "; INV_NO=" + INV_NO + "; INPUT_DATE=" + INPUT_DATE + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C205_fromDKO100, errorCount);

        } // for loop end
    }

    private void setDTEPC205_Fields(BatchQueryDataSet bqds) throws DBException, ModuleException {

        String[] C203col = { "SUB_CPY_ID", "CRT_NO", "CUS_NO", "PAY_KIND", "INV_NO", "INV_CD", "PAY_S_DATE", "PAY_E_DATE", "DIV_NO",
                "SLIP_DATE", "INV_AMT", "SAL_AMT", "TAX_AMT", "TAX_TYPE", "RJT_AMT", "PRE_PAY_AMT", "CHK_TYPE", "RSN_CODE", "INPUT_DATE",
                "OPR_DATE" };

        String[] RCV_YMarr = ObjectUtils.toString(bqds.getField("PAY_S_DATE")).split("-");

        if (RCV_YMarr != null && RCV_YMarr.length > 0) {
            BigDecimal RCV_YM = new BigDecimal(RCV_YMarr[0] + RCV_YMarr[1]);
            buds_Insert_1.setField("RCV_YM", RCV_YM);
        }

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

    }

    private void importC209() throws ModuleException {
        try {
            deleteC209();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            DKO104toC209();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC209() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C209);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C209_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {
            while (bqds_1.next()) {
                buds_Insert_1.setField("CRT_NO", STRING.objToStrNoNull(bqds_1.getField("CRT_NO")));
                buds_Insert_1.setField("CUS_NO", STRING.objToStrNoNull(bqds_1.getField("CUS_NO")));
                buds_Insert_1.setField("RCV_YM", STRING.objToStrNoNull(bqds_1.getField("RCV_YM")));
                buds_Insert_1.setField("PAY_KIND", STRING.objToStrNoNull(bqds_1.getField("PAY_KIND")));
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object RCV_YM = errMap.get("RCV_YM");
                Object PAY_KIND = errMap.get("PAY_KIND");

                errorLog.addErrorLog("DELETE DTEPC209 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + " CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "; RCV_YM=" + RCV_YM + "; PAY_KIND=" + PAY_KIND + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void DKO104toC209() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_DK");
        searchAndRetrieve(bqds_1, query_sql_DKO104toC209);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_DKO104_toC209, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C209);
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC209_Fields(bqds_1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C209_fromDKO104, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object RCV_YM = errMap.get("RCV_YM");
                Object PAY_KIND = errMap.get("PAY_KIND");

                errorLog.addErrorLog("insert DTEPC209 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + " CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "; RCV_YM=" + RCV_YM + "; PAY_KIND=" + PAY_KIND + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C209_fromDKO104, errorCount);

        } // for loop end
    }

    private void setDTEPC209_Fields(BatchQueryDataSet bqds) throws DBException, ModuleException {

        String[] C203col = { "CRT_NO", "CUS_NO", "PAY_KIND", "MEMO", "OPR_DATE" };

        BigDecimal RCV_YM = new BigDecimal(ObjectUtils.toString(bqds.getField("RCV_YM"), "0").trim()).add(BD1911);

        buds_Insert_1.setField("RCV_YM", RCV_YM);

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

    }

    private void importC208() throws ModuleException {
        try {
            deleteC208();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            DKO101toC208();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC208() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C208);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C208_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {
            while (bqds_1.next()) {
                buds_Insert_1.setField("CRT_NO", STRING.objToStrNoNull(bqds_1.getField("CRT_NO")));
                buds_Insert_1.setField("CUS_NO", STRING.objToStrNoNull(bqds_1.getField("CUS_NO")));
                buds_Insert_1.setField("RCV_YM", STRING.objToStrNoNull(bqds_1.getField("RCV_YM")));
                buds_Insert_1.setField("PAY_YYYYMM", STRING.objToStrNoNull(bqds_1.getField("PAY_YYYYMM")));
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object RCV_YM = errMap.get("RCV_YM");
                Object PAY_YYYYMM = errMap.get("PAY_YYYYMM");

                errorLog.addErrorLog("DELETE DTEPC208 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + " CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "; RCV_YM=" + RCV_YM + "; PAY_YYYYMM=" + PAY_YYYYMM + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void DKO101toC208() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_DK");
        searchAndRetrieve(bqds_1, query_sql_DKO101toC208);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_DKO101_toC208, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C208);
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC208_Fields(bqds_1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C208_fromDKO101, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object RCV_YM = errMap.get("RCV_YM");
                Object PAY_YYYYMM = errMap.get("PAY_YYYYMM");

                errorLog.addErrorLog("insert DTEPC208 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + " CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "; RCV_YM=" + RCV_YM + "; PAY_YYYYMM=" + PAY_YYYYMM + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C208_fromDKO101, errorCount);

        } // for loop end
    }

    private void setDTEPC208_Fields(BatchQueryDataSet bqds) throws DBException, ModuleException {
        String[] C203col = { "CRT_NO", "CUS_NO", "PAY_YYYYMM", "CHK_TYPE" };

        BigDecimal RCV_YM = new BigDecimal(ObjectUtils.toString(bqds.getField("RCV_YM"), "0").trim()).add(BD1911);

        buds_Insert_1.setField("RCV_YM", RCV_YM);

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

    }

    private void importC207() throws ModuleException {
        try {
            deleteC207();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            DKO103toC207();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC207() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C207);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C207_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {
            while (bqds_1.next()) {
                buds_Insert_1.setField("SUB_CPY_ID", STRING.objToStrNoNull(bqds_1.getField("SUB_CPY_ID")));
                buds_Insert_1.setField("RCV_YM", STRING.objToStrNoNull(bqds_1.getField("RCV_YM")));
                buds_Insert_1.setField("CRT_NO", STRING.objToStrNoNull(bqds_1.getField("CRT_NO")));
                buds_Insert_1.setField("CUS_NO", STRING.objToStrNoNull(bqds_1.getField("CUS_NO")));
                buds_Insert_1.setField("PAY_KIND", STRING.objToStrNoNull(bqds_1.getField("PAY_KIND")));
                buds_Insert_1.setField("SET_NO", STRING.objToStrNoNull(bqds_1.getField("SET_NO")));
                buds_Insert_1.setField("SER_NO", STRING.objToStrNoNull(bqds_1.getField("SER_NO")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object SUB_CPY_ID = errMap.get("SUB_CPY_ID");
                Object RCV_YM = errMap.get("RCV_YM");
                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object PAY_KIND = errMap.get("PAY_KIND");
                Object SET_NO = errMap.get("SET_NO");
                Object SER_NO = errMap.get("SER_NO");

                errorLog.addErrorLog("DELETE DTEPC207 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                        + "SUB_CPY_ID=" + SUB_CPY_ID + "; RCV_YM=" + RCV_YM + "; CRT_NO=" + CRT_NO + "; CUS_NO=" + CUS_NO + "; PAY_KIND="
                        + PAY_KIND + "; SET_NO=" + SET_NO + "; SER_NO=" + SER_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void DKO103toC207() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_DK");
        searchAndRetrieve(bqds_1, query_sql_DKO103toC207);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_DKO103_toC207, inputCount); //�]�w��X���
        
        
        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C207);
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC207_Fields(bqds_1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C207_fromDKO103, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object SUB_CPY_ID = errMap.get("SUB_CPY_ID");
                Object RCV_YM = errMap.get("RCV_YM");
                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object PAY_KIND = errMap.get("PAY_KIND");
                Object SET_NO = errMap.get("SET_NO");
                Object SER_NO = errMap.get("SER_NO");

                errorLog.addErrorLog("insert DTEPC207 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                        + "SUB_CPY_ID=" + SUB_CPY_ID + "; RCV_YM=" + RCV_YM + "; CRT_NO=" + CRT_NO + "; CUS_NO=" + CUS_NO + "; PAY_KIND="
                        + PAY_KIND + "; SET_NO=" + SET_NO + "; SER_NO=" + SER_NO + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C207_fromDKO103, errorCount);

        } // for loop end
    }

    private void setDTEPC207_Fields(BatchQueryDataSet bqds) throws DBException, ModuleException {
        String[] C203col = { "SUB_CPY_ID", "CRT_NO", "CUS_NO", "PAY_KIND", "SET_NO", "SER_NO", "INV_NO", "INV_CD", "PAY_S_DATE",
                "PAY_E_DATE", "DIV_NO", "SLIP_DATE", "INV_AMT", "SAL_AMT", "TAX_TYPE", "TAX_AMT", "RJT_AMT", "REC_AMT", "PRE_PAY_AMT" };

        BigDecimal RCV_YM = new BigDecimal(ObjectUtils.toString(bqds.getField("RCV_YM"), "0").trim()).add(BD1911);

        buds_Insert_1.setField("RCV_YM", RCV_YM);

        for (String colkey : C203col) {
            if(colkey.equals("INV_CD")){
                String INV_CD = STRING.objToStrNoNull(bqds.getField("INV_CD"));
                buds_Insert_1.setField(colkey, INV_CD.toUpperCase());
            }else{
                buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
            }
        }

    }

    private void importC206() throws ModuleException {
        try {
            deleteC206();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            DKO102toC206();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC206() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C206);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C206_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {
            while (bqds_1.next()) {
                buds_Insert_1.setField("SUB_CPY_ID", STRING.objToStrNoNull(bqds_1.getField("SUB_CPY_ID")));
                buds_Insert_1.setField("RCV_YM", STRING.objToStrNoNull(bqds_1.getField("RCV_YM")));
                buds_Insert_1.setField("CRT_NO", STRING.objToStrNoNull(bqds_1.getField("CRT_NO")));
                buds_Insert_1.setField("CUS_NO", STRING.objToStrNoNull(bqds_1.getField("CUS_NO")));
                buds_Insert_1.setField("PAY_KIND", STRING.objToStrNoNull(bqds_1.getField("PAY_KIND")));
                buds_Insert_1.setField("SET_NO", STRING.objToStrNoNull(bqds_1.getField("SET_NO")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object SUB_CPY_ID = errMap.get("SUB_CPY_ID");
                Object RCV_YM = errMap.get("RCV_YM");
                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object PAY_KIND = errMap.get("PAY_KIND");
                Object SET_NO = errMap.get("SET_NO");

                errorLog.addErrorLog("DELETE DTEPC206 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                        + "SUB_CPY_ID=" + SUB_CPY_ID + "; RCV_YM=" + RCV_YM + "; CRT_NO=" + CRT_NO + "; CUS_NO=" + CUS_NO + "; PAY_KIND="
                        + PAY_KIND + "; SET_NO=" + SET_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void DKO102toC206() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_DK");
        searchAndRetrieve(bqds_1, query_sql_DKO102toC206);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_DKO102_toC206, inputCount); //�]�w��X���
        
        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C206);
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC206_Fields(bqds_1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C206_fromDKO102, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object SUB_CPY_ID = errMap.get("SUB_CPY_ID");
                Object RCV_YM = errMap.get("RCV_YM");
                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object PAY_KIND = errMap.get("PAY_KIND");
                Object SET_NO = errMap.get("SET_NO");

                errorLog.addErrorLog("insert DTEPC206 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                        + "SUB_CPY_ID=" + SUB_CPY_ID + "; RCV_YM=" + RCV_YM + "; CRT_NO=" + CRT_NO + "; CUS_NO=" + CUS_NO + "; PAY_KIND="
                        + PAY_KIND + "; SET_NO=" + SET_NO + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C206_fromDKO102, errorCount);

        } // for loop end
    }

    private void setDTEPC206_Fields(BatchQueryDataSet bqds) throws DBException, ModuleException {
        String[] C203col = { "SUB_CPY_ID", "CRT_NO", "CUS_NO", "PAY_KIND", "SET_NO", "STS", "ACNT_DATE", "ACNT_DIV_NO", "SLIP_LOT_NO",
                "SLIP_SET_NO", "TRN_SER_NO", "LINE_REC_AMT", "TOT_REC_AMT", "OPR_ID", "OPR_NAME", "OPR_DATE" };

        BigDecimal RCV_YM = new BigDecimal(ObjectUtils.toString(bqds.getField("RCV_YM"), "0").trim()).add(BD1911);

        buds_Insert_1.setField("RCV_YM", RCV_YM);

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

    }

    private void importC103() throws ModuleException {
        try {
            deleteC103();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            C06toC103();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC103() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C103);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C103_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("RCV_NO", STRING.objToStrNoNull(bqds_1.getField("RCV_NO")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object RCV_NO = errMap.get("RCV_NO");

                errorLog.addErrorLog("DELETE DTEPC103 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO="
                        + RCV_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void C06toC103() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C06toC103);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_C06_toC103, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C103);

        buds_Insert_2.clearBatch();
        buds_Insert_2.setConnName("DS_EP");
        buds_Insert_2.preparedBatch(insert_sql_Z998);
        
        // int serno=1;
        Integer oldRCV_YM = null;
        EP_Z0Z001 z001 = new EP_Z0Z001();
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                String oriRCV_YM = bqds_1.getField("RCV_YM").toString().trim();
                BigDecimal RCV_YM = new BigDecimal(oriRCV_YM).add(BD1911);
                int oldrcvym = RCV_YM.intValue();
                if(oldrcvym%100!=6 && oldrcvym%100!=12){
                    oldrcvym++;
                }  
                // if(oldRCV_YM!=null && 0!=oldRCV_YM.compareTo(RCV_YM)){
                if (oldRCV_YM == null || oldRCV_YM!=oldrcvym) {
                    try {
                        // new EP_Z0Z001().updateSER_NO("00", "003", "C06C103",
                        // oriRCV_YM, ""+(serno-1));
                        z001.updateSER_NO("00", "008", "" + oldrcvym, "3", "0");
                    } catch (Exception e) {
                        log.fatal("C103����, ��s�y�����ɥ���:  '00', '008', " + RCV_YM.intValue() + ", 3");
                    }
                    // serno=1;
                }
                int SER_NO = z001.createNextNumber("00", "008", "" + oldrcvym, "3");
                setDTEPC103_Fields(bqds_1, SER_NO);// serno);
                buds_Insert_1.addBatch();
                // serno++;
                oldRCV_YM = oldrcvym;
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C103_fromC06, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object RCV_NO = errMap.get("RCV_NO");

                errorLog.addErrorLog("insert DTEPC103 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO="
                        + RCV_NO + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C103_fromC06, errorCount);

            int buds_INSERT_2_Ret[] = buds_Insert_2.executeBatch();

            Object errObject_2[][] = errorHandler.getErrorArray(buds_Insert_2.getBatchUpdateErrorArray(), buds_INSERT_2_Ret, buds_Insert_2
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_2.length; i++) {
                Map errMap = (Map) errObject_2[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_2[i][2]);

                Object OLD_TABLE = errMap.get("OLD_TABLE");
                Object NEW_TABLE = errMap.get("NEW_TABLE");
                Object OLD_KEY = errMap.get("OLD_KEY");

                errorLog.addErrorLog("INSERT DTEPZ998 " + errObject_2[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                        + "OLD_TABLE=" + OLD_TABLE + "NEW_TABLE=" + NEW_TABLE + "OLD_KEY=" + OLD_KEY + "]:" + errObject_2[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }
            
        } // for loop end

    }

    private void setDTEPC103_Fields(BatchQueryDataSet bqds, int serno) throws DBException, ModuleException {
        String[] C203col = { "SUB_CPY_ID", "BLD_CD", "CRT_NO", "CUS_NO", "SAL_AMT", "TAX_AMT", "RCV_AMT", "ID", "CUS_NAME", "DEL_CD",
                "TRN_KIND", "FLOW_NO", "OP_STATUS" };

        BigDecimal RCV_YM = new BigDecimal(bqds.getField("RCV_YM").toString().trim()).add(BD1911);
        
        int oldrcvym = RCV_YM.intValue();
        if(oldrcvym%100!=6 && oldrcvym%100!=12){
            oldrcvym++;
        }       
        
        String SUB_CPY_ID = (String) (bqds.getField("SUB_CPY_ID"));
        sb.append(SUB_CPY_ID).append(oldrcvym).append("3").append(STRING.fillZero("" + serno, 4));

        String RCV_NO = sb.toString();
        sb.setLength(0);
        buds_Insert_1.setField("RCV_NO", RCV_NO);
        buds_Insert_1.setField("RCV_YM", RCV_YM);
        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }
        buds_Insert_1.setField("LST_PROC_DATE", DATE.getDBTimeStamp());


        String PAY_S_DATE = RCV_YM.intValue()+"";
        PAY_S_DATE = PAY_S_DATE.substring(0,4)+"-"+PAY_S_DATE.substring(4,6)+"-01";
        
        sb.append(oldrcvym).append("@")
            .append(STRING.objToStrNoNull(bqds.getField("BLD_CD")).trim()).append("@")
            .append(STRING.objToStrNoNull(bqds.getField("CRT_NO")).trim()).append("@")
            .append(STRING.objToStrNoNull(bqds.getField("CUS_NO")).trim()).append("@")
            .append(PAY_S_DATE);
        String OLD_KEY = sb.toString();
        sb.setLength(0);
        buds_Insert_2.setField("OLD_TABLE", "DTEPC06");
        buds_Insert_2.setField("NEW_TABLE", "DTEPC103");
        buds_Insert_2.setField("OLD_KEY", OLD_KEY);
        buds_Insert_2.setField("NEW_KEY", RCV_NO);
        buds_Insert_2.addBatch();
        
        
        String SAL_AMT_str = STRING.objToStrNoNull(bqds.getField("SAL_AMT"));
        if(NumberUtils.isNumber(SAL_AMT_str)){
            SAL_AMT_str = new BigDecimal(SAL_AMT_str).intValue()+"";
            
            sb.append(oldrcvym).append("@")
                .append(STRING.objToStrNoNull(bqds.getField("BLD_CD")).trim()).append("@")
                .append(STRING.objToStrNoNull(bqds.getField("CRT_NO")).trim()).append("@")
                .append(STRING.objToStrNoNull(bqds.getField("CUS_NO")).trim()).append("@")
                .append(PAY_S_DATE).append("@")
                .append(SAL_AMT_str);
            OLD_KEY = sb.toString();
            sb.setLength(0);
            buds_Insert_2.setField("OLD_TABLE", "DTEPC06");
            buds_Insert_2.setField("NEW_TABLE", "DTEPC103");
            buds_Insert_2.setField("OLD_KEY", OLD_KEY);
            buds_Insert_2.setField("NEW_KEY", RCV_NO);
            buds_Insert_2.addBatch();
        
        }

    }

    private void importC102() throws ModuleException {
        try {
            deleteC102();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            C03toC102();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC102() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C102);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C102_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("CRT_NO", STRING.objToStrNoNull(bqds_1.getField("CRT_NO")));
                buds_Insert_1.setField("CUS_NO", STRING.objToStrNoNull(bqds_1.getField("CUS_NO")));
                buds_Insert_1.setField("ADJ_DATE", STRING.objToStrNoNull(bqds_1.getField("ADJ_DATE")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object ADJ_DATE = errMap.get("ADJ_DATE");

                errorLog.addErrorLog("DELETE DTEPC102 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "; ADJ_DATE=" + ADJ_DATE + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void C03toC102() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C03toC102);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_C03_toC102, inputCount); //�]�w��X���
        
        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C102);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC102_Fields(bqds_1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C102_fromC03, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object ADJ_DATE = errMap.get("ADJ_DATE");

                errorLog.addErrorLog("insert DTEPC102 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "; ADJ_DATE=" + ADJ_DATE + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C102_fromC03, errorCount);

        } // for loop end
    }

    private void setDTEPC102_Fields(BatchQueryDataSet bqds) throws DBException, ModuleException {
        String[] C203col = { "CRT_NO", "CUS_NO", "ADJ_DATE", "SUB_CPY_ID", "BLD_CD", "ART_AMT", "APM_AMT", "ADJ_UNIT_NUM", "ADJ_UNIT",
                "ADJ_E_DATE", "ADD_AMT", "INPUT_ID", "INPUT_NAME", "INPUT_DATE", "RNT_S_DATE", "RNT_E_DATE", "ADJ_TYPE", "ADJ_PM",
                "RNT_AMT", "PMS_AMT", "ID", "CUS_NAME", "DEL_CD", "TRN_KIND", "FLOW_NO", "OP_STATUS" };

        BigDecimal ADJ_YM = new BigDecimal(ObjectUtils.toString(bqds.getField("ADJ_YM"), "0").trim()).add(BD1911);
        buds_Insert_1.setField("ADJ_YM", ADJ_YM);
        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }
        
        String OP_STATUS = (String)bqds.getField("OP_STATUS");
        //String INPUT_ID = (String)bqds.getField("INPUT_ID");
        String DIV_NO = (String)bqds.getField("DIV_NO");
        if("0".equals(OP_STATUS)){
            String FLOW_NO = new RZ_N0Z001().startFlow("EPC1_0001", "�s�W", "", idMap.get(DIV_NO), DIV_NO);
            buds_Insert_1.setField("FLOW_NO", FLOW_NO);
        }
        
        buds_Insert_1.setField("FROM_TYPE", "1");
        buds_Insert_1.setField("LST_PROC_DATE", DATE.getDBTimeStamp());

    }

    private void importB201() throws ModuleException {
        try {
            deleteB201();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            B102toB201();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteB201() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_B201);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_B201_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("CUS_ID", STRING.objToStrNoNull(bqds_1.getField("CUS_ID")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object CUS_ID = errMap.get("CUS_ID");

                errorLog.addErrorLog("DELETE DTEPB201 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CUS_ID="
                        + CUS_ID + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void B102toB201() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_B102toB201);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_B102_toB201, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_B201);

        int serno = 1;
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPB201_Fields(bqds_1, serno);
                buds_Insert_1.addBatch();
                serno++;
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_B201_fromB102, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object CUS_ID = errMap.get("CUS_ID");

                errorLog.addErrorLog("insert DTEPB201 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CUS_ID="
                        + CUS_ID + "]:" + errObject_1[i][2]);

            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_B201_fromB102, errorCount);

        } // for loop end
        try {
            new EP_Z0Z001().updateSER_NO("00", "003", "CUS_ID", "CUS_ID", "" + (serno - 1));
        } catch (Exception e) {
            log.fatal("B201����, ��s�y�����ɥ���:  '00', '003', 'CUS_ID', 'CUS_ID', " + (serno - 1));
        }
    }

    private void setDTEPB201_Fields(BatchQueryDataSet bqds, int serno) throws DBException, ModuleException {
        String[] C203col = { "CUS_NAME", "ID", "JOB_TYPE", "BOSS_NAME", "COMP_ZIP_CODE", "COMP_ADDR", "CONT_NAME", "CONT_MOBIL_NO",
                "TEL_AREA", "TEL", "TEL_EXT", "CONT_ZIP_CODE", "CONT_ADDR", "MEMO", "TAX_FREE_CD", "CUS_EMAIL", "SUB_CPY_ID", "CHG_DATE",
                "CHG_DIV_NO", "CHG_ID", "CHG_NAME" };

        String ID = ObjectUtils.toString(bqds.getField("ID"), "").trim();
        String ID_TYPE = "";
        if (ID.length() == 8) {
            ID_TYPE = "1";
        } else if (ID.length() > 8) {
            ID_TYPE = "2";
        }else{
            ID_TYPE = "4";
        }
            
        buds_Insert_1.setField("CUS_ID", "00" + STRING.fillZero("" + serno, 8));
        buds_Insert_1.setField("ID_TYPE", ID_TYPE);
        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

    }

    private void importB106() throws ModuleException {
        try {
            deleteB106();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            DKO090toB106();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteB106() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_B106);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_B106_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("SUB_CPY_ID", STRING.objToStrNoNull(bqds_1.getField("SUB_CPY_ID")));
                buds_Insert_1.setField("CRT_NO", STRING.objToStrNoNull(bqds_1.getField("CRT_NO")));
                buds_Insert_1.setField("CUS_NO", STRING.objToStrNoNull(bqds_1.getField("CUS_NO")));
                buds_Insert_1.setField("REC_YYMM", STRING.objToStrNoNull(bqds_1.getField("REC_YYMM")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object REC_YYMM = errMap.get("REC_YYMM");

                errorLog.addErrorLog("DELETE DTEPB106 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "; REC_YYMM=" + REC_YYMM + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void DKO090toB106() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_DK");
        searchAndRetrieve(bqds_1, query_sql_DKO090toB106);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_DKO090092_toB106, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_B106);
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPB106_Fields(bqds_1, 1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_B106_fromDKO090092, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object REC_YYMM = errMap.get("REC_YYMM");

                errorLog.addErrorLog("insert DTEPB106 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "; REC_YYMM=" + REC_YYMM + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_B106_fromDKO090092, errorCount);

        } // for loop end

        bqds_1.clear();
        bqds_1.setConnName("DS_DK");
        searchAndRetrieve(bqds_1, query_sql_DKO090toB106_2);
        int inputCount2 = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_DKO090060_toB106, inputCount2); //�]�w��X���
        
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPB106_Fields(bqds_1, 2);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_B106_fromDKO090060, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");
                Object REC_YYMM = errMap.get("REC_YYMM");

                errorLog.addErrorLog("insert DTEPB106 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "; REC_YYMM=" + REC_YYMM + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_B106_fromDKO090060, errorCount);

        } // for loop end
    }

    private void setDTEPB106_Fields(BatchQueryDataSet bqds, int flag) throws DBException, ModuleException {
        String[] C203col = { "SUB_CPY_ID", "CRT_NO", "CUS_NO", "ADJ_UNIT_NUM", "ADJ_UNIT", "EXP_DAY", "REC_AMT", "CAL_REC_AMT",
                "TOT_RNT_DAY", "RNT_STR_DATE", "RNT_END_DATE", "ADJ_CNT", "ADJ_STR_DATE", "AFT_ADJ_NORNT", "CHG_DATE", "CHG_DIV_NO",
                "CHG_ID", "CHG_NAME", "APLY_NO", "TRN_KIND" };

        BigDecimal REC_YYMM = new BigDecimal(ObjectUtils.toString(bqds.getField("REC_YYMM"), "0").trim()).add(BD1911);

        buds_Insert_1.setField("REC_YYMM", REC_YYMM);

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

        if (flag == 2) {
            buds_Insert_1.setField("ADJ_STR_DATE", null);
        }
    }

    private void importB107() throws ModuleException {
        try {
            deleteB107();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            DKO060toB107();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteB107() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_B107);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_B107_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("SUB_CPY_ID", STRING.objToStrNoNull(bqds_1.getField("SUB_CPY_ID")));
                buds_Insert_1.setField("CRT_NO", STRING.objToStrNoNull(bqds_1.getField("CRT_NO")));
                buds_Insert_1.setField("CUS_NO", STRING.objToStrNoNull(bqds_1.getField("CUS_NO")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");

                errorLog.addErrorLog("DELETE DTEPB107 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void DKO060toB107() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_DK");
        searchAndRetrieve(bqds_1, query_sql_DKO060toB107);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_DKO060_toB107, inputCount); //�]�w��X���
        
        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_B107);
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPB107_Fields(bqds_1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_B107_fromDKO060, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object CRT_NO = errMap.get("CRT_NO");
                Object CUS_NO = errMap.get("CUS_NO");

                errorLog.addErrorLog("insert DTEPB107 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CRT_NO="
                        + CRT_NO + "; CUS_NO=" + CUS_NO + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_B107_fromDKO060, errorCount);


        } // for loop end
    }

    private void setDTEPB107_Fields(BatchQueryDataSet bqds) throws DBException, ModuleException {
        String[] C203col = { "SUB_CPY_ID", "CRT_NO", "CUS_NO", "CUS_NAME", "ID", "RNT_STR_DATE", "RNT_END_DATE", "ORG_RNT_AMT", "MON_BRK",
                "PERIOD_CNT", "TOT_RENT_AMT", "LIN_RENT_AMT", "LAST_RENT_AMT", "REC_AMT", "ADD_REC_AMT", "REAL_REC_AMT", "IS_CFM",
                "CHG_DATE", "CHG_DIV_NO", "CHG_ID", "CHG_NAME", "APLY_NO", "TRN_KIND" };

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

        BigDecimal LAST_REC_YYMM = new BigDecimal(ObjectUtils.toString(bqds.getField("LAST_REC_YYMM"), "0").trim()).add(BD1911);
        BigDecimal REV_YYMM = new BigDecimal(ObjectUtils.toString(bqds.getField("REV_YYMM"), "0").trim()).add(BD1911);
        buds_Insert_1.setField("LAST_REC_YYMM", LAST_REC_YYMM);
        buds_Insert_1.setField("REV_YYMM", REV_YYMM);
        buds_Insert_1.setField("MON_BRK_EDATE", null);

    }

    private void deleteZ998(String OLD_TABLEstr, String NEW_TABLEstr) throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        if(StringUtils.isNotBlank(OLD_TABLEstr)){
            bqds_1.setField("OLD_TABLE", OLD_TABLEstr);
        }
        if(StringUtils.isNotBlank(NEW_TABLEstr)){
            bqds_1.setField("NEW_TABLE", NEW_TABLEstr);
        }
        searchAndRetrieve(bqds_1, query_sql_Z998);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_Z998);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("OLD_TABLE", STRING.objToStrNoNull(bqds_1.getField("OLD_TABLE")));
                buds_Insert_1.setField("NEW_TABLE", STRING.objToStrNoNull(bqds_1.getField("NEW_TABLE")));
                buds_Insert_1.setField("OLD_KEY", STRING.objToStrNoNull(bqds_1.getField("OLD_KEY")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object OLD_TABLE = errMap.get("OLD_TABLE");
                Object NEW_TABLE = errMap.get("NEW_TABLE");
                Object OLD_KEY = errMap.get("OLD_KEY");

                errorLog.addErrorLog("DELETE DTEPZ998 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                        + "OLD_TABLE=" + OLD_TABLE + "NEW_TABLE=" + NEW_TABLE + "OLD_KEY=" + OLD_KEY + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void importC305() throws ModuleException {
        try {
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C305, false);
            deleteC305();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            E04toC305();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC305() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C305);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C305_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("CARD_NO", STRING.objToStrNoNull(bqds_1.getField("CARD_NO")));
                buds_Insert_1.setField("RCV_NO", STRING.objToStrNoNull(bqds_1.getField("RCV_NO")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object CARD_NO = errMap.get("CARD_NO");
                Object RCV_NO = errMap.get("RCV_NO");

                errorLog.addErrorLog("DELETE DTEPC305 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CARD_NO="
                        + CARD_NO + "RCV_NO=" + RCV_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void E04toC305() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_E04toC305);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_E04_toC305, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C305);

        int ser_no = 0;
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC305_Fields(bqds_1, ser_no);
                buds_Insert_1.addBatch();
                ser_no++;
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C305_fromE04, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object RCV_NO = errMap.get("RCV_NO");

                errorLog.addErrorLog("INSERT DTEPC104 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO="
                        + RCV_NO + "]:" + errObject_1[i][2]);

            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C305_fromE04, errorCount);

        } // for loop end
    }

    private void setDTEPC305_Fields(BatchQueryDataSet bqds, int ser_no) throws DBException {

        BigDecimal RCV_YM = new BigDecimal(ObjectUtils.toString(bqds.getField("RCV_YM"), "0").trim()).add(BD1911);

        buds_Insert_1.setField("RCV_YM", "" + RCV_YM.intValue());
        buds_Insert_1.setField("RCV_NO", STRING.fillZero("" + ser_no, 13));
        String[] C203col = { "CARD_NO", "PRC_DATE", "ACNT_DATE", "CHK_SET_NO", "COA_DATE", "CRD_DATE", "CHK_KD", "UPD_DATE" };

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

    }

    private void importC303() throws ModuleException {
        try {
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C303, false);
            deleteC303();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.setField("SYS_CODE", "029");
            DBUtil.executeUpdate(queryDS, update_sql_Z001, false);
        } catch (ModuleException e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            E06toC303();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC303() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C303);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C303_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("RMT_NO", STRING.objToStrNoNull(bqds_1.getField("RMT_NO")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object RMT_NO = errMap.get("RMT_NO");

                errorLog.addErrorLog("DELETE DTEPC303 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RMT_NO="
                        + RMT_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void E06toC303() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_E06toC303);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_E06_toC303, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C303);
        int ser_no = 1;
        Map BANK_NOMap = new HashMap();
        BANK_NOMap.put("00189", "0132011");
        BANK_NOMap.put("00707", "0020493");
        BANK_NOMap.put("00979", "0110233");
        BANK_NOMap.put("02789", "0130017");
        BANK_NOMap.put("05390", "0095005");
        BANK_NOMap.put("05899", "0100081");
        BANK_NOMap.put("07001", "0060567");
        BANK_NOMap.put("22800", "0070937");
        BANK_NOMap.put("28088", "0081005");
        BANK_NOMap.put("30956", "0060567");
        BANK_NOMap.put("88857", "7000010");

        Map ACNT_NOMap = new HashMap();
        ACNT_NOMap.put("00189", "0000201010001892");
        ACNT_NOMap.put("00707", "0000049302007076");
        ACNT_NOMap.put("00979", "0023101001009798");
        ACNT_NOMap.put("02789", "0000001010027892");
        ACNT_NOMap.put("05390", "0050050300053900");
        ACNT_NOMap.put("05899", "0000803100058997");
        ACNT_NOMap.put("07001", "0000560705070011");
        ACNT_NOMap.put("22800", "0000009330228000");
        ACNT_NOMap.put("28088", "0000100100280883");
        ACNT_NOMap.put("30956", "0000560717309567");
        ACNT_NOMap.put("88857", "0000000018888575");
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC303_Fields(bqds_1, ser_no, BANK_NOMap, ACNT_NOMap);
                buds_Insert_1.addBatch();
                ser_no++;
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C303_fromE06, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object ACNT_NO = errMap.get("ACNT_NO");

                errorLog.addErrorLog("INSERT DTEPC104 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "ACNT_NO="
                        + ACNT_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void setDTEPC303_Fields(BatchQueryDataSet bqds, int ser_no, Map BANK_NOMap, Map ACNT_NOMap) throws DBException, ModuleException {

        String RMT_DATE = ObjectUtils.toString(bqds.getField("RMT_DATE"), "").replaceAll("-", "");
        String RMT_YM = RMT_DATE.substring(0, 6);

        String SUB_CPY_ID = (String) (bqds.getField("SUB_CPY_ID"));

        int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "025", RMT_DATE, "1");

        //sb.append(SUB_CPY_ID).append(RCV_YM.intValue()).append(PAY_KIND).append
        // (STRING.fillZero("" + ser_no, 4));
        sb.append(SUB_CPY_ID).append(RMT_DATE).append(STRING.fillZero("" + SER_NO, 4));

        String SLIP_SET_NO = ObjectUtils.toString(bqds.getField("CEACTNO"), "0").trim();
        buds_Insert_1.setField("SLIP_SET_NO", SLIP_SET_NO);

        String[] C203col = { "SUB_CPY_ID", "RMT_DATE", "RMT_AMT", "CEPSTCD", "CEMALAM", "INPUT_ID", "TRN_DATE", "TRN_SER_NO", "ACNT_DATE",
                "ACNT_DIV_NO", "SLIP_LOT_NO" ,"SLIP_SET_NO"};

        String key = ObjectUtils.toString(bqds.getField("CEACTNO"), "");

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }
        buds_Insert_1.setField("RMT_SET_NO", "EP" + STRING.fillZero("" + ser_no, 8));
        buds_Insert_1.setField("RMT_NO", sb.toString());
        buds_Insert_1.setField("BANK_NO", MapUtils.getString(BANK_NOMap, key, key));
        buds_Insert_1.setField("ACNT_NO", MapUtils.getString(ACNT_NOMap, key, ""));
        sb.setLength(0);
    }

    private void importC302() throws ModuleException {
        try {
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C302, false);
            deleteC302();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            E05toC302();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC302() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C302);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C302_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("BANK_NO", STRING.objToStrNoNull(bqds_1.getField("BANK_NO")));
                buds_Insert_1.setField("CHK_NO", STRING.objToStrNoNull(bqds_1.getField("CHK_NO")));
                buds_Insert_1.setField("ACNT_NO", STRING.objToStrNoNull(bqds_1.getField("ACNT_NO")));
                buds_Insert_1.setField("CHK_SET_NO", STRING.objToStrNoNull(bqds_1.getField("CHK_SET_NO")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object BANK_NO = errMap.get("BANK_NO");
                Object CHK_NO = errMap.get("CHK_NO");
                Object ACNT_NO = errMap.get("ACNT_NO");
                Object CHK_SET_NO = errMap.get("CHK_SET_NO");

                errorLog.addErrorLog("DELETE DTEPC302 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "BANK_NO="
                        + BANK_NO + ";CHK_NO=" + CHK_NO + ";ACNT_NO=" + ACNT_NO + ";CHK_SET_NO=" + CHK_SET_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void E05toC302() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_E05toC302);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_E05_toC302, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C302);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC302_Fields(bqds_1);
                buds_Insert_1.addBatch();

            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C302_fromE05, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object ACNT_NO = errMap.get("ACNT_NO");

                errorLog.addErrorLog("INSERT DTEPC104 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "ACNT_NO="
                        + ACNT_NO + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C302_fromE05, errorCount);

        } // for loop end
    }

    private void setDTEPC302_Fields(BatchQueryDataSet bqds) throws DBException {

        String SLIP_SET_NO = STRING.objToStrNoNull(bqds.getField("SLIP_SET_NO")).trim();
        if("".equals(SLIP_SET_NO)){
            SLIP_SET_NO = "0";
        }
        buds_Insert_1.setField("SLIP_SET_NO", SLIP_SET_NO);

        String[] C203col = { "BANK_NO", "CHK_NO", "ACNT_NO", "CHK_SET_NO", "SUB_CPY_ID", "CHK_DATE", "CHK_AMT", "INPUT_ID", "INPUT_NAME",
                "TRN_DATE", "TRN_SER_NO", "ACNT_DATE", "ACNT_DIV_NO", "SLIP_LOT_NO", "SLIP_SET_NO" };

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }
    }

    private void importC104() throws ModuleException {
        try {
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C104, false);
            deleteC104();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        log.fatal("FLAG - 1");
        try {
            queryDS.clear();
            C07toC104();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC104() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C104);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C104_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("RCV_NO", STRING.objToStrNoNull(bqds_1.getField("RCV_NO")));
                buds_Insert_1.setField("TRN_YM", STRING.objToStrNoNull(bqds_1.getField("TRN_YM")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object RCV_NO = errMap.get("RCV_NO");

                errorLog.addErrorLog("DELETE DTEPC104 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO="
                        + RCV_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void C07toC104() throws Exception {

        Integer ser_no = 1;
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C07toC104);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_C07_toC104, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C104);
        oldTRN_YM = BigDecimal.ZERO;
        
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                sb.append(STRING.objToStrNoNull(bqds_1.getField("INV_NO")).trim());
                String OLD_KEY = sb.toString();

                sb.setLength(0);
                String RCV_NO_NEW_KEY = getNEW_KEY("DTEPC02", "DTEPC101", OLD_KEY, query_sql_Z998_2);
                if(StringUtils.isBlank(RCV_NO_NEW_KEY)){
                    RCV_NO_NEW_KEY = getNEW_KEY("DTEPD05", "DTEPC101", OLD_KEY, query_sql_Z998_2);
                }
                // if (null == bqds_1.getField("RCV_NO")) {
                if ("" == RCV_NO_NEW_KEY) {
                    BigDecimal newTRN_YM = new BigDecimal(bqds_1.getField("TRN_YM").toString().trim());
                    if (0 != oldTRN_YM.compareTo(newTRN_YM)) {
                        ser_no = 1;
                    }
                    oldTRN_YM = newTRN_YM;
                    setDTEPC104_Fields(bqds_1, ser_no, null);
                    ser_no++;
                } else {
                    setDTEPC104_Fields(bqds_1, null, RCV_NO_NEW_KEY);
                }

                buds_Insert_1.addBatch();

            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C104_fromC07, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object RCV_NO = errMap.get("RCV_NO");

                errorLog.addErrorLog("INSERT DTEPC104 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO="
                        + RCV_NO + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C104_fromC07, errorCount);

        } // for loop end
    }

    private void setDTEPC104_Fields(BatchQueryDataSet bqds, Integer ser_no, String RCV_NO_NEW_KEY) throws DBException {

        String RCV_NO;
        BigDecimal TRN_YM = new BigDecimal(bqds.getField("TRN_YM").toString().trim()).add(BD1911);
        if (null != ser_no) {
            String PAY_KIND = (String) (bqds.getField("PAY_KIND"));
            sb.append("99").append(TRN_YM.intValue()).append(PAY_KIND).append(STRING.fillZero("" + ser_no, 4));
            RCV_NO = sb.toString();
            sb.setLength(0);
        } else {
            RCV_NO = RCV_NO_NEW_KEY;
        }
        buds_Insert_1.setField("RCV_NO", RCV_NO);
        buds_Insert_1.setField("TRN_YM", TRN_YM);
        buds_Insert_1.setField("SLIP_SET_NO", bqds.getField("SLIP_SET_NO").toString().trim());

        String[] C203col = { "PAY_KIND", "CRT_NO", "CUS_NO", "DIV_NO", "ID", "CUS_NAME", "INV_NO", "PASS_DAY", "PRP_S_DATE", "PRP_E_DATE",
                "PRP_AMT", "EXT_DATE", "ACNT_DATE", "ACNT_ID", "ACNT_NAME", "ACNT_DIV_NO", "SUB_CPY_ID", "BLD_CD" };

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }
    }

    private void importC105() throws ModuleException {
        try {
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C105, false);
            deleteC105();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            C01toC105();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC105() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C105);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C105_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("SUB_CPY_ID", STRING.objToStrNoNull(bqds_1.getField("SUB_CPY_ID")));
                buds_Insert_1.setField("EXT_TYPE", STRING.objToStrNoNull(bqds_1.getField("EXT_TYPE")));
                buds_Insert_1.setField("EXT_YM", STRING.objToStrNoNull(bqds_1.getField("EXT_YM")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object EXT_TYPE = errMap.get("EXT_TYPE");
                Object EXT_YM = errMap.get("EXT_YM");

                errorLog.addErrorLog("DELETE DTEPC105 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "EXT_TYPE="
                        + EXT_TYPE + "; EXT_YM=" + EXT_YM + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void C01toC105() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C01toC105);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_C01_toC105, inputCount); //�]�w��X���

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C105);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                if (bqds_1.getField("EXT_YM").toString().startsWith("099")) {
                    continue;
                }

                setDTEPC105_Fields(bqds_1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C105_fromC01, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object EXT_YM = errMap.get("EXT_YM");
                Object EXT_TYPE = errMap.get("EXT_TYPE");

                errorLog.addErrorLog("INSERT DTEPC105 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "EXT_YM="
                        + EXT_YM + "; EXT_TYPE=" + EXT_TYPE + "]:" + errObject_1[i][2]);
            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C105_fromC01, errorCount);

        } // for loop end
    }

    private void setDTEPC105_Fields(BatchQueryDataSet bqds) throws DBException {

        BigDecimal EXT_YM = new BigDecimal(bqds.getField("EXT_YM").toString().trim()).add(BD1911);
        buds_Insert_1.setField("EXT_YM", EXT_YM);
        sb.setLength(0);

        String[] C203col = { "SUB_CPY_ID", "EXT_TYPE", "EXT_DATE", "CNT", "AMT", "CHG_DATE", "CHG_ID", "CHG_NAME" };

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }
    }

    private void importEPC201(MultiKeyMap mkm) throws ModuleException {
        try {
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C201, false);
            deleteC201();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            D01toC201(mkm);
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC201() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C201);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C201_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("INT_NO", STRING.objToStrNoNull(bqds_1.getField("INT_NO")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object INT_NO = errMap.get("INT_NO");

                errorLog.addErrorLog("DELETE DTEPC201 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "INT_NO="
                        + INT_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void D01toC201(MultiKeyMap mkm) throws Exception {
        Integer ser_no = 1;
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_D01toC201);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_D01_toC201, inputCount); //�]�w��X���
        oldINT_YM = BigDecimal.ZERO;

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C201);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                log.debug("!!!!");
                BigDecimal newINT_YM = new BigDecimal(bqds_1.getField("INT_YM").toString().trim());
                if (0 != oldINT_YM.compareTo(newINT_YM)) {
                    ser_no = 1;
                }
                oldINT_YM = newINT_YM;

                setDTEPC201_Fields(bqds_1, ser_no, mkm);
                buds_Insert_1.addBatch();
                ser_no++;
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C201_fromD01, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object PAY_NO = errMap.get("PAY_NO");

                errorLog.addErrorLog("INSERT DTEPC301 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "PAY_NO="
                        + PAY_NO + "]:" + errObject_1[i][2]);

            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C201_fromD01, errorCount);

        } // for loop end
    }

    private void setDTEPC201_Fields(BatchQueryDataSet bqds, int ser_no, MultiKeyMap mkm) throws DBException, ModuleException {
        BigDecimal INT_YM = new BigDecimal(bqds.getField("INT_YM").toString().trim()).add(BD1911);
        String SUB_CPY_ID = (String) (bqds.getField("SUB_CPY_ID"));
        sb.append(SUB_CPY_ID).append(INT_YM.intValue()).append("I").append(STRING.fillZero("" + ser_no, 4));
        String INT_NO = sb.toString();
        buds_Insert_1.setField("INT_NO", INT_NO);
        buds_Insert_1.setField("SUB_CPY_ID", SUB_CPY_ID);
        buds_Insert_1.setField("INT_YM", INT_YM);
        sb.setLength(0);

        String[] C203col = { "CRT_NO", "CUS_NO", "DIV_NO", "ID", "CUS_NAME", "PMI_S_DATE", "PMI_E_DATE", "PASS_DAY", "PMS_AMT", "RAT_CD",
                "PIM_RATE", "PMI_AMT", "PMI_TAX", "INV_NO", "INV_AMT", "TAX_TYPE", "ACNT_DATE", "ACNT_ID", "ACNT_DIV_NO", "SLIP_LOT_NO", "SLIP_SET_NO", "FLOW_NO",
                "OP_STATUS", "LST_PROC_DATE", "LST_PROC_ID", "LST_PROC_DIV" };

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

        String OP_STATUS = STRING.objToStrNoNull(bqds.getField("OP_STATUS"));
//        String ACNT_ID = (String)bqds.getField("ACNT_ID");
        String DIV_NO = (String)bqds.getField("DIV_NO");
        if("0".equals(OP_STATUS)){
            String FLOW_NO = new RZ_N0Z001().startFlow("EPC2_0030", "�s�W", "", idMap.get(DIV_NO), DIV_NO);
            buds_Insert_1.setField("FLOW_NO", FLOW_NO);
        }
        
        String BLD_CD = STRING.objToStrNoNull(bqds.getField("BLD_CD"));
        // if(BLD_CD!=null && !BLD_CD.trim().equals("")){
        // BLD_CD = "0000"+BLD_CD;
        // }
        buds_Insert_1.setField("BLD_CD", BLD_CD);

        String PAY_NO = ObjectUtils.toString(mkm.get(STRING.objToStrNoNull(bqds.getField("CRT_NO")), STRING.objToStrNoNull(bqds
                .getField("CUS_NO")), STRING.objToStrNoNull(bqds.getField("OLD_RCV_NO"))));
        buds_Insert_1.setField("PAY_NO", PAY_NO);
    }

    private void importEPC301306(MultiKeyMap mkm) throws ModuleException {
        try {
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C301, false);
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C306, false);
            deleteC301();
            deleteC306();
//            deleteE01FAIL();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            E01toC301C306(mkm);
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC301() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C301);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C301_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("PAY_NO", STRING.objToStrNoNull(bqds_1.getField("PAY_NO")));
                buds_Insert_1.setField("RCV_NO", (bqds_1.getField("RCV_NO")));
                buds_Insert_1.addBatch();
            }
            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object PAY_NO = errMap.get("PAY_NO");

                errorLog.addErrorLog("DELETE DTEPC301 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "PAY_NO="
                        + PAY_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void deleteC306() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C306);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C306_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("PAY_NO", STRING.objToStrNoNull(bqds_1.getField("PAY_NO")));
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object PAY_NO = errMap.get("PAY_NO");

                errorLog.addErrorLog("DELETE DTEPC306 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "PAY_NO="
                        + PAY_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

//    private void deleteE01FAIL() throws Exception {
//        bqds_1.clear();
//        bqds_1.setConnName("DS_EP");
//        searchAndRetrieve(bqds_1, query_sql_E01FAIL);
//
//        buds_Insert_1.clearBatch();
//        buds_Insert_1.setConnName("DS_EP");
//        buds_Insert_1.preparedBatch(delete_sql_E01FAIL);
//
//        for (prepareFetch(); fetchData(bqds_1); goNext()) {
//
//            while (bqds_1.next()) {
//                buds_Insert_1.setField("CERCVYM", (bqds_1.getField("CERCVYM")));
//                buds_Insert_1.setField("CEPAYKD", (bqds_1.getField("CEPAYKD")));
//                buds_Insert_1.setField("CECRTNO", (bqds_1.getField("CECRTNO")));
//                buds_Insert_1.setField("CECUSNO", (bqds_1.getField("CECUSNO")));
//                buds_Insert_1.setField("CERCVNO", (bqds_1.getField("CERCVNO")));
//                buds_Insert_1.addBatch();
//            }
//            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();
//
//            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
//                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);
//
//            for (int i = 0; i < errObject_1.length; i++) {
//                Map errMap = (Map) errObject_1[i][1];
//
//                if (isDebug)
//                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);
//
//                Object CERCVNO = errMap.get("CERCVNO");
//
//                errorLog.addErrorLog("DELETE DTEPC301 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "CERCVNO="
//                        + CERCVNO + "]:" + errObject_1[i][2]);
//
//                errorLog.getErrorCountAndWriteErrorMessage();
//
//            }
//
//        } // for loop end
//    }

    private String getNEW_KEY(String OLD_TABLE, String NEW_TABLE, String OLD_KEY, String sql) {
        queryDS.clear();
        queryDS.setField("OLD_TABLE", OLD_TABLE);
        queryDS.setField("NEW_TABLE", NEW_TABLE);
        queryDS.setField("OLD_KEY", OLD_KEY);
        try {
            List<Map> Z998List = VOTool.findToMaps(queryDS, sql);
            return MapUtils.getString(Z998List.get(0), "NEW_KEY", "");
        } catch (Exception e) {
            return "";
        }
    }

    private void E01toC301C306(MultiKeyMap mkm) throws Exception {
        Integer ser_no = 1;
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_E01toC301C306);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_E01_toC301C306, inputCount); //�]�w��X���
        oldRCV_YM = BigDecimal.ZERO;

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C301);

        buds_Insert_2.clearBatch();
        buds_Insert_2.setConnName("DS_EP");
        buds_Insert_2.preparedBatch(insert_sql_C306);

        buds_Insert_3.clearBatch();
        buds_Insert_3.setConnName("DS_EP");
        buds_Insert_3.preparedBatch(insert_sql_Z998);

//        buds_Insert_4.clearBatch();
//        buds_Insert_4.setConnName("DS_EP");
//        buds_Insert_4.preparedBatch(insert_sql_E01FAIL);

        Integer C301failcnt = 0;
        EP_Z0Z001 z001 = new EP_Z0Z001();
        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                log.debug("!!!!");
                BigDecimal newRCV_YM = new BigDecimal(bqds_1.getField("RCV_YM").toString().trim());
                String PAY_KIND = (String) (bqds_1.getField("PAY_KIND"));
                if (0 != oldRCV_YM.compareTo(newRCV_YM)) {
                    ser_no = 1;
                    z001.updateSER_NO("00", "008", "" + (newRCV_YM.add(BD1911)).intValue(), "ERROR", "0");
                    z001.updateSER_NO("00", "021", "" + (newRCV_YM.add(BD1911)).intValue(), "1", "0");
                    z001.updateSER_NO("00", "021", "" + (newRCV_YM.add(BD1911)).intValue(), "2", "0");
                    z001.updateSER_NO("00", "021", "" + (newRCV_YM.add(BD1911)).intValue(), "3", "0");
                    z001.updateSER_NO("00", "021", "" + (newRCV_YM.add(BD1911)).intValue(), "4", "0");
                    z001.updateSER_NO("00", "021", "" + (newRCV_YM.add(BD1911)).intValue(), "5", "0");
                    z001.updateSER_NO("00", "021", "" + (newRCV_YM.add(BD1911)).intValue(), "7", "0");
                }
                oldRCV_YM = newRCV_YM;

                sb.append(STRING.objToStrNoNull(bqds_1.getField("RCV_YM")).trim()).append("@").append(
                    STRING.objToStrNoNull(bqds_1.getField("PAY_KIND")).trim()).append("@").append(
                    STRING.objToStrNoNull(bqds_1.getField("CRT_NO")).trim()).append("@").append(
                    STRING.objToStrNoNull(bqds_1.getField("CUS_NO")).trim()).append("@").append(
                    STRING.objToStrNoNull(bqds_1.getField("PAY_S_DATE")).trim()).append("@").append(
                    STRING.objToStrNoNull(bqds_1.getField("PAY_E_DATE")).trim());
                String OLD_KEY = sb.toString();
                sb.setLength(0);
                String RCV_NO_NEW_KEY = getNEW_KEY("DTEPC02", "DTEPC101", OLD_KEY, query_sql_Z998_2);
                if(StringUtils.isBlank(RCV_NO_NEW_KEY)){
                    RCV_NO_NEW_KEY = getNEW_KEY("DTEPD05", "DTEPC101", OLD_KEY, query_sql_Z998_2);
                }
//                sb.append(STRING.objToStrNoNull(bqds_1.getField("INV_NO")).trim());
//                String OLD_KEY = sb.toString();
//                sb.setLength(0);
//                String RCV_NO_NEW_KEY = getNEW_KEY("DTEPC02", "DTEPC101", OLD_KEY, query_sql_Z998_2);
                if (RCV_NO_NEW_KEY == null || RCV_NO_NEW_KEY.trim().equals("")) {
                    int SER_NO = z001.createNextNumber("00", "008", "" + (newRCV_YM.add(BD1911)).intValue(), "ERROR");
                    RCV_NO_NEW_KEY = "00" + (newRCV_YM.add(BD1911)).intValue() + "E" + STRING.fillZero("" + SER_NO, 4);
                }
//                log.fatal("RCV_NO_NEW_KEY:" + RCV_NO_NEW_KEY);
                
                
                int SER_NO = z001.createNextNumber("00", "021", ""+(newRCV_YM.add(BD1911)).intValue(), PAY_KIND);
                String PAY_NO = setDTEPC301_Fields(bqds_1, SER_NO, mkm, RCV_NO_NEW_KEY);
                // String RCV_NO =
                // STRING.objToStrNoNull(bqds_1.getField("RCV_NO"));
                // if (RCV_NO != null && !RCV_NO.trim().equals("")) {
                if (RCV_NO_NEW_KEY != null && !RCV_NO_NEW_KEY.trim().equals("")) {
                    buds_Insert_1.addBatch();
                } else {
                    C301failcnt++;
//                    setDTEPE01FAIL_Fields(bqds_1);
                }
                setDTEPC306_Fields(bqds_1, PAY_NO);
                buds_Insert_2.addBatch();
                ser_no++;
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C301_fromE01, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object PAY_NO = errMap.get("PAY_NO");

                errorLog.addErrorLog("INSERT DTEPC301 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "PAY_NO="
                        + PAY_NO + "]:" + errObject_1[i][2]);

            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C301_fromE01, errorCount);

            int buds_INSERT_2_Ret[] = buds_Insert_2.executeBatch();

            Object errObject_2[][] = errorHandler.getErrorArray(buds_Insert_2.getBatchUpdateErrorArray(), buds_INSERT_2_Ret, buds_Insert_2
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount2 = buds_INSERT_2_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount2 -= errObject_2.length;
            

            countManager.addCountNumber(OUTPUT_COUNT_C306_fromE01, outputCount2);
            
            for (int i = 0; i < errObject_2.length; i++) {
                Map errMap = (Map) errObject_2[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_2[i][2]);

                Object PAY_NO = errMap.get("PAY_NO");

                errorLog.addErrorLog("INSERT DTEPC306 " + errObject_2[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "PAY_NO="
                        + PAY_NO + "]:" + errObject_2[i][2]);

            }
            int errorCount2 = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C306_fromE01, errorCount2);

            int buds_INSERT_3_Ret[] = buds_Insert_3.executeBatch();

            Object errObject_3[][] = errorHandler.getErrorArray(buds_Insert_3.getBatchUpdateErrorArray(), buds_INSERT_3_Ret, buds_Insert_3
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_SUCCESS);

            for (int i = 0; i < errObject_3.length; i++) {
                Map errMap = (Map) errObject_3[i][1];

                Object OLD_KEY = errMap.get("OLD_KEY");
                Object NEW_KEY = errMap.get("NEW_KEY");
                
                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_3[i][2]);

                errorLog.addErrorLog("INSERT DTEPZ998 " + errObject_3[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "OLD_KEY="
                        + OLD_KEY + "NEW_KEY=" + NEW_KEY + "]:" + errObject_3[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }
//
//            int buds_INSERT_4_Ret[] = buds_Insert_4.executeBatch();
//
//            Object errObject_4[][] = errorHandler.getErrorArray(buds_Insert_4.getBatchUpdateErrorArray(), buds_INSERT_4_Ret, buds_Insert_4
//                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);
//
//          //���XaddBatch�������
//            int outputCount4 = buds_INSERT_4_Ret.length;
//
//            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
//            outputCount4 -= errObject_4.length;
//            
//            countManager.addCountNumber(OUTPUT_COUNT_C301FAIL_fromE01, outputCount4);
//            
//            for (int i = 0; i < errObject_4.length; i++) {
//                Map errMap = (Map) errObject_4[i][1];
//
//                if (isDebug)
//                    log.debug("EPZ1_0100(17)�G" + errObject_4[i][2]);
//
//                Object CERCVNO = errMap.get("CERCVNO");
//
//                errorLog.addErrorLog("INSERT DTEPE01FAIL " + errObject_4[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
//                        + "CERCVNO=" + CERCVNO + "]:" + errObject_4[i][2]);
//
//            }
//            int errorCount4 = errorLog.getErrorCountAndWriteErrorMessage();
//            //�������~���
//            countManager.addCountNumber(ERROR_COUNT_C301FAIL_fromE01, errorCount4);
        } // for loop end

        log.fatal("C301failcnt=" + C301failcnt);
    }

//    private void setDTEPE01FAIL_Fields(BatchQueryDataSet bqds) throws DBException {
//        buds_Insert_4.setField("CERCVYM", (bqds.getField("RCV_YM")));
//        buds_Insert_4.setField("CEPAYKD", (bqds.getField("PAY_KIND")));
//        buds_Insert_4.setField("CECRTNO", (bqds.getField("CRT_NO")));
//        buds_Insert_4.setField("CECUSNO", (bqds.getField("CUS_NO")));
//        buds_Insert_4.setField("CERCVNO", (bqds.getField("OLD_RCV_NO")));
//        buds_Insert_4.addBatch();
//    }

    private String setDTEPC301_Fields(BatchQueryDataSet bqds, int ser_no, MultiKeyMap mkm, String RCV_NO_NEW_KEY) throws DBException {
        String RCV_YM_Str = STRING.objToStrNoNull(bqds.getField("RCV_YM"));
        if ("".equals(RCV_YM_Str)) {
            RCV_YM_Str = "0";
        } else {
            RCV_YM_Str = RCV_YM_Str.trim();
        }
        BigDecimal RCV_YM = new BigDecimal(RCV_YM_Str).add(BD1911);
        String SUB_CPY_ID = (String) (bqds.getField("SUB_CPY_ID"));
        String PAY_KIND = (String) (bqds.getField("PAY_KIND"));
        
        sb.append(SUB_CPY_ID).append(RCV_YM.intValue()).append(PAY_KIND).append(STRING.fillZero("" + ser_no, 4));
        String PAY_NO = sb.toString();
        buds_Insert_1.setField("PAY_NO", PAY_NO);
        buds_Insert_1.setField("SUB_CPY_ID", SUB_CPY_ID);
        buds_Insert_1.setField("RCV_YM", RCV_YM);
        buds_Insert_1.setField("PAY_KIND", PAY_KIND);
        sb.setLength(0);

        String[] C203col = { "CRT_NO", "CUS_NO", "PAY_TYPE", "PAY_AMT", "CHK_CD", "COA_DATE", "PMI_S_DATE", "PMI_E_DATE", "SWP_KIND",
                "SWP_DATE", "INV_NO", "ID", "CUS_NAME", "PAY_S_DATE", "PAY_E_DATE", "INPUT_ID", "TRN_DATE", "TRN_SER_NO", "ACNT_DATE",
                "ACNT_DIV_NO", "SLIP_LOT_NO","SLIP_SET_NO", "TRN_KIND", "CHG_DATE", "CHG_ID", "OP_STATUS_C101" };

        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

        String BLD_CD = STRING.objToStrNoNull(bqds.getField("BLD_CD"));
        // if(BLD_CD!=null && !BLD_CD.trim().equals("")){
        // BLD_CD = "0000"+BLD_CD;
        // }
        buds_Insert_1.setField("INPUT_NAME", bqds.getField("INPUT_ID"));
        buds_Insert_1.setField("BLD_CD", BLD_CD);
        buds_Insert_1.setField("RCV_NO", RCV_NO_NEW_KEY);

        
        sb.append(RCV_YM_Str).append("@").append(PAY_KIND).append("@").append(bqds.getField("CRT_NO"))
        .append("@").append(bqds.getField("CUS_NO")).append("@").append(bqds.getField("OLD_RCV_NO"));
        String OLD_KEY = sb.toString();
        sb.setLength(0);
        buds_Insert_3.setField("OLD_TABLE", "DTEPE01");
        buds_Insert_3.setField("NEW_TABLE", "C301_RCVNO");
        buds_Insert_3.setField("OLD_KEY", OLD_KEY);
        buds_Insert_3.setField("NEW_KEY", RCV_NO_NEW_KEY);
        buds_Insert_3.addBatch();
        
        sb.setLength(0);
        buds_Insert_3.setField("OLD_TABLE", "DTEPE01");
        buds_Insert_3.setField("NEW_TABLE", "C301_PAYNO");
        buds_Insert_3.setField("OLD_KEY", OLD_KEY);
        buds_Insert_3.setField("NEW_KEY", PAY_NO);
        buds_Insert_3.addBatch();
        
        
        if ("2".equals(PAY_KIND)) {
            mkm.put(STRING.objToStrNoNull(bqds.getField("CRT_NO")), STRING.objToStrNoNull(bqds.getField("CUS_NO")), STRING
                    .objToStrNoNull(bqds.getField("OLD_RCV_NO")), PAY_NO);
        }

        return PAY_NO;
    }

    private void setDTEPC306_Fields(BatchQueryDataSet bqds, String PAY_NO) throws DBException {
        buds_Insert_2.setField("PAY_NO", PAY_NO);

        String[] C203col = { "CSH_AMT", "CHK_AMT", "RMT_AMT", "TKD_AMT", "MAL_AMT", "PAY_AMT", "DACNT_AMT", "TMP_AMT", "ACNT_AMT",
                "CHK_SET_NO", "INPUT_ID", "TRN_DATE", "TRN_SER_NO", "ACNT_DATE", "ACNT_DIV_NO", "SLIP_LOT_NO","SLIP_SET_NO", "TRN_KIND", "CHG_DATE", "CHG_ID" };

        for (String colkey : C203col) {
            buds_Insert_2.setField(colkey, (bqds.getField(colkey)));
        }

        String RCV_YM_Str = STRING.objToStrNoNull(bqds.getField("RCV_YM"));
        if ("".equals(RCV_YM_Str)) {
            RCV_YM_Str = "0";
        } else {
            RCV_YM_Str = RCV_YM_Str.trim();
        }
        String CECKGPN = STRING.objToStrNoNull(bqds.getField("CECKGPN"));
        sb.append(bqds.getField("OLD_RCV_NO")).append("@").append(RCV_YM_Str).append("@").append(CECKGPN);
        String OLD_KEY = sb.toString();
        sb.setLength(0);
        buds_Insert_3.setField("OLD_TABLE", "DTEPE01");
        buds_Insert_3.setField("NEW_TABLE", "DTEPC306");
        buds_Insert_3.setField("OLD_KEY", OLD_KEY);
        buds_Insert_3.setField("NEW_KEY", PAY_NO);
        buds_Insert_3.addBatch();
    }

    private void importDKG002() throws ModuleException {

        try {
            // queryDS.clear();
            // queryDS.setConnName("DS_DK");
            // DBUtil.executeUpdate(queryDS, delete_sql_DKG002, false);
            deleteDKG002();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
         try {
         queryDS.clear();
         E07toDKG002();
        
         } catch (Exception e) {
         errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
         setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
         log.fatal(e.toString());
         log.debug(e.toString());
         throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
         }
    }

    private void deleteDKG002() throws Exception {

        bqds_1.clear();
        bqds_1.setConnName("DS_DK");
        searchAndRetrieve(bqds_1, query_sql_DKG002);

        BatchUpdateDataSet buds = null;

        try {
            buds = getBatchUpdateDataSet();
            buds.setConnName("DS_DK");
            buds.preparedBatch(delete_sql_DKG002_2);

            for (prepareFetch(); fetchData(bqds_1); goNext()) {

                while (bqds_1.next()) {
                    buds.setField("TMP_NO", STRING.objToStrNoNull(bqds_1.getField("TMP_NO")));
                    buds.addBatch();
                }

                int buds_INSERT_1_Ret[] = buds.executeBatch();

                Object errObject_1[][] = errorHandler.getErrorArray(buds.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds
                        .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

                for (int i = 0; i < errObject_1.length; i++) {
                    Map errMap = (Map) errObject_1[i][1];

                    if (isDebug) {
                        log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);
                    }

                    Object TMP_NO = errMap.get("TMP_NO");
                    Object params = errObject_1[i][2];

                    sb.append("com.cathay.ep.z1.module.EPZ1_0100.INSERT").append("[").append("TMP_NO=").append(TMP_NO).append("]:").append(
                        params);
                    String msg = sb.toString();
                    sb.setLength(0);

                    errorLog.addErrorLog("DELETE DTDKG002 " + params, msg);

                    errorLog.getErrorCountAndWriteErrorMessage();

                }

            } // for loop end

        } finally {
            if (buds != null) {
                buds.close();
            }

        }

    }

    private void importDKG003() throws ModuleException {
        try {
            // queryDS.clear();
            // queryDS.setConnName("DS_DK");
            // DBUtil.executeUpdate(queryDS, delete_sql_DKG003, false);
            deleteDKG003();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }
        try {
            queryDS.clear();
            E08toDKG003();

        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteDKG003() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_DK");
        searchAndRetrieve(bqds_1, query_sql_DKG003);

        BatchUpdateDataSet buds = null;

        try {
            buds = getBatchUpdateDataSet();
            buds.setConnName("DS_DK");
            buds.preparedBatch(delete_sql_DKG003_2);

            for (prepareFetch(); fetchData(bqds_1); goNext()) {

                while (bqds_1.next()) {
                    buds.setField("DTMP_NO", STRING.objToStrNoNull(bqds_1.getField("DTMP_NO")));
                    buds.addBatch();
                }

                int buds_INSERT_1_Ret[] = buds.executeBatch();

                Object errObject_1[][] = errorHandler.getErrorArray(buds.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds
                        .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

                for (int i = 0; i < errObject_1.length; i++) {
                    Map errMap = (Map) errObject_1[i][1];

                    if (isDebug) {
                        log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);
                    }

                    Object DTMP_NO = errMap.get("DTMP_NO");
                    Object params = errObject_1[i][2];

                    sb.append("com.cathay.ep.z1.module.EPZ1_0100.INSERT").append("[").append("DTMP_NO=").append(DTMP_NO).append("]:").append(
                        params);
                    String msg = sb.toString();
                    sb.setLength(0);

                    errorLog.addErrorLog("DELETE DTDKG003 " + params, msg);

                    errorLog.getErrorCountAndWriteErrorMessage();

                }

            } // for loop end

        } finally {
            if (buds != null) {
                buds.close();
            }

        }

        
        
    }

    private void C02toC101(Map year2Serno, Set RCV_NO_Set) throws Exception {
        Integer ser_no = 1;
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        // bqds_1.setField("YEAR_B", new BigDecimal(ROCYEAR).multiply(new
        // BigDecimal("100")));
        // bqds_1.setField("YEAR_E", (new
        // BigDecimal(ROCYEAR).add(BigDecimal.ONE)).multiply(new
        // BigDecimal("100")));
        searchAndRetrieve(bqds_1, query_sql_C02toC101);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_C02_toC101, inputCount); //�]�w��X���
        
        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C101);

        buds_Insert_2.clearBatch();
        buds_Insert_2.setConnName("DS_EP");
        buds_Insert_2.preparedBatch(insert_sql_Z998);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                BigDecimal newRCV_YM = new BigDecimal(bqds_1.getField("RCV_YM").toString().trim());
                if (0 != oldRCV_YM.compareTo(newRCV_YM)) {
                    ser_no = 1;
                    new EP_Z0Z001().updateSER_NO("00", "008", "" + (newRCV_YM.add(BD1911)).intValue(), "E_C101", "0");
                }
                oldRCV_YM = newRCV_YM;
                setDTEPC101_Fields(bqds_1, ser_no, "DTEPC02", RCV_NO_Set);
                buds_Insert_1.addBatch();
                ser_no++;
                year2Serno.put(oldRCV_YM, ser_no);
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(14)�G" + errObject_1[i][2]);

                Object RCV_NO = errMap.get("RCV_NO");

                errorLog.addErrorLog("INSERT DTEPC101 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO="
                        + RCV_NO + "]:" + errObject_1[i][2]);

            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C101_fromC02, errorCount);
            
            //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C101_fromC02, outputCount);
            
            
            int buds_INSERT_2_Ret[] = buds_Insert_2.executeBatch();

            Object errObject_2[][] = errorHandler.getErrorArray(buds_Insert_2.getBatchUpdateErrorArray(), buds_INSERT_2_Ret, buds_Insert_2
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_2.length; i++) {
                Map errMap = (Map) errObject_2[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_2[i][2]);

                Object OLD_TABLE = errMap.get("OLD_TABLE");
                Object NEW_TABLE = errMap.get("NEW_TABLE");
                Object OLD_KEY = errMap.get("OLD_KEY");

                errorLog.addErrorLog("INSERT DTEPZ998 " + errObject_2[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                        + "OLD_TABLE=" + OLD_TABLE + "NEW_TABLE=" + NEW_TABLE + "OLD_KEY=" + OLD_KEY + "]:" + errObject_2[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }
        } // for loop end
    }

    private void importC101() throws ModuleException {
        try {
            // DBUtil.executeUpdate(queryDS, delete_sql_C101, false);
            deleteC101();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8)�G" + e);
        }

        Map<BigDecimal, Integer> year2Serno = new HashMap();
        Set RCV_NO_Set = new HashSet();
        try {
            queryDS.clear();
            C02toC101(year2Serno, RCV_NO_Set);
            queryDS.clear();
            D05toC101(year2Serno, RCV_NO_Set);

        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16)�G" + e.getMessage());
        }
    }

    private void deleteC101() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C101);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C101_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("RCV_NO", STRING.objToStrNoNull(bqds_1.getField("RCV_NO")));
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object RCV_NO = errMap.get("RCV_NO");

                errorLog.addErrorLog("DELETE DTEPC101 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO="
                        + RCV_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void E08toDKG003() throws Exception {

        BatchUpdateDataSet buds = null;

        try {

            buds = getBatchUpdateDataSet();
            buds.setConnName("DS_DK");
            buds.preparedBatch(insert_sql_DKG003);

            // DataSet ds_dk = Transaction.getDataSet();
            // ds_dk.setConnName("DS_DK");

            bqds_1.clear();
            bqds_1.setConnName("DS_EP");
            searchAndRetrieve(bqds_1, query_sql_E08toDKG003);
            int inputCount = getInputCount();
            countManager.addCountNumber(INPUT_COUNT_E08_toDKG003, inputCount); //�]�w��X���

            // buds_Insert_1.clear();
            // buds_Insert_1.setDataSet(ds_dk);
            // buds_Insert_1.setConnName("DS_DK");
            // buds_Insert_1.preparedBatch(insert_sql_DKG003);
            int serno = 1;
            String DTMP_NO_OLD = "";
            for (prepareFetch(); fetchData(bqds_1); goNext()) {

                while (bqds_1.next()) {
                    String DTMP_NO = STRING.objToStrNoNull(bqds_1.getField("DTMP_NO"));
                    if (0 != DTMP_NO.compareTo(DTMP_NO_OLD)) {
                        serno = 1;
                    }
                    DTMP_NO_OLD = DTMP_NO;

                    setDTDKG003_Fields(bqds_1, buds, serno);
                    buds.addBatch();
                    serno++;
                }

                int buds_Ret[] = buds.executeBatch();

                Object errObject_1[][] = errorHandler.getErrorArray(buds.getBatchUpdateErrorArray(), buds_Ret, buds.getBatchMapsArray(),
                    ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

              //���XaddBatch�������
                int outputCount = buds_Ret.length;

                //�N��X��Ʀ�����Insert�ɵo�ͪ����~
                outputCount -= errObject_1.length;
                
                countManager.addCountNumber(OUTPUT_COUNT_DKG003_fromE08, outputCount);
                
                for (int i = 0; i < errObject_1.length; i++) {
                    Map errMap = (Map) errObject_1[i][1];

                    if (isDebug)
                        log.debug("EPZ1_0100(14)�G" + errObject_1[i][2]);

                    Object DTMP_NO = errMap.get("DTMP_NO");

                    errorLog.addErrorLog("INSERT DTDKG003 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                            + "DTMP_NO=" + DTMP_NO + "]:" + errObject_1[i][2]);

                }
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                //�������~���
                countManager.addCountNumber(ERROR_COUNT_DKG003_fromE08, errorCount);

            } // for loop end
        } finally {
            if (buds != null) {
                buds.close();
            }

        }
    }

    private void setDTDKG003_Fields(BatchQueryDataSet bqds, BatchUpdateDataSet buds, int serno) throws DBException {
        String[] C203col = { "TMP_NO", "TMP_CD", "DACNT_ID", "SLIP_DATE", "DACNT_DATE", "SLIP_SET_NO", "DACNT_AMT", "SUB_ACNT_CODE", "TMP_D_KIND",
                "RTN_KIND", "ACPT_ID", "ACPT_ACNT_NAME" };
        String DTMP_NO = STRING.objToStrNoNull(bqds.getField("DTMP_NO"));
        DTMP_NO = DTMP_NO.replace("-", "");
        if(DTMP_NO.length()>2){
            DTMP_NO = DTMP_NO.substring(2);
        }
        DTMP_NO = "EP" + DTMP_NO + STRING.fillZero("" + serno, 4);

        String DDATE_ONE = STRING.objToStrNoNull(bqds.getField("DDATE_ONE")).split(" ")[0];
        String DDATE_TWO = STRING.objToStrNoNull(bqds.getField("DDATE_TWO")).split(" ")[1];

        String SLIP_SET_NO = STRING.objToStrNoNull(bqds.getField("SLIP_SET_NO"));
        int int_SLIP_SET_NO = 0;
        if (SLIP_SET_NO != null && NumberUtils.isNumber(SLIP_SET_NO)) {
            int_SLIP_SET_NO = Integer.parseInt(SLIP_SET_NO);
        }
        buds.setField("DTMP_NO", DTMP_NO);
        if (!"".equals(DDATE_ONE) && !"".equals(DDATE_TWO)) {
            buds.setField("DACNT_IN_DATE", DDATE_ONE + " " + DDATE_TWO);
        } else {
            buds.setField("DACNT_IN_DATE", null);
        }
        buds.setField("SLIP_SET_NO", int_SLIP_SET_NO);
        String BAL_AMT = STRING.objToStrNoNull(bqds.getField("BAL_AMT"));
        if (!"".equals(BAL_AMT)) {
            buds.setField("BAL_AMT", new BigDecimal(BAL_AMT));
        } else {
            buds.setField("BAL_AMT", null);
        }
        for (String colkey : C203col) {
            buds.setField(colkey, (bqds.getField(colkey)));
        }
    }

    private void E07toDKG002() throws Exception {

        BatchUpdateDataSet buds = null;

        try {

            buds = getBatchUpdateDataSet();
            buds.setConnName("DS_DK");
            buds.preparedBatch(insert_sql_DKG002);

            
            buds_Insert_1.clearBatch();
            buds_Insert_1.setConnName("DS_EP");
            buds_Insert_1.preparedBatch(insert_sql_C306);
            
            buds_Insert_2.clearBatch();
            buds_Insert_2.setConnName("DS_EP");
            buds_Insert_2.preparedBatch(insert_sql_Z998);

            bqds_1.clear();
            bqds_1.setConnName("DS_EP");
            searchAndRetrieve(bqds_1, query_sql_E07toDKG002);
            int inputCount = getInputCount();
            countManager.addCountNumber(INPUT_COUNT_E07_toDKG002, inputCount); //�]�w��X���

            for (prepareFetch(); fetchData(bqds_1); goNext()) {

                while (bqds_1.next()) {
                    setDTDKG002_Fields(bqds_1, buds);
                    
                    
//                    String BAL_AMT_Str = STRING.objToStrNoNull(bqds_1.getField("BAL_AMT"));
//                    BigDecimal BAL_AMT = BigDecimal.ZERO;
//                    if(StringUtils.isNotBlank(BAL_AMT_Str)&&NumberUtils.isNumber(BAL_AMT_Str)){
//                        BAL_AMT = new BigDecimal(BAL_AMT_Str);
//                    }
//                    if(0<BAL_AMT.compareTo(BigDecimal.ZERO)){
                        countManager.addCountNumber(INPUT_COUNT_E07_toC306, 1);
                        String PAY_NO = setDTEPC306_Fields_2(bqds_1);
                        buds_Insert_1.addBatch();
                        buds.setField("RTN_RCPT_NO", PAY_NO);
//                    }
                    
                    buds.addBatch();
                }

                int buds_Ret[] = buds.executeBatch();

                Object errObject_1[][] = errorHandler.getErrorArray(buds.getBatchUpdateErrorArray(), buds_Ret, buds.getBatchMapsArray(),
                    ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

                //���XaddBatch�������
                int outputCount = buds_Ret.length;

                //�N��X��Ʀ�����Insert�ɵo�ͪ����~
                outputCount -= errObject_1.length;
                
                countManager.addCountNumber(OUTPUT_COUNT_DKG002_fromE07, outputCount);
                
                for (int i = 0; i < errObject_1.length; i++) {
                    Map errMap = (Map) errObject_1[i][1];

                    if (isDebug)
                        log.debug("EPZ1_0100(14)�G" + errObject_1[i][2]);

                    Object TMP_NO = errMap.get("TMP_NO");

                    errorLog.addErrorLog("INSERT DTDKG002 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                            + "TMP_NO=" + TMP_NO + "]:" + errObject_1[i][2]);

                }
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                //�������~���
                countManager.addCountNumber(ERROR_COUNT_DKG002_fromE07, errorCount);

                
                int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

                Object errObject_3[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                        .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

              //���XaddBatch�������
                int outputCount2 = buds_INSERT_1_Ret.length;

                //�N��X��Ʀ�����Insert�ɵo�ͪ����~
                outputCount2 -= errObject_3.length;
                
                countManager.addCountNumber(OUTPUT_COUNT_C306_fromE07, outputCount2);
                
                for (int i = 0; i < errObject_3.length; i++) {
                    Map errMap = (Map) errObject_3[i][1];

                    if (isDebug)
                        log.debug("EPZ1_0100(17)�G" + errObject_3[i][2]);

                    Object PAY_NO = errMap.get("PAY_NO");

                    errorLog.addErrorLog("INSERT DTEPC306 " + errObject_3[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                            + "PAY_NO=" + PAY_NO + "]:" + errObject_3[i][2]);

                }
                int errorCount2 = errorLog.getErrorCountAndWriteErrorMessage();
                //�������~���
                countManager.addCountNumber(ERROR_COUNT_C306_fromE07, errorCount2);
                
                
                int buds_INSERT_2_Ret[] = buds_Insert_2.executeBatch();

                Object errObject_2[][] = errorHandler.getErrorArray(buds_Insert_2.getBatchUpdateErrorArray(), buds_INSERT_2_Ret, buds_Insert_2
                        .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

                for (int i = 0; i < errObject_2.length; i++) {
                    Map errMap = (Map) errObject_2[i][1];

                    if (isDebug)
                        log.debug("EPZ1_0100(17)�G" + errObject_2[i][2]);

                    Object OLD_TABLE = errMap.get("OLD_TABLE");
                    Object NEW_TABLE = errMap.get("NEW_TABLE");
                    Object OLD_KEY = errMap.get("OLD_KEY");

                    errorLog.addErrorLog("INSERT DTEPZ998 " + errObject_2[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                            + "OLD_TABLE=" + OLD_TABLE + "NEW_TABLE=" + NEW_TABLE + "OLD_KEY=" + OLD_KEY + "]:" + errObject_2[i][2]);

                    errorLog.getErrorCountAndWriteErrorMessage();

                }
                
            } // for loop end
        } finally {
            if (buds != null) {
                buds.close();
            }
        }
    }

    private String setDTEPC306_Fields_2(BatchQueryDataSet bqds) throws DBException, ModuleException {
        
        String PAY_KIND = STRING.objToStrNoNull(bqds.getField("CAT_PREM"));
        String SLIP_DATE = STRING.objToStrNoNull(bqds.getField("SLIP_DATE"));
        if(StringUtils.isBlank(SLIP_DATE)){
            SLIP_DATE = STRING.objToStrNoNull(bqds.getField("LST_CHG_DATE"));
        }
        if(StringUtils.isBlank(SLIP_DATE)){
            return "";
        }else{
            SLIP_DATE = SLIP_DATE.replace("-","");
            SLIP_DATE = SLIP_DATE.substring(0, 6);
        }
        BigDecimal RCV_YM = new BigDecimal(SLIP_DATE);
        if(StringUtils.isBlank(PAY_KIND)){
            PAY_KIND = "5";
        }
        int SER_NO = new EP_Z0Z001().createNextNumber("00", "021", ""+RCV_YM.intValue(), PAY_KIND);
        sb.append("00").append(RCV_YM.intValue()).append(PAY_KIND).append(STRING.fillZero("" + SER_NO, 4));
        String PAY_NO = sb.toString();
        sb.setLength(0);
        
        BigDecimal CSH_AMT = BigDecimal.ZERO;
        BigDecimal CHK_AMT = BigDecimal.ZERO;
        BigDecimal RMT_AMT = BigDecimal.ZERO;
        BigDecimal PAY_AMT = BigDecimal.ZERO;
        BigDecimal TMP_AMT = BigDecimal.ZERO;
        
        String PAY_AMT_str = STRING.objToStrNoNull(bqds.getField("ACNT_AMT"));
        if(StringUtils.isNotBlank(PAY_AMT_str)){
            PAY_AMT = new BigDecimal(PAY_AMT_str);
            TMP_AMT = PAY_AMT;
            String CETKCKD = STRING.objToStrNoNull(bqds.getField("CETKCKD"));
            if("4".equals(CETKCKD)){
                CSH_AMT = PAY_AMT;
            }else if("1".equals(CETKCKD)){
                CHK_AMT = PAY_AMT;
            }else if("2".equals(CETKCKD)){
                RMT_AMT = PAY_AMT;
            }
        }
        
        buds_Insert_1.setField("PAY_NO", PAY_NO);
        buds_Insert_1.setField("CSH_AMT", CSH_AMT);
        buds_Insert_1.setField("CHK_AMT", CHK_AMT);
        buds_Insert_1.setField("RMT_AMT", RMT_AMT);
        buds_Insert_1.setField("TKD_AMT", BigDecimal.ZERO);
        buds_Insert_1.setField("MAL_AMT", BigDecimal.ZERO);
        buds_Insert_1.setField("PAY_AMT", PAY_AMT);
        buds_Insert_1.setField("DACNT_AMT", BigDecimal.ZERO);
        buds_Insert_1.setField("TMP_AMT", TMP_AMT);
        buds_Insert_1.setField("ACNT_AMT", BigDecimal.ZERO);
        buds_Insert_1.setField("CHK_SET_NO", bqds.getField("CHK_SET_NO"));
        buds_Insert_1.setField("INPUT_ID", null);
        buds_Insert_1.setField("TRN_DATE", null);
        buds_Insert_1.setField("TRN_SER_NO", null);
        buds_Insert_1.setField("ACNT_DATE", bqds.getField("CEPAYDT"));
        buds_Insert_1.setField("ACNT_DIV_NO", bqds.getField("ACNT_DIV_NO"));
        buds_Insert_1.setField("SLIP_LOT_NO", null);
        buds_Insert_1.setField("SLIP_SET_NO", null);
        buds_Insert_1.setField("TRN_KIND", "01");
        buds_Insert_1.setField("CHG_DATE", bqds.getField("LST_CHG_DATE"));
        buds_Insert_1.setField("CHG_ID", bqds.getField("LST_CHG_DIV"));
        
        return PAY_NO;
    }
    
    private void setDTDKG002_Fields(BatchQueryDataSet bqds, BatchUpdateDataSet buds) throws DBException {
        String[] C203col = { "TMP_NO", "SYS_NO", "TMP_CD", "TMP_KIND", "INPUT_CD", "ACNT_ID", "ACNT_IN_DATE", "SLIP_DATE", "ACNT_DATE",
                "ACNT_AMT", "BAL_AMT", "SUB_ACNT_CODE", "DTL_ACNT_CODE", "TMP_IN_CD", "RESN_NO", "ACNT_DIV_NO", "ACNT_DIV_NAME",
                "LST_CHG_ID", "LST_CHG_DATE", "ID", "POLICY_NO", "PAY_TIMES", "CAT_PREM", "APLY_NO", "RTN_RCPT_NO", "CST_NAME",
                "CHK_SET_NO", "CHK_STS_CODE", "MEMO", "CURR", "COA_DATE" };
        log.debug("=======" + STRING.objToStrNoNull(bqds.getField("TMP_NO")));
        String SLIP_SET_NO = STRING.objToStrNoNull(bqds.getField("SLIP_SET_NO"));
        int int_SLIP_SET_NO = 0;
        if (SLIP_SET_NO != null && NumberUtils.isNumber(SLIP_SET_NO)) {
            int_SLIP_SET_NO = Integer.parseInt(SLIP_SET_NO);
        }
        buds.setField("SLIP_SET_NO", int_SLIP_SET_NO);
        buds.setField("TRN_KIND", "EPC305");
        for (String colkey : C203col) {
            buds.setField(colkey, (bqds.getField(colkey)));
        }

        String TMP_NO = STRING.objToStrNoNull(bqds.getField("TMP_NO"));
        String OLD_KEY = bqds.getField("CETKCNO").toString().trim();
        buds_Insert_2.setField("OLD_TABLE", "DTEPE07");
        buds_Insert_2.setField("NEW_TABLE", "DTDKG002");
        buds_Insert_2.setField("OLD_KEY", OLD_KEY);
        buds_Insert_2.setField("NEW_KEY", TMP_NO);
        buds_Insert_2.addBatch();

        sb.append(bqds.getField("RTN_RCPT_NO")).append("@").append(bqds.getField("CHK_SET_NO"));
        OLD_KEY = sb.toString();
        sb.setLength(0);
        buds_Insert_2.setField("OLD_TABLE", "DTEPE07");
        buds_Insert_2.setField("NEW_TABLE", "DTDKG002");
        buds_Insert_2.setField("OLD_KEY", OLD_KEY);
        buds_Insert_2.setField("NEW_KEY", TMP_NO);
        buds_Insert_2.addBatch();

    }

    private void D05toC101(Map<BigDecimal, Integer> year2Serno, Set RCV_NO_Set) throws Exception {
        Integer ser_no = 1;
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_D05toC101);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_D05_toC101, inputCount); //�]�w��X���
        oldRCV_YM = BigDecimal.ZERO;

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C101);

        buds_Insert_2.clearBatch();
        buds_Insert_2.setConnName("DS_EP");
        buds_Insert_2.preparedBatch(insert_sql_Z998);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                log.debug("!!!!");
                BigDecimal newRCV_YM = new BigDecimal(bqds_1.getField("RCV_YM").toString().trim());
                if (0 != oldRCV_YM.compareTo(newRCV_YM)) {
                    ser_no = year2Serno.get(newRCV_YM);
                    if (null == ser_no) {
                        ser_no = 1;
                    }
                }
                oldRCV_YM = newRCV_YM;
                setDTEPC101_Fields(bqds_1, ser_no, "DTEPD05", RCV_NO_Set);

                buds_Insert_1.addBatch();
                ser_no++;
                year2Serno.put(oldRCV_YM, ser_no);
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

          //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C101_fromD05, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_1[i][2]);

                Object RCV_NO = errMap.get("RCV_NO");

                errorLog.addErrorLog("INSERT DTEPC101 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO="
                        + RCV_NO + "]:" + errObject_1[i][2]);

            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C101_fromD05, errorCount);

            int buds_INSERT_2_Ret[] = buds_Insert_2.executeBatch();

            Object errObject_2[][] = errorHandler.getErrorArray(buds_Insert_2.getBatchUpdateErrorArray(), buds_INSERT_2_Ret, buds_Insert_2
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_2.length; i++) {
                Map errMap = (Map) errObject_2[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(17)�G" + errObject_2[i][2]);

                Object OLD_TABLE = errMap.get("OLD_TABLE");
                Object NEW_TABLE = errMap.get("NEW_TABLE");
                Object OLD_KEY = errMap.get("OLD_KEY");

                errorLog.addErrorLog("INSERT DTEPZ998 " + errObject_2[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "["
                        + "OLD_TABLE=" + OLD_TABLE + "NEW_TABLE=" + NEW_TABLE + "OLD_KEY=" + OLD_KEY + "]:" + errObject_2[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void importC202() throws Exception {
        try {
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C202,false);
            deleteC202();
        } catch (ModuleException e) {
            throw new ModuleException("EPZ1_0100(8-2)�G" + e);
        }
        try {
            queryDS.clear();
            D03toC202();

            // D05toC202();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15-2)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16-2)�G" + e.getMessage());
        }
    }

    private void deleteC202() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C202);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C202_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("INV_NO", STRING.objToStrNoNull(bqds_1.getField("INV_NO")));
                buds_Insert_1.setField("SUB_CPY_ID", (bqds_1.getField("SUB_CPY_ID")));
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object INV_NO = errMap.get("INV_NO");

                errorLog.addErrorLog("DELETE DTEPC202 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "INV_NO="
                        + INV_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void D03toC202() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_D03toC202);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_D03_toC202, inputCount); //�]�w��X���
        
        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C202);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC202_Fields(bqds_1, 0);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C202_fromD03, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object INV_NO = errMap.get("INV_NO");

                errorLog.addErrorLog("INSERT DTEPC202 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "INV_NO="
                        + INV_NO + "]:" + errObject_1[i][2]);

            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C202_fromD03, errorCount);

        } // for loop end
    }

    // private void D05toC202() throws Exception {
    // bqds_1.clear();
    // searchAndRetrieve(bqds_1, query_sql_D05toC202);
    // buds_Insert_1.clearBatch();
    // buds_Insert_1.preparedBatch(insert_sql_C202);
    //
    // for (prepareFetch(); fetchData(bqds_1); goNext()) {
    //
    // while (bqds_1.next()) {
    // setDTEPC202_Fields(bqds_1, 0);
    // buds_Insert_1.addBatch();
    // }
    //
    // int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();
    //
    // Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1
    // .getBatchUpdateErrorArray(), buds_INSERT_1_Ret,
    // buds_Insert_1.getBatchMapsArray(),
    // ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);
    //
    // for (int i = 0; i < errObject_1.length; i++) {
    // Map errMap = (Map) errObject_1[i][1];
    //
    // if (isDebug)
    // log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);
    //
    // Object INV_NO = errMap.get("INV_NO");
    //
    // errorLog
    // .addErrorLog("INSERT DTEPC202 " + errObject_1[i][2],
    // "com.cathay.ep.z1.module.EPZ1_0100.INSERT"
    // + "[" + "INV_NO=" + INV_NO + "]:"
    // + errObject_1[i][2]);
    //
    // errorLog.getErrorCountAndWriteErrorMessage();
    //
    // }
    //
    // } // for loop end
    // }

    private void importC204() throws ModuleException {
        try {
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C204, false);
            deleteC204();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8-3)�G" + e);
        }
        try {
            queryDS.clear();
            D03toC204();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15-3)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16-3)�G" + e.getMessage());
        }
    }

    private void deleteC204() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C204);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C204_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("INV_NO", STRING.objToStrNoNull(bqds_1.getField("INV_NO")));
                buds_Insert_1.setField("SUB_CPY_ID", (bqds_1.getField("SUB_CPY_ID")));
                buds_Insert_1.setField("SER_NO", (bqds_1.getField("SER_NO")));
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object INV_NO = errMap.get("INV_NO");

                errorLog.addErrorLog("DELETE DTEPC204 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "INV_NO="
                        + INV_NO + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void D03toC204() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_D03toC204);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_D03_toC204, inputCount); //�]�w��X���
        
        
        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C204);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC204_Fields(bqds_1, 1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C204_fromD03, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object INV_NO = errMap.get("INV_NO");

                errorLog.addErrorLog("INSERT DTEPC204 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "RCV_NO="
                        + INV_NO + "]:" + errObject_1[i][2]);

            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C204_fromD03, errorCount);

        } // for loop end
    }

    private void importC203() throws ModuleException {
        try {
            // queryDS.clear();
            // DBUtil.executeUpdate(queryDS, delete_sql_C203, false);
            deleteC203();
        } catch (Exception e) {
            throw new ModuleException("EPZ1_0100(8-4)�G" + e);
        }
        try {
            queryDS.clear();
            D04toC203();
        } catch (Exception e) {
            errorLog.addErrorLog("EPZ1_0100(15-4)�G", e.getMessage());
            setExitCode(ERROR); // �]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.toString());
            log.debug(e.toString());
            throw new ModuleException("EPZ1_0100(16-4)�G" + e.getMessage());
        }
    }

    private void deleteC203() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_C203);

        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(delete_sql_C203_2);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                buds_Insert_1.setField("INV_YM", STRING.objToStrNoNull(bqds_1.getField("INV_YM")));
                buds_Insert_1.setField("SUB_CPY_ID", (bqds_1.getField("SUB_CPY_ID")));
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object INV_YM = errMap.get("INV_YM");

                errorLog.addErrorLog("DELETE DTEPC203 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "INV_YM="
                        + INV_YM + "]:" + errObject_1[i][2]);

                errorLog.getErrorCountAndWriteErrorMessage();

            }

        } // for loop end
    }

    private void D04toC203() throws Exception {
        bqds_1.clear();
        bqds_1.setConnName("DS_EP");
        searchAndRetrieve(bqds_1, query_sql_D04toC203);
        int inputCount = getInputCount();
        countManager.addCountNumber(INPUT_COUNT_D04_toC203, inputCount); //�]�w��X���
        
        buds_Insert_1.clearBatch();
        buds_Insert_1.setConnName("DS_EP");
        buds_Insert_1.preparedBatch(insert_sql_C203);

        for (prepareFetch(); fetchData(bqds_1); goNext()) {

            while (bqds_1.next()) {
                setDTEPC203_Fields(bqds_1, 1);
                buds_Insert_1.addBatch();
            }

            int buds_INSERT_1_Ret[] = buds_Insert_1.executeBatch();

            Object errObject_1[][] = errorHandler.getErrorArray(buds_Insert_1.getBatchUpdateErrorArray(), buds_INSERT_1_Ret, buds_Insert_1
                    .getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

            //���XaddBatch�������
            int outputCount = buds_INSERT_1_Ret.length;

            //�N��X��Ʀ�����Insert�ɵo�ͪ����~
            outputCount -= errObject_1.length;
            
            countManager.addCountNumber(OUTPUT_COUNT_C203_fromD04, outputCount);
            
            for (int i = 0; i < errObject_1.length; i++) {
                Map errMap = (Map) errObject_1[i][1];

                if (isDebug)
                    log.debug("EPZ1_0100(18)�G" + errObject_1[i][2]);

                Object INV_YM = errMap.get("INV_YM");

                errorLog.addErrorLog("INSERT DTEPC203 " + errObject_1[i][2], "com.cathay.ep.z1.module.EPZ1_0100.INSERT" + "[" + "INV_YM="
                        + INV_YM + "]:" + errObject_1[i][2]);

            }
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            //�������~���
            countManager.addCountNumber(ERROR_COUNT_C203_fromD04, errorCount);

        } // for loop end
    }

    private void setDTEPC101_Fields(BatchQueryDataSet bqds, int ser_no, String oldtable, Set RCV_NO_Set) throws DBException, ModuleException {
        BigDecimal RCV_YM = new BigDecimal(bqds.getField("RCV_YM").toString().trim()).add(BD1911);
        String SUB_CPY_ID = (String) (bqds.getField("SUB_CPY_ID"));
        String PAY_KIND = (String) (bqds.getField("PAY_KIND"));
        String BLD_CD = STRING.objToStrNoNull(bqds.getField("BLD_CD"));
        
        String RCV_NO="";
        if("DTEPC02".equals(oldtable) && "3".equals(PAY_KIND)){//�޲z�O�qC06->C103����
            String PAY_S_DATE = STRING.objToStrNoNull(bqds.getField("PAY_S_DATE")).trim();//�޲z�O�n��ú�O�_�W�@���~��h��C06
            if(StringUtils.isNotBlank(PAY_S_DATE)){
                //Integer rcvym = Integer.parseInt(PAY_S_DATE.replace("-", "").substring(0,6));
                
                String OLD_KEY="";
                
                String SAL_AMT_str = STRING.objToStrNoNull(bqds.getField("SAL_AMT"));
                if(NumberUtils.isNumber(SAL_AMT_str)){
                    SAL_AMT_str = new BigDecimal(SAL_AMT_str).intValue()+"";
                    
                    sb.append(RCV_YM.intValue()).append("@")
                        .append(STRING.objToStrNoNull(BLD_CD).trim()).append("@")
                        .append(STRING.objToStrNoNull(bqds.getField("CRT_NO")).trim()).append("@")
                        .append(STRING.objToStrNoNull(bqds.getField("CUS_NO")).trim()).append("@")
                        .append(STRING.objToStrNoNull(bqds.getField("PAY_S_DATE")).trim()).append("@")
                        .append(SAL_AMT_str);
                    OLD_KEY = sb.toString();
                    sb.setLength(0);
                    RCV_NO = getNEW_KEY("DTEPC06", "DTEPC103", OLD_KEY, query_sql_Z998_2);
                }
                
                if(StringUtils.isBlank(RCV_NO)){
                    sb.append(RCV_YM.intValue()).append("@")
                        .append(STRING.objToStrNoNull(BLD_CD).trim()).append("@")
                        .append(STRING.objToStrNoNull(bqds.getField("CRT_NO")).trim()).append("@")
                        .append(STRING.objToStrNoNull(bqds.getField("CUS_NO")).trim()).append("@")
                        .append(STRING.objToStrNoNull(bqds.getField("PAY_S_DATE")).trim());
                    
                    OLD_KEY = sb.toString();
                    sb.setLength(0);
                    RCV_NO = getNEW_KEY("DTEPC06", "DTEPC103", OLD_KEY, query_sql_Z998_2);
                }
                
                if(StringUtils.isBlank(RCV_NO) || RCV_NO_Set.contains(RCV_NO)){
                    int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "008", "" + RCV_YM.intValue(), PAY_KIND);
                    sb.append(SUB_CPY_ID).append(RCV_YM.intValue()).append(PAY_KIND).append(STRING.fillZero("" + SER_NO, 4));
                    RCV_NO = sb.toString();
                    sb.setLength(0);
                }  
                    
                RCV_NO_Set.add(RCV_NO);
            }else{
                int SER_NO = new EP_Z0Z001().createNextNumber("00", "008", "" + RCV_YM.intValue(), "E_C101");
                sb.append(SUB_CPY_ID).append(RCV_YM.intValue()).append("E").append(STRING.fillZero("" + SER_NO, 4));
                RCV_NO = sb.toString();
                sb.setLength(0);
            }
        }else{
            int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "008", "" + RCV_YM.intValue(), PAY_KIND);
            sb.append(SUB_CPY_ID).append(RCV_YM.intValue()).append(PAY_KIND).append(STRING.fillZero("" + SER_NO, 4));
            RCV_NO = sb.toString();
            sb.setLength(0);
        }

        buds_Insert_1.setField("RCV_NO", RCV_NO);
        buds_Insert_1.setField("SUB_CPY_ID", SUB_CPY_ID);
        buds_Insert_1.setField("RCV_YM", RCV_YM);
        buds_Insert_1.setField("PAY_KIND", PAY_KIND);

        String[] C203col = { "CRT_NO", "CUS_NO", "PAY_S_DATE", "PAY_E_DATE", "ID", "CUS_NAME", "DIV_NO", "BLD_USR_ID", "BLD_USR_NAME",
                "EXT_DATE", "EXT_TYPE", "INV_AMT", "SAL_AMT", "TAX_AMT", "TAX_TYPE", "SPR_AMT", "PASS_DAY", "PRP_S_DATE", "RNT_AMT",
                "PRP_AMT", "PRP_SP_AMT", "RJT_CD", "ACNT_DATE", "ACNT_ID", "ACNT_NAME", "ACNT_DIV_NO", "SLIP_LOT_NO", "SLIP_SET_NO",
                "TURN_ACNT_DATE", "TURN_ID", "TURN_NAME", "TURN_SLPLOT_NO", "TURN_SLPSET_NO", "BDEBT_ACNT_DATE", "BDEBT_ID", "BDEBT_NAME",
                "BDEBT_SLPLOT_NO", "BDEBT_SLPSET_NO", "TRN_KIND", "FLOW_NO", "OP_STATUS", "LST_PROC_DATE", "LST_PROC_ID", "LST_PROC_DIV",
                "LST_PROC_NAME" };
        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }

        

        buds_Insert_1.setField("BLD_CD", BLD_CD);
        buds_Insert_1.setField("PAY_CD", STRING.objToStrNoNull(bqds.getField("PAY_CD")));
        buds_Insert_1.setField("INV_NO", STRING.objToStrNoNull(bqds.getField("INV_NO")));

        String BLD_USR_NAME = STRING.objToStrNoNull(bqds.getField("BLD_USR_NAME")).trim();
        if(nameMap.containsKey(BLD_USR_NAME)){
            buds_Insert_1.setField("BLD_USR_ID", nameMap.get(BLD_USR_NAME));
        }
        
        sb.append(STRING.objToStrNoNull(bqds.getField("RCV_YM")).trim()).append("@").append(PAY_KIND).append("@").append(
            STRING.objToStrNoNull(bqds.getField("CRT_NO")).trim()).append("@")
                .append(STRING.objToStrNoNull(bqds.getField("CUS_NO")).trim()).append("@").append(
                    STRING.objToStrNoNull(bqds.getField("PAY_S_DATE")).trim()).append("@").append(
                    STRING.objToStrNoNull(bqds.getField("PAY_E_DATE")).trim()).append("@").append(
                    STRING.objToStrNoNull(bqds.getField("CETNSKD")).trim()).append("@").append(
                    STRING.objToStrNoNull(bqds.getField("CETNSDT")).trim());
        String OLD_KEY = sb.toString();
        sb.setLength(0);
        buds_Insert_2.setField("OLD_TABLE", oldtable);
        buds_Insert_2.setField("NEW_TABLE", "DTEPC101");
        buds_Insert_2.setField("OLD_KEY", OLD_KEY);
        buds_Insert_2.setField("NEW_KEY", RCV_NO);
        buds_Insert_2.addBatch();

        sb.append(STRING.objToStrNoNull(bqds.getField("RCV_YM")).trim()).append("@").append(PAY_KIND).append("@").append(
            STRING.objToStrNoNull(bqds.getField("CRT_NO")).trim()).append("@").append(
            STRING.objToStrNoNull(bqds.getField("CUS_NO")).trim()).append("@").append(
            STRING.objToStrNoNull(bqds.getField("PAY_S_DATE")).trim()).append("@").append(
            STRING.objToStrNoNull(bqds.getField("PAY_E_DATE")).trim());
        OLD_KEY = sb.toString();
        sb.setLength(0);
        buds_Insert_2.setField("OLD_TABLE", oldtable);
        buds_Insert_2.setField("NEW_TABLE", "DTEPC101");
        buds_Insert_2.setField("OLD_KEY", OLD_KEY);
        buds_Insert_2.setField("NEW_KEY", RCV_NO);
        buds_Insert_2.addBatch();

        sb.append(STRING.objToStrNoNull(bqds.getField("RCV_YM")).trim()).append("@").append(PAY_KIND).append("@").append(
            STRING.objToStrNoNull(bqds.getField("CRT_NO")).trim()).append("@").append(
            STRING.objToStrNoNull(bqds.getField("CUS_NO")).trim()).append("@").append(
            STRING.objToStrNoNull(bqds.getField("INV_NO")).trim());
        OLD_KEY = sb.toString();
        sb.setLength(0);
        buds_Insert_2.setField("OLD_TABLE", oldtable);
        buds_Insert_2.setField("NEW_TABLE", "DTEPC101");
        buds_Insert_2.setField("OLD_KEY", OLD_KEY);
        buds_Insert_2.setField("NEW_KEY", RCV_NO);
        buds_Insert_2.addBatch();
        
        sb.append(STRING.objToStrNoNull(bqds.getField("INV_NO")).trim());
        OLD_KEY = sb.toString();
        if(StringUtils.isNotBlank(OLD_KEY)){
            sb.setLength(0);
            buds_Insert_2.setField("OLD_TABLE", oldtable);
            buds_Insert_2.setField("NEW_TABLE", "DTEPC101");
            buds_Insert_2.setField("OLD_KEY", OLD_KEY);
            buds_Insert_2.setField("NEW_KEY", RCV_NO);
            buds_Insert_2.addBatch();
        }
    }

    private void setDTEPC202_Fields(BatchQueryDataSet bqds, int isnull) throws DBException {
        BigDecimal RCV_YM = new BigDecimal(bqds.getField("RCV_YM").toString().trim()).add(BD1911);
        String[] C203col = { "SUB_CPY_ID", "CRT_NO", "CUS_NO", "PAY_KIND", "CUS_NAME", "ID", "BLD_NAME", "PIN_CODE", "PIN_NAME", "FLD_NO",
                "ROOM_NO", "PRK_NO", "INV_AMT", "SAL_AMT", "TAX_AMT", "TAX_TYPE", "PAY_S_DATE", "PAY_E_DATE", "SLIP_DATE", "SLIP_DIV_NO",
                "INV_CD", "SER_NO", "CHK_NO", "RCV_NO", "DIV_NO", "TRN_KIND", "CHG_DATE", "CHG_DIV_NO", "CHG_ID", "CHG_NAME", "APLY_NO" };

        buds_Insert_1.setField("INV_NO", STRING.objToStrNoNull(bqds.getField("INV_NO")));
        buds_Insert_1.setField("RCV_YM", RCV_YM);
        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }
        String BLD_CD = STRING.objToStrNoNull(bqds.getField("BLD_CD"));
        // if(BLD_CD!=null && !BLD_CD.trim().equals("")){
        // BLD_CD = "0000"+BLD_CD;
        // }
        buds_Insert_1.setField("BLD_CD", BLD_CD);
        String INV_DATE = STRING.objToStrNoNull(bqds.getField("INV_DATE"));
        buds_Insert_1.setField("INV_DATE", ("".equals(INV_DATE)) ? null : INV_DATE);
        Integer SLIP_SEQ_NO = (bqds.getField("SLIP_SEQ_NO") == null || bqds.getField("SLIP_SEQ_NO").toString().trim().equals("")) ? null
                : Integer.parseInt(bqds.getField("SLIP_SEQ_NO").toString().trim());
        buds_Insert_1.setField("SLIP_SEQ_NO", SLIP_SEQ_NO);
        String APLY_DATE = STRING.objToStrNoNull(bqds.getField("APLY_DATE"));
        buds_Insert_1.setField("APLY_DATE", ("".equals(APLY_DATE)) ? null : APLY_DATE);
        String PRT_DATE = STRING.objToStrNoNull(bqds.getField("PRT_DATE"));
        buds_Insert_1.setField("PRT_DATE", ("".equals(PRT_DATE)) ? null : PRT_DATE);
        String D_ACNT_DATE = STRING.objToStrNoNull(bqds.getField("D_ACNT_DATE"));
        buds_Insert_1.setField("D_ACNT_DATE", ("".equals(D_ACNT_DATE)) ? null : D_ACNT_DATE);
        buds_Insert_1.setField("D_ACNT_ID", isnull == 2 ? null : (bqds.getField("D_ACNT_ID")));
        buds_Insert_1.setField("D_ACNT_DIV_NO", isnull == 2 ? null : (bqds.getField("D_ACNT_DIV_NO")));
        buds_Insert_1.setField("D_SLPLOT_NO", isnull == 2 ? null : (bqds.getField("D_SLPLOT_NO")));
        buds_Insert_1.setField("D_SLPSET_NO", isnull == 2 ? null : (bqds.getField("D_SLPSET_NO")));
        String D_CFM_DATE = STRING.objToStrNoNull(bqds.getField("D_CFM_DATE"));
        buds_Insert_1.setField("D_CFM_DATE", ("".equals(D_CFM_DATE)) ? null : D_CFM_DATE);
    }

    private void setDTEPC204_Fields(BatchQueryDataSet bqds, int isnull) throws DBException {
        String RCV_YM_Str = STRING.objToStrNoNull(bqds.getField("RCV_YM"));
        if ("".equals(RCV_YM_Str)) {
            RCV_YM_Str = "0";
        } else {
            RCV_YM_Str = RCV_YM_Str.trim();
        }
        BigDecimal RCV_YM = new BigDecimal(RCV_YM_Str).add(BD1911);
        String[] C203col = { "SER_NO", "SUB_CPY_ID", "CRT_NO", "CUS_NO", "CUS_NAME", "ID", "INV_AMT", "SAL_AMT", "TAX_AMT", "TAX_TYPE",
                "RJT_AMT", "RJT_TAX", "RJT_S_DATE", "RJT_E_DATE", "RJT_RNT_AMT", "RJT_SPR_AMT", "RJT_PRPSP_AMT", "RJT_C104PRP_AMT",
                "R_ACNT_DATE", "R_ACNT_ID", "R_ACNT_NAME", "R_ACNT_DIV_NO", "R_SLPLOT_NO", "R_SLPSET_NO", "R_TRNSER_NO", "PAY_TYPE",
                "ACPT_BANK_NO", "ACPT_ACNT_NO", "ACPT_ACNT_NAME", "ACPT_ID", "RMT_BANK_NO", "RMT_ACNT_NO", "TRN_KIND", "CHG_DATE",
                "CHG_DIV_NO", "CHG_ID", "CHG_NAME" };

        buds_Insert_1.setField("INV_NO", STRING.objToStrNoNull(bqds.getField("INV_NO")));
        buds_Insert_1.setField("RCV_YM", RCV_YM);
        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }
    }

    private void setDTEPC203_Fields(BatchQueryDataSet bqds, int isnull) throws DBException {
        BigDecimal INV_YM = new BigDecimal(bqds.getField("INV_YM").toString().trim()).add(BD1911);
        String[] C203col = { "SUB_CPY_ID", "INV_CD_1", "INV_SNO_1", "INV_ENO_1", "INV_LNO_1", "SEQ_NO_1", "INV_CD_2", "INV_SNO_2",
                "INV_ENO_2", "INV_LNO_2", "SEQ_NO_2" };

        buds_Insert_1.setField("INV_YM", INV_YM);
        for (String colkey : C203col) {
            buds_Insert_1.setField(colkey, (bqds.getField(colkey)));
        }
    }

}
