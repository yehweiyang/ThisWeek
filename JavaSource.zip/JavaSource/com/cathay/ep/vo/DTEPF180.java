package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF180
 * <pre>
 * Generated value object of DBEP.DTEPF180 (��µ�ץ�_��޶O�뵲��)
 * </pre>
 */
public class DTEPF180 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF180";
	
	
	@Column(desc="��ޤ뵲�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String CMM_APLY_NO = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�뵲�~��", nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String CMM_YM = EmptyField.STRING;
	
	@Column(desc="�뵲���", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CMM_CNT = EmptyField.INTEGER;
	
	@Column(desc="�`��µ���B", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer TOT_CLR_AMT = EmptyField.INTEGER;
	
	@Column(desc="��޶O���B", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer TOT_CMM_FEE = EmptyField.INTEGER;
	
	@Column(desc="��޶O���|�B", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer UNTAX_AMT = EmptyField.INTEGER;
	
	@Column(desc="��޶O�|�B", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer TAX_AMT = EmptyField.INTEGER;
	
	@Column(desc="�߮פH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INPUT_ID = EmptyField.STRING;
	
	@Column(desc="�߮׳��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String INPUT_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�߮פ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp INPUT_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�t�ӽs��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String SUP_ID = EmptyField.STRING;
	
	@Column(desc="�t�ӦW��", type=java.sql.Types.VARCHAR, length=160, defaultValue="") 
	private String SUP_NM = EmptyField.STRING;
	
	@Column(desc="�f��y�{�s��", nullAble=false, type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FLOW_NO = EmptyField.STRING;
	
	@Column(desc="�@�~�i��", nullAble=false, type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String OP_STATUS = EmptyField.STRING;
	
	@Column(desc="�дڰO���s��", type=java.sql.Types.VARCHAR, length=11, defaultValue="") 
	private String CASE_NO = EmptyField.STRING;
	
	@Column(desc="�дڤ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date PAY_DATE = EmptyField.DATE;
	
	@Column(desc="�дڽT�{���", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date PAY_CFM_DATE = EmptyField.DATE;
	
	@Column(desc="�|�p�Ю֤��", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp ACC_SECVER_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�@�~�ɶ�", nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp LST_PROC_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�@�~�H��", nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String LST_PROC_ID = EmptyField.STRING;
	
	@Column(desc="�@�~���", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String LST_PROC_DIV = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPF180(){
		// do nothing	
	}
	
	/**
	 * get value of ��ޤ뵲�s��
	 * @return ��ޤ뵲�s��
	 */
	public String getCMM_APLY_NO() {
		if(EmptyField.isEmpty(CMM_APLY_NO)){
			return null;
		}
		return CMM_APLY_NO;
	}

	/**
	 * set value of ��ޤ뵲�s��
	 * @param newCMM_APLY_NO - ��ޤ뵲�s��
	 */
	public void setCMM_APLY_NO(String newCMM_APLY_NO){
		CMM_APLY_NO = newCMM_APLY_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �뵲�~��
	 * @return �뵲�~��
	 */
	public String getCMM_YM() {
		if(EmptyField.isEmpty(CMM_YM)){
			return null;
		}
		return CMM_YM;
	}

	/**
	 * set value of �뵲�~��
	 * @param newCMM_YM - �뵲�~��
	 */
	public void setCMM_YM(String newCMM_YM){
		CMM_YM = newCMM_YM;
	}	
	
	/**
	 * get value of �뵲���
	 * @return �뵲���
	 */
	public Integer getCMM_CNT() {
		if(EmptyField.isEmpty(CMM_CNT)){
			return null;
		}
		return CMM_CNT;
	}

	/**
	 * set value of �뵲���
	 * @param newCMM_CNT - �뵲���
	 */
	public void setCMM_CNT(Integer newCMM_CNT){
		CMM_CNT = newCMM_CNT;
	}	
	
	/**
	 * get value of �`��µ���B
	 * @return �`��µ���B
	 */
	public Integer getTOT_CLR_AMT() {
		if(EmptyField.isEmpty(TOT_CLR_AMT)){
			return null;
		}
		return TOT_CLR_AMT;
	}

	/**
	 * set value of �`��µ���B
	 * @param newTOT_CLR_AMT - �`��µ���B
	 */
	public void setTOT_CLR_AMT(Integer newTOT_CLR_AMT){
		TOT_CLR_AMT = newTOT_CLR_AMT;
	}	
	
	/**
	 * get value of ��޶O���B
	 * @return ��޶O���B
	 */
	public Integer getTOT_CMM_FEE() {
		if(EmptyField.isEmpty(TOT_CMM_FEE)){
			return null;
		}
		return TOT_CMM_FEE;
	}

	/**
	 * set value of ��޶O���B
	 * @param newTOT_CMM_FEE - ��޶O���B
	 */
	public void setTOT_CMM_FEE(Integer newTOT_CMM_FEE){
		TOT_CMM_FEE = newTOT_CMM_FEE;
	}	
	
	/**
	 * get value of ��޶O���|�B
	 * @return ��޶O���|�B
	 */
	public Integer getUNTAX_AMT() {
		if(EmptyField.isEmpty(UNTAX_AMT)){
			return null;
		}
		return UNTAX_AMT;
	}

	/**
	 * set value of ��޶O���|�B
	 * @param newUNTAX_AMT - ��޶O���|�B
	 */
	public void setUNTAX_AMT(Integer newUNTAX_AMT){
		UNTAX_AMT = newUNTAX_AMT;
	}	
	
	/**
	 * get value of ��޶O�|�B
	 * @return ��޶O�|�B
	 */
	public Integer getTAX_AMT() {
		if(EmptyField.isEmpty(TAX_AMT)){
			return null;
		}
		return TAX_AMT;
	}

	/**
	 * set value of ��޶O�|�B
	 * @param newTAX_AMT - ��޶O�|�B
	 */
	public void setTAX_AMT(Integer newTAX_AMT){
		TAX_AMT = newTAX_AMT;
	}	
	
	/**
	 * get value of �߮פH��ID
	 * @return �߮פH��ID
	 */
	public String getINPUT_ID() {
		if(EmptyField.isEmpty(INPUT_ID)){
			return null;
		}
		return INPUT_ID;
	}

	/**
	 * set value of �߮פH��ID
	 * @param newINPUT_ID - �߮פH��ID
	 */
	public void setINPUT_ID(String newINPUT_ID){
		INPUT_ID = newINPUT_ID;
	}	
	
	/**
	 * get value of �߮׳��
	 * @return �߮׳��
	 */
	public String getINPUT_DIV_NO() {
		if(EmptyField.isEmpty(INPUT_DIV_NO)){
			return null;
		}
		return INPUT_DIV_NO;
	}

	/**
	 * set value of �߮׳��
	 * @param newINPUT_DIV_NO - �߮׳��
	 */
	public void setINPUT_DIV_NO(String newINPUT_DIV_NO){
		INPUT_DIV_NO = newINPUT_DIV_NO;
	}	
	
	/**
	 * get value of �߮פ���ɶ�
	 * @return �߮פ���ɶ�
	 */
	public java.sql.Timestamp getINPUT_DATE() {
		if(EmptyField.isEmpty(INPUT_DATE)){
			return null;
		}
		return INPUT_DATE;
	}

	/**
	 * set value of �߮פ���ɶ�
	 * @param newINPUT_DATE - �߮פ���ɶ�
	 */
	public void setINPUT_DATE(java.sql.Timestamp newINPUT_DATE){
		INPUT_DATE = newINPUT_DATE;
	}	
	
	/**
	 * get value of �t�ӽs��
	 * @return �t�ӽs��
	 */
	public String getSUP_ID() {
		if(EmptyField.isEmpty(SUP_ID)){
			return null;
		}
		return SUP_ID;
	}

	/**
	 * set value of �t�ӽs��
	 * @param newSUP_ID - �t�ӽs��
	 */
	public void setSUP_ID(String newSUP_ID){
		SUP_ID = newSUP_ID;
	}	
	
	/**
	 * get value of �t�ӦW��
	 * @return �t�ӦW��
	 */
	public String getSUP_NM() {
		if(EmptyField.isEmpty(SUP_NM)){
			return null;
		}
		return SUP_NM;
	}

	/**
	 * set value of �t�ӦW��
	 * @param newSUP_NM - �t�ӦW��
	 */
	public void setSUP_NM(String newSUP_NM){
		SUP_NM = newSUP_NM;
	}	
	
	/**
	 * get value of �f��y�{�s��
	 * @return �f��y�{�s��
	 */
	public String getFLOW_NO() {
		if(EmptyField.isEmpty(FLOW_NO)){
			return null;
		}
		return FLOW_NO;
	}

	/**
	 * set value of �f��y�{�s��
	 * @param newFLOW_NO - �f��y�{�s��
	 */
	public void setFLOW_NO(String newFLOW_NO){
		FLOW_NO = newFLOW_NO;
	}	
	
	/**
	 * get value of �@�~�i��
	 * @return �@�~�i��
	 */
	public String getOP_STATUS() {
		if(EmptyField.isEmpty(OP_STATUS)){
			return null;
		}
		return OP_STATUS;
	}

	/**
	 * set value of �@�~�i��
	 * @param newOP_STATUS - �@�~�i��
	 */
	public void setOP_STATUS(String newOP_STATUS){
		OP_STATUS = newOP_STATUS;
	}	
	
	/**
	 * get value of �дڰO���s��
	 * @return �дڰO���s��
	 */
	public String getCASE_NO() {
		if(EmptyField.isEmpty(CASE_NO)){
			return null;
		}
		return CASE_NO;
	}

	/**
	 * set value of �дڰO���s��
	 * @param newCASE_NO - �дڰO���s��
	 */
	public void setCASE_NO(String newCASE_NO){
		CASE_NO = newCASE_NO;
	}	
	
	/**
	 * get value of �дڤ��
	 * @return �дڤ��
	 */
	public java.sql.Date getPAY_DATE() {
		if(EmptyField.isEmpty(PAY_DATE)){
			return null;
		}
		return PAY_DATE;
	}

	/**
	 * set value of �дڤ��
	 * @param newPAY_DATE - �дڤ��
	 */
	public void setPAY_DATE(java.sql.Date newPAY_DATE){
		PAY_DATE = newPAY_DATE;
	}	
	
	/**
	 * get value of �дڽT�{���
	 * @return �дڽT�{���
	 */
	public java.sql.Date getPAY_CFM_DATE() {
		if(EmptyField.isEmpty(PAY_CFM_DATE)){
			return null;
		}
		return PAY_CFM_DATE;
	}

	/**
	 * set value of �дڽT�{���
	 * @param newPAY_CFM_DATE - �дڽT�{���
	 */
	public void setPAY_CFM_DATE(java.sql.Date newPAY_CFM_DATE){
		PAY_CFM_DATE = newPAY_CFM_DATE;
	}	
	
	/**
	 * get value of �|�p�Ю֤��
	 * @return �|�p�Ю֤��
	 */
	public java.sql.Timestamp getACC_SECVER_DATE() {
		if(EmptyField.isEmpty(ACC_SECVER_DATE)){
			return null;
		}
		return ACC_SECVER_DATE;
	}

	/**
	 * set value of �|�p�Ю֤��
	 * @param newACC_SECVER_DATE - �|�p�Ю֤��
	 */
	public void setACC_SECVER_DATE(java.sql.Timestamp newACC_SECVER_DATE){
		ACC_SECVER_DATE = newACC_SECVER_DATE;
	}	
	
	/**
	 * get value of �@�~�ɶ�
	 * @return �@�~�ɶ�
	 */
	public java.sql.Timestamp getLST_PROC_DATE() {
		if(EmptyField.isEmpty(LST_PROC_DATE)){
			return null;
		}
		return LST_PROC_DATE;
	}

	/**
	 * set value of �@�~�ɶ�
	 * @param newLST_PROC_DATE - �@�~�ɶ�
	 */
	public void setLST_PROC_DATE(java.sql.Timestamp newLST_PROC_DATE){
		LST_PROC_DATE = newLST_PROC_DATE;
	}	
	
	/**
	 * get value of �@�~�H��
	 * @return �@�~�H��
	 */
	public String getLST_PROC_ID() {
		if(EmptyField.isEmpty(LST_PROC_ID)){
			return null;
		}
		return LST_PROC_ID;
	}

	/**
	 * set value of �@�~�H��
	 * @param newLST_PROC_ID - �@�~�H��
	 */
	public void setLST_PROC_ID(String newLST_PROC_ID){
		LST_PROC_ID = newLST_PROC_ID;
	}	
	
	/**
	 * get value of �@�~���
	 * @return �@�~���
	 */
	public String getLST_PROC_DIV() {
		if(EmptyField.isEmpty(LST_PROC_DIV)){
			return null;
		}
		return LST_PROC_DIV;
	}

	/**
	 * set value of �@�~���
	 * @param newLST_PROC_DIV - �@�~���
	 */
	public void setLST_PROC_DIV(String newLST_PROC_DIV){
		LST_PROC_DIV = newLST_PROC_DIV;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(CMM_APLY_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CMM_YM);
		hcBuilder.append(CMM_CNT);
		hcBuilder.append(TOT_CLR_AMT);
		hcBuilder.append(TOT_CMM_FEE);
		hcBuilder.append(UNTAX_AMT);
		hcBuilder.append(TAX_AMT);
		hcBuilder.append(INPUT_ID);
		hcBuilder.append(INPUT_DIV_NO);
		hcBuilder.append(INPUT_DATE);
		hcBuilder.append(SUP_ID);
		hcBuilder.append(SUP_NM);
		hcBuilder.append(FLOW_NO);
		hcBuilder.append(OP_STATUS);
		hcBuilder.append(CASE_NO);
		hcBuilder.append(PAY_DATE);
		hcBuilder.append(PAY_CFM_DATE);
		hcBuilder.append(ACC_SECVER_DATE);
		hcBuilder.append(LST_PROC_DATE);
		hcBuilder.append(LST_PROC_ID);
		hcBuilder.append(LST_PROC_DIV);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF180)){
			return false;
		}
        
		DTEPF180 theObj = (DTEPF180)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				