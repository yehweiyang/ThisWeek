package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPA105
 * <pre>
 * Generated value object of DBEP.DTEPA105 (�j��_����C�L����)
 * </pre>
 */
public class DTEPA105 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPA105";
	
	
	@Column(desc="�C�L�~��", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer PRT_YR = EmptyField.INTEGER;
	
	@Column(desc="�j�ӥN��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="����N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String PRK_NO = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�C�L�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String PRT_NO = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String DATA_TYPE = EmptyField.STRING;
	
	@Column(desc="�ϥΪ̦W��", type=java.sql.Types.VARCHAR, length=60, defaultValue="") 
	private String USR_NAME = EmptyField.STRING;
	
	@Column(desc="���Ĵ���", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date EFF_DATE = EmptyField.DATE;
	
	@Column(desc="�����N��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�����Ҫ��A", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String PRK_STS = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPA105(){
		// do nothing	
	}
	
	/**
	 * get value of �C�L�~��
	 * @return �C�L�~��
	 */
	public Integer getPRT_YR() {
		if(EmptyField.isEmpty(PRT_YR)){
			return null;
		}
		return PRT_YR;
	}

	/**
	 * set value of �C�L�~��
	 * @param newPRT_YR - �C�L�~��
	 */
	public void setPRT_YR(Integer newPRT_YR){
		PRT_YR = newPRT_YR;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of ����N��
	 * @return ����N��
	 */
	public String getPRK_NO() {
		if(EmptyField.isEmpty(PRK_NO)){
			return null;
		}
		return PRK_NO;
	}

	/**
	 * set value of ����N��
	 * @param newPRK_NO - ����N��
	 */
	public void setPRK_NO(String newPRK_NO){
		PRK_NO = newPRK_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �C�L�Ǹ�
	 * @return �C�L�Ǹ�
	 */
	public String getPRT_NO() {
		if(EmptyField.isEmpty(PRT_NO)){
			return null;
		}
		return PRT_NO;
	}

	/**
	 * set value of �C�L�Ǹ�
	 * @param newPRT_NO - �C�L�Ǹ�
	 */
	public void setPRT_NO(String newPRT_NO){
		PRT_NO = newPRT_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getDATA_TYPE() {
		if(EmptyField.isEmpty(DATA_TYPE)){
			return null;
		}
		return DATA_TYPE;
	}

	/**
	 * set value of �������
	 * @param newDATA_TYPE - �������
	 */
	public void setDATA_TYPE(String newDATA_TYPE){
		DATA_TYPE = newDATA_TYPE;
	}	
	
	/**
	 * get value of �ϥΪ̦W��
	 * @return �ϥΪ̦W��
	 */
	public String getUSR_NAME() {
		if(EmptyField.isEmpty(USR_NAME)){
			return null;
		}
		return USR_NAME;
	}

	/**
	 * set value of �ϥΪ̦W��
	 * @param newUSR_NAME - �ϥΪ̦W��
	 */
	public void setUSR_NAME(String newUSR_NAME){
		USR_NAME = newUSR_NAME;
	}	
	
	/**
	 * get value of ���Ĵ���
	 * @return ���Ĵ���
	 */
	public java.sql.Date getEFF_DATE() {
		if(EmptyField.isEmpty(EFF_DATE)){
			return null;
		}
		return EFF_DATE;
	}

	/**
	 * set value of ���Ĵ���
	 * @param newEFF_DATE - ���Ĵ���
	 */
	public void setEFF_DATE(java.sql.Date newEFF_DATE){
		EFF_DATE = newEFF_DATE;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �����Ҫ��A
	 * @return �����Ҫ��A
	 */
	public String getPRK_STS() {
		if(EmptyField.isEmpty(PRK_STS)){
			return null;
		}
		return PRK_STS;
	}

	/**
	 * set value of �����Ҫ��A
	 * @param newPRK_STS - �����Ҫ��A
	 */
	public void setPRK_STS(String newPRK_STS){
		PRK_STS = newPRK_STS;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(PRT_YR);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(PRK_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(PRT_NO);
		hcBuilder.append(DATA_TYPE);
		hcBuilder.append(USR_NAME);
		hcBuilder.append(EFF_DATE);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(PRK_STS);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPA105)){
			return false;
		}
        
		DTEPA105 theObj = (DTEPA105)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				