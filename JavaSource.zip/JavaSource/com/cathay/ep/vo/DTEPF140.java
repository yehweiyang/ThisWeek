package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF140
 * <pre>
 * Generated value object of DBEP.DTEPF140 (��µ�ץ�_�������R��)
 * </pre>
 */
public class DTEPF140 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF140";
	
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�Ƨѿ��渹", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer MEMO_NO = EmptyField.INTEGER;
	
	@Column(desc="�u�اǸ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer PRO_NO = EmptyField.INTEGER;
	
	@Column(desc="��µ�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer PRT_NO = EmptyField.INTEGER;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="���ƥN�X", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String MAT_ID = EmptyField.STRING;
	
	@Column(desc="���ƫ~�W", type=java.sql.Types.VARCHAR, length=900, defaultValue="") 
	private String MAT_NM = EmptyField.STRING;
	
	@Column(desc="���Ƽƶq", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CNT = EmptyField.INTEGER;
	
	@Column(desc="���Ƴ��", type=java.sql.Types.VARCHAR, length=15, defaultValue="") 
	private String UNIT = EmptyField.STRING;
	
	@Column(desc="���Ƴ��", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer PRICE = EmptyField.INTEGER;
	
	@Column(desc="���B", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer EST_AMT = EmptyField.INTEGER;
	
	/**
	 * Default constructor
	 */
	public DTEPF140(){
		// do nothing	
	}
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �Ƨѿ��渹
	 * @return �Ƨѿ��渹
	 */
	public Integer getMEMO_NO() {
		if(EmptyField.isEmpty(MEMO_NO)){
			return null;
		}
		return MEMO_NO;
	}

	/**
	 * set value of �Ƨѿ��渹
	 * @param newMEMO_NO - �Ƨѿ��渹
	 */
	public void setMEMO_NO(Integer newMEMO_NO){
		MEMO_NO = newMEMO_NO;
	}	
	
	/**
	 * get value of �u�اǸ�
	 * @return �u�اǸ�
	 */
	public Integer getPRO_NO() {
		if(EmptyField.isEmpty(PRO_NO)){
			return null;
		}
		return PRO_NO;
	}

	/**
	 * set value of �u�اǸ�
	 * @param newPRO_NO - �u�اǸ�
	 */
	public void setPRO_NO(Integer newPRO_NO){
		PRO_NO = newPRO_NO;
	}	
	
	/**
	 * get value of ��µ�Ǹ�
	 * @return ��µ�Ǹ�
	 */
	public Integer getPRT_NO() {
		if(EmptyField.isEmpty(PRT_NO)){
			return null;
		}
		return PRT_NO;
	}

	/**
	 * set value of ��µ�Ǹ�
	 * @param newPRT_NO - ��µ�Ǹ�
	 */
	public void setPRT_NO(Integer newPRT_NO){
		PRT_NO = newPRT_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ���ƥN�X
	 * @return ���ƥN�X
	 */
	public String getMAT_ID() {
		if(EmptyField.isEmpty(MAT_ID)){
			return null;
		}
		return MAT_ID;
	}

	/**
	 * set value of ���ƥN�X
	 * @param newMAT_ID - ���ƥN�X
	 */
	public void setMAT_ID(String newMAT_ID){
		MAT_ID = newMAT_ID;
	}	
	
	/**
	 * get value of ���ƫ~�W
	 * @return ���ƫ~�W
	 */
	public String getMAT_NM() {
		if(EmptyField.isEmpty(MAT_NM)){
			return null;
		}
		return MAT_NM;
	}

	/**
	 * set value of ���ƫ~�W
	 * @param newMAT_NM - ���ƫ~�W
	 */
	public void setMAT_NM(String newMAT_NM){
		MAT_NM = newMAT_NM;
	}	
	
	/**
	 * get value of ���Ƽƶq
	 * @return ���Ƽƶq
	 */
	public Integer getCNT() {
		if(EmptyField.isEmpty(CNT)){
			return null;
		}
		return CNT;
	}

	/**
	 * set value of ���Ƽƶq
	 * @param newCNT - ���Ƽƶq
	 */
	public void setCNT(Integer newCNT){
		CNT = newCNT;
	}	
	
	/**
	 * get value of ���Ƴ��
	 * @return ���Ƴ��
	 */
	public String getUNIT() {
		if(EmptyField.isEmpty(UNIT)){
			return null;
		}
		return UNIT;
	}

	/**
	 * set value of ���Ƴ��
	 * @param newUNIT - ���Ƴ��
	 */
	public void setUNIT(String newUNIT){
		UNIT = newUNIT;
	}	
	
	/**
	 * get value of ���Ƴ��
	 * @return ���Ƴ��
	 */
	public Integer getPRICE() {
		if(EmptyField.isEmpty(PRICE)){
			return null;
		}
		return PRICE;
	}

	/**
	 * set value of ���Ƴ��
	 * @param newPRICE - ���Ƴ��
	 */
	public void setPRICE(Integer newPRICE){
		PRICE = newPRICE;
	}	
	
	/**
	 * get value of ���B
	 * @return ���B
	 */
	public Integer getEST_AMT() {
		if(EmptyField.isEmpty(EST_AMT)){
			return null;
		}
		return EST_AMT;
	}

	/**
	 * set value of ���B
	 * @param newEST_AMT - ���B
	 */
	public void setEST_AMT(Integer newEST_AMT){
		EST_AMT = newEST_AMT;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(APLY_NO);
		hcBuilder.append(MEMO_NO);
		hcBuilder.append(PRO_NO);
		hcBuilder.append(PRT_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(MAT_ID);
		hcBuilder.append(MAT_NM);
		hcBuilder.append(CNT);
		hcBuilder.append(UNIT);
		hcBuilder.append(PRICE);
		hcBuilder.append(EST_AMT);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF140)){
			return false;
		}
        
		DTEPF140 theObj = (DTEPF140)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				