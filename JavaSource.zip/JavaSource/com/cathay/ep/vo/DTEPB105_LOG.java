package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPB105_LOG
 * <pre>
 * Generated value object of DBEP.DTEPB105_LOG (����_�կ��]�w��LOG)
 * </pre>
 */
public class DTEPB105_LOG implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPB105_LOG";
	
	
	@Column(desc="�J�ɤ���ɶ�", pk=true, nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp UPD_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�����N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�կ��_��", pk=true, nullAble=false, type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ADJ_RNT_SDATE = EmptyField.DATE;
	
	@Column(desc="�կ�����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ADJ_RNT_EDATE = EmptyField.DATE;
	
	@Column(desc="�կ�����", type=java.sql.Types.DECIMAL, length=15, defaultValue="") 
	private java.math.BigDecimal ADJ_UNIT_NUM = EmptyField.BIGDECIMAL;
	
	@Column(desc="�կ����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ADJ_UNIT = EmptyField.STRING;
	
	@Column(desc="�O�_�H�u�կ�", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String IS_MAN_ADJ = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	@Column(desc="�J�ɮץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String UPD_APLY_NO = EmptyField.STRING;
	
	@Column(desc="�J�ɥ������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String UPD_TRN_KIND = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPB105_LOG(){
		// do nothing	
	}
	
	/**
	 * get value of �J�ɤ���ɶ�
	 * @return �J�ɤ���ɶ�
	 */
	public java.sql.Timestamp getUPD_DATE() {
		if(EmptyField.isEmpty(UPD_DATE)){
			return null;
		}
		return UPD_DATE;
	}

	/**
	 * set value of �J�ɤ���ɶ�
	 * @param newUPD_DATE - �J�ɤ���ɶ�
	 */
	public void setUPD_DATE(java.sql.Timestamp newUPD_DATE){
		UPD_DATE = newUPD_DATE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �կ��_��
	 * @return �կ��_��
	 */
	public java.sql.Date getADJ_RNT_SDATE() {
		if(EmptyField.isEmpty(ADJ_RNT_SDATE)){
			return null;
		}
		return ADJ_RNT_SDATE;
	}

	/**
	 * set value of �կ��_��
	 * @param newADJ_RNT_SDATE - �կ��_��
	 */
	public void setADJ_RNT_SDATE(java.sql.Date newADJ_RNT_SDATE){
		ADJ_RNT_SDATE = newADJ_RNT_SDATE;
	}	
	
	/**
	 * get value of �կ�����
	 * @return �կ�����
	 */
	public java.sql.Date getADJ_RNT_EDATE() {
		if(EmptyField.isEmpty(ADJ_RNT_EDATE)){
			return null;
		}
		return ADJ_RNT_EDATE;
	}

	/**
	 * set value of �կ�����
	 * @param newADJ_RNT_EDATE - �կ�����
	 */
	public void setADJ_RNT_EDATE(java.sql.Date newADJ_RNT_EDATE){
		ADJ_RNT_EDATE = newADJ_RNT_EDATE;
	}	
	
	/**
	 * get value of �կ�����
	 * @return �կ�����
	 */
	public java.math.BigDecimal getADJ_UNIT_NUM() {
		if(EmptyField.isEmpty(ADJ_UNIT_NUM)){
			return null;
		}
		return ADJ_UNIT_NUM;
	}

	/**
	 * set value of �կ�����
	 * @param newADJ_UNIT_NUM - �կ�����
	 */
	public void setADJ_UNIT_NUM(java.math.BigDecimal newADJ_UNIT_NUM){
		ADJ_UNIT_NUM = newADJ_UNIT_NUM;
	}	
	
	/**
	 * get value of �կ����
	 * @return �կ����
	 */
	public String getADJ_UNIT() {
		if(EmptyField.isEmpty(ADJ_UNIT)){
			return null;
		}
		return ADJ_UNIT;
	}

	/**
	 * set value of �կ����
	 * @param newADJ_UNIT - �կ����
	 */
	public void setADJ_UNIT(String newADJ_UNIT){
		ADJ_UNIT = newADJ_UNIT;
	}	
	
	/**
	 * get value of �O�_�H�u�կ�
	 * @return �O�_�H�u�կ�
	 */
	public String getIS_MAN_ADJ() {
		if(EmptyField.isEmpty(IS_MAN_ADJ)){
			return null;
		}
		return IS_MAN_ADJ;
	}

	/**
	 * set value of �O�_�H�u�կ�
	 * @param newIS_MAN_ADJ - �O�_�H�u�կ�
	 */
	public void setIS_MAN_ADJ(String newIS_MAN_ADJ){
		IS_MAN_ADJ = newIS_MAN_ADJ;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * get value of �J�ɮץ�s��
	 * @return �J�ɮץ�s��
	 */
	public String getUPD_APLY_NO() {
		if(EmptyField.isEmpty(UPD_APLY_NO)){
			return null;
		}
		return UPD_APLY_NO;
	}

	/**
	 * set value of �J�ɮץ�s��
	 * @param newUPD_APLY_NO - �J�ɮץ�s��
	 */
	public void setUPD_APLY_NO(String newUPD_APLY_NO){
		UPD_APLY_NO = newUPD_APLY_NO;
	}	
	
	/**
	 * get value of �J�ɥ������
	 * @return �J�ɥ������
	 */
	public String getUPD_TRN_KIND() {
		if(EmptyField.isEmpty(UPD_TRN_KIND)){
			return null;
		}
		return UPD_TRN_KIND;
	}

	/**
	 * set value of �J�ɥ������
	 * @param newUPD_TRN_KIND - �J�ɥ������
	 */
	public void setUPD_TRN_KIND(String newUPD_TRN_KIND){
		UPD_TRN_KIND = newUPD_TRN_KIND;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(UPD_DATE);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(ADJ_RNT_SDATE);
		hcBuilder.append(ADJ_RNT_EDATE);
		hcBuilder.append(ADJ_UNIT_NUM);
		hcBuilder.append(ADJ_UNIT);
		hcBuilder.append(IS_MAN_ADJ);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(TRN_KIND);
		hcBuilder.append(UPD_APLY_NO);
		hcBuilder.append(UPD_TRN_KIND);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPB105_LOG)){
			return false;
		}
        
		DTEPB105_LOG theObj = (DTEPB105_LOG)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				