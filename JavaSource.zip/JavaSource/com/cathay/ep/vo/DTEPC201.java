package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC201
 * <pre>
 * Generated value object of DBEP.DTEPC201 (�㯲������)
 * </pre>
 */
public class DTEPC201 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC201";
	
	
	@Column(desc="�㯲���s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String INT_NO = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�p���~��", type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal INT_YM = EmptyField.BIGDECIMAL;
	
	@Column(desc="�����N��", type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="ú�O�s��", type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String PAY_NO = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�ӿ���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ҥ󸹽X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ID = EmptyField.STRING;
	
	@Column(desc="�Ȥ�W��", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String CUS_NAME = EmptyField.STRING;
	
	@Column(desc="�p���_��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date PMI_S_DATE = EmptyField.DATE;
	
	@Column(desc="�p���פ�", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date PMI_E_DATE = EmptyField.DATE;
	
	@Column(desc="�g�L�Ѽ�", type=java.sql.Types.DECIMAL, length=5, defaultValue="") 
	private java.math.BigDecimal PASS_DAY = EmptyField.BIGDECIMAL;
	
	@Column(desc="������B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PMS_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�㮧�Q�v�N��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String RAT_CD = EmptyField.STRING;
	
	@Column(desc="�㯲����Q�v", type=java.sql.Types.DECIMAL, length=13, defaultValue="") 
	private java.math.BigDecimal PIM_RATE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�㯲�����B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PMI_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�㯲���|�B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PMI_TAX = EmptyField.BIGDECIMAL;
	
	@Column(desc="�o�����X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INV_NO = EmptyField.STRING;
	
	@Column(desc="�o�����B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal INV_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�|�O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String TAX_TYPE = EmptyField.STRING;
	
	@Column(desc="�b�Ȥ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ACNT_DATE = EmptyField.DATE;
	
	@Column(desc="�b�ȤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACNT_ID = EmptyField.STRING;
	
	@Column(desc="�b�ȽT�{�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String ACNT_NAME = EmptyField.STRING;
	
	@Column(desc="�b�ȳ��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACNT_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��帹", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String SLIP_LOT_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��ո�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SLIP_SET_NO = EmptyField.INTEGER;
	
	@Column(desc="�f��y�{�s��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FLOW_NO = EmptyField.STRING;
	
	@Column(desc="�@�~�i��", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer OP_STATUS = EmptyField.INTEGER;
	
	@Column(desc="�@�~�ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp LST_PROC_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�@�~�H��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String LST_PROC_ID = EmptyField.STRING;
	
	@Column(desc="�@�~���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String LST_PROC_DIV = EmptyField.STRING;
	
	@Column(desc="�@�~�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String LST_PROC_NAME = EmptyField.STRING;
	
	@Column(desc="�����s��", type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String RCV_NO = EmptyField.STRING;
	
	@Column(desc="��X���", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date SWP_DATE = EmptyField.DATE;
	
	@Column(desc="��X�e������B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal ORN_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�g�����Ǹ�", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal TRN_SER_NO = EmptyField.BIGDECIMAL;
	
	@Column(desc="�o�����I�覡", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String INV_TRANS_TYPE = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPC201(){
		// do nothing	
	}
	
	/**
	 * get value of �㯲���s��
	 * @return �㯲���s��
	 */
	public String getINT_NO() {
		if(EmptyField.isEmpty(INT_NO)){
			return null;
		}
		return INT_NO;
	}

	/**
	 * set value of �㯲���s��
	 * @param newINT_NO - �㯲���s��
	 */
	public void setINT_NO(String newINT_NO){
		INT_NO = newINT_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �p���~��
	 * @return �p���~��
	 */
	public java.math.BigDecimal getINT_YM() {
		if(EmptyField.isEmpty(INT_YM)){
			return null;
		}
		return INT_YM;
	}

	/**
	 * set value of �p���~��
	 * @param newINT_YM - �p���~��
	 */
	public void setINT_YM(java.math.BigDecimal newINT_YM){
		INT_YM = newINT_YM;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of ú�O�s��
	 * @return ú�O�s��
	 */
	public String getPAY_NO() {
		if(EmptyField.isEmpty(PAY_NO)){
			return null;
		}
		return PAY_NO;
	}

	/**
	 * set value of ú�O�s��
	 * @param newPAY_NO - ú�O�s��
	 */
	public void setPAY_NO(String newPAY_NO){
		PAY_NO = newPAY_NO;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �ӿ���
	 * @return �ӿ���
	 */
	public String getDIV_NO() {
		if(EmptyField.isEmpty(DIV_NO)){
			return null;
		}
		return DIV_NO;
	}

	/**
	 * set value of �ӿ���
	 * @param newDIV_NO - �ӿ���
	 */
	public void setDIV_NO(String newDIV_NO){
		DIV_NO = newDIV_NO;
	}	
	
	/**
	 * get value of �ҥ󸹽X
	 * @return �ҥ󸹽X
	 */
	public String getID() {
		if(EmptyField.isEmpty(ID)){
			return null;
		}
		return ID;
	}

	/**
	 * set value of �ҥ󸹽X
	 * @param newID - �ҥ󸹽X
	 */
	public void setID(String newID){
		ID = newID;
	}	
	
	/**
	 * get value of �Ȥ�W��
	 * @return �Ȥ�W��
	 */
	public String getCUS_NAME() {
		if(EmptyField.isEmpty(CUS_NAME)){
			return null;
		}
		return CUS_NAME;
	}

	/**
	 * set value of �Ȥ�W��
	 * @param newCUS_NAME - �Ȥ�W��
	 */
	public void setCUS_NAME(String newCUS_NAME){
		CUS_NAME = newCUS_NAME;
	}	
	
	/**
	 * get value of �p���_��
	 * @return �p���_��
	 */
	public java.sql.Date getPMI_S_DATE() {
		if(EmptyField.isEmpty(PMI_S_DATE)){
			return null;
		}
		return PMI_S_DATE;
	}

	/**
	 * set value of �p���_��
	 * @param newPMI_S_DATE - �p���_��
	 */
	public void setPMI_S_DATE(java.sql.Date newPMI_S_DATE){
		PMI_S_DATE = newPMI_S_DATE;
	}	
	
	/**
	 * get value of �p���פ�
	 * @return �p���פ�
	 */
	public java.sql.Date getPMI_E_DATE() {
		if(EmptyField.isEmpty(PMI_E_DATE)){
			return null;
		}
		return PMI_E_DATE;
	}

	/**
	 * set value of �p���פ�
	 * @param newPMI_E_DATE - �p���פ�
	 */
	public void setPMI_E_DATE(java.sql.Date newPMI_E_DATE){
		PMI_E_DATE = newPMI_E_DATE;
	}	
	
	/**
	 * get value of �g�L�Ѽ�
	 * @return �g�L�Ѽ�
	 */
	public java.math.BigDecimal getPASS_DAY() {
		if(EmptyField.isEmpty(PASS_DAY)){
			return null;
		}
		return PASS_DAY;
	}

	/**
	 * set value of �g�L�Ѽ�
	 * @param newPASS_DAY - �g�L�Ѽ�
	 */
	public void setPASS_DAY(java.math.BigDecimal newPASS_DAY){
		PASS_DAY = newPASS_DAY;
	}	
	
	/**
	 * get value of ������B
	 * @return ������B
	 */
	public java.math.BigDecimal getPMS_AMT() {
		if(EmptyField.isEmpty(PMS_AMT)){
			return null;
		}
		return PMS_AMT;
	}

	/**
	 * set value of ������B
	 * @param newPMS_AMT - ������B
	 */
	public void setPMS_AMT(java.math.BigDecimal newPMS_AMT){
		PMS_AMT = newPMS_AMT;
	}	
	
	/**
	 * get value of �㮧�Q�v�N��
	 * @return �㮧�Q�v�N��
	 */
	public String getRAT_CD() {
		if(EmptyField.isEmpty(RAT_CD)){
			return null;
		}
		return RAT_CD;
	}

	/**
	 * set value of �㮧�Q�v�N��
	 * @param newRAT_CD - �㮧�Q�v�N��
	 */
	public void setRAT_CD(String newRAT_CD){
		RAT_CD = newRAT_CD;
	}	
	
	/**
	 * get value of �㯲����Q�v
	 * @return �㯲����Q�v
	 */
	public java.math.BigDecimal getPIM_RATE() {
		if(EmptyField.isEmpty(PIM_RATE)){
			return null;
		}
		return PIM_RATE;
	}

	/**
	 * set value of �㯲����Q�v
	 * @param newPIM_RATE - �㯲����Q�v
	 */
	public void setPIM_RATE(java.math.BigDecimal newPIM_RATE){
		PIM_RATE = newPIM_RATE;
	}	
	
	/**
	 * get value of �㯲�����B
	 * @return �㯲�����B
	 */
	public java.math.BigDecimal getPMI_AMT() {
		if(EmptyField.isEmpty(PMI_AMT)){
			return null;
		}
		return PMI_AMT;
	}

	/**
	 * set value of �㯲�����B
	 * @param newPMI_AMT - �㯲�����B
	 */
	public void setPMI_AMT(java.math.BigDecimal newPMI_AMT){
		PMI_AMT = newPMI_AMT;
	}	
	
	/**
	 * get value of �㯲���|�B
	 * @return �㯲���|�B
	 */
	public java.math.BigDecimal getPMI_TAX() {
		if(EmptyField.isEmpty(PMI_TAX)){
			return null;
		}
		return PMI_TAX;
	}

	/**
	 * set value of �㯲���|�B
	 * @param newPMI_TAX - �㯲���|�B
	 */
	public void setPMI_TAX(java.math.BigDecimal newPMI_TAX){
		PMI_TAX = newPMI_TAX;
	}	
	
	/**
	 * get value of �o�����X
	 * @return �o�����X
	 */
	public String getINV_NO() {
		if(EmptyField.isEmpty(INV_NO)){
			return null;
		}
		return INV_NO;
	}

	/**
	 * set value of �o�����X
	 * @param newINV_NO - �o�����X
	 */
	public void setINV_NO(String newINV_NO){
		INV_NO = newINV_NO;
	}	
	
	/**
	 * get value of �o�����B
	 * @return �o�����B
	 */
	public java.math.BigDecimal getINV_AMT() {
		if(EmptyField.isEmpty(INV_AMT)){
			return null;
		}
		return INV_AMT;
	}

	/**
	 * set value of �o�����B
	 * @param newINV_AMT - �o�����B
	 */
	public void setINV_AMT(java.math.BigDecimal newINV_AMT){
		INV_AMT = newINV_AMT;
	}	
	
	/**
	 * get value of �|�O
	 * @return �|�O
	 */
	public String getTAX_TYPE() {
		if(EmptyField.isEmpty(TAX_TYPE)){
			return null;
		}
		return TAX_TYPE;
	}

	/**
	 * set value of �|�O
	 * @param newTAX_TYPE - �|�O
	 */
	public void setTAX_TYPE(String newTAX_TYPE){
		TAX_TYPE = newTAX_TYPE;
	}	
	
	/**
	 * get value of �b�Ȥ��
	 * @return �b�Ȥ��
	 */
	public java.sql.Date getACNT_DATE() {
		if(EmptyField.isEmpty(ACNT_DATE)){
			return null;
		}
		return ACNT_DATE;
	}

	/**
	 * set value of �b�Ȥ��
	 * @param newACNT_DATE - �b�Ȥ��
	 */
	public void setACNT_DATE(java.sql.Date newACNT_DATE){
		ACNT_DATE = newACNT_DATE;
	}	
	
	/**
	 * get value of �b�ȤH��ID
	 * @return �b�ȤH��ID
	 */
	public String getACNT_ID() {
		if(EmptyField.isEmpty(ACNT_ID)){
			return null;
		}
		return ACNT_ID;
	}

	/**
	 * set value of �b�ȤH��ID
	 * @param newACNT_ID - �b�ȤH��ID
	 */
	public void setACNT_ID(String newACNT_ID){
		ACNT_ID = newACNT_ID;
	}	
	
	/**
	 * get value of �b�ȽT�{�H���m�W
	 * @return �b�ȽT�{�H���m�W
	 */
	public String getACNT_NAME() {
		if(EmptyField.isEmpty(ACNT_NAME)){
			return null;
		}
		return ACNT_NAME;
	}

	/**
	 * set value of �b�ȽT�{�H���m�W
	 * @param newACNT_NAME - �b�ȽT�{�H���m�W
	 */
	public void setACNT_NAME(String newACNT_NAME){
		ACNT_NAME = newACNT_NAME;
	}	
	
	/**
	 * get value of �b�ȳ��
	 * @return �b�ȳ��
	 */
	public String getACNT_DIV_NO() {
		if(EmptyField.isEmpty(ACNT_DIV_NO)){
			return null;
		}
		return ACNT_DIV_NO;
	}

	/**
	 * set value of �b�ȳ��
	 * @param newACNT_DIV_NO - �b�ȳ��
	 */
	public void setACNT_DIV_NO(String newACNT_DIV_NO){
		ACNT_DIV_NO = newACNT_DIV_NO;
	}	
	
	/**
	 * get value of �ǲ��帹
	 * @return �ǲ��帹
	 */
	public String getSLIP_LOT_NO() {
		if(EmptyField.isEmpty(SLIP_LOT_NO)){
			return null;
		}
		return SLIP_LOT_NO;
	}

	/**
	 * set value of �ǲ��帹
	 * @param newSLIP_LOT_NO - �ǲ��帹
	 */
	public void setSLIP_LOT_NO(String newSLIP_LOT_NO){
		SLIP_LOT_NO = newSLIP_LOT_NO;
	}	
	
	/**
	 * get value of �ǲ��ո�
	 * @return �ǲ��ո�
	 */
	public Integer getSLIP_SET_NO() {
		if(EmptyField.isEmpty(SLIP_SET_NO)){
			return null;
		}
		return SLIP_SET_NO;
	}

	/**
	 * set value of �ǲ��ո�
	 * @param newSLIP_SET_NO - �ǲ��ո�
	 */
	public void setSLIP_SET_NO(Integer newSLIP_SET_NO){
		SLIP_SET_NO = newSLIP_SET_NO;
	}	
	
	/**
	 * get value of �f��y�{�s��
	 * @return �f��y�{�s��
	 */
	public String getFLOW_NO() {
		if(EmptyField.isEmpty(FLOW_NO)){
			return null;
		}
		return FLOW_NO;
	}

	/**
	 * set value of �f��y�{�s��
	 * @param newFLOW_NO - �f��y�{�s��
	 */
	public void setFLOW_NO(String newFLOW_NO){
		FLOW_NO = newFLOW_NO;
	}	
	
	/**
	 * get value of �@�~�i��
	 * @return �@�~�i��
	 */
	public Integer getOP_STATUS() {
		if(EmptyField.isEmpty(OP_STATUS)){
			return null;
		}
		return OP_STATUS;
	}

	/**
	 * set value of �@�~�i��
	 * @param newOP_STATUS - �@�~�i��
	 */
	public void setOP_STATUS(Integer newOP_STATUS){
		OP_STATUS = newOP_STATUS;
	}	
	
	/**
	 * get value of �@�~�ɶ�
	 * @return �@�~�ɶ�
	 */
	public java.sql.Timestamp getLST_PROC_DATE() {
		if(EmptyField.isEmpty(LST_PROC_DATE)){
			return null;
		}
		return LST_PROC_DATE;
	}

	/**
	 * set value of �@�~�ɶ�
	 * @param newLST_PROC_DATE - �@�~�ɶ�
	 */
	public void setLST_PROC_DATE(java.sql.Timestamp newLST_PROC_DATE){
		LST_PROC_DATE = newLST_PROC_DATE;
	}	
	
	/**
	 * get value of �@�~�H��
	 * @return �@�~�H��
	 */
	public String getLST_PROC_ID() {
		if(EmptyField.isEmpty(LST_PROC_ID)){
			return null;
		}
		return LST_PROC_ID;
	}

	/**
	 * set value of �@�~�H��
	 * @param newLST_PROC_ID - �@�~�H��
	 */
	public void setLST_PROC_ID(String newLST_PROC_ID){
		LST_PROC_ID = newLST_PROC_ID;
	}	
	
	/**
	 * get value of �@�~���
	 * @return �@�~���
	 */
	public String getLST_PROC_DIV() {
		if(EmptyField.isEmpty(LST_PROC_DIV)){
			return null;
		}
		return LST_PROC_DIV;
	}

	/**
	 * set value of �@�~���
	 * @param newLST_PROC_DIV - �@�~���
	 */
	public void setLST_PROC_DIV(String newLST_PROC_DIV){
		LST_PROC_DIV = newLST_PROC_DIV;
	}	
	
	/**
	 * get value of �@�~�H���m�W
	 * @return �@�~�H���m�W
	 */
	public String getLST_PROC_NAME() {
		if(EmptyField.isEmpty(LST_PROC_NAME)){
			return null;
		}
		return LST_PROC_NAME;
	}

	/**
	 * set value of �@�~�H���m�W
	 * @param newLST_PROC_NAME - �@�~�H���m�W
	 */
	public void setLST_PROC_NAME(String newLST_PROC_NAME){
		LST_PROC_NAME = newLST_PROC_NAME;
	}	
	
	/**
	 * get value of �����s��
	 * @return �����s��
	 */
	public String getRCV_NO() {
		if(EmptyField.isEmpty(RCV_NO)){
			return null;
		}
		return RCV_NO;
	}

	/**
	 * set value of �����s��
	 * @param newRCV_NO - �����s��
	 */
	public void setRCV_NO(String newRCV_NO){
		RCV_NO = newRCV_NO;
	}	
	
	/**
	 * get value of ��X���
	 * @return ��X���
	 */
	public java.sql.Date getSWP_DATE() {
		if(EmptyField.isEmpty(SWP_DATE)){
			return null;
		}
		return SWP_DATE;
	}

	/**
	 * set value of ��X���
	 * @param newSWP_DATE - ��X���
	 */
	public void setSWP_DATE(java.sql.Date newSWP_DATE){
		SWP_DATE = newSWP_DATE;
	}	
	
	/**
	 * get value of ��X�e������B
	 * @return ��X�e������B
	 */
	public java.math.BigDecimal getORN_AMT() {
		if(EmptyField.isEmpty(ORN_AMT)){
			return null;
		}
		return ORN_AMT;
	}

	/**
	 * set value of ��X�e������B
	 * @param newORN_AMT - ��X�e������B
	 */
	public void setORN_AMT(java.math.BigDecimal newORN_AMT){
		ORN_AMT = newORN_AMT;
	}	
	
	/**
	 * get value of �g�����Ǹ�
	 * @return �g�����Ǹ�
	 */
	public java.math.BigDecimal getTRN_SER_NO() {
		if(EmptyField.isEmpty(TRN_SER_NO)){
			return null;
		}
		return TRN_SER_NO;
	}

	/**
	 * set value of �g�����Ǹ�
	 * @param newTRN_SER_NO - �g�����Ǹ�
	 */
	public void setTRN_SER_NO(java.math.BigDecimal newTRN_SER_NO){
		TRN_SER_NO = newTRN_SER_NO;
	}	
	
	/**
	 * get value of �o�����I�覡
	 * @return �o�����I�覡
	 */
	public String getINV_TRANS_TYPE() {
		if(EmptyField.isEmpty(INV_TRANS_TYPE)){
			return null;
		}
		return INV_TRANS_TYPE;
	}

	/**
	 * set value of �o�����I�覡
	 * @param newINV_TRANS_TYPE - �o�����I�覡
	 */
	public void setINV_TRANS_TYPE(String newINV_TRANS_TYPE){
		INV_TRANS_TYPE = newINV_TRANS_TYPE;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(INT_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(INT_YM);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(PAY_NO);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(DIV_NO);
		hcBuilder.append(ID);
		hcBuilder.append(CUS_NAME);
		hcBuilder.append(PMI_S_DATE);
		hcBuilder.append(PMI_E_DATE);
		hcBuilder.append(PASS_DAY);
		hcBuilder.append(PMS_AMT);
		hcBuilder.append(RAT_CD);
		hcBuilder.append(PIM_RATE);
		hcBuilder.append(PMI_AMT);
		hcBuilder.append(PMI_TAX);
		hcBuilder.append(INV_NO);
		hcBuilder.append(INV_AMT);
		hcBuilder.append(TAX_TYPE);
		hcBuilder.append(ACNT_DATE);
		hcBuilder.append(ACNT_ID);
		hcBuilder.append(ACNT_NAME);
		hcBuilder.append(ACNT_DIV_NO);
		hcBuilder.append(SLIP_LOT_NO);
		hcBuilder.append(SLIP_SET_NO);
		hcBuilder.append(FLOW_NO);
		hcBuilder.append(OP_STATUS);
		hcBuilder.append(LST_PROC_DATE);
		hcBuilder.append(LST_PROC_ID);
		hcBuilder.append(LST_PROC_DIV);
		hcBuilder.append(LST_PROC_NAME);
		hcBuilder.append(RCV_NO);
		hcBuilder.append(SWP_DATE);
		hcBuilder.append(ORN_AMT);
		hcBuilder.append(TRN_SER_NO);
		hcBuilder.append(INV_TRANS_TYPE);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC201)){
			return false;
		}
        
		DTEPC201 theObj = (DTEPC201)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				