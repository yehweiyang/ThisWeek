package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF191
 * <pre>
 * Generated value object of DBEP.DTEPF191 (�j�ӳ]�ƺ��װO����)
 * </pre>
 */
public class DTEPF191 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF191";
	
	
	@Column(desc="�]�ƽs��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String EQP_ID = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�y����", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SER_NO = EmptyField.INTEGER;
	
	@Column(desc="�G�ٴy�z", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String MEMO = EmptyField.STRING;
	
	@Column(desc="���ת��B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal FIX_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���פ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date FIX_DATE = EmptyField.DATE;
	
	/**
	 * Default constructor
	 */
	public DTEPF191(){
		// do nothing	
	}
	
	/**
	 * get value of �]�ƽs��
	 * @return �]�ƽs��
	 */
	public String getEQP_ID() {
		if(EmptyField.isEmpty(EQP_ID)){
			return null;
		}
		return EQP_ID;
	}

	/**
	 * set value of �]�ƽs��
	 * @param newEQP_ID - �]�ƽs��
	 */
	public void setEQP_ID(String newEQP_ID){
		EQP_ID = newEQP_ID;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �y����
	 * @return �y����
	 */
	public Integer getSER_NO() {
		if(EmptyField.isEmpty(SER_NO)){
			return null;
		}
		return SER_NO;
	}

	/**
	 * set value of �y����
	 * @param newSER_NO - �y����
	 */
	public void setSER_NO(Integer newSER_NO){
		SER_NO = newSER_NO;
	}	
	
	/**
	 * get value of �G�ٴy�z
	 * @return �G�ٴy�z
	 */
	public String getMEMO() {
		if(EmptyField.isEmpty(MEMO)){
			return null;
		}
		return MEMO;
	}

	/**
	 * set value of �G�ٴy�z
	 * @param newMEMO - �G�ٴy�z
	 */
	public void setMEMO(String newMEMO){
		MEMO = newMEMO;
	}	
	
	/**
	 * get value of ���ת��B
	 * @return ���ת��B
	 */
	public java.math.BigDecimal getFIX_AMT() {
		if(EmptyField.isEmpty(FIX_AMT)){
			return null;
		}
		return FIX_AMT;
	}

	/**
	 * set value of ���ת��B
	 * @param newFIX_AMT - ���ת��B
	 */
	public void setFIX_AMT(java.math.BigDecimal newFIX_AMT){
		FIX_AMT = newFIX_AMT;
	}	
	
	/**
	 * get value of ���פ��
	 * @return ���פ��
	 */
	public java.sql.Date getFIX_DATE() {
		if(EmptyField.isEmpty(FIX_DATE)){
			return null;
		}
		return FIX_DATE;
	}

	/**
	 * set value of ���פ��
	 * @param newFIX_DATE - ���פ��
	 */
	public void setFIX_DATE(java.sql.Date newFIX_DATE){
		FIX_DATE = newFIX_DATE;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(EQP_ID);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(SER_NO);
		hcBuilder.append(MEMO);
		hcBuilder.append(FIX_AMT);
		hcBuilder.append(FIX_DATE);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF191)){
			return false;
		}
        
		DTEPF191 theObj = (DTEPF191)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				