package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPB108
 * <pre>
 * Generated value object of DBEP.DTEPB108 (����_�k�������Y��)
 * </pre>
 */
public class DTEPB108 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPB108";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�s�էǸ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer GRP_NO = EmptyField.INTEGER;
	
	@Column(desc="�����N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�«����N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String PRE_CRT_NO = EmptyField.STRING;
	
	@Column(desc="ñ�����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date CRT_DATE = EmptyField.DATE;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPB108(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �s�էǸ�
	 * @return �s�էǸ�
	 */
	public Integer getGRP_NO() {
		if(EmptyField.isEmpty(GRP_NO)){
			return null;
		}
		return GRP_NO;
	}

	/**
	 * set value of �s�էǸ�
	 * @param newGRP_NO - �s�էǸ�
	 */
	public void setGRP_NO(Integer newGRP_NO){
		GRP_NO = newGRP_NO;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �«����N��
	 * @return �«����N��
	 */
	public String getPRE_CRT_NO() {
		if(EmptyField.isEmpty(PRE_CRT_NO)){
			return null;
		}
		return PRE_CRT_NO;
	}

	/**
	 * set value of �«����N��
	 * @param newPRE_CRT_NO - �«����N��
	 */
	public void setPRE_CRT_NO(String newPRE_CRT_NO){
		PRE_CRT_NO = newPRE_CRT_NO;
	}	
	
	/**
	 * get value of ñ�����
	 * @return ñ�����
	 */
	public java.sql.Date getCRT_DATE() {
		if(EmptyField.isEmpty(CRT_DATE)){
			return null;
		}
		return CRT_DATE;
	}

	/**
	 * set value of ñ�����
	 * @param newCRT_DATE - ñ�����
	 */
	public void setCRT_DATE(java.sql.Date newCRT_DATE){
		CRT_DATE = newCRT_DATE;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(GRP_NO);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(PRE_CRT_NO);
		hcBuilder.append(CRT_DATE);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(TRN_KIND);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPB108)){
			return false;
		}
        
		DTEPB108 theObj = (DTEPB108)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				