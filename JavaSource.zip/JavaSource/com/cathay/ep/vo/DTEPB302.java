package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPB302
 * <pre>
 * Generated value object of DBEP.DTEPB302 ()
 * </pre>
 */
public class DTEPB302 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPB302";
	
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�������", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String DATA_TYPE = EmptyField.STRING;
	
	@Column(desc="�����N��", type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="ñ�����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date CRT_DATE = EmptyField.DATE;
	
	@Column(desc="�������p", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String CRT_STS = EmptyField.STRING;
	
	@Column(desc="ú�O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String PAY_FREQ = EmptyField.STRING;
	
	@Column(desc="�|�O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String TAX_TYPE = EmptyField.STRING;
	
	@Column(desc="���Y�O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String RLT_CD = EmptyField.STRING;
	
	@Column(desc="�ӯ��`�W��", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal RNT_TOT_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�`�믲��", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal RNT_TOT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�կ�����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ADJ_TYPE = EmptyField.STRING;
	
	@Column(desc="�`���", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PMS_TOT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�թ����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ADJ_PM = EmptyField.STRING;
	
	@Column(desc="�Q�v�N��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String RATE_CD = EmptyField.STRING;
	
	@Column(desc="�ӯ��Ȥ��", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer RNT_CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="���z�ӷ�", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String CASE_TYPE = EmptyField.STRING;
	
	@Column(desc="�O�_�������s����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String IS_REP_CRT = EmptyField.STRING;
	
	@Column(desc="���o����", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal COST_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���O", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String CURR = EmptyField.STRING;
	
	@Column(desc="�p�q���", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String UNIT = EmptyField.STRING;
	
	@Column(desc="�ӯ��O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String RNT_TYPE = EmptyField.STRING;
	
	@Column(desc="�K�|�Ҹ�", type=java.sql.Types.VARCHAR, length=45, defaultValue="") 
	private String TAX_FREE_CD = EmptyField.STRING;
	
	@Column(desc="�������O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String CRT_TYPE = EmptyField.STRING;
	
	@Column(desc="�ɮ׽s��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FILE_NO = EmptyField.STRING;
	
	@Column(desc="ñ���ӿ�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CRT_RESP_NAME = EmptyField.STRING;
	
	@Column(desc="�O�_�e�����Ʒ|", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String IS_BOARD = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPB302(){
		// do nothing	
	}
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getDATA_TYPE() {
		if(EmptyField.isEmpty(DATA_TYPE)){
			return null;
		}
		return DATA_TYPE;
	}

	/**
	 * set value of �������
	 * @param newDATA_TYPE - �������
	 */
	public void setDATA_TYPE(String newDATA_TYPE){
		DATA_TYPE = newDATA_TYPE;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of ñ�����
	 * @return ñ�����
	 */
	public java.sql.Date getCRT_DATE() {
		if(EmptyField.isEmpty(CRT_DATE)){
			return null;
		}
		return CRT_DATE;
	}

	/**
	 * set value of ñ�����
	 * @param newCRT_DATE - ñ�����
	 */
	public void setCRT_DATE(java.sql.Date newCRT_DATE){
		CRT_DATE = newCRT_DATE;
	}	
	
	/**
	 * get value of �������p
	 * @return �������p
	 */
	public String getCRT_STS() {
		if(EmptyField.isEmpty(CRT_STS)){
			return null;
		}
		return CRT_STS;
	}

	/**
	 * set value of �������p
	 * @param newCRT_STS - �������p
	 */
	public void setCRT_STS(String newCRT_STS){
		CRT_STS = newCRT_STS;
	}	
	
	/**
	 * get value of ú�O
	 * @return ú�O
	 */
	public String getPAY_FREQ() {
		if(EmptyField.isEmpty(PAY_FREQ)){
			return null;
		}
		return PAY_FREQ;
	}

	/**
	 * set value of ú�O
	 * @param newPAY_FREQ - ú�O
	 */
	public void setPAY_FREQ(String newPAY_FREQ){
		PAY_FREQ = newPAY_FREQ;
	}	
	
	/**
	 * get value of �|�O
	 * @return �|�O
	 */
	public String getTAX_TYPE() {
		if(EmptyField.isEmpty(TAX_TYPE)){
			return null;
		}
		return TAX_TYPE;
	}

	/**
	 * set value of �|�O
	 * @param newTAX_TYPE - �|�O
	 */
	public void setTAX_TYPE(String newTAX_TYPE){
		TAX_TYPE = newTAX_TYPE;
	}	
	
	/**
	 * get value of ���Y�O
	 * @return ���Y�O
	 */
	public String getRLT_CD() {
		if(EmptyField.isEmpty(RLT_CD)){
			return null;
		}
		return RLT_CD;
	}

	/**
	 * set value of ���Y�O
	 * @param newRLT_CD - ���Y�O
	 */
	public void setRLT_CD(String newRLT_CD){
		RLT_CD = newRLT_CD;
	}	
	
	/**
	 * get value of �ӯ��`�W��
	 * @return �ӯ��`�W��
	 */
	public java.math.BigDecimal getRNT_TOT_SIZE() {
		if(EmptyField.isEmpty(RNT_TOT_SIZE)){
			return null;
		}
		return RNT_TOT_SIZE;
	}

	/**
	 * set value of �ӯ��`�W��
	 * @param newRNT_TOT_SIZE - �ӯ��`�W��
	 */
	public void setRNT_TOT_SIZE(java.math.BigDecimal newRNT_TOT_SIZE){
		RNT_TOT_SIZE = newRNT_TOT_SIZE;
	}	
	
	/**
	 * get value of �`�믲��
	 * @return �`�믲��
	 */
	public java.math.BigDecimal getRNT_TOT_AMT() {
		if(EmptyField.isEmpty(RNT_TOT_AMT)){
			return null;
		}
		return RNT_TOT_AMT;
	}

	/**
	 * set value of �`�믲��
	 * @param newRNT_TOT_AMT - �`�믲��
	 */
	public void setRNT_TOT_AMT(java.math.BigDecimal newRNT_TOT_AMT){
		RNT_TOT_AMT = newRNT_TOT_AMT;
	}	
	
	/**
	 * get value of �կ�����
	 * @return �կ�����
	 */
	public String getADJ_TYPE() {
		if(EmptyField.isEmpty(ADJ_TYPE)){
			return null;
		}
		return ADJ_TYPE;
	}

	/**
	 * set value of �կ�����
	 * @param newADJ_TYPE - �կ�����
	 */
	public void setADJ_TYPE(String newADJ_TYPE){
		ADJ_TYPE = newADJ_TYPE;
	}	
	
	/**
	 * get value of �`���
	 * @return �`���
	 */
	public java.math.BigDecimal getPMS_TOT_AMT() {
		if(EmptyField.isEmpty(PMS_TOT_AMT)){
			return null;
		}
		return PMS_TOT_AMT;
	}

	/**
	 * set value of �`���
	 * @param newPMS_TOT_AMT - �`���
	 */
	public void setPMS_TOT_AMT(java.math.BigDecimal newPMS_TOT_AMT){
		PMS_TOT_AMT = newPMS_TOT_AMT;
	}	
	
	/**
	 * get value of �թ����
	 * @return �թ����
	 */
	public String getADJ_PM() {
		if(EmptyField.isEmpty(ADJ_PM)){
			return null;
		}
		return ADJ_PM;
	}

	/**
	 * set value of �թ����
	 * @param newADJ_PM - �թ����
	 */
	public void setADJ_PM(String newADJ_PM){
		ADJ_PM = newADJ_PM;
	}	
	
	/**
	 * get value of �Q�v�N��
	 * @return �Q�v�N��
	 */
	public String getRATE_CD() {
		if(EmptyField.isEmpty(RATE_CD)){
			return null;
		}
		return RATE_CD;
	}

	/**
	 * set value of �Q�v�N��
	 * @param newRATE_CD - �Q�v�N��
	 */
	public void setRATE_CD(String newRATE_CD){
		RATE_CD = newRATE_CD;
	}	
	
	/**
	 * get value of �ӯ��Ȥ��
	 * @return �ӯ��Ȥ��
	 */
	public Integer getRNT_CUS_NO() {
		if(EmptyField.isEmpty(RNT_CUS_NO)){
			return null;
		}
		return RNT_CUS_NO;
	}

	/**
	 * set value of �ӯ��Ȥ��
	 * @param newRNT_CUS_NO - �ӯ��Ȥ��
	 */
	public void setRNT_CUS_NO(Integer newRNT_CUS_NO){
		RNT_CUS_NO = newRNT_CUS_NO;
	}	
	
	/**
	 * get value of ���z�ӷ�
	 * @return ���z�ӷ�
	 */
	public String getCASE_TYPE() {
		if(EmptyField.isEmpty(CASE_TYPE)){
			return null;
		}
		return CASE_TYPE;
	}

	/**
	 * set value of ���z�ӷ�
	 * @param newCASE_TYPE - ���z�ӷ�
	 */
	public void setCASE_TYPE(String newCASE_TYPE){
		CASE_TYPE = newCASE_TYPE;
	}	
	
	/**
	 * get value of �O�_�������s����
	 * @return �O�_�������s����
	 */
	public String getIS_REP_CRT() {
		if(EmptyField.isEmpty(IS_REP_CRT)){
			return null;
		}
		return IS_REP_CRT;
	}

	/**
	 * set value of �O�_�������s����
	 * @param newIS_REP_CRT - �O�_�������s����
	 */
	public void setIS_REP_CRT(String newIS_REP_CRT){
		IS_REP_CRT = newIS_REP_CRT;
	}	
	
	/**
	 * get value of ���o����
	 * @return ���o����
	 */
	public java.math.BigDecimal getCOST_AMT() {
		if(EmptyField.isEmpty(COST_AMT)){
			return null;
		}
		return COST_AMT;
	}

	/**
	 * set value of ���o����
	 * @param newCOST_AMT - ���o����
	 */
	public void setCOST_AMT(java.math.BigDecimal newCOST_AMT){
		COST_AMT = newCOST_AMT;
	}	
	
	/**
	 * get value of ���O
	 * @return ���O
	 */
	public String getCURR() {
		if(EmptyField.isEmpty(CURR)){
			return null;
		}
		return CURR;
	}

	/**
	 * set value of ���O
	 * @param newCURR - ���O
	 */
	public void setCURR(String newCURR){
		CURR = newCURR;
	}	
	
	/**
	 * get value of �p�q���
	 * @return �p�q���
	 */
	public String getUNIT() {
		if(EmptyField.isEmpty(UNIT)){
			return null;
		}
		return UNIT;
	}

	/**
	 * set value of �p�q���
	 * @param newUNIT - �p�q���
	 */
	public void setUNIT(String newUNIT){
		UNIT = newUNIT;
	}	
	
	/**
	 * get value of �ӯ��O
	 * @return �ӯ��O
	 */
	public String getRNT_TYPE() {
		if(EmptyField.isEmpty(RNT_TYPE)){
			return null;
		}
		return RNT_TYPE;
	}

	/**
	 * set value of �ӯ��O
	 * @param newRNT_TYPE - �ӯ��O
	 */
	public void setRNT_TYPE(String newRNT_TYPE){
		RNT_TYPE = newRNT_TYPE;
	}	
	
	/**
	 * get value of �K�|�Ҹ�
	 * @return �K�|�Ҹ�
	 */
	public String getTAX_FREE_CD() {
		if(EmptyField.isEmpty(TAX_FREE_CD)){
			return null;
		}
		return TAX_FREE_CD;
	}

	/**
	 * set value of �K�|�Ҹ�
	 * @param newTAX_FREE_CD - �K�|�Ҹ�
	 */
	public void setTAX_FREE_CD(String newTAX_FREE_CD){
		TAX_FREE_CD = newTAX_FREE_CD;
	}	
	
	/**
	 * get value of �������O
	 * @return �������O
	 */
	public String getCRT_TYPE() {
		if(EmptyField.isEmpty(CRT_TYPE)){
			return null;
		}
		return CRT_TYPE;
	}

	/**
	 * set value of �������O
	 * @param newCRT_TYPE - �������O
	 */
	public void setCRT_TYPE(String newCRT_TYPE){
		CRT_TYPE = newCRT_TYPE;
	}	
	
	/**
	 * get value of �ɮ׽s��
	 * @return �ɮ׽s��
	 */
	public String getFILE_NO() {
		if(EmptyField.isEmpty(FILE_NO)){
			return null;
		}
		return FILE_NO;
	}

	/**
	 * set value of �ɮ׽s��
	 * @param newFILE_NO - �ɮ׽s��
	 */
	public void setFILE_NO(String newFILE_NO){
		FILE_NO = newFILE_NO;
	}	
	
	/**
	 * get value of ñ���ӿ�H���m�W
	 * @return ñ���ӿ�H���m�W
	 */
	public String getCRT_RESP_NAME() {
		if(EmptyField.isEmpty(CRT_RESP_NAME)){
			return null;
		}
		return CRT_RESP_NAME;
	}

	/**
	 * set value of ñ���ӿ�H���m�W
	 * @param newCRT_RESP_NAME - ñ���ӿ�H���m�W
	 */
	public void setCRT_RESP_NAME(String newCRT_RESP_NAME){
		CRT_RESP_NAME = newCRT_RESP_NAME;
	}	
	
	/**
	 * get value of �O�_�e�����Ʒ|
	 * @return �O�_�e�����Ʒ|
	 */
	public String getIS_BOARD() {
		if(EmptyField.isEmpty(IS_BOARD)){
			return null;
		}
		return IS_BOARD;
	}

	/**
	 * set value of �O�_�e�����Ʒ|
	 * @param newIS_BOARD - �O�_�e�����Ʒ|
	 */
	public void setIS_BOARD(String newIS_BOARD){
		IS_BOARD = newIS_BOARD;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(APLY_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(DATA_TYPE);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(CRT_DATE);
		hcBuilder.append(CRT_STS);
		hcBuilder.append(PAY_FREQ);
		hcBuilder.append(TAX_TYPE);
		hcBuilder.append(RLT_CD);
		hcBuilder.append(RNT_TOT_SIZE);
		hcBuilder.append(RNT_TOT_AMT);
		hcBuilder.append(ADJ_TYPE);
		hcBuilder.append(PMS_TOT_AMT);
		hcBuilder.append(ADJ_PM);
		hcBuilder.append(RATE_CD);
		hcBuilder.append(RNT_CUS_NO);
		hcBuilder.append(CASE_TYPE);
		hcBuilder.append(IS_REP_CRT);
		hcBuilder.append(COST_AMT);
		hcBuilder.append(CURR);
		hcBuilder.append(UNIT);
		hcBuilder.append(RNT_TYPE);
		hcBuilder.append(TAX_FREE_CD);
		hcBuilder.append(CRT_TYPE);
		hcBuilder.append(FILE_NO);
		hcBuilder.append(CRT_RESP_NAME);
		hcBuilder.append(IS_BOARD);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPB302)){
			return false;
		}
        
		DTEPB302 theObj = (DTEPB302)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				