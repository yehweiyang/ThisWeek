package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPB309
 * <pre>
 * Generated value object of DBEP.DTEPB309 (�ץ�_�j�ӼӼh�ܧ����)
 * </pre>
 */
public class DTEPB309 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPB309";
	
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�ץ�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String APLY_SER_NO = EmptyField.STRING;
	
	@Column(desc="�������", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String DATA_TYPE = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�Ӽh�O", nullAble=false, type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String FLD_NO = EmptyField.STRING;
	
	@Column(desc="�Ӽh�`���n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal FLD_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="���]��", type=java.sql.Types.DECIMAL, length=5, defaultValue="") 
	private java.math.BigDecimal PBL_RATE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�C��쩳��", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal AVG_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�C������", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal CLR_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�n�O�γ~", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String FLD_TYPE = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPB309(){
		// do nothing	
	}
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �ץ�Ǹ�
	 * @return �ץ�Ǹ�
	 */
	public String getAPLY_SER_NO() {
		if(EmptyField.isEmpty(APLY_SER_NO)){
			return null;
		}
		return APLY_SER_NO;
	}

	/**
	 * set value of �ץ�Ǹ�
	 * @param newAPLY_SER_NO - �ץ�Ǹ�
	 */
	public void setAPLY_SER_NO(String newAPLY_SER_NO){
		APLY_SER_NO = newAPLY_SER_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getDATA_TYPE() {
		if(EmptyField.isEmpty(DATA_TYPE)){
			return null;
		}
		return DATA_TYPE;
	}

	/**
	 * set value of �������
	 * @param newDATA_TYPE - �������
	 */
	public void setDATA_TYPE(String newDATA_TYPE){
		DATA_TYPE = newDATA_TYPE;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �Ӽh�O
	 * @return �Ӽh�O
	 */
	public String getFLD_NO() {
		if(EmptyField.isEmpty(FLD_NO)){
			return null;
		}
		return FLD_NO;
	}

	/**
	 * set value of �Ӽh�O
	 * @param newFLD_NO - �Ӽh�O
	 */
	public void setFLD_NO(String newFLD_NO){
		FLD_NO = newFLD_NO;
	}	
	
	/**
	 * get value of �Ӽh�`���n
	 * @return �Ӽh�`���n
	 */
	public java.math.BigDecimal getFLD_SIZE() {
		if(EmptyField.isEmpty(FLD_SIZE)){
			return null;
		}
		return FLD_SIZE;
	}

	/**
	 * set value of �Ӽh�`���n
	 * @param newFLD_SIZE - �Ӽh�`���n
	 */
	public void setFLD_SIZE(java.math.BigDecimal newFLD_SIZE){
		FLD_SIZE = newFLD_SIZE;
	}	
	
	/**
	 * get value of ���]��
	 * @return ���]��
	 */
	public java.math.BigDecimal getPBL_RATE() {
		if(EmptyField.isEmpty(PBL_RATE)){
			return null;
		}
		return PBL_RATE;
	}

	/**
	 * set value of ���]��
	 * @param newPBL_RATE - ���]��
	 */
	public void setPBL_RATE(java.math.BigDecimal newPBL_RATE){
		PBL_RATE = newPBL_RATE;
	}	
	
	/**
	 * get value of �C��쩳��
	 * @return �C��쩳��
	 */
	public java.math.BigDecimal getAVG_AMT() {
		if(EmptyField.isEmpty(AVG_AMT)){
			return null;
		}
		return AVG_AMT;
	}

	/**
	 * set value of �C��쩳��
	 * @param newAVG_AMT - �C��쩳��
	 */
	public void setAVG_AMT(java.math.BigDecimal newAVG_AMT){
		AVG_AMT = newAVG_AMT;
	}	
	
	/**
	 * get value of �C������
	 * @return �C������
	 */
	public java.math.BigDecimal getCLR_AMT() {
		if(EmptyField.isEmpty(CLR_AMT)){
			return null;
		}
		return CLR_AMT;
	}

	/**
	 * set value of �C������
	 * @param newCLR_AMT - �C������
	 */
	public void setCLR_AMT(java.math.BigDecimal newCLR_AMT){
		CLR_AMT = newCLR_AMT;
	}	
	
	/**
	 * get value of �n�O�γ~
	 * @return �n�O�γ~
	 */
	public String getFLD_TYPE() {
		if(EmptyField.isEmpty(FLD_TYPE)){
			return null;
		}
		return FLD_TYPE;
	}

	/**
	 * set value of �n�O�γ~
	 * @param newFLD_TYPE - �n�O�γ~
	 */
	public void setFLD_TYPE(String newFLD_TYPE){
		FLD_TYPE = newFLD_TYPE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(APLY_NO);
		hcBuilder.append(APLY_SER_NO);
		hcBuilder.append(DATA_TYPE);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(FLD_NO);
		hcBuilder.append(FLD_SIZE);
		hcBuilder.append(PBL_RATE);
		hcBuilder.append(AVG_AMT);
		hcBuilder.append(CLR_AMT);
		hcBuilder.append(FLD_TYPE);
		hcBuilder.append(SUB_CPY_ID);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPB309)){
			return false;
		}
        
		DTEPB309 theObj = (DTEPB309)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				