package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF190
 * <pre>
 * Generated value object of DBEP.DTEPF190 (�j�ӳ]�Ƴ]�w��)
 * </pre>
 */
public class DTEPF190 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF190";
	
	
	@Column(desc="�]�ƽs��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String EQP_ID = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�j�ӦW��", nullAble=false, type=java.sql.Types.VARCHAR, length=45, defaultValue="") 
	private String BLD_NM = EmptyField.STRING;
	
	@Column(desc="�]�ƺ���(�j��)", nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String EQP_CD = EmptyField.STRING;
	
	@Column(desc="�]�ƺ���(����)", nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_EQP_CD = EmptyField.STRING;
	
	@Column(desc="�]�ƺ���(�W��X)", nullAble=false, type=java.sql.Types.VARCHAR, length=4, defaultValue="") 
	private String CODE = EmptyField.STRING;
	
	@Column(desc="�]�ƧǸ�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer EQP_NO = EmptyField.INTEGER;
	
	@Column(desc="�y����", nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SER_NO = EmptyField.INTEGER;
	
	@Column(desc="�t�P", type=java.sql.Types.VARCHAR, length=60, defaultValue="") 
	private String EQP_LB = EmptyField.STRING;
	
	@Column(desc="��t����", type=java.sql.Types.VARCHAR, length=100, defaultValue="") 
	private String EQP_MD = EmptyField.STRING;
	
	@Column(desc="�X�t�~��", type=java.sql.Types.VARCHAR, length=4, defaultValue="") 
	private String EQP_YR = EmptyField.STRING;
	
	@Column(desc="�]�Ʀ�m(�Ӽh)", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String EQP_FR = EmptyField.STRING;
	
	@Column(desc="����(1)/�L��(0)", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String VALID = EmptyField.STRING;
	
	@Column(desc="�Ƶ�", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String MEMO = EmptyField.STRING;
	
	@Column(desc="��Ƨ�s�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String UPDATE_ID = EmptyField.STRING;
	
	@Column(desc="��Ƨ�s���", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date UPDATE_DATE = EmptyField.DATE;
	
	@Column(desc="�]�ƳW��1", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String EQP_SPEC1 = EmptyField.STRING;
	
	@Column(desc="�]�ƳW��2", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String EQP_SPEC2 = EmptyField.STRING;
	
	@Column(desc="�]�ƳW��3", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String EQP_SPEC3 = EmptyField.STRING;
	
	@Column(desc="�]�ƳW��4", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String EQP_SPEC4 = EmptyField.STRING;
	
	@Column(desc="�]�ƳW��5", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String EQP_SPEC5 = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPF190(){
		// do nothing	
	}
	
	/**
	 * get value of �]�ƽs��
	 * @return �]�ƽs��
	 */
	public String getEQP_ID() {
		if(EmptyField.isEmpty(EQP_ID)){
			return null;
		}
		return EQP_ID;
	}

	/**
	 * set value of �]�ƽs��
	 * @param newEQP_ID - �]�ƽs��
	 */
	public void setEQP_ID(String newEQP_ID){
		EQP_ID = newEQP_ID;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �j�ӦW��
	 * @return �j�ӦW��
	 */
	public String getBLD_NM() {
		if(EmptyField.isEmpty(BLD_NM)){
			return null;
		}
		return BLD_NM;
	}

	/**
	 * set value of �j�ӦW��
	 * @param newBLD_NM - �j�ӦW��
	 */
	public void setBLD_NM(String newBLD_NM){
		BLD_NM = newBLD_NM;
	}	
	
	/**
	 * get value of �]�ƺ���(�j��)
	 * @return �]�ƺ���(�j��)
	 */
	public String getEQP_CD() {
		if(EmptyField.isEmpty(EQP_CD)){
			return null;
		}
		return EQP_CD;
	}

	/**
	 * set value of �]�ƺ���(�j��)
	 * @param newEQP_CD - �]�ƺ���(�j��)
	 */
	public void setEQP_CD(String newEQP_CD){
		EQP_CD = newEQP_CD;
	}	
	
	/**
	 * get value of �]�ƺ���(����)
	 * @return �]�ƺ���(����)
	 */
	public String getSUB_EQP_CD() {
		if(EmptyField.isEmpty(SUB_EQP_CD)){
			return null;
		}
		return SUB_EQP_CD;
	}

	/**
	 * set value of �]�ƺ���(����)
	 * @param newSUB_EQP_CD - �]�ƺ���(����)
	 */
	public void setSUB_EQP_CD(String newSUB_EQP_CD){
		SUB_EQP_CD = newSUB_EQP_CD;
	}	
	
	/**
	 * get value of �]�ƺ���(�W��X)
	 * @return �]�ƺ���(�W��X)
	 */
	public String getCODE() {
		if(EmptyField.isEmpty(CODE)){
			return null;
		}
		return CODE;
	}

	/**
	 * set value of �]�ƺ���(�W��X)
	 * @param newCODE - �]�ƺ���(�W��X)
	 */
	public void setCODE(String newCODE){
		CODE = newCODE;
	}	
	
	/**
	 * get value of �]�ƧǸ�
	 * @return �]�ƧǸ�
	 */
	public Integer getEQP_NO() {
		if(EmptyField.isEmpty(EQP_NO)){
			return null;
		}
		return EQP_NO;
	}

	/**
	 * set value of �]�ƧǸ�
	 * @param newEQP_NO - �]�ƧǸ�
	 */
	public void setEQP_NO(Integer newEQP_NO){
		EQP_NO = newEQP_NO;
	}	
	
	/**
	 * get value of �y����
	 * @return �y����
	 */
	public Integer getSER_NO() {
		if(EmptyField.isEmpty(SER_NO)){
			return null;
		}
		return SER_NO;
	}

	/**
	 * set value of �y����
	 * @param newSER_NO - �y����
	 */
	public void setSER_NO(Integer newSER_NO){
		SER_NO = newSER_NO;
	}	
	
	/**
	 * get value of �t�P
	 * @return �t�P
	 */
	public String getEQP_LB() {
		if(EmptyField.isEmpty(EQP_LB)){
			return null;
		}
		return EQP_LB;
	}

	/**
	 * set value of �t�P
	 * @param newEQP_LB - �t�P
	 */
	public void setEQP_LB(String newEQP_LB){
		EQP_LB = newEQP_LB;
	}	
	
	/**
	 * get value of ��t����
	 * @return ��t����
	 */
	public String getEQP_MD() {
		if(EmptyField.isEmpty(EQP_MD)){
			return null;
		}
		return EQP_MD;
	}

	/**
	 * set value of ��t����
	 * @param newEQP_MD - ��t����
	 */
	public void setEQP_MD(String newEQP_MD){
		EQP_MD = newEQP_MD;
	}	
	
	/**
	 * get value of �X�t�~��
	 * @return �X�t�~��
	 */
	public String getEQP_YR() {
		if(EmptyField.isEmpty(EQP_YR)){
			return null;
		}
		return EQP_YR;
	}

	/**
	 * set value of �X�t�~��
	 * @param newEQP_YR - �X�t�~��
	 */
	public void setEQP_YR(String newEQP_YR){
		EQP_YR = newEQP_YR;
	}	
	
	/**
	 * get value of �]�Ʀ�m(�Ӽh)
	 * @return �]�Ʀ�m(�Ӽh)
	 */
	public String getEQP_FR() {
		if(EmptyField.isEmpty(EQP_FR)){
			return null;
		}
		return EQP_FR;
	}

	/**
	 * set value of �]�Ʀ�m(�Ӽh)
	 * @param newEQP_FR - �]�Ʀ�m(�Ӽh)
	 */
	public void setEQP_FR(String newEQP_FR){
		EQP_FR = newEQP_FR;
	}	
	
	/**
	 * get value of ����(1)/�L��(0)
	 * @return ����(1)/�L��(0)
	 */
	public String getVALID() {
		if(EmptyField.isEmpty(VALID)){
			return null;
		}
		return VALID;
	}

	/**
	 * set value of ����(1)/�L��(0)
	 * @param newVALID - ����(1)/�L��(0)
	 */
	public void setVALID(String newVALID){
		VALID = newVALID;
	}	
	
	/**
	 * get value of �Ƶ�
	 * @return �Ƶ�
	 */
	public String getMEMO() {
		if(EmptyField.isEmpty(MEMO)){
			return null;
		}
		return MEMO;
	}

	/**
	 * set value of �Ƶ�
	 * @param newMEMO - �Ƶ�
	 */
	public void setMEMO(String newMEMO){
		MEMO = newMEMO;
	}	
	
	/**
	 * get value of ��Ƨ�s�H��ID
	 * @return ��Ƨ�s�H��ID
	 */
	public String getUPDATE_ID() {
		if(EmptyField.isEmpty(UPDATE_ID)){
			return null;
		}
		return UPDATE_ID;
	}

	/**
	 * set value of ��Ƨ�s�H��ID
	 * @param newUPDATE_ID - ��Ƨ�s�H��ID
	 */
	public void setUPDATE_ID(String newUPDATE_ID){
		UPDATE_ID = newUPDATE_ID;
	}	
	
	/**
	 * get value of ��Ƨ�s���
	 * @return ��Ƨ�s���
	 */
	public java.sql.Date getUPDATE_DATE() {
		if(EmptyField.isEmpty(UPDATE_DATE)){
			return null;
		}
		return UPDATE_DATE;
	}

	/**
	 * set value of ��Ƨ�s���
	 * @param newUPDATE_DATE - ��Ƨ�s���
	 */
	public void setUPDATE_DATE(java.sql.Date newUPDATE_DATE){
		UPDATE_DATE = newUPDATE_DATE;
	}	
	
	/**
	 * get value of �]�ƳW��1
	 * @return �]�ƳW��1
	 */
	public String getEQP_SPEC1() {
		if(EmptyField.isEmpty(EQP_SPEC1)){
			return null;
		}
		return EQP_SPEC1;
	}

	/**
	 * set value of �]�ƳW��1
	 * @param newEQP_SPEC1 - �]�ƳW��1
	 */
	public void setEQP_SPEC1(String newEQP_SPEC1){
		EQP_SPEC1 = newEQP_SPEC1;
	}	
	
	/**
	 * get value of �]�ƳW��2
	 * @return �]�ƳW��2
	 */
	public String getEQP_SPEC2() {
		if(EmptyField.isEmpty(EQP_SPEC2)){
			return null;
		}
		return EQP_SPEC2;
	}

	/**
	 * set value of �]�ƳW��2
	 * @param newEQP_SPEC2 - �]�ƳW��2
	 */
	public void setEQP_SPEC2(String newEQP_SPEC2){
		EQP_SPEC2 = newEQP_SPEC2;
	}	
	
	/**
	 * get value of �]�ƳW��3
	 * @return �]�ƳW��3
	 */
	public String getEQP_SPEC3() {
		if(EmptyField.isEmpty(EQP_SPEC3)){
			return null;
		}
		return EQP_SPEC3;
	}

	/**
	 * set value of �]�ƳW��3
	 * @param newEQP_SPEC3 - �]�ƳW��3
	 */
	public void setEQP_SPEC3(String newEQP_SPEC3){
		EQP_SPEC3 = newEQP_SPEC3;
	}	
	
	/**
	 * get value of �]�ƳW��4
	 * @return �]�ƳW��4
	 */
	public String getEQP_SPEC4() {
		if(EmptyField.isEmpty(EQP_SPEC4)){
			return null;
		}
		return EQP_SPEC4;
	}

	/**
	 * set value of �]�ƳW��4
	 * @param newEQP_SPEC4 - �]�ƳW��4
	 */
	public void setEQP_SPEC4(String newEQP_SPEC4){
		EQP_SPEC4 = newEQP_SPEC4;
	}	
	
	/**
	 * get value of �]�ƳW��5
	 * @return �]�ƳW��5
	 */
	public String getEQP_SPEC5() {
		if(EmptyField.isEmpty(EQP_SPEC5)){
			return null;
		}
		return EQP_SPEC5;
	}

	/**
	 * set value of �]�ƳW��5
	 * @param newEQP_SPEC5 - �]�ƳW��5
	 */
	public void setEQP_SPEC5(String newEQP_SPEC5){
		EQP_SPEC5 = newEQP_SPEC5;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(EQP_ID);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(BLD_NM);
		hcBuilder.append(EQP_CD);
		hcBuilder.append(SUB_EQP_CD);
		hcBuilder.append(CODE);
		hcBuilder.append(EQP_NO);
		hcBuilder.append(SER_NO);
		hcBuilder.append(EQP_LB);
		hcBuilder.append(EQP_MD);
		hcBuilder.append(EQP_YR);
		hcBuilder.append(EQP_FR);
		hcBuilder.append(VALID);
		hcBuilder.append(MEMO);
		hcBuilder.append(UPDATE_ID);
		hcBuilder.append(UPDATE_DATE);
		hcBuilder.append(EQP_SPEC1);
		hcBuilder.append(EQP_SPEC2);
		hcBuilder.append(EQP_SPEC3);
		hcBuilder.append(EQP_SPEC4);
		hcBuilder.append(EQP_SPEC5);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF190)){
			return false;
		}
        
		DTEPF190 theObj = (DTEPF190)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				