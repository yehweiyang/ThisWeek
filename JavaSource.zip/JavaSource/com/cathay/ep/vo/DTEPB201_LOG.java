package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPB201_LOG
 * <pre>
 * Generated value object of DBEP.DTEPB201_LOG ()
 * </pre>
 */
public class DTEPB201_LOG implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPB201_LOG";
	
	
	@Column(desc="�J�ɤ���ɶ�", pk=true, nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp UPD_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�Ȥ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CUS_ID = EmptyField.STRING;
	
	@Column(desc="�������", nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String DATA_TYPE = EmptyField.STRING;
	
	@Column(desc="�Ȥ�m�W", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String CUS_NAME = EmptyField.STRING;
	
	@Column(desc="�ҥ����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ID_TYPE = EmptyField.STRING;
	
	@Column(desc="�ҥ󸹽X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ID = EmptyField.STRING;
	
	@Column(desc="��~�O", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String JOB_TYPE = EmptyField.STRING;
	
	@Column(desc="�t�d�H", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String BOSS_NAME = EmptyField.STRING;
	
	@Column(desc="���q�l���ϸ�", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String COMP_ZIP_CODE = EmptyField.STRING;
	
	@Column(desc="���q�n�O�a�}", type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String COMP_ADDR = EmptyField.STRING;
	
	@Column(desc="�p���H", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String CONT_NAME = EmptyField.STRING;
	
	@Column(desc="�p���H���", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CONT_MOBIL_NO = EmptyField.STRING;
	
	@Column(desc="�q�ܰϽX", type=java.sql.Types.VARCHAR, length=4, defaultValue="") 
	private String TEL_AREA = EmptyField.STRING;
	
	@Column(desc="�q��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String TEL = EmptyField.STRING;
	
	@Column(desc="�q�ܤ���", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String TEL_EXT = EmptyField.STRING;
	
	@Column(desc="�q�T�a�l���ϸ�", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String CONT_ZIP_CODE = EmptyField.STRING;
	
	@Column(desc="�q�T�a�}", type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String CONT_ADDR = EmptyField.STRING;
	
	@Column(desc="�Ƶ�", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String MEMO = EmptyField.STRING;
	
	@Column(desc="�K�|�Ҹ�", type=java.sql.Types.VARCHAR, length=45, defaultValue="") 
	private String TAX_FREE_CD = EmptyField.STRING;
	
	@Column(desc="�Ȥ�EMAIL", type=java.sql.Types.VARCHAR, length=50, defaultValue="") 
	private String CUS_EMAIL = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="��s�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String UPD_ID = EmptyField.STRING;
	
	@Column(desc="��s�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String UPD_NAME = EmptyField.STRING;
	
	@Column(desc="�����b��ID", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String VIR_ACC_ID = EmptyField.STRING;
	
	@Column(desc="�o�����I�覡", type=java.sql.Types.VARCHAR, length=1, defaultValue="'A'") 
	private String TRANS_TYPE = EmptyField.STRING;
	
	@Column(desc="�o���ӤH��������", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String INV_DEVICE_TYPE = EmptyField.STRING;
	
	@Column(desc="�o���ӤH���㸹�X", type=java.sql.Types.VARCHAR, length=16, defaultValue="") 
	private String INV_DEVICE_NO = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPB201_LOG(){
		// do nothing	
	}
	
	/**
	 * get value of �J�ɤ���ɶ�
	 * @return �J�ɤ���ɶ�
	 */
	public java.sql.Timestamp getUPD_DATE() {
		if(EmptyField.isEmpty(UPD_DATE)){
			return null;
		}
		return UPD_DATE;
	}

	/**
	 * set value of �J�ɤ���ɶ�
	 * @param newUPD_DATE - �J�ɤ���ɶ�
	 */
	public void setUPD_DATE(java.sql.Timestamp newUPD_DATE){
		UPD_DATE = newUPD_DATE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �Ȥ�s��
	 * @return �Ȥ�s��
	 */
	public String getCUS_ID() {
		if(EmptyField.isEmpty(CUS_ID)){
			return null;
		}
		return CUS_ID;
	}

	/**
	 * set value of �Ȥ�s��
	 * @param newCUS_ID - �Ȥ�s��
	 */
	public void setCUS_ID(String newCUS_ID){
		CUS_ID = newCUS_ID;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getDATA_TYPE() {
		if(EmptyField.isEmpty(DATA_TYPE)){
			return null;
		}
		return DATA_TYPE;
	}

	/**
	 * set value of �������
	 * @param newDATA_TYPE - �������
	 */
	public void setDATA_TYPE(String newDATA_TYPE){
		DATA_TYPE = newDATA_TYPE;
	}	
	
	/**
	 * get value of �Ȥ�m�W
	 * @return �Ȥ�m�W
	 */
	public String getCUS_NAME() {
		if(EmptyField.isEmpty(CUS_NAME)){
			return null;
		}
		return CUS_NAME;
	}

	/**
	 * set value of �Ȥ�m�W
	 * @param newCUS_NAME - �Ȥ�m�W
	 */
	public void setCUS_NAME(String newCUS_NAME){
		CUS_NAME = newCUS_NAME;
	}	
	
	/**
	 * get value of �ҥ����
	 * @return �ҥ����
	 */
	public String getID_TYPE() {
		if(EmptyField.isEmpty(ID_TYPE)){
			return null;
		}
		return ID_TYPE;
	}

	/**
	 * set value of �ҥ����
	 * @param newID_TYPE - �ҥ����
	 */
	public void setID_TYPE(String newID_TYPE){
		ID_TYPE = newID_TYPE;
	}	
	
	/**
	 * get value of �ҥ󸹽X
	 * @return �ҥ󸹽X
	 */
	public String getID() {
		if(EmptyField.isEmpty(ID)){
			return null;
		}
		return ID;
	}

	/**
	 * set value of �ҥ󸹽X
	 * @param newID - �ҥ󸹽X
	 */
	public void setID(String newID){
		ID = newID;
	}	
	
	/**
	 * get value of ��~�O
	 * @return ��~�O
	 */
	public String getJOB_TYPE() {
		if(EmptyField.isEmpty(JOB_TYPE)){
			return null;
		}
		return JOB_TYPE;
	}

	/**
	 * set value of ��~�O
	 * @param newJOB_TYPE - ��~�O
	 */
	public void setJOB_TYPE(String newJOB_TYPE){
		JOB_TYPE = newJOB_TYPE;
	}	
	
	/**
	 * get value of �t�d�H
	 * @return �t�d�H
	 */
	public String getBOSS_NAME() {
		if(EmptyField.isEmpty(BOSS_NAME)){
			return null;
		}
		return BOSS_NAME;
	}

	/**
	 * set value of �t�d�H
	 * @param newBOSS_NAME - �t�d�H
	 */
	public void setBOSS_NAME(String newBOSS_NAME){
		BOSS_NAME = newBOSS_NAME;
	}	
	
	/**
	 * get value of ���q�l���ϸ�
	 * @return ���q�l���ϸ�
	 */
	public String getCOMP_ZIP_CODE() {
		if(EmptyField.isEmpty(COMP_ZIP_CODE)){
			return null;
		}
		return COMP_ZIP_CODE;
	}

	/**
	 * set value of ���q�l���ϸ�
	 * @param newCOMP_ZIP_CODE - ���q�l���ϸ�
	 */
	public void setCOMP_ZIP_CODE(String newCOMP_ZIP_CODE){
		COMP_ZIP_CODE = newCOMP_ZIP_CODE;
	}	
	
	/**
	 * get value of ���q�n�O�a�}
	 * @return ���q�n�O�a�}
	 */
	public String getCOMP_ADDR() {
		if(EmptyField.isEmpty(COMP_ADDR)){
			return null;
		}
		return COMP_ADDR;
	}

	/**
	 * set value of ���q�n�O�a�}
	 * @param newCOMP_ADDR - ���q�n�O�a�}
	 */
	public void setCOMP_ADDR(String newCOMP_ADDR){
		COMP_ADDR = newCOMP_ADDR;
	}	
	
	/**
	 * get value of �p���H
	 * @return �p���H
	 */
	public String getCONT_NAME() {
		if(EmptyField.isEmpty(CONT_NAME)){
			return null;
		}
		return CONT_NAME;
	}

	/**
	 * set value of �p���H
	 * @param newCONT_NAME - �p���H
	 */
	public void setCONT_NAME(String newCONT_NAME){
		CONT_NAME = newCONT_NAME;
	}	
	
	/**
	 * get value of �p���H���
	 * @return �p���H���
	 */
	public String getCONT_MOBIL_NO() {
		if(EmptyField.isEmpty(CONT_MOBIL_NO)){
			return null;
		}
		return CONT_MOBIL_NO;
	}

	/**
	 * set value of �p���H���
	 * @param newCONT_MOBIL_NO - �p���H���
	 */
	public void setCONT_MOBIL_NO(String newCONT_MOBIL_NO){
		CONT_MOBIL_NO = newCONT_MOBIL_NO;
	}	
	
	/**
	 * get value of �q�ܰϽX
	 * @return �q�ܰϽX
	 */
	public String getTEL_AREA() {
		if(EmptyField.isEmpty(TEL_AREA)){
			return null;
		}
		return TEL_AREA;
	}

	/**
	 * set value of �q�ܰϽX
	 * @param newTEL_AREA - �q�ܰϽX
	 */
	public void setTEL_AREA(String newTEL_AREA){
		TEL_AREA = newTEL_AREA;
	}	
	
	/**
	 * get value of �q��
	 * @return �q��
	 */
	public String getTEL() {
		if(EmptyField.isEmpty(TEL)){
			return null;
		}
		return TEL;
	}

	/**
	 * set value of �q��
	 * @param newTEL - �q��
	 */
	public void setTEL(String newTEL){
		TEL = newTEL;
	}	
	
	/**
	 * get value of �q�ܤ���
	 * @return �q�ܤ���
	 */
	public String getTEL_EXT() {
		if(EmptyField.isEmpty(TEL_EXT)){
			return null;
		}
		return TEL_EXT;
	}

	/**
	 * set value of �q�ܤ���
	 * @param newTEL_EXT - �q�ܤ���
	 */
	public void setTEL_EXT(String newTEL_EXT){
		TEL_EXT = newTEL_EXT;
	}	
	
	/**
	 * get value of �q�T�a�l���ϸ�
	 * @return �q�T�a�l���ϸ�
	 */
	public String getCONT_ZIP_CODE() {
		if(EmptyField.isEmpty(CONT_ZIP_CODE)){
			return null;
		}
		return CONT_ZIP_CODE;
	}

	/**
	 * set value of �q�T�a�l���ϸ�
	 * @param newCONT_ZIP_CODE - �q�T�a�l���ϸ�
	 */
	public void setCONT_ZIP_CODE(String newCONT_ZIP_CODE){
		CONT_ZIP_CODE = newCONT_ZIP_CODE;
	}	
	
	/**
	 * get value of �q�T�a�}
	 * @return �q�T�a�}
	 */
	public String getCONT_ADDR() {
		if(EmptyField.isEmpty(CONT_ADDR)){
			return null;
		}
		return CONT_ADDR;
	}

	/**
	 * set value of �q�T�a�}
	 * @param newCONT_ADDR - �q�T�a�}
	 */
	public void setCONT_ADDR(String newCONT_ADDR){
		CONT_ADDR = newCONT_ADDR;
	}	
	
	/**
	 * get value of �Ƶ�
	 * @return �Ƶ�
	 */
	public String getMEMO() {
		if(EmptyField.isEmpty(MEMO)){
			return null;
		}
		return MEMO;
	}

	/**
	 * set value of �Ƶ�
	 * @param newMEMO - �Ƶ�
	 */
	public void setMEMO(String newMEMO){
		MEMO = newMEMO;
	}	
	
	/**
	 * get value of �K�|�Ҹ�
	 * @return �K�|�Ҹ�
	 */
	public String getTAX_FREE_CD() {
		if(EmptyField.isEmpty(TAX_FREE_CD)){
			return null;
		}
		return TAX_FREE_CD;
	}

	/**
	 * set value of �K�|�Ҹ�
	 * @param newTAX_FREE_CD - �K�|�Ҹ�
	 */
	public void setTAX_FREE_CD(String newTAX_FREE_CD){
		TAX_FREE_CD = newTAX_FREE_CD;
	}	
	
	/**
	 * get value of �Ȥ�EMAIL
	 * @return �Ȥ�EMAIL
	 */
	public String getCUS_EMAIL() {
		if(EmptyField.isEmpty(CUS_EMAIL)){
			return null;
		}
		return CUS_EMAIL;
	}

	/**
	 * set value of �Ȥ�EMAIL
	 * @param newCUS_EMAIL - �Ȥ�EMAIL
	 */
	public void setCUS_EMAIL(String newCUS_EMAIL){
		CUS_EMAIL = newCUS_EMAIL;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of ��s�H��ID
	 * @return ��s�H��ID
	 */
	public String getUPD_ID() {
		if(EmptyField.isEmpty(UPD_ID)){
			return null;
		}
		return UPD_ID;
	}

	/**
	 * set value of ��s�H��ID
	 * @param newUPD_ID - ��s�H��ID
	 */
	public void setUPD_ID(String newUPD_ID){
		UPD_ID = newUPD_ID;
	}	
	
	/**
	 * get value of ��s�H���m�W
	 * @return ��s�H���m�W
	 */
	public String getUPD_NAME() {
		if(EmptyField.isEmpty(UPD_NAME)){
			return null;
		}
		return UPD_NAME;
	}

	/**
	 * set value of ��s�H���m�W
	 * @param newUPD_NAME - ��s�H���m�W
	 */
	public void setUPD_NAME(String newUPD_NAME){
		UPD_NAME = newUPD_NAME;
	}	
	
	/**
	 * get value of �����b��ID
	 * @return �����b��ID
	 */
	public String getVIR_ACC_ID() {
		if(EmptyField.isEmpty(VIR_ACC_ID)){
			return null;
		}
		return VIR_ACC_ID;
	}

	/**
	 * set value of �����b��ID
	 * @param newVIR_ACC_ID - �����b��ID
	 */
	public void setVIR_ACC_ID(String newVIR_ACC_ID){
		VIR_ACC_ID = newVIR_ACC_ID;
	}	
	
	/**
	 * get value of �o�����I�覡
	 * @return �o�����I�覡
	 */
	public String getTRANS_TYPE() {
		if(EmptyField.isEmpty(TRANS_TYPE)){
			return null;
		}
		return TRANS_TYPE;
	}

	/**
	 * set value of �o�����I�覡
	 * @param newTRANS_TYPE - �o�����I�覡
	 */
	public void setTRANS_TYPE(String newTRANS_TYPE){
		TRANS_TYPE = newTRANS_TYPE;
	}	
	
	/**
	 * get value of �o���ӤH��������
	 * @return �o���ӤH��������
	 */
	public String getINV_DEVICE_TYPE() {
		if(EmptyField.isEmpty(INV_DEVICE_TYPE)){
			return null;
		}
		return INV_DEVICE_TYPE;
	}

	/**
	 * set value of �o���ӤH��������
	 * @param newINV_DEVICE_TYPE - �o���ӤH��������
	 */
	public void setINV_DEVICE_TYPE(String newINV_DEVICE_TYPE){
		INV_DEVICE_TYPE = newINV_DEVICE_TYPE;
	}	
	
	/**
	 * get value of �o���ӤH���㸹�X
	 * @return �o���ӤH���㸹�X
	 */
	public String getINV_DEVICE_NO() {
		if(EmptyField.isEmpty(INV_DEVICE_NO)){
			return null;
		}
		return INV_DEVICE_NO;
	}

	/**
	 * set value of �o���ӤH���㸹�X
	 * @param newINV_DEVICE_NO - �o���ӤH���㸹�X
	 */
	public void setINV_DEVICE_NO(String newINV_DEVICE_NO){
		INV_DEVICE_NO = newINV_DEVICE_NO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(UPD_DATE);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CUS_ID);
		hcBuilder.append(DATA_TYPE);
		hcBuilder.append(CUS_NAME);
		hcBuilder.append(ID_TYPE);
		hcBuilder.append(ID);
		hcBuilder.append(JOB_TYPE);
		hcBuilder.append(BOSS_NAME);
		hcBuilder.append(COMP_ZIP_CODE);
		hcBuilder.append(COMP_ADDR);
		hcBuilder.append(CONT_NAME);
		hcBuilder.append(CONT_MOBIL_NO);
		hcBuilder.append(TEL_AREA);
		hcBuilder.append(TEL);
		hcBuilder.append(TEL_EXT);
		hcBuilder.append(CONT_ZIP_CODE);
		hcBuilder.append(CONT_ADDR);
		hcBuilder.append(MEMO);
		hcBuilder.append(TAX_FREE_CD);
		hcBuilder.append(CUS_EMAIL);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(UPD_ID);
		hcBuilder.append(UPD_NAME);
		hcBuilder.append(VIR_ACC_ID);
		hcBuilder.append(TRANS_TYPE);
		hcBuilder.append(INV_DEVICE_TYPE);
		hcBuilder.append(INV_DEVICE_NO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPB201_LOG)){
			return false;
		}
        
		DTEPB201_LOG theObj = (DTEPB201_LOG)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				