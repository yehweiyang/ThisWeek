package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPI101
 * <pre>
 * Generated value object of DBEP.DTEPI101 ()
 * </pre>
 */
public class DTEPI101 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPI101";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="���դj�ӥN��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String INV_CD = EmptyField.STRING;
	
	@Column(desc="�~", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer INV_YR = EmptyField.INTEGER;
	
	@Column(desc="�u", pk=true, nullAble=false, type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String INV_SN = EmptyField.STRING;
	
	@Column(desc="���u�Ÿm�W��", type=java.sql.Types.DECIMAL, length=10, defaultValue="") 
	private java.math.BigDecimal EPT_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�����}��", type=java.sql.Types.DECIMAL, length=10, defaultValue="") 
	private java.math.BigDecimal OFFER_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="��������", type=java.sql.Types.DECIMAL, length=10, defaultValue="") 
	private java.math.BigDecimal BASE_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���쯲��", type=java.sql.Types.DECIMAL, length=10, defaultValue="") 
	private java.math.BigDecimal RNT_PRK_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�޲z�O", type=java.sql.Types.DECIMAL, length=10, defaultValue="") 
	private java.math.BigDecimal EXP_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�h���W��", type=java.sql.Types.DECIMAL, length=10, defaultValue="") 
	private java.math.BigDecimal RDC_RNT_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�s���W��", type=java.sql.Types.DECIMAL, length=10, defaultValue="") 
	private java.math.BigDecimal ADD_RNT_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="���������}��", type=java.sql.Types.DECIMAL, length=10, defaultValue="") 
	private java.math.BigDecimal SHOP_OFFER_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="������������", type=java.sql.Types.DECIMAL, length=10, defaultValue="") 
	private java.math.BigDecimal SHOP_BASE_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�Ȥ�y�J", type=java.sql.Types.VARCHAR, length=1000, defaultValue="") 
	private String CUST_IN = EmptyField.STRING;
	
	@Column(desc="�Ȥ�y�X", type=java.sql.Types.VARCHAR, length=1000, defaultValue="") 
	private String CUST_OUT = EmptyField.STRING;
	
	@Column(desc="�Ƶ�", type=java.sql.Types.VARCHAR, length=1000, defaultValue="") 
	private String MEMO = EmptyField.STRING;
	
	@Column(desc="���դH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INV_ID = EmptyField.STRING;
	
	@Column(desc="���դH���m�W", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INV_NAME = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPI101(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ���դj�ӥN��
	 * @return ���դj�ӥN��
	 */
	public String getINV_CD() {
		if(EmptyField.isEmpty(INV_CD)){
			return null;
		}
		return INV_CD;
	}

	/**
	 * set value of ���դj�ӥN��
	 * @param newINV_CD - ���դj�ӥN��
	 */
	public void setINV_CD(String newINV_CD){
		INV_CD = newINV_CD;
	}	
	
	/**
	 * get value of �~
	 * @return �~
	 */
	public Integer getINV_YR() {
		if(EmptyField.isEmpty(INV_YR)){
			return null;
		}
		return INV_YR;
	}

	/**
	 * set value of �~
	 * @param newINV_YR - �~
	 */
	public void setINV_YR(Integer newINV_YR){
		INV_YR = newINV_YR;
	}	
	
	/**
	 * get value of �u
	 * @return �u
	 */
	public String getINV_SN() {
		if(EmptyField.isEmpty(INV_SN)){
			return null;
		}
		return INV_SN;
	}

	/**
	 * set value of �u
	 * @param newINV_SN - �u
	 */
	public void setINV_SN(String newINV_SN){
		INV_SN = newINV_SN;
	}	
	
	/**
	 * get value of ���u�Ÿm�W��
	 * @return ���u�Ÿm�W��
	 */
	public java.math.BigDecimal getEPT_SIZE() {
		if(EmptyField.isEmpty(EPT_SIZE)){
			return null;
		}
		return EPT_SIZE;
	}

	/**
	 * set value of ���u�Ÿm�W��
	 * @param newEPT_SIZE - ���u�Ÿm�W��
	 */
	public void setEPT_SIZE(java.math.BigDecimal newEPT_SIZE){
		EPT_SIZE = newEPT_SIZE;
	}	
	
	/**
	 * get value of �����}��
	 * @return �����}��
	 */
	public java.math.BigDecimal getOFFER_AMT() {
		if(EmptyField.isEmpty(OFFER_AMT)){
			return null;
		}
		return OFFER_AMT;
	}

	/**
	 * set value of �����}��
	 * @param newOFFER_AMT - �����}��
	 */
	public void setOFFER_AMT(java.math.BigDecimal newOFFER_AMT){
		OFFER_AMT = newOFFER_AMT;
	}	
	
	/**
	 * get value of ��������
	 * @return ��������
	 */
	public java.math.BigDecimal getBASE_AMT() {
		if(EmptyField.isEmpty(BASE_AMT)){
			return null;
		}
		return BASE_AMT;
	}

	/**
	 * set value of ��������
	 * @param newBASE_AMT - ��������
	 */
	public void setBASE_AMT(java.math.BigDecimal newBASE_AMT){
		BASE_AMT = newBASE_AMT;
	}	
	
	/**
	 * get value of ���쯲��
	 * @return ���쯲��
	 */
	public java.math.BigDecimal getRNT_PRK_AMT() {
		if(EmptyField.isEmpty(RNT_PRK_AMT)){
			return null;
		}
		return RNT_PRK_AMT;
	}

	/**
	 * set value of ���쯲��
	 * @param newRNT_PRK_AMT - ���쯲��
	 */
	public void setRNT_PRK_AMT(java.math.BigDecimal newRNT_PRK_AMT){
		RNT_PRK_AMT = newRNT_PRK_AMT;
	}	
	
	/**
	 * get value of �޲z�O
	 * @return �޲z�O
	 */
	public java.math.BigDecimal getEXP_AMT() {
		if(EmptyField.isEmpty(EXP_AMT)){
			return null;
		}
		return EXP_AMT;
	}

	/**
	 * set value of �޲z�O
	 * @param newEXP_AMT - �޲z�O
	 */
	public void setEXP_AMT(java.math.BigDecimal newEXP_AMT){
		EXP_AMT = newEXP_AMT;
	}	
	
	/**
	 * get value of �h���W��
	 * @return �h���W��
	 */
	public java.math.BigDecimal getRDC_RNT_SIZE() {
		if(EmptyField.isEmpty(RDC_RNT_SIZE)){
			return null;
		}
		return RDC_RNT_SIZE;
	}

	/**
	 * set value of �h���W��
	 * @param newRDC_RNT_SIZE - �h���W��
	 */
	public void setRDC_RNT_SIZE(java.math.BigDecimal newRDC_RNT_SIZE){
		RDC_RNT_SIZE = newRDC_RNT_SIZE;
	}	
	
	/**
	 * get value of �s���W��
	 * @return �s���W��
	 */
	public java.math.BigDecimal getADD_RNT_SIZE() {
		if(EmptyField.isEmpty(ADD_RNT_SIZE)){
			return null;
		}
		return ADD_RNT_SIZE;
	}

	/**
	 * set value of �s���W��
	 * @param newADD_RNT_SIZE - �s���W��
	 */
	public void setADD_RNT_SIZE(java.math.BigDecimal newADD_RNT_SIZE){
		ADD_RNT_SIZE = newADD_RNT_SIZE;
	}	
	
	/**
	 * get value of ���������}��
	 * @return ���������}��
	 */
	public java.math.BigDecimal getSHOP_OFFER_AMT() {
		if(EmptyField.isEmpty(SHOP_OFFER_AMT)){
			return null;
		}
		return SHOP_OFFER_AMT;
	}

	/**
	 * set value of ���������}��
	 * @param newSHOP_OFFER_AMT - ���������}��
	 */
	public void setSHOP_OFFER_AMT(java.math.BigDecimal newSHOP_OFFER_AMT){
		SHOP_OFFER_AMT = newSHOP_OFFER_AMT;
	}	
	
	/**
	 * get value of ������������
	 * @return ������������
	 */
	public java.math.BigDecimal getSHOP_BASE_AMT() {
		if(EmptyField.isEmpty(SHOP_BASE_AMT)){
			return null;
		}
		return SHOP_BASE_AMT;
	}

	/**
	 * set value of ������������
	 * @param newSHOP_BASE_AMT - ������������
	 */
	public void setSHOP_BASE_AMT(java.math.BigDecimal newSHOP_BASE_AMT){
		SHOP_BASE_AMT = newSHOP_BASE_AMT;
	}	
	
	/**
	 * get value of �Ȥ�y�J
	 * @return �Ȥ�y�J
	 */
	public String getCUST_IN() {
		if(EmptyField.isEmpty(CUST_IN)){
			return null;
		}
		return CUST_IN;
	}

	/**
	 * set value of �Ȥ�y�J
	 * @param newCUST_IN - �Ȥ�y�J
	 */
	public void setCUST_IN(String newCUST_IN){
		CUST_IN = newCUST_IN;
	}	
	
	/**
	 * get value of �Ȥ�y�X
	 * @return �Ȥ�y�X
	 */
	public String getCUST_OUT() {
		if(EmptyField.isEmpty(CUST_OUT)){
			return null;
		}
		return CUST_OUT;
	}

	/**
	 * set value of �Ȥ�y�X
	 * @param newCUST_OUT - �Ȥ�y�X
	 */
	public void setCUST_OUT(String newCUST_OUT){
		CUST_OUT = newCUST_OUT;
	}	
	
	/**
	 * get value of �Ƶ�
	 * @return �Ƶ�
	 */
	public String getMEMO() {
		if(EmptyField.isEmpty(MEMO)){
			return null;
		}
		return MEMO;
	}

	/**
	 * set value of �Ƶ�
	 * @param newMEMO - �Ƶ�
	 */
	public void setMEMO(String newMEMO){
		MEMO = newMEMO;
	}	
	
	/**
	 * get value of ���դH��ID
	 * @return ���դH��ID
	 */
	public String getINV_ID() {
		if(EmptyField.isEmpty(INV_ID)){
			return null;
		}
		return INV_ID;
	}

	/**
	 * set value of ���դH��ID
	 * @param newINV_ID - ���դH��ID
	 */
	public void setINV_ID(String newINV_ID){
		INV_ID = newINV_ID;
	}	
	
	/**
	 * get value of ���դH���m�W
	 * @return ���դH���m�W
	 */
	public String getINV_NAME() {
		if(EmptyField.isEmpty(INV_NAME)){
			return null;
		}
		return INV_NAME;
	}

	/**
	 * set value of ���դH���m�W
	 * @param newINV_NAME - ���դH���m�W
	 */
	public void setINV_NAME(String newINV_NAME){
		INV_NAME = newINV_NAME;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(INV_CD);
		hcBuilder.append(INV_YR);
		hcBuilder.append(INV_SN);
		hcBuilder.append(EPT_SIZE);
		hcBuilder.append(OFFER_AMT);
		hcBuilder.append(BASE_AMT);
		hcBuilder.append(RNT_PRK_AMT);
		hcBuilder.append(EXP_AMT);
		hcBuilder.append(RDC_RNT_SIZE);
		hcBuilder.append(ADD_RNT_SIZE);
		hcBuilder.append(SHOP_OFFER_AMT);
		hcBuilder.append(SHOP_BASE_AMT);
		hcBuilder.append(CUST_IN);
		hcBuilder.append(CUST_OUT);
		hcBuilder.append(MEMO);
		hcBuilder.append(INV_ID);
		hcBuilder.append(INV_NAME);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPI101)){
			return false;
		}
        
		DTEPI101 theObj = (DTEPI101)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				