package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPB301_LOG
 * <pre>
 * Generated value object of DBEP.DTEPB301_LOG ()
 * </pre>
 */
public class DTEPB301_LOG implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPB301_LOG";
	
	
	@Column(desc="���ʤ���ɶ�", pk=true, nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�y����", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SER_NO = EmptyField.INTEGER;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�����N��", type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�Ȥ�m�W", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String CUS_NAME = EmptyField.STRING;
	
	@Column(desc="�����s��", type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String RCV_NO = EmptyField.STRING;
	
	@Column(desc="�o�����X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INV_NO = EmptyField.STRING;
	
	@Column(desc="ú�O�s��", type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String PAY_NO = EmptyField.STRING;
	
	@Column(desc="��J����ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp INPUT_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="��J���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String INPUT_DIV_NO = EmptyField.STRING;
	
	@Column(desc="��J�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INPUT_ID = EmptyField.STRING;
	
	@Column(desc="��J�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String INPUT_NAME = EmptyField.STRING;
	
	@Column(desc="�R�����", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String DEL_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�R���H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String DEL_ID = EmptyField.STRING;
	
	@Column(desc="�R���H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String DEL_NAME = EmptyField.STRING;
	
	@Column(desc="�ɮצW��", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String TABLE_NAME = EmptyField.STRING;
	
	@Column(desc="�{��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String PROG_ID = EmptyField.STRING;
	
	@Column(desc="�Ƶ�", type=java.sql.Types.VARCHAR, length=450, defaultValue="") 
	private String MEMO = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPB301_LOG(){
		// do nothing	
	}
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of �y����
	 * @return �y����
	 */
	public Integer getSER_NO() {
		if(EmptyField.isEmpty(SER_NO)){
			return null;
		}
		return SER_NO;
	}

	/**
	 * set value of �y����
	 * @param newSER_NO - �y����
	 */
	public void setSER_NO(Integer newSER_NO){
		SER_NO = newSER_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �Ȥ�m�W
	 * @return �Ȥ�m�W
	 */
	public String getCUS_NAME() {
		if(EmptyField.isEmpty(CUS_NAME)){
			return null;
		}
		return CUS_NAME;
	}

	/**
	 * set value of �Ȥ�m�W
	 * @param newCUS_NAME - �Ȥ�m�W
	 */
	public void setCUS_NAME(String newCUS_NAME){
		CUS_NAME = newCUS_NAME;
	}	
	
	/**
	 * get value of �����s��
	 * @return �����s��
	 */
	public String getRCV_NO() {
		if(EmptyField.isEmpty(RCV_NO)){
			return null;
		}
		return RCV_NO;
	}

	/**
	 * set value of �����s��
	 * @param newRCV_NO - �����s��
	 */
	public void setRCV_NO(String newRCV_NO){
		RCV_NO = newRCV_NO;
	}	
	
	/**
	 * get value of �o�����X
	 * @return �o�����X
	 */
	public String getINV_NO() {
		if(EmptyField.isEmpty(INV_NO)){
			return null;
		}
		return INV_NO;
	}

	/**
	 * set value of �o�����X
	 * @param newINV_NO - �o�����X
	 */
	public void setINV_NO(String newINV_NO){
		INV_NO = newINV_NO;
	}	
	
	/**
	 * get value of ú�O�s��
	 * @return ú�O�s��
	 */
	public String getPAY_NO() {
		if(EmptyField.isEmpty(PAY_NO)){
			return null;
		}
		return PAY_NO;
	}

	/**
	 * set value of ú�O�s��
	 * @param newPAY_NO - ú�O�s��
	 */
	public void setPAY_NO(String newPAY_NO){
		PAY_NO = newPAY_NO;
	}	
	
	/**
	 * get value of ��J����ɶ�
	 * @return ��J����ɶ�
	 */
	public java.sql.Timestamp getINPUT_DATE() {
		if(EmptyField.isEmpty(INPUT_DATE)){
			return null;
		}
		return INPUT_DATE;
	}

	/**
	 * set value of ��J����ɶ�
	 * @param newINPUT_DATE - ��J����ɶ�
	 */
	public void setINPUT_DATE(java.sql.Timestamp newINPUT_DATE){
		INPUT_DATE = newINPUT_DATE;
	}	
	
	/**
	 * get value of ��J���
	 * @return ��J���
	 */
	public String getINPUT_DIV_NO() {
		if(EmptyField.isEmpty(INPUT_DIV_NO)){
			return null;
		}
		return INPUT_DIV_NO;
	}

	/**
	 * set value of ��J���
	 * @param newINPUT_DIV_NO - ��J���
	 */
	public void setINPUT_DIV_NO(String newINPUT_DIV_NO){
		INPUT_DIV_NO = newINPUT_DIV_NO;
	}	
	
	/**
	 * get value of ��J�H��ID
	 * @return ��J�H��ID
	 */
	public String getINPUT_ID() {
		if(EmptyField.isEmpty(INPUT_ID)){
			return null;
		}
		return INPUT_ID;
	}

	/**
	 * set value of ��J�H��ID
	 * @param newINPUT_ID - ��J�H��ID
	 */
	public void setINPUT_ID(String newINPUT_ID){
		INPUT_ID = newINPUT_ID;
	}	
	
	/**
	 * get value of ��J�H���m�W
	 * @return ��J�H���m�W
	 */
	public String getINPUT_NAME() {
		if(EmptyField.isEmpty(INPUT_NAME)){
			return null;
		}
		return INPUT_NAME;
	}

	/**
	 * set value of ��J�H���m�W
	 * @param newINPUT_NAME - ��J�H���m�W
	 */
	public void setINPUT_NAME(String newINPUT_NAME){
		INPUT_NAME = newINPUT_NAME;
	}	
	
	/**
	 * get value of �R�����
	 * @return �R�����
	 */
	public String getDEL_DIV_NO() {
		if(EmptyField.isEmpty(DEL_DIV_NO)){
			return null;
		}
		return DEL_DIV_NO;
	}

	/**
	 * set value of �R�����
	 * @param newDEL_DIV_NO - �R�����
	 */
	public void setDEL_DIV_NO(String newDEL_DIV_NO){
		DEL_DIV_NO = newDEL_DIV_NO;
	}	
	
	/**
	 * get value of �R���H��ID
	 * @return �R���H��ID
	 */
	public String getDEL_ID() {
		if(EmptyField.isEmpty(DEL_ID)){
			return null;
		}
		return DEL_ID;
	}

	/**
	 * set value of �R���H��ID
	 * @param newDEL_ID - �R���H��ID
	 */
	public void setDEL_ID(String newDEL_ID){
		DEL_ID = newDEL_ID;
	}	
	
	/**
	 * get value of �R���H���m�W
	 * @return �R���H���m�W
	 */
	public String getDEL_NAME() {
		if(EmptyField.isEmpty(DEL_NAME)){
			return null;
		}
		return DEL_NAME;
	}

	/**
	 * set value of �R���H���m�W
	 * @param newDEL_NAME - �R���H���m�W
	 */
	public void setDEL_NAME(String newDEL_NAME){
		DEL_NAME = newDEL_NAME;
	}	
	
	/**
	 * get value of �ɮצW��
	 * @return �ɮצW��
	 */
	public String getTABLE_NAME() {
		if(EmptyField.isEmpty(TABLE_NAME)){
			return null;
		}
		return TABLE_NAME;
	}

	/**
	 * set value of �ɮצW��
	 * @param newTABLE_NAME - �ɮצW��
	 */
	public void setTABLE_NAME(String newTABLE_NAME){
		TABLE_NAME = newTABLE_NAME;
	}	
	
	/**
	 * get value of �{��ID
	 * @return �{��ID
	 */
	public String getPROG_ID() {
		if(EmptyField.isEmpty(PROG_ID)){
			return null;
		}
		return PROG_ID;
	}

	/**
	 * set value of �{��ID
	 * @param newPROG_ID - �{��ID
	 */
	public void setPROG_ID(String newPROG_ID){
		PROG_ID = newPROG_ID;
	}	
	
	/**
	 * get value of �Ƶ�
	 * @return �Ƶ�
	 */
	public String getMEMO() {
		if(EmptyField.isEmpty(MEMO)){
			return null;
		}
		return MEMO;
	}

	/**
	 * set value of �Ƶ�
	 * @param newMEMO - �Ƶ�
	 */
	public void setMEMO(String newMEMO){
		MEMO = newMEMO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(SER_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(TRN_KIND);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(CUS_NAME);
		hcBuilder.append(RCV_NO);
		hcBuilder.append(INV_NO);
		hcBuilder.append(PAY_NO);
		hcBuilder.append(INPUT_DATE);
		hcBuilder.append(INPUT_DIV_NO);
		hcBuilder.append(INPUT_ID);
		hcBuilder.append(INPUT_NAME);
		hcBuilder.append(DEL_DIV_NO);
		hcBuilder.append(DEL_ID);
		hcBuilder.append(DEL_NAME);
		hcBuilder.append(TABLE_NAME);
		hcBuilder.append(PROG_ID);
		hcBuilder.append(MEMO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPB301_LOG)){
			return false;
		}
        
		DTEPB301_LOG theObj = (DTEPB301_LOG)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				