package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPG130
 * <pre>
 * Generated value object of DBEP.DTEPG130 (��a�b��������)
 * </pre>
 */
public class DTEPG130 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPG130";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="��a�N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BASE_CD = EmptyField.STRING;
	
	@Column(desc="IFRS�����", type=java.sql.Types.DECIMAL, length=5, defaultValue="") 
	private java.math.BigDecimal IFRS_INV_RT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ت�����", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal BLD_COST = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ت���ꦨ��", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal BLD_COST_INV = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ت��ۥΦ���", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal BLD_COST_SLF = EmptyField.BIGDECIMAL;
	
	@Column(desc="�g�a����", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal LND_COST = EmptyField.BIGDECIMAL;
	
	@Column(desc="�g�a��ꦨ��", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal LND_COST_INV = EmptyField.BIGDECIMAL;
	
	@Column(desc="�g�a�ۥΦ���", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal LND_COST_SLF = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ت���l", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal BLD_LOSS = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ت�����l", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal BLD_LOSS_INV = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ت��ۥδ�l", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal BLD_LOSS_SLF = EmptyField.BIGDECIMAL;
	
	@Column(desc="�g�a��l", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal LND_LOSS = EmptyField.BIGDECIMAL;
	
	@Column(desc="�g�a����l", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal LND_LOSS_INV = EmptyField.BIGDECIMAL;
	
	@Column(desc="�g�a�ۥδ�l", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal LND_LOSS_SLF = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ت�IFRS����", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal BLD_IFRS_COST = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ت�IFRS��ꦨ��", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal BLD_IFRS_INV = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ت�IFRS�ۥΦ���", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal BLD_IFRS_SLF = EmptyField.BIGDECIMAL;
	
	@Column(desc="�g�aIFRS����", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal LND_IFRS_COST = EmptyField.BIGDECIMAL;
	
	@Column(desc="�g�aIFRS��ꦨ��", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal LND_IFRS_INV = EmptyField.BIGDECIMAL;
	
	@Column(desc="�g�aIFRS�ۥΦ���", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal LND_IFRS_SLF = EmptyField.BIGDECIMAL;
	
	@Column(desc="����s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�g�a���n", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal LND_AREA = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ت����n", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal BLD_AREA = EmptyField.BIGDECIMAL;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPG130(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ��a�N��
	 * @return ��a�N��
	 */
	public String getBASE_CD() {
		if(EmptyField.isEmpty(BASE_CD)){
			return null;
		}
		return BASE_CD;
	}

	/**
	 * set value of ��a�N��
	 * @param newBASE_CD - ��a�N��
	 */
	public void setBASE_CD(String newBASE_CD){
		BASE_CD = newBASE_CD;
	}	
	
	/**
	 * get value of IFRS�����
	 * @return IFRS�����
	 */
	public java.math.BigDecimal getIFRS_INV_RT() {
		if(EmptyField.isEmpty(IFRS_INV_RT)){
			return null;
		}
		return IFRS_INV_RT;
	}

	/**
	 * set value of IFRS�����
	 * @param newIFRS_INV_RT - IFRS�����
	 */
	public void setIFRS_INV_RT(java.math.BigDecimal newIFRS_INV_RT){
		IFRS_INV_RT = newIFRS_INV_RT;
	}	
	
	/**
	 * get value of �ت�����
	 * @return �ت�����
	 */
	public java.math.BigDecimal getBLD_COST() {
		if(EmptyField.isEmpty(BLD_COST)){
			return null;
		}
		return BLD_COST;
	}

	/**
	 * set value of �ت�����
	 * @param newBLD_COST - �ت�����
	 */
	public void setBLD_COST(java.math.BigDecimal newBLD_COST){
		BLD_COST = newBLD_COST;
	}	
	
	/**
	 * get value of �ت���ꦨ��
	 * @return �ت���ꦨ��
	 */
	public java.math.BigDecimal getBLD_COST_INV() {
		if(EmptyField.isEmpty(BLD_COST_INV)){
			return null;
		}
		return BLD_COST_INV;
	}

	/**
	 * set value of �ت���ꦨ��
	 * @param newBLD_COST_INV - �ت���ꦨ��
	 */
	public void setBLD_COST_INV(java.math.BigDecimal newBLD_COST_INV){
		BLD_COST_INV = newBLD_COST_INV;
	}	
	
	/**
	 * get value of �ت��ۥΦ���
	 * @return �ت��ۥΦ���
	 */
	public java.math.BigDecimal getBLD_COST_SLF() {
		if(EmptyField.isEmpty(BLD_COST_SLF)){
			return null;
		}
		return BLD_COST_SLF;
	}

	/**
	 * set value of �ت��ۥΦ���
	 * @param newBLD_COST_SLF - �ت��ۥΦ���
	 */
	public void setBLD_COST_SLF(java.math.BigDecimal newBLD_COST_SLF){
		BLD_COST_SLF = newBLD_COST_SLF;
	}	
	
	/**
	 * get value of �g�a����
	 * @return �g�a����
	 */
	public java.math.BigDecimal getLND_COST() {
		if(EmptyField.isEmpty(LND_COST)){
			return null;
		}
		return LND_COST;
	}

	/**
	 * set value of �g�a����
	 * @param newLND_COST - �g�a����
	 */
	public void setLND_COST(java.math.BigDecimal newLND_COST){
		LND_COST = newLND_COST;
	}	
	
	/**
	 * get value of �g�a��ꦨ��
	 * @return �g�a��ꦨ��
	 */
	public java.math.BigDecimal getLND_COST_INV() {
		if(EmptyField.isEmpty(LND_COST_INV)){
			return null;
		}
		return LND_COST_INV;
	}

	/**
	 * set value of �g�a��ꦨ��
	 * @param newLND_COST_INV - �g�a��ꦨ��
	 */
	public void setLND_COST_INV(java.math.BigDecimal newLND_COST_INV){
		LND_COST_INV = newLND_COST_INV;
	}	
	
	/**
	 * get value of �g�a�ۥΦ���
	 * @return �g�a�ۥΦ���
	 */
	public java.math.BigDecimal getLND_COST_SLF() {
		if(EmptyField.isEmpty(LND_COST_SLF)){
			return null;
		}
		return LND_COST_SLF;
	}

	/**
	 * set value of �g�a�ۥΦ���
	 * @param newLND_COST_SLF - �g�a�ۥΦ���
	 */
	public void setLND_COST_SLF(java.math.BigDecimal newLND_COST_SLF){
		LND_COST_SLF = newLND_COST_SLF;
	}	
	
	/**
	 * get value of �ت���l
	 * @return �ت���l
	 */
	public java.math.BigDecimal getBLD_LOSS() {
		if(EmptyField.isEmpty(BLD_LOSS)){
			return null;
		}
		return BLD_LOSS;
	}

	/**
	 * set value of �ت���l
	 * @param newBLD_LOSS - �ت���l
	 */
	public void setBLD_LOSS(java.math.BigDecimal newBLD_LOSS){
		BLD_LOSS = newBLD_LOSS;
	}	
	
	/**
	 * get value of �ت�����l
	 * @return �ت�����l
	 */
	public java.math.BigDecimal getBLD_LOSS_INV() {
		if(EmptyField.isEmpty(BLD_LOSS_INV)){
			return null;
		}
		return BLD_LOSS_INV;
	}

	/**
	 * set value of �ت�����l
	 * @param newBLD_LOSS_INV - �ت�����l
	 */
	public void setBLD_LOSS_INV(java.math.BigDecimal newBLD_LOSS_INV){
		BLD_LOSS_INV = newBLD_LOSS_INV;
	}	
	
	/**
	 * get value of �ت��ۥδ�l
	 * @return �ت��ۥδ�l
	 */
	public java.math.BigDecimal getBLD_LOSS_SLF() {
		if(EmptyField.isEmpty(BLD_LOSS_SLF)){
			return null;
		}
		return BLD_LOSS_SLF;
	}

	/**
	 * set value of �ت��ۥδ�l
	 * @param newBLD_LOSS_SLF - �ت��ۥδ�l
	 */
	public void setBLD_LOSS_SLF(java.math.BigDecimal newBLD_LOSS_SLF){
		BLD_LOSS_SLF = newBLD_LOSS_SLF;
	}	
	
	/**
	 * get value of �g�a��l
	 * @return �g�a��l
	 */
	public java.math.BigDecimal getLND_LOSS() {
		if(EmptyField.isEmpty(LND_LOSS)){
			return null;
		}
		return LND_LOSS;
	}

	/**
	 * set value of �g�a��l
	 * @param newLND_LOSS - �g�a��l
	 */
	public void setLND_LOSS(java.math.BigDecimal newLND_LOSS){
		LND_LOSS = newLND_LOSS;
	}	
	
	/**
	 * get value of �g�a����l
	 * @return �g�a����l
	 */
	public java.math.BigDecimal getLND_LOSS_INV() {
		if(EmptyField.isEmpty(LND_LOSS_INV)){
			return null;
		}
		return LND_LOSS_INV;
	}

	/**
	 * set value of �g�a����l
	 * @param newLND_LOSS_INV - �g�a����l
	 */
	public void setLND_LOSS_INV(java.math.BigDecimal newLND_LOSS_INV){
		LND_LOSS_INV = newLND_LOSS_INV;
	}	
	
	/**
	 * get value of �g�a�ۥδ�l
	 * @return �g�a�ۥδ�l
	 */
	public java.math.BigDecimal getLND_LOSS_SLF() {
		if(EmptyField.isEmpty(LND_LOSS_SLF)){
			return null;
		}
		return LND_LOSS_SLF;
	}

	/**
	 * set value of �g�a�ۥδ�l
	 * @param newLND_LOSS_SLF - �g�a�ۥδ�l
	 */
	public void setLND_LOSS_SLF(java.math.BigDecimal newLND_LOSS_SLF){
		LND_LOSS_SLF = newLND_LOSS_SLF;
	}	
	
	/**
	 * get value of �ت�IFRS����
	 * @return �ت�IFRS����
	 */
	public java.math.BigDecimal getBLD_IFRS_COST() {
		if(EmptyField.isEmpty(BLD_IFRS_COST)){
			return null;
		}
		return BLD_IFRS_COST;
	}

	/**
	 * set value of �ت�IFRS����
	 * @param newBLD_IFRS_COST - �ت�IFRS����
	 */
	public void setBLD_IFRS_COST(java.math.BigDecimal newBLD_IFRS_COST){
		BLD_IFRS_COST = newBLD_IFRS_COST;
	}	
	
	/**
	 * get value of �ت�IFRS��ꦨ��
	 * @return �ت�IFRS��ꦨ��
	 */
	public java.math.BigDecimal getBLD_IFRS_INV() {
		if(EmptyField.isEmpty(BLD_IFRS_INV)){
			return null;
		}
		return BLD_IFRS_INV;
	}

	/**
	 * set value of �ت�IFRS��ꦨ��
	 * @param newBLD_IFRS_INV - �ت�IFRS��ꦨ��
	 */
	public void setBLD_IFRS_INV(java.math.BigDecimal newBLD_IFRS_INV){
		BLD_IFRS_INV = newBLD_IFRS_INV;
	}	
	
	/**
	 * get value of �ت�IFRS�ۥΦ���
	 * @return �ت�IFRS�ۥΦ���
	 */
	public java.math.BigDecimal getBLD_IFRS_SLF() {
		if(EmptyField.isEmpty(BLD_IFRS_SLF)){
			return null;
		}
		return BLD_IFRS_SLF;
	}

	/**
	 * set value of �ت�IFRS�ۥΦ���
	 * @param newBLD_IFRS_SLF - �ت�IFRS�ۥΦ���
	 */
	public void setBLD_IFRS_SLF(java.math.BigDecimal newBLD_IFRS_SLF){
		BLD_IFRS_SLF = newBLD_IFRS_SLF;
	}	
	
	/**
	 * get value of �g�aIFRS����
	 * @return �g�aIFRS����
	 */
	public java.math.BigDecimal getLND_IFRS_COST() {
		if(EmptyField.isEmpty(LND_IFRS_COST)){
			return null;
		}
		return LND_IFRS_COST;
	}

	/**
	 * set value of �g�aIFRS����
	 * @param newLND_IFRS_COST - �g�aIFRS����
	 */
	public void setLND_IFRS_COST(java.math.BigDecimal newLND_IFRS_COST){
		LND_IFRS_COST = newLND_IFRS_COST;
	}	
	
	/**
	 * get value of �g�aIFRS��ꦨ��
	 * @return �g�aIFRS��ꦨ��
	 */
	public java.math.BigDecimal getLND_IFRS_INV() {
		if(EmptyField.isEmpty(LND_IFRS_INV)){
			return null;
		}
		return LND_IFRS_INV;
	}

	/**
	 * set value of �g�aIFRS��ꦨ��
	 * @param newLND_IFRS_INV - �g�aIFRS��ꦨ��
	 */
	public void setLND_IFRS_INV(java.math.BigDecimal newLND_IFRS_INV){
		LND_IFRS_INV = newLND_IFRS_INV;
	}	
	
	/**
	 * get value of �g�aIFRS�ۥΦ���
	 * @return �g�aIFRS�ۥΦ���
	 */
	public java.math.BigDecimal getLND_IFRS_SLF() {
		if(EmptyField.isEmpty(LND_IFRS_SLF)){
			return null;
		}
		return LND_IFRS_SLF;
	}

	/**
	 * set value of �g�aIFRS�ۥΦ���
	 * @param newLND_IFRS_SLF - �g�aIFRS�ۥΦ���
	 */
	public void setLND_IFRS_SLF(java.math.BigDecimal newLND_IFRS_SLF){
		LND_IFRS_SLF = newLND_IFRS_SLF;
	}	
	
	/**
	 * get value of ����s��
	 * @return ����s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of ����s��
	 * @param newAPLY_NO - ����s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �g�a���n
	 * @return �g�a���n
	 */
	public java.math.BigDecimal getLND_AREA() {
		if(EmptyField.isEmpty(LND_AREA)){
			return null;
		}
		return LND_AREA;
	}

	/**
	 * set value of �g�a���n
	 * @param newLND_AREA - �g�a���n
	 */
	public void setLND_AREA(java.math.BigDecimal newLND_AREA){
		LND_AREA = newLND_AREA;
	}	
	
	/**
	 * get value of �ت����n
	 * @return �ت����n
	 */
	public java.math.BigDecimal getBLD_AREA() {
		if(EmptyField.isEmpty(BLD_AREA)){
			return null;
		}
		return BLD_AREA;
	}

	/**
	 * set value of �ت����n
	 * @param newBLD_AREA - �ت����n
	 */
	public void setBLD_AREA(java.math.BigDecimal newBLD_AREA){
		BLD_AREA = newBLD_AREA;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BASE_CD);
		hcBuilder.append(IFRS_INV_RT);
		hcBuilder.append(BLD_COST);
		hcBuilder.append(BLD_COST_INV);
		hcBuilder.append(BLD_COST_SLF);
		hcBuilder.append(LND_COST);
		hcBuilder.append(LND_COST_INV);
		hcBuilder.append(LND_COST_SLF);
		hcBuilder.append(BLD_LOSS);
		hcBuilder.append(BLD_LOSS_INV);
		hcBuilder.append(BLD_LOSS_SLF);
		hcBuilder.append(LND_LOSS);
		hcBuilder.append(LND_LOSS_INV);
		hcBuilder.append(LND_LOSS_SLF);
		hcBuilder.append(BLD_IFRS_COST);
		hcBuilder.append(BLD_IFRS_INV);
		hcBuilder.append(BLD_IFRS_SLF);
		hcBuilder.append(LND_IFRS_COST);
		hcBuilder.append(LND_IFRS_INV);
		hcBuilder.append(LND_IFRS_SLF);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(LND_AREA);
		hcBuilder.append(BLD_AREA);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPG130)){
			return false;
		}
        
		DTEPG130 theObj = (DTEPG130)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				