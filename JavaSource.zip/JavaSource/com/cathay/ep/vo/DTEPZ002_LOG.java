package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPZ002_LOG
 * <pre>
 * Generated value object of DBEP.DTEPZ002_LOG ()
 * </pre>
 */
public class DTEPZ002_LOG implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPZ002_LOG";
	
	
	@Column(desc="�J�ɤ���ɶ�", pk=true, nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp UPD_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="���1", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=45, defaultValue="") 
	private String KEY1 = EmptyField.STRING;
	
	@Column(desc="���2", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=45, defaultValue="") 
	private String KEY2 = EmptyField.STRING;
	
	@Column(desc="���3", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=45, defaultValue="") 
	private String KEY3 = EmptyField.STRING;
	
	@Column(desc="�ƭ�1", type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String VALUE1 = EmptyField.STRING;
	
	@Column(desc="�ƭ�2", type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String VALUE2 = EmptyField.STRING;
	
	@Column(desc="�ƭ�3", type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String VALUE3 = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="LOG��������", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String UPD_TYPE = EmptyField.STRING;
	
	@Column(desc="LOG���ʤH�����N��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String UPD_DIV_NO = EmptyField.STRING;
	
	@Column(desc="LOG���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String UPD_ID = EmptyField.STRING;
	
	@Column(desc="LOG���ʤH���m�W", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String UPD_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPZ002_LOG(){
		// do nothing	
	}
	
	/**
	 * get value of �J�ɤ���ɶ�
	 * @return �J�ɤ���ɶ�
	 */
	public java.sql.Timestamp getUPD_DATE() {
		if(EmptyField.isEmpty(UPD_DATE)){
			return null;
		}
		return UPD_DATE;
	}

	/**
	 * set value of �J�ɤ���ɶ�
	 * @param newUPD_DATE - �J�ɤ���ɶ�
	 */
	public void setUPD_DATE(java.sql.Timestamp newUPD_DATE){
		UPD_DATE = newUPD_DATE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ���1
	 * @return ���1
	 */
	public String getKEY1() {
		if(EmptyField.isEmpty(KEY1)){
			return null;
		}
		return KEY1;
	}

	/**
	 * set value of ���1
	 * @param newKEY1 - ���1
	 */
	public void setKEY1(String newKEY1){
		KEY1 = newKEY1;
	}	
	
	/**
	 * get value of ���2
	 * @return ���2
	 */
	public String getKEY2() {
		if(EmptyField.isEmpty(KEY2)){
			return null;
		}
		return KEY2;
	}

	/**
	 * set value of ���2
	 * @param newKEY2 - ���2
	 */
	public void setKEY2(String newKEY2){
		KEY2 = newKEY2;
	}	
	
	/**
	 * get value of ���3
	 * @return ���3
	 */
	public String getKEY3() {
		if(EmptyField.isEmpty(KEY3)){
			return null;
		}
		return KEY3;
	}

	/**
	 * set value of ���3
	 * @param newKEY3 - ���3
	 */
	public void setKEY3(String newKEY3){
		KEY3 = newKEY3;
	}	
	
	/**
	 * get value of �ƭ�1
	 * @return �ƭ�1
	 */
	public String getVALUE1() {
		if(EmptyField.isEmpty(VALUE1)){
			return null;
		}
		return VALUE1;
	}

	/**
	 * set value of �ƭ�1
	 * @param newVALUE1 - �ƭ�1
	 */
	public void setVALUE1(String newVALUE1){
		VALUE1 = newVALUE1;
	}	
	
	/**
	 * get value of �ƭ�2
	 * @return �ƭ�2
	 */
	public String getVALUE2() {
		if(EmptyField.isEmpty(VALUE2)){
			return null;
		}
		return VALUE2;
	}

	/**
	 * set value of �ƭ�2
	 * @param newVALUE2 - �ƭ�2
	 */
	public void setVALUE2(String newVALUE2){
		VALUE2 = newVALUE2;
	}	
	
	/**
	 * get value of �ƭ�3
	 * @return �ƭ�3
	 */
	public String getVALUE3() {
		if(EmptyField.isEmpty(VALUE3)){
			return null;
		}
		return VALUE3;
	}

	/**
	 * set value of �ƭ�3
	 * @param newVALUE3 - �ƭ�3
	 */
	public void setVALUE3(String newVALUE3){
		VALUE3 = newVALUE3;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of LOG��������
	 * @return LOG��������
	 */
	public String getUPD_TYPE() {
		if(EmptyField.isEmpty(UPD_TYPE)){
			return null;
		}
		return UPD_TYPE;
	}

	/**
	 * set value of LOG��������
	 * @param newUPD_TYPE - LOG��������
	 */
	public void setUPD_TYPE(String newUPD_TYPE){
		UPD_TYPE = newUPD_TYPE;
	}	
	
	/**
	 * get value of LOG���ʤH�����N��
	 * @return LOG���ʤH�����N��
	 */
	public String getUPD_DIV_NO() {
		if(EmptyField.isEmpty(UPD_DIV_NO)){
			return null;
		}
		return UPD_DIV_NO;
	}

	/**
	 * set value of LOG���ʤH�����N��
	 * @param newUPD_DIV_NO - LOG���ʤH�����N��
	 */
	public void setUPD_DIV_NO(String newUPD_DIV_NO){
		UPD_DIV_NO = newUPD_DIV_NO;
	}	
	
	/**
	 * get value of LOG���ʤH��ID
	 * @return LOG���ʤH��ID
	 */
	public String getUPD_ID() {
		if(EmptyField.isEmpty(UPD_ID)){
			return null;
		}
		return UPD_ID;
	}

	/**
	 * set value of LOG���ʤH��ID
	 * @param newUPD_ID - LOG���ʤH��ID
	 */
	public void setUPD_ID(String newUPD_ID){
		UPD_ID = newUPD_ID;
	}	
	
	/**
	 * get value of LOG���ʤH���m�W
	 * @return LOG���ʤH���m�W
	 */
	public String getUPD_NAME() {
		if(EmptyField.isEmpty(UPD_NAME)){
			return null;
		}
		return UPD_NAME;
	}

	/**
	 * set value of LOG���ʤH���m�W
	 * @param newUPD_NAME - LOG���ʤH���m�W
	 */
	public void setUPD_NAME(String newUPD_NAME){
		UPD_NAME = newUPD_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(UPD_DATE);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(KEY1);
		hcBuilder.append(KEY2);
		hcBuilder.append(KEY3);
		hcBuilder.append(VALUE1);
		hcBuilder.append(VALUE2);
		hcBuilder.append(VALUE3);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(UPD_TYPE);
		hcBuilder.append(UPD_DIV_NO);
		hcBuilder.append(UPD_ID);
		hcBuilder.append(UPD_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPZ002_LOG)){
			return false;
		}
        
		DTEPZ002_LOG theObj = (DTEPZ002_LOG)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				