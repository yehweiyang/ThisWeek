package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC303
 * <pre>
 * Generated value object of DBEP.DTEPC303 (�״ڳ������)
 * </pre>
 */
public class DTEPC303 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC303";
	
	
	@Column(desc="�״ڽs��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String RMT_NO = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="��w�N��", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String BANK_NO = EmptyField.STRING;
	
	@Column(desc="�Ȧ�b��", nullAble=false, type=java.sql.Types.VARCHAR, length=16, defaultValue="") 
	private String ACNT_NO = EmptyField.STRING;
	
	@Column(desc="�״ڤ��", nullAble=false, type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date RMT_DATE = EmptyField.DATE;
	
	@Column(desc="�״ڲո�", nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String RMT_SET_NO = EmptyField.STRING;
	
	@Column(desc="�״ڪ��B", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer RMT_AMT = EmptyField.INTEGER;
	
	@Column(desc="�l������", type=java.sql.Types.CHAR, length=6, defaultValue="") 
	private String CEPSTCD = EmptyField.STRING;
	
	@Column(desc="�l�O", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CEMALAM = EmptyField.INTEGER;
	
	@Column(desc="��J�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INPUT_ID = EmptyField.STRING;
	
	@Column(desc="��J�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String INPUT_NAME = EmptyField.STRING;
	
	@Column(desc="�������ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp TRN_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�g�����Ǹ�", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal TRN_SER_NO = EmptyField.BIGDECIMAL;
	
	@Column(desc="�b�Ȥ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ACNT_DATE = EmptyField.DATE;
	
	@Column(desc="�b�ȳ��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACNT_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��帹", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String SLIP_LOT_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��ո�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SLIP_SET_NO = EmptyField.INTEGER;
	
	/**
	 * Default constructor
	 */
	public DTEPC303(){
		// do nothing	
	}
	
	/**
	 * get value of �״ڽs��
	 * @return �״ڽs��
	 */
	public String getRMT_NO() {
		if(EmptyField.isEmpty(RMT_NO)){
			return null;
		}
		return RMT_NO;
	}

	/**
	 * set value of �״ڽs��
	 * @param newRMT_NO - �״ڽs��
	 */
	public void setRMT_NO(String newRMT_NO){
		RMT_NO = newRMT_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ��w�N��
	 * @return ��w�N��
	 */
	public String getBANK_NO() {
		if(EmptyField.isEmpty(BANK_NO)){
			return null;
		}
		return BANK_NO;
	}

	/**
	 * set value of ��w�N��
	 * @param newBANK_NO - ��w�N��
	 */
	public void setBANK_NO(String newBANK_NO){
		BANK_NO = newBANK_NO;
	}	
	
	/**
	 * get value of �Ȧ�b��
	 * @return �Ȧ�b��
	 */
	public String getACNT_NO() {
		if(EmptyField.isEmpty(ACNT_NO)){
			return null;
		}
		return ACNT_NO;
	}

	/**
	 * set value of �Ȧ�b��
	 * @param newACNT_NO - �Ȧ�b��
	 */
	public void setACNT_NO(String newACNT_NO){
		ACNT_NO = newACNT_NO;
	}	
	
	/**
	 * get value of �״ڤ��
	 * @return �״ڤ��
	 */
	public java.sql.Date getRMT_DATE() {
		if(EmptyField.isEmpty(RMT_DATE)){
			return null;
		}
		return RMT_DATE;
	}

	/**
	 * set value of �״ڤ��
	 * @param newRMT_DATE - �״ڤ��
	 */
	public void setRMT_DATE(java.sql.Date newRMT_DATE){
		RMT_DATE = newRMT_DATE;
	}	
	
	/**
	 * get value of �״ڲո�
	 * @return �״ڲո�
	 */
	public String getRMT_SET_NO() {
		if(EmptyField.isEmpty(RMT_SET_NO)){
			return null;
		}
		return RMT_SET_NO;
	}

	/**
	 * set value of �״ڲո�
	 * @param newRMT_SET_NO - �״ڲո�
	 */
	public void setRMT_SET_NO(String newRMT_SET_NO){
		RMT_SET_NO = newRMT_SET_NO;
	}	
	
	/**
	 * get value of �״ڪ��B
	 * @return �״ڪ��B
	 */
	public Integer getRMT_AMT() {
		if(EmptyField.isEmpty(RMT_AMT)){
			return null;
		}
		return RMT_AMT;
	}

	/**
	 * set value of �״ڪ��B
	 * @param newRMT_AMT - �״ڪ��B
	 */
	public void setRMT_AMT(Integer newRMT_AMT){
		RMT_AMT = newRMT_AMT;
	}	
	
	/**
	 * get value of �l������
	 * @return �l������
	 */
	public String getCEPSTCD() {
		if(EmptyField.isEmpty(CEPSTCD)){
			return null;
		}
		return CEPSTCD;
	}

	/**
	 * set value of �l������
	 * @param newCEPSTCD - �l������
	 */
	public void setCEPSTCD(String newCEPSTCD){
		CEPSTCD = newCEPSTCD;
	}	
	
	/**
	 * get value of �l�O
	 * @return �l�O
	 */
	public Integer getCEMALAM() {
		if(EmptyField.isEmpty(CEMALAM)){
			return null;
		}
		return CEMALAM;
	}

	/**
	 * set value of �l�O
	 * @param newCEMALAM - �l�O
	 */
	public void setCEMALAM(Integer newCEMALAM){
		CEMALAM = newCEMALAM;
	}	
	
	/**
	 * get value of ��J�H��ID
	 * @return ��J�H��ID
	 */
	public String getINPUT_ID() {
		if(EmptyField.isEmpty(INPUT_ID)){
			return null;
		}
		return INPUT_ID;
	}

	/**
	 * set value of ��J�H��ID
	 * @param newINPUT_ID - ��J�H��ID
	 */
	public void setINPUT_ID(String newINPUT_ID){
		INPUT_ID = newINPUT_ID;
	}	
	
	/**
	 * get value of ��J�H���m�W
	 * @return ��J�H���m�W
	 */
	public String getINPUT_NAME() {
		if(EmptyField.isEmpty(INPUT_NAME)){
			return null;
		}
		return INPUT_NAME;
	}

	/**
	 * set value of ��J�H���m�W
	 * @param newINPUT_NAME - ��J�H���m�W
	 */
	public void setINPUT_NAME(String newINPUT_NAME){
		INPUT_NAME = newINPUT_NAME;
	}	
	
	/**
	 * get value of �������ɶ�
	 * @return �������ɶ�
	 */
	public java.sql.Timestamp getTRN_DATE() {
		if(EmptyField.isEmpty(TRN_DATE)){
			return null;
		}
		return TRN_DATE;
	}

	/**
	 * set value of �������ɶ�
	 * @param newTRN_DATE - �������ɶ�
	 */
	public void setTRN_DATE(java.sql.Timestamp newTRN_DATE){
		TRN_DATE = newTRN_DATE;
	}	
	
	/**
	 * get value of �g�����Ǹ�
	 * @return �g�����Ǹ�
	 */
	public java.math.BigDecimal getTRN_SER_NO() {
		if(EmptyField.isEmpty(TRN_SER_NO)){
			return null;
		}
		return TRN_SER_NO;
	}

	/**
	 * set value of �g�����Ǹ�
	 * @param newTRN_SER_NO - �g�����Ǹ�
	 */
	public void setTRN_SER_NO(java.math.BigDecimal newTRN_SER_NO){
		TRN_SER_NO = newTRN_SER_NO;
	}	
	
	/**
	 * get value of �b�Ȥ��
	 * @return �b�Ȥ��
	 */
	public java.sql.Date getACNT_DATE() {
		if(EmptyField.isEmpty(ACNT_DATE)){
			return null;
		}
		return ACNT_DATE;
	}

	/**
	 * set value of �b�Ȥ��
	 * @param newACNT_DATE - �b�Ȥ��
	 */
	public void setACNT_DATE(java.sql.Date newACNT_DATE){
		ACNT_DATE = newACNT_DATE;
	}	
	
	/**
	 * get value of �b�ȳ��
	 * @return �b�ȳ��
	 */
	public String getACNT_DIV_NO() {
		if(EmptyField.isEmpty(ACNT_DIV_NO)){
			return null;
		}
		return ACNT_DIV_NO;
	}

	/**
	 * set value of �b�ȳ��
	 * @param newACNT_DIV_NO - �b�ȳ��
	 */
	public void setACNT_DIV_NO(String newACNT_DIV_NO){
		ACNT_DIV_NO = newACNT_DIV_NO;
	}	
	
	/**
	 * get value of �ǲ��帹
	 * @return �ǲ��帹
	 */
	public String getSLIP_LOT_NO() {
		if(EmptyField.isEmpty(SLIP_LOT_NO)){
			return null;
		}
		return SLIP_LOT_NO;
	}

	/**
	 * set value of �ǲ��帹
	 * @param newSLIP_LOT_NO - �ǲ��帹
	 */
	public void setSLIP_LOT_NO(String newSLIP_LOT_NO){
		SLIP_LOT_NO = newSLIP_LOT_NO;
	}	
	
	/**
	 * get value of �ǲ��ո�
	 * @return �ǲ��ո�
	 */
	public Integer getSLIP_SET_NO() {
		if(EmptyField.isEmpty(SLIP_SET_NO)){
			return null;
		}
		return SLIP_SET_NO;
	}

	/**
	 * set value of �ǲ��ո�
	 * @param newSLIP_SET_NO - �ǲ��ո�
	 */
	public void setSLIP_SET_NO(Integer newSLIP_SET_NO){
		SLIP_SET_NO = newSLIP_SET_NO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(RMT_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BANK_NO);
		hcBuilder.append(ACNT_NO);
		hcBuilder.append(RMT_DATE);
		hcBuilder.append(RMT_SET_NO);
		hcBuilder.append(RMT_AMT);
		hcBuilder.append(CEPSTCD);
		hcBuilder.append(CEMALAM);
		hcBuilder.append(INPUT_ID);
		hcBuilder.append(INPUT_NAME);
		hcBuilder.append(TRN_DATE);
		hcBuilder.append(TRN_SER_NO);
		hcBuilder.append(ACNT_DATE);
		hcBuilder.append(ACNT_DIV_NO);
		hcBuilder.append(SLIP_LOT_NO);
		hcBuilder.append(SLIP_SET_NO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC303)){
			return false;
		}
        
		DTEPC303 theObj = (DTEPC303)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				