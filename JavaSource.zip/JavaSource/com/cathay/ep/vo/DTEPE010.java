package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPE010
 * <pre>
 * Generated value object of DBEP.DTEPE010 (�Ȥ�A��_���D��ĳ�O���D��)
 * </pre>
 */
public class DTEPE010 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPE010";
	
	
	@Column(desc="���D��s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String PS_SER_NO = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�Ȥ�s��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CUS_ID = EmptyField.STRING;
	
	@Column(desc="�ҥ󸹽X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ID = EmptyField.STRING;
	
	@Column(desc="�Ȥ�m�W", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String CUS_NAME = EmptyField.STRING;
	
	@Column(desc="�t�Υӳ����", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp PS_DATETIME = EmptyField.TIMESTAMP;
	
	@Column(desc="�ӳ��覡", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String PS_TYPE = EmptyField.STRING;
	
	@Column(desc="�ӳ��@�~�i��", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String PS_STATUS = EmptyField.STRING;
	
	@Column(desc="�ӳ��H��", nullAble=false, type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String PS_NAME = EmptyField.STRING;
	
	@Column(desc="�q�T���", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String PS_TEL_PHONE = EmptyField.STRING;
	
	@Column(desc="�q�T�q�ܡX�ϰ�X", type=java.sql.Types.VARCHAR, length=4, defaultValue="") 
	private String PS_TEL_ARA_NO = EmptyField.STRING;
	
	@Column(desc="�q�T�q�ܡX�q��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String PS_TEL_NO = EmptyField.STRING;
	
	@Column(desc="�q�T�q�ܡX����", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String PS_TEL_EXT_NO = EmptyField.STRING;
	
	@Column(desc="�q�TE-MAIL", type=java.sql.Types.VARCHAR, length=50, defaultValue="") 
	private String PS_EMAIL = EmptyField.STRING;
	
	@Column(desc="���D�y�z", type=java.sql.Types.VARCHAR, length=1200, defaultValue="") 
	private String PS_MEMO = EmptyField.STRING;
	
	@Column(desc="���D�ɮ׽s��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String PS_FILE_NO = EmptyField.STRING;
	
	@Column(desc="��J�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INS_ID = EmptyField.STRING;
	
	@Column(desc="��J����ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp INS_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="��J���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String INS_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�j�Ӹg��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String BLD_USR_ID = EmptyField.STRING;
	
	@Column(desc="�ӿ�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String TAKE_ID = EmptyField.STRING;
	
	@Column(desc="�ӿ���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String TAKE_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ӿ�@�~�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String TAKE_USER_ID = EmptyField.STRING;
	
	@Column(desc="�t�Ωӿ�ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp TAKE_DATETIME = EmptyField.TIMESTAMP;
	
	@Column(desc="�ӿ��Ю�ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String TAKE_REVIEW_ID = EmptyField.STRING;
	
	@Column(desc="�ӿ��Ю֤���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp TAKE_REVIEW_DATETIME = EmptyField.TIMESTAMP;
	
	@Column(desc="�ӿ��Юֳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String TAKE_REVIEW_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ӿ��ɮ׽s��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String TAKE_FILE_NO = EmptyField.STRING;
	
	@Column(desc="�ӿ���D����", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String TAKE_TYPE = EmptyField.STRING;
	
	@Column(desc="�ӿ�^�ЫȤ�", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String TAKE_IS_NOTICE = EmptyField.STRING;
	
	@Column(desc="²�T�q���Ȥ�", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String TAKE_NOTICE_TYPE = EmptyField.STRING;
	
	@Column(desc="²�T�q���N�X", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String SMS_NOTICE_ID = EmptyField.STRING;
	
	@Column(desc="EMAIL_�q���N�X", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String EMAIL_NOTICE_ID = EmptyField.STRING;
	
	@Column(desc="�ӿ�^�гq��", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String TAKE_RE_MEMO = EmptyField.STRING;
	
	@Column(desc="���פH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CLOSE_ID = EmptyField.STRING;
	
	@Column(desc="���׳��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CLOSE_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�t�ε��׮ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CLOSE_DATETIME = EmptyField.TIMESTAMP;
	
	@Column(desc="�����Ю�ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CLOSE_REVIEW_ID = EmptyField.STRING;
	
	@Column(desc="�����Ю֤���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CLOSE_REVIEW_DATETIME = EmptyField.TIMESTAMP;
	
	@Column(desc="�����Юֳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CLOSE_REVIEW_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���צ^�гq��", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String CLOSE_RE_MEMO = EmptyField.STRING;
	
	@Column(desc="���׳B�z����", type=java.sql.Types.VARCHAR, length=450, defaultValue="") 
	private String CLOSE_PRO_MEMO = EmptyField.STRING;
	
	@Column(desc="���ק�s�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CLOSE_CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ק�s�ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CLOSE_CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ק�s���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CLOSE_CHG_DIV_NO = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPE010(){
		// do nothing	
	}
	
	/**
	 * get value of ���D��s��
	 * @return ���D��s��
	 */
	public String getPS_SER_NO() {
		if(EmptyField.isEmpty(PS_SER_NO)){
			return null;
		}
		return PS_SER_NO;
	}

	/**
	 * set value of ���D��s��
	 * @param newPS_SER_NO - ���D��s��
	 */
	public void setPS_SER_NO(String newPS_SER_NO){
		PS_SER_NO = newPS_SER_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �Ȥ�s��
	 * @return �Ȥ�s��
	 */
	public String getCUS_ID() {
		if(EmptyField.isEmpty(CUS_ID)){
			return null;
		}
		return CUS_ID;
	}

	/**
	 * set value of �Ȥ�s��
	 * @param newCUS_ID - �Ȥ�s��
	 */
	public void setCUS_ID(String newCUS_ID){
		CUS_ID = newCUS_ID;
	}	
	
	/**
	 * get value of �ҥ󸹽X
	 * @return �ҥ󸹽X
	 */
	public String getID() {
		if(EmptyField.isEmpty(ID)){
			return null;
		}
		return ID;
	}

	/**
	 * set value of �ҥ󸹽X
	 * @param newID - �ҥ󸹽X
	 */
	public void setID(String newID){
		ID = newID;
	}	
	
	/**
	 * get value of �Ȥ�m�W
	 * @return �Ȥ�m�W
	 */
	public String getCUS_NAME() {
		if(EmptyField.isEmpty(CUS_NAME)){
			return null;
		}
		return CUS_NAME;
	}

	/**
	 * set value of �Ȥ�m�W
	 * @param newCUS_NAME - �Ȥ�m�W
	 */
	public void setCUS_NAME(String newCUS_NAME){
		CUS_NAME = newCUS_NAME;
	}	
	
	/**
	 * get value of �t�Υӳ����
	 * @return �t�Υӳ����
	 */
	public java.sql.Timestamp getPS_DATETIME() {
		if(EmptyField.isEmpty(PS_DATETIME)){
			return null;
		}
		return PS_DATETIME;
	}

	/**
	 * set value of �t�Υӳ����
	 * @param newPS_DATETIME - �t�Υӳ����
	 */
	public void setPS_DATETIME(java.sql.Timestamp newPS_DATETIME){
		PS_DATETIME = newPS_DATETIME;
	}	
	
	/**
	 * get value of �ӳ��覡
	 * @return �ӳ��覡
	 */
	public String getPS_TYPE() {
		if(EmptyField.isEmpty(PS_TYPE)){
			return null;
		}
		return PS_TYPE;
	}

	/**
	 * set value of �ӳ��覡
	 * @param newPS_TYPE - �ӳ��覡
	 */
	public void setPS_TYPE(String newPS_TYPE){
		PS_TYPE = newPS_TYPE;
	}	
	
	/**
	 * get value of �ӳ��@�~�i��
	 * @return �ӳ��@�~�i��
	 */
	public String getPS_STATUS() {
		if(EmptyField.isEmpty(PS_STATUS)){
			return null;
		}
		return PS_STATUS;
	}

	/**
	 * set value of �ӳ��@�~�i��
	 * @param newPS_STATUS - �ӳ��@�~�i��
	 */
	public void setPS_STATUS(String newPS_STATUS){
		PS_STATUS = newPS_STATUS;
	}	
	
	/**
	 * get value of �ӳ��H��
	 * @return �ӳ��H��
	 */
	public String getPS_NAME() {
		if(EmptyField.isEmpty(PS_NAME)){
			return null;
		}
		return PS_NAME;
	}

	/**
	 * set value of �ӳ��H��
	 * @param newPS_NAME - �ӳ��H��
	 */
	public void setPS_NAME(String newPS_NAME){
		PS_NAME = newPS_NAME;
	}	
	
	/**
	 * get value of �q�T���
	 * @return �q�T���
	 */
	public String getPS_TEL_PHONE() {
		if(EmptyField.isEmpty(PS_TEL_PHONE)){
			return null;
		}
		return PS_TEL_PHONE;
	}

	/**
	 * set value of �q�T���
	 * @param newPS_TEL_PHONE - �q�T���
	 */
	public void setPS_TEL_PHONE(String newPS_TEL_PHONE){
		PS_TEL_PHONE = newPS_TEL_PHONE;
	}	
	
	/**
	 * get value of �q�T�q�ܡX�ϰ�X
	 * @return �q�T�q�ܡX�ϰ�X
	 */
	public String getPS_TEL_ARA_NO() {
		if(EmptyField.isEmpty(PS_TEL_ARA_NO)){
			return null;
		}
		return PS_TEL_ARA_NO;
	}

	/**
	 * set value of �q�T�q�ܡX�ϰ�X
	 * @param newPS_TEL_ARA_NO - �q�T�q�ܡX�ϰ�X
	 */
	public void setPS_TEL_ARA_NO(String newPS_TEL_ARA_NO){
		PS_TEL_ARA_NO = newPS_TEL_ARA_NO;
	}	
	
	/**
	 * get value of �q�T�q�ܡX�q��
	 * @return �q�T�q�ܡX�q��
	 */
	public String getPS_TEL_NO() {
		if(EmptyField.isEmpty(PS_TEL_NO)){
			return null;
		}
		return PS_TEL_NO;
	}

	/**
	 * set value of �q�T�q�ܡX�q��
	 * @param newPS_TEL_NO - �q�T�q�ܡX�q��
	 */
	public void setPS_TEL_NO(String newPS_TEL_NO){
		PS_TEL_NO = newPS_TEL_NO;
	}	
	
	/**
	 * get value of �q�T�q�ܡX����
	 * @return �q�T�q�ܡX����
	 */
	public String getPS_TEL_EXT_NO() {
		if(EmptyField.isEmpty(PS_TEL_EXT_NO)){
			return null;
		}
		return PS_TEL_EXT_NO;
	}

	/**
	 * set value of �q�T�q�ܡX����
	 * @param newPS_TEL_EXT_NO - �q�T�q�ܡX����
	 */
	public void setPS_TEL_EXT_NO(String newPS_TEL_EXT_NO){
		PS_TEL_EXT_NO = newPS_TEL_EXT_NO;
	}	
	
	/**
	 * get value of �q�TE-MAIL
	 * @return �q�TE-MAIL
	 */
	public String getPS_EMAIL() {
		if(EmptyField.isEmpty(PS_EMAIL)){
			return null;
		}
		return PS_EMAIL;
	}

	/**
	 * set value of �q�TE-MAIL
	 * @param newPS_EMAIL - �q�TE-MAIL
	 */
	public void setPS_EMAIL(String newPS_EMAIL){
		PS_EMAIL = newPS_EMAIL;
	}	
	
	/**
	 * get value of ���D�y�z
	 * @return ���D�y�z
	 */
	public String getPS_MEMO() {
		if(EmptyField.isEmpty(PS_MEMO)){
			return null;
		}
		return PS_MEMO;
	}

	/**
	 * set value of ���D�y�z
	 * @param newPS_MEMO - ���D�y�z
	 */
	public void setPS_MEMO(String newPS_MEMO){
		PS_MEMO = newPS_MEMO;
	}	
	
	/**
	 * get value of ���D�ɮ׽s��
	 * @return ���D�ɮ׽s��
	 */
	public String getPS_FILE_NO() {
		if(EmptyField.isEmpty(PS_FILE_NO)){
			return null;
		}
		return PS_FILE_NO;
	}

	/**
	 * set value of ���D�ɮ׽s��
	 * @param newPS_FILE_NO - ���D�ɮ׽s��
	 */
	public void setPS_FILE_NO(String newPS_FILE_NO){
		PS_FILE_NO = newPS_FILE_NO;
	}	
	
	/**
	 * get value of ��J�H��ID
	 * @return ��J�H��ID
	 */
	public String getINS_ID() {
		if(EmptyField.isEmpty(INS_ID)){
			return null;
		}
		return INS_ID;
	}

	/**
	 * set value of ��J�H��ID
	 * @param newINS_ID - ��J�H��ID
	 */
	public void setINS_ID(String newINS_ID){
		INS_ID = newINS_ID;
	}	
	
	/**
	 * get value of ��J����ɶ�
	 * @return ��J����ɶ�
	 */
	public java.sql.Timestamp getINS_DATE() {
		if(EmptyField.isEmpty(INS_DATE)){
			return null;
		}
		return INS_DATE;
	}

	/**
	 * set value of ��J����ɶ�
	 * @param newINS_DATE - ��J����ɶ�
	 */
	public void setINS_DATE(java.sql.Timestamp newINS_DATE){
		INS_DATE = newINS_DATE;
	}	
	
	/**
	 * get value of ��J���
	 * @return ��J���
	 */
	public String getINS_DIV_NO() {
		if(EmptyField.isEmpty(INS_DIV_NO)){
			return null;
		}
		return INS_DIV_NO;
	}

	/**
	 * set value of ��J���
	 * @param newINS_DIV_NO - ��J���
	 */
	public void setINS_DIV_NO(String newINS_DIV_NO){
		INS_DIV_NO = newINS_DIV_NO;
	}	
	
	/**
	 * get value of �j�Ӹg��ID
	 * @return �j�Ӹg��ID
	 */
	public String getBLD_USR_ID() {
		if(EmptyField.isEmpty(BLD_USR_ID)){
			return null;
		}
		return BLD_USR_ID;
	}

	/**
	 * set value of �j�Ӹg��ID
	 * @param newBLD_USR_ID - �j�Ӹg��ID
	 */
	public void setBLD_USR_ID(String newBLD_USR_ID){
		BLD_USR_ID = newBLD_USR_ID;
	}	
	
	/**
	 * get value of �ӿ�H��ID
	 * @return �ӿ�H��ID
	 */
	public String getTAKE_ID() {
		if(EmptyField.isEmpty(TAKE_ID)){
			return null;
		}
		return TAKE_ID;
	}

	/**
	 * set value of �ӿ�H��ID
	 * @param newTAKE_ID - �ӿ�H��ID
	 */
	public void setTAKE_ID(String newTAKE_ID){
		TAKE_ID = newTAKE_ID;
	}	
	
	/**
	 * get value of �ӿ���
	 * @return �ӿ���
	 */
	public String getTAKE_DIV_NO() {
		if(EmptyField.isEmpty(TAKE_DIV_NO)){
			return null;
		}
		return TAKE_DIV_NO;
	}

	/**
	 * set value of �ӿ���
	 * @param newTAKE_DIV_NO - �ӿ���
	 */
	public void setTAKE_DIV_NO(String newTAKE_DIV_NO){
		TAKE_DIV_NO = newTAKE_DIV_NO;
	}	
	
	/**
	 * get value of �ӿ�@�~�H��ID
	 * @return �ӿ�@�~�H��ID
	 */
	public String getTAKE_USER_ID() {
		if(EmptyField.isEmpty(TAKE_USER_ID)){
			return null;
		}
		return TAKE_USER_ID;
	}

	/**
	 * set value of �ӿ�@�~�H��ID
	 * @param newTAKE_USER_ID - �ӿ�@�~�H��ID
	 */
	public void setTAKE_USER_ID(String newTAKE_USER_ID){
		TAKE_USER_ID = newTAKE_USER_ID;
	}	
	
	/**
	 * get value of �t�Ωӿ�ɶ�
	 * @return �t�Ωӿ�ɶ�
	 */
	public java.sql.Timestamp getTAKE_DATETIME() {
		if(EmptyField.isEmpty(TAKE_DATETIME)){
			return null;
		}
		return TAKE_DATETIME;
	}

	/**
	 * set value of �t�Ωӿ�ɶ�
	 * @param newTAKE_DATETIME - �t�Ωӿ�ɶ�
	 */
	public void setTAKE_DATETIME(java.sql.Timestamp newTAKE_DATETIME){
		TAKE_DATETIME = newTAKE_DATETIME;
	}	
	
	/**
	 * get value of �ӿ��Ю�ID
	 * @return �ӿ��Ю�ID
	 */
	public String getTAKE_REVIEW_ID() {
		if(EmptyField.isEmpty(TAKE_REVIEW_ID)){
			return null;
		}
		return TAKE_REVIEW_ID;
	}

	/**
	 * set value of �ӿ��Ю�ID
	 * @param newTAKE_REVIEW_ID - �ӿ��Ю�ID
	 */
	public void setTAKE_REVIEW_ID(String newTAKE_REVIEW_ID){
		TAKE_REVIEW_ID = newTAKE_REVIEW_ID;
	}	
	
	/**
	 * get value of �ӿ��Ю֤���ɶ�
	 * @return �ӿ��Ю֤���ɶ�
	 */
	public java.sql.Timestamp getTAKE_REVIEW_DATETIME() {
		if(EmptyField.isEmpty(TAKE_REVIEW_DATETIME)){
			return null;
		}
		return TAKE_REVIEW_DATETIME;
	}

	/**
	 * set value of �ӿ��Ю֤���ɶ�
	 * @param newTAKE_REVIEW_DATETIME - �ӿ��Ю֤���ɶ�
	 */
	public void setTAKE_REVIEW_DATETIME(java.sql.Timestamp newTAKE_REVIEW_DATETIME){
		TAKE_REVIEW_DATETIME = newTAKE_REVIEW_DATETIME;
	}	
	
	/**
	 * get value of �ӿ��Юֳ��
	 * @return �ӿ��Юֳ��
	 */
	public String getTAKE_REVIEW_DIV_NO() {
		if(EmptyField.isEmpty(TAKE_REVIEW_DIV_NO)){
			return null;
		}
		return TAKE_REVIEW_DIV_NO;
	}

	/**
	 * set value of �ӿ��Юֳ��
	 * @param newTAKE_REVIEW_DIV_NO - �ӿ��Юֳ��
	 */
	public void setTAKE_REVIEW_DIV_NO(String newTAKE_REVIEW_DIV_NO){
		TAKE_REVIEW_DIV_NO = newTAKE_REVIEW_DIV_NO;
	}	
	
	/**
	 * get value of �ӿ��ɮ׽s��
	 * @return �ӿ��ɮ׽s��
	 */
	public String getTAKE_FILE_NO() {
		if(EmptyField.isEmpty(TAKE_FILE_NO)){
			return null;
		}
		return TAKE_FILE_NO;
	}

	/**
	 * set value of �ӿ��ɮ׽s��
	 * @param newTAKE_FILE_NO - �ӿ��ɮ׽s��
	 */
	public void setTAKE_FILE_NO(String newTAKE_FILE_NO){
		TAKE_FILE_NO = newTAKE_FILE_NO;
	}	
	
	/**
	 * get value of �ӿ���D����
	 * @return �ӿ���D����
	 */
	public String getTAKE_TYPE() {
		if(EmptyField.isEmpty(TAKE_TYPE)){
			return null;
		}
		return TAKE_TYPE;
	}

	/**
	 * set value of �ӿ���D����
	 * @param newTAKE_TYPE - �ӿ���D����
	 */
	public void setTAKE_TYPE(String newTAKE_TYPE){
		TAKE_TYPE = newTAKE_TYPE;
	}	
	
	/**
	 * get value of �ӿ�^�ЫȤ�
	 * @return �ӿ�^�ЫȤ�
	 */
	public String getTAKE_IS_NOTICE() {
		if(EmptyField.isEmpty(TAKE_IS_NOTICE)){
			return null;
		}
		return TAKE_IS_NOTICE;
	}

	/**
	 * set value of �ӿ�^�ЫȤ�
	 * @param newTAKE_IS_NOTICE - �ӿ�^�ЫȤ�
	 */
	public void setTAKE_IS_NOTICE(String newTAKE_IS_NOTICE){
		TAKE_IS_NOTICE = newTAKE_IS_NOTICE;
	}	
	
	/**
	 * get value of ²�T�q���Ȥ�
	 * @return ²�T�q���Ȥ�
	 */
	public String getTAKE_NOTICE_TYPE() {
		if(EmptyField.isEmpty(TAKE_NOTICE_TYPE)){
			return null;
		}
		return TAKE_NOTICE_TYPE;
	}

	/**
	 * set value of ²�T�q���Ȥ�
	 * @param newTAKE_NOTICE_TYPE - ²�T�q���Ȥ�
	 */
	public void setTAKE_NOTICE_TYPE(String newTAKE_NOTICE_TYPE){
		TAKE_NOTICE_TYPE = newTAKE_NOTICE_TYPE;
	}	
	
	/**
	 * get value of ²�T�q���N�X
	 * @return ²�T�q���N�X
	 */
	public String getSMS_NOTICE_ID() {
		if(EmptyField.isEmpty(SMS_NOTICE_ID)){
			return null;
		}
		return SMS_NOTICE_ID;
	}

	/**
	 * set value of ²�T�q���N�X
	 * @param newSMS_NOTICE_ID - ²�T�q���N�X
	 */
	public void setSMS_NOTICE_ID(String newSMS_NOTICE_ID){
		SMS_NOTICE_ID = newSMS_NOTICE_ID;
	}	
	
	/**
	 * get value of EMAIL_�q���N�X
	 * @return EMAIL_�q���N�X
	 */
	public String getEMAIL_NOTICE_ID() {
		if(EmptyField.isEmpty(EMAIL_NOTICE_ID)){
			return null;
		}
		return EMAIL_NOTICE_ID;
	}

	/**
	 * set value of EMAIL_�q���N�X
	 * @param newEMAIL_NOTICE_ID - EMAIL_�q���N�X
	 */
	public void setEMAIL_NOTICE_ID(String newEMAIL_NOTICE_ID){
		EMAIL_NOTICE_ID = newEMAIL_NOTICE_ID;
	}	
	
	/**
	 * get value of �ӿ�^�гq��
	 * @return �ӿ�^�гq��
	 */
	public String getTAKE_RE_MEMO() {
		if(EmptyField.isEmpty(TAKE_RE_MEMO)){
			return null;
		}
		return TAKE_RE_MEMO;
	}

	/**
	 * set value of �ӿ�^�гq��
	 * @param newTAKE_RE_MEMO - �ӿ�^�гq��
	 */
	public void setTAKE_RE_MEMO(String newTAKE_RE_MEMO){
		TAKE_RE_MEMO = newTAKE_RE_MEMO;
	}	
	
	/**
	 * get value of ���פH��ID
	 * @return ���פH��ID
	 */
	public String getCLOSE_ID() {
		if(EmptyField.isEmpty(CLOSE_ID)){
			return null;
		}
		return CLOSE_ID;
	}

	/**
	 * set value of ���פH��ID
	 * @param newCLOSE_ID - ���פH��ID
	 */
	public void setCLOSE_ID(String newCLOSE_ID){
		CLOSE_ID = newCLOSE_ID;
	}	
	
	/**
	 * get value of ���׳��
	 * @return ���׳��
	 */
	public String getCLOSE_DIV_NO() {
		if(EmptyField.isEmpty(CLOSE_DIV_NO)){
			return null;
		}
		return CLOSE_DIV_NO;
	}

	/**
	 * set value of ���׳��
	 * @param newCLOSE_DIV_NO - ���׳��
	 */
	public void setCLOSE_DIV_NO(String newCLOSE_DIV_NO){
		CLOSE_DIV_NO = newCLOSE_DIV_NO;
	}	
	
	/**
	 * get value of �t�ε��׮ɶ�
	 * @return �t�ε��׮ɶ�
	 */
	public java.sql.Timestamp getCLOSE_DATETIME() {
		if(EmptyField.isEmpty(CLOSE_DATETIME)){
			return null;
		}
		return CLOSE_DATETIME;
	}

	/**
	 * set value of �t�ε��׮ɶ�
	 * @param newCLOSE_DATETIME - �t�ε��׮ɶ�
	 */
	public void setCLOSE_DATETIME(java.sql.Timestamp newCLOSE_DATETIME){
		CLOSE_DATETIME = newCLOSE_DATETIME;
	}	
	
	/**
	 * get value of �����Ю�ID
	 * @return �����Ю�ID
	 */
	public String getCLOSE_REVIEW_ID() {
		if(EmptyField.isEmpty(CLOSE_REVIEW_ID)){
			return null;
		}
		return CLOSE_REVIEW_ID;
	}

	/**
	 * set value of �����Ю�ID
	 * @param newCLOSE_REVIEW_ID - �����Ю�ID
	 */
	public void setCLOSE_REVIEW_ID(String newCLOSE_REVIEW_ID){
		CLOSE_REVIEW_ID = newCLOSE_REVIEW_ID;
	}	
	
	/**
	 * get value of �����Ю֤���ɶ�
	 * @return �����Ю֤���ɶ�
	 */
	public java.sql.Timestamp getCLOSE_REVIEW_DATETIME() {
		if(EmptyField.isEmpty(CLOSE_REVIEW_DATETIME)){
			return null;
		}
		return CLOSE_REVIEW_DATETIME;
	}

	/**
	 * set value of �����Ю֤���ɶ�
	 * @param newCLOSE_REVIEW_DATETIME - �����Ю֤���ɶ�
	 */
	public void setCLOSE_REVIEW_DATETIME(java.sql.Timestamp newCLOSE_REVIEW_DATETIME){
		CLOSE_REVIEW_DATETIME = newCLOSE_REVIEW_DATETIME;
	}	
	
	/**
	 * get value of �����Юֳ��
	 * @return �����Юֳ��
	 */
	public String getCLOSE_REVIEW_DIV_NO() {
		if(EmptyField.isEmpty(CLOSE_REVIEW_DIV_NO)){
			return null;
		}
		return CLOSE_REVIEW_DIV_NO;
	}

	/**
	 * set value of �����Юֳ��
	 * @param newCLOSE_REVIEW_DIV_NO - �����Юֳ��
	 */
	public void setCLOSE_REVIEW_DIV_NO(String newCLOSE_REVIEW_DIV_NO){
		CLOSE_REVIEW_DIV_NO = newCLOSE_REVIEW_DIV_NO;
	}	
	
	/**
	 * get value of ���צ^�гq��
	 * @return ���צ^�гq��
	 */
	public String getCLOSE_RE_MEMO() {
		if(EmptyField.isEmpty(CLOSE_RE_MEMO)){
			return null;
		}
		return CLOSE_RE_MEMO;
	}

	/**
	 * set value of ���צ^�гq��
	 * @param newCLOSE_RE_MEMO - ���צ^�гq��
	 */
	public void setCLOSE_RE_MEMO(String newCLOSE_RE_MEMO){
		CLOSE_RE_MEMO = newCLOSE_RE_MEMO;
	}	
	
	/**
	 * get value of ���׳B�z����
	 * @return ���׳B�z����
	 */
	public String getCLOSE_PRO_MEMO() {
		if(EmptyField.isEmpty(CLOSE_PRO_MEMO)){
			return null;
		}
		return CLOSE_PRO_MEMO;
	}

	/**
	 * set value of ���׳B�z����
	 * @param newCLOSE_PRO_MEMO - ���׳B�z����
	 */
	public void setCLOSE_PRO_MEMO(String newCLOSE_PRO_MEMO){
		CLOSE_PRO_MEMO = newCLOSE_PRO_MEMO;
	}	
	
	/**
	 * get value of ���ק�s�H��ID
	 * @return ���ק�s�H��ID
	 */
	public String getCLOSE_CHG_ID() {
		if(EmptyField.isEmpty(CLOSE_CHG_ID)){
			return null;
		}
		return CLOSE_CHG_ID;
	}

	/**
	 * set value of ���ק�s�H��ID
	 * @param newCLOSE_CHG_ID - ���ק�s�H��ID
	 */
	public void setCLOSE_CHG_ID(String newCLOSE_CHG_ID){
		CLOSE_CHG_ID = newCLOSE_CHG_ID;
	}	
	
	/**
	 * get value of ���ק�s�ɶ�
	 * @return ���ק�s�ɶ�
	 */
	public java.sql.Timestamp getCLOSE_CHG_DATE() {
		if(EmptyField.isEmpty(CLOSE_CHG_DATE)){
			return null;
		}
		return CLOSE_CHG_DATE;
	}

	/**
	 * set value of ���ק�s�ɶ�
	 * @param newCLOSE_CHG_DATE - ���ק�s�ɶ�
	 */
	public void setCLOSE_CHG_DATE(java.sql.Timestamp newCLOSE_CHG_DATE){
		CLOSE_CHG_DATE = newCLOSE_CHG_DATE;
	}	
	
	/**
	 * get value of ���ק�s���
	 * @return ���ק�s���
	 */
	public String getCLOSE_CHG_DIV_NO() {
		if(EmptyField.isEmpty(CLOSE_CHG_DIV_NO)){
			return null;
		}
		return CLOSE_CHG_DIV_NO;
	}

	/**
	 * set value of ���ק�s���
	 * @param newCLOSE_CHG_DIV_NO - ���ק�s���
	 */
	public void setCLOSE_CHG_DIV_NO(String newCLOSE_CHG_DIV_NO){
		CLOSE_CHG_DIV_NO = newCLOSE_CHG_DIV_NO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(PS_SER_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(CUS_ID);
		hcBuilder.append(ID);
		hcBuilder.append(CUS_NAME);
		hcBuilder.append(PS_DATETIME);
		hcBuilder.append(PS_TYPE);
		hcBuilder.append(PS_STATUS);
		hcBuilder.append(PS_NAME);
		hcBuilder.append(PS_TEL_PHONE);
		hcBuilder.append(PS_TEL_ARA_NO);
		hcBuilder.append(PS_TEL_NO);
		hcBuilder.append(PS_TEL_EXT_NO);
		hcBuilder.append(PS_EMAIL);
		hcBuilder.append(PS_MEMO);
		hcBuilder.append(PS_FILE_NO);
		hcBuilder.append(INS_ID);
		hcBuilder.append(INS_DATE);
		hcBuilder.append(INS_DIV_NO);
		hcBuilder.append(BLD_USR_ID);
		hcBuilder.append(TAKE_ID);
		hcBuilder.append(TAKE_DIV_NO);
		hcBuilder.append(TAKE_USER_ID);
		hcBuilder.append(TAKE_DATETIME);
		hcBuilder.append(TAKE_REVIEW_ID);
		hcBuilder.append(TAKE_REVIEW_DATETIME);
		hcBuilder.append(TAKE_REVIEW_DIV_NO);
		hcBuilder.append(TAKE_FILE_NO);
		hcBuilder.append(TAKE_TYPE);
		hcBuilder.append(TAKE_IS_NOTICE);
		hcBuilder.append(TAKE_NOTICE_TYPE);
		hcBuilder.append(SMS_NOTICE_ID);
		hcBuilder.append(EMAIL_NOTICE_ID);
		hcBuilder.append(TAKE_RE_MEMO);
		hcBuilder.append(CLOSE_ID);
		hcBuilder.append(CLOSE_DIV_NO);
		hcBuilder.append(CLOSE_DATETIME);
		hcBuilder.append(CLOSE_REVIEW_ID);
		hcBuilder.append(CLOSE_REVIEW_DATETIME);
		hcBuilder.append(CLOSE_REVIEW_DIV_NO);
		hcBuilder.append(CLOSE_RE_MEMO);
		hcBuilder.append(CLOSE_PRO_MEMO);
		hcBuilder.append(CLOSE_CHG_ID);
		hcBuilder.append(CLOSE_CHG_DATE);
		hcBuilder.append(CLOSE_CHG_DIV_NO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPE010)){
			return false;
		}
        
		DTEPE010 theObj = (DTEPE010)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				