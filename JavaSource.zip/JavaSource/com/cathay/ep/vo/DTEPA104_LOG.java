package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPA104_LOG
 * <pre>
 * Generated value object of DBEP.DTEPA104_LOG (�j��_����Ψ�L�O����LOG)
 * </pre>
 */
public class DTEPA104_LOG implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPA104_LOG";
	
	
	@Column(desc="�J�ɤ���ɶ�", pk=true, nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp UPD_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="����N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String PRK_NO = EmptyField.STRING;
	
	@Column(desc="�X������", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String RNT_KIND = EmptyField.STRING;
	
	@Column(desc="�����N��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�ϥΪ̦W��", type=java.sql.Types.VARCHAR, length=60, defaultValue="") 
	private String USR_NAME = EmptyField.STRING;
	
	@Column(desc="������", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String PRK_PER = EmptyField.STRING;
	
	@Column(desc="����", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String CAR_NO = EmptyField.STRING;
	
	@Column(desc="�ϥΪ��p", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String USE_TYPE = EmptyField.STRING;
	
	@Column(desc="�믲��", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal CAR_RNT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�_�����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date RNT_STR_DATE = EmptyField.DATE;
	
	@Column(desc="�������", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date RNT_END_DATE = EmptyField.DATE;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	@Column(desc="�J�ɮץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String UPD_APLY_NO = EmptyField.STRING;
	
	@Column(desc="�J�ɥ������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String UPD_TRN_KIND = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPA104_LOG(){
		// do nothing	
	}
	
	/**
	 * get value of �J�ɤ���ɶ�
	 * @return �J�ɤ���ɶ�
	 */
	public java.sql.Timestamp getUPD_DATE() {
		if(EmptyField.isEmpty(UPD_DATE)){
			return null;
		}
		return UPD_DATE;
	}

	/**
	 * set value of �J�ɤ���ɶ�
	 * @param newUPD_DATE - �J�ɤ���ɶ�
	 */
	public void setUPD_DATE(java.sql.Timestamp newUPD_DATE){
		UPD_DATE = newUPD_DATE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of ����N��
	 * @return ����N��
	 */
	public String getPRK_NO() {
		if(EmptyField.isEmpty(PRK_NO)){
			return null;
		}
		return PRK_NO;
	}

	/**
	 * set value of ����N��
	 * @param newPRK_NO - ����N��
	 */
	public void setPRK_NO(String newPRK_NO){
		PRK_NO = newPRK_NO;
	}	
	
	/**
	 * get value of �X������
	 * @return �X������
	 */
	public String getRNT_KIND() {
		if(EmptyField.isEmpty(RNT_KIND)){
			return null;
		}
		return RNT_KIND;
	}

	/**
	 * set value of �X������
	 * @param newRNT_KIND - �X������
	 */
	public void setRNT_KIND(String newRNT_KIND){
		RNT_KIND = newRNT_KIND;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �ϥΪ̦W��
	 * @return �ϥΪ̦W��
	 */
	public String getUSR_NAME() {
		if(EmptyField.isEmpty(USR_NAME)){
			return null;
		}
		return USR_NAME;
	}

	/**
	 * set value of �ϥΪ̦W��
	 * @param newUSR_NAME - �ϥΪ̦W��
	 */
	public void setUSR_NAME(String newUSR_NAME){
		USR_NAME = newUSR_NAME;
	}	
	
	/**
	 * get value of ������
	 * @return ������
	 */
	public String getPRK_PER() {
		if(EmptyField.isEmpty(PRK_PER)){
			return null;
		}
		return PRK_PER;
	}

	/**
	 * set value of ������
	 * @param newPRK_PER - ������
	 */
	public void setPRK_PER(String newPRK_PER){
		PRK_PER = newPRK_PER;
	}	
	
	/**
	 * get value of ����
	 * @return ����
	 */
	public String getCAR_NO() {
		if(EmptyField.isEmpty(CAR_NO)){
			return null;
		}
		return CAR_NO;
	}

	/**
	 * set value of ����
	 * @param newCAR_NO - ����
	 */
	public void setCAR_NO(String newCAR_NO){
		CAR_NO = newCAR_NO;
	}	
	
	/**
	 * get value of �ϥΪ��p
	 * @return �ϥΪ��p
	 */
	public String getUSE_TYPE() {
		if(EmptyField.isEmpty(USE_TYPE)){
			return null;
		}
		return USE_TYPE;
	}

	/**
	 * set value of �ϥΪ��p
	 * @param newUSE_TYPE - �ϥΪ��p
	 */
	public void setUSE_TYPE(String newUSE_TYPE){
		USE_TYPE = newUSE_TYPE;
	}	
	
	/**
	 * get value of �믲��
	 * @return �믲��
	 */
	public java.math.BigDecimal getCAR_RNT_AMT() {
		if(EmptyField.isEmpty(CAR_RNT_AMT)){
			return null;
		}
		return CAR_RNT_AMT;
	}

	/**
	 * set value of �믲��
	 * @param newCAR_RNT_AMT - �믲��
	 */
	public void setCAR_RNT_AMT(java.math.BigDecimal newCAR_RNT_AMT){
		CAR_RNT_AMT = newCAR_RNT_AMT;
	}	
	
	/**
	 * get value of �_�����
	 * @return �_�����
	 */
	public java.sql.Date getRNT_STR_DATE() {
		if(EmptyField.isEmpty(RNT_STR_DATE)){
			return null;
		}
		return RNT_STR_DATE;
	}

	/**
	 * set value of �_�����
	 * @param newRNT_STR_DATE - �_�����
	 */
	public void setRNT_STR_DATE(java.sql.Date newRNT_STR_DATE){
		RNT_STR_DATE = newRNT_STR_DATE;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public java.sql.Date getRNT_END_DATE() {
		if(EmptyField.isEmpty(RNT_END_DATE)){
			return null;
		}
		return RNT_END_DATE;
	}

	/**
	 * set value of �������
	 * @param newRNT_END_DATE - �������
	 */
	public void setRNT_END_DATE(java.sql.Date newRNT_END_DATE){
		RNT_END_DATE = newRNT_END_DATE;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * get value of �J�ɮץ�s��
	 * @return �J�ɮץ�s��
	 */
	public String getUPD_APLY_NO() {
		if(EmptyField.isEmpty(UPD_APLY_NO)){
			return null;
		}
		return UPD_APLY_NO;
	}

	/**
	 * set value of �J�ɮץ�s��
	 * @param newUPD_APLY_NO - �J�ɮץ�s��
	 */
	public void setUPD_APLY_NO(String newUPD_APLY_NO){
		UPD_APLY_NO = newUPD_APLY_NO;
	}	
	
	/**
	 * get value of �J�ɥ������
	 * @return �J�ɥ������
	 */
	public String getUPD_TRN_KIND() {
		if(EmptyField.isEmpty(UPD_TRN_KIND)){
			return null;
		}
		return UPD_TRN_KIND;
	}

	/**
	 * set value of �J�ɥ������
	 * @param newUPD_TRN_KIND - �J�ɥ������
	 */
	public void setUPD_TRN_KIND(String newUPD_TRN_KIND){
		UPD_TRN_KIND = newUPD_TRN_KIND;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(UPD_DATE);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(PRK_NO);
		hcBuilder.append(RNT_KIND);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(USR_NAME);
		hcBuilder.append(PRK_PER);
		hcBuilder.append(CAR_NO);
		hcBuilder.append(USE_TYPE);
		hcBuilder.append(CAR_RNT_AMT);
		hcBuilder.append(RNT_STR_DATE);
		hcBuilder.append(RNT_END_DATE);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(TRN_KIND);
		hcBuilder.append(UPD_APLY_NO);
		hcBuilder.append(UPD_TRN_KIND);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPA104_LOG)){
			return false;
		}
        
		DTEPA104_LOG theObj = (DTEPA104_LOG)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				