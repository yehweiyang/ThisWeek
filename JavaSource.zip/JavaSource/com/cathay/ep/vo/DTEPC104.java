package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC104
 * <pre>
 * Generated value object of DBEP.DTEPC104 (�w��������������)
 * </pre>
 */
public class DTEPC104 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC104";
	
	
	@Column(desc="�����s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String RCV_NO = EmptyField.STRING;
	
	@Column(desc="�ഫ�~��", pk=true, nullAble=false, type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal TRN_YM = EmptyField.BIGDECIMAL;
	
	@Column(desc="ú�ں���", nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String PAY_KIND = EmptyField.STRING;
	
	@Column(desc="�����N��", nullAble=false, type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�ӿ���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ҥ󸹽X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ID = EmptyField.STRING;
	
	@Column(desc="�Ȥ�W��", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String CUS_NAME = EmptyField.STRING;
	
	@Column(desc="�o�����X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INV_NO = EmptyField.STRING;
	
	@Column(desc="�g�L�Ѽ�", type=java.sql.Types.DECIMAL, length=5, defaultValue="") 
	private java.math.BigDecimal PASS_DAY = EmptyField.BIGDECIMAL;
	
	@Column(desc="�w���l��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date PRP_S_DATE = EmptyField.DATE;
	
	@Column(desc="�w���״�", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date PRP_E_DATE = EmptyField.DATE;
	
	@Column(desc="���������B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PRP_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�����", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp EXT_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�b�Ȥ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ACNT_DATE = EmptyField.DATE;
	
	@Column(desc="�b�ȤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACNT_ID = EmptyField.STRING;
	
	@Column(desc="�b�ȤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String ACNT_NAME = EmptyField.STRING;
	
	@Column(desc="�b�ȳ��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACNT_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��帹", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String SLIP_LOT_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��ո�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SLIP_SET_NO = EmptyField.INTEGER;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�j�Ӹg��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String BLD_USR_ID = EmptyField.STRING;
	
	@Column(desc="�j�Ӹg��m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String BLD_USR_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPC104(){
		// do nothing	
	}
	
	/**
	 * get value of �����s��
	 * @return �����s��
	 */
	public String getRCV_NO() {
		if(EmptyField.isEmpty(RCV_NO)){
			return null;
		}
		return RCV_NO;
	}

	/**
	 * set value of �����s��
	 * @param newRCV_NO - �����s��
	 */
	public void setRCV_NO(String newRCV_NO){
		RCV_NO = newRCV_NO;
	}	
	
	/**
	 * get value of �ഫ�~��
	 * @return �ഫ�~��
	 */
	public java.math.BigDecimal getTRN_YM() {
		if(EmptyField.isEmpty(TRN_YM)){
			return null;
		}
		return TRN_YM;
	}

	/**
	 * set value of �ഫ�~��
	 * @param newTRN_YM - �ഫ�~��
	 */
	public void setTRN_YM(java.math.BigDecimal newTRN_YM){
		TRN_YM = newTRN_YM;
	}	
	
	/**
	 * get value of ú�ں���
	 * @return ú�ں���
	 */
	public String getPAY_KIND() {
		if(EmptyField.isEmpty(PAY_KIND)){
			return null;
		}
		return PAY_KIND;
	}

	/**
	 * set value of ú�ں���
	 * @param newPAY_KIND - ú�ں���
	 */
	public void setPAY_KIND(String newPAY_KIND){
		PAY_KIND = newPAY_KIND;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �ӿ���
	 * @return �ӿ���
	 */
	public String getDIV_NO() {
		if(EmptyField.isEmpty(DIV_NO)){
			return null;
		}
		return DIV_NO;
	}

	/**
	 * set value of �ӿ���
	 * @param newDIV_NO - �ӿ���
	 */
	public void setDIV_NO(String newDIV_NO){
		DIV_NO = newDIV_NO;
	}	
	
	/**
	 * get value of �ҥ󸹽X
	 * @return �ҥ󸹽X
	 */
	public String getID() {
		if(EmptyField.isEmpty(ID)){
			return null;
		}
		return ID;
	}

	/**
	 * set value of �ҥ󸹽X
	 * @param newID - �ҥ󸹽X
	 */
	public void setID(String newID){
		ID = newID;
	}	
	
	/**
	 * get value of �Ȥ�W��
	 * @return �Ȥ�W��
	 */
	public String getCUS_NAME() {
		if(EmptyField.isEmpty(CUS_NAME)){
			return null;
		}
		return CUS_NAME;
	}

	/**
	 * set value of �Ȥ�W��
	 * @param newCUS_NAME - �Ȥ�W��
	 */
	public void setCUS_NAME(String newCUS_NAME){
		CUS_NAME = newCUS_NAME;
	}	
	
	/**
	 * get value of �o�����X
	 * @return �o�����X
	 */
	public String getINV_NO() {
		if(EmptyField.isEmpty(INV_NO)){
			return null;
		}
		return INV_NO;
	}

	/**
	 * set value of �o�����X
	 * @param newINV_NO - �o�����X
	 */
	public void setINV_NO(String newINV_NO){
		INV_NO = newINV_NO;
	}	
	
	/**
	 * get value of �g�L�Ѽ�
	 * @return �g�L�Ѽ�
	 */
	public java.math.BigDecimal getPASS_DAY() {
		if(EmptyField.isEmpty(PASS_DAY)){
			return null;
		}
		return PASS_DAY;
	}

	/**
	 * set value of �g�L�Ѽ�
	 * @param newPASS_DAY - �g�L�Ѽ�
	 */
	public void setPASS_DAY(java.math.BigDecimal newPASS_DAY){
		PASS_DAY = newPASS_DAY;
	}	
	
	/**
	 * get value of �w���l��
	 * @return �w���l��
	 */
	public java.sql.Date getPRP_S_DATE() {
		if(EmptyField.isEmpty(PRP_S_DATE)){
			return null;
		}
		return PRP_S_DATE;
	}

	/**
	 * set value of �w���l��
	 * @param newPRP_S_DATE - �w���l��
	 */
	public void setPRP_S_DATE(java.sql.Date newPRP_S_DATE){
		PRP_S_DATE = newPRP_S_DATE;
	}	
	
	/**
	 * get value of �w���״�
	 * @return �w���״�
	 */
	public java.sql.Date getPRP_E_DATE() {
		if(EmptyField.isEmpty(PRP_E_DATE)){
			return null;
		}
		return PRP_E_DATE;
	}

	/**
	 * set value of �w���״�
	 * @param newPRP_E_DATE - �w���״�
	 */
	public void setPRP_E_DATE(java.sql.Date newPRP_E_DATE){
		PRP_E_DATE = newPRP_E_DATE;
	}	
	
	/**
	 * get value of ���������B
	 * @return ���������B
	 */
	public java.math.BigDecimal getPRP_AMT() {
		if(EmptyField.isEmpty(PRP_AMT)){
			return null;
		}
		return PRP_AMT;
	}

	/**
	 * set value of ���������B
	 * @param newPRP_AMT - ���������B
	 */
	public void setPRP_AMT(java.math.BigDecimal newPRP_AMT){
		PRP_AMT = newPRP_AMT;
	}	
	
	/**
	 * get value of �����
	 * @return �����
	 */
	public java.sql.Timestamp getEXT_DATE() {
		if(EmptyField.isEmpty(EXT_DATE)){
			return null;
		}
		return EXT_DATE;
	}

	/**
	 * set value of �����
	 * @param newEXT_DATE - �����
	 */
	public void setEXT_DATE(java.sql.Timestamp newEXT_DATE){
		EXT_DATE = newEXT_DATE;
	}	
	
	/**
	 * get value of �b�Ȥ��
	 * @return �b�Ȥ��
	 */
	public java.sql.Date getACNT_DATE() {
		if(EmptyField.isEmpty(ACNT_DATE)){
			return null;
		}
		return ACNT_DATE;
	}

	/**
	 * set value of �b�Ȥ��
	 * @param newACNT_DATE - �b�Ȥ��
	 */
	public void setACNT_DATE(java.sql.Date newACNT_DATE){
		ACNT_DATE = newACNT_DATE;
	}	
	
	/**
	 * get value of �b�ȤH��ID
	 * @return �b�ȤH��ID
	 */
	public String getACNT_ID() {
		if(EmptyField.isEmpty(ACNT_ID)){
			return null;
		}
		return ACNT_ID;
	}

	/**
	 * set value of �b�ȤH��ID
	 * @param newACNT_ID - �b�ȤH��ID
	 */
	public void setACNT_ID(String newACNT_ID){
		ACNT_ID = newACNT_ID;
	}	
	
	/**
	 * get value of �b�ȤH���m�W
	 * @return �b�ȤH���m�W
	 */
	public String getACNT_NAME() {
		if(EmptyField.isEmpty(ACNT_NAME)){
			return null;
		}
		return ACNT_NAME;
	}

	/**
	 * set value of �b�ȤH���m�W
	 * @param newACNT_NAME - �b�ȤH���m�W
	 */
	public void setACNT_NAME(String newACNT_NAME){
		ACNT_NAME = newACNT_NAME;
	}	
	
	/**
	 * get value of �b�ȳ��
	 * @return �b�ȳ��
	 */
	public String getACNT_DIV_NO() {
		if(EmptyField.isEmpty(ACNT_DIV_NO)){
			return null;
		}
		return ACNT_DIV_NO;
	}

	/**
	 * set value of �b�ȳ��
	 * @param newACNT_DIV_NO - �b�ȳ��
	 */
	public void setACNT_DIV_NO(String newACNT_DIV_NO){
		ACNT_DIV_NO = newACNT_DIV_NO;
	}	
	
	/**
	 * get value of �ǲ��帹
	 * @return �ǲ��帹
	 */
	public String getSLIP_LOT_NO() {
		if(EmptyField.isEmpty(SLIP_LOT_NO)){
			return null;
		}
		return SLIP_LOT_NO;
	}

	/**
	 * set value of �ǲ��帹
	 * @param newSLIP_LOT_NO - �ǲ��帹
	 */
	public void setSLIP_LOT_NO(String newSLIP_LOT_NO){
		SLIP_LOT_NO = newSLIP_LOT_NO;
	}	
	
	/**
	 * get value of �ǲ��ո�
	 * @return �ǲ��ո�
	 */
	public Integer getSLIP_SET_NO() {
		if(EmptyField.isEmpty(SLIP_SET_NO)){
			return null;
		}
		return SLIP_SET_NO;
	}

	/**
	 * set value of �ǲ��ո�
	 * @param newSLIP_SET_NO - �ǲ��ո�
	 */
	public void setSLIP_SET_NO(Integer newSLIP_SET_NO){
		SLIP_SET_NO = newSLIP_SET_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �j�Ӹg��ID
	 * @return �j�Ӹg��ID
	 */
	public String getBLD_USR_ID() {
		if(EmptyField.isEmpty(BLD_USR_ID)){
			return null;
		}
		return BLD_USR_ID;
	}

	/**
	 * set value of �j�Ӹg��ID
	 * @param newBLD_USR_ID - �j�Ӹg��ID
	 */
	public void setBLD_USR_ID(String newBLD_USR_ID){
		BLD_USR_ID = newBLD_USR_ID;
	}	
	
	/**
	 * get value of �j�Ӹg��m�W
	 * @return �j�Ӹg��m�W
	 */
	public String getBLD_USR_NAME() {
		if(EmptyField.isEmpty(BLD_USR_NAME)){
			return null;
		}
		return BLD_USR_NAME;
	}

	/**
	 * set value of �j�Ӹg��m�W
	 * @param newBLD_USR_NAME - �j�Ӹg��m�W
	 */
	public void setBLD_USR_NAME(String newBLD_USR_NAME){
		BLD_USR_NAME = newBLD_USR_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(RCV_NO);
		hcBuilder.append(TRN_YM);
		hcBuilder.append(PAY_KIND);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(DIV_NO);
		hcBuilder.append(ID);
		hcBuilder.append(CUS_NAME);
		hcBuilder.append(INV_NO);
		hcBuilder.append(PASS_DAY);
		hcBuilder.append(PRP_S_DATE);
		hcBuilder.append(PRP_E_DATE);
		hcBuilder.append(PRP_AMT);
		hcBuilder.append(EXT_DATE);
		hcBuilder.append(ACNT_DATE);
		hcBuilder.append(ACNT_ID);
		hcBuilder.append(ACNT_NAME);
		hcBuilder.append(ACNT_DIV_NO);
		hcBuilder.append(SLIP_LOT_NO);
		hcBuilder.append(SLIP_SET_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(BLD_USR_ID);
		hcBuilder.append(BLD_USR_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC104)){
			return false;
		}
        
		DTEPC104 theObj = (DTEPC104)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				