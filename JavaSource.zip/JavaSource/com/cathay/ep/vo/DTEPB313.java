package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPB313
 * <pre>
 * Generated value object of DBEP.DTEPB313 (�ץ�_�j�ӼӼh�ܧ����)
 * </pre>
 */
public class DTEPB313 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPB313";
	
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�å��Ǹ�", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String TRS_SEQ = EmptyField.STRING;
	
	@Column(desc="�������", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String DATA_TYPE = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="��a�N��", nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BASE_CD = EmptyField.STRING;
	
	@Column(desc="���O", nullAble=false, type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String KIND = EmptyField.STRING;
	
	@Column(desc="�ت��a�}", type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String BLD_ADDR = EmptyField.STRING;
	
	@Column(desc="�|�y�s��", type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String TAX_NO = EmptyField.STRING;
	
	@Column(desc="�a�q", type=java.sql.Types.VARCHAR, length=75, defaultValue="") 
	private String LND_SEC = EmptyField.STRING;
	
	@Column(desc="�a��", type=java.sql.Types.VARCHAR, length=75, defaultValue="") 
	private String LND_NO = EmptyField.STRING;
	
	@Column(desc="�Ƶ�", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String TRS_MEMO = EmptyField.STRING;
	
	@Column(desc="���n", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal TRS_AREA = EmptyField.BIGDECIMAL;
	
	@Column(desc="����(���l)", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String HD_NM = EmptyField.STRING;
	
	@Column(desc="����(����)", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String HD_DM = EmptyField.STRING;
	
	@Column(desc="�å����A", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String TRS_STS = EmptyField.STRING;
	
	@Column(desc="��a�g�a���", type=java.sql.Types.DECIMAL, length=5, defaultValue="1") 
	private java.math.BigDecimal LND_RT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ɮ׽s��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String TRS_FILE_NO = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPB313(){
		// do nothing	
	}
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �å��Ǹ�
	 * @return �å��Ǹ�
	 */
	public String getTRS_SEQ() {
		if(EmptyField.isEmpty(TRS_SEQ)){
			return null;
		}
		return TRS_SEQ;
	}

	/**
	 * set value of �å��Ǹ�
	 * @param newTRS_SEQ - �å��Ǹ�
	 */
	public void setTRS_SEQ(String newTRS_SEQ){
		TRS_SEQ = newTRS_SEQ;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getDATA_TYPE() {
		if(EmptyField.isEmpty(DATA_TYPE)){
			return null;
		}
		return DATA_TYPE;
	}

	/**
	 * set value of �������
	 * @param newDATA_TYPE - �������
	 */
	public void setDATA_TYPE(String newDATA_TYPE){
		DATA_TYPE = newDATA_TYPE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ��a�N��
	 * @return ��a�N��
	 */
	public String getBASE_CD() {
		if(EmptyField.isEmpty(BASE_CD)){
			return null;
		}
		return BASE_CD;
	}

	/**
	 * set value of ��a�N��
	 * @param newBASE_CD - ��a�N��
	 */
	public void setBASE_CD(String newBASE_CD){
		BASE_CD = newBASE_CD;
	}	
	
	/**
	 * get value of ���O
	 * @return ���O
	 */
	public String getKIND() {
		if(EmptyField.isEmpty(KIND)){
			return null;
		}
		return KIND;
	}

	/**
	 * set value of ���O
	 * @param newKIND - ���O
	 */
	public void setKIND(String newKIND){
		KIND = newKIND;
	}	
	
	/**
	 * get value of �ت��a�}
	 * @return �ت��a�}
	 */
	public String getBLD_ADDR() {
		if(EmptyField.isEmpty(BLD_ADDR)){
			return null;
		}
		return BLD_ADDR;
	}

	/**
	 * set value of �ت��a�}
	 * @param newBLD_ADDR - �ت��a�}
	 */
	public void setBLD_ADDR(String newBLD_ADDR){
		BLD_ADDR = newBLD_ADDR;
	}	
	
	/**
	 * get value of �|�y�s��
	 * @return �|�y�s��
	 */
	public String getTAX_NO() {
		if(EmptyField.isEmpty(TAX_NO)){
			return null;
		}
		return TAX_NO;
	}

	/**
	 * set value of �|�y�s��
	 * @param newTAX_NO - �|�y�s��
	 */
	public void setTAX_NO(String newTAX_NO){
		TAX_NO = newTAX_NO;
	}	
	
	/**
	 * get value of �a�q
	 * @return �a�q
	 */
	public String getLND_SEC() {
		if(EmptyField.isEmpty(LND_SEC)){
			return null;
		}
		return LND_SEC;
	}

	/**
	 * set value of �a�q
	 * @param newLND_SEC - �a�q
	 */
	public void setLND_SEC(String newLND_SEC){
		LND_SEC = newLND_SEC;
	}	
	
	/**
	 * get value of �a��
	 * @return �a��
	 */
	public String getLND_NO() {
		if(EmptyField.isEmpty(LND_NO)){
			return null;
		}
		return LND_NO;
	}

	/**
	 * set value of �a��
	 * @param newLND_NO - �a��
	 */
	public void setLND_NO(String newLND_NO){
		LND_NO = newLND_NO;
	}	
	
	/**
	 * get value of �Ƶ�
	 * @return �Ƶ�
	 */
	public String getTRS_MEMO() {
		if(EmptyField.isEmpty(TRS_MEMO)){
			return null;
		}
		return TRS_MEMO;
	}

	/**
	 * set value of �Ƶ�
	 * @param newTRS_MEMO - �Ƶ�
	 */
	public void setTRS_MEMO(String newTRS_MEMO){
		TRS_MEMO = newTRS_MEMO;
	}	
	
	/**
	 * get value of ���n
	 * @return ���n
	 */
	public java.math.BigDecimal getTRS_AREA() {
		if(EmptyField.isEmpty(TRS_AREA)){
			return null;
		}
		return TRS_AREA;
	}

	/**
	 * set value of ���n
	 * @param newTRS_AREA - ���n
	 */
	public void setTRS_AREA(java.math.BigDecimal newTRS_AREA){
		TRS_AREA = newTRS_AREA;
	}	
	
	/**
	 * get value of ����(���l)
	 * @return ����(���l)
	 */
	public String getHD_NM() {
		if(EmptyField.isEmpty(HD_NM)){
			return null;
		}
		return HD_NM;
	}

	/**
	 * set value of ����(���l)
	 * @param newHD_NM - ����(���l)
	 */
	public void setHD_NM(String newHD_NM){
		HD_NM = newHD_NM;
	}	
	
	/**
	 * get value of ����(����)
	 * @return ����(����)
	 */
	public String getHD_DM() {
		if(EmptyField.isEmpty(HD_DM)){
			return null;
		}
		return HD_DM;
	}

	/**
	 * set value of ����(����)
	 * @param newHD_DM - ����(����)
	 */
	public void setHD_DM(String newHD_DM){
		HD_DM = newHD_DM;
	}	
	
	/**
	 * get value of �å����A
	 * @return �å����A
	 */
	public String getTRS_STS() {
		if(EmptyField.isEmpty(TRS_STS)){
			return null;
		}
		return TRS_STS;
	}

	/**
	 * set value of �å����A
	 * @param newTRS_STS - �å����A
	 */
	public void setTRS_STS(String newTRS_STS){
		TRS_STS = newTRS_STS;
	}	
	
	/**
	 * get value of ��a�g�a���
	 * @return ��a�g�a���
	 */
	public java.math.BigDecimal getLND_RT() {
		if(EmptyField.isEmpty(LND_RT)){
			return null;
		}
		return LND_RT;
	}

	/**
	 * set value of ��a�g�a���
	 * @param newLND_RT - ��a�g�a���
	 */
	public void setLND_RT(java.math.BigDecimal newLND_RT){
		LND_RT = newLND_RT;
	}	
	
	/**
	 * get value of �ɮ׽s��
	 * @return �ɮ׽s��
	 */
	public String getTRS_FILE_NO() {
		if(EmptyField.isEmpty(TRS_FILE_NO)){
			return null;
		}
		return TRS_FILE_NO;
	}

	/**
	 * set value of �ɮ׽s��
	 * @param newTRS_FILE_NO - �ɮ׽s��
	 */
	public void setTRS_FILE_NO(String newTRS_FILE_NO){
		TRS_FILE_NO = newTRS_FILE_NO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(APLY_NO);
		hcBuilder.append(TRS_SEQ);
		hcBuilder.append(DATA_TYPE);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BASE_CD);
		hcBuilder.append(KIND);
		hcBuilder.append(BLD_ADDR);
		hcBuilder.append(TAX_NO);
		hcBuilder.append(LND_SEC);
		hcBuilder.append(LND_NO);
		hcBuilder.append(TRS_MEMO);
		hcBuilder.append(TRS_AREA);
		hcBuilder.append(HD_NM);
		hcBuilder.append(HD_DM);
		hcBuilder.append(TRS_STS);
		hcBuilder.append(LND_RT);
		hcBuilder.append(TRS_FILE_NO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPB313)){
			return false;
		}
        
		DTEPB313 theObj = (DTEPB313)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				