package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPZ111
 * <pre>
 * Generated value object of DBEP.DTEPZ111 ()
 * </pre>
 */
public class DTEPZ111 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPZ111";
	
	
	@Column(desc="�ƥ�����ɶ�", pk=true, nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp BACKUP_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�@�~���O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String DIV_TP = EmptyField.STRING;
	
	@Column(desc="�����Ҧr��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String EMPLOYEE_ID = EmptyField.STRING;
	
	@Column(desc="���N��", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String DIV_NO = EmptyField.STRING;
	
	@Column(desc="���²��", type=java.sql.Types.VARCHAR, length=60, defaultValue="") 
	private String DIV_SHORT_NAME = EmptyField.STRING;
	
	@Column(desc="����N��", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String ORI_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String NAME = EmptyField.STRING;
	
	@Column(desc="���u�s��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String EMP_NO = EmptyField.STRING;
	
	@Column(desc="EMAIL", type=java.sql.Types.VARCHAR, length=50, defaultValue="") 
	private String EMAIL = EmptyField.STRING;
	
	@Column(desc="�D��¾", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String IS_MGR = EmptyField.STRING;
	
	@Column(desc="�W�Ǥ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date UPLOAD_DATE = EmptyField.DATE;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="���q�q��", type=java.sql.Types.VARCHAR, length=22, defaultValue="") 
	private String INSTITUTION_PHONE = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPZ111(){
		// do nothing	
	}
	
	/**
	 * get value of �ƥ�����ɶ�
	 * @return �ƥ�����ɶ�
	 */
	public java.sql.Timestamp getBACKUP_DATE() {
		if(EmptyField.isEmpty(BACKUP_DATE)){
			return null;
		}
		return BACKUP_DATE;
	}

	/**
	 * set value of �ƥ�����ɶ�
	 * @param newBACKUP_DATE - �ƥ�����ɶ�
	 */
	public void setBACKUP_DATE(java.sql.Timestamp newBACKUP_DATE){
		BACKUP_DATE = newBACKUP_DATE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �@�~���O
	 * @return �@�~���O
	 */
	public String getDIV_TP() {
		if(EmptyField.isEmpty(DIV_TP)){
			return null;
		}
		return DIV_TP;
	}

	/**
	 * set value of �@�~���O
	 * @param newDIV_TP - �@�~���O
	 */
	public void setDIV_TP(String newDIV_TP){
		DIV_TP = newDIV_TP;
	}	
	
	/**
	 * get value of �����Ҧr��
	 * @return �����Ҧr��
	 */
	public String getEMPLOYEE_ID() {
		if(EmptyField.isEmpty(EMPLOYEE_ID)){
			return null;
		}
		return EMPLOYEE_ID;
	}

	/**
	 * set value of �����Ҧr��
	 * @param newEMPLOYEE_ID - �����Ҧr��
	 */
	public void setEMPLOYEE_ID(String newEMPLOYEE_ID){
		EMPLOYEE_ID = newEMPLOYEE_ID;
	}	
	
	/**
	 * get value of ���N��
	 * @return ���N��
	 */
	public String getDIV_NO() {
		if(EmptyField.isEmpty(DIV_NO)){
			return null;
		}
		return DIV_NO;
	}

	/**
	 * set value of ���N��
	 * @param newDIV_NO - ���N��
	 */
	public void setDIV_NO(String newDIV_NO){
		DIV_NO = newDIV_NO;
	}	
	
	/**
	 * get value of ���²��
	 * @return ���²��
	 */
	public String getDIV_SHORT_NAME() {
		if(EmptyField.isEmpty(DIV_SHORT_NAME)){
			return null;
		}
		return DIV_SHORT_NAME;
	}

	/**
	 * set value of ���²��
	 * @param newDIV_SHORT_NAME - ���²��
	 */
	public void setDIV_SHORT_NAME(String newDIV_SHORT_NAME){
		DIV_SHORT_NAME = newDIV_SHORT_NAME;
	}	
	
	/**
	 * get value of ����N��
	 * @return ����N��
	 */
	public String getORI_DIV_NO() {
		if(EmptyField.isEmpty(ORI_DIV_NO)){
			return null;
		}
		return ORI_DIV_NO;
	}

	/**
	 * set value of ����N��
	 * @param newORI_DIV_NO - ����N��
	 */
	public void setORI_DIV_NO(String newORI_DIV_NO){
		ORI_DIV_NO = newORI_DIV_NO;
	}	
	
	/**
	 * get value of �m�W
	 * @return �m�W
	 */
	public String getNAME() {
		if(EmptyField.isEmpty(NAME)){
			return null;
		}
		return NAME;
	}

	/**
	 * set value of �m�W
	 * @param newNAME - �m�W
	 */
	public void setNAME(String newNAME){
		NAME = newNAME;
	}	
	
	/**
	 * get value of ���u�s��
	 * @return ���u�s��
	 */
	public String getEMP_NO() {
		if(EmptyField.isEmpty(EMP_NO)){
			return null;
		}
		return EMP_NO;
	}

	/**
	 * set value of ���u�s��
	 * @param newEMP_NO - ���u�s��
	 */
	public void setEMP_NO(String newEMP_NO){
		EMP_NO = newEMP_NO;
	}	
	
	/**
	 * get value of EMAIL
	 * @return EMAIL
	 */
	public String getEMAIL() {
		if(EmptyField.isEmpty(EMAIL)){
			return null;
		}
		return EMAIL;
	}

	/**
	 * set value of EMAIL
	 * @param newEMAIL - EMAIL
	 */
	public void setEMAIL(String newEMAIL){
		EMAIL = newEMAIL;
	}	
	
	/**
	 * get value of �D��¾
	 * @return �D��¾
	 */
	public String getIS_MGR() {
		if(EmptyField.isEmpty(IS_MGR)){
			return null;
		}
		return IS_MGR;
	}

	/**
	 * set value of �D��¾
	 * @param newIS_MGR - �D��¾
	 */
	public void setIS_MGR(String newIS_MGR){
		IS_MGR = newIS_MGR;
	}	
	
	/**
	 * get value of �W�Ǥ��
	 * @return �W�Ǥ��
	 */
	public java.sql.Date getUPLOAD_DATE() {
		if(EmptyField.isEmpty(UPLOAD_DATE)){
			return null;
		}
		return UPLOAD_DATE;
	}

	/**
	 * set value of �W�Ǥ��
	 * @param newUPLOAD_DATE - �W�Ǥ��
	 */
	public void setUPLOAD_DATE(java.sql.Date newUPLOAD_DATE){
		UPLOAD_DATE = newUPLOAD_DATE;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of ���q�q��
	 * @return ���q�q��
	 */
	public String getINSTITUTION_PHONE() {
		if(EmptyField.isEmpty(INSTITUTION_PHONE)){
			return null;
		}
		return INSTITUTION_PHONE;
	}

	/**
	 * set value of ���q�q��
	 * @param newINSTITUTION_PHONE - ���q�q��
	 */
	public void setINSTITUTION_PHONE(String newINSTITUTION_PHONE){
		INSTITUTION_PHONE = newINSTITUTION_PHONE;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(BACKUP_DATE);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(DIV_TP);
		hcBuilder.append(EMPLOYEE_ID);
		hcBuilder.append(DIV_NO);
		hcBuilder.append(DIV_SHORT_NAME);
		hcBuilder.append(ORI_DIV_NO);
		hcBuilder.append(NAME);
		hcBuilder.append(EMP_NO);
		hcBuilder.append(EMAIL);
		hcBuilder.append(IS_MGR);
		hcBuilder.append(UPLOAD_DATE);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(INSTITUTION_PHONE);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPZ111)){
			return false;
		}
        
		DTEPZ111 theObj = (DTEPZ111)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				