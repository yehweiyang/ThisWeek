package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPZ001
 * <pre>
 * Generated value object of DBEP.DTEPZ001 (�y���Ǹ�������)
 * </pre>
 */
public class DTEPZ001 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPZ001";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�t�ΧO", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String SYS_CODE = EmptyField.STRING;
	
	@Column(desc="�Ѽ�1", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String PARM1 = EmptyField.STRING;
	
	@Column(desc="�Ѽ�2", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String PARM2 = EmptyField.STRING;
	
	@Column(desc="�y���Ǹ�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SER_NO = EmptyField.INTEGER;
	
	/**
	 * Default constructor
	 */
	public DTEPZ001(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �t�ΧO
	 * @return �t�ΧO
	 */
	public String getSYS_CODE() {
		if(EmptyField.isEmpty(SYS_CODE)){
			return null;
		}
		return SYS_CODE;
	}

	/**
	 * set value of �t�ΧO
	 * @param newSYS_CODE - �t�ΧO
	 */
	public void setSYS_CODE(String newSYS_CODE){
		SYS_CODE = newSYS_CODE;
	}	
	
	/**
	 * get value of �Ѽ�1
	 * @return �Ѽ�1
	 */
	public String getPARM1() {
		if(EmptyField.isEmpty(PARM1)){
			return null;
		}
		return PARM1;
	}

	/**
	 * set value of �Ѽ�1
	 * @param newPARM1 - �Ѽ�1
	 */
	public void setPARM1(String newPARM1){
		PARM1 = newPARM1;
	}	
	
	/**
	 * get value of �Ѽ�2
	 * @return �Ѽ�2
	 */
	public String getPARM2() {
		if(EmptyField.isEmpty(PARM2)){
			return null;
		}
		return PARM2;
	}

	/**
	 * set value of �Ѽ�2
	 * @param newPARM2 - �Ѽ�2
	 */
	public void setPARM2(String newPARM2){
		PARM2 = newPARM2;
	}	
	
	/**
	 * get value of �y���Ǹ�
	 * @return �y���Ǹ�
	 */
	public Integer getSER_NO() {
		if(EmptyField.isEmpty(SER_NO)){
			return null;
		}
		return SER_NO;
	}

	/**
	 * set value of �y���Ǹ�
	 * @param newSER_NO - �y���Ǹ�
	 */
	public void setSER_NO(Integer newSER_NO){
		SER_NO = newSER_NO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(SYS_CODE);
		hcBuilder.append(PARM1);
		hcBuilder.append(PARM2);
		hcBuilder.append(SER_NO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPZ001)){
			return false;
		}
        
		DTEPZ001 theObj = (DTEPZ001)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				