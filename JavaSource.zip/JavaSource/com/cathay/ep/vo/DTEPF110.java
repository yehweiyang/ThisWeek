package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF110
 * <pre>
 * Generated value object of DBEP.DTEPF110 (��µ�ץ�_�򥻸����)
 * </pre>
 */
public class DTEPF110 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF110";
	
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�j�ӦW��", nullAble=false, type=java.sql.Types.VARCHAR, length=45, defaultValue="") 
	private String BLD_NM = EmptyField.STRING;
	
	@Column(desc="�y���a�I", type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String BLD_ADDR = EmptyField.STRING;
	
	@Column(desc="��µ���e", nullAble=false, type=java.sql.Types.VARCHAR, length=900, defaultValue="") 
	private String FIX_MO = EmptyField.STRING;
	
	@Column(desc="�߮׳��", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String INPUT_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�߮פ���ɶ�", nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp INPUT_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�߮פH��ID", nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INPUT_ID = EmptyField.STRING;
	
	@Column(desc="�ץ����", nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String APLY_TP = EmptyField.STRING;
	
	@Column(desc="�ϥΪ��p����", nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String USE_TP = EmptyField.STRING;
	
	@Column(desc="�O�κ���", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String EXP_TP = EmptyField.STRING;
	
	@Column(desc="�ɬd�ɮ׽s��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FIX_FILE_NO = EmptyField.STRING;
	
	@Column(desc="�禬�ɮ׽s��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FINAL_FILE_NO = EmptyField.STRING;
	
	@Column(desc="��µ��H��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String FIX_DIV_ID = EmptyField.STRING;
	
	@Column(desc="��µ�դH��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String FIX_GROUP_ID = EmptyField.STRING;
	
	@Column(desc="���u�ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp FIX_FINAL_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�����禬�ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp SUB_USR_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�����禬�ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp USR_FINAL_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�����k�ɮɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp END_APLY_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�t�ӽs��", type=java.sql.Types.VARCHAR, length=15, defaultValue="") 
	private String SUP_ID = EmptyField.STRING;
	
	@Column(desc="���B(�t�|)", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CLR_AMT = EmptyField.INTEGER;
	
	@Column(desc="��޵|", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer ACT_AMT = EmptyField.INTEGER;
	
	@Column(desc="���O", type=java.sql.Types.VARCHAR, length=3, defaultValue="'NTD'") 
	private String CURR = EmptyField.STRING;
	
	@Column(desc="�T�{�u�k����", type=java.sql.Types.VARCHAR, length=390, defaultValue="") 
	private String CFM_WORK_MO = EmptyField.STRING;
	
	@Column(desc="�D�ްh�^����", type=java.sql.Types.VARCHAR, length=390, defaultValue="") 
	private String MGR_PPL_MO = EmptyField.STRING;
	
	@Column(desc="�O�T���", type=java.sql.Types.DECIMAL, length=3, defaultValue="") 
	private java.math.BigDecimal WAR_MON = EmptyField.BIGDECIMAL;
	
	@Column(desc="�u�{�k��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String PRO_OWN = EmptyField.STRING;
	
	@Column(desc="�f��y�{�s��", nullAble=false, type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FLOW_NO = EmptyField.STRING;
	
	@Column(desc="�@�~�i��", nullAble=false, type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String OP_STATUS = EmptyField.STRING;
	
	@Column(desc="�ӽнs��", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String REQNO = EmptyField.STRING;
	
	@Column(desc="�@�~�ɶ�", nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp LST_PROC_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�@�~�H��", nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String LST_PROC_ID = EmptyField.STRING;
	
	@Column(desc="�@�~���", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String LST_PROC_DIV = EmptyField.STRING;
	
	@Column(desc="�P�׭�]", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String NULLIFY = EmptyField.STRING;
	
	@Column(desc="�w�����B", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer EST_AMT = EmptyField.INTEGER;
	
	@Column(desc="�e��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String CHECK = EmptyField.STRING;
	
	@Column(desc="�D��ñ�֤��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date DIV_CFM_DATE = EmptyField.DATE;
	
	@Column(desc="�q���I�u���", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date INFM_CONS_DATE = EmptyField.DATE;
	
	@Column(desc="�t�ӦW��", type=java.sql.Types.VARCHAR, length=240, defaultValue="") 
	private String SUP_NM = EmptyField.STRING;
	
	@Column(desc="�o�����X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INV_NO = EmptyField.STRING;
	
	@Column(desc="�s�P�X����ޤ뵲�s��", type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String CMM_APLY_NO = EmptyField.STRING;
	
	@Column(desc="�@�~�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String LST_PROC_NM = EmptyField.STRING;
	
	@Column(desc="��µ��H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String FIX_DIV_NM = EmptyField.STRING;
	
	@Column(desc="��µ�դH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String FIX_GROUP_NM = EmptyField.STRING;
	
	@Column(desc="�߮פH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String INPUT_NM = EmptyField.STRING;
	
	@Column(desc="�߮׳��W��", type=java.sql.Types.VARCHAR, length=60, defaultValue="") 
	private String INPUT_DIV_NM = EmptyField.STRING;
	
	@Column(desc="�h��e�i��", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String PRE_OP_STATUS = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPF110(){
		// do nothing	
	}
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �j�ӦW��
	 * @return �j�ӦW��
	 */
	public String getBLD_NM() {
		if(EmptyField.isEmpty(BLD_NM)){
			return null;
		}
		return BLD_NM;
	}

	/**
	 * set value of �j�ӦW��
	 * @param newBLD_NM - �j�ӦW��
	 */
	public void setBLD_NM(String newBLD_NM){
		BLD_NM = newBLD_NM;
	}	
	
	/**
	 * get value of �y���a�I
	 * @return �y���a�I
	 */
	public String getBLD_ADDR() {
		if(EmptyField.isEmpty(BLD_ADDR)){
			return null;
		}
		return BLD_ADDR;
	}

	/**
	 * set value of �y���a�I
	 * @param newBLD_ADDR - �y���a�I
	 */
	public void setBLD_ADDR(String newBLD_ADDR){
		BLD_ADDR = newBLD_ADDR;
	}	
	
	/**
	 * get value of ��µ���e
	 * @return ��µ���e
	 */
	public String getFIX_MO() {
		if(EmptyField.isEmpty(FIX_MO)){
			return null;
		}
		return FIX_MO;
	}

	/**
	 * set value of ��µ���e
	 * @param newFIX_MO - ��µ���e
	 */
	public void setFIX_MO(String newFIX_MO){
		FIX_MO = newFIX_MO;
	}	
	
	/**
	 * get value of �߮׳��
	 * @return �߮׳��
	 */
	public String getINPUT_DIV_NO() {
		if(EmptyField.isEmpty(INPUT_DIV_NO)){
			return null;
		}
		return INPUT_DIV_NO;
	}

	/**
	 * set value of �߮׳��
	 * @param newINPUT_DIV_NO - �߮׳��
	 */
	public void setINPUT_DIV_NO(String newINPUT_DIV_NO){
		INPUT_DIV_NO = newINPUT_DIV_NO;
	}	
	
	/**
	 * get value of �߮פ���ɶ�
	 * @return �߮פ���ɶ�
	 */
	public java.sql.Timestamp getINPUT_DATE() {
		if(EmptyField.isEmpty(INPUT_DATE)){
			return null;
		}
		return INPUT_DATE;
	}

	/**
	 * set value of �߮פ���ɶ�
	 * @param newINPUT_DATE - �߮פ���ɶ�
	 */
	public void setINPUT_DATE(java.sql.Timestamp newINPUT_DATE){
		INPUT_DATE = newINPUT_DATE;
	}	
	
	/**
	 * get value of �߮פH��ID
	 * @return �߮פH��ID
	 */
	public String getINPUT_ID() {
		if(EmptyField.isEmpty(INPUT_ID)){
			return null;
		}
		return INPUT_ID;
	}

	/**
	 * set value of �߮פH��ID
	 * @param newINPUT_ID - �߮פH��ID
	 */
	public void setINPUT_ID(String newINPUT_ID){
		INPUT_ID = newINPUT_ID;
	}	
	
	/**
	 * get value of �ץ����
	 * @return �ץ����
	 */
	public String getAPLY_TP() {
		if(EmptyField.isEmpty(APLY_TP)){
			return null;
		}
		return APLY_TP;
	}

	/**
	 * set value of �ץ����
	 * @param newAPLY_TP - �ץ����
	 */
	public void setAPLY_TP(String newAPLY_TP){
		APLY_TP = newAPLY_TP;
	}	
	
	/**
	 * get value of �ϥΪ��p����
	 * @return �ϥΪ��p����
	 */
	public String getUSE_TP() {
		if(EmptyField.isEmpty(USE_TP)){
			return null;
		}
		return USE_TP;
	}

	/**
	 * set value of �ϥΪ��p����
	 * @param newUSE_TP - �ϥΪ��p����
	 */
	public void setUSE_TP(String newUSE_TP){
		USE_TP = newUSE_TP;
	}	
	
	/**
	 * get value of �O�κ���
	 * @return �O�κ���
	 */
	public String getEXP_TP() {
		if(EmptyField.isEmpty(EXP_TP)){
			return null;
		}
		return EXP_TP;
	}

	/**
	 * set value of �O�κ���
	 * @param newEXP_TP - �O�κ���
	 */
	public void setEXP_TP(String newEXP_TP){
		EXP_TP = newEXP_TP;
	}	
	
	/**
	 * get value of �ɬd�ɮ׽s��
	 * @return �ɬd�ɮ׽s��
	 */
	public String getFIX_FILE_NO() {
		if(EmptyField.isEmpty(FIX_FILE_NO)){
			return null;
		}
		return FIX_FILE_NO;
	}

	/**
	 * set value of �ɬd�ɮ׽s��
	 * @param newFIX_FILE_NO - �ɬd�ɮ׽s��
	 */
	public void setFIX_FILE_NO(String newFIX_FILE_NO){
		FIX_FILE_NO = newFIX_FILE_NO;
	}	
	
	/**
	 * get value of �禬�ɮ׽s��
	 * @return �禬�ɮ׽s��
	 */
	public String getFINAL_FILE_NO() {
		if(EmptyField.isEmpty(FINAL_FILE_NO)){
			return null;
		}
		return FINAL_FILE_NO;
	}

	/**
	 * set value of �禬�ɮ׽s��
	 * @param newFINAL_FILE_NO - �禬�ɮ׽s��
	 */
	public void setFINAL_FILE_NO(String newFINAL_FILE_NO){
		FINAL_FILE_NO = newFINAL_FILE_NO;
	}	
	
	/**
	 * get value of ��µ��H��
	 * @return ��µ��H��
	 */
	public String getFIX_DIV_ID() {
		if(EmptyField.isEmpty(FIX_DIV_ID)){
			return null;
		}
		return FIX_DIV_ID;
	}

	/**
	 * set value of ��µ��H��
	 * @param newFIX_DIV_ID - ��µ��H��
	 */
	public void setFIX_DIV_ID(String newFIX_DIV_ID){
		FIX_DIV_ID = newFIX_DIV_ID;
	}	
	
	/**
	 * get value of ��µ�դH��
	 * @return ��µ�դH��
	 */
	public String getFIX_GROUP_ID() {
		if(EmptyField.isEmpty(FIX_GROUP_ID)){
			return null;
		}
		return FIX_GROUP_ID;
	}

	/**
	 * set value of ��µ�դH��
	 * @param newFIX_GROUP_ID - ��µ�դH��
	 */
	public void setFIX_GROUP_ID(String newFIX_GROUP_ID){
		FIX_GROUP_ID = newFIX_GROUP_ID;
	}	
	
	/**
	 * get value of ���u�ɶ�
	 * @return ���u�ɶ�
	 */
	public java.sql.Timestamp getFIX_FINAL_DATE() {
		if(EmptyField.isEmpty(FIX_FINAL_DATE)){
			return null;
		}
		return FIX_FINAL_DATE;
	}

	/**
	 * set value of ���u�ɶ�
	 * @param newFIX_FINAL_DATE - ���u�ɶ�
	 */
	public void setFIX_FINAL_DATE(java.sql.Timestamp newFIX_FINAL_DATE){
		FIX_FINAL_DATE = newFIX_FINAL_DATE;
	}	
	
	/**
	 * get value of �����禬�ɶ�
	 * @return �����禬�ɶ�
	 */
	public java.sql.Timestamp getSUB_USR_DATE() {
		if(EmptyField.isEmpty(SUB_USR_DATE)){
			return null;
		}
		return SUB_USR_DATE;
	}

	/**
	 * set value of �����禬�ɶ�
	 * @param newSUB_USR_DATE - �����禬�ɶ�
	 */
	public void setSUB_USR_DATE(java.sql.Timestamp newSUB_USR_DATE){
		SUB_USR_DATE = newSUB_USR_DATE;
	}	
	
	/**
	 * get value of �����禬�ɶ�
	 * @return �����禬�ɶ�
	 */
	public java.sql.Timestamp getUSR_FINAL_DATE() {
		if(EmptyField.isEmpty(USR_FINAL_DATE)){
			return null;
		}
		return USR_FINAL_DATE;
	}

	/**
	 * set value of �����禬�ɶ�
	 * @param newUSR_FINAL_DATE - �����禬�ɶ�
	 */
	public void setUSR_FINAL_DATE(java.sql.Timestamp newUSR_FINAL_DATE){
		USR_FINAL_DATE = newUSR_FINAL_DATE;
	}	
	
	/**
	 * get value of �����k�ɮɶ�
	 * @return �����k�ɮɶ�
	 */
	public java.sql.Timestamp getEND_APLY_DATE() {
		if(EmptyField.isEmpty(END_APLY_DATE)){
			return null;
		}
		return END_APLY_DATE;
	}

	/**
	 * set value of �����k�ɮɶ�
	 * @param newEND_APLY_DATE - �����k�ɮɶ�
	 */
	public void setEND_APLY_DATE(java.sql.Timestamp newEND_APLY_DATE){
		END_APLY_DATE = newEND_APLY_DATE;
	}	
	
	/**
	 * get value of �t�ӽs��
	 * @return �t�ӽs��
	 */
	public String getSUP_ID() {
		if(EmptyField.isEmpty(SUP_ID)){
			return null;
		}
		return SUP_ID;
	}

	/**
	 * set value of �t�ӽs��
	 * @param newSUP_ID - �t�ӽs��
	 */
	public void setSUP_ID(String newSUP_ID){
		SUP_ID = newSUP_ID;
	}	
	
	/**
	 * get value of ���B(�t�|)
	 * @return ���B(�t�|)
	 */
	public Integer getCLR_AMT() {
		if(EmptyField.isEmpty(CLR_AMT)){
			return null;
		}
		return CLR_AMT;
	}

	/**
	 * set value of ���B(�t�|)
	 * @param newCLR_AMT - ���B(�t�|)
	 */
	public void setCLR_AMT(Integer newCLR_AMT){
		CLR_AMT = newCLR_AMT;
	}	
	
	/**
	 * get value of ��޵|
	 * @return ��޵|
	 */
	public Integer getACT_AMT() {
		if(EmptyField.isEmpty(ACT_AMT)){
			return null;
		}
		return ACT_AMT;
	}

	/**
	 * set value of ��޵|
	 * @param newACT_AMT - ��޵|
	 */
	public void setACT_AMT(Integer newACT_AMT){
		ACT_AMT = newACT_AMT;
	}	
	
	/**
	 * get value of ���O
	 * @return ���O
	 */
	public String getCURR() {
		if(EmptyField.isEmpty(CURR)){
			return null;
		}
		return CURR;
	}

	/**
	 * set value of ���O
	 * @param newCURR - ���O
	 */
	public void setCURR(String newCURR){
		CURR = newCURR;
	}	
	
	/**
	 * get value of �T�{�u�k����
	 * @return �T�{�u�k����
	 */
	public String getCFM_WORK_MO() {
		if(EmptyField.isEmpty(CFM_WORK_MO)){
			return null;
		}
		return CFM_WORK_MO;
	}

	/**
	 * set value of �T�{�u�k����
	 * @param newCFM_WORK_MO - �T�{�u�k����
	 */
	public void setCFM_WORK_MO(String newCFM_WORK_MO){
		CFM_WORK_MO = newCFM_WORK_MO;
	}	
	
	/**
	 * get value of �D�ްh�^����
	 * @return �D�ްh�^����
	 */
	public String getMGR_PPL_MO() {
		if(EmptyField.isEmpty(MGR_PPL_MO)){
			return null;
		}
		return MGR_PPL_MO;
	}

	/**
	 * set value of �D�ްh�^����
	 * @param newMGR_PPL_MO - �D�ްh�^����
	 */
	public void setMGR_PPL_MO(String newMGR_PPL_MO){
		MGR_PPL_MO = newMGR_PPL_MO;
	}	
	
	/**
	 * get value of �O�T���
	 * @return �O�T���
	 */
	public java.math.BigDecimal getWAR_MON() {
		if(EmptyField.isEmpty(WAR_MON)){
			return null;
		}
		return WAR_MON;
	}

	/**
	 * set value of �O�T���
	 * @param newWAR_MON - �O�T���
	 */
	public void setWAR_MON(java.math.BigDecimal newWAR_MON){
		WAR_MON = newWAR_MON;
	}	
	
	/**
	 * get value of �u�{�k��
	 * @return �u�{�k��
	 */
	public String getPRO_OWN() {
		if(EmptyField.isEmpty(PRO_OWN)){
			return null;
		}
		return PRO_OWN;
	}

	/**
	 * set value of �u�{�k��
	 * @param newPRO_OWN - �u�{�k��
	 */
	public void setPRO_OWN(String newPRO_OWN){
		PRO_OWN = newPRO_OWN;
	}	
	
	/**
	 * get value of �f��y�{�s��
	 * @return �f��y�{�s��
	 */
	public String getFLOW_NO() {
		if(EmptyField.isEmpty(FLOW_NO)){
			return null;
		}
		return FLOW_NO;
	}

	/**
	 * set value of �f��y�{�s��
	 * @param newFLOW_NO - �f��y�{�s��
	 */
	public void setFLOW_NO(String newFLOW_NO){
		FLOW_NO = newFLOW_NO;
	}	
	
	/**
	 * get value of �@�~�i��
	 * @return �@�~�i��
	 */
	public String getOP_STATUS() {
		if(EmptyField.isEmpty(OP_STATUS)){
			return null;
		}
		return OP_STATUS;
	}

	/**
	 * set value of �@�~�i��
	 * @param newOP_STATUS - �@�~�i��
	 */
	public void setOP_STATUS(String newOP_STATUS){
		OP_STATUS = newOP_STATUS;
	}	
	
	/**
	 * get value of �ӽнs��
	 * @return �ӽнs��
	 */
	public String getREQNO() {
		if(EmptyField.isEmpty(REQNO)){
			return null;
		}
		return REQNO;
	}

	/**
	 * set value of �ӽнs��
	 * @param newREQNO - �ӽнs��
	 */
	public void setREQNO(String newREQNO){
		REQNO = newREQNO;
	}	
	
	/**
	 * get value of �@�~�ɶ�
	 * @return �@�~�ɶ�
	 */
	public java.sql.Timestamp getLST_PROC_DATE() {
		if(EmptyField.isEmpty(LST_PROC_DATE)){
			return null;
		}
		return LST_PROC_DATE;
	}

	/**
	 * set value of �@�~�ɶ�
	 * @param newLST_PROC_DATE - �@�~�ɶ�
	 */
	public void setLST_PROC_DATE(java.sql.Timestamp newLST_PROC_DATE){
		LST_PROC_DATE = newLST_PROC_DATE;
	}	
	
	/**
	 * get value of �@�~�H��
	 * @return �@�~�H��
	 */
	public String getLST_PROC_ID() {
		if(EmptyField.isEmpty(LST_PROC_ID)){
			return null;
		}
		return LST_PROC_ID;
	}

	/**
	 * set value of �@�~�H��
	 * @param newLST_PROC_ID - �@�~�H��
	 */
	public void setLST_PROC_ID(String newLST_PROC_ID){
		LST_PROC_ID = newLST_PROC_ID;
	}	
	
	/**
	 * get value of �@�~���
	 * @return �@�~���
	 */
	public String getLST_PROC_DIV() {
		if(EmptyField.isEmpty(LST_PROC_DIV)){
			return null;
		}
		return LST_PROC_DIV;
	}

	/**
	 * set value of �@�~���
	 * @param newLST_PROC_DIV - �@�~���
	 */
	public void setLST_PROC_DIV(String newLST_PROC_DIV){
		LST_PROC_DIV = newLST_PROC_DIV;
	}	
	
	/**
	 * get value of �P�׭�]
	 * @return �P�׭�]
	 */
	public String getNULLIFY() {
		if(EmptyField.isEmpty(NULLIFY)){
			return null;
		}
		return NULLIFY;
	}

	/**
	 * set value of �P�׭�]
	 * @param newNULLIFY - �P�׭�]
	 */
	public void setNULLIFY(String newNULLIFY){
		NULLIFY = newNULLIFY;
	}	
	
	/**
	 * get value of �w�����B
	 * @return �w�����B
	 */
	public Integer getEST_AMT() {
		if(EmptyField.isEmpty(EST_AMT)){
			return null;
		}
		return EST_AMT;
	}

	/**
	 * set value of �w�����B
	 * @param newEST_AMT - �w�����B
	 */
	public void setEST_AMT(Integer newEST_AMT){
		EST_AMT = newEST_AMT;
	}	
	
	/**
	 * get value of �e��
	 * @return �e��
	 */
	public String getCHECK() {
		if(EmptyField.isEmpty(CHECK)){
			return null;
		}
		return CHECK;
	}

	/**
	 * set value of �e��
	 * @param newCHECK - �e��
	 */
	public void setCHECK(String newCHECK){
		CHECK = newCHECK;
	}	
	
	/**
	 * get value of �D��ñ�֤��
	 * @return �D��ñ�֤��
	 */
	public java.sql.Date getDIV_CFM_DATE() {
		if(EmptyField.isEmpty(DIV_CFM_DATE)){
			return null;
		}
		return DIV_CFM_DATE;
	}

	/**
	 * set value of �D��ñ�֤��
	 * @param newDIV_CFM_DATE - �D��ñ�֤��
	 */
	public void setDIV_CFM_DATE(java.sql.Date newDIV_CFM_DATE){
		DIV_CFM_DATE = newDIV_CFM_DATE;
	}	
	
	/**
	 * get value of �q���I�u���
	 * @return �q���I�u���
	 */
	public java.sql.Date getINFM_CONS_DATE() {
		if(EmptyField.isEmpty(INFM_CONS_DATE)){
			return null;
		}
		return INFM_CONS_DATE;
	}

	/**
	 * set value of �q���I�u���
	 * @param newINFM_CONS_DATE - �q���I�u���
	 */
	public void setINFM_CONS_DATE(java.sql.Date newINFM_CONS_DATE){
		INFM_CONS_DATE = newINFM_CONS_DATE;
	}	
	
	/**
	 * get value of �t�ӦW��
	 * @return �t�ӦW��
	 */
	public String getSUP_NM() {
		if(EmptyField.isEmpty(SUP_NM)){
			return null;
		}
		return SUP_NM;
	}

	/**
	 * set value of �t�ӦW��
	 * @param newSUP_NM - �t�ӦW��
	 */
	public void setSUP_NM(String newSUP_NM){
		SUP_NM = newSUP_NM;
	}	
	
	/**
	 * get value of �o�����X
	 * @return �o�����X
	 */
	public String getINV_NO() {
		if(EmptyField.isEmpty(INV_NO)){
			return null;
		}
		return INV_NO;
	}

	/**
	 * set value of �o�����X
	 * @param newINV_NO - �o�����X
	 */
	public void setINV_NO(String newINV_NO){
		INV_NO = newINV_NO;
	}	
	
	/**
	 * get value of �s�P�X����ޤ뵲�s��
	 * @return �s�P�X����ޤ뵲�s��
	 */
	public String getCMM_APLY_NO() {
		if(EmptyField.isEmpty(CMM_APLY_NO)){
			return null;
		}
		return CMM_APLY_NO;
	}

	/**
	 * set value of �s�P�X����ޤ뵲�s��
	 * @param newCMM_APLY_NO - �s�P�X����ޤ뵲�s��
	 */
	public void setCMM_APLY_NO(String newCMM_APLY_NO){
		CMM_APLY_NO = newCMM_APLY_NO;
	}	
	
	/**
	 * get value of �@�~�H���m�W
	 * @return �@�~�H���m�W
	 */
	public String getLST_PROC_NM() {
		if(EmptyField.isEmpty(LST_PROC_NM)){
			return null;
		}
		return LST_PROC_NM;
	}

	/**
	 * set value of �@�~�H���m�W
	 * @param newLST_PROC_NM - �@�~�H���m�W
	 */
	public void setLST_PROC_NM(String newLST_PROC_NM){
		LST_PROC_NM = newLST_PROC_NM;
	}	
	
	/**
	 * get value of ��µ��H���m�W
	 * @return ��µ��H���m�W
	 */
	public String getFIX_DIV_NM() {
		if(EmptyField.isEmpty(FIX_DIV_NM)){
			return null;
		}
		return FIX_DIV_NM;
	}

	/**
	 * set value of ��µ��H���m�W
	 * @param newFIX_DIV_NM - ��µ��H���m�W
	 */
	public void setFIX_DIV_NM(String newFIX_DIV_NM){
		FIX_DIV_NM = newFIX_DIV_NM;
	}	
	
	/**
	 * get value of ��µ�դH���m�W
	 * @return ��µ�դH���m�W
	 */
	public String getFIX_GROUP_NM() {
		if(EmptyField.isEmpty(FIX_GROUP_NM)){
			return null;
		}
		return FIX_GROUP_NM;
	}

	/**
	 * set value of ��µ�դH���m�W
	 * @param newFIX_GROUP_NM - ��µ�դH���m�W
	 */
	public void setFIX_GROUP_NM(String newFIX_GROUP_NM){
		FIX_GROUP_NM = newFIX_GROUP_NM;
	}	
	
	/**
	 * get value of �߮פH���m�W
	 * @return �߮פH���m�W
	 */
	public String getINPUT_NM() {
		if(EmptyField.isEmpty(INPUT_NM)){
			return null;
		}
		return INPUT_NM;
	}

	/**
	 * set value of �߮פH���m�W
	 * @param newINPUT_NM - �߮פH���m�W
	 */
	public void setINPUT_NM(String newINPUT_NM){
		INPUT_NM = newINPUT_NM;
	}	
	
	/**
	 * get value of �߮׳��W��
	 * @return �߮׳��W��
	 */
	public String getINPUT_DIV_NM() {
		if(EmptyField.isEmpty(INPUT_DIV_NM)){
			return null;
		}
		return INPUT_DIV_NM;
	}

	/**
	 * set value of �߮׳��W��
	 * @param newINPUT_DIV_NM - �߮׳��W��
	 */
	public void setINPUT_DIV_NM(String newINPUT_DIV_NM){
		INPUT_DIV_NM = newINPUT_DIV_NM;
	}	
	
	/**
	 * get value of �h��e�i��
	 * @return �h��e�i��
	 */
	public String getPRE_OP_STATUS() {
		if(EmptyField.isEmpty(PRE_OP_STATUS)){
			return null;
		}
		return PRE_OP_STATUS;
	}

	/**
	 * set value of �h��e�i��
	 * @param newPRE_OP_STATUS - �h��e�i��
	 */
	public void setPRE_OP_STATUS(String newPRE_OP_STATUS){
		PRE_OP_STATUS = newPRE_OP_STATUS;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(APLY_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(BLD_NM);
		hcBuilder.append(BLD_ADDR);
		hcBuilder.append(FIX_MO);
		hcBuilder.append(INPUT_DIV_NO);
		hcBuilder.append(INPUT_DATE);
		hcBuilder.append(INPUT_ID);
		hcBuilder.append(APLY_TP);
		hcBuilder.append(USE_TP);
		hcBuilder.append(EXP_TP);
		hcBuilder.append(FIX_FILE_NO);
		hcBuilder.append(FINAL_FILE_NO);
		hcBuilder.append(FIX_DIV_ID);
		hcBuilder.append(FIX_GROUP_ID);
		hcBuilder.append(FIX_FINAL_DATE);
		hcBuilder.append(SUB_USR_DATE);
		hcBuilder.append(USR_FINAL_DATE);
		hcBuilder.append(END_APLY_DATE);
		hcBuilder.append(SUP_ID);
		hcBuilder.append(CLR_AMT);
		hcBuilder.append(ACT_AMT);
		hcBuilder.append(CURR);
		hcBuilder.append(CFM_WORK_MO);
		hcBuilder.append(MGR_PPL_MO);
		hcBuilder.append(WAR_MON);
		hcBuilder.append(PRO_OWN);
		hcBuilder.append(FLOW_NO);
		hcBuilder.append(OP_STATUS);
		hcBuilder.append(REQNO);
		hcBuilder.append(LST_PROC_DATE);
		hcBuilder.append(LST_PROC_ID);
		hcBuilder.append(LST_PROC_DIV);
		hcBuilder.append(NULLIFY);
		hcBuilder.append(EST_AMT);
		hcBuilder.append(CHECK);
		hcBuilder.append(DIV_CFM_DATE);
		hcBuilder.append(INFM_CONS_DATE);
		hcBuilder.append(SUP_NM);
		hcBuilder.append(INV_NO);
		hcBuilder.append(CMM_APLY_NO);
		hcBuilder.append(LST_PROC_NM);
		hcBuilder.append(FIX_DIV_NM);
		hcBuilder.append(FIX_GROUP_NM);
		hcBuilder.append(INPUT_NM);
		hcBuilder.append(INPUT_DIV_NM);
		hcBuilder.append(PRE_OP_STATUS);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF110)){
			return false;
		}
        
		DTEPF110 theObj = (DTEPF110)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				