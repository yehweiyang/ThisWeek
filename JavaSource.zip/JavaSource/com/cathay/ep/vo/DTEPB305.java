package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPB305
 * <pre>
 * Generated value object of DBEP.DTEPB305 ()
 * </pre>
 */
public class DTEPB305 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPB305";
	
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�ץ�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer APLY_SER_NO = EmptyField.INTEGER;
	
	@Column(desc="�������", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String DATA_TYPE = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�����N��", nullAble=false, type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�կ��_��", nullAble=false, type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ADJ_RNT_SDATE = EmptyField.DATE;
	
	@Column(desc="�կ�����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ADJ_RNT_EDATE = EmptyField.DATE;
	
	@Column(desc="�կ�����", type=java.sql.Types.DECIMAL, length=15, defaultValue="") 
	private java.math.BigDecimal ADJ_UNIT_NUM = EmptyField.BIGDECIMAL;
	
	@Column(desc="�կ����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ADJ_UNIT = EmptyField.STRING;
	
	@Column(desc="�O�_�H�u�կ�", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String IS_MAN_ADJ = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPB305(){
		// do nothing	
	}
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �ץ�Ǹ�
	 * @return �ץ�Ǹ�
	 */
	public Integer getAPLY_SER_NO() {
		if(EmptyField.isEmpty(APLY_SER_NO)){
			return null;
		}
		return APLY_SER_NO;
	}

	/**
	 * set value of �ץ�Ǹ�
	 * @param newAPLY_SER_NO - �ץ�Ǹ�
	 */
	public void setAPLY_SER_NO(Integer newAPLY_SER_NO){
		APLY_SER_NO = newAPLY_SER_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getDATA_TYPE() {
		if(EmptyField.isEmpty(DATA_TYPE)){
			return null;
		}
		return DATA_TYPE;
	}

	/**
	 * set value of �������
	 * @param newDATA_TYPE - �������
	 */
	public void setDATA_TYPE(String newDATA_TYPE){
		DATA_TYPE = newDATA_TYPE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �կ��_��
	 * @return �կ��_��
	 */
	public java.sql.Date getADJ_RNT_SDATE() {
		if(EmptyField.isEmpty(ADJ_RNT_SDATE)){
			return null;
		}
		return ADJ_RNT_SDATE;
	}

	/**
	 * set value of �կ��_��
	 * @param newADJ_RNT_SDATE - �կ��_��
	 */
	public void setADJ_RNT_SDATE(java.sql.Date newADJ_RNT_SDATE){
		ADJ_RNT_SDATE = newADJ_RNT_SDATE;
	}	
	
	/**
	 * get value of �կ�����
	 * @return �կ�����
	 */
	public java.sql.Date getADJ_RNT_EDATE() {
		if(EmptyField.isEmpty(ADJ_RNT_EDATE)){
			return null;
		}
		return ADJ_RNT_EDATE;
	}

	/**
	 * set value of �կ�����
	 * @param newADJ_RNT_EDATE - �կ�����
	 */
	public void setADJ_RNT_EDATE(java.sql.Date newADJ_RNT_EDATE){
		ADJ_RNT_EDATE = newADJ_RNT_EDATE;
	}	
	
	/**
	 * get value of �կ�����
	 * @return �կ�����
	 */
	public java.math.BigDecimal getADJ_UNIT_NUM() {
		if(EmptyField.isEmpty(ADJ_UNIT_NUM)){
			return null;
		}
		return ADJ_UNIT_NUM;
	}

	/**
	 * set value of �կ�����
	 * @param newADJ_UNIT_NUM - �կ�����
	 */
	public void setADJ_UNIT_NUM(java.math.BigDecimal newADJ_UNIT_NUM){
		ADJ_UNIT_NUM = newADJ_UNIT_NUM;
	}	
	
	/**
	 * get value of �կ����
	 * @return �կ����
	 */
	public String getADJ_UNIT() {
		if(EmptyField.isEmpty(ADJ_UNIT)){
			return null;
		}
		return ADJ_UNIT;
	}

	/**
	 * set value of �կ����
	 * @param newADJ_UNIT - �կ����
	 */
	public void setADJ_UNIT(String newADJ_UNIT){
		ADJ_UNIT = newADJ_UNIT;
	}	
	
	/**
	 * get value of �O�_�H�u�կ�
	 * @return �O�_�H�u�կ�
	 */
	public String getIS_MAN_ADJ() {
		if(EmptyField.isEmpty(IS_MAN_ADJ)){
			return null;
		}
		return IS_MAN_ADJ;
	}

	/**
	 * set value of �O�_�H�u�կ�
	 * @param newIS_MAN_ADJ - �O�_�H�u�կ�
	 */
	public void setIS_MAN_ADJ(String newIS_MAN_ADJ){
		IS_MAN_ADJ = newIS_MAN_ADJ;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(APLY_NO);
		hcBuilder.append(APLY_SER_NO);
		hcBuilder.append(DATA_TYPE);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(ADJ_RNT_SDATE);
		hcBuilder.append(ADJ_RNT_EDATE);
		hcBuilder.append(ADJ_UNIT_NUM);
		hcBuilder.append(ADJ_UNIT);
		hcBuilder.append(IS_MAN_ADJ);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPB305)){
			return false;
		}
        
		DTEPB305 theObj = (DTEPB305)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				