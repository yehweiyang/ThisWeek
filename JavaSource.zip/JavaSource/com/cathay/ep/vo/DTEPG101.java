package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPG101
 * <pre>
 * Generated value object of DBEP.DTEPG101 (��a�g�a�ت��å�)
 * </pre>
 */
public class DTEPG101 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPG101";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="��a�N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BASE_CD = EmptyField.STRING;
	
	@Column(desc="�å��Ǹ�", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String TRS_SEQ = EmptyField.STRING;
	
	@Column(desc="���O", nullAble=false, type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String KIND = EmptyField.STRING;
	
	@Column(desc="�ت��a�}", type=java.sql.Types.VARCHAR, length=100, defaultValue="") 
	private String BLD_ADDR = EmptyField.STRING;
	
	@Column(desc="�|�y�s��", type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String TAX_NO = EmptyField.STRING;
	
	@Column(desc="�a�q", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String LND_SEC = EmptyField.STRING;
	
	@Column(desc="�a��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String LND_NO = EmptyField.STRING;
	
	@Column(desc="�Ƶ�", type=java.sql.Types.VARCHAR, length=200, defaultValue="") 
	private String TRS_MEMO = EmptyField.STRING;
	
	@Column(desc="���n", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal TRS_AREA = EmptyField.BIGDECIMAL;
	
	@Column(desc="����(���l)", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String HD_NM = EmptyField.STRING;
	
	@Column(desc="����(����)", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String HD_DM = EmptyField.STRING;
	
	@Column(desc="�f�媬�A", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String OP_STATUS = EmptyField.STRING;
	
	@Column(desc="�å����A", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String TRS_STS = EmptyField.STRING;
	
	@Column(desc="��a�g�a���", type=java.sql.Types.DECIMAL, length=5, defaultValue="1") 
	private java.math.BigDecimal LND_RT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ɮ׽s��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String TRS_FILE_NO = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPG101(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ��a�N��
	 * @return ��a�N��
	 */
	public String getBASE_CD() {
		if(EmptyField.isEmpty(BASE_CD)){
			return null;
		}
		return BASE_CD;
	}

	/**
	 * set value of ��a�N��
	 * @param newBASE_CD - ��a�N��
	 */
	public void setBASE_CD(String newBASE_CD){
		BASE_CD = newBASE_CD;
	}	
	
	/**
	 * get value of �å��Ǹ�
	 * @return �å��Ǹ�
	 */
	public String getTRS_SEQ() {
		if(EmptyField.isEmpty(TRS_SEQ)){
			return null;
		}
		return TRS_SEQ;
	}

	/**
	 * set value of �å��Ǹ�
	 * @param newTRS_SEQ - �å��Ǹ�
	 */
	public void setTRS_SEQ(String newTRS_SEQ){
		TRS_SEQ = newTRS_SEQ;
	}	
	
	/**
	 * get value of ���O
	 * @return ���O
	 */
	public String getKIND() {
		if(EmptyField.isEmpty(KIND)){
			return null;
		}
		return KIND;
	}

	/**
	 * set value of ���O
	 * @param newKIND - ���O
	 */
	public void setKIND(String newKIND){
		KIND = newKIND;
	}	
	
	/**
	 * get value of �ت��a�}
	 * @return �ت��a�}
	 */
	public String getBLD_ADDR() {
		if(EmptyField.isEmpty(BLD_ADDR)){
			return null;
		}
		return BLD_ADDR;
	}

	/**
	 * set value of �ت��a�}
	 * @param newBLD_ADDR - �ت��a�}
	 */
	public void setBLD_ADDR(String newBLD_ADDR){
		BLD_ADDR = newBLD_ADDR;
	}	
	
	/**
	 * get value of �|�y�s��
	 * @return �|�y�s��
	 */
	public String getTAX_NO() {
		if(EmptyField.isEmpty(TAX_NO)){
			return null;
		}
		return TAX_NO;
	}

	/**
	 * set value of �|�y�s��
	 * @param newTAX_NO - �|�y�s��
	 */
	public void setTAX_NO(String newTAX_NO){
		TAX_NO = newTAX_NO;
	}	
	
	/**
	 * get value of �a�q
	 * @return �a�q
	 */
	public String getLND_SEC() {
		if(EmptyField.isEmpty(LND_SEC)){
			return null;
		}
		return LND_SEC;
	}

	/**
	 * set value of �a�q
	 * @param newLND_SEC - �a�q
	 */
	public void setLND_SEC(String newLND_SEC){
		LND_SEC = newLND_SEC;
	}	
	
	/**
	 * get value of �a��
	 * @return �a��
	 */
	public String getLND_NO() {
		if(EmptyField.isEmpty(LND_NO)){
			return null;
		}
		return LND_NO;
	}

	/**
	 * set value of �a��
	 * @param newLND_NO - �a��
	 */
	public void setLND_NO(String newLND_NO){
		LND_NO = newLND_NO;
	}	
	
	/**
	 * get value of �Ƶ�
	 * @return �Ƶ�
	 */
	public String getTRS_MEMO() {
		if(EmptyField.isEmpty(TRS_MEMO)){
			return null;
		}
		return TRS_MEMO;
	}

	/**
	 * set value of �Ƶ�
	 * @param newTRS_MEMO - �Ƶ�
	 */
	public void setTRS_MEMO(String newTRS_MEMO){
		TRS_MEMO = newTRS_MEMO;
	}	
	
	/**
	 * get value of ���n
	 * @return ���n
	 */
	public java.math.BigDecimal getTRS_AREA() {
		if(EmptyField.isEmpty(TRS_AREA)){
			return null;
		}
		return TRS_AREA;
	}

	/**
	 * set value of ���n
	 * @param newTRS_AREA - ���n
	 */
	public void setTRS_AREA(java.math.BigDecimal newTRS_AREA){
		TRS_AREA = newTRS_AREA;
	}	
	
	/**
	 * get value of ����(���l)
	 * @return ����(���l)
	 */
	public String getHD_NM() {
		if(EmptyField.isEmpty(HD_NM)){
			return null;
		}
		return HD_NM;
	}

	/**
	 * set value of ����(���l)
	 * @param newHD_NM - ����(���l)
	 */
	public void setHD_NM(String newHD_NM){
		HD_NM = newHD_NM;
	}	
	
	/**
	 * get value of ����(����)
	 * @return ����(����)
	 */
	public String getHD_DM() {
		if(EmptyField.isEmpty(HD_DM)){
			return null;
		}
		return HD_DM;
	}

	/**
	 * set value of ����(����)
	 * @param newHD_DM - ����(����)
	 */
	public void setHD_DM(String newHD_DM){
		HD_DM = newHD_DM;
	}	
	
	/**
	 * get value of �f�媬�A
	 * @return �f�媬�A
	 */
	public String getOP_STATUS() {
		if(EmptyField.isEmpty(OP_STATUS)){
			return null;
		}
		return OP_STATUS;
	}

	/**
	 * set value of �f�媬�A
	 * @param newOP_STATUS - �f�媬�A
	 */
	public void setOP_STATUS(String newOP_STATUS){
		OP_STATUS = newOP_STATUS;
	}	
	
	/**
	 * get value of �å����A
	 * @return �å����A
	 */
	public String getTRS_STS() {
		if(EmptyField.isEmpty(TRS_STS)){
			return null;
		}
		return TRS_STS;
	}

	/**
	 * set value of �å����A
	 * @param newTRS_STS - �å����A
	 */
	public void setTRS_STS(String newTRS_STS){
		TRS_STS = newTRS_STS;
	}	
	
	/**
	 * get value of ��a�g�a���
	 * @return ��a�g�a���
	 */
	public java.math.BigDecimal getLND_RT() {
		if(EmptyField.isEmpty(LND_RT)){
			return null;
		}
		return LND_RT;
	}

	/**
	 * set value of ��a�g�a���
	 * @param newLND_RT - ��a�g�a���
	 */
	public void setLND_RT(java.math.BigDecimal newLND_RT){
		LND_RT = newLND_RT;
	}	
	
	/**
	 * get value of �ɮ׽s��
	 * @return �ɮ׽s��
	 */
	public String getTRS_FILE_NO() {
		if(EmptyField.isEmpty(TRS_FILE_NO)){
			return null;
		}
		return TRS_FILE_NO;
	}

	/**
	 * set value of �ɮ׽s��
	 * @param newTRS_FILE_NO - �ɮ׽s��
	 */
	public void setTRS_FILE_NO(String newTRS_FILE_NO){
		TRS_FILE_NO = newTRS_FILE_NO;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BASE_CD);
		hcBuilder.append(TRS_SEQ);
		hcBuilder.append(KIND);
		hcBuilder.append(BLD_ADDR);
		hcBuilder.append(TAX_NO);
		hcBuilder.append(LND_SEC);
		hcBuilder.append(LND_NO);
		hcBuilder.append(TRS_MEMO);
		hcBuilder.append(TRS_AREA);
		hcBuilder.append(HD_NM);
		hcBuilder.append(HD_DM);
		hcBuilder.append(OP_STATUS);
		hcBuilder.append(TRS_STS);
		hcBuilder.append(LND_RT);
		hcBuilder.append(TRS_FILE_NO);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(TRN_KIND);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPG101)){
			return false;
		}
        
		DTEPG101 theObj = (DTEPG101)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				