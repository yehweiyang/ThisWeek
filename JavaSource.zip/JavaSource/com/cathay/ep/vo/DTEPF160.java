package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF160
 * <pre>
 * Generated value object of DBEP.DTEPF160 (�дڮ־P���I��)
 * </pre>
 */
public class DTEPF160 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF160";
	
	
	@Column(desc="�дڽs��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=11, defaultValue="") 
	private String PAY_CASE_NO = EmptyField.STRING;
	
	@Column(desc="�дڧǸ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer PAY_SER_NO = EmptyField.INTEGER;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", nullAble=false, type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�X���s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CONT_NO = EmptyField.STRING;
	
	@Column(desc="�t�ӽs��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String SUP_ID = EmptyField.STRING;
	
	@Column(desc="�дڪ��B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PAY_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�дڵ|�B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal TAX_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�o�����X", type=java.sql.Types.VARCHAR, length=15, defaultValue="") 
	private String INV_NO = EmptyField.STRING;
	
	@Column(desc="�дڤ��", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp PAY_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�дڽT�{���", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp PAY_CFM_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�дڰO���s��", type=java.sql.Types.VARCHAR, length=11, defaultValue="") 
	private String CASE_NO = EmptyField.STRING;
	
	@Column(desc="�|�p����", nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ACC_TP = EmptyField.STRING;
	
	@Column(desc="�|�O", nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String TAX_TP = EmptyField.STRING;
	
	@Column(desc="��ƨӷ�", nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String DATA_SOURCE = EmptyField.STRING;
	
	@Column(desc="�@�~�ɶ�", nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp LST_PROC_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�@�~�H��", nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String LST_PROC_ID = EmptyField.STRING;
	
	@Column(desc="�@�~���", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String LST_PROC_DIV = EmptyField.STRING;
	
	@Column(desc="�Ƨѿ��渹", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer MEMO_NO = EmptyField.INTEGER;
	
	@Column(desc="�u�اǸ�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer PRO_NO = EmptyField.INTEGER;
	
	@Column(desc="���ڹﹳ�O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ACPT_CODE = EmptyField.STRING;
	
	@Column(desc="���ڤH�N�X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACPT_ID = EmptyField.STRING;
	
	@Column(desc="�t�ӦW��", type=java.sql.Types.VARCHAR, length=240, defaultValue="") 
	private String SUP_NM = EmptyField.STRING;
	
	@Column(desc="�|�p�Ю֤��", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp ACC_SECVER_DATE = EmptyField.TIMESTAMP;
	
	/**
	 * Default constructor
	 */
	public DTEPF160(){
		// do nothing	
	}
	
	/**
	 * get value of �дڽs��
	 * @return �дڽs��
	 */
	public String getPAY_CASE_NO() {
		if(EmptyField.isEmpty(PAY_CASE_NO)){
			return null;
		}
		return PAY_CASE_NO;
	}

	/**
	 * set value of �дڽs��
	 * @param newPAY_CASE_NO - �дڽs��
	 */
	public void setPAY_CASE_NO(String newPAY_CASE_NO){
		PAY_CASE_NO = newPAY_CASE_NO;
	}	
	
	/**
	 * get value of �дڧǸ�
	 * @return �дڧǸ�
	 */
	public Integer getPAY_SER_NO() {
		if(EmptyField.isEmpty(PAY_SER_NO)){
			return null;
		}
		return PAY_SER_NO;
	}

	/**
	 * set value of �дڧǸ�
	 * @param newPAY_SER_NO - �дڧǸ�
	 */
	public void setPAY_SER_NO(Integer newPAY_SER_NO){
		PAY_SER_NO = newPAY_SER_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �X���s��
	 * @return �X���s��
	 */
	public String getCONT_NO() {
		if(EmptyField.isEmpty(CONT_NO)){
			return null;
		}
		return CONT_NO;
	}

	/**
	 * set value of �X���s��
	 * @param newCONT_NO - �X���s��
	 */
	public void setCONT_NO(String newCONT_NO){
		CONT_NO = newCONT_NO;
	}	
	
	/**
	 * get value of �t�ӽs��
	 * @return �t�ӽs��
	 */
	public String getSUP_ID() {
		if(EmptyField.isEmpty(SUP_ID)){
			return null;
		}
		return SUP_ID;
	}

	/**
	 * set value of �t�ӽs��
	 * @param newSUP_ID - �t�ӽs��
	 */
	public void setSUP_ID(String newSUP_ID){
		SUP_ID = newSUP_ID;
	}	
	
	/**
	 * get value of �дڪ��B
	 * @return �дڪ��B
	 */
	public java.math.BigDecimal getPAY_AMT() {
		if(EmptyField.isEmpty(PAY_AMT)){
			return null;
		}
		return PAY_AMT;
	}

	/**
	 * set value of �дڪ��B
	 * @param newPAY_AMT - �дڪ��B
	 */
	public void setPAY_AMT(java.math.BigDecimal newPAY_AMT){
		PAY_AMT = newPAY_AMT;
	}	
	
	/**
	 * get value of �дڵ|�B
	 * @return �дڵ|�B
	 */
	public java.math.BigDecimal getTAX_AMT() {
		if(EmptyField.isEmpty(TAX_AMT)){
			return null;
		}
		return TAX_AMT;
	}

	/**
	 * set value of �дڵ|�B
	 * @param newTAX_AMT - �дڵ|�B
	 */
	public void setTAX_AMT(java.math.BigDecimal newTAX_AMT){
		TAX_AMT = newTAX_AMT;
	}	
	
	/**
	 * get value of �o�����X
	 * @return �o�����X
	 */
	public String getINV_NO() {
		if(EmptyField.isEmpty(INV_NO)){
			return null;
		}
		return INV_NO;
	}

	/**
	 * set value of �o�����X
	 * @param newINV_NO - �o�����X
	 */
	public void setINV_NO(String newINV_NO){
		INV_NO = newINV_NO;
	}	
	
	/**
	 * get value of �дڤ��
	 * @return �дڤ��
	 */
	public java.sql.Timestamp getPAY_DATE() {
		if(EmptyField.isEmpty(PAY_DATE)){
			return null;
		}
		return PAY_DATE;
	}

	/**
	 * set value of �дڤ��
	 * @param newPAY_DATE - �дڤ��
	 */
	public void setPAY_DATE(java.sql.Timestamp newPAY_DATE){
		PAY_DATE = newPAY_DATE;
	}	
	
	/**
	 * get value of �дڽT�{���
	 * @return �дڽT�{���
	 */
	public java.sql.Timestamp getPAY_CFM_DATE() {
		if(EmptyField.isEmpty(PAY_CFM_DATE)){
			return null;
		}
		return PAY_CFM_DATE;
	}

	/**
	 * set value of �дڽT�{���
	 * @param newPAY_CFM_DATE - �дڽT�{���
	 */
	public void setPAY_CFM_DATE(java.sql.Timestamp newPAY_CFM_DATE){
		PAY_CFM_DATE = newPAY_CFM_DATE;
	}	
	
	/**
	 * get value of �дڰO���s��
	 * @return �дڰO���s��
	 */
	public String getCASE_NO() {
		if(EmptyField.isEmpty(CASE_NO)){
			return null;
		}
		return CASE_NO;
	}

	/**
	 * set value of �дڰO���s��
	 * @param newCASE_NO - �дڰO���s��
	 */
	public void setCASE_NO(String newCASE_NO){
		CASE_NO = newCASE_NO;
	}	
	
	/**
	 * get value of �|�p����
	 * @return �|�p����
	 */
	public String getACC_TP() {
		if(EmptyField.isEmpty(ACC_TP)){
			return null;
		}
		return ACC_TP;
	}

	/**
	 * set value of �|�p����
	 * @param newACC_TP - �|�p����
	 */
	public void setACC_TP(String newACC_TP){
		ACC_TP = newACC_TP;
	}	
	
	/**
	 * get value of �|�O
	 * @return �|�O
	 */
	public String getTAX_TP() {
		if(EmptyField.isEmpty(TAX_TP)){
			return null;
		}
		return TAX_TP;
	}

	/**
	 * set value of �|�O
	 * @param newTAX_TP - �|�O
	 */
	public void setTAX_TP(String newTAX_TP){
		TAX_TP = newTAX_TP;
	}	
	
	/**
	 * get value of ��ƨӷ�
	 * @return ��ƨӷ�
	 */
	public String getDATA_SOURCE() {
		if(EmptyField.isEmpty(DATA_SOURCE)){
			return null;
		}
		return DATA_SOURCE;
	}

	/**
	 * set value of ��ƨӷ�
	 * @param newDATA_SOURCE - ��ƨӷ�
	 */
	public void setDATA_SOURCE(String newDATA_SOURCE){
		DATA_SOURCE = newDATA_SOURCE;
	}	
	
	/**
	 * get value of �@�~�ɶ�
	 * @return �@�~�ɶ�
	 */
	public java.sql.Timestamp getLST_PROC_DATE() {
		if(EmptyField.isEmpty(LST_PROC_DATE)){
			return null;
		}
		return LST_PROC_DATE;
	}

	/**
	 * set value of �@�~�ɶ�
	 * @param newLST_PROC_DATE - �@�~�ɶ�
	 */
	public void setLST_PROC_DATE(java.sql.Timestamp newLST_PROC_DATE){
		LST_PROC_DATE = newLST_PROC_DATE;
	}	
	
	/**
	 * get value of �@�~�H��
	 * @return �@�~�H��
	 */
	public String getLST_PROC_ID() {
		if(EmptyField.isEmpty(LST_PROC_ID)){
			return null;
		}
		return LST_PROC_ID;
	}

	/**
	 * set value of �@�~�H��
	 * @param newLST_PROC_ID - �@�~�H��
	 */
	public void setLST_PROC_ID(String newLST_PROC_ID){
		LST_PROC_ID = newLST_PROC_ID;
	}	
	
	/**
	 * get value of �@�~���
	 * @return �@�~���
	 */
	public String getLST_PROC_DIV() {
		if(EmptyField.isEmpty(LST_PROC_DIV)){
			return null;
		}
		return LST_PROC_DIV;
	}

	/**
	 * set value of �@�~���
	 * @param newLST_PROC_DIV - �@�~���
	 */
	public void setLST_PROC_DIV(String newLST_PROC_DIV){
		LST_PROC_DIV = newLST_PROC_DIV;
	}	
	
	/**
	 * get value of �Ƨѿ��渹
	 * @return �Ƨѿ��渹
	 */
	public Integer getMEMO_NO() {
		if(EmptyField.isEmpty(MEMO_NO)){
			return null;
		}
		return MEMO_NO;
	}

	/**
	 * set value of �Ƨѿ��渹
	 * @param newMEMO_NO - �Ƨѿ��渹
	 */
	public void setMEMO_NO(Integer newMEMO_NO){
		MEMO_NO = newMEMO_NO;
	}	
	
	/**
	 * get value of �u�اǸ�
	 * @return �u�اǸ�
	 */
	public Integer getPRO_NO() {
		if(EmptyField.isEmpty(PRO_NO)){
			return null;
		}
		return PRO_NO;
	}

	/**
	 * set value of �u�اǸ�
	 * @param newPRO_NO - �u�اǸ�
	 */
	public void setPRO_NO(Integer newPRO_NO){
		PRO_NO = newPRO_NO;
	}	
	
	/**
	 * get value of ���ڹﹳ�O
	 * @return ���ڹﹳ�O
	 */
	public String getACPT_CODE() {
		if(EmptyField.isEmpty(ACPT_CODE)){
			return null;
		}
		return ACPT_CODE;
	}

	/**
	 * set value of ���ڹﹳ�O
	 * @param newACPT_CODE - ���ڹﹳ�O
	 */
	public void setACPT_CODE(String newACPT_CODE){
		ACPT_CODE = newACPT_CODE;
	}	
	
	/**
	 * get value of ���ڤH�N�X
	 * @return ���ڤH�N�X
	 */
	public String getACPT_ID() {
		if(EmptyField.isEmpty(ACPT_ID)){
			return null;
		}
		return ACPT_ID;
	}

	/**
	 * set value of ���ڤH�N�X
	 * @param newACPT_ID - ���ڤH�N�X
	 */
	public void setACPT_ID(String newACPT_ID){
		ACPT_ID = newACPT_ID;
	}	
	
	/**
	 * get value of �t�ӦW��
	 * @return �t�ӦW��
	 */
	public String getSUP_NM() {
		if(EmptyField.isEmpty(SUP_NM)){
			return null;
		}
		return SUP_NM;
	}

	/**
	 * set value of �t�ӦW��
	 * @param newSUP_NM - �t�ӦW��
	 */
	public void setSUP_NM(String newSUP_NM){
		SUP_NM = newSUP_NM;
	}	
	
	/**
	 * get value of �|�p�Ю֤��
	 * @return �|�p�Ю֤��
	 */
	public java.sql.Timestamp getACC_SECVER_DATE() {
		if(EmptyField.isEmpty(ACC_SECVER_DATE)){
			return null;
		}
		return ACC_SECVER_DATE;
	}

	/**
	 * set value of �|�p�Ю֤��
	 * @param newACC_SECVER_DATE - �|�p�Ю֤��
	 */
	public void setACC_SECVER_DATE(java.sql.Timestamp newACC_SECVER_DATE){
		ACC_SECVER_DATE = newACC_SECVER_DATE;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(PAY_CASE_NO);
		hcBuilder.append(PAY_SER_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(CONT_NO);
		hcBuilder.append(SUP_ID);
		hcBuilder.append(PAY_AMT);
		hcBuilder.append(TAX_AMT);
		hcBuilder.append(INV_NO);
		hcBuilder.append(PAY_DATE);
		hcBuilder.append(PAY_CFM_DATE);
		hcBuilder.append(CASE_NO);
		hcBuilder.append(ACC_TP);
		hcBuilder.append(TAX_TP);
		hcBuilder.append(DATA_SOURCE);
		hcBuilder.append(LST_PROC_DATE);
		hcBuilder.append(LST_PROC_ID);
		hcBuilder.append(LST_PROC_DIV);
		hcBuilder.append(MEMO_NO);
		hcBuilder.append(PRO_NO);
		hcBuilder.append(ACPT_CODE);
		hcBuilder.append(ACPT_ID);
		hcBuilder.append(SUP_NM);
		hcBuilder.append(ACC_SECVER_DATE);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF160)){
			return false;
		}
        
		DTEPF160 theObj = (DTEPF160)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				