package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPE011
 * <pre>
 * Generated value object of DBEP.DTEPE011 (�Ȥ�A��_���D��ĳ�|�������)
 * </pre>
 */
public class DTEPE011 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPE011";
	
	
	@Column(desc="���D��s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=17, defaultValue="") 
	private String PS_SER_NO = EmptyField.STRING;
	
	@Column(desc="�|��y����", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer NOTIFY_SER_NO = EmptyField.INTEGER;
	
	@Column(desc="�|��H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String TAKE_ID = EmptyField.STRING;
	
	@Column(desc="�|��ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp TAKE_DATETIME = EmptyField.TIMESTAMP;
	
	@Column(desc="�|����", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String TAKE_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�|��^�ФH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String TAKE_RE_ID = EmptyField.STRING;
	
	@Column(desc="�|��^�Ф��", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp TAKE_RE_DATETIME = EmptyField.TIMESTAMP;
	
	@Column(desc="�|��^�г��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String TAKE_RE_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�|��^�л���", type=java.sql.Types.VARCHAR, length=200, defaultValue="") 
	private String TAKE_RE_MEMO = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPE011(){
		// do nothing	
	}
	
	/**
	 * get value of ���D��s��
	 * @return ���D��s��
	 */
	public String getPS_SER_NO() {
		if(EmptyField.isEmpty(PS_SER_NO)){
			return null;
		}
		return PS_SER_NO;
	}

	/**
	 * set value of ���D��s��
	 * @param newPS_SER_NO - ���D��s��
	 */
	public void setPS_SER_NO(String newPS_SER_NO){
		PS_SER_NO = newPS_SER_NO;
	}	
	
	/**
	 * get value of �|��y����
	 * @return �|��y����
	 */
	public Integer getNOTIFY_SER_NO() {
		if(EmptyField.isEmpty(NOTIFY_SER_NO)){
			return null;
		}
		return NOTIFY_SER_NO;
	}

	/**
	 * set value of �|��y����
	 * @param newNOTIFY_SER_NO - �|��y����
	 */
	public void setNOTIFY_SER_NO(Integer newNOTIFY_SER_NO){
		NOTIFY_SER_NO = newNOTIFY_SER_NO;
	}	
	
	/**
	 * get value of �|��H��ID
	 * @return �|��H��ID
	 */
	public String getTAKE_ID() {
		if(EmptyField.isEmpty(TAKE_ID)){
			return null;
		}
		return TAKE_ID;
	}

	/**
	 * set value of �|��H��ID
	 * @param newTAKE_ID - �|��H��ID
	 */
	public void setTAKE_ID(String newTAKE_ID){
		TAKE_ID = newTAKE_ID;
	}	
	
	/**
	 * get value of �|��ɶ�
	 * @return �|��ɶ�
	 */
	public java.sql.Timestamp getTAKE_DATETIME() {
		if(EmptyField.isEmpty(TAKE_DATETIME)){
			return null;
		}
		return TAKE_DATETIME;
	}

	/**
	 * set value of �|��ɶ�
	 * @param newTAKE_DATETIME - �|��ɶ�
	 */
	public void setTAKE_DATETIME(java.sql.Timestamp newTAKE_DATETIME){
		TAKE_DATETIME = newTAKE_DATETIME;
	}	
	
	/**
	 * get value of �|����
	 * @return �|����
	 */
	public String getTAKE_DIV_NO() {
		if(EmptyField.isEmpty(TAKE_DIV_NO)){
			return null;
		}
		return TAKE_DIV_NO;
	}

	/**
	 * set value of �|����
	 * @param newTAKE_DIV_NO - �|����
	 */
	public void setTAKE_DIV_NO(String newTAKE_DIV_NO){
		TAKE_DIV_NO = newTAKE_DIV_NO;
	}	
	
	/**
	 * get value of �|��^�ФH��ID
	 * @return �|��^�ФH��ID
	 */
	public String getTAKE_RE_ID() {
		if(EmptyField.isEmpty(TAKE_RE_ID)){
			return null;
		}
		return TAKE_RE_ID;
	}

	/**
	 * set value of �|��^�ФH��ID
	 * @param newTAKE_RE_ID - �|��^�ФH��ID
	 */
	public void setTAKE_RE_ID(String newTAKE_RE_ID){
		TAKE_RE_ID = newTAKE_RE_ID;
	}	
	
	/**
	 * get value of �|��^�Ф��
	 * @return �|��^�Ф��
	 */
	public java.sql.Timestamp getTAKE_RE_DATETIME() {
		if(EmptyField.isEmpty(TAKE_RE_DATETIME)){
			return null;
		}
		return TAKE_RE_DATETIME;
	}

	/**
	 * set value of �|��^�Ф��
	 * @param newTAKE_RE_DATETIME - �|��^�Ф��
	 */
	public void setTAKE_RE_DATETIME(java.sql.Timestamp newTAKE_RE_DATETIME){
		TAKE_RE_DATETIME = newTAKE_RE_DATETIME;
	}	
	
	/**
	 * get value of �|��^�г��
	 * @return �|��^�г��
	 */
	public String getTAKE_RE_DIV_NO() {
		if(EmptyField.isEmpty(TAKE_RE_DIV_NO)){
			return null;
		}
		return TAKE_RE_DIV_NO;
	}

	/**
	 * set value of �|��^�г��
	 * @param newTAKE_RE_DIV_NO - �|��^�г��
	 */
	public void setTAKE_RE_DIV_NO(String newTAKE_RE_DIV_NO){
		TAKE_RE_DIV_NO = newTAKE_RE_DIV_NO;
	}	
	
	/**
	 * get value of �|��^�л���
	 * @return �|��^�л���
	 */
	public String getTAKE_RE_MEMO() {
		if(EmptyField.isEmpty(TAKE_RE_MEMO)){
			return null;
		}
		return TAKE_RE_MEMO;
	}

	/**
	 * set value of �|��^�л���
	 * @param newTAKE_RE_MEMO - �|��^�л���
	 */
	public void setTAKE_RE_MEMO(String newTAKE_RE_MEMO){
		TAKE_RE_MEMO = newTAKE_RE_MEMO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(PS_SER_NO);
		hcBuilder.append(NOTIFY_SER_NO);
		hcBuilder.append(TAKE_ID);
		hcBuilder.append(TAKE_DATETIME);
		hcBuilder.append(TAKE_DIV_NO);
		hcBuilder.append(TAKE_RE_ID);
		hcBuilder.append(TAKE_RE_DATETIME);
		hcBuilder.append(TAKE_RE_DIV_NO);
		hcBuilder.append(TAKE_RE_MEMO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPE011)){
			return false;
		}
        
		DTEPE011 theObj = (DTEPE011)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				