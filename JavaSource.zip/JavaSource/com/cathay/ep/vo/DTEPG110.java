package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPG110
 * <pre>
 * Generated value object of DBEP.DTEPG110 (��a�å��վ\�]�w��)
 * </pre>
 */
public class DTEPG110 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPG110";
	
	
	@Column(desc="��a�N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BASE_CD = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�����N�X", nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CITY_ID = EmptyField.STRING;
	
	@Column(desc="�����W��", type=java.sql.Types.VARCHAR, length=75, defaultValue="") 
	private String CITY_NM = EmptyField.STRING;
	
	@Column(desc="�ϰ�N�X", nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String AREA_ID = EmptyField.STRING;
	
	@Column(desc="�ϰ�W��", type=java.sql.Types.VARCHAR, length=75, defaultValue="") 
	private String AREA_NM = EmptyField.STRING;
	
	@Column(desc="�a�ҥN�X", nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String LN = EmptyField.STRING;
	
	@Column(desc="�a�ҦW��", type=java.sql.Types.VARCHAR, length=75, defaultValue="") 
	private String LN_NM = EmptyField.STRING;
	
	@Column(desc="�q�p�q�N�X", nullAble=false, type=java.sql.Types.VARCHAR, length=4, defaultValue="") 
	private String SESSION_ID = EmptyField.STRING;
	
	@Column(desc="�q�p�q�W��", type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String SESSION_NM = EmptyField.STRING;
	
	@Column(desc="�Ҧ��v�H�Ҹ�", nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String OWN_ID = EmptyField.STRING;
	
	@Column(desc="�å���a�q", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String XS_CD = EmptyField.STRING;
	
	@Column(desc="�վ\�s��", type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String EP_APLY_NO = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPG110(){
		// do nothing	
	}
	
	/**
	 * get value of ��a�N��
	 * @return ��a�N��
	 */
	public String getBASE_CD() {
		if(EmptyField.isEmpty(BASE_CD)){
			return null;
		}
		return BASE_CD;
	}

	/**
	 * set value of ��a�N��
	 * @param newBASE_CD - ��a�N��
	 */
	public void setBASE_CD(String newBASE_CD){
		BASE_CD = newBASE_CD;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �����N�X
	 * @return �����N�X
	 */
	public String getCITY_ID() {
		if(EmptyField.isEmpty(CITY_ID)){
			return null;
		}
		return CITY_ID;
	}

	/**
	 * set value of �����N�X
	 * @param newCITY_ID - �����N�X
	 */
	public void setCITY_ID(String newCITY_ID){
		CITY_ID = newCITY_ID;
	}	
	
	/**
	 * get value of �����W��
	 * @return �����W��
	 */
	public String getCITY_NM() {
		if(EmptyField.isEmpty(CITY_NM)){
			return null;
		}
		return CITY_NM;
	}

	/**
	 * set value of �����W��
	 * @param newCITY_NM - �����W��
	 */
	public void setCITY_NM(String newCITY_NM){
		CITY_NM = newCITY_NM;
	}	
	
	/**
	 * get value of �ϰ�N�X
	 * @return �ϰ�N�X
	 */
	public String getAREA_ID() {
		if(EmptyField.isEmpty(AREA_ID)){
			return null;
		}
		return AREA_ID;
	}

	/**
	 * set value of �ϰ�N�X
	 * @param newAREA_ID - �ϰ�N�X
	 */
	public void setAREA_ID(String newAREA_ID){
		AREA_ID = newAREA_ID;
	}	
	
	/**
	 * get value of �ϰ�W��
	 * @return �ϰ�W��
	 */
	public String getAREA_NM() {
		if(EmptyField.isEmpty(AREA_NM)){
			return null;
		}
		return AREA_NM;
	}

	/**
	 * set value of �ϰ�W��
	 * @param newAREA_NM - �ϰ�W��
	 */
	public void setAREA_NM(String newAREA_NM){
		AREA_NM = newAREA_NM;
	}	
	
	/**
	 * get value of �a�ҥN�X
	 * @return �a�ҥN�X
	 */
	public String getLN() {
		if(EmptyField.isEmpty(LN)){
			return null;
		}
		return LN;
	}

	/**
	 * set value of �a�ҥN�X
	 * @param newLN - �a�ҥN�X
	 */
	public void setLN(String newLN){
		LN = newLN;
	}	
	
	/**
	 * get value of �a�ҦW��
	 * @return �a�ҦW��
	 */
	public String getLN_NM() {
		if(EmptyField.isEmpty(LN_NM)){
			return null;
		}
		return LN_NM;
	}

	/**
	 * set value of �a�ҦW��
	 * @param newLN_NM - �a�ҦW��
	 */
	public void setLN_NM(String newLN_NM){
		LN_NM = newLN_NM;
	}	
	
	/**
	 * get value of �q�p�q�N�X
	 * @return �q�p�q�N�X
	 */
	public String getSESSION_ID() {
		if(EmptyField.isEmpty(SESSION_ID)){
			return null;
		}
		return SESSION_ID;
	}

	/**
	 * set value of �q�p�q�N�X
	 * @param newSESSION_ID - �q�p�q�N�X
	 */
	public void setSESSION_ID(String newSESSION_ID){
		SESSION_ID = newSESSION_ID;
	}	
	
	/**
	 * get value of �q�p�q�W��
	 * @return �q�p�q�W��
	 */
	public String getSESSION_NM() {
		if(EmptyField.isEmpty(SESSION_NM)){
			return null;
		}
		return SESSION_NM;
	}

	/**
	 * set value of �q�p�q�W��
	 * @param newSESSION_NM - �q�p�q�W��
	 */
	public void setSESSION_NM(String newSESSION_NM){
		SESSION_NM = newSESSION_NM;
	}	
	
	/**
	 * get value of �Ҧ��v�H�Ҹ�
	 * @return �Ҧ��v�H�Ҹ�
	 */
	public String getOWN_ID() {
		if(EmptyField.isEmpty(OWN_ID)){
			return null;
		}
		return OWN_ID;
	}

	/**
	 * set value of �Ҧ��v�H�Ҹ�
	 * @param newOWN_ID - �Ҧ��v�H�Ҹ�
	 */
	public void setOWN_ID(String newOWN_ID){
		OWN_ID = newOWN_ID;
	}	
	
	/**
	 * get value of �å���a�q
	 * @return �å���a�q
	 */
	public String getXS_CD() {
		if(EmptyField.isEmpty(XS_CD)){
			return null;
		}
		return XS_CD;
	}

	/**
	 * set value of �å���a�q
	 * @param newXS_CD - �å���a�q
	 */
	public void setXS_CD(String newXS_CD){
		XS_CD = newXS_CD;
	}	
	
	/**
	 * get value of �վ\�s��
	 * @return �վ\�s��
	 */
	public String getEP_APLY_NO() {
		if(EmptyField.isEmpty(EP_APLY_NO)){
			return null;
		}
		return EP_APLY_NO;
	}

	/**
	 * set value of �վ\�s��
	 * @param newEP_APLY_NO - �վ\�s��
	 */
	public void setEP_APLY_NO(String newEP_APLY_NO){
		EP_APLY_NO = newEP_APLY_NO;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(BASE_CD);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CITY_ID);
		hcBuilder.append(CITY_NM);
		hcBuilder.append(AREA_ID);
		hcBuilder.append(AREA_NM);
		hcBuilder.append(LN);
		hcBuilder.append(LN_NM);
		hcBuilder.append(SESSION_ID);
		hcBuilder.append(SESSION_NM);
		hcBuilder.append(OWN_ID);
		hcBuilder.append(XS_CD);
		hcBuilder.append(EP_APLY_NO);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPG110)){
			return false;
		}
        
		DTEPG110 theObj = (DTEPG110)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				