package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPZ004
 * <pre>
 * Generated value object of DBEP.DTEPZ004 ()
 * </pre>
 */
public class DTEPZ004 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPZ004";
	
	
	@Column(desc="�ɮ׽s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FILE_NO = EmptyField.STRING;
	
	@Column(desc="�ɮצW��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String FILE_NM = EmptyField.STRING;
	
	@Column(desc="���v���", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String COM_DATA = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="���v����", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String COM_TYPE = EmptyField.STRING;
	
	@Column(desc="��J���", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp INS_DT = EmptyField.TIMESTAMP;
	
	@Column(desc="��J�H��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INS_ID = EmptyField.STRING;
	
	@Column(desc="��J���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String INS_DIVNO = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPZ004(){
		// do nothing	
	}
	
	/**
	 * get value of �ɮ׽s��
	 * @return �ɮ׽s��
	 */
	public String getFILE_NO() {
		if(EmptyField.isEmpty(FILE_NO)){
			return null;
		}
		return FILE_NO;
	}

	/**
	 * set value of �ɮ׽s��
	 * @param newFILE_NO - �ɮ׽s��
	 */
	public void setFILE_NO(String newFILE_NO){
		FILE_NO = newFILE_NO;
	}	
	
	/**
	 * get value of �ɮצW��
	 * @return �ɮצW��
	 */
	public String getFILE_NM() {
		if(EmptyField.isEmpty(FILE_NM)){
			return null;
		}
		return FILE_NM;
	}

	/**
	 * set value of �ɮצW��
	 * @param newFILE_NM - �ɮצW��
	 */
	public void setFILE_NM(String newFILE_NM){
		FILE_NM = newFILE_NM;
	}	
	
	/**
	 * get value of ���v���
	 * @return ���v���
	 */
	public String getCOM_DATA() {
		if(EmptyField.isEmpty(COM_DATA)){
			return null;
		}
		return COM_DATA;
	}

	/**
	 * set value of ���v���
	 * @param newCOM_DATA - ���v���
	 */
	public void setCOM_DATA(String newCOM_DATA){
		COM_DATA = newCOM_DATA;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ���v����
	 * @return ���v����
	 */
	public String getCOM_TYPE() {
		if(EmptyField.isEmpty(COM_TYPE)){
			return null;
		}
		return COM_TYPE;
	}

	/**
	 * set value of ���v����
	 * @param newCOM_TYPE - ���v����
	 */
	public void setCOM_TYPE(String newCOM_TYPE){
		COM_TYPE = newCOM_TYPE;
	}	
	
	/**
	 * get value of ��J���
	 * @return ��J���
	 */
	public java.sql.Timestamp getINS_DT() {
		if(EmptyField.isEmpty(INS_DT)){
			return null;
		}
		return INS_DT;
	}

	/**
	 * set value of ��J���
	 * @param newINS_DT - ��J���
	 */
	public void setINS_DT(java.sql.Timestamp newINS_DT){
		INS_DT = newINS_DT;
	}	
	
	/**
	 * get value of ��J�H��
	 * @return ��J�H��
	 */
	public String getINS_ID() {
		if(EmptyField.isEmpty(INS_ID)){
			return null;
		}
		return INS_ID;
	}

	/**
	 * set value of ��J�H��
	 * @param newINS_ID - ��J�H��
	 */
	public void setINS_ID(String newINS_ID){
		INS_ID = newINS_ID;
	}	
	
	/**
	 * get value of ��J���
	 * @return ��J���
	 */
	public String getINS_DIVNO() {
		if(EmptyField.isEmpty(INS_DIVNO)){
			return null;
		}
		return INS_DIVNO;
	}

	/**
	 * set value of ��J���
	 * @param newINS_DIVNO - ��J���
	 */
	public void setINS_DIVNO(String newINS_DIVNO){
		INS_DIVNO = newINS_DIVNO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(FILE_NO);
		hcBuilder.append(FILE_NM);
		hcBuilder.append(COM_DATA);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(COM_TYPE);
		hcBuilder.append(INS_DT);
		hcBuilder.append(INS_ID);
		hcBuilder.append(INS_DIVNO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPZ004)){
			return false;
		}
        
		DTEPZ004 theObj = (DTEPZ004)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				