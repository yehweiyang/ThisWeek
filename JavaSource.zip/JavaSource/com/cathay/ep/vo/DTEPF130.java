package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF130
 * <pre>
 * Generated value object of DBEP.DTEPF130 (��µ�ץ�_�u�{������)
 * </pre>
 */
public class DTEPF130 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF130";
	
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�Ƨѿ��渹", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer MEMO_NO = EmptyField.INTEGER;
	
	@Column(desc="�u�اǸ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer PRO_NO = EmptyField.INTEGER;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�u�{����", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String PROJECT_TP = EmptyField.STRING;
	
	@Column(desc="�O�T���", type=java.sql.Types.DECIMAL, length=3, defaultValue="") 
	private java.math.BigDecimal WAR_MON = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ƶq", type=java.sql.Types.DECIMAL, length=2, defaultValue="") 
	private java.math.BigDecimal CNT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String UNIT = EmptyField.STRING;
	
	@Column(desc="���", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PRICE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�w�����B(�t�|)", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal EST_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�t�ӽs��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String SUP_ID = EmptyField.STRING;
	
	@Column(desc="�������B(�t�|)", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal CLR_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="��@���B(�t�|)", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal ACT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���I�l�B(�t�|)", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PR_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�u�{�k��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String PRO_OWN = EmptyField.STRING;
	
	@Column(desc="�X����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String IS_CONT = EmptyField.STRING;
	
	@Column(desc="�X���s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CONT_NO = EmptyField.STRING;
	
	@Column(desc="�X�����B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal CONT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�I�u�_��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date CONS_SDATE = EmptyField.DATE;
	
	@Column(desc="�I�u����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date CONS_EDATE = EmptyField.DATE;
	
	@Column(desc="���u���", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date FINAL_DATE = EmptyField.DATE;
	
	@Column(desc="�@�~�ɶ�", nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp LST_PROC_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�@�~�H��", nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String LST_PROC_ID = EmptyField.STRING;
	
	@Column(desc="�@�~���", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String LST_PROC_DIV = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPF130(){
		// do nothing	
	}
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �Ƨѿ��渹
	 * @return �Ƨѿ��渹
	 */
	public Integer getMEMO_NO() {
		if(EmptyField.isEmpty(MEMO_NO)){
			return null;
		}
		return MEMO_NO;
	}

	/**
	 * set value of �Ƨѿ��渹
	 * @param newMEMO_NO - �Ƨѿ��渹
	 */
	public void setMEMO_NO(Integer newMEMO_NO){
		MEMO_NO = newMEMO_NO;
	}	
	
	/**
	 * get value of �u�اǸ�
	 * @return �u�اǸ�
	 */
	public Integer getPRO_NO() {
		if(EmptyField.isEmpty(PRO_NO)){
			return null;
		}
		return PRO_NO;
	}

	/**
	 * set value of �u�اǸ�
	 * @param newPRO_NO - �u�اǸ�
	 */
	public void setPRO_NO(Integer newPRO_NO){
		PRO_NO = newPRO_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �u�{����
	 * @return �u�{����
	 */
	public String getPROJECT_TP() {
		if(EmptyField.isEmpty(PROJECT_TP)){
			return null;
		}
		return PROJECT_TP;
	}

	/**
	 * set value of �u�{����
	 * @param newPROJECT_TP - �u�{����
	 */
	public void setPROJECT_TP(String newPROJECT_TP){
		PROJECT_TP = newPROJECT_TP;
	}	
	
	/**
	 * get value of �O�T���
	 * @return �O�T���
	 */
	public java.math.BigDecimal getWAR_MON() {
		if(EmptyField.isEmpty(WAR_MON)){
			return null;
		}
		return WAR_MON;
	}

	/**
	 * set value of �O�T���
	 * @param newWAR_MON - �O�T���
	 */
	public void setWAR_MON(java.math.BigDecimal newWAR_MON){
		WAR_MON = newWAR_MON;
	}	
	
	/**
	 * get value of �ƶq
	 * @return �ƶq
	 */
	public java.math.BigDecimal getCNT() {
		if(EmptyField.isEmpty(CNT)){
			return null;
		}
		return CNT;
	}

	/**
	 * set value of �ƶq
	 * @param newCNT - �ƶq
	 */
	public void setCNT(java.math.BigDecimal newCNT){
		CNT = newCNT;
	}	
	
	/**
	 * get value of ���
	 * @return ���
	 */
	public String getUNIT() {
		if(EmptyField.isEmpty(UNIT)){
			return null;
		}
		return UNIT;
	}

	/**
	 * set value of ���
	 * @param newUNIT - ���
	 */
	public void setUNIT(String newUNIT){
		UNIT = newUNIT;
	}	
	
	/**
	 * get value of ���
	 * @return ���
	 */
	public java.math.BigDecimal getPRICE() {
		if(EmptyField.isEmpty(PRICE)){
			return null;
		}
		return PRICE;
	}

	/**
	 * set value of ���
	 * @param newPRICE - ���
	 */
	public void setPRICE(java.math.BigDecimal newPRICE){
		PRICE = newPRICE;
	}	
	
	/**
	 * get value of �w�����B(�t�|)
	 * @return �w�����B(�t�|)
	 */
	public java.math.BigDecimal getEST_AMT() {
		if(EmptyField.isEmpty(EST_AMT)){
			return null;
		}
		return EST_AMT;
	}

	/**
	 * set value of �w�����B(�t�|)
	 * @param newEST_AMT - �w�����B(�t�|)
	 */
	public void setEST_AMT(java.math.BigDecimal newEST_AMT){
		EST_AMT = newEST_AMT;
	}	
	
	/**
	 * get value of �t�ӽs��
	 * @return �t�ӽs��
	 */
	public String getSUP_ID() {
		if(EmptyField.isEmpty(SUP_ID)){
			return null;
		}
		return SUP_ID;
	}

	/**
	 * set value of �t�ӽs��
	 * @param newSUP_ID - �t�ӽs��
	 */
	public void setSUP_ID(String newSUP_ID){
		SUP_ID = newSUP_ID;
	}	
	
	/**
	 * get value of �������B(�t�|)
	 * @return �������B(�t�|)
	 */
	public java.math.BigDecimal getCLR_AMT() {
		if(EmptyField.isEmpty(CLR_AMT)){
			return null;
		}
		return CLR_AMT;
	}

	/**
	 * set value of �������B(�t�|)
	 * @param newCLR_AMT - �������B(�t�|)
	 */
	public void setCLR_AMT(java.math.BigDecimal newCLR_AMT){
		CLR_AMT = newCLR_AMT;
	}	
	
	/**
	 * get value of ��@���B(�t�|)
	 * @return ��@���B(�t�|)
	 */
	public java.math.BigDecimal getACT_AMT() {
		if(EmptyField.isEmpty(ACT_AMT)){
			return null;
		}
		return ACT_AMT;
	}

	/**
	 * set value of ��@���B(�t�|)
	 * @param newACT_AMT - ��@���B(�t�|)
	 */
	public void setACT_AMT(java.math.BigDecimal newACT_AMT){
		ACT_AMT = newACT_AMT;
	}	
	
	/**
	 * get value of ���I�l�B(�t�|)
	 * @return ���I�l�B(�t�|)
	 */
	public java.math.BigDecimal getPR_AMT() {
		if(EmptyField.isEmpty(PR_AMT)){
			return null;
		}
		return PR_AMT;
	}

	/**
	 * set value of ���I�l�B(�t�|)
	 * @param newPR_AMT - ���I�l�B(�t�|)
	 */
	public void setPR_AMT(java.math.BigDecimal newPR_AMT){
		PR_AMT = newPR_AMT;
	}	
	
	/**
	 * get value of �u�{�k��
	 * @return �u�{�k��
	 */
	public String getPRO_OWN() {
		if(EmptyField.isEmpty(PRO_OWN)){
			return null;
		}
		return PRO_OWN;
	}

	/**
	 * set value of �u�{�k��
	 * @param newPRO_OWN - �u�{�k��
	 */
	public void setPRO_OWN(String newPRO_OWN){
		PRO_OWN = newPRO_OWN;
	}	
	
	/**
	 * get value of �X����
	 * @return �X����
	 */
	public String getIS_CONT() {
		if(EmptyField.isEmpty(IS_CONT)){
			return null;
		}
		return IS_CONT;
	}

	/**
	 * set value of �X����
	 * @param newIS_CONT - �X����
	 */
	public void setIS_CONT(String newIS_CONT){
		IS_CONT = newIS_CONT;
	}	
	
	/**
	 * get value of �X���s��
	 * @return �X���s��
	 */
	public String getCONT_NO() {
		if(EmptyField.isEmpty(CONT_NO)){
			return null;
		}
		return CONT_NO;
	}

	/**
	 * set value of �X���s��
	 * @param newCONT_NO - �X���s��
	 */
	public void setCONT_NO(String newCONT_NO){
		CONT_NO = newCONT_NO;
	}	
	
	/**
	 * get value of �X�����B
	 * @return �X�����B
	 */
	public java.math.BigDecimal getCONT_AMT() {
		if(EmptyField.isEmpty(CONT_AMT)){
			return null;
		}
		return CONT_AMT;
	}

	/**
	 * set value of �X�����B
	 * @param newCONT_AMT - �X�����B
	 */
	public void setCONT_AMT(java.math.BigDecimal newCONT_AMT){
		CONT_AMT = newCONT_AMT;
	}	
	
	/**
	 * get value of �I�u�_��
	 * @return �I�u�_��
	 */
	public java.sql.Date getCONS_SDATE() {
		if(EmptyField.isEmpty(CONS_SDATE)){
			return null;
		}
		return CONS_SDATE;
	}

	/**
	 * set value of �I�u�_��
	 * @param newCONS_SDATE - �I�u�_��
	 */
	public void setCONS_SDATE(java.sql.Date newCONS_SDATE){
		CONS_SDATE = newCONS_SDATE;
	}	
	
	/**
	 * get value of �I�u����
	 * @return �I�u����
	 */
	public java.sql.Date getCONS_EDATE() {
		if(EmptyField.isEmpty(CONS_EDATE)){
			return null;
		}
		return CONS_EDATE;
	}

	/**
	 * set value of �I�u����
	 * @param newCONS_EDATE - �I�u����
	 */
	public void setCONS_EDATE(java.sql.Date newCONS_EDATE){
		CONS_EDATE = newCONS_EDATE;
	}	
	
	/**
	 * get value of ���u���
	 * @return ���u���
	 */
	public java.sql.Date getFINAL_DATE() {
		if(EmptyField.isEmpty(FINAL_DATE)){
			return null;
		}
		return FINAL_DATE;
	}

	/**
	 * set value of ���u���
	 * @param newFINAL_DATE - ���u���
	 */
	public void setFINAL_DATE(java.sql.Date newFINAL_DATE){
		FINAL_DATE = newFINAL_DATE;
	}	
	
	/**
	 * get value of �@�~�ɶ�
	 * @return �@�~�ɶ�
	 */
	public java.sql.Timestamp getLST_PROC_DATE() {
		if(EmptyField.isEmpty(LST_PROC_DATE)){
			return null;
		}
		return LST_PROC_DATE;
	}

	/**
	 * set value of �@�~�ɶ�
	 * @param newLST_PROC_DATE - �@�~�ɶ�
	 */
	public void setLST_PROC_DATE(java.sql.Timestamp newLST_PROC_DATE){
		LST_PROC_DATE = newLST_PROC_DATE;
	}	
	
	/**
	 * get value of �@�~�H��
	 * @return �@�~�H��
	 */
	public String getLST_PROC_ID() {
		if(EmptyField.isEmpty(LST_PROC_ID)){
			return null;
		}
		return LST_PROC_ID;
	}

	/**
	 * set value of �@�~�H��
	 * @param newLST_PROC_ID - �@�~�H��
	 */
	public void setLST_PROC_ID(String newLST_PROC_ID){
		LST_PROC_ID = newLST_PROC_ID;
	}	
	
	/**
	 * get value of �@�~���
	 * @return �@�~���
	 */
	public String getLST_PROC_DIV() {
		if(EmptyField.isEmpty(LST_PROC_DIV)){
			return null;
		}
		return LST_PROC_DIV;
	}

	/**
	 * set value of �@�~���
	 * @param newLST_PROC_DIV - �@�~���
	 */
	public void setLST_PROC_DIV(String newLST_PROC_DIV){
		LST_PROC_DIV = newLST_PROC_DIV;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(APLY_NO);
		hcBuilder.append(MEMO_NO);
		hcBuilder.append(PRO_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(PROJECT_TP);
		hcBuilder.append(WAR_MON);
		hcBuilder.append(CNT);
		hcBuilder.append(UNIT);
		hcBuilder.append(PRICE);
		hcBuilder.append(EST_AMT);
		hcBuilder.append(SUP_ID);
		hcBuilder.append(CLR_AMT);
		hcBuilder.append(ACT_AMT);
		hcBuilder.append(PR_AMT);
		hcBuilder.append(PRO_OWN);
		hcBuilder.append(IS_CONT);
		hcBuilder.append(CONT_NO);
		hcBuilder.append(CONT_AMT);
		hcBuilder.append(CONS_SDATE);
		hcBuilder.append(CONS_EDATE);
		hcBuilder.append(FINAL_DATE);
		hcBuilder.append(LST_PROC_DATE);
		hcBuilder.append(LST_PROC_ID);
		hcBuilder.append(LST_PROC_DIV);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF130)){
			return false;
		}
        
		DTEPF130 theObj = (DTEPF130)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				