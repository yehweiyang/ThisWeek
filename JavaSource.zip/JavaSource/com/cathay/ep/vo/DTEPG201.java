package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPG201
 * <pre>
 * Generated value object of DBEP.DTEPG201 (��a��������)
 * </pre>
 */
public class DTEPG201 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPG201";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="��a�N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BASE_CD = EmptyField.STRING;
	
	@Column(desc="���ӧǸ�", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String ITEM_SEQ = EmptyField.STRING;
	
	@Column(desc="���ۥ�", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String BASE_USE_CD = EmptyField.STRING;
	
	@Column(desc="���O", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String KIND = EmptyField.STRING;
	
	@Column(desc="�������O", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String COST_TP = EmptyField.STRING;
	
	@Column(desc="�����O", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_TP = EmptyField.STRING;
	
	@Column(desc="������", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date TRN_DT = EmptyField.DATE;
	
	@Column(desc="������B", type=java.sql.Types.DECIMAL, length=22, defaultValue="") 
	private java.math.BigDecimal TRN_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="������n", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal TRN_AREA = EmptyField.BIGDECIMAL;
	
	@Column(desc="�K�n", type=java.sql.Types.VARCHAR, length=50, defaultValue="") 
	private String MEMO = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPG201(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ��a�N��
	 * @return ��a�N��
	 */
	public String getBASE_CD() {
		if(EmptyField.isEmpty(BASE_CD)){
			return null;
		}
		return BASE_CD;
	}

	/**
	 * set value of ��a�N��
	 * @param newBASE_CD - ��a�N��
	 */
	public void setBASE_CD(String newBASE_CD){
		BASE_CD = newBASE_CD;
	}	
	
	/**
	 * get value of ���ӧǸ�
	 * @return ���ӧǸ�
	 */
	public String getITEM_SEQ() {
		if(EmptyField.isEmpty(ITEM_SEQ)){
			return null;
		}
		return ITEM_SEQ;
	}

	/**
	 * set value of ���ӧǸ�
	 * @param newITEM_SEQ - ���ӧǸ�
	 */
	public void setITEM_SEQ(String newITEM_SEQ){
		ITEM_SEQ = newITEM_SEQ;
	}	
	
	/**
	 * get value of ���ۥ�
	 * @return ���ۥ�
	 */
	public String getBASE_USE_CD() {
		if(EmptyField.isEmpty(BASE_USE_CD)){
			return null;
		}
		return BASE_USE_CD;
	}

	/**
	 * set value of ���ۥ�
	 * @param newBASE_USE_CD - ���ۥ�
	 */
	public void setBASE_USE_CD(String newBASE_USE_CD){
		BASE_USE_CD = newBASE_USE_CD;
	}	
	
	/**
	 * get value of ���O
	 * @return ���O
	 */
	public String getKIND() {
		if(EmptyField.isEmpty(KIND)){
			return null;
		}
		return KIND;
	}

	/**
	 * set value of ���O
	 * @param newKIND - ���O
	 */
	public void setKIND(String newKIND){
		KIND = newKIND;
	}	
	
	/**
	 * get value of �������O
	 * @return �������O
	 */
	public String getCOST_TP() {
		if(EmptyField.isEmpty(COST_TP)){
			return null;
		}
		return COST_TP;
	}

	/**
	 * set value of �������O
	 * @param newCOST_TP - �������O
	 */
	public void setCOST_TP(String newCOST_TP){
		COST_TP = newCOST_TP;
	}	
	
	/**
	 * get value of �����O
	 * @return �����O
	 */
	public String getSUB_TP() {
		if(EmptyField.isEmpty(SUB_TP)){
			return null;
		}
		return SUB_TP;
	}

	/**
	 * set value of �����O
	 * @param newSUB_TP - �����O
	 */
	public void setSUB_TP(String newSUB_TP){
		SUB_TP = newSUB_TP;
	}	
	
	/**
	 * get value of ������
	 * @return ������
	 */
	public java.sql.Date getTRN_DT() {
		if(EmptyField.isEmpty(TRN_DT)){
			return null;
		}
		return TRN_DT;
	}

	/**
	 * set value of ������
	 * @param newTRN_DT - ������
	 */
	public void setTRN_DT(java.sql.Date newTRN_DT){
		TRN_DT = newTRN_DT;
	}	
	
	/**
	 * get value of ������B
	 * @return ������B
	 */
	public java.math.BigDecimal getTRN_AMT() {
		if(EmptyField.isEmpty(TRN_AMT)){
			return null;
		}
		return TRN_AMT;
	}

	/**
	 * set value of ������B
	 * @param newTRN_AMT - ������B
	 */
	public void setTRN_AMT(java.math.BigDecimal newTRN_AMT){
		TRN_AMT = newTRN_AMT;
	}	
	
	/**
	 * get value of ������n
	 * @return ������n
	 */
	public java.math.BigDecimal getTRN_AREA() {
		if(EmptyField.isEmpty(TRN_AREA)){
			return null;
		}
		return TRN_AREA;
	}

	/**
	 * set value of ������n
	 * @param newTRN_AREA - ������n
	 */
	public void setTRN_AREA(java.math.BigDecimal newTRN_AREA){
		TRN_AREA = newTRN_AREA;
	}	
	
	/**
	 * get value of �K�n
	 * @return �K�n
	 */
	public String getMEMO() {
		if(EmptyField.isEmpty(MEMO)){
			return null;
		}
		return MEMO;
	}

	/**
	 * set value of �K�n
	 * @param newMEMO - �K�n
	 */
	public void setMEMO(String newMEMO){
		MEMO = newMEMO;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BASE_CD);
		hcBuilder.append(ITEM_SEQ);
		hcBuilder.append(BASE_USE_CD);
		hcBuilder.append(KIND);
		hcBuilder.append(COST_TP);
		hcBuilder.append(SUB_TP);
		hcBuilder.append(TRN_DT);
		hcBuilder.append(TRN_AMT);
		hcBuilder.append(TRN_AREA);
		hcBuilder.append(MEMO);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPG201)){
			return false;
		}
        
		DTEPG201 theObj = (DTEPG201)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				