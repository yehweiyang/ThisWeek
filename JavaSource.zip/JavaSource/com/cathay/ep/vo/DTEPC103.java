package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC103
 * <pre>
 * Generated value object of DBEP.DTEPC103 (�޲z�O���u�������)
 * </pre>
 */
public class DTEPC103 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC103";
	
	
	@Column(desc="�����s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String RCV_NO = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�����~��", type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal RCV_YM = EmptyField.BIGDECIMAL;
	
	@Column(desc="�j�ӥN��", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�����N��", type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�P����B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal SAL_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="��~�|�B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal TAX_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�����`�B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal RCV_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ҥ󸹽X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ID = EmptyField.STRING;
	
	@Column(desc="�Ȥ�W��", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String CUS_NAME = EmptyField.STRING;
	
	@Column(desc="�@�o����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String DEL_CD = EmptyField.STRING;
	
	@Column(desc="�������", nullAble=false, type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	@Column(desc="�f��y�{�s��", nullAble=false, type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FLOW_NO = EmptyField.STRING;
	
	@Column(desc="�@�~�i��", type=java.sql.Types.CHAR, length=3, defaultValue="") 
	private String OP_STATUS = EmptyField.STRING;
	
	@Column(desc="�@�~�ɶ�", nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp LST_PROC_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�@�~�H��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String LST_PROC_ID = EmptyField.STRING;
	
	@Column(desc="�@�~���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String LST_PROC_DIV = EmptyField.STRING;
	
	@Column(desc="�@�~�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String LST_PROC_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPC103(){
		// do nothing	
	}
	
	/**
	 * get value of �����s��
	 * @return �����s��
	 */
	public String getRCV_NO() {
		if(EmptyField.isEmpty(RCV_NO)){
			return null;
		}
		return RCV_NO;
	}

	/**
	 * set value of �����s��
	 * @param newRCV_NO - �����s��
	 */
	public void setRCV_NO(String newRCV_NO){
		RCV_NO = newRCV_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �����~��
	 * @return �����~��
	 */
	public java.math.BigDecimal getRCV_YM() {
		if(EmptyField.isEmpty(RCV_YM)){
			return null;
		}
		return RCV_YM;
	}

	/**
	 * set value of �����~��
	 * @param newRCV_YM - �����~��
	 */
	public void setRCV_YM(java.math.BigDecimal newRCV_YM){
		RCV_YM = newRCV_YM;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �P����B
	 * @return �P����B
	 */
	public java.math.BigDecimal getSAL_AMT() {
		if(EmptyField.isEmpty(SAL_AMT)){
			return null;
		}
		return SAL_AMT;
	}

	/**
	 * set value of �P����B
	 * @param newSAL_AMT - �P����B
	 */
	public void setSAL_AMT(java.math.BigDecimal newSAL_AMT){
		SAL_AMT = newSAL_AMT;
	}	
	
	/**
	 * get value of ��~�|�B
	 * @return ��~�|�B
	 */
	public java.math.BigDecimal getTAX_AMT() {
		if(EmptyField.isEmpty(TAX_AMT)){
			return null;
		}
		return TAX_AMT;
	}

	/**
	 * set value of ��~�|�B
	 * @param newTAX_AMT - ��~�|�B
	 */
	public void setTAX_AMT(java.math.BigDecimal newTAX_AMT){
		TAX_AMT = newTAX_AMT;
	}	
	
	/**
	 * get value of �����`�B
	 * @return �����`�B
	 */
	public java.math.BigDecimal getRCV_AMT() {
		if(EmptyField.isEmpty(RCV_AMT)){
			return null;
		}
		return RCV_AMT;
	}

	/**
	 * set value of �����`�B
	 * @param newRCV_AMT - �����`�B
	 */
	public void setRCV_AMT(java.math.BigDecimal newRCV_AMT){
		RCV_AMT = newRCV_AMT;
	}	
	
	/**
	 * get value of �ҥ󸹽X
	 * @return �ҥ󸹽X
	 */
	public String getID() {
		if(EmptyField.isEmpty(ID)){
			return null;
		}
		return ID;
	}

	/**
	 * set value of �ҥ󸹽X
	 * @param newID - �ҥ󸹽X
	 */
	public void setID(String newID){
		ID = newID;
	}	
	
	/**
	 * get value of �Ȥ�W��
	 * @return �Ȥ�W��
	 */
	public String getCUS_NAME() {
		if(EmptyField.isEmpty(CUS_NAME)){
			return null;
		}
		return CUS_NAME;
	}

	/**
	 * set value of �Ȥ�W��
	 * @param newCUS_NAME - �Ȥ�W��
	 */
	public void setCUS_NAME(String newCUS_NAME){
		CUS_NAME = newCUS_NAME;
	}	
	
	/**
	 * get value of �@�o����
	 * @return �@�o����
	 */
	public String getDEL_CD() {
		if(EmptyField.isEmpty(DEL_CD)){
			return null;
		}
		return DEL_CD;
	}

	/**
	 * set value of �@�o����
	 * @param newDEL_CD - �@�o����
	 */
	public void setDEL_CD(String newDEL_CD){
		DEL_CD = newDEL_CD;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * get value of �f��y�{�s��
	 * @return �f��y�{�s��
	 */
	public String getFLOW_NO() {
		if(EmptyField.isEmpty(FLOW_NO)){
			return null;
		}
		return FLOW_NO;
	}

	/**
	 * set value of �f��y�{�s��
	 * @param newFLOW_NO - �f��y�{�s��
	 */
	public void setFLOW_NO(String newFLOW_NO){
		FLOW_NO = newFLOW_NO;
	}	
	
	/**
	 * get value of �@�~�i��
	 * @return �@�~�i��
	 */
	public String getOP_STATUS() {
		if(EmptyField.isEmpty(OP_STATUS)){
			return null;
		}
		return OP_STATUS;
	}

	/**
	 * set value of �@�~�i��
	 * @param newOP_STATUS - �@�~�i��
	 */
	public void setOP_STATUS(String newOP_STATUS){
		OP_STATUS = newOP_STATUS;
	}	
	
	/**
	 * get value of �@�~�ɶ�
	 * @return �@�~�ɶ�
	 */
	public java.sql.Timestamp getLST_PROC_DATE() {
		if(EmptyField.isEmpty(LST_PROC_DATE)){
			return null;
		}
		return LST_PROC_DATE;
	}

	/**
	 * set value of �@�~�ɶ�
	 * @param newLST_PROC_DATE - �@�~�ɶ�
	 */
	public void setLST_PROC_DATE(java.sql.Timestamp newLST_PROC_DATE){
		LST_PROC_DATE = newLST_PROC_DATE;
	}	
	
	/**
	 * get value of �@�~�H��
	 * @return �@�~�H��
	 */
	public String getLST_PROC_ID() {
		if(EmptyField.isEmpty(LST_PROC_ID)){
			return null;
		}
		return LST_PROC_ID;
	}

	/**
	 * set value of �@�~�H��
	 * @param newLST_PROC_ID - �@�~�H��
	 */
	public void setLST_PROC_ID(String newLST_PROC_ID){
		LST_PROC_ID = newLST_PROC_ID;
	}	
	
	/**
	 * get value of �@�~���
	 * @return �@�~���
	 */
	public String getLST_PROC_DIV() {
		if(EmptyField.isEmpty(LST_PROC_DIV)){
			return null;
		}
		return LST_PROC_DIV;
	}

	/**
	 * set value of �@�~���
	 * @param newLST_PROC_DIV - �@�~���
	 */
	public void setLST_PROC_DIV(String newLST_PROC_DIV){
		LST_PROC_DIV = newLST_PROC_DIV;
	}	
	
	/**
	 * get value of �@�~�H���m�W
	 * @return �@�~�H���m�W
	 */
	public String getLST_PROC_NAME() {
		if(EmptyField.isEmpty(LST_PROC_NAME)){
			return null;
		}
		return LST_PROC_NAME;
	}

	/**
	 * set value of �@�~�H���m�W
	 * @param newLST_PROC_NAME - �@�~�H���m�W
	 */
	public void setLST_PROC_NAME(String newLST_PROC_NAME){
		LST_PROC_NAME = newLST_PROC_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(RCV_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(RCV_YM);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(SAL_AMT);
		hcBuilder.append(TAX_AMT);
		hcBuilder.append(RCV_AMT);
		hcBuilder.append(ID);
		hcBuilder.append(CUS_NAME);
		hcBuilder.append(DEL_CD);
		hcBuilder.append(TRN_KIND);
		hcBuilder.append(FLOW_NO);
		hcBuilder.append(OP_STATUS);
		hcBuilder.append(LST_PROC_DATE);
		hcBuilder.append(LST_PROC_ID);
		hcBuilder.append(LST_PROC_DIV);
		hcBuilder.append(LST_PROC_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC103)){
			return false;
		}
        
		DTEPC103 theObj = (DTEPC103)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				