package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPZ301
 * <pre>
 * Generated value object of DBEP.DTEPZ301 (���ʲ������T������)
 * </pre>
 */
public class DTEPZ301 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPZ301";
	
	
	@Column(desc="�ƥ�N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String EVENT_ID = EmptyField.STRING;
	
	@Column(desc="�B�z�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer PCS_SEQ = EmptyField.INTEGER;
	
	@Column(desc="�T���ӷ����}", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=800, defaultValue="") 
	private String URL = EmptyField.STRING;
	
	@Column(desc="�T�����D", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=1200, defaultValue="") 
	private String TITLE = EmptyField.STRING;
	
	@Column(desc="�T���Ƶ�", type=java.sql.Types.VARCHAR, length=1000, defaultValue="") 
	private String MEMO = EmptyField.STRING;
	
	@Column(desc="�T���ӷ�", type=java.sql.Types.VARCHAR, length=75, defaultValue="") 
	private String INFO_SOURCE = EmptyField.STRING;
	
	@Column(desc="�̪�B�z�ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp PCS_DT = EmptyField.TIMESTAMP;
	
	@Column(desc="RSS�o�G�ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp PUBLISH_DT = EmptyField.TIMESTAMP;
	
	/**
	 * Default constructor
	 */
	public DTEPZ301(){
		// do nothing	
	}
	
	/**
	 * get value of �ƥ�N��
	 * @return �ƥ�N��
	 */
	public String getEVENT_ID() {
		if(EmptyField.isEmpty(EVENT_ID)){
			return null;
		}
		return EVENT_ID;
	}

	/**
	 * set value of �ƥ�N��
	 * @param newEVENT_ID - �ƥ�N��
	 */
	public void setEVENT_ID(String newEVENT_ID){
		EVENT_ID = newEVENT_ID;
	}	
	
	/**
	 * get value of �B�z�Ǹ�
	 * @return �B�z�Ǹ�
	 */
	public Integer getPCS_SEQ() {
		if(EmptyField.isEmpty(PCS_SEQ)){
			return null;
		}
		return PCS_SEQ;
	}

	/**
	 * set value of �B�z�Ǹ�
	 * @param newPCS_SEQ - �B�z�Ǹ�
	 */
	public void setPCS_SEQ(Integer newPCS_SEQ){
		PCS_SEQ = newPCS_SEQ;
	}	
	
	/**
	 * get value of �T���ӷ����}
	 * @return �T���ӷ����}
	 */
	public String getURL() {
		if(EmptyField.isEmpty(URL)){
			return null;
		}
		return URL;
	}

	/**
	 * set value of �T���ӷ����}
	 * @param newURL - �T���ӷ����}
	 */
	public void setURL(String newURL){
		URL = newURL;
	}	
	
	/**
	 * get value of �T�����D
	 * @return �T�����D
	 */
	public String getTITLE() {
		if(EmptyField.isEmpty(TITLE)){
			return null;
		}
		return TITLE;
	}

	/**
	 * set value of �T�����D
	 * @param newTITLE - �T�����D
	 */
	public void setTITLE(String newTITLE){
		TITLE = newTITLE;
	}	
	
	/**
	 * get value of �T���Ƶ�
	 * @return �T���Ƶ�
	 */
	public String getMEMO() {
		if(EmptyField.isEmpty(MEMO)){
			return null;
		}
		return MEMO;
	}

	/**
	 * set value of �T���Ƶ�
	 * @param newMEMO - �T���Ƶ�
	 */
	public void setMEMO(String newMEMO){
		MEMO = newMEMO;
	}	
	
	/**
	 * get value of �T���ӷ�
	 * @return �T���ӷ�
	 */
	public String getINFO_SOURCE() {
		if(EmptyField.isEmpty(INFO_SOURCE)){
			return null;
		}
		return INFO_SOURCE;
	}

	/**
	 * set value of �T���ӷ�
	 * @param newINFO_SOURCE - �T���ӷ�
	 */
	public void setINFO_SOURCE(String newINFO_SOURCE){
		INFO_SOURCE = newINFO_SOURCE;
	}	
	
	/**
	 * get value of �̪�B�z�ɶ�
	 * @return �̪�B�z�ɶ�
	 */
	public java.sql.Timestamp getPCS_DT() {
		if(EmptyField.isEmpty(PCS_DT)){
			return null;
		}
		return PCS_DT;
	}

	/**
	 * set value of �̪�B�z�ɶ�
	 * @param newPCS_DT - �̪�B�z�ɶ�
	 */
	public void setPCS_DT(java.sql.Timestamp newPCS_DT){
		PCS_DT = newPCS_DT;
	}	
	
	/**
	 * get value of RSS�o�G�ɶ�
	 * @return RSS�o�G�ɶ�
	 */
	public java.sql.Timestamp getPUBLISH_DT() {
		if(EmptyField.isEmpty(PUBLISH_DT)){
			return null;
		}
		return PUBLISH_DT;
	}

	/**
	 * set value of RSS�o�G�ɶ�
	 * @param newPUBLISH_DT - RSS�o�G�ɶ�
	 */
	public void setPUBLISH_DT(java.sql.Timestamp newPUBLISH_DT){
		PUBLISH_DT = newPUBLISH_DT;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(EVENT_ID);
		hcBuilder.append(PCS_SEQ);
		hcBuilder.append(URL);
		hcBuilder.append(TITLE);
		hcBuilder.append(MEMO);
		hcBuilder.append(INFO_SOURCE);
		hcBuilder.append(PCS_DT);
		hcBuilder.append(PUBLISH_DT);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPZ301)){
			return false;
		}
        
		DTEPZ301 theObj = (DTEPZ301)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				