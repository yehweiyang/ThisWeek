package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC302
 * <pre>
 * Generated value object of DBEP.DTEPC302 (���ک�����)
 * </pre>
 */
public class DTEPC302 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC302";
	
	
	@Column(desc="��w�N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String BANK_NO = EmptyField.STRING;
	
	@Column(desc="����", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String CHK_NO = EmptyField.STRING;
	
	@Column(desc="�b��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=16, defaultValue="") 
	private String ACNT_NO = EmptyField.STRING;
	
	@Column(desc="���ڲո�", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHK_SET_NO = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="���ڤ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date CHK_DATE = EmptyField.DATE;
	
	@Column(desc="���ڪ��B", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CHK_AMT = EmptyField.INTEGER;
	
	@Column(desc="��J�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INPUT_ID = EmptyField.STRING;
	
	@Column(desc="��J�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String INPUT_NAME = EmptyField.STRING;
	
	@Column(desc="�������ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp TRN_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�g�����Ǹ�", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal TRN_SER_NO = EmptyField.BIGDECIMAL;
	
	@Column(desc="�b�Ȥ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ACNT_DATE = EmptyField.DATE;
	
	@Column(desc="�b�ȳ��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACNT_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��帹", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String SLIP_LOT_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��ո�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SLIP_SET_NO = EmptyField.INTEGER;
	
	/**
	 * Default constructor
	 */
	public DTEPC302(){
		// do nothing	
	}
	
	/**
	 * get value of ��w�N��
	 * @return ��w�N��
	 */
	public String getBANK_NO() {
		if(EmptyField.isEmpty(BANK_NO)){
			return null;
		}
		return BANK_NO;
	}

	/**
	 * set value of ��w�N��
	 * @param newBANK_NO - ��w�N��
	 */
	public void setBANK_NO(String newBANK_NO){
		BANK_NO = newBANK_NO;
	}	
	
	/**
	 * get value of ����
	 * @return ����
	 */
	public String getCHK_NO() {
		if(EmptyField.isEmpty(CHK_NO)){
			return null;
		}
		return CHK_NO;
	}

	/**
	 * set value of ����
	 * @param newCHK_NO - ����
	 */
	public void setCHK_NO(String newCHK_NO){
		CHK_NO = newCHK_NO;
	}	
	
	/**
	 * get value of �b��
	 * @return �b��
	 */
	public String getACNT_NO() {
		if(EmptyField.isEmpty(ACNT_NO)){
			return null;
		}
		return ACNT_NO;
	}

	/**
	 * set value of �b��
	 * @param newACNT_NO - �b��
	 */
	public void setACNT_NO(String newACNT_NO){
		ACNT_NO = newACNT_NO;
	}	
	
	/**
	 * get value of ���ڲո�
	 * @return ���ڲո�
	 */
	public String getCHK_SET_NO() {
		if(EmptyField.isEmpty(CHK_SET_NO)){
			return null;
		}
		return CHK_SET_NO;
	}

	/**
	 * set value of ���ڲո�
	 * @param newCHK_SET_NO - ���ڲո�
	 */
	public void setCHK_SET_NO(String newCHK_SET_NO){
		CHK_SET_NO = newCHK_SET_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ���ڤ��
	 * @return ���ڤ��
	 */
	public java.sql.Date getCHK_DATE() {
		if(EmptyField.isEmpty(CHK_DATE)){
			return null;
		}
		return CHK_DATE;
	}

	/**
	 * set value of ���ڤ��
	 * @param newCHK_DATE - ���ڤ��
	 */
	public void setCHK_DATE(java.sql.Date newCHK_DATE){
		CHK_DATE = newCHK_DATE;
	}	
	
	/**
	 * get value of ���ڪ��B
	 * @return ���ڪ��B
	 */
	public Integer getCHK_AMT() {
		if(EmptyField.isEmpty(CHK_AMT)){
			return null;
		}
		return CHK_AMT;
	}

	/**
	 * set value of ���ڪ��B
	 * @param newCHK_AMT - ���ڪ��B
	 */
	public void setCHK_AMT(Integer newCHK_AMT){
		CHK_AMT = newCHK_AMT;
	}	
	
	/**
	 * get value of ��J�H��ID
	 * @return ��J�H��ID
	 */
	public String getINPUT_ID() {
		if(EmptyField.isEmpty(INPUT_ID)){
			return null;
		}
		return INPUT_ID;
	}

	/**
	 * set value of ��J�H��ID
	 * @param newINPUT_ID - ��J�H��ID
	 */
	public void setINPUT_ID(String newINPUT_ID){
		INPUT_ID = newINPUT_ID;
	}	
	
	/**
	 * get value of ��J�H���m�W
	 * @return ��J�H���m�W
	 */
	public String getINPUT_NAME() {
		if(EmptyField.isEmpty(INPUT_NAME)){
			return null;
		}
		return INPUT_NAME;
	}

	/**
	 * set value of ��J�H���m�W
	 * @param newINPUT_NAME - ��J�H���m�W
	 */
	public void setINPUT_NAME(String newINPUT_NAME){
		INPUT_NAME = newINPUT_NAME;
	}	
	
	/**
	 * get value of �������ɶ�
	 * @return �������ɶ�
	 */
	public java.sql.Timestamp getTRN_DATE() {
		if(EmptyField.isEmpty(TRN_DATE)){
			return null;
		}
		return TRN_DATE;
	}

	/**
	 * set value of �������ɶ�
	 * @param newTRN_DATE - �������ɶ�
	 */
	public void setTRN_DATE(java.sql.Timestamp newTRN_DATE){
		TRN_DATE = newTRN_DATE;
	}	
	
	/**
	 * get value of �g�����Ǹ�
	 * @return �g�����Ǹ�
	 */
	public java.math.BigDecimal getTRN_SER_NO() {
		if(EmptyField.isEmpty(TRN_SER_NO)){
			return null;
		}
		return TRN_SER_NO;
	}

	/**
	 * set value of �g�����Ǹ�
	 * @param newTRN_SER_NO - �g�����Ǹ�
	 */
	public void setTRN_SER_NO(java.math.BigDecimal newTRN_SER_NO){
		TRN_SER_NO = newTRN_SER_NO;
	}	
	
	/**
	 * get value of �b�Ȥ��
	 * @return �b�Ȥ��
	 */
	public java.sql.Date getACNT_DATE() {
		if(EmptyField.isEmpty(ACNT_DATE)){
			return null;
		}
		return ACNT_DATE;
	}

	/**
	 * set value of �b�Ȥ��
	 * @param newACNT_DATE - �b�Ȥ��
	 */
	public void setACNT_DATE(java.sql.Date newACNT_DATE){
		ACNT_DATE = newACNT_DATE;
	}	
	
	/**
	 * get value of �b�ȳ��
	 * @return �b�ȳ��
	 */
	public String getACNT_DIV_NO() {
		if(EmptyField.isEmpty(ACNT_DIV_NO)){
			return null;
		}
		return ACNT_DIV_NO;
	}

	/**
	 * set value of �b�ȳ��
	 * @param newACNT_DIV_NO - �b�ȳ��
	 */
	public void setACNT_DIV_NO(String newACNT_DIV_NO){
		ACNT_DIV_NO = newACNT_DIV_NO;
	}	
	
	/**
	 * get value of �ǲ��帹
	 * @return �ǲ��帹
	 */
	public String getSLIP_LOT_NO() {
		if(EmptyField.isEmpty(SLIP_LOT_NO)){
			return null;
		}
		return SLIP_LOT_NO;
	}

	/**
	 * set value of �ǲ��帹
	 * @param newSLIP_LOT_NO - �ǲ��帹
	 */
	public void setSLIP_LOT_NO(String newSLIP_LOT_NO){
		SLIP_LOT_NO = newSLIP_LOT_NO;
	}	
	
	/**
	 * get value of �ǲ��ո�
	 * @return �ǲ��ո�
	 */
	public Integer getSLIP_SET_NO() {
		if(EmptyField.isEmpty(SLIP_SET_NO)){
			return null;
		}
		return SLIP_SET_NO;
	}

	/**
	 * set value of �ǲ��ո�
	 * @param newSLIP_SET_NO - �ǲ��ո�
	 */
	public void setSLIP_SET_NO(Integer newSLIP_SET_NO){
		SLIP_SET_NO = newSLIP_SET_NO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(BANK_NO);
		hcBuilder.append(CHK_NO);
		hcBuilder.append(ACNT_NO);
		hcBuilder.append(CHK_SET_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CHK_DATE);
		hcBuilder.append(CHK_AMT);
		hcBuilder.append(INPUT_ID);
		hcBuilder.append(INPUT_NAME);
		hcBuilder.append(TRN_DATE);
		hcBuilder.append(TRN_SER_NO);
		hcBuilder.append(ACNT_DATE);
		hcBuilder.append(ACNT_DIV_NO);
		hcBuilder.append(SLIP_LOT_NO);
		hcBuilder.append(SLIP_SET_NO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC302)){
			return false;
		}
        
		DTEPC302 theObj = (DTEPC302)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				