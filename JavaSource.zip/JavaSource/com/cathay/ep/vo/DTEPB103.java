package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPB103
 * <pre>
 * Generated value object of DBEP.DTEPB103 (����_�Ƶ�
����)
 * </pre>
 */
public class DTEPB103 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPB103";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�����N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�~��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=4, defaultValue="") 
	private String YEAR = EmptyField.STRING;
	
	@Column(desc="�ӿ��O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CLC_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�y����", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SER_NO = EmptyField.INTEGER;
	
	@Column(desc="�Ƶ�", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String MEMO = EmptyField.STRING;
	
	@Column(desc="�q���O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String INFM_TYPE = EmptyField.STRING;
	
	@Column(desc="�B�z���A", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String PROC_STS = EmptyField.STRING;
	
	@Column(desc="�q�����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date INFM_DATE = EmptyField.DATE;
	
	@Column(desc="�q���H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INFM_ID = EmptyField.STRING;
	
	@Column(desc="�q���H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String INFM_NAME = EmptyField.STRING;
	
	@Column(desc="�q��EMAIL", type=java.sql.Types.VARCHAR, length=50, defaultValue="") 
	private String INFM_EMAIL = EmptyField.STRING;
	
	@Column(desc="���פ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date END_CASE_DATE = EmptyField.DATE;
	
	@Column(desc="�ɮ׽s��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FILE_NO = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPB103(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �~��
	 * @return �~��
	 */
	public String getYEAR() {
		if(EmptyField.isEmpty(YEAR)){
			return null;
		}
		return YEAR;
	}

	/**
	 * set value of �~��
	 * @param newYEAR - �~��
	 */
	public void setYEAR(String newYEAR){
		YEAR = newYEAR;
	}	
	
	/**
	 * get value of �ӿ��O
	 * @return �ӿ��O
	 */
	public String getCLC_DIV_NO() {
		if(EmptyField.isEmpty(CLC_DIV_NO)){
			return null;
		}
		return CLC_DIV_NO;
	}

	/**
	 * set value of �ӿ��O
	 * @param newCLC_DIV_NO - �ӿ��O
	 */
	public void setCLC_DIV_NO(String newCLC_DIV_NO){
		CLC_DIV_NO = newCLC_DIV_NO;
	}	
	
	/**
	 * get value of �y����
	 * @return �y����
	 */
	public Integer getSER_NO() {
		if(EmptyField.isEmpty(SER_NO)){
			return null;
		}
		return SER_NO;
	}

	/**
	 * set value of �y����
	 * @param newSER_NO - �y����
	 */
	public void setSER_NO(Integer newSER_NO){
		SER_NO = newSER_NO;
	}	
	
	/**
	 * get value of �Ƶ�
	 * @return �Ƶ�
	 */
	public String getMEMO() {
		if(EmptyField.isEmpty(MEMO)){
			return null;
		}
		return MEMO;
	}

	/**
	 * set value of �Ƶ�
	 * @param newMEMO - �Ƶ�
	 */
	public void setMEMO(String newMEMO){
		MEMO = newMEMO;
	}	
	
	/**
	 * get value of �q���O
	 * @return �q���O
	 */
	public String getINFM_TYPE() {
		if(EmptyField.isEmpty(INFM_TYPE)){
			return null;
		}
		return INFM_TYPE;
	}

	/**
	 * set value of �q���O
	 * @param newINFM_TYPE - �q���O
	 */
	public void setINFM_TYPE(String newINFM_TYPE){
		INFM_TYPE = newINFM_TYPE;
	}	
	
	/**
	 * get value of �B�z���A
	 * @return �B�z���A
	 */
	public String getPROC_STS() {
		if(EmptyField.isEmpty(PROC_STS)){
			return null;
		}
		return PROC_STS;
	}

	/**
	 * set value of �B�z���A
	 * @param newPROC_STS - �B�z���A
	 */
	public void setPROC_STS(String newPROC_STS){
		PROC_STS = newPROC_STS;
	}	
	
	/**
	 * get value of �q�����
	 * @return �q�����
	 */
	public java.sql.Date getINFM_DATE() {
		if(EmptyField.isEmpty(INFM_DATE)){
			return null;
		}
		return INFM_DATE;
	}

	/**
	 * set value of �q�����
	 * @param newINFM_DATE - �q�����
	 */
	public void setINFM_DATE(java.sql.Date newINFM_DATE){
		INFM_DATE = newINFM_DATE;
	}	
	
	/**
	 * get value of �q���H��ID
	 * @return �q���H��ID
	 */
	public String getINFM_ID() {
		if(EmptyField.isEmpty(INFM_ID)){
			return null;
		}
		return INFM_ID;
	}

	/**
	 * set value of �q���H��ID
	 * @param newINFM_ID - �q���H��ID
	 */
	public void setINFM_ID(String newINFM_ID){
		INFM_ID = newINFM_ID;
	}	
	
	/**
	 * get value of �q���H���m�W
	 * @return �q���H���m�W
	 */
	public String getINFM_NAME() {
		if(EmptyField.isEmpty(INFM_NAME)){
			return null;
		}
		return INFM_NAME;
	}

	/**
	 * set value of �q���H���m�W
	 * @param newINFM_NAME - �q���H���m�W
	 */
	public void setINFM_NAME(String newINFM_NAME){
		INFM_NAME = newINFM_NAME;
	}	
	
	/**
	 * get value of �q��EMAIL
	 * @return �q��EMAIL
	 */
	public String getINFM_EMAIL() {
		if(EmptyField.isEmpty(INFM_EMAIL)){
			return null;
		}
		return INFM_EMAIL;
	}

	/**
	 * set value of �q��EMAIL
	 * @param newINFM_EMAIL - �q��EMAIL
	 */
	public void setINFM_EMAIL(String newINFM_EMAIL){
		INFM_EMAIL = newINFM_EMAIL;
	}	
	
	/**
	 * get value of ���פ��
	 * @return ���פ��
	 */
	public java.sql.Date getEND_CASE_DATE() {
		if(EmptyField.isEmpty(END_CASE_DATE)){
			return null;
		}
		return END_CASE_DATE;
	}

	/**
	 * set value of ���פ��
	 * @param newEND_CASE_DATE - ���פ��
	 */
	public void setEND_CASE_DATE(java.sql.Date newEND_CASE_DATE){
		END_CASE_DATE = newEND_CASE_DATE;
	}	
	
	/**
	 * get value of �ɮ׽s��
	 * @return �ɮ׽s��
	 */
	public String getFILE_NO() {
		if(EmptyField.isEmpty(FILE_NO)){
			return null;
		}
		return FILE_NO;
	}

	/**
	 * set value of �ɮ׽s��
	 * @param newFILE_NO - �ɮ׽s��
	 */
	public void setFILE_NO(String newFILE_NO){
		FILE_NO = newFILE_NO;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(YEAR);
		hcBuilder.append(CLC_DIV_NO);
		hcBuilder.append(SER_NO);
		hcBuilder.append(MEMO);
		hcBuilder.append(INFM_TYPE);
		hcBuilder.append(PROC_STS);
		hcBuilder.append(INFM_DATE);
		hcBuilder.append(INFM_ID);
		hcBuilder.append(INFM_NAME);
		hcBuilder.append(INFM_EMAIL);
		hcBuilder.append(END_CASE_DATE);
		hcBuilder.append(FILE_NO);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPB103)){
			return false;
		}
        
		DTEPB103 theObj = (DTEPB103)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				