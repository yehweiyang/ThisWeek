package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC209
 * <pre>
 * Generated value object of DBEP.DTEPC209 ()
 * </pre>
 */
public class DTEPC209 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC209";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�����N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�����~��", pk=true, nullAble=false, type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal RCV_YM = EmptyField.BIGDECIMAL;
	
	@Column(desc="ú�ں���", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String PAY_KIND = EmptyField.STRING;
	
	@Column(desc="���O", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String MEMO = EmptyField.STRING;
	
	@Column(desc="�@�~�ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp OPR_DATE = EmptyField.TIMESTAMP;
	
	/**
	 * Default constructor
	 */
	public DTEPC209(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �����~��
	 * @return �����~��
	 */
	public java.math.BigDecimal getRCV_YM() {
		if(EmptyField.isEmpty(RCV_YM)){
			return null;
		}
		return RCV_YM;
	}

	/**
	 * set value of �����~��
	 * @param newRCV_YM - �����~��
	 */
	public void setRCV_YM(java.math.BigDecimal newRCV_YM){
		RCV_YM = newRCV_YM;
	}	
	
	/**
	 * get value of ú�ں���
	 * @return ú�ں���
	 */
	public String getPAY_KIND() {
		if(EmptyField.isEmpty(PAY_KIND)){
			return null;
		}
		return PAY_KIND;
	}

	/**
	 * set value of ú�ں���
	 * @param newPAY_KIND - ú�ں���
	 */
	public void setPAY_KIND(String newPAY_KIND){
		PAY_KIND = newPAY_KIND;
	}	
	
	/**
	 * get value of ���O
	 * @return ���O
	 */
	public String getMEMO() {
		if(EmptyField.isEmpty(MEMO)){
			return null;
		}
		return MEMO;
	}

	/**
	 * set value of ���O
	 * @param newMEMO - ���O
	 */
	public void setMEMO(String newMEMO){
		MEMO = newMEMO;
	}	
	
	/**
	 * get value of �@�~�ɶ�
	 * @return �@�~�ɶ�
	 */
	public java.sql.Timestamp getOPR_DATE() {
		if(EmptyField.isEmpty(OPR_DATE)){
			return null;
		}
		return OPR_DATE;
	}

	/**
	 * set value of �@�~�ɶ�
	 * @param newOPR_DATE - �@�~�ɶ�
	 */
	public void setOPR_DATE(java.sql.Timestamp newOPR_DATE){
		OPR_DATE = newOPR_DATE;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(RCV_YM);
		hcBuilder.append(PAY_KIND);
		hcBuilder.append(MEMO);
		hcBuilder.append(OPR_DATE);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC209)){
			return false;
		}
        
		DTEPC209 theObj = (DTEPC209)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				