package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF151
 * <pre>
 * Generated value object of DBEP.DTEPF151 ()
 * </pre>
 */
public class DTEPF151 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF151";
	
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�M�����", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String CLOSE_TP = EmptyField.STRING;
	
	@Column(desc="�M��N�X", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String SUB_ITEM_NO = EmptyField.STRING;
	
	@Column(desc="�M�ⶵ�ئW��", nullAble=false, type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String SUB_ITEM_NM = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="����", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String SUB_ITEM = EmptyField.STRING;
	
	@Column(desc="�X�p", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal ITEM_TOTAL = EmptyField.BIGDECIMAL;
	
	@Column(desc="�Ƶ�", type=java.sql.Types.VARCHAR, length=375, defaultValue="") 
	private String ITEM_MEMO = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPF151(){
		// do nothing	
	}
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �M�����
	 * @return �M�����
	 */
	public String getCLOSE_TP() {
		if(EmptyField.isEmpty(CLOSE_TP)){
			return null;
		}
		return CLOSE_TP;
	}

	/**
	 * set value of �M�����
	 * @param newCLOSE_TP - �M�����
	 */
	public void setCLOSE_TP(String newCLOSE_TP){
		CLOSE_TP = newCLOSE_TP;
	}	
	
	/**
	 * get value of �M��N�X
	 * @return �M��N�X
	 */
	public String getSUB_ITEM_NO() {
		if(EmptyField.isEmpty(SUB_ITEM_NO)){
			return null;
		}
		return SUB_ITEM_NO;
	}

	/**
	 * set value of �M��N�X
	 * @param newSUB_ITEM_NO - �M��N�X
	 */
	public void setSUB_ITEM_NO(String newSUB_ITEM_NO){
		SUB_ITEM_NO = newSUB_ITEM_NO;
	}	
	
	/**
	 * get value of �M�ⶵ�ئW��
	 * @return �M�ⶵ�ئW��
	 */
	public String getSUB_ITEM_NM() {
		if(EmptyField.isEmpty(SUB_ITEM_NM)){
			return null;
		}
		return SUB_ITEM_NM;
	}

	/**
	 * set value of �M�ⶵ�ئW��
	 * @param newSUB_ITEM_NM - �M�ⶵ�ئW��
	 */
	public void setSUB_ITEM_NM(String newSUB_ITEM_NM){
		SUB_ITEM_NM = newSUB_ITEM_NM;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ����
	 * @return ����
	 */
	public String getSUB_ITEM() {
		if(EmptyField.isEmpty(SUB_ITEM)){
			return null;
		}
		return SUB_ITEM;
	}

	/**
	 * set value of ����
	 * @param newSUB_ITEM - ����
	 */
	public void setSUB_ITEM(String newSUB_ITEM){
		SUB_ITEM = newSUB_ITEM;
	}	
	
	/**
	 * get value of �X�p
	 * @return �X�p
	 */
	public java.math.BigDecimal getITEM_TOTAL() {
		if(EmptyField.isEmpty(ITEM_TOTAL)){
			return null;
		}
		return ITEM_TOTAL;
	}

	/**
	 * set value of �X�p
	 * @param newITEM_TOTAL - �X�p
	 */
	public void setITEM_TOTAL(java.math.BigDecimal newITEM_TOTAL){
		ITEM_TOTAL = newITEM_TOTAL;
	}	
	
	/**
	 * get value of �Ƶ�
	 * @return �Ƶ�
	 */
	public String getITEM_MEMO() {
		if(EmptyField.isEmpty(ITEM_MEMO)){
			return null;
		}
		return ITEM_MEMO;
	}

	/**
	 * set value of �Ƶ�
	 * @param newITEM_MEMO - �Ƶ�
	 */
	public void setITEM_MEMO(String newITEM_MEMO){
		ITEM_MEMO = newITEM_MEMO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(APLY_NO);
		hcBuilder.append(CLOSE_TP);
		hcBuilder.append(SUB_ITEM_NO);
		hcBuilder.append(SUB_ITEM_NM);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(SUB_ITEM);
		hcBuilder.append(ITEM_TOTAL);
		hcBuilder.append(ITEM_MEMO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF151)){
			return false;
		}
        
		DTEPF151 theObj = (DTEPF151)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				