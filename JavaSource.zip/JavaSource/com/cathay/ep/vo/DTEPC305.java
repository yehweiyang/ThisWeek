package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC305
 * <pre>
 * Generated value object of DBEP.DTEPC305 ()
 * </pre>
 */
public class DTEPC305 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC305";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�d��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String CARD_NO = EmptyField.STRING;
	
	@Column(desc="����(�Ȧ�)�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String RCV_NO = EmptyField.STRING;
	
	@Column(desc="��ú�~��", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String RCV_YM = EmptyField.STRING;
	
	@Column(desc="�B�z���", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date PRC_DATE = EmptyField.DATE;
	
	@Column(desc="�ǲ����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ACNT_DATE = EmptyField.DATE;
	
	@Column(desc="���ڲո�", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHK_SET_NO = EmptyField.STRING;
	
	@Column(desc="�Ȧ�P�b��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date COA_DATE = EmptyField.DATE;
	
	@Column(desc="�d����X��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date CRD_DATE = EmptyField.DATE;
	
	@Column(desc="���O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String CHK_KD = EmptyField.STRING;
	
	@Column(desc="��s���", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp UPD_DATE = EmptyField.TIMESTAMP;
	
	/**
	 * Default constructor
	 */
	public DTEPC305(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �d��
	 * @return �d��
	 */
	public String getCARD_NO() {
		if(EmptyField.isEmpty(CARD_NO)){
			return null;
		}
		return CARD_NO;
	}

	/**
	 * set value of �d��
	 * @param newCARD_NO - �d��
	 */
	public void setCARD_NO(String newCARD_NO){
		CARD_NO = newCARD_NO;
	}	
	
	/**
	 * get value of ����(�Ȧ�)�s��
	 * @return ����(�Ȧ�)�s��
	 */
	public String getRCV_NO() {
		if(EmptyField.isEmpty(RCV_NO)){
			return null;
		}
		return RCV_NO;
	}

	/**
	 * set value of ����(�Ȧ�)�s��
	 * @param newRCV_NO - ����(�Ȧ�)�s��
	 */
	public void setRCV_NO(String newRCV_NO){
		RCV_NO = newRCV_NO;
	}	
	
	/**
	 * get value of ��ú�~��
	 * @return ��ú�~��
	 */
	public String getRCV_YM() {
		if(EmptyField.isEmpty(RCV_YM)){
			return null;
		}
		return RCV_YM;
	}

	/**
	 * set value of ��ú�~��
	 * @param newRCV_YM - ��ú�~��
	 */
	public void setRCV_YM(String newRCV_YM){
		RCV_YM = newRCV_YM;
	}	
	
	/**
	 * get value of �B�z���
	 * @return �B�z���
	 */
	public java.sql.Date getPRC_DATE() {
		if(EmptyField.isEmpty(PRC_DATE)){
			return null;
		}
		return PRC_DATE;
	}

	/**
	 * set value of �B�z���
	 * @param newPRC_DATE - �B�z���
	 */
	public void setPRC_DATE(java.sql.Date newPRC_DATE){
		PRC_DATE = newPRC_DATE;
	}	
	
	/**
	 * get value of �ǲ����
	 * @return �ǲ����
	 */
	public java.sql.Date getACNT_DATE() {
		if(EmptyField.isEmpty(ACNT_DATE)){
			return null;
		}
		return ACNT_DATE;
	}

	/**
	 * set value of �ǲ����
	 * @param newACNT_DATE - �ǲ����
	 */
	public void setACNT_DATE(java.sql.Date newACNT_DATE){
		ACNT_DATE = newACNT_DATE;
	}	
	
	/**
	 * get value of ���ڲո�
	 * @return ���ڲո�
	 */
	public String getCHK_SET_NO() {
		if(EmptyField.isEmpty(CHK_SET_NO)){
			return null;
		}
		return CHK_SET_NO;
	}

	/**
	 * set value of ���ڲո�
	 * @param newCHK_SET_NO - ���ڲո�
	 */
	public void setCHK_SET_NO(String newCHK_SET_NO){
		CHK_SET_NO = newCHK_SET_NO;
	}	
	
	/**
	 * get value of �Ȧ�P�b��
	 * @return �Ȧ�P�b��
	 */
	public java.sql.Date getCOA_DATE() {
		if(EmptyField.isEmpty(COA_DATE)){
			return null;
		}
		return COA_DATE;
	}

	/**
	 * set value of �Ȧ�P�b��
	 * @param newCOA_DATE - �Ȧ�P�b��
	 */
	public void setCOA_DATE(java.sql.Date newCOA_DATE){
		COA_DATE = newCOA_DATE;
	}	
	
	/**
	 * get value of �d����X��
	 * @return �d����X��
	 */
	public java.sql.Date getCRD_DATE() {
		if(EmptyField.isEmpty(CRD_DATE)){
			return null;
		}
		return CRD_DATE;
	}

	/**
	 * set value of �d����X��
	 * @param newCRD_DATE - �d����X��
	 */
	public void setCRD_DATE(java.sql.Date newCRD_DATE){
		CRD_DATE = newCRD_DATE;
	}	
	
	/**
	 * get value of ���O
	 * @return ���O
	 */
	public String getCHK_KD() {
		if(EmptyField.isEmpty(CHK_KD)){
			return null;
		}
		return CHK_KD;
	}

	/**
	 * set value of ���O
	 * @param newCHK_KD - ���O
	 */
	public void setCHK_KD(String newCHK_KD){
		CHK_KD = newCHK_KD;
	}	
	
	/**
	 * get value of ��s���
	 * @return ��s���
	 */
	public java.sql.Timestamp getUPD_DATE() {
		if(EmptyField.isEmpty(UPD_DATE)){
			return null;
		}
		return UPD_DATE;
	}

	/**
	 * set value of ��s���
	 * @param newUPD_DATE - ��s���
	 */
	public void setUPD_DATE(java.sql.Timestamp newUPD_DATE){
		UPD_DATE = newUPD_DATE;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CARD_NO);
		hcBuilder.append(RCV_NO);
		hcBuilder.append(RCV_YM);
		hcBuilder.append(PRC_DATE);
		hcBuilder.append(ACNT_DATE);
		hcBuilder.append(CHK_SET_NO);
		hcBuilder.append(COA_DATE);
		hcBuilder.append(CRD_DATE);
		hcBuilder.append(CHK_KD);
		hcBuilder.append(UPD_DATE);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC305)){
			return false;
		}
        
		DTEPC305 theObj = (DTEPC305)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				