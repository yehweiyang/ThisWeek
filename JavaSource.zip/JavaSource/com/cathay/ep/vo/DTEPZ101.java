package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPZ101
 * <pre>
 * Generated value object of DBEP.DTEPZ101 (�]�w_�㯲���Q�v��)
 * </pre>
 */
public class DTEPZ101 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPZ101";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�~��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=4, defaultValue="") 
	private String YEAR = EmptyField.STRING;
	
	@Column(desc="�Q�v�N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String RATE_CD = EmptyField.STRING;
	
	@Column(desc="�㯲���~�Q�v", type=java.sql.Types.DECIMAL, length=13, defaultValue="") 
	private java.math.BigDecimal YEAR_RATE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�㯲����Q�v", type=java.sql.Types.DECIMAL, length=13, defaultValue="") 
	private java.math.BigDecimal MONTH_RATE = EmptyField.BIGDECIMAL;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPZ101(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �~��
	 * @return �~��
	 */
	public String getYEAR() {
		if(EmptyField.isEmpty(YEAR)){
			return null;
		}
		return YEAR;
	}

	/**
	 * set value of �~��
	 * @param newYEAR - �~��
	 */
	public void setYEAR(String newYEAR){
		YEAR = newYEAR;
	}	
	
	/**
	 * get value of �Q�v�N��
	 * @return �Q�v�N��
	 */
	public String getRATE_CD() {
		if(EmptyField.isEmpty(RATE_CD)){
			return null;
		}
		return RATE_CD;
	}

	/**
	 * set value of �Q�v�N��
	 * @param newRATE_CD - �Q�v�N��
	 */
	public void setRATE_CD(String newRATE_CD){
		RATE_CD = newRATE_CD;
	}	
	
	/**
	 * get value of �㯲���~�Q�v
	 * @return �㯲���~�Q�v
	 */
	public java.math.BigDecimal getYEAR_RATE() {
		if(EmptyField.isEmpty(YEAR_RATE)){
			return null;
		}
		return YEAR_RATE;
	}

	/**
	 * set value of �㯲���~�Q�v
	 * @param newYEAR_RATE - �㯲���~�Q�v
	 */
	public void setYEAR_RATE(java.math.BigDecimal newYEAR_RATE){
		YEAR_RATE = newYEAR_RATE;
	}	
	
	/**
	 * get value of �㯲����Q�v
	 * @return �㯲����Q�v
	 */
	public java.math.BigDecimal getMONTH_RATE() {
		if(EmptyField.isEmpty(MONTH_RATE)){
			return null;
		}
		return MONTH_RATE;
	}

	/**
	 * set value of �㯲����Q�v
	 * @param newMONTH_RATE - �㯲����Q�v
	 */
	public void setMONTH_RATE(java.math.BigDecimal newMONTH_RATE){
		MONTH_RATE = newMONTH_RATE;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(YEAR);
		hcBuilder.append(RATE_CD);
		hcBuilder.append(YEAR_RATE);
		hcBuilder.append(MONTH_RATE);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPZ101)){
			return false;
		}
        
		DTEPZ101 theObj = (DTEPZ101)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				