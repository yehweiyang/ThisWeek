package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPG152
 * <pre>
 * Generated value object of DBEP.DTEPG152 (��a�s�Y�ɧQ���ˮ�)
 * </pre>
 */
public class DTEPG152 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPG152";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="��a�N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BASE_CD = EmptyField.STRING;
	
	@Column(desc="�ˮ֦~��", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CAL_YM = EmptyField.INTEGER;
	
	@Column(desc="�X���v(%)", type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal RENT_RT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�����S�v(%)", type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal ROI_RT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ˮ֫���(%)", type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal IDX_RT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�Y�ɧQ���ˮ�", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String USE_CHK = EmptyField.STRING;
	
	@Column(desc="�ˮֳƵ�����", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String CHK_MEMO = EmptyField.STRING;
	
	@Column(desc="�����覡", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ACC_MD = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPG152(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ��a�N��
	 * @return ��a�N��
	 */
	public String getBASE_CD() {
		if(EmptyField.isEmpty(BASE_CD)){
			return null;
		}
		return BASE_CD;
	}

	/**
	 * set value of ��a�N��
	 * @param newBASE_CD - ��a�N��
	 */
	public void setBASE_CD(String newBASE_CD){
		BASE_CD = newBASE_CD;
	}	
	
	/**
	 * get value of �ˮ֦~��
	 * @return �ˮ֦~��
	 */
	public Integer getCAL_YM() {
		if(EmptyField.isEmpty(CAL_YM)){
			return null;
		}
		return CAL_YM;
	}

	/**
	 * set value of �ˮ֦~��
	 * @param newCAL_YM - �ˮ֦~��
	 */
	public void setCAL_YM(Integer newCAL_YM){
		CAL_YM = newCAL_YM;
	}	
	
	/**
	 * get value of �X���v(%)
	 * @return �X���v(%)
	 */
	public java.math.BigDecimal getRENT_RT() {
		if(EmptyField.isEmpty(RENT_RT)){
			return null;
		}
		return RENT_RT;
	}

	/**
	 * set value of �X���v(%)
	 * @param newRENT_RT - �X���v(%)
	 */
	public void setRENT_RT(java.math.BigDecimal newRENT_RT){
		RENT_RT = newRENT_RT;
	}	
	
	/**
	 * get value of �����S�v(%)
	 * @return �����S�v(%)
	 */
	public java.math.BigDecimal getROI_RT() {
		if(EmptyField.isEmpty(ROI_RT)){
			return null;
		}
		return ROI_RT;
	}

	/**
	 * set value of �����S�v(%)
	 * @param newROI_RT - �����S�v(%)
	 */
	public void setROI_RT(java.math.BigDecimal newROI_RT){
		ROI_RT = newROI_RT;
	}	
	
	/**
	 * get value of �ˮ֫���(%)
	 * @return �ˮ֫���(%)
	 */
	public java.math.BigDecimal getIDX_RT() {
		if(EmptyField.isEmpty(IDX_RT)){
			return null;
		}
		return IDX_RT;
	}

	/**
	 * set value of �ˮ֫���(%)
	 * @param newIDX_RT - �ˮ֫���(%)
	 */
	public void setIDX_RT(java.math.BigDecimal newIDX_RT){
		IDX_RT = newIDX_RT;
	}	
	
	/**
	 * get value of �Y�ɧQ���ˮ�
	 * @return �Y�ɧQ���ˮ�
	 */
	public String getUSE_CHK() {
		if(EmptyField.isEmpty(USE_CHK)){
			return null;
		}
		return USE_CHK;
	}

	/**
	 * set value of �Y�ɧQ���ˮ�
	 * @param newUSE_CHK - �Y�ɧQ���ˮ�
	 */
	public void setUSE_CHK(String newUSE_CHK){
		USE_CHK = newUSE_CHK;
	}	
	
	/**
	 * get value of �ˮֳƵ�����
	 * @return �ˮֳƵ�����
	 */
	public String getCHK_MEMO() {
		if(EmptyField.isEmpty(CHK_MEMO)){
			return null;
		}
		return CHK_MEMO;
	}

	/**
	 * set value of �ˮֳƵ�����
	 * @param newCHK_MEMO - �ˮֳƵ�����
	 */
	public void setCHK_MEMO(String newCHK_MEMO){
		CHK_MEMO = newCHK_MEMO;
	}	
	
	/**
	 * get value of �����覡
	 * @return �����覡
	 */
	public String getACC_MD() {
		if(EmptyField.isEmpty(ACC_MD)){
			return null;
		}
		return ACC_MD;
	}

	/**
	 * set value of �����覡
	 * @param newACC_MD - �����覡
	 */
	public void setACC_MD(String newACC_MD){
		ACC_MD = newACC_MD;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BASE_CD);
		hcBuilder.append(CAL_YM);
		hcBuilder.append(RENT_RT);
		hcBuilder.append(ROI_RT);
		hcBuilder.append(IDX_RT);
		hcBuilder.append(USE_CHK);
		hcBuilder.append(CHK_MEMO);
		hcBuilder.append(ACC_MD);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPG152)){
			return false;
		}
        
		DTEPG152 theObj = (DTEPG152)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				