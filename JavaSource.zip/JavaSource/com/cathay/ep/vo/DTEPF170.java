package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF170
 * <pre>
 * Generated value object of DBEP.DTEPF170 (�j�ӤH���]�w��)
 * </pre>
 */
public class DTEPF170 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF170";
	
	
	@Column(desc="�j�ӥN��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=11, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�j�ӦW��", type=java.sql.Types.VARCHAR, length=45, defaultValue="") 
	private String BLD_NAME = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�j�Ӳ{���޲z(�ӽ�)���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String REQ_DIV = EmptyField.STRING;
	
	@Column(desc="�j�Ӳ{���޲z(�ӽ�)���W��", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String REQ_NM = EmptyField.STRING;
	
	@Column(desc="�j�Ӳ{���޲z(�ӽ�)�H��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String REQ_ID = EmptyField.STRING;
	
	@Column(desc="��µ��H��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String FIX_DIV_ID = EmptyField.STRING;
	
	@Column(desc="��µ�դH��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String FIX_GROUP_ID = EmptyField.STRING;
	
	@Column(desc="�o�]�դH��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String SUBCON_GROUP_ID = EmptyField.STRING;
	
	@Column(desc="�ϰ�O", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String ARA_CD = EmptyField.STRING;
	
	@Column(desc="�l���ϸ�", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String ZIP_CODE = EmptyField.STRING;
	
	@Column(desc="�ϰ줤��", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String ZIP_NAME = EmptyField.STRING;
	
	@Column(desc="�a�}", type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String BLD_ADDR = EmptyField.STRING;
	
	@Column(desc="�γ~�N�X", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String BLD_USE_CD = EmptyField.STRING;
	
	@Column(desc="�@�~�ɶ�", nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp LST_PROC_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�@�~�H��", nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String LST_PROC_ID = EmptyField.STRING;
	
	@Column(desc="�@�~���", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String LST_PROC_DIV = EmptyField.STRING;
	
	@Column(desc="IFRS�����", type=java.sql.Types.DECIMAL, length=5, defaultValue="") 
	private java.math.BigDecimal IFRS_INV_RT = EmptyField.BIGDECIMAL;
	
	/**
	 * Default constructor
	 */
	public DTEPF170(){
		// do nothing	
	}
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �j�ӦW��
	 * @return �j�ӦW��
	 */
	public String getBLD_NAME() {
		if(EmptyField.isEmpty(BLD_NAME)){
			return null;
		}
		return BLD_NAME;
	}

	/**
	 * set value of �j�ӦW��
	 * @param newBLD_NAME - �j�ӦW��
	 */
	public void setBLD_NAME(String newBLD_NAME){
		BLD_NAME = newBLD_NAME;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �j�Ӳ{���޲z(�ӽ�)���
	 * @return �j�Ӳ{���޲z(�ӽ�)���
	 */
	public String getREQ_DIV() {
		if(EmptyField.isEmpty(REQ_DIV)){
			return null;
		}
		return REQ_DIV;
	}

	/**
	 * set value of �j�Ӳ{���޲z(�ӽ�)���
	 * @param newREQ_DIV - �j�Ӳ{���޲z(�ӽ�)���
	 */
	public void setREQ_DIV(String newREQ_DIV){
		REQ_DIV = newREQ_DIV;
	}	
	
	/**
	 * get value of �j�Ӳ{���޲z(�ӽ�)���W��
	 * @return �j�Ӳ{���޲z(�ӽ�)���W��
	 */
	public String getREQ_NM() {
		if(EmptyField.isEmpty(REQ_NM)){
			return null;
		}
		return REQ_NM;
	}

	/**
	 * set value of �j�Ӳ{���޲z(�ӽ�)���W��
	 * @param newREQ_NM - �j�Ӳ{���޲z(�ӽ�)���W��
	 */
	public void setREQ_NM(String newREQ_NM){
		REQ_NM = newREQ_NM;
	}	
	
	/**
	 * get value of �j�Ӳ{���޲z(�ӽ�)�H��
	 * @return �j�Ӳ{���޲z(�ӽ�)�H��
	 */
	public String getREQ_ID() {
		if(EmptyField.isEmpty(REQ_ID)){
			return null;
		}
		return REQ_ID;
	}

	/**
	 * set value of �j�Ӳ{���޲z(�ӽ�)�H��
	 * @param newREQ_ID - �j�Ӳ{���޲z(�ӽ�)�H��
	 */
	public void setREQ_ID(String newREQ_ID){
		REQ_ID = newREQ_ID;
	}	
	
	/**
	 * get value of ��µ��H��
	 * @return ��µ��H��
	 */
	public String getFIX_DIV_ID() {
		if(EmptyField.isEmpty(FIX_DIV_ID)){
			return null;
		}
		return FIX_DIV_ID;
	}

	/**
	 * set value of ��µ��H��
	 * @param newFIX_DIV_ID - ��µ��H��
	 */
	public void setFIX_DIV_ID(String newFIX_DIV_ID){
		FIX_DIV_ID = newFIX_DIV_ID;
	}	
	
	/**
	 * get value of ��µ�դH��
	 * @return ��µ�դH��
	 */
	public String getFIX_GROUP_ID() {
		if(EmptyField.isEmpty(FIX_GROUP_ID)){
			return null;
		}
		return FIX_GROUP_ID;
	}

	/**
	 * set value of ��µ�դH��
	 * @param newFIX_GROUP_ID - ��µ�դH��
	 */
	public void setFIX_GROUP_ID(String newFIX_GROUP_ID){
		FIX_GROUP_ID = newFIX_GROUP_ID;
	}	
	
	/**
	 * get value of �o�]�դH��
	 * @return �o�]�դH��
	 */
	public String getSUBCON_GROUP_ID() {
		if(EmptyField.isEmpty(SUBCON_GROUP_ID)){
			return null;
		}
		return SUBCON_GROUP_ID;
	}

	/**
	 * set value of �o�]�դH��
	 * @param newSUBCON_GROUP_ID - �o�]�դH��
	 */
	public void setSUBCON_GROUP_ID(String newSUBCON_GROUP_ID){
		SUBCON_GROUP_ID = newSUBCON_GROUP_ID;
	}	
	
	/**
	 * get value of �ϰ�O
	 * @return �ϰ�O
	 */
	public String getARA_CD() {
		if(EmptyField.isEmpty(ARA_CD)){
			return null;
		}
		return ARA_CD;
	}

	/**
	 * set value of �ϰ�O
	 * @param newARA_CD - �ϰ�O
	 */
	public void setARA_CD(String newARA_CD){
		ARA_CD = newARA_CD;
	}	
	
	/**
	 * get value of �l���ϸ�
	 * @return �l���ϸ�
	 */
	public String getZIP_CODE() {
		if(EmptyField.isEmpty(ZIP_CODE)){
			return null;
		}
		return ZIP_CODE;
	}

	/**
	 * set value of �l���ϸ�
	 * @param newZIP_CODE - �l���ϸ�
	 */
	public void setZIP_CODE(String newZIP_CODE){
		ZIP_CODE = newZIP_CODE;
	}	
	
	/**
	 * get value of �ϰ줤��
	 * @return �ϰ줤��
	 */
	public String getZIP_NAME() {
		if(EmptyField.isEmpty(ZIP_NAME)){
			return null;
		}
		return ZIP_NAME;
	}

	/**
	 * set value of �ϰ줤��
	 * @param newZIP_NAME - �ϰ줤��
	 */
	public void setZIP_NAME(String newZIP_NAME){
		ZIP_NAME = newZIP_NAME;
	}	
	
	/**
	 * get value of �a�}
	 * @return �a�}
	 */
	public String getBLD_ADDR() {
		if(EmptyField.isEmpty(BLD_ADDR)){
			return null;
		}
		return BLD_ADDR;
	}

	/**
	 * set value of �a�}
	 * @param newBLD_ADDR - �a�}
	 */
	public void setBLD_ADDR(String newBLD_ADDR){
		BLD_ADDR = newBLD_ADDR;
	}	
	
	/**
	 * get value of �γ~�N�X
	 * @return �γ~�N�X
	 */
	public String getBLD_USE_CD() {
		if(EmptyField.isEmpty(BLD_USE_CD)){
			return null;
		}
		return BLD_USE_CD;
	}

	/**
	 * set value of �γ~�N�X
	 * @param newBLD_USE_CD - �γ~�N�X
	 */
	public void setBLD_USE_CD(String newBLD_USE_CD){
		BLD_USE_CD = newBLD_USE_CD;
	}	
	
	/**
	 * get value of �@�~�ɶ�
	 * @return �@�~�ɶ�
	 */
	public java.sql.Timestamp getLST_PROC_DATE() {
		if(EmptyField.isEmpty(LST_PROC_DATE)){
			return null;
		}
		return LST_PROC_DATE;
	}

	/**
	 * set value of �@�~�ɶ�
	 * @param newLST_PROC_DATE - �@�~�ɶ�
	 */
	public void setLST_PROC_DATE(java.sql.Timestamp newLST_PROC_DATE){
		LST_PROC_DATE = newLST_PROC_DATE;
	}	
	
	/**
	 * get value of �@�~�H��
	 * @return �@�~�H��
	 */
	public String getLST_PROC_ID() {
		if(EmptyField.isEmpty(LST_PROC_ID)){
			return null;
		}
		return LST_PROC_ID;
	}

	/**
	 * set value of �@�~�H��
	 * @param newLST_PROC_ID - �@�~�H��
	 */
	public void setLST_PROC_ID(String newLST_PROC_ID){
		LST_PROC_ID = newLST_PROC_ID;
	}	
	
	/**
	 * get value of �@�~���
	 * @return �@�~���
	 */
	public String getLST_PROC_DIV() {
		if(EmptyField.isEmpty(LST_PROC_DIV)){
			return null;
		}
		return LST_PROC_DIV;
	}

	/**
	 * set value of �@�~���
	 * @param newLST_PROC_DIV - �@�~���
	 */
	public void setLST_PROC_DIV(String newLST_PROC_DIV){
		LST_PROC_DIV = newLST_PROC_DIV;
	}	
	
	/**
	 * get value of IFRS�����
	 * @return IFRS�����
	 */
	public java.math.BigDecimal getIFRS_INV_RT() {
		if(EmptyField.isEmpty(IFRS_INV_RT)){
			return null;
		}
		return IFRS_INV_RT;
	}

	/**
	 * set value of IFRS�����
	 * @param newIFRS_INV_RT - IFRS�����
	 */
	public void setIFRS_INV_RT(java.math.BigDecimal newIFRS_INV_RT){
		IFRS_INV_RT = newIFRS_INV_RT;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(BLD_CD);
		hcBuilder.append(BLD_NAME);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(REQ_DIV);
		hcBuilder.append(REQ_NM);
		hcBuilder.append(REQ_ID);
		hcBuilder.append(FIX_DIV_ID);
		hcBuilder.append(FIX_GROUP_ID);
		hcBuilder.append(SUBCON_GROUP_ID);
		hcBuilder.append(ARA_CD);
		hcBuilder.append(ZIP_CODE);
		hcBuilder.append(ZIP_NAME);
		hcBuilder.append(BLD_ADDR);
		hcBuilder.append(BLD_USE_CD);
		hcBuilder.append(LST_PROC_DATE);
		hcBuilder.append(LST_PROC_ID);
		hcBuilder.append(LST_PROC_DIV);
		hcBuilder.append(IFRS_INV_RT);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF170)){
			return false;
		}
        
		DTEPF170 theObj = (DTEPF170)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				