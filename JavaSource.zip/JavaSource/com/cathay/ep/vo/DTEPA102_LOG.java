package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPA102_LOG
 * <pre>
 * Generated value object of DBEP.DTEPA102_LOG (�j��_�Ӽh�O����)
 * </pre>
 */
public class DTEPA102_LOG implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPA102_LOG";
	
	
	@Column(desc="�J�ɤ���ɶ�", pk=true, nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp UPD_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�Ӽh�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String FLD_NO = EmptyField.STRING;
	
	@Column(desc="�Ӽh�`���n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal FLD_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="���]��", type=java.sql.Types.DECIMAL, length=5, defaultValue="") 
	private java.math.BigDecimal PBL_RATE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�C��쩳��", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal AVG_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�C������", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal CLR_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�n�O�γ~", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String FLD_TYPE = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	@Column(desc="�J�ɮץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String UPD_APLY_NO = EmptyField.STRING;
	
	@Column(desc="�J�ɥ������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String UPD_TRN_KIND = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPA102_LOG(){
		// do nothing	
	}
	
	/**
	 * get value of �J�ɤ���ɶ�
	 * @return �J�ɤ���ɶ�
	 */
	public java.sql.Timestamp getUPD_DATE() {
		if(EmptyField.isEmpty(UPD_DATE)){
			return null;
		}
		return UPD_DATE;
	}

	/**
	 * set value of �J�ɤ���ɶ�
	 * @param newUPD_DATE - �J�ɤ���ɶ�
	 */
	public void setUPD_DATE(java.sql.Timestamp newUPD_DATE){
		UPD_DATE = newUPD_DATE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �Ӽh�O
	 * @return �Ӽh�O
	 */
	public String getFLD_NO() {
		if(EmptyField.isEmpty(FLD_NO)){
			return null;
		}
		return FLD_NO;
	}

	/**
	 * set value of �Ӽh�O
	 * @param newFLD_NO - �Ӽh�O
	 */
	public void setFLD_NO(String newFLD_NO){
		FLD_NO = newFLD_NO;
	}	
	
	/**
	 * get value of �Ӽh�`���n
	 * @return �Ӽh�`���n
	 */
	public java.math.BigDecimal getFLD_SIZE() {
		if(EmptyField.isEmpty(FLD_SIZE)){
			return null;
		}
		return FLD_SIZE;
	}

	/**
	 * set value of �Ӽh�`���n
	 * @param newFLD_SIZE - �Ӽh�`���n
	 */
	public void setFLD_SIZE(java.math.BigDecimal newFLD_SIZE){
		FLD_SIZE = newFLD_SIZE;
	}	
	
	/**
	 * get value of ���]��
	 * @return ���]��
	 */
	public java.math.BigDecimal getPBL_RATE() {
		if(EmptyField.isEmpty(PBL_RATE)){
			return null;
		}
		return PBL_RATE;
	}

	/**
	 * set value of ���]��
	 * @param newPBL_RATE - ���]��
	 */
	public void setPBL_RATE(java.math.BigDecimal newPBL_RATE){
		PBL_RATE = newPBL_RATE;
	}	
	
	/**
	 * get value of �C��쩳��
	 * @return �C��쩳��
	 */
	public java.math.BigDecimal getAVG_AMT() {
		if(EmptyField.isEmpty(AVG_AMT)){
			return null;
		}
		return AVG_AMT;
	}

	/**
	 * set value of �C��쩳��
	 * @param newAVG_AMT - �C��쩳��
	 */
	public void setAVG_AMT(java.math.BigDecimal newAVG_AMT){
		AVG_AMT = newAVG_AMT;
	}	
	
	/**
	 * get value of �C������
	 * @return �C������
	 */
	public java.math.BigDecimal getCLR_AMT() {
		if(EmptyField.isEmpty(CLR_AMT)){
			return null;
		}
		return CLR_AMT;
	}

	/**
	 * set value of �C������
	 * @param newCLR_AMT - �C������
	 */
	public void setCLR_AMT(java.math.BigDecimal newCLR_AMT){
		CLR_AMT = newCLR_AMT;
	}	
	
	/**
	 * get value of �n�O�γ~
	 * @return �n�O�γ~
	 */
	public String getFLD_TYPE() {
		if(EmptyField.isEmpty(FLD_TYPE)){
			return null;
		}
		return FLD_TYPE;
	}

	/**
	 * set value of �n�O�γ~
	 * @param newFLD_TYPE - �n�O�γ~
	 */
	public void setFLD_TYPE(String newFLD_TYPE){
		FLD_TYPE = newFLD_TYPE;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * get value of �J�ɮץ�s��
	 * @return �J�ɮץ�s��
	 */
	public String getUPD_APLY_NO() {
		if(EmptyField.isEmpty(UPD_APLY_NO)){
			return null;
		}
		return UPD_APLY_NO;
	}

	/**
	 * set value of �J�ɮץ�s��
	 * @param newUPD_APLY_NO - �J�ɮץ�s��
	 */
	public void setUPD_APLY_NO(String newUPD_APLY_NO){
		UPD_APLY_NO = newUPD_APLY_NO;
	}	
	
	/**
	 * get value of �J�ɥ������
	 * @return �J�ɥ������
	 */
	public String getUPD_TRN_KIND() {
		if(EmptyField.isEmpty(UPD_TRN_KIND)){
			return null;
		}
		return UPD_TRN_KIND;
	}

	/**
	 * set value of �J�ɥ������
	 * @param newUPD_TRN_KIND - �J�ɥ������
	 */
	public void setUPD_TRN_KIND(String newUPD_TRN_KIND){
		UPD_TRN_KIND = newUPD_TRN_KIND;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(UPD_DATE);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(FLD_NO);
		hcBuilder.append(FLD_SIZE);
		hcBuilder.append(PBL_RATE);
		hcBuilder.append(AVG_AMT);
		hcBuilder.append(CLR_AMT);
		hcBuilder.append(FLD_TYPE);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(TRN_KIND);
		hcBuilder.append(UPD_APLY_NO);
		hcBuilder.append(UPD_TRN_KIND);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPA102_LOG)){
			return false;
		}
        
		DTEPA102_LOG theObj = (DTEPA102_LOG)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				