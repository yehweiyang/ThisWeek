package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPA103
 * <pre>
 * Generated value object of DBEP.DTEPA103 (�j��_�ǧO�O����)
 * </pre>
 */
public class DTEPA103 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPA103";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�Ӽh�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String FLD_NO = EmptyField.STRING;
	
	@Column(desc="�ǧO", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=4, defaultValue="") 
	private String ROOM_NO = EmptyField.STRING;
	
	@Column(desc="�����N��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�ǧO���n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal ROOM_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�X�����n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal RNT_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�޲z�O���n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal MGT_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�b���n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal NET_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�_�����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date RNT_STR_DATE = EmptyField.DATE;
	
	@Column(desc="�������", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date RNT_END_DATE = EmptyField.DATE;
	
	@Column(desc="������", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal FNL_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ϥΪ��p����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String USE_TYPE = EmptyField.STRING;
	
	@Column(desc="�ϥγ��N��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String USE_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ϥγ��W��", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String USE_DIV_NAME = EmptyField.STRING;
	
	@Column(desc="�ϥγ��ʽ�", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String USE_KD = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	@Column(desc="�Ӽh���ΦX��", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String FLD_ADJ = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPA103(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �Ӽh�O
	 * @return �Ӽh�O
	 */
	public String getFLD_NO() {
		if(EmptyField.isEmpty(FLD_NO)){
			return null;
		}
		return FLD_NO;
	}

	/**
	 * set value of �Ӽh�O
	 * @param newFLD_NO - �Ӽh�O
	 */
	public void setFLD_NO(String newFLD_NO){
		FLD_NO = newFLD_NO;
	}	
	
	/**
	 * get value of �ǧO
	 * @return �ǧO
	 */
	public String getROOM_NO() {
		if(EmptyField.isEmpty(ROOM_NO)){
			return null;
		}
		return ROOM_NO;
	}

	/**
	 * set value of �ǧO
	 * @param newROOM_NO - �ǧO
	 */
	public void setROOM_NO(String newROOM_NO){
		ROOM_NO = newROOM_NO;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �ǧO���n
	 * @return �ǧO���n
	 */
	public java.math.BigDecimal getROOM_SIZE() {
		if(EmptyField.isEmpty(ROOM_SIZE)){
			return null;
		}
		return ROOM_SIZE;
	}

	/**
	 * set value of �ǧO���n
	 * @param newROOM_SIZE - �ǧO���n
	 */
	public void setROOM_SIZE(java.math.BigDecimal newROOM_SIZE){
		ROOM_SIZE = newROOM_SIZE;
	}	
	
	/**
	 * get value of �X�����n
	 * @return �X�����n
	 */
	public java.math.BigDecimal getRNT_SIZE() {
		if(EmptyField.isEmpty(RNT_SIZE)){
			return null;
		}
		return RNT_SIZE;
	}

	/**
	 * set value of �X�����n
	 * @param newRNT_SIZE - �X�����n
	 */
	public void setRNT_SIZE(java.math.BigDecimal newRNT_SIZE){
		RNT_SIZE = newRNT_SIZE;
	}	
	
	/**
	 * get value of �޲z�O���n
	 * @return �޲z�O���n
	 */
	public java.math.BigDecimal getMGT_SIZE() {
		if(EmptyField.isEmpty(MGT_SIZE)){
			return null;
		}
		return MGT_SIZE;
	}

	/**
	 * set value of �޲z�O���n
	 * @param newMGT_SIZE - �޲z�O���n
	 */
	public void setMGT_SIZE(java.math.BigDecimal newMGT_SIZE){
		MGT_SIZE = newMGT_SIZE;
	}	
	
	/**
	 * get value of �b���n
	 * @return �b���n
	 */
	public java.math.BigDecimal getNET_SIZE() {
		if(EmptyField.isEmpty(NET_SIZE)){
			return null;
		}
		return NET_SIZE;
	}

	/**
	 * set value of �b���n
	 * @param newNET_SIZE - �b���n
	 */
	public void setNET_SIZE(java.math.BigDecimal newNET_SIZE){
		NET_SIZE = newNET_SIZE;
	}	
	
	/**
	 * get value of �_�����
	 * @return �_�����
	 */
	public java.sql.Date getRNT_STR_DATE() {
		if(EmptyField.isEmpty(RNT_STR_DATE)){
			return null;
		}
		return RNT_STR_DATE;
	}

	/**
	 * set value of �_�����
	 * @param newRNT_STR_DATE - �_�����
	 */
	public void setRNT_STR_DATE(java.sql.Date newRNT_STR_DATE){
		RNT_STR_DATE = newRNT_STR_DATE;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public java.sql.Date getRNT_END_DATE() {
		if(EmptyField.isEmpty(RNT_END_DATE)){
			return null;
		}
		return RNT_END_DATE;
	}

	/**
	 * set value of �������
	 * @param newRNT_END_DATE - �������
	 */
	public void setRNT_END_DATE(java.sql.Date newRNT_END_DATE){
		RNT_END_DATE = newRNT_END_DATE;
	}	
	
	/**
	 * get value of ������
	 * @return ������
	 */
	public java.math.BigDecimal getFNL_AMT() {
		if(EmptyField.isEmpty(FNL_AMT)){
			return null;
		}
		return FNL_AMT;
	}

	/**
	 * set value of ������
	 * @param newFNL_AMT - ������
	 */
	public void setFNL_AMT(java.math.BigDecimal newFNL_AMT){
		FNL_AMT = newFNL_AMT;
	}	
	
	/**
	 * get value of �ϥΪ��p����
	 * @return �ϥΪ��p����
	 */
	public String getUSE_TYPE() {
		if(EmptyField.isEmpty(USE_TYPE)){
			return null;
		}
		return USE_TYPE;
	}

	/**
	 * set value of �ϥΪ��p����
	 * @param newUSE_TYPE - �ϥΪ��p����
	 */
	public void setUSE_TYPE(String newUSE_TYPE){
		USE_TYPE = newUSE_TYPE;
	}	
	
	/**
	 * get value of �ϥγ��N��
	 * @return �ϥγ��N��
	 */
	public String getUSE_DIV_NO() {
		if(EmptyField.isEmpty(USE_DIV_NO)){
			return null;
		}
		return USE_DIV_NO;
	}

	/**
	 * set value of �ϥγ��N��
	 * @param newUSE_DIV_NO - �ϥγ��N��
	 */
	public void setUSE_DIV_NO(String newUSE_DIV_NO){
		USE_DIV_NO = newUSE_DIV_NO;
	}	
	
	/**
	 * get value of �ϥγ��W��
	 * @return �ϥγ��W��
	 */
	public String getUSE_DIV_NAME() {
		if(EmptyField.isEmpty(USE_DIV_NAME)){
			return null;
		}
		return USE_DIV_NAME;
	}

	/**
	 * set value of �ϥγ��W��
	 * @param newUSE_DIV_NAME - �ϥγ��W��
	 */
	public void setUSE_DIV_NAME(String newUSE_DIV_NAME){
		USE_DIV_NAME = newUSE_DIV_NAME;
	}	
	
	/**
	 * get value of �ϥγ��ʽ�
	 * @return �ϥγ��ʽ�
	 */
	public String getUSE_KD() {
		if(EmptyField.isEmpty(USE_KD)){
			return null;
		}
		return USE_KD;
	}

	/**
	 * set value of �ϥγ��ʽ�
	 * @param newUSE_KD - �ϥγ��ʽ�
	 */
	public void setUSE_KD(String newUSE_KD){
		USE_KD = newUSE_KD;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * get value of �Ӽh���ΦX��
	 * @return �Ӽh���ΦX��
	 */
	public String getFLD_ADJ() {
		if(EmptyField.isEmpty(FLD_ADJ)){
			return null;
		}
		return FLD_ADJ;
	}

	/**
	 * set value of �Ӽh���ΦX��
	 * @param newFLD_ADJ - �Ӽh���ΦX��
	 */
	public void setFLD_ADJ(String newFLD_ADJ){
		FLD_ADJ = newFLD_ADJ;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(FLD_NO);
		hcBuilder.append(ROOM_NO);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(ROOM_SIZE);
		hcBuilder.append(RNT_SIZE);
		hcBuilder.append(MGT_SIZE);
		hcBuilder.append(NET_SIZE);
		hcBuilder.append(RNT_STR_DATE);
		hcBuilder.append(RNT_END_DATE);
		hcBuilder.append(FNL_AMT);
		hcBuilder.append(USE_TYPE);
		hcBuilder.append(USE_DIV_NO);
		hcBuilder.append(USE_DIV_NAME);
		hcBuilder.append(USE_KD);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(TRN_KIND);
		hcBuilder.append(FLD_ADJ);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPA103)){
			return false;
		}
        
		DTEPA103 theObj = (DTEPA103)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				