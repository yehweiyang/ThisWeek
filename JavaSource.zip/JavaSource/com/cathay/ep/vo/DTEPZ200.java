package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPZ200
 * <pre>
 * Generated value object of DBEP.DTEPZ200 (�ɮײ��ͳ]�w��)
 * </pre>
 */
public class DTEPZ200 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPZ200";
	
	
	@Column(desc="�ƥ�N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String EVENT_ID = EmptyField.STRING;
	
	@Column(desc="����Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer FILE_SEQ = EmptyField.INTEGER;
	
	@Column(desc="���N�X", nullAble=false, type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FELD_NO = EmptyField.STRING;
	
	@Column(desc="��Ƥ����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�O�_���ͪ��Y", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String HEAD = EmptyField.STRING;
	
	@Column(desc="��Ƴ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String DIV_NO = EmptyField.STRING;
	
	@Column(desc="���|��m", type=java.sql.Types.VARCHAR, length=75, defaultValue="") 
	private String FILE_DIR = EmptyField.STRING;
	
	@Column(desc="�����ɦW", type=java.sql.Types.VARCHAR, length=75, defaultValue="") 
	private String FILE_NAME = EmptyField.STRING;
	
	@Column(desc="��ƳB�z�Ҳ�", type=java.sql.Types.VARCHAR, length=15, defaultValue="") 
	private String MOD_ID = EmptyField.STRING;
	
	@Column(desc="��ƳB�z��k", type=java.sql.Types.VARCHAR, length=50, defaultValue="") 
	private String MTD_ID = EmptyField.STRING;
	
	@Column(desc="�B�z�覡", type=java.sql.Types.CHAR, length=1, defaultValue="") 
	private String PCS_TP = EmptyField.STRING;
	
	@Column(desc="�]�w�ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp UPD_DT = EmptyField.TIMESTAMP;
	
	/**
	 * Default constructor
	 */
	public DTEPZ200(){
		// do nothing	
	}
	
	/**
	 * get value of �ƥ�N��
	 * @return �ƥ�N��
	 */
	public String getEVENT_ID() {
		if(EmptyField.isEmpty(EVENT_ID)){
			return null;
		}
		return EVENT_ID;
	}

	/**
	 * set value of �ƥ�N��
	 * @param newEVENT_ID - �ƥ�N��
	 */
	public void setEVENT_ID(String newEVENT_ID){
		EVENT_ID = newEVENT_ID;
	}	
	
	/**
	 * get value of ����Ǹ�
	 * @return ����Ǹ�
	 */
	public Integer getFILE_SEQ() {
		if(EmptyField.isEmpty(FILE_SEQ)){
			return null;
		}
		return FILE_SEQ;
	}

	/**
	 * set value of ����Ǹ�
	 * @param newFILE_SEQ - ����Ǹ�
	 */
	public void setFILE_SEQ(Integer newFILE_SEQ){
		FILE_SEQ = newFILE_SEQ;
	}	
	
	/**
	 * get value of ���N�X
	 * @return ���N�X
	 */
	public String getFELD_NO() {
		if(EmptyField.isEmpty(FELD_NO)){
			return null;
		}
		return FELD_NO;
	}

	/**
	 * set value of ���N�X
	 * @param newFELD_NO - ���N�X
	 */
	public void setFELD_NO(String newFELD_NO){
		FELD_NO = newFELD_NO;
	}	
	
	/**
	 * get value of ��Ƥ����q�O
	 * @return ��Ƥ����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of ��Ƥ����q�O
	 * @param newSUB_CPY_ID - ��Ƥ����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �O�_���ͪ��Y
	 * @return �O�_���ͪ��Y
	 */
	public String getHEAD() {
		if(EmptyField.isEmpty(HEAD)){
			return null;
		}
		return HEAD;
	}

	/**
	 * set value of �O�_���ͪ��Y
	 * @param newHEAD - �O�_���ͪ��Y
	 */
	public void setHEAD(String newHEAD){
		HEAD = newHEAD;
	}	
	
	/**
	 * get value of ��Ƴ��
	 * @return ��Ƴ��
	 */
	public String getDIV_NO() {
		if(EmptyField.isEmpty(DIV_NO)){
			return null;
		}
		return DIV_NO;
	}

	/**
	 * set value of ��Ƴ��
	 * @param newDIV_NO - ��Ƴ��
	 */
	public void setDIV_NO(String newDIV_NO){
		DIV_NO = newDIV_NO;
	}	
	
	/**
	 * get value of ���|��m
	 * @return ���|��m
	 */
	public String getFILE_DIR() {
		if(EmptyField.isEmpty(FILE_DIR)){
			return null;
		}
		return FILE_DIR;
	}

	/**
	 * set value of ���|��m
	 * @param newFILE_DIR - ���|��m
	 */
	public void setFILE_DIR(String newFILE_DIR){
		FILE_DIR = newFILE_DIR;
	}	
	
	/**
	 * get value of �����ɦW
	 * @return �����ɦW
	 */
	public String getFILE_NAME() {
		if(EmptyField.isEmpty(FILE_NAME)){
			return null;
		}
		return FILE_NAME;
	}

	/**
	 * set value of �����ɦW
	 * @param newFILE_NAME - �����ɦW
	 */
	public void setFILE_NAME(String newFILE_NAME){
		FILE_NAME = newFILE_NAME;
	}	
	
	/**
	 * get value of ��ƳB�z�Ҳ�
	 * @return ��ƳB�z�Ҳ�
	 */
	public String getMOD_ID() {
		if(EmptyField.isEmpty(MOD_ID)){
			return null;
		}
		return MOD_ID;
	}

	/**
	 * set value of ��ƳB�z�Ҳ�
	 * @param newMOD_ID - ��ƳB�z�Ҳ�
	 */
	public void setMOD_ID(String newMOD_ID){
		MOD_ID = newMOD_ID;
	}	
	
	/**
	 * get value of ��ƳB�z��k
	 * @return ��ƳB�z��k
	 */
	public String getMTD_ID() {
		if(EmptyField.isEmpty(MTD_ID)){
			return null;
		}
		return MTD_ID;
	}

	/**
	 * set value of ��ƳB�z��k
	 * @param newMTD_ID - ��ƳB�z��k
	 */
	public void setMTD_ID(String newMTD_ID){
		MTD_ID = newMTD_ID;
	}	
	
	/**
	 * get value of �B�z�覡
	 * @return �B�z�覡
	 */
	public String getPCS_TP() {
		if(EmptyField.isEmpty(PCS_TP)){
			return null;
		}
		return PCS_TP;
	}

	/**
	 * set value of �B�z�覡
	 * @param newPCS_TP - �B�z�覡
	 */
	public void setPCS_TP(String newPCS_TP){
		PCS_TP = newPCS_TP;
	}	
	
	/**
	 * get value of �]�w�ɶ�
	 * @return �]�w�ɶ�
	 */
	public java.sql.Timestamp getUPD_DT() {
		if(EmptyField.isEmpty(UPD_DT)){
			return null;
		}
		return UPD_DT;
	}

	/**
	 * set value of �]�w�ɶ�
	 * @param newUPD_DT - �]�w�ɶ�
	 */
	public void setUPD_DT(java.sql.Timestamp newUPD_DT){
		UPD_DT = newUPD_DT;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(EVENT_ID);
		hcBuilder.append(FILE_SEQ);
		hcBuilder.append(FELD_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(HEAD);
		hcBuilder.append(DIV_NO);
		hcBuilder.append(FILE_DIR);
		hcBuilder.append(FILE_NAME);
		hcBuilder.append(MOD_ID);
		hcBuilder.append(MTD_ID);
		hcBuilder.append(PCS_TP);
		hcBuilder.append(UPD_DT);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPZ200)){
			return false;
		}
        
		DTEPZ200 theObj = (DTEPZ200)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				