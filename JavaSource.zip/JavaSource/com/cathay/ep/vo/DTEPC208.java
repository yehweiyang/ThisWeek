package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC208
 * <pre>
 * Generated value object of DBEP.DTEPC208 ()
 * </pre>
 */
public class DTEPC208 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC208";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�����N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�����~��", pk=true, nullAble=false, type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal RCV_YM = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ꦬ���", pk=true, nullAble=false, type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date PAY_YYYYMM = EmptyField.DATE;
	
	@Column(desc="�o�����X", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INV_NO = EmptyField.STRING;
	
	@Column(desc="�ˮ֥N�X", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String CHK_TYPE = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPC208(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �����~��
	 * @return �����~��
	 */
	public java.math.BigDecimal getRCV_YM() {
		if(EmptyField.isEmpty(RCV_YM)){
			return null;
		}
		return RCV_YM;
	}

	/**
	 * set value of �����~��
	 * @param newRCV_YM - �����~��
	 */
	public void setRCV_YM(java.math.BigDecimal newRCV_YM){
		RCV_YM = newRCV_YM;
	}	
	
	/**
	 * get value of �ꦬ���
	 * @return �ꦬ���
	 */
	public java.sql.Date getPAY_YYYYMM() {
		if(EmptyField.isEmpty(PAY_YYYYMM)){
			return null;
		}
		return PAY_YYYYMM;
	}

	/**
	 * set value of �ꦬ���
	 * @param newPAY_YYYYMM - �ꦬ���
	 */
	public void setPAY_YYYYMM(java.sql.Date newPAY_YYYYMM){
		PAY_YYYYMM = newPAY_YYYYMM;
	}	
	
	/**
	 * get value of �o�����X
	 * @return �o�����X
	 */
	public String getINV_NO() {
		if(EmptyField.isEmpty(INV_NO)){
			return null;
		}
		return INV_NO;
	}

	/**
	 * set value of �o�����X
	 * @param newINV_NO - �o�����X
	 */
	public void setINV_NO(String newINV_NO){
		INV_NO = newINV_NO;
	}	
	
	/**
	 * get value of �ˮ֥N�X
	 * @return �ˮ֥N�X
	 */
	public String getCHK_TYPE() {
		if(EmptyField.isEmpty(CHK_TYPE)){
			return null;
		}
		return CHK_TYPE;
	}

	/**
	 * set value of �ˮ֥N�X
	 * @param newCHK_TYPE - �ˮ֥N�X
	 */
	public void setCHK_TYPE(String newCHK_TYPE){
		CHK_TYPE = newCHK_TYPE;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(RCV_YM);
		hcBuilder.append(PAY_YYYYMM);
		hcBuilder.append(INV_NO);
		hcBuilder.append(CHK_TYPE);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC208)){
			return false;
		}
        
		DTEPC208 theObj = (DTEPC208)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				