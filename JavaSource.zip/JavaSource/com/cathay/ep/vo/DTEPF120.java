package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF120
 * <pre>
 * Generated value object of DBEP.DTEPF120 (��µ�ץ�_�Ƨѿ���)
 * </pre>
 */
public class DTEPF120 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF120";
	
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�Ƨѿ��渹", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer MEMO_NO = EmptyField.INTEGER;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="��ޥ�", nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String IS_BM = EmptyField.STRING;
	
	@Column(desc="�Ƨѿ�����", nullAble=false, type=java.sql.Types.VARCHAR, length=390, defaultValue="") 
	private String MEMO_MO = EmptyField.STRING;
	
	@Column(desc="�Ƨѿ����B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal MEMO_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�e�֪��ɮ�", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String PPL_FILE_NO = EmptyField.STRING;
	
	@Column(desc="�Ƨѿ��ɮ�", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String MEMO_FILE_NO = EmptyField.STRING;
	
	@Column(desc="�T�{�u�k����", type=java.sql.Types.VARCHAR, length=390, defaultValue="") 
	private String CFM_WORK_MO = EmptyField.STRING;
	
	@Column(desc="�o�]�դH��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String SUBCON_GROUP_ID = EmptyField.STRING;
	
	@Column(desc="�f��y�{�s��", nullAble=false, type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FLOW_NO = EmptyField.STRING;
	
	@Column(desc="�@�~�i��", nullAble=false, type=java.sql.Types.CHAR, length=3, defaultValue="") 
	private String OP_STATUS = EmptyField.STRING;
	
	@Column(desc="�@�~�ɶ�", nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp LST_PROC_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�@�~�H��", nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String LST_PROC_ID = EmptyField.STRING;
	
	@Column(desc="�@�~���", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String LST_PROC_DIV = EmptyField.STRING;
	
	@Column(desc="�D��ñ�֤��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date DIV_CFM_DATE = EmptyField.DATE;
	
	@Column(desc="�q���I�u���", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date INFM_CONS_DATE = EmptyField.DATE;
	
	@Column(desc="����I�u�q�����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date PRE_CONS_DATE = EmptyField.DATE;
	
	@Column(desc="�o�]�դH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String SUBCON_GROUP_NM = EmptyField.STRING;
	
	@Column(desc="�@�~�H��", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String LST_PROC_NM = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPF120(){
		// do nothing	
	}
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �Ƨѿ��渹
	 * @return �Ƨѿ��渹
	 */
	public Integer getMEMO_NO() {
		if(EmptyField.isEmpty(MEMO_NO)){
			return null;
		}
		return MEMO_NO;
	}

	/**
	 * set value of �Ƨѿ��渹
	 * @param newMEMO_NO - �Ƨѿ��渹
	 */
	public void setMEMO_NO(Integer newMEMO_NO){
		MEMO_NO = newMEMO_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ��ޥ�
	 * @return ��ޥ�
	 */
	public String getIS_BM() {
		if(EmptyField.isEmpty(IS_BM)){
			return null;
		}
		return IS_BM;
	}

	/**
	 * set value of ��ޥ�
	 * @param newIS_BM - ��ޥ�
	 */
	public void setIS_BM(String newIS_BM){
		IS_BM = newIS_BM;
	}	
	
	/**
	 * get value of �Ƨѿ�����
	 * @return �Ƨѿ�����
	 */
	public String getMEMO_MO() {
		if(EmptyField.isEmpty(MEMO_MO)){
			return null;
		}
		return MEMO_MO;
	}

	/**
	 * set value of �Ƨѿ�����
	 * @param newMEMO_MO - �Ƨѿ�����
	 */
	public void setMEMO_MO(String newMEMO_MO){
		MEMO_MO = newMEMO_MO;
	}	
	
	/**
	 * get value of �Ƨѿ����B
	 * @return �Ƨѿ����B
	 */
	public java.math.BigDecimal getMEMO_AMT() {
		if(EmptyField.isEmpty(MEMO_AMT)){
			return null;
		}
		return MEMO_AMT;
	}

	/**
	 * set value of �Ƨѿ����B
	 * @param newMEMO_AMT - �Ƨѿ����B
	 */
	public void setMEMO_AMT(java.math.BigDecimal newMEMO_AMT){
		MEMO_AMT = newMEMO_AMT;
	}	
	
	/**
	 * get value of �e�֪��ɮ�
	 * @return �e�֪��ɮ�
	 */
	public String getPPL_FILE_NO() {
		if(EmptyField.isEmpty(PPL_FILE_NO)){
			return null;
		}
		return PPL_FILE_NO;
	}

	/**
	 * set value of �e�֪��ɮ�
	 * @param newPPL_FILE_NO - �e�֪��ɮ�
	 */
	public void setPPL_FILE_NO(String newPPL_FILE_NO){
		PPL_FILE_NO = newPPL_FILE_NO;
	}	
	
	/**
	 * get value of �Ƨѿ��ɮ�
	 * @return �Ƨѿ��ɮ�
	 */
	public String getMEMO_FILE_NO() {
		if(EmptyField.isEmpty(MEMO_FILE_NO)){
			return null;
		}
		return MEMO_FILE_NO;
	}

	/**
	 * set value of �Ƨѿ��ɮ�
	 * @param newMEMO_FILE_NO - �Ƨѿ��ɮ�
	 */
	public void setMEMO_FILE_NO(String newMEMO_FILE_NO){
		MEMO_FILE_NO = newMEMO_FILE_NO;
	}	
	
	/**
	 * get value of �T�{�u�k����
	 * @return �T�{�u�k����
	 */
	public String getCFM_WORK_MO() {
		if(EmptyField.isEmpty(CFM_WORK_MO)){
			return null;
		}
		return CFM_WORK_MO;
	}

	/**
	 * set value of �T�{�u�k����
	 * @param newCFM_WORK_MO - �T�{�u�k����
	 */
	public void setCFM_WORK_MO(String newCFM_WORK_MO){
		CFM_WORK_MO = newCFM_WORK_MO;
	}	
	
	/**
	 * get value of �o�]�դH��
	 * @return �o�]�դH��
	 */
	public String getSUBCON_GROUP_ID() {
		if(EmptyField.isEmpty(SUBCON_GROUP_ID)){
			return null;
		}
		return SUBCON_GROUP_ID;
	}

	/**
	 * set value of �o�]�դH��
	 * @param newSUBCON_GROUP_ID - �o�]�դH��
	 */
	public void setSUBCON_GROUP_ID(String newSUBCON_GROUP_ID){
		SUBCON_GROUP_ID = newSUBCON_GROUP_ID;
	}	
	
	/**
	 * get value of �f��y�{�s��
	 * @return �f��y�{�s��
	 */
	public String getFLOW_NO() {
		if(EmptyField.isEmpty(FLOW_NO)){
			return null;
		}
		return FLOW_NO;
	}

	/**
	 * set value of �f��y�{�s��
	 * @param newFLOW_NO - �f��y�{�s��
	 */
	public void setFLOW_NO(String newFLOW_NO){
		FLOW_NO = newFLOW_NO;
	}	
	
	/**
	 * get value of �@�~�i��
	 * @return �@�~�i��
	 */
	public String getOP_STATUS() {
		if(EmptyField.isEmpty(OP_STATUS)){
			return null;
		}
		return OP_STATUS;
	}

	/**
	 * set value of �@�~�i��
	 * @param newOP_STATUS - �@�~�i��
	 */
	public void setOP_STATUS(String newOP_STATUS){
		OP_STATUS = newOP_STATUS;
	}	
	
	/**
	 * get value of �@�~�ɶ�
	 * @return �@�~�ɶ�
	 */
	public java.sql.Timestamp getLST_PROC_DATE() {
		if(EmptyField.isEmpty(LST_PROC_DATE)){
			return null;
		}
		return LST_PROC_DATE;
	}

	/**
	 * set value of �@�~�ɶ�
	 * @param newLST_PROC_DATE - �@�~�ɶ�
	 */
	public void setLST_PROC_DATE(java.sql.Timestamp newLST_PROC_DATE){
		LST_PROC_DATE = newLST_PROC_DATE;
	}	
	
	/**
	 * get value of �@�~�H��
	 * @return �@�~�H��
	 */
	public String getLST_PROC_ID() {
		if(EmptyField.isEmpty(LST_PROC_ID)){
			return null;
		}
		return LST_PROC_ID;
	}

	/**
	 * set value of �@�~�H��
	 * @param newLST_PROC_ID - �@�~�H��
	 */
	public void setLST_PROC_ID(String newLST_PROC_ID){
		LST_PROC_ID = newLST_PROC_ID;
	}	
	
	/**
	 * get value of �@�~���
	 * @return �@�~���
	 */
	public String getLST_PROC_DIV() {
		if(EmptyField.isEmpty(LST_PROC_DIV)){
			return null;
		}
		return LST_PROC_DIV;
	}

	/**
	 * set value of �@�~���
	 * @param newLST_PROC_DIV - �@�~���
	 */
	public void setLST_PROC_DIV(String newLST_PROC_DIV){
		LST_PROC_DIV = newLST_PROC_DIV;
	}	
	
	/**
	 * get value of �D��ñ�֤��
	 * @return �D��ñ�֤��
	 */
	public java.sql.Date getDIV_CFM_DATE() {
		if(EmptyField.isEmpty(DIV_CFM_DATE)){
			return null;
		}
		return DIV_CFM_DATE;
	}

	/**
	 * set value of �D��ñ�֤��
	 * @param newDIV_CFM_DATE - �D��ñ�֤��
	 */
	public void setDIV_CFM_DATE(java.sql.Date newDIV_CFM_DATE){
		DIV_CFM_DATE = newDIV_CFM_DATE;
	}	
	
	/**
	 * get value of �q���I�u���
	 * @return �q���I�u���
	 */
	public java.sql.Date getINFM_CONS_DATE() {
		if(EmptyField.isEmpty(INFM_CONS_DATE)){
			return null;
		}
		return INFM_CONS_DATE;
	}

	/**
	 * set value of �q���I�u���
	 * @param newINFM_CONS_DATE - �q���I�u���
	 */
	public void setINFM_CONS_DATE(java.sql.Date newINFM_CONS_DATE){
		INFM_CONS_DATE = newINFM_CONS_DATE;
	}	
	
	/**
	 * get value of ����I�u�q�����
	 * @return ����I�u�q�����
	 */
	public java.sql.Date getPRE_CONS_DATE() {
		if(EmptyField.isEmpty(PRE_CONS_DATE)){
			return null;
		}
		return PRE_CONS_DATE;
	}

	/**
	 * set value of ����I�u�q�����
	 * @param newPRE_CONS_DATE - ����I�u�q�����
	 */
	public void setPRE_CONS_DATE(java.sql.Date newPRE_CONS_DATE){
		PRE_CONS_DATE = newPRE_CONS_DATE;
	}	
	
	/**
	 * get value of �o�]�դH���m�W
	 * @return �o�]�դH���m�W
	 */
	public String getSUBCON_GROUP_NM() {
		if(EmptyField.isEmpty(SUBCON_GROUP_NM)){
			return null;
		}
		return SUBCON_GROUP_NM;
	}

	/**
	 * set value of �o�]�դH���m�W
	 * @param newSUBCON_GROUP_NM - �o�]�դH���m�W
	 */
	public void setSUBCON_GROUP_NM(String newSUBCON_GROUP_NM){
		SUBCON_GROUP_NM = newSUBCON_GROUP_NM;
	}	
	
	/**
	 * get value of �@�~�H��
	 * @return �@�~�H��
	 */
	public String getLST_PROC_NM() {
		if(EmptyField.isEmpty(LST_PROC_NM)){
			return null;
		}
		return LST_PROC_NM;
	}

	/**
	 * set value of �@�~�H��
	 * @param newLST_PROC_NM - �@�~�H��
	 */
	public void setLST_PROC_NM(String newLST_PROC_NM){
		LST_PROC_NM = newLST_PROC_NM;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(APLY_NO);
		hcBuilder.append(MEMO_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(IS_BM);
		hcBuilder.append(MEMO_MO);
		hcBuilder.append(MEMO_AMT);
		hcBuilder.append(PPL_FILE_NO);
		hcBuilder.append(MEMO_FILE_NO);
		hcBuilder.append(CFM_WORK_MO);
		hcBuilder.append(SUBCON_GROUP_ID);
		hcBuilder.append(FLOW_NO);
		hcBuilder.append(OP_STATUS);
		hcBuilder.append(LST_PROC_DATE);
		hcBuilder.append(LST_PROC_ID);
		hcBuilder.append(LST_PROC_DIV);
		hcBuilder.append(DIV_CFM_DATE);
		hcBuilder.append(INFM_CONS_DATE);
		hcBuilder.append(PRE_CONS_DATE);
		hcBuilder.append(SUBCON_GROUP_NM);
		hcBuilder.append(LST_PROC_NM);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF120)){
			return false;
		}
        
		DTEPF120 theObj = (DTEPF120)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				