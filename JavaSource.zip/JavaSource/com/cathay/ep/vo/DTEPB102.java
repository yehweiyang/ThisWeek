package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPB102
 * <pre>
 * Generated value object of DBEP.DTEPB102 (����_�ӯ�����)
 * </pre>
 */
public class DTEPB102 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPB102";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�����N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�Ȥ�m�W", type=java.sql.Types.VARCHAR, length=60, defaultValue="") 
	private String CUS_NAME = EmptyField.STRING;
	
	@Column(desc="�ҥ󸹽X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ID = EmptyField.STRING;
	
	@Column(desc="��~�O", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String JOB_TYPE = EmptyField.STRING;
	
	@Column(desc="�ӯ��O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String RNT_TYPE = EmptyField.STRING;
	
	@Column(desc="�_�����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date RNT_STR_DATE = EmptyField.DATE;
	
	@Column(desc="�������", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date RNT_END_DATE = EmptyField.DATE;
	
	@Column(desc="�㯲�覡", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String PMS_TYPE = EmptyField.STRING;
	
	@Column(desc="�ӯ��W��", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal RNT_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�믲��", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal RNT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PMS_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�U����ú��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date NEXT_PAY_DATE = EmptyField.DATE;
	
	@Column(desc="�Ȥ᪬�p", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String CUS_STS = EmptyField.STRING;
	
	@Column(desc="���ڤ覡", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String DCT_TYPE = EmptyField.STRING;
	
	@Column(desc="���~ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String SLRY_ID = EmptyField.STRING;
	
	@Column(desc="�կ����O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ADJ_KIND = EmptyField.STRING;
	
	@Column(desc="�O�_���뵲��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String MON_BRK = EmptyField.STRING;
	
	@Column(desc="�}�먴��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date MON_BRK_EDATE = EmptyField.DATE;
	
	@Column(desc="��l����", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal ORG_RNT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���ڦ�w", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String ACPT_BANK_NO = EmptyField.STRING;
	
	@Column(desc="���ڱb��", type=java.sql.Types.VARCHAR, length=16, defaultValue="") 
	private String ACPT_ACNT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�s��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CUS_ID = EmptyField.STRING;
	
	@Column(desc="�t�d�H", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String BOSS_NAME = EmptyField.STRING;
	
	@Column(desc="���q�l���ϸ�", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String COMP_ZIP_CODE = EmptyField.STRING;
	
	@Column(desc="���q�n�O�a�}", type=java.sql.Types.VARCHAR, length=200, defaultValue="") 
	private String COMP_ADDR = EmptyField.STRING;
	
	@Column(desc="�p���H", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CONT_NAME = EmptyField.STRING;
	
	@Column(desc="�p���H���", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CONT_MOBIL_NO = EmptyField.STRING;
	
	@Column(desc="�q�ܰϽX", type=java.sql.Types.VARCHAR, length=4, defaultValue="") 
	private String TEL_AREA = EmptyField.STRING;
	
	@Column(desc="�q��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String TEL = EmptyField.STRING;
	
	@Column(desc="�q�ܤ���", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String TEL_EXT = EmptyField.STRING;
	
	@Column(desc="�q�T�a�l���ϸ�", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String CONT_ZIP_CODE = EmptyField.STRING;
	
	@Column(desc="�q�T�a�}", type=java.sql.Types.VARCHAR, length=200, defaultValue="") 
	private String CONT_ADDR = EmptyField.STRING;
	
	@Column(desc="�Ȥ�EMAIL", type=java.sql.Types.VARCHAR, length=50, defaultValue="") 
	private String CUS_EMAIL = EmptyField.STRING;
	
	@Column(desc="�ɮ׽s��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FILE_NO = EmptyField.STRING;
	
	@Column(desc="�Ƶ�", type=java.sql.Types.VARCHAR, length=200, defaultValue="") 
	private String MEMO = EmptyField.STRING;
	
	@Column(desc="�q�T���ʤH��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CONT_CHG_ID = EmptyField.STRING;
	
	@Column(desc="�q�T���ʩm�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CONT_CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�q�T���ʤ��", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CONT_CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�q�T���ʨ��s", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CONT_CHG_APLYNO = EmptyField.STRING;
	
	@Column(desc="�ӯ����ʤH��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String RNT_CHG_ID = EmptyField.STRING;
	
	@Column(desc="�ӯ����ʩm�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String RNT_CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�ӯ����ʤ��", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp RNT_CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�ӯ����ʨ��s", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String RNT_CHG_APLYNO = EmptyField.STRING;
	
	@Column(desc="�ӯ����ʺ���", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String RNT_CHG_TRNKD = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPB102(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �Ȥ�m�W
	 * @return �Ȥ�m�W
	 */
	public String getCUS_NAME() {
		if(EmptyField.isEmpty(CUS_NAME)){
			return null;
		}
		return CUS_NAME;
	}

	/**
	 * set value of �Ȥ�m�W
	 * @param newCUS_NAME - �Ȥ�m�W
	 */
	public void setCUS_NAME(String newCUS_NAME){
		CUS_NAME = newCUS_NAME;
	}	
	
	/**
	 * get value of �ҥ󸹽X
	 * @return �ҥ󸹽X
	 */
	public String getID() {
		if(EmptyField.isEmpty(ID)){
			return null;
		}
		return ID;
	}

	/**
	 * set value of �ҥ󸹽X
	 * @param newID - �ҥ󸹽X
	 */
	public void setID(String newID){
		ID = newID;
	}	
	
	/**
	 * get value of ��~�O
	 * @return ��~�O
	 */
	public String getJOB_TYPE() {
		if(EmptyField.isEmpty(JOB_TYPE)){
			return null;
		}
		return JOB_TYPE;
	}

	/**
	 * set value of ��~�O
	 * @param newJOB_TYPE - ��~�O
	 */
	public void setJOB_TYPE(String newJOB_TYPE){
		JOB_TYPE = newJOB_TYPE;
	}	
	
	/**
	 * get value of �ӯ��O
	 * @return �ӯ��O
	 */
	public String getRNT_TYPE() {
		if(EmptyField.isEmpty(RNT_TYPE)){
			return null;
		}
		return RNT_TYPE;
	}

	/**
	 * set value of �ӯ��O
	 * @param newRNT_TYPE - �ӯ��O
	 */
	public void setRNT_TYPE(String newRNT_TYPE){
		RNT_TYPE = newRNT_TYPE;
	}	
	
	/**
	 * get value of �_�����
	 * @return �_�����
	 */
	public java.sql.Date getRNT_STR_DATE() {
		if(EmptyField.isEmpty(RNT_STR_DATE)){
			return null;
		}
		return RNT_STR_DATE;
	}

	/**
	 * set value of �_�����
	 * @param newRNT_STR_DATE - �_�����
	 */
	public void setRNT_STR_DATE(java.sql.Date newRNT_STR_DATE){
		RNT_STR_DATE = newRNT_STR_DATE;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public java.sql.Date getRNT_END_DATE() {
		if(EmptyField.isEmpty(RNT_END_DATE)){
			return null;
		}
		return RNT_END_DATE;
	}

	/**
	 * set value of �������
	 * @param newRNT_END_DATE - �������
	 */
	public void setRNT_END_DATE(java.sql.Date newRNT_END_DATE){
		RNT_END_DATE = newRNT_END_DATE;
	}	
	
	/**
	 * get value of �㯲�覡
	 * @return �㯲�覡
	 */
	public String getPMS_TYPE() {
		if(EmptyField.isEmpty(PMS_TYPE)){
			return null;
		}
		return PMS_TYPE;
	}

	/**
	 * set value of �㯲�覡
	 * @param newPMS_TYPE - �㯲�覡
	 */
	public void setPMS_TYPE(String newPMS_TYPE){
		PMS_TYPE = newPMS_TYPE;
	}	
	
	/**
	 * get value of �ӯ��W��
	 * @return �ӯ��W��
	 */
	public java.math.BigDecimal getRNT_SIZE() {
		if(EmptyField.isEmpty(RNT_SIZE)){
			return null;
		}
		return RNT_SIZE;
	}

	/**
	 * set value of �ӯ��W��
	 * @param newRNT_SIZE - �ӯ��W��
	 */
	public void setRNT_SIZE(java.math.BigDecimal newRNT_SIZE){
		RNT_SIZE = newRNT_SIZE;
	}	
	
	/**
	 * get value of �믲��
	 * @return �믲��
	 */
	public java.math.BigDecimal getRNT_AMT() {
		if(EmptyField.isEmpty(RNT_AMT)){
			return null;
		}
		return RNT_AMT;
	}

	/**
	 * set value of �믲��
	 * @param newRNT_AMT - �믲��
	 */
	public void setRNT_AMT(java.math.BigDecimal newRNT_AMT){
		RNT_AMT = newRNT_AMT;
	}	
	
	/**
	 * get value of ���
	 * @return ���
	 */
	public java.math.BigDecimal getPMS_AMT() {
		if(EmptyField.isEmpty(PMS_AMT)){
			return null;
		}
		return PMS_AMT;
	}

	/**
	 * set value of ���
	 * @param newPMS_AMT - ���
	 */
	public void setPMS_AMT(java.math.BigDecimal newPMS_AMT){
		PMS_AMT = newPMS_AMT;
	}	
	
	/**
	 * get value of �U����ú��
	 * @return �U����ú��
	 */
	public java.sql.Date getNEXT_PAY_DATE() {
		if(EmptyField.isEmpty(NEXT_PAY_DATE)){
			return null;
		}
		return NEXT_PAY_DATE;
	}

	/**
	 * set value of �U����ú��
	 * @param newNEXT_PAY_DATE - �U����ú��
	 */
	public void setNEXT_PAY_DATE(java.sql.Date newNEXT_PAY_DATE){
		NEXT_PAY_DATE = newNEXT_PAY_DATE;
	}	
	
	/**
	 * get value of �Ȥ᪬�p
	 * @return �Ȥ᪬�p
	 */
	public String getCUS_STS() {
		if(EmptyField.isEmpty(CUS_STS)){
			return null;
		}
		return CUS_STS;
	}

	/**
	 * set value of �Ȥ᪬�p
	 * @param newCUS_STS - �Ȥ᪬�p
	 */
	public void setCUS_STS(String newCUS_STS){
		CUS_STS = newCUS_STS;
	}	
	
	/**
	 * get value of ���ڤ覡
	 * @return ���ڤ覡
	 */
	public String getDCT_TYPE() {
		if(EmptyField.isEmpty(DCT_TYPE)){
			return null;
		}
		return DCT_TYPE;
	}

	/**
	 * set value of ���ڤ覡
	 * @param newDCT_TYPE - ���ڤ覡
	 */
	public void setDCT_TYPE(String newDCT_TYPE){
		DCT_TYPE = newDCT_TYPE;
	}	
	
	/**
	 * get value of ���~ID
	 * @return ���~ID
	 */
	public String getSLRY_ID() {
		if(EmptyField.isEmpty(SLRY_ID)){
			return null;
		}
		return SLRY_ID;
	}

	/**
	 * set value of ���~ID
	 * @param newSLRY_ID - ���~ID
	 */
	public void setSLRY_ID(String newSLRY_ID){
		SLRY_ID = newSLRY_ID;
	}	
	
	/**
	 * get value of �կ����O
	 * @return �կ����O
	 */
	public String getADJ_KIND() {
		if(EmptyField.isEmpty(ADJ_KIND)){
			return null;
		}
		return ADJ_KIND;
	}

	/**
	 * set value of �կ����O
	 * @param newADJ_KIND - �կ����O
	 */
	public void setADJ_KIND(String newADJ_KIND){
		ADJ_KIND = newADJ_KIND;
	}	
	
	/**
	 * get value of �O�_���뵲��
	 * @return �O�_���뵲��
	 */
	public String getMON_BRK() {
		if(EmptyField.isEmpty(MON_BRK)){
			return null;
		}
		return MON_BRK;
	}

	/**
	 * set value of �O�_���뵲��
	 * @param newMON_BRK - �O�_���뵲��
	 */
	public void setMON_BRK(String newMON_BRK){
		MON_BRK = newMON_BRK;
	}	
	
	/**
	 * get value of �}�먴��
	 * @return �}�먴��
	 */
	public java.sql.Date getMON_BRK_EDATE() {
		if(EmptyField.isEmpty(MON_BRK_EDATE)){
			return null;
		}
		return MON_BRK_EDATE;
	}

	/**
	 * set value of �}�먴��
	 * @param newMON_BRK_EDATE - �}�먴��
	 */
	public void setMON_BRK_EDATE(java.sql.Date newMON_BRK_EDATE){
		MON_BRK_EDATE = newMON_BRK_EDATE;
	}	
	
	/**
	 * get value of ��l����
	 * @return ��l����
	 */
	public java.math.BigDecimal getORG_RNT_AMT() {
		if(EmptyField.isEmpty(ORG_RNT_AMT)){
			return null;
		}
		return ORG_RNT_AMT;
	}

	/**
	 * set value of ��l����
	 * @param newORG_RNT_AMT - ��l����
	 */
	public void setORG_RNT_AMT(java.math.BigDecimal newORG_RNT_AMT){
		ORG_RNT_AMT = newORG_RNT_AMT;
	}	
	
	/**
	 * get value of ���ڦ�w
	 * @return ���ڦ�w
	 */
	public String getACPT_BANK_NO() {
		if(EmptyField.isEmpty(ACPT_BANK_NO)){
			return null;
		}
		return ACPT_BANK_NO;
	}

	/**
	 * set value of ���ڦ�w
	 * @param newACPT_BANK_NO - ���ڦ�w
	 */
	public void setACPT_BANK_NO(String newACPT_BANK_NO){
		ACPT_BANK_NO = newACPT_BANK_NO;
	}	
	
	/**
	 * get value of ���ڱb��
	 * @return ���ڱb��
	 */
	public String getACPT_ACNT_NO() {
		if(EmptyField.isEmpty(ACPT_ACNT_NO)){
			return null;
		}
		return ACPT_ACNT_NO;
	}

	/**
	 * set value of ���ڱb��
	 * @param newACPT_ACNT_NO - ���ڱb��
	 */
	public void setACPT_ACNT_NO(String newACPT_ACNT_NO){
		ACPT_ACNT_NO = newACPT_ACNT_NO;
	}	
	
	/**
	 * get value of �Ȥ�s��
	 * @return �Ȥ�s��
	 */
	public String getCUS_ID() {
		if(EmptyField.isEmpty(CUS_ID)){
			return null;
		}
		return CUS_ID;
	}

	/**
	 * set value of �Ȥ�s��
	 * @param newCUS_ID - �Ȥ�s��
	 */
	public void setCUS_ID(String newCUS_ID){
		CUS_ID = newCUS_ID;
	}	
	
	/**
	 * get value of �t�d�H
	 * @return �t�d�H
	 */
	public String getBOSS_NAME() {
		if(EmptyField.isEmpty(BOSS_NAME)){
			return null;
		}
		return BOSS_NAME;
	}

	/**
	 * set value of �t�d�H
	 * @param newBOSS_NAME - �t�d�H
	 */
	public void setBOSS_NAME(String newBOSS_NAME){
		BOSS_NAME = newBOSS_NAME;
	}	
	
	/**
	 * get value of ���q�l���ϸ�
	 * @return ���q�l���ϸ�
	 */
	public String getCOMP_ZIP_CODE() {
		if(EmptyField.isEmpty(COMP_ZIP_CODE)){
			return null;
		}
		return COMP_ZIP_CODE;
	}

	/**
	 * set value of ���q�l���ϸ�
	 * @param newCOMP_ZIP_CODE - ���q�l���ϸ�
	 */
	public void setCOMP_ZIP_CODE(String newCOMP_ZIP_CODE){
		COMP_ZIP_CODE = newCOMP_ZIP_CODE;
	}	
	
	/**
	 * get value of ���q�n�O�a�}
	 * @return ���q�n�O�a�}
	 */
	public String getCOMP_ADDR() {
		if(EmptyField.isEmpty(COMP_ADDR)){
			return null;
		}
		return COMP_ADDR;
	}

	/**
	 * set value of ���q�n�O�a�}
	 * @param newCOMP_ADDR - ���q�n�O�a�}
	 */
	public void setCOMP_ADDR(String newCOMP_ADDR){
		COMP_ADDR = newCOMP_ADDR;
	}	
	
	/**
	 * get value of �p���H
	 * @return �p���H
	 */
	public String getCONT_NAME() {
		if(EmptyField.isEmpty(CONT_NAME)){
			return null;
		}
		return CONT_NAME;
	}

	/**
	 * set value of �p���H
	 * @param newCONT_NAME - �p���H
	 */
	public void setCONT_NAME(String newCONT_NAME){
		CONT_NAME = newCONT_NAME;
	}	
	
	/**
	 * get value of �p���H���
	 * @return �p���H���
	 */
	public String getCONT_MOBIL_NO() {
		if(EmptyField.isEmpty(CONT_MOBIL_NO)){
			return null;
		}
		return CONT_MOBIL_NO;
	}

	/**
	 * set value of �p���H���
	 * @param newCONT_MOBIL_NO - �p���H���
	 */
	public void setCONT_MOBIL_NO(String newCONT_MOBIL_NO){
		CONT_MOBIL_NO = newCONT_MOBIL_NO;
	}	
	
	/**
	 * get value of �q�ܰϽX
	 * @return �q�ܰϽX
	 */
	public String getTEL_AREA() {
		if(EmptyField.isEmpty(TEL_AREA)){
			return null;
		}
		return TEL_AREA;
	}

	/**
	 * set value of �q�ܰϽX
	 * @param newTEL_AREA - �q�ܰϽX
	 */
	public void setTEL_AREA(String newTEL_AREA){
		TEL_AREA = newTEL_AREA;
	}	
	
	/**
	 * get value of �q��
	 * @return �q��
	 */
	public String getTEL() {
		if(EmptyField.isEmpty(TEL)){
			return null;
		}
		return TEL;
	}

	/**
	 * set value of �q��
	 * @param newTEL - �q��
	 */
	public void setTEL(String newTEL){
		TEL = newTEL;
	}	
	
	/**
	 * get value of �q�ܤ���
	 * @return �q�ܤ���
	 */
	public String getTEL_EXT() {
		if(EmptyField.isEmpty(TEL_EXT)){
			return null;
		}
		return TEL_EXT;
	}

	/**
	 * set value of �q�ܤ���
	 * @param newTEL_EXT - �q�ܤ���
	 */
	public void setTEL_EXT(String newTEL_EXT){
		TEL_EXT = newTEL_EXT;
	}	
	
	/**
	 * get value of �q�T�a�l���ϸ�
	 * @return �q�T�a�l���ϸ�
	 */
	public String getCONT_ZIP_CODE() {
		if(EmptyField.isEmpty(CONT_ZIP_CODE)){
			return null;
		}
		return CONT_ZIP_CODE;
	}

	/**
	 * set value of �q�T�a�l���ϸ�
	 * @param newCONT_ZIP_CODE - �q�T�a�l���ϸ�
	 */
	public void setCONT_ZIP_CODE(String newCONT_ZIP_CODE){
		CONT_ZIP_CODE = newCONT_ZIP_CODE;
	}	
	
	/**
	 * get value of �q�T�a�}
	 * @return �q�T�a�}
	 */
	public String getCONT_ADDR() {
		if(EmptyField.isEmpty(CONT_ADDR)){
			return null;
		}
		return CONT_ADDR;
	}

	/**
	 * set value of �q�T�a�}
	 * @param newCONT_ADDR - �q�T�a�}
	 */
	public void setCONT_ADDR(String newCONT_ADDR){
		CONT_ADDR = newCONT_ADDR;
	}	
	
	/**
	 * get value of �Ȥ�EMAIL
	 * @return �Ȥ�EMAIL
	 */
	public String getCUS_EMAIL() {
		if(EmptyField.isEmpty(CUS_EMAIL)){
			return null;
		}
		return CUS_EMAIL;
	}

	/**
	 * set value of �Ȥ�EMAIL
	 * @param newCUS_EMAIL - �Ȥ�EMAIL
	 */
	public void setCUS_EMAIL(String newCUS_EMAIL){
		CUS_EMAIL = newCUS_EMAIL;
	}	
	
	/**
	 * get value of �ɮ׽s��
	 * @return �ɮ׽s��
	 */
	public String getFILE_NO() {
		if(EmptyField.isEmpty(FILE_NO)){
			return null;
		}
		return FILE_NO;
	}

	/**
	 * set value of �ɮ׽s��
	 * @param newFILE_NO - �ɮ׽s��
	 */
	public void setFILE_NO(String newFILE_NO){
		FILE_NO = newFILE_NO;
	}	
	
	/**
	 * get value of �Ƶ�
	 * @return �Ƶ�
	 */
	public String getMEMO() {
		if(EmptyField.isEmpty(MEMO)){
			return null;
		}
		return MEMO;
	}

	/**
	 * set value of �Ƶ�
	 * @param newMEMO - �Ƶ�
	 */
	public void setMEMO(String newMEMO){
		MEMO = newMEMO;
	}	
	
	/**
	 * get value of �q�T���ʤH��
	 * @return �q�T���ʤH��
	 */
	public String getCONT_CHG_ID() {
		if(EmptyField.isEmpty(CONT_CHG_ID)){
			return null;
		}
		return CONT_CHG_ID;
	}

	/**
	 * set value of �q�T���ʤH��
	 * @param newCONT_CHG_ID - �q�T���ʤH��
	 */
	public void setCONT_CHG_ID(String newCONT_CHG_ID){
		CONT_CHG_ID = newCONT_CHG_ID;
	}	
	
	/**
	 * get value of �q�T���ʩm�W
	 * @return �q�T���ʩm�W
	 */
	public String getCONT_CHG_NAME() {
		if(EmptyField.isEmpty(CONT_CHG_NAME)){
			return null;
		}
		return CONT_CHG_NAME;
	}

	/**
	 * set value of �q�T���ʩm�W
	 * @param newCONT_CHG_NAME - �q�T���ʩm�W
	 */
	public void setCONT_CHG_NAME(String newCONT_CHG_NAME){
		CONT_CHG_NAME = newCONT_CHG_NAME;
	}	
	
	/**
	 * get value of �q�T���ʤ��
	 * @return �q�T���ʤ��
	 */
	public java.sql.Timestamp getCONT_CHG_DATE() {
		if(EmptyField.isEmpty(CONT_CHG_DATE)){
			return null;
		}
		return CONT_CHG_DATE;
	}

	/**
	 * set value of �q�T���ʤ��
	 * @param newCONT_CHG_DATE - �q�T���ʤ��
	 */
	public void setCONT_CHG_DATE(java.sql.Timestamp newCONT_CHG_DATE){
		CONT_CHG_DATE = newCONT_CHG_DATE;
	}	
	
	/**
	 * get value of �q�T���ʨ��s
	 * @return �q�T���ʨ��s
	 */
	public String getCONT_CHG_APLYNO() {
		if(EmptyField.isEmpty(CONT_CHG_APLYNO)){
			return null;
		}
		return CONT_CHG_APLYNO;
	}

	/**
	 * set value of �q�T���ʨ��s
	 * @param newCONT_CHG_APLYNO - �q�T���ʨ��s
	 */
	public void setCONT_CHG_APLYNO(String newCONT_CHG_APLYNO){
		CONT_CHG_APLYNO = newCONT_CHG_APLYNO;
	}	
	
	/**
	 * get value of �ӯ����ʤH��
	 * @return �ӯ����ʤH��
	 */
	public String getRNT_CHG_ID() {
		if(EmptyField.isEmpty(RNT_CHG_ID)){
			return null;
		}
		return RNT_CHG_ID;
	}

	/**
	 * set value of �ӯ����ʤH��
	 * @param newRNT_CHG_ID - �ӯ����ʤH��
	 */
	public void setRNT_CHG_ID(String newRNT_CHG_ID){
		RNT_CHG_ID = newRNT_CHG_ID;
	}	
	
	/**
	 * get value of �ӯ����ʩm�W
	 * @return �ӯ����ʩm�W
	 */
	public String getRNT_CHG_NAME() {
		if(EmptyField.isEmpty(RNT_CHG_NAME)){
			return null;
		}
		return RNT_CHG_NAME;
	}

	/**
	 * set value of �ӯ����ʩm�W
	 * @param newRNT_CHG_NAME - �ӯ����ʩm�W
	 */
	public void setRNT_CHG_NAME(String newRNT_CHG_NAME){
		RNT_CHG_NAME = newRNT_CHG_NAME;
	}	
	
	/**
	 * get value of �ӯ����ʤ��
	 * @return �ӯ����ʤ��
	 */
	public java.sql.Timestamp getRNT_CHG_DATE() {
		if(EmptyField.isEmpty(RNT_CHG_DATE)){
			return null;
		}
		return RNT_CHG_DATE;
	}

	/**
	 * set value of �ӯ����ʤ��
	 * @param newRNT_CHG_DATE - �ӯ����ʤ��
	 */
	public void setRNT_CHG_DATE(java.sql.Timestamp newRNT_CHG_DATE){
		RNT_CHG_DATE = newRNT_CHG_DATE;
	}	
	
	/**
	 * get value of �ӯ����ʨ��s
	 * @return �ӯ����ʨ��s
	 */
	public String getRNT_CHG_APLYNO() {
		if(EmptyField.isEmpty(RNT_CHG_APLYNO)){
			return null;
		}
		return RNT_CHG_APLYNO;
	}

	/**
	 * set value of �ӯ����ʨ��s
	 * @param newRNT_CHG_APLYNO - �ӯ����ʨ��s
	 */
	public void setRNT_CHG_APLYNO(String newRNT_CHG_APLYNO){
		RNT_CHG_APLYNO = newRNT_CHG_APLYNO;
	}	
	
	/**
	 * get value of �ӯ����ʺ���
	 * @return �ӯ����ʺ���
	 */
	public String getRNT_CHG_TRNKD() {
		if(EmptyField.isEmpty(RNT_CHG_TRNKD)){
			return null;
		}
		return RNT_CHG_TRNKD;
	}

	/**
	 * set value of �ӯ����ʺ���
	 * @param newRNT_CHG_TRNKD - �ӯ����ʺ���
	 */
	public void setRNT_CHG_TRNKD(String newRNT_CHG_TRNKD){
		RNT_CHG_TRNKD = newRNT_CHG_TRNKD;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(CUS_NAME);
		hcBuilder.append(ID);
		hcBuilder.append(JOB_TYPE);
		hcBuilder.append(RNT_TYPE);
		hcBuilder.append(RNT_STR_DATE);
		hcBuilder.append(RNT_END_DATE);
		hcBuilder.append(PMS_TYPE);
		hcBuilder.append(RNT_SIZE);
		hcBuilder.append(RNT_AMT);
		hcBuilder.append(PMS_AMT);
		hcBuilder.append(NEXT_PAY_DATE);
		hcBuilder.append(CUS_STS);
		hcBuilder.append(DCT_TYPE);
		hcBuilder.append(SLRY_ID);
		hcBuilder.append(ADJ_KIND);
		hcBuilder.append(MON_BRK);
		hcBuilder.append(MON_BRK_EDATE);
		hcBuilder.append(ORG_RNT_AMT);
		hcBuilder.append(ACPT_BANK_NO);
		hcBuilder.append(ACPT_ACNT_NO);
		hcBuilder.append(CUS_ID);
		hcBuilder.append(BOSS_NAME);
		hcBuilder.append(COMP_ZIP_CODE);
		hcBuilder.append(COMP_ADDR);
		hcBuilder.append(CONT_NAME);
		hcBuilder.append(CONT_MOBIL_NO);
		hcBuilder.append(TEL_AREA);
		hcBuilder.append(TEL);
		hcBuilder.append(TEL_EXT);
		hcBuilder.append(CONT_ZIP_CODE);
		hcBuilder.append(CONT_ADDR);
		hcBuilder.append(CUS_EMAIL);
		hcBuilder.append(FILE_NO);
		hcBuilder.append(MEMO);
		hcBuilder.append(CONT_CHG_ID);
		hcBuilder.append(CONT_CHG_NAME);
		hcBuilder.append(CONT_CHG_DATE);
		hcBuilder.append(CONT_CHG_APLYNO);
		hcBuilder.append(RNT_CHG_ID);
		hcBuilder.append(RNT_CHG_NAME);
		hcBuilder.append(RNT_CHG_DATE);
		hcBuilder.append(RNT_CHG_APLYNO);
		hcBuilder.append(RNT_CHG_TRNKD);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(TRN_KIND);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPB102)){
			return false;
		}
        
		DTEPB102 theObj = (DTEPB102)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				