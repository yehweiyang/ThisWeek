package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC210
 * <pre>
 * Generated value object of DBEP.DTEPC210 ()
 * </pre>
 */
public class DTEPC210 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC210";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�����~��", pk=true, nullAble=false, type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal RCV_YM = EmptyField.BIGDECIMAL;
	
	@Column(desc="���ɧ�������ɶ�", pk=true, nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp INPUT_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�X�b��������ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CFM_DATE = EmptyField.TIMESTAMP;
	
	/**
	 * Default constructor
	 */
	public DTEPC210(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �����~��
	 * @return �����~��
	 */
	public java.math.BigDecimal getRCV_YM() {
		if(EmptyField.isEmpty(RCV_YM)){
			return null;
		}
		return RCV_YM;
	}

	/**
	 * set value of �����~��
	 * @param newRCV_YM - �����~��
	 */
	public void setRCV_YM(java.math.BigDecimal newRCV_YM){
		RCV_YM = newRCV_YM;
	}	
	
	/**
	 * get value of ���ɧ�������ɶ�
	 * @return ���ɧ�������ɶ�
	 */
	public java.sql.Timestamp getINPUT_DATE() {
		if(EmptyField.isEmpty(INPUT_DATE)){
			return null;
		}
		return INPUT_DATE;
	}

	/**
	 * set value of ���ɧ�������ɶ�
	 * @param newINPUT_DATE - ���ɧ�������ɶ�
	 */
	public void setINPUT_DATE(java.sql.Timestamp newINPUT_DATE){
		INPUT_DATE = newINPUT_DATE;
	}	
	
	/**
	 * get value of �X�b��������ɶ�
	 * @return �X�b��������ɶ�
	 */
	public java.sql.Timestamp getCFM_DATE() {
		if(EmptyField.isEmpty(CFM_DATE)){
			return null;
		}
		return CFM_DATE;
	}

	/**
	 * set value of �X�b��������ɶ�
	 * @param newCFM_DATE - �X�b��������ɶ�
	 */
	public void setCFM_DATE(java.sql.Timestamp newCFM_DATE){
		CFM_DATE = newCFM_DATE;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(RCV_YM);
		hcBuilder.append(INPUT_DATE);
		hcBuilder.append(CFM_DATE);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC210)){
			return false;
		}
        
		DTEPC210 theObj = (DTEPC210)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				