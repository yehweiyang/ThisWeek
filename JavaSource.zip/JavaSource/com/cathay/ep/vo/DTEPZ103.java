package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPZ103
 * <pre>
 * Generated value object of DBEP.DTEPZ103 (�]�w_EMAIL�q�����@��)
 * </pre>
 */
public class DTEPZ103 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPZ103";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�ҥ󸹽X", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ID = EmptyField.STRING;
	
	@Column(desc="�m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String NAME = EmptyField.STRING;
	
	@Column(desc="�ҥ����", nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ID_TYPE = EmptyField.STRING;
	
	@Column(desc="EMAIL", type=java.sql.Types.VARCHAR, length=50, defaultValue="") 
	private String EMAIL = EmptyField.STRING;
	
	@Column(desc="EMAIL����", type=java.sql.Types.VARCHAR, length=200, defaultValue="") 
	private String MAIL_ITEM = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPZ103(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �ҥ󸹽X
	 * @return �ҥ󸹽X
	 */
	public String getID() {
		if(EmptyField.isEmpty(ID)){
			return null;
		}
		return ID;
	}

	/**
	 * set value of �ҥ󸹽X
	 * @param newID - �ҥ󸹽X
	 */
	public void setID(String newID){
		ID = newID;
	}	
	
	/**
	 * get value of �m�W
	 * @return �m�W
	 */
	public String getNAME() {
		if(EmptyField.isEmpty(NAME)){
			return null;
		}
		return NAME;
	}

	/**
	 * set value of �m�W
	 * @param newNAME - �m�W
	 */
	public void setNAME(String newNAME){
		NAME = newNAME;
	}	
	
	/**
	 * get value of �ҥ����
	 * @return �ҥ����
	 */
	public String getID_TYPE() {
		if(EmptyField.isEmpty(ID_TYPE)){
			return null;
		}
		return ID_TYPE;
	}

	/**
	 * set value of �ҥ����
	 * @param newID_TYPE - �ҥ����
	 */
	public void setID_TYPE(String newID_TYPE){
		ID_TYPE = newID_TYPE;
	}	
	
	/**
	 * get value of EMAIL
	 * @return EMAIL
	 */
	public String getEMAIL() {
		if(EmptyField.isEmpty(EMAIL)){
			return null;
		}
		return EMAIL;
	}

	/**
	 * set value of EMAIL
	 * @param newEMAIL - EMAIL
	 */
	public void setEMAIL(String newEMAIL){
		EMAIL = newEMAIL;
	}	
	
	/**
	 * get value of EMAIL����
	 * @return EMAIL����
	 */
	public String getMAIL_ITEM() {
		if(EmptyField.isEmpty(MAIL_ITEM)){
			return null;
		}
		return MAIL_ITEM;
	}

	/**
	 * set value of EMAIL����
	 * @param newMAIL_ITEM - EMAIL����
	 */
	public void setMAIL_ITEM(String newMAIL_ITEM){
		MAIL_ITEM = newMAIL_ITEM;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(ID);
		hcBuilder.append(NAME);
		hcBuilder.append(ID_TYPE);
		hcBuilder.append(EMAIL);
		hcBuilder.append(MAIL_ITEM);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPZ103)){
			return false;
		}
        
		DTEPZ103 theObj = (DTEPZ103)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				