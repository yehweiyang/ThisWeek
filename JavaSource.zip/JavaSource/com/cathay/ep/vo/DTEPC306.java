package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC306
 * <pre>
 * Generated value object of DBEP.DTEPC306 ()
 * </pre>
 */
public class DTEPC306 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC306";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="ú�O�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=13, defaultValue="") 
	private String PAY_NO = EmptyField.STRING;
	
	@Column(desc="�{�����B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal CSH_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�䲼���B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal CHK_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�״ڪ��B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal RMT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�R�Ȧ����B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal TKD_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�M��P�b���B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal ACNT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�l�O", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal MAL_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="��ú���B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PAY_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�P�b���B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal DACNT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�Ȧ����B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal TMP_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���ڲո�", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHK_SET_NO = EmptyField.STRING;
	
	@Column(desc="�״ڲո�", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String RMT_SET_NO = EmptyField.STRING;
	
	@Column(desc="�M��ո�", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACNT_SET_NO = EmptyField.STRING;
	
	@Column(desc="��J�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INPUT_ID = EmptyField.STRING;
	
	@Column(desc="��J�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String INPUT_NAME = EmptyField.STRING;
	
	@Column(desc="�������ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp TRN_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�g�����Ǹ�", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal TRN_SER_NO = EmptyField.BIGDECIMAL;
	
	@Column(desc="�b�Ȥ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ACNT_DATE = EmptyField.DATE;
	
	@Column(desc="�b�ȳ��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACNT_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��帹", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String SLIP_LOT_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��ո�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SLIP_SET_NO = EmptyField.INTEGER;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��N��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�H�Υd�P�b�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String CARD_D_NO = EmptyField.STRING;
	
	@Column(desc="�H�Υd�P�b���B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal CARD_D_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���~���B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal SAL_D_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�Ȧ��s��", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String TMP_NO = EmptyField.STRING;
	
	@Column(desc="�R�Ȧ��s��", type=java.sql.Types.VARCHAR, length=300, defaultValue="") 
	private String DTMP_NO = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPC306(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ú�O�s��
	 * @return ú�O�s��
	 */
	public String getPAY_NO() {
		if(EmptyField.isEmpty(PAY_NO)){
			return null;
		}
		return PAY_NO;
	}

	/**
	 * set value of ú�O�s��
	 * @param newPAY_NO - ú�O�s��
	 */
	public void setPAY_NO(String newPAY_NO){
		PAY_NO = newPAY_NO;
	}	
	
	/**
	 * get value of �{�����B
	 * @return �{�����B
	 */
	public java.math.BigDecimal getCSH_AMT() {
		if(EmptyField.isEmpty(CSH_AMT)){
			return null;
		}
		return CSH_AMT;
	}

	/**
	 * set value of �{�����B
	 * @param newCSH_AMT - �{�����B
	 */
	public void setCSH_AMT(java.math.BigDecimal newCSH_AMT){
		CSH_AMT = newCSH_AMT;
	}	
	
	/**
	 * get value of �䲼���B
	 * @return �䲼���B
	 */
	public java.math.BigDecimal getCHK_AMT() {
		if(EmptyField.isEmpty(CHK_AMT)){
			return null;
		}
		return CHK_AMT;
	}

	/**
	 * set value of �䲼���B
	 * @param newCHK_AMT - �䲼���B
	 */
	public void setCHK_AMT(java.math.BigDecimal newCHK_AMT){
		CHK_AMT = newCHK_AMT;
	}	
	
	/**
	 * get value of �״ڪ��B
	 * @return �״ڪ��B
	 */
	public java.math.BigDecimal getRMT_AMT() {
		if(EmptyField.isEmpty(RMT_AMT)){
			return null;
		}
		return RMT_AMT;
	}

	/**
	 * set value of �״ڪ��B
	 * @param newRMT_AMT - �״ڪ��B
	 */
	public void setRMT_AMT(java.math.BigDecimal newRMT_AMT){
		RMT_AMT = newRMT_AMT;
	}	
	
	/**
	 * get value of �R�Ȧ����B
	 * @return �R�Ȧ����B
	 */
	public java.math.BigDecimal getTKD_AMT() {
		if(EmptyField.isEmpty(TKD_AMT)){
			return null;
		}
		return TKD_AMT;
	}

	/**
	 * set value of �R�Ȧ����B
	 * @param newTKD_AMT - �R�Ȧ����B
	 */
	public void setTKD_AMT(java.math.BigDecimal newTKD_AMT){
		TKD_AMT = newTKD_AMT;
	}	
	
	/**
	 * get value of �M��P�b���B
	 * @return �M��P�b���B
	 */
	public java.math.BigDecimal getACNT_AMT() {
		if(EmptyField.isEmpty(ACNT_AMT)){
			return null;
		}
		return ACNT_AMT;
	}

	/**
	 * set value of �M��P�b���B
	 * @param newACNT_AMT - �M��P�b���B
	 */
	public void setACNT_AMT(java.math.BigDecimal newACNT_AMT){
		ACNT_AMT = newACNT_AMT;
	}	
	
	/**
	 * get value of �l�O
	 * @return �l�O
	 */
	public java.math.BigDecimal getMAL_AMT() {
		if(EmptyField.isEmpty(MAL_AMT)){
			return null;
		}
		return MAL_AMT;
	}

	/**
	 * set value of �l�O
	 * @param newMAL_AMT - �l�O
	 */
	public void setMAL_AMT(java.math.BigDecimal newMAL_AMT){
		MAL_AMT = newMAL_AMT;
	}	
	
	/**
	 * get value of ��ú���B
	 * @return ��ú���B
	 */
	public java.math.BigDecimal getPAY_AMT() {
		if(EmptyField.isEmpty(PAY_AMT)){
			return null;
		}
		return PAY_AMT;
	}

	/**
	 * set value of ��ú���B
	 * @param newPAY_AMT - ��ú���B
	 */
	public void setPAY_AMT(java.math.BigDecimal newPAY_AMT){
		PAY_AMT = newPAY_AMT;
	}	
	
	/**
	 * get value of �P�b���B
	 * @return �P�b���B
	 */
	public java.math.BigDecimal getDACNT_AMT() {
		if(EmptyField.isEmpty(DACNT_AMT)){
			return null;
		}
		return DACNT_AMT;
	}

	/**
	 * set value of �P�b���B
	 * @param newDACNT_AMT - �P�b���B
	 */
	public void setDACNT_AMT(java.math.BigDecimal newDACNT_AMT){
		DACNT_AMT = newDACNT_AMT;
	}	
	
	/**
	 * get value of �Ȧ����B
	 * @return �Ȧ����B
	 */
	public java.math.BigDecimal getTMP_AMT() {
		if(EmptyField.isEmpty(TMP_AMT)){
			return null;
		}
		return TMP_AMT;
	}

	/**
	 * set value of �Ȧ����B
	 * @param newTMP_AMT - �Ȧ����B
	 */
	public void setTMP_AMT(java.math.BigDecimal newTMP_AMT){
		TMP_AMT = newTMP_AMT;
	}	
	
	/**
	 * get value of ���ڲո�
	 * @return ���ڲո�
	 */
	public String getCHK_SET_NO() {
		if(EmptyField.isEmpty(CHK_SET_NO)){
			return null;
		}
		return CHK_SET_NO;
	}

	/**
	 * set value of ���ڲո�
	 * @param newCHK_SET_NO - ���ڲո�
	 */
	public void setCHK_SET_NO(String newCHK_SET_NO){
		CHK_SET_NO = newCHK_SET_NO;
	}	
	
	/**
	 * get value of �״ڲո�
	 * @return �״ڲո�
	 */
	public String getRMT_SET_NO() {
		if(EmptyField.isEmpty(RMT_SET_NO)){
			return null;
		}
		return RMT_SET_NO;
	}

	/**
	 * set value of �״ڲո�
	 * @param newRMT_SET_NO - �״ڲո�
	 */
	public void setRMT_SET_NO(String newRMT_SET_NO){
		RMT_SET_NO = newRMT_SET_NO;
	}	
	
	/**
	 * get value of �M��ո�
	 * @return �M��ո�
	 */
	public String getACNT_SET_NO() {
		if(EmptyField.isEmpty(ACNT_SET_NO)){
			return null;
		}
		return ACNT_SET_NO;
	}

	/**
	 * set value of �M��ո�
	 * @param newACNT_SET_NO - �M��ո�
	 */
	public void setACNT_SET_NO(String newACNT_SET_NO){
		ACNT_SET_NO = newACNT_SET_NO;
	}	
	
	/**
	 * get value of ��J�H��ID
	 * @return ��J�H��ID
	 */
	public String getINPUT_ID() {
		if(EmptyField.isEmpty(INPUT_ID)){
			return null;
		}
		return INPUT_ID;
	}

	/**
	 * set value of ��J�H��ID
	 * @param newINPUT_ID - ��J�H��ID
	 */
	public void setINPUT_ID(String newINPUT_ID){
		INPUT_ID = newINPUT_ID;
	}	
	
	/**
	 * get value of ��J�H���m�W
	 * @return ��J�H���m�W
	 */
	public String getINPUT_NAME() {
		if(EmptyField.isEmpty(INPUT_NAME)){
			return null;
		}
		return INPUT_NAME;
	}

	/**
	 * set value of ��J�H���m�W
	 * @param newINPUT_NAME - ��J�H���m�W
	 */
	public void setINPUT_NAME(String newINPUT_NAME){
		INPUT_NAME = newINPUT_NAME;
	}	
	
	/**
	 * get value of �������ɶ�
	 * @return �������ɶ�
	 */
	public java.sql.Timestamp getTRN_DATE() {
		if(EmptyField.isEmpty(TRN_DATE)){
			return null;
		}
		return TRN_DATE;
	}

	/**
	 * set value of �������ɶ�
	 * @param newTRN_DATE - �������ɶ�
	 */
	public void setTRN_DATE(java.sql.Timestamp newTRN_DATE){
		TRN_DATE = newTRN_DATE;
	}	
	
	/**
	 * get value of �g�����Ǹ�
	 * @return �g�����Ǹ�
	 */
	public java.math.BigDecimal getTRN_SER_NO() {
		if(EmptyField.isEmpty(TRN_SER_NO)){
			return null;
		}
		return TRN_SER_NO;
	}

	/**
	 * set value of �g�����Ǹ�
	 * @param newTRN_SER_NO - �g�����Ǹ�
	 */
	public void setTRN_SER_NO(java.math.BigDecimal newTRN_SER_NO){
		TRN_SER_NO = newTRN_SER_NO;
	}	
	
	/**
	 * get value of �b�Ȥ��
	 * @return �b�Ȥ��
	 */
	public java.sql.Date getACNT_DATE() {
		if(EmptyField.isEmpty(ACNT_DATE)){
			return null;
		}
		return ACNT_DATE;
	}

	/**
	 * set value of �b�Ȥ��
	 * @param newACNT_DATE - �b�Ȥ��
	 */
	public void setACNT_DATE(java.sql.Date newACNT_DATE){
		ACNT_DATE = newACNT_DATE;
	}	
	
	/**
	 * get value of �b�ȳ��
	 * @return �b�ȳ��
	 */
	public String getACNT_DIV_NO() {
		if(EmptyField.isEmpty(ACNT_DIV_NO)){
			return null;
		}
		return ACNT_DIV_NO;
	}

	/**
	 * set value of �b�ȳ��
	 * @param newACNT_DIV_NO - �b�ȳ��
	 */
	public void setACNT_DIV_NO(String newACNT_DIV_NO){
		ACNT_DIV_NO = newACNT_DIV_NO;
	}	
	
	/**
	 * get value of �ǲ��帹
	 * @return �ǲ��帹
	 */
	public String getSLIP_LOT_NO() {
		if(EmptyField.isEmpty(SLIP_LOT_NO)){
			return null;
		}
		return SLIP_LOT_NO;
	}

	/**
	 * set value of �ǲ��帹
	 * @param newSLIP_LOT_NO - �ǲ��帹
	 */
	public void setSLIP_LOT_NO(String newSLIP_LOT_NO){
		SLIP_LOT_NO = newSLIP_LOT_NO;
	}	
	
	/**
	 * get value of �ǲ��ո�
	 * @return �ǲ��ո�
	 */
	public Integer getSLIP_SET_NO() {
		if(EmptyField.isEmpty(SLIP_SET_NO)){
			return null;
		}
		return SLIP_SET_NO;
	}

	/**
	 * set value of �ǲ��ո�
	 * @param newSLIP_SET_NO - �ǲ��ո�
	 */
	public void setSLIP_SET_NO(Integer newSLIP_SET_NO){
		SLIP_SET_NO = newSLIP_SET_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��N��
	 * @return ���ʳ��N��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��N��
	 * @param newCHG_DIV_NO - ���ʳ��N��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of �H�Υd�P�b�s��
	 * @return �H�Υd�P�b�s��
	 */
	public String getCARD_D_NO() {
		if(EmptyField.isEmpty(CARD_D_NO)){
			return null;
		}
		return CARD_D_NO;
	}

	/**
	 * set value of �H�Υd�P�b�s��
	 * @param newCARD_D_NO - �H�Υd�P�b�s��
	 */
	public void setCARD_D_NO(String newCARD_D_NO){
		CARD_D_NO = newCARD_D_NO;
	}	
	
	/**
	 * get value of �H�Υd�P�b���B
	 * @return �H�Υd�P�b���B
	 */
	public java.math.BigDecimal getCARD_D_AMT() {
		if(EmptyField.isEmpty(CARD_D_AMT)){
			return null;
		}
		return CARD_D_AMT;
	}

	/**
	 * set value of �H�Υd�P�b���B
	 * @param newCARD_D_AMT - �H�Υd�P�b���B
	 */
	public void setCARD_D_AMT(java.math.BigDecimal newCARD_D_AMT){
		CARD_D_AMT = newCARD_D_AMT;
	}	
	
	/**
	 * get value of ���~���B
	 * @return ���~���B
	 */
	public java.math.BigDecimal getSAL_D_AMT() {
		if(EmptyField.isEmpty(SAL_D_AMT)){
			return null;
		}
		return SAL_D_AMT;
	}

	/**
	 * set value of ���~���B
	 * @param newSAL_D_AMT - ���~���B
	 */
	public void setSAL_D_AMT(java.math.BigDecimal newSAL_D_AMT){
		SAL_D_AMT = newSAL_D_AMT;
	}	
	
	/**
	 * get value of �Ȧ��s��
	 * @return �Ȧ��s��
	 */
	public String getTMP_NO() {
		if(EmptyField.isEmpty(TMP_NO)){
			return null;
		}
		return TMP_NO;
	}

	/**
	 * set value of �Ȧ��s��
	 * @param newTMP_NO - �Ȧ��s��
	 */
	public void setTMP_NO(String newTMP_NO){
		TMP_NO = newTMP_NO;
	}	
	
	/**
	 * get value of �R�Ȧ��s��
	 * @return �R�Ȧ��s��
	 */
	public String getDTMP_NO() {
		if(EmptyField.isEmpty(DTMP_NO)){
			return null;
		}
		return DTMP_NO;
	}

	/**
	 * set value of �R�Ȧ��s��
	 * @param newDTMP_NO - �R�Ȧ��s��
	 */
	public void setDTMP_NO(String newDTMP_NO){
		DTMP_NO = newDTMP_NO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(PAY_NO);
		hcBuilder.append(CSH_AMT);
		hcBuilder.append(CHK_AMT);
		hcBuilder.append(RMT_AMT);
		hcBuilder.append(TKD_AMT);
		hcBuilder.append(ACNT_AMT);
		hcBuilder.append(MAL_AMT);
		hcBuilder.append(PAY_AMT);
		hcBuilder.append(DACNT_AMT);
		hcBuilder.append(TMP_AMT);
		hcBuilder.append(CHK_SET_NO);
		hcBuilder.append(RMT_SET_NO);
		hcBuilder.append(ACNT_SET_NO);
		hcBuilder.append(INPUT_ID);
		hcBuilder.append(INPUT_NAME);
		hcBuilder.append(TRN_DATE);
		hcBuilder.append(TRN_SER_NO);
		hcBuilder.append(ACNT_DATE);
		hcBuilder.append(ACNT_DIV_NO);
		hcBuilder.append(SLIP_LOT_NO);
		hcBuilder.append(SLIP_SET_NO);
		hcBuilder.append(TRN_KIND);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(CARD_D_NO);
		hcBuilder.append(CARD_D_AMT);
		hcBuilder.append(SAL_D_AMT);
		hcBuilder.append(TMP_NO);
		hcBuilder.append(DTMP_NO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC306)){
			return false;
		}
        
		DTEPC306 theObj = (DTEPC306)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				