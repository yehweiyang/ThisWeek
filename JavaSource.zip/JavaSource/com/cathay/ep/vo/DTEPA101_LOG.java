package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPA101_LOG
 * <pre>
 * Generated value object of DBEP.DTEPA101_LOG (�j��_�򥻸����LOG)
 * </pre>
 */
public class DTEPA101_LOG implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPA101_LOG";
	
	
	@Column(desc="�J�ɤ���ɶ�", pk=true, nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp UPD_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�j�ӦW��", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String BLD_NAME = EmptyField.STRING;
	
	@Column(desc="�j�Ӹg��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String BLD_USR_ID = EmptyField.STRING;
	
	@Column(desc="�j�Ӹg��W��", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String BLD_USR_NAME = EmptyField.STRING;
	
	@Column(desc="�l���ϸ�", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String ZIP_CODE = EmptyField.STRING;
	
	@Column(desc="�ϰ줤��", type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String ZIP_NAME = EmptyField.STRING;
	
	@Column(desc="�a�}", type=java.sql.Types.VARCHAR, length=100, defaultValue="") 
	private String BLD_ADDR = EmptyField.STRING;
	
	@Column(desc="���O", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String CURR = EmptyField.STRING;
	
	@Column(desc="�p�q���", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String UNIT = EmptyField.STRING;
	
	@Column(desc="�`���n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal BLD_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�`�믲��", type=java.sql.Types.DECIMAL, length=15, defaultValue="") 
	private java.math.BigDecimal RNT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ۥέ��n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal SLF_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�X�����n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal RNT_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="��ڥX�����n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal ACT_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ӳ����n", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal BUS_SIZE = EmptyField.BIGDECIMAL;
	
	@Column(desc="�`�����", type=java.sql.Types.DECIMAL, length=4, defaultValue="") 
	private java.math.BigDecimal BLD_PRK = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ۥΨ���", type=java.sql.Types.DECIMAL, length=4, defaultValue="") 
	private java.math.BigDecimal SLF_PRK = EmptyField.BIGDECIMAL;
	
	@Column(desc="�X������", type=java.sql.Types.DECIMAL, length=4, defaultValue="") 
	private java.math.BigDecimal RNT_PRK = EmptyField.BIGDECIMAL;
	
	@Column(desc="�Ӱ�", type=java.sql.Types.DECIMAL, length=3, defaultValue="") 
	private java.math.BigDecimal FLG_RD = EmptyField.BIGDECIMAL;
	
	@Column(desc="�a�U�Ӽh��", type=java.sql.Types.DECIMAL, length=2, defaultValue="") 
	private java.math.BigDecimal UD_FLG_RD = EmptyField.BIGDECIMAL;
	
	@Column(desc="�Ȥ��", type=java.sql.Types.DECIMAL, length=5, defaultValue="") 
	private java.math.BigDecimal CUS_CNT = EmptyField.BIGDECIMAL;
	
	@Column(desc="����", type=java.sql.Types.DECIMAL, length=5, defaultValue="") 
	private java.math.BigDecimal DIV_CNT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�Ŷ��j����", type=java.sql.Types.DECIMAL, length=5, defaultValue="") 
	private java.math.BigDecimal PART_CNT = EmptyField.BIGDECIMAL;
	
	@Column(desc="����", type=java.sql.Types.DECIMAL, length=16, defaultValue="") 
	private java.math.BigDecimal COST_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�ϰ�O", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String ARA_CD = EmptyField.STRING;
	
	@Column(desc="�γ~�N�X", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String BLD_USE_CD = EmptyField.STRING;
	
	@Column(desc="�ҥΤ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date BLD_STR_DATE = EmptyField.DATE;
	
	@Column(desc="���u���", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date BLD_END_DATE = EmptyField.DATE;
	
	@Column(desc="�q�ܡX�ϰ�X", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String TEL_ARA_NO = EmptyField.STRING;
	
	@Column(desc="�q�ܡX�j�ӹq��", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String TEL_NO = EmptyField.STRING;
	
	@Column(desc="�q�ܡX����", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String TEL_EXT_NO = EmptyField.STRING;
	
	@Column(desc="�ǯu�X�ϰ�X", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String FAX_ARA_NO = EmptyField.STRING;
	
	@Column(desc="�j�Ӷǯu", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String FAX_NO = EmptyField.STRING;
	
	@Column(desc="�j�ӥD��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String DIRECTOR_ID = EmptyField.STRING;
	
	@Column(desc="�޲z���(�ӿ��O)", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CLC_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�w�B�޲z�O", type=java.sql.Types.DECIMAL, length=16, defaultValue="") 
	private java.math.BigDecimal MNG_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�j�өʽ�_�ϰ�γ~�N��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String BLD_KD_1 = EmptyField.STRING;
	
	@Column(desc="�j�өʽ�_�ϥ������N��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String BLD_KD_2 = EmptyField.STRING;
	
	@Column(desc="�j�өʽ�_�ӷ~�����N��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String BLD_KD_3 = EmptyField.STRING;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	@Column(desc="�ץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	@Column(desc="�J�ɮץ�s��", type=java.sql.Types.VARCHAR, length=14, defaultValue="") 
	private String UPD_APLY_NO = EmptyField.STRING;
	
	@Column(desc="�J�ɥ������", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String UPD_TRN_KIND = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPA101_LOG(){
		// do nothing	
	}
	
	/**
	 * get value of �J�ɤ���ɶ�
	 * @return �J�ɤ���ɶ�
	 */
	public java.sql.Timestamp getUPD_DATE() {
		if(EmptyField.isEmpty(UPD_DATE)){
			return null;
		}
		return UPD_DATE;
	}

	/**
	 * set value of �J�ɤ���ɶ�
	 * @param newUPD_DATE - �J�ɤ���ɶ�
	 */
	public void setUPD_DATE(java.sql.Timestamp newUPD_DATE){
		UPD_DATE = newUPD_DATE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �j�ӦW��
	 * @return �j�ӦW��
	 */
	public String getBLD_NAME() {
		if(EmptyField.isEmpty(BLD_NAME)){
			return null;
		}
		return BLD_NAME;
	}

	/**
	 * set value of �j�ӦW��
	 * @param newBLD_NAME - �j�ӦW��
	 */
	public void setBLD_NAME(String newBLD_NAME){
		BLD_NAME = newBLD_NAME;
	}	
	
	/**
	 * get value of �j�Ӹg��ID
	 * @return �j�Ӹg��ID
	 */
	public String getBLD_USR_ID() {
		if(EmptyField.isEmpty(BLD_USR_ID)){
			return null;
		}
		return BLD_USR_ID;
	}

	/**
	 * set value of �j�Ӹg��ID
	 * @param newBLD_USR_ID - �j�Ӹg��ID
	 */
	public void setBLD_USR_ID(String newBLD_USR_ID){
		BLD_USR_ID = newBLD_USR_ID;
	}	
	
	/**
	 * get value of �j�Ӹg��W��
	 * @return �j�Ӹg��W��
	 */
	public String getBLD_USR_NAME() {
		if(EmptyField.isEmpty(BLD_USR_NAME)){
			return null;
		}
		return BLD_USR_NAME;
	}

	/**
	 * set value of �j�Ӹg��W��
	 * @param newBLD_USR_NAME - �j�Ӹg��W��
	 */
	public void setBLD_USR_NAME(String newBLD_USR_NAME){
		BLD_USR_NAME = newBLD_USR_NAME;
	}	
	
	/**
	 * get value of �l���ϸ�
	 * @return �l���ϸ�
	 */
	public String getZIP_CODE() {
		if(EmptyField.isEmpty(ZIP_CODE)){
			return null;
		}
		return ZIP_CODE;
	}

	/**
	 * set value of �l���ϸ�
	 * @param newZIP_CODE - �l���ϸ�
	 */
	public void setZIP_CODE(String newZIP_CODE){
		ZIP_CODE = newZIP_CODE;
	}	
	
	/**
	 * get value of �ϰ줤��
	 * @return �ϰ줤��
	 */
	public String getZIP_NAME() {
		if(EmptyField.isEmpty(ZIP_NAME)){
			return null;
		}
		return ZIP_NAME;
	}

	/**
	 * set value of �ϰ줤��
	 * @param newZIP_NAME - �ϰ줤��
	 */
	public void setZIP_NAME(String newZIP_NAME){
		ZIP_NAME = newZIP_NAME;
	}	
	
	/**
	 * get value of �a�}
	 * @return �a�}
	 */
	public String getBLD_ADDR() {
		if(EmptyField.isEmpty(BLD_ADDR)){
			return null;
		}
		return BLD_ADDR;
	}

	/**
	 * set value of �a�}
	 * @param newBLD_ADDR - �a�}
	 */
	public void setBLD_ADDR(String newBLD_ADDR){
		BLD_ADDR = newBLD_ADDR;
	}	
	
	/**
	 * get value of ���O
	 * @return ���O
	 */
	public String getCURR() {
		if(EmptyField.isEmpty(CURR)){
			return null;
		}
		return CURR;
	}

	/**
	 * set value of ���O
	 * @param newCURR - ���O
	 */
	public void setCURR(String newCURR){
		CURR = newCURR;
	}	
	
	/**
	 * get value of �p�q���
	 * @return �p�q���
	 */
	public String getUNIT() {
		if(EmptyField.isEmpty(UNIT)){
			return null;
		}
		return UNIT;
	}

	/**
	 * set value of �p�q���
	 * @param newUNIT - �p�q���
	 */
	public void setUNIT(String newUNIT){
		UNIT = newUNIT;
	}	
	
	/**
	 * get value of �`���n
	 * @return �`���n
	 */
	public java.math.BigDecimal getBLD_SIZE() {
		if(EmptyField.isEmpty(BLD_SIZE)){
			return null;
		}
		return BLD_SIZE;
	}

	/**
	 * set value of �`���n
	 * @param newBLD_SIZE - �`���n
	 */
	public void setBLD_SIZE(java.math.BigDecimal newBLD_SIZE){
		BLD_SIZE = newBLD_SIZE;
	}	
	
	/**
	 * get value of �`�믲��
	 * @return �`�믲��
	 */
	public java.math.BigDecimal getRNT_AMT() {
		if(EmptyField.isEmpty(RNT_AMT)){
			return null;
		}
		return RNT_AMT;
	}

	/**
	 * set value of �`�믲��
	 * @param newRNT_AMT - �`�믲��
	 */
	public void setRNT_AMT(java.math.BigDecimal newRNT_AMT){
		RNT_AMT = newRNT_AMT;
	}	
	
	/**
	 * get value of �ۥέ��n
	 * @return �ۥέ��n
	 */
	public java.math.BigDecimal getSLF_SIZE() {
		if(EmptyField.isEmpty(SLF_SIZE)){
			return null;
		}
		return SLF_SIZE;
	}

	/**
	 * set value of �ۥέ��n
	 * @param newSLF_SIZE - �ۥέ��n
	 */
	public void setSLF_SIZE(java.math.BigDecimal newSLF_SIZE){
		SLF_SIZE = newSLF_SIZE;
	}	
	
	/**
	 * get value of �X�����n
	 * @return �X�����n
	 */
	public java.math.BigDecimal getRNT_SIZE() {
		if(EmptyField.isEmpty(RNT_SIZE)){
			return null;
		}
		return RNT_SIZE;
	}

	/**
	 * set value of �X�����n
	 * @param newRNT_SIZE - �X�����n
	 */
	public void setRNT_SIZE(java.math.BigDecimal newRNT_SIZE){
		RNT_SIZE = newRNT_SIZE;
	}	
	
	/**
	 * get value of ��ڥX�����n
	 * @return ��ڥX�����n
	 */
	public java.math.BigDecimal getACT_SIZE() {
		if(EmptyField.isEmpty(ACT_SIZE)){
			return null;
		}
		return ACT_SIZE;
	}

	/**
	 * set value of ��ڥX�����n
	 * @param newACT_SIZE - ��ڥX�����n
	 */
	public void setACT_SIZE(java.math.BigDecimal newACT_SIZE){
		ACT_SIZE = newACT_SIZE;
	}	
	
	/**
	 * get value of �ӳ����n
	 * @return �ӳ����n
	 */
	public java.math.BigDecimal getBUS_SIZE() {
		if(EmptyField.isEmpty(BUS_SIZE)){
			return null;
		}
		return BUS_SIZE;
	}

	/**
	 * set value of �ӳ����n
	 * @param newBUS_SIZE - �ӳ����n
	 */
	public void setBUS_SIZE(java.math.BigDecimal newBUS_SIZE){
		BUS_SIZE = newBUS_SIZE;
	}	
	
	/**
	 * get value of �`�����
	 * @return �`�����
	 */
	public java.math.BigDecimal getBLD_PRK() {
		if(EmptyField.isEmpty(BLD_PRK)){
			return null;
		}
		return BLD_PRK;
	}

	/**
	 * set value of �`�����
	 * @param newBLD_PRK - �`�����
	 */
	public void setBLD_PRK(java.math.BigDecimal newBLD_PRK){
		BLD_PRK = newBLD_PRK;
	}	
	
	/**
	 * get value of �ۥΨ���
	 * @return �ۥΨ���
	 */
	public java.math.BigDecimal getSLF_PRK() {
		if(EmptyField.isEmpty(SLF_PRK)){
			return null;
		}
		return SLF_PRK;
	}

	/**
	 * set value of �ۥΨ���
	 * @param newSLF_PRK - �ۥΨ���
	 */
	public void setSLF_PRK(java.math.BigDecimal newSLF_PRK){
		SLF_PRK = newSLF_PRK;
	}	
	
	/**
	 * get value of �X������
	 * @return �X������
	 */
	public java.math.BigDecimal getRNT_PRK() {
		if(EmptyField.isEmpty(RNT_PRK)){
			return null;
		}
		return RNT_PRK;
	}

	/**
	 * set value of �X������
	 * @param newRNT_PRK - �X������
	 */
	public void setRNT_PRK(java.math.BigDecimal newRNT_PRK){
		RNT_PRK = newRNT_PRK;
	}	
	
	/**
	 * get value of �Ӱ�
	 * @return �Ӱ�
	 */
	public java.math.BigDecimal getFLG_RD() {
		if(EmptyField.isEmpty(FLG_RD)){
			return null;
		}
		return FLG_RD;
	}

	/**
	 * set value of �Ӱ�
	 * @param newFLG_RD - �Ӱ�
	 */
	public void setFLG_RD(java.math.BigDecimal newFLG_RD){
		FLG_RD = newFLG_RD;
	}	
	
	/**
	 * get value of �a�U�Ӽh��
	 * @return �a�U�Ӽh��
	 */
	public java.math.BigDecimal getUD_FLG_RD() {
		if(EmptyField.isEmpty(UD_FLG_RD)){
			return null;
		}
		return UD_FLG_RD;
	}

	/**
	 * set value of �a�U�Ӽh��
	 * @param newUD_FLG_RD - �a�U�Ӽh��
	 */
	public void setUD_FLG_RD(java.math.BigDecimal newUD_FLG_RD){
		UD_FLG_RD = newUD_FLG_RD;
	}	
	
	/**
	 * get value of �Ȥ��
	 * @return �Ȥ��
	 */
	public java.math.BigDecimal getCUS_CNT() {
		if(EmptyField.isEmpty(CUS_CNT)){
			return null;
		}
		return CUS_CNT;
	}

	/**
	 * set value of �Ȥ��
	 * @param newCUS_CNT - �Ȥ��
	 */
	public void setCUS_CNT(java.math.BigDecimal newCUS_CNT){
		CUS_CNT = newCUS_CNT;
	}	
	
	/**
	 * get value of ����
	 * @return ����
	 */
	public java.math.BigDecimal getDIV_CNT() {
		if(EmptyField.isEmpty(DIV_CNT)){
			return null;
		}
		return DIV_CNT;
	}

	/**
	 * set value of ����
	 * @param newDIV_CNT - ����
	 */
	public void setDIV_CNT(java.math.BigDecimal newDIV_CNT){
		DIV_CNT = newDIV_CNT;
	}	
	
	/**
	 * get value of �Ŷ��j����
	 * @return �Ŷ��j����
	 */
	public java.math.BigDecimal getPART_CNT() {
		if(EmptyField.isEmpty(PART_CNT)){
			return null;
		}
		return PART_CNT;
	}

	/**
	 * set value of �Ŷ��j����
	 * @param newPART_CNT - �Ŷ��j����
	 */
	public void setPART_CNT(java.math.BigDecimal newPART_CNT){
		PART_CNT = newPART_CNT;
	}	
	
	/**
	 * get value of ����
	 * @return ����
	 */
	public java.math.BigDecimal getCOST_AMT() {
		if(EmptyField.isEmpty(COST_AMT)){
			return null;
		}
		return COST_AMT;
	}

	/**
	 * set value of ����
	 * @param newCOST_AMT - ����
	 */
	public void setCOST_AMT(java.math.BigDecimal newCOST_AMT){
		COST_AMT = newCOST_AMT;
	}	
	
	/**
	 * get value of �ϰ�O
	 * @return �ϰ�O
	 */
	public String getARA_CD() {
		if(EmptyField.isEmpty(ARA_CD)){
			return null;
		}
		return ARA_CD;
	}

	/**
	 * set value of �ϰ�O
	 * @param newARA_CD - �ϰ�O
	 */
	public void setARA_CD(String newARA_CD){
		ARA_CD = newARA_CD;
	}	
	
	/**
	 * get value of �γ~�N�X
	 * @return �γ~�N�X
	 */
	public String getBLD_USE_CD() {
		if(EmptyField.isEmpty(BLD_USE_CD)){
			return null;
		}
		return BLD_USE_CD;
	}

	/**
	 * set value of �γ~�N�X
	 * @param newBLD_USE_CD - �γ~�N�X
	 */
	public void setBLD_USE_CD(String newBLD_USE_CD){
		BLD_USE_CD = newBLD_USE_CD;
	}	
	
	/**
	 * get value of �ҥΤ��
	 * @return �ҥΤ��
	 */
	public java.sql.Date getBLD_STR_DATE() {
		if(EmptyField.isEmpty(BLD_STR_DATE)){
			return null;
		}
		return BLD_STR_DATE;
	}

	/**
	 * set value of �ҥΤ��
	 * @param newBLD_STR_DATE - �ҥΤ��
	 */
	public void setBLD_STR_DATE(java.sql.Date newBLD_STR_DATE){
		BLD_STR_DATE = newBLD_STR_DATE;
	}	
	
	/**
	 * get value of ���u���
	 * @return ���u���
	 */
	public java.sql.Date getBLD_END_DATE() {
		if(EmptyField.isEmpty(BLD_END_DATE)){
			return null;
		}
		return BLD_END_DATE;
	}

	/**
	 * set value of ���u���
	 * @param newBLD_END_DATE - ���u���
	 */
	public void setBLD_END_DATE(java.sql.Date newBLD_END_DATE){
		BLD_END_DATE = newBLD_END_DATE;
	}	
	
	/**
	 * get value of �q�ܡX�ϰ�X
	 * @return �q�ܡX�ϰ�X
	 */
	public String getTEL_ARA_NO() {
		if(EmptyField.isEmpty(TEL_ARA_NO)){
			return null;
		}
		return TEL_ARA_NO;
	}

	/**
	 * set value of �q�ܡX�ϰ�X
	 * @param newTEL_ARA_NO - �q�ܡX�ϰ�X
	 */
	public void setTEL_ARA_NO(String newTEL_ARA_NO){
		TEL_ARA_NO = newTEL_ARA_NO;
	}	
	
	/**
	 * get value of �q�ܡX�j�ӹq��
	 * @return �q�ܡX�j�ӹq��
	 */
	public String getTEL_NO() {
		if(EmptyField.isEmpty(TEL_NO)){
			return null;
		}
		return TEL_NO;
	}

	/**
	 * set value of �q�ܡX�j�ӹq��
	 * @param newTEL_NO - �q�ܡX�j�ӹq��
	 */
	public void setTEL_NO(String newTEL_NO){
		TEL_NO = newTEL_NO;
	}	
	
	/**
	 * get value of �q�ܡX����
	 * @return �q�ܡX����
	 */
	public String getTEL_EXT_NO() {
		if(EmptyField.isEmpty(TEL_EXT_NO)){
			return null;
		}
		return TEL_EXT_NO;
	}

	/**
	 * set value of �q�ܡX����
	 * @param newTEL_EXT_NO - �q�ܡX����
	 */
	public void setTEL_EXT_NO(String newTEL_EXT_NO){
		TEL_EXT_NO = newTEL_EXT_NO;
	}	
	
	/**
	 * get value of �ǯu�X�ϰ�X
	 * @return �ǯu�X�ϰ�X
	 */
	public String getFAX_ARA_NO() {
		if(EmptyField.isEmpty(FAX_ARA_NO)){
			return null;
		}
		return FAX_ARA_NO;
	}

	/**
	 * set value of �ǯu�X�ϰ�X
	 * @param newFAX_ARA_NO - �ǯu�X�ϰ�X
	 */
	public void setFAX_ARA_NO(String newFAX_ARA_NO){
		FAX_ARA_NO = newFAX_ARA_NO;
	}	
	
	/**
	 * get value of �j�Ӷǯu
	 * @return �j�Ӷǯu
	 */
	public String getFAX_NO() {
		if(EmptyField.isEmpty(FAX_NO)){
			return null;
		}
		return FAX_NO;
	}

	/**
	 * set value of �j�Ӷǯu
	 * @param newFAX_NO - �j�Ӷǯu
	 */
	public void setFAX_NO(String newFAX_NO){
		FAX_NO = newFAX_NO;
	}	
	
	/**
	 * get value of �j�ӥD��ID
	 * @return �j�ӥD��ID
	 */
	public String getDIRECTOR_ID() {
		if(EmptyField.isEmpty(DIRECTOR_ID)){
			return null;
		}
		return DIRECTOR_ID;
	}

	/**
	 * set value of �j�ӥD��ID
	 * @param newDIRECTOR_ID - �j�ӥD��ID
	 */
	public void setDIRECTOR_ID(String newDIRECTOR_ID){
		DIRECTOR_ID = newDIRECTOR_ID;
	}	
	
	/**
	 * get value of �޲z���(�ӿ��O)
	 * @return �޲z���(�ӿ��O)
	 */
	public String getCLC_DIV_NO() {
		if(EmptyField.isEmpty(CLC_DIV_NO)){
			return null;
		}
		return CLC_DIV_NO;
	}

	/**
	 * set value of �޲z���(�ӿ��O)
	 * @param newCLC_DIV_NO - �޲z���(�ӿ��O)
	 */
	public void setCLC_DIV_NO(String newCLC_DIV_NO){
		CLC_DIV_NO = newCLC_DIV_NO;
	}	
	
	/**
	 * get value of �w�B�޲z�O
	 * @return �w�B�޲z�O
	 */
	public java.math.BigDecimal getMNG_AMT() {
		if(EmptyField.isEmpty(MNG_AMT)){
			return null;
		}
		return MNG_AMT;
	}

	/**
	 * set value of �w�B�޲z�O
	 * @param newMNG_AMT - �w�B�޲z�O
	 */
	public void setMNG_AMT(java.math.BigDecimal newMNG_AMT){
		MNG_AMT = newMNG_AMT;
	}	
	
	/**
	 * get value of �j�өʽ�_�ϰ�γ~�N��
	 * @return �j�өʽ�_�ϰ�γ~�N��
	 */
	public String getBLD_KD_1() {
		if(EmptyField.isEmpty(BLD_KD_1)){
			return null;
		}
		return BLD_KD_1;
	}

	/**
	 * set value of �j�өʽ�_�ϰ�γ~�N��
	 * @param newBLD_KD_1 - �j�өʽ�_�ϰ�γ~�N��
	 */
	public void setBLD_KD_1(String newBLD_KD_1){
		BLD_KD_1 = newBLD_KD_1;
	}	
	
	/**
	 * get value of �j�өʽ�_�ϥ������N��
	 * @return �j�өʽ�_�ϥ������N��
	 */
	public String getBLD_KD_2() {
		if(EmptyField.isEmpty(BLD_KD_2)){
			return null;
		}
		return BLD_KD_2;
	}

	/**
	 * set value of �j�өʽ�_�ϥ������N��
	 * @param newBLD_KD_2 - �j�өʽ�_�ϥ������N��
	 */
	public void setBLD_KD_2(String newBLD_KD_2){
		BLD_KD_2 = newBLD_KD_2;
	}	
	
	/**
	 * get value of �j�өʽ�_�ӷ~�����N��
	 * @return �j�өʽ�_�ӷ~�����N��
	 */
	public String getBLD_KD_3() {
		if(EmptyField.isEmpty(BLD_KD_3)){
			return null;
		}
		return BLD_KD_3;
	}

	/**
	 * set value of �j�өʽ�_�ӷ~�����N��
	 * @param newBLD_KD_3 - �j�өʽ�_�ӷ~�����N��
	 */
	public void setBLD_KD_3(String newBLD_KD_3){
		BLD_KD_3 = newBLD_KD_3;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��
	 * @return ���ʳ��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��
	 * @param newCHG_DIV_NO - ���ʳ��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * get value of �J�ɮץ�s��
	 * @return �J�ɮץ�s��
	 */
	public String getUPD_APLY_NO() {
		if(EmptyField.isEmpty(UPD_APLY_NO)){
			return null;
		}
		return UPD_APLY_NO;
	}

	/**
	 * set value of �J�ɮץ�s��
	 * @param newUPD_APLY_NO - �J�ɮץ�s��
	 */
	public void setUPD_APLY_NO(String newUPD_APLY_NO){
		UPD_APLY_NO = newUPD_APLY_NO;
	}	
	
	/**
	 * get value of �J�ɥ������
	 * @return �J�ɥ������
	 */
	public String getUPD_TRN_KIND() {
		if(EmptyField.isEmpty(UPD_TRN_KIND)){
			return null;
		}
		return UPD_TRN_KIND;
	}

	/**
	 * set value of �J�ɥ������
	 * @param newUPD_TRN_KIND - �J�ɥ������
	 */
	public void setUPD_TRN_KIND(String newUPD_TRN_KIND){
		UPD_TRN_KIND = newUPD_TRN_KIND;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(UPD_DATE);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(BLD_NAME);
		hcBuilder.append(BLD_USR_ID);
		hcBuilder.append(BLD_USR_NAME);
		hcBuilder.append(ZIP_CODE);
		hcBuilder.append(ZIP_NAME);
		hcBuilder.append(BLD_ADDR);
		hcBuilder.append(CURR);
		hcBuilder.append(UNIT);
		hcBuilder.append(BLD_SIZE);
		hcBuilder.append(RNT_AMT);
		hcBuilder.append(SLF_SIZE);
		hcBuilder.append(RNT_SIZE);
		hcBuilder.append(ACT_SIZE);
		hcBuilder.append(BUS_SIZE);
		hcBuilder.append(BLD_PRK);
		hcBuilder.append(SLF_PRK);
		hcBuilder.append(RNT_PRK);
		hcBuilder.append(FLG_RD);
		hcBuilder.append(UD_FLG_RD);
		hcBuilder.append(CUS_CNT);
		hcBuilder.append(DIV_CNT);
		hcBuilder.append(PART_CNT);
		hcBuilder.append(COST_AMT);
		hcBuilder.append(ARA_CD);
		hcBuilder.append(BLD_USE_CD);
		hcBuilder.append(BLD_STR_DATE);
		hcBuilder.append(BLD_END_DATE);
		hcBuilder.append(TEL_ARA_NO);
		hcBuilder.append(TEL_NO);
		hcBuilder.append(TEL_EXT_NO);
		hcBuilder.append(FAX_ARA_NO);
		hcBuilder.append(FAX_NO);
		hcBuilder.append(DIRECTOR_ID);
		hcBuilder.append(CLC_DIV_NO);
		hcBuilder.append(MNG_AMT);
		hcBuilder.append(BLD_KD_1);
		hcBuilder.append(BLD_KD_2);
		hcBuilder.append(BLD_KD_3);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		hcBuilder.append(APLY_NO);
		hcBuilder.append(TRN_KIND);
		hcBuilder.append(UPD_APLY_NO);
		hcBuilder.append(UPD_TRN_KIND);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPA101_LOG)){
			return false;
		}
        
		DTEPA101_LOG theObj = (DTEPA101_LOG)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				