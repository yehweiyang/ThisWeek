package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC105
 * <pre>
 * Generated value object of DBEP.DTEPC105 (������������)
 * </pre>
 */
public class DTEPC105 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC105";
	
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="������", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String EXT_TYPE = EmptyField.STRING;
	
	@Column(desc="���~��", pk=true, nullAble=false, type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal EXT_YM = EmptyField.BIGDECIMAL;
	
	@Column(desc="�����", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp EXT_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���", type=java.sql.Types.DECIMAL, length=5, defaultValue="") 
	private java.math.BigDecimal CNT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���B", type=java.sql.Types.DECIMAL, length=16, defaultValue="") 
	private java.math.BigDecimal AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���ʤ���ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp CHG_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="���ʳ��N��", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String CHG_DIV_NO = EmptyField.STRING;
	
	@Column(desc="���ʤH��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CHG_ID = EmptyField.STRING;
	
	@Column(desc="���ʤH���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CHG_NAME = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPC105(){
		// do nothing	
	}
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ������
	 * @return ������
	 */
	public String getEXT_TYPE() {
		if(EmptyField.isEmpty(EXT_TYPE)){
			return null;
		}
		return EXT_TYPE;
	}

	/**
	 * set value of ������
	 * @param newEXT_TYPE - ������
	 */
	public void setEXT_TYPE(String newEXT_TYPE){
		EXT_TYPE = newEXT_TYPE;
	}	
	
	/**
	 * get value of ���~��
	 * @return ���~��
	 */
	public java.math.BigDecimal getEXT_YM() {
		if(EmptyField.isEmpty(EXT_YM)){
			return null;
		}
		return EXT_YM;
	}

	/**
	 * set value of ���~��
	 * @param newEXT_YM - ���~��
	 */
	public void setEXT_YM(java.math.BigDecimal newEXT_YM){
		EXT_YM = newEXT_YM;
	}	
	
	/**
	 * get value of �����
	 * @return �����
	 */
	public java.sql.Timestamp getEXT_DATE() {
		if(EmptyField.isEmpty(EXT_DATE)){
			return null;
		}
		return EXT_DATE;
	}

	/**
	 * set value of �����
	 * @param newEXT_DATE - �����
	 */
	public void setEXT_DATE(java.sql.Timestamp newEXT_DATE){
		EXT_DATE = newEXT_DATE;
	}	
	
	/**
	 * get value of ���
	 * @return ���
	 */
	public java.math.BigDecimal getCNT() {
		if(EmptyField.isEmpty(CNT)){
			return null;
		}
		return CNT;
	}

	/**
	 * set value of ���
	 * @param newCNT - ���
	 */
	public void setCNT(java.math.BigDecimal newCNT){
		CNT = newCNT;
	}	
	
	/**
	 * get value of ���B
	 * @return ���B
	 */
	public java.math.BigDecimal getAMT() {
		if(EmptyField.isEmpty(AMT)){
			return null;
		}
		return AMT;
	}

	/**
	 * set value of ���B
	 * @param newAMT - ���B
	 */
	public void setAMT(java.math.BigDecimal newAMT){
		AMT = newAMT;
	}	
	
	/**
	 * get value of ���ʤ���ɶ�
	 * @return ���ʤ���ɶ�
	 */
	public java.sql.Timestamp getCHG_DATE() {
		if(EmptyField.isEmpty(CHG_DATE)){
			return null;
		}
		return CHG_DATE;
	}

	/**
	 * set value of ���ʤ���ɶ�
	 * @param newCHG_DATE - ���ʤ���ɶ�
	 */
	public void setCHG_DATE(java.sql.Timestamp newCHG_DATE){
		CHG_DATE = newCHG_DATE;
	}	
	
	/**
	 * get value of ���ʳ��N��
	 * @return ���ʳ��N��
	 */
	public String getCHG_DIV_NO() {
		if(EmptyField.isEmpty(CHG_DIV_NO)){
			return null;
		}
		return CHG_DIV_NO;
	}

	/**
	 * set value of ���ʳ��N��
	 * @param newCHG_DIV_NO - ���ʳ��N��
	 */
	public void setCHG_DIV_NO(String newCHG_DIV_NO){
		CHG_DIV_NO = newCHG_DIV_NO;
	}	
	
	/**
	 * get value of ���ʤH��ID
	 * @return ���ʤH��ID
	 */
	public String getCHG_ID() {
		if(EmptyField.isEmpty(CHG_ID)){
			return null;
		}
		return CHG_ID;
	}

	/**
	 * set value of ���ʤH��ID
	 * @param newCHG_ID - ���ʤH��ID
	 */
	public void setCHG_ID(String newCHG_ID){
		CHG_ID = newCHG_ID;
	}	
	
	/**
	 * get value of ���ʤH���m�W
	 * @return ���ʤH���m�W
	 */
	public String getCHG_NAME() {
		if(EmptyField.isEmpty(CHG_NAME)){
			return null;
		}
		return CHG_NAME;
	}

	/**
	 * set value of ���ʤH���m�W
	 * @param newCHG_NAME - ���ʤH���m�W
	 */
	public void setCHG_NAME(String newCHG_NAME){
		CHG_NAME = newCHG_NAME;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(EXT_TYPE);
		hcBuilder.append(EXT_YM);
		hcBuilder.append(EXT_DATE);
		hcBuilder.append(CNT);
		hcBuilder.append(AMT);
		hcBuilder.append(CHG_DATE);
		hcBuilder.append(CHG_DIV_NO);
		hcBuilder.append(CHG_ID);
		hcBuilder.append(CHG_NAME);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC105)){
			return false;
		}
        
		DTEPC105 theObj = (DTEPC105)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				