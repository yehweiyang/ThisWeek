package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC102
 * <pre>
 * Generated value object of DBEP.DTEPC102 (���կ��թ����)
 * </pre>
 */
public class DTEPC102 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC102";
	
	
	@Column(desc="�����N��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�կ����", pk=true, nullAble=false, type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ADJ_DATE = EmptyField.DATE;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="���զ~��", nullAble=false, type=java.sql.Types.DECIMAL, length=6, defaultValue="") 
	private java.math.BigDecimal ADJ_YM = EmptyField.BIGDECIMAL;
	
	@Column(desc="�j�ӥN��", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�վ㯲��", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal ART_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�վ���", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal APM_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�կ�����", type=java.sql.Types.DECIMAL, length=15, defaultValue="") 
	private java.math.BigDecimal ADJ_UNIT_NUM = EmptyField.BIGDECIMAL;
	
	@Column(desc="�կ����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ADJ_UNIT = EmptyField.STRING;
	
	@Column(desc="�ɶ}�W��", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp ADJ_E_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�ɶ}���B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal ADD_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="��J�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INPUT_ID = EmptyField.STRING;
	
	@Column(desc="��J�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String INPUT_NAME = EmptyField.STRING;
	
	@Column(desc="��J���", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp INPUT_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�_�����", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date RNT_S_DATE = EmptyField.DATE;
	
	@Column(desc="���������", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date RNT_E_DATE = EmptyField.DATE;
	
	@Column(desc="�կ��覡", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ADJ_TYPE = EmptyField.STRING;
	
	@Column(desc="�թ����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ADJ_PM = EmptyField.STRING;
	
	@Column(desc="�믲��", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal RNT_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal PMS_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�Τ@�s��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ID = EmptyField.STRING;
	
	@Column(desc="�Ȥ�m�W", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String CUS_NAME = EmptyField.STRING;
	
	@Column(desc="�簣����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String DEL_CD = EmptyField.STRING;
	
	@Column(desc="�������", nullAble=false, type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TRN_KIND = EmptyField.STRING;
	
	@Column(desc="�f��y�{�s��", nullAble=false, type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FLOW_NO = EmptyField.STRING;
	
	@Column(desc="�@�~�i��", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String OP_STATUS = EmptyField.STRING;
	
	@Column(desc="�@�~�ɶ�", nullAble=false, type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp LST_PROC_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�@�~�H��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String LST_PROC_ID = EmptyField.STRING;
	
	@Column(desc="�@�~���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String LST_PROC_DIV = EmptyField.STRING;
	
	@Column(desc="�@�~�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String LST_PROC_NAME = EmptyField.STRING;
	
	@Column(desc="��Ʃ�������", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String FROM_TYPE = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPC102(){
		// do nothing	
	}
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �կ����
	 * @return �կ����
	 */
	public java.sql.Date getADJ_DATE() {
		if(EmptyField.isEmpty(ADJ_DATE)){
			return null;
		}
		return ADJ_DATE;
	}

	/**
	 * set value of �կ����
	 * @param newADJ_DATE - �կ����
	 */
	public void setADJ_DATE(java.sql.Date newADJ_DATE){
		ADJ_DATE = newADJ_DATE;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ���զ~��
	 * @return ���զ~��
	 */
	public java.math.BigDecimal getADJ_YM() {
		if(EmptyField.isEmpty(ADJ_YM)){
			return null;
		}
		return ADJ_YM;
	}

	/**
	 * set value of ���զ~��
	 * @param newADJ_YM - ���զ~��
	 */
	public void setADJ_YM(java.math.BigDecimal newADJ_YM){
		ADJ_YM = newADJ_YM;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �վ㯲��
	 * @return �վ㯲��
	 */
	public java.math.BigDecimal getART_AMT() {
		if(EmptyField.isEmpty(ART_AMT)){
			return null;
		}
		return ART_AMT;
	}

	/**
	 * set value of �վ㯲��
	 * @param newART_AMT - �վ㯲��
	 */
	public void setART_AMT(java.math.BigDecimal newART_AMT){
		ART_AMT = newART_AMT;
	}	
	
	/**
	 * get value of �վ���
	 * @return �վ���
	 */
	public java.math.BigDecimal getAPM_AMT() {
		if(EmptyField.isEmpty(APM_AMT)){
			return null;
		}
		return APM_AMT;
	}

	/**
	 * set value of �վ���
	 * @param newAPM_AMT - �վ���
	 */
	public void setAPM_AMT(java.math.BigDecimal newAPM_AMT){
		APM_AMT = newAPM_AMT;
	}	
	
	/**
	 * get value of �կ�����
	 * @return �կ�����
	 */
	public java.math.BigDecimal getADJ_UNIT_NUM() {
		if(EmptyField.isEmpty(ADJ_UNIT_NUM)){
			return null;
		}
		return ADJ_UNIT_NUM;
	}

	/**
	 * set value of �կ�����
	 * @param newADJ_UNIT_NUM - �կ�����
	 */
	public void setADJ_UNIT_NUM(java.math.BigDecimal newADJ_UNIT_NUM){
		ADJ_UNIT_NUM = newADJ_UNIT_NUM;
	}	
	
	/**
	 * get value of �կ����
	 * @return �կ����
	 */
	public String getADJ_UNIT() {
		if(EmptyField.isEmpty(ADJ_UNIT)){
			return null;
		}
		return ADJ_UNIT;
	}

	/**
	 * set value of �կ����
	 * @param newADJ_UNIT - �կ����
	 */
	public void setADJ_UNIT(String newADJ_UNIT){
		ADJ_UNIT = newADJ_UNIT;
	}	
	
	/**
	 * get value of �ɶ}�W��
	 * @return �ɶ}�W��
	 */
	public java.sql.Timestamp getADJ_E_DATE() {
		if(EmptyField.isEmpty(ADJ_E_DATE)){
			return null;
		}
		return ADJ_E_DATE;
	}

	/**
	 * set value of �ɶ}�W��
	 * @param newADJ_E_DATE - �ɶ}�W��
	 */
	public void setADJ_E_DATE(java.sql.Timestamp newADJ_E_DATE){
		ADJ_E_DATE = newADJ_E_DATE;
	}	
	
	/**
	 * get value of �ɶ}���B
	 * @return �ɶ}���B
	 */
	public java.math.BigDecimal getADD_AMT() {
		if(EmptyField.isEmpty(ADD_AMT)){
			return null;
		}
		return ADD_AMT;
	}

	/**
	 * set value of �ɶ}���B
	 * @param newADD_AMT - �ɶ}���B
	 */
	public void setADD_AMT(java.math.BigDecimal newADD_AMT){
		ADD_AMT = newADD_AMT;
	}	
	
	/**
	 * get value of ��J�H��ID
	 * @return ��J�H��ID
	 */
	public String getINPUT_ID() {
		if(EmptyField.isEmpty(INPUT_ID)){
			return null;
		}
		return INPUT_ID;
	}

	/**
	 * set value of ��J�H��ID
	 * @param newINPUT_ID - ��J�H��ID
	 */
	public void setINPUT_ID(String newINPUT_ID){
		INPUT_ID = newINPUT_ID;
	}	
	
	/**
	 * get value of ��J�H���m�W
	 * @return ��J�H���m�W
	 */
	public String getINPUT_NAME() {
		if(EmptyField.isEmpty(INPUT_NAME)){
			return null;
		}
		return INPUT_NAME;
	}

	/**
	 * set value of ��J�H���m�W
	 * @param newINPUT_NAME - ��J�H���m�W
	 */
	public void setINPUT_NAME(String newINPUT_NAME){
		INPUT_NAME = newINPUT_NAME;
	}	
	
	/**
	 * get value of ��J���
	 * @return ��J���
	 */
	public java.sql.Timestamp getINPUT_DATE() {
		if(EmptyField.isEmpty(INPUT_DATE)){
			return null;
		}
		return INPUT_DATE;
	}

	/**
	 * set value of ��J���
	 * @param newINPUT_DATE - ��J���
	 */
	public void setINPUT_DATE(java.sql.Timestamp newINPUT_DATE){
		INPUT_DATE = newINPUT_DATE;
	}	
	
	/**
	 * get value of �_�����
	 * @return �_�����
	 */
	public java.sql.Date getRNT_S_DATE() {
		if(EmptyField.isEmpty(RNT_S_DATE)){
			return null;
		}
		return RNT_S_DATE;
	}

	/**
	 * set value of �_�����
	 * @param newRNT_S_DATE - �_�����
	 */
	public void setRNT_S_DATE(java.sql.Date newRNT_S_DATE){
		RNT_S_DATE = newRNT_S_DATE;
	}	
	
	/**
	 * get value of ���������
	 * @return ���������
	 */
	public java.sql.Date getRNT_E_DATE() {
		if(EmptyField.isEmpty(RNT_E_DATE)){
			return null;
		}
		return RNT_E_DATE;
	}

	/**
	 * set value of ���������
	 * @param newRNT_E_DATE - ���������
	 */
	public void setRNT_E_DATE(java.sql.Date newRNT_E_DATE){
		RNT_E_DATE = newRNT_E_DATE;
	}	
	
	/**
	 * get value of �կ��覡
	 * @return �կ��覡
	 */
	public String getADJ_TYPE() {
		if(EmptyField.isEmpty(ADJ_TYPE)){
			return null;
		}
		return ADJ_TYPE;
	}

	/**
	 * set value of �կ��覡
	 * @param newADJ_TYPE - �կ��覡
	 */
	public void setADJ_TYPE(String newADJ_TYPE){
		ADJ_TYPE = newADJ_TYPE;
	}	
	
	/**
	 * get value of �թ����
	 * @return �թ����
	 */
	public String getADJ_PM() {
		if(EmptyField.isEmpty(ADJ_PM)){
			return null;
		}
		return ADJ_PM;
	}

	/**
	 * set value of �թ����
	 * @param newADJ_PM - �թ����
	 */
	public void setADJ_PM(String newADJ_PM){
		ADJ_PM = newADJ_PM;
	}	
	
	/**
	 * get value of �믲��
	 * @return �믲��
	 */
	public java.math.BigDecimal getRNT_AMT() {
		if(EmptyField.isEmpty(RNT_AMT)){
			return null;
		}
		return RNT_AMT;
	}

	/**
	 * set value of �믲��
	 * @param newRNT_AMT - �믲��
	 */
	public void setRNT_AMT(java.math.BigDecimal newRNT_AMT){
		RNT_AMT = newRNT_AMT;
	}	
	
	/**
	 * get value of ���
	 * @return ���
	 */
	public java.math.BigDecimal getPMS_AMT() {
		if(EmptyField.isEmpty(PMS_AMT)){
			return null;
		}
		return PMS_AMT;
	}

	/**
	 * set value of ���
	 * @param newPMS_AMT - ���
	 */
	public void setPMS_AMT(java.math.BigDecimal newPMS_AMT){
		PMS_AMT = newPMS_AMT;
	}	
	
	/**
	 * get value of �Τ@�s��
	 * @return �Τ@�s��
	 */
	public String getID() {
		if(EmptyField.isEmpty(ID)){
			return null;
		}
		return ID;
	}

	/**
	 * set value of �Τ@�s��
	 * @param newID - �Τ@�s��
	 */
	public void setID(String newID){
		ID = newID;
	}	
	
	/**
	 * get value of �Ȥ�m�W
	 * @return �Ȥ�m�W
	 */
	public String getCUS_NAME() {
		if(EmptyField.isEmpty(CUS_NAME)){
			return null;
		}
		return CUS_NAME;
	}

	/**
	 * set value of �Ȥ�m�W
	 * @param newCUS_NAME - �Ȥ�m�W
	 */
	public void setCUS_NAME(String newCUS_NAME){
		CUS_NAME = newCUS_NAME;
	}	
	
	/**
	 * get value of �簣����
	 * @return �簣����
	 */
	public String getDEL_CD() {
		if(EmptyField.isEmpty(DEL_CD)){
			return null;
		}
		return DEL_CD;
	}

	/**
	 * set value of �簣����
	 * @param newDEL_CD - �簣����
	 */
	public void setDEL_CD(String newDEL_CD){
		DEL_CD = newDEL_CD;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTRN_KIND() {
		if(EmptyField.isEmpty(TRN_KIND)){
			return null;
		}
		return TRN_KIND;
	}

	/**
	 * set value of �������
	 * @param newTRN_KIND - �������
	 */
	public void setTRN_KIND(String newTRN_KIND){
		TRN_KIND = newTRN_KIND;
	}	
	
	/**
	 * get value of �f��y�{�s��
	 * @return �f��y�{�s��
	 */
	public String getFLOW_NO() {
		if(EmptyField.isEmpty(FLOW_NO)){
			return null;
		}
		return FLOW_NO;
	}

	/**
	 * set value of �f��y�{�s��
	 * @param newFLOW_NO - �f��y�{�s��
	 */
	public void setFLOW_NO(String newFLOW_NO){
		FLOW_NO = newFLOW_NO;
	}	
	
	/**
	 * get value of �@�~�i��
	 * @return �@�~�i��
	 */
	public String getOP_STATUS() {
		if(EmptyField.isEmpty(OP_STATUS)){
			return null;
		}
		return OP_STATUS;
	}

	/**
	 * set value of �@�~�i��
	 * @param newOP_STATUS - �@�~�i��
	 */
	public void setOP_STATUS(String newOP_STATUS){
		OP_STATUS = newOP_STATUS;
	}	
	
	/**
	 * get value of �@�~�ɶ�
	 * @return �@�~�ɶ�
	 */
	public java.sql.Timestamp getLST_PROC_DATE() {
		if(EmptyField.isEmpty(LST_PROC_DATE)){
			return null;
		}
		return LST_PROC_DATE;
	}

	/**
	 * set value of �@�~�ɶ�
	 * @param newLST_PROC_DATE - �@�~�ɶ�
	 */
	public void setLST_PROC_DATE(java.sql.Timestamp newLST_PROC_DATE){
		LST_PROC_DATE = newLST_PROC_DATE;
	}	
	
	/**
	 * get value of �@�~�H��
	 * @return �@�~�H��
	 */
	public String getLST_PROC_ID() {
		if(EmptyField.isEmpty(LST_PROC_ID)){
			return null;
		}
		return LST_PROC_ID;
	}

	/**
	 * set value of �@�~�H��
	 * @param newLST_PROC_ID - �@�~�H��
	 */
	public void setLST_PROC_ID(String newLST_PROC_ID){
		LST_PROC_ID = newLST_PROC_ID;
	}	
	
	/**
	 * get value of �@�~���
	 * @return �@�~���
	 */
	public String getLST_PROC_DIV() {
		if(EmptyField.isEmpty(LST_PROC_DIV)){
			return null;
		}
		return LST_PROC_DIV;
	}

	/**
	 * set value of �@�~���
	 * @param newLST_PROC_DIV - �@�~���
	 */
	public void setLST_PROC_DIV(String newLST_PROC_DIV){
		LST_PROC_DIV = newLST_PROC_DIV;
	}	
	
	/**
	 * get value of �@�~�H���m�W
	 * @return �@�~�H���m�W
	 */
	public String getLST_PROC_NAME() {
		if(EmptyField.isEmpty(LST_PROC_NAME)){
			return null;
		}
		return LST_PROC_NAME;
	}

	/**
	 * set value of �@�~�H���m�W
	 * @param newLST_PROC_NAME - �@�~�H���m�W
	 */
	public void setLST_PROC_NAME(String newLST_PROC_NAME){
		LST_PROC_NAME = newLST_PROC_NAME;
	}	
	
	/**
	 * get value of ��Ʃ�������
	 * @return ��Ʃ�������
	 */
	public String getFROM_TYPE() {
		if(EmptyField.isEmpty(FROM_TYPE)){
			return null;
		}
		return FROM_TYPE;
	}

	/**
	 * set value of ��Ʃ�������
	 * @param newFROM_TYPE - ��Ʃ�������
	 */
	public void setFROM_TYPE(String newFROM_TYPE){
		FROM_TYPE = newFROM_TYPE;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(ADJ_DATE);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(ADJ_YM);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(ART_AMT);
		hcBuilder.append(APM_AMT);
		hcBuilder.append(ADJ_UNIT_NUM);
		hcBuilder.append(ADJ_UNIT);
		hcBuilder.append(ADJ_E_DATE);
		hcBuilder.append(ADD_AMT);
		hcBuilder.append(INPUT_ID);
		hcBuilder.append(INPUT_NAME);
		hcBuilder.append(INPUT_DATE);
		hcBuilder.append(RNT_S_DATE);
		hcBuilder.append(RNT_E_DATE);
		hcBuilder.append(ADJ_TYPE);
		hcBuilder.append(ADJ_PM);
		hcBuilder.append(RNT_AMT);
		hcBuilder.append(PMS_AMT);
		hcBuilder.append(ID);
		hcBuilder.append(CUS_NAME);
		hcBuilder.append(DEL_CD);
		hcBuilder.append(TRN_KIND);
		hcBuilder.append(FLOW_NO);
		hcBuilder.append(OP_STATUS);
		hcBuilder.append(LST_PROC_DATE);
		hcBuilder.append(LST_PROC_ID);
		hcBuilder.append(LST_PROC_DIV);
		hcBuilder.append(LST_PROC_NAME);
		hcBuilder.append(FROM_TYPE);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC102)){
			return false;
		}
        
		DTEPC102 theObj = (DTEPC102)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				