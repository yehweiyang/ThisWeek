package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPC307
 * <pre>
 * Generated value object of DBEP.DTEPC307 (�Ȧ�M�������)
 * </pre>
 */
public class DTEPC307 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPC307";
	
	
	@Column(desc="�Ȧ�b�Ǹ�", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String BANK_SER_NO = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="��w�N��", nullAble=false, type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String BANK_NO = EmptyField.STRING;
	
	@Column(desc="�Ȧ�b��", nullAble=false, type=java.sql.Types.VARCHAR, length=16, defaultValue="") 
	private String ACNT_NO = EmptyField.STRING;
	
	@Column(desc="�״ڤ��", nullAble=false, type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date RMT_DATE = EmptyField.DATE;
	
	@Column(desc="����Ǹ�", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String TX_SEQNO = EmptyField.STRING;
	
	@Column(desc="����N��", type=java.sql.Types.VARCHAR, length=4, defaultValue="") 
	private String TX_IDNO = EmptyField.STRING;
	
	@Column(desc="�ť�", type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SPACE = EmptyField.STRING;
	
	@Column(desc="�䲼���X", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String CHNO = EmptyField.STRING;
	
	@Column(desc="�ɶU�O", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String DC = EmptyField.STRING;
	
	@Column(desc="������B���t��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String SIGN = EmptyField.STRING;
	
	@Column(desc="������B", type=java.sql.Types.DECIMAL, length=15, defaultValue="") 
	private java.math.BigDecimal AMOUNT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�b��l�B���t��", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String BSIGN = EmptyField.STRING;
	
	@Column(desc="�b��l�B", type=java.sql.Types.DECIMAL, length=15, defaultValue="") 
	private java.math.BigDecimal BAMOUNT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�Ƶ��@", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String MEMO1 = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String TX_MACH = EmptyField.STRING;
	
	@Column(desc="�������", type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String TX_SPEC = EmptyField.STRING;
	
	@Column(desc="����", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String BANKID = EmptyField.STRING;
	
	@Column(desc="��W", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String ACCNAME = EmptyField.STRING;
	
	@Column(desc="�Ƶ��G", type=java.sql.Types.VARCHAR, length=36, defaultValue="") 
	private String MEMO2 = EmptyField.STRING;
	
	@Column(desc="����ɶ�", type=java.sql.Types.VARCHAR, length=6, defaultValue="") 
	private String TX_TIME = EmptyField.STRING;
	
	@Column(desc="�����N��", type=java.sql.Types.VARCHAR, length=18, defaultValue="") 
	private String CRT_NO = EmptyField.STRING;
	
	@Column(desc="�Ȥ�Ǹ�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer CUS_NO = EmptyField.INTEGER;
	
	@Column(desc="�ҥ󸹽X", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ID = EmptyField.STRING;
	
	@Column(desc="�j�ӥN��", type=java.sql.Types.VARCHAR, length=8, defaultValue="") 
	private String BLD_CD = EmptyField.STRING;
	
	@Column(desc="�T�{���", type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String CFM_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�T�{���", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date CFM_DATE = EmptyField.DATE;
	
	@Column(desc="�T�{�H��ID", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String CFM_ID = EmptyField.STRING;
	
	@Column(desc="�T�{�H���m�W", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String CFM_NAME = EmptyField.STRING;
	
	@Column(desc="�M��ո�", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACNT_SET_NO = EmptyField.STRING;
	
	@Column(desc="�������ɶ�", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp TRN_DATE = EmptyField.TIMESTAMP;
	
	@Column(desc="�g�����Ǹ�", type=java.sql.Types.DECIMAL, length=9, defaultValue="") 
	private java.math.BigDecimal TRN_SER_NO = EmptyField.BIGDECIMAL;
	
	@Column(desc="�b�Ȥ��", type=java.sql.Types.DATE, length=4, defaultValue="") 
	private java.sql.Date ACNT_DATE = EmptyField.DATE;
	
	@Column(desc="�b�ȳ��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String ACNT_DIV_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��帹", type=java.sql.Types.VARCHAR, length=3, defaultValue="") 
	private String SLIP_LOT_NO = EmptyField.STRING;
	
	@Column(desc="�ǲ��ո�", type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer SLIP_SET_NO = EmptyField.INTEGER;
	
	@Column(desc="�ӷ�", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String SOURCE = EmptyField.STRING;
	
	@Column(desc="�~�b����", type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String ERR_CODE = EmptyField.STRING;
	
	@Column(desc="�|�p�P�b�Ƶ�", type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String ACC_MEMO = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPC307(){
		// do nothing	
	}
	
	/**
	 * get value of �Ȧ�b�Ǹ�
	 * @return �Ȧ�b�Ǹ�
	 */
	public String getBANK_SER_NO() {
		if(EmptyField.isEmpty(BANK_SER_NO)){
			return null;
		}
		return BANK_SER_NO;
	}

	/**
	 * set value of �Ȧ�b�Ǹ�
	 * @param newBANK_SER_NO - �Ȧ�b�Ǹ�
	 */
	public void setBANK_SER_NO(String newBANK_SER_NO){
		BANK_SER_NO = newBANK_SER_NO;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of ��w�N��
	 * @return ��w�N��
	 */
	public String getBANK_NO() {
		if(EmptyField.isEmpty(BANK_NO)){
			return null;
		}
		return BANK_NO;
	}

	/**
	 * set value of ��w�N��
	 * @param newBANK_NO - ��w�N��
	 */
	public void setBANK_NO(String newBANK_NO){
		BANK_NO = newBANK_NO;
	}	
	
	/**
	 * get value of �Ȧ�b��
	 * @return �Ȧ�b��
	 */
	public String getACNT_NO() {
		if(EmptyField.isEmpty(ACNT_NO)){
			return null;
		}
		return ACNT_NO;
	}

	/**
	 * set value of �Ȧ�b��
	 * @param newACNT_NO - �Ȧ�b��
	 */
	public void setACNT_NO(String newACNT_NO){
		ACNT_NO = newACNT_NO;
	}	
	
	/**
	 * get value of �״ڤ��
	 * @return �״ڤ��
	 */
	public java.sql.Date getRMT_DATE() {
		if(EmptyField.isEmpty(RMT_DATE)){
			return null;
		}
		return RMT_DATE;
	}

	/**
	 * set value of �״ڤ��
	 * @param newRMT_DATE - �״ڤ��
	 */
	public void setRMT_DATE(java.sql.Date newRMT_DATE){
		RMT_DATE = newRMT_DATE;
	}	
	
	/**
	 * get value of ����Ǹ�
	 * @return ����Ǹ�
	 */
	public String getTX_SEQNO() {
		if(EmptyField.isEmpty(TX_SEQNO)){
			return null;
		}
		return TX_SEQNO;
	}

	/**
	 * set value of ����Ǹ�
	 * @param newTX_SEQNO - ����Ǹ�
	 */
	public void setTX_SEQNO(String newTX_SEQNO){
		TX_SEQNO = newTX_SEQNO;
	}	
	
	/**
	 * get value of ����N��
	 * @return ����N��
	 */
	public String getTX_IDNO() {
		if(EmptyField.isEmpty(TX_IDNO)){
			return null;
		}
		return TX_IDNO;
	}

	/**
	 * set value of ����N��
	 * @param newTX_IDNO - ����N��
	 */
	public void setTX_IDNO(String newTX_IDNO){
		TX_IDNO = newTX_IDNO;
	}	
	
	/**
	 * get value of �ť�
	 * @return �ť�
	 */
	public String getSPACE() {
		if(EmptyField.isEmpty(SPACE)){
			return null;
		}
		return SPACE;
	}

	/**
	 * set value of �ť�
	 * @param newSPACE - �ť�
	 */
	public void setSPACE(String newSPACE){
		SPACE = newSPACE;
	}	
	
	/**
	 * get value of �䲼���X
	 * @return �䲼���X
	 */
	public String getCHNO() {
		if(EmptyField.isEmpty(CHNO)){
			return null;
		}
		return CHNO;
	}

	/**
	 * set value of �䲼���X
	 * @param newCHNO - �䲼���X
	 */
	public void setCHNO(String newCHNO){
		CHNO = newCHNO;
	}	
	
	/**
	 * get value of �ɶU�O
	 * @return �ɶU�O
	 */
	public String getDC() {
		if(EmptyField.isEmpty(DC)){
			return null;
		}
		return DC;
	}

	/**
	 * set value of �ɶU�O
	 * @param newDC - �ɶU�O
	 */
	public void setDC(String newDC){
		DC = newDC;
	}	
	
	/**
	 * get value of ������B���t��
	 * @return ������B���t��
	 */
	public String getSIGN() {
		if(EmptyField.isEmpty(SIGN)){
			return null;
		}
		return SIGN;
	}

	/**
	 * set value of ������B���t��
	 * @param newSIGN - ������B���t��
	 */
	public void setSIGN(String newSIGN){
		SIGN = newSIGN;
	}	
	
	/**
	 * get value of ������B
	 * @return ������B
	 */
	public java.math.BigDecimal getAMOUNT() {
		if(EmptyField.isEmpty(AMOUNT)){
			return null;
		}
		return AMOUNT;
	}

	/**
	 * set value of ������B
	 * @param newAMOUNT - ������B
	 */
	public void setAMOUNT(java.math.BigDecimal newAMOUNT){
		AMOUNT = newAMOUNT;
	}	
	
	/**
	 * get value of �b��l�B���t��
	 * @return �b��l�B���t��
	 */
	public String getBSIGN() {
		if(EmptyField.isEmpty(BSIGN)){
			return null;
		}
		return BSIGN;
	}

	/**
	 * set value of �b��l�B���t��
	 * @param newBSIGN - �b��l�B���t��
	 */
	public void setBSIGN(String newBSIGN){
		BSIGN = newBSIGN;
	}	
	
	/**
	 * get value of �b��l�B
	 * @return �b��l�B
	 */
	public java.math.BigDecimal getBAMOUNT() {
		if(EmptyField.isEmpty(BAMOUNT)){
			return null;
		}
		return BAMOUNT;
	}

	/**
	 * set value of �b��l�B
	 * @param newBAMOUNT - �b��l�B
	 */
	public void setBAMOUNT(java.math.BigDecimal newBAMOUNT){
		BAMOUNT = newBAMOUNT;
	}	
	
	/**
	 * get value of �Ƶ��@
	 * @return �Ƶ��@
	 */
	public String getMEMO1() {
		if(EmptyField.isEmpty(MEMO1)){
			return null;
		}
		return MEMO1;
	}

	/**
	 * set value of �Ƶ��@
	 * @param newMEMO1 - �Ƶ��@
	 */
	public void setMEMO1(String newMEMO1){
		MEMO1 = newMEMO1;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTX_MACH() {
		if(EmptyField.isEmpty(TX_MACH)){
			return null;
		}
		return TX_MACH;
	}

	/**
	 * set value of �������
	 * @param newTX_MACH - �������
	 */
	public void setTX_MACH(String newTX_MACH){
		TX_MACH = newTX_MACH;
	}	
	
	/**
	 * get value of �������
	 * @return �������
	 */
	public String getTX_SPEC() {
		if(EmptyField.isEmpty(TX_SPEC)){
			return null;
		}
		return TX_SPEC;
	}

	/**
	 * set value of �������
	 * @param newTX_SPEC - �������
	 */
	public void setTX_SPEC(String newTX_SPEC){
		TX_SPEC = newTX_SPEC;
	}	
	
	/**
	 * get value of ����
	 * @return ����
	 */
	public String getBANKID() {
		if(EmptyField.isEmpty(BANKID)){
			return null;
		}
		return BANKID;
	}

	/**
	 * set value of ����
	 * @param newBANKID - ����
	 */
	public void setBANKID(String newBANKID){
		BANKID = newBANKID;
	}	
	
	/**
	 * get value of ��W
	 * @return ��W
	 */
	public String getACCNAME() {
		if(EmptyField.isEmpty(ACCNAME)){
			return null;
		}
		return ACCNAME;
	}

	/**
	 * set value of ��W
	 * @param newACCNAME - ��W
	 */
	public void setACCNAME(String newACCNAME){
		ACCNAME = newACCNAME;
	}	
	
	/**
	 * get value of �Ƶ��G
	 * @return �Ƶ��G
	 */
	public String getMEMO2() {
		if(EmptyField.isEmpty(MEMO2)){
			return null;
		}
		return MEMO2;
	}

	/**
	 * set value of �Ƶ��G
	 * @param newMEMO2 - �Ƶ��G
	 */
	public void setMEMO2(String newMEMO2){
		MEMO2 = newMEMO2;
	}	
	
	/**
	 * get value of ����ɶ�
	 * @return ����ɶ�
	 */
	public String getTX_TIME() {
		if(EmptyField.isEmpty(TX_TIME)){
			return null;
		}
		return TX_TIME;
	}

	/**
	 * set value of ����ɶ�
	 * @param newTX_TIME - ����ɶ�
	 */
	public void setTX_TIME(String newTX_TIME){
		TX_TIME = newTX_TIME;
	}	
	
	/**
	 * get value of �����N��
	 * @return �����N��
	 */
	public String getCRT_NO() {
		if(EmptyField.isEmpty(CRT_NO)){
			return null;
		}
		return CRT_NO;
	}

	/**
	 * set value of �����N��
	 * @param newCRT_NO - �����N��
	 */
	public void setCRT_NO(String newCRT_NO){
		CRT_NO = newCRT_NO;
	}	
	
	/**
	 * get value of �Ȥ�Ǹ�
	 * @return �Ȥ�Ǹ�
	 */
	public Integer getCUS_NO() {
		if(EmptyField.isEmpty(CUS_NO)){
			return null;
		}
		return CUS_NO;
	}

	/**
	 * set value of �Ȥ�Ǹ�
	 * @param newCUS_NO - �Ȥ�Ǹ�
	 */
	public void setCUS_NO(Integer newCUS_NO){
		CUS_NO = newCUS_NO;
	}	
	
	/**
	 * get value of �ҥ󸹽X
	 * @return �ҥ󸹽X
	 */
	public String getID() {
		if(EmptyField.isEmpty(ID)){
			return null;
		}
		return ID;
	}

	/**
	 * set value of �ҥ󸹽X
	 * @param newID - �ҥ󸹽X
	 */
	public void setID(String newID){
		ID = newID;
	}	
	
	/**
	 * get value of �j�ӥN��
	 * @return �j�ӥN��
	 */
	public String getBLD_CD() {
		if(EmptyField.isEmpty(BLD_CD)){
			return null;
		}
		return BLD_CD;
	}

	/**
	 * set value of �j�ӥN��
	 * @param newBLD_CD - �j�ӥN��
	 */
	public void setBLD_CD(String newBLD_CD){
		BLD_CD = newBLD_CD;
	}	
	
	/**
	 * get value of �T�{���
	 * @return �T�{���
	 */
	public String getCFM_DIV_NO() {
		if(EmptyField.isEmpty(CFM_DIV_NO)){
			return null;
		}
		return CFM_DIV_NO;
	}

	/**
	 * set value of �T�{���
	 * @param newCFM_DIV_NO - �T�{���
	 */
	public void setCFM_DIV_NO(String newCFM_DIV_NO){
		CFM_DIV_NO = newCFM_DIV_NO;
	}	
	
	/**
	 * get value of �T�{���
	 * @return �T�{���
	 */
	public java.sql.Date getCFM_DATE() {
		if(EmptyField.isEmpty(CFM_DATE)){
			return null;
		}
		return CFM_DATE;
	}

	/**
	 * set value of �T�{���
	 * @param newCFM_DATE - �T�{���
	 */
	public void setCFM_DATE(java.sql.Date newCFM_DATE){
		CFM_DATE = newCFM_DATE;
	}	
	
	/**
	 * get value of �T�{�H��ID
	 * @return �T�{�H��ID
	 */
	public String getCFM_ID() {
		if(EmptyField.isEmpty(CFM_ID)){
			return null;
		}
		return CFM_ID;
	}

	/**
	 * set value of �T�{�H��ID
	 * @param newCFM_ID - �T�{�H��ID
	 */
	public void setCFM_ID(String newCFM_ID){
		CFM_ID = newCFM_ID;
	}	
	
	/**
	 * get value of �T�{�H���m�W
	 * @return �T�{�H���m�W
	 */
	public String getCFM_NAME() {
		if(EmptyField.isEmpty(CFM_NAME)){
			return null;
		}
		return CFM_NAME;
	}

	/**
	 * set value of �T�{�H���m�W
	 * @param newCFM_NAME - �T�{�H���m�W
	 */
	public void setCFM_NAME(String newCFM_NAME){
		CFM_NAME = newCFM_NAME;
	}	
	
	/**
	 * get value of �M��ո�
	 * @return �M��ո�
	 */
	public String getACNT_SET_NO() {
		if(EmptyField.isEmpty(ACNT_SET_NO)){
			return null;
		}
		return ACNT_SET_NO;
	}

	/**
	 * set value of �M��ո�
	 * @param newACNT_SET_NO - �M��ո�
	 */
	public void setACNT_SET_NO(String newACNT_SET_NO){
		ACNT_SET_NO = newACNT_SET_NO;
	}	
	
	/**
	 * get value of �������ɶ�
	 * @return �������ɶ�
	 */
	public java.sql.Timestamp getTRN_DATE() {
		if(EmptyField.isEmpty(TRN_DATE)){
			return null;
		}
		return TRN_DATE;
	}

	/**
	 * set value of �������ɶ�
	 * @param newTRN_DATE - �������ɶ�
	 */
	public void setTRN_DATE(java.sql.Timestamp newTRN_DATE){
		TRN_DATE = newTRN_DATE;
	}	
	
	/**
	 * get value of �g�����Ǹ�
	 * @return �g�����Ǹ�
	 */
	public java.math.BigDecimal getTRN_SER_NO() {
		if(EmptyField.isEmpty(TRN_SER_NO)){
			return null;
		}
		return TRN_SER_NO;
	}

	/**
	 * set value of �g�����Ǹ�
	 * @param newTRN_SER_NO - �g�����Ǹ�
	 */
	public void setTRN_SER_NO(java.math.BigDecimal newTRN_SER_NO){
		TRN_SER_NO = newTRN_SER_NO;
	}	
	
	/**
	 * get value of �b�Ȥ��
	 * @return �b�Ȥ��
	 */
	public java.sql.Date getACNT_DATE() {
		if(EmptyField.isEmpty(ACNT_DATE)){
			return null;
		}
		return ACNT_DATE;
	}

	/**
	 * set value of �b�Ȥ��
	 * @param newACNT_DATE - �b�Ȥ��
	 */
	public void setACNT_DATE(java.sql.Date newACNT_DATE){
		ACNT_DATE = newACNT_DATE;
	}	
	
	/**
	 * get value of �b�ȳ��
	 * @return �b�ȳ��
	 */
	public String getACNT_DIV_NO() {
		if(EmptyField.isEmpty(ACNT_DIV_NO)){
			return null;
		}
		return ACNT_DIV_NO;
	}

	/**
	 * set value of �b�ȳ��
	 * @param newACNT_DIV_NO - �b�ȳ��
	 */
	public void setACNT_DIV_NO(String newACNT_DIV_NO){
		ACNT_DIV_NO = newACNT_DIV_NO;
	}	
	
	/**
	 * get value of �ǲ��帹
	 * @return �ǲ��帹
	 */
	public String getSLIP_LOT_NO() {
		if(EmptyField.isEmpty(SLIP_LOT_NO)){
			return null;
		}
		return SLIP_LOT_NO;
	}

	/**
	 * set value of �ǲ��帹
	 * @param newSLIP_LOT_NO - �ǲ��帹
	 */
	public void setSLIP_LOT_NO(String newSLIP_LOT_NO){
		SLIP_LOT_NO = newSLIP_LOT_NO;
	}	
	
	/**
	 * get value of �ǲ��ո�
	 * @return �ǲ��ո�
	 */
	public Integer getSLIP_SET_NO() {
		if(EmptyField.isEmpty(SLIP_SET_NO)){
			return null;
		}
		return SLIP_SET_NO;
	}

	/**
	 * set value of �ǲ��ո�
	 * @param newSLIP_SET_NO - �ǲ��ո�
	 */
	public void setSLIP_SET_NO(Integer newSLIP_SET_NO){
		SLIP_SET_NO = newSLIP_SET_NO;
	}	
	
	/**
	 * get value of �ӷ�
	 * @return �ӷ�
	 */
	public String getSOURCE() {
		if(EmptyField.isEmpty(SOURCE)){
			return null;
		}
		return SOURCE;
	}

	/**
	 * set value of �ӷ�
	 * @param newSOURCE - �ӷ�
	 */
	public void setSOURCE(String newSOURCE){
		SOURCE = newSOURCE;
	}	
	
	/**
	 * get value of �~�b����
	 * @return �~�b����
	 */
	public String getERR_CODE() {
		if(EmptyField.isEmpty(ERR_CODE)){
			return null;
		}
		return ERR_CODE;
	}

	/**
	 * set value of �~�b����
	 * @param newERR_CODE - �~�b����
	 */
	public void setERR_CODE(String newERR_CODE){
		ERR_CODE = newERR_CODE;
	}	
	
	/**
	 * get value of �|�p�P�b�Ƶ�
	 * @return �|�p�P�b�Ƶ�
	 */
	public String getACC_MEMO() {
		if(EmptyField.isEmpty(ACC_MEMO)){
			return null;
		}
		return ACC_MEMO;
	}

	/**
	 * set value of �|�p�P�b�Ƶ�
	 * @param newACC_MEMO - �|�p�P�b�Ƶ�
	 */
	public void setACC_MEMO(String newACC_MEMO){
		ACC_MEMO = newACC_MEMO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(BANK_SER_NO);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(BANK_NO);
		hcBuilder.append(ACNT_NO);
		hcBuilder.append(RMT_DATE);
		hcBuilder.append(TX_SEQNO);
		hcBuilder.append(TX_IDNO);
		hcBuilder.append(SPACE);
		hcBuilder.append(CHNO);
		hcBuilder.append(DC);
		hcBuilder.append(SIGN);
		hcBuilder.append(AMOUNT);
		hcBuilder.append(BSIGN);
		hcBuilder.append(BAMOUNT);
		hcBuilder.append(MEMO1);
		hcBuilder.append(TX_MACH);
		hcBuilder.append(TX_SPEC);
		hcBuilder.append(BANKID);
		hcBuilder.append(ACCNAME);
		hcBuilder.append(MEMO2);
		hcBuilder.append(TX_TIME);
		hcBuilder.append(CRT_NO);
		hcBuilder.append(CUS_NO);
		hcBuilder.append(ID);
		hcBuilder.append(BLD_CD);
		hcBuilder.append(CFM_DIV_NO);
		hcBuilder.append(CFM_DATE);
		hcBuilder.append(CFM_ID);
		hcBuilder.append(CFM_NAME);
		hcBuilder.append(ACNT_SET_NO);
		hcBuilder.append(TRN_DATE);
		hcBuilder.append(TRN_SER_NO);
		hcBuilder.append(ACNT_DATE);
		hcBuilder.append(ACNT_DIV_NO);
		hcBuilder.append(SLIP_LOT_NO);
		hcBuilder.append(SLIP_SET_NO);
		hcBuilder.append(SOURCE);
		hcBuilder.append(ERR_CODE);
		hcBuilder.append(ACC_MEMO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPC307)){
			return false;
		}
        
		DTEPC307 theObj = (DTEPC307)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				