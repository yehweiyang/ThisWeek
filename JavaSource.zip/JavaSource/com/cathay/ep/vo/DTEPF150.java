package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPF150
 * <pre>
 * Generated value object of DBEP.DTEPF150 (��µ�ץ�_�M��D��)
 * </pre>
 */
public class DTEPF150 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPF150";
	
	
	@Column(desc="�ץ�s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=12, defaultValue="") 
	private String APLY_NO = EmptyField.STRING;
	
	@Column(desc="�M�����", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=1, defaultValue="") 
	private String CLOSE_TP = EmptyField.STRING;
	
	@Column(desc="�M��Ǹ�", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer ITEM_NO = EmptyField.INTEGER;
	
	@Column(desc="���ئW�١��t��", nullAble=false, type=java.sql.Types.VARCHAR, length=90, defaultValue="") 
	private String ITEM_NM = EmptyField.STRING;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�֭p������B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal TOTAL_PAY_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���~�ץI�ڪ��B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal YEAR_PAY_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="���~�ץi����|�B", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal TAX_PAY_AMT = EmptyField.BIGDECIMAL;
	
	@Column(desc="�I�ܨM���֭p", type=java.sql.Types.DECIMAL, length=12, defaultValue="") 
	private java.math.BigDecimal CLOSE_PAY_AMT = EmptyField.BIGDECIMAL;
	
	/**
	 * Default constructor
	 */
	public DTEPF150(){
		// do nothing	
	}
	
	/**
	 * get value of �ץ�s��
	 * @return �ץ�s��
	 */
	public String getAPLY_NO() {
		if(EmptyField.isEmpty(APLY_NO)){
			return null;
		}
		return APLY_NO;
	}

	/**
	 * set value of �ץ�s��
	 * @param newAPLY_NO - �ץ�s��
	 */
	public void setAPLY_NO(String newAPLY_NO){
		APLY_NO = newAPLY_NO;
	}	
	
	/**
	 * get value of �M�����
	 * @return �M�����
	 */
	public String getCLOSE_TP() {
		if(EmptyField.isEmpty(CLOSE_TP)){
			return null;
		}
		return CLOSE_TP;
	}

	/**
	 * set value of �M�����
	 * @param newCLOSE_TP - �M�����
	 */
	public void setCLOSE_TP(String newCLOSE_TP){
		CLOSE_TP = newCLOSE_TP;
	}	
	
	/**
	 * get value of �M��Ǹ�
	 * @return �M��Ǹ�
	 */
	public Integer getITEM_NO() {
		if(EmptyField.isEmpty(ITEM_NO)){
			return null;
		}
		return ITEM_NO;
	}

	/**
	 * set value of �M��Ǹ�
	 * @param newITEM_NO - �M��Ǹ�
	 */
	public void setITEM_NO(Integer newITEM_NO){
		ITEM_NO = newITEM_NO;
	}	
	
	/**
	 * get value of ���ئW�١��t��
	 * @return ���ئW�١��t��
	 */
	public String getITEM_NM() {
		if(EmptyField.isEmpty(ITEM_NM)){
			return null;
		}
		return ITEM_NM;
	}

	/**
	 * set value of ���ئW�١��t��
	 * @param newITEM_NM - ���ئW�١��t��
	 */
	public void setITEM_NM(String newITEM_NM){
		ITEM_NM = newITEM_NM;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �֭p������B
	 * @return �֭p������B
	 */
	public java.math.BigDecimal getTOTAL_PAY_AMT() {
		if(EmptyField.isEmpty(TOTAL_PAY_AMT)){
			return null;
		}
		return TOTAL_PAY_AMT;
	}

	/**
	 * set value of �֭p������B
	 * @param newTOTAL_PAY_AMT - �֭p������B
	 */
	public void setTOTAL_PAY_AMT(java.math.BigDecimal newTOTAL_PAY_AMT){
		TOTAL_PAY_AMT = newTOTAL_PAY_AMT;
	}	
	
	/**
	 * get value of ���~�ץI�ڪ��B
	 * @return ���~�ץI�ڪ��B
	 */
	public java.math.BigDecimal getYEAR_PAY_AMT() {
		if(EmptyField.isEmpty(YEAR_PAY_AMT)){
			return null;
		}
		return YEAR_PAY_AMT;
	}

	/**
	 * set value of ���~�ץI�ڪ��B
	 * @param newYEAR_PAY_AMT - ���~�ץI�ڪ��B
	 */
	public void setYEAR_PAY_AMT(java.math.BigDecimal newYEAR_PAY_AMT){
		YEAR_PAY_AMT = newYEAR_PAY_AMT;
	}	
	
	/**
	 * get value of ���~�ץi����|�B
	 * @return ���~�ץi����|�B
	 */
	public java.math.BigDecimal getTAX_PAY_AMT() {
		if(EmptyField.isEmpty(TAX_PAY_AMT)){
			return null;
		}
		return TAX_PAY_AMT;
	}

	/**
	 * set value of ���~�ץi����|�B
	 * @param newTAX_PAY_AMT - ���~�ץi����|�B
	 */
	public void setTAX_PAY_AMT(java.math.BigDecimal newTAX_PAY_AMT){
		TAX_PAY_AMT = newTAX_PAY_AMT;
	}	
	
	/**
	 * get value of �I�ܨM���֭p
	 * @return �I�ܨM���֭p
	 */
	public java.math.BigDecimal getCLOSE_PAY_AMT() {
		if(EmptyField.isEmpty(CLOSE_PAY_AMT)){
			return null;
		}
		return CLOSE_PAY_AMT;
	}

	/**
	 * set value of �I�ܨM���֭p
	 * @param newCLOSE_PAY_AMT - �I�ܨM���֭p
	 */
	public void setCLOSE_PAY_AMT(java.math.BigDecimal newCLOSE_PAY_AMT){
		CLOSE_PAY_AMT = newCLOSE_PAY_AMT;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(APLY_NO);
		hcBuilder.append(CLOSE_TP);
		hcBuilder.append(ITEM_NO);
		hcBuilder.append(ITEM_NM);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(TOTAL_PAY_AMT);
		hcBuilder.append(YEAR_PAY_AMT);
		hcBuilder.append(TAX_PAY_AMT);
		hcBuilder.append(CLOSE_PAY_AMT);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPF150)){
			return false;
		}
        
		DTEPF150 theObj = (DTEPF150)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				