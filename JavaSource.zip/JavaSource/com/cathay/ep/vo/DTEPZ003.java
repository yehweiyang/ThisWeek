package com.cathay.ep.vo;

import org.apache.commons.lang.builder.*;
import com.cathay.common.im.annotation.Column;
import com.cathay.common.im.db.EmptyField;

/**
 * DTEPZ003
 * <pre>
 * Generated value object of DBEP.DTEPZ003 ()
 * </pre>
 */
public class DTEPZ003 implements Cloneable {
	
	/** name of db table to map to  */
	public static final String DB_TABLE_NAME = "DBEP.DTEPZ003";
	
	
	@Column(desc="�ɮ׽s��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=20, defaultValue="") 
	private String FILE_NO = EmptyField.STRING;
	
	@Column(desc="�ɮצW��", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=150, defaultValue="") 
	private String FILE_NM = EmptyField.STRING;
	
	@Column(desc="�ɮת���", pk=true, nullAble=false, type=java.sql.Types.INTEGER, length=4, defaultValue="") 
	private Integer FILE_VER = EmptyField.INTEGER;
	
	@Column(desc="�����q�O", pk=true, nullAble=false, type=java.sql.Types.VARCHAR, length=2, defaultValue="") 
	private String SUB_CPY_ID = EmptyField.STRING;
	
	@Column(desc="�ɮ׺���(���ɦW)", type=java.sql.Types.VARCHAR, length=5, defaultValue="") 
	private String FILE_KIND = EmptyField.STRING;
	
	@Column(desc="�ɮ׳Ƶ�", type=java.sql.Types.VARCHAR, length=750, defaultValue="") 
	private String FILE_REMARK = EmptyField.STRING;
	
	@Column(desc="����y����", type=java.sql.Types.VARCHAR, length=30, defaultValue="") 
	private String FILE_ID = EmptyField.STRING;
	
	@Column(desc="��J���", type=java.sql.Types.TIMESTAMP, length=10, defaultValue="") 
	private java.sql.Timestamp INS_DT = EmptyField.TIMESTAMP;
	
	@Column(desc="��J�H��", type=java.sql.Types.VARCHAR, length=10, defaultValue="") 
	private String INS_ID = EmptyField.STRING;
	
	@Column(desc="��J���", type=java.sql.Types.VARCHAR, length=7, defaultValue="") 
	private String INS_DIVNO = EmptyField.STRING;
	
	/**
	 * Default constructor
	 */
	public DTEPZ003(){
		// do nothing	
	}
	
	/**
	 * get value of �ɮ׽s��
	 * @return �ɮ׽s��
	 */
	public String getFILE_NO() {
		if(EmptyField.isEmpty(FILE_NO)){
			return null;
		}
		return FILE_NO;
	}

	/**
	 * set value of �ɮ׽s��
	 * @param newFILE_NO - �ɮ׽s��
	 */
	public void setFILE_NO(String newFILE_NO){
		FILE_NO = newFILE_NO;
	}	
	
	/**
	 * get value of �ɮצW��
	 * @return �ɮצW��
	 */
	public String getFILE_NM() {
		if(EmptyField.isEmpty(FILE_NM)){
			return null;
		}
		return FILE_NM;
	}

	/**
	 * set value of �ɮצW��
	 * @param newFILE_NM - �ɮצW��
	 */
	public void setFILE_NM(String newFILE_NM){
		FILE_NM = newFILE_NM;
	}	
	
	/**
	 * get value of �ɮת���
	 * @return �ɮת���
	 */
	public Integer getFILE_VER() {
		if(EmptyField.isEmpty(FILE_VER)){
			return null;
		}
		return FILE_VER;
	}

	/**
	 * set value of �ɮת���
	 * @param newFILE_VER - �ɮת���
	 */
	public void setFILE_VER(Integer newFILE_VER){
		FILE_VER = newFILE_VER;
	}	
	
	/**
	 * get value of �����q�O
	 * @return �����q�O
	 */
	public String getSUB_CPY_ID() {
		if(EmptyField.isEmpty(SUB_CPY_ID)){
			return null;
		}
		return SUB_CPY_ID;
	}

	/**
	 * set value of �����q�O
	 * @param newSUB_CPY_ID - �����q�O
	 */
	public void setSUB_CPY_ID(String newSUB_CPY_ID){
		SUB_CPY_ID = newSUB_CPY_ID;
	}	
	
	/**
	 * get value of �ɮ׺���(���ɦW)
	 * @return �ɮ׺���(���ɦW)
	 */
	public String getFILE_KIND() {
		if(EmptyField.isEmpty(FILE_KIND)){
			return null;
		}
		return FILE_KIND;
	}

	/**
	 * set value of �ɮ׺���(���ɦW)
	 * @param newFILE_KIND - �ɮ׺���(���ɦW)
	 */
	public void setFILE_KIND(String newFILE_KIND){
		FILE_KIND = newFILE_KIND;
	}	
	
	/**
	 * get value of �ɮ׳Ƶ�
	 * @return �ɮ׳Ƶ�
	 */
	public String getFILE_REMARK() {
		if(EmptyField.isEmpty(FILE_REMARK)){
			return null;
		}
		return FILE_REMARK;
	}

	/**
	 * set value of �ɮ׳Ƶ�
	 * @param newFILE_REMARK - �ɮ׳Ƶ�
	 */
	public void setFILE_REMARK(String newFILE_REMARK){
		FILE_REMARK = newFILE_REMARK;
	}	
	
	/**
	 * get value of ����y����
	 * @return ����y����
	 */
	public String getFILE_ID() {
		if(EmptyField.isEmpty(FILE_ID)){
			return null;
		}
		return FILE_ID;
	}

	/**
	 * set value of ����y����
	 * @param newFILE_ID - ����y����
	 */
	public void setFILE_ID(String newFILE_ID){
		FILE_ID = newFILE_ID;
	}	
	
	/**
	 * get value of ��J���
	 * @return ��J���
	 */
	public java.sql.Timestamp getINS_DT() {
		if(EmptyField.isEmpty(INS_DT)){
			return null;
		}
		return INS_DT;
	}

	/**
	 * set value of ��J���
	 * @param newINS_DT - ��J���
	 */
	public void setINS_DT(java.sql.Timestamp newINS_DT){
		INS_DT = newINS_DT;
	}	
	
	/**
	 * get value of ��J�H��
	 * @return ��J�H��
	 */
	public String getINS_ID() {
		if(EmptyField.isEmpty(INS_ID)){
			return null;
		}
		return INS_ID;
	}

	/**
	 * set value of ��J�H��
	 * @param newINS_ID - ��J�H��
	 */
	public void setINS_ID(String newINS_ID){
		INS_ID = newINS_ID;
	}	
	
	/**
	 * get value of ��J���
	 * @return ��J���
	 */
	public String getINS_DIVNO() {
		if(EmptyField.isEmpty(INS_DIVNO)){
			return null;
		}
		return INS_DIVNO;
	}

	/**
	 * set value of ��J���
	 * @param newINS_DIVNO - ��J���
	 */
	public void setINS_DIVNO(String newINS_DIVNO){
		INS_DIVNO = newINS_DIVNO;
	}	
	
	/**
	 * override Object.toString()
	 * @return string value of the value object
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}
	
	/**
	 * override Object.hashCode()
	 * @return a hash code value for this value object
	 */
	public int hashCode() {
	
		HashCodeBuilder hcBuilder = new HashCodeBuilder(17, 37);
		
		hcBuilder.append(FILE_NO);
		hcBuilder.append(FILE_NM);
		hcBuilder.append(FILE_VER);
		hcBuilder.append(SUB_CPY_ID);
		hcBuilder.append(FILE_KIND);
		hcBuilder.append(FILE_REMARK);
		hcBuilder.append(FILE_ID);
		hcBuilder.append(INS_DT);
		hcBuilder.append(INS_ID);
		hcBuilder.append(INS_DIVNO);
		
		return hcBuilder.toHashCode();
	}

	/**
	 * override Object.equals()
	 * @param obj the object to be compared to
	 * @return true or false
	 */
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof DTEPZ003)){
			return false;
		}
        
		DTEPZ003 theObj = (DTEPZ003)obj;
        
        return (this.hashCode() == theObj.hashCode());

	}

	/**
	 * override Object.clone()
	 * @return cloned object
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}	
}
				