package com.cathay.ep.g3.module;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.ep.z0.module.EP_Z0G420;

/**
 * <pre>
 * �ˮָ��
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EPG3_0200_mod {
    /**
     * �ˮ��ɮפ��e�榡
     * @param fileItem
     * @param reqMap
     * @throws ModuleException
     * @throws IOException 
     */
    public void checkFormat(FileItem fileItem, Map reqMap) throws ModuleException, IOException {
        ErrorInputException eie = null;
        if (fileItem == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPG3_0200_mod_MSG_001")); //�פJ�ɮפ��o����
        }
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPG3_0200_mod_MSG_002")); //�ǤJ���󤣱o����
        }
        if (eie != null) {
            throw eie;
        }
        String FILE_TYPE = fileItem.getName().substring(fileItem.getName().lastIndexOf(".") + 1); // �ɮ�����: csv, txt
        if (!("csv".equalsIgnoreCase(FILE_TYPE) || "txt".equalsIgnoreCase(FILE_TYPE))) {
            throw new ErrorInputException(MessageUtil.getMessage("EPG3_0200_mod_MSG_003"));//�ɦW���~
        }
        String UP_TP = MapUtils.getString(reqMap, "UP_TP");
        String CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
        Map UP_FLDList = FieldOptionList.getName("EP", "EPG30200_FLD_" + UP_TP);

        BufferedReader br = EncodingHelper.getBufferedReader(fileItem.getInputStream()); // �إ߽w�İ�
        int fieldCount = UP_FLDList.size();

        try {
            String line;
            String[] tokens;
            int i = 1;
            while ((line = br.readLine()) != null) {
                //tokens=line.split(",");
                tokens = StringUtils.splitPreserveAllTokens(line, ","); //��ƪ����j�Ÿ���","

                if (tokens.length == 1) { //�p�G���ťզ�
                    continue;
                } else if (tokens.length != fieldCount) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPG3_0200_mod_MSG_004", new Object[] { i })); //��{0}���ɮ׮榡���~�A���ˬd���ƥجO�_���T
                }
                if (StringUtils.isBlank(tokens[0].trim())) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPG3_0200_mod_MSG_005")); //�j��/��a�N���L��
                }
                if (StringUtils.isBlank(tokens[1].trim())) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPG3_0200_mod_MSG_006")); //�@�~�~��L��
                } else {
                    if (!tokens[1].equals(CAL_YM)) {
                        throw new ErrorInputException(MessageUtil.getMessage("EPG3_0200_mod_MSG_007")); //�@�~�~��P�e�����@�P
                    }
                }
                i++;
            }
        } finally {
            if (br != null) {
                br.close();
            }
        }
    }

    /**
     * �ˮ֤W���ɮפ��e�O�_�w�g�s�b
     * @param reqMap
     * @throws ModuleException
     */

    public void checkUpload(Map reqMap) throws ModuleException {
        if (reqMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EPG3_0200_mod_MSG_002")); //�ǤJ���󤣱o����
        }
        try {
            new EP_Z0G420().queryList(reqMap);
            throw new ModuleException(MessageUtil.getMessage("EPG3_0200_mod_MSG_008")); //�w�g����ơA�Х��R���A���s�W��
        } catch (DataNotFoundException dnfe) {

        }
    }

    /**
     * �ˮ֬O�_�i�R��
     * @param reqMap
     * @throws ModuleException
     */
    public void checkDelete(Map reqMap) throws ModuleException {
        if (reqMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EPG3_0200_mod_MSG_002")); //�ǤJ���󤣱o����
        }
        try {
            new EP_Z0G420().queryList(reqMap);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPG3_0200_mod_MSG_009")); //�W�Ǹ�Ƥ��s�b�A�L�k�R��
        }
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
