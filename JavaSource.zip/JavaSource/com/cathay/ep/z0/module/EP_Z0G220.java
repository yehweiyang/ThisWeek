package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.g3.batch.EPG3_B100;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014/09/30  Created ������
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��a���������R�P�Ҳ�
 * �Ҳ�ID    EP_Z0G220 
 * ���n����    ��a�����������@�Ҳ�
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EP_Z0G220 {

    private static final String SQL_queryG220List_001 = "com.cathay.ep.z0.module.EP_Z0G220.SQL_queryG220List_001";

    private static final String SQL_getDAplyNo_001 = "com.cathay.ep.z0.module.EP_Z0G220.SQL_getDAplyNo_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0G220.SQL_queryMap_001";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0G220.SQL_insert_001";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0G220.SQL_delete_001";

    private static final Logger log = Logger.getLogger(EP_Z0G220.class);

    private static final String SQL_approve_001 = "com.cathay.ep.z0.module.EP_Z0G220.SQL_approve_001";

    /**
     * Ū������R�P��T�M��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryG220List(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        String APLY_NO = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_003")); //�ǤJ��a�N�����o���ŭ�
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_004")); //�ǤJ�ץ�s�����o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�߮ץ�_��a�������������� (DTEPG221)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("APLY_NO", APLY_NO);
        return VOTool.findToMaps(ds, SQL_queryG220List_001);
    }

    /**
     * �f��ץ��s�j�ӥD�ɸ��
     * @param BASE_CD
     * @param DTEPB301VO
     * @param UPD_TIME
     * @throws Exception 
     */
    public void approve(String BASE_CD, DTEPB301 DTEPB301VO, String UPD_TIME) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_003")); //�ǤJ��a�N�����o���ŭ�
        }
        if (DTEPB301VO == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_006")); //�ǤJ�߮׮ץ󤣱o���ŭ�
        }
        if (StringUtils.isBlank(UPD_TIME)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_007")); //�ǤJ���ʤ���ɶ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�d�߲��ʩ���
        Map qryMap = new HashMap();
        qryMap.put("SUB_CPY_ID", DTEPB301VO.getSUB_CPY_ID());
        qryMap.put("BASE_CD", BASE_CD);
        qryMap.put("APLY_NO", DTEPB301VO.getAPLY_NO());
        List<Map> G220List = new EP_Z0G220().queryG220List(qryMap);
        Map<String, List<Map>> g221ListMap = new EP_Z0G221().queryMapList(qryMap);
        String SYS_DT = DATE.getDBDate();

        StringBuilder sb = new StringBuilder();
        BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        Timestamp tTime = DATE.currentTime();
        String EmpID = DTEPB301VO.getINPUT_ID();
        String OpUnit = DTEPB301VO.getINPUT_DIV_NO();
        String EmpName = DTEPB301VO.getINPUT_NAME();
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���
        List<Map> listG210 = new ArrayList();

        List<Map> listG301 = new ArrayList();

        try {
            int batchCount;

            buds.clear();
            buds.preparedBatch(SQL_approve_001);

            batchCount = (G220List.size() / commit_size) + 1;

            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? G220List.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        Map updG220 = G220List.get(j);
                        String key = sb.append(MapUtils.getString(updG220, "SUB_CPY_ID")).append(MapUtils.getString(updG220, "BASE_CD"))
                                .append(MapUtils.getString(updG220, "APLY_NO")).append(MapUtils.getString(updG220, "DEPR_KD")).toString();
                        sb.setLength(0);
                        List<Map> g221List = g221ListMap.get(key);
                        for (Map updG221 : g221List) {
                            String DEPR_KD = MapUtils.getString(updG221, "DEPR_KD");
                            BigDecimal COST_AMT = STRING.objToBigDecimal(updG221.get("COST_AMT"), BigDecimal.ZERO);
                            BigDecimal LOSS_AMT = STRING.objToBigDecimal(updG221.get("LOSS_AMT"), BigDecimal.ZERO);
                            BigDecimal D_COST_AMT = STRING.objToBigDecimal(updG221.get("D_COST_AMT"), BigDecimal.ZERO);
                            BigDecimal D_LOSS_AMT = STRING.objToBigDecimal(updG221.get("D_LOSS_AMT"), BigDecimal.ZERO);

                            Map G301Map = new HashMap();
                            G301Map.put("SUB_CPY_ID", updG221.get("SUB_CPY_ID"));
                            G301Map.put("BASE_CD", updG221.get("BASE_CD"));
                            G301Map.put("COST_SEQ", updG221.get("COST_SEQ"));
                            G301Map.put("DEPR_KD", updG221.get("DEPR_KD"));
                            G301Map.put("CAL_DT", SYS_DT);
                            G301Map.put("DEPR_YM", BigDecimal.ZERO);
                            G301Map.put("KIND", updG221.get("KIND"));
                            G301Map.put("IFRS_INV_RT", updG221.get("IFRS_INV_RT"));
                            G301Map.put("ITEM_NO", updG221.get("ITEM_NO"));
                            G301Map.put("SUB_ITEM_NO", updG221.get("SUB_ITEM_NO"));
                            G301Map.put("COST_DT", updG221.get("COST_DT"));
                            G301Map.put("LOSS_AMT", LOSS_AMT.subtract(D_LOSS_AMT));
                            G301Map.put("DEPR_YR", updG221.get("DEPR_YR"));
                            G301Map.put("FST_YR_MON", updG221.get("FST_YR_MON"));
                            G301Map.put("TOT_DERP_MON", BigDecimal.ZERO);
                            G301Map.put("LY_DEPR_MON", BigDecimal.ZERO);
                            BigDecimal UPD_COST_AMT;
                            if ("2".equals(DEPR_KD)) {
                                UPD_COST_AMT = COST_AMT.subtract(D_COST_AMT).subtract(LOSS_AMT.subtract(D_LOSS_AMT));
                            } else {
                                UPD_COST_AMT = COST_AMT.subtract(D_COST_AMT);
                            }
                            G301Map.put("COST_AMT", UPD_COST_AMT);

                            G301Map.put("COST_AMT_INV", STRING.objToBigDecimal(updG221.get("COST_AMT_INV"), BigDecimal.ZERO).subtract(
                                STRING.objToBigDecimal(updG221.get("D_COST_AMT_INV"), BigDecimal.ZERO)));
                            G301Map.put("COST_AMT_SLF", STRING.objToBigDecimal(updG221.get("COST_AMT_SLF"), BigDecimal.ZERO).subtract(
                                STRING.objToBigDecimal(updG221.get("D_COST_AMT_SLF"), BigDecimal.ZERO)));

                            G301Map.put("LY_DEPR", STRING.objToBigDecimal(updG221.get("LY_DEPR"), BigDecimal.ZERO).subtract(
                                STRING.objToBigDecimal(updG221.get("D_LY_DEPR"), BigDecimal.ZERO)));

                            G301Map.put("DEPR_AMT", STRING.objToBigDecimal(updG221.get("DEPR_AMT"), BigDecimal.ZERO).subtract(
                                STRING.objToBigDecimal(updG221.get("D_DEPR_AMT"), BigDecimal.ZERO)));

                            G301Map.put("DEPR_AMT_INV", STRING.objToBigDecimal(updG221.get("DEPR_AMT_INV"), BigDecimal.ZERO).subtract(
                                STRING.objToBigDecimal(updG221.get("D_DEPR_AMT_INV"), BigDecimal.ZERO)));

                            G301Map.put("DEPR_AMT_SLF", STRING.objToBigDecimal(updG221.get("DEPR_AMT_SLF"), BigDecimal.ZERO).subtract(
                                STRING.objToBigDecimal(updG221.get("D_DEPR_AMT_SLF"), BigDecimal.ZERO)));

                            G301Map.put("YR_DEPR", STRING.objToBigDecimal(updG221.get("YR_DEPR"), BigDecimal.ZERO).subtract(
                                STRING.objToBigDecimal(updG221.get("D_YR_DEPR"), BigDecimal.ZERO)));

                            G301Map.put("YR_DEPR_INV", STRING.objToBigDecimal(updG221.get("YR_DEPR_INV"), BigDecimal.ZERO).subtract(
                                STRING.objToBigDecimal(updG221.get("D_YR_DEPR_INV"), BigDecimal.ZERO)));

                            G301Map.put("YR_DEPR_SLF", STRING.objToBigDecimal(updG221.get("YR_DEPR_SLF"), BigDecimal.ZERO).subtract(
                                STRING.objToBigDecimal(updG221.get("D_YR_DEPR_SLF"), BigDecimal.ZERO)));

                            G301Map.put("UN_DERP", UPD_COST_AMT.subtract(STRING.objToBigDecimal(updG221.get("DEPR_AMT"), BigDecimal.ZERO)
                                    .subtract(STRING.objToBigDecimal(updG221.get("D_DEPR_AMT"), BigDecimal.ZERO))));

                            BigDecimal COST_BAS = STRING.objToBigDecimal(updG221.get("COST_AMT"), BigDecimal.ZERO);
                            if ("2".equals(DEPR_KD)) {
                                COST_BAS = COST_BAS.subtract(STRING.objToBigDecimal(updG221.get("LOSS_AMT"), BigDecimal.ZERO));
                            }
                            G301Map.put("BAS_DT", updG221.get("CAL_DT"));
                            G301Map.put("COST_BAS", COST_BAS);
                            G301Map.put("COST_INV_BAS", updG221.get("COST_AMT_INV"));

                            G301Map.put("COST_SLF_BAS", updG221.get("COST_AMT_SLF"));

                            G301Map.put("COST_ADJ", UPD_COST_AMT.subtract(COST_BAS));

                            G301Map.put("COST_INV_ADJ", BigDecimal.ZERO.subtract(STRING.objToBigDecimal(updG221.get("D_COST_AMT_INV"),
                                BigDecimal.ZERO)));
                            G301Map.put("COST_SLF_ADJ", BigDecimal.ZERO.subtract(STRING.objToBigDecimal(updG221.get("D_COST_AMT_SLF"),
                                BigDecimal.ZERO)));

                            G301Map.put("DEPR_BAS", updG221.get("DEPR_AMT"));
                            G301Map.put("DEPR_INV_BAS", updG221.get("DEPR_AMT_INV"));
                            G301Map.put("DEPR_SLF_BAS", updG221.get("DEPR_AMT_SLF"));
                            G301Map.put("DEPR_ADJ", updG221.get("D_DEPR_AMT"));
                            G301Map.put("DEPR_INV_ADJ", BigDecimal.ZERO.subtract(STRING.objToBigDecimal(updG221.get("D_DEPR_AMT_INV"),
                                BigDecimal.ZERO)));
                            G301Map.put("DEPR_SLF_ADJ", BigDecimal.ZERO.subtract(STRING.objToBigDecimal(updG221.get("D_DEPR_AMT_SLF"),
                                BigDecimal.ZERO)));
                            G301Map.put("CHG_DATE", tTime);
                            G301Map.put("CHG_DIV_NO", OpUnit);
                            G301Map.put("CHG_ID", EmpID);
                            G301Map.put("CHG_NAME", EmpName);

                            listG301.add(G301Map);

                            //��s������������
                            if ("2".equals(DEPR_KD) || "3".equals(DEPR_KD)) {
                                Map G210Map = new HashMap();
                                G210Map.put("SUB_CPY_ID", updG221.get("SUB_CPY_ID"));
                                G210Map.put("BASE_CD", updG221.get("BASE_CD"));
                                G210Map.put("COST_SEQ", updG221.get("COST_SEQ"));
                                G210Map.put("COST_AMT", COST_AMT.subtract(D_COST_AMT));
                                G210Map.put("LOSS_AMT", LOSS_AMT.subtract(D_LOSS_AMT));
                                G210Map.put("IFRS_INV_RT", updG221.get("IFRS_INV_RT"));

                                G210Map.put("UPD_APLY_NO", updG221.get("APLY_NO"));
                                G210Map.put("CAL_DT", SYS_DT);
                                G210Map.put("CAL_DT_LS", SYS_DT);
                                G210Map.put("CHG_DATE", tTime);
                                G210Map.put("CHG_DIV_NO", OpUnit);
                                G210Map.put("CHG_ID", EmpID);
                                G210Map.put("CHG_NAME", EmpName);
                                listG210.add(G210Map);
                            }
                        }

                        //��s����R�P�B�z�X

                        buds.setField("SUB_CPY_ID", updG220.get("SUB_CPY_ID"));
                        buds.setField("BASE_CD", updG220.get("BASE_CD"));
                        buds.setField("APLY_NO", updG220.get("APLY_NO"));
                        buds.setField("DEPR_KD", updG220.get("DEPR_KD"));
                        buds.setField("D_COST_CD", "2");
                        buds.setField("D_COST_DATE", tTime);
                        buds.setField("D_COST_DIV_NO", OpUnit);
                        buds.setField("D_COST_ID", EmpID);
                        buds.setField("D_COST_NAME", EmpName);
                        buds.addBatch();

                    }

                    buds.executeBatch();
                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap,
                                (Exception) theErrorObject[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException(MessageUtil.getMessage("��s��Ʀ��~"));//�s�W��Ʀ��~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException(e);//�妸�s�W����
                }
            }//end 

        } finally {
            if (buds != null) {
                buds.close();
            }
        }
        //�s�W���§�s���G
        new EP_Z0G301().batchInsert(listG301);

        //��s���������B�z���A�X
        new EP_Z0G210().batchUpdate(listG210);

        EPG3_B100 theEPG3_B100 = new EPG3_B100();
        for (Map upd : G220List) {
            theEPG3_B100.createG300(MapUtils.getString(upd, "SUB_CPY_ID"), MapUtils.getString(upd, "BASE_CD"), MapUtils.getString(upd,
                "DEPR_KD"), SYS_DT, MapUtils.getString(upd, "DEPR_YM"), EmpID, EmpName, OpUnit);
        }

    }

    /**
     * Ū������R�P��T�M��
     * @param SUB_CPY_ID
     * @param BASE_CD
     * @return
     * @throws ModuleException
     */
    public String getDAplyNo(String SUB_CPY_ID, String BASE_CD, int chkCnt) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_002")); //�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_003")); //�ǤJ��a�N�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�߮ץ�_��a�������������� (DTEPG221)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_getDAplyNo_001, false);
        if (rtnList != null) {
            if (chkCnt > 0 && chkCnt != rtnList.size()) {
                return "";
            } else {
                return MapUtils.getString(rtnList.get(0), "APLY_NO");
            }
        } else {
            return "";
        }
    }

    /**
     * Ū������R�P��T
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryMap(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;

        String DEPR_KD = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");

            DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_003")); //�ǤJ��a�N�����o���ŭ�
            }

            if (StringUtils.isBlank(DEPR_KD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_005")); //�ǤJ�������O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�߮ץ�_��a�������������� (DTEPG221)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        setFieldIfExist(ds, "BASE_CD", BASE_CD);
        setFieldIfExist(ds, reqMap, "APLY_NO");
        setFieldIfExist(ds, "DEPR_KD", DEPR_KD);
        return VOTool.findOneToMap(ds, SQL_queryMap_001);
    }

    /**
     * �s�W��������R�P����
     * @param sumMap
     * @throws ModuleException
     */
    public void insert(Map sumMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;

        if (sumMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(sumMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", sumMap.get("BASE_CD"));
        ds.setField("APLY_NO", sumMap.get("APLY_NO"));
        ds.setField("DEPR_KD", sumMap.get("DEPR_KD"));
        ds.setField("TRN_DATE", sumMap.get("TRN_DATE"));
        ds.setField("IFRS_INV_RT", sumMap.get("IFRS_INV_RT"));
        ds.setField("TOT_LND_AREA", sumMap.get("TOT_LND_AREA"));
        ds.setField("D_LND_AREA", sumMap.get("D_LND_AREA"));
        ds.setField("TOT_LND_COST", sumMap.get("TOT_LND_COST"));
        ds.setField("D_LND_COST", sumMap.get("D_LND_COST"));
        ds.setField("SUM_D_LND_LOSS", sumMap.get("SUM_D_LND_LOSS"));
        ds.setField("TOT_BLD_AREA", sumMap.get("TOT_BLD_AREA"));
        ds.setField("D_BLD_AREA", sumMap.get("D_BLD_AREA"));
        ds.setField("TOT_BLD_COST", sumMap.get("TOT_BLD_COST"));
        ds.setField("D_BLD_COST", sumMap.get("D_BLD_COST"));
        ds.setField("SUM_D_BLD_LOSS", sumMap.get("SUM_D_BLD_LOSS"));
        ds.setField("TOT_DEPR_AMT", sumMap.get("TOT_DEPR_AMT"));
        ds.setField("SUM_D_DEPR_AMT", sumMap.get("SUM_D_DEPR_AMT"));
        ds.setField("SUM_CUR_DEPR", sumMap.get("SUM_CUR_DEPR"));
        ds.setField("CHG_DATE", sumMap.get("CHG_DATE"));
        ds.setField("CHG_DIV_NO", sumMap.get("CHG_DIV_NO"));
        ds.setField("CHG_ID", sumMap.get("CHG_ID"));
        ds.setField("CHG_NAME", sumMap.get("CHG_NAME"));
        ds.setField("D_COST_CD", "1");//�ݳB�z�A����X����Ю֮ɧ�s
        ds.setField("D_COST_DATE", sumMap.get("D_COST_DATE"));
        ds.setField("D_COST_DIV_NO", sumMap.get("D_COST_DIV_NO"));
        ds.setField("D_COST_ID", sumMap.get("D_COST_ID"));
        ds.setField("D_COST_NAME", sumMap.get("D_COST_NAME"));
        DBUtil.executeUpdate(ds, SQL_insert_001);

    }

    /**
     * ������������R�P����
     * @param reqMap
     * @throws ModuleException
     */
    public void delete(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        String APLY_NO = null;
        String DEPR_KD = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_003")); //�ǤJ��a�N�����o���ŭ�
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_004")); //�ǤJ�ץ�s�����o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_KD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G220_MSG_005")); //�ǤJ�������O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("DEPR_KD", DEPR_KD);
        DBUtil.executeUpdate(ds, SQL_delete_001);
    }

    /**
     * dataset ��
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, Map tmpMap, String key) {
        String value = MapUtils.getString(tmpMap, key);
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }

    }

    /**
     * dataset ��
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
