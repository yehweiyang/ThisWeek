package com.cathay.ep.z0.module;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPC303;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �״ڬ������@�Ҳ�(�qEP_C30020�h���L��)
 * </pre>
 * @author ����[
 * @since 2015/3/27
 */
@SuppressWarnings("unchecked")
public class EP_Z0C303 {
    private static final Logger log = Logger.getLogger(EP_Z0C303.class);

    private static final String SQL_deleteByRmtSetNo_001 = "com.cathay.ep.z0.module.EP_Z0C303.SQL_deleteByRmtSetNo_001";

    private static final String SQL_insertRmtInfo_001 = "com.cathay.ep.z0.module.EP_Z0C303.SQL_insertRmtInfo_001";

    private EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();

    private EP_Z00030 theEP_Z00030 = new EP_Z00030();

    /**
     * �s�W�״ڳ���Ӹ�T
     * @param RMT_INFO_LIST �״ڳ���Ӹ�T�M��
     * @param user �ϥΪ̸�T
     * @return �״ڳ�ո�
     * @throws ModuleException
     */
    public String insertRmtInfo(List<Map> RMT_INFO_LIST, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (RMT_INFO_LIST == null || RMT_INFO_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_008"));//�״ڳ���Ӹ�T�M�椣�o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_009"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        //���o�����q�O
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);

        String EmpID = user.getEmpID();
        String EmpName = user.getEmpName();
        //�v���B�z�ǤJ.RMT_INFO_LIST

        for (Map map : RMT_INFO_LIST) {
            //����DBEP.DTEPC303�״ڳ�����ɮ榡
            DTEPC303 DTEPC303_VO = new DTEPC303();
            String RMT_DATE = MapUtils.getString(map, "RMT_DATE");
            DTEPC303_VO.setRMT_NO(this.getRmtNo(SUB_CPY_ID, RMT_DATE));//�״ڽs��
            DTEPC303_VO.setSUB_CPY_ID(SUB_CPY_ID);//�����q�O
            DTEPC303_VO.setBANK_NO(MapUtils.getString(map, "BANK_NO"));//��w�N��
            DTEPC303_VO.setACNT_NO(MapUtils.getString(map, "ACNT_NO"));//�Ȧ�b��
            DTEPC303_VO.setRMT_DATE(DATE.isDate(RMT_DATE) ? Date.valueOf(RMT_DATE) : null);//�״ڤ�� 
            DTEPC303_VO.setRMT_SET_NO(this.getRmtSetNo(SUB_CPY_ID, map));//�״ڲո�
            DTEPC303_VO.setRMT_AMT(Integer.valueOf(MapUtils.getString(map, "TRN_AMT")));//�״ڪ��B
            DTEPC303_VO.setCEPSTCD(MapUtils.getString(map, "POST_NO"));//�l������
            DTEPC303_VO.setCEMALAM(0);//�l�O
            DTEPC303_VO.setINPUT_ID(EmpID);//��J�H��ID
            DTEPC303_VO.setINPUT_NAME(EmpName);//��J�H���m�W

            //�s�WDBEP.DTEPC303�״ڳ������,�NDTEPC303_VO�g�iDBEP.DTEPC303
            try {
                VOTool.insert(DTEPC303_VO);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_010"));//�g�J�״ڳ�����ɦ��~
            }
        }

        return (String) RMT_INFO_LIST.get(0).get("RMT_SET_NO");
    }

    /**
     * �妸�s�W�״ڳ���Ӹ�T
     * @param RMT_INFO_LIST
     * @param user
     * @return
     * @throws DBException 
     * @throws ModuleException 
     */
    public String insertRmtInfo(List<Map> RMT_INFO_LIST, UserObject user, BatchUpdateDataSet buds) throws DBException, ModuleException {
        if (RMT_INFO_LIST == null || RMT_INFO_LIST.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C303_MSG_003"));//�ǤJ�״ڲո����i����
        }

        //���o�����q�O
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);

        String EmpID = user.getEmpID();
        String EmpName = user.getEmpName();

        //�妸
        //�]XAMode:buds�ѥD�{���ǤJ
        //BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        buds.preparedBatch(SQL_insertRmtInfo_001);
        try {

            for (Map map : RMT_INFO_LIST) {

                //���o�״ڤ��
                String RMT_DATE = MapUtils.getString(map, "RMT_DATE");
                //���o�״ڽs��
                buds.setField("RMT_NO", this.getRmtNo(SUB_CPY_ID, RMT_DATE));
                buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                buds.setField("BANK_NO", map.get("BANK_NO"));
                buds.setField("ACNT_NO", map.get("ACNT_NO"));
                buds.setField("RMT_DATE", DATE.isDate(RMT_DATE) ? Date.valueOf(RMT_DATE) : null);
                buds.setField("RMT_SET_NO", this.getRmtSetNo(SUB_CPY_ID, map));
                buds.setField("RMT_AMT", map.get("TRN_AMT"));
                buds.setField("CEPSTCD", map.get("POST_NO"));
                buds.setField("CEMALAM", "0");
                buds.setField("INPUT_ID", EmpID);
                buds.setField("INPUT_NAME", EmpName);
                buds.addBatch();
            }
            // ���s�W�j�Ӳ���LOG
            buds.executeBatch();
            Object theErrorObject[][] = buds.getBatchUpdateErrorArray();

            if (theErrorObject.length > 0) {
                for (int k = 0; k < theErrorObject.length; k++) {
                    Map errorDataMap = (Map) theErrorObject[k][1];
                    log.error("�g�J�״ڳ�����ɲ�" + (Exception) theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap.toString(),
                        (Exception) theErrorObject[k][2]);
                }
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C303_MSG_001"));// �g�J�״ڳ�����ɦ��~
            }
        } catch (Exception e) {
            log.error(e, e);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C303_MSG_001"));// �g�J�״ڳ�����ɦ��~
        }
        return MapUtils.getString(RMT_INFO_LIST.get(0), "RMT_SET_NO");
    }

    /**
     * �̶״ڲո��R���״ک���
     * @param RMT_SET_NO
     * @throws ModuleException
     */
    public void deleteByRmtSetNo(String RMT_SET_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(RMT_SET_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C303_MSG_003"));//�ǤJ�״ڲո����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }

        //�R���״ک���BY�״ڲո�
        DataSet ds = Transaction.getDataSet();

        ds.setField("RMT_SET_NO", RMT_SET_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_deleteByRmtSetNo_001);
        } catch (ModuleException e) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C303_MSG_002", new Object[] { RMT_SET_NO }));//"�R���״ڳ������BY�״ڲո����~,�״ڲո�={0}"
        }
    }

    /** 
     * ���o�״ڽs��
     * @param SUB_CPY_ID �����q�O
     * @param RMT_DATE �״ڤ��
     * @return �״ڽs��
     * @throws ModuleException
     */
    public String getRmtNo(String SUB_CPY_ID, String RMT_DATE) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o����
        }
        if (StringUtils.isBlank(RMT_DATE) || !DATE.isDate(RMT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_003"));//�״ڤ�����o���ũΤ��Ť���榡
        }
        if (eie != null) {
            throw eie;
        }

        //���o�y���Ǹ�
        String sRMT_DATE = RMT_DATE.replaceAll("-", "");
        int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "025", sRMT_DATE, "1");
        //�榡�ƶ״ڽs�� ,SER_NO�e��0��4�X
        String SER_NO_S = STRING.fillZero(Integer.toString(SER_NO), 4);

        return new StringBuilder().append(SUB_CPY_ID).append(sRMT_DATE).append(SER_NO_S).toString();
    }

    /** 
     * ���o�״ڲո�
     * @param SUB_CPY_ID �����q�O
     * @param RMT_DATE �״ڤ��
     * @return �״ڽs��
     * @throws ModuleException
     */
    public String getRmtSetNo(String SUB_CPY_ID, Map map) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o����
        }
        if (eie != null) {
            throw eie;
        }

        String RMT_SET_NO = MapUtils.getString(map, "RMT_SET_NO");
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
            if (StringUtils.isBlank(RMT_SET_NO)) {
                throw new ModuleException("�״ڲո����i����");
            }
            return RMT_SET_NO;
        }
        if (StringUtils.isBlank(RMT_SET_NO)) {
            RMT_SET_NO = theEP_Z0Z001.createNextNo(SUB_CPY_ID, "029", "RMT_SET_NO", DATE.getY2KYear(DATE.getDBDate()), SUB_CPY_ID
                    + DATE.getY2KYear(DATE.getDBDate()).substring(2, 4), 6);
            map.put("RMT_SET_NO", RMT_SET_NO);
        }
        return RMT_SET_NO;
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

}
