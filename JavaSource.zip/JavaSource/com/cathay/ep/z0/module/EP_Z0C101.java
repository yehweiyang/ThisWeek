package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPC101;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014-11-24  Created ������
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �����ɺ��@�Ҳ�
 * �Ҳ�ID    EP_Z0C101
 * ���n����    SQL�����ɼҲ�
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0C101 {
    private static final Logger log = Logger.getLogger(EP_Z0C101.class);

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_insert_001";

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_queryList_001";

    private static final String SQL_confirm_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_confirm_001";

    private static final String SQL_cancelConfirmAcnt_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_cancelConfirmAcnt_001";

    private static final String SQL_failInvoice_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_failInvoice_001";

    private static final String SQL_cancelConfirm_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_cancelConfirm_001";

    private static final String SQL_aprvConfirm_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_aprvConfirm_001";

    private static final String SQL_confirmAcnt_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_confirmAcnt_001";

    private static final String SQL_cancelConfirmAcnt_002 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_cancelConfirmAcnt_002";

    private static final String SQL_queryRcvMap_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_queryRcvMap_001";

    private static final String SQL_updateRcvSprAmtBatch_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_updateRcvSprAmtBatch_001";

    private static final String SQL_queryRentFreeList_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_queryRentFreeList_001";

    private static final String SQL_adjRentFreeList_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_adjRentFreeList_001";

    private static final String SQL_updateSPR_AMTbyC304003 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_updateSPR_AMTbyC304003";

    private static final String SQL_updateInvNo_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_updateInvNo_001";

    private static final String SQL_aprvConfirm_002 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_aprvConfirm_002";

    private static final String SQL_qryMaxPayEDateByCrtNo_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_qryMaxPayEDateByCrtNo_001";

	private static final String SQL_queryC101forC307_001 = "com.cathay.ep.z0.module.EP_Z0C101.SQL_queryC101forC307_001";

    /**
     * �s�W��������
     * @param voC101
     * @throws ModuleException
     */
    public void insert(DTEPC101 voC101) throws ModuleException {
        if (voC101 == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_001"));//�����ɩ��Ӥ��o����
        }
        //�]�w�f��i�סG
        voC101.setOP_STATUS(Integer.valueOf(this.getStartOpStatus("EPC1_0002")));
        //voC101.setFLOW_NO("");
        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_NO", voC101.getRCV_NO());
        ds.setField("SUB_CPY_ID", voC101.getSUB_CPY_ID());
        ds.setField("RCV_YM", voC101.getRCV_YM());
        ds.setField("PAY_KIND", voC101.getPAY_KIND());
        ds.setField("CRT_NO", voC101.getCRT_NO());
        ds.setField("CUS_NO", voC101.getCUS_NO());
        ds.setField("PAY_S_DATE", voC101.getPAY_S_DATE());
        ds.setField("PAY_E_DATE", voC101.getPAY_E_DATE());
        ds.setField("ID", voC101.getID());
        ds.setField("CUS_NAME", voC101.getCUS_NAME());
        ds.setField("DIV_NO", voC101.getDIV_NO());
        ds.setField("BLD_CD", voC101.getBLD_CD());
        ds.setField("BLD_USR_ID", voC101.getBLD_USR_ID());
        ds.setField("BLD_USR_NAME", voC101.getBLD_USR_NAME());
        ds.setField("PAY_CD", voC101.getPAY_CD());
        ds.setField("EXT_DATE", voC101.getEXT_DATE());
        ds.setField("EXT_TYPE", voC101.getEXT_TYPE());
        ds.setField("INV_NO", voC101.getINV_NO());
        ds.setField("INV_AMT", voC101.getINV_AMT());
        ds.setField("SAL_AMT", voC101.getSAL_AMT());
        ds.setField("TAX_AMT", voC101.getTAX_AMT());
        ds.setField("TAX_TYPE", voC101.getTAX_TYPE());
        ds.setField("SPR_AMT", voC101.getSPR_AMT());
        ds.setField("PASS_DAY", voC101.getPASS_DAY());
        ds.setField("PRP_S_DATE", voC101.getPRP_S_DATE());
        ds.setField("RNT_AMT", voC101.getRNT_AMT());
        ds.setField("PRP_AMT", voC101.getPRP_AMT());
        ds.setField("PRP_SP_AMT", voC101.getPRP_SP_AMT());
        ds.setField("RJT_CD", voC101.getRJT_CD());
        ds.setField("ACNT_DATE", voC101.getACNT_DATE());
        ds.setField("ACNT_ID", voC101.getACNT_ID());
        ds.setField("ACNT_NAME", voC101.getACNT_NAME());
        ds.setField("ACNT_DIV_NO", voC101.getACNT_DIV_NO());
        ds.setField("SLIP_LOT_NO", voC101.getSLIP_LOT_NO());
        ds.setField("SLIP_SET_NO", voC101.getSLIP_SET_NO());
        ds.setField("TURN_ACNT_DATE", voC101.getTURN_ACNT_DATE());
        ds.setField("TURN_ID", voC101.getTURN_ID());
        ds.setField("TURN_NAME", voC101.getTURN_NAME());
        ds.setField("TURN_SLPLOT_NO", voC101.getTURN_SLPLOT_NO());
        ds.setField("TURN_SLPSET_NO", voC101.getTURN_SLPSET_NO());
        ds.setField("BDEBT_ACNT_DATE", voC101.getBDEBT_ACNT_DATE());
        ds.setField("BDEBT_ID", voC101.getBDEBT_ID());
        ds.setField("BDEBT_NAME", voC101.getBDEBT_NAME());
        ds.setField("BDEBT_SLPLOT_NO", voC101.getBDEBT_SLPLOT_NO());
        ds.setField("BDEBT_SLPSET_NO", voC101.getBDEBT_SLPSET_NO());
        ds.setField("TRN_KIND", voC101.getTRN_KIND());
        ds.setField("FLOW_NO", "");
        ds.setField("OP_STATUS", voC101.getOP_STATUS());
        ds.setField("LST_PROC_DATE", voC101.getLST_PROC_DATE());
        ds.setField("LST_PROC_ID", voC101.getLST_PROC_ID());
        ds.setField("LST_PROC_DIV", voC101.getLST_PROC_DIV());
        ds.setField("LST_PROC_NAME", voC101.getLST_PROC_NAME());
        ds.setField("FLD_NO", voC101.getFLD_NO());
        ds.setField("ROOM_NO", voC101.getROOM_NO());
        ds.setField("PRK_NO", voC101.getPRK_NO());
        ds.setField("INV_TRANS_TYPE", voC101.getINV_TRANS_TYPE());
        DBUtil.executeUpdate(ds, SQL_insert_001);
    }

    /**
     * �s�W��������
     * @param voC101
     * @throws ModuleException
     */
    public void update(DTEPC101 voC101) throws ModuleException {
        if (voC101 == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_001"));//�����ɩ��Ӥ��o����
        }
        VOTool.update(voC101);
    }

    /**
     * �R����������
     * @param voC101
     * @throws ModuleException
     */
    public void delete(DTEPC101 voC101) throws ModuleException {
        if (voC101 == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_001"));//�����ɩ��Ӥ��o����
        }
        VOTool.delByPK(voC101);
    }

    /**
     * �d������
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_002"));//�b�ȸ�T���o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        //�d�ߤw�b�ȽT�{����������
        DataSet ds = Transaction.getDataSet();
        setFieldIfExist(ds, reqMap, "ACNT_DATE");
        setFieldIfExist(ds, reqMap, "ACNT_DIV_NO");
        setFieldIfExist(ds, reqMap, "SLIP_LOT_NO");
        setFieldIfExist(ds, reqMap, "SLIP_SET_NO");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_queryList_001);
    }

    /**
     * �d������
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryByRcvNo(Map reqMap) throws ModuleException {
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_002"));//�b�ȸ�T���o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_NO", reqMap.get("RCV_NO"));
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findOneToMap(ds, SQL_queryList_001);
    }

    /**
     * �������ӽT�{
     * @param selectList
     * @param user
     * @throws ModuleException
     * @throws DBException 
     */
    public void confirm(List<DTEPC101> selectList, UserObject user) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (selectList == null || selectList.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_003")); //�ǤJ�����ɩ��Ӥ��o����!
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_004")); //�ǤJ�ϥΪ̸�T���o����!
        }
        if (eie != null) {
            throw eie;
        }
        //��s�f��i�סG
        String OLD_OP_STATUS = String.valueOf(selectList.get(0).getOP_STATUS());
        String NEW_OP_STATUS = this.getNextOpStatus("EPC1_0002", OLD_OP_STATUS);
        log.error("====OLD_OP_STATUS==" + OLD_OP_STATUS);

        //UZEP_C10050_�������ӽT�{�Ҳ�
        //�B�z���update
        BatchUpdateDataSet buds = null;
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���
        try {
            int batchCount;
            buds = Transaction.getBatchUpdateDataSet();
            buds.preparedBatch(SQL_confirm_001);
            //��s�ץ�i�� (C101)
            batchCount = (selectList.size() / commit_size) + 1;
            Timestamp tTime = DATE.currentTime();
            String EmpID = user.getEmpID();
            String OpUnit = user.getOpUnit();
            String EmpName = user.getEmpName();
            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? selectList.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        DTEPC101 DTEPC101VO = selectList.get(j);
                        buds.setField("NEW_OP_STATUS", NEW_OP_STATUS);
                        buds.setField("LST_PROC_DATE", tTime);
                        buds.setField("LST_PROC_ID", EmpID);
                        buds.setField("LST_PROC_DIV", OpUnit);
                        buds.setField("LST_PROC_NAME", EmpName);
                        buds.setField("RCV_NO", DTEPC101VO.getRCV_NO());
                        buds.setField("OLD_OP_STATUS", OLD_OP_STATUS);
                        buds.setField("SUB_CPY_ID", DTEPC101VO.getSUB_CPY_ID());
                        buds.setField("TRN_KIND", DTEPC101VO.getTRN_KIND());
                        buds.setField("PAY_CD", DTEPC101VO.getPAY_CD());
                        buds.addBatch();
                    }
                    buds.executeBatch();
                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap, (Exception) theErrorObject[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException("�s�W��Ʀ��~");//�s�W��Ʀ��~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException("�妸�s�W����");//�妸�s�W����
                }
            } //end ��s�ץ�i�� (C101)

        } finally {
            if (buds != null) {
                buds.close();
            }
        }
    }

    /**
     * �������Ө����T�{
     * @param selectList
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void cancelConfirm(List<DTEPC101> selectList, UserObject user) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (selectList == null || selectList.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_003")); //�ǤJ�����ɩ��Ӥ��o����!
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_004")); //�ǤJ�ϥΪ̸�T���o����!
        }
        if (eie != null) {
            throw eie;
        }
        //��s�f��i�סG
        String OLD_OP_STATUS = String.valueOf(selectList.get(0).getOP_STATUS());
        String NEW_OP_STATUS = this.getPreOpStatus("EPC1_0002", OLD_OP_STATUS);

        //�B�z���update
        BatchUpdateDataSet buds = null;
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���
        try {
            int batchCount;
            buds = Transaction.getBatchUpdateDataSet();
            buds.preparedBatch(SQL_cancelConfirm_001);
            //��s�ץ�i�� (C101)
            batchCount = (selectList.size() / commit_size) + 1;
            Timestamp tTime = DATE.currentTime();
            String EmpID = user.getEmpID();
            String OpUnit = user.getOpUnit();
            String EmpName = user.getEmpName();
            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? selectList.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        DTEPC101 C101 = selectList.get(j);
                        buds.setField("NEW_OP_STATUS", NEW_OP_STATUS);
                        buds.setField("SUB_CPY_ID", C101.getSUB_CPY_ID());
                        buds.setField("LST_PROC_DATE", tTime); //�@�~�B�z�ɶ�
                        buds.setField("LST_PROC_ID", EmpID); //�@�~�B�z�H��ID
                        buds.setField("LST_PROC_DIV", OpUnit); //�@�~�B�z���
                        buds.setField("LST_PROC_NAME", EmpName); //�@�~�B�z�H���m�W
                        buds.setField("RCV_NO", C101.getRCV_NO()); //�����s��
                        buds.setField("OLD_OP_STATUS", OLD_OP_STATUS);
                        buds.addBatch();
                    }
                    buds.executeBatch();
                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap, (Exception) theErrorObject[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException("�s�W��Ʀ��~");//�s�W��Ʀ��~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException("�妸�s�W����");//�妸�s�W����
                }
            } //end ��s�ץ�i�� (C101)

        } finally {
            if (buds != null) {
                buds.close();
            }
        }
    }

    /**
     * ���������Ю�
     * @param selectList
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void aprvConfirm(List<DTEPC101> C101List) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (C101List == null || C101List.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_003")); //�ǤJ�����ɩ��Ӥ��o����!
        }
        if (eie != null) {
            throw eie;
        }
        //��s�f��i�סG
        String OLD_OP_STATUS = C101List.get(0).getOP_STATUS().toString();
        String NEW_OP_STATUS = this.getNextOpStatus("EPC1_0002", OLD_OP_STATUS);

        //�B�z���update
        BatchUpdateDataSet buds = null;
        BatchUpdateDataSet budst = null;
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���

        try {
            int batchCount;
            buds = Transaction.getBatchUpdateDataSet();
            budst = Transaction.getBatchUpdateDataSet();

            buds.preparedBatch(SQL_aprvConfirm_001);
            budst.preparedBatch(SQL_aprvConfirm_002);
            //��s�ץ�i�� (C101)
            batchCount = (C101List.size() / commit_size) + 1;

            BatchUpdateDataSet tempbuds = null;

            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? C101List.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        DTEPC101 C101VO = C101List.get(j);

                        if (StringUtils.isNotBlank(C101VO.getINV_NO())) {
                            tempbuds = buds;
                            tempbuds.setField("INV_NO", C101VO.getINV_NO());
                        } else {
                            tempbuds = budst;
                        }
                        tempbuds.setField("NEW_OP_STATUS", NEW_OP_STATUS);
                        tempbuds.setField("TRN_KIND", "EPC018");//�����ЮֽT�{
                        tempbuds.setField("PAY_CD", C101VO.getPAY_CD());
                        tempbuds.setField("LST_PROC_DATE", C101VO.getLST_PROC_DATE()); //�@�~�B�z�ɶ�
                        tempbuds.setField("LST_PROC_ID", C101VO.getLST_PROC_ID()); //�@�~�B�z�H��ID
                        tempbuds.setField("LST_PROC_DIV", C101VO.getLST_PROC_DIV()); //�@�~�B�z���
                        tempbuds.setField("LST_PROC_NAME", C101VO.getLST_PROC_NAME()); //�@�~�B�z�H���m�W
                        tempbuds.setField("RCV_NO", C101VO.getRCV_NO()); //�����s��
                        tempbuds.setField("OLD_OP_STATUS", OLD_OP_STATUS);
                        tempbuds.setField("SUB_CPY_ID", C101VO.getSUB_CPY_ID());
                        tempbuds.addBatch();
                    }
                    buds.executeBatch();
                    budst.executeBatch();

                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    Object theErrorObjectt[][] = budst.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0 || theErrorObjectt.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��Ʀ��~ setField = " + errorDataMap, (Exception) theErrorObject[k][2]);
                        }
                        for (int k = 0; k < theErrorObjectt.length; k++) {
                            Map errorDataMap = (Map) theErrorObjectt[k][1];
                            log.error("��s��Ʀ��~ setField = " + errorDataMap, (Exception) theErrorObjectt[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException("�����Ю֦��~");
                    }

                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException("�����Ю֦��~");
                }
            } //end ��s�ץ�i�� (C101)

        } finally {
            if (buds != null) {
                buds.close();
            }
        }
    }

    /**
     * �������Ө����Ю�
     * @param selectList
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void cancelAprvConfirm(List<Map> selectList, UserObject user) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (selectList == null || selectList.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_003")); //�ǤJ�����ɩ��Ӥ��o����!
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_004")); //�ǤJ�ϥΪ̸�T���o����!
        }
        if (eie != null) {
            throw eie;
        }
        //��s�f��i�סG
        String OLD_OP_STATUS = MapUtils.getString(selectList.get(0), "OP_STATUS");
        String NEW_OP_STATUS = this.getPreOpStatus("EPC1_0002", OLD_OP_STATUS);

        //�B�z���update
        BatchUpdateDataSet buds = null;
        BatchUpdateDataSet budst = null;
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���

        try {
            int batchCount;
            buds = Transaction.getBatchUpdateDataSet();
            budst = Transaction.getBatchUpdateDataSet();

            buds.preparedBatch(SQL_aprvConfirm_001);
            budst.preparedBatch(SQL_aprvConfirm_002);
            //��s�ץ�i�� (C101)
            batchCount = (selectList.size() / commit_size) + 1;
            Timestamp tTime = DATE.currentTime();
            String EmpID = user.getEmpID();
            String OpUnit = user.getOpUnit();
            String EmpName = user.getEmpName();

            BatchUpdateDataSet tempbuds = null;

            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? selectList.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        Map C101Map = selectList.get(j);

                        if (StringUtils.isNotBlank(MapUtils.getString(C101Map, "INV_NO"))) {
                            tempbuds = buds;
                        } else {
                            tempbuds = budst;
                        }

                        tempbuds.setField("NEW_OP_STATUS", NEW_OP_STATUS);
                        tempbuds.setField("TRN_KIND", MapUtils.getString(C101Map, "TRN_KIND"));
                        tempbuds.setField("PAY_CD", MapUtils.getString(C101Map, "PAY_CD"));
                        if (StringUtils.isNotBlank(MapUtils.getString(C101Map, "INV_NO"))) {
                            tempbuds.setField("INV_NO", MapUtils.getString(C101Map, "INV_NO"));
                        }

                        tempbuds.setField("LST_PROC_DATE", tTime); //�@�~�B�z�ɶ�
                        tempbuds.setField("LST_PROC_ID", EmpID); //�@�~�B�z�H��ID
                        tempbuds.setField("LST_PROC_DIV", OpUnit); //�@�~�B�z���
                        tempbuds.setField("LST_PROC_NAME", EmpName); //�@�~�B�z�H���m�W
                        tempbuds.setField("RCV_NO", MapUtils.getString(C101Map, "RCV_NO")); //�����s��
                        tempbuds.setField("OLD_OP_STATUS", OLD_OP_STATUS);
                        tempbuds.setField("SUB_CPY_ID", MapUtils.getString(C101Map, "SUB_CPY_ID"));
                        tempbuds.addBatch();
                    }
                    buds.executeBatch();
                    budst.executeBatch();

                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    Object theErrorObjectt[][] = budst.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0 || theErrorObjectt.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��Ʀ��~ setField = " + errorDataMap, (Exception) theErrorObject[k][2]);
                        }
                        for (int k = 0; k < theErrorObjectt.length; k++) {
                            Map errorDataMap = (Map) theErrorObjectt[k][1];
                            log.error("��s��Ʀ��~ setField = " + errorDataMap, (Exception) theErrorObjectt[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException("�����Ю֦��~");
                    }

                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException("�����Ю֦��~");
                }
            } //end ��s�ץ�i�� (C101)

        } finally {
            if (buds != null) {
                buds.close();
            }
        }
    }

    /**
     * �������ӱb�ȽT�{
     * @param selectList
     * @param acntMap
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void confirmAcnt(List<Map> selectList, Map acntMap, UserObject user) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (selectList == null || selectList.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_003")); //�ǤJ�����ɩ��Ӥ��o����!
        }
        if (acntMap == null || acntMap.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_002")); //�b�ȸ�T���o����!
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_004")); //�ǤJ�ϥΪ̸�T���o����!
        }
        if (eie != null) {
            throw eie;
        }
        //��s�f��i�סG
        String OLD_OP_STATUS = MapUtils.getString(selectList.get(0), "OP_STATUS");
        String NEW_OP_STATUS = this.getNextOpStatus("EPC1_0002", OLD_OP_STATUS);

        //�B�z���update
        BatchUpdateDataSet buds = null;
        try {
            buds = Transaction.getBatchUpdateDataSet();
            //�p����妸��
            int commit_size = 200; //�@��200���i�H�ݨD���ܵ���

            int batchCount;

            buds.clear();

            buds.preparedBatch(SQL_confirmAcnt_001);
            //��s�ץ�i�� (C101)
            batchCount = (selectList.size() / commit_size) + 1;
            Timestamp tTime = DATE.currentTime();
            String EmpID = user.getEmpID();
            String OpUnit = user.getOpUnit();
            String EmpName = user.getEmpName();
            String SUB_CPY_ID = MapUtils.getString(acntMap, "SUB_CPY_ID");
            String ACNT_DATE = MapUtils.getString(acntMap, "ACNT_DATE");
            String ACNT_DIV_NO = MapUtils.getString(acntMap, "ACNT_DIV_NO");
            String SLIP_LOT_NO = MapUtils.getString(acntMap, "SLIP_LOT_NO");
            String SLIP_SET_NO = MapUtils.getString(acntMap, "SlipSetNo");
            String UserTrnSerno = MapUtils.getString(acntMap, "UserTrnSerno");
            String ACNT_ID = MapUtils.getString(acntMap, "ACNT_ID");
            String ACNT_NAME = MapUtils.getString(acntMap, "ACNT_NAME");
            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? selectList.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        Map C101Map = selectList.get(j);
                        buds.setField("NEW_OP_STATUS", NEW_OP_STATUS);
                        buds.setField("TRN_KIND", MapUtils.getString(C101Map, "TRN_KIND"));
                        buds.setField("ACNT_DATE", ACNT_DATE);
                        buds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
                        buds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
                        buds.setField("SLIP_SET_NO", SLIP_SET_NO);
                        buds.setField("UserTrnSerno", UserTrnSerno);
                        buds.setField("ACNT_ID", ACNT_ID);
                        buds.setField("ACNT_NAME", ACNT_NAME);
                        buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                        buds.setField("LST_PROC_DATE", tTime); //�@�~�B�z�ɶ�
                        buds.setField("LST_PROC_ID", EmpID); //�@�~�B�z�H��ID
                        buds.setField("LST_PROC_DIV", OpUnit); //�@�~�B�z���
                        buds.setField("LST_PROC_NAME", EmpName); //�@�~�B�z�H���m�W
                        buds.setField("RCV_NO", MapUtils.getString(C101Map, "RCV_NO"));//�����s��
                        buds.setField("OLD_OP_STATUS", OLD_OP_STATUS);
                        buds.addBatch();
                    }
                    buds.executeBatch();
                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap, (Exception) theErrorObject[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException(MessageUtil.getMessage("EP_Z0C101_MSG_006"));//�b�ȸ�T�^�����������ɦ��~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException(MessageUtil.getMessage("EP_Z0C101_MSG_006"));//�b�ȸ�T�^�����������ɦ��~
                }
            } //end ��s�ץ�i�� (C101)

        } finally {
            if (buds != null) {
                buds.close();
            }
        }

    }

    /**
     * �������Ө����T�{
     * @param selectList
     * @param acntMap
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void cancelConfirmAcnt(List<DTEPC101> selectList, Map acntMap, UserObject user) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (selectList == null || selectList.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_003")); //�ǤJ�����ɩ��Ӥ��o����!
        }
        if (acntMap == null || acntMap.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_002")); //�b�ȸ�T���o����!
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_004")); //�ǤJ�ϥΪ̸�T���o����!
        }
        if (eie != null) {
            throw eie;
        }
        //��s�f��i�סG
        String OLD_OP_STATUS = String.valueOf(selectList.get(0).getOP_STATUS());
        String NEW_OP_STATUS = this.getPreOpStatus("EPC1_0002", OLD_OP_STATUS);

        //�B�z���update
        BatchUpdateDataSet buds = null;
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���

        try {
            buds = Transaction.getBatchUpdateDataSet();
            int batchCount;

            buds.clear();
            buds.preparedBatch(SQL_cancelConfirmAcnt_002);
            //��s�ץ�i�� (C101)
            batchCount = (selectList.size() / commit_size) + 1;
            Timestamp tTime = DATE.currentTime();
            String EmpID = user.getEmpID();
            String OpUnit = user.getOpUnit();
            String EmpName = user.getEmpName();
            String SUB_CPY_ID = MapUtils.getString(acntMap, "SUB_CPY_ID");
            String ACNT_DATE = MapUtils.getString(acntMap, "ACNT_DATE");
            String ACNT_DIV_NO = MapUtils.getString(acntMap, "ACNT_DIV_NO");
            String SLIP_LOT_NO = MapUtils.getString(acntMap, "SLIP_LOT_NO");
            String SLIP_SET_NO = MapUtils.getString(acntMap, "SLIP_SET_NO");
            String UserTrnSerno = MapUtils.getString(acntMap, "UserTrnSerno");
            String ACNT_ID = MapUtils.getString(acntMap, "ACNT_ID");
            String ACNT_NAME = MapUtils.getString(acntMap, "ACNT_NAME");
            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? selectList.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        DTEPC101 C101 = selectList.get(j);
                        buds.setField("NEW_OP_STATUS", NEW_OP_STATUS);
                        buds.setField("TRN_KIND", C101.getTRN_KIND());
                        buds.setField("ACNT_DATE", ACNT_DATE);
                        buds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
                        buds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
                        buds.setField("SLIP_SET_NO", SLIP_SET_NO);
                        buds.setField("UserTrnSerno", UserTrnSerno);
                        buds.setField("ACNT_ID", ACNT_ID);
                        buds.setField("ACNT_NAME", ACNT_NAME);
                        buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                        buds.setField("LST_PROC_DATE", tTime); //�@�~�B�z�ɶ�
                        buds.setField("LST_PROC_ID", EmpID); //�@�~�B�z�H��ID
                        buds.setField("LST_PROC_DIV", OpUnit); //�@�~�B�z���
                        buds.setField("LST_PROC_NAME", EmpName); //�@�~�B�z�H���m�W
                        buds.setField("RCV_NO", C101.getRCV_NO()); //�����s��
                        buds.setField("OLD_OP_STATUS", OLD_OP_STATUS);
                        buds.addBatch();
                    }
                    buds.executeBatch();
                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap, (Exception) theErrorObject[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException("��s�����ɪ��A���~");
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException("��s�����ɪ��A���~");
                }
            } //end ��s�ץ�i�� (C101)

        } finally {
            if (buds != null) {
                buds.close();
            }
        }
    }

    /**
     * ���������b�ȽT�{
     * @param reqMap
     * @throws ModuleException
     */
    public void cancelConfirmAcnt(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_002"));//�b�ȸ�T���o����
        }
        //�d�ߤw�b�ȽT�{����������
        Map qryMap = new HashMap();
        String ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
        String ACNT_DIV_NO = MapUtils.getString(reqMap, "ACNT_DIV_NO");
        String SLIP_LOT_NO = MapUtils.getString(reqMap, "SLIP_LOT_NO");
        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        qryMap.put("ACNT_DATE", ACNT_DATE);
        qryMap.put("ACNT_DIV_NO", ACNT_DIV_NO);
        qryMap.put("SLIP_LOT_NO", SLIP_LOT_NO);
        qryMap.put("SLIP_SET_NO", SLIP_SET_NO);
        qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> DTEPC101_VO_List = this.queryList(qryMap);
        //��s�f��i�סG
        String OLD_OP_STATUS = MapUtils.getString(DTEPC101_VO_List.get(0), "OP_STATUS");
        String NEW_OP_STATUS = this.getPreOpStatus("EPC1_0002", OLD_OP_STATUS);
        DataSet ds = Transaction.getDataSet();
        ds.setField("NEW_OP_STATUS", NEW_OP_STATUS); //�f�ֶi��3:�w�X�b
        ds.setField("LST_PROC_DATE", reqMap.get("LST_PROC_DATE")); //�@�~�B�z�ɶ�
        ds.setField("LST_PROC_ID", reqMap.get("LST_PROC_ID")); //�@�~�B�z�H��ID
        ds.setField("LST_PROC_DIV", reqMap.get("LST_PROC_DIV")); //�@�~�B�z���
        ds.setField("LST_PROC_NAME", reqMap.get("LST_PROC_NAME")); //�@�~�B�z�H���m�W
        ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
        ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_cancelConfirmAcnt_001);

    }

    /**
     * �q�l�o��:�o���}�߫�^���o�����X
     * @param List<Map> C101List
     * @param UserObject user
     * @throws ModuleException
     * @throws DBException 
     */
    public void updateInvNo(List<Map> C101List, UserObject user) throws ModuleException, DBException {

        ErrorInputException eie = null;
        if (C101List == null || C101List.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_027")); //������Ƥ��o����
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_004")); //�ǤJ�ϥΪ̸�T���o����!
        }
        if (eie != null) {
            throw eie;
        }

        String LST_PROC_ID = user.getEmpID();
        String LST_PROC_DIV = user.getOpUnit();
        String LST_PROC_NAME = user.getEmpName();

        //�B�z���update
        BatchUpdateDataSet buds = null;
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���
        try {
            int batchCount;
            buds = Transaction.getBatchUpdateDataSet();
            buds.preparedBatch(SQL_updateInvNo_001);
            //��s�ץ�i�� (C101)
            batchCount = (C101List.size() / commit_size) + 1;
            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? C101List.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        Map rtnMap = C101List.get(j);

                        buds.setField("LST_PROC_DATE", DATE.currentTime()); //�@�~�B�z�ɶ�
                        buds.setField("INV_NO", MapUtils.getString(rtnMap, "INV_NO"));
                        buds.setField("RCV_NO", MapUtils.getString(rtnMap, "RCV_NO"));
                        buds.setField("SUB_CPY_ID", MapUtils.getString(rtnMap, "SUB_CPY_ID"));
                        buds.setField("LST_PROC_ID", LST_PROC_ID); //�@�~�B�z�H��ID  
                        buds.setField("LST_PROC_DIV", LST_PROC_DIV); //�@�~�B�z���
                        buds.setField("LST_PROC_NAME", LST_PROC_NAME); //�@�~�B�z�H���m�W
                        buds.addBatch();
                    }
                    buds.executeBatch();
                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap, (Exception) theErrorObject[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException(MessageUtil.getMessage("EP_Z0C101_MSG_006"));//�b�ȸ�T�^�����������ɦ��~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException(MessageUtil.getMessage("EP_Z0C101_MSG_006"));//�b�ȸ�T�^�����������ɦ��~
                }
            } //end ��s�ץ�i�� (C101)

        } finally {
            if (buds != null) {
                buds.close();
            }
        }

    }

    /**
     * �@�o�����o��
     * @param invNoMap
     * @param EMP_ID
     * @param EMP_NAME
     * @param DIV_NO
     * @throws ModuleException
     */
    public void failInvoice(Map invNoMap, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException {
        ErrorInputException eie = null;
        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_002")); //�b�ȸ�T���o����!
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_007")); //�T�{�H�����o����!
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_008")); //�T�{�H���m�W���o����!
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_009")); //�T�{�H����줣�o����!
        }
        if (eie != null) {
            throw eie;
        }
        //�@�o���A
        String FAIL_OP_STATUS = "99";

        //�d������
        Map DTEPC101Map = queryByRcvNo(invNoMap);
        DataSet ds = Transaction.getDataSet();
        ds.setField("FAIL_OP_STATUS", FAIL_OP_STATUS);
        ds.setField("RCV_NO", invNoMap.get("RCV_NO"));
        ds.setField("LST_PROC_DATE", DATE.currentTime()); //�@�~�B�z�ɶ�
        ds.setField("LST_PROC_ID", EMP_ID); //�@�~�B�z�H��ID
        ds.setField("LST_PROC_DIV", DIV_NO); //�@�~�B�z���
        ds.setField("LST_PROC_NAME", EMP_NAME); //�@�~�B�z�H���m�W
        ds.setField("FLOW_NO", DTEPC101Map.get("OP_STATUS"));//
        ds.setField("SUB_CPY_ID", DTEPC101Map.get("SUB_CPY_ID"));
        DBUtil.executeUpdate(ds, SQL_failInvoice_001);
    }

    /**
     * �����@�o�����o��
     * @param invNoMap
     * @param EMP_ID
     * @param EMP_NAME
     * @param DIV_NO
     * @throws ModuleException
     */
    public void cancelFailInvoice(Map invNoMap, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException {
        ErrorInputException eie = null;
        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_002")); //�b�ȸ�T���o����!
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_007")); //�T�{�H�����o����!
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_008")); //�T�{�H���m�W���o����!
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_009")); //�T�{�H����줣�o����!
        }
        if (eie != null) {
            throw eie;
        }
        //�@�o���A
        //String FAIL_OP_STATUS = "99";

        //�d������
        Map DTEPC101Map = queryByRcvNo(invNoMap);

        if (!"99".equals(MapUtils.getString(DTEPC101Map, "OP_STATUS"))) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C101_MSG_005"));//�������A�D�o���@�o�L�k����
        }
        String PRE_OP_STATUS = MapUtils.getString(DTEPC101Map, "FLOW_NO").trim();
        DataSet ds = Transaction.getDataSet();

        ds.setField("FAIL_OP_STATUS", PRE_OP_STATUS);
        ds.setField("RCV_NO", invNoMap.get("RCV_NO"));
        ds.setField("LST_PROC_DATE", DATE.currentTime()); //�@�~�B�z�ɶ�
        ds.setField("LST_PROC_ID", EMP_ID); //�@�~�B�z�H��ID
        ds.setField("LST_PROC_DIV", DIV_NO); //�@�~�B�z���
        ds.setField("LST_PROC_NAME", EMP_NAME); //�@�~�B�z�H���m�W
        ds.setField("FLOW_NO", "");//
        ds.setField("SUB_CPY_ID", invNoMap.get("SUB_CPY_ID"));
        DBUtil.executeUpdate(ds, SQL_failInvoice_001);
    }

    /**
     * ���o�f��y�{�@�~�i�׳]�w
     * @param FLOW_TYPE
     * @param OP_STATUS
     * @return
     * @throws ModuleException
     */
    public String getNextOpStatus(String FLOW_TYPE, String OP_STATUS) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(FLOW_TYPE)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_010")); //�f��y�{�������o����!
        }
        if (StringUtils.isBlank(OP_STATUS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_011")); //�@�~�i�פ��o����!
        }
        if (eie != null) {
            throw eie;
        }

        return FieldOptionList.getName("EP", FLOW_TYPE, OP_STATUS);
    }

    /**
     * ���o�f��]�w��ư_�l�i��
     * @param FLOW_TYPE
     * @return
     * @throws ModuleException
     */
    public String getStartOpStatus(String FLOW_TYPE) throws ModuleException {
        if (StringUtils.isBlank(FLOW_TYPE)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_010")); //�f��y�{�������o����!
        }
        //�f��]�w
        //Map FLOW_TYPE_Map = FieldOptionList.getName("EP", FLOW_TYPE);

        return "00";
        //return MapUtils.getString(FLOW_TYPE_Map, "0");

    }

    /**
     * ���o�f��]�w��ƤW�@�@�~�i�ץN�X
     * @param FLOW_TYPE
     * @param OP_STATUS
     * @return
     * @throws ModuleException
     */
    public String getPreOpStatus(String FLOW_TYPE, String OP_STATUS) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(FLOW_TYPE)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_010")); //�f��y�{�������o����!
        }
        if (StringUtils.isBlank(OP_STATUS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_011")); //�@�~�i�פ��o����!
        }
        if (eie != null) {
            throw eie;
        }
        //�f��]�w
        String PRE_OP_STATUS = null;
        Map FLOW_TYPE_Map = FieldOptionList.getName("EP", FLOW_TYPE);
        for (Object every_key : FLOW_TYPE_Map.keySet()) {
            String tmp_OP_STATUS = MapUtils.getString(FLOW_TYPE_Map, every_key);
            if (tmp_OP_STATUS.equals(OP_STATUS)) {
                PRE_OP_STATUS = ObjectUtils.toString(every_key);
                break;
            }
        }
        return PRE_OP_STATUS;
    }

    /**
     * �d�ߥ�O�M�椧�������
     * @param payList
     * @return
     * @throws ModuleException
     */
    public Map<String, Map> queryRcvMap(List<Map> payList) throws ModuleException {
        ErrorInputException eie = null;

        String SUB_CPY_ID = null;
        if (payList == null || payList.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_012"));//ú�O�M�椣�o����
        } else {
            SUB_CPY_ID = MapUtils.getString(payList.get(0), "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        List<String> RCV_NO_LIST = new ArrayList<String>();
        //�v���NpayList �� RCV_NO ��JRCV_NO_LIST�A�ۦP�s�������Ʃ�J
        for (Map payMap : payList) {
            String RCV_NO = MapUtils.getString(payMap, "RCV_NO");
            if (!RCV_NO_LIST.contains(RCV_NO)) {
                RCV_NO_LIST.add(RCV_NO);
            }
        }

        DataSet ds = Transaction.getDataSet();
        ds.setFieldValues("RCV_NO_LIST", RCV_NO_LIST);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryRcvMap_001);

        Map<String, Map> rtnMap = new HashMap<String, Map>();
        for (Map rcvMap : rtnList) {
            rtnMap.put(MapUtils.getString(rcvMap, "RCV_NO"), rcvMap);
        }

        return rtnMap;
    }

    /**
     * �d���������(by RCV_NO_LIST)
     * @param payList
     * @return
     * @throws ModuleException
     */
    public List<Map> queryRcvList(List<String> RCV_NO_LIST, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (RCV_NO_LIST == null || RCV_NO_LIST.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_037"));//�����s�����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setFieldValues("RCV_NO_LIST", RCV_NO_LIST);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryRcvMap_001);

        return rtnList;
    }

    //=======================20150416 insert========================//
    /**
     * ��s�����������l�B
     * @param KIND ���ʺ���
     * @param PAY_AMT ��ú���B
     * @param RCV_NO �����s��
     * @param SPR_AMT �����l�B
     * @throws ModuleException 
     */
    /* EP_Z0C101.updateRcvSprAmtBatch()*/
    public void updateRcvSprAmt(String KIND, String PAY_NO, BigDecimal PAY_AMT, String RCV_NO, BigDecimal SPR_AMT, Map RTL_MAP, EP_Z0C101 theEP_Z0C101) throws ModuleException {
        //�ǤJ�Ѽ��ˬd
        ErrorInputException eie = null;
        if (!"I".equals(KIND) && !"D".equals(KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_035", new Object[] { KIND }));//�ǤJ�ѼơG���ʺ����榡���~�G{0}
        }

        if (PAY_AMT == null || BigDecimal.ZERO.compareTo(PAY_AMT) > 0) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_036"));//�ǤJ�ѼơG��ú���B���o�p��0
        }
        if (StringUtils.isBlank(RCV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_037"));//�ǤJ�ѼơG�����s�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�M�w��s���B
        BigDecimal CAL_SPR_AMT = BigDecimal.ZERO;
        if ("I".equals(KIND)) {
            CAL_SPR_AMT = PAY_AMT.negate();
        } else {
            CAL_SPR_AMT = PAY_AMT;
        }
        //�ˮ֪��B
        theEP_Z0C101.chkPAY_AMT(KIND, PAY_NO, SPR_AMT, CAL_SPR_AMT, RTL_MAP);

        BigDecimal TOT = SPR_AMT.add(CAL_SPR_AMT);
        /* ��z�i�Ҳ�
        if (TOT.compareTo(BigDecimal.ZERO) < 0) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30020_MSG_038", new Object[] { SPR_AMT, CAL_SPR_AMT }));//��s�����ɪ������l�B���~,�ǤJ�l�B:{0},�p���s���B:{1}
        }*/

        //��sDBEP.DTEPC101�����ɪ������l�B
        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("SPR_AMT", TOT);
        ds.setField("SUB_CPY_ID", RTL_MAP.get("SUB_CPY_ID"));
        try {
            DBUtil.executeUpdate(ds, SQL_updateRcvSprAmtBatch_001);
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_039"));//��s�����ɪ������l�B���~
        }

    }

    /**
     * ����s�����������l�B
     * @param KIND
     * @param PAY_LIST
     * @throws DBException
     * @throws ModuleException
     */
    public void updateRcvSprAmtBatch(String KIND, List<Map> PAY_LIST, BatchUpdateDataSet buds) throws DBException, ModuleException {
        //�ǤJ�Ѽ��ˬd
        ErrorInputException eie = null;
        if (!"I".equals(KIND) && !"D".equals(KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_013", new Object[] { KIND }));//�ǤJ�ѼơG���ʺ����榡���~�G{0}
        }
        for (Map PAY_MAP : PAY_LIST) {
            BigDecimal PAY_AMT = STRING.objToBigDecimal(PAY_MAP.get("PAY_AMT"), BigDecimal.ZERO);
            if (PAY_AMT == null || BigDecimal.ZERO.compareTo(PAY_AMT) > 0) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_014", new Object[] { MapUtils.getString(PAY_MAP, "PAY_NO") }));//�ǤJ�ѼơG��ú���B���o�p��0(ú�O�s��={0})
            }
            String RCV_NO = MapUtils.getString(PAY_MAP, "RCV_NO");
            if (StringUtils.isBlank(RCV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_015", new Object[] { MapUtils.getString(PAY_MAP, "CRT_NO") }));//�ǤJ�ѼơG�����s�����o���ŭ�(�����N��={0})
            }
            String SUB_CPY_ID = MapUtils.getString(PAY_MAP, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���i���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        //�]XAMode:buds�ѥD�{���ǤJ
        //BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        try {
            buds.preparedBatch(SQL_updateRcvSprAmtBatch_001);
            for (Map RTL_MAP : PAY_LIST) {

                BigDecimal PAY_AMT = STRING.objToBigDecimal(RTL_MAP.get("PAY_AMT"), BigDecimal.ZERO);
                BigDecimal SPR_AMT = STRING.objToBigDecimal(RTL_MAP.get("SPR_AMT"), BigDecimal.ZERO);
                String PAY_NO = MapUtils.getString(RTL_MAP, "PAY_NO");
                //�M�w��s���B
                BigDecimal CAL_SPR_AMT = BigDecimal.ZERO;
                if ("I".equals(KIND)) {
                    CAL_SPR_AMT = PAY_AMT.negate();
                } else {
                    CAL_SPR_AMT = PAY_AMT;
                }

                this.chkPAY_AMT(KIND, PAY_NO, SPR_AMT, CAL_SPR_AMT, RTL_MAP);
                buds.setField("SUB_CPY_ID", RTL_MAP.get("SUB_CPY_ID"));
                buds.setField("SPR_AMT", SPR_AMT.add(CAL_SPR_AMT));
                buds.setField("RCV_NO", RTL_MAP.get("RCV_NO"));
                buds.addBatch();
            }
            buds.executeBatch();
            Object theErrorObject[][] = buds.getBatchUpdateErrorArray();

            if (theErrorObject.length > 0) {
                for (int k = 0; k < theErrorObject.length; k++) {
                    Map errorDataMap = (Map) theErrorObject[k][1];
                    log.error("��s�����ɪ������l�B,��" + (Exception) theErrorObject[k][0] + "����Ʀ��~ Update setField = " + errorDataMap.toString(), (Exception) theErrorObject[k][2]);
                }
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C101_MSG_017"));// ��s�����ɪ������l�B���~
            }
        } catch (Exception e) {
            log.error("", e);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C101_MSG_017"));// ��s�����ɪ������l�B���~
        }
    }

    /**
     * �ˮ֪��B
     * @param KIND
     * @param PAY_NO
     * @param SPR_AMT
     * @param CAL_SPR_AMT
     * @param RTL_MAP
     * @throws ErrorInputException
     */
    public void chkPAY_AMT(String KIND, String PAY_NO, BigDecimal SPR_AMT, BigDecimal CAL_SPR_AMT, Map RTL_MAP) throws ErrorInputException {
        if ("I".equals(KIND)) {
            BigDecimal TOT = SPR_AMT.add(CAL_SPR_AMT);
            if (TOT.compareTo(BigDecimal.ZERO) < 0) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_016", new Object[] { SPR_AMT, CAL_SPR_AMT, PAY_NO }));//��s�����ɪ������l�B���~,�ǤJ�l�B:{0},�p���s���B:{1},ú�O�s��:{2}
            }
        } else {
            BigDecimal TOT = SPR_AMT.add(CAL_SPR_AMT).add(STRING.objToBigDecimal(RTL_MAP.get("RCV_PAY_AMT"), BigDecimal.ZERO));
            if (TOT.compareTo(STRING.objToBigDecimal(RTL_MAP.get("REC_AMT"), BigDecimal.ZERO)) > 0) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_016", new Object[] { SPR_AMT, CAL_SPR_AMT, PAY_NO }));//��s�����ɪ������l�B���~,�ǤJ�l�B:{0},�p���s���B:{1},ú�O�s��:{2}
            }
        }
    }

    //=======================150420 modifid for �K���վ�========================//
    /**
     * �d�ߥ�O�M�椧�������
     * @param reqMap
     * @param TRN_KIND
     * @return
     * @throws ModuleException 
     */
    public List<Map> queryRentFreeList(Map reqMap, String TRN_KIND) throws ModuleException {
        //�ǤJ�Ѽ��ˬd
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_018"));//�ǤJ�ѼƤ��i����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_019"));//�����q�O������J
        }
        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
        if (StringUtils.isBlank(RCV_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_020"));//�����~�륲����J
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        if (!"EPC001".equals(TRN_KIND)) {//�@����

            if (StringUtils.isBlank(CRT_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_021"));//�����N��������J
            }
            if (StringUtils.isBlank(CUS_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_022"));//�Ȥ�Ǹ�������J
            }
        }
        if (eie != null) {
            throw eie;
        }

        //���o������
        String EXT_TYPE = this.getExtType(TRN_KIND);

        //�d�ߤw�b�ȽT�{����������
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("EXT_TYPE", EXT_TYPE);
        ds.setField("RCV_YM", RCV_YM);
        setFieldIfExist(ds, "CRT_NO", CRT_NO);
        setFieldIfExist(ds, "CUS_NO", CUS_NO);
        return VOTool.findToMaps(ds, SQL_queryRentFreeList_001);
    }

    /**
     * ����s�K���վ�����
     * @param rtnList
     * @param USR_ID
     * @param USR_NAME
     * @param USR_DIV_NO
     * @throws DBException 
     * @throws ModuleException 
     */
    public void adjRentFreeList(List<Map> rtnList, String USR_ID, String USR_NAME, String USR_DIV_NO) throws DBException, ModuleException {

        BatchUpdateDataSet buds = null;

        Timestamp LST_PROC_DATE = DATE.currentTime();

        try {
            buds = Transaction.getBatchUpdateDataSet();
            int commit_size = 200; // �@��200���i�H�ݨD���ܵ���
            int batchCount = (rtnList.size() / commit_size) + 1;
            buds.preparedBatch(SQL_adjRentFreeList_001);
            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? rtnList.size() : i * commit_size;
                    for (int j = initS; j < initE; j++) {
                        Map mapC101 = (Map) rtnList.get(j);
                        //�]�w���
                        VOTool.mapToDataSet(mapC101, buds);
                        //��s�@�~�H��
                        buds.setField("LST_PROC_DATE", LST_PROC_DATE);
                        buds.setField("USR_ID", USR_ID);
                        buds.setField("USR_DIV_NO", USR_DIV_NO);
                        buds.setField("USR_NAME", USR_NAME);

                        buds.setField("RCV_NO", mapC101.get("RCV_NO"));
                        buds.addBatch();
                    }
                    buds.executeBatch();
                    Object theErrorLOGObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorLOGObject.length > 0) {
                        for (int k = 0; k < theErrorLOGObject.length; k++) {
                            Map errorDataMap = (Map) theErrorLOGObject[k][1];
                            log.error("��s��" + (Exception) theErrorLOGObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap.toString(), (Exception) theErrorLOGObject[k][2]);
                        }
                        throw new ModuleException(MessageUtil.getMessage("EP_Z0C101_MSG_024"));//��s�K���վ��������~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException(MessageUtil.getMessage("EP_Z0C101_MSG_024"));// ��s�K���վ��������~
                }
            }
        } finally {
            if (buds != null) {
                buds.close();
            }
        }
    }

    /**
     * �P�_������
     * @param TRN_KIND
     * @return
     * @throws ErrorInputException
     */
    public String getExtType(String TRN_KIND) throws ErrorInputException {
        //TRN_KIND ������EPC001��EPC002 ��EPC013�A �_�h��X���~�T���� �@�~����������EPC001��EPC002 ��EPC013���C
        if (!("EPC001".equals(TRN_KIND) || "EPC002".equals(TRN_KIND) || "EPC013".equals(TRN_KIND))) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C101_MSG_025"));//�@�~����������EPC001��EPC002 ��EPC013
        }

        if ("EPC001".equals(TRN_KIND)) { //�����
            return "2"; //��������
        } else if ("EPC002".equals(TRN_KIND)) {//�簣����
            return "1"; //��@������
        } else if ("EPC013".equals(TRN_KIND)) {//�����ɶ}
            return "4"; //�����ɩ������
        }
        return null;

    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldIfExist(DataSet ds, Map tmpMap, String key) {
        String value = MapUtils.getString(tmpMap, key);
        this.setFieldIfExist(ds, key, value);
    }

    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * ú�O��X,�^�_�����l�B(from EP_C30070.inser)
     * @param tmpMap
     * @throws ModuleException 
     */
    public void updateSPR_AMTbyC304(Map tmpMap) throws ModuleException {
        DataSet ds = Transaction.getDataSet();
        ds.setField("SPR_AMT", tmpMap.get("SPR_AMT"));
        ds.setField("LST_PROC_DATE", tmpMap.get("LST_PROC_DATE"));
        ds.setField("LST_PROC_ID", tmpMap.get("LST_PROC_ID"));
        ds.setField("LST_PROC_DIV", tmpMap.get("LST_PROC_DIV"));
        ds.setField("LST_PROC_NAME", tmpMap.get("LST_PROC_NAME"));
        ds.setField("RCV_NO", tmpMap.get("RCV_NO"));
        ds.setField("SUB_CPY_ID", tmpMap.get("SUB_CPY_ID"));
        DBUtil.executeUpdate(ds, SQL_updateSPR_AMTbyC304003);
    }

    /**
     * �������~��,�����N���d�߸Ӵ������̤jú�O����
     * (�ˮ֥�)
     * @param RCV_YM
     * @param CRT_NO
     * @param CUS_NO
     * @return
     * @throws ModuleException 
     */
    public Map qryMaxPayEDateByCrtNo(String RCV_YM, String CRT_NO, String CUS_NO) throws ModuleException {
        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        return VOTool.findOneToMap(ds, SQL_qryMaxPayEDateByCrtNo_001, false);
    }
    
    /**
     * �d�߱M��i�P�b��������
     * @param C307IDList
     * @param CURRENT_YM
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException
     */
    public List<Map> queryC101forC307(List<String> C307IDList, String RCV_YM, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (C307IDList == null || C307IDList.isEmpty()) {
        	eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_002"));//�b�ȸ�T���o����
        }
        if (StringUtils.isBlank(RCV_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_020"));//�����~�륲����J
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setFieldValues("C307IDList", C307IDList);
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_queryC101forC307_001);
    }
}
