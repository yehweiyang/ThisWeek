package com.cathay.ep.z0.module;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPB313;
import com.cathay.ep.vo.DTEPG101;
import com.cathay.ep.vo.DTEPG101_LOG;
import com.cathay.ep.vo.DTEPZ003;
import com.cathay.ep.vo.DTEPZ004;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014/09/17  Created ������
 * 2018/03/07  �t�X��ؽվ� ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��a�å���ƺ��@�Ҳ�
 * �Ҳ�ID    EP_Z0G101
 * ���n����    ��a�å���ƺ��@�Ҳ�
 * </pre>
 * @author ����[
 * @since 2014/12/5
 */
@SuppressWarnings("unchecked")
public class EP_Z0G101 {

    private static final Logger log = Logger.getLogger(EP_Z0G101.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G101.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.z0.module.EP_Z0G101.SQL_queryList_002";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0G101.SQL_queryMap_001";

    private static final String SQL_queryMap_002 = "com.cathay.ep.z0.module.EP_Z0G101.SQL_queryMap_002";

    private static final String SQL_queryMap_003 = "com.cathay.ep.z0.module.EP_Z0G101.SQL_queryMap_003";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0G101.SQL_delete_001";

    private static final String SQL_importFile_001 = "com.cathay.ep.z0.module.EP_Z0G101.SQL_importFile_001";

    /**
     * Ū����a�򥻸���ɲM��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G101_MSG_001"));//�ǤJ��T���o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G101_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
        }
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");

        List<Map> rtnList;
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotEmpty(BASE_CD)) {
            ds.setField("BASE_CD", sb.append("%").append(BASE_CD).append("%").toString());
        }
        String KIND = MapUtils.getString(reqMap, "KIND");
        if (StringUtils.isNotEmpty(KIND)) {
            sb.setLength(0);
            ds.setField("KIND", sb.append("%").append(KIND).append("%").toString());
        }
        if (StringUtils.isNotBlank(APLY_NO)) {
            //�YAPLY_NO����
            //�H�ǤJ�����q�O�d�߮ץ�_��a�å��ܧ����(DTEPB313)�G
            ds.setField("APLY_NO", APLY_NO);
            rtnList = VOTool.findToMaps(ds, SQL_queryList_001);
        } else {
            //�YAPLY_NO�L��
            //�H�ǤJ�����q�O�d�߰�a�å������(DTEPG101)�G
            rtnList = VOTool.findToMaps(ds, SQL_queryList_002);
        }
        for (Map rtnMap : rtnList) {
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "G0_TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            rtnMap.put("TRS_STS_NM", FieldOptionList.getName("EP", "TRS_STS", MapUtils.getString(rtnMap, "TRS_STS")));
        }

        return rtnList;
    }

    /**
     * Ū����a�򥻸����
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryMap(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G101_MSG_001"));//�ǤJ��T���o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            if (StringUtils.isBlank(BASE_CD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_003"));//�ǤJ��a�N�����o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        String BASE_BLD_NAME = MapUtils.getString(reqMap, "BASE_BLD_NAME");
        String DATA_TYPE = MapUtils.getString(reqMap, "DATA_TYPE");
        log.debug("EP_Z0G101.reqMap:" + reqMap);
        Map rtnMap = null;
        DataSet ds = Transaction.getDataSet();
        if (StringUtils.isNotBlank(APLY_NO)) {
            //�YAPLY_NO����
            //�H�ǤJ�����q�O�d�߮ץ�_��a�򥻸���ܧ����(DTEPB312)�G
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("BASE_CD", BASE_CD);
            ds.setField("APLY_NO", APLY_NO);
            String TRS_SEQ = MapUtils.getString(reqMap, "TRS_SEQ");
            String kind = MapUtils.getString(reqMap, "KIND");
            setFieldIfExist(ds, "KIND", kind);
            if (StringUtils.isNotEmpty(TRS_SEQ)) {
                setFieldIfExist(ds, "TRS_SEQ", reqMap);
            } else {
                if ("1".equals(kind)) {
                    setFieldIfExist(ds, "LND_SEC", reqMap);
                    setFieldIfExist(ds, "LND_NO", reqMap);
                } else if ("2".equals(kind)) {
                    setFieldIfExist(ds, "TAX_NO", reqMap);
                    setFieldIfExist(ds, "BLD_ADDR", reqMap);
                }
            }
            setFieldIfExist(ds, "BASE_BLD_NAME", BASE_BLD_NAME);
            setFieldIfExist(ds, "DATA_TYPE", DATA_TYPE);
            rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001, false);
        }
        if (rtnMap == null || rtnMap.isEmpty()) {
            //�YrtnMap�L��
            String QRY_TYPE = MapUtils.getString(reqMap, "QRY_TYPE");
            ds.clear();
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("BASE_CD", BASE_CD);
            String TRS_SEQ = MapUtils.getString(reqMap, "TRS_SEQ");
            String kind = MapUtils.getString(reqMap, "KIND");
            if (StringUtils.isNotEmpty(TRS_SEQ)) {
                setFieldIfExist(ds, "TRS_SEQ", reqMap);
            } else {
                if ("1".equals(kind)) {
                    setFieldIfExist(ds, "LND_SEC", reqMap);
                    setFieldIfExist(ds, "LND_NO", reqMap);
                } else if ("2".equals(kind)) {
                    setFieldIfExist(ds, "TAX_NO", reqMap);
                    setFieldIfExist(ds, "BLD_ADDR", reqMap);
                }
            }
            setFieldIfExist(ds, "BASE_BLD_NAME", BASE_BLD_NAME);
            setFieldIfExist(ds, "KIND", kind);

            if ("2".equals(QRY_TYPE)) {
                //�d�߮ץ�_��a�򥻸���ܧ����(DTEPB313)�G
                rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_002);
            } else {
                //�H�ǤJ�����q�O�ΰ�a�N���d�߰�a�򥻸����(DTEPG101)�G

                rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_003);
                rtnMap.put("SOURCE", "A");
            }

        }

        //���o�u����v����:
        rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "G0_TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
        //���o�u�a�ϡv����:
        rtnMap.put("ZONE_NM", FieldOptionList.getName("EP", "ZONE", MapUtils.getString(rtnMap, "ZONE")));
        //���o�u�ϰ�O�v����:
        rtnMap.put("ZONE_CD_NM", FieldOptionList.getName("EP", "ZONE_CD", MapUtils.getString(rtnMap, "ZONE_CD")));

        return rtnMap;

    }

    /**
     * �s�W��a�򥻸��LOG��
     * @param data
     * @param UPD_DATE
     * @param UPD_APLY_NO
     * @param UPD_TRN_KIND
     * @throws ModuleException 
     */
    private void insertLog(Map data, Timestamp UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        if (data == null || data.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_004"));//�ǤJ��a�򥻸���ɤ��o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(data, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            BASE_CD = MapUtils.getString(data, "BASE_CD");
            if (StringUtils.isBlank(BASE_CD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_003"));//�ǤJ��a�N�����o���ŭ�
            }
        }
        if (UPD_DATE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_005"));//�ǤJ�J�ɤ���ɶ����o���ŭ�
        }
        if (StringUtils.isBlank(UPD_APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_006"));//�ǤJ�J�ɮץ�s�����o���ŭ�
        }
        if (StringUtils.isBlank(UPD_TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_007"));//�ǤJ�J�ɥ���������o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�g�@��LOG��
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BASE_CD", BASE_CD);
        reqMap.put("TRS_SEQ", data.get("TRS_SEQ"));

        DTEPG101_LOG G101Vo_Log = VOTool.mapToVO(DTEPG101_LOG.class, this.queryMap(reqMap));
        G101Vo_Log.setUPD_DATE(UPD_DATE);
        G101Vo_Log.setUPD_APLY_NO(UPD_APLY_NO);
        G101Vo_Log.setUPD_TRN_KIND(UPD_TRN_KIND);
        VOTool.insert(G101Vo_Log);
    }

    /**
     * �פJ�ץ��å��ܧ���
     * @param reqMap
     * @param fileItem
     * @throws IOException 
     * @throws ModuleException 
     * @throws DBException 
     */
    public void importFile(Map reqMap, FileItem fileItem) throws IOException, ModuleException, DBException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        String APLY_NO = null;
        String KIND = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_001"));//�ǤJ��T���o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            if (StringUtils.isBlank(BASE_CD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_003"));//�ǤJ��a�N�����o���ŭ�
            }
            APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            if (StringUtils.isBlank(APLY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_008"));//�ǤJ���z�s�����o���ŭ�
            }
            KIND = MapUtils.getString(reqMap, "KIND");
            if (StringUtils.isBlank(KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_009"));//�ǤJ���O���o���ŭ�
            } else if (!"1".equals(KIND) && !"2".equals(KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_010"));//�ǤJ���O�榡���~
            }
        }
        if (fileItem == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_011"));//�פJ�ɮפ��o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        reqMap.put("DATA_TYPE", "I");

        BufferedReader br = EncodingHelper.getBufferedReader(fileItem.getInputStream()); // �إ߽w�İ�

        List<Map> dataList = new ArrayList<Map>();
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        try {
            String line;
            String[] tokens;

            while ((line = br.readLine()) != null) {

                tokens = line.split(","); //��ƪ����j�Ÿ���","
                if (tokens.length == 1) { //�p�G���ťզ�
                    continue;
                }

                Map textMap = new HashMap();
                //�Y���O�� 1:�g�a
                if (("1".equals(KIND))) {
                    textMap.put("LND_SEC", tokens[0].trim());
                    textMap.put("LND_NO", tokens[1].trim());
                    textMap.put("TRS_MEMO", tokens[2].trim());
                    textMap.put("TRS_AREA", tokens[3].trim());
                    textMap.put("HD_NM", tokens[4].trim());
                    textMap.put("HD_DM", tokens[5].trim());
                    textMap.put("TRS_STS", tokens[6].trim());
                    textMap.put("LND_RT", tokens[7].trim());
                } else {
                    //�Y���O�� 2:�ت�
                    textMap.put("BLD_ADDR", tokens[0].trim());
                    textMap.put("TAX_NO", tokens[1].trim());
                    textMap.put("TRS_MEMO", tokens[2].trim());
                    textMap.put("TRS_AREA", tokens[3].trim());
                    textMap.put("HD_NM", tokens[4].trim());
                    textMap.put("HD_DM", tokens[5].trim());
                    textMap.put("TRS_STS", tokens[6].trim());
                }
                textMap.putAll(reqMap);
                //���o�å��y����
                textMap.put("TRS_SEQ", theEP_Z0Z001.createNextNo(SUB_CPY_ID, "039", BASE_CD, KIND, KIND, 4));

                dataList.add(textMap);
            }
        } finally {
            if (br != null) {
                br.close();
            }
        }

        //�s�W�å��ܧ���� DTEPB313�G
        BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        buds.preparedBatch(SQL_importFile_001);
        int commit_size = 100; // �@��200���i�H�ݨD���ܵ���
        int batchCount = (dataList.size() / commit_size) + 1;
        try {
            for (int i = 1; i <= batchCount; i++) {
                try {

                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? dataList.size() : i * commit_size;
                    // �J�`�Q��w�s�H�Τ������զ�����w�s
                    for (int j = initS; j < initE; j++) {
                        Map dataMap = (Map) dataList.get(j);

                        buds.setField("APLY_NO", dataMap.get("APLY_NO"));
                        buds.setField("TRS_SEQ", dataMap.get("TRS_SEQ"));
                        buds.setField("DATA_TYPE", dataMap.get("DATA_TYPE"));
                        buds.setField("SUB_CPY_ID", dataMap.get("SUB_CPY_ID"));
                        buds.setField("BASE_CD", dataMap.get("BASE_CD"));
                        buds.setField("KIND", dataMap.get("KIND"));
                        buds.setField("BLD_ADDR", dataMap.get("BLD_ADDR"));
                        buds.setField("TAX_NO", dataMap.get("TAX_NO"));
                        buds.setField("LND_SEC", dataMap.get("LND_SEC"));
                        buds.setField("LND_NO", dataMap.get("LND_NO"));
                        buds.setField("TRS_MEMO", dataMap.get("TRS_MEMO"));
                        buds.setField("TRS_AREA", dataMap.get("TRS_AREA"));
                        buds.setField("HD_NM", dataMap.get("HD_NM"));
                        buds.setField("HD_DM", dataMap.get("HD_DM"));
                        buds.setField("TRS_STS", dataMap.get("TRS_STS"));
                        buds.setField("LND_RT", dataMap.get("LND_RT"));
                        buds.setField("TRS_FILE_NO", dataMap.get("TRS_FILE_NO"));

                        buds.addBatch();

                    }
                    buds.executeBatch();
                    Object theErrorbudsObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorbudsObject.length > 0) {
                        for (int k = 0; k < theErrorbudsObject.length; k++) {
                            Map errorDataMap = (Map) theErrorbudsObject[k][1];
                            log.error("�s�W��" + theErrorbudsObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap.toString(),
                                (Exception) theErrorbudsObject[k][2]);
                        }
                        throw new ModuleException(MessageUtil.getMessage("EP_Z0G101_MSG_024"));// �s�W��Ʀ��~
                    }
                } catch (Exception e) {
                    log.error("�妸�s�W����", e);
                    throw new ModuleException(MessageUtil.getMessage("EP_Z0G101_MSG_025"));// �妸�s�W����
                }
            }
        } finally {
            if (buds != null) {
                buds.close();
            }
        }

    }

    /**
     * �s�W�ץ��å����
     * @param dataMap
     * @param fi
     * @param user
     * @throws Exception 
     */
    public void insert(Map dataMap, FileItem fi, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String APLY_NO = null;
        String KIND = null;
        String BASE_CD = null;
        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_012"));//�ǤJ�ץ�_��a�å���Ƥ��o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            APLY_NO = MapUtils.getString(dataMap, "APLY_NO");
            if (StringUtils.isBlank(APLY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_013"));//�ǤJ�ץ�s�����o���ŭ�
            }
            KIND = MapUtils.getString(dataMap, "KIND");
            if (StringUtils.isBlank(KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_009"));//�ǤJ���O���o���ŭ�
            }
            BASE_CD = MapUtils.getString(dataMap, "BASE_CD");
            if (StringUtils.isBlank(BASE_CD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_003"));//�ǤJ��a�N�����o���ŭ�
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_014"));//�ϥΤH����T���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //���o�å��Ǹ�
        dataMap.put("TRS_SEQ", new EP_Z0Z001().createNextNo(SUB_CPY_ID, "039", BASE_CD, KIND, KIND, 4));

        //�s�W�å��ܧ����
        this.insertDTEPB313(dataMap, fi, user, "I");

    }

    /**
     * �s�W�ץ��å��ܧ���
     * @param dataMap
     * @param fi
     * @param user
     * @param opTYPE
     * @throws Exception
     */
    private void insertDTEPB313(Map dataMap, FileItem fi, UserObject user, String opTYPE) throws Exception {
        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
        String KIND = MapUtils.getString(dataMap, "KIND");

        if (!"D".equals(opTYPE) && (fi != null && fi.getSize() != 0)) {
            String FILE_NO = uploadFile(dataMap, fi, user, SUB_CPY_ID, KIND);
            dataMap.put("TRS_FILE_NO", FILE_NO);

        }

        //�̷� dataMap format DTEPB313
        DTEPB313 EPB313VO = VOTool.mapToVO(DTEPB313.class, dataMap);
        EPB313VO.setDATA_TYPE(opTYPE);
        VOTool.insert(EPB313VO);

    }

    private String uploadFile(Map dataMap, FileItem fi, UserObject user, String SUB_CPY_ID, String KIND) throws Exception, ModuleException {
        log.debug("Update Insert File");
        DTEPZ003 EPZ003VO = new DTEPZ003();
        EPZ003VO.setFILE_NO("");//�ɮ׽s��
        String[] FILE_NMs = fi.getName().split("\\.");
        String FILE_NM = FILE_NMs[0];
        EPZ003VO.setFILE_NM(FILE_NM); //�ɮצW��
        EPZ003VO.setFILE_KIND(FILE_NMs[1]);//�ɮ׺���

        //�ɮ׳Ƶ�
        StringBuilder sb = new StringBuilder();
        if ("1".equals(KIND)) {
            //EPZ003VO.FILE_REMARK = data.BASE_BLD_NAME +���g�a�å���+ data. LND_SEC + data.LND_NO
            EPZ003VO.setFILE_REMARK(sb.append(MapUtils.getString(dataMap, "BASE_BLD_NAME")).append(
                MessageUtil.getMessage("EP_Z0G101_MSG_027")/*"�g�a�å�"*/).append(MapUtils.getString(dataMap, "LND_SEC")).append(
                MapUtils.getString(dataMap, "LND_NO")).toString());
        } else {
            //EPZ003VO.FILE_REMARK = data.BASE_BLD_NAME +���ت��å���+ data.BLD_ADDR 
            EPZ003VO.setFILE_REMARK(sb.append(MapUtils.getString(dataMap, "BASE_BLD_NAME")).append(
                MessageUtil.getMessage("EP_Z0G101_MSG_028")/*"�ت��å�"*/).append(MapUtils.getString(dataMap, "BLD_ADDR")).toString());
        }

        EPZ003VO.setSUB_CPY_ID(SUB_CPY_ID);//�����q�O
        Timestamp currentTime = DATE.currentTime();
        String EmpId = user.getEmpID();
        String OpUnit = user.getOpUnit();
        EPZ003VO.setINS_DT(currentTime); //��J���
        EPZ003VO.setINS_ID(EmpId); //��J�H��
        EPZ003VO.setINS_DIVNO(OpUnit);//��J���

        //�W���ɮ�
        new EP_Z00010().insert(EPZ003VO, fi, user);
        String FILE_NO = EPZ003VO.getFILE_NO();

        //�� EPZ003VO �]�w �ɮ��v��
        DTEPZ004 EPZ004VO = new DTEPZ004();
        EPZ004VO.setFILE_NO(FILE_NO);
        EPZ004VO.setFILE_NM(FILE_NM);
        EPZ004VO.setCOM_DATA(EPZ003VO.getINS_DIVNO());
        EPZ004VO.setCOM_TYPE("02"); //   02:���v���
        EPZ004VO.setSUB_CPY_ID(SUB_CPY_ID);//�ǤJ�������q�O
        EPZ004VO.setINS_DT(currentTime); //��J���
        EPZ004VO.setINS_ID(EmpId); //��J�H��
        EPZ004VO.setINS_DIVNO(OpUnit); //��J���
        //�s�W�ɮ��v��
        new EP_Z00030().insert(EPZ004VO);
        return FILE_NO;
    }

    /**
     * �ק�
     * @param dataMap
     * @param fi
     * @param user
     * @throws Exception 
     */
    public void update(Map dataMap, FileItem fi, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String APLY_NO = null;
        String KIND = null;
        String BASE_CD = null;
        String TRS_SEQ = null;
        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_012"));//�ǤJ�ץ�_��a�å���Ƥ��o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            APLY_NO = MapUtils.getString(dataMap, "APLY_NO");
            if (StringUtils.isBlank(APLY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_013"));//�ǤJ�ץ�s�����o���ŭ�
            }
            KIND = MapUtils.getString(dataMap, "KIND");
            if (StringUtils.isBlank(KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_009"));//�ǤJ���O���o���ŭ�
            }
            BASE_CD = MapUtils.getString(dataMap, "BASE_CD");
            if (StringUtils.isBlank(BASE_CD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_003"));//�ǤJ��a�N�����o���ŭ�
            }
            TRS_SEQ = MapUtils.getString(dataMap, "TRS_SEQ");
            if (StringUtils.isBlank(TRS_SEQ)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_015"));//�ǤJ�å��Ǹ����o���ŭ�
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_014"));//�ϥΤH����T���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String DATA_TYPE = MapUtils.getString(dataMap, "DATA_TYPE");
        log.debug("EP_Z0G101.update DATA_TYPE:" + DATA_TYPE);
        if (StringUtils.isBlank(DATA_TYPE)) {
            //����s�W�{��(�ק�ɼW�[2����ơA�@�����ʫ�A�@�����ʫe)
            this.insertDTEPB313(dataMap, fi, user, "A");

            //���ʫe�A �d���å����
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            reqMap.put("BASE_CD", BASE_CD);
            reqMap.put("TRS_SEQ", TRS_SEQ);
            Map rtnMap = new EP_Z0G101().queryMap(reqMap);

            DTEPB313 EPB313VO = VOTool.mapToVO(DTEPB313.class, rtnMap);
            EPB313VO.setAPLY_NO(APLY_NO);
            EPB313VO.setDATA_TYPE("B");
            VOTool.insert(EPB313VO);
        } else if ("I".equals(DATA_TYPE) || "A".equals(DATA_TYPE)) {
            //UPDATE DBEP.DTEPB313 by dataMap

            DTEPB313 EPB313VO = VOTool.mapToVO(DTEPB313.class, dataMap);
            if (fi != null && fi.getSize() != 0) {
                String FILE_NO = uploadFile(dataMap, fi, user, SUB_CPY_ID, KIND);
                EPB313VO.setTRS_FILE_NO(FILE_NO);
            }
            VOTool.update(EPB313VO);
        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G101_MSG_016", new Object[] { DATA_TYPE }));//�å��ܧ�������ʺ���[0]���~�A�L�k�ק�
        }

    }

    /**
     * �R��
     * @param dataMap
     * @param user
     * @throws Exception
     */
    public void delete(Map dataMap, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String APLY_NO = null;
        String KIND = null;
        String BASE_CD = null;
        String TRS_SEQ = null;
        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_012"));//�ǤJ�ץ�_��a�å���Ƥ��o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            APLY_NO = MapUtils.getString(dataMap, "APLY_NO");
            if (StringUtils.isBlank(APLY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_013"));//�ǤJ�ץ�s�����o���ŭ�
            }
            KIND = MapUtils.getString(dataMap, "KIND");
            if (StringUtils.isBlank(KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_009"));//�ǤJ���O���o���ŭ�
            }
            BASE_CD = MapUtils.getString(dataMap, "BASE_CD");
            if (StringUtils.isBlank(BASE_CD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_003"));//�ǤJ��a�N�����o���ŭ�
            }
            TRS_SEQ = MapUtils.getString(dataMap, "TRS_SEQ");
            if (StringUtils.isBlank(TRS_SEQ)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_015"));//�ǤJ�å��Ǹ����o���ŭ�
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_014"));//�ϥΤH����T���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String DATA_TYPE = MapUtils.getString(dataMap, "DATA_TYPE");
        if (StringUtils.isBlank(DATA_TYPE)) {
            //����s�W�{��(�ק�ɼW�[2����ơA�@�����ʫ�A�@�����ʫe)
            this.insertDTEPB313(dataMap, null, user, "D");

        } else if ("I".equals(DATA_TYPE) || "A".equals(DATA_TYPE)) {
            DataSet ds = Transaction.getDataSet();
            ds.setField("APLY_NO", APLY_NO);
            ds.setField("BASE_CD", BASE_CD);
            ds.setField("TRS_SEQ", TRS_SEQ);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_delete_001);
        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G101_MSG_017", new Object[] { DATA_TYPE }));//�å��ܧ�������ʺ���[0]���~�A�L�k�R��
        }
    }

    /**
     * �X���å�
     * @param chkList
     * @param user
     * @throws Exception 
     */
    public void soldOut(List<Map> chkList, UserObject user) throws Exception {
        ErrorInputException eie = null;
        if (chkList == null || chkList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_018"));//�ǤJ���ʩ��Ӥ��o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_014"));//�ϥΤH����T���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        for (Map upd : chkList) {
            if (StringUtils.isNotBlank(MapUtils.getString(upd, "DATA_TYPE"))) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G101_MSG_019"));//�å����Ӳ��ʤ��A���i�妸�X��
            }
            upd.put("TRS_STS", "3");//�X��
        }

        for (Map upd : chkList) {
            this.update(upd, null, user);
        }

    }

    /**
     *  �X���å�
     * @param chkList
     * @param user
     * @throws Exception 
     */
    public void deTax(List<Map> chkList, UserObject user) throws Exception {
        ErrorInputException eie = null;
        if (chkList == null || chkList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_018"));//�ǤJ���ʩ��Ӥ��o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_014"));//�ϥΤH����T���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        for (Map upd : chkList) {
            if (StringUtils.isNotBlank(MapUtils.getString(upd, "DATA_TYPE"))) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G101_MSG_020"));//�å����Ӳ��ʤ��A���i���K�|
            }
            upd.put("TRS_STS", "2");//�K�|
        }

        for (Map upd : chkList) {
            this.update(upd, null, user);
        }

    }

    /**
     * �f��ץ��s��a�å����
     * @param BASE_CD
     * @param EPB301VO
     * @param UPD_TIME
     * @throws ModuleException
     */
    public void approve(String BASE_CD, DTEPB301 EPB301VO, String UPD_TIME) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BASE_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_003"));//�ǤJ��a�N�����o���ŭ�
        }
        if (EPB301VO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_021"));//�ǤJ�߮׮ץ󤣱o���ŭ�
        }
        if (StringUtils.isBlank(UPD_TIME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G101_MSG_022"));//�ǤJ���ʤ���ɶ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        Map reqMap = new HashMap();
        String SUB_CPY_ID = EPB301VO.getSUB_CPY_ID();
        String APLY_NO = EPB301VO.getAPLY_NO();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID); //�����q�O
        reqMap.put("APLY_NO", APLY_NO); //�ץ�s��
        //�d�߲��ʩ���
        List<Map> updList = this.queryList(reqMap);

        String TRN_KIND = EPB301VO.getTRN_KIND();
        String INPUT_DIV_NO = EPB301VO.getINPUT_DIV_NO();
        String INPUT_ID = EPB301VO.getINPUT_ID();
        String INPUT_NAME = EPB301VO.getINPUT_NAME();
        Timestamp UPD_TIME_stamp = DATE.toTimestamp(UPD_TIME);
        for (Map upd : updList) {
            upd.put("APLY_NO", APLY_NO);
            upd.put("TRN_KIND", TRN_KIND);
            upd.put("CHG_DATE", UPD_TIME_stamp);
            upd.put("CHG_DIV_NO", INPUT_DIV_NO);
            upd.put("CHG_ID", INPUT_ID);
            upd.put("CHG_NAME", INPUT_NAME);

            String DATA_TYPE = MapUtils.getString(upd, "DATA_TYPE");
            if (!"B".equals(DATA_TYPE)) {
                if ("I".equals(DATA_TYPE)) {
                    DTEPG101 EPG101VO = VOTool.mapToVO(DTEPG101.class, upd);
                    VOTool.insert(EPG101VO);
                } else if ("D".equals(DATA_TYPE)) {
                    //�gLOG��
                    this.insertLog(upd, UPD_TIME_stamp, APLY_NO, TRN_KIND);

                    //�R����a�򥻸���� DTEPG101�G
                    DTEPG101 EPG101VO = VOTool.mapToVO(DTEPG101.class, upd);
                    VOTool.delByPK(EPG101VO);

                } else if ("A".equals(DATA_TYPE)) {
                    //�gLOG��
                    this.insertLog(upd, UPD_TIME_stamp, APLY_NO, TRN_KIND);

                    //�ק��a�򥻸���� DTEPG101�G
                    DTEPG101 EPG101VO = VOTool.mapToVO(DTEPG101.class, upd);
                    VOTool.update(EPG101VO);
                }
            }

        }

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * SQL�����D���n�Ѽ�
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * SQL�����D���n�Ѽ�
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, Map data) {
        String value = MapUtils.getString(data, key);
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }
}
