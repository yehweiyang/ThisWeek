package com.cathay.ep.z0.module;

import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2015/01/22  Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �j�ӶO�μҲ�
 * �Ҳ�ID    EP_Z0G420
 * ���n����    �j�ӶO�μҲ�
 * </pre>
 * @author 
 * @since 2015/1/22
 */
@SuppressWarnings("unchecked")
public class EP_Z0G420 {
    private static final Logger log = Logger.getLogger(EP_Z0G420.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G420.SQL_queryList_001";

    private static final String SQL_queryBldTax_001 = "com.cathay.ep.z0.module.EP_Z0G420.SQL_queryBldTax_001";

    private static final String SQL_queryBldFee_001 = "com.cathay.ep.z0.module.EP_Z0G420.SQL_queryBldFee_001";

    private static final String SQL_queryPrem_001 = "com.cathay.ep.z0.module.EP_Z0G420.SQL_queryPrem_001";

    private static final String SQL_queryBaseInfo_001 = "com.cathay.ep.z0.module.EP_Z0G420.SQL_queryBaseInfo_001";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0G420.SQL_delete_001";

    private static final String SQL_importFile_001 = "com.cathay.ep.z0.module.EP_Z0G420.SQL_importFile_001";

    private static BigDecimal twelve = new BigDecimal(12);

    /**
     * Ū���j�ӤW�Ǹ��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String CAL_YM = null;
        String UP_TP = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_003"));//�ǤJ�p��~�뤣�o���ŭ�
            }
            UP_TP = MapUtils.getString(reqMap, "UP_TP");
            if (StringUtils.isBlank(UP_TP)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_017"));//�ǤJ�W���ɮ��������o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("UP_TP", UP_TP);
        ds.setField("CAL_YM", CAL_YM);

        return VOTool.findToMaps(ds, SQL_queryList_001);

    }

    /**
     * Ū���j�ӵ|��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryBldTax(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String CAL_YM = null;

        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_003"));//�ǤJ�p��~�뤣�o���ŭ�
            }

        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�ߵ|��DTEPG420)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("DATA_YR", CAL_YM);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryBldTax_001);
        String[] fields = new String[] { "LAND_TAX", "HOUSE_TAX" };
        for (Map dataMap : rtnList) {
            for (String field : fields) {
                BigDecimal TAX = STRING.objToBigDecimal(dataMap.get(field), BigDecimal.ZERO);
                TAX = TAX.divide(twelve, 0, BigDecimal.ROUND_HALF_UP);
                dataMap.put(field, TAX);
            }
        }

        //�N��a�|���̤j�ө��
        Map rtnMap = this.allocateBaseValueToBld(rtnList, fields); //�~
        return rtnMap;

    }

    /**
     * Ū���j�Ӻ޲z�O
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryBldFee(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String CAL_YM = null;

        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_003"));//�ǤJ�p��~�뤣�o���ŭ�
            }

        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�ߺ޲z�ODTEPG420)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        ds.setField("CAL_YM", CAL_YM);
        DBUtil.searchAndRetrieve(ds, SQL_queryBldFee_001);
        Map rtnMap = new HashMap();
        while (ds.next()) {
            Map tmpMap = VOTool.dataSetToMap(ds);
            rtnMap.put(tmpMap.get("BSLD_CD"), tmpMap);
        }

        return rtnMap;
    }

    /**
     * Ū���j�ӫO�O
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryPrem(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String CAL_YM = null;

        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_003"));//�ǤJ�p��~�뤣�o���ŭ�
            }

        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�߫O�I�ODTEPG420)�G

        String DATA_YR = CAL_YM.substring(0, 4);
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        ds.setField("DATA_YR", DATA_YR);
        DBUtil.searchAndRetrieve(ds, SQL_queryPrem_001);
        Map rtnMap = new HashMap();
        BigDecimal twelve = new BigDecimal(12);
        while (ds.next()) {
            Map tmpMap = VOTool.dataSetToMap(ds);
            BigDecimal PREM_AMT = STRING.objToBigDecimal(tmpMap.get("PREM_AMT"), BigDecimal.ZERO);
            rtnMap.put(tmpMap.get("BSLD_CD"), BigDecimal.ZERO);
            if (PREM_AMT.compareTo(BigDecimal.ZERO) != 0) {
                rtnMap.put(tmpMap.get("BSLD_CD"), PREM_AMT.divide(twelve, 0, BigDecimal.ROUND_HALF_UP));
            }

        }

        return rtnMap;
    }

    /**
     *  Ū���j�Ӱ�a���
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryBaseInfo(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String CAL_YM = null;

        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_003"));//�ǤJ�p��~�뤣�o���ŭ�
            }

        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�ߵ|��DTEPG420)�G

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CAL_YM", CAL_YM);
        String INV_EFF_CD = MapUtils.getString(reqMap, "INV_EFF_CD");
        if (StringUtils.isNotBlank(INV_EFF_CD)) {
            ds.setField("INV_EFF_CD", INV_EFF_CD);
        }
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryBaseInfo_001);
        String COST_KD = MapUtils.getString(reqMap, "COST_KD");
        for (Map dataMap : rtnList) {
            BigDecimal IFRS_INV_RT = STRING.objToBigDecimal(dataMap.get("IFRS_INV_RT"), BigDecimal.ZERO);
            BigDecimal COST_AMT = STRING.objToBigDecimal(dataMap.get("COST_AMT"), BigDecimal.ZERO);
            BigDecimal FL_EVAL = STRING.objToBigDecimal(dataMap.get("FL_EVAL"), BigDecimal.ZERO);
            BigDecimal BLD_COST_AMT;
            if ("1".equals(COST_KD)) {
                BLD_COST_AMT = COST_AMT;
            } else {
                if (FL_EVAL.compareTo(BigDecimal.ZERO) == 0) {
                    BLD_COST_AMT = COST_AMT;
                } else {
                    BLD_COST_AMT = FL_EVAL.multiply(IFRS_INV_RT);
                    BLD_COST_AMT = BLD_COST_AMT.add(COST_AMT.multiply(BigDecimal.ONE.subtract(IFRS_INV_RT)));
                }
            }
            dataMap.put("BLD_COST_AMT", BLD_COST_AMT);
        }

        //�N��a�̤j�ө��
        Map rtnMap = this.allocateBaseValueToBld(rtnList, new String[] { "BLD_COST_AMT" }); //��
        return rtnMap;
    }

    /**
     * ����j�Ӫ��B
     * @param rtnList
     * @param fields
     * @param FREQ
     * @return
     * @throws ModuleException
     */
    public Map allocateBaseValueToBld(List<Map> rtnList, String[] fields) throws ModuleException {
        //��Ĥ@���A�i��ǤJ����ˮ�
        ErrorInputException eie = null;
        Map chkMap = rtnList.get(0);
        if (!chkMap.containsKey("BLD_CD")) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_018"));//���ǤJ�j�ӥN��
        }
        if (!chkMap.containsKey("BASE_CD")) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_005"));//���ǤJ��a�N��
        }
        if (!chkMap.containsKey("COST_RT")) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_006"));//���ǤJ������
        }
        if (!chkMap.containsKey("BLD_CNT")) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_007"));//���ǤJ��a�����j�Ӵɼ�
        }
        if (fields.length == 0) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_008"));//���ǤJ������B���M��
        } else {
            for (String strkey : fields) {
                if (!chkMap.containsKey(strkey)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_009", new Object[] { strkey }));//���ǤJ������{0}
                }
            }
        }

        if (eie != null) {
            throw eie;
        }

        Map rtnMap = new HashMap();
        Map sumMap = new HashMap();

        for (Map dataMap : rtnList) {

            Integer BLD_CNT = MapUtils.getIntValue(dataMap, "BLD_CNT");
            String BLD_CD = MapUtils.getString(dataMap, "BLD_CD");
            String BASE_CD = MapUtils.getString(dataMap, "BASE_CD");
            if (BLD_CNT == 1) {
                rtnMap.put(BLD_CD, dataMap);
            } else if (BLD_CNT > 1) {
                //��a�������h�ɤj��
                Map baseInfo;

                if (sumMap.containsKey(BASE_CD)) {
                    baseInfo = (Map) sumMap.get(BASE_CD);
                } else {
                    baseInfo = new HashMap();
                    baseInfo.putAll(dataMap);
                    sumMap.put(BASE_CD, baseInfo);

                }
                Integer baseBLD_CNT = MapUtils.getIntValue(baseInfo, "BLD_CNT");
                //�v�@��������B
                for (String strkey : fields) {
                    //�̫�@���A�̾l�B����

                    if (baseBLD_CNT == 1) {
                        dataMap.put(strkey, baseInfo.get(strkey));
                        sumMap.put("BLD_CNT", 0);
                    } else {
                        BigDecimal divValue = STRING.objToBigDecimal(dataMap.get("COST_RT"), BigDecimal.ZERO).multiply(
                            STRING.objToBigDecimal(dataMap.get(strkey), BigDecimal.ZERO)).setScale(0, BigDecimal.ROUND_HALF_UP);

                        // ��s��������B
                        dataMap.put(strkey, divValue);
                        // ��s��a��T�l�B
                        BigDecimal baseValue = STRING.objToBigDecimal(baseInfo.get(strkey), BigDecimal.ZERO);
                        baseInfo.put(strkey, baseValue.subtract(divValue));
                        baseInfo.put("BLD_CNT", baseBLD_CNT - 1);//TODO
                    }
                }

                //�]�w��a�J���T
                sumMap.put(BASE_CD, baseInfo);
                //�]�w�j�ө�����G
                rtnMap.put(dataMap.get("BLD_CD"), dataMap);

            } else {
                rtnMap.put(dataMap.get("BLD_CD"), dataMap);

                //throw new ModuleException(MessageUtil.getMessage("EP_Z0G420_MSG_015"));//��a�L�j�ӹ���ɸ��
            }
        }
        return rtnMap;
    }

    /**
     * �פJ�j�Ӧ����O�θ��
     * @param reqMap
     * @param fileItem
     * @param user
     * @throws ModuleException
     * @throws IOException 
     * @throws DBException 
     */
    public List<Map> importFile(Map reqMap, FileItem fileItem, UserObject user) throws ModuleException, IOException, DBException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String UP_TP = null;
        String UPD_PRD = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            UP_TP = MapUtils.getString(reqMap, "UP_TP");
            if (StringUtils.isBlank(UP_TP)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_010"));//�ǤJ�ɮ��������o���ŭ�
            }
            UPD_PRD = MapUtils.getString(reqMap, "UPD_PRD");
            if (StringUtils.isBlank(UPD_PRD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_011"));//�ǤJ�@�~�g�����o���ŭ�
            }
        }
        if (fileItem == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_012"));//�פJ�ɮפ��o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        Map fldMap = FieldOptionList.getName("EP", "EPG30200_FLD_" + UP_TP);
        log.debug("FIELD_SET:" + fldMap);
        BufferedReader br = EncodingHelper.getBufferedReader(fileItem.getInputStream()); // �إ߽w�İ�

        List<Map> dataList = new ArrayList<Map>();

        try {
            String line;
            String[] tokens;

            while ((line = br.readLine()) != null) {

                //tokens = line.split(","); //��ƪ����j�Ÿ���","
                tokens = StringUtils.splitPreserveAllTokens(line, ",");
                if (tokens.length == 1) { //�p�G���ťզ�
                    continue;
                }

                Map textMap = new HashMap();
                textMap.put("SUB_CPY_ID", SUB_CPY_ID);
                textMap.put("UP_TP", UP_TP);

                //�����]�w ������m�A�����W�ٳ]�Ȧ� MAP
                for (Object key : fldMap.keySet()) {
                    String FIELD = MapUtils.getString(fldMap, key);
                    int idx = Integer.parseInt(key.toString().trim());
                    String value = tokens[idx].trim();
                    //�ƭ���� �L�ȵ�0
                    if (idx > 1 && StringUtils.isBlank(value)) {
                        value = "0";
                    }
                    textMap.put(FIELD, value);
                }
                log.debug(textMap);

                //                if ("1".equals(UP_TP)) {
                //                    textMap.put("BSLD_CD", tokens[0].trim());
                //                    textMap.put("CAL_YM", tokens[1].trim());
                //                    textMap.put("BASE_BLD_NAME", tokens[2].trim());
                //                    textMap.put("IFRS_INV_RT", StringUtils.isBlank(tokens[3].trim()) ? BigDecimal.ZERO : tokens[3].trim());
                //                    textMap.put("TOT_RNT_SIZE", StringUtils.isBlank(tokens[4].trim()) ? BigDecimal.ZERO : tokens[4].trim());
                //                    textMap.put("RNT_RT", StringUtils.isBlank(tokens[5].trim()) ? BigDecimal.ZERO : tokens[5].trim());
                //                    textMap.put("INV_RNT_SIZE", StringUtils.isBlank(tokens[6].trim()) ? BigDecimal.ZERO : tokens[6].trim());
                //                    textMap.put("FL_EVAL", StringUtils.isBlank(tokens[7].trim()) ? BigDecimal.ZERO : tokens[7].trim());
                //                    textMap.put("COST_AMT", StringUtils.isBlank(tokens[8].trim()) ? BigDecimal.ZERO : tokens[8].trim());
                //                    textMap.put("BLD_COST_AMT", StringUtils.isBlank(tokens[9].trim()) ? BigDecimal.ZERO : tokens[8].trim());
                //                    textMap.put("BLD_AREA", StringUtils.isBlank(tokens[10].trim()) ? BigDecimal.ZERO : tokens[9].trim());
                //                    textMap.put("LND_AREA", StringUtils.isBlank(tokens[11].trim()) ? BigDecimal.ZERO : tokens[10].trim());
                //                    textMap.put("PRK_AREA", StringUtils.isBlank(tokens[12].trim()) ? BigDecimal.ZERO : tokens[11].trim());
                //                } else if ("2".equals(UP_TP)) {
                //                    textMap.put("BSLD_CD", tokens[0].trim());
                //                    textMap.put("CAL_YM", tokens[1].trim());
                //                    textMap.put("DIFF_FEE", StringUtils.isBlank(tokens[2].trim()) ? BigDecimal.ZERO : tokens[2].trim());
                //                    textMap.put("EMPTY_FEE", StringUtils.isBlank(tokens[3].trim()) ? BigDecimal.ZERO : tokens[3].trim());
                //                    textMap.put("SLF_RNT_AMT", StringUtils.isBlank(tokens[4].trim()) ? BigDecimal.ZERO : tokens[4].trim());
                //                } else if ("3".equals(UP_TP)) {
                //                    textMap.put("BSLD_CD", tokens[0].trim());
                //                    textMap.put("CAL_YM", tokens[1].trim());
                //                    textMap.put("LAND_TAX", StringUtils.isBlank(tokens[2].trim()) ? BigDecimal.ZERO : tokens[2].trim());
                //                    textMap.put("HOUSE_TAX", StringUtils.isBlank(tokens[3].trim()) ? BigDecimal.ZERO : tokens[3].trim());
                //                } else if ("4".equals(UP_TP)) {
                //                    textMap.put("BSLD_CD", tokens[0].trim());
                //                    textMap.put("CAL_YM", tokens[1].trim());
                //                    textMap.put("PREM_AMT", StringUtils.isBlank(tokens[2].trim()) ? BigDecimal.ZERO : tokens[2].trim());
                //                }
                dataList.add(textMap);

            }
        } finally {
            if (br != null) {
                br.close();
            }
        }
        //�s�W DTEPG420�G
        BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        buds.preparedBatch(SQL_importFile_001);

        int commit_size = 500; // �@��200���i�H�ݨD���ܵ���
        int batchCount = (dataList.size() / commit_size) + 1;

        Timestamp tTime = DATE.currentTime();
        String EmpID = user.getEmpID();
        String OpUnit = user.getOpUnit();
        String EmpName = user.getEmpName();
        String CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
        try {
            for (int i = 1; i <= batchCount; i++) {
                try {

                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? dataList.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        Map dataMap = (Map) dataList.get(j);

                        buds.setField("BASE_BLD_NAME", null);
                        buds.setField("IFRS_INV_RT", null);
                        buds.setField("TOT_RNT_SIZE", null);
                        buds.setField("RNT_RT", null);
                        buds.setField("INV_RNT_SIZE", null);
                        buds.setField("FL_EVAL", null);
                        buds.setField("COST_AMT", null);
                        buds.setField("BLD_AREA", null);
                        buds.setField("LND_AREA", null);
                        buds.setField("PRK_AREA", null);
                        buds.setField("DIFF_FEE", null);
                        buds.setField("EMPTY_FEE", null);
                        buds.setField("SLF_RNT_AMT", null);
                        buds.setField("LAND_TAX", null);
                        buds.setField("HOUSE_TAX", null);
                        buds.setField("PREM_AMT", null);
                        buds.setField("BLD_COST_AMT", null);

                        for (Object obj : fldMap.keySet()) {

                            String NAME = MapUtils.getString(fldMap, obj);
                            if ("CAL_YM".equals(NAME)) {
                                buds.setField("CAL_YM", CAL_YM);
                            } else {
                                buds.setField(NAME, dataMap.get(NAME));
                            }

                        }
                        buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                        buds.setField("UP_TP", UP_TP);
                        buds.setField("CHG_DATE", tTime);
                        buds.setField("CHG_DIV_NO", OpUnit);
                        buds.setField("CHG_ID", EmpID);
                        buds.setField("CHG_NAME", EmpName);

                        buds.addBatch();

                    }
                    buds.executeBatch();
                    Object theErrorbudsObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorbudsObject.length > 0) {
                        for (int k = 0; k < theErrorbudsObject.length; k++) {
                            Map errorDataMap = (Map) theErrorbudsObject[k][1];
                            log.error("�s�W��" + theErrorbudsObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap.toString(),
                                (Exception) theErrorbudsObject[k][2]);
                        }
                        throw new ModuleException(MessageUtil.getMessage("EP_Z0G420_MSG_013"));// �s�W��Ʀ��~
                    }
                } catch (Exception e) {
                    log.error("�妸�s�W����", e);
                    throw new ModuleException(MessageUtil.getMessage("EP_Z0G420_MSG_014"));// �妸�s�W����
                }
            }
        } finally {
            if (buds != null) {
                buds.close();
            }
        }
        return dataList;
    }

    /**
     * �R��
     * @param dataMap
     * @param user
     * @throws ModuleException
     */
    public void delete(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String CAL_YM = null;
        String UP_TP = null;
        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            CAL_YM = MapUtils.getString(dataMap, "CAL_YM");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_003"));//�ǤJ�p��~�뤣�o���ŭ�
            }
            UP_TP = MapUtils.getString(dataMap, "UP_TP");
            if (StringUtils.isBlank(UP_TP)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_010"));//�ǤJ�ɮ��������o���ŭ�
            }

        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CAL_YM", CAL_YM);
        ds.setField("UP_TP", UP_TP);
        DBUtil.executeUpdate(ds, SQL_delete_001);
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}
