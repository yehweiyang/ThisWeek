package com.cathay.ep.z0.module;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.ep.vo.DTEPI102;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE    Description Author
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �ӥ���i�W���ɬd�ߺ��@�Ҳ�
 * �Ҳ�ID    EP_Z0I102
 * ���n����    �ӥ���i�W���ɬd�ߺ��@�Ҳ�
 * </pre>
 * @author �L�ç�
 * @since 2016/12/05
 */
@SuppressWarnings("unchecked")
public class EP_Z0I102 {

    private static final String SQL_queryDTEPI102_001 = "com.cathay.ep.z0.module.EP_Z0I102.SQL_queryDTEPI102_001";

    private static final String SQL_query_001 = "com.cathay.ep.z0.module.EP_Z0I102.SQL_query_001";

    /**
     * �ק�ӥ���i�W�Ǹ��
     * @param reqMap
     * @param user �ϥΪ̸�T
     * @throws ModuleException 
     */
    public void updateDTEPI102(Map reqMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "EP_Z0I102_MSG_001");//�ϥΪ̸�T���o����
        }
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_Z0I102_MSG_002");//�ӥ���i�W�Ǹ�T���o����
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String CITY_CD = MapUtils.getString(reqMap, "CITY_CD");
        String BRK_CD = MapUtils.getString(reqMap, "BRK_CD");
        String INV_YR = MapUtils.getString(reqMap, "INV_YR");
        String INV_SN = MapUtils.getString(reqMap, "INV_SN");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_Z0I102_MSG_003");//�����q�O���o����
        }
        if (StringUtils.isBlank(CITY_CD)) {
            eie = getErrorInputException(eie, "EP_Z0I102_MSG_004");//�����O�N�����o����
        }
        if (StringUtils.isBlank(BRK_CD)) {
            eie = getErrorInputException(eie, "EP_Z0I102_MSG_005");//�ӥ�N�����o����
        }
        if (StringUtils.isBlank(INV_YR)) {
            eie = getErrorInputException(eie, "EP_Z0I102_MSG_006");//�~���o����
        }
        if (StringUtils.isBlank(INV_SN)) {
            eie = getErrorInputException(eie, "EP_Z0I102_MSG_007");//�u���o����
        }
        if (eie != null) {
            throw eie;
        }

        String DIV_NO = user.getDivNo();
        String EMP_ID = user.getEmpID();
        String EMP_NM = user.getEmpName();
        Timestamp currentTime = DATE.currentTime();

        DTEPI102 I102Vo = VOTool.mapToVO(DTEPI102.class, reqMap);
        I102Vo.setCHG_DATE(currentTime);
        I102Vo.setCHG_DIV_NO(DIV_NO);
        I102Vo.setCHG_ID(EMP_ID);
        I102Vo.setCHG_NAME(EMP_NM);

        if (VOTool.findByPK(I102Vo, false) != null) {
            VOTool.update(I102Vo);
        } else {
            //�Y��s�L��ƫh�s�W�@��
            VOTool.insert(I102Vo);
        }
    }

    /**
     * �d�߰ӥ���i�W�Ǹ��
     * @param reqMap
     * @return List<Map>
     * @throws ModuleException 
     * @throws SQLException 
     */
    public List<Map> query(Map reqMap) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_Z0I102_MSG_002");//�ӥ���i�W�Ǹ�T���o����
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw getErrorInputException(eie, "EP_Z0I102_MSG_003");//�����q�O���o����
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (MapUtils.getBoolean(reqMap, "isUpload")) {
            ds.setField("isUpload","1");
            ds.setField("CITY_CD",reqMap.get("CITY_CD"));
            ds.setField("BRK_CD",reqMap.get("BRK_CD"));
            ds.setField("INV_YR",reqMap.get("INV_YR"));
            ds.setField("INV_SN",reqMap.get("INV_SN"));
        } else {
            ds.setField("isQuery","1");
            setValueIfExist(ds, reqMap, "QCITY_CD");
            setValueIfExist(ds, reqMap, "QBRK_CD");
            setValueIfExist(ds, reqMap, "QINV_YR1");
            setValueIfExist(ds, reqMap, "QINV_YR2");
            setValueIfExist(ds, reqMap, "QINV_SN1");
            setValueIfExist(ds, reqMap, "QINV_SN2");
        }

        DivData theDivData = new DivData();
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_query_001);
        for (Map rtnMap : rtnList) {
            //��������
            rtnMap.put("CITY_CD_NM", FieldOptionList.getName("EP", "I1_CITY_CD2", MapUtils.getString(rtnMap, "CITY_CD")));
            //�ӥ򤤤�
            rtnMap.put("BRK_CD_NM", FieldOptionList.getName("EP", "I1_BRK_CD", MapUtils.getString(rtnMap, "BRK_CD")));
            //�u����
            rtnMap.put("INV_SN_NM", FieldOptionList.getName("EP", "I1_INV_SN", MapUtils.getString(rtnMap, "INV_SN")));
            //���ʳ�줤��
            rtnMap.put("CHG_DIV_NM", theDivData.getUnit4ShortName(MapUtils.getString(rtnMap, "CHG_DIV_NO")));
        }
        return rtnList;
    }

    /**
     * �d�߰ӥ���i�W�Ǹ��
     * @param reqMap
     * @return List<Map>
     * @throws ModuleException 
     * @throws SQLException 
     */
    public List<Map> queryDTEPI102(Map reqMap) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_Z0I102_MSG_002");//�ӥ���i�W�Ǹ�T���o����
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw getErrorInputException(eie, "EP_Z0I102_MSG_003");//�����q�O���o����
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setValueIfExist(ds, reqMap, "CITY_CD");
        setValueIfExist(ds, reqMap, "BRK_CD");
        setValueIfExist(ds, reqMap, "INV_YR");
        setValueIfExist(ds, reqMap, "INV_SN");

        DivData theDivData = new DivData();
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryDTEPI102_001);
        for (Map rtnMap : rtnList) {
            //��������
            rtnMap.put("CITY_CD_NM", FieldOptionList.getName("EP", "I1_CITY_CD2", MapUtils.getString(rtnMap, "CITY_CD")));
            //�ӥ򤤤�
            rtnMap.put("BRK_CD_NM", FieldOptionList.getName("EP", "I1_BRK_CD", MapUtils.getString(rtnMap, "BRK_CD")));
            //�u����
            rtnMap.put("INV_SN_NM", FieldOptionList.getName("EP", "I1_INV_SN", MapUtils.getString(rtnMap, "INV_SN")));
            //���ʳ�줤��
            rtnMap.put("CHG_DIV_NM", theDivData.getUnit4ShortName(MapUtils.getString(rtnMap, "CHG_DIV_NO")));
        }
        return rtnList;
    }

    /**
     * �� Map ���Akey ������ value �s�b�ɡA�~��J DataSet
     * @param ds
     * @param map
     * @param key
     */
    private void setValueIfExist(DataSet ds, Map map, String key) {
        String value = MapUtils.getString(map, key);
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}