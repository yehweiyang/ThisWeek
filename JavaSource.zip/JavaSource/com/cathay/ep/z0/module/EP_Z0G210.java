package com.cathay.ep.z0.module;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014/09/30  Created ������
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��a�����������@�Ҳ�
 * �Ҳ�ID    EP_Z0G210 
 * ���n����    ��a�����������@�Ҳ�
 * </pre>
 * @author �Ťl��
 * 
 * [20200323] �ק��
 * Modified�\��睊�A�վ�queryList�BqueryMap
 * �R��update�Binsert�Bdelete, queryCostList
 * �s�W batchInsert�BbatchUpdate�BbatchDelete�BqueryG210WithTempList�BqueryTempList�BinsertTemp�BupdateTemp �BdeleteTemp�BbatchDeleteTemp�BqueryLogList�BbatchInsertLog�BbatchDeleteLog�BconfirmUpdate�BcancelUpdate
 * deprecated batchUpdate(List)
 * 20200407 AllenTsai �վ�W�[�N�X
 * 2020/04/08 AllenTsai �վ�queryTempList�B�z�ǤJ����s�����d�߱���
 * 2020/04/08 AllenTsai confirmUpdate �վ�����s�W�A�d�L����������Ƶ������`
 * [20200506] AllenTsai �W�[Dummy ��k���U�[�{���i�H�sĶ�A����A�NMETHOD �R��
 * [20200507] AllenTsai �R��Dummy��k
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0G210 {
    private static final Logger log = Logger.getLogger(EP_Z0G210.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_queryList_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_queryMap_001";

    private static final String SQL_updateCalDate_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_updateCalDate_001";

    private static final String SQL_batchUpdate_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_batchUpdate_001";

    private static final String SQL_batchInsert_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_batchInsert_001";

    private static final String SQL_batchDelete_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_batchDelete_001";

    private static final String SQL_queryG210WithTempList_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_queryG210WithTempList_001";

    private static final String SQL_queryTempList_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_queryTempList_001";

    private static final String SQL_insertTemp_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_insertTemp_001";

    private static final String SQL_updateTemp_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_updateTemp_001";

    private static final String SQL_deleteTemp_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_deleteTemp_001";

    private static final String SQL_batchInsertLog_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_batchInsertLog_001";

    private static final String SQL_batchDeleteLog_001 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_batchDeleteLog_001";

    private static final String SQL_batchUpdate_002 = "com.cathay.ep.z0.module.EP_Z0G210.SQL_batchUpdate_002";

    /**
    * Ū����a����M��
    * @param reqMap
    * @param UPD_SRC ���ʨӷ��i����J(11:��������;13:�����d��)
    * @return
    * @throws ModuleException
    */
    public List<Map> queryList(Map reqMap, String UPD_SRC) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;

        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }

            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_003")); //[20200323]�ǤJ��a�N�����o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�߮ץ�_��a�������������� (DTEPG210)�G
        DataSet ds = Transaction.getDataSet();

        StringBuilder sb = new StringBuilder();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        setLikeFieldsIfExsits(ds, reqMap, "BASE_CD", sb);
        //[20200323]�s�W���
        setLikeFieldsIfExsits(ds, reqMap, "ACC_TP", sb);//�Y�|�p���O����J���d�߱���        
        //�Y UPD_SRC ����J�A���d�߱���
        if (StringUtils.isNotEmpty(UPD_SRC)) {
            ds.setField("UPD_SRC", UPD_SRC);
        } else {
            setLikeFieldsIfExsits(ds, reqMap, "APLY_NO", sb);//�Y UPD_SRC �S��J �B G210.APLY_NO ����J�A�~�]�w�d�߱���
        }

        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        List<Map> rtnList = new ArrayList();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //�|�p����
            rtnMap.put("ACC_TP_NM", FieldOptionList.getName("EP", "ACC_TP", MapUtils.getString(rtnMap, "ACC_TP")));
            //[20200323]�������O
            //[20200323]�����u������  
            //�u������  
            rtnMap.put("SUB_ITEM_NO_NM", FieldOptionList.getName("EP", "G3_SUB_ITEM_NO", MapUtils.getString(rtnMap, "SUB_ITEM_NO")));
            //�������A
            rtnMap.put("ITEM_STS_NM", FieldOptionList.getName("EP", "ITEM_STS", MapUtils.getString(rtnMap, "ITEM_STS")));
            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * Ū����a�������������
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryMap(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        String COST_SEQ = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            COST_SEQ = MapUtils.getString(reqMap, "COST_SEQ");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_003")); //�ǤJ��a�N�����o���ŭ�
            }
            if (StringUtils.isBlank(COST_SEQ)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_004")); //�ǤJ���������Ǹ����o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("COST_SEQ", COST_SEQ);
        setFieldIfExist(ds, reqMap, "APLY_NO");
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001);
        //�|�p����
        rtnMap.put("ACC_TP_NM", FieldOptionList.getName("EP", "ACC_TP", MapUtils.getString(rtnMap, "ACC_TP")));
        //[20200323]�������O
        //[20200323]�����u������  
        //�u������  
        rtnMap.put("SUB_ITEM_NO_NM", FieldOptionList.getName("EP", "G3_SUB_ITEM_NO", MapUtils.getString(rtnMap, "SUB_ITEM_NO")));
        //�������A
        rtnMap.put("ITEM_STS_NM", FieldOptionList.getName("EP", "ITEM_STS", MapUtils.getString(rtnMap, "ITEM_STS")));
        return rtnMap;
    }

    /**
     * ����s����R�P��T
     * @param listG210
     * @throws ModuleException
     * @throws DBException
     */
    @Deprecated
    public void batchUpdateOld(List<Map> listG210) throws ModuleException, DBException {
        ErrorInputException eie = null;

        if (listG210 == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_010")); //�ǤJ�R�P�����T���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�B�z���update
        BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���

        try {
            int batchCount;

            buds.clear();
            buds.preparedBatch(SQL_batchUpdate_001);

            batchCount = (listG210.size() / commit_size) + 1;

            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? listG210.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {

                        Map G210Map = listG210.get(j);
                        buds.setField("SUB_CPY_ID", G210Map.get("SUB_CPY_ID"));
                        buds.setField("BASE_CD", G210Map.get("BASE_CD"));
                        buds.setField("COST_SEQ", G210Map.get("COST_SEQ"));

                        buds.setField("COST_AMT", G210Map.get("COST_AMT"));
                        buds.setField("LOSS_AMT", G210Map.get("LOSS_AMT"));
                        buds.setField("IFRS_INV_RT", G210Map.get("IFRS_INV_RT"));
                        buds.setField("UPD_APLY_NO", G210Map.get("UPD_APLY_NO"));
                        buds.setField("CAL_DT", G210Map.get("CAL_DT"));
                        buds.setField("CAL_DT_LS", G210Map.get("CAL_DT_LS"));
                        buds.setField("CHG_DATE", G210Map.get("CHG_DATE"));
                        buds.setField("CHG_DIV_NO", G210Map.get("CHG_DIV_NO"));
                        buds.setField("CHG_ID", G210Map.get("CHG_ID"));
                        buds.setField("CHG_NAME", G210Map.get("CHG_NAME"));

                        buds.addBatch();

                    }
                    buds.executeBatch();
                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap,
                                (Exception) theErrorObject[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException(MessageUtil.getMessage(""));//�s�W��Ʀ��~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException(e);//�妸�s�W����
                }
            }//end 

        } finally {
            if (buds != null) {
                buds.close();
            }
        }

    }

    /**
     * �妸�ק����������[20200323]
     * @param g210List
     * @throws ModuleException
     * @throws DBException
     */
    public void batchUpdate(List<Map> g210List) throws ModuleException, DBException {
        if (g210List == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        BatchConstructor.processByBatch(g210List, SQL_batchUpdate_002, false, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL,
            new BatchConstructor.ListHandler() {
                protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {
                    Map G210Map = (Map) Object;
                    buds.setField("ACC_TP", G210Map.get("ACC_TP"));
                    buds.setField("SUB_ITEM_NO", G210Map.get("SUB_ITEM_NO"));
                    buds.setField("ITEM_MEMO", G210Map.get("ITEM_MEMO"));
                    buds.setField("COST_DT", G210Map.get("COST_DT"));
                    buds.setField("COST_AMT", G210Map.get("COST_AMT"));
                    buds.setField("LOSS_AMT", G210Map.get("LOSS_AMT"));
                    buds.setField("DEPR_YR", G210Map.get("DEPR_YR"));
                    buds.setField("FST_YR_MON", G210Map.get("FST_YR_MON"));
                    buds.setField("ITEM_STS", G210Map.get("ITEM_STS"));
                    buds.setField("APLY_NO", G210Map.get("APLY_NO"));
                    buds.setField("D_APLY_NO", G210Map.get("D_APLY_NO"));
                    buds.setField("CHG_DATE", G210Map.get("CHG_DATE"));
                    buds.setField("CHG_DIV_NO", G210Map.get("CHG_DIV_NO"));
                    buds.setField("CHG_ID", G210Map.get("CHG_ID"));
                    buds.setField("CHG_NAME", G210Map.get("CHG_NAME"));
                    buds.setField("SUB_CPY_ID", G210Map.get("SUB_CPY_ID"));
                    buds.setField("BASE_CD", G210Map.get("BASE_CD"));
                    buds.setField("COST_SEQ", G210Map.get("COST_SEQ"));
                    addBatchAndJoinGroup(buds);
                }
            });
    }

    /**
     * �妸�s�W���������� [20200323]
     * @param listG210
     * @param APLY_NO
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void batchInsert(List<Map> listG210, final String APLY_NO, UserObject user) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (listG210 == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_009")); //�ǤJ�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        final String id = user.getEmpID();
        final String nm = user.getEmpName();
        final String div_no = user.getOpUnit();
        final Timestamp current = DATE.currentTime();

        //�v��Ū��g210List�z�LBUDS �妸���s�W��a��������
        BatchConstructor.processByBatch(listG210, SQL_batchInsert_001, false, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL,
            new BatchConstructor.ListHandler() {
                protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {
                    Map G210Map = (Map) Object;
                    buds.setField("SUB_CPY_ID", G210Map.get("SUB_CPY_ID"));
                    buds.setField("BASE_CD", G210Map.get("BASE_CD"));
                    buds.setField("COST_SEQ", G210Map.get("COST_SEQ"));
                    buds.setField("ACC_TP", G210Map.get("ACC_TP"));
                    buds.setField("SUB_ITEM_NO", G210Map.get("SUB_ITEM_NO"));
                    buds.setField("ITEM_MEMO", G210Map.get("ITEM_MEMO"));
                    buds.setField("COST_DT", G210Map.get("COST_DT"));
                    buds.setField("COST_AMT", G210Map.get("COST_AMT"));
                    buds.setField("LOSS_AMT", G210Map.get("LOSS_AMT"));
                    buds.setField("DEPR_YR", G210Map.get("DEPR_YR"));
                    buds.setField("FST_YR_MON", G210Map.get("FST_YR_MON"));
                    buds.setField("ITEM_STS", G210Map.get("ITEM_STS"));
                    buds.setField("APLY_NO", APLY_NO);
                    buds.setField("D_APLY_NO", "");
                    buds.setField("CHG_DATE", current);
                    buds.setField("CHG_DIV_NO", div_no);
                    buds.setField("CHG_ID", id);
                    buds.setField("CHG_NAME", nm);
                    addBatchAndJoinGroup(buds);
                }
            });
    }

    /**
     * �妸�R����������[20200323]
     * @param listG210
     * @throws ModuleException
     * @throws DBException
     */
    public void batchDelete(List<Map> listG210) throws ModuleException, DBException {
        if (listG210 == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        //�v��Ū��g210List  �z�LBUDS �妸���R����a���������Ȧs�� 
        BatchConstructor.processByBatch(listG210, SQL_batchDelete_001, false, ErrorHandler.DATA_NOT_FOUND_FAIL_ONLY,
            new BatchConstructor.ListHandler() {
                protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {
                    Map G210Map = (Map) Object;
                    buds.setField("SUB_CPY_ID", G210Map.get("SUB_CPY_ID"));
                    buds.setField("BASE_CD", G210Map.get("BASE_CD"));
                    buds.setField("COST_SEQ", G210Map.get("COST_SEQ"));
                    addBatchAndJoinGroup(buds);
                }
            });
    }

    /**
     * Ū����a���������Ȧs��[20200323]
     * @param reqMap
     * @param ACC_TP
     * @return
     * @throws ModuleException
     */
    public List<Map> queryG210WithTempList(Map reqMap) throws ModuleException {
        if (reqMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G210_MSG_001")); //�ǤJ���󤣱o����
        }

        ErrorInputException eie = null;

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_002")); //�ǤJ�����q�O���o���ŭ�
        }

        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_003")); //�ǤJ��a�N�����o���ŭ�
        }
        String ACC_TP = MapUtils.getString(reqMap, "ACC_TP");
        if (StringUtils.isBlank(ACC_TP)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_006")); //�ǤJ�|�p���O���o���ŭ� 
        }

        if (eie != null) {
            throw eie;
        }

        //�H�ǤJ�d�ߤ����������©��ӻP���ʼȦs�� (DTEPG210)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("ACC_TP", ACC_TP);
        //�Y���ǤJ���d�߱���
        String aplyNo = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isNotEmpty(aplyNo)) {
            ds.setField("APLY_NO", aplyNo);
        } else {
            //���ǤJ
            String qryUpdSrc = "13"; //�����d��
            ds.setField("qryUpdSrc", qryUpdSrc);
        }

        setFieldIfExist(ds, reqMap, "APLY_NO");

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryG210WithTempList_001);
        // �v���B�z�^�ǲM��G
        for (Map rtnMap : rtnList) {
            //�u������  
            rtnMap.put("SUB_ITEM_NO_NM", FieldOptionList.getName("EP", "G3_SUB_ITEM_NO", MapUtils.getString(rtnMap, "SUB_ITEM_NO")));
            //�|�p����
            rtnMap.put("ACC_TP_NM", FieldOptionList.getName("EP", "ACC_TP", MapUtils.getString(rtnMap, "ACC_TP")));
            //�������A
            rtnMap.put("ITEM_STS_NM", FieldOptionList.getName("EP", "ITEM_STS", MapUtils.getString(rtnMap, "ITEM_STS")));
            //[20200414]���ʧO 
            rtnMap.put("UPD_TP_NM", FieldOptionList.getName("EP", "UPD_TP", MapUtils.getString(rtnMap, "UPD_TP")));
        }

        return rtnList;
    }

    /**
     * �d�߰�a���������Ȧs�M��[20200323]
     * @param reqMap
     * @param UPD_SRC ���ʨӷ�  11:��������;13:�����d��
     * @return
     * @throws ModuleException
     */
    public List<Map> queryTempList(Map reqMap, String UPD_SRC) throws ModuleException {
        if (reqMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G210_MSG_001")); //�ǤJ���󤣱o����
        }

        ErrorInputException eie = null;

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_002")); //�ǤJ�����q�O���o���ŭ�
        }

        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_003")); //�ǤJ��a�N�����o���ŭ�
        }

        if (StringUtils.isBlank(UPD_SRC)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_011")); //�ǤJ���ʨӷ����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        StringBuilder sb = new StringBuilder();

        // �d�߰�a������������Ȧs��� (DTEPG209)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        setLikeFieldsIfExsits(ds, reqMap, "BASE_CD", sb);
        setLikeFieldsIfExsits(ds, reqMap, "ACC_TP", sb);

        ds.setField("UPD_SRC", sb.append('%').append(UPD_SRC).append('%').toString());
        sb.setLength(0);

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryTempList_001);

        // �v���B�z�^�ǲM��G
        for (Map rtnMap : rtnList) {
            //�|�p����
            rtnMap.put("ACC_TP_NM", FieldOptionList.getName("EP", "ACC_TP", MapUtils.getString(rtnMap, "ACC_TP")));
            //�u������  
            rtnMap.put("SUB_ITEM_NO_NM", FieldOptionList.getName("EP", "G3_SUB_ITEM_NO", MapUtils.getString(rtnMap, "SUB_ITEM_NO")));
            //�������A
            rtnMap.put("ITEM_STS_NM", FieldOptionList.getName("EP", "ITEM_STS", MapUtils.getString(rtnMap, "ITEM_STS")));
            //���ʧO
            rtnMap.put("UPD_TP_NM", FieldOptionList.getName("EP", "UPD_TP", MapUtils.getString(rtnMap, "UPD_TP")));
        }
        return rtnList;
    }

    /**
     * �s�W��a���������Ȧs��[20200323]
     * @param g209Map
     * @param user
     * @param UPD_SRC ���ʨӷ�  11:��������;13:�����d��
     * @throws ModuleException
     */
    public void insertTemp(Map g209Map, UserObject user, String UPD_SRC) throws ModuleException {
        ErrorInputException eie = null;
        if (g209Map == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_009")); //�ǤJ�@�~�H�����o���ŭ�
        }
        if (UPD_SRC == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_011")); //�ǤJ���ʨӷ����o���ŭ� 
        }
        if (eie != null) {
            throw eie;
        }

        String SUB_CPY_ID = MapUtils.getString(g209Map, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_002")); //�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(g209Map, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_003")); //�ǤJ��a�N�����o���ŭ�
        }
        String ACC_TP = MapUtils.getString(g209Map, "ACC_TP");
        if (StringUtils.isBlank(ACC_TP)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_006")); //�ǤJ�|�p���O���o���ŭ� 
        }
        if (eie != null) {
            throw eie;
        }
        // �]�w���������Ǹ�
        String COST_SEQ = MapUtils.getString(g209Map, "COST_SEQ");

        if (StringUtils.isBlank(COST_SEQ)) {
            COST_SEQ = new EP_Z0Z001().createNextNo(SUB_CPY_ID, "040", BASE_CD, ACC_TP, ACC_TP, 4);
        }

        //�s�W���������Ȧs�� (DTEPG209)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", g209Map.get("SUB_CPY_ID"));//�����q�O
        ds.setField("BASE_CD", g209Map.get("BASE_CD"));//��a�N��
        ds.setField("COST_SEQ", COST_SEQ);//���������Ǹ�
        ds.setField("UPD_TP", g209Map.get("UPD_TP")); //���ʺ���
        ds.setField("UPD_SRC", UPD_SRC);//���ʨӷ����ǤJ�����ʨӷ�
        ds.setField("ACC_TP", g209Map.get("ACC_TP"));//�|�p���O
        ds.setField("SUB_ITEM_NO", g209Map.get("SUB_ITEM_NO"));//�u������
        ds.setField("ITEM_MEMO", g209Map.get("ITEM_MEMO"));//�������سƵ�
        ds.setField("COST_DT", g209Map.get("COST_DT"));//�M����
        ds.setField("COST_AMT", g209Map.get("COST_AMT"));//��l����
        ds.setField("LOSS_AMT", g209Map.get("LOSS_AMT"));//��l���B
        ds.setField("DEPR_YR", g209Map.get("DEPR_YR"));//���¦~��
        ds.setField("FST_YR_MON", g209Map.get("FST_YR_MON"));//��~�פ��
        ds.setField("ITEM_STS", g209Map.get("ITEM_STS"));//�������A
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());

        DBUtil.executeUpdate(ds, SQL_insertTemp_001);
    }

    /**
     * �妸�s�W���������Ȧs�� [20200323]
     * @param listG210
     * @param APLY_NO
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void batchInsertTemp(List<Map> listG210, UserObject user) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (listG210 == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_009")); //�ǤJ�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        final String id = user.getEmpID();
        final String nm = user.getEmpName();
        final String div_no = user.getOpUnit();
        final Timestamp current = DATE.currentTime();

        //�v��Ū��g210List�z�LBUDS �妸���s�W��a��������
        BatchConstructor.processByBatch(listG210, SQL_insertTemp_001, false, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL,
            new BatchConstructor.ListHandler() {
                protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {
                    Map G210Map = (Map) Object;
                    buds.setField("SUB_CPY_ID", G210Map.get("SUB_CPY_ID"));
                    buds.setField("BASE_CD", G210Map.get("BASE_CD"));
                    buds.setField("COST_SEQ", G210Map.get("COST_SEQ"));
                    buds.setField("UPD_TP", "I"); //���ʺ���
                    buds.setField("UPD_SRC", "11");//���ʨӷ����ǤJ�����ʨӷ�                    
                    buds.setField("ACC_TP", G210Map.get("ACC_TP"));
                    buds.setField("SUB_ITEM_NO", G210Map.get("SUB_ITEM_NO"));
                    buds.setField("ITEM_MEMO", G210Map.get("ITEM_MEMO"));
                    buds.setField("COST_DT", G210Map.get("COST_DT"));
                    buds.setField("COST_AMT", G210Map.get("COST_AMT"));
                    buds.setField("LOSS_AMT", G210Map.get("LOSS_AMT"));
                    buds.setField("DEPR_YR", G210Map.get("DEPR_YR"));
                    buds.setField("FST_YR_MON", G210Map.get("FST_YR_MON"));
                    buds.setField("ITEM_STS", G210Map.get("ITEM_STS"));
                    buds.setField("CHG_DATE", current);
                    buds.setField("CHG_DIV_NO", div_no);
                    buds.setField("CHG_ID", id);
                    buds.setField("CHG_NAME", nm);
                    addBatchAndJoinGroup(buds);
                }
            });
    }

    /**
     * ��s��a���������Ȧs��[20200323]
     * @param g209Map
     * @param user
     * @throws ModuleException
     */
    public void updateTemp(Map g209Map, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (g209Map == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_009")); //�ǤJ�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String SUB_CPY_ID = MapUtils.getString(g209Map, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_002")); //�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(g209Map, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_003")); //�ǤJ��a�N�����o���ŭ�
        }
        String ACC_TP = MapUtils.getString(g209Map, "ACC_TP");
        if (StringUtils.isBlank(ACC_TP)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_006")); //�ǤJ�J�|�p���O���o���ŭ� 
        }
        String COST_SEQ = MapUtils.getString(g209Map, "COST_SEQ");
        if (StringUtils.isBlank(COST_SEQ)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_004")); //�ǤJ���������Ǹ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //��s�����������ӼȦs�� (DTEPG209)�G
        //����s���ʺ����P���ʨӷ��A�����s�W����J���e
        DataSet ds = Transaction.getDataSet();
        ds.setField("ACC_TP", g209Map.get("ACC_TP"));
        ds.setField("SUB_ITEM_NO", g209Map.get("SUB_ITEM_NO"));
        ds.setField("ITEM_MEMO", g209Map.get("ITEM_MEMO"));
        ds.setField("COST_DT", g209Map.get("COST_DT"));
        ds.setField("COST_AMT", g209Map.get("COST_AMT"));
        ds.setField("LOSS_AMT", g209Map.get("LOSS_AMT"));
        ds.setField("DEPR_YR", g209Map.get("DEPR_YR"));
        ds.setField("FST_YR_MON", g209Map.get("FST_YR_MON"));
        ds.setField("ITEM_STS", g209Map.get("ITEM_STS"));
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());

        ds.setField("SUB_CPY_ID", g209Map.get("SUB_CPY_ID"));
        ds.setField("BASE_CD", g209Map.get("BASE_CD"));
        ds.setField("COST_SEQ", g209Map.get("COST_SEQ"));

        DBUtil.executeUpdate(ds, SQL_updateTemp_001);
    }

    /**
     * �R����a���������Ȧs��[20200323]
     * @param g209Map
     * @throws ModuleException
     */
    public void deleteTemp(Map g209Map) throws ModuleException {
        if (g209Map == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }

        ErrorInputException eie = null;

        String SUB_CPY_ID = MapUtils.getString(g209Map, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_002")); //�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(g209Map, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_003")); //�ǤJ��a�N�����o���ŭ�
        }
        String COST_SEQ = MapUtils.getString(g209Map, "COST_SEQ");
        if (StringUtils.isBlank(COST_SEQ)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_004")); //�ǤJ���������Ǹ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�R�����������Ȧs�� (DTEPG209)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("COST_SEQ", COST_SEQ);

        DBUtil.executeUpdate(ds, SQL_deleteTemp_001);
    }

    /**
     * �妸�R�����������Ȧs��[20200323]
     * @param g209Map
     * @throws ModuleException
     * @throws DBException 
     */
    public void batchDeleteTemp(List<Map> g209List) throws ModuleException, DBException {
        if (g209List == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        //�v��Ū��g210List  �z�LBUDS �妸���R����a���������Ȧs�� 
        BatchConstructor.processByBatch(g209List, SQL_deleteTemp_001, false, ErrorHandler.DATA_NOT_FOUND_FAIL_ONLY,
            new BatchConstructor.ListHandler() {
                protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {
                    Map mapG209 = (Map) Object;
                    buds.setField("SUB_CPY_ID", mapG209.get("SUB_CPY_ID"));
                    buds.setField("BASE_CD", mapG209.get("BASE_CD"));
                    buds.setField("COST_SEQ", mapG209.get("COST_SEQ"));
                    addBatchAndJoinGroup(buds);
                }
            });
    }


    /**
     * �妸�s�W������������LOG�� [20200323]
     * @param listG210
     * @param APLY_NO
     * @throws ModuleException
     * @throws DBException
     */
    public void batchInsertLog(List<Map> g210List, final String APLY_NO) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (g210List == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (APLY_NO == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_012")); //�ǤJ����s�����o���ŭ� 
        }
        if (eie != null) {
            throw eie;
        }
        //�s�W��a������������LOG  DTEPG210LOG 
        BatchConstructor.processByBatch(g210List, SQL_batchInsertLog_001, false, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL,
            new BatchConstructor.ListHandler() {
                protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {
                    Map mapG210 = (Map) Object;
                    buds.setField("SUB_CPY_ID", mapG210.get("SUB_CPY_ID"));
                    buds.setField("BASE_CD", mapG210.get("BASE_CD"));
                    buds.setField("COST_SEQ", mapG210.get("COST_SEQ"));
                    buds.setField("UPD_APLY_NO", APLY_NO);
                    buds.setField("ACC_TP", mapG210.get("ACC_TP"));
                    buds.setField("SUB_ITEM_NO", mapG210.get("SUB_ITEM_NO"));
                    buds.setField("ITEM_MEMO", mapG210.get("ITEM_MEMO"));
                    buds.setField("COST_DT", mapG210.get("COST_DT"));
                    buds.setField("COST_AMT", mapG210.get("COST_AMT"));
                    buds.setField("LOSS_AMT", mapG210.get("LOSS_AMT"));
                    buds.setField("DEPR_YR", mapG210.get("DEPR_YR"));
                    buds.setField("FST_YR_MON", mapG210.get("FST_YR_MON"));
                    buds.setField("ITEM_STS", mapG210.get("ITEM_STS"));
                    buds.setField("APLY_NO", mapG210.get("APLY_NO"));
                    buds.setField("D_APLY_NO", mapG210.get("D_APLY_NO"));
                    buds.setField("CHG_DATE", mapG210.get("CHG_DATE"));
                    buds.setField("CHG_DIV_NO", mapG210.get("CHG_DIV_NO"));
                    buds.setField("CHG_ID", mapG210.get("CHG_ID"));
                    buds.setField("CHG_NAME", mapG210.get("CHG_NAME"));
                    addBatchAndJoinGroup(buds);
                }
            });
    }

    /**
     * �妸�R��������������LOG��[20200323]
     * @param logList
     * @throws ModuleException
     * @throws DBException 
     */
    public void batchDeleteLog(List<Map> logList) throws ModuleException, DBException {
        if (logList == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        //�v��Ū��g210List  �z�LBUDS �妸���R����a���������Ȧs�� 
        BatchConstructor.processByBatch(logList, SQL_batchDeleteLog_001, false, ErrorHandler.DATA_NOT_FOUND_FAIL_ONLY,
            new BatchConstructor.ListHandler() {
                protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {
                    Map logMap = (Map) Object;
                    buds.setField("SUB_CPY_ID", logMap.get("SUB_CPY_ID"));
                    buds.setField("BASE_CD", logMap.get("BASE_CD"));
                    buds.setField("COST_SEQ", logMap.get("COST_SEQ"));
                    buds.setField("UPD_APLY_NO", logMap.get("UPD_APLY_NO"));
                    addBatchAndJoinGroup(buds);
                }
            });
    }

    /**
     * [20200323]�T�{���������H�u�ץ����ʩ���
     * @param G211Map
     * @param user
     * @param UPD_SRC ���ʨӷ�  11:��������;13:�����d��
     * @throws ModuleException
     * @throws DBException
     */
    public void confirmUpdate(Map G211Map, UserObject user, String UPD_SRC) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (G211Map == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_009")); //�ǤJ�@�~�H�����o���ŭ�
        }
        if (UPD_SRC == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_011")); //�ǤJ���ʨӷ����o���ŭ� 
        }
        if (eie != null) {
            throw eie;
        }

        String SUB_CPY_ID = MapUtils.getString(G211Map, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_002")); //�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(G211Map, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_003")); //�ǤJ��a�N�����o���ŭ�
        }
        String ACC_TP = MapUtils.getString(G211Map, "ACC_TP");
        if (StringUtils.isBlank(ACC_TP)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G210_MSG_006")); //�ǤJ�|�p���O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String APLY_NO = MapUtils.getString(G211Map, "APLY_NO");

        //20200414 �վ�d�L��Ƶ������`
        try {
            // �d�ߤ�����������
            List<Map> G210List = queryList(G211Map, UPD_SRC);

            // ����X������������LOG
            batchInsertLog(G210List, APLY_NO);

        } catch (DataNotFoundException dnfe) {
            //�������ʳ��O�s�W�A�d�L��Ƶ������`
        }

        // �d�ߤ����������ʼȦs��
        List<Map> G209List = queryTempList(G211Map, UPD_SRC);

        String id = user.getEmpID();
        String nm = user.getEmpName();
        String div_no = user.getOpUnit();
        Timestamp current = DATE.currentTime();

        List<Map> insList = new ArrayList();
        List<Map> updList = new ArrayList();
        for (Map updMap : G209List) {
            String UPD_TP = MapUtils.getString(updMap, "UPD_TP");
            if ("I".equals(UPD_TP)) {//�s�W
                insList.add(updMap);

            } else if ("U".equals(UPD_TP)) {//�ק�
                updMap.put("APLY_NO", APLY_NO);
                updMap.put("D_APLY_NO", "");
                updMap.put("CHG_DATE", current);
                updMap.put("CHG_ID", id);
                updMap.put("CHG_NAME", nm);
                updMap.put("CHG_DIV_NO", div_no);

                updList.add(updMap);
            }
        }
        //���s�W��������
        if (insList.size() > 0) {
            batchInsert(insList, APLY_NO, user);
        }
        //����s��������
        if (updList.size() > 0) {
            batchUpdate(updList);
        }

        //���R�����������Ȧs��
        batchDeleteTemp(G209List);
    }

    private void setLikeFieldsIfExsits(DataSet ds, Map reqMap, String key, StringBuilder sb) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            sb.append('%').append(value).append('%');
            ds.setField(key, sb.toString());
            sb.setLength(0);
        }
    }

    /**
     * dataset ��
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, Map tmpMap, String key) {
        String value = MapUtils.getString(tmpMap, key);
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }

    }

    /**
     * ��s���³B�z���A
     * @param dataMap
     * @param user
     * @param DEPR_STS
     * @throws ModuleException
     */
    public void updateCalDate(Map dataMap, UserObject user, String deprSTS, String CAL_DT) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_009")); //�ǤJ�@�~�H�����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        String deprKd = (String) dataMap.get("DEPR_KD");
        if ("1".equals(deprSTS)) {
            if ("1".equals(deprKd) || "3".equals(deprKd)) {
                ds.setField("CAL_DT", CAL_DT);
            } else if ("2".equals(deprKd)) {
                ds.setField("CAL_DT_LS", CAL_DT);
            }
        } else {
            if ("1".equals(deprKd) || "3".equals(deprKd)) {
                ds.setField("PRE_CAL_DT", CAL_DT);
            } else if ("2".equals(deprKd)) {
                ds.setField("PRE_CAL_DT_LS", CAL_DT);
            }
        }

        ds.setField("SUB_CPY_ID", dataMap.get("SUB_CPY_ID"));
        ds.setField("DEPR_YM", dataMap.get("DEPR_YM"));
        ds.setField("DEPR_KD", dataMap.get("DEPR_KD"));
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_DATE", DATE.currentTime());
        DBUtil.executeUpdate(ds, SQL_updateCalDate_001);
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
