package com.cathay.ep.z0.module;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.ConnectException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.ep.vo.DTEPZ300;
import com.cathay.ep.vo.DTEPZ301;
import com.cathay.ep.vo.DTEPZ302;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2015/05/14  Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ���ʲ������T���ӷ����@�Ҳ�
 * �Ҳ�ID    EP_Z0Z300
 * ���n����    ���ʲ������T���ӷ����@�Ҳ�
 * </pre>
 * 
 * @author ����[
 * @since 2015/5/19
 * @since [2019-04-29] �ӽЮ�190123001147 - �u�Ƶ{��
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class EP_Z0Z300 {
    private Logger log = Logger.getLogger(EP_Z0Z300.class);

    private boolean isDebug = log.isDebugEnabled();

    private static final String SQL_query_001 = "com.cathay.ep.z0.module.EP_Z0Z300.SQL_query_001";

    private static final String SQL_update_001 = "com.cathay.ep.z0.module.EP_Z0Z300.SQL_update_001";

    /**
     * ���o���ʲ������T���ӷ�
     * @param EVENT_ID
     * @return
     * @throws ModuleException
     */
    public List<DTEPZ300> getSitesList(String EVENT_ID) throws ModuleException {
        // �ˮֶǤJ�Ѽ�:
        if (StringUtils.isBlank(EVENT_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0Z300_MSG_001"));// �ǤJ�ƥ�N�����o���ŭ�!
        }

        // �H�ǤJ�ƥ�N���d�ߤ��ʲ������T���]�w��(DTEPZ300)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("EVENT_ID", EVENT_ID);
        return VOTool.findToVOs(DTEPZ300.class, ds, SQL_query_001);
    }

    /**
     * (���ե�)���oEvent_ID�U�������M��
     * @param EVENT_ID
     * @param start_seq
     * @param count
     * @return
     * @throws ModuleException
     */
    public List<DTEPZ300> getSitesList(String EVENT_ID, int start_seq, Integer count) throws ModuleException {
        // �ˮֶǤJ�Ѽ�:
        if (StringUtils.isBlank(EVENT_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0Z300_MSG_001"));// �ǤJ�ƥ�N�����o���ŭ�!
        }

        // �H�ǤJ�ƥ�N���d�ߤ��ʲ������T���]�w��(DTEPZ300)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("EVENT_ID", EVENT_ID);
        ds.setField("START_SEQ", start_seq);
        if (count != null) {
            ds.setField("END_SEQ", start_seq + count);
        }
        return VOTool.findToVOs(DTEPZ300.class, ds, SQL_query_001);
    }

    /**
     * Ū�����ʲ������T���]�w��
     * @param EVENT_ID
     * @param PCS_SEQ
     * @return
     * @throws ModuleException
     */
    public DTEPZ300 getSite(String EVENT_ID, String PCS_SEQ) throws ModuleException {
        // �ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (StringUtils.isBlank(EVENT_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z300_MSG_001"));// �ǤJ�ƥ�N�����o���ŭ�!
        }
        if (StringUtils.isBlank(PCS_SEQ)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z300_MSG_002"));// �ǤJ�B�z�Ǹ����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        // �H�ǤJ�ƥ�N���B�B�z�Ǹ��d�ߤ��ʲ������T���]�w��(DTEPZ300)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("EVENT_ID", EVENT_ID);
        ds.setField("PCS_SEQ", PCS_SEQ);
        return VOTool.findOneToVO(DTEPZ300.class, ds, SQL_query_001);
    }

    /**
     * ���o�T���ѪR���� (STEP 0)
     * @param site
     * @return
     * @throws ClassNotFoundException
     * @throws SecurityException
     * @throws NoSuchMethodException
     * @throws IllegalArgumentException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public NewsExtractor getExtractor(DTEPZ300 site) throws ClassNotFoundException, SecurityException, NoSuchMethodException,
            IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException {

        // ���o�T���ѪR����
        Class<?> clazz = Class.forName(site.getEXTRACTOR());
        Constructor<?> ctor = clazz.getConstructor(DTEPZ300.class);
        NewsExtractor extractor = (NewsExtractor) ctor.newInstance(new Object[] { site });
        return extractor;
    }

    /**
     * �ѪR�����T��
     * @param EVENT_ID
     * @return
     * @throws ModuleException
     * @throws SecurityException
     * @throws IllegalArgumentException
     * @throws ClassNotFoundException
     * @throws NoSuchMethodException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public Map getNews(final String EVENT_ID) throws ModuleException, SecurityException, IllegalArgumentException, ClassNotFoundException,
            NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {

        // 2018-06-26 �t�Τ@�� �]SSL Security.setProperty�S�w���g�覡�|�v�TJVM��SSL�B�@����A�N�]�w�{������
        // 2019-05-03 �į��u��:���thread����

        List<DTEPZ300> sites = getSitesList(EVENT_ID);
        final List<DTEPZ301> news = new ArrayList<DTEPZ301>();
        final List<DTEPZ302> errSites = new ArrayList<DTEPZ302>();

        log.fatal(EVENT_ID + "�����]�w����:" + sites.size());

        if (isDebug) {
            log.debug("�ѪR��ƶ}�l");
        }

        int threadSize;
        try {
            threadSize = Integer.parseInt(FieldOptionList.getName("EP", "NEWS_DIGEST", "THREAD_COUNT"));
        } catch (Exception e) {
            threadSize = 10;
        }
        final ScheduledExecutorService executor = Executors.newScheduledThreadPool(threadSize);
        List<Future> handlerList = new ArrayList<Future>();

        // �v�@�����T���ӷ��B�z
        for (final DTEPZ300 site : sites) {

            Future handler = executor.submit(new Callable() {

                public Object call() throws Exception {

                    int PCS_SEQ = site.getPCS_SEQ();
                    String logMsg = EVENT_ID + "-" + PCS_SEQ;
                    try {

                        // ���o�T���ѪR����
                        NewsExtractor extractor = getExtractor(site);
                        // �ѪR���
                        List<DTEPZ301> newData = extractor.extractNews();
                        if (newData == null || newData.size() == 0) {
                            addNoDataToErrorSites(errSites, site, "��T�ӷ��L���");
                            return null;
                        }

                        if (isDebug)
                            log.debug(logMsg + "�L�o����r�e�T������:" + newData.size());

                        //[20190429] �P�_�O�_�t����r
                        //�L�o����r
                        filterKeyWords(newData, site.getKEYWORD());

                        if (isDebug)
                            log.debug(logMsg + "�L�o����r�e�T������:" + newData.size());

                        //�L�o�w�q���T��
                        filterOldNews(EVENT_ID, PCS_SEQ, newData);

                        if (isDebug)
                            log.debug(logMsg + "�L�o�w�q����T������:" + newData.size());

                        if (newData.size() == 0) {
                            addNoDataToErrorSites(errSites, site, "�L�o�w�q���T����L���");
                        }

                        news.addAll(newData);

                    } catch (ConnectException e) {
                        log.error(logMsg + ":�ѪR�����o�Ϳ��~ConnectException");
                        addToErrorSites(errSites, site, e);
                    } catch (Exception e) {
                        log.error(logMsg + ":�ѪR�����o�Ϳ��~Exception");
                        addToErrorSites(errSites, site, e);
                    } catch (Throwable e) {
                        log.error(logMsg + ":�ѪR�����o�Ϳ��~Throwable");
                        addToErrorSites(errSites, site, e);
                    }

                    return null;
                }

            });

            handlerList.add(handler);

        }

        int threadTimeout;
        try {
            threadTimeout = Integer.parseInt(FieldOptionList.getName("EP", "NEWS_DIGEST", "THREAD_TIMEOUT"));
        } catch (Exception e) {
            threadTimeout = 70000; //��connet_timeout�j
        }

        for (int i = 0; i < handlerList.size(); i++) {
            Future handler = handlerList.get(i);
            try {
                handler.get(threadTimeout, TimeUnit.MILLISECONDS);
            } catch (Exception e) {
                DTEPZ300 site = sites.get(i);
                log.error(site.getEVENT_ID() + "-" + site.getPCS_SEQ() + ":�ѪR����thread���`", e);
                addToErrorSites(errSites, site, e);
            } finally {
                if (!handler.isCancelled() || !handler.isDone()) {
                    handler.cancel(true);
                }
            }
        }

        executor.shutdownNow();

        Map rtnMap = new HashMap();
        rtnMap.put("NEWS", news);
        rtnMap.put("ERR_SITES", errSites);
        rtnMap.put("SITES", sites);
        rtnMap.put("PCS_DT", DATE.getDBTimeStamp());
        return rtnMap;
    }

    /**
     * �L�o����r
     * @param newData
     * @param keyword
     */
    public void filterKeyWords(List<DTEPZ301> newData, String keyword) {
        //DTEPZ300��keyword�]�w
        boolean isMatchKeyWord = StringUtils.isNotEmpty(keyword);
        if (isMatchKeyWord) {
            String[] keys = (keyword == null || keyword.length() == 0) ? new String[0] : StringUtils.split(keyword, "|");

            //���o"�ݩ���"������r
            Map<String, String> chkMap;
            try {
                chkMap = FieldOptionList.getName("EP", "KEYWORD_CHECK");
            } catch (Exception e) {
                // �����S���]�w
                chkMap = Collections.emptyMap();
            }

            Iterator<DTEPZ301> iNews = newData.iterator();
            while (iNews.hasNext()) {
                DTEPZ301 Z301 = iNews.next();
                String title = Z301.getTITLE();
                if (!this.checkKeyWord(isMatchKeyWord, keys, chkMap, title)) {
                    iNews.remove();
                }
            }
        }

    }

    /**
     * �B�z����r
     * @param title
     * @return
     */
    private boolean checkKeyWord(boolean isMatchKeyWord, String[] keywords, Map<String, String> chkMap, String title) {
        boolean chkKeyWord = true;
        if (isMatchKeyWord) {
            chkKeyWord = false;
            for (String key : keywords) {
                if (matchKeyWord(title, key, chkMap)) {
                    chkKeyWord = true;
                    break;
                }
            }
        }
        return chkKeyWord;

    }

    /**
     * �������r
     * @param title
     * @return
     */
    private boolean matchKeyWord(String title, String key, Map<String, String> chkMap) {

        boolean chkKeyWord = false;
        if (title.indexOf(key) >= 0) {
            //log.debug("title:" + title + " match [" + key + "]");
            Set<String> chkKeys = chkMap.keySet();
            int cnt1 = wordCount(title, key);
            int cnt = 0;
            for (String word : chkKeys) {
                String keyWd = chkMap.get(word);
                if (key.equals(keyWd)) {
                    //log.debug("����r:" + key + ", �����r��:" + word);
                    cnt += wordCount(title, word);
                }
            }
            //log.debug("����r��[" + key + "]:" + cnt1);
            //log.debug("�����r��[" + chkMap + "]:" + cnt);
            if (cnt != cnt1) {
                chkKeyWord = true;
            }
        }
        return chkKeyWord;
    }

    private int wordCount(String text, String keyword) {
        Pattern p = Pattern.compile("(" + keyword + ")");
        Matcher m = p.matcher(text);

        int cnt = 0;
        while (m.find()) {
            cnt++;
        }
        return cnt;
    }

    /**
     * �L�o�°T��
     * @param EVENT_ID
     * @param news
     * @throws ModuleException
     */
    public void filterOldNews(String EVENT_ID, int PCS_SEQ, List<DTEPZ301> news) throws ModuleException {
        // ���o�����T���q��
        EP_Z0Z301 theEP_Z0Z301 = new EP_Z0Z301();
        //��url�d�߬O�_�°T��
        //[2019-05-03] �W�[�d�߱���,��ְ���ɶ�
        Map<String, DTEPZ301> newsMap = theEP_Z0Z301.queryNewsMap(EVENT_ID, PCS_SEQ, news);
        //�ˮ֥����T���O�_�w�g�ѪR�L
        Iterator<DTEPZ301> iNews = news.iterator();
        while (iNews.hasNext()) {
            DTEPZ301 z301 = iNews.next();
            // key = url + title
            String key = theEP_Z0Z301.getKey(z301);
            if (newsMap.containsKey(key)) {
                iNews.remove();
            }
        }
    }

    /**
     * �s�W�ѪR���Ѭ���(�ѪR���~)
     * @param errSites
     * @param site
     * @param e
     * @throws ModuleException
     */
    private void addToErrorSites(List<DTEPZ302> errSites, DTEPZ300 site, Throwable e) throws ModuleException {
        // ���~�B�z �s�JDTEPZ302

        DTEPZ302 err = new DTEPZ302();
        VOTool.copyVOFromTo(site, err);

        err.setERR_MSG(getTextByByteLen(e.getMessage(), 300));

        StringWriter errors = new StringWriter();
        e.printStackTrace(new PrintWriter(errors));
        String stackTrace = getTextByByteLen(errors.toString(), 1500);
        err.setSTACK_TRACE(stackTrace);

        errSites.add(err);

    }

    /**
     * �s�W�ѪR���Ѭ���(�L�s�T��)
     * @param errSites
     * @param site
     * @param e
     * @throws ModuleException
     */
    private void addNoDataToErrorSites(List<DTEPZ302> errSites, DTEPZ300 site, String errMsg) throws ModuleException {
        // ���~�B�z �s�JDTEPZ302

        DTEPZ302 err = new DTEPZ302();
        VOTool.copyVOFromTo(site, err);

        err.setERR_MSG(getTextByByteLen(errMsg, 200));

        err.setSTACK_TRACE("");

        errSites.add(err);
    }

    /**
     * ��sZ300�̷s�d�߮ɶ�
     * @param budsZ300
     * @param commit_size
     * @param rtnMap
     * @param PCS_DT
     * @return
     * @throws Exception
     */
    public BatchUpdateDataSet updatePCS_DATEforBatch(BatchUpdateDataSet budsZ300, int commit_size, Map<String, Object> rtnMap,
            Timestamp PCS_DT) throws Exception {

        budsZ300.clear();
        budsZ300.preparedBatch(SQL_update_001);

        List<DTEPZ300> sites = (List<DTEPZ300>) rtnMap.get("SITES");
        if (sites != null && !sites.isEmpty()) {
            // �Ynews ����ơA�z�L BUDS ���@����X

            int batchCount = (sites.size() / commit_size) + 1;
            for (int i = 1; i <= batchCount; i++) {
                int initS = (i - 1) * commit_size;
                int initE = (i == batchCount) ? sites.size() : i * commit_size; // �������
                budsZ300.beginTransaction(); // �������}�l
                try {
                    // �v���B�z
                    for (int j = initS; j < initE; j++) {
                        DTEPZ300 site = sites.get(j);
                        VOTool.voToDataSet(site, budsZ300);
                        budsZ300.setField("PCS_DT", PCS_DT);
                        budsZ300.addBatch();
                    }// while loop end
                    budsZ300.executeBatch();

                    Object theErrorObject[][] = budsZ300.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s�����]�w��,��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap,
                                (Exception) theErrorObject[k][2]);
                        }
                        // ��s��Ʀ��~
                        throw new ModuleException(MessageUtil.getMessage(""));// �s�W��Ʀ��~
                    }

                    budsZ300.endTransaction();

                } catch (Exception e) { // �Y����L�{���o�Ͳ��`���p
                    budsZ300.rollbackTransaction(); // �^�_��媺�@�~
                    throw e; // �Y�o�Ϳ��~�h�{���X�פ�
                }
            } // for loop end
        }

        return budsZ300;
    }

    /**
     * �^���r�����
     * 
     * @param errMsg
     * @param byteLen
     * @return
     */
    private String getTextByByteLen(String errMsg, int byteLen) {
        if (StringUtils.isBlank(errMsg)) {
            return "";
        }
        try {
            errMsg = STRING.subStringByByteArray(errMsg, byteLen, false, EncodingHelper.Charset_UTF8);
        } catch (Exception e1) {
            errMsg = errMsg.substring(0, (byteLen / 3));
        }
        return errMsg;
    }

    /**
     * ��wEIE����
     * 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
