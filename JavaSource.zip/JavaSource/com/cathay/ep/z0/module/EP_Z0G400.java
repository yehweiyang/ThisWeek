package com.cathay.ep.z0.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2015/01/20  Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �Y�ɧQ�βv�@�~�Ҳ�
 * �Ҳ�ID    EP_Z0G400
 * ���n����    �Y�ɧQ�βv�@�~
 * </pre>
 * @author ����[
 * @since 2015/1/21
 */
@SuppressWarnings("unchecked")
public class EP_Z0G400 {

    private static final String SQL_query_001 = "com.cathay.ep.z0.module.EP_Z0G400.SQL_query_001";

    /**
     * Ū����a�Y�ɧQ�βv
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> query(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String CAL_YM = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G400_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G400_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G400_MSG_003"));//�ǤJ�p��~�뤣�o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        //�H�ǤJ�����q�O�d�ߧY�ɧQ�βv(DTEPG400)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CAL_YM", CAL_YM);
      
        //150506 Modified�W�[�b�U�O
        String BAL_TYPE = MapUtils.getString(reqMap,"BAL_TYPE");
        if("SG".equals(BAL_TYPE)){
            ds.setField("BAL_TYPE_LIST", "1");//B.BAL_TYPE IN {��SF��,  ��GL��}
        }else if(StringUtils.isNotBlank(BAL_TYPE)){
            ds.setField("BAL_TYPE", BAL_TYPE);
        }
        
        DBUtil.searchAndRetrieve(ds, SQL_query_001);

        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //���j�Ӻ���
            rtnMap.put("INV_BLD_KD_NM", FieldOptionList.getName("EP", "INV_BLD_KD", MapUtils.getString(rtnMap, "INV_BLD_KD")));

            rtnList.add(rtnMap);
        }

        return rtnList;

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}
