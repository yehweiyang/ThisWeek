package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE Description Author
 * 2014/09/17  Created ������
 * 
 * �@�B  �ҲզW��	��a�����ƺ��@�Ҳ�
 * �Ҳ�ID	EP_Z0G200
 * ���n����	��a�����ƺ��@�Ҳ�
 * 
 * [20190212]Modified�վ�d�߱���PDTEPG201_LOG���(�u����)�վ㤣�n�ϥ�VOTool.insert �߮׳渹 : 190130000429
 * </pre>
 * @author ������
 * @since 2014/12/29
 * 
 * [20200312]�ק��
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0G201 {

    private static final Logger log = Logger.getLogger(EP_Z0G201.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_queryList_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_queryMap_001";

    private static final String SQL_update_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_update_001";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_delete_001";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_insert_001";

    private static final String SQL_insert_002 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_insert_002";

    private static final String SQL_querySummary_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_querySummary_001";

    private static final String SQL_queryToDoList_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_queryToDoList_001";

    private static final String SQL_queryByAplyNo_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_queryByAplyNo_001";

    private static final String SQL_batchUpdAplyNo_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_batchUpdAplyNo_001";

    //private static final String SQL_confirm_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_confirm_001";

    //private static final String SQL_approve_001 = "com.cathay.ep.z0.module.EP_Z0G201.SQL_approve_001";

    /**
     * Ū����a����M��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    /*[20190212] �߮׳渹 : 190130000429*/
    public List<Map> queryList(Map reqMap) throws ModuleException {
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_001"));//�ǤJ��T���o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
        }

        List<Map> rtnList;
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        setFieldIfExist(ds, "BASE_CD", BASE_CD);

        String KIND = MapUtils.getString(reqMap, "KIND");
        setFieldIfExist(ds, "KIND", KIND);
        String BASE_USE_CD = MapUtils.getString(reqMap, "BASE_USE_CD");
        setFieldIfExist(ds, "BASE_USE_CD", BASE_USE_CD);

        rtnList = VOTool.findToMaps(ds, SQL_queryList_001);

        for (Map rtnMap : rtnList) {
            //���ۥ�
            String BS_USE_CD = MapUtils.getString(rtnMap, "BASE_USE_CD");
            rtnMap.put("BASE_USE_CD_NM", FieldOptionList.getName("EP", "BASE_USE_CD", BS_USE_CD));
            //���O
            rtnMap.put("KIND_NM", FieldOptionList.getName("EP", "KIND", MapUtils.getString(rtnMap, "KIND")));
            //�������O	
            String COST_TP = MapUtils.getString(rtnMap, "COST_TP");
            if (StringUtils.isNotEmpty(COST_TP)) {
                rtnMap.put("COST_TP_NM", FieldOptionList.getName("EP", "COST_TP", COST_TP));
            }
            //�]�w��a�N�����
            if ("1".equals(BS_USE_CD)) {
                rtnMap.put("BASE_SHOW", rtnMap.get("INV_CD"));
            } else {
                rtnMap.put("BASE_SHOW", rtnMap.get("SLF_CD"));
            }

        }

        return rtnList;
    }

    /**
     * Ū����a����M��(�u�����ϥ�)
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    /*[20190212] �߮׳渹 : 190130000429*/
    public List<Map> queryListforTableUI(Map reqMap, boolean isReal, ResponseContext resp, boolean isFirstQuery, Integer startWith,
            Integer endWith) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_001"));//�ǤJ��T���o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }

        List<Map> rtnList;
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        setFieldIfExist(ds, "BASE_CD", BASE_CD);

        String KIND = MapUtils.getString(reqMap, "KIND");
        setFieldIfExist(ds, "KIND", KIND);
        String BASE_USE_CD = MapUtils.getString(reqMap, "BASE_USE_CD");
        setFieldIfExist(ds, "BASE_USE_CD", BASE_USE_CD);

        if (isReal) {
            ds.setFetchRange(startWith, endWith);//�u�����\�� �_����ƦC �]�w
        }

        rtnList = VOTool.findToMaps(ds, SQL_queryList_001);

        if (isReal && isFirstQuery) {
            resp.addOutputData("totalOfRecords", ds.getQueryTotalCount()); // ���o-�`����,�u�����\��T�w�ѼƦW��
        }

        for (Map rtnMap : rtnList) {
            //���ۥ�
            String BS_USE_CD = MapUtils.getString(rtnMap, "BASE_USE_CD");
            rtnMap.put("BASE_USE_CD_NM", FieldOptionList.getName("EP", "BASE_USE_CD", BS_USE_CD));
            //���O
            rtnMap.put("KIND_NM", FieldOptionList.getName("EP", "KIND", MapUtils.getString(rtnMap, "KIND")));
            //�������O  
            String COST_TP = MapUtils.getString(rtnMap, "COST_TP");
            if (StringUtils.isNotEmpty(COST_TP)) {
                rtnMap.put("COST_TP_NM", FieldOptionList.getName("EP", "COST_TP", COST_TP));
            }
            //�]�w��a�N�����
            if ("1".equals(BS_USE_CD)) {
                rtnMap.put("BASE_SHOW", rtnMap.get("INV_CD"));
            } else {
                rtnMap.put("BASE_SHOW", rtnMap.get("SLF_CD"));
            }

        }

        return rtnList;
    }

    /**
     * Ū����a��������
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryMap(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        String ITEM_SEQ = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_001"));//�ǤJ��T���o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_002");//�ǤJ�����q�O���o���ŭ�
            }
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_003");//�ǤJ��a�N�����o���ŭ�
            }
            ITEM_SEQ = MapUtils.getString(reqMap, "ITEM_SEQ");
            if (StringUtils.isBlank(ITEM_SEQ)) {
                eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_004");//�ǤJ���ӧǸ����o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();

        //�YAPLY_NO����
        //�H�ǤJ�����q�O�d�߮ץ�_��a�򥻸���ܧ����(DTEPB312)�G
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("ITEM_SEQ", ITEM_SEQ);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001, false);

        //���ۥ�
        rtnMap.put("BASE_USE_CD_NM", FieldOptionList.getName("EP", "BASE_USE_CD", MapUtils.getString(rtnMap, "BASE_USE_CD")));
        //���O
        rtnMap.put("KIND_NM", FieldOptionList.getName("EP", "KIND", MapUtils.getString(rtnMap, "KIND")));
        //�������O	
        String COST_TP = MapUtils.getString(rtnMap, "COST_TP");
        if (StringUtils.isNotEmpty(COST_TP)) {
            rtnMap.put("COST_TP_NM", FieldOptionList.getName("EP", "COST_TP", COST_TP));
        }

        return rtnMap;

    }

    /**
     * �ק�
     * @param dataMap   ��a��������
     * @param user      �@�~�H��
     * @throws ModuleException 
     */
    /*[20190212] �߮׳渹 : 190130000429*/
    public void update(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null || dataMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_001")); //�ǤJ��T���o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_002");//�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(dataMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_003");//�ǤJ��a�N�����o���ŭ�
        }
        String ITEM_SEQ = MapUtils.getString(dataMap, "ITEM_SEQ");
        if (StringUtils.isBlank(ITEM_SEQ)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_004");//�ǤJ���ӧǸ����o���ŭ�
        }

        if (user == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_005"); //�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String empID = user.getEmpID();
        String empName = user.getEmpName();
        Timestamp currentTime = DATE.currentTime();

        this.insertLog(dataMap, currentTime, empID, empName, "U");
        //��s�������������T
        DataSet ds = Transaction.getDataSet();
        setDSFields(dataMap, ds);
        ds.setField("CHG_DATE", currentTime);
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_ID", empID);
        ds.setField("CHG_NAME", empName);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_update_001);
    }

    /**
     * �R��
     * @param dataMap   ��a��������
     * @param user      �@�~�H��
     * @throws ModuleException 
     */
    /*[20190212] �߮׳渹 : 190130000429*/
    public void delete(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null || dataMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_001")); //�ǤJ��T���o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID", "");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_002");//�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(dataMap, "BASE_CD", "");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_003");//�ǤJ��a�N�����o���ŭ�
        }
        String ITEM_SEQ = MapUtils.getString(dataMap, "ITEM_SEQ");
        if (StringUtils.isBlank(ITEM_SEQ)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_004");//�ǤJ���ӧǸ����o���ŭ�
        }

        if (user == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G103_MSG_006"); //�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        this.insertLog(dataMap, DATE.currentTime(), user.getEmpID(), user.getEmpName(), "D");
        //�R���������������T
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("ITEM_SEQ", ITEM_SEQ);
        DBUtil.executeUpdate(ds, SQL_delete_001);
    }

    /**
     * �s�W
     * @param dataMap   ��a��������
     * @param user      �@�~�H��
     * @throws ModuleException 
     */
    public void insert(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null || dataMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_001")); //�ǤJ��T���o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID", "");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_002");//�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(dataMap, "BASE_CD", "");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_003");//�ǤJ��a�N�����o���ŭ�
        }
        String WK_DATE = DATE.getDBDate();
        String year = WK_DATE.substring(0, 4);
        String ITEM_SEQ = new EP_Z0Z001().createNextNo(SUB_CPY_ID, "041", BASE_CD, year, year, 4);
        dataMap.put("ITEM_SEQ", ITEM_SEQ);
        if (user == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_005"); //�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�s�W�������������T
        DataSet ds = Transaction.getDataSet();
        // SET FIELDS By dataMap
        setDSFields(dataMap, ds);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        DBUtil.executeUpdate(ds, SQL_insert_001);
    }

    /**
     * �ץX
     * @param reqMap
     * @param user
     * @param resp
     * @throws Exception
     */
    public void export(Map reqMap, UserObject user, ResponseContext resp) throws Exception {

        List<Map> rtnList = this.queryList(reqMap);
        Map sumMap = new HashMap();
        sumMap.put("COST_TP_NM", MessageUtil.getMessage("EPG10120_SUM_ALL"));
        sumMap.put("TRN_AMT", reqMap.get("SUM_AMT_1"));
        sumMap.put("TRN_AREA", reqMap.get("SUM_AREA_1"));
        rtnList.add(sumMap);
        LocaleDisplay display = new LocaleDisplay("EP", user);
        for (Map tMap : rtnList) {
            if (StringUtils.isNotBlank(MapUtils.getString(tMap, "TRN_DT"))) {
                tMap.put("TRN_DT", display.formatDate((Date) tMap.get("TRN_DT"), "/", "/"));
            } else {
                tMap.put("TRN_DT", "");
            }
        }

        XlsUtils xlsUtils = new XlsUtils(MapUtils.getString(reqMap, "fileName"), rtnList, resp);
        String gridJSON = MapUtils.getString(reqMap, "gridJSON");
        xlsUtils.initExportSetting(gridJSON);
        xlsUtils.execute(new XlsUtils.ListProcessHandler() {

        });
    }

    /**
     * ��s�����
     * @param dataMap
     * @param user
     * @throws ModuleException
     */
    public void adjustIFRS_INV_RT(Map dataMap, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (dataMap == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_001"); //�ǤJ��T���o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_005"); //�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //��lG201
        Map mapG201 = new HashMap();
        mapG201.put("SUB_CPY_ID", dataMap.get("SUB_CPY_ID"));
        mapG201.put("BASE_CD", dataMap.get("BASE_CD"));
        mapG201.put("COST_TP", "10");
        mapG201.put("SUB_TP", "00");
        String str_TRN_DT = MapUtils.getString(dataMap, "ADJ_DATE");
        mapG201.put("TRN_DT", (StringUtils.isNotBlank(str_TRN_DT) && DATE.isDate(str_TRN_DT)) ? Date.valueOf(str_TRN_DT) : null);
        StringBuilder sb = new StringBuilder();
        mapG201.put("MEMO", sb.append("�����").append(dataMap.get("INV_RATE_B")).append("�վ㬰").append(dataMap.get("INV_RATE_A")).toString());
        mapG201.put("TRN_AREA", null);
        mapG201.put("APLY_NO", "");

        //���ͧ��g�a����ï�O����
        BigDecimal DIFF_LND_COST_INV = STRING.objToBigDecimal(dataMap.get("DIFF_LND_COST_INV"), BigDecimal.ZERO);
        if (BigDecimal.ZERO.compareTo(DIFF_LND_COST_INV) != 0) {
            //�s�W�@��ï�O����
            mapG201.put("BASE_USE_CD", "1");//���
            mapG201.put("KIND", "1");//�g�a
            mapG201.put("TRN_AMT", DIFF_LND_COST_INV);
            this.insert(mapG201, user);
        }
        //���ͧ��ت�����ï�O����
        BigDecimal DIFF_BLD_COST_INV = STRING.objToBigDecimal(dataMap.get("DIFF_BLD_COST_INV"), BigDecimal.ZERO);
        if (BigDecimal.ZERO.compareTo(DIFF_BLD_COST_INV) != 0) {
            //�s�W�@��ï�O����
            mapG201.put("BASE_USE_CD", "1");//���
            mapG201.put("KIND", "2");//�ت�
            mapG201.put("TRN_AMT", DIFF_BLD_COST_INV);
            this.insert(mapG201, user);
        }
        //���ͦۥΤg�a����ï�O����
        BigDecimal DIFF_LND_COST_SLF = STRING.objToBigDecimal(dataMap.get("DIFF_LND_COST_SLF"), BigDecimal.ZERO);
        if (BigDecimal.ZERO.compareTo(DIFF_LND_COST_SLF) != 0) {
            //�s�W�@��ï�O����
            mapG201.put("BASE_USE_CD", "2");//�ۥ�
            mapG201.put("KIND", "1");//�g�a
            mapG201.put("TRN_AMT", DIFF_LND_COST_SLF);
            this.insert(mapG201, user);
        }
        //���ͦۥΫت�����ï�O����
        BigDecimal DIFF_BLD_COST_SLF = STRING.objToBigDecimal(dataMap.get("DIFF_BLD_COST_SLF"), BigDecimal.ZERO);
        if (BigDecimal.ZERO.compareTo(DIFF_BLD_COST_SLF) != 0) {
            //�s�W�@��ï�O����
            mapG201.put("BASE_USE_CD", "2");//�ۥ�
            mapG201.put("KIND", "2");//�ت�
            mapG201.put("TRN_AMT", DIFF_BLD_COST_SLF);
            this.insert(mapG201, user);
        }
    }

    /**
     * �d�߰�a�����X�p�l�B
     * @param reqMap
     * @return rtnMap
     * @throws ModuleException 
     */
    /*[20190212] �߮׳渹 : 190130000429*/
    public Map querySummary(Map reqMap) throws ModuleException {
        //�ˮֶǤJ�Ѽ�
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_001")); //�ǤJ��T���o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID", "");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_002");//�ǤJ�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        //�H�ǤJ�����q�O�d�߮ץ�_��a�������Ӹ�� (DTEPG201)
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setFieldIfExist(ds, "BASE_CD", MapUtils.getString(reqMap, "BASE_CD"));
        setFieldIfExist(ds, "KIND", MapUtils.getString(reqMap, "KIND"));
        setFieldIfExist(ds, "BASE_USE_CD", MapUtils.getString(reqMap, "BASE_USE_CD"));

        Map rtnMap = VOTool.findOneToMap(ds, SQL_querySummary_001);

        BigDecimal SUM_AREA = STRING.objToBigDecimal(rtnMap.get("SUM_AREA"), BigDecimal.ZERO);
        rtnMap.put("SUM_AREA_1", SUM_AREA.setScale(2, BigDecimal.ROUND_HALF_UP));
        //���n�l�B�]M2�^
        //rtnMap.SUM_AREA_1 = rtnMap.SUM_AREA  �|�ˤ��J��p�ƲĤG��
        rtnMap.put("SUM_AREA_2", SUM_AREA.multiply(new BigDecimal("0.3025")).setScale(2, BigDecimal.ROUND_HALF_UP));
        //���n�l�B�]�W�^
        //rtnMap.SUM_AREA_2 = rtnMap.SUM_AREA *  0.3025  �|�ˤ��J��p�ƲĤG�� 
        return rtnMap;
    }

    // [20200312]�s�W�{���X
    /**
     * Ū���ݳB�z����ï�O����
     * @param reqMap
     * @return rtnList ��a�������Ӹ����DTEPG201(�h��)
     * @throws ModuleException 
     */
    public List<Map> queryToDoList(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_001")); // �ǤJ��T���o���ŭ�
        }

        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID"); // �����q
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_002"); // �ǤJ�����q�O���o���ŭ�
        }
        String DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM"); // ���¦~��(�褸)
        if (StringUtils.isBlank(DEPR_YM)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_008"); // �ǤJ���¦~�뤣�o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        StringBuilder sb = new StringBuilder();
        String newDEPR_YM = sb.append(DEPR_YM.substring(0, 4)).append('-').append(DEPR_YM.substring(4, 6)).toString();
        String qryDate = DATE.getLastMonthLastDate(DATE.addDate(newDEPR_YM + "-01", 0, 1, 0)); // ���¦~�몺�̫�@��
        // �H�ǤJ�����q�O�d�߮ץ�_��a�������Ӹ�� (DTEPG201)
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("qryDate", qryDate);
        setFieldIfExist(ds, "BASE_CD", MapUtils.getString(reqMap, "BASE_CD")); // ��a�N��
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryToDoList_001);

        this.addField(rtnList); // �s�W����^�ǲM�� 

        return rtnList;
    }

    // [20200312]�s�W�{���X
    /**
     * Ū�����������������ï�O����
     * @param reqMap
     * @return rtnList ��a�������Ӹ����DTEPG201(�h��)
     * @throws ModuleException 
     */
    public List<Map> queryByAplyNo(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_001")); // �ǤJ��T���o���ŭ�
        }

        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID"); // �����q
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_002"); // �ǤJ�����q�O���o���ŭ�
        }
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO"); // ����s��
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_010"); // �ǤJ����s�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        // �H�ǤJ�����q�O�d�߮ץ�_��a�������Ӹ�� (DTEPG201)
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);
        setFieldIfExist(ds, "BASE_CD", MapUtils.getString(reqMap, "BASE_CD")); // ��a�N��
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryByAplyNo_001);

        this.addField(rtnList); // �s�W����^�ǲM�� 

        return rtnList;
    }

    // [20200312]�s�W�{���X
    /**
     * �妸��s����ï�O����s��
     * @param g2011List ����ï�O����
     * @param aplyNO ����s��
     * @param user �@�~�H��
     * @throws ModuleException
     */
    public void batchUpdAplyNo(List<Map> g2011List, String aplyNO, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (g2011List == null || g2011List.isEmpty()) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_009"); // ����J����ï�O���ӲM��
        }
        // [20200407] ����aplyNO�ˮ�
        if (user == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_005"); // �@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        final Timestamp currentTime = DATE.currentTime();
        final String empID = user.getEmpID();
        final String empName = user.getEmpName();
        final String opUnit = user.getOpUnit();
        final String APLY_NO = aplyNO;
        try {
            BatchConstructor.processByBatch(g2011List, SQL_batchUpdAplyNo_001, false, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_SUCCESS,
                new BatchConstructor.ListHandler() {
                    protected <T extends Object> void setField(T object, BatchUpdateDataSet buds) throws DBException {
                        Map reqMap = (Map) object;
                        buds.setField("CHG_DATE", currentTime);
                        buds.setField("CHG_ID", empID);
                        buds.setField("CHG_NAME", empName);
                        buds.setField("CHG_DIV_NO", opUnit);
                        buds.setField("APLY_NO", APLY_NO);
                        buds.setField("SUB_CPY_ID", reqMap.get("SUB_CPY_ID"));
                        buds.setField("BASE_CD", reqMap.get("BASE_CD"));
                        buds.setField("ITEM_SEQ", reqMap.get("ITEM_SEQ"));
                        addBatchAndJoinGroup(buds);
                    }
                });
        } catch (Exception e) {
            log.error("�妸��s����ï�O����s������", e);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0G201_MSG_011")); // �妸��s����ï�O����s������
        }

    }

    // [20200312]�s�W�{���X
    /**
     * �s�W����^�ǲM�� 
     * @param rtnList
     */
    private void addField(List<Map> rtnList) {
        // �v���B�z�^�ǲM��G
        // �s�W����^�ǲM�� 
        for (Map rtnMap : rtnList) {
            // ���ۥ�
            rtnMap.put("BASE_USE_CD_NM", FieldOptionList.getName("EP", "BASE_USE_CD", MapUtils.getString(rtnMap, "BASE_USE_CD")));
            // ���O
            rtnMap.put("KIND_NM", FieldOptionList.getName("EP", "KIND", MapUtils.getString(rtnMap, "KIND")));
            // �������O  
            rtnMap.put("COST_TP _NM", FieldOptionList.getName("EP", "COST_TP", MapUtils.getString(rtnMap, "COST_TP")));
            // �]�w��a�N�����
            if ("1".equals(MapUtils.getString(rtnMap, "BASE_USE_CD"))) {
                rtnMap.put("BASE_SHOW", rtnMap.get("INV_CD"));
            } else {
                rtnMap.put("BASE_SHOW", rtnMap.get("SLF_CD"));
            }
        }
    }

    /**
     * �s�W��a�򥻸��LOG��
     * @param MapG201
     * @param UPD_DATE
     * @param UPD_ID
     * @param UPD_NAME
     * @param UPD_TYPE
     * @throws ModuleException 
     */
    /*[20190212] �߮׳渹 : 190130000429*/
    private void insertLog(Map MapG201, Timestamp UPD_DATE, String UPD_ID, String UPD_NAME, String UPD_TYPE) throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (MapG201 == null || MapG201.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G201_MSG_006")); //�ǤJ��a������Ƥ��o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(MapG201, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_002");//�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(MapG201, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_003");//�ǤJ��a�N�����o���ŭ�
        }
        String ITEM_SEQ = MapUtils.getString(MapG201, "ITEM_SEQ");
        if (StringUtils.isBlank(ITEM_SEQ)) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_004");//�ǤJ���ӧǸ����o���ŭ�
        }
        if (UPD_DATE == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G201_MSG_007");//�ǤJ�J�ɤ���ɶ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�g�@��LOG��
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BASE_CD", BASE_CD);
        reqMap.put("ITEM_SEQ", ITEM_SEQ);
        Map mapG201Log = this.queryMap(reqMap);

        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("ITEM_SEQ", ITEM_SEQ);
        ds.setField("UPD_DATE", UPD_DATE);
        ds.setField("BASE_USE_CD", mapG201Log.get("BASE_USE_CD"));
        ds.setField("KIND", mapG201Log.get("KIND"));
        ds.setField("COST_TP", mapG201Log.get("COST_TP"));
        ds.setField("SUB_TP", mapG201Log.get("SUB_TP"));
        ds.setField("TRN_DT", mapG201Log.get("TRN_DT"));
        ds.setField("TRN_AMT", mapG201Log.get("TRN_AMT"));
        ds.setField("TRN_AREA", mapG201Log.get("TRN_AREA"));
        ds.setField("MEMO", mapG201Log.get("MEMO"));
        ds.setField("CHG_DATE", mapG201Log.get("CHG_DATE"));
        ds.setField("CHG_DIV_NO", mapG201Log.get("CHG_DIV_NO"));
        ds.setField("CHG_ID", mapG201Log.get("CHG_ID"));
        ds.setField("CHG_NAME", mapG201Log.get("CHG_NAME"));
        ds.setField("UPD_TYPE", UPD_TYPE);
        ds.setField("UPD_ID", UPD_ID);
        ds.setField("UPD_NAME", UPD_NAME);

        DBUtil.executeUpdate(ds, SQL_insert_002);
    }

    /**
     * �]�w ��a�������� ���
     * @param dataMap
     * @param ds
     */
    private void setDSFields(Map dataMap, DataSet ds) {
        ds.setField("SUB_CPY_ID", dataMap.get("SUB_CPY_ID"));
        ds.setField("BASE_CD", dataMap.get("BASE_CD"));
        ds.setField("ITEM_SEQ", dataMap.get("ITEM_SEQ"));
        ds.setField("BASE_USE_CD", dataMap.get("BASE_USE_CD"));
        ds.setField("KIND", dataMap.get("KIND"));
        ds.setField("COST_TP", dataMap.get("COST_TP"));
        ds.setField("SUB_TP", dataMap.get("SUB_TP"));
        ds.setField("TRN_DT", dataMap.get("TRN_DT"));
        ds.setField("TRN_AMT", dataMap.get("TRN_AMT"));
        ds.setField("TRN_AREA", dataMap.get("TRN_AREA"));
        ds.setField("MEMO", dataMap.get("MEMO"));
        ds.setField("APLY_NO", dataMap.get("APLY_NO"));
        ds.setField("CHG_DATE", dataMap.get("CHG_DATE"));
        ds.setField("CHG_DIV_NO", dataMap.get("CHG_DIV_NO"));
        ds.setField("CHG_ID", dataMap.get("CHG_ID"));
        ds.setField("CHG_NAME", dataMap.get("CHG_NAME"));
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * SQL�����D���n�Ѽ�
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }
}
