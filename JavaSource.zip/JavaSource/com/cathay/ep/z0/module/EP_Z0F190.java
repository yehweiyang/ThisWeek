package com.cathay.ep.z0.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2019/5/20 Created �L�ç�
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �j�ӳ]�Ƴ]�w�ɺ��@�Ҳ�
 * �Ҳ�ID      EP_Z0F190
 * ���n����    �j�ӳ]�Ƴ]�w�ɺ��@�Ҳ�
 * </pre>
 * @author 
 * @since 2019/5/20
 */
@SuppressWarnings("unchecked")
public class EP_Z0F190 {

    private static final String SQL_queryDTEPF190MaxSerNo_001 = "com.cathay.ep.z0.module.EP_Z0F190.SQL_queryDTEPF190MaxSerNo_001";

    private static final String SQL_queryEqpId_001 = "com.cathay.ep.z0.module.EP_Z0F190.SQL_queryEqpId_001";

    private static final String SQL_queryEqpNo_001 = "com.cathay.ep.z0.module.EP_Z0F190.SQL_queryEqpNo_001";

    /**
     * �d�̤߳j�y����
     * @param inMap
     * @return 
     * @throws Exception
     */

    public int queryDTEPF190MaxSerNo(Map inMap) throws ModuleException {
        if (inMap == null || inMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F190_MSG_001")); //�ǤJ�ѼƦ��~
        }
        String BLD_CD = MapUtils.getString(inMap, "BLD_CD");
        String EQP_CD = MapUtils.getString(inMap, "EQP_CD");
        String SUB_EQP_CD = MapUtils.getString(inMap, "SUB_EQP_CD");
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_002")); //�j�ӥN�����o����
        }
        if (StringUtils.isBlank(EQP_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_003")); //�]�ƺ������o����
        }
        if (StringUtils.isBlank(SUB_EQP_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_003")); //�]�ƺ������o����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("EQP_CD", EQP_CD);
        ds.setField("SUB_EQP_CD", SUB_EQP_CD);
        DBUtil.searchAndRetrieve(ds, SQL_queryDTEPF190MaxSerNo_001);

        ds.next();
        return ds.getField(0) == null ? 0 : (Integer) ds.getField(0);
    }

    /**
     * �d�߳]�ƽs��
     * @param inMap
     * @return �]�ƽs��
     * @throws Exception
     */
    public String queryEqpId(Map inMap) throws ModuleException {
        if (inMap == null || inMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F190_MSG_001")); //�ǤJ�ѼƦ��~
        }
        String BLD_CD = MapUtils.getString(inMap, "BLD_CD");
        String EQP_CD = MapUtils.getString(inMap, "EQP_CD");
        String EQP_NO = MapUtils.getString(inMap, "EQP_NO");
        String SUB_CPY_ID = MapUtils.getString(inMap, "SUB_CPY_ID");
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_002")); //�j�ӥN�����o����
        }
        if (StringUtils.isBlank(EQP_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_003")); //�]�ƺ������o����
        }
        if (StringUtils.isBlank(EQP_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_004")); //�]�ƧǸ����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_005")); //�����q�O���o����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();

        ds.setField("BLD_CD", BLD_CD);
        ds.setField("EQP_CD", EQP_CD);
        ds.setField("EQP_NO", EQP_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        DBUtil.searchAndRetrieve(ds, SQL_queryEqpId_001);
        ds.next();
        String EQP_ID = STRING.objToStrNoNull(ds.getField("EQP_ID"));
        return EQP_ID;
    }

    /**
     * �d�߳]�ƧǸ��M��
     * @param inMap
     * @return �]�ƽs��
     * @throws Exception
     */
    public List<Map> queryEqpNo(Map inMap) throws ModuleException {
        if (inMap == null || inMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F190_MSG_001")); //�ǤJ�ѼƦ��~
        }
        String BLD_CD = MapUtils.getString(inMap, "BLD_CD");
        String EQP_CD = MapUtils.getString(inMap, "EQP_CD");
        String SUB_EQP_CD = MapUtils.getString(inMap, "SUB_EQP_CD");
        String SUB_CPY_ID = MapUtils.getString(inMap, "SUB_CPY_ID");
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_002")); //�j�ӥN�����o����
        }
        if (StringUtils.isBlank(EQP_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_003")); //�]�ƺ������o����
        }
        if (StringUtils.isBlank(SUB_EQP_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_003")); //�]�ƺ������o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F190_MSG_005")); //�����q�O���o����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();

        ds.setField("BLD_CD", BLD_CD);
        ds.setField("EQP_CD", EQP_CD);
        ds.setField("SUB_EQP_CD", SUB_EQP_CD);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        DBUtil.searchAndRetrieve(ds, SQL_queryEqpNo_001, false);

        StringBuilder sb = new StringBuilder();
        String EQP_FR_MSG = MessageUtil.getMessage("EP_Z0F190_MSG_006");
        List<Map> rtnList = VOTool.dataSetToMaps(ds);
        for (Map rtnMap : rtnList) {
            String EQP_NO = MapUtils.getString(rtnMap, "EQP_NO");
            String EQP_FR = MapUtils.getString(rtnMap, "EQP_FR");
            String INFO = sb.append(EQP_NO).append("(").append(EQP_FR_MSG).append(EQP_FR).append(")").toString();
            sb.setLength(0);
            rtnMap.put("INFO", INFO);
        }
        return rtnList;
    }

    /**
     * �걵���~�T��
     * @param eie
     * @param msg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(msg);
        return eie;
    }
}