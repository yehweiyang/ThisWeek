package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.rpt.XlsUtils;
import com.cathay.rpt.XlsUtils.SORT_RULE;
import com.cathay.rpt.datasource.xls.ColumnOptions;
import com.cathay.rpt.datasource.xls.ColumnSetting;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE Description Author
 * 2014/10/01  Created ������
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��a���©��Ӭd�߼Ҳ�
 * �Ҳ�ID    EP_Z0G300 
 * ���n����    ��a���©��Ӭd�߼Ҳ�
 * 
 * [20200312] Modified�\��睊 �ק�� (�߮׳渹�G200226001085)
 * �վ����ק� queryList, queryLastestList, qryBuildSumInfo, qryLandSumInfo, queryLatestSumMap��k�d�߱���P���
 * �s�WdeleteDTEPG300
 * [20200330] �X��queryList���, �B�z�����ܰ��D (���D�渹: 20200327142434)
 * [20200401] �ק�W����~ (���D�渹: 20200401142422)
 * [20200407] �R���¤�k
 * [20200506] �վ�N�X�A���s����JUnit
 * [20200506] AllenTsai �W�[Dummy ��k���U�[�{���i�H�sĶ�A����A�NMETHOD �R��
 * [20200507] AllenTsai �R��Dummy��k
 * </pre>
 * @author �Ťl��
 * 
 *
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0G300 {

    private static final Logger log = Logger.getLogger(EP_Z0G300.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G300.SQL_queryList_001";

    private static final String SQL_querySumMap_001 = "com.cathay.ep.z0.module.EP_Z0G300.SQL_querySumMap_001";

    private static final String SQL_qryLandSumInfo_001 = "com.cathay.ep.z0.module.EP_Z0G300.SQL_qryLandSumInfo_001";

    private static final String SQL_qryBuildSumInfo_001 = "com.cathay.ep.z0.module.EP_Z0G300.SQL_qryBuildSumInfo_001";

    private static final String SQL_queryLastestList_001 = "com.cathay.ep.z0.module.EP_Z0G300.SQL_queryLastestList_001";

    private static final String SQL_adjustIFRS_INV_RT_001 = "com.cathay.ep.z0.module.EP_Z0G300.SQL_adjustIFRS_INV_RT_001";

    private static final String SQL_deleteDTEPG_001 = "com.cathay.ep.z0.module.EP_Z0G300.SQL_deleteDTEPG_001";

    //[20200330]��SA�ݨD, �X��queryList��k 

    /**
     * [20200330]�s�W�d�����P�X�֤�k
     * �ץX��a���²M��
     * @param reqMap
     * @return
     * @throws Exception 
     */
    public List<Map> queryList(Map reqMap, ResponseContext resp) throws Exception {
        ErrorInputException eie = null;
        if (reqMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G300_MSG_001")); //�ǤJ���󤣱o����
        }
        final String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        final String DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
        final String DEPR_YM_BEG = MapUtils.getString(reqMap, "DEPR_YM_BEG");
        final String DEPR_YM_END = MapUtils.getString(reqMap, "DEPR_YM_END");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_002")); //�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(DEPR_KD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_003")); //�ǤJ�������O���o���ŭ�
        }
        if (StringUtils.isBlank(DEPR_YM_BEG)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_004")); //�ǤJ���¦~��(�_)���o���ŭ�
        }
        if (StringUtils.isBlank(DEPR_YM_END)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_007")); //�ǤJ���¦~��(��)���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String tableUI_GridJSON = MapUtils.getString(reqMap, "gridJSON");
        String fileName = MapUtils.getString(reqMap, "fileName");//�ɮצW��
        final String BASE_CD = MapUtils.getString(reqMap, "BASE_CD", "");
        final String BAL_TYPE = MapUtils.getString(reqMap, "BAL_TYPE");
        //[20200330] �W�[��J�Ѽ�
        final String KIND = MapUtils.getString(reqMap, "KIND");
        final String INV_CD = MapUtils.getString(reqMap, "INV_CD");
        final String SLF_CD = MapUtils.getString(reqMap, "SLF_CD");
        final String QRY_INV_SLF = MapUtils.getString(reqMap, "QRY_INV_SLF");
        final String CHK = MapUtils.getString(reqMap, "CHK");
        final String DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM");

        //�ץX
        if (resp != null) {
            XlsUtils xlsUtils = new XlsUtils(fileName, resp);
            xlsUtils.initExportSetting(tableUI_GridJSON, null);
            xlsUtils.execute(new XlsUtils.BqdsProcessHandler() {

                protected void searchProcess(BatchQueryDataSet bqds) throws Exception {
                    bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    bqds.setField("DEPR_YM_BEG", DEPR_YM_BEG);
                    bqds.setField("DEPR_YM_END", DEPR_YM_END);
                    bqds.setField("DEPR_KD", DEPR_KD);
                    if (StringUtils.isNotEmpty(BASE_CD)) {
                        bqds.setField("BASE_CD", BASE_CD);
                    }
                    //[20200330] �W�[�d�����
                    if (StringUtils.isNotBlank(DEPR_YM)) {
                        bqds.setField("DEPR_YM", DEPR_YM);
                    }
                    if (StringUtils.isNotBlank(KIND)) {
                        bqds.setField("KIND", KIND);
                    }
                    if (StringUtils.isNotBlank(INV_CD)) {
                        bqds.setField("INV_CD", INV_CD);
                    }
                    if (StringUtils.isNotBlank(SLF_CD)) {
                        bqds.setField("SLF_CD", SLF_CD);
                    }
                    if (StringUtils.isNotBlank(BAL_TYPE)) {
                        bqds.setField("BAL_TYPE", BAL_TYPE);
                    }
                    if (StringUtils.isNotBlank(QRY_INV_SLF)) {
                        bqds.setField("QRY_INV_SLF", QRY_INV_SLF);
                    }
                    if (StringUtils.isNotBlank(CHK)) {
                        bqds.setField("CHK", CHK);
                    }

                    List<String> listINV_SLF_TP = new ArrayList<String>();
                    if ("1".equals(QRY_INV_SLF)) { // �ۥ�
                        listINV_SLF_TP.add("1");
                        listINV_SLF_TP.add("3");
                    } else if ("2".equals(QRY_INV_SLF)) { // ���
                        listINV_SLF_TP.add("2");
                        listINV_SLF_TP.add("3");
                    }
                    if (!listINV_SLF_TP.isEmpty()) {
                        bqds.setFieldValues("listINV_SLF_TP", listINV_SLF_TP);
                    }

                    // �����b�U�O�P�_

                    bqds.searchAndRetrieve(SQL_queryList_001);
                }

                int i = 1;

                /**
                 * �v���B�z
                 */
                protected boolean dataOutputProcess(Map dataMap) {
                    dataMap.put("SER_NO", i++);
                    //���O
                    dataMap.put("KIND_NM", FieldOptionList.getName("EP", "KIND", MapUtils.getString(dataMap, "KIND")));
                    dataMap.put("DEPR_KD_NM", FieldOptionList.getName("EP", "DEPR_KD", MapUtils.getString(dataMap, "DEPR_KD")));
                    //[20200330]�W�[���ܦ^�ǲM��
                    dataMap.put("BAL_TYPE_NM", FieldOptionList.getName("EP", "G3_BAL_TYPE", MapUtils.getString(dataMap, "BAL_TYPE")));
                    dataMap.put("COST_CHK_NM", FieldOptionList.getName("EP", "COST_CHK", MapUtils.getString(dataMap, "COST_CHK")));
                    dataMap.put("DEPR_CHK_NM", FieldOptionList.getName("EP", "DEPR_CHK", MapUtils.getString(dataMap, "DEPR_CHK")));
                    //[20200330]�ק����榡
                    dataMap.put("DEPR_YM", DATE.getROCYearAndMonth(dataMap.get("DEPR_YM").toString()));
                    //[20200401]�ק�IFRS���ʤ������
                    //[20200406]�]�wIFRS���p���I���
                    dataMap.put("IFRS_INV_RT", new BigDecimal("100").multiply(STRING.objToBigDecimal(dataMap.get("IFRS_INV_RT"), BigDecimal.ZERO)).setScale(2).toString()+'%');
                    return true;//true:�����n�ץX ; false:�������ץX
                }
            });
            return null;
        } else {
            //�H�ǤJ�d�ߧ��©��� (DTEPG300)�G
            DataSet ds = Transaction.getDataSet();
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("DEPR_YM_BEG", DEPR_YM_BEG);
            ds.setField("DEPR_YM_END", DEPR_YM_END);
            ds.setField("DEPR_KD", DEPR_KD);
            if (StringUtils.isNotEmpty(BASE_CD)) {
                ds.setField("BASE_CD", BASE_CD);
            }

            //[20200330]�s�W�d�����
            if (StringUtils.isNotBlank(DEPR_YM)) {
                ds.setField("DEPR_YM", DEPR_YM);
            }
            if (StringUtils.isNotBlank(KIND)) {
                ds.setField("KIND", KIND);
            }
            if (StringUtils.isNotBlank(INV_CD)) {
                ds.setField("INV_CD", INV_CD);
            }
            if (StringUtils.isNotBlank(SLF_CD)) {
                ds.setField("SLF_CD", SLF_CD);
            }
            if (StringUtils.isNotBlank(BAL_TYPE)) {
                ds.setField("BAL_TYPE", BAL_TYPE);
            }
            if (StringUtils.isNotBlank(QRY_INV_SLF)) {
                ds.setField("QRY_INV_SLF", QRY_INV_SLF);
            }
            if (StringUtils.isNotBlank(CHK)) {
                ds.setField("CHK", CHK);
            }

            List<String> listINV_SLF_TP = new ArrayList<String>();
            if ("1".equals(QRY_INV_SLF)) { // �ۥ�
                listINV_SLF_TP.add("1");
                listINV_SLF_TP.add("3");
            } else if ("2".equals(QRY_INV_SLF)) { // ���
                listINV_SLF_TP.add("2");
                listINV_SLF_TP.add("3");
            }
            if (!listINV_SLF_TP.isEmpty()) {
                ds.setFieldValues("listINV_SLF_TP", listINV_SLF_TP);
            }

            //200310 �R��BAL_TYPE�P�_�޿�

            DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
            List<Map> rtnList = new ArrayList();
            while (ds.next()) {
                Map rtnMap = VOTool.dataSetToMap(ds);
                //���O
                rtnMap.put("KIND_NM", FieldOptionList.getName("EP", "KIND", MapUtils.getString(rtnMap, "KIND")));
                //�������O
                //[20200312] �W�[���ܦ^�ǲM�� 
                rtnMap.put("DEPR_KD_NM", FieldOptionList.getName("EP", "DEPR_KD", MapUtils.getString(rtnMap, "DEPR_KD")));
                //�b�U�O
                rtnMap.put("BAL_TYPE_NM", FieldOptionList.getName("EP", "G3_BAL_TYPE", MapUtils.getString(rtnMap, "BAL_TYPE")));
                //�����ˮ�
                rtnMap.put("COST_CHK_NM", FieldOptionList.getName("EP", "COST_CHK", MapUtils.getString(rtnMap, "COST_CHK")));
                //�b�U�O
                rtnMap.put("DEPR_CHK_NM", FieldOptionList.getName("EP", "DEPR_CHK", MapUtils.getString(rtnMap, "DEPR_CHK")));

                //[20200406]�ק�IFRS��Ҽg�k
                rtnMap.put("IFRS_INV_RT", new BigDecimal("100").multiply(STRING.objToBigDecimal(rtnMap.get("IFRS_INV_RT"), BigDecimal.ZERO)).setScale(2).toString() + '%');

                rtnList.add(rtnMap);
            }
            return rtnList;
        }

    }

  
     /**
     * �R����a���²M��
     * @param reqMap
     * @throws ModuleException
     */
    //[20200312] �s�W�R����k
    public void deleteDTEPG300(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
        String DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM");

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_002")); //�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(DEPR_KD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_003")); //�ǤJ�������O���o���ŭ�
        }
        if (StringUtils.isBlank(DEPR_YM)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_004")); //�ǤJ���¦~�뤣�o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("DEPR_KD", DEPR_KD);
        ds.setField("DEPR_YM", DEPR_YM);

        try {
            DBUtil.executeUpdate(ds, SQL_deleteDTEPG_001);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L��ơA�������`", dnfe);
        } catch (ModuleException me) {
            throw new ModuleException("�R�����`");
        }
    }

    /**
     * �ץX��Ƴ]�w
     * @param columns  ���key
     * @param firstRow   ���Y
     * @param firstRow_  ����
     */
    private void xlsSettingCol(String[] columns, List<ColumnSetting> firstRow, List<ColumnSetting> firstRow_) {
        for (String key : columns) {
            String columnNM = MessageUtil.getMessage("EPG3_0300_UI_" + key);
            XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, columnNM);
            if (key.indexOf("COST") != -1 || key.indexOf("DEPR") != -1) {
                if (key.equals("DEPR_KD_NM")) {
                    XlsUtils.addColumnAttrs(firstRow_, key, columnNM, new ColumnOptions(1, 1, SORT_RULE.STRING));
                } else if (key.equals("DEPR_YM")) {//TODO
                    XlsUtils.addColumnAttrs(firstRow_, key, columnNM, new ColumnOptions(1, 1, SORT_RULE.STRING));
                } else {
                    XlsUtils.addColumnAttrs(firstRow_, key, columnNM, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
                }
            } else {
                XlsUtils.addColumnAttrs(firstRow_, key, columnNM, new ColumnOptions(1, 1, SORT_RULE.STRING));
            }
        }
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
    
    
    /**
     * �d�ߧ��¦~���`��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map querySumMap(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String DEPR_KD = null;
        String DEPR_YM = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
            DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_KD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_003")); //�ǤJ�������O���o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_YM)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_004")); //�ǤJ���¦~�뤣�o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�d�ߧ����`���G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("DEPR_KD", DEPR_KD);
        ds.setField("DEPR_YM", DEPR_YM);
        ds.setField("KIND", "1");

    	try {
    		Map<String, String> mapIgnoreBase = FieldOptionList.getName("EP" , "BASE_IGNORE_SUM"); 
    		Set<String> ignoreBases = mapIgnoreBase.keySet();
    	    if(ignoreBases.size()>0) {
    	    	String[] bases= new String[ignoreBases.size()] ;
    	    	bases = (String[]) ignoreBases.toArray(new String[0]);
    	    	//bases.addAll(ignoreBases);
    	    	 ds.setFieldValues("BASE_CDs", bases);//BLD_CD not in SG_BLD_CDs
    	    }
    	} catch(Exception e) {
    	}
        Map rtnMap = VOTool.findOneToMap(ds, SQL_querySumMap_001);
        return rtnMap;
    }
}
