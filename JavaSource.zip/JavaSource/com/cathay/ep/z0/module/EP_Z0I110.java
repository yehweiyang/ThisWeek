package com.cathay.ep.z0.module;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * ���դj�ӼҲ�
 * </pre>
 * @author �©s��
 * @since 2019/7/16
 * 2019/11/11 AllenTsai�t�X�q�l�a��API�վ�Token�W�[UserID
 * 2019/11/11 AllenTsai �վ�w��T�{�P�_����
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class EP_Z0I110 {

    /** logger */
    private static final Logger log = Logger.getLogger(EP_Z0I110.class);
	
    private static final String SQL_queryByInvCd_001 = "com.cathay.ep.z0.module.EP_Z0I110.SQL_queryByInvCd_001";

    private static final String SQL_addInvBldData_001 = "com.cathay.ep.z0.module.EP_Z0I110.SQL_addInvBldData_001";

    private static final String SQL_queryByBldCDList_001 = "com.cathay.ep.z0.module.EP_Z0I110.SQL_queryByBldCDList_001";

    /**
     * @param SUB_CPY_ID
     * @param INV_CD
     * @return
     * @throws ModuleException
     */
    public Map queryByInvCd(String SUB_CPY_ID, String INV_CD) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, "EP_Z0I110_MSG_001");//��J�����q�O(SUB_CPY_ID)���i����
        }
        if (StringUtils.isBlank(INV_CD)) {
            eie = getEie(eie, "EP_Z0I110_MSG_002");//��J�j�ӥN��(INV_CD)���i����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INV_CD", INV_CD);

        return VOTool.findOneToMap(ds, SQL_queryByInvCd_001);
    }

    /**
     * [20190723] �����q�l�a��API MAP003
     * @param reqMap
     * @throws ModuleException
     */
    public void addInvBldData(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I110_MSG_003"));//��JreqMap���i����
        }
        ErrorInputException eie = null;

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, "EP_Z0I110_MSG_001");//��J�����q�O(SUB_CPY_ID)���i����
        }
        String INV_CD = MapUtils.getString(reqMap, "INV_CD");
        if (StringUtils.isBlank(INV_CD)) {
            eie = getEie(eie, "EP_Z0I110_MSG_002");//��J�j�ӥN��(INV_CD)���i����
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INV_CD", INV_CD);
        ds.setField("CITY", reqMap.get("CITY"));
        ds.setField("TOWN", reqMap.get("TOWN"));
        ds.setField("X", reqMap.get("X"));
        ds.setField("Y", reqMap.get("Y"));
        ds.setField("LV", reqMap.get("LV"));
        ds.setField("CHG_ID", reqMap.get("CHG_ID"));
        ds.setField("CHG_DATE", reqMap.get("CHG_DATE"));
        ds.setField("CFM_CD", reqMap.get("CFM_CD"));
        ds.setField("CFM_ID", reqMap.get("CFM_ID"));
        ds.setField("CFM_DATE", reqMap.get("CFM_DATE"));

        DBUtil.executeUpdate(ds, SQL_addInvBldData_001);
    }

    /**
     * [20190723] �����q�l�a��API MAP004
     * @param bldList
     * @return
     * @throws ModuleException
     */
    public List<Map> queryByBldCDList(List<String> bldList) throws ModuleException {
        if (bldList == null || bldList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I110_MSG_004"));//��J�j�ӽs���M�椣�i����
        }
        DataSet ds = Transaction.getDataSet();
        ds.setFieldValues("bldList", bldList);

        return VOTool.findToMaps(ds, SQL_queryByBldCDList_001);
    }

    /**
     * [20190723] �I�s�����q�l�a��API MAP003
     * @param mapI110
     * @throws Exception
     */
    public void callAPIMap003(Map mapI110, String usrId) throws Exception {
        Map reqMap = new HashMap();
        reqMap.put("reqMap", mapI110);
        String jsonStr = VOTool.toJSON(reqMap);
        Object result = new EP_Z0A110().callAPI("MAP003", jsonStr, usrId);
        Map rtnMap = VOTool.jsonToMap(VOTool.toJSON(result));
        if (ReturnCode.OK != MapUtils.getIntValue(rtnMap, "returnCode", 1)) {
            throw new ModuleException();
        }
    }

    /**
     * [20190723] �I�s�����q�l�a��API MAP004
     * @param bldList
     * @return
     * @throws Exception
     * 2019/11/08 AllenTsai �t�X�q�l�a��API�վ�/api/SurveyBuilding ���դj�ӪŶ���Ƭd�� �I�s API
     */
    public List<Map> callAPIMap004(List<String> bldList, String userId) throws Exception {

        Map reqMap = new HashMap();
        reqMap.put("buildingNo", bldList);
        
        Map appInfo = new HashMap();
        appInfo.put("appId", "EP");
        appInfo.put("sourceCode", userId);
        
        reqMap.put("appInfo", appInfo);
        String jsonStr = VOTool.toJSON(reqMap);


        log.debug("callAPIMap004 JSON:"+jsonStr);
        Object result = new EP_Z0A110().callAPI("MAP004", jsonStr, userId);
        log.debug("/api/SurveyBuilding ���դj�ӪŶ���Ƭd��:\n"+result);
        Map rtnMap = VOTool.jsonToMap(VOTool.toJSON(result));
        String strSuccess = MapUtils.getString(rtnMap , "success");
		log.debug("success: "+strSuccess);
        Object detail = MapUtils.getObject(rtnMap, "result");
        log.debug(detail.getClass());
        if(strSuccess.equals("true")) {        	  
        	List<Map> rtnList = (List<Map>)  detail;
        	for(Map rtnData: rtnList) {
        	    String lv = MapUtils.getString(rtnData, "lv");
        	    if("99".equals(lv)) {
        	    	rtnData.put("CFM_CD", "Y");
        	    } else {
        	    	rtnData.put("CFM_CD", "N");
        	    }
        	}
        	return rtnList;        	  
        }
        return Collections.EMPTY_LIST;
    }

    /**
     * �B�zErrorInputException
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getEie(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

}
