package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2015-03-04  Created ������
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ú�O�������@�Ҳ�
 * �Ҳ�ID    EP_Z0C306
 * ���n����    ú�O�������@�Ҳ�
 * </pre>
 * @author ������
 *
 */
@SuppressWarnings("unchecked")
public class EP_Z0C306 {

    private static final Logger log = Logger.getLogger(EP_Z0C306.class);

    private static final String SQL_updatePayInfo_001 = "com.cathay.ep.z0.module.EP_Z0C306.SQL_updatePayInfo_001";

    private static final String SQL_updatePayInfo_002 = "com.cathay.ep.z0.module.EP_Z0C306.SQL_updatePayInfo_002";

    private static final String SQL_doQuery_001 = "com.cathay.ep.z0.module.EP_Z0C306.SQL_doQuery_001";

    private static final String SQL_deleteByPayNo_001 = "com.cathay.ep.z0.module.EP_Z0C306.SQL_deleteByPayNo_001";

    private static final String SQL_updateForTRNKIND8_002 = "com.cathay.ep.z0.module.EP_Z0C306.SQL_updateForTRNKIND8_002";

    /**
     * ���oú�O�M��
     * @param PAY_NO ú�O�s��
     * @return ú�O���p�M��
     * @throws ModuleException
     */
    public List<Map> queryPayList(List<Map> PAY_RLT_LIST, String SUB_CPY_ID) throws ModuleException {
        if (PAY_RLT_LIST == null || PAY_RLT_LIST.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C306_MSG_001"));//ú�O�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        List<String> PAY_NO_LIST = new ArrayList();
        for (Map PAY_RLT_MAP : PAY_RLT_LIST) {
            String PAY_NO = MapUtils.getString(PAY_RLT_MAP, "PAY_NO");
            if (!PAY_NO_LIST.contains(PAY_NO)) {
                PAY_NO_LIST.add(PAY_NO);
            }
        }
        try {
            DataSet ds = Transaction.getDataSet();
            int i = 1;
            List<String> tmpPAY_NOList = new ArrayList();
            List<Map> payList = new ArrayList<Map>();
            int PAY_NO_SIZE = PAY_NO_LIST.size();
            for (String PAY_NO : PAY_NO_LIST) {
                tmpPAY_NOList.add(PAY_NO);
                //�קKSQL�L��
                if (i % 200 == 0) {
                    ds.clear();
                    ds.setFieldValues("PAY_NO", tmpPAY_NOList);
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    payList.addAll(VOTool.findToMaps(ds, SQL_doQuery_001));
                    tmpPAY_NOList = new ArrayList();
                }

                if (i == PAY_NO_SIZE && i % 200 != 0) {
                    ds.clear();
                    ds.setFieldValues("PAY_NO", tmpPAY_NOList);
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    payList.addAll(VOTool.findToMaps(ds, SQL_doQuery_001));
                }
                i++;
            }

            return payList;
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C306_MSG_002"));//���oú�O���p�M��o�Ϳ��~,
        }

    }

    /**
     * ��sú�ڰO���b�ȸ�T
     * �qEP_C30040 �h���L��
     * @param PAY_NO ú�O�s��
     * @param TRN_KIND ������� (06:�T�{; 01:�����T�{)
     * @param ACNT_DATE �b�Ȥ��
     * @param ACNT_DIV_NO �b�ȳ��
     * @param SLIP_LOT_NO �ǲ��帹
     * @param SLIP_SET_NO �ǲ��ո�
     * @param TRN_SER_NO �g�����Ǹ�
     * @param user
     * @throws ModuleException
     */
    public void updatePayInfo(String PAY_NO, String TRN_KIND, Date ACNT_DATE, String ACNT_DIV_NO, String SLIP_LOT_NO, Integer SLIP_SET_NO,
            BigDecimal TRN_SER_NO, UserObject user, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_003"));//����������o����
        } else if (!"01".equals(TRN_KIND) && !"06".equals(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_004"));//����������~
        }
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_005"));//�b�Ȥ�����o����
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_006"));//�b�ȳ�줣�o����
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_007"));//�ǲ��帹���o����
        }
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (SLIP_SET_NO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_008"));//�ǲ��ո����o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_009"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        String Op = user.getOpUnit();
        String Id = user.getEmpID();
        String Name = user.getEmpName();
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
        ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        ds.setField("TRN_KIND", TRN_KIND);
        ds.setField("Op", Op);
        ds.setField("Id", Id);
        ds.setField("Name", Name);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //06:�T�{; 
        if ("06".equals(TRN_KIND)) {
            if (StringUtils.isBlank(PAY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_010"));//ú�O�s�����o����
            }
            if (TRN_SER_NO == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_011"));//�g�����Ǹ����o����
            }
            if (eie != null) {
                throw eie;
            }
            //��WDTEPC306ú�ڬ����ɱb�ȸ�T
            ds.setField("TRN_SER_NO", TRN_SER_NO);
            ds.setField("PAY_NO", PAY_NO);
            try {
                DBUtil.executeUpdate(ds, SQL_updatePayInfo_001);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C306_MSG_012"));//��sú�ڬ����ɱb�ȸ�T���~,
            }
        } else {
            //01:�����T�{
            //�M��DTEPC306ú�ڬ����ɱb�ȸ�T
            try {
                ds.setField("PAY_NO", PAY_NO);
                DBUtil.executeUpdate(ds, SQL_updatePayInfo_002);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C306_MSG_013"));//����ú�ڬ����ɱb�ȸ�T���~,
            }
        }
    }

    /**
     * ����sú�ڰO���b�ȸ�T
     * @param PAY_LIST
     * @param MAP_TRNSERNO
     * @param TRN_KIND
     * @param ACNT_DATE
     * @param ACNT_DIV_NO
     * @param SLIP_LOT_NO
     * @param SLIP_SET_NO
     * @param user
     * @throws DBException
     * @throws ModuleException
     */
    public void acntUpdateBatch(List<Map> PAY_LIST, Map<String, Map> MAP_TRNSERNO, String TRN_KIND, Date ACNT_DATE, String SLIP_LOT_NO,
            Integer SLIP_SET_NO, UserObject user, BatchUpdateDataSet budsC306) throws DBException, ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        //�ˮֶǤJ�Ѽ�
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_003"));//����������o����
        } else if (!"01".equals(TRN_KIND) && !"06".equals(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_004"));//����������~
        }
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_005"));//�b�Ȥ�����o����
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_007"));//�ǲ��帹���o����
        }
        if (SLIP_SET_NO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_008"));//�ǲ��ո����o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C306_MSG_009"));//�ϥΪ̸�T���o����
        } else {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        String Id = user.getEmpID();
        String Name = user.getEmpName();
        String Op = user.getOpUnit();

        String ACNT_DIV_NO = user.getOpUnit();

        //�]XAMode:buds�ѥD�{���ǤJ
        //BatchUpdateDataSet budsC306 = Transaction.getBatchUpdateDataSet();
        boolean isConfirm;
        if ("06".equals(TRN_KIND)) {
            //06:�T�{
            budsC306.preparedBatch(SQL_updatePayInfo_001);
            isConfirm = true;
        } else {
            budsC306.preparedBatch(SQL_updatePayInfo_002);
            isConfirm = false;
        }
        try {
            for (Map payMap : PAY_LIST) {

                String PAY_NO = MapUtils.getString(payMap, "PAY_NO");
                Map paySerRCVYM = MAP_TRNSERNO.get(PAY_NO);
                String TRN_SER_NO = MapUtils.getString(paySerRCVYM, "TRN_SER_NO");

                if (isConfirm) {
                    //��WDTEPC306ú�O���p�ɱb�ȸ�T
                    budsC306.setField("ACNT_DATE", ACNT_DATE);
                    budsC306.setField("ACNT_DIV_NO", ACNT_DIV_NO);
                    budsC306.setField("SLIP_LOT_NO", SLIP_LOT_NO);
                    budsC306.setField("SLIP_SET_NO", SLIP_SET_NO);
                    budsC306.setField("TRN_KIND", TRN_KIND);
                    budsC306.setField("Op", Op);
                    budsC306.setField("Id", Id);
                    budsC306.setField("Name", Name);
                    budsC306.setField("TRN_SER_NO", TRN_SER_NO);
                    budsC306.setField("PAY_NO", PAY_NO);
                    budsC306.setField("SUB_CPY_ID", SUB_CPY_ID);
                } else {
                    //�M��DTEPC306ú�ڬ����ɱb�ȸ�T
                    budsC306.setField("TRN_KIND", TRN_KIND);
                    budsC306.setField("Op", Op);
                    budsC306.setField("Id", Id);
                    budsC306.setField("Name", Name);
                    budsC306.setField("PAY_NO", PAY_NO);
                    budsC306.setField("SUB_CPY_ID", SUB_CPY_ID);
                }
                budsC306.addBatch();
            }

            budsC306.executeBatch();
            Object theErrorBudsC301Object[][] = budsC306.getBatchUpdateErrorArray();
            if (theErrorBudsC301Object.length > 0) {
                for (int k = 0; k < theErrorBudsC301Object.length; k++) {
                    Map errorDataMap = (Map) theErrorBudsC301Object[k][1];
                    log.error("��sú�ڬ����ɱb�ȸ�T,��" + (Exception) theErrorBudsC301Object[k][0] + "����Ʀ��~,setField = " + errorDataMap.toString(),
                        (Exception) theErrorBudsC301Object[k][2]);
                }
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C306_MSG_014"));// ��sú�ڬ����ɱb�ȸ�T���~
            }
        } catch (Exception e) {
            log.error(e, e);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C306_MSG_014"));// ��sú�ڬ����ɱb�ȸ�T���~
        }
    }

    /**
     * ��ú�O�s���R��ú�O����
     * @param PAY_NO
     * @throws ModuleException
     */
    public void deleteByPayNo(String PAY_NO, String SUB_CPY_ID) throws ModuleException {
        // �Ѽ��ˮ�
        if (StringUtils.isBlank(PAY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C306_MSG_001")); //ú�O�s�����o����
        }

        //����DTEPC306ú�O������
        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_deleteByPayNo_001);
        } catch (ModuleException e) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C306_MSG_015", new Object[] { PAY_NO }));//"�R��ú�ڬ�����BYú�O�s�����~,ú�O�s��={0}"
        }

    }

    /**
     * from EP_C30080.doUpdate()
     * @param PAY_NO
     * @param CHG_ID
     * @param CHG_NAME
     * @param CHG_DIV_NO
     * @param currentTime
     * @throws ModuleException
     */
    public void updateForTRNKIND8(String PAY_NO, String CHG_ID, String CHG_NAME, String CHG_DIV_NO, Timestamp currentTime, String SUB_CPY_ID)
            throws ModuleException {
        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("CHG_ID", CHG_ID);
        ds.setField("CHG_NAME", CHG_NAME);
        ds.setField("CHG_DIV_NO", CHG_DIV_NO);
        ds.setField("CHG_DATE", currentTime);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_updateForTRNKIND8_002);
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

}
