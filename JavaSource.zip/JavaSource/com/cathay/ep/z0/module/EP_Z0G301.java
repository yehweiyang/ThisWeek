package com.cathay.ep.z0.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014/10/01  Created ������
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ���©��Ӭd�߼Ҳ�
 * �Ҳ�ID    EP_Z0G301 
 * ���n����    ���§@�~�Ҳ�
 * 
 * [20200313] Modified�\��睊�վ���� �ק�� (�߮׳渹�G200226001085)
 * �ק��kqueryList,queryLatestList�d�߱���P���
 * �s�WdeleteDTEPG301
 * 
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EP_Z0G301 {
    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G301.SQL_queryList_001";

    private static final String SQL_queryLatestList_001 = "com.cathay.ep.z0.module.EP_Z0G301.SQL_queryLatestList_001";

    private static final Logger log = Logger.getLogger(EP_Z0G301.class);

    private static final String SQL_batchInsert_001 = "com.cathay.ep.z0.module.EP_Z0G301.SQL_batchInsert_001";

    private static final String SQL_deleteDTEPG301_001 = "com.cathay.ep.z0.module.EP_Z0G301.SQL_deleteDTEPG301_001";

    /**
     * Ū����a���²M��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String DEPR_KD = null;
        String DEPR_YM = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G301_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
            DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G301_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_KD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G301_MSG_003")); //�ǤJ�������O���o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_YM)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G301_MSG_004")); //�ǤJ���¦~�뤣�o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�ߧ����`�� (DTEPG300)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //[20200313]�ק�APLY_NO��DEPR_YM
        ds.setField("DEPR_YM", DEPR_YM);
        ds.setField("DEPR_KD", DEPR_KD);
        //[20200313]�ק�DEPR_YM��INV_CD, KIND��SLF_CD 
        setFieldIfExist(ds, reqMap, "BASE_CD");
        setFieldIfExist(ds, reqMap, "INV_CD");
        setFieldIfExist(ds, reqMap, "SLF_CD");

        //[20200313] �R���b�U�O�P�_

        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        List<Map> rtnList = new ArrayList();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //�u������  
            // [20200313]�ק�SUB_ITEM_NO��G3_SUB_ITEM_NO
            rtnMap.put("SUB_ITEM_NO_NM", FieldOptionList.getName("EP", "G3_SUB_ITEM_NO", MapUtils.getString(rtnMap, "SUB_ITEM_NO")));
            rtnMap.put("KIND_NM", FieldOptionList.getName("EP", "KIND", MapUtils.getString(rtnMap, "KIND")));
            rtnMap.put("DEPR_KD_NM", FieldOptionList.getName("EP", "DEPR_KD", MapUtils.getString(rtnMap, "DEPR_KD")));
            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * Ū����a���³̷s���²M��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    // [20200313]�ק�SQL���e
    public List<Map> queryLatestList(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        //String DEPR_KD = null;
        //String DEPR_YM = null;
        String BASE_CD = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G301_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            //DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
            //DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM");
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G301_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            /*if (StringUtils.isBlank(DEPR_KD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G301_MSG_003")); //�ǤJ�������O���o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_YM)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G301_MSG_004")); //�ǤJ���¦~�뤣�o���ŭ�
            }*/
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G301_MSG_005")); //�ǤJ��a�N�����o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�ߧ����`�� (DTEPG300)�G
        DataSet ds = Transaction.getDataSet();

        ds.setField("BASE_CD", BASE_CD);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_queryLatestList_001);
    }

    /**
     *  ���s�W���¸�T
     * @param listG301
     * @throws ModuleException
     * @throws DBException
     */
    public void batchInsert(List<Map> listG301) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (listG301 == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G301_MSG_006")); //�ǤJ�C���a���©��Ӥ��o����
        }
        if (eie != null) {
            throw eie;
        }
        //�B�z���update
        BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���
        try {
            int batchCount;

            buds.clear();
            buds.preparedBatch(SQL_batchInsert_001);

            batchCount = (listG301.size() / commit_size) + 1;

            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? listG301.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        Map G301Map = listG301.get(j);

                        buds.setField("SUB_CPY_ID", G301Map.get("SUB_CPY_ID"));
                        buds.setField("BASE_CD", G301Map.get("BASE_CD"));
                        buds.setField("COST_SEQ", G301Map.get("COST_SEQ"));
                        buds.setField("DEPR_KD", G301Map.get("DEPR_KD"));
                        buds.setField("CAL_DT", G301Map.get("CAL_DT"));
                        buds.setField("DEPR_YM", G301Map.get("DEPR_YM"));
                        buds.setField("KIND", G301Map.get("KIND"));
                        buds.setField("IFRS_INV_RT", G301Map.get("IFRS_INV_RT"));
                        buds.setField("ITEM_NO", G301Map.get("ITEM_NO"));
                        buds.setField("SUB_ITEM_NO", G301Map.get("SUB_ITEM_NO"));
                        buds.setField("COST_DT", G301Map.get("COST_DT"));
                        buds.setField("LOSS_AMT", G301Map.get("LOSS_AMT"));
                        buds.setField("DEPR_YR", G301Map.get("DEPR_YR"));
                        buds.setField("FST_YR_MON", G301Map.get("FST_YR_MON"));
                        buds.setField("TOT_DERP_MON", G301Map.get("TOT_DERP_MON"));
                        buds.setField("LY_DEPR_MON", G301Map.get("LY_DEPR_MON"));
                        buds.setField("COST_AMT", G301Map.get("COST_AMT"));
                        buds.setField("COST_AMT_INV", G301Map.get("COST_AMT_INV"));
                        buds.setField("COST_AMT_SLF", G301Map.get("COST_AMT_SLF"));
                        buds.setField("LY_DEPR", G301Map.get("LY_DEPR"));
                        buds.setField("DEPR_AMT", G301Map.get("DEPR_AMT"));
                        buds.setField("DEPR_AMT_INV", G301Map.get("DEPR_AMT_INV"));
                        buds.setField("DEPR_AMT_SLF", G301Map.get("DEPR_AMT_SLF"));
                        buds.setField("YR_DEPR", G301Map.get("YR_DEPR"));
                        buds.setField("YR_DEPR_INV", G301Map.get("YR_DEPR_INV"));
                        buds.setField("YR_DEPR_SLF", G301Map.get("YR_DEPR_SLF"));
                        buds.setField("UN_DERP", G301Map.get("UN_DERP"));
                        buds.setField("BAS_DT", G301Map.get("BAS_DT"));
                        buds.setField("COST_BAS", G301Map.get("COST_BAS"));
                        buds.setField("COST_INV_BAS", G301Map.get("COST_INV_BAS"));
                        buds.setField("COST_SLF_BAS", G301Map.get("COST_SLF_BAS"));
                        buds.setField("COST_ADJ", G301Map.get("COST_ADJ"));
                        buds.setField("COST_INV_ADJ", G301Map.get("COST_INV_ADJ"));
                        buds.setField("COST_SLF_ADJ", G301Map.get("COST_SLF_ADJ"));
                        buds.setField("DEPR_BAS", G301Map.get("DEPR_BAS"));
                        buds.setField("DEPR_INV_BAS", G301Map.get("DEPR_INV_BAS"));
                        buds.setField("DEPR_SLF_BAS", G301Map.get("DEPR_SLF_BAS"));
                        buds.setField("DEPR_ADJ", G301Map.get("DEPR_ADJ"));
                        buds.setField("DEPR_INV_ADJ", G301Map.get("DEPR_INV_ADJ"));
                        buds.setField("DEPR_SLF_ADJ", G301Map.get("DEPR_SLF_ADJ"));
                        buds.setField("CHG_DATE", G301Map.get("CHG_DATE"));
                        buds.setField("CHG_DIV_NO", G301Map.get("CHG_DIV_NO"));
                        buds.setField("CHG_ID", G301Map.get("CHG_ID"));
                        buds.setField("CHG_NAME", G301Map.get("CHG_NAME"));
                        buds.addBatch();
                    }
                    buds.executeBatch();
                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap, (Exception) theErrorObject[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException(MessageUtil.getMessage(""));//�s�W��Ʀ��~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException(e);//�妸�s�W����
                }
            } //end ��s�ץ�i�� (C101)

        } finally {
            if (buds != null) {
                buds.close();
            }
        }
    }

    /**
     * �R����a�������²M��
     * @param reqMap
     * @throws ModuleException
     */
    //[20200313] �s�W�R����k
    public void deleteDTEPG301(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
        String DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM");

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_002")); //�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(DEPR_KD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G300_MSG_003")); //�ǤJ�������O���o���ŭ�
        }
        if (StringUtils.isBlank(DEPR_YM)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_004")); //�ǤJ���¦~�뤣�o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("DEPR_KD", DEPR_KD);
        ds.setField("DEPR_YM", DEPR_YM);

        try {
            DBUtil.executeUpdate(ds, SQL_deleteDTEPG301_001);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L��ơA�������`", dnfe);
        } catch (ModuleException me) {
            throw new ModuleException("�R�����`");
        }
    }

    /**
     * dataset ��
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, Map tmpMap, String key) {
        String value = MapUtils.getString(tmpMap, key);
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
