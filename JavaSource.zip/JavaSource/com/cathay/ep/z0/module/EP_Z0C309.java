package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.hr.Employee;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.hr.Unit;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPC309;
import com.cathay.ep.vo.DTEPC310;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �ҲզW�� �������J�b�ɺ��@�Ҳ� 
 * �Ҳ�ID EP_Z0C309 
 * ���n���� �������J�b�ɺ��@�Ҳ�
 * </pre>
 * @author ���Z�@
 * @since 2018/02/27
 * 
 * [20200212] ��عq�l�o���ɤJ�G�Y�I�sws���ѡA�ȧR�����\���o���Ȧ�
 */
@SuppressWarnings({ "rawtypes" })
public class EP_Z0C309 {

    private static final Logger log = Logger.getLogger(EP_Z0C309.class);

    private static final String SQL_queryDTEPC309_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_queryDTEPC309_001";

    private static final String SQL_queryDTEPC309ByTMP_NOs_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_queryDTEPC309ByTMP_NOs_001";

    private static final String SQL_queryDTEPC309ByPAY_NO_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_queryDTEPC309ByPAY_NO_001";

    private static final String SQL_queryC309hasBALAMT_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_queryC309hasBALAMT_001";

    private static final String SQL_updateC309ForACNT_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_updateC309ForACNT_001";

    private static final String SQL_update309RTN_RCPT_NO_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_update309RTN_RCPT_NO_001";

    private static final String SQL_updateC309forDTMP_NO_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_updateC309forDTMP_NO_001";

    private static final String SQL_deleteDTEPC309ByACNT_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_deleteDTEPC309ByACNT_001";

    private static final String SQL_deleteDTEPC309ByTMP_NO_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_deleteDTEPC309ByTMP_NO_001";

    private static final String SQL_verifyDelete_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_verifyDelete_001";

    private static final String SQL_queryDTEPC309ByEXT_NO_001 = "com.cathay.ep.z0.module.EP_Z0C309.SQL_queryDTEPC309ByEXT_NO_001";

    /**
     * �d�߼������J�b��(PK)
     * @param SUB_CPY_ID, TMP_NO
     * @return DTEPC309
     * @throws ModuleException
     */
    public DTEPC309 queryDTEPC309(String SUB_CPY_ID, String TMP_NO) throws ModuleException {

        ErrorInputException errex = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_001"); // �����q�O���o����
        }

        if (StringUtils.isBlank(TMP_NO)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_002"); // �Ȧ��s�����o����
        }
        if (errex != null) {
            throw errex;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("TMP_NO", TMP_NO);
        ds.setField("TMP_CD", "A");//�Ȧ���

        DTEPC309 DTEPC309VO = VOTool.findOneToVO(DTEPC309.class, ds, SQL_queryDTEPC309_001);
        return DTEPC309VO;
    }

    /**
     * �d�߼������J�b��(PKs)
     * @param SUB_CPY_ID, TMP_NO
     * @return C309List
     * @throws ModuleException
     */
    public List<DTEPC309> queryDTEPC309ByTMP_NOs(String SUB_CPY_ID, String[] TMP_NOs) throws ModuleException {

        ErrorInputException errex = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_001"); // �����q�O���o����
        }
        if (TMP_NOs == null || TMP_NOs.length == 0) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_002"); // �Ȧ��s�����o����
        }
        if (errex != null) {
            throw errex;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("TMP_NOs", TMP_NOs);
        ds.setField("TMP_CD", "A");//�Ȧ���

        return VOTool.findToVOs(DTEPC309.class, ds, SQL_queryDTEPC309ByTMP_NOs_001);

    }

    /**
     * �d�߼������J�b��(byú�O�s��)
     * @param SUB_CPY_ID, PAY_NO
     * @return C309List
     * @throws ModuleException
     */
    public List<Map> queryDTEPC309ByPAY_NO(String SUB_CPY_ID, String PAY_NO) throws ModuleException {

        ErrorInputException errex = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_001"); // �����q�O���o����
        }
        if (StringUtils.isBlank(PAY_NO)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_003"); // ú�O�s�����o����
        }
        if (errex != null) {
            throw errex;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("PAY_NO", PAY_NO);

        return VOTool.findToMaps(ds, SQL_queryDTEPC309ByPAY_NO_001);

    }

    /**
     * �d�߼������J�b��(by��X�s��)
     * @param SUB_CPY_ID, EXT_NO
     * @return C309
     * @throws ModuleException
     */
    public DTEPC309 queryDTEPC309ByEXT_NO(String SUB_CPY_ID, String EXT_NO) throws ModuleException {

        ErrorInputException errex = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_001"); // �����q�O���o����
        }
        if (StringUtils.isBlank(EXT_NO)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_004"); // ��X�s�����o����
        }
        if (errex != null) {
            throw errex;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("EXT_NO", EXT_NO);

        return VOTool.findOneToVO(DTEPC309.class, ds, SQL_queryDTEPC309ByEXT_NO_001);

    }

    /**
     * �d�߼������J�b��(�Ȧ��l�B>0)
     * @param reqMap
     * @return C309List
     * @throws ModuleException
     */

    public List<Map> queryC309hasBALAMT(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C309_ERRMSG_001")); //�ǤJ�ѼƤ��i����
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C309_ERRMSG_001")); // �����q�O���o����
        }

        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if (StringUtils.isNotEmpty(CRT_NO)) {
            ds.setField("CRT_NO", CRT_NO);
        }
        if (StringUtils.isNotEmpty(CUS_NO)) {
            ds.setField("CUS_NO", CUS_NO);
        }

        return VOTool.findToMaps(ds, SQL_queryC309hasBALAMT_001);

    }

    /**
     * �s�W�������J�b��
     * @param C309
     * @return 
     * @throws ModuleException
     * @throws SQLException 
     */
    public String insertDTEPC309(DTEPC309 C309) throws ModuleException, SQLException {

        ErrorInputException errex = null;

        if (C309 == null) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_005"); // �������J�b�ɤ��i����
        }
        String SUB_CPY_ID = C309.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_001 "); // �����q�O���o����
        }
        if (errex != null) {
            throw errex;
        }

        //�ˮֶǤJ�Ѽ�+�հѼ�
        this.verifyAdd(C309);

        String TMP_NO = C309.getTMP_NO();

        //�s�W�������J�b��DTEPC309
        VOTool.insert(C309);
        return TMP_NO;
    }

    /**
     * ��sC309���|�p�������(����帹�ո�����Ǹ�byú�O�s��)
     * @param C309
     * @return 
     * @throws ModuleException
     */
    public void updateC309ForACNT(DTEPC309 C309) throws ModuleException {

        if (C309 == null) {
            throw new ErrorInputException("EP_Z0C309_ERRMSG_006"); // �|�p������Ƥ��i����
        }

        ErrorInputException errex = null;

        String SUB_CPY_ID = C309.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_001"); // �����q�O���o����
        }
        String TMP_NO = C309.getTMP_NO();
        if (StringUtils.isBlank(TMP_NO)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_002"); // �Ȧ��s�����o����
        }
        if (errex != null) {
            throw errex;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("TMP_NO", TMP_NO);
        ds.setField("SLIP_DATE", C309.getSLIP_DATE());
        ds.setField("ACNT_DATE", C309.getACNT_DATE());
        ds.setField("SLIP_LOT_NO", C309.getSLIP_LOT_NO());
        ds.setField("SLIP_SET_NO", C309.getSLIP_SET_NO());
        ds.setField("ACNT_DIV_NO", C309.getACNT_DIV_NO());
        ds.setField("ACNT_SER_NO", C309.getACNT_SER_NO());

        DBUtil.executeUpdate(ds, SQL_updateC309ForACNT_001);

    }

    /**
     * �̼Ȧ��s����s"�h�����I���ڸ��X"
     * @param inMap
     * @return 
     * @throws ModuleException
     */
    public void update309RTN_RCPT_NO(Map inMap) throws ModuleException {

        if (inMap == null || inMap.isEmpty()) {
            throw new ErrorInputException("EP_Z0C309_ERRMSG_007"); // ��Ʒs�W���i����
        }

        ErrorInputException errex = null;

        String SUB_CPY_ID = MapUtils.getString(inMap, "SUB_CPY_ID");
        String TMP_NO = MapUtils.getString(inMap, "TMP_NO");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_001"); // �����q�O���o����
        }
        if (StringUtils.isBlank(TMP_NO)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_002"); // �Ȧ��s�����o����
        }
        if (errex != null) {
            throw errex;
        }

        String[] TMP_NOs = TMP_NO.split(",");

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("TMP_NOs", TMP_NOs);
        ds.setField("RTN_RCPT_NO", inMap.get("RTN_RCPT_NO"));
        ds.setField("LST_CHG_ID", inMap.get("LST_CHG_ID"));
        DBUtil.executeUpdate(ds, SQL_update309RTN_RCPT_NO_001);

    }

    /**
     * ��s�������J�b��
     * @param SUB_CPY_ID, TMP_NO, UPD_TP, DTMP_NO, BAL_AMT
     * @return 
     * @throws ModuleException
     */
    public void updateC309forDTMP_NO(String SUB_CPY_ID, String TMP_NO, String UPD_TP, String DTMP_NO, BigDecimal BAL_AMT) throws ModuleException {

        ErrorInputException errex = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_008"); // �ǤJ�����q�O���~!
        }
        if (StringUtils.isBlank(TMP_NO)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_009"); // �ǤJ�������J�b�s�����~!
        }
        if ("1".equals(UPD_TP) && StringUtils.isBlank(DTMP_NO)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_010"); // �ǤJ�������R�b�s�����~!
        }

        if (BAL_AMT == null) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_011"); // �ǤJ�R�b�l�B���~!
        }
        if (errex != null) {
            throw errex;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("TMP_NO", TMP_NO);
        ds.setField("DTMP_NO", DTMP_NO);
        ds.setField("BAL_AMT", BAL_AMT);
        DBUtil.executeUpdate(ds, SQL_updateC309forDTMP_NO_001);

    }

    /**
     * �R���������J�b��
     * @param SUB_CPY_ID, ACNT_ID, ACNT_IN_DATE, ACNT_SER_NO
     * @return 
     * @throws ModuleException
     */
    public void deleteDTEPC309ByACNT(String SUB_CPY_ID, String ACNT_ID, String ACNT_IN_DATE, String ACNT_SER_NO, List<String> invNoList) throws ModuleException {

        ErrorInputException errex = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_008"); // �ǤJ�����q�O���~!
        }
        if (StringUtils.isBlank(ACNT_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_012"); // ��J���J�b��J�H�����~�I
        }
        if (!DATE.isDBTimeStamp(ACNT_IN_DATE)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_013"); // ��J���J�b��J������~�I
        }
        if (StringUtils.isBlank(ACNT_SER_NO)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_014"); // ��J���J�b����Ǹ����~�I
        }
        if (errex != null) {
            throw errex;
        }

        //���d+�ˮ�C309
        this.verifyDelete(SUB_CPY_ID, ACNT_ID, ACNT_IN_DATE, ACNT_SER_NO, invNoList);

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("ACNT_ID", ACNT_ID);
        ds.setField("ACNT_IN_DATE", ACNT_IN_DATE);
        ds.setField("ACNT_SER_NO", ACNT_SER_NO);
        //20200212 ��عq�l�o���ɤJ�G�Y�I�sws���ѡA�ȧR�����\���o���Ȧ�
        if (invNoList != null && !invNoList.isEmpty()) {
            ds.setFieldValues("INV_NOs", invNoList);
        }
        DBUtil.executeUpdate(ds, SQL_deleteDTEPC309ByACNT_001);//�R��C309

    }

    /**
     * �R���������J�b��
     * @param SUB_CPY_ID, TMP_NO
     * @return 
     * @throws ModuleException
     */
    public void deleteDTEPC309ByTMP_NO(String SUB_CPY_ID, String TMP_NO) throws ModuleException {

        ErrorInputException errex = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_008"); // �ǤJ�����q�O���~!
        }
        if (StringUtils.isBlank(TMP_NO)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_015"); // ��J���J�b��J�H�����~�I
        }
        if (errex != null) {
            throw errex;
        }

        DTEPC309 C309 = this.queryDTEPC309(SUB_CPY_ID, TMP_NO);

        //�ˮ֬O�_�w�R�b
        List<DTEPC310> C310List = null;
        try {
            C310List = new EP_Z0C310().queryDTEPC310ByTMP_NO(C309.getSUB_CPY_ID(), C309.getTMP_NO());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�LC310��Ƶ������`");
        }
        if (C310List != null) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C309_ERRMSG_016", new String[] { TMP_NO })); // �Х������Ȧ��R�b��:�Ȧ��s��{0}
        }

        if (C309.getSLIP_DATE() != null || C309.getACNT_DATE() != null || StringUtils.isNotBlank(C309.getSLIP_LOT_NO()) || (C309.getSLIP_SET_NO() != null && !"0".equals(C309.getSLIP_SET_NO())) || StringUtils.isNotBlank(C309.getACNT_DIV_NO())
                || (C309.getACNT_SER_NO() != null && !"0".equals(C309.getACNT_SER_NO()))) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C309_ERRMSG_017")); // �Х������Ȧ��b�ȸ�� 
        }

        //�R��C309
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("TMP_NO", TMP_NO);
        DBUtil.executeUpdate(ds, SQL_deleteDTEPC309ByTMP_NO_001);
    }

    /**
     * ��s�X�b(����)
     * @param C309List
     * @return 
     * @throws ModuleException
     */
    public void cancelAcnt(List<DTEPC309> C309List) throws ModuleException {

        if (C309List == null || C309List.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C309_ERRMSG_018")); // �X�b�M�椣�o����
        }

        //�ˮ�
        for (DTEPC309 C309 : C309List) {
            this.checkAndUpdateC309(C309);
        }

    }

    /**
     * �����X�b���ˮ�+C309����������s���ť�
     * @param C309VO
     * @return 
     * @throws ModuleException
     */
    public void checkAndUpdateC309(DTEPC309 C309VO) throws ModuleException {

        if (C309VO == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C309_ERRMSG_019")); // �������J�ɤ��o����
        }

        //�������O
        List<DTEPC310> C310List = null;
        try {
            C310List = new EP_Z0C310().queryDTEPC310ByTMP_NO(C309VO.getSUB_CPY_ID(), C309VO.getTMP_NO());
        } catch (DataNotFoundException dnfe) {
            log.fatal("�d�L�R�Ȧ��ɵ������`");
        }

        //�ˮ֤J�b��
        if (C310List != null) {
            boolean isReject = false; //�p�G����J�b��, �N���X��
            for (DTEPC310 C310 : C310List) {
                if (C310.getDACNT_DATE() != null) {
                    isReject = true;
                    break;
                }
            }
            if (isReject) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C309_ERRMSG_020")); // �Х������Ȧ��R�b��
            }
        }

        //�M�űb�ȸ�T
        DTEPC309 NEW_C309VO = new DTEPC309();
        NEW_C309VO.setSUB_CPY_ID(C309VO.getSUB_CPY_ID());
        NEW_C309VO.setTMP_NO(C309VO.getTMP_NO());
        NEW_C309VO.setSLIP_DATE(null);
        NEW_C309VO.setACNT_DATE(null);
        NEW_C309VO.setSLIP_LOT_NO(null);
        NEW_C309VO.setSLIP_LOT_NO(null);
        NEW_C309VO.setACNT_DIV_NO(null);
        NEW_C309VO.setACNT_SER_NO(null);
        this.updateC309ForACNT(NEW_C309VO);
    }

    /**
     * �ˮ�/��z�g�J���
     * @param C309VO
     * @return 
     * @throws ModuleException
     * @throws SQLException 
     */
    public void verifyAdd(DTEPC309 C309VO) throws ModuleException, SQLException {

        if (C309VO == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C309_ERRMSG_019")); // �������J�ɤ��o����
        }

        ErrorInputException errex = null;

        //�������O
        String strTMP_CD = C309VO.getTMP_CD();
        if (!"A".equals(strTMP_CD)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_021"); // �������O�ݬ�A�I
        }

        BigDecimal bigACNT_AMT = STRING.objToBigDecimal(C309VO.getACNT_AMT(), BigDecimal.ZERO);
        BigDecimal CASH = BigDecimal.ZERO;
        if (bigACNT_AMT.compareTo(CASH) == 0) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_022"); // �J�b���B���o��0�I
        }

        BigDecimal bigBAL_AMT = STRING.objToBigDecimal(C309VO.getBAL_AMT(), BigDecimal.ZERO);
        if (bigBAL_AMT.compareTo(bigACNT_AMT) != 0) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_023"); // �R�b�l�B !=�J�b���B�I
        }

        //�J�b��J�H��
        String strACNT_ID = C309VO.getACNT_ID();
        if (StringUtils.isBlank(strACNT_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_024"); // ��J�H���A���o���ťաI
        }

        //�J�b��J���
        Timestamp ACNT_IN_DATE = C309VO.getACNT_IN_DATE();
        if (ACNT_IN_DATE == null) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_025"); // �J�b��J����A���o���ťաI
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd 00:00:00.0");
            C309VO.setACNT_IN_DATE(DATE.toTimestamp(sdf.format(ACNT_IN_DATE)));//�j���ɶ��h��
        }

        //��]
        String strRESN_NO = STRING.emptyIf(C309VO.getRESN_NO(), "");
        String strRESN_NAME = STRING.emptyIf(C309VO.getRESN_NAME(), "");
        //��]����
        if ("99".equals(strRESN_NO)) {
            if (StringUtils.isBlank(strRESN_NAME)) {
                errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_026"); // ��]����A���o���ťաI
            }
        }

        //���v�R�b�H��
        String strAUTH_ID = STRING.emptyIf(C309VO.getAUTH_ID(), "");
        if (StringUtils.isNotBlank(strAUTH_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_027"); // ���v�R�b�H���A�ݬ�NULL�I
        }

        //�����ú���
        Date strRCPT_DATE = C309VO.getRCPT_DATE();
        if (strRCPT_DATE != null) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_028"); // �����ú����A�ݬ�NULL�I
        }

        if (errex != null) {
            throw errex;
        }

        //�J�b���
        String strACNT_DIV_NO = STRING.emptyIf(C309VO.getACNT_DIV_NO(), "");
        Unit unit = new DivData().getUnit(strACNT_DIV_NO);
        if (unit != null) {
            if ("1".equals(unit.getDivChangeStatus())) {
                C309VO.setACNT_DIV_NAME(unit.getDivShortName()); //�J�b��줤��
            }
        }

        //�g��H
        String strAGNT_ID = STRING.emptyIf(C309VO.getAGNT_ID(), "");
        PersonnelData pd = new PersonnelData();
        Employee Emp = pd.getByEmployeeID(strAGNT_ID);

        if (Emp != null) {
            if ((Emp.getStatus() >= 1) && (Emp.getStatus() <= 49)) {
                C309VO.setAGNT_NAME(Emp.getName()); //�g��H�m�W
            }
        }

        //�������J�b�s���GCALL�Ǹ����o�@�μҲը��o
        String strDATE = DATE.getDBDate();
        String strYear = strDATE.substring(2, 4);//2�X
        String strMonth = strDATE.substring(5, 7);//2�X

        //�e�q
        StringBuilder sb = new StringBuilder();
        sb.append('2').append(strYear).append(strMonth);

        //�y���Ǹ�
        String strSerialNo = new EP_Z0Z001().createNextNo(C309VO.getSUB_CPY_ID(), "047", strYear, strMonth, sb.toString(), 7);
        C309VO.setTMP_NO(strSerialNo);
    }

    /**
     * �ˮ�/��z�R�����
     * @param SUB_CPY_ID, ACNT_ID, ACNT_IN_DATE, ACNT_SET_NO
     * @throws ModuleException
     * @throws SQLException 
     */
    public void verifyDelete(String SUB_CPY_ID, String ACNT_ID, String ACNT_IN_DATE, String ACNT_SER_NO, List<String> invNoList) throws ModuleException {

        ErrorInputException errex = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_008"); // �ǤJ�����q�O���~!
        }
        if (StringUtils.isBlank(ACNT_ID)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_012"); // ��J���J�b��J�H�����~�I
        }
        if (!DATE.isDBTimeStamp(ACNT_IN_DATE)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_013"); // ��J���J�b��J������~�I
        }
        if (StringUtils.isBlank(ACNT_SER_NO)) {
            errex = getErrorInputException(errex, "EP_Z0C309_ERRMSG_014"); // ��J���J�b����Ǹ����~�I
        }
        if (errex != null) {
            throw errex;
        }

        //���d
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("ACNT_ID", ACNT_ID);
        ds.setField("ACNT_IN_DATE", ACNT_IN_DATE);
        ds.setField("ACNT_SER_NO", ACNT_SER_NO);
        //20200212 ��عq�l�o���ɤJ�G�Y�I�sws���ѡA�ȧR�����\���o���Ȧ�
        if (invNoList != null && !invNoList.isEmpty()) {
            ds.setFieldValues("INV_NOs", invNoList);
        }
        List<DTEPC309> C309LIST = VOTool.findToVOs(DTEPC309.class, ds, SQL_verifyDelete_001, false);

        if (C309LIST == null) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C309_ERRMSG_029")); //  �������J�b�L�ӵ���ơA���i�R���I
        }

        for (DTEPC309 C309 : C309LIST) {
            //��C309�ǲ����SLIP_DATE�ȩ�DTDEA120���@�b���ACNT_DATE
            C309.setACNT_DATE(C309.getSLIP_DATE());

            //�ˮּȦ��l�B
            BigDecimal ACNT_AMT = C309.getACNT_AMT();
            BigDecimal BAL_AMT = C309.getBAL_AMT();
            if (ACNT_AMT != null && BAL_AMT != null && ACNT_AMT.compareTo(BAL_AMT) != 0) {
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C309_ERRMSG_030")); // �������J�b��Ƥw�Q�R��A���i�R���I
            }

        }
    }

    /**
     * ���~�T���B�z
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException errex, String errstring) {
        if (errex == null) {
            errex = new ErrorInputException();
        }
        errex.appendMessage(MessageUtil.getMessage(errstring));
        return errex;
    }

}
