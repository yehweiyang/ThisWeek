package com.cathay.ep.z0.module;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.cathay.common.util.FieldOptionList;
import com.cathay.ep.vo.DTEPZ300;
import com.cathay.ep.vo.DTEPZ301;

/**
 * <pre>
 * LinksExtractor
 * </pre>
 * 
 * @author
 * @since [2019-04-29] �ӽЮ�190123001147 - �u�Ƶ{��
 */
public class LinksExtractor extends NewsExtractor {
    /**
     * �غc�l
     * @param site
     */
    public LinksExtractor(DTEPZ300 site) {
        super(site);
    }

    //private static final Logger log = Logger.getLogger(LinksExtractor.class);

    // [20190429] �R�����եε{��

    /**
     * �ѪR����(STEP 2)
     * �мgNewsExtractor.digesNews(site)
     */
    public List<DTEPZ301> digestNews(DTEPZ300 site) throws IOException, MalformedURLException {
        List<DTEPZ301> matchNews = new ArrayList<DTEPZ301>();
        String url = site.getURL();
        String baseUrl = url.substring(0, url.lastIndexOf('/') + 1);
        Document doc = getDocument(site);
        //log.debug("### DOC::" + StringUtils.substring(doc.text(), 0, 100));
        //log.debug("##### DOC::" + doc.text());

        Elements links;
        if (StringUtils.isNotBlank(site.getSELECTOR())) {
            Elements board = doc.select(site.getSELECTOR());
            // log.debug("Selector["+site.getSELECTOR()+"]"+ board);
            // log.debug(""+site.getINFO_SOURCE()+","+site.getSELECTOR()+": "+board.size());

            if (board == null || board.size() == 0) {
                String fullDoc = doc.text();
                String checkDoc = "";
                try {
                    checkDoc = FieldOptionList.getName("EP", "NEWS_DIGEST", site.getEVENT_ID() + "_" + site.getPCS_SEQ() + "_NOTERR");
                } catch (Exception e) {

                }
                if (StringUtils.isBlank(checkDoc) || fullDoc.indexOf(checkDoc) < 0) {
                    throw new RuntimeException("�������e�P�w�q�ѪR��ܾ�[" + site.getSELECTOR() + "]���P");
                } else {
                    throw new RuntimeException("��T�ӷ��L���");

                }
            }
            links = board.select("a");
        } else {
            links = doc.select("a");
        }

        for (Element link : links) {

            // log.debug("### link::"+link);
            // log.debug("selector class:"+ link.attr("class") +"== "+link.text());
            DTEPZ301 news = initDTEPZ301(site);

            //���o�s��
            String href = extractUrl(url, link);
            if (StringUtils.isBlank(href)) {
                continue;
            }
            String titleText = link.text();
            if (titleText.startsWith("?")) {
                titleText = titleText.substring(1);
            }

            // logHexCode(titleText);

            //���otitle
            String title = getLinkTitle(link);
            // log.debug("link text:" + title);

            news.setTITLE(title);
            news.setURL(extractUrl(baseUrl, href));

            matchNews.add(news);

        }

        return matchNews;

    }

}
