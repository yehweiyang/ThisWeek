package com.cathay.ep.z0.module;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.i1.module.EP_I10120;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE        Description Author
 * 2016/11/14  Created     �_�ɪ�
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �򥻸���ɬd�ߺ��@�Ҳ�
 * �Ҳ�ID    EP_Z0I100
 * ���n����    �򥻸���ɬd�ߺ��@�Ҳ�
 * </pre>
 * @author �����
 * @since  2016-11-29
 * 2019/07/03 �t�X���ʲ��a�ϱM�׷s�WAPI 
 * [20190808]�վ�Ÿm�v�P���������i�H��ܩʿ�J�W�U���A����J�~������,�p���I���NumberUtils.isNumber �ˮ� �A�̧C�ȻݧC��̰���
 * 2020/01/10 AllenTsai �̥��հϰ�W�٬d�ߥ��հϰ�N�X�M��Ψ̥��եN���d�ߤ���
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class EP_Z0I100 {

	Logger log = Logger.getLogger(EP_Z0I100.class);
	
    private static final String SQL_insertDTEPI100_001 = "com.cathay.ep.z0.module.EP_Z0I100.SQL_insertDTEPI100_001";

    private static final String SQL_updateDTEPI100_001 = "com.cathay.ep.z0.module.EP_Z0I100.SQL_updateDTEPI100_001";

    private static final String SQL_deleteDTEPI100_001 = "com.cathay.ep.z0.module.EP_Z0I100.SQL_deleteDTEPI100_001";

    private static final String SQL_queryDTEPI100_001 = "com.cathay.ep.z0.module.EP_Z0I100.SQL_queryDTEPI100_001";

    private static final String SQL_queryBldName_001 = "com.cathay.ep.z0.module.EP_Z0I100.SQL_queryBldName_001";

    private static final String SQL_insertDTEPI100_LOG_001 = "com.cathay.ep.z0.module.EP_Z0I100.SQL_insertDTEPI100_LOG_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0I100.SQL_queryMap_001";

    private static final String SQL_qryMktBuild_001 = "com.cathay.ep.z0.module.EP_Z0I100.SQL_qryMktBuild_001";

    private static final String SQL_qryMktBuildList_001 = "com.cathay.ep.z0.module.EP_Z0I100.SQL_qryMktBuildList_001";

    /**
     * �s�W�򥻸�� 
     *          �ѼƦW��   �榡         ����
     * @param   map     Map         �򥻸�Ƹ�T
     * @param   user    userObject  �ϥΪ̸�T
     * @return  INV_CD  String      ���դj�ӥN��
     * @throws ModuleException 
     * @throws UnsupportedEncodingException 
     */
    public String insertDTEPI100(Map map, UserObject user) throws ModuleException, UnsupportedEncodingException {
        ErrorInputException eie = null;
        if (map == null || map.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I100_MSG_001"));//�򥻸�Ƹ�T���o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I100_MSG_002")); //�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        //�y����
        String SUB_CPY_ID = MapUtils.getString(map, "SUB_CPY_ID");//�����q�O
        String CITY_CD = MapUtils.getString(map, "CITY_CD");//�����O�N��
        String ZONE_CD = MapUtils.getString(map, "ZONE_CD");//���հϰ�N��

        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I100_MSG_003"));//�����q�O���o����
        eie = checkStringParam(eie, CITY_CD, MessageUtil.getMessage("EP_Z0I100_MSG_004"));//�����O�N�����o����
        eie = checkStringParam(eie, ZONE_CD, MessageUtil.getMessage("EP_Z0I100_MSG_005"));//���հϰ�N�����o����
        if (eie != null) {
            throw eie;
        }

        int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "050", CITY_CD, ZONE_CD);
        String strSER_NO = Integer.toString(SER_NO);

        strSER_NO = STRING.fillCharFromLeftExt(strSER_NO, 5, '0', EncodingHelper.DefaultCharset);

        //����5��h����0
        //        for (strSER_NO.length(); strSER_NO.length() < 5;) {
        //            strSER_NO = "0" + strSER_NO;
        //        }
        String INV_CD = CITY_CD + ZONE_CD + strSER_NO; //���դj�ӥN��=�����O(3�X)+�ϰ�N��(3�X)+5�X�y����

        //�s�W�򥻸����DBEP.DTEPI100
        DataSet ds = Transaction.getDataSet();
        String[] keys1 = new String[] { "SUB_CPY_ID", "INV_CD", "CITY_CD", "ZONE_CD", "BLD_NAME", "ADDR_ZIP", "ADDR", "OFC_CLS", "BLD_KD",
                "PRK_KD", "FILE_NO", "INV_DIV_NO", "INV_ID", "INV_NAME", "CHG_DIV_NO", "CHG_ID", "CHG_NAME" };
        String[] keys2 = new String[] { "UP_FLR", "DWN_FLR", "BLD_SIZE", "BLD_END_DATE", "RNT_SIZE", "OFC_RNT_SIZE", "SHOP_RNT_SIZE",
                "RNT_PRK", "CHG_DATE" };

        for (String key : keys1) {
            if (StringUtils.isBlank(MapUtils.getString(map, key))) {
                ds.setField(key, "");
            } else {
                ds.setField(key, map.get(key));
            }
        }
        for (String key : keys2) {
            if (StringUtils.isBlank(MapUtils.getString(map, key))) {
                ds.setField(key, null);
            } else {
                ds.setField(key, map.get(key));
            }
        }
        ds.setField("INV_CD", INV_CD);
        ds.setField("CHG_DATE", DATE.currentTime());//���ʤ���ɶ�
        ds.setField("CHG_DIV_NO", user.getDivNo());//���ʳ��
        ds.setField("CHG_ID", user.getEmpID());//���ʤH��ID
        ds.setField("CHG_NAME", user.getEmpName());//���ʤH���m�W

        DBUtil.executeUpdate(ds, SQL_insertDTEPI100_001);
        return INV_CD;

    }

    /**
     * �ק�򥻸�� 
     *          �ѼƦW��   �榡         ����
     * @param   map     Map         �򥻸�Ƹ�T
     * @param   user    userObject  �ϥΪ̸�T
     * @throws ModuleException 
     */
    public void updateDTEPI100(Map map, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (map == null || map.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I100_MSG_001"));//�򥻸�Ƹ�T���o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I100_MSG_002")); //�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = MapUtils.getString(map, "SUB_CPY_ID");
        String INV_CD = MapUtils.getString(map, "INV_CD");

        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I100_MSG_003"));//�����q�O���o����
        eie = checkStringParam(eie, INV_CD, MessageUtil.getMessage("EP_Z0I100_MSG_006"));//���դj�ӥN�����o����
        if (eie != null) {
            throw eie;
        }
        //���d�߭n���ʪ���� 
        Map reqMap = new HashMap<String, String>();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("INV_CD", INV_CD);
        Map rtnMap = this.queryMap(reqMap);//���o�n���ʪ����

        String[] keys1 = new String[] { "SUB_CPY_ID", "INV_CD", "CITY_CD", "ZONE_CD", "BLD_NAME", "ADDR_ZIP", "ADDR", "OFC_CLS", "BLD_KD",
                "PRK_KD", "FILE_NO", "INV_DIV_NO", "INV_ID", "INV_NAME", "CHG_DIV_NO", "CHG_ID", "CHG_NAME" };
        String[] keys2 = new String[] { "UP_FLR", "DWN_FLR", "BLD_SIZE", "BLD_END_DATE", "RNT_SIZE", "OFC_RNT_SIZE", "SHOP_RNT_SIZE",
                "RNT_PRK", "CHG_DATE" };

        //�N���ʫe����ƥ��s�W��DTEPI100_LOG
        DataSet ds = Transaction.getDataSet();
        for (String key : keys1) {
            if (StringUtils.isBlank(MapUtils.getString(rtnMap, key))) {
                ds.setField(key, "");
            } else {
                ds.setField(key, rtnMap.get(key));
            }
        }
        for (String key : keys2) {
            if (StringUtils.isBlank(MapUtils.getString(rtnMap, key))) {
                ds.setField(key, null);
            } else {
                ds.setField(key, rtnMap.get(key));
            }
        }

        ds.setField("UPD_DATE", DATE.currentTime());//�J�ɤ���ɶ�
        ds.setField("UPD_TYPE", "U");
        ds.setField("UPD_DIV_NO", user.getDivNo());//LOG���ʤH�����N��
        ds.setField("UPD_ID", user.getEmpID());//LOG���ʤH��ID
        ds.setField("UPD_NAME", user.getEmpName());//LOG���ʤH���m�W

        DBUtil.executeUpdate(ds, SQL_insertDTEPI100_LOG_001);

        //���ʫe����Ʒs�W��LOG��A�~��sDTEPI101�����
        ds.clear();
        for (String key : keys1) {
            if (StringUtils.isBlank(MapUtils.getString(map, key))) {
                ds.setField(key, "");
            } else {
                ds.setField(key, map.get(key));
            }
        }
        for (String key : keys2) {
            if (StringUtils.isBlank(MapUtils.getString(map, key))) {
                ds.setField(key, null);
            } else {
                ds.setField(key, map.get(key));
            }
        }

        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getDivNo());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());

        DBUtil.executeUpdate(ds, SQL_updateDTEPI100_001);
    }

    /**
     * �R���򥻸�� 
     *          �ѼƦW��   �榡         ����
     * @param   map     Map         �򥻸�Ƹ�T
     * @param   user    userObject  �ϥΪ̸�T
     * @throws ModuleException 
     */
    public void deleteDTEPI100(Map map, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (map == null || map.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I100_MSG_001"));//�򥻸�Ƹ�T���o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I100_MSG_002")); //�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = MapUtils.getString(map, "SUB_CPY_ID");
        String INV_CD = MapUtils.getString(map, "INV_CD");

        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I100_MSG_003"));//�����q�O���o����
        eie = checkStringParam(eie, INV_CD, MessageUtil.getMessage("EP_Z0I100_MSG_006"));//���դj�ӥN�����o����
        if (eie != null) {
            throw eie;
        }
        //���d�߭n���ʪ���� 
        Map reqMap = new HashMap<String, String>();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("INV_CD", INV_CD);
        Map rtnMap = this.queryMap(reqMap); //���o�n���ʪ����

        String[] keys = new String[] { "SUB_CPY_ID", "INV_CD", "CITY_CD", "ZONE_CD", "BLD_NAME", "ADDR_ZIP", "ADDR", "OFC_CLS", "UP_FLR",
                "DWN_FLR", "BLD_SIZE", "BLD_END_DATE", "BLD_KD", "RNT_SIZE", "OFC_RNT_SIZE", "SHOP_RNT_SIZE", "RNT_PRK", "PRK_KD",
                "FILE_NO", "INV_DIV_NO", "INV_ID", "INV_NAME", "CHG_DATE", "CHG_DIV_NO", "CHG_ID", "CHG_NAME" };

        //�N�n���ʪ���Ʒs�W��DTEPI100_LOG
        DataSet ds = Transaction.getDataSet();
        for (String key : keys) {
            ds.setField(key, rtnMap.get(key));
        }
        ds.setField("UPD_DATE", DATE.currentTime());//�J�ɤ���ɶ�
        ds.setField("UPD_TYPE", "D");
        ds.setField("UPD_DIV_NO", user.getDivNo());//LOG���ʤH�����N��
        ds.setField("UPD_ID", user.getEmpID());//LOG���ʤH��ID
        ds.setField("UPD_NAME", user.getEmpName());//LOG���ʤH���m�W
        DBUtil.executeUpdate(ds, SQL_insertDTEPI100_LOG_001);

        //�}�l�R�����
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INV_CD", INV_CD);
        DBUtil.executeUpdate(ds, SQL_deleteDTEPI100_001);
    }

    /**
     * �d�߰򥻸�� 
     *          �ѼƦW��   �榡         ����
     * @param   map      Map      
     * @return  rtnList  List<Map>  �򥻸�Ʃ���     
     * @throws ModuleException 
     * 
     */
    public List<Map> queryDTEPI100(Map map) throws ModuleException {

        if (map == null || map.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_001"));//�򥻸�Ƹ�T���o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(map, "SUB_CPY_ID");

        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I100_MSG_003"));//�����q�O���o����
        if (eie != null) {
            throw eie;
        }

        String[] keys = new String[] { "SUB_CPY_ID", "INV_CD", "CITY_CD", "ZONE_CD", "OFC_CLS", "BLD_KD", "PRK_KD", "INV_DIV_NO", "INV_ID",
                "BLD_NAME" };

        DataSet ds = Transaction.getDataSet();
        for (String key : keys) {
            String Stringkey = MapUtils.getString(map, key);
            if (StringUtils.isNotEmpty(Stringkey)) {
                ds.setField(key, map.get(key));
            }
        }
        DBUtil.searchAndRetrieve(ds, SQL_queryDTEPI100_001);

        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map maps = VOTool.dataSetToMap(ds);
            String CITY_CD = MapUtils.getString(maps, "CITY_CD");
            String INV_DIV_NO = MapUtils.getString(maps, "INV_DIV_NO");
            String OFC_CLS = MapUtils.getString(maps, "OFC_CLS");
            String ZONE_CD = MapUtils.getString(maps, "ZONE_CD");
            String BLD_KD = MapUtils.getString(maps, "BLD_KD");//���c�y���� �ϥ�
            String PRK_KD = MapUtils.getString(maps, "PRK_KD");//�����쫬������ �ϥ�
            maps.put("CITY_CD_NM", FieldOptionList.getName("EP", "I1_CITY_CD", CITY_CD)); //��������
            maps.put("INV_DIV_NM", FieldOptionList.getName("EP", "I1_INV_DIV", INV_DIV_NO));//�ӿ��줤��          
            maps.put("OFC_CLS_NM", FieldOptionList.getName("EP", "I1_OFC_CLS", OFC_CLS));//�줽�Ǥ���         
            maps.put("ZONE_CD_NM", FieldOptionList.getName("EP", "I1_ZONE_CD_" + CITY_CD, ZONE_CD));//�ϰ줤��
            maps.put("BLD_KD_NM", FieldOptionList.getName("EP", "I1_BLD_KD", BLD_KD));//�c�y����  
            maps.put("PRK_KD_NM", FieldOptionList.getName("EP", "I1_PRK_KD", PRK_KD)); //���쫬������
            rtnList.add(maps);
        }
        return rtnList;
    }

    /**
     * �d�ߤj�ӦW�ٲM��
     *          �ѼƦW��        �榡         ����
     * @param   SUB_CPY_ID   String     �����q�O
     * @param   CITY_CD      String     �����O
     * @param   ZONE_CD      String     �ϰ�O
     * @return  rtnList      List<Map>  �򥻸�Ʃ���     
     * @throws ModuleException 
     * 
     */
    public List<Map> queryBldName(String SUB_CPY_ID, String CITY_CD, String ZONE_CD) throws ModuleException {

        ErrorInputException eie = null;

        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I100_MSG_003"));//�����q�O���o����
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (StringUtils.isNotEmpty(CITY_CD)) {
            ds.setField("CITY_CD", CITY_CD);
        }
        if (StringUtils.isNotEmpty(ZONE_CD)) {
            ds.setField("ZONE_CD", ZONE_CD);
        }
        return VOTool.findToMaps(ds, SQL_queryBldName_001);
    }

    /**
     * [20190703] ���դj�Ӭd��API
     * @param reqMap
     * @param MKT_BLD_LIST ���դj�ӽs���M��
     * @return
     * @throws ModuleException
     */
    public List<Map> qryMktBuildList(Map reqMap, List<String> MKT_BLD_LIST) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_009"));//��JreqMap���i����
        }
        if (MKT_BLD_LIST == null || MKT_BLD_LIST.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_007"));//��J���դj�ӽs���M��(MKT_BLD_LIST)���i����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_003"));//��J�����q�O(SUB_CPY_ID)���i����
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("MKT_BLD_LIST", MKT_BLD_LIST);

        //���������̧C��
        String BASE_AMT_LOW = MapUtils.getString(reqMap, "BASE_AMT_LOW");
        boolean isBASE_AMT_LOW = StringUtils.isNotBlank(BASE_AMT_LOW);
        //���������̰���
        String BASE_AMT_HIGH = MapUtils.getString(reqMap, "BASE_AMT_HIGH");
        boolean isBASE_AMT_HIGH = StringUtils.isNotBlank(BASE_AMT_HIGH);
        //[20190808]�վ�Ÿm�v�P���������i�H��ܩʿ�J�W�U���A����J�~������
        if (isBASE_AMT_LOW) {
            if (!StringUtils.isNumeric(BASE_AMT_LOW)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_010"));//���������̧C�Ȼݭn���Ʀr
            }
            ds.setField("BASE_AMT_LOW", BASE_AMT_LOW);
        }

        if (isBASE_AMT_HIGH) {
            if (!StringUtils.isNumeric(BASE_AMT_HIGH) ) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_014"));//���������̰��Ȼݭn���Ʀr
            }
            ds.setField("BASE_AMT_HIGH", BASE_AMT_HIGH);
        }        
        //���������̧C�ȻݧC��̰���
        if (isBASE_AMT_LOW && isBASE_AMT_HIGH && this.CompareBD(BASE_AMT_LOW, BASE_AMT_HIGH) > 0) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_011"));//���������̧C�ȻݧC��̰���
        }
        
        //�Ÿm�v�̧C��
        String EPT_RT_LOW = MapUtils.getString(reqMap, "EPT_RT_LOW");
        boolean isEPT_RT_LOW = StringUtils.isNotBlank(EPT_RT_LOW);
        //�Ÿm�v�̰���
        String EPT_RT_HIGH = MapUtils.getString(reqMap, "EPT_RT_HIGH");
        boolean isEPT_RT_HIGH = StringUtils.isNotBlank(EPT_RT_HIGH);

        //�Ÿm�v�̧C�ȭY��J�ݬ��Ʀr
        if (isEPT_RT_LOW) {
            if (!NumberUtils.isNumber(EPT_RT_LOW)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_013"));//�Ÿm�v�̧C�Ȼݬ��Ʀr
            }
        }
        //�Ÿm�v�̰��ȭY��J�ݬ��Ʀr
        if (isEPT_RT_HIGH) {
            if (!NumberUtils.isNumber(EPT_RT_HIGH) ) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_015"));//�Ÿm�v�̰��Ȼݬ��Ʀr
            }
        }        
        //�Ÿm�v�̧C�ȻݧC��̰���
        if (isEPT_RT_LOW && isEPT_RT_HIGH && this.CompareBD(EPT_RT_LOW, EPT_RT_HIGH) > 0) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_012"));//�Ÿm�v�̧C�ȻݧC��̰���
        }

        DBUtil.searchAndRetrieve(ds, SQL_qryMktBuildList_001);

        List<Map> rtnList = new ArrayList<Map>();

        Map OFC_CLS_Map = FieldOptionList.getFieldOptions("EP", "I1_OFC_CLS");
        Map BLD_KD_Map = FieldOptionList.getFieldOptions("EP", "I1_BLD_KD");

        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            BigDecimal EPT_SIZE = STRING.objToBigDecimal(rtnMap.get("EPT_SIZE"), BigDecimal.ZERO);
            BigDecimal RNT_SIZE = STRING.objToBigDecimal(rtnMap.get("RNT_SIZE"), BigDecimal.ONE);
            String EPT_RT = EPT_SIZE.divide(RNT_SIZE, 5, RoundingMode.HALF_UP).toPlainString();

            //�p�G�n�L�o�Ÿm�v,�åB�Ÿm�v�S���b�϶����h���L
            //�p�G����JEPT_RT_HIGH , EPT_RT ����W�����h���L
            if (isEPT_RT_HIGH && this.CompareBD(EPT_RT, EPT_RT_HIGH) > 0 ) {
                continue;
            }
            //�p�G����JEPT_RT_LOW , EPT_RT �C��U�����h���L
            if ((isEPT_RT_LOW && this.CompareBD(EPT_RT, EPT_RT_LOW) < 0) ) {
                continue;                       
            }
            //EPT_RT �Ÿm�v  = EPT_SIZE / OFC_RNT_SIZE
            rtnMap.put("EPT_RT", EPT_RT);
            //�ഫ����~
            rtnMap.put("INV_YR", MapUtils.getIntValue(rtnMap, "INV_YR") + 1911);
            String CITY_CD_CODE = "I1_ZONE_CD_" + MapUtils.getString(rtnMap, "CITY_CD");
            //���հϰ�W��
            rtnMap.put("ZONE_CD_NM", FieldOptionList.getName("EP", CITY_CD_CODE, MapUtils.getString(rtnMap, "ZONE_CD")));
            //�줽�ǵ��ŦW��
            rtnMap.put("OFC_CLS_NM", OFC_CLS_Map.get(MapUtils.getString(rtnMap, "OFC_CLS")));
            //�c�y�W��
            rtnMap.put("BLD_KD_NM", BLD_KD_Map.get(MapUtils.getString(rtnMap, "BLD_KD")));
            rtnList.add(rtnMap);
        }

        return rtnList;
    }

    /**
     * [20190703] ���դj�Ӱ򥻸�Ƭd��API
     * @param reqMap
     * @return
     * @throws ModuleException 
     */

    public Map qryMktBuild(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_009"));//��JreqMap���i����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I100_MSG_003"));//��J�����q�O(SUB_CPY_ID)���i����
        }
        String INV_CD = MapUtils.getString(reqMap, "INV_CD");
        if (StringUtils.isBlank(INV_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I100_MSG_008"));//���դj�ӽs��(INV_CD)���i����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INV_CD", INV_CD);

        Map rtnMap = VOTool.findOneToMap(ds, SQL_qryMktBuild_001);

        rtnMap.put("INV_YR", MapUtils.getIntValue(rtnMap, "INV_YR") + 1911);
        String CITY_CD_CODE = "I1_ZONE_CD_" + MapUtils.getString(rtnMap, "CITY_CD");
        //���հϰ�W��
        rtnMap.put("ZONE_CD_NM", FieldOptionList.getName("EP", CITY_CD_CODE, MapUtils.getString(rtnMap, "ZONE_CD")));
        //�줽�ǵ��ŦW��
        rtnMap.put("OFC_CLS_NM", FieldOptionList.getName("EP", "I1_OFC_CLS", MapUtils.getString(rtnMap, "OFC_CLS")));
        //�c�y�W��
        rtnMap.put("BLD_KD_NM", FieldOptionList.getName("EP", "I1_BLD_KD", MapUtils.getString(rtnMap, "BLD_KD")));
        //����Φ��W��
        rtnMap.put("PRK_KD_NM", FieldOptionList.getName("EP", "I1_PRK_KD", MapUtils.getString(rtnMap, "PRK_KD")));

        return rtnMap;
    }
    

    /**
     * �̥��հϰ�W�٬d�ߥ��հϰ�N�X�M��
     * @param invName
     * @return
     * @throws ModuleException
     */
    public List<Map<String, String>> getZoneList(String invName) throws ModuleException {
        if (StringUtils.isBlank(invName) ) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_019"));//�ݿ�J���հϰ�W��
        }
    	Map<String, String> cityMap = FieldOptionList.getName("EP", "I1_CITY_CD");
    	log.debug(cityMap);
    	List<Map<String, String>>  rtnList = new ArrayList<Map<String, String>> ();
    	for(Map.Entry<String, String> cityEntry : cityMap.entrySet()) {
    		String cityCode= cityEntry.getKey();
    		try{
        		Map <String, String> zoneInvMap = FieldOptionList.getName("EP", "I1_ZONE_CD_"+ cityCode);
        		for (Map.Entry<String, String> entry : zoneInvMap.entrySet()) {
        		    //log.debug(entry.getKey() + "/" + entry.getValue());
        		    if(entry.getValue().indexOf(invName)>=0) {
        		    	Map<String, String> invCodeName = new HashMap<String, String>();
        		    	invCodeName.put("CITY_CD", cityCode);
        		    	invCodeName.put("CITY_CD_NM", cityEntry.getValue());
        		    	invCodeName.put("CITY_ZONE_CD", cityCode+entry.getKey());
        		    	invCodeName.put("ZONE_CD_NM", entry.getValue());
        		    	rtnList.add(invCodeName);
        		    }
        		}    			
    		} catch(Exception e) {
    			
    		}
    		
    	}
    	return rtnList;
    }
    /**
     * �d�ߥ��հϰ줤��
     * @param  invCode ���հϰ� �������X
     * @return ���հϰ�P����
     * @throws ModuleException
     */    
    public String getInvZoneName(String invCode) throws ModuleException{
        if (StringUtils.isBlank(invCode) || invCode.length()!=6) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_016"));//��J���հϰ춷�����X
        }
    	String cityCode = invCode.substring(0,3);
    	String zoneCode = invCode.substring(3,6);
    	try{
        	String invName = FieldOptionList.getName("EP", "I1_ZONE_CD_"+ cityCode, zoneCode);
        	if(StringUtils.isEmpty(invName)) {
        		throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_017"));//��J���հϰ쥼����
        	}
        	return invName;
    	} catch(Exception e) {
    		log.fatal(e,e);
    		throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I100_MSG_018"));//�������հϰ�|������
    	}

    }    

    /**
     * �s�WLOG�ɨϥάd�߸��
     * @param reqMap
     * @return Map
     */
    private Map queryMap(Map reqMap) throws ModuleException {

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String INV_CD = MapUtils.getString(reqMap, "INV_CD");

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INV_CD", INV_CD);

        return VOTool.findOneToMap(ds, SQL_queryMap_001);
    }

    /**
     * 
     * @param eie
     * @param parameter
     * @param errMsg
     * @return
     */
    private ErrorInputException checkStringParam(ErrorInputException eie, String parameter, String errMsg) {
        if (StringUtils.isBlank(parameter)) {
            if (eie == null) {
                eie = new ErrorInputException();
            }
            eie.appendMessage(errMsg);
        }
        return eie;
    }

    /**
     * 
     * @param eie
     * @param parameter
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * [20190703]���str1,str2
     * 1 �N�� str1 > str2, 0 �N�� str1 = str2, -1 �N�� str1 < str2
     * @param str1
     * @param str2
     * @return
     */
    private int CompareBD(String str1, String str2) {
        BigDecimal BD1 = new BigDecimal(str1);
        BigDecimal BD2 = new BigDecimal(str2);
        return BD1.compareTo(BD2);
    }

}
