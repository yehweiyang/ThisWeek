package com.cathay.ep.z0.module;

import java.io.IOException;
import java.net.MalformedURLException;
import java.security.Security;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jsoup.nodes.Document;

import com.cathay.ep.vo.DTEPZ300;
import com.cathay.ep.vo.DTEPZ301;

/**
 * 
 * @author i9301216
 * @since [2019-04-29] �ӽЮ�190123001147 - �u�Ƶ{��
 */
public class NpbosExtractor extends NewsExtractor {
	public NpbosExtractor(DTEPZ300 site) {
		super(site);
	}
	static final Logger log = Logger.getLogger(NpbosExtractor.class);

    // [20190429] �R�����եε{��
	public List<DTEPZ301> digestNews(DTEPZ300 site) throws IOException,
			MalformedURLException {

		String url = site.getURL();
		String userAgent = site.getUSER_AGENT();
		String baseUrl = url.substring(0, url.lastIndexOf("/") + 1);
		Document doc = getDocumentByScript(url);
		List<DTEPZ301> matchNews = extractTable(doc, "http://www.fnpc.gov.tw/html/ch/CFT.php?page=CFTSaleBid&area=C000", "table table[bordercolor*=#A5D46F]");
		return matchNews;

	}

}
