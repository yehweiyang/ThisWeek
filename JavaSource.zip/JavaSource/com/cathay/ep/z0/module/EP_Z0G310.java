package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPG310;
import com.cathay.util.ControlMCaller;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014/10/01  Created ������
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ���§@�~�Ҳ�
 * �Ҳ�ID    EP_Z0G310 
 * ���n����    ���§@�~�Ҳ�
 * </pre>
 * @author �Ťl��
 *
 * [20200312]�ק��
 * 2020/04/07 AllenTsai �����¤�k
 * 20200511 �W�[�������C�Ƥ�K�s�¤��
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0G310 {

    private static final Logger log = Logger.getLogger(EP_Z0G310.class);

    private static final String SQL_queryG310ListGTYM_001 = "com.cathay.ep.z0.module.EP_Z0G310.SQL_queryG310ListGTYM_001";

    private static final String SQL_process_001 = "com.cathay.ep.z0.module.EP_Z0G310.SQL_process_001";

    private static final String SQL_updateSatus_001 = "com.cathay.ep.z0.module.EP_Z0G310.SQL_updateSatus_001";

    private static final String SQL_deleteDTEPG310_001 = "com.cathay.ep.z0.module.EP_Z0G310.SQL_deleteDTEPG310_001";

    private static final String SQL_queryProcessDepreYM_001 = "com.cathay.ep.z0.module.EP_Z0G310.SQL_queryProcessDepreYM_001";

    private static final String SQL_createDTEPG310_001 = "com.cathay.ep.z0.module.EP_Z0G310.SQL_createDTEPG310_001";
    
    private static final BigDecimal zero = BigDecimal.ZERO;
    /**
     * Ū����a���²M��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryG310ListGTYM(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String DEPR_KD = null;
        String DEPR_YM = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
            DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_KD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_003")); //�ǤJ�������O���o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_YM)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_004")); //�ǤJ���¦~�뤣�o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�ߧ����`�� (DTEPG310)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("DEPR_KD", DEPR_KD);
        ds.setField("GT_DEPR_YM", DEPR_YM);
        return VOTool.findToMaps(ds, SQL_queryG310ListGTYM_001);
    }

    /**
     * �d�ߧ��¦~���`��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map querySumMap(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String DEPR_KD = null;
        String DEPR_YM = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
            DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_KD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_003")); //�ǤJ�������O���o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_YM)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_004")); //�ǤJ���¦~�뤣�o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�d�ߧ����`���G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("DEPR_KD", DEPR_KD);
        ds.setField("DEPR_YM", DEPR_YM);

        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryG310ListGTYM_001);

        // [20200312]�s�W�{���X: �s�W�N�X�त��
        // �N�X�त��
        // ���ª��A
        rtnMap.put("DEPR_STS_NM", FieldOptionList.getName("EP", "DEPR_STS", MapUtils.getString(rtnMap, "DEPR_STS")));
        // �������O
        rtnMap.put("DEPR_KD_NM", FieldOptionList.getName("EP", "DEPR_KD", DEPR_KD));
        // ���§妸�B�z���A
        rtnMap.put("PCS_CD_NM", FieldOptionList.getName("EP", "PCS_CD", MapUtils.getString(rtnMap, "PCS_CD")));

        //�s�¤��W�[�������C��
        BigDecimal LY_DEPR = STRING.objToBigDecimal(MapUtils.getString(rtnMap, "LY_DEPR"), zero);
        if(LY_DEPR.compareTo(zero) ==0) {
            Map sumMap = new EP_Z0G300().querySumMap(rtnMap);

        	rtnMap.putAll(sumMap);
        }
        return rtnMap;
    }


    /**
     * ���³B�z
     * @param dataMap
     * @param user
     * @throws Exception
     * @Deprecated
     */
    public void process(Map dataMap, UserObject user) throws Exception {
        ErrorInputException eie = null;
        if (dataMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_009")); //�ǤJ�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�I�s�妸�@�~������³B�z
        ControlMCaller caller = new ControlMCaller(true);
        StringBuilder sb = new StringBuilder();
        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
        String DEPR_YM = MapUtils.getString(dataMap, "DEPR_YM");
        String DEPR_KD = MapUtils.getString(dataMap, "DEPR_KD");
        sb.append(SUB_CPY_ID).append("_").append(DEPR_YM).append("_").append(DEPR_KD);

        String[] batchArgArray = new String[] { SUB_CPY_ID, DEPR_YM, DEPR_KD, user.getEmpID(), user.getEmpName(), user.getOpUnit() };
        caller.runBatch("EPG3_B100", sb.toString(), batchArgArray, true);

    }

    /**
     * ��s���³B�z���A
     * @param dataMap
     * @param user
     * @param DEPR_STS
     * @throws ModuleException
     */
    public void updateSatus(Map dataMap, UserObject user, String DEPR_STS) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_008")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (StringUtils.isBlank(MapUtils.getString(dataMap, "SUB_CPY_ID"))) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_009")); //�ǤJ�@�~�H�����o���ŭ�
        }
        if (StringUtils.isBlank(DEPR_STS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_010")); //�ǤJ���³B�z���A���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        // [20200312]�ק�{���X
        Timestamp currentTime = DATE.currentTime();
        String opUnit = user.getOpUnit();
        String empID = user.getEmpID();
        String empName = user.getEmpName();
        String CFM_ID;
        String CFM_NM;
        String CFM_DIV_NO;
        Timestamp CFM_DT;
        if ("1".equals(DEPR_STS)) {
            CFM_DT = currentTime;
            CFM_DIV_NO = opUnit;
            CFM_ID = empID;
            CFM_NM = empName;
        } else {
            CFM_DT = null;
            CFM_DIV_NO = "";
            CFM_ID = "";
            CFM_NM = "";
        }

        // ��s���³B�z���A
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", dataMap.get("SUB_CPY_ID"));
        ds.setField("DEPR_YM", dataMap.get("DEPR_YM"));
        ds.setField("DEPR_KD", dataMap.get("DEPR_KD"));
        ds.setField("DEPR_STS", DEPR_STS);
        ds.setField("OLD_DEPR_STS", DEPR_STS);
        ds.setField("CHG_ID", empID);
        ds.setField("CHG_NAME", empName);
        ds.setField("CHG_DIV_NO", opUnit);
        ds.setField("CHG_DATE", currentTime);
        ds.setField("CFM_DT", CFM_DT);
        ds.setField("CFM_DIV_NO", CFM_DIV_NO);
        ds.setField("CFM_ID", CFM_ID);
        ds.setField("CFM_NM", CFM_NM);
        DBUtil.executeUpdate(ds, SQL_updateSatus_001);
    }

    // [20200312]�s�W�{���X
    /**
     * �R�������`��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public void deleteDTEPG310(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G310_MSG_008")); // �ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_002")); // �ǤJ�����q�O���o���ŭ�
        }
        String DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
        if (StringUtils.isBlank(DEPR_KD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_003")); // �ǤJ�������O���o���ŭ�
        }
        String DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM");
        if (StringUtils.isBlank(DEPR_YM)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_004")); // �ǤJ���¦~�뤣�o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        // �R�������`�� (DTEPG310)
        try {
            DataSet ds = Transaction.getDataSet();
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("DEPR_KD", DEPR_KD);
            ds.setField("DEPR_YM", DEPR_YM);
            DBUtil.executeUpdate(ds, SQL_deleteDTEPG310_001);
        } catch (DataNotFoundException dnfe) {
            log.info("�R�������`�� (DTEPG310)�A�R�L���", dnfe);
        }
    }

    // [20200312]�s�W�{���X
    /**
     * Ū����a���³B�z���M��
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException
     */
    public List<Map> queryProcessDepreYM(String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G310_MSG_002")); // �ǤJ�����q�O���o���ŭ�
        }
        // �H�ǤJ�����q�O�d�ߧ����`�� (DTEPG310)
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryProcessDepreYM_001);

        // �N�X�त��
        for (Map rtnMap : rtnList) {
            // ���ª��A
            rtnMap.put("DEPR_STS_NM", FieldOptionList.getName("EP", "DEPR_STS", MapUtils.getString(rtnMap, "DEPR_STS")));
            // �������O
            rtnMap.put("DEPR_KD_NM", FieldOptionList.getName("EP", "DEPR_KD", MapUtils.getString(rtnMap, "DEPR_KD")));
            // ���§妸�B�z���A
            rtnMap.put("PCS_CD_NM", FieldOptionList.getName("EP", "PCS_CD", MapUtils.getString(rtnMap, "PCS_CD")));
        }

        return rtnList;
    }

    // [20200312]�s�W�{���X
    /**
     * �s�W�ݳB�z�����`��
     * @param reqMap
     * @param user �@�~�H��
     * @throws ModuleException
     */
    public void createDTEPG310(Map reqMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_008")); // �ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_009")); // �ǤJ�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_002")); // �ǤJ�����q�O���o���ŭ�
        }
        String DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
        if (StringUtils.isBlank(DEPR_KD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_003")); // �ǤJ�������O���o���ŭ�
        }
        String DEPR_YM = MapUtils.getString(reqMap, "DEPR_YM");
        if (StringUtils.isBlank(DEPR_YM)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G310_MSG_004")); // �ǤJ���¦~�뤣�o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("DEPR_KD", DEPR_KD);
        ds.setField("DEPR_YM", DEPR_YM);
        ds.setField("CAL_DT", DATE.getDBDate());
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        ds.setField("DEPR_STS", "0");
        ds.setField("PCS_CD", "0");
        DBUtil.executeUpdate(ds, SQL_createDTEPG310_001);
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
