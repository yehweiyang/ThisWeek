package com.cathay.ep.z0.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.jsoup.helper.StringUtil;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �Ȥ��ƺ��@�Ҳ�
 * </pre>
 * @author ����[
 * @since 2016/3/22
 */
@SuppressWarnings("unchecked")
public class EP_Z0B201 {

    private static final String SQL_queryByVIR_ACC_ID_001 = "com.cathay.ep.z0.module.EP_Z0B201.SQL_queryByVIR_ACC_ID_001";

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0B201.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.z0.module.EP_Z0B201.SQL_queryList_002";

    /**
     * ���o�Ȥ��T(by�����b��)
     * @param VIR_ACC_ID
     * @return
     * @throws ModuleException 
     */
    public Map queryByVIR_ACC_ID(String VIR_ACC_ID, String SUB_CPY_ID) throws ModuleException {
        if (StringUtil.isBlank(VIR_ACC_ID)) {
            throw new ErrorInputException();//�ǤJ�����b�����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("VIR_ACC_ID", VIR_ACC_ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        int cnt = DBUtil.searchAndRetrieve(ds, SQL_queryByVIR_ACC_ID_001);
        if (cnt > 1) {
            throw new ModuleException("�����b�������h���Ȥ���");//�����b�������h���Ȥ���
        }
        ds.next();
        return VOTool.dataSetToMap(ds);
    }

    /**
     * �d�߫Ȥ���(from EP_B20010.queryList)
     * @param reqMap
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException 
     */
    public List<Map> queryB201List(Map reqMap, String SUB_CPY_ID) throws ModuleException {
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        boolean IS_EXACT = !"Y".equals(MapUtils.getString(reqMap, "IS_EXACT"));
        StringBuilder sb = new StringBuilder();
        setIfExist(ds, reqMap, "ID", sb, IS_EXACT);
        setIfExist(ds, reqMap, "CUS_NAME", sb, IS_EXACT);
        setIfExist(ds, reqMap, "CUS_ID", sb, IS_EXACT);
        setIfExist(ds, reqMap, "VIR_ACC_ID", sb, IS_EXACT);
        String SQL = IS_EXACT ? SQL_queryList_001 : SQL_queryList_002; //IS_EXACT "Y" ��T�d��
        List<Map> rtnList = VOTool.findToMaps(ds, SQL);
        return rtnList;
    }

    /**
     * �P�_�ȬO�_�s�b�A�]�w��Ʈw����
     * @param ds
     * @param reqMap
     * @param key
     * @param sb
     * @param isLike �O�_�ҽk����
     */
    private void setIfExist(DataSet ds, Map reqMap, String key, StringBuilder sb, boolean isLike) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            if (isLike) {
                value = sb.append("%").append(value).append("%").toString();
                sb.setLength(0);
            }
            ds.setField(key, value);
        }
    }
}
