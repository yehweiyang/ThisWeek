package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014-12-04  Created �Ťl��
 * 2018-03-12  �t�X��ؽվ�   ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �կ��թ���@�Ҳ�
 * �Ҳ�ID    EP_Z0C102
 * ���n����    SQL�կ��թ�Ҳ�
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EP_Z0C301 {

    private static final Logger log = Logger.getLogger(EP_Z0C301.class);

    private static final String SQL_doQuery_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_doQuery_001";

    private static final String SQL_doUpdate_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_doUpdate_001";

    private static final String SQL_updateRltAcntInfo_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_updateRltAcntInfo_001";

    private static final String SQL_updateRltAcntInfo_002 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_updateRltAcntInfo_002";

    private static final String SQL_queryPayList_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_queryPayList_001";

    private static final String SQL_deleteByPayNo_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_deleteByPayNo_001";

    private static final String SQL_insertBatch_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_insertBatch_001";

    private static final String SQL_queryH010List_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_queryH010List_001";

    private static final String SQL_queryH020ListB_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_queryH020ListB_001";

    private static final String SQL_queryH010TOTAL2_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_queryH010TOTAL2_001";

    private static final String SQL_queryListByPayNos_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_queryListByPayNos_001";

    private static final String SQL_updatePMI_S_DATE_001 = "com.cathay.ep.z0.module.EP_Z0C301.SQL_updatePMI_S_DATE_001";

    /**
     * ����ഫ�ק�ú�ڬ���
     * 20141219 ��s����ഫ��s
     * @param updMap ú�ڬ������
     * @throws ModuleException
     */
    public void switchPayment(Map reqMap, String CHG_ID, String CHG_NAME, String CHG_DIV_NO, Timestamp currentTime, String NEW_RCV_NO,
            String NEW_PAY_NO, String SUB_CPY_ID) throws ModuleException {
        DataSet ds = Transaction.getDataSet();
        VOTool.mapToDataSet(reqMap, ds);
        ds.setField("CHG_ID", CHG_ID);
        ds.setField("CHG_NAME", CHG_NAME);
        ds.setField("CHG_DIV_NO", CHG_DIV_NO);
        ds.setField("CHG_DATE", currentTime);
        ds.setField("NEW_RCV_NO", NEW_RCV_NO);
        ds.setField("NEW_PAY_NO", NEW_PAY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_doUpdate_001);
        return;
    }

    /**
     * �dú�ڬ������
     * 20141219 Allen Sql�Ҳդ� �q EP_C30080����L�� 
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @return �dú�ڬ������
     * @throws ModuleException
     */
    public List<Map> doQuery(String CRT_NO, String CUS_NO) throws ModuleException {
        // �Ѽ��ˮ�
        ErrorInputException eie = null;
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_Z0C301_MSG_001")); //�����N�����o����
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_Z0C301_MSG_002")); //�Ȥ�Ǹ����o����
        }

        if (!NumberUtils.isNumber(CUS_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_Z0C301_MSG_003")); //�Ȥ�Ǹ��ݬ��Ʀr�榡
        }

        if (eie != null) {
            throw eie;
        }

        // �d�߸�Ƴ]�w
        DataSet ds = Transaction.getDataSet();
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        DBUtil.searchAndRetrieve(ds, SQL_doQuery_001);

        int i = 1;
        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map map = VOTool.dataSetToMap(ds);

            // ���oú�ں�������
            map.put("PAY_KIND_NM", FieldOptionList.getName("EP", "PAY_KIND", MapUtils.getString(map, "PAY_KIND")));

            // ���oú�O�覡����
            map.put("PAY_TYPE_NM", FieldOptionList.getName("EP", "PAY_TYPE", MapUtils.getString(map, "PAY_TYPE")));

            map.put("Order", i++);

            map.put("ID", MapUtils.getString(map, "ID", "").trim());

            rtnList.add(map);
        }

        return rtnList;
    }

    /**
     * �dú�ڬ������
     * @param PAY_NOs
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException
     */
    public List<Map> queryListByPayNos(List<String> PAY_NOs, String SUB_CPY_ID) throws ModuleException {
        // �Ѽ��ˮ�
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (PAY_NOs == null || PAY_NOs.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C301_MSG_011")); //ú�O�s�����o����
        }

        if (eie != null) {
            throw eie;
        }

        // �d�߸�Ƴ]�w
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("PAY_NOs", PAY_NOs);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryListByPayNos_001);

        return rtnList;
    }

    /**
     * �dú�ڬ������
     * @param PAY_NO
     * @return
     * @throws ModuleException
     */
    public List<Map> queryPayList(String PAY_NO, String SUB_CPY_ID) throws ModuleException {
        // �Ѽ��ˮ�
        if (StringUtils.isBlank(PAY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C301_MSG_011")); //ú�O�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryPayList_001);

        for (Map rtnMap : rtnList) {

            //�]�w�������B
            String PAY_KIND = MapUtils.getString(rtnMap, "PAY_KIND");
            if ("3".equals(PAY_KIND)) {
                rtnMap.put("REC_AMT", rtnMap.get("RCV_AMT"));
            } else if ("2".equals(PAY_KIND)) {
                rtnMap.put("REC_AMT", rtnMap.get("SAL_AMT"));
            } else {
                rtnMap.put("REC_AMT", rtnMap.get("INV_AMT"));
            }
            rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND", PAY_KIND));
        }
        return rtnList;
    }

    /**
     * ��sú�O���p�b�ȸ�T
     * @param PAY_NO ú�O�s��
     * @param TRN_KIND ������� (06:�T�{; 01:�����T�{)
     * @param ACNT_DATE �b�Ȥ��
     * @param ACNT_DIV_NO �b�ȳ��
     * @param SLIP_LOT_NO �ǲ��帹
     * @param SLIP_SET_NO �ǲ��ո�
     * @param TRN_SER_NO �g�����Ǹ�
     * @param user
     * @throws ModuleException
     */
    public void updateRltAcntInfo(String PAY_NO, String TRN_KIND, Date ACNT_DATE, String ACNT_DIV_NO, String SLIP_LOT_NO,
            Integer SLIP_SET_NO, BigDecimal TRN_SER_NO, UserObject user, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_004"));//����������o����
        } else if (!"01".equals(TRN_KIND) && !"06".equals(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_005"));//����������~
        }
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_006"));//�b�Ȥ�����o����
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_007"));//�b�ȳ�줣�o����
        }
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_008"));//�ǲ��帹���o����
        }
        if (SLIP_SET_NO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_009"));//�ǲ��ո����o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_010"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        String Op = user.getOpUnit();
        String Id = user.getEmpID();
        String Name = user.getEmpName();
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
        ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        ds.setField("TRN_KIND", TRN_KIND);
        ds.setField("Op", Op);
        ds.setField("Id", Id);
        ds.setField("Name", Name);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //06:�T�{
        if ("06".equals(TRN_KIND)) {
            if (StringUtils.isBlank(PAY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_011"));//ú�O�s�����o����
            }
            if (TRN_SER_NO == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_012"));//�g�����Ǹ����o����
            }
            if (eie != null) {
                throw eie;
            }
            //��WDTEPC301ú�O���p�ɱb�ȸ�T
            ds.setField("TRN_SER_NO", TRN_SER_NO);
            ds.setField("PAY_NO", PAY_NO);

            try {
                DBUtil.executeUpdate(ds, SQL_updateRltAcntInfo_001);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C301_MSG_013"));//��sú�O���p�ɱb�ȸ�T���~,
            }
        } else {
            //01:�����T�{
            //�M��DTEPC301ú�O���p�ɱb�ȸ�T
            try {
                ds.setField("PAY_NO", PAY_NO);
                DBUtil.executeUpdate(ds, SQL_updateRltAcntInfo_002);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C301_MSG_014"));//����ú�O���p�ɱb�ȸ�T���~,
            }
        }

    }

    /**
     * �妸��sú�O���p�b�ȸ�T
     * @param PAY_LIST
     * @param MAP_TRNSERNO
     * @param TRN_KIND
     * @param ACNT_DATE
     * @param ACNT_DIV_NO
     * @param SLIP_LOT_NO
     * @param SLIP_SET_NO
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void acntUpdateBatch(List<Map> PAY_LIST, Map<String, Map> MAP_TRNSERNO, String TRN_KIND, Date ACNT_DATE, String SLIP_LOT_NO,
            Integer SLIP_SET_NO, UserObject user, BatchUpdateDataSet budsC301) throws ModuleException, DBException {

        //�վ�updateRltAcntInfo�W�[��岧�ʳB�z�覡
        //�ˮֶǤJ�Ѽ�
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        //�ˮֶǤJ�Ѽ�
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_004"));//����������o����
        } else if (!"01".equals(TRN_KIND) && !"06".equals(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_005"));//����������~
        }
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_006"));//�b�Ȥ�����o����
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_008"));//�ǲ��帹���o����
        }
        if (SLIP_SET_NO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_009"));//�ǲ��ո����o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_010"));//�ϥΪ̸�T���o����
        } else {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        String Op = user.getOpUnit();
        String Id = user.getEmpID();
        String Name = user.getEmpName();

        //BatchUpdateDataSet budsC301 = Transaction.getBatchUpdateDataSet();
        boolean isConfirm;
        if ("06".equals(TRN_KIND)) {
            //06:�T�{
            budsC301.preparedBatch(SQL_updateRltAcntInfo_001);
            isConfirm = true;
        } else {
            budsC301.preparedBatch(SQL_updateRltAcntInfo_002);
            isConfirm = false;
        }

        String ACNT_DIV_NO = user.getOpUnit();

        try {
            if (log.isDebugEnabled()) {
                log.debug("acntUpdateBatch.PAY_LIST::" + PAY_LIST);
                log.debug("acntUpdateBatch.MAP_TRNSERNO::" + MAP_TRNSERNO);
            }
            for (Map payMap : PAY_LIST) {
                //�D����ú�O�APASS�B�z�U�@�����
                String PAY_NO = MapUtils.getString(payMap, "PAY_NO");
                Map paySerRCVYM = MAP_TRNSERNO.get(PAY_NO);
                int RCV_YM = MapUtils.getIntValue(paySerRCVYM, "RCV_YM");
                if (0 == RCV_YM) {
                    log.fatal("acntUpdateBatch.0 == RCV_YM");
                    if (log.isDebugEnabled()) {
                        log.debug("acntUpdateBatch.RCV_YM::" + RCV_YM);
                    }
                    continue;
                }

                if (isConfirm) {
                    //��WDTEPC301ú�O���p�ɱb�ȸ�T
                    budsC301.setField("ACNT_DATE", ACNT_DATE);
                    budsC301.setField("ACNT_DIV_NO", ACNT_DIV_NO);
                    budsC301.setField("SLIP_LOT_NO", SLIP_LOT_NO);
                    budsC301.setField("SLIP_SET_NO", SLIP_SET_NO);
                    budsC301.setField("TRN_KIND", TRN_KIND);
                    budsC301.setField("Op", Op);
                    budsC301.setField("Id", Id);
                    budsC301.setField("Name", Name);
                    budsC301.setField("TRN_SER_NO", paySerRCVYM.get("TRN_SER_NO"));
                    budsC301.setField("PAY_NO", PAY_NO);
                    budsC301.setField("SUB_CPY_ID", SUB_CPY_ID);
                } else {
                    //01:�����T�{
                    //�M��DTEPC301ú�O���p�ɱb�ȸ�T
                    budsC301.setField("TRN_KIND", TRN_KIND);
                    budsC301.setField("Op", Op);
                    budsC301.setField("Id", Id);
                    budsC301.setField("Name", Name);
                    budsC301.setField("PAY_NO", PAY_NO);
                    budsC301.setField("SUB_CPY_ID", SUB_CPY_ID);
                }
                budsC301.addBatch();
            }

            // ����WDTEPC301ú�O���p�ɱb�ȸ�T
            budsC301.executeBatch();
            Object theErrorBudsC301Object[][] = budsC301.getBatchUpdateErrorArray();
            if (theErrorBudsC301Object.length > 0) {
                for (int k = 0; k < theErrorBudsC301Object.length; k++) {
                    Map errorDataMap = (Map) theErrorBudsC301Object[k][1];
                    if (isConfirm) {
                        log.error("��WDTEPC301ú�O���p�ɱb�ȸ�T,��" + (Exception) theErrorBudsC301Object[k][0] + "����Ʀ��~ ,setField = "
                                + errorDataMap.toString(), (Exception) theErrorBudsC301Object[k][2]);
                    } else {
                        log.error("�M��DTEPC301ú�O���p�ɱb�ȸ�T,��" + (Exception) theErrorBudsC301Object[k][0] + "����Ʀ��~,setField = "
                                + errorDataMap.toString(), (Exception) theErrorBudsC301Object[k][2]);
                    }
                }
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C301_MSG_015"));// ��sú�O���p�ɱb�ȸ�T���~
            }

        } catch (Exception e) {
            log.error(e, e);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C301_MSG_015"));// �妸��sú�O���p�ɱb�ȸ�T���~
        }

    }

    /**
     * ���s�Wú�O���p��T
     * @param PAY_LIST
     * @param user
     * @throws DBException 
     * @throws ModuleException 
     */
    public void insertBatch(List<Map> PAY_LIST, UserObject user, BatchUpdateDataSet budsC301) throws DBException, ModuleException {
        //�qEP_C30020. insertRtlInfo  �NDTEPC301�g�ɡA�վ㬰���B�z�Ҧ�
        //�ǤJ�Ѽ��ˬd
        ErrorInputException eie = null;
        if (PAY_LIST == null || PAY_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C301_MSG_016"));//ú�O�M�椣�o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String ID = user.getEmpID();
        String NAME = user.getEmpName();
        Timestamp currentTime = DATE.currentTime();
        String op = user.getOpUnit();

        //�]XAMode:buds�ѥD�{���ǤJ
        //BatchUpdateDataSet budsC301 = Transaction.getBatchUpdateDataSet();
        budsC301.preparedBatch(SQL_insertBatch_001);

        try {
            for (Map payMap : PAY_LIST) {
                String PAY_TYPE = MapUtils.getString(payMap, "PAY_TYPE");
                if ("5".equals(PAY_TYPE)) {
                    budsC301.setField("CHK_CD", "0");
                } else {
                    budsC301.setField("CHK_CD", "");
                }
                budsC301.setField("PAY_NO", payMap.get("PAY_NO"));
                budsC301.setField("RCV_NO", payMap.get("RCV_NO"));
                budsC301.setField("SUB_CPY_ID", payMap.get("SUB_CPY_ID"));
                budsC301.setField("RCV_YM", payMap.get("RCV_YM"));
                budsC301.setField("PAY_KIND", payMap.get("PAY_KIND"));
                budsC301.setField("CRT_NO", payMap.get("CRT_NO"));
                budsC301.setField("CUS_NO", payMap.get("CUS_NO"));
                budsC301.setField("PAY_TYPE", PAY_TYPE);
                budsC301.setField("PAY_AMT", payMap.get("PAY_AMT"));
                budsC301.setField("ORN_AMT", payMap.get("PAY_AMT"));
                String COA_DATE = MapUtils.getString(payMap, "COA_DATE");
                budsC301.setField("COA_DATE", DATE.isDate(COA_DATE) ? COA_DATE : null);
                String PMI_S_DATE = MapUtils.getString(payMap, "PMI_S_DATE");
                budsC301.setField("PMI_S_DATE", (DATE.isDate(PMI_S_DATE) ? PMI_S_DATE : null));
                String PMI_E_DATE = MapUtils.getString(payMap, "PMI_E_DATE");
                budsC301.setField("PMI_E_DATE", (DATE.isDate(PMI_E_DATE) ? PMI_E_DATE : null));
                budsC301.setField("INV_NO", payMap.get("INV_NO"));
                budsC301.setField("ID", MapUtils.getString(payMap, "ID", "").trim());//180502:��ذ��D�B�z:�קKnullPointException
                budsC301.setField("CUS_NAME", payMap.get("CUS_NAME"));
                budsC301.setField("BLD_CD", payMap.get("BLD_CD"));
                String PAY_S_DATE = MapUtils.getString(payMap, "PAY_S_DATE");
                budsC301.setField("PAY_S_DATE", (DATE.isDate(PAY_S_DATE) ? PAY_S_DATE : null));
                String PAY_E_DATE = MapUtils.getString(payMap, "PAY_E_DATE");
                budsC301.setField("PAY_E_DATE", (DATE.isDate(PAY_E_DATE) ? PAY_E_DATE : null));
                budsC301.setField("INPUT_ID", ID);
                budsC301.setField("INPUT_NAME", NAME);
                budsC301.setField("SLIP_SET_NO", 0);
                budsC301.setField("TRN_KIND", "01");
                budsC301.setField("CHG_DATE", currentTime);
                budsC301.setField("CHG_DIV_NO", op);
                budsC301.setField("CHG_ID", ID);
                budsC301.setField("CHG_NAME", NAME);
                budsC301.setField("OP_STATUS_C101", payMap.get("OP_STATUS"));

                budsC301.addBatch();
            }

            // ���s�WDBEP.DTEPC301ú�O���p��
            budsC301.executeBatch();
            Object theErrorBudsC301Object[][] = budsC301.getBatchUpdateErrorArray();
            if (theErrorBudsC301Object.length > 0) {
                for (int k = 0; k < theErrorBudsC301Object.length; k++) {
                    Map errorDataMap = (Map) theErrorBudsC301Object[k][1];
                    log.error("�s�WDBEP.DTEPC301ú�O���p��,��" + (Exception) theErrorBudsC301Object[k][0] + "����Ʀ��~,setField = "
                            + errorDataMap.toString(), (Exception) theErrorBudsC301Object[k][2]);
                }
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C301_MSG_017"));// �g�Jú�O���p�ɦ��~ 
            }

        } catch (Exception e) {
            log.error(e, e);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C301_MSG_017"));// �g�Jú�O���p�ɦ��~
        }
    }

    /**
     * ��ú�O�s���R��ú�O���p���� 
     * @param PAY_NO
     * @throws ModuleException
     */
    public void deleteByPayNo(String PAY_NO, String SUB_CPY_ID) throws ModuleException {
        // �Ѽ��ˮ�
        if (StringUtils.isBlank(PAY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C301_MSG_011")); //ú�O�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }

        //����DTEPC301ú�O���p��
        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_deleteByPayNo_001);
        } catch (ModuleException e) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C301_MSG_018", new Object[] { PAY_NO }));//"�R��ú�O���p��BYú�O�s�����~,ú�O�s��={0}"
        }

    }

    public List<Map> queryH010List(String RCV_YM, String SUB_CPY_ID) throws ModuleException {

        List<Map> rtnList = null;

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        String RCV_YM2 = RCV_YM.substring(0, 4) + "01";

        ds.setField("RCV_YM2", RCV_YM2);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        rtnList = VOTool.findToMaps(ds, SQL_queryH010List_001);

        return rtnList;
    }

    public void bqdsH010Search(BatchQueryDataSet bqds, String RCV_YM, String SUB_CPY_ID) throws DBException {
        bqds.setField("RCV_YM", RCV_YM);
        String RCV_YM2 = RCV_YM.substring(0, 4) + "01";
        bqds.setField("RCV_YM2", RCV_YM2);
        bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
        bqds.searchAndRetrieve(SQL_queryH010List_001);
    }

    /**
     * �d�����Y�H������
     * @param ID
     * @param ds 
     * @return   rtnList List<Map>   ���Y�H������
     */
    public List<Map> queryH020List(String[] ID, DataSet ds, String SUB_CPY_ID) throws ModuleException {

        ds.clear();
        ds.setFieldValues("ID", ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_queryH020ListB_001);
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

    /**
     * ��J�Ѽ��ˮ�
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getEieInstance(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �d�߷��~�ײ֭p�ܷ������`�M
     * @param RCV_YM
     * @param ID
     * @return
     * @throws ModuleException
     */
    public Map<String, BigDecimal> queryH010TOTAL2(String RCV_YM, List<String> IDs, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isEmpty(RCV_YM)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_002")); //�����~�묰�������
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (IDs == null || IDs.size() == 0) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_003")); //�Τ@�s�����������
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setFieldValues("ID", IDs);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //        DBUtil.searchAndRetrieve(ds, SQL_queryH010TOTAL3_001);
        //        ds.next();
        //
        //        return getBigDecimal(ds.getField(0));
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryH010TOTAL2_001);
        Map rtnMap = new HashMap<String, BigDecimal>(rtnList.size());
        for (Map data : rtnList) {
            rtnMap.put(MapUtils.getString(data, "ID", "").trim(), data.get("TOTAL2"));
        }
        return rtnMap;

    }

    /**
     * �P�h�����^��p���϶�
     * @param PAY_NO
     * @param RCV_NO
     * @param SUB_CPY_ID
     * @param PMI_S_DATE
     * @param PMI_E_DATE
     * @throws ModuleException 
     */
    public void updatePMI_S_DATE(String PAY_NO,String RCV_NO,String SUB_CPY_ID,String PMI_S_DATE,String PMI_E_DATE) throws ModuleException {
        
        DataSet ds = Transaction.getDataSet();
        ds.setField("PMI_S_DATE", PMI_S_DATE);
        ds.setField("PMI_E_DATE", PMI_E_DATE);
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("SUB_CPY_ID",SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_updatePMI_S_DATE_001);
    }
}
