package com.cathay.ep.z0.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPG152;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE        Description Author �߮׳渹
 * 2020/06/02  Created     ������  200414001917
 * 
 * �ҲզW��   �j�ӧY�ɧQ���ˮֺ��@�Ҳ�
 * �Ҳ�ID     EP_Z0G152
 * ���n����   �j�ӧY�ɧQ���ˮֺ��@�Ҳ�
 * </pre>
 * @author ���۾�
 * @since 2020/06/05
 *
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0G152 {

    private static final Logger log = Logger.getLogger(EP_Z0G152.class);

    private static final String SQL_qeuryList_001 = "com.cathay.ep.z0.module.EP_Z0G152.SQL_qeuryList_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0G152.SQL_queryMap_001";

    /**
     * �d�ߤj�ӧY�ɧQ���ˮֲM��
     * @param reqMap �d�߱���
     * @return �j�ӧY�ɧQ���ˮ� DETEPG152(�h��)
     * @throws ModuleException 
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { "EP_Z0G152_ERRMSG_002" })); //TODO//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}  EP_Z0G152_ERRMSG_002 -> �d�߱���
        }
        List<String> strArry = null;
        String formatErrorMsg = "";
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_003");//EP_Z0G152_ERRMSG_003 -> �����q�O
        }
        String REG_TP = MapUtils.getString(reqMap, "REG_TP");
        if (StringUtils.isBlank(REG_TP)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_004");//EP_Z0G152_ERRMSG_004 -> �Y�ɧQ�Ϊk�O
        }
        String EDIT_TP = MapUtils.getString(reqMap, "EDIT_TP");
        if (StringUtils.isBlank(EDIT_TP)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_005");//EP_Z0G152_ERRMSG_005 -> �B�z���A
        }
        String CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
        if (StringUtils.isBlank(CAL_YM)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_006");//EP_Z0G152_ERRMSG_006 -> �ˮ֦~��
        } else if (!DATE.isDate(CAL_YM + "01", "########")) {
            formatErrorMsg = MessageUtil.getMessage("EP_Z0G152_ERRMSG_007");//EP_Z0G152_ERRMSG_007 -> �ˮ֦~��榡���~
        }
        if (StringUtils.isBlank(formatErrorMsg) && strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        if (StringUtils.isNotBlank(formatErrorMsg)) {
            StringBuilder sb = new StringBuilder();
            if (strArry != null) {
                sb.append(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
                STRING.newLine(sb);
            }
            sb.append(formatErrorMsg);
            throw new ErrorInputException(sb.toString());
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("REG_TP", REG_TP);
        ds.setField("EDIT_TP", EDIT_TP);
        ds.setField("CAL_YM", CAL_YM);
        List<Map> rtnList = new ArrayList<Map>(DBUtil.searchAndRetrieve(ds, SQL_qeuryList_001));
        //�v���B�z�^�ǲM��G
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //�]�w���ȳ]�w�N�X����
            setBldNmInfo(rtnMap, reqMap);
            rtnList.add(rtnMap);
        }

        return rtnList;
    }

    /**
     * �d�ߤj�ӧY�ɧQ���ˮֵ��G
     * @param reqMap �d�߱���
     * @return �j�ӧY�ɧQ���ˮ�DETEPG152
     * @throws ModuleException 
     */
    public Map queryMap(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { "EP_Z0G152_ERRMSG_002" })); //TODO//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}  EP_Z0G152_ERRMSG_002 -> �d�߱���
        }
        List<String> strArry = null;
        String formatErrorMsg = "";
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_003");//EP_Z0G152_ERRMSG_003 -> �����q�O
        }
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_008");//EP_Z0G152_ERRMSG_008 -> ��a�N��
        }
        String CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
        if (StringUtils.isBlank(CAL_YM)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_006");//EP_Z0G152_ERRMSG_006 -> �ˮ֦~��
        } else if (!DATE.isDate(CAL_YM + "01", "########")) {
            formatErrorMsg = MessageUtil.getMessage("EP_Z0G152_ERRMSG_007");//EP_Z0G152_ERRMSG_007 -> �ˮ֦~��榡���~
        }
        if (StringUtils.isBlank(formatErrorMsg) && strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        if (StringUtils.isNotBlank(formatErrorMsg)) {
            StringBuilder sb = new StringBuilder();
            if (strArry != null) {
                sb.append(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
                STRING.newLine(sb);
            }
            sb.append(formatErrorMsg);
            throw new ErrorInputException(sb.toString());
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("CAL_YM", CAL_YM);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001);
        //�]�w���������N�X����
        setBldNmInfo(rtnMap, reqMap);

        return rtnMap;
    }

    /**
     * �s�W�j�ӧY�ɧQ���ˮֵ��G
     * @param reqMap �j�ӧY�ɧQ���ˮֵ��G
     * @param user   �@�~�H��
     * @throws ModuleException 
     */
    public void insertRecord(Map reqMap, UserObject user) throws ModuleException {
        List<String> strArry = null;
        if (reqMap == null || reqMap.isEmpty()) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_009");//EP_Z0G152_ERRMSG_009 -> �j�ӧY�ɧQ���ˮֵ��G
        }
        if (user == null) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_010");//EP_Z0G152_ERRMSG_010 -> �@�~�H��
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") })); //TODO//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_003");//EP_Z0G152_ERRMSG_003 -> �����q�O
        }
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_008");//EP_Z0G152_ERRMSG_008 -> ��a�N��
        }
        String EVAL_ZONE = MapUtils.getString(reqMap, "EVAL_ZONE");
        if (StringUtils.isBlank(EVAL_ZONE)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_011");//EP_Z0G152_ERRMSG_011 -> ���Ȱϰ�
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") })); //TODO//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        DTEPG152 G152VO = VOTool.mapToVO(DTEPG152.class, reqMap);
        G152VO.setCHG_DATE(DATE.currentTime());
        G152VO.setCHG_ID(user.getEmpID());
        G152VO.setCHG_NAME(user.getEmpName());
        G152VO.setCHG_DIV_NO(user.getOpUnit());
        VOTool.insert(G152VO);
    }

    /**
     * �R���j�ӧY�ɧQ���ˮֵ��G
     * @param reqMap �j�ӧY�ɧQ���ˮֵ��G
     * @throws ModuleException 
     */
    public void deleteRecord(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { "EP_Z0G152_ERRMSG_002" })); //TODO//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}  EP_Z0G152_ERRMSG_002 -> �d�߱���
        }
        List<String> strArry = null;
        String formatErrorMsg = "";
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_003");//EP_Z0G152_ERRMSG_003 -> �����q�O
        }
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_008");//EP_Z0G152_ERRMSG_008 -> ��a�N��
        }
        String CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
        if (StringUtils.isBlank(CAL_YM)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_006");//EP_Z0G152_ERRMSG_006 -> �ˮ֦~��
        } else if (!DATE.isDate(CAL_YM + "01", "########")) {
            formatErrorMsg = MessageUtil.getMessage("EP_Z0G152_ERRMSG_007");//EP_Z0G152_ERRMSG_007 -> �ˮ֦~��榡���~
        }
        if (StringUtils.isBlank(formatErrorMsg) && strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        if (StringUtils.isNotBlank(formatErrorMsg)) {
            StringBuilder sb = new StringBuilder();
            if (strArry != null) {
                sb.append(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
                STRING.newLine(sb);
            }
            sb.append(formatErrorMsg);
            throw new ErrorInputException(sb.toString());
        }
        //�R���j�ӧY�ɧQ���ˮֵ��G (DTEPG152)�G
        DTEPG152 G152VO = new DTEPG152();
        G152VO.setSUB_CPY_ID(SUB_CPY_ID);
        G152VO.setBASE_CD(BASE_CD);
        G152VO.setCAL_YM(Integer.valueOf(CAL_YM));
        VOTool.delByPK(G152VO);
    }

    /**
     * ��s�j�ӧY�ɧQ���ˮֵ��G
     * @param reqMap  �j�ӧY�ɧQ���ˮֵ��G
     * @param user    �@�~�H��
     * @throws ModuleException 
     */
    public void updateRecord(Map reqMap, UserObject user) throws ModuleException {
        List<String> strArry = null;
        if (reqMap == null || reqMap.isEmpty()) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_009");//EP_Z0G152_ERRMSG_009 -> �j�ӧY�ɧQ���ˮֵ��G
        }
        if (user == null) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_010");//EP_Z0G152_ERRMSG_010 -> �@�~�H��
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") })); //TODO//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        String formatErrorMsg = "";
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_003");//EP_Z0G152_ERRMSG_003 -> �����q�O
        }
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_008");//EP_Z0G152_ERRMSG_008 -> ��a�N��
        }
        String CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
        if (StringUtils.isBlank(CAL_YM)) {
            strArry = getArrayList(strArry, "EP_Z0G152_ERRMSG_006");//EP_Z0G152_ERRMSG_006 -> �ˮ֦~��
        } else if (!DATE.isDate(CAL_YM + "01", "########")) {
            formatErrorMsg = MessageUtil.getMessage("EP_Z0G152_ERRMSG_007");//EP_Z0G152_ERRMSG_007 -> �ˮ֦~��榡���~
        }
        if (StringUtils.isBlank(formatErrorMsg) && strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        if (StringUtils.isNotBlank(formatErrorMsg)) {
            StringBuilder sb = new StringBuilder();
            if (strArry != null) {
                sb.append(MessageUtil.getMessage("EP_Z0G152_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G152_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
                STRING.newLine(sb);
            }
            sb.append(formatErrorMsg);
            throw new ErrorInputException(sb.toString());
        }
        //��s�j�ӧY�ɧQ���ˮֵ��G 
        DTEPG152 G152VO = VOTool.mapToVO(DTEPG152.class, reqMap);
        G152VO.setCHG_DATE(DATE.currentTime());
        G152VO.setCHG_ID(user.getEmpID());
        G152VO.setCHG_NAME(user.getEmpName());
        G152VO.setCHG_DIV_NO(user.getOpUnit());
        VOTool.update(G152VO);
    }

    /**
     * <pre>
     * �w���s��FieldOptionList
     * �J��catch Exception�ì���log�B�a�J�ŭ�
     * </pre>
     * @param sysId
     * @param fieldName
     * @param option
     * @param rtnMap    �^��Map
     * @param rtnName   �N�����^Map��key��
     * @param errMsg    log����
     */
    private void getNameSafe(String sysId, String fieldName, String option, Map rtnMap, String rtnName, String errMsg) {
        try {
            String name = FieldOptionList.getName(sysId, fieldName, option);
            rtnMap.put(rtnName, name);
        } catch (Exception e) {
            log.fatal(errMsg, e);
            rtnMap.put(rtnName, "");
        }
    }

    /**
     * �]�w�N�X����
     * @param rtnMap �j�Ӧ�������DETEPG150
     */
    private void setBldNmInfo(Map rtnMap, Map reqMap) {
        String REG_TP = MapUtils.getString(rtnMap, "REG_TP");
        this.getNameSafe("EP", "REG_TP", REG_TP, rtnMap, "REG_TP_NM", "���o�N�X���奢��:�Y�ɧQ�Ϊk�O");
        String ACC_MD = MapUtils.getString(rtnMap, "ACC_MD");
        this.getNameSafe("EP", "ACC_MD", ACC_MD, rtnMap, "ACC_MD_NM", "���o�N�X���奢��:�����覡");
        String EVAL_TP = MapUtils.getString(rtnMap, "EVAL_TP");
        this.getNameSafe("EP", "EVAL_TP", EVAL_TP, rtnMap, "EVAL_TP_NM", "���o�N�X���奢��:�g�a����");
        String USE_CHK = MapUtils.getString(rtnMap, "USE_CHK");
        this.getNameSafe("EP", "USE_CHK", USE_CHK, rtnMap, "USE_CHK_NM", "���o�N�X���奢��:�Y�ɧQ���ˮ�");
        String BASE_CD = MapUtils.getString(rtnMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            //�L�Y�ɧQ���ˮֳ]�w�|���B�z
            rtnMap.put("BASE_CD", rtnMap.get("BASE_CD_G150"));
            rtnMap.put("SUB_CPY_ID", rtnMap.get("SUB_CPY_ID_G150"));
            rtnMap.put("CAL_YM", reqMap.get("CAL_YM"));
        }
    }

    /**
     * ���oArrayList<String>����
     * ErrorInputException
     * @param strArry
     * @param errMsg
     * @return 
     */
    private List<String> getArrayList(List strArry, String errMsg) {
        if (strArry == null) {
            strArry = new ArrayList<String>();
        }
        strArry.add(errMsg);
        return strArry;
    }
}
