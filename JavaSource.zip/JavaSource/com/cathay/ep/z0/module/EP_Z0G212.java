package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �ҲզW�� ��a���������R�P�O�����@�Ҳ�
 * �Ҳ�ID EP_Z0G212
 * ���n���� ��a���������R�P�O�����@�Ҳ�
 * </pre>
 * @author ���t�@
 * @since 2020/03/30
 * 20200408 AllenTsai �վ�ҲնǤJ�@�~�H��
 * 20200409 AllenTsai �վ�R�P����s�����ȳB�z
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0G212 {

    //    private static final Logger log = Logger.getLogger(EP_Z0G212.class);

    private static final String SQL_batchInsert_001 = "com.cathay.ep.z0.module.EP_Z0G212.SQL_batchInsert_001";

    private static final String SQL_batchDelete_001 = "com.cathay.ep.z0.module.EP_Z0G212.SQL_batchDelete_001";

    private static final String SQL_queryDeductList_001 = "com.cathay.ep.z0.module.EP_Z0G212.SQL_queryDeductList_001";

    /**
     * �妸�s�W���������R�P�O����
     * @param g212List
     * @param aply_no
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void batchInsert(List<Map> g212List, String aply_no, UserObject user) throws ModuleException, DBException {
        if (g212List == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G212_MSG_001")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ� 
        }
        
        if (StringUtils.isEmpty(aply_no)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G212_MSG_005")); //�ǤJ����s�����o���ŭ� 
        }

        final String D_APLY_NO = aply_no;
        final String id = user.getEmpID();
        final String nm = user.getEmpName();
        final String div_no = user.getOpUnit();
        final Timestamp current = DATE.currentTime();
        //�v��Ū��g212List �z�LBUDS �妸���s�W��a���������R�P���� DTEPG212
        BatchConstructor.processByBatch(g212List, SQL_batchInsert_001, false, ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL,
            new BatchConstructor.ListHandler() {
                protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {
                    Map g212Map = (Map) Object;
                    buds.setField("SUB_CPY_ID", g212Map.get("SUB_CPY_ID"));
                    buds.setField("BASE_CD", g212Map.get("BASE_CD"));
                    buds.setField("COST_SEQ", g212Map.get("COST_SEQ"));
                    buds.setField("D_APLY_NO", D_APLY_NO);
                    buds.setField("ACC_TP", g212Map.get("ACC_TP"));
                    buds.setField("SUB_ITEM_NO", g212Map.get("SUB_ITEM_NO"));
                    buds.setField("ITEM_MEMO", g212Map.get("ITEM_MEMO"));
                    buds.setField("D_COST_AMT", g212Map.get("D_COST_AMT"));
                    buds.setField("D_LOSS_AMT", g212Map.get("D_LOSS_AMT"));
                    buds.setField("CHG_DATE", current);
                    buds.setField("CHG_DIV_NO", div_no);
                    buds.setField("CHG_ID", id);
                    buds.setField("CHG_NAME", nm);
                    addBatchAndJoinGroup(buds);
                }
            });
    }

    /**
     * �妸�R����������
     * @param g212List
     * @throws ModuleException
     * @throws DBException
     */
    public void batchDelete(List<Map> g212List) throws ModuleException, DBException {
        if (g212List == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G212_MSG_001")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        //�v��Ū��g212List ���o mapG212 �z�LBUDS �妸���R����a���������R�P����
        BatchConstructor.processByBatch(g212List, SQL_batchDelete_001, false, ErrorHandler.DATA_NOT_FOUND_FAIL_ONLY,
            new BatchConstructor.ListHandler() {
                protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {
                    Map g212Map = (Map) Object;
                    buds.setField("SUB_CPY_ID", g212Map.get("SUB_CPY_ID"));
                    buds.setField("BASE_CD", g212Map.get("BASE_CD"));
                    buds.setField("COST_SEQ", g212Map.get("COST_SEQ"));
                    buds.setField("D_APLY_NO", g212Map.get("G212_D_APLY_NO"));
                    addBatchAndJoinGroup(buds);
                }
            });
    }

    /**
     * �d�߰�a���������R�P�����P���ʫe����
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryDeductList(Map reqMap) throws ModuleException {
        if (reqMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G212_MSG_002")); //�ǤJ���󤣱o����
        }

        ErrorInputException eie = null;

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G212_MSG_003")); //�ǤJ�����q�O���o���ŭ�
        }

        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G212_MSG_004")); //�ǤJ��a�N�����o���ŭ�
        }

        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G212_MSG_005")); //�ǤJ����s�����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        //�H�ǤJ����d�߰�a�������������Ʋ���LOG �P�R�P����(DTEPG210_LOG)�G
        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        StringBuilder sb = new StringBuilder();

        setLikeFieldsIfExsits(ds, reqMap, "BASE_CD", sb);
        setLikeFieldsIfExsits(ds, reqMap, "APLY_NO", sb);

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryDeductList_001);
        // �v���B�z�^�ǲM��G
        for (Map rtnMap : rtnList) {
            //�|�p����
            rtnMap.put("ACC_TP_NM", FieldOptionList.getName("EP", "ACC_TP", MapUtils.getString(rtnMap, "ACC_TP")));

            //�u������  
            rtnMap.put("SUB_ITEM_NO_NM", FieldOptionList.getName("EP", "G3_SUB_ITEM_NO", MapUtils.getString(rtnMap, "SUB_ITEM_NO")));

            //�������A
            rtnMap.put("ITEM_STS_NM", FieldOptionList.getName("EP", "ITEM_STS", MapUtils.getString(rtnMap, "ITEM_STS")));

            //�]�w�R�P�������R�P����s��
            rtnMap.put("G212_D_APLY_NO", MapUtils.getString(rtnMap, "UPD_APLY_NO"));
        }

        return rtnList;
    }

    /**
     * �p���a���������R�P�e��M��
     * @param G212List
     * @param G100Map
     * @param user
     * @return
     * @throws ModuleException
     */
    public Map calDeductG210List(List<Map> G212List, Map G100Map, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (G212List == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G212_MSG_001")); //�ǤJ�B�z�ѼƸ�Ƥ��o���ŭ�
        }
        if (G100Map == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G212_MSG_002"));//�ǤJ���󤣱o����
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G212_MSG_006")); //�ǤJ�@�~�H�����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        String SUB_CPY_ID = MapUtils.getString(G100Map, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G212_MSG_003")); //�ǤJ�����q�O���o���ŭ�
        }

        String BASE_CD = MapUtils.getString(G100Map, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G212_MSG_004")); //�ǤJ��a�N�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        StringBuilder sb = new StringBuilder();

        //���o�R�P�������� deductMap
        Map<String, Map> deductMap = new HashMap<String, Map>();

        //�v���B�z G212List
        for (Map G212Map : G212List) {
            BigDecimal D_COST_AMT = STRING.objToBigDecimal(G212Map.get("D_COST_AMT"), BigDecimal.ZERO);
            if (D_COST_AMT.compareTo(BigDecimal.ZERO) > 0) {
                String key = sb.append(MapUtils.getString(G212Map, "SUB_CPY_ID")).append(MapUtils.getString(G212Map, "BASE_CD"))
                        .append(MapUtils.getString(G212Map, "COST_SEQ")).toString();
                deductMap.put(key, G212Map);
                sb.setLength(0);
            }
        }

        //�d�߰�a�������������ơG
        List<Map> G210List = new EP_Z0G210().queryList(G100Map, "");

        //�B�z�R�P�e����������M��
        List<Map> orgG210List = new ArrayList<Map>(); //�R�P�e��������
        List<Map> deductG210List = new ArrayList<Map>();//�R�P���������

        String id = user.getEmpID();
        String nm = user.getEmpName();
        String div_no = user.getOpUnit();
        Timestamp current = DATE.currentTime();

        for (Map G210Map : G210List) {
            String key = sb.append(MapUtils.getString(G210Map, "SUB_CPY_ID")).append(MapUtils.getString(G210Map, "BASE_CD"))
                    .append(MapUtils.getString(G210Map, "COST_SEQ")).toString();
            Map G212Map = deductMap.get(key);
            sb.setLength(0);

            if (G212Map != null && !G212Map.isEmpty()) {
                //��J�R�P�e��������
                Map G210MapLog = new HashMap();
                G210MapLog.putAll(G210Map);
                orgG210List.add(G210MapLog);

                //�p��R�P��b������
                BigDecimal COST_AMT = STRING.objToBigDecimal(G210Map.get("COST_AMT"), BigDecimal.ZERO);
                BigDecimal D_COST_AMT = STRING.objToBigDecimal(G212Map.get("D_COST_AMT"), BigDecimal.ZERO);
                G210Map.put("COST_AMT", COST_AMT.subtract(D_COST_AMT));

                //�p��R�P���l���B
                BigDecimal LOSS_AMT = STRING.objToBigDecimal(G210Map.get("LOSS_AMT"), BigDecimal.ZERO);
                BigDecimal D_LOSS_AMT = STRING.objToBigDecimal(G212Map.get("D_LOSS_AMT"), BigDecimal.ZERO);
                G210Map.put("LOSS_AMT", LOSS_AMT.subtract(D_LOSS_AMT));

                //�]�w�R�P�b������
                G210Map.put("D_COST_AMT", G212Map.get("D_COST_AMT"));

                //�]�w�R�P��l���B
                G210Map.put("D_LOSS_AMT", G212Map.get("D_LOSS_AMT"));

                //�]�w���ʤH���P���ʮɶ�
                G210Map.put("CHG_DATE", current);
                G210Map.put("CHG_DIV_NO", div_no);
                G210Map.put("CHG_ID", id);
                G210Map.put("CHG_NAME", nm);

                //��J�R�P���������
                deductG210List.add(G210Map);
            }
        }

        Map rtnMap = new HashMap();
        rtnMap.put("ORG_LIST", orgG210List);
        rtnMap.put("DEDUCT_LIST", deductG210List);
        return rtnMap;
    }

    /**
     * @param ds
     * @param reqMap
     * @param key
     * @param sb
     */
    private void setLikeFieldsIfExsits(DataSet ds, Map reqMap, String key, StringBuilder sb) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            sb.append('%').append(value).append('%');
            ds.setField(key, sb.toString());
            sb.setLength(0);
        }
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
