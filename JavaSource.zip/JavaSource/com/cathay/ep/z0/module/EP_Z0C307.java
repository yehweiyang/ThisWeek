package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPC307;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �M��ú�O�������@�Ҳ�(�qEP_C30020�h���L��)
 * </pre>
 * @author ����[
 * @since 2015/4/1
 */
@SuppressWarnings("unchecked")
public class EP_Z0C307 {

    private static final Logger log = Logger.getLogger(EP_Z0C307.class);

    private static final String SQL_acntUpdateBatch_001 = "com.cathay.ep.z0.module.EP_Z0C307.SQL_acntUpdateBatch_001";

    private static final String SQL_acntUpdateBatch_002 = "com.cathay.ep.z0.module.EP_Z0C307.SQL_acntUpdateBatch_002";

    private static final String SQL_queryAcntPayListMap_001 = "com.cathay.ep.z0.module.EP_Z0C307.SQL_queryAcntPayListMap_001";

    private static final String SQL_updateAcntInfo_001 = "com.cathay.ep.z0.module.EP_Z0C307.SQL_updateAcntInfo_001";

    private static final String SQL_clearAcntSetNo_001 = "com.cathay.ep.z0.module.EP_Z0C307.SQL_clearAcntSetNo_001";

    private static final String SQL_cancelConfirm_001 = "com.cathay.ep.z0.module.EP_Z0C307.SQL_cancelConfirm_001";

    private static final String SQL_confirm_001 = "com.cathay.ep.z0.module.EP_Z0C307.SQL_confirm_001";

    private static final String SQL_queryC307_001 = "com.cathay.ep.z0.module.EP_Z0C307.SQL_queryC307_001";

    private static final String SQL_insertDTEPC307_001 = "com.cathay.ep.z0.module.EP_Z0C307.SQL_insertDTEPC307_001";

    /**
     * �d�߱M��ú�O����
     * @param PAY_NO_LIST
     * @return
     * @throws Exception
     */
    public Map<String, List<DTEPC307>> queryAcntPayListMap(List<Map> PAY_NO_LIST, String SUB_CPY_ID) throws Exception {
        if (PAY_NO_LIST == null || PAY_NO_LIST.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C307_MSG_003"));//�ǤJú�O�������i���� 
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //�qEP_C30040 �h���d�ߤ�k�L��
        //�]�w�M��
        List<String> ACNT_SET_LIST = new ArrayList<String>();
        for (Map payMap : PAY_NO_LIST) {
            BigDecimal ACNT_AMT = STRING.objToBigDecimal(payMap.get("ACNT_AMT"), BigDecimal.ZERO);
            if (ACNT_AMT.compareTo(BigDecimal.ZERO) > 0) {
                String ACNT_SET_NO = MapUtils.getString(payMap, "ACNT_SET_NO");
                if (!ACNT_SET_LIST.contains(ACNT_SET_NO)) {
                    ACNT_SET_LIST.add(ACNT_SET_NO);
                }
            }
        }

        if (ACNT_SET_LIST != null && !ACNT_SET_LIST.isEmpty()) {
            Map<String, List<DTEPC307>> tmpMap = new HashMap();
            List<DTEPC307> ACNT_LIST;
            DataSet ds = Transaction.getDataSet();
            ds.setFieldValues("ACNT_SET_NOs", ACNT_SET_LIST);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.searchAndRetrieve(ds, SQL_queryAcntPayListMap_001);
            while (ds.next()) {
                String ACNT_SET_NO = ObjectUtils.toString(ds.getField("ACNT_SET_NO"));
                if (!tmpMap.containsKey(ACNT_SET_NO)) {
                    ACNT_LIST = new ArrayList();
                    ACNT_LIST.add(VOTool.dataSetToVO(DTEPC307.class, ds));
                    tmpMap.put(ACNT_SET_NO, ACNT_LIST);
                } else {
                    ACNT_LIST = tmpMap.get(ACNT_SET_NO);
                    ACNT_LIST.add(VOTool.dataSetToVO(DTEPC307.class, ds));
                }
            }
            return tmpMap;
        }
        return null;
    }

    /**
     * ��s�M����b���ӱb�ȸ�T(���)
     * @param PAY_LIST
     * @param MAP_TRNSERNO
     * @param TRN_KIND
     * @param ACNT_DATE
     * @param SLIP_LOT_NO
     * @param SLIP_SET_NO
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void acntUpdateBatch(List<Map> PAY_LIST, Map<String, Map> MAP_TRNSERNO, String TRN_KIND, Date ACNT_DATE, String SLIP_LOT_NO,
            Integer SLIP_SET_NO, UserObject user, BatchUpdateDataSet budsC307) throws ModuleException, DBException {
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_017"));//����������o����
        } else if (!"01".equals(TRN_KIND) && !"06".equals(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_018"));//����������~
        }
        if (PAY_LIST == null || PAY_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_005"));//ú�O�s�����o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_010"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        //���o�����q�O
        //Call�ɮ��v���]�w���@�Ҳ�.���o�����q�O��k
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
        //�D��ؤ��B�z
        if (!"00".equals(SUB_CPY_ID)) {
            return;
        }
        //BatchUpdateDataSet budsC307 = Transaction.getBatchUpdateDataSet();
        boolean isConfirm;
        if ("06".equals(TRN_KIND)) {
            //06:�T�{
            budsC307.preparedBatch(SQL_acntUpdateBatch_001);
            isConfirm = true;
        } else {
            budsC307.preparedBatch(SQL_acntUpdateBatch_002);
            isConfirm = false;
        }

        String ACNT_DIV_NO = user.getOpUnit();
        try {
            for (Map payMap : PAY_LIST) {

                //�D�M��ú�O�APASS�B�z�U�@����� 
                String ACNT_SET_NO = MapUtils.getString(payMap, "ACNT_SET_NO", null);
                if (ACNT_SET_NO == null || StringUtils.isBlank(ACNT_SET_NO)) {
                    continue;
                }
                String PAY_NO = MapUtils.getString(payMap, "PAY_NO");
                Map trnSerRcv = MAP_TRNSERNO.get(PAY_NO);
                String TRN_SER_NO = MapUtils.getString(trnSerRcv, "TRN_SER_NO");

                if (isConfirm) {
                    //��WDTEPC307�Ȧ�M������ɱb�ȸ�T
                    budsC307.setField("TRN_SER_NO", TRN_SER_NO);
                    budsC307.setField("ACNT_DATE", ACNT_DATE);
                    budsC307.setField("ACNT_DIV_NO", ACNT_DIV_NO);
                    budsC307.setField("SLIP_LOT_NO", SLIP_LOT_NO);
                    budsC307.setField("SLIP_SET_NO", SLIP_SET_NO);
                    budsC307.setField("ACNT_SET_NO", ACNT_SET_NO);
                } else {
                    //�M��DTEPC307�Ȧ�M������ɱb�ȸ�T
                    budsC307.setField("ACNT_SET_NO", ACNT_SET_NO);
                }
                budsC307.setField("SUB_CPY_ID", SUB_CPY_ID);
                budsC307.addBatch();
            }

            budsC307.executeBatch();
            Object theErrorBudsC301Object[][] = budsC307.getBatchUpdateErrorArray();
            if (theErrorBudsC301Object.length > 0) {
                for (int k = 0; k < theErrorBudsC301Object.length; k++) {
                    Map errorDataMap = (Map) theErrorBudsC301Object[k][1];
                    log.error("��s�Ȧ�M������ɱb�ȸ�T,��" + (Exception) theErrorBudsC301Object[k][0] + "����Ʀ��~,setField = " + errorDataMap.toString(),
                        (Exception) theErrorBudsC301Object[k][2]);
                }
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C307_MSG_001"));// ��s�Ȧ�M������ɱb�ȸ�T���~
            }
        } catch (Exception e) {
            log.error(e, e);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C307_MSG_001"));// ��s�Ȧ�M������ɱb�ȸ�T���~
        }
    }

    /**
     * ��s�M����Ӹ�T
     * @param ACNT_INFO_LIST �Ȧ�M����Ӹ�T�M��
     * @param user �ϥΪ̸�T
     * @return �M��ո�
     * @throws ModuleException
     */
    /*(����EP_Z0C307���BUDS���B�z)*/
    public String updateAcntInfo(List<Map> ACNT_INFO_LIST, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (ACNT_INFO_LIST == null || ACNT_INFO_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_008"));//�״ڳ���Ӹ�T�M�椣�o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_009"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        //���o�����q�O
        String SUB_SPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
        //���o�M��ո�
        String ACNT_SET_NO = this.getAcntSetNo(SUB_SPY_ID);

        //�v���B�z�ǤJ.ACNT_INFO_LIST
        //��sDBEP.DTEPC307�Ȧ�M������ɸ��
        DataSet ds = Transaction.getDataSet();
        for (Map map : ACNT_INFO_LIST) {
            ds.clear();
            ds.setField("ACNT_SET_NO", ACNT_SET_NO);
            ds.setField("BANK_SER_NO", MapUtils.getString(map, "BANK_SER_NO"));
            ds.setField("SUB_CPY_ID", SUB_SPY_ID);
            try {
                DBUtil.executeUpdate(ds, SQL_updateAcntInfo_001);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_013"));//��s�Ȧ�M������ɦ��~
            }
        }

        return ACNT_SET_NO;
    }

    /**
     * ��s�M����Ӹ�T(���)
     * @param ACNT_INFO_LIST
     * @param user
     * @return
     * @throws ModuleException
     * @throws DBException
     */
    public String updateAcntInfo(List<Map> ACNT_INFO_LIST, UserObject user, BatchUpdateDataSet budsC307) throws ModuleException,
            DBException {
        if (ACNT_INFO_LIST == null || ACNT_INFO_LIST.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C307_MSG_004"));//�ǤJ�Ȧ�M����Ӹ�T�M�椣�i���� 
        }
        //���o�����q�O
        //Call�ɮ��v�����@�Ҳ�.���o�����q�O��k
        String SUB_SPY_ID = new EP_Z00030().getSUB_CPY_ID(user);

        //���o�M��ո�
        String ACNT_SET_NO = getAcntSetNo(SUB_SPY_ID);

        //�]XAMode:buds�ѥD�{���ǤJ
        //BatchUpdateDataSet budsC307 = Transaction.getBatchUpdateDataSet();
        budsC307.preparedBatch(SQL_updateAcntInfo_001);
        try {
            for (Map acntMap : ACNT_INFO_LIST) {
                budsC307.setField("ACNT_SET_NO", ACNT_SET_NO);
                budsC307.setField("BANK_SER_NO", MapUtils.getString(acntMap, "BANK_SER_NO"));
                budsC307.setField("SUB_CPY_ID", SUB_SPY_ID);
                budsC307.addBatch();
            }

            budsC307.executeBatch();
            Object theErrorBudsC301Object[][] = budsC307.getBatchUpdateErrorArray();
            if (theErrorBudsC301Object.length > 0) {
                for (int k = 0; k < theErrorBudsC301Object.length; k++) {
                    Map errorDataMap = (Map) theErrorBudsC301Object[k][1];
                    log.error("��s�Ȧ�M������ɦ��~,��" + (Exception) theErrorBudsC301Object[k][0] + "����Ʀ��~,setField = " + errorDataMap.toString(),
                        (Exception) theErrorBudsC301Object[k][2]);
                }
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C307_MSG_002"));// ��s�Ȧ�M������ɦ��~
            }
        } catch (Exception e) {
            log.error(e, e);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C307_MSG_002"));// ��s�Ȧ�M������ɦ��~
        }

        return ACNT_SET_NO;
    }

    /**
     * ��s�M����Ӹ�T
     * @param ACNT_INFO_LIST �Ȧ�M����Ӹ�T�M��
     * @param user �ϥΪ̸�T
     * @return �M��ո�
     * @throws ModuleException
     */
    /*(����EP_Z0C307���BUDS���B�z)*/
    public String updateAcntInfo(Map ACNT_INFO_MAP, UserObject user, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (ACNT_INFO_MAP == null || ACNT_INFO_MAP.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_008"));//�״ڳ���Ӹ�T�M�椣�o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_009"));//�ϥΪ̸�T���o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //���o�M��ո�
        String ACNT_SET_NO = this.getAcntSetNo(SUB_CPY_ID);

        //�v���B�z�ǤJ.ACNT_INFO_LIST
        //��sDBEP.DTEPC307�Ȧ�M������ɸ��
        DataSet ds = Transaction.getDataSet();
        ds.setField("ACNT_SET_NO", ACNT_SET_NO);
        ds.setField("BANK_SER_NO", MapUtils.getString(ACNT_INFO_MAP, "BANK_SER_NO"));
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_updateAcntInfo_001);
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_013"));//��s�Ȧ�M������ɦ��~
        }

        return ACNT_SET_NO;
    }

    /**
     * �M�űM��ո�
     * @param ACNT_SET_NO
     * @throws ModuleException
     */
    public void clearAcntSetNo(String ACNT_SET_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(ACNT_SET_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C307_MSG_005"));//�ǤJ�M��ո����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("ACNT_SET_NO", ACNT_SET_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_clearAcntSetNo_001);
        } catch (Exception e) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C307_MSG_006", new Object[] { ACNT_SET_NO }));//�M�ŻȦ�M������ɪ��M��ո����~,�M��ո�={0}
        }
    }

    /**
     * ���o�M��ո�
     * @param SUB_CPY_ID �����q�O
     * @return �M��ո�
     * @throws ModuleException
     */
    public String getAcntSetNo(String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }

        //���o�y���Ǹ�
        int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "027", "1", "1");

        return new StringBuilder().append(SUB_CPY_ID).append(STRING.fillZero(Integer.toString(SER_NO), 8)).toString();

    }

    /**
     * �T�{(from EP_C30130.doConfirm())
     * @param reqMap
     * @param user
     * @param BANK_SER_NOs
     * @throws ModuleException 
     */
    public void confirm(Map reqMap, UserObject user, List<String> BANK_SER_NOs) throws ModuleException {

        String ACC_CHECK = MapUtils.getString(reqMap, "ACC_CHECK");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String ID = MapUtils.getString(reqMap, "ID");
        DataSet ds = Transaction.getDataSet();

        if ("Y".equals(ACC_CHECK)) {
            CUS_NO = null;
            BLD_CD = null;
            CRT_NO = null;
            ID = null;
            ds.setField("ACC_MEMO", reqMap.get("ACC_MEMO"));
            ds.setField("ACNT_DATE", reqMap.get("ACNT_DATE"));
            ds.setField("ACNT_DIV_NO", reqMap.get("ACNT_DIV_NO"));
            ds.setField("SLIP_SET_NO", reqMap.get("SLIP_SET_NO"));
        } else {
            if (StringUtils.isBlank(CUS_NO)) {
                CUS_NO = null;
            }

        }
        ds.setField("ID", ID);
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CFM_ID", user.getEmpID());
        ds.setField("CFM_NAME", user.getEmpName());
        ds.setField("CFM_DIV_NO", user.getOpUnit());
        ds.setField("CFM_DATE", DATE.getDBDate());
        ds.setFieldValues("BANK_SER_NO", BANK_SER_NOs);
        DBUtil.executeUpdate(ds, SQL_confirm_001);
    }

    /**
     * �̤��P����d�߱M����(from:EP_C30130)
     * @param ds
     * @return
     * @throws ModuleException
     */
    public List<Map> queryC307(DataSet ds) throws ModuleException {
        return VOTool.findToMaps(ds, SQL_queryC307_001);
    }

    /**
     * �����T�{(from EP_C30130.doCancelConfirm())
     * @param BANK_SER_NOs
     * @throws ModuleException
     */
    public void cancelConfirm(List<String> BANK_SER_NOs, String SUB_CPY_ID) throws ModuleException {

        DataSet ds = Transaction.getDataSet();
        ds.setFieldValues("BANK_SER_NO", BANK_SER_NOs);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_cancelConfirm_001);
    }

    /**
     * �s�W�Ȧ�M������ɸ��(�Ҳդ� from:EP_C30130)
     * @param EPC307List
     * @throws ModuleException 
     */
    public void insertDTEPC307(List<Map> EPC307List, String SUB_CPY_ID) throws ModuleException {

        EP_Z0B201 theEP_Z0B201 = new EP_Z0B201();
        String VIR_ACC_ID = FieldOptionList.getName("EP", "VIR_ACC", "VIR_ACC_ID");//�e�|�X
        String TODAY = DATE.getDBDate();

        //�s�W�Ȧ�M������ɸ��
        DataSet ds = Transaction.getDataSet();
        for (Map EPC307Map : EPC307List) {
            ds.clear();
            ds.setField("BANK_SER_NO", MapUtils.getString(EPC307Map, "BANK_SER_NO")); //�Ȧ�b�Ǹ�
            ds.setField("BANK_NO", MapUtils.getString(EPC307Map, "BANK_NO")); //��w�N��
            ds.setField("ACNT_NO", MapUtils.getString(EPC307Map, "ACNT_NO")); //�Ȧ�b��
            ds.setField("RMT_DATE", MapUtils.getString(EPC307Map, "RMT_DATE")); //�״ڤ��

            String TX_SEQNO = MapUtils.getString(EPC307Map, "TX_SEQNO", "");
            ds.setField("TX_SEQNO", TX_SEQNO); //����Ǹ�
            ds.setField("TX_IDNO", MapUtils.getString(EPC307Map, "TX_IDNO", "")); //����N��
            ds.setField("SPACE", MapUtils.getString(EPC307Map, "SPACE", "")); //�ť�
            ds.setField("CHNO", MapUtils.getString(EPC307Map, "CHK_NO", "")); //�䲼���X

            ds.setField("SIGN", MapUtils.getString(EPC307Map, "PN_CODE")); //������B���t��
            ds.setField("AMOUNT", MapUtils.getString(EPC307Map, "TRN_AMT")); //������B
            ds.setField("BSIGN", MapUtils.getString(EPC307Map, "BSIGN", "")); //�b��l�B���t��
            ds.setField("BAMOUNT", MapUtils.getString(EPC307Map, "BAL_AMT")); //�b��l�B

            //�C��פJ���|
            String DC;
            String MEMO1;
            String MEMO2;
            String ACCNAME;
            if (StringUtils.isBlank(TX_SEQNO)) {//�C���ɤW��
                //2016.04.28�t�X�����b��ɤJ,�ק�C��W�Ǯ榡
                String RMK = MapUtils.getString(EPC307Map, "RMK", "");
                try {
                    MEMO1 = STRING.subStringUtil(RMK, 0, 20, EncodingHelper.Charset_BIG5);//�Ƶ��@
                } catch (Exception e) {
                    log.error("RMK�I�_�o�Ϳ��~(0~20):" + RMK);
                    MEMO1 = "";
                }
                try {
                    MEMO2 = STRING.subStringUtil(RMK, 21, 40, EncodingHelper.Charset_BIG5);//�Ƶ��G
                } catch (Exception e) {
                    log.error("RMK�I�_�o�Ϳ��~(21~40):" + RMK);
                    MEMO2 = "";
                }
                ACCNAME = MapUtils.getString(EPC307Map, "MEMO", ""); //��W
                DC = "DR".equals(MapUtils.getString(EPC307Map, "PAY_RCV_CODE")) ? "2" : "1";
            } else {
                //�Y�ɤJ�����|
                MEMO1 = MapUtils.getString(EPC307Map, "MEMO1", ""); //�Ƶ��@
                MEMO2 = MapUtils.getString(EPC307Map, "MEMO2", ""); //�Ƶ��G
                ACCNAME = MapUtils.getString(EPC307Map, "ACCNAME", ""); //��W
                DC = MapUtils.getString(EPC307Map, "DC");
            }
            ds.setField("MEMO1", MEMO1); //�Ƶ��@
            ds.setField("MEMO2", MEMO2); //�Ƶ��G
            ds.setField("ACCNAME", ACCNAME); //��W

            ds.setField("DC", DC); //�ɶU�O
            ds.setField("TX_MACH", MapUtils.getString(EPC307Map, "TX_MACH", "")); //�������
            ds.setField("TX_SPEC", MapUtils.getString(EPC307Map, "TX_SPEC", "")); //�������
            ds.setField("BANKID", MapUtils.getString(EPC307Map, "BANKID", "")); //����
            ds.setField("TX_TIME", MapUtils.getString(EPC307Map, "TX_TIME", "")); //����ɶ�
            ds.setField("SUB_CPY_ID", SUB_CPY_ID); //�����q�O
            ds.setField("SOURCE", MapUtils.getString(EPC307Map, "SOURCE", "1")); //�ӷ�, 1�X�ǽT�{(�j��) 2�Y�ɤJ��(�멳����)
            String ERR_CODE = MapUtils.getString(EPC307Map, "ERR_CODE", "N");
            ds.setField("ERR_CODE", ERR_CODE); //�~�b����

            //�����b��,�۰ʽT�{����
            //�D�~�b�B�������b��
            boolean setNull = true;
            if (!"Y".equals(ERR_CODE) && MEMO1.startsWith(VIR_ACC_ID)) {
                Map B201Map;
                try {
                    B201Map = theEP_Z0B201.queryByVIR_ACC_ID(MEMO1, SUB_CPY_ID);
                    if (B201Map != null && !B201Map.isEmpty()) {
                        String ID = MapUtils.getString(B201Map, "ID");
                        log.debug("@@ �������b��,id=" + ID);
                        if (StringUtils.isNotBlank(ID)) {
                            //���������Ȥ���;�L�����Ȥ���,�P�M��,�ѤH�u�T�{
                            setNull = false;
                            ds.setField("ID", ID);
                            ds.setField("CFM_NAME", "�����b��۰ʽT�{");
                            ds.setField("CFM_DATE", TODAY);
                        }
                    }
                } catch (Exception e) {
                    log.error("�����Ȥ��Ʀ��~", e);
                }
            }
            if (setNull) {
                ds.setField("ID", null);
                ds.setField("CFM_NAME", null);
                ds.setField("CFM_DATE", null);
            }

            DBUtil.executeUpdate(ds, SQL_insertDTEPC307_001);
            log.debug("�g�JDTEPC307���\>>>" + EPC307List.size() + "��");
        }

    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }
}