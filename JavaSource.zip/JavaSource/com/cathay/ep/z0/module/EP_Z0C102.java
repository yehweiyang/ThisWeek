package com.cathay.ep.z0.module;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.util.DATE;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014-12-04  Created �Ťl��
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �կ��թ���@�Ҳ�
 * �Ҳ�ID    EP_Z0C102
 * ���n����    SQL�կ��թ�Ҳ�
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EP_Z0C102 {
    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0C102.SQL_insert_001";

    private static final String SQL_confirm_001 = "com.cathay.ep.z0.module.EP_Z0C102.SQL_confirm_001";

    private static final String SQL_unconfirm_001 = "com.cathay.ep.z0.module.EP_Z0C102.SQL_unconfirm_001";

    private static final String SQL_approve_001 = "com.cathay.ep.z0.module.EP_Z0C102.SQL_approve_001";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0C102.SQL_delete_001";

    private static final String SQL_update_001 = "com.cathay.ep.z0.module.EP_Z0C102.SQL_update_001";

    private static final String SQL_update_002 = "com.cathay.ep.z0.module.EP_Z0C102.SQL_update_002";

    private static final String SQL_cancel_001 = "com.cathay.ep.z0.module.EP_Z0C102.SQL_cancel_001";

    private static final String SQL_unCancel_001 = "com.cathay.ep.z0.module.EP_Z0C102.SQL_unCancel_001";

    /**
     * �s�W�կ��թ����
     * @param DTEPC102_VO
     * @throws ModuleException
     */
    public void insert(Map DTEPC102Map) throws ModuleException {
        if (DTEPC102Map == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C102_MSG_001"));//���կ�(��)�����ɤ��o����
        }
        //�]�w�f��i�סG
        DTEPC102Map.put("OP_STATUS", this.getStartOpStatus("EPC1_0001"));
        //DTEPC102Map.put("FLOW_NO", "");
        DataSet ds = Transaction.getDataSet();
        ds.setField("CRT_NO", DTEPC102Map.get("CRT_NO"));
        ds.setField("CUS_NO", DTEPC102Map.get("CUS_NO"));
        ds.setField("ADJ_DATE", DTEPC102Map.get("ADJ_DATE"));
        ds.setField("SUB_CPY_ID", DTEPC102Map.get("SUB_CPY_ID"));
        ds.setField("ADJ_YM", DTEPC102Map.get("ADJ_YM"));
        ds.setField("BLD_CD", DTEPC102Map.get("BLD_CD"));
        ds.setField("ART_AMT", DTEPC102Map.get("ART_AMT"));
        ds.setField("APM_AMT", DTEPC102Map.get("APM_AMT"));
        ds.setField("ADJ_UNIT_NUM", DTEPC102Map.get("ADJ_UNIT_NUM"));
        ds.setField("ADJ_UNIT", DTEPC102Map.get("ADJ_UNIT"));
        ds.setField("ADJ_E_DATE", DTEPC102Map.get("ADJ_E_DATE"));
        ds.setField("ADD_AMT", DTEPC102Map.get("ADD_AMT"));
        ds.setField("INPUT_ID", DTEPC102Map.get("INPUT_ID"));
        ds.setField("INPUT_NAME", DTEPC102Map.get("INPUT_NAME"));
        ds.setField("INPUT_DATE", DTEPC102Map.get("INPUT_DATE"));
        ds.setField("RNT_S_DATE", DTEPC102Map.get("RNT_S_DATE"));
        ds.setField("RNT_E_DATE", DTEPC102Map.get("RNT_E_DATE"));
        ds.setField("ADJ_TYPE", DTEPC102Map.get("ADJ_TYPE"));
        ds.setField("ADJ_PM", DTEPC102Map.get("ADJ_PM"));
        ds.setField("RNT_AMT", DTEPC102Map.get("RNT_AMT"));
        ds.setField("PMS_AMT", DTEPC102Map.get("PMS_AMT"));
        ds.setField("ID", DTEPC102Map.get("ID"));
        ds.setField("CUS_NAME", DTEPC102Map.get("CUS_NAME"));
        ds.setField("DEL_CD", DTEPC102Map.get("DEL_CD"));
        ds.setField("TRN_KIND", DTEPC102Map.get("TRN_KIND"));
        ds.setField("FLOW_NO", "");
        ds.setField("OP_STATUS", DTEPC102Map.get("OP_STATUS"));
        ds.setField("LST_PROC_DATE", DTEPC102Map.get("LST_PROC_DATE"));
        ds.setField("LST_PROC_ID", DTEPC102Map.get("LST_PROC_ID"));
        ds.setField("LST_PROC_DIV", DTEPC102Map.get("LST_PROC_DIV"));
        ds.setField("LST_PROC_NAME", DTEPC102Map.get("LST_PROC_NAME"));
        ds.setField("FROM_TYPE", DTEPC102Map.get("FROM_TYPE"));

        DBUtil.executeUpdate(ds, SQL_insert_001);
    }

    /**
     * �կ��թ���ӽT�{
     * @param resultList
     * @param EMP_ID
     * @param EMP_NAME
     * @param DIV_NO
     * @throws ModuleException
     */
    public void confirm(List<Map> resultList, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException {
        ErrorInputException eie = null;
        if (resultList == null || resultList.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_001")); //�կ��թ���Ӥ��o����!
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_003")); //�T�{�H��ID���o����!
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_004")); //�T�{�H���m�W���o����!
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_005")); //�T�{�H�����N�����o����!
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        Timestamp crnTime = DATE.currentTime();
        for (Map resultMap : resultList) {
            ds.clear();
            //��s�ץ�i��
            ds.setField("LST_PROC_DATE", crnTime);//�@�~�B�z�ɶ�
            ds.setField("LST_PROC_ID", EMP_ID);//�@�~�B�z�H��id
            ds.setField("LST_PROC_DIV", DIV_NO);//�@�~�B�z���
            ds.setField("LST_PROC_NAME", EMP_NAME);//�@�~�B�z�H���m�W
            ds.setField("ADJ_DATE", resultMap.get("ADJ_DATE"));//�կ����
            ds.setField("CRT_NO", resultMap.get("CRT_NO"));//�����N��
            ds.setField("CUS_NO", resultMap.get("CUS_NO"));//�Ȥ�Ǹ�
            ds.setField("SUB_CPY_ID", resultMap.get("SUB_CPY_ID"));
            DBUtil.executeUpdate(ds, SQL_confirm_001);
        }
    }

    /**
     * �կ��թ���Ө����T�{
     * @param resultList
     * @param EMP_ID
     * @param EMP_NAME
     * @param DIV_NO
     * @throws ModuleException
     */
    public void unconfirm(List<Map> resultList, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException {
        ErrorInputException eie = null;
        if (resultList == null || resultList.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_001")); //�կ��թ���Ӥ��o����!
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_003")); //�T�{�H��ID���o����!
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_004")); //�T�{�H���m�W���o����!
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_005")); //�T�{�H�����N�����o����!
        }
        if (eie != null) {
            throw eie;
        }

        Timestamp crnTime = DATE.currentTime();
        DataSet ds = Transaction.getDataSet();
        for (Map resultMap : resultList) {
            ds.clear();
            //��s�ץ�i��
            ds.setField("LST_PROC_DATE", crnTime);//�@�~�B�z�ɶ�
            ds.setField("LST_PROC_ID", EMP_ID);//�@�~�B�z�H��id
            ds.setField("LST_PROC_DIV", DIV_NO);//�@�~�B�z���
            ds.setField("LST_PROC_NAME", EMP_NAME);//�@�~�B�z�H���m�W
            ds.setField("SUB_CPY_ID", resultMap.get("SUB_CPY_ID"));
            setFieldIfExist(resultMap, ds, "ADJ_DATE");//�կ����
            setFieldIfExist(resultMap, ds, "CRT_NO");//�����N��
            setFieldIfExist(resultMap, ds, "CUS_NO");//�Ȥ�Ǹ�
            DBUtil.executeUpdate(ds, SQL_unconfirm_001);
        }
    }

    /**
     * �Юֽկ��թ���
     * @param tmpMap
     * @throws ModuleException
     */
    public void approve(Map tmpMap) throws ModuleException {
        if (tmpMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C102_MSG_006"));//��s��T���o����
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("LST_PROC_DATE", tmpMap.get("LST_PROC_DATE"));
        ds.setField("LST_PROC_NAME", tmpMap.get("LST_PROC_NAME"));
        ds.setField("LST_PROC_DIV", tmpMap.get("LST_PROC_DIV"));
        ds.setField("LST_PROC_ID", tmpMap.get("LST_PROC_ID"));
        ds.setField("ADD_AMT", tmpMap.get("ADD_AMT"));
        setFieldIfExist(tmpMap, ds, "ADJ_E_DATE");
        ds.setField("CRT_NO", tmpMap.get("CRT_NO"));
        ds.setField("CUS_NO", tmpMap.get("CUS_NO"));
        ds.setField("ADJ_DATE", tmpMap.get("ADJ_DATE"));
        ds.setField("SUB_CPY_ID", tmpMap.get("SUB_CPY_ID"));
        DBUtil.executeUpdate(ds, SQL_approve_001);
    }

    /**
     * �ק�կ��թ���
     * 
     * @param reqMap �կ��ק鷺�e
     * @param EMP_ID ���ʤH��ID
     * @param EMP_NAME ���ʤH���m�W
     * @param DIV_NO ���ʤH�����
     * @throws ModuleException
     */
    public void update(Map reqMap, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C102_MSG_007"));//�ǤJ�򥻸�Ƥ��o����
        }
        ErrorInputException eie = null;
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_008"));//�@�~�H�����o���ŭ�
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_009"));//�@�~�H���m�W���o���ŭ�
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_010"));//�@�~��줣�o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�Y�կ��覡��2:��CPI���Ʃ�3:��RPT���ơA�h���o�ɶ}����
        String ADJ_TYPE = MapUtils.getString(reqMap, "ADJ_TYPE");

        //��s���կ�(��)�ɸ�� 
        DataSet ds = Transaction.getDataSet();
        ds.setField("ADJ_TYPE", ADJ_TYPE);

        ds.setField("ART_AMT", reqMap.get("ART_AMT"));
        ds.setField("APM_AMT", reqMap.get("APM_AMT"));
        ds.setField("currenTime", DATE.currentTime());
        ds.setField("EMP_ID", EMP_ID);
        ds.setField("DIV_NO", DIV_NO);
        ds.setField("EMP_NAME", EMP_NAME);
        ds.setField("ADJ_UNIT_NUM", reqMap.get("ADJ_UNIT_NUM"));
        ds.setField("ADJ_UNIT", reqMap.get("ADJ_UNIT"));
        ds.setField("CRT_NO", reqMap.get("CRT_NO"));
        ds.setField("CUS_NO", reqMap.get("CUS_NO"));
        ds.setField("ADJ_DATE", reqMap.get("ADJ_DATE"));
        ds.setField("SUB_CPY_ID", reqMap.get("SUB_CPY_ID"));
        //�Y�կ��覡��2:��CPI���Ʃ�3:��RPT����
        if ("2".equals(ADJ_TYPE) || "3".equals(ADJ_TYPE)) {
            String NEXT_PAY_DATE = MapUtils.getString(reqMap, "NEXT_PAY_DATE");
            String ADJ_E_DATE = DATE.addDate(NEXT_PAY_DATE, 0, 0, -1);

            ds.setField("ADJ_E_DATE", ADJ_E_DATE);
            ds.setField("ADD_AMT", reqMap.get("ADD_AMT"));
            DBUtil.executeUpdate(ds, SQL_update_002);

        } else if ("1".equals(ADJ_TYPE) || "0".equals(ADJ_TYPE)) {//�կ��覡:�T�w OR ����
            ds.setField("ADJ_PM", reqMap.get("ADJ_PM"));
            DBUtil.executeUpdate(ds, SQL_update_001);
        }

    }

    /**
     *  �簣�կ��թ���
     *  
     * @param reqMap �կ��ק鷺�e
     * @param EMP_ID ���ʤH��ID
     * @param EMP_NAME ���ʤH���m�W
     * @param DIV_NO ���ʤH�����
     * @throws ModuleException
     */
    public void cancel(Map reqMap, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C102_MSG_007"));//�ǤJ�򥻸�Ƥ��o����
        }
        ErrorInputException eie = null;
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_008"));//�@�~�H�����o���ŭ�
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_009"));//�@�~�H���m�W���o���ŭ�
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_010"));//�@�~��줣�o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�簣���կ�(��)�ɸ��

        DataSet ds = Transaction.getDataSet();

        ds.setField("DEL_CD", reqMap.get("DEL_CD"));
        ds.setField("currenTime", DATE.currentTime());
        ds.setField("EMP_ID", EMP_ID);
        ds.setField("DIV_NO", DIV_NO);
        ds.setField("EMP_NAME", EMP_NAME);
        ds.setField("CRT_NO", reqMap.get("CRT_NO"));
        ds.setField("CUS_NO", reqMap.get("CUS_NO"));
        ds.setField("ADJ_DATE", reqMap.get("ADJ_DATE"));
        ds.setField("SUB_CPY_ID", reqMap.get("SUB_CPY_ID"));
        DBUtil.executeUpdate(ds, SQL_cancel_001);

    }

    /**
     * �����簣�կ��թ���
     * @param reqMap
     * @param EMP_ID
     * @param EMP_NAME
     * @param DIV_NO
     * @throws ModuleException
     */
    public void unCancel(Map reqMap, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C102_MSG_007"));//�ǤJ�򥻸�Ƥ��o����
        }
        ErrorInputException eie = null;
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_008"));//�@�~�H�����o���ŭ�
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_009"));//�@�~�H���m�W���o���ŭ�
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C102_MSG_010"));//�@�~��줣�o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�����簣���կ�(��)�ɸ��
        DataSet ds = Transaction.getDataSet();

        ds.setField("currenTime", DATE.currentTime());
        ds.setField("EMP_ID", EMP_ID);
        ds.setField("DIV_NO", DIV_NO);
        ds.setField("EMP_NAME", EMP_NAME);
        ds.setField("CRT_NO", reqMap.get("CRT_NO"));
        ds.setField("CUS_NO", reqMap.get("CUS_NO"));
        ds.setField("ADJ_DATE", reqMap.get("ADJ_DATE"));
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_unCancel_001);
    }

    /**
     * �R���կ��թ���
     * @param resultList
     * @throws ModuleException
     */
    public void delete(List<Map> resultList) throws ModuleException {
        if (resultList == null || resultList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C102_MSG_001")); //�կ��թ���Ӥ��o����!
        }
        DataSet ds = Transaction.getDataSet();
        //�N�կ��թ�����(resultList)�R���q���կ��թ������(DTEPC102)
        for (Map aMap : resultList) {
            ds.clear();
            //�R�����կ�(��)������(DTEPC102)
            ds.setField("ADJ_DATE", aMap.get("ADJ_DATE"));
            ds.setField("CRT_NO", aMap.get("CRT_NO"));
            ds.setField("CUS_NO", aMap.get("CUS_NO"));
            ds.setField("SUB_CPY_ID", aMap.get("SUB_CPY_ID"));

            DBUtil.executeUpdate(ds, SQL_delete_001);
        }
    }

    /**
     * ���o�f��]�w��ư_�l�i��
     * @param FLOW_TYPE
     * @return
     * @throws ModuleException
     */
    public String getStartOpStatus(String FLOW_TYPE) throws ModuleException {
        if (StringUtils.isBlank(FLOW_TYPE)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C102_MSG_002")); //�f��y�{�������o����!
        }
        //�f��]�w
        //Map FLOW_TYPE_Map = FieldOptionList.getName("EP", FLOW_TYPE);

        return "0";
        //return MapUtils.getString(FLOW_TYPE_Map, "0");
    }

    /**
     * private �d�߸�ƫ��A�� ='key' or like 'key'
     * @param reqMap
     * @param ds
     * @param key
     * @param sb
     */
    private void setFieldIfExist(Map reqMap, DataSet ds, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }
}
