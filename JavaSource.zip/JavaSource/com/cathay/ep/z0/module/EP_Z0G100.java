package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPG100;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014/09/17  Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��a�򥻸�ƺ��@�Ҳ�
 * �Ҳ�ID    EP_Z0G100
 * ���n����    ��a�򥻸�ƺ��@�Ҳ�
 * 
 * [20190211] �ק��  Modify�վ㪽����sDTEPG100 ����DTEPG100 /DTEPG100_LOG ���Map �߮׳渹 : 190130000429
 * [20191121] �ק�� Modify �߮׳渹 : 191025000965
 *  1. �վ�TABLE�W�[���
 *  2. �վ��k queryList,queryMap,insertLog, update, insert ,insertLog�W�[�^�ǭ�
 *  3. �s�W updateAreaSize��k
 *  4. �s�W queryBaseConfigList(String, List) �d�߰�a�վ\�å��M��
 *  [20200310] �ק�� Modify �߮׳渹 : 200226001085
 *  1. �վ��kinsertLog�W�[�^�ǭ�
 *  2. �վ��kupdate�W�[�ˮֻP�^�ǭ�
 *  3. �վ��kinsert�W�[�ˮֻP�^�ǭ�
 *  4. �s�WcheckIFRSDTLCD(Map) �ˮ֧���һP�|�p�ӥ�
 * 
 * </pre>
 * 
 * @author ����[
 * @since 2014/12/5
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0G100 {

    private static final String SQL_queryList_002 = "com.cathay.ep.z0.module.EP_Z0G100.SQL_queryList_002";

    private static final String SQL_queryMap_002 = "com.cathay.ep.z0.module.EP_Z0G100.SQL_queryMap_002";

    private static final String SQL_queryMap_003 = "com.cathay.ep.z0.module.EP_Z0G100.SQL_queryMap_003";

    private static final String SQL_insert_g100log = "com.cathay.ep.z0.module.EP_Z0G100.SQL_insert_g100log";

    private static final String SQL_update_001 = "com.cathay.ep.z0.module.EP_Z0G100.SQL_update_001";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0G100.SQL_insert_001";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0G100.SQL_delete_001";

    private static final String SQL_updateAreaSize_001 = "com.cathay.ep.z0.module.EP_Z0G100.SQL_updateAreaSize_001";

    private static final String SQL_updateAreaSize_002 = "com.cathay.ep.z0.module.EP_Z0G100.SQL_updateAreaSize_002";

    private static final String SQL_queryBaseConfigList_001 = "com.cathay.ep.z0.module.EP_Z0G100.SQL_queryBaseConfigList_001";

    /**
     * Ū����a�򥻸���ɲM��
     * 
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    /* [20190211] �߮׳渹 : 190130000429 */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G100_MSG_001"));// �ǤJ��T���o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G100_MSG_002"));// �ǤJ�����q�O���o���ŭ�
            }
        }

        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        String BASE_BLD_NAME = MapUtils.getString(reqMap, "BASE_BLD_NAME");

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotEmpty(BASE_CD)) {
            ds.setField("BASE_CD", sb.append('%').append(BASE_CD).append('%').toString());
        }
        if (StringUtils.isNotEmpty(BASE_BLD_NAME)) {
            sb.setLength(0);
            ds.setField("BASE_BLD_NAME", sb.append('%').append(BASE_BLD_NAME).append('%').toString());
        }

        // �H�ǤJ�����q�O�d�߰�a�򥻸����(DTEPG100)�G
        // �v���B�z Map [20191121]�s�W�B�z(�ק�}�l)
        DBUtil.searchAndRetrieve(ds, SQL_queryList_002);
        List<Map> rtnList = new ArrayList();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            // �]�w�겣���O����
            rtnMap.put("BASE_TYPE_NM", FieldOptionList.getName("EP", "BASE_TYPE", MapUtils.getString(rtnMap, "BASE_TYPE")));
            // �]�w���v����
            rtnMap.put("OWN_TYPE_NM", FieldOptionList.getName("EP", "OWN_TYPE", MapUtils.getString(rtnMap, "OWN_TYPE")));
            // �]�w�b�C����
            rtnMap.put("ACC_TYPE_NM", FieldOptionList.getName("EP", "ACC_TYPE", MapUtils.getString(rtnMap, "ACC_TYPE")));
            rtnList.add(rtnMap);
        }
        return rtnList;
        // [20191121](�קﵲ��)
    }

    /**
     * Ū����a�򥻸����
     * 
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    /* [20190211] �߮׳渹 : 190130000429 */
    public Map queryMap(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G100_MSG_001"));// �ǤJ��T���o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_002");// �ǤJ�����q�O���o���ŭ�
        }
        String QRY_TYPE = MapUtils.getString(reqMap, "QRY_TYPE");
        String SLF_CD = MapUtils.getString(reqMap, "SLF_CD");
        String INV_CD = MapUtils.getString(reqMap, "INV_CD");
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");

        if ("2".equals(QRY_TYPE)) {
            if (StringUtils.isBlank(SLF_CD)) {
                eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_016");// �ǤJ��a�ۥΥN�����o���ŭ�
            }
            if (StringUtils.isBlank(INV_CD)) {
                eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_017");// �ǤJ��a���N�����o���ŭ�
            }
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_003");// �ǤJ��a�N�����o���ŭ�
            }
        } else {
            if (StringUtils.isBlank(SLF_CD) && StringUtils.isBlank(INV_CD) && StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_003");// �ǤJ��a�N�����o���ŭ�
            }
        }

        if (eie != null) {
            throw eie;
        }

        String BASE_BLD_NAME = MapUtils.getString(reqMap, "BASE_BLD_NAME");
        Map rtnMap = null;
        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if ("2".equals(QRY_TYPE)) {
            //�ˮ֬O�_�����@�N�� �w�g�s�b��a�D��
            ds.setField("BASE_CD", BASE_CD);
            ds.setField("SLF_CD", SLF_CD);
            ds.setField("INV_CD", INV_CD);
            rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_002);

        } else {
            setFieldIfExist(ds, "BASE_BLD_NAME", BASE_BLD_NAME);
            setFieldIfExist(ds, "BASE_CD", BASE_CD);
            setFieldIfExist(ds, "SLF_CD", SLF_CD);
            setFieldIfExist(ds, "INV_CD", INV_CD);
            //�H�ǤJ�����q�O�ΰ�a�N���d�߰�a�򥻸����(DTEPG100)�G
            rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_003);
        }
        //���o�u�a�ϡv����:
        rtnMap.put("ZONE_NM", FieldOptionList.getName("EP", "ZONE", MapUtils.getString(rtnMap, "ZONE")));
        //���o�u�ϰ�O�v����:
        rtnMap.put("ZONE_CD_NM", FieldOptionList.getName("EP", "ZONE_CD", MapUtils.getString(rtnMap, "ZONE_CD")));

        // [20191121]�s�W�����o����(�ק�}�l)
        // ���o��a��������
        rtnMap.put("BASE_TYPE_NM", FieldOptionList.getName("EP", "BASE_TYPE", MapUtils.getString(rtnMap, "BASE_TYPE")));
        // �]�w���v����
        rtnMap.put("OWN_TYPE_NM", FieldOptionList.getName("EP", "OWN_TYPE", MapUtils.getString(rtnMap, "OWN_TYPE")));
        // �]�w�b�C����
        rtnMap.put("ACC_TYPE_NM", FieldOptionList.getName("EP", "ACC_TYPE", MapUtils.getString(rtnMap, "ACC_TYPE")));
        // [20191121](�קﵲ��)
        return rtnMap;
    }

    /**
     * �s�W��a�򥻸��LOG��
     * 
     * @param MapG100
     * @param UPD_DATE
     * @param UPD_ID
     * @param UPD_NAME
     * @param UPD_TYPE
     * @return
     * @throws ModuleException
     */
    /* [20190211] �߮׳渹 : 190130000429 */
    // [20191121] �s�W�^�ǰѼ�
    /* [20200310] �߮׳渹 : 200226001085 */
    private Map insertLog(Map MapG100, Timestamp UPD_DATE, String UPD_ID, String UPD_NAME, String UPD_TYPE) throws ModuleException {
        // �ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        if (MapG100 == null || MapG100.isEmpty()) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_004");// �ǤJ��a�򥻸���ɤ��o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(MapG100, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_002");// �ǤJ�����q�O���o���ŭ�
            }
            BASE_CD = MapUtils.getString(MapG100, "BASE_CD");
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_003");// �ǤJ��a�N�����o���ŭ�
            }
        }
        if (UPD_DATE == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_005");// �ǤJ�J�ɤ���ɶ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        // �g�@��LOG��
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BASE_CD", BASE_CD);
        Map mapG100Log = this.queryMap(reqMap);

        DataSet ds = Transaction.getDataSet();

        ds.setField("UPD_DATE", UPD_DATE);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("SLF_CD", mapG100Log.get("SLF_CD"));
        ds.setField("INV_CD", mapG100Log.get("INV_CD"));
        ds.setField("INV_TP", mapG100Log.get("INV_TP"));
        ds.setField("ZONE", mapG100Log.get("ZONE"));
        ds.setField("ZONE_CD", mapG100Log.get("ZONE_CD"));
        ds.setField("SLF_HD1", mapG100Log.get("SLF_HD1"));
        ds.setField("SLF_HD2", mapG100Log.get("SLF_HD2"));
        ds.setField("INV_HD1", mapG100Log.get("INV_HD1"));
        ds.setField("INV_HD2", mapG100Log.get("INV_HD2"));
        ds.setField("SLF_PR_HD1", mapG100Log.get("SLF_PR_HD1"));
        ds.setField("SLF_PR_HD2", mapG100Log.get("SLF_PR_HD2"));
        ds.setField("INV_PR_HD1", mapG100Log.get("INV_PR_HD1"));
        ds.setField("INV_PR_HD2", mapG100Log.get("INV_PR_HD2"));
        this.setDateIfExist(ds, "LND_DT", mapG100Log);
        ds.setField("SLF_LND_STS", mapG100Log.get("SLF_LND_STS"));
        ds.setField("SLF_BLD_STS", mapG100Log.get("SLF_BLD_STS"));
        ds.setField("INV_LND_STS", mapG100Log.get("INV_LND_STS"));
        ds.setField("INV_BLD_STS", mapG100Log.get("INV_BLD_STS"));
        ds.setField("LND_LOCATE", mapG100Log.get("LND_LOCATE"));
        ds.setField("LND_SEG", mapG100Log.get("LND_SEG"));
        ds.setField("LND_NO", mapG100Log.get("LND_NO"));
        this.setDateIfExist(ds, "LND_EVL_AMT", mapG100Log);
        this.setDateIfExist(ds, "LND_MKT_VAL", mapG100Log);
        ds.setField("INV_USE_MEMO", mapG100Log.get("INV_USE_MEMO"));
        ds.setField("SLF_USE_MEMO", mapG100Log.get("SLF_USE_MEMO"));
        ds.setField("LND_MEMO", mapG100Log.get("LND_MEMO"));
        this.setDateIfExist(ds, "BLD_DT", mapG100Log);
        this.setDateIfExist(ds, "CEBLPRI", mapG100Log);
        ds.setField("BLD_NO", mapG100Log.get("BLD_NO"));
        ds.setField("BLD_ADDR", mapG100Log.get("BLD_ADDR"));
        ds.setField("BASE_BLD_NAME", mapG100Log.get("BASE_BLD_NAME"));
        this.setDateIfExist(ds, "BLD_LCN_DT", mapG100Log);
        this.setDateIfExist(ds, "BLD_EVL_AMT", mapG100Log);
        ds.setField("BLD_MEMO", mapG100Log.get("BLD_MEMO"));
        // [20191121]TABLE DTEPG100_LOG�W�[���
        ds.setField("BASE_TYPE", mapG100Log.get("BASE_TYPE"));// �겣���OBASE_TYPE
        ds.setField("LND_AREA", mapG100Log.get("LND_AREA"));// �g�a�v�����n
        ds.setField("BLD_AREA", mapG100Log.get("BLD_AREA"));// �ت��v�����n
        ds.setField("LND_HLD_STS", mapG100Log.get("LND_HLD_STS"));// �g�a�������A
        ds.setField("BLD_HLD_STS", mapG100Log.get("BLD_HLD_STS"));// �ت��������A
        ds.setField("OWN_TYPE", mapG100Log.get("OWN_TYPE"));// ���v
        ds.setField("ACC_TYPE", mapG100Log.get("ACC_TYPE"));// �b�C
        this.setDateIfExist(ds, "CHG_DATE", mapG100Log);
        ds.setField("CHG_DIV_NO", mapG100Log.get("CHG_DIV_NO"));
        ds.setField("CHG_ID", mapG100Log.get("CHG_ID"));
        ds.setField("CHG_NAME", mapG100Log.get("CHG_NAME"));
        ds.setField("UPD_ID", UPD_ID);
        ds.setField("UPD_NAME", UPD_NAME);
        ds.setField("UPD_TYPE", UPD_TYPE);
        /* [20200310] �s�W�^�ǰѼ� */
        ds.setField("IFRS_INV_RT", mapG100Log.get("IFRS_INV_RT"));
        ds.setField("INV_ACCDTL_CD", mapG100Log.get("INV_ACCDTL_CD"));
        ds.setField("SLF_ACCDTL_CD", mapG100Log.get("SLF_ACCDTL_CD"));

        DBUtil.executeUpdate(ds, SQL_insert_g100log);// [20191121]TABLE DTEPG100_LOG�W�[��� ��a����BASE_TYPE
        return mapG100Log;
    }

    /**
     * ���o��a�N��
     * 
     * @param SUB_CPY_ID
     * @param ZONE_CD
     * @return
     * @throws ModuleException
     */
    public String getBASE_CD(String SUB_CPY_ID, String ZONE_CD) throws ModuleException {
        // �ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_002");// �ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(ZONE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_010");// �ǤJ�ϰ�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        int serNo = theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "038", ZONE_CD, "BASE_CD");
        // �s�t�ηs�ذ�a�A�q 100 �}�l�s��
        if (serNo < 100) {
            serNo = 100;
            theEP_Z0Z001.updateSER_NO(SUB_CPY_ID, "038", ZONE_CD, "BASE_CD", Integer.toString(serNo));
        }

        StringBuilder sb = new StringBuilder();
        if ("00".equals(SUB_CPY_ID)) {
            return sb.append(ZONE_CD).append('2').append(serNo).toString();
        } else {
            return sb.append(SUB_CPY_ID).append(ZONE_CD).append('2').append(serNo).toString();
        }

    }

    /**
     * �ק�
     * 
     * @param mapG100
     * @param user
     * @throws ModuleException
     * @throws SQLException
     */
    /* [20190211] �߮׳渹 : 190130000429 */
    public void update(Map mapG100, UserObject user) throws ModuleException, SQLException {

        ErrorInputException eie = null;
        if (user == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_015");// �ǤJ�@�~�H����T ���o���ŭ�
        }
        if (mapG100 == null || mapG100.isEmpty()) {
            throw this.getErrorInputException(eie, "EP_Z0G100_MSG_004");// �ǤJ��a�򥻸���ɤ��o���ŭ�
        }
        /* [20200310] �s�W�ˮ� */
        this.checkIFRSDTLCD(mapG100);

        String SUB_CPY_ID = MapUtils.getString(mapG100, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_002");// �ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(mapG100, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_003");// �ǤJ��a�N�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        Timestamp updDate = DATE.currentTime();
        String UPD_ID = user.getEmpID();
        String UPD_NAME = user.getEmpName();
        // �s�W��a�D��LOG�O��
        Map mapG100Log = this.insertLog(mapG100, updDate, UPD_ID, UPD_NAME, "U");// [20191121]�s�W�^�ǰѼ�
        // ��s��a�D��
        DataSet ds = Transaction.getDataSet();

        ds.setField("BASE_CD", BASE_CD);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("SLF_CD", mapG100.get("SLF_CD"));
        ds.setField("INV_CD", mapG100.get("INV_CD"));
        ds.setField("INV_TP", mapG100.get("INV_TP"));
        ds.setField("ZONE", mapG100.get("ZONE"));
        ds.setField("ZONE_CD", mapG100.get("ZONE_CD"));
        ds.setField("SLF_HD1", mapG100.get("SLF_HD1"));
        ds.setField("SLF_HD2", mapG100.get("SLF_HD2"));
        ds.setField("INV_HD1", mapG100.get("INV_HD1"));
        ds.setField("INV_HD2", mapG100.get("INV_HD2"));
        ds.setField("SLF_PR_HD1", mapG100.get("SLF_PR_HD1"));
        ds.setField("SLF_PR_HD2", mapG100.get("SLF_PR_HD2"));
        ds.setField("INV_PR_HD1", mapG100.get("INV_PR_HD1"));
        ds.setField("INV_PR_HD2", mapG100.get("INV_PR_HD2"));
        this.setDateIfExist(ds, "LND_DT", mapG100);
        ds.setField("SLF_LND_STS", mapG100.get("SLF_LND_STS"));
        ds.setField("SLF_BLD_STS", mapG100.get("SLF_BLD_STS"));
        ds.setField("INV_LND_STS", mapG100.get("INV_LND_STS"));
        ds.setField("INV_BLD_STS", mapG100.get("INV_BLD_STS"));
        ds.setField("LND_LOCATE", mapG100.get("LND_LOCATE"));
        ds.setField("LND_SEG", mapG100.get("LND_SEG"));
        ds.setField("LND_NO", mapG100.get("LND_NO"));
        this.setDateIfExist(ds, "LND_EVL_AMT", mapG100);
        this.setDateIfExist(ds, "LND_MKT_VAL", mapG100);
        ds.setField("INV_USE_MEMO", mapG100.get("INV_USE_MEMO"));
        ds.setField("SLF_USE_MEMO", mapG100.get("SLF_USE_MEMO"));
        ds.setField("LND_MEMO", mapG100.get("LND_MEMO"));
        this.setDateIfExist(ds, "BLD_DT", mapG100);
        this.setDateIfExist(ds, "CEBLPRI", mapG100);
        ds.setField("BLD_NO", mapG100.get("BLD_NO"));
        ds.setField("BLD_ADDR", mapG100.get("BLD_ADDR"));
        ds.setField("BASE_BLD_NAME", mapG100.get("BASE_BLD_NAME"));
        this.setDateIfExist(ds, "BLD_LCN_DT", mapG100);
        this.setDateIfExist(ds, "BLD_EVL_AMT", mapG100);
        ds.setField("BLD_MEMO", mapG100.get("BLD_MEMO"));
        ds.setField("CHG_DATE", updDate);
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_ID", UPD_ID);
        ds.setField("CHG_NAME", UPD_NAME);
        // [20191121]�վ� DTEPG100 �W�[��� BASE_TYPE ��a�����BOWN_TYPE���v�B�b�CACC_TYPE
        ds.setField("BASE_TYPE", mapG100.get("BASE_TYPE"));
        ds.setField("OWN_TYPE", mapG100.get("OWN_TYPE"));
        ds.setField("ACC_TYPE", mapG100.get("ACC_TYPE"));
        // �U�C���������a�D�ɵ��G
        ds.setField("LND_AREA", mapG100Log.get("LND_AREA"));// �g�a�v�����n
        ds.setField("BLD_AREA", mapG100Log.get("BLD_AREA"));// �ت��v�����n
        ds.setField("LND_HLD_STS", mapG100Log.get("LND_HLD_STS"));// �g�a�������A
        ds.setField("BLD_HLD_STS", mapG100Log.get("BLD_HLD_STS"));// �ت��������A
        // [20200310]�վ� DTEPG100 �W�[��� IFRS_INV_RT
        // ���®�IFRS����ҡBINV_ACCDTL_CD���|�p��زӥءBSLF_ACCDTL_CD�ۥη|�p��زӥ�
        ds.setField("IFRS_INV_RT", mapG100.get("IFRS_INV_RT"));
        ds.setField("INV_ACCDTL_CD", mapG100.get("INV_ACCDTL_CD"));
        ds.setField("SLF_ACCDTL_CD", mapG100.get("SLF_ACCDTL_CD"));

        DBUtil.executeUpdate(ds, SQL_update_001);

    }

    /**
     * �s�W
     * 
     * @param mapG100
     * @param user
     * @throws ModuleException
     */
    /* [20190211] �߮׳渹 : 190130000429 */
    /* [20200310] �߮׳渹 : 200226001085 */
    public void insert(Map mapG100, UserObject user) throws ModuleException {

        if (mapG100 == null || mapG100.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G100_MSG_008"));// �ǤJ�ץ�_��a�򥻸���ɤ��o���ŭ�
        }
        if (user == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G100_MSG_015"));// �ǤJ�@�~�H����T ���o���ŭ�
        }
        /* [20200310] �s�W�ˮ� */
        this.checkIFRSDTLCD(mapG100);
        String ZONE_CD = MapUtils.getString(mapG100, "ZONE_CD");
        String SLF_CD = MapUtils.getString(mapG100, "SLF_CD");
        String INV_CD = MapUtils.getString(mapG100, "INV_CD");
        // ��s��a�D��
        DataSet ds = Transaction.getDataSet();

        ds.setField("BASE_CD", this.getNewBaseCd(ZONE_CD, SLF_CD, INV_CD));
        ds.setField("SUB_CPY_ID", MapUtils.getString(mapG100, "SUB_CPY_ID"));
        ds.setField("SLF_CD", SLF_CD);
        ds.setField("INV_CD", INV_CD);
        ds.setField("INV_TP", mapG100.get("INV_TP"));
        ds.setField("ZONE", mapG100.get("ZONE"));
        ds.setField("ZONE_CD", ZONE_CD);
        ds.setField("SLF_HD1", mapG100.get("SLF_HD1"));
        ds.setField("SLF_HD2", mapG100.get("SLF_HD2"));
        ds.setField("INV_HD1", mapG100.get("INV_HD1"));
        ds.setField("INV_HD2", mapG100.get("INV_HD2"));
        ds.setField("SLF_PR_HD1", mapG100.get("SLF_PR_HD1"));
        ds.setField("SLF_PR_HD2", mapG100.get("SLF_PR_HD2"));
        ds.setField("INV_PR_HD1", mapG100.get("INV_PR_HD1"));
        ds.setField("INV_PR_HD2", mapG100.get("INV_PR_HD2"));
        this.setDateIfExist(ds, "LND_DT", mapG100);
        ds.setField("SLF_LND_STS", mapG100.get("SLF_LND_STS"));
        ds.setField("SLF_BLD_STS", mapG100.get("SLF_BLD_STS"));
        ds.setField("INV_LND_STS", mapG100.get("INV_LND_STS"));
        ds.setField("INV_BLD_STS", mapG100.get("INV_BLD_STS"));
        ds.setField("LND_LOCATE", mapG100.get("LND_LOCATE"));
        ds.setField("LND_SEG", mapG100.get("LND_SEG"));
        ds.setField("LND_NO", mapG100.get("LND_NO"));
        this.setDateIfExist(ds, "LND_EVL_AMT", mapG100);
        this.setDateIfExist(ds, "LND_MKT_VAL", mapG100);
        ds.setField("INV_USE_MEMO", mapG100.get("INV_USE_MEMO"));
        ds.setField("SLF_USE_MEMO", mapG100.get("SLF_USE_MEMO"));
        ds.setField("LND_MEMO", mapG100.get("LND_MEMO"));
        this.setDateIfExist(ds, "BLD_DT", mapG100);
        this.setDateIfExist(ds, "CEBLPRI", mapG100);
        ds.setField("BLD_NO", mapG100.get("BLD_NO"));
        ds.setField("BLD_ADDR", mapG100.get("BLD_ADDR"));
        ds.setField("BASE_BLD_NAME", mapG100.get("BASE_BLD_NAME"));
        this.setDateIfExist(ds, "BLD_LCN_DT", mapG100);
        this.setDateIfExist(ds, "BLD_EVL_AMT", mapG100);
        ds.setField("BLD_MEMO", mapG100.get("BLD_MEMO"));
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        // [20191121]�s�W���
        // �վ� DTEPG100 �W�[��� BASE_TYPE �겣���O�BOWN_TYPE���v�B�b�CACC_TYPE
        // (�U�C���b��ƽL�I�T�{�ɧ�s�A�s�W���ݺ��@ LND_AREA �g�a�v�����n, BLD_AREA �ت��v�����n, LND_HLD_STS �g�a�������A,
        // BLD_HLD_STS �ت��������A)
        ds.setField("BASE_TYPE", mapG100.get("BASE_TYPE"));// �겣���O
        ds.setField("OWN_TYPE", mapG100.get("OWN_TYPE"));// ���v
        ds.setField("ACC_TYPE", mapG100.get("ACC_TYPE"));// �b�C
        // [20200310]�վ� DTEPG100 �W�[��� IFRS_INV_RT
        // ���®�IFRS����ҡBINV_ACCDTL_CD���|�p��زӥءBSLF_ACCDTL_CD�ۥη|�p��زӥ�
        ds.setField("IFRS_INV_RT", mapG100.get("IFRS_INV_RT"));
        ds.setField("INV_ACCDTL_CD", mapG100.get("INV_ACCDTL_CD"));
        ds.setField("SLF_ACCDTL_CD", mapG100.get("SLF_ACCDTL_CD"));

        DBUtil.executeUpdate(ds, SQL_insert_001);

    }

    /**
     * �R��
     * 
     * @param mapG100
     * @param user
     * @throws ModuleException
     */
    /* [20190211] �߮׳渹 : 190130000429 */
    public void delete(Map mapG100, UserObject user) throws ModuleException {

        ErrorInputException eie = null;

        if (user == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_015");// �ǤJ�@�~�H����T ���o���ŭ�
        }
        if (mapG100 == null || mapG100.isEmpty()) {
            throw this.getErrorInputException(eie, "EP_Z0G100_MSG_004");// �ǤJ��a�򥻸���ɤ��o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(mapG100, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_002");// �ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(mapG100, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_003");// �ǤJ��a�N�����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        // �s�W��a�D��LOG�O��
        this.insertLog(mapG100, DATE.currentTime(), user.getEmpID(), user.getEmpName(), "D");
        // ��s��a�D��
        DataSet ds = Transaction.getDataSet();

        ds.setField("BASE_CD", BASE_CD);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        DBUtil.executeUpdate(ds, SQL_delete_001);
    }

    /**
     * ��s�����
     * 
     * @param dataMap
     * @param user
     * @throws ModuleException
     */
    public void updateIFRS_INV_RT(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null || dataMap.isEmpty()) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_014");// �ǤJ�ץ�_��a�������ۥνվ��Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_015");// �ǤJ�@�~�H����T ���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        // ���o��a���
        Map updMap = queryMap(dataMap);
        DTEPG100 voG100 = VOTool.mapToVO(DTEPG100.class, updMap);
        String APLY_NO = "XXX";
        String TRN_KIND = "EPG300";
        Timestamp CHG_DATE = DATE.currentTime();
        voG100.setAPLY_NO(APLY_NO);
        voG100.setTRN_KIND(TRN_KIND);
        voG100.setCHG_DATE(CHG_DATE);
        voG100.setCHG_DIV_NO(user.getOpUnit());
        voG100.setCHG_ID(user.getEmpID());
        voG100.setCHG_NAME(user.getEmpName());

        // �g��a����LOG
        // insertLog(voG100, CHG_DATE, APLY_NO, TRN_KIND);//[20190211] SA�T�{�o�q���ѱ�

        BigDecimal INV_RT_A = STRING.objToBigDecimal(dataMap.get("INV_RATE_A"), BigDecimal.ZERO);
        voG100.setIFRS_INV_RT(INV_RT_A.divide(new BigDecimal("100"), 4, BigDecimal.ROUND_HALF_UP));
        VOTool.update(voG100);

    }

    /**
     * ���o��a�N��
     * 
     * @param ZONE_CD
     * @param SLF_CD
     * @param INV_CD
     * @return BASE_CD
     * @throws ModuleException
     */
    /* [20190211] �߮׳渹 : 190130000429 */
    public String getNewBaseCd(String ZONE_CD, String SLF_CD, String INV_CD) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(ZONE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_010");// �ǤJ�ϰ�O���o���ŭ�
        }
        if (StringUtils.isBlank(SLF_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_019");// �ۥΥN��������J
        } else if (SLF_CD.length() != 6) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_024");// �ۥΥN�����~
        } else {
            if (!"0".equals(SLF_CD.substring(2, 3))) {
                eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_018");// �ǤJ�ۥΥN���s�X���~�A�ĤT�X������0
            }
        }
        if (StringUtils.isBlank(INV_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_020");// ���N��������J
        } else if (INV_CD.length() != 6) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_025");// ���N�����~
        } else {
            if (!"1".equals(INV_CD.substring(2, 3))) {
                eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_021");// �ǤJ���N���s�X���~�A�ĤT�X������1
            }
        }

        if (eie != null) {
            throw eie;
        }

        String subSLF_CD = SLF_CD.substring(3, 6);
        if (!StringUtils.equals(subSLF_CD, INV_CD.substring(3, 6))) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_022");// �ǤJ���N���P�ۥΥN�����T�X���@�P
        }
        if (StringUtils.isNotBlank(ZONE_CD)) {
            if (!StringUtils.equals(ZONE_CD, SLF_CD.substring(0, 2)) || !StringUtils.equals(ZONE_CD, INV_CD.substring(0, 2))) {
                eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_023");// �ǤJ���N���P�ۥΥN���e��X�P�ϰ�O���@�P
            }
        }

        if (eie != null) {
            throw eie;
        }

        StringBuilder sb = new StringBuilder();

        return sb.append(ZONE_CD).append('2').append(subSLF_CD).toString();
    }

    /**
     * ��s��a�L�I�v�����n
     * 
     * @param req
     * @param opType
     * @param user
     * @throws ModuleException
     */
    // [20191121]�s�Wmethod
    public void updateAreaSize(Map reqMap, String opType, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_001");// �ǤJ��T���o���ŭ�
        }
        if (StringUtils.isBlank(opType)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_026");// �ǤJ�@�~���� ���o���ŭ�
        } else if (!"1".equals(opType) && !"2".equals(opType)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_027");// �ǤJ�@�~���������ݬ�1:�T�{��2:�����T�{!
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_015");// �ǤJ�@�~�H����T ���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String EP_CHK_YR = MapUtils.getString(reqMap, "EP_CHK_YR");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_002");// �ǤJ�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(EP_CHK_YR)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_028");// �ǤJ�L�I�~�פ��o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("strCHG_ID", user.getEmpID());
        ds.setField("strCHG_NAME", user.getEmpName());
        ds.setField("strCHG_DIV_NO", user.getOpUnit());
        ds.setField("chgDate", DATE.getDBTimeStamp());
        ds.setField("EP_CHK_YR", EP_CHK_YR);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        // �̾ڽL�I�~�ת���a�L�I���G�A��s��a�D�ɪ��v���L�I���n�P�������G
        if ("1".equals(opType)) {// �T�{
            // �̾ڽL�I�~�ת���a�L�I���G�A��s��a�D�ɪ��v���L�I���G
            DBUtil.executeUpdate(ds, SQL_updateAreaSize_001);
        } else {// 2:�����T�{
                // �̾ڽL�I�~�ת���a�L�I���G�A��s��a�D�ɪ��v���L�I���W�Ӧ~�ת��L�I���G
            DBUtil.executeUpdate(ds, SQL_updateAreaSize_002);
        }
    }

    /**
     * �d�߰�a�վ\�å��M��
     * 
     * @param SUB_CPY_ID �����q�O
     * @param baseList   ��a�M��
     * @return
     * @throws ModuleException
     */
    // [20191121]�s�Wmethod
    // [20191126]��^��List<Map>
    public List<Map> queryBaseConfigList(String SUB_CPY_ID, List baseList) throws ModuleException {
        // �ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_002");// �ǤJ�����q�O���o���ŭ�
        }
        if (baseList == null || baseList.isEmpty()) {
            eie = this.getErrorInputException(eie, "EP_Z0G100_MSG_029");// �ǤJ�վ\��a�M�椣�o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        // �d�ߦ��İ�a�L�å��վ\�]�w����a
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("baseList", baseList);
        // [20191126]�����B�z��MultiKeyMap���{��
        return VOTool.findToMaps(ds, SQL_queryBaseConfigList_001);
    }

    /**
     * ��wEIE����
     * 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * SQL�����D���n�Ѽ�
     * 
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * SQL�����D���n�Ѽ�
     * 
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setDateIfExist(DataSet ds, String key, Map map) {
        if (StringUtils.isNotBlank(MapUtils.getString(map, key))) {
            ds.setField(key, map.get(key));
        } else {
            ds.setField(key, null);
        }
    }

    /* [20200310] �߮׳渹 : 200226001085 */
    /**
     * SQL�����D���n�Ѽ�
     * 
     * @param ds
     * @param reqMap
     * @param key
     * @throws ErrorInputException
     */
    private void checkIFRSDTLCD(Map map) throws ErrorInputException {

        ErrorInputException eie = null;

        String IFRS_INV_RT = MapUtils.getString(map, "IFRS_INV_RT");
        if (StringUtils.isBlank(IFRS_INV_RT)) {
            throw new ErrorInputException(MessageUtil.getMessage("EPG1_0100_UI_CHECK_IFRS_RT"));// �ݿ�JIFRS�����
        }

        BigDecimal bd_IFRS_INV_RT = new BigDecimal(IFRS_INV_RT);
        Integer zeroCompareToIFRS_INV_RT = BigDecimal.ZERO.compareTo(bd_IFRS_INV_RT);
        Integer iFRS_INV_RTtoOne = BigDecimal.ONE.compareTo(bd_IFRS_INV_RT);

        if (!(zeroCompareToIFRS_INV_RT <= 0 && iFRS_INV_RTtoOne >= 0)) {
            throw new ErrorInputException(MessageUtil.getMessage("EPG1_0100_UI_CHECK_IFRS_RT")); // �ݿ�JIFRS�����
        }

        if (zeroCompareToIFRS_INV_RT < 0) {
            String INV_ACCDTL_CD = MapUtils.getString(map, "INV_ACCDTL_CD");
            if (null == INV_ACCDTL_CD) {
                throw new ErrorInputException(MessageUtil.getMessage("EPG1_0100_UI_CHECK_IFRS_INV"));// IFRS�����>0%
                                                                                                     // �ݿ�J���ӥ�
            }
        }

        if (iFRS_INV_RTtoOne > 0) {
            String SLF_ACCDTL_CD = MapUtils.getString(map, "SLF_ACCDTL_CD");
            if (null == SLF_ACCDTL_CD) {
                throw new ErrorInputException(MessageUtil.getMessage("EPG1_0100_UI_CHECK_IFRS_SFL")); // IFRS�����<100%
                                                                                                      // �ݿ�J�ۥβӥ�
            }
        }

    }
}
