package com.cathay.ep.z0.module;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.hr.EmployeeDetail;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dj.a0.module.DJ_A0Z002;
import com.cathay.dj.bo.DTDJA004;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.f1.module.EP_F10300;
import com.cathay.ep.f1.module.EP_F10310;
import com.cathay.ep.vo.DTEPF110;
import com.cathay.ep.vo.DTEPF120;
import com.cathay.ep.vo.DTEPF130;
import com.cathay.ep.vo.DTEPF160;
import com.cathay.ep.vo.DTEPZ003;
import com.cathay.rz.n0.module.RZ_N00100;
import com.cathay.rz.n0.module.RZ_N0Z001;
import com.cathay.rz.s0.module.RZ_S00300;
import com.cathay.rz.vo.DTRZN001;
import com.cathay.rz.vo.DTRZN010;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * DATE Description Author
*2014/09/15  Created ����i
*2018/03/07  �t�X��ؽվ� ����[
*�@�B  �{���\�෧�n�����G
*�ҲզW��    ��µ�ӽк��@�Ҳ�
*�Ҳ�ID    EP_Z0F110
*���n����    ��µ�ӽк��@�Ҳ�
 * @author �Ťl��
 *
 * @version 2018/01/26 ���~��:�s��µ�t�γB�z�[�J���P��/��H��
 *
 */
@SuppressWarnings("unchecked")
public class EP_Z0F110 {

    public static final String ST_1 = "1";

    public static final String ST_2 = "2";

    public static final String ST_3 = "3";

    public static final String ST_000 = "000";

    public static final String ST_100 = "100";

    public static final String ST_200 = "200";

    public static final String ST_300 = "300";

    public static final String ST_400 = "400";

    public static final String ST_420 = "420";

    public static final String ST_490 = "490";

    public static final String ST_500 = "500";

    public static final String ST_600 = "600";

    public static final String ST_700 = "700";

    public static final String ST_800 = "800";

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_queryList_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_queryMap_001";

    private static final String SQL_update_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_update_001";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_insert_001";

    private static final String SQL_updateF110_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_updateF110_001";

    private static final Logger log = Logger.getLogger(EP_Z0F110.class);

    /**
     *  Ū����µ�ץ�_�򥻸���ɲM��
     * @param F110Vo
     * @param QUERY_STS
     * @return
     * @throws Exception 
     */
    public List<Map> queryList(DTEPF110 F110Vo, String QUERY_STS) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (F110Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //�ǤJ��µ�ץ󬰪�
        } else {
            if (StringUtils.isBlank(F110Vo.getAPLY_NO()) && StringUtils.isBlank(F110Vo.getAPLY_TP()) && F110Vo.getINPUT_DATE() == null
                    && F110Vo.getEND_APLY_DATE() == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_002")); //�ץ�s���B�ץ�����B�߮פ���B���פ���A�Цܤ־ܤ@��J���A�d��
            }
            SUB_CPY_ID = F110Vo.getSUB_CPY_ID();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }

            if (StringUtils.isNotBlank(QUERY_STS)) {
                String[] QUERY_STS_Array = { ST_100, ST_200, ST_300, ST_400, ST_500, ST_600, ST_700, ST_800, ST_000 };
                if (!ArrayUtils.contains(QUERY_STS_Array, QUERY_STS)) {
                    eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_003")); //�ǤJ�ץ󪬺A���~�A���ˮ�
                }
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�����q�O�ζǤJ�ѼƬd�߭�µ�ץ�_�򥻸����(DTEPF110)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        setFieldIfExist(ds, F110Vo.getAPLY_NO(), "APLY_NO");
        setFieldIfExist(ds, F110Vo.getBLD_CD(), "BLD_CD");
        setFieldIfExist(ds, F110Vo.getAPLY_TP(), "APLY_TP");
        if (F110Vo.getINPUT_DATE() != null) {
            ds.setField("INPUT_DATE", F110Vo.getINPUT_DATE());
        }
        if (F110Vo.getEND_APLY_DATE() != null) {
            ds.setField("END_APLY_DATE", F110Vo.getEND_APLY_DATE());
        }

        setFieldIfExist(ds, F110Vo.getEXP_TP(), "EXP_TP");
        setFieldIfExist(ds, QUERY_STS, "QUERY_STS");
        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);

        //�v���B�z�^�ǲM��G�s�W����^�ǲM��
        List<Map> rtnList = new ArrayList<Map>();
        EP_F10310 theEP_F10310 = new EP_F10310();
        EP_Z0F120 theEP_Z0F120 = new EP_Z0F120();
        PersonnelData pd = new PersonnelData();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //�ץ����
            rtnMap.put("APLY_TP_NM", FieldOptionList.getName("EP", "APLY_TP_F101", MapUtils.getString(rtnMap, "APLY_TP")));
            //�ϥΪ��p����
            rtnMap.put("USE_TP_NM", FieldOptionList.getName("EP", "USE_TP_F101", MapUtils.getString(rtnMap, "USE_TP")));
            //�O�κ���
            rtnMap.put("EXP_TP_NM", FieldOptionList.getName("EP", "EXP_TP_F101", MapUtils.getString(rtnMap, "EXP_TP")));
            //�@�~�i��
            theEP_Z0F120.setOP_STATUS_NM(rtnMap);

            //��µ��H��
            String FIX_DIV_ID = MapUtils.getString(rtnMap, "FIX_DIV_ID");
            if (StringUtils.isNotBlank(FIX_DIV_ID)) {
                try {
                    EmployeeDetail emp = pd.getByEmployeeID2(FIX_DIV_ID);
                    if (emp != null) {
                        rtnMap.put("FIX_DIV_NM", emp.getName());
                    } else {
                        rtnMap.put("FIX_DIV_NM", "�L���H��");
                    }
                } catch (SQLException e) {
                    rtnMap.put("FIX_DIV_NM", "�L���H��");
                }
            }

            //��µ�դH��
            String FIX_GROUP_ID = MapUtils.getString(rtnMap, "FIX_GROUP_ID");
            if (StringUtils.isNotBlank(FIX_GROUP_ID)) {
                try {
                    rtnMap.put("FIX_GROUP_NM", theEP_F10310.getEmpMap(FIX_GROUP_ID, true, SUB_CPY_ID).get("NAME"));
                } catch (Exception e) {
                    rtnMap.put("FIX_GROUP_NM", "�L���H��");
                }
            }

            //�@�~�H��
            String LST_PROC_DIV = MapUtils.getString(rtnMap, "LST_PROC_DIV");
            String LST_PROC_ID = MapUtils.getString(rtnMap, "LST_PROC_ID");
            if (StringUtils.isNotEmpty(LST_PROC_DIV)) {
                if (LST_PROC_DIV.startsWith("EP9")) {
                    Map empMap;
                    try {
                        empMap = theEP_F10310.getEmpMap(LST_PROC_ID, true, SUB_CPY_ID);
                        rtnMap.put("LST_PROC_NM", empMap.get("NAME"));
                        rtnMap.put("LST_PROC_DIV_NM", empMap.get("DIV_SHORT_NAME"));
                    } catch (Exception e) {
                        rtnMap.put("LST_PROC_NM", "�L���H��");
                        rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                    }
                } else {
                    EmployeeDetail emp;
                    try {
                        emp = pd.getByEmployeeID2(LST_PROC_ID);
                        if (emp != null) {
                            rtnMap.put("LST_PROC_NM", emp.getName());
                            rtnMap.put("LST_PROC_DIV_NM", pd.getByEmployeeID(LST_PROC_ID).getDivShortName());
                        } else {
                            rtnMap.put("LST_PROC_NM", "�L���H��");
                            rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                        }
                    } catch (SQLException e) {
                        rtnMap.put("LST_PROC_NM", "�L���H��");
                        rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                    }
                }
            }

            //�߮פH��
            String INPUT_DIV_NO = MapUtils.getString(rtnMap, "INPUT_DIV_NO");
            String INPUT_ID = MapUtils.getString(rtnMap, "INPUT_ID");
            if (StringUtils.isNotEmpty(INPUT_DIV_NO)) {
                if (INPUT_DIV_NO.startsWith("EP9")) {
                    Map empMap;
                    try {
                        empMap = theEP_F10310.getEmpMap(INPUT_ID, true, SUB_CPY_ID);
                        rtnMap.put("INPUT_NM", empMap.get("NAME"));
                        rtnMap.put("INPUT_DIV_NM", empMap.get("DIV_SHORT_NAME"));
                    } catch (Exception e) {
                        rtnMap.put("INPUT_NM", "�L���H��");
                        rtnMap.put("INPUT_DIV_NM", "�L�����");
                    }
                } else {
                    EmployeeDetail emp;
                    try {
                        emp = pd.getByEmployeeID2(INPUT_ID);
                        rtnMap.put("INPUT_NM", emp.getName());
                        rtnMap.put("INPUT_DIV_NM", pd.getByEmployeeID(INPUT_ID).getDivShortName());
                    } catch (SQLException e) {
                        rtnMap.put("INPUT_NM", "�L���H��");
                        rtnMap.put("INPUT_DIV_NM", "�L�����");
                    }
                }
            }

            //�t�ӦW��
            setSUP_NM(rtnMap);

            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * Ū����µ�ץ�_�򥻸����
     * @param APLY_NO
     * @return
     * @throws ModuleException
     * @throws DBException
     * @throws SQLException 
     */
    public Map queryMap(String APLY_NO, String SUB_CPY_ID) throws ModuleException, DBException, SQLException {
        if (StringUtils.isBlank(APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F110_MSG_004"));//�ץ�s������
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //�H�ǤJ�ץ�s���d�߭�µ�ץ�_�򥻸����(DTEPF110)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001);
        EP_F10310 theEP_F10310 = new EP_F10310();
        PersonnelData pd = new PersonnelData();

        //�ץ����
        rtnMap.put("APLY_TP_NM", FieldOptionList.getName("EP", "APLY_TP_F101", MapUtils.getString(rtnMap, "APLY_TP")));
        //�ϥΪ��p����
        rtnMap.put("USE_TP_NM", FieldOptionList.getName("EP", "USE_TP_F101", MapUtils.getString(rtnMap, "USE_TP")));
        //�O�κ���
        rtnMap.put("EXP_TP_NM", FieldOptionList.getName("EP", "EXP_TP_F101", MapUtils.getString(rtnMap, "EXP_TP")));
        //�@�~�i��
        new EP_Z0F120().setOP_STATUS_NM(rtnMap);

        //��µ��H��
        String FIX_DIV_ID = MapUtils.getString(rtnMap, "FIX_DIV_ID");
        if (StringUtils.isNotBlank(FIX_DIV_ID)) {
            try {
                EmployeeDetail emp = pd.getByEmployeeID2(FIX_DIV_ID);
                if (emp != null) {
                    rtnMap.put("FIX_DIV_NM", emp.getName());
                } else {
                    rtnMap.put("FIX_DIV_NM", "�L���H��");
                }
            } catch (SQLException e) {
                rtnMap.put("FIX_DIV_NM", "�L���H��");
            }
        }

        //��µ�դH��
        String FIX_GROUP_ID = MapUtils.getString(rtnMap, "FIX_GROUP_ID");
        if (StringUtils.isNotBlank(FIX_GROUP_ID)) {
            try {
                rtnMap.put("FIX_GROUP_NM", theEP_F10310.getEmpMap(FIX_GROUP_ID, true, SUB_CPY_ID).get("NAME"));
            } catch (Exception e) {
                rtnMap.put("FIX_GROUP_NM", "�L���H��");
            }
        }

        //�@�~�H��
        String LST_PROC_DIV = MapUtils.getString(rtnMap, "LST_PROC_DIV");
        String LST_PROC_ID = MapUtils.getString(rtnMap, "LST_PROC_ID");
        if (StringUtils.isNotEmpty(LST_PROC_DIV)) {
            if (LST_PROC_DIV.startsWith("EP9")) {
                Map empMap;
                try {
                    empMap = theEP_F10310.getEmpMap(LST_PROC_ID, true, SUB_CPY_ID);
                    rtnMap.put("LST_PROC_NM", empMap.get("NAME"));
                    rtnMap.put("LST_PROC_DIV_NM", empMap.get("DIV_SHORT_NAME"));
                } catch (Exception e) {
                    rtnMap.put("LST_PROC_NM", "�L���H��");
                    rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                }
            } else {
                EmployeeDetail emp;
                try {
                    emp = pd.getByEmployeeID2(LST_PROC_ID);
                    if (emp != null) {
                        rtnMap.put("LST_PROC_NM", emp.getName());
                        rtnMap.put("LST_PROC_DIV_NM", pd.getByEmployeeID(LST_PROC_ID).getDivShortName());
                    } else {
                        rtnMap.put("LST_PROC_NM", "�L���H��");
                        rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                    }
                } catch (SQLException e) {
                    rtnMap.put("LST_PROC_NM", "�L���H��");
                    rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                }
            }
        }

        //�߮פH��
        String INPUT_DIV_NO = MapUtils.getString(rtnMap, "INPUT_DIV_NO");
        String INPUT_ID = MapUtils.getString(rtnMap, "INPUT_ID");
        if (StringUtils.isNotEmpty(INPUT_DIV_NO)) {
            if (INPUT_DIV_NO.startsWith("EP9")) {
                Map empMap;
                try {
                    empMap = theEP_F10310.getEmpMap(INPUT_ID, true, SUB_CPY_ID);
                    rtnMap.put("INPUT_NM", empMap.get("NAME"));
                    rtnMap.put("INPUT_DIV_NM", empMap.get("DIV_SHORT_NAME"));
                } catch (Exception e) {
                    rtnMap.put("INPUT_NM", "�L���H��");
                    rtnMap.put("INPUT_DIV_NM", "�L�����");
                }
            } else {
                EmployeeDetail emp;
                try {
                    emp = pd.getByEmployeeID2(INPUT_ID);
                    if (emp != null) {
                        rtnMap.put("INPUT_NM", emp.getName());
                        rtnMap.put("INPUT_DIV_NM", pd.getByEmployeeID(INPUT_ID).getDivShortName());
                    } else {
                        rtnMap.put("INPUT_NM", "�L���H��");
                        rtnMap.put("INPUT_DIV_NM", "�L�����");
                    }
                } catch (SQLException e) {
                    rtnMap.put("INPUT_NM", "�L���H��");
                    rtnMap.put("INPUT_DIV_NM", "�L�����");
                }
            }
        }

        //�t�ӦW��
        setSUP_NM(rtnMap);
        return rtnMap;
    }

    /**
     * �]�w�t�ӦW��
     * @param rtnMap
     * @throws DBException
     * @throws ModuleException
     * @throws SQLException 
     */
    public void setSUP_NM(Map rtnMap) throws DBException, ModuleException, SQLException {
        String SUP_ID = MapUtils.getString(rtnMap, "SUP_ID");
        String SUP_NM = MapUtils.getString(rtnMap, "SUP_NM");
        if (StringUtils.isNotBlank(SUP_ID) && StringUtils.isBlank(SUP_NM)) {
            rtnMap.put("SUP_NM", this.setSUP_NM(SUP_ID));
        }
    }

    /**
     * �]�w�t�ӦW��
     * @param SUP_ID
     * @return
     * @throws SQLException
     * @throws DBException
     * @throws ModuleException
     */
    public String setSUP_NM(String SUP_ID) throws SQLException, DBException, ModuleException {
        String SUP_NM = "";
        if (StringUtils.isNotBlank(SUP_ID)) {
            if (SUP_ID.length() == 7 && STRING.isMatchPattern(SUP_ID, "^\\w+$")) {
                SUP_NM = new DivData().getUnit4ShortName(SUP_ID);
            } else {
                ReturnMessage rm = new ReturnMessage();
                DTDJA004 dj = new DJ_A0Z002().doQuery(SUP_ID, rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    //throw new ModuleException(MessageUtil.getMessage("EP_Z0F110_MSG_012"));//���o�t�ӦW�ٸ��o�Ϳ��~
                    //SUP_NM = MessageUtil.getMessage("EP_Z0F110_MSG_012");
                    SUP_NM = "�L���t��";
                } else if (dj != null) {
                    SUP_NM = dj.getACPT_NAME();
                }
            }
        }
        return SUP_NM;
    }

    /**
     * �s�W��µ�ץ�
     * @param F110Vo
     * @param userMap
     * @return
     * @throws ModuleException
     */
    public Map insert(DTEPF110 F110Vo, Map userMap) throws ModuleException {
        ErrorInputException eie = null;
        String APLY_TP = "";
        if (F110Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //�ǤJ��µ�ץ󬰪�
        } else {
            if (StringUtils.isBlank(F110Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
            }
            APLY_TP = F110Vo.getAPLY_TP();
            if (StringUtils.isBlank(F110Vo.getAPLY_TP())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_006")); //�ǤJ�ץ��������!
            }
        }
        if (userMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }
        //���o�ץ�s��(�Ҧ������q�O�@�νs�X, �G�����q�O�T�w��00)
        String currentDate = DATE.toDate_yyyyMMdd(DATE.getDBDate());
        String APLY_NO = new EP_Z0Z001().createNextNo("00", "033", DATE.getY2KYear(DATE.getDBDate()), "APLY_NO", currentDate, 4);
        //�s�W��µ�ץ�_�򥻸����DTEPF110�G
        F110Vo.setAPLY_NO(APLY_NO);
        F110Vo.setINPUT_DIV_NO(MapUtils.getString(userMap, "CHG_DIV_NO"));//�߮׳��
        F110Vo.setINPUT_ID(MapUtils.getString(userMap, "INPUT_ID"));//�߮פH��ID
        F110Vo.setINPUT_DATE((Timestamp) userMap.get("CHG_DATE"));//�߮פ���ɶ�
        F110Vo.setLST_PROC_DIV(MapUtils.getString(userMap, "CHG_DIV_NO"));
        F110Vo.setLST_PROC_ID(MapUtils.getString(userMap, "CHG_ID"));
        F110Vo.setLST_PROC_DATE((Timestamp) userMap.get("CHG_DATE"));

        //�W�[�f��y�{
        //���o�f��y����strFlowNo
        F110Vo.setOP_STATUS(ST_100);
        String FLOW_TYPE;
        if (ST_1.equals(APLY_TP)) {
            // 1:�s�P��
            FLOW_TYPE = "EPF1_0100";
        } else if (ST_2.equals(APLY_TP)) {
            //2:�@��� 
            //�@���߮׬y�{
            FLOW_TYPE = "EPF1_0200";
        } else {
            //3:����� 
            //�����߮׬y�{
            FLOW_TYPE = "EPF1_0200";
        }
        String CHG_ID = MapUtils.getString(userMap, "CHG_ID", "");
        String CHG_DIV_NO = MapUtils.getString(userMap, "CHG_DIV_NO", "");
        String CHG_NAME = MapUtils.getString(userMap, "CHG_NAME", "");
        if (CHG_DIV_NO.startsWith("EP9")) {
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String strFlowNo = new RZ_N0Z001().startFlow(FLOW_TYPE, "�߮�", "�߮�(" + CHG_NAME + ")", CHG_ID, CHG_DIV_NO);
        F110Vo.setFLOW_NO(strFlowNo);
        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("SUB_CPY_ID", F110Vo.getSUB_CPY_ID());
        ds.setField("BLD_CD", F110Vo.getBLD_CD());
        ds.setField("BLD_NM", F110Vo.getBLD_NM());
        ds.setField("BLD_ADDR", F110Vo.getBLD_ADDR());
        if (StringUtils.isBlank(F110Vo.getFIX_MO())) {
            ds.setField("FIX_MO", "");
        } else {
            ds.setField("FIX_MO", F110Vo.getFIX_MO());
        }

        ds.setField("INPUT_DIV_NO", F110Vo.getINPUT_DIV_NO());
        ds.setField("INPUT_DATE", F110Vo.getINPUT_DATE());
        ds.setField("INPUT_ID", F110Vo.getINPUT_ID());
        ds.setField("APLY_TP", F110Vo.getAPLY_TP());
        ds.setField("USE_TP", F110Vo.getUSE_TP());
        ds.setField("EXP_TP", F110Vo.getEXP_TP());

        ds.setField("FIX_FILE_NO", F110Vo.getFIX_FILE_NO());
        ds.setField("FINAL_FILE_NO", F110Vo.getFINAL_FILE_NO());
        ds.setField("FIX_DIV_ID", F110Vo.getFIX_DIV_ID());
        ds.setField("FIX_GROUP_ID", F110Vo.getFIX_GROUP_ID());
        ds.setField("FIX_FINAL_DATE", F110Vo.getFIX_FINAL_DATE());
        ds.setField("SUB_USR_DATE", F110Vo.getSUB_USR_DATE());
        ds.setField("USR_FINAL_DATE", F110Vo.getUSR_FINAL_DATE());
        ds.setField("END_APLY_DATE", F110Vo.getEND_APLY_DATE());

        ds.setField("SUP_ID", F110Vo.getSUP_ID());
        ds.setField("CLR_AMT", F110Vo.getCLR_AMT());
        ds.setField("ACT_AMT", F110Vo.getACT_AMT());
        ds.setField("CURR", ObjectUtils.toString(F110Vo.getCURR(), "NTD"));
        ds.setField("CFM_WORK_MO", F110Vo.getCFM_WORK_MO());
        ds.setField("MGR_PPL_MO", F110Vo.getMGR_PPL_MO());

        ds.setField("FLOW_NO", F110Vo.getFLOW_NO());
        ds.setField("OP_STATUS", F110Vo.getOP_STATUS());
        ds.setField("REQNO", F110Vo.getREQNO());
        ds.setField("LST_PROC_DATE", F110Vo.getLST_PROC_DATE());
        ds.setField("LST_PROC_ID", F110Vo.getLST_PROC_ID());
        ds.setField("LST_PROC_DIV", F110Vo.getLST_PROC_DIV());

        DBUtil.executeUpdate(ds, SQL_insert_001);
        Map rtnMap = new HashMap();
        rtnMap.put("APLY_NO", APLY_NO);
        rtnMap.put("FLOW_NO", strFlowNo);
        return rtnMap;

    }

    /**
     * �ק��µ�ץ�_�򥻸����
     * @param F110Vo
     * @param user
     * @param approve
     * @throws Exception 
     */
    public void update(Map reqMap, UserObject user, String approve) throws Exception {
        ErrorInputException eie = null;
        String APLY_TP = "";
        String SUB_CPY_ID = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
            }
            APLY_TP = MapUtils.getString(reqMap, "APLY_TP");
            if (StringUtils.isBlank(APLY_TP)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_006")); //�ǤJ�ץ��������!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }

        //�d�߭�µ�ץ�_�򥻸��
        Map F110Map = this.queryMap(MapUtils.getString(reqMap, "APLY_NO"), SUB_CPY_ID);
        String FLOW_NO = MapUtils.getString(F110Map, "FLOW_NO");
        reqMap.put("FLOW_NO", FLOW_NO);
        // String Map_OP_STATUS = MapUtils.getString(F110Map, "OP_STAT  US");

        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String AUTH_DESC = MapUtils.getString(reqMap, "AUTH_DESC");
        String OP_STATUS = MapUtils.getString(F110Map, "OP_STATUS", "");
        if (ST_1.equals(approve)) {
            String aplyTP = MapUtils.getString(F110Map, "APLY_TP", "");
            log.debug("OP_STATUS:" + OP_STATUS);
            log.debug("APLY_TP:" + aplyTP);

            //FIX_GROUP_ID    VARCHAR 10          ��µ�դH��   
            //�h��᭫�s�e��
            if ("100".equals(OP_STATUS)) {
                // FIX_DIV_ID   VARCHAR 10          ��µ��H��   
                String FIX_DIV_ID = MapUtils.getString(F110Map, "FIX_DIV_ID", "");
                log.debug("FIX_DIV_ID:" + FIX_DIV_ID);
                if (StringUtils.isNotEmpty(FIX_DIV_ID)) {
                    if ("1".equals(aplyTP)) {
                        new RZ_N0Z001().assignOPStatus(FLOW_NO, AUTH_DESC, "�h�^�᭫�s�e��", ST_420, CHG_ID, CHG_DIV_NO);
                    } else {
                        //EPF1_0200 200 300 ��µ��w����
                        String newStatus = ST_300;
                        String FIX_GROUP_ID = MapUtils.getString(F110Map, "FIX_GROUP_ID", "");
                        log.debug("FIX_GROUP_ID:" + FIX_GROUP_ID);
                        if (StringUtils.isNotEmpty(FIX_GROUP_ID)) {
                            //EPF1_0200 300 400 ��µ�դw����
                            newStatus = ST_400;
                        }
                        new RZ_N0Z001().assignOPStatus(FLOW_NO, AUTH_DESC, "�h�^�᭫�s�e��", newStatus, CHG_ID, CHG_DIV_NO);
                    }
                } else {
                    new RZ_N0Z001().approveFlow(FLOW_NO, AUTH_DESC, AUTH_DESC + "(" + user.getEmpName() + ")", CHG_ID, CHG_DIV_NO);
                }
            } else {
                new RZ_N0Z001().approveFlow(FLOW_NO, AUTH_DESC, AUTH_DESC + "(" + user.getEmpName() + ")", CHG_ID, CHG_DIV_NO);
            }
        } else if (ST_2.equals(approve)) {
            new RZ_N0Z001().rejectFlow(FLOW_NO, AUTH_DESC, AUTH_DESC + "(" + user.getEmpName() + ")", CHG_ID, CHG_DIV_NO);
        } else if (ST_3.equals(approve)) {
            String MGR_PPL_MO = MapUtils.getString(reqMap, "MGR_PPL_MO");
            String COMMENT = AUTH_DESC + "(" + user.getEmpName() + ")�A�h�^��]:" + MGR_PPL_MO;
            new RZ_N0Z001().assignOPStatus(FLOW_NO, AUTH_DESC, COMMENT, ST_100, CHG_ID, CHG_DIV_NO);
        }
        DTRZN010 voDTRZN010 = new DTRZN010();
        voDTRZN010.setFLOW_NO(FLOW_NO);
        voDTRZN010 = new RZ_N00100().queryDTRZN010(voDTRZN010).get(0);
        String NEW_STATUS = voDTRZN010.getOP_STATUS();

        //��s�H���m�W
        if ("200".equals(NEW_STATUS)) { //200 �ݬ���(��µ��)
            reqMap.put("INPUT_DIV_NM", this.getFixDivName(user.getOpUnit(), SUB_CPY_ID));
        } else if ("300".equals(NEW_STATUS)) {
            String FIX_DIV_ID = StringUtils.isNotBlank(MapUtils.getString(F110Map, "FIX_DIV_ID")) ? MapUtils.getString(F110Map,
                "FIX_DIV_ID") : MapUtils.getString(reqMap, "FIX_DIV_ID", "");
            if (StringUtils.isNotBlank(FIX_DIV_ID)) {
                EmployeeDetail ep = new PersonnelData().getByEmployeeID2(FIX_DIV_ID);
                reqMap.put("FIX_DIV_NM", ep.getName());
            } else {
                throw new ModuleException("��µ�쬣��,��µ��H�����i����");
            }
        } else if ("400".equals(NEW_STATUS)) {
            String FIX_GROUP_ID = StringUtils.isNotBlank(MapUtils.getString(F110Map, "FIX_GROUP_ID")) ? MapUtils.getString(F110Map,
                "FIX_GROUP_ID") : MapUtils.getString(reqMap, "FIX_GROUP_ID", "");
            if (StringUtils.isNotBlank(FIX_GROUP_ID)) {
            	EP_F10310 theEP_F10310 = new EP_F10310();
                reqMap.put("FIX_GROUP_NM", theEP_F10310.getEmpMap(FIX_GROUP_ID, true, SUB_CPY_ID).get("NAME"));
            } else {
                //20190211 �q���@�~�ӽЮ�190130000633:��µ�e������������� 
                //throw new ModuleException("��µ�լ���,��µ�դH�����i����");
                throw new ModuleException("�ɬd�H������,�ɬd�H�����i����");
            }
        }

        DataSet ds = Transaction.getDataSet();

        if (ST_1.equals(approve)) {
            //�e�� ��s�߮פH�����e��H��
            log.debug("OP_STATUS:" + NEW_STATUS);
            if ("200".equals(NEW_STATUS)) {
                ds.setField("INPUT_ID", user.getEmpID());
            }
            setFieldIfExistforMap(ds, reqMap, "FIX_DIV_ID");
            setFieldIfExistforMap(ds, reqMap, "FIX_GROUP_ID");

            setFieldIfExistforMap(ds, reqMap, "INPUT_DIV_NM");
            setFieldIfExistforMap(ds, reqMap, "FIX_DIV_NM");
            setFieldIfExistforMap(ds, reqMap, "FIX_GROUP_NM");

            setFieldIfExistforMap(ds, reqMap, "FIX_FINAL_DATE");
            setFieldIfExistforMap(ds, reqMap, "SUB_USR_DATE");
            setFieldIfExistforMap(ds, reqMap, "USR_FINAL_DATE");
            setFieldIfExistforMap(ds, reqMap, "END_APLY_DATE");
            setFieldIfExistforMap(ds, reqMap, "DIV_CFM_DATE");
            setFieldIfExistforMap(ds, reqMap, "INFM_CONS_DATE");

            setFieldIfExistforMap(ds, reqMap, "CFM_WORK_MO");
            setFieldIfExistforMap(ds, reqMap, "MGR_PPL_MO");
            setFieldIfExistforMap(ds, reqMap, "FINAL_FILE_NO");
            //setFieldIfExistforMap(ds, reqMap, "INV_NO");
        } else {
            setFieldIfExistforNULL(ds, reqMap, "EST_AMT");
            if (ST_2.equals(approve) || ST_3.equals(approve)) {
                //setFieldIfExistforNULL(ds, reqMap, "FIX_DIV_ID");
                //setFieldIfExistforNULL(ds, reqMap, "FIX_GROUP_ID");
                setFieldIfExistforNULL(ds, reqMap, "CFM_WORK_MO");

                if (ST_1.equals(APLY_TP)) {
                    setFieldIfExistforNULL(ds, reqMap, "MGR_PPL_MO");
                    setFieldIfExistforNULL(ds, reqMap, "DIV_CFM_DATE");
                    setFieldIfExistforNULL(ds, reqMap, "INFM_CONS_DATE");

                } else {
                    setFieldIfExistforNULL(ds, reqMap, "FIX_FINAL_DATE");

                }
                setFieldIfExistforNULL(ds, reqMap, "SUB_USR_DATE");
                setFieldIfExistforNULL(ds, reqMap, "USR_FINAL_DATE");
            }

            //���������禬
            //�s�P��µ�ץ�A�����禬 �R�����дڪ��дڮ־P����
            if (ST_2.equals(approve) && "1".equals(APLY_TP) && "700".equals(OP_STATUS)) {
                String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
                EP_Z0F160 theEP_Z0F160 = new EP_Z0F160();
                List<Map> listF160 = theEP_Z0F160.qryChkList(APLY_NO, SUB_CPY_ID);
                for (Map F160Map : listF160) {
                    Object PAY_DATE = F160Map.get("PAY_DATE");
                    if (PAY_DATE == null) {
                        DTEPF160 F160Vo = VOTool.mapToVO(DTEPF160.class, F160Map);
                        theEP_Z0F160.delete(F160Vo);
                    }
                }
            }
        }

        //��s�ץ��ܧ���DTEPF110�G
        //F110Vo.setOP_STATUS(NEW_STATUS);
        ds.setField("OP_STATUS", NEW_STATUS);
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("LST_PROC_NM", user.getEmpName());
        ds.setField("APLY_NO", reqMap.get("APLY_NO"));
        ds.setField("SUB_CPY_ID", reqMap.get("SUB_CPY_ID"));

        DBUtil.executeUpdate(ds, SQL_update_001);

    }

    /**
    * �@���µ�ץ�i��_�򥻸����
    * @param F110Vo
    * @param user
    * @throws Exception 
    */
    public void approve(Map reqMap, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String APLY_TP = "";
        String SUB_CPY_ID = "";
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
            }
            APLY_TP = MapUtils.getString(reqMap, "APLY_TP");
            if (StringUtils.isBlank(APLY_TP)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_006")); //�ǤJ�ץ��������!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }
        //�d�߭�µ�ץ�_�򥻸��
        Map F110Map = this.queryMap(MapUtils.getString(reqMap, "APLY_NO"), SUB_CPY_ID);
        String FLOW_NO = MapUtils.getString(F110Map, "FLOW_NO");
        reqMap.put("FLOW_NO", MapUtils.getString(F110Map, "FLOW_NO"));
        // String Map_OP_STATUS = MapUtils.getString(F110Map, "OP_STAT  US");

        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String AUTH_DESC = MapUtils.getString(reqMap, "AUTH_DESC");

        String OP_STATUS = MapUtils.getString(F110Map, "OP_STATUS", "");
        String aplyTP = MapUtils.getString(F110Map, "APLY_TP", "");
        log.debug("OP_STATUS:" + OP_STATUS);
        log.debug("APLY_TP:" + aplyTP);
        //�h��᭫�s�e��
        if ("100".equals(OP_STATUS)) {
            // FIX_DIV_ID   VARCHAR 10          ��µ��H��   
            String FIX_DIV_ID = MapUtils.getString(F110Map, "FIX_DIV_ID", "");
            log.debug("FIX_DIV_ID:" + FIX_DIV_ID);
            if (StringUtils.isNotEmpty(FIX_DIV_ID)) {
                if ("1".equals(aplyTP)) {
                    new RZ_N0Z001().assignOPStatus(FLOW_NO, AUTH_DESC, "�h�^�᭫�s�e��", ST_420, CHG_ID, CHG_DIV_NO);
                } else {
                    //EPF1_0200 200 300 ��µ��w����
                    String newStatus = ST_300;
                    String FIX_GROUP_ID = MapUtils.getString(F110Map, "FIX_GROUP_ID", "");
                    log.debug("FIX_GROUP_ID:" + FIX_GROUP_ID);
                    if (StringUtils.isNotEmpty(FIX_GROUP_ID)) {
                        //EPF1_0200 300 400 ��µ�դw����
                        newStatus = ST_400;
                    }
                    new RZ_N0Z001().assignOPStatus(FLOW_NO, AUTH_DESC, "�h�^�᭫�s�e��", newStatus, CHG_ID, CHG_DIV_NO);
                }
            } else {
                new RZ_N0Z001().approveFlow(FLOW_NO, AUTH_DESC, AUTH_DESC + "(" + user.getEmpName() + ")", CHG_ID, CHG_DIV_NO);
            }
        } else {
            new RZ_N0Z001().approveFlow(FLOW_NO, AUTH_DESC, AUTH_DESC + "(" + user.getEmpName() + ")", CHG_ID, CHG_DIV_NO);
        }

        DTRZN010 voDTRZN010 = new DTRZN010();
        voDTRZN010.setFLOW_NO(FLOW_NO);
        voDTRZN010 = new RZ_N00100().queryDTRZN010(voDTRZN010).get(0);

        DataSet ds = Transaction.getDataSet();

        //�e�� ��s�߮פH�����e��H��
        log.debug("OP_STATUS:" + voDTRZN010.getOP_STATUS());
        if ("200".equals(voDTRZN010.getOP_STATUS())) {
            ds.setField("INPUT_ID", user.getEmpID());
        }
        setFieldIfExistforMap(ds, reqMap, "FIX_DIV_ID");
        setFieldIfExistforMap(ds, reqMap, "FIX_GROUP_ID");
        setFieldIfExistforMap(ds, reqMap, "FIX_FINAL_DATE");
        setFieldIfExistforMap(ds, reqMap, "SUB_USR_DATE");
        setFieldIfExistforMap(ds, reqMap, "USR_FINAL_DATE");
        setFieldIfExistforMap(ds, reqMap, "END_APLY_DATE");
        setFieldIfExistforMap(ds, reqMap, "DIV_CFM_DATE");
        setFieldIfExistforMap(ds, reqMap, "INFM_CONS_DATE");
        setFieldIfExistforMap(ds, reqMap, "CFM_WORK_MO");
        setFieldIfExistforMap(ds, reqMap, "MGR_PPL_MO");
        setFieldIfExistforMap(ds, reqMap, "FINAL_FILE_NO");

        //��s�ץ��ܧ���DTEPF110�G
        //F110Vo.setOP_STATUS(voDTRZN010.getOP_STATUS());
        ds.setField("OP_STATUS", voDTRZN010.getOP_STATUS());
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("APLY_NO", reqMap.get("APLY_NO"));
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_update_001);

    }

    /**
     * �R����µ�ץ�_�򥻸����
     * @param F110Vo
     * @param user
     * @throws Exception 
     */
    public void delete(DTEPF110 F110Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;

        if (F110Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            if (StringUtils.isBlank(F110Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_004")); //�ǤJ�ץ�s������!
            }
            if (StringUtils.isBlank(F110Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
            if (!ST_100.equals(F110Vo.getOP_STATUS())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_008")); //�ץ�@�~�i�׫D�߮סA���o�R��!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }
        //�O���f��Ƨѿ����{
        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String COMMENT = "�R���ץ�" + F110Vo.getAPLY_NO() + "(" + user.getEmpName() + ")";
        //�h���f��y�{�s��
        String[] flowNoArrayList = F110Vo.getFLOW_NO().split(",");
        if (flowNoArrayList.length > 0) {
            new RZ_N0Z001().deleteFlowByDiv(flowNoArrayList[0], "�R��", COMMENT, CHG_ID, CHG_DIV_NO, user.getCOMP_ID());
        }

        if (flowNoArrayList.length > 1) {
            //���Ƨѿ��y�{
            EP_Z0F120 F120Mod = new EP_Z0F120();
            EP_Z0F130 F130Mod = new EP_Z0F130();
            DTEPF120 F120Vo = new DTEPF120();
            F120Vo.setAPLY_NO(F110Vo.getAPLY_NO());
            F120Vo.setSUB_CPY_ID(F110Vo.getSUB_CPY_ID());
            List<DTEPF120> voList = VOTool.findWithUR(DTEPF120.class, F120Vo, false);
            for (DTEPF120 F120Obj : voList) {
                String MEMO_NO = ObjectUtils.toString(F120Obj.getMEMO_NO());
                //�Y�Ƨѿ��渹������
                if (F120Obj.getMEMO_NO() >= 1) {
                    //�R����µ�ץ�_�Ƨѿ����
                    F120Mod.delete(F120Obj, user);
                    //�R����µ�ץ�_�Ƨѿ��e�֪��ɮ�
                    if (StringUtils.isNotBlank(F120Obj.getPPL_FILE_NO())) {
                        try {
                            //�N�R���ɮ׽s���A���c����k�@��
                            deleteFileNo(F110Vo.getSUB_CPY_ID(), F120Obj.getPPL_FILE_NO(), user);
                        } catch (DataNotFoundException e) {
                            //�d�L��Ƶ������`
                        }
                    }
                    //�R����µ�ץ�_�Ƨѿ��ɮ�
                    if (StringUtils.isNotBlank(F120Obj.getMEMO_FILE_NO())) {
                        try {
                            //�N�R���ɮ׽s���A���c����k�@��
                            deleteFileNo(F110Vo.getSUB_CPY_ID(), F120Obj.getPPL_FILE_NO(), user);
                        } catch (DataNotFoundException e) {
                            //�d�L��Ƶ������`
                        }
                    }

                    //�R����µ�ץ�Ƨѿ� ���u�ظ��
                    try {
                        DTEPF130 F130Vo = new DTEPF130();
                        F130Vo.setAPLY_NO(F110Vo.getAPLY_NO());
                        F130Vo.setMEMO_NO(NumberUtils.toInt(MEMO_NO));
                        F130Vo.setSUB_CPY_ID(F110Vo.getSUB_CPY_ID());
                        F130Mod.deleteByUpload(F130Vo, user);
                    } catch (DataNotFoundException dnfe) {
                        //�R�L��� �������`
                    }
                }
            }
        }

        //�R����µ�ץ�_�򥻸����DTEPF110
        VOTool.delByPK(F110Vo);

        List<String> fileNo = new ArrayList<String>();

        fileNo.add(F110Vo.getFIX_FILE_NO()); //�ɬd�ɮ׽s��
        fileNo.add(F110Vo.getFINAL_FILE_NO()); //�禬�ɮ׽s��

        for (String file : fileNo) {
            if (StringUtils.isNotBlank(file)) {
                try {
                    //�N�R���ɮ׽s���A���c����k�@��
                    deleteFileNo(F110Vo.getSUB_CPY_ID(), file, user);
                } catch (DataNotFoundException e) {
                    //�d�L��Ƶ������`
                }
            }
        }
    }

    /**
     * ��µ�ץ�W���ɮ�
     * @param F110Vo
     * @param fileItem
     * @param user
     * @param type
     * @throws Exception 
     */
    public void upload(DTEPF110 F110Vo, FileItem fileItem, UserObject user, String type) throws Exception {
        ErrorInputException eie = null;

        if (F110Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            if (StringUtils.isBlank(F110Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_004")); //�ǤJ�ץ�s������!
            }
            if (StringUtils.isBlank(F110Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }
        Timestamp currentDate = DATE.currentTime();
        //���o��µ�ץ�_�򥻸����DTEPF110
        DTEPF110 DBF110Vo = VOTool.findByPKWithUR(F110Vo);
        //�ɮפW��
        DTEPZ003 EPZ003VO = new DTEPZ003();
        EP_Z00010 theEP_Z00010 = new EP_Z00010();
        EPZ003VO.setFILE_NM(fileItem.getName());
        String FILE_KIND = fileItem.getName().substring(fileItem.getName().lastIndexOf(".") + 1);
        EPZ003VO.setFILE_KIND(FILE_KIND);
        EPZ003VO.setSUB_CPY_ID(F110Vo.getSUB_CPY_ID());
        EPZ003VO.setINS_DT(currentDate);
        EPZ003VO.setINS_ID(user.getEmpID());
        EPZ003VO.setINS_DIVNO(user.getOpUnit());

        String FILE_NO;
        if (ST_1.equals(type) && StringUtils.isBlank(DBF110Vo.getFIX_FILE_NO())) {
            FILE_NO = theEP_Z00010.insert(EPZ003VO, fileItem, user);//�W�ǰɬd�ɮ�
            DBF110Vo.setFIX_FILE_NO(FILE_NO);//�ɬd�ɮ׽s��

        } else if (ST_1.equals(type) && StringUtils.isNotBlank(DBF110Vo.getFIX_FILE_NO())) {
            theEP_Z00010.update(EPZ003VO, "N", fileItem, user); //��s�ɬd�ɮ�
        } else if (ST_2.equals(type) && StringUtils.isBlank(DBF110Vo.getFINAL_FILE_NO())) {
            FILE_NO = theEP_Z00010.insert(EPZ003VO, fileItem, user); //�W���禬�ɮ�
            DBF110Vo.setFINAL_FILE_NO(FILE_NO);//�禬�ɮ׽s��
        } else if (ST_2.equals(type) && StringUtils.isNotBlank(DBF110Vo.getFINAL_FILE_NO())) {
            theEP_Z00010.update(EPZ003VO, "N", fileItem, user); //��s�禬�ɮ�
        }
        //�ק��µ�ץ�_�򥻸����DTEPF110�ɮ׽s��
        VOTool.update(DBF110Vo);
        //�O���f��Ƨѿ����{
        /*DBF110Vo = VOTool.mapToVO(DTEPF110.class, this.queryMap(F110Vo.getAPLY_NO()));
        DBF110Vo.setLST_PROC_DATE(currentDate);
        DBF110Vo.setLST_PROC_ID(user.getEmpID());
        DBF110Vo.setLST_PROC_DIV(user.getOpUnit());
        String COMMENT;
        if (ST_1.equals(type)) {
            COMMENT = "��µ�ץ�_�򥻸���ɰɬd�ɮפW��";
        } else {
            COMMENT = "��µ�ץ�_�򥻸�����禬�ɮפW��";
        }
        new RZ_N0Z001().insertLogOnly(DBF110Vo, COMMENT);*/
    }

    /**
     * �P��
     * @param F110Vo
     * @param user
     * @throws ModuleException
     */
    public void cancel(DTEPF110 F110Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;

        if (F110Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //�ǤJ��µ�ץ󬰪�
        } else {
            if (StringUtils.isBlank(F110Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_004")); //�ǤJ�ץ�s������!
            }
            if (StringUtils.isBlank(F110Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
            String[] OP_STATUS_Array = { ST_100, ST_200, ST_300, ST_400, ST_420, ST_500, ST_600 };
            if (!ArrayUtils.contains(OP_STATUS_Array, F110Vo.getOP_STATUS())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_009")); //�ץ�@�~�i�צ��~�A���o�P��!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }

        //��s�ץ�i��
        F110Vo.setLST_PROC_DATE(DATE.currentTime());
        F110Vo.setLST_PROC_DIV(user.getOpUnit());
        F110Vo.setLST_PROC_ID(user.getEmpID());
        F110Vo.setOP_STATUS(ST_000); //�P��
        VOTool.update(F110Vo);
        //�f��
        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String COMMENT = "�ץ�P��(" + user.getEmpName() + ")�A�P�׭�]:" + F110Vo.getNULLIFY();
        new RZ_N0Z001().assignOPStatus(F110Vo.getFLOW_NO(), "�P��", COMMENT, ST_000, CHG_ID, CHG_DIV_NO);
        //Ū����µ�ץ�_�Ƨѿ��ɲM��
        if (!ST_1.equals(F110Vo.getAPLY_TP())) {
            EP_Z0F120 theEP_Z0F120 = new EP_Z0F120();
            List<Map> rtnList = theEP_Z0F120.queryF120List(F110Vo.getAPLY_NO(), F110Vo.getSUB_CPY_ID());
            for (Map rtnMap : rtnList) {
                if (StringUtils.isNotBlank(MapUtils.getString(rtnMap, "MEMO_NO"))) {
                    DTEPF120 DTEPF120Vo = VOTool.mapToVO(DTEPF120.class, rtnMap);
                    try {
                        theEP_Z0F120.cancel(DTEPF120Vo, user);
                    } catch (DataNotFoundException dnfe) {
                        log.error("", dnfe);//�������`
                    }
                }
            }
        }
    }

    /**
     * �h�^
     * @param F110Vo
     * @param user
     * @throws ModuleException
     */
    public void back(DTEPF110 F110Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;

        if (F110Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //�ǤJ��µ�ץ󬰪�
        } else {
            if (StringUtils.isBlank(F110Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_004")); //�ǤJ�ץ�s������!
            }
            if (StringUtils.isBlank(F110Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }
        //��s�ץ�i��
        F110Vo.setLST_PROC_DATE(DATE.currentTime());
        F110Vo.setLST_PROC_DIV(user.getOpUnit());
        F110Vo.setLST_PROC_ID(user.getEmpID());
        F110Vo.setOP_STATUS(ST_100); //�߮׫ݰe��
        VOTool.update(F110Vo);
        //�f��
        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        new RZ_N0Z001().assignOPStatus(F110Vo.getFLOW_NO(), "�h�^", "�ץ�h�^�߮׫ݰe��(" + user.getEmpName() + ")", ST_100, CHG_ID, CHG_DIV_NO);

    }

    /**
     * �ק��µ�ץ�_�򥻸����(EPF10101.doUpdate)
     * @param F110Vo
     * @param user
     * @param isChangeAplyTp
     * @param DBF110Map
     * @throws Exception
     */
    public void updateF110(DTEPF110 F110Vo, UserObject user, boolean isChangeAplyTp, Map DBF110Map) throws Exception {
        ErrorInputException eie = null;
        String APLY_TP = "";
        if (F110Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            APLY_TP = F110Vo.getAPLY_TP();
            if (StringUtils.isBlank(APLY_TP)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_006")); //�ǤJ�ץ��������!
            }
            if (StringUtils.isBlank(F110Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_004")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }
        //�d�߭�µ�ץ�_�򥻸��
        String Map_OP_STATUS = MapUtils.getString(DBF110Map, "OP_STATUS");

        String FIX_DIV_ID = MapUtils.getString(DBF110Map, "FIX_DIV_ID");
        boolean isFIX_DIV_ID = StringUtils.equals(user.getEmpID(), FIX_DIV_ID);

        //��s�ץ��ܧ���DTEPF110�G
        DataSet ds = Transaction.getDataSet();
        //150923 �ϥΧO,�O�κ���,���B,�t�ӦW��/id �אּ�ѭ�µ��H���i�ק�,���d���A
        ds.setField("APLY_NO", F110Vo.getAPLY_NO());
        ds.setField("SUB_CPY_ID", F110Vo.getSUB_CPY_ID());
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        setFieldIfExist(ds, F110Vo.getEXP_TP(), "EXP_TP");
        setFieldIfExist(ds, F110Vo.getUSE_TP(), "USE_TP");
        if (ST_1.equals(APLY_TP)) {
            setFieldIfExist(ds, F110Vo.getSUP_ID(), "SUP_ID");
            setFieldIfExist(ds, F110Vo.getSUP_NM(), "SUP_NM");
            if (F110Vo.getCLR_AMT() != null) {
                ds.setField("CLR_AMT", F110Vo.getCLR_AMT());
            }
            if (F110Vo.getACT_AMT() != null) {
                ds.setField("ACT_AMT", F110Vo.getACT_AMT());
            }
        } else {//�s�P�אּ"�@��,����",�ݱNF110�t�����M��
            ds.setField("SUP_ID", null);
            ds.setField("SUP_NM", null);
            ds.setField("CLR_AMT", null);
            ds.setField("ACT_AMT", null);
        }

        String[] can_update_OP_STATUS = FieldOptionList.getName("EP", "BTN_CONTRAL", "F110_UPDATE_STATUS").split(",");
        //150923 ��l���̪��A���� //TODO
        if (ArrayUtils.contains(can_update_OP_STATUS, Map_OP_STATUS) || isChangeAplyTp || isFIX_DIV_ID) {
            log.debug("### update other field,OP_STATUS:" + Map_OP_STATUS);
            /*if (ST_100.equals(Map_OP_STATUS) || isChangeAplyTp || "420".equals(Map_OP_STATUS) || ST_500.equals(Map_OP_STATUS)
                    || ST_600.equals(Map_OP_STATUS)) {*/
            setFieldIfExist(ds, F110Vo.getBLD_CD(), "BLD_CD");
            setFieldIfExist(ds, F110Vo.getBLD_NM(), "BLD_NM");
            setFieldIfExist(ds, F110Vo.getCFM_WORK_MO(), "CFM_WORK_MO");
            setFieldIfExist(ds, F110Vo.getMGR_PPL_MO(), "MGR_PPL_MO");
            setFieldIfExist(ds, F110Vo.getFIX_FILE_NO(), "FIX_FILE_NO");
            setFieldIfExist(ds, F110Vo.getFINAL_FILE_NO(), "FINAL_FILE_NO");
            setFieldIfExist(ds, F110Vo.getBLD_ADDR(), "BLD_ADDR");
            setFieldIfExist(ds, F110Vo.getINPUT_DIV_NO(), "INPUT_DIV_NO");
            if (F110Vo.getINPUT_DATE() != null) {
                ds.setField("INPUT_DATE", F110Vo.getINPUT_DATE());
            }

            setFieldIfExist(ds, F110Vo.getINPUT_ID(), "INPUT_ID");
            if (isChangeAplyTp) {
                setFieldIfExist(ds, APLY_TP, "APLY_TP");
            }
            setFieldIfExist(ds, F110Vo.getCURR(), "CURR");
            setFieldIfExist(ds, F110Vo.getFLOW_NO(), "FLOW_NO");
            //setFieldIfExist(ds, F110Vo.getOP_STATUS(), "OP_STATUS");
            setFieldIfExist(ds, F110Vo.getFIX_MO(), "FIX_MO");
            if (F110Vo.getWAR_MON() != null) {
                ds.setField("WAR_MON", F110Vo.getWAR_MON());
            }

            if (ST_1.equals(APLY_TP)) {
                //�s�P��ϥ����
                /*if (F110Vo.getCLR_AMT() != null) {
                    ds.setField("CLR_AMT", F110Vo.getCLR_AMT());
                }
                if (F110Vo.getACT_AMT() != null) {
                    ds.setField("ACT_AMT", F110Vo.getACT_AMT());
                }*/

                //ds.setField("EXP_TP", ST_1); //150922 �s�P��i�ק�O�κ���
                ds.setField("PRO_OWN", F110Vo.getPRO_OWN());
                if (ST_500.equals(Map_OP_STATUS) || ST_600.equals(Map_OP_STATUS) || ST_700.equals(Map_OP_STATUS)) {
                    ds.setField("INV_NO", F110Vo.getINV_NO());
                }
            } else {
                ds.setField("EST_AMT", F110Vo.getEST_AMT());
                /*if (ST_600.equals(Map_OP_STATUS)) {
                    ds.setField("EXP_TP", F110Vo.getEXP_TP());
                }*/
            }
        }

        //�D�s�P��µ
        if (!"1".equals(APLY_TP)) {
            if ("410".equals(Map_OP_STATUS)) {
                ds.setField("FINAL_FILE_NO", F110Vo.getFINAL_FILE_NO()); //�����ҩ��ɮ׽s��
            }
        }

        DBUtil.executeUpdate(ds, SQL_updateF110_001);

        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String COMMENT;
        if (StringUtils.isNotBlank(F110Vo.getNULLIFY())) {
            //�s�W�f��O��(�ק��])
            COMMENT = "�ץ�ק�(" + user.getEmpName() + ")�A�ק��]:" + F110Vo.getNULLIFY();
        } else {
            COMMENT = "�ץ�ק�(" + user.getEmpName() + ")";
        }
        new RZ_N0Z001().assignOPStatus(F110Vo.getFLOW_NO(), "�ק�", COMMENT, Map_OP_STATUS, CHG_ID, CHG_DIV_NO);

    }

    /**
     * �ק��µ�ץ�_�ק��µ��H��
     * @param reqMap
     * @param user
     * @throws Exception
     */
    public void updateFiXDivID(Map reqMap, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String APLY_TP = "";
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "SUB_CPY_ID"))) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
            }
            APLY_TP = MapUtils.getString(reqMap, "APLY_TP");
            if (StringUtils.isBlank(APLY_TP)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_006")); //�ǤJ�ץ��������!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        setFieldIfExistforMap(ds, reqMap, "APLY_NO");

        // �s�W�m�WFIX_DIV_NM
        String FIX_DIV_ID = MapUtils.getString(reqMap, "FIX_DIV_ID");
        if (StringUtils.isNotBlank(FIX_DIV_ID)) {
            ds.setField("FIX_DIV_ID", FIX_DIV_ID);
            EmployeeDetail ep = new PersonnelData().getByEmployeeID2(FIX_DIV_ID);
            ds.setField("FIX_DIV_NM", ep.getName());
        }

        DBUtil.executeUpdate(ds, SQL_updateFiXDivID_001);

    }

    /**
     * �ק��µ�ץ�_�ק��µ�դH��
     * @param reqMap
     * @param user
     * @throws Exception
     */
    public void updateFiXGroupID(Map reqMap, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = "";
        String APLY_NO = "";
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
            }
            APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_004")); //�ǤJ�ץ�s������!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }

        //�s�W�m�W FIX_GROUP_NM
        String FIX_GROUP_ID = MapUtils.getString(reqMap, "FIX_GROUP_ID");
        String FIX_GROUP_NM = null;
        if (StringUtils.isNotBlank(FIX_GROUP_ID)) {
            FIX_GROUP_NM = MapUtils.getString(new EP_F10310().getEmpMap(FIX_GROUP_ID, true, SUB_CPY_ID), "NAME");
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if (StringUtils.isNotBlank(FIX_GROUP_ID)) {
            ds.setField("FIX_GROUP_ID", FIX_GROUP_ID);
            ds.setField("FIX_GROUP_NM", FIX_GROUP_NM);
        }

        DBUtil.executeUpdate(ds, SQL_updateFiXGroupID_001);

    }

    /**
     * EMAIL�o�e
     * @param TRN_ID  String  ����N��
     * @param ID  String  ����HID
     * @param NAME String  ����H�m�W 
     * @param EMAIL   String  ����HEMAIL
     * @param DIVNO   String  ����H���
     * @param DIVNM   String  ����H���W��
     * @param INFM_CNTN  String  �T�����e
     * @param 
     * @throws ModuleException 
     */
    public void senMail(String TRN_ID, String ID, String NAME, String EMAIL, String DIVNO, String DIVNM, String INFM_CNTN)
            throws IOException, ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(TRN_ID)) {
            eie = getErrorInputException(eie, "EP_Z0F110_MSG_006");//����N�����o���ŭ�!
        }
        if (StringUtils.isBlank(ID)) {
            eie = getErrorInputException(eie, "EP_Z0F110_MSG_009");//����H���o���ŭ�!
        }
        if (StringUtils.isBlank(NAME)) {
            eie = getErrorInputException(eie, "EP_Z0F110_MSG_009");//����H���o���ŭ�!
        }
        if (StringUtils.isBlank(EMAIL)) {
            eie = getErrorInputException(eie, "EP_Z0F110_MSG_007");//EMAIL���o���ŭ�!
        }
        if (StringUtils.isBlank(INFM_CNTN)) {
            eie = getErrorInputException(eie, "EP_Z0F110_MSG_008");//�T�����e���o���ŭ�!
        }

        if (eie != null) {
            throw eie;
        }

        //�]�wMAIL�o�e
        //����̸�T�M��
        List<Map> recipientList = new ArrayList<Map>();
        //����̸�T
        Map map = new HashMap<String, String>();
        //����HID
        map.put("USER_ID", ID);
        //����H�m�W
        map.put("USER_NAME", NAME);
        //����̳��N�� 
        map.put("USER_DIVNO", DIVNO);
        //����̳�줤��
        map.put("USER_DIVNM", DIVNM);
        //����HMAIL
        map.put("USER_EMAIL", EMAIL);
        //map.put("USER_EMAIL", "hardy@cathaylife.com.tw");
        recipientList.add(map);
        String[] fileIDs = {};
        String MSG = new RZ_S00300().createRecord("EP_IB009", "EP", DATE.today(), null, recipientList, null, null, INFM_CNTN, fileIDs);
        if (StringUtils.isNotBlank(MSG)) {
            throw new ModuleException(MSG);
        }
    }

    /**
     * �s�P��µ
     * by i9300622 2015/9/25
     * delete by i9301216 2015/11/10 �L�ϥ�
     * �����禬�h��
     * @param reqMap
     * @param user
     * @param RTN_STS
     * @throws Exception
     */
    /*public void reject(Map reqMap, UserObject user, String RTN_STS) throws Exception {
        ErrorInputException eie = null;
        String APLY_TP = "";
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "SUB_CPY_ID"))) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
            }
            APLY_TP = MapUtils.getString(reqMap, "APLY_TP");
            if (StringUtils.isBlank(APLY_TP)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_006")); //�ǤJ�ץ��������!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (eie != null) {
            throw eie;
        }
        String MGR_PPL_MO = MapUtils.getString(reqMap, "MGR_PPL_MO");
        //�d�߭�µ�ץ�_�򥻸��
        DTEPF110 DBF110Vo = VOTool.mapToVO(DTEPF110.class, this.queryMap(MapUtils.getString(reqMap, "APLY_NO")));

        String RTN_STS_NM = FieldOptionList.getName("EP", "RTN_STS", RTN_STS);
        String comment = MessageUtil.getMessage("EP_Z0F110_MSG_014", new Object[] { RTN_STS_NM, user.getEmpName(), MGR_PPL_MO });
        String empID = user.getEmpID();
        String opUNIT = user.getOpUnit();
        new RZ_N0Z001().assignOPStatus(DBF110Vo.getFLOW_NO(), MessageUtil.getMessage("EP_Z0F110_MSG_015"), comment, RTN_STS, empID, opUNIT);

        DataSet ds = Transaction.getDataSet();
        //��s�ץ��ܧ���DTEPF110�G
        //F110Vo.setOP_STATUS(voDTRZN010.getOP_STATUS());
        ds.setField("OP_STATUS", RTN_STS);
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("APLY_NO", reqMap.get("APLY_NO"));
        ds.setField("SUB_CPY_ID", reqMap.get("SUB_CPY_ID"));
        DBUtil.executeUpdate(ds, SQL_update_001);
    }*/

    /**
     * �d�߷s�W(�s�P)�дڮ־P���
     * @param aplyNoList
     * @param SUB_CPY_ID
     * @param ds
     * @return
     * @throws ModuleException
     */
    public List<Map> qryListForF116(List<String> aplyNoList, String SUB_CPY_ID, DataSet ds) throws ModuleException {
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_TP", "1");//FOR �s�P
        ds.setFieldValues("aplyNoList", aplyNoList);
        return VOTool.findToMaps(ds, SQL_qryListForF116_001);
    }

    /**
     * format �����榡
     * @param rtnMap
     * @param user
     * @return
     */
    public Map doFmtRpt(Map rtnMap, UserObject user) {

        Date INPUT_DATE = DATE.timestampToDate(MapUtils.getString(rtnMap, "INPUT_DATE"));
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        List<Map> rtnList = new ArrayList();
        String USE_TP = MapUtils.getString(rtnMap, "USE_TP");
        rtnMap.put("INPUT_DATE", DATE.toROCFormat(df.format(INPUT_DATE), "/"));
        rtnMap.put("NAME1", "");
        rtnMap.put("NAME2", "");
        if (ST_1.equals(USE_TP)) {//�ۥ�
            rtnMap.put("BLD_USR_NM", rtnMap.get("BLD_NM") + "�޲z�B");
            rtnMap.put("NAME1", rtnMap.get("INPUT_NM"));
        } else {
            rtnMap.put("BLD_USR_NM", rtnMap.get("INPUT_DIV_NM"));
            rtnMap.put("NAME2", rtnMap.get("INPUT_NM"));
        }
        rtnList.add(rtnMap);
        this.convertString(rtnList);
        //�]�w�^�ǭ�
        Map tmpMap = new HashMap();
        Map param = new HashMap();
        param.put("REPORT_ID", "EP_F10101");

        tmpMap.put("params", param);
        tmpMap.put("detail", rtnList);

        return tmpMap;
    }

    /**
     * �C�L�� µ �� �� ��
     * @param reqMap
     * @param resp
     */
    public void prtRpt(Map reqMap, ResponseContext resp) {
        JasperReportUtils.addOutputRptDataToResp("EP_F10101", (Map) reqMap.get("params"), (List) reqMap.get("detail"), resp);
    }

    /**
     * Deliver decimal/int to iReport will cause many problems,
     * so All data will be convert to String.
     * @param rtnMap
     */
    BigDecimal TOTAL_AMT = BigDecimal.ZERO;

    private static final String SQL_updateFiXDivID_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_updateFiXDivID_001";

    private static final String SQL_updateFiXGroupID_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_updateFiXGroupID_001";

    private static final String SQL_qryListForF116_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_qryListForF116_001";

    //    private static final String SQL_update_002 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_update_002";
    //
    //    private static final String SQL_update_003 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_update_003";
    //
    //    private static final String SQL_update_004 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_update_004";

    private static final String SQL_updateExeTp_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_updateExeTp_001";

    private void convertString(List<Map> rptList) {

        for (Map rtnMap : rptList) {
            Iterator it = rtnMap.keySet().iterator();
            while (it.hasNext()) {
                String key = (String) it.next();
                Object obj = rtnMap.get(key);
                if (obj == null) {
                    rtnMap.put(key, "");
                } else {
                    rtnMap.put(key, obj.toString());
                }
            }

        }

    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String value, String key) {

        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldIfExistforMap(DataSet ds, Map tmpMap, String key) {
        String value = MapUtils.getString(tmpMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldIfExistforNULL(DataSet ds, Map tmpMap, String key) {

        if (tmpMap.containsKey(key)) {
            ds.setField(key, null);
        }

    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �h�^���e���d
     * @param F110Vo
     * @param user
     * @param RTN_OP_STATUS
     * 
     */
    public void returnToStatus(Map F110Map, UserObject user, String RTN_OP_STATUS, String RTN_REASON) throws ModuleException {
        if (F110Map == null || F110Map.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F110_MSG_016"));
        }
        ErrorInputException eie = null;
        String APLY_NO = MapUtils.getString(F110Map, "APLY_NO");
        String SUB_CPY_ID = MapUtils.getString(F110Map, "SUB_CPY_ID");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_004"));//�ץ�s������
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (StringUtils.isBlank(RTN_OP_STATUS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_017"));//�h�^�i�פ��i����
        }
        if (eie != null) {
            throw eie;
        }

        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }

        //�Y�w�g�ѭ��T�{��A�R���|���дڮ־P���дک���
        String OP_STATUS = MapUtils.getString(F110Map, "OP_STATUS");
        if ("700".equals(OP_STATUS)) {
            try {
                EP_Z0F160 theEP_Z0F160 = new EP_Z0F160();
                List<Map> listF160 = theEP_Z0F160.qryChkList(APLY_NO, SUB_CPY_ID);
                for (Map f160Map : listF160) {
                    if (f160Map.get("PAY_DATE") == null) {
                        DTEPF160 f160VO = VOTool.mapToVO(DTEPF160.class, f160Map);
                        theEP_Z0F160.delete(f160VO);
                    }
                }
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L�дڮ־P��,�L�ݧR��", dnfe);
            }
        }

        DataSet ds = Transaction.getDataSet();
        //��s�ץ��ܧ���DTEPF110�G
        ds.setField("PRE_OP_STATUS", OP_STATUS);
        ds.setField("OP_STATUS", RTN_OP_STATUS);
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_update_001);

        //�h�^�i�צW��
        String RTN_STATUS_NM = new RZ_N00100().queryStatusNM((EP_Z0F110.ST_1.equals(MapUtils.getString(F110Map, "APLY_TP")) ? "EPF1_0100"
                : "EPF1_0200"), RTN_OP_STATUS);
        //��s�f��i��
        String FLOW_NO = MapUtils.getString(F110Map, "FLOW_NO");//���Ƨѿ����ץ�,flow_no�|���Ƨѿ���
        FLOW_NO = FLOW_NO.split(",")[0];
        StringBuffer COMMENT = new StringBuffer();
        new RZ_N0Z001().assignOPStatus(FLOW_NO, "�h�^", COMMENT.append("�ץ�h�^:").append(RTN_STATUS_NM).append("(").append(RTN_REASON).append(
            ")").append("(").append(user.getEmpName()).append(")").toString(), RTN_OP_STATUS, CHG_ID, CHG_DIV_NO);

    }

    /**
     * ��µ�ץ�i��
     * @param F110Vo
     * @param user
     * @param RTN_OP_STATUS
     * 
     */
    /*public void approveApply(Map F110Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String APLY_TP = null;
        if (F110Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            if (StringUtils.isBlank(MapUtils.getString(F110Vo, "SUB_CPY_ID"))) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
            }
            APLY_TP = MapUtils.getString(F110Vo, "APLY_TP");
            if (StringUtils.isBlank(APLY_TP)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_006")); //�ǤJ�ץ��������!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007"));//�ǤJ�ϥΪ̸�T����! 
        }
        if (eie != null) {
            throw eie;
        }

        //�d�߭�µ�ץ�_�򥻸��
        String PRE_OP_STATUS = MapUtils.getString(F110Vo, "PRE_OP_STATUS");
        String FLOW_NO = null;
        String NEW_STATUS = null;

        if (StringUtils.isNotBlank(PRE_OP_STATUS)) {
            String RTN_STATUS_NM = new RZ_N00100().queryStatusNM("EPF1_0200", PRE_OP_STATUS);

            //��s�f��i��
            FLOW_NO = MapUtils.getString(F110Vo, "FLOW_NO");
            new RZ_N0Z001().assignOPStatus(FLOW_NO, "���e", "�ץ�^�_��" + RTN_STATUS_NM, PRE_OP_STATUS, user);
            NEW_STATUS = PRE_OP_STATUS;
        } else {

            F110Vo = this.queryMap(MapUtils.getString(F110Vo, "APLY_NO"));
            FLOW_NO = MapUtils.getString(F110Vo, "FLOW_NO");
            new RZ_N0Z001().approveFlow(FLOW_NO, null, null, user);

            DTRZN010 voDTRZN010 = new DTRZN010();
            voDTRZN010.setFLOW_NO(FLOW_NO);
            voDTRZN010 = new RZ_N00100().queryDTRZN010(voDTRZN010).get(0);
            NEW_STATUS = voDTRZN010.getOP_STATUS();
        }

        //�s�P��µ�ץ�A�дڤ��T�{��A�t�β����禬�q����B�дڥӽЪ�
        if ("600".equals(NEW_STATUS) && "1".equals(APLY_TP)) {

            String SUB_CPY_ID = MapUtils.getString(F110Vo, "SUB_CPY_ID");

            //�R���� �禬�q����P�дڥӽЪ�
            String NTFY_FILE_NO = MapUtils.getString(F110Vo, "NTFY_FILE_NO");
            if (StringUtils.isNotBlank(NTFY_FILE_NO)) {
                // �R�� ���禬�q���ɮ׽s��
                deleteFileNo(SUB_CPY_ID, NTFY_FILE_NO);
            }

            //�����禬�q���� 
            NTFY_FILE_NO = createUploadPDF(F110Vo, user, "1");
            F110Vo.put("NTFY_FILE_NO", NTFY_FILE_NO);

            String APLY_FILE_NO = MapUtils.getString(F110Vo, "APLY_FILE_NO");
            if (StringUtils.isNotBlank(APLY_FILE_NO)) {
                // �u�{�дڥӽ��ɮ׽s��
                deleteFileNo(SUB_CPY_ID, APLY_FILE_NO);
            }
            //���ͤu�{�дڥӽЪ�
            APLY_FILE_NO = createUploadPDF(F110Vo, user, "2");
            F110Vo.put("APLY_FILE_NO", APLY_FILE_NO);
        }

        DataSet ds = Transaction.getDataSet();
        Timestamp currentDate = DATE.currentTime();
        //�]�w�i�פ���ɶ�
        if ("200".equals(NEW_STATUS)) { //�ݬ���(��µ��)
            ds.setField("SUB_USR_DATE", currentDate); //�����禬�ɶ�
            ds.setField("INPUT_NM", user.getEmpName());
            ds.setField("INPUT_DIV_NM", this.getFixDivName(user.getOpUnit()));
        } else if ("500".equals(NEW_STATUS)) { //��µ�쬣��A�ݽдڤ��T�{ 
            ds.setField("INFM_CONS_DATE", currentDate); //�q���I�u���
            ds.setField("DIV_CFM_DATE", currentDate); //�D��ñ�֤��
        } else if ("600".equals(NEW_STATUS)) { //�ݮѭ��T�{ 
            ds.setField("FIX_FINAL_DATE", currentDate); //���u�ɶ�
        } else if ("700".equals(NEW_STATUS)) { //�ݵ����k��
            ds.setField("USR_FINAL_DATE", currentDate); //�����禬�ɶ�
        } else if ("800".equals(NEW_STATUS)) { //�w�����k��
            ds.setField("END_APLY_DATE", currentDate); //�����k�ɮɶ�
        }

        ds.setField("OP_STATUS", NEW_STATUS); //�@�~�i��
        ds.setField("LST_PROC_DATE", currentDate); //�@�~�ɶ�
        ds.setField("LST_PROC_ID", user.getEmpID()); //�@�~�H��
        ds.setField("LST_PROC_DIV", user.getOpUnit()); //�@�~���
        ds.setField("LST_PROC_NM", user.getEmpName()); //�@�~�H���m�W

        DBUtil.executeUpdate(ds, SQL_update_003);

    }*/

    /**
     * �R����µ�ץ��ɮ׽s��
     * @param SUB_CPY_ID
     * @param errMsg
     * @return 
     * @throws SQLException 
     * @throws ModuleException 
     */
    public void deleteFileNo(String SUB_CPY_ID, String FILE_NO, UserObject user) throws ModuleException, SQLException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
        }
        if (StringUtils.isBlank(FILE_NO)) {
            eie = this.getErrorInputException(eie, "�ɮ׽s������!");
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }

        //�R�����ץ��ɮ�
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("FILE_NO", FILE_NO);
        List<Map> fileList = new EP_Z00010().queryList(reqMap); //Ū���ɮװ򥻸���ɲM��
        EP_Z00010 theEP_Z00010 = new EP_Z00010();
        for (Map tmpMap : fileList) {
            DTEPZ003 voDTEPZ003 = VOTool.mapToVO(DTEPZ003.class, tmpMap);
            theEP_Z00010.delete(voDTEPZ003, user);
        }
    }

    /**
     * ����PDF�ɤW��
     * @param F110Map
     * @param user
     * @param REPORT_TP
     * @return 
     * @throws Exception 
     */
    public String createUploadPDF(Map F110Map, UserObject user, String REPORT_TP, ResponseContext resp, RequestContext req)
            throws Exception {

        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (F110Map == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            if (StringUtils.isBlank(REPORT_TP)) {
                eie = this.getErrorInputException(eie, "������������");
            } else if (!"1".equals(REPORT_TP) && !"2".equals(REPORT_TP)) {
                eie = this.getErrorInputException(eie, "������������  1:�禬�q����B2:�дڥӽЪ�");
            }
            SUB_CPY_ID = MapUtils.getString(F110Map, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }

        Map parmMap = new HashMap();

        //�����禬�q����
        String NTFY_FILE_NO = MapUtils.getString(F110Map, "NTFY_FILE_NO");
        //�禬�q���ɮ׽s��
        if ("1".equals(REPORT_TP) && StringUtils.isNotBlank(NTFY_FILE_NO)) {
            deleteFileNo(SUB_CPY_ID, NTFY_FILE_NO, user);
        }
        //�u�{�дڥӽ��ɮ׽s��
        String APLY_FILE_NO = MapUtils.getString(F110Map, "APLY_FILE_NO");
        if ("2".equals(REPORT_TP) && StringUtils.isNotBlank(APLY_FILE_NO)) {
            deleteFileNo(SUB_CPY_ID, APLY_FILE_NO, user);
        }

        parmMap.putAll(F110Map);
        parmMap.put("REPORT_TP", REPORT_TP);
        List rptList = new ArrayList();
        rptList.add(F110Map);

        //����PDF������
        FileItem fi = new EP_F10300().printRent(rptList, user, parmMap, resp, req, false);

        String RPT_NM = FieldOptionList.getName("EP", "REPORT_TP", REPORT_TP);

        /*
        //�W��PDF��
        DTEPZ003 voEPZ003 = new DTEPZ003();
        voEPZ003.setFILE_NO(""); //�ɮ׽s��
        voEPZ003.setFILE_NM(new StringBuilder().append(MapUtils.getString(F110Map, "APLY_NO")).append("_").append(REPORT_TP).toString());//�ɮצW��
        voEPZ003.setFILE_KIND("pdf"); //�ɮ׺���
        voEPZ003.setFILE_REMARK(RPT_NM);
        voEPZ003.setSUB_CPY_ID(SUB_CPY_ID);//�����q�O
        voEPZ003.setINS_DT(DATE.currentTime()); //��J���
        voEPZ003.setINS_ID(user.getEmpID()); //��J�H��
        voEPZ003.setINS_DIVNO(user.getOpUnit()); //��J���

        String FILE_NO = new EP_Z00010().insert(voEPZ003, fi);

        //��s��µ�ץ�
        DataSet ds = Transaction.getDataSet();
        if ("1".equals(REPORT_TP)) {
            ds.setField("NTFY_FILE_NO", FILE_NO); //�禬�q���ɮ׽s��
        } else if ("2".equals(REPORT_TP)) {
            ds.setField("APLY_FILE_NO", FILE_NO);//�u�{�дڥӽ��ɮ׽s��
        }

        //��s�ץ��ܧ���DTEPF110�G
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("LST_PROC_NM", user.getEmpName());
        ds.setField("APLY_NO", F110Map.get("APLY_NO"));
        ds.setField("SUB_CPY_ID", F110Map.get("SUB_CPY_ID"));
        DBUtil.executeUpdate(ds, SQL_update_001);
        */
        return null;

    }

    /**
     * �d�߭�µ�Ӻ޳��W��
     * @param divNo
     * @return
     * @throws ModuleException 
     * @throws SQLException 
     */
    public String getFixDivName(String divNo, String SUB_CPY_ID) throws ModuleException, SQLException {

        if (StringUtils.isNotBlank(divNo)) {
            if (divNo.startsWith("EP")) {
                //�z�L�M��ӺޤW�Ǹ�ƨ��o���W��
                return new EP_Z00100().getDivName(divNo, SUB_CPY_ID);
            } else {
                //�z�L�j�Ӧ@�μҲը��o���γ��W��(�� cached�B�z)
                return new EP_A10010().getDivName(divNo, SUB_CPY_ID);
            }

        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F110_MSG_021"));//���N�����i����
        }

    }

    /**
     * �ק�O�κ���
     * @param F110Vo
     * @param expTp
     * @param user
     * @throws ModuleException 
     */
    public void updateExeTp(Map F110Map, String expTP, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String APLY_NO = null;
        if (F110Map == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        } else {
            SUB_CPY_ID = MapUtils.getString(F110Map, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
            }
            APLY_NO = MapUtils.getString(F110Map, "APLY_NO");
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_004"));//�ץ�s������
            }
        }
        if (StringUtils.isBlank(expTP)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_041")); //�ǤJ�O�κ�������!
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_007")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }

        // ��s�O�κ���
        DataSet ds = Transaction.getDataSet();
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("EXP_TP", expTP);

        DBUtil.executeUpdate(ds, SQL_updateExeTp_001);
    }

    /**
     * ���o�Ƨѿ��h�^���d�U�Կ��
     * @param APLY_TP
     * @param OP_STATUS
     * @return
     * @throws ModuleException
     */
    public List<Map> getBackStatus(String APLY_TP, String OP_STATUS, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_TP)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
        }
        if (StringUtils.isBlank(OP_STATUS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_004"));//�ץ�s������
        }
        if (eie != null) {
            throw eie;
        }

        DTRZN001 vo = new DTRZN001();
        if ("1".equals(APLY_TP)) {
            //�@��I�u�Ƨѿ��y�{
            vo.setFLOW_TYPE("EPF1_0100");
        } else {
            //����I�u�Ƨѿ��y�{
            vo.setFLOW_TYPE("EPF1_0200");
        }
        List<DTRZN001> n001List = new RZ_N00100().queryDTRZN001(vo);
        BigDecimal chkSerNo = BigDecimal.ZERO;
        for (DTRZN001 n001 : n001List) {
            if (n001.getOP_STATUS().equals(OP_STATUS)) {
                chkSerNo = n001.getSER_NO();
                break;
            }
        }
        boolean isNotFixDiv = !user.getRoles().containsKey("RLEP014");//�D��µ��H��>>�h�^���Alist�L�o����µ�쪬�A

        //�v���P�_�A�C�X�f�媬�A�b�ץ󪬺A���e��
        List<Map> rntStsList = new ArrayList<Map>();
        Map opStats_NotFixDiv = FieldOptionList.getFieldOptions("EP", "OP_STATUS_NOT_FIXDIV_F110");
        for (DTRZN001 n001 : n001List) {
            if (n001.getSER_NO().equals(BigDecimal.ZERO)) {
                continue;
            }

            //�D��µ��A��ܯS�w���A
            if ((isNotFixDiv && opStats_NotFixDiv.containsKey(n001.getOP_STATUS())) || !isNotFixDiv) {
                if (n001.getSER_NO().compareTo(chkSerNo) < 0) {
                    Map<String, String> rtnMap = new HashMap<String, String>();
                    rtnMap.put("OPSTATUS_FROM", n001.getOP_STATUS());
                    rtnMap.put("STATUS_NM", n001.getOP_STATUS_NM());

                    rntStsList.add(rtnMap);
                }
            }
        }

        return rntStsList;
    }

    //TODO ��޶O�s�W��k====start====

    private static final String SQL_queryByCMM_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_queryByCMM_001";

    private static final String SQL_updateCMM_APLY_NO_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_updateCMM_APLY_NO_001";

    private static final String SQL_queryByCMMDATE_001 = "com.cathay.ep.z0.module.EP_Z0F110.SQL_queryByCMMDATE_001";

    /**
     * �d����޶O�뵲�ץ�
     * @param SUB_CPY_ID �����q�O
     * @param START_CMM_DATE �ѥN�X�]�w
     */
    public List<Map> queryByCMM(String SUB_CPY_ID, String CMM_APLY_NO) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (StringUtils.isBlank(CMM_APLY_NO)) {
            String START_CMM_DATE = FieldOptionList.getName("EP", "CMM_SET", "START_DATE");
            //�s�P,�X��,�w����,����޶O�뵲,�߮פ�>=START_CMM_DATE
            ds.setField("START_CMM_DATE", START_CMM_DATE);
        } else {
            ds.setField("CMM_APLY_NO", CMM_APLY_NO);
        }
        return VOTool.findToMaps(ds, SQL_queryByCMM_001);
    }

    /**
     * �d����޶O���뵲�ץ�
     * @param SUB_CPY_ID �����q�O
     * @param START_CMM_DATE �ѥN�X�]�w
     */
    public List<Map> queryByCMMDATE(String SUB_CPY_ID, String DATES, String DATEE) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F110_MSG_005")); //�ǤJ�����q�O����!
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        String START_CMM_DATE = FieldOptionList.getName("EP", "CMM_SET", "START_DATE");
        //�s�P,�X��,�w����,����޶O�뵲,�߮פ�>=START_CMM_DATE
        ds.setField("START_CMM_DATE", START_CMM_DATE);
        ds.setField("DATES", DATES);
        ds.setField("DATEE", DATEE);

        return VOTool.findToMaps(ds, SQL_queryByCMMDATE_001);
    }

    /**
     * ��s��޶O�뵲���A
     * @param F110List ��µ�ץ�
     * @param CMM_APLY_NO ��ޤ뵲�s��
     * @param user �ϥΪ̸�T
     * @throws ModuleException 
     * @throws DBException 
     */
    public void updateCMM_APLY_NO(List<Map> F110List, String CMM_APLY_NO, UserObject user) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (F110List == null || F110List.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F110_MSG_001")); //��µ�ץ󬰪�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (eie != null) {
            throw eie;
        }

        Timestamp LST_PROC_DATE = DATE.currentTime();
        String LST_PROC_ID = user.getEmpID();
        String LST_PROC_DIV = user.getOpUnit();

        DataSet ds = Transaction.getDataSet();
        for (Map F110Map : F110List) {
            ds.clear();
            ds.setField("CMM_APLY_NO", CMM_APLY_NO);//CMM_APLY_NO = null ����
            ds.setField("LST_PROC_DATE", LST_PROC_DATE);
            ds.setField("LST_PROC_ID", LST_PROC_ID);
            ds.setField("LST_PROC_DIV", LST_PROC_DIV);
            ds.setField("SUB_CPY_ID", MapUtils.getString(F110Map, "SUB_CPY_ID"));
            ds.setField("APLY_NO", MapUtils.getString(F110Map, "APLY_NO"));

            DBUtil.executeUpdate(ds, SQL_updateCMM_APLY_NO_001);
        }
    }
    //TODO ��޶O�s�W��k====end====
}
