package com.cathay.ep.z0.module;

import java.sql.SQLException;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPZ003;
import com.cathay.rz.t0.module.RZ_T0Z001;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE    Description Author
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �o���ɺ��@�Ҳ�
 * �Ҳ�ID    EP_Z0C202
 * ���n����    �o���ɺ��@�Ҳ�
 * </pre>
 * @author ����[
 * @since 2015/4/23
 */
@SuppressWarnings("unchecked")
public class EP_Z0Z003 {

    private static final Logger log = Logger.getLogger(EP_Z0Z003.class);

    private static final String SQL_update_001 = "com.cathay.ep.z0.module.EP_Z0Z003.SQL_update_001";

    private static final String SQL_query_001 = "com.cathay.ep.z0.module.EP_Z0Z003.SQL_query_001";

    /**
     * Ū���ɮװ򥻸����
     * @param reqMap
     *              <pre>
     *              FILE_NO = �ɮ׽s��
     *              FILE_NM = �ɮצW��
     *              FILE_VER = �ɮת���
     *              </pre>
     * @return tnMap  Map �ɮװ򥻸����
     */
    public DTEPZ003 queryMaxVerFileNo(String FILE_NO, String SUB_CPY_ID) throws ModuleException, SQLException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(FILE_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z003_MSG_001"));//�ɮ׽s�����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("FILE_NO", FILE_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DTEPZ003 voZ003 = VOTool.findOneToVO(DTEPZ003.class, ds, SQL_query_001);
        return voZ003;
    }

    /**
     * �ק��ɮװ򥻸����
     * @param EPZ003Vo  DTEPZ003    �ɮװ򥻸����
     * @param UPD_TYP   String      �ɮת�����s
     * @param fileItem  FileItem
     */
    public void updateByFileNo(String FILE_NO, DTEPZ003 inputZ003Vo, UserObject user, FileItem fileItem) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(FILE_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z003_MSG_001"));//�ɮ׽s�����o���ŭ�
        }

        if (inputZ003Vo == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z003_MSG_002"));//�ɮװ򥻸���ɤ��o����
        }
        String FILE_NM = inputZ003Vo.getFILE_NM();
        if (StringUtils.isBlank(FILE_NM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z003_MSG_003"));//�ɮצW�٤��o���ŭ�
        }
        String SUB_CPY_ID = inputZ003Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z003_MSG_004"));//��J�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DTEPZ003 voMaxVer = queryMaxVerFileNo(FILE_NO, SUB_CPY_ID);
        RZ_T0Z001 theRZ_T0Z001 = new RZ_T0Z001();
        //��s
        if (fileItem != null) {
            //��s�ɮ�
            //�R������y�������ɮ�
            theRZ_T0Z001.removeFile(voMaxVer.getFILE_ID());
            //�ɮפW�Ǩè��o����y����FILE_ID
            String FILE_ID = theRZ_T0Z001.uploadFile(voMaxVer.getFILE_NO(), "EP", "EP_Z00010", voMaxVer.getINS_ID(), voMaxVer
                    .getFILE_REMARK(), fileItem);
            //��s����y����FILE_ID
            inputZ003Vo.setFILE_ID(FILE_ID);
        }
        //�ק��ɮװ򥻸���� DTEPZ003�G

        DataSet ds = Transaction.getDataSet();

        ds.setField("FILE_NO", FILE_NO);
        ds.setField("FILE_NM", inputZ003Vo.getFILE_NM());
        ds.setField("FILE_VER", voMaxVer.getFILE_VER());
        ds.setField("FILE_KIND", inputZ003Vo.getFILE_KIND());
        ds.setField("FILE_REMARK", inputZ003Vo.getFILE_REMARK());
        ds.setField("FILE_ID", inputZ003Vo.getFILE_ID());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INS_ID", user.getEmpID()); //�@�~�B�z�H��ID
        ds.setField("INS_DIVNO", user.getOpUnit()); //�@�~�B�z���
        ds.setField("INS_DT", DATE.getDBTimeStamp()); //�@�~�B�z�ɶ�

        try {
            DBUtil.executeUpdate(ds, SQL_update_001);
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0Z003_MSG_005"));//��s�W���ɮ׸�ƿ��~
        }

    }

    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
