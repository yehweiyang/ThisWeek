package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE        Description Author
 * 2020/04/24  Created     ���f��
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �w�s��ޱ������@�Ҳ�
 * �Ҳ�ID    EP_Z0H121
 * ���n����    �w�s��ޱ������@�Ҳ�
 * </pre>
 * @author ���f��
 * @since  2020-04-24
 *
 */
@SuppressWarnings("rawtypes")
public class EP_Z0H121 {

    private static final String SQL_insertExpRecord_001 = "com.cathay.ep.z0.module.EP_Z0H121.SQL_insertExpRecord_001";

    /**
     * �s�W�w�s��������
     * @param TRD_NO
     * @param reqMapC
     * @param user
     * @throws ModuleException
     */
    public void insertExpRecord(String TRD_NO, Map reqMapC, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(TRD_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H121_MSG_001"));//�����s�����i����
        }
        if (reqMapC == null || reqMapC.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_002"));//�w�s���Ƥ��i����
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_003"));//�ϥΪ̸�T���i����
        }
        if (eie != null) {
            throw eie;
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMapC, "EXP_TRD_KD"))) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_004"));//�������������i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMapC, "EXP_ACC_AMT"))) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_005"));//����J�b�`���B���i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMapC, "EXP_ACC_DATE"))) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_006"));//����J�b������i����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        VOTool.mapToDataSet(reqMapC, ds);
        ds.setField("TRD_NO", TRD_NO);
        ds.setField("EXT_AMT", STRING.objToBigDecimal(reqMapC.get("EXT_AMT"), BigDecimal.ZERO));
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        ds.setField("CHG_DIV_NO", user.getDivNo());
        DBUtil.executeUpdate(ds, SQL_insertExpRecord_001);
    }

    /**
     * ����~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
