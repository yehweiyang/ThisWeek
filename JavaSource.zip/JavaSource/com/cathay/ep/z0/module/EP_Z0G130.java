package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.jsoup.helper.StringUtil;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * ���ʤ��         ����  ���ʻ���    ���ʤH��    �߮׳渹
 * 2020/03/13     1.0    Created      ������    200226001085
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��a�b���������@�Ҳ�
 * �Ҳ�ID    EP_Z0G130
 * ���n����    ��a�b���������@�Ҳ�
 *
 * �G�B�ϥ��ɮסG
 * ����  ���廡��                                 �ɮצW��        �d��  �s�W  �ק�  �R��
 * 1.      ��a�b��������                      DTEPG130        ��       ��      ��      ��
 * 2.      ��a�b����������LOG��     DTEPG130_LOG    ��       ��      ��      ��
 * 
 * </pre>
 * @author ���R��
 * @since 2020/03/19
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class EP_Z0G130 {

    private static final Logger log = Logger.getLogger(EP_Z0G130.class);

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0G130.SQL_queryMap_001";

    private static final String SQL_insertG130_001 = "com.cathay.ep.z0.module.EP_Z0G130.SQL_insertG130_001";

    private static final String SQL_updateG130_001 = "com.cathay.ep.z0.module.EP_Z0G130.SQL_updateG130_001";

    private static final String SQL_deleteG130_001 = "com.cathay.ep.z0.module.EP_Z0G130.SQL_deleteG130_001";

    private static final String SQL_queryLogMap_001 = "com.cathay.ep.z0.module.EP_Z0G130.SQL_queryLogMap_001";

    private static final String SQL_insertLog_001 = "com.cathay.ep.z0.module.EP_Z0G130.SQL_insertLog_001";

    private static final String SQL_deleteLog_001 = "com.cathay.ep.z0.module.EP_Z0G130.SQL_deleteLog_001";

    /**
     *  Ū����a�b�����������
     * @param reqMap
     * @return rtnMap
     * @throws ModuleException 
     */
    public Map queryMap(Map reqMap) throws ModuleException {

        if (null == reqMap || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G130_MSG_001")); // �ǤJ��T���o���ŭ�
        }

        ErrorInputException eie = null;

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");

        if (StringUtil.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_002"); // �ǤJ�����q���o���ŭ�!
        }
        if (StringUtil.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_003"); // �ǤJ��a�N�����o���ŭ�!
        }
        if (null != eie) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);

        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001);

        return rtnMap;
    }

    /**
     *  �ק��a�b������
     * @param G130Map
     * @throws ModuleException 
     */
    private void updateG130(Map G130Map) throws ModuleException {

        ErrorInputException eie = null;

        String SUB_CPY_ID = MapUtils.getString(G130Map, "SUB_CPY_ID");
        String BASE_CD = MapUtils.getString(G130Map, "BASE_CD");

        if (StringUtil.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_002"); // �ǤJ�����q���o���ŭ�!
        }
        if (StringUtil.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_003"); // �ǤJ��a�N�����o���ŭ�!
        }
        if (null != eie) {
            throw eie;
        }
        
        DataSet ds = Transaction.getDataSet();
        ds.setField("IFRS_INV_RT", G130Map.get("IFRS_INV_RT"));

        ds.setField("BLD_COST", G130Map.get("BLD_COST"));
        ds.setField("BLD_COST_INV", G130Map.get("BLD_COST_INV"));
        ds.setField("BLD_COST_SLF", G130Map.get("BLD_COST_SLF"));

        ds.setField("LND_COST", G130Map.get("LND_COST"));
        ds.setField("LND_COST_INV", G130Map.get("LND_COST_INV"));
        ds.setField("LND_COST_SLF", G130Map.get("LND_COST_SLF"));

        ds.setField("BLD_LOSS", G130Map.get("BLD_LOSS"));
        ds.setField("BLD_LOSS_INV", G130Map.get("BLD_LOSS_INV"));
        ds.setField("BLD_LOSS_SLF", G130Map.get("BLD_LOSS_SLF"));

        ds.setField("LND_LOSS", G130Map.get("LND_LOSS"));
        ds.setField("LND_LOSS_INV", G130Map.get("LND_LOSS_INV"));
        ds.setField("LND_LOSS_SLF", G130Map.get("LND_LOSS_SLF"));

        ds.setField("BLD_IFRS_COST", G130Map.get("BLD_IFRS_COST"));
        ds.setField("BLD_IFRS_INV", G130Map.get("BLD_IFRS_INV"));
        ds.setField("BLD_IFRS_SLF", G130Map.get("BLD_IFRS_SLF"));

        ds.setField("LND_IFRS_COST", G130Map.get("LND_IFRS_COST"));
        ds.setField("LND_IFRS_INV", G130Map.get("LND_IFRS_INV"));
        ds.setField("LND_IFRS_SLF", G130Map.get("LND_IFRS_SLF"));

        ds.setField("APLY_NO", G130Map.get("APLY_NO"));
        ds.setField("LND_AREA", G130Map.get("LND_AREA"));
        ds.setField("BLD_AREA", G130Map.get("BLD_AREA"));

        ds.setField("CHG_DATE", G130Map.get("CHG_DATE"));
        ds.setField("CHG_DIV_NO", G130Map.get("CHG_DIV_NO"));
        ds.setField("CHG_ID", G130Map.get("CHG_ID"));
        ds.setField("CHG_NAME", G130Map.get("CHG_NAME"));

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);

        DBUtil.executeUpdate(ds, SQL_updateG130_001);
    }

    /**
     * �s�W��a�b��������
     * @param mapG130
     * @param user
     * @throws ModuleException 
     */
    private void insertG130(Map mapG130, UserObject user) throws ModuleException {

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", mapG130.get("SUB_CPY_ID"));
        ds.setField("BASE_CD", mapG130.get("BASE_CD"));
        ds.setField("IFRS_INV_RT", mapG130.get("IFRS_INV_RT"));

        ds.setField("BLD_COST", mapG130.get("BLD_COST"));
        ds.setField("BLD_COST_INV", mapG130.get("BLD_COST_INV"));
        ds.setField("BLD_COST_SLF", mapG130.get("BLD_COST_SLF"));

        ds.setField("LND_COST", mapG130.get("LND_COST"));
        ds.setField("LND_COST_INV", mapG130.get("LND_COST_INV"));
        ds.setField("LND_COST_SLF", mapG130.get("LND_COST_SLF"));

        ds.setField("BLD_LOSS", mapG130.get("BLD_LOSS"));
        ds.setField("BLD_LOSS_INV", mapG130.get("BLD_LOSS_INV"));
        ds.setField("BLD_LOSS_SLF", mapG130.get("BLD_LOSS_SLF"));

        ds.setField("LND_LOSS", mapG130.get("LND_LOSS"));
        ds.setField("LND_LOSS_INV", mapG130.get("LND_LOSS_INV"));
        ds.setField("LND_LOSS_SLF", mapG130.get("LND_LOSS_SLF"));

        ds.setField("BLD_IFRS_COST", mapG130.get("BLD_IFRS_COST"));
        ds.setField("BLD_IFRS_INV", mapG130.get("BLD_IFRS_INV"));
        ds.setField("BLD_IFRS_SLF", mapG130.get("BLD_IFRS_SLF"));

        ds.setField("LND_IFRS_COST", mapG130.get("LND_IFRS_COST"));
        ds.setField("LND_IFRS_INV", mapG130.get("LND_IFRS_INV"));
        ds.setField("LND_IFRS_SLF", mapG130.get("LND_IFRS_SLF"));

        ds.setField("APLY_NO", mapG130.get("APLY_NO"));
        ds.setField("LND_AREA", mapG130.get("LND_AREA"));
        ds.setField("BLD_AREA", mapG130.get("BLD_AREA"));

        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());

        DBUtil.executeUpdate(ds, SQL_insertG130_001);
    }

    /**
     * �R����a�b��������
     * @param mapG130
     * @throws ModuleException 
     */
    private void deleteG130(Map mapG130) throws ModuleException {

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", mapG130.get("SUB_CPY_ID"));
        ds.setField("BASE_CD", mapG130.get("BASE_CD"));

        DBUtil.executeUpdate(ds, SQL_deleteG130_001);
    }

    /**
     * �d�߰�a�b����������LOG
     * @param reqMap
     * @return rtnMap
     * @throws ModuleException 
     */
    public Map queryLogMap(Map reqMap) throws ModuleException {

        if (null == reqMap || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G130_MSG_001")); // �ǤJ��T���o���ŭ�
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        String UPD_APLY_NO = MapUtils.getString(reqMap, "APLY_NO");

        if (StringUtil.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_002"); // �ǤJ�����q���o���ŭ�!
        }
        if (StringUtil.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_003"); // �ǤJ��a�N�����o���ŭ�!
        }
        if (StringUtil.isBlank(UPD_APLY_NO)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_005"); // ���ʥ���s�����o����
        }
        if (null != eie) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("UPD_APLY_NO", UPD_APLY_NO);

        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryLogMap_001);

        return rtnMap;
    }

    /**
     * �s�W�b����������LOG��
     * @param mapG130
     * @param user
     * @throws ModuleException 
     */
    private void insertLog(Map mapG130) throws ModuleException {

        String SUB_CPY_ID = MapUtils.getString(mapG130, "SUB_CPY_ID");
        String BASE_CD = MapUtils.getString(mapG130, "BASE_CD");
        String UPD_APLY_NO = MapUtils.getString(mapG130, "UPD_APLY_NO");

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("UPD_APLY_NO", UPD_APLY_NO);
        ds.setField("IFRS_INV_RT", mapG130.get("IFRS_INV_RT"));
        ds.setField("BLD_COST", mapG130.get("BLD_COST"));

        ds.setField("BLD_COST_INV", mapG130.get("BLD_COST_INV"));
        ds.setField("BLD_COST_SLF", mapG130.get("BLD_COST_SLF"));
        ds.setField("LND_COST", mapG130.get("LND_COST"));
        ds.setField("LND_COST_INV", mapG130.get("LND_COST_INV"));
        ds.setField("LND_COST_SLF", mapG130.get("LND_COST_SLF"));

        ds.setField("BLD_LOSS", mapG130.get("BLD_LOSS"));
        ds.setField("BLD_LOSS_INV", mapG130.get("BLD_LOSS_INV"));
        ds.setField("BLD_LOSS_SLF", mapG130.get("BLD_LOSS_SLF"));
        ds.setField("LND_LOSS", mapG130.get("LND_LOSS"));
        ds.setField("LND_LOSS_INV", mapG130.get("LND_LOSS_INV"));

        ds.setField("LND_LOSS_SLF", mapG130.get("LND_LOSS_SLF"));
        ds.setField("BLD_IFRS_COST", mapG130.get("BLD_IFRS_COST"));
        ds.setField("BLD_IFRS_INV", mapG130.get("BLD_IFRS_INV"));
        ds.setField("BLD_IFRS_SLF", mapG130.get("BLD_IFRS_SLF"));
        ds.setField("LND_IFRS_COST", mapG130.get("LND_IFRS_COST"));

        ds.setField("LND_IFRS_INV", mapG130.get("LND_IFRS_INV"));
        ds.setField("LND_IFRS_SLF", mapG130.get("LND_IFRS_SLF"));
        ds.setField("APLY_NO", mapG130.get("APLY_NO"));
        ds.setField("LND_AREA", mapG130.get("LND_AREA"));
        ds.setField("BLD_AREA", mapG130.get("BLD_AREA"));

        ds.setField("CHG_DATE", mapG130.get("CHG_DATE"));
        ds.setField("CHG_DIV_NO", mapG130.get("CHG_DIV_NO"));
        ds.setField("CHG_ID", mapG130.get("CHG_ID"));
        ds.setField("CHG_NAME", mapG130.get("CHG_NAME"));

        DBUtil.executeUpdate(ds, SQL_insertLog_001);
    }

    /**
     * �R���b����������LOG��
     * @param mapLog
     * @throws ModuleException 
     */
    private void deleteLog(Map mapLog) throws ModuleException {

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", mapLog.get("SUB_CPY_ID"));
        ds.setField("BASE_CD", mapLog.get("BASE_CD"));
        ds.setField("UPD_APLY_NO", mapLog.get("UPD_APLY_NO"));

        DBUtil.executeUpdate(ds, SQL_deleteLog_001);
    }

    /**
     * �T�{�b�������������
     * @param mapG211
     * @param user
     * @throws ModuleException 
     */
    public void confirmRecord(Map mapG211, UserObject user) throws ModuleException {

        ErrorInputException eie = null;

        if (null == mapG211 || mapG211.isEmpty()) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_001"); // �ǤJ��T���o���ŭ�
        }
        if (null == user) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_004"); // �ǤJ�H�����o����
        }
        if (null != eie) {
            throw eie;
        }

        String SUB_CPY_ID = MapUtils.getString(mapG211, "SUB_CPY_ID");
        String BASE_CD = MapUtils.getString(mapG211, "BASE_CD");
        String APLY_NO = MapUtils.getString(mapG211, "APLY_NO");

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_002"); // �ǤJ�����q���o���ŭ�!
        }
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_003"); // �ǤJ��a�N�����o���ŭ�!
        }
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_006"); // �ǤJ����s�����o���ŭ�!
        }
        if (null != eie) {
            throw eie;
        }

        try {
            Map mapG130 = this.queryMap(mapG211);

            // ���o���ʸ��, �s�W���ʽs��
            mapG130.put("UPD_APLY_NO", APLY_NO);
            this.insertLog(mapG130);

            // �̾ڥ��������s���ʫ᪺��a�b������
            mapG130.put("APLY_NO", APLY_NO);
            // �p��ت�����
            mapG130.put("BLD_COST", STRING.objToBigDecimal(mapG130.get("BLD_COST"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("BLD_COST"), BigDecimal.ZERO)));
            // �p��ت���ꦨ��
            mapG130.put("BLD_COST_INV", STRING.objToBigDecimal(mapG130.get("BLD_COST_INV"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("BLD_COST_INV"), BigDecimal.ZERO)));
            // �p��ت��ۥΦ���
            mapG130.put("BLD_COST_SLF", STRING.objToBigDecimal(mapG130.get("BLD_COST_SLF"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("BLD_COST_SLF"), BigDecimal.ZERO)));

            // �p��g�a����
            mapG130.put("LND_COST", STRING.objToBigDecimal(mapG130.get("LND_COST"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("LND_COST"), BigDecimal.ZERO)));
            // �p��g�a��ꦨ��
            mapG130.put("LND_COST_INV", STRING.objToBigDecimal(mapG130.get("LND_COST_INV"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("LND_COST_INV"), BigDecimal.ZERO)));
            // �p��g�a�ۥΦ���
            mapG130.put("LND_COST_SLF", STRING.objToBigDecimal(mapG130.get("LND_COST_SLF"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("LND_COST_SLF"), BigDecimal.ZERO)));

            mapG130.put("BLD_LOSS", STRING.objToBigDecimal(mapG130.get("BLD_LOSS"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("BLD_LOSS"), BigDecimal.ZERO)));
            mapG130.put("BLD_LOSS_INV", STRING.objToBigDecimal(mapG130.get("BLD_LOSS_INV"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("BLD_LOSS_INV"), BigDecimal.ZERO)));
            mapG130.put("BLD_LOSS_SLF", STRING.objToBigDecimal(mapG130.get("BLD_LOSS_SLF"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("BLD_LOSS_SLF"), BigDecimal.ZERO)));

            mapG130.put("LND_LOSS", STRING.objToBigDecimal(mapG130.get("LND_LOSS"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("LND_LOSS"), BigDecimal.ZERO)));
            mapG130.put("LND_LOSS_INV", STRING.objToBigDecimal(mapG130.get("LND_LOSS_INV"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("LND_LOSS_INV"), BigDecimal.ZERO)));
            mapG130.put("LND_LOSS_SLF", STRING.objToBigDecimal(mapG130.get("LND_LOSS_SLF"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("LND_LOSS_SLF"), BigDecimal.ZERO)));

            mapG130.put("BLD_IFRS_COST", STRING.objToBigDecimal(mapG130.get("BLD_IFRS_COST"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("BLD_IFRS_COST"), BigDecimal.ZERO)));
            mapG130.put("BLD_IFRS_INV", STRING.objToBigDecimal(mapG130.get("BLD_IFRS_INV"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("BLD_IFRS_INV"), BigDecimal.ZERO)));
            mapG130.put("BLD_IFRS_SLF", STRING.objToBigDecimal(mapG130.get("BLD_IFRS_SLF"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("BLD_IFRS_SLF"), BigDecimal.ZERO)));

            mapG130.put("LND_IFRS_COST", STRING.objToBigDecimal(mapG130.get("LND_IFRS_COST"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("LND_IFRS_COST"), BigDecimal.ZERO)));
            mapG130.put("LND_IFRS_INV", STRING.objToBigDecimal(mapG130.get("LND_IFRS_INV"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("LND_IFRS_INV"), BigDecimal.ZERO)));
            mapG130.put("LND_IFRS_SLF", STRING.objToBigDecimal(mapG130.get("LND_IFRS_SLF"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("LND_IFRS_SLF"), BigDecimal.ZERO)));

            mapG130.put("LND_AREA", STRING.objToBigDecimal(mapG130.get("LND_AREA"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("LND_AREA"), BigDecimal.ZERO)));
            mapG130.put("BLD_AREA", STRING.objToBigDecimal(mapG130.get("BLD_AREA"), BigDecimal.ZERO).add(STRING.objToBigDecimal(mapG211.get("BLD_AREA"), BigDecimal.ZERO)));

            mapG130.put("CHG_DATE", DATE.currentTime());
            mapG130.put("CHG_DIV_NO", user.getOpUnit());
            mapG130.put("CHG_ID", user.getEmpID());
            mapG130.put("CHG_NAME", user.getEmpName());

            this.updateG130(mapG130);

        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            //�s�W��a�b������
            this.insertG130(mapG211, user);
        }
    }

    /**
     * �����T�{����^�_��a�b������
     * @param mapG211
     * @throws ModuleException 
     */
    public void cancelRecord(Map mapG211) throws ModuleException {

        if (null == mapG211 || mapG211.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G130_MSG_001")); // �ǤJ��T���o���ŭ�
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(mapG211, "SUB_CPY_ID");
        String BASE_CD = MapUtils.getString(mapG211, "BASE_CD");
        String APLY_NO = MapUtils.getString(mapG211, "APLY_NO");

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_002"); // �ǤJ�����q���o���ŭ�!
        }
        if (StringUtils.isBlank(BASE_CD)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_003"); // �ǤJ��a�N�����o���ŭ�!
        }
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, "EP_Z0G130_MSG_006"); // �ǤJ����s�����o���ŭ�!
        }
        if (null != eie) {
            throw eie;
        }

        Map mapG130Log = null;
        try {
            mapG130Log = this.queryLogMap(mapG211);

        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���");
            //�R����a�b��������
            this.deleteG130(mapG211);
        }

        if (StringUtils.isNotBlank(MapUtils.getString(mapG130Log, "BASE_CD"))) {
            //��s��a�b������������LOG�ƥ����
            this.updateG130(mapG130Log);

            //�R���b����������LOG
            this.deleteLog(mapG130Log);
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}