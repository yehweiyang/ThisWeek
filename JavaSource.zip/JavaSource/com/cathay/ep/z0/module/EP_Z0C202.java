package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.c2.module.EP_C21030;
import com.cathay.ep.vo.DTEPC202;
import com.cathay.util.Transaction;
import com.cathay.util.TransactionHelper;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE    Description Author
 * 2015-04-10  Created �qEP_C10050�h���L��  ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �o���ɺ��@�Ҳ�
 * �Ҳ�ID    EP_Z0C202
 * ���n����    �o���ɺ��@�Ҳ�
 * </pre>
 * @author ����[
 * @since 2015/4/23
 * 2019/12/25 �վ�㯲���o���ˮ֡A�W�[�㯲���o�������d��
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0C202 {
    private static final Logger Log = Logger.getLogger(EP_Z0C202.class);

    private static final String SQL_queryH010List_002 = "com.cathay.ep.z0.module.EP_Z0C202.SQL_queryH010List_002";

    //private static final String SQL_aprvConfirm_003 = "com.cathay.ep.z0.module.EP_Z0C202.SQL_aprvConfirm_003";

    private static final String SQL_queryH010TOTAL_001 = "com.cathay.ep.z0.module.EP_Z0C202.SQL_queryH010TOTAL_001";
    
    private static final String SQL_queryPmInvoiceData_001 = "com.cathay.ep.z0.module.EP_Z0C202.SQL_queryPmInvoiceData_001";

    private static final String SQL_queryH010TOTAL3_001 = "com.cathay.ep.z0.module.EP_Z0C202.SQL_queryH010TOTAL3_001";

    private static final String SQL_updateC202_001 = "com.cathay.ep.z0.module.EP_Z0C202.SQL_updateC202_001";

    private static final String SQL_insertDTEPC202_001 = "com.cathay.ep.z0.module.EP_Z0C202.SQL_insertDTEPC202_001";

    /**
     * 
     * @param invList
     * @throws DBException
     * @throws ModuleException
     */
    public void insertInvList(List<DTEPC202> invList) throws DBException, ModuleException {

        if (invList != null && !invList.isEmpty()) {
            //�B�z���update
            BatchUpdateDataSet bqds = Transaction.getBatchUpdateDataSet();

            //�p����妸��
            int commit_size = 200; //�@��200���i�H�ݨD���ܵ���
            try {
                int batchCount;
                bqds.preparedBatch(SQL_insertDTEPC202_001);
                //�s�W�o����
                batchCount = (invList.size() / commit_size) + 1;
                for (int i = 1; i <= batchCount; i++) {
                    try {
                        int initS = (i - 1) * commit_size;
                        int initE = (i == batchCount) ? invList.size() : i * commit_size;
                        //�J�`�Q��w�s�H�Τ������զ�����w�s
                        for (int j = initS; j < initE; j++) {
                            DTEPC202 C202VO = (DTEPC202) invList.get(j);
                            bqds.setField("INV_NO", C202VO.getINV_NO());
                            bqds.setField("SUB_CPY_ID", C202VO.getSUB_CPY_ID());
                            bqds.setField("RCV_YM", C202VO.getRCV_YM());
                            bqds.setField("CRT_NO", C202VO.getCRT_NO());
                            bqds.setField("CUS_NO", C202VO.getCUS_NO());
                            bqds.setField("PAY_KIND", C202VO.getPAY_KIND());
                            bqds.setField("CUS_NAME", C202VO.getCUS_NAME());
                            bqds.setField("ID", C202VO.getID());
                            bqds.setField("BLD_CD", C202VO.getBLD_CD());
                            bqds.setField("BLD_NAME", C202VO.getBLD_NAME());
                            bqds.setField("PIN_CODE", C202VO.getPIN_CODE());
                            bqds.setField("PIN_NAME", C202VO.getPIN_NAME());
                            bqds.setField("FLD_NO", C202VO.getFLD_NO());
                            bqds.setField("ROOM_NO", C202VO.getROOM_NO());
                            bqds.setField("PRK_NO", C202VO.getPRK_NO());
                            bqds.setField("INV_AMT", C202VO.getINV_AMT());
                            bqds.setField("SAL_AMT", C202VO.getSAL_AMT());
                            bqds.setField("TAX_AMT", C202VO.getTAX_AMT());
                            bqds.setField("TAX_TYPE", C202VO.getTAX_TYPE());
                            bqds.setField("PAY_S_DATE", C202VO.getPAY_S_DATE());
                            bqds.setField("PAY_E_DATE", C202VO.getPAY_E_DATE());
                            bqds.setField("INV_DATE", C202VO.getINV_DATE());
                            bqds.setField("SLIP_DATE", C202VO.getSLIP_DATE());
                            bqds.setField("SLIP_SEQ_NO", C202VO.getSLIP_SEQ_NO());
                            bqds.setField("SLIP_DIV_NO", C202VO.getSLIP_DIV_NO());
                            bqds.setField("APLY_DATE", C202VO.getAPLY_DATE());
                            bqds.setField("PRT_DATE", C202VO.getPRT_DATE());
                            bqds.setField("INV_CD", C202VO.getINV_CD());
                            bqds.setField("SER_NO", C202VO.getSER_NO());
                            bqds.setField("CHK_NO", C202VO.getCHK_NO());
                            bqds.setField("RCV_NO", C202VO.getRCV_NO());
                            bqds.setField("DIV_NO", C202VO.getDIV_NO());
                            bqds.setField("D_ACNT_DATE", C202VO.getD_ACNT_DATE());
                            bqds.setField("D_ACNT_ID", C202VO.getD_ACNT_ID());
                            bqds.setField("D_ACNT_DIV_NO", C202VO.getD_ACNT_DIV_NO());
                            bqds.setField("D_SLPLOT_NO", C202VO.getD_SLPLOT_NO());
                            bqds.setField("D_SLPSET_NO", C202VO.getD_SLPSET_NO());
                            bqds.setField("TRN_KIND", C202VO.getTRN_KIND());
                            bqds.setField("CHG_DATE", C202VO.getCHG_DATE());
                            bqds.setField("CHG_DIV_NO", C202VO.getCHG_DIV_NO());
                            bqds.setField("CHG_ID", C202VO.getCHG_ID());
                            bqds.setField("CHG_NAME", C202VO.getCHG_NAME());
                            bqds.setField("D_CFM_DATE", C202VO.getD_CFM_DATE());
                            bqds.setField("APLY_NO", C202VO.getAPLY_NO());
                            bqds.setField("EXP_STR_DATE", C202VO.getEXP_STR_DATE());
                            bqds.setField("EXP_END_DATE", C202VO.getEXP_END_DATE());
                            bqds.setField("INV_TYPE", C202VO.getINV_TYPE());
                            bqds.setField("TRANS_TYPE", C202VO.getTRANS_TYPE());
                            bqds.setField("CUS_ID", C202VO.getCUS_ID());
                            bqds.setField("DEVICE_NO", C202VO.getDEVICE_NO());

                            bqds.addBatch();
                        }
                        bqds.executeBatch();
                        Object theErrorObject[][] = bqds.getBatchUpdateErrorArray();
                        if (theErrorObject.length > 0) {
                            for (int k = 0; k < theErrorObject.length; k++) {
                                Map errorDataMap = (Map) theErrorObject[k][1];
                                Log.error("�s�W��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap,
                                    (Exception) theErrorObject[k][2]);
                            }
                            //�s�W��Ʀ��~
                            throw new ModuleException("�s�W��Ʀ��~");//�s�W��Ʀ��~
                        }
                    } catch (Exception e) {
                        Log.error(e, e);
                        throw new ModuleException("�妸�s�W����");//�妸�s�W����
                    }
                }//end �s�W�o����
            } finally {
                if (bqds != null) {
                    bqds.close();
                }
            }
        }
    }

    /**
     * 
     * @param RCV_YM
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException
     */
    public List<Map> queryH010List(String RCV_YM, String SUB_CPY_ID) throws ModuleException {

        List<Map> rtnList = null;
        String RCV_YM2 = RCV_YM.substring(0, 4) + "01";
        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("RCV_YM2", RCV_YM2);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        rtnList = VOTool.findToMaps(ds, SQL_queryH010List_002);
        return rtnList;
    }

    /**
     * �d�ߩ㯲���o������
     * @param INV_NO
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException
     */
    public Map queryPmIntInvoiceData(String INV_NO, String SUB_CPY_ID) throws ModuleException {

        Map rtnMap = null;
        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        rtnMap = VOTool.findOneToMap(ds, SQL_queryPmInvoiceData_001);
        return rtnMap;
    }
    
    /**
     * 
     * @param bqds
     * @param RCV_YM
     * @param SUB_CPY_ID
     * @throws DBException
     */
    public void bqdsH010Search(BatchQueryDataSet bqds, String RCV_YM, String SUB_CPY_ID) throws DBException {
        String RCV_YM2 = RCV_YM.substring(0, 4) + "01";
        bqds.setField("RCV_YM", RCV_YM);
        bqds.setField("RCV_YM2", RCV_YM2);
        bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
        bqds.searchAndRetrieve(SQL_queryH010List_002);
    }

    /**
     * �d�߷��~�ײ֭p�ܷ��믲���`�M
     * @param RCV_YM
     * @param ID
     * @return
     * @throws ModuleException
     */
    public Map<String, BigDecimal> queryH010TOTAL(String RCV_YM, List<String> IDs, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isEmpty(RCV_YM)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_002")); //�����~�묰�������
        }
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (IDs == null || IDs.size() == 0) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_003")); //�Τ@�s�����������
        }
        if (eie != null) {
            throw eie;
        }

        //        String RCV_YM_string = RCV_YM.toString();
        String RCV_YM2 = RCV_YM.substring(0, 4) + "01";

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("RCV_YM2", RCV_YM2);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("ID", IDs);

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryH010TOTAL_001);
        Map rtnMap = new HashMap<String, BigDecimal>(rtnList.size());
        for (Map data : rtnList) {
            rtnMap.put(MapUtils.getString(data, "ID", "").trim(), data.get("TOTAL"));
        }
        //        
        //        DBUtil.searchAndRetrieve(ds, SQL_queryH010TOTAL_001);
        //        ds.next();

        return rtnMap;

    }

    /**
     * �d�߷��~�ײ֭p�ܷ���㯲���`�M
     * @param RCV_YM
     * @param ID
     * @return
     * @throws ModuleException
     */
    public Map<String, BigDecimal> queryH010TOTAL3(String RCV_YM, List<String> IDs, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isEmpty(RCV_YM)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_002")); //�����~�묰�������
        }
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (IDs == null || IDs.size() == 0) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_003")); //�Τ@�s�����������
        }
        if (eie != null) {
            throw eie;
        }

        String RCV_YM2 = RCV_YM.substring(0, 4) + "01";

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("RCV_YM2", RCV_YM2);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("ID", IDs);
        //        DBUtil.searchAndRetrieve(ds, SQL_queryH010TOTAL3_001);
        //        ds.next();
        //
        //        return getBigDecimal(ds.getField(0));
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryH010TOTAL3_001);
        Map rtnMap = new HashMap<String, BigDecimal>(rtnList.size());
        for (Map data : rtnList) {
            rtnMap.put(MapUtils.getString(data, "ID", "").trim(), data.get("TOTAL3"));
        }
        return rtnMap;

    }

    /**
     * insertDTEPC202 �s�W�o����T
     * @param INVMap �o���M��
     * @param invNoMap �o�����X�M��
     * @param RandomNoList �H���X
     * @return rtnMap
     * @throws ErrorInputException
     * @throws ModuleException
     * @throws DBException 
     */
    public Map insertDTEPC202(Map INVMap, Map invNoMap, int[] RandomNoList) throws ErrorInputException, ModuleException, DBException {

        ErrorInputException eie = null;
        if (INVMap == null || INVMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C202_MSG_001"));// �ǤJ���o���M�椣�i���� 
        }

        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C202_MSG_002"));// �ǤJ���o�����X�M�椣�i���� 
        }

        if (RandomNoList == null || RandomNoList.length == 0) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C202_MSG_003"));// �ǤJ���H���X���i���� 
        }

        if (eie != null) {
            throw eie;
        }

        List<Map> RCV_LIST = new ArrayList<Map>();
        List<Map> INT_LIST = new ArrayList<Map>();
        StringBuilder sb = new StringBuilder();

        for (Object key : INVMap.keySet()) {

            List<Map> InvList = (List<Map>) INVMap.get(key);
            List<Map> invNoList = (List<Map>) invNoMap.get(key);

            if (InvList.size() != invNoList.size()) {
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C202_MSG_004"));// �o�����X�ƶq���~
            }

            int commit_size = TransactionHelper.getInstance().getBatchFetchSize();//���o������
            int batchCount = InvList.size() / commit_size;// ���o���妸��
            if ((InvList.size() % commit_size) > 0) {
                batchCount++;
            }
            BatchUpdateDataSet buds = null;
            try {
                buds = Transaction.getBatchUpdateDataSet();
                buds.preparedBatch(SQL_insertDTEPC202_001);

                ErrorHandler theErrorHandler = new ErrorHandler();

                int index = 0;
                for (int i = 1; i <= batchCount; i++) {

                    try {
                        //���o�ӧ媺�϶�
                        int initS = (i - 1) * commit_size;
                        int initE = (i == batchCount) ? InvList.size() : i * commit_size;
                        for (int j = initS; j < initE; j++) {
                            Map invMap = InvList.get(j);
                            Map tempMap = new HashMap();
                            String SUB_CPY_ID = MapUtils.getString(invMap, "SUB_CPY_ID");
                            String INV_NO = MapUtils.getString(invNoList.get(index), "INV_NO");
                            index++;
                            tempMap.put("SUB_CPY_ID", SUB_CPY_ID);
                            tempMap.put("INV_NO", INV_NO);

                            String PAY_KIND = MapUtils.getString(invMap, "PAY_KIND");
                            String PRE_KEY = MapUtils.getString(invMap, "PRE_KEY");

                            if ("2".equals(PAY_KIND)) { // �㯲��
                                tempMap.put("INT_NO", PRE_KEY);
                                INT_LIST.add(tempMap);
                            } else {
                                tempMap.put("RCV_NO", PRE_KEY);
                                RCV_LIST.add(tempMap);
                            }

                            DTEPC202 C202 = VOTool.mapToVO(DTEPC202.class, InvList.get(j));
                            String invNoList_INV_NO = MapUtils.getString(invNoList.get(j), "INV_NO");
                            C202.setINV_NO(invNoList_INV_NO);
                            C202.setCHK_NO(STRING.fillZero(String.valueOf(RandomNoList[j]), 4, EncodingHelper.DefaultCharset));
                            buds.setField("INV_NO", C202.getINV_NO());
                            buds.setField("SUB_CPY_ID", C202.getSUB_CPY_ID());
                            buds.setField("RCV_YM", C202.getRCV_YM());
                            buds.setField("CRT_NO", C202.getCRT_NO());
                            buds.setField("CUS_NO", C202.getCUS_NO());
                            buds.setField("PAY_KIND", C202.getPAY_KIND());
                            buds.setField("CUS_NAME", C202.getCUS_NAME());
                            buds.setField("ID", C202.getID());
                            buds.setField("BLD_CD", C202.getBLD_CD());
                            buds.setField("BLD_NAME", C202.getBLD_NAME());
                            buds.setField("PIN_CODE", C202.getPIN_CODE());
                            buds.setField("PIN_NAME", C202.getPIN_NAME());
                            buds.setField("FLD_NO", C202.getFLD_NO());
                            buds.setField("ROOM_NO", C202.getROOM_NO());
                            buds.setField("PRK_NO", C202.getPRK_NO());
                            buds.setField("INV_AMT", C202.getINV_AMT());
                            buds.setField("SAL_AMT", C202.getSAL_AMT());
                            buds.setField("TAX_AMT", C202.getTAX_AMT());
                            buds.setField("TAX_TYPE", C202.getTAX_TYPE());
                            buds.setField("PAY_S_DATE", C202.getPAY_S_DATE());
                            buds.setField("PAY_E_DATE", C202.getPAY_E_DATE());
                            buds.setField("INV_DATE", C202.getINV_DATE());
                            buds.setField("SLIP_DATE", C202.getSLIP_DATE());
                            buds.setField("SLIP_SEQ_NO", C202.getSLIP_SEQ_NO());
                            buds.setField("SLIP_DIV_NO", C202.getSLIP_DIV_NO());
                            buds.setField("APLY_DATE", C202.getAPLY_DATE());
                            buds.setField("PRT_DATE", C202.getPRT_DATE());
                            buds.setField("INV_CD", C202.getINV_CD());
                            buds.setField("SER_NO", C202.getSER_NO());
                            buds.setField("CHK_NO", C202.getCHK_NO());
                            buds.setField("RCV_NO", C202.getRCV_NO());
                            buds.setField("DIV_NO", C202.getDIV_NO());
                            buds.setField("D_ACNT_DATE", C202.getD_ACNT_DATE());
                            buds.setField("D_ACNT_ID", C202.getD_ACNT_ID());
                            buds.setField("D_ACNT_DIV_NO", C202.getD_ACNT_DIV_NO());
                            buds.setField("D_SLPLOT_NO", C202.getD_SLPLOT_NO());
                            buds.setField("D_SLPSET_NO", C202.getD_SLPSET_NO());
                            buds.setField("TRN_KIND", C202.getTRN_KIND());
                            buds.setField("CHG_DATE", C202.getCHG_DATE());
                            buds.setField("CHG_DIV_NO", C202.getCHG_DIV_NO());
                            buds.setField("CHG_ID", C202.getCHG_ID());
                            buds.setField("CHG_NAME", C202.getCHG_NAME());
                            buds.setField("D_CFM_DATE", C202.getD_CFM_DATE());
                            buds.setField("APLY_NO", C202.getAPLY_NO());
                            buds.setField("EXP_STR_DATE", C202.getEXP_STR_DATE());
                            buds.setField("EXP_END_DATE", C202.getEXP_END_DATE());
                            buds.setField("INV_TYPE", C202.getINV_TYPE());
                            buds.setField("CUS_ID", C202.getCUS_ID());
                            buds.setField("TRANS_TYPE", C202.getTRANS_TYPE());
                            //[20200327] �q�l�o��������T(email/���㸹�X)
                            buds.setField("DEVICE_NO", C202.getDEVICE_NO());

                            buds.addBatch();

                        }
                        int[] budsRet = buds.executeBatch();

                        Object theErrorObject[][] = theErrorHandler.getErrorArray(buds.getBatchUpdateErrorArray(), budsRet,
                            buds.getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                        if (theErrorObject.length > 0) {
                            sb.setLength(0);

                            for (int k = 0; k < theErrorObject.length; k++) {
                                Map errorDataMap = (Map) theErrorObject[k][1];
                                Log.error(
                                    sb.append("�s�W��").append(theErrorObject[k][0]).append("����Ʀ��~ Insert setField = ").append(errorDataMap)
                                            .toString(), (Exception) theErrorObject[k][2]);
                                sb.setLength(0);
                            }
                            throw new ModuleException(MessageUtil.getMessage("EP_Z0C202_MSG_008"));// �妸�B�z��Ʈɦ��~
                        }
                    } catch (Exception e) {
                        Log.error("�妸�s�W����", e);
                        throw new ModuleException(MessageUtil.getMessage("EP_Z0C202_MSG_009")); // �妸�s�W����
                    }
                }
            } finally {
                if (buds != null) {
                    buds.close();
                }
            }

        }

        Map rtnMap = new HashMap();
        rtnMap.put("RCV_LIST", RCV_LIST);
        rtnMap.put("INT_LIST", INT_LIST);

        return rtnMap;
    }

    /**
     * �s�W�o����
     * @param inMap ��J�Ѽ�
     * @throws ModuleException
     */
    public void insertDTEPC202(Map inMap) throws ModuleException {
        // [20200218]��EP_C20030���J
        ErrorInputException eie = null;
        UserObject user = null;
        String INV_NO = null;
        String TRN_KIND = null;
        String SUB_CPY_ID = null;

        if (inMap == null || inMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_002"));//��J�ѼƤ��i����
        } else {
            user = (UserObject) inMap.get("User");
            if (user == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_003"));//�ϥΪ̸�T���i����
            }
            INV_NO = MapUtils.getString(inMap, "INV_NO");
            if (StringUtils.isBlank(INV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_024"));//�o�����X���i����
            }
            TRN_KIND = MapUtils.getString(inMap, "TRN_KIND");
            if (StringUtils.isBlank(TRN_KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_025"));//����������i����
            }
            SUB_CPY_ID = MapUtils.getString(inMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //���o�ˬd���X
        String CHK_NO = new EP_C21030().getCHK_NO(INV_NO);
        try {
            Map C202Map = VOTool.voToMap(new DTEPC202());
            C202Map.putAll(inMap);
            C202Map.put("CHK_NO", CHK_NO);
            C202Map.put("CHG_ID", user.getEmpID());
            C202Map.put("CHG_DIV_NO", user.getDivNo());
            C202Map.put("CHG_NAME", user.getEmpName());
            //�s�WDTEPC202�o����
            DataSet ds = Transaction.getDataSet();
            VOTool.mapToDataSet(C202Map, ds);
            DBUtil.executeUpdate(ds, SQL_insertDTEPC202_001);
        } catch (IllegalAccessException e) {
            throw new ModuleException(e.getMessage());
        }
    }

    /**
     * updateC202 ��s�o�����A
     * @param InvMap �o���M��
     * @param reqmap ��s���M��
     * @throws ModuleException 
     */
    public void updateC202(Map InvMap, Map reqMap) throws ModuleException {
        ErrorInputException eie = null;

        if (InvMap == null || InvMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C202_MSG_005")); // �ǤJ���o���M�椣�i����
        }

        if (reqMap == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C202_MSG_006")); // �ǤJ����s���M�椣�i����
        }

        if (eie != null) {
            throw eie;
        }

        String INV_NO = MapUtils.getString(InvMap, "INV_NO");
        if (StringUtils.isBlank(INV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C202_MSG_007"));// �o�����X���o����
        }

        String APLY_DATE = MapUtils.getString(reqMap, "APLY_DATE");
        if (StringUtils.isNotBlank(APLY_DATE) && !DATE.isDate(APLY_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C202_MSG_010"));// �ӳ��������榡���~
        }

        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);

        String INV_CD = MapUtils.getString(reqMap, "INV_CD");
        if (StringUtils.isNotEmpty(INV_CD)) {
            ds.setField("INV_CD", INV_CD);
        }

        String TRN_KIND = MapUtils.getString(reqMap, "TRN_KIND");
        if (StringUtils.isNotEmpty(TRN_KIND)) {
            ds.setField("TRN_KIND", TRN_KIND);
        }

        if (StringUtils.isNotEmpty(APLY_DATE)) {
            ds.setField("APLY_DATE", APLY_DATE);
        }

        DBUtil.executeUpdate(ds, SQL_updateC202_001);

    }

    /**
     * 
     * @param eie
     * @param msg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(msg);
        return eie;
    }

}
