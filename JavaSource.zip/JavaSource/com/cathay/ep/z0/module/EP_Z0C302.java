package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.de.module.DE_00Z030;
import com.cathay.ep.vo.DTEPC302;
import com.cathay.util.MessageUtil;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �䲼�������@�Ҳ�(�qEP_C30020�h���L��)
 * </pre>
 * @author ����[
 * @since 2015/3/27
 */
@SuppressWarnings("unchecked")
public class EP_Z0C302 {
    private static final Logger log = Logger.getLogger(EP_Z0C302.class);

    private static final String SQL_deleteByChkSetNo_001 = "com.cathay.ep.z0.module.EP_Z0C302.SQL_deleteByChkSetNo_001";

    private static final String SQL_insertChkInfo_001 = "com.cathay.ep.z0.module.EP_Z0C302.SQL_insertChkInfo_001";

    private static final String SQL_queryChkPayListMap_001 = "com.cathay.ep.z0.module.EP_Z0C302.SQL_queryChkPayListMap_001";

    private EP_Z00030 theEP_Z00030 = new EP_Z00030();

    /**
     * �d�߲���ú�O����
     * @param PAY_NO_LIST
     * @return
     * @throws Exception
     */
    public Map<String, List<Map>> queryChkPayListMap(List<Map> PAY_NO_LIST, String SUB_CPY_ID) throws Exception {
        if (PAY_NO_LIST == null || PAY_NO_LIST.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C306_MSG_001"));//�ǤJú�O�s�����i����  TODO
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        List<String> CHK_SET_LIST = new ArrayList<String>();//CHK_SET_NO
        for (Map payMap : PAY_NO_LIST) {
            BigDecimal CHK_AMT = STRING.objToBigDecimal(payMap.get("CHK_AMT"), BigDecimal.ZERO);
            if (CHK_AMT.compareTo(BigDecimal.ZERO) > 0) {
                String CHK_SET_NO = MapUtils.getString(payMap, "CHK_SET_NO");
                if (!CHK_SET_LIST.contains(CHK_SET_NO)) {
                    CHK_SET_LIST.add(CHK_SET_NO);
                }
            }
        }

        if (CHK_SET_LIST != null && !CHK_SET_LIST.isEmpty()) {
            Map<String, List<Map>> tmpMap = new HashMap();
            List<Map> CHK_LIST;
            DataSet ds = Transaction.getDataSet();
            ds.setFieldValues("CHK_SET_NOs", CHK_SET_LIST);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.searchAndRetrieve(ds, SQL_queryChkPayListMap_001);
            while (ds.next()) {
                String CHK_SET_NO = ObjectUtils.toString(ds.getField("CHK_SET_NO"));
                if (!tmpMap.containsKey(CHK_SET_NO)) {
                    CHK_LIST = new ArrayList();
                    CHK_LIST.add(VOTool.dataSetToMap(ds));
                    tmpMap.put(CHK_SET_NO, CHK_LIST);
                } else {
                    CHK_LIST = tmpMap.get(CHK_SET_NO);
                    CHK_LIST.add(VOTool.dataSetToMap(ds));
                }
            }
            return tmpMap;
        }
        return null;
    }

    /**
     * �̲��ڲո��R��
     * @param CHK_SET_NO
     * @throws ModuleException
     */
    public void deleteByChkSetNo(String CHK_SET_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(CHK_SET_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C302_MSG_004"));//�ǤJ���ڲո����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //�R�����ڲո��A�qEP_C30020�h���L�� 
        DataSet ds = Transaction.getDataSet();

        ds.setField("CHK_SET_NO", CHK_SET_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_deleteByChkSetNo_001);
        } catch (ModuleException e) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C302_MSG_001", new Object[] { CHK_SET_NO }));//"�R�����ک�����BY���ڲո����~,���ڲո�={0}"
        }
    }

    /**
     * �s�W���ک��Ӹ�T
     * @param CHK_INFO_LIST ���ک��Ӹ�T�M��
     * @param user �ϥΪ̸�T
     * @return ���ڲո�
     * @throws Exception
     */
    /*(��k���� EP_Z0C302)*/
    public String insertChkInfo(List<Map> CHK_INFO_LIST, UserObject user) throws Exception {
        ErrorInputException eie = null;
        if (CHK_INFO_LIST == null || CHK_INFO_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_008"));//�״ڳ���Ӹ�T�M�椣�o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_009"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        //���o�����q�O
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
        //���o���ڲո�
        String CHK_SET_NO = this.getChkSetNo(SUB_CPY_ID);

        String EmpID = user.getEmpID();
        String EmpName = user.getEmpName();
        for (Map map : CHK_INFO_LIST) {
            DTEPC302 DTEPC302_vo = new DTEPC302();
            DTEPC302_vo.setBANK_NO(MapUtils.getString(map, "BANK_NO"));
            DTEPC302_vo.setCHK_NO(MapUtils.getString(map, "CHK_NO"));
            DTEPC302_vo.setACNT_NO(MapUtils.getString(map, "ACNT_NO"));
            DTEPC302_vo.setCHK_SET_NO(CHK_SET_NO);
            DTEPC302_vo.setSUB_CPY_ID(SUB_CPY_ID);
            String CHK_DATE = MapUtils.getString(map, "CHK_DATE");
            DTEPC302_vo.setCHK_DATE(DATE.isDate(CHK_DATE) ? Date.valueOf(CHK_DATE) : null);
            String CHK_AMT = MapUtils.getString(map, "CHK_AMT");
            DTEPC302_vo.setCHK_AMT(NumberUtils.isDigits(CHK_AMT) ? Integer.valueOf(CHK_AMT) : null);
            DTEPC302_vo.setINPUT_ID(EmpID);
            DTEPC302_vo.setINPUT_NAME(EmpName);

            //�s�WDBEP.DTEPC302���ک�����
            try {
                VOTool.insert(DTEPC302_vo);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_012"));//�g�J���ک����ɦ��~,
            }
        }
        return CHK_SET_NO;
    }

    /**
     * �s�W���ک��Ӹ�T
     * @param CHK_INFO_LIST
     * @param user
     * @return
     * @throws Exception
     */
    public String insertChkInfo(List<Map> CHK_INFO_LIST, UserObject user, BatchUpdateDataSet buds) throws Exception {
        if (CHK_INFO_LIST == null || CHK_INFO_LIST.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C302_MSG_004"));//�ǤJ���ڲո����i����
        }

        //���o�����q�O
        String SUB_CPY_ID = theEP_Z00030.getSUB_CPY_ID(user);
        //���o���ڲո�
        String CHK_SET_NO = this.getChkSetNo(SUB_CPY_ID);

        String EmpID = user.getEmpID();
        String EmpName = user.getEmpName();

        //�妸
        //�]XAMode:buds�ѥD�{���ǤJ
        //BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        buds.preparedBatch(SQL_insertChkInfo_001);
        try {

            for (Map map : CHK_INFO_LIST) {

                buds.setField("BANK_NO", map.get("BANK_NO"));
                buds.setField("CHK_NO", map.get("CHK_NO"));
                buds.setField("ACNT_NO", map.get("ACNT_NO"));
                buds.setField("CHK_SET_NO", CHK_SET_NO);
                buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                buds.setField("CHK_DATE", map.get("CHK_DATE"));
                buds.setField("CHK_AMT", map.get("CHK_AMT"));
                buds.setField("INPUT_ID", EmpID);
                buds.setField("INPUT_NAME", EmpName);
                buds.addBatch();
            }
            buds.executeBatch();
            Object theErrorObject[][] = buds.getBatchUpdateErrorArray();

            if (theErrorObject.length > 0) {
                for (int k = 0; k < theErrorObject.length; k++) {
                    Map errorDataMap = (Map) theErrorObject[k][1];
                    log.error("�g�J���ک����ɲ�" + (Exception) theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap.toString(),
                        (Exception) theErrorObject[k][2]);
                }
                throw new ModuleException(MessageUtil.getMessage("EP_Z0C302_MSG_003"));// �g�J���ک����ɦ��~
            }
        } catch (Exception e) {
            log.error(e, e);
            throw new ModuleException(MessageUtil.getMessage("EP_Z0C302_MSG_003"));// �g�J���ک����ɦ��~
        }
        return CHK_SET_NO;
    }

    /**
     * �̤����q�O���o���@�ո�
     * @param SUB_CPY_ID
     * @return
     * @throws ErrorInputException
     * @throws IllegalArgumentException
     * @throws ModuleException
     * @throws Exception
     */
    private String getChkSetNo(String SUB_CPY_ID) throws ErrorInputException, IllegalArgumentException, ModuleException, Exception {
        String CHK_SET_NO;
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
            ReturnMessage msg = new ReturnMessage();
            CHK_SET_NO = new DE_00Z030().getCHK_SET_NO("8", msg);
            if (msg.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_011") + msg.getMsgDesc());//EP_C30020:�I�s���ڨt�νs�����o�Ҳզ��~,
            }
        } else {
            CHK_SET_NO = new EP_Z0Z001().createNextNo(SUB_CPY_ID, "046", "CHK_SET_NO", DATE.getY2KYear(DATE.getDBDate()), SUB_CPY_ID
                    + DATE.getY2KYear(DATE.getDBDate()).substring(2, 4), 6);
        }

        return CHK_SET_NO;
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }
}
