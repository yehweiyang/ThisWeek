package com.cathay.ep.z0.module;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.TextNode;
import org.jsoup.select.Elements;

import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.http.TrustAllSSLSocketFactory;
import com.cathay.ep.vo.DTEPZ300;
import com.cathay.ep.vo.DTEPZ301;

/**
 * <pre>
 * NewsExtractor
 * </pre>
 * 
 * @author
 * @since 2015/5/22
 * @since [2019-04-29] �ӽЮ�190123001147 - �u�Ƶ{��
 */
public class NewsExtractor {

    static final Logger log = Logger.getLogger(NewsExtractor.class);

    static final boolean isDebug = log.isDebugEnabled();

    protected DTEPZ300 DTEPZ300;

    protected DTEPZ300 getDTEPZ300() {
        return DTEPZ300;
    }

    protected void setDTEPZ300(DTEPZ300 dtepz300) {
        DTEPZ300 = dtepz300;
    }

    /**
     * �غc�l
     * @param site
     */
    public NewsExtractor(DTEPZ300 site) {

        this.setDTEPZ300(site);

    }

    /**
     * �ѪR�T��(STEP 1)
     * @return
     * @throws IOException
     */
    public List<DTEPZ301> extractNews() throws IOException {
        // [20190429] �R�����եε{��

        DTEPZ300 site = getDTEPZ300();
        List<DTEPZ301> newList = digestNews(site);

        return newList;
    }

    /**
     * �ŧiDTEPZ301
     * @param site
     * @return
     */
    public DTEPZ301 initDTEPZ301(DTEPZ300 site) {
        DTEPZ301 Z301 = new DTEPZ301();
        Z301.setEVENT_ID(site.getEVENT_ID());
        Z301.setPCS_SEQ(site.getPCS_SEQ());
        Z301.setINFO_SOURCE(site.getINFO_SOURCE());
        return Z301;
    }

    /**
     * �ѪR����(STEP 2)
     * @param site
     * @return
     * @throws IOException
     * @throws MalformedURLException
     */
    protected List<DTEPZ301> digestNews(DTEPZ300 site) throws IOException, MalformedURLException {
        //[20190503]�L�k�ѪR�N���ΦA�hgetDocument�����߿�+��ܵL�k�ѪR����]
        //Document doc = this.getDocument(site);
        //log.debug("### DOC::" + StringUtils.substring(doc.text(), 0, 100));
        throw new UnsupportedOperationException("�Ӻ������e�L�k�۰ʸѪR"
                + (StringUtils.isNotBlank(site.getUNEXTRACT_MEMO()) ? ("�G" + site.getUNEXTRACT_MEMO()) : ""));
    }

    /**
     * �����������e(STEP 2)
     * @param site
     * @return
     * @throws IOException
     * @throws MalformedURLException
     */
    protected Document getDocument(DTEPZ300 site) throws IOException, MalformedURLException {
        Document doc;
        // trustEveryone();
        //[20190429] �վ�ssl�{�Ҥ�k(��Ω��h�@��)
        new TrustAllSSLSocketFactory();

        long begTime = System.currentTimeMillis();
        if (StringUtils.isNotBlank(site.getUSER_AGENT())) {
            doc = Jsoup.connect(site.getURL()).userAgent(site.getUSER_AGENT()).timeout(getConnectTimeout()).get();
        } else {
            doc = getDocumentByUrl(site.getURL(), site.getENCODING());
        }

        long endTime = System.currentTimeMillis();
        if (isDebug)
            log.debug("##### End Parse Document at " + DATE.getDBTimeStamp() + ", spend Time:" + (endTime - begTime) / 1000 + " s");
        return doc;
    }

    /**
     * ���o�������e
     * @param url
     * @param encoding
     * @return
     * @throws IOException
     * @throws MalformedURLException
     */
    protected Document getDocumentByUrl(String url, String encoding) throws IOException, MalformedURLException {

        URL siteURL = new URL(url);
        URLConnection urlConnection = siteURL.openConnection();
        urlConnection.setConnectTimeout(getConnectTimeout());
        urlConnection.setReadTimeout(getConnectTimeout());
        InputStream is = null;
        try {
            is = urlConnection.getInputStream();
            Document doc = Jsoup.parse(is, encoding, url);
            return doc;
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (Exception e) {
                }
            }
        }

    }

    protected Document getDocumentByFile(String file, String encoding, String baseUri) throws IOException, MalformedURLException {
        File input = new File(file);
        Document doc = Jsoup.parse(input, encoding, baseUri);
        return doc;
    }

    protected Document getDocumentByScript(String url) throws IOException, MalformedURLException {
        Document doc = getDocumentByUrl(url, "big5");

        Element script = doc.select("script").first();
        Pattern p = Pattern.compile("(html[+]{1}=[']{1})(.*?)([']{1})");
        Matcher m = p.matcher(script.html());

        StringBuffer html = new StringBuffer();
        while (m.find()) {
            html.append(m.group(2)).append("\n");
        }

        Document aaa = Jsoup.parse(html.toString());
        return aaa;
    }

    /**
     * ���o�W�s��element 
     * @param url
     * @param alink
     * @return
     * @throws Exception 
     */
    protected String extractUrl(String url, Element alink) {
        String baseUrl = url.substring(0, url.lastIndexOf('/') + 1);

        String href = alink.attr("href");
        String onclick = alink.attr("onclick");
        // log.debug("onclick:" + onclick);
        String link = null;
        if (StringUtils.isNotBlank(href)) {
            // log.debug("href:" + href);
            if ("#".equals(href)) {
                link = url;
            } else {
                link = extractUrl(baseUrl, href);
            }
        } else if ((StringUtils.isBlank(link) || baseUrl.equals(link)) && StringUtils.isNotBlank(onclick)) {
            link = extractUrl(baseUrl, onclick);
        } else {//[190515] �Yelement�L�]�whref��onclick function���ܹw�]��쥻��url+title
            link = url ;
        }

        return link;
    }

    /**
     * �ѪRURL (LinksExtractor,RSSExtractor)
     * @param baseUrl
     * @param input
     * @return
     */
    protected String extractUrl(String baseUrl, String input) {
        if (input.startsWith("SF01")) {
            // SF01('KDA020101','jsp','_self','KDA050100','');
            String regex = "[(](.*?)[)]";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(input);
            while (matcher.find()) {
                //log.debug(matcher.group());
                String output = (matcher.group().replaceAll(regex, "$1"));
                output = output.replaceAll("'", "");
                String[] params = StringUtils.split(output, ",");
                StringBuilder sb = new StringBuilder();
                sb.append(params[0]).append(".");
                sb.append(params[1]).append("?PK01=").append(params[3]);
                if (params.length > 4) {
                    sb.append("&PK02=").append(params[4]);
                }
                output = getFullURL(baseUrl, sb.toString());

                sb.setLength(0);
                try {
                    output = java.net.URLDecoder.decode(output, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    //log.fatal("UrlDecode Failed", e);
                }
                return output;
            }
        } else {
            String regex = "['\"](.*?)(\\s*['\"])";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(input);
            while (matcher.find()) {
                String output = (matcher.group().replaceAll(regex, "$1"));
                output = getFullURL(baseUrl, output);
                try {
                    output = java.net.URLDecoder.decode(output, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    log.fatal("UrlDecode Failed", e);
                }
                return output;
            }
        }

        return getFullURL(baseUrl, input);

    }

    /**
     * ���o����url
     * @param baseUrl
     * @param input
     * @return
     */
    private String getFullURL(String baseUrl, String input) {
        if (input.startsWith(baseUrl)) {
            return input;
        } else {
            if (input.startsWith("http")) {
                return input;
            } else if (input.startsWith("/")) {
                baseUrl = baseUrl.substring(0, baseUrl.indexOf('/', 10));
                if (baseUrl.endsWith("/")) {
                    return baseUrl + input.substring(1);
                } else {
                    return baseUrl + input;
                }
            } else {
                return baseUrl + input;
            }
        }
    }

    /**
     * �I��url����title (LinksExtractor,TableExtractor)
     * @param link
     * @return
     */
    protected String getLinkTitle(Element link) {

        List<TextNode> textNodes = link.textNodes();
        String title;
        if (textNodes.size() == 1) {
            //log.debug("### textNodes::"+link.lastElementSibling().toString());
            title = link.textNodes().get(0).toString();

            if (StringUtils.isBlank(title)) {
                title = link.text();
            }
        } else {
            title = link.text();
        }
        title = title.replaceAll("\u00a0", "");//replace &nbsp;

        // 2. �v�̦r���P�_�O�_�����r�A�p�G�����r��s���e�� ���@��//�����ť�
        //[20190429] ��Ʈw�אּutf-8,�����Ӧ����r���D
        /*StringBuilder sb = new StringBuilder();
        char[] vals = title.toCharArray();
        for (char val : vals) {
            if (isDW_CODE(val)) {
                sb.append('�@');
            } else {
                sb.append(val);
            }
        }
        title = sb.toString();*/
        //log.debug("### title::"+title);
        return title;
    }

    //================================== FOR TableExtractor =================================//

    /**
     * �ѪRtable(TableExtractor)
     * @param doc
     * @param url
     * @param selector
     * @return
     */
    protected List<DTEPZ301> extractTable(Document doc, String url, String selector) {
        List<DTEPZ301> matchNews = new ArrayList<DTEPZ301>();
        DTEPZ300 site = this.getDTEPZ300();
        // "table table[bordercolor*=#A5D46F]"
        Elements selecTable = doc.select(selector);
        //log.debug("## selecTable:"+selecTable.toString());
        if (selecTable.size() > 1) {
            log.fatal("TableExtractor �����h�itable�AEVENT_ID:" + site.getEVENT_ID() + ", PCS_SEQ:" + site.getPCS_SEQ() + ", SELECTOR:"
                    + site.getSELECTOR() + ", URL:" + site.getURL()+ ", Table cnt:" + selecTable.size());
        }
        if (selecTable.size() == 0) {
            throw new RuntimeException("�������e�P�w�q�ѪR��ܾ�[" + selector + "]���P,�d�L���wTABLE");
        }
        //log.debug("selecTable::" + selecTable.size());

        int tableCnt = getTBLCNT();
        if (tableCnt <= 1) {
            tableCnt = 1;
        }

        for (int tbli = 0; tbli < tableCnt; tbli++) {
            //[2019-04-29] �վ�i�̳]�w,�����h�itable 
            Element table = selecTable.get(tbli);

            int[] titleIdx = getTitleIdx();
            /*for (int ii : titleIdx) {
                log.debug("TitleIdx: " + ii);
            }*/

            int passRow = getPassRow();
            // log.debug("passRow: " + passRow);
            int tdCnt = getTDCNT();
            // log.debug("TD Cnt:" + tdCnt);
            int linkIdx = getLinkIdx();
            // log.debug("linkIdx: " + linkIdx);
            int[] memoIdx = getMemoIdxes();
            // log.debug("memoIdx:" + Arrays.asList(memoIdx));
            String[] memoHead = getMemoHead();
            // log.debug("memoHead:" + Arrays.asList(memoHead));

            int rowIdx = 0;
            StringBuilder sb = new StringBuilder();
            for (Element tr : table.select("tr")) {

                // �Ǹ� ���ʲ��Х� ���n(���褽��) �ϥΤ��ϩνs�w�ϥκ��� �Ƶ�
                Elements tds = tr.select("td");
                //log.debug("## tds:" + tds.toString());

                // TITLE[1];MEMO[2|4];MEMOHEAD[���n(���褽��)|�Ƶ�]
                if (tds.size() == tdCnt) {
                    // �����X�����
                    if (passRow > 0 && rowIdx < passRow) {
                        //log.debug("## passRow:" + passRow + "||rowIdx:" + rowIdx);
                        rowIdx++;
                        continue;
                    }

                    // �B�ztitle
                    sb.setLength(0);
                    for (int tIdx : titleIdx) {
                        sb = sb.append(getLinkTitle(tds.get(tIdx)));
                    }
                    String title = sb.toString();

                    //�B�z�s��
                    String link;
                    if (linkIdx >= 0) {
                        Element td = tds.get(linkIdx);
                        Element e = td.select("a").first();
                        if (e != null) {
                            link = extractUrl(url, e);
                        } else {
                            link = url + "#" + title;
                        }
                    } else {
                        link = url + "#" + title;
                    }
                    //log.debug("## link:"+link);

                    //�B�zmemo
                    sb.setLength(0);
                    for (int i = 0; i < memoIdx.length; i++) {
                        sb.append(memoHead[i]).append(":").append(tds.get(memoIdx[i]).text()).append(";");
                    }

                    DTEPZ301 news = initDTEPZ301(site);
                    news.setTITLE(title);
                    news.setURL(link);
                    news.setMEMO(sb.toString());
                    sb.setLength(0);

                    matchNews.add(news);
                }
            }
        }

        //log.debug("### matchNews::" + matchNews);
        return matchNews;
    }

    /**
     * ���otable����title index(TableExtractor)
     * (�ҩl��0)
     * @return
     */
    protected int[] getTitleIdx() {
        // TITLE[2];LINK[];MEMO[5];
        return getIdxes("TITLE", this.getDTEPZ300().getTD_IDX());
    }

    /**
     * ����table�`���(TableExtractor)
     * @return
     */
    protected int getTDCNT() {
        // TITLE[2];LINK[];MEMO[5];
        return getIdx("TDCNT", this.getDTEPZ300().getTD_IDX());
    }

    /**
     * ���otable����link index(TableExtractor)
     * (�ҩl��0)
     * @return
     */
    protected int getLinkIdx() {
        // TITLE[2];LINK[];MEMO[5];
        return getIdx("LINK", this.getDTEPZ300().getTD_IDX());
    }

    /**
     * ���otable����table count index(TableExtractor)
     * (�ҩl��0)
     * @return
     */
    protected int getTBLCNT() {
        // TITLE[2];LINK[];MEMO[5];
        return getIdx("TBLCNT", this.getDTEPZ300().getTD_IDX());
    }

    /**
     * ���otable�������������(TableExtractor)
     * (�ҩl��0)
     * @return
     */
    protected int getPassRow() {
        // TITLE[2];LINK[];MEMO[5];
        return getIdx("PASSROW", this.getDTEPZ300().getTD_IDX());
    }

    /**
     * ���otable��memo index(TableExtractor)
     * (�ҩl��0)
     * @return
     */
    protected int[] getMemoIdxes() {
        return getIdxes("MEMO", getDTEPZ300().getTD_IDX());
    }

    /**
     * ���omemo��title(TableExtractor)
     * @return
     */
    protected String[] getMemoHead() {
        String head = getDTEPZ300().getTD_IDX();
        Pattern p = Pattern.compile("HEAD\\[(.*)\\]");

        Matcher m = p.matcher(head);

        String memos = "";
        while (m.find()) {
            memos = m.group(1);
        }
        if (StringUtils.isNotEmpty(memos)) {
            String[] memohead = StringUtils.split(memos, "|");
            return memohead;
        }
        return new String[0];

    }

    /**
     * TableExtractor:get Index
     * @return
     */
    protected int getIdx(String prefix, String text) {
        // TITLE[2];LINK[];MEMO[5];
        Pattern p = Pattern.compile((prefix + "\\[(\\d*)\\];?"));
        Matcher m = p.matcher(text);

        while (m.find()) {
            String idx = m.group(1);
            return Integer.parseInt(idx);
        }
        return -1;
    }

    /**
     * TableExtractor:get Index(�h��)
     * @return
     */
    protected int[] getIdxes(String prefix, String memo) {

        Pattern p = Pattern.compile(prefix + "\\[([0-9,|]*)\\];");
        Matcher m = p.matcher(memo);

        String memos = "";
        while (m.find()) {
            memos = m.group(1);
        }
        if (StringUtils.isNotEmpty(memos)) {
            String[] memoIdx = StringUtils.split(memos, "|");
            int[] idx = new int[memoIdx.length];
            int i = 0;
            for (String mIdx : memoIdx) {
                idx[i++] = Integer.parseInt(mIdx);
            }
            return idx;
        }
        return new int[0];
    }

    //================================== �䥦�@��function =================================//

    /**
     * �s�utimeout�]�w
     * @return
     */
    public int getConnectTimeout() {
        // �]�w TIMEOUT 60 sec
        int connectTimeout = 60000;
        try {
            String CONNECT_TIMEOUT = FieldOptionList.getName("EP", "NEWS_DIGEST", "CONNECT_TIMEOUT");
            connectTimeout = Integer.parseInt(CONNECT_TIMEOUT);
            //log.debug("CONNECT TIMEOUT BY FieldOptionList:" + connectTimeout);
        } catch (Exception e) {
            // �L�]�w�ϥιw�]��
        }
        return connectTimeout;
    }

    /**
     * �P�_char �O�_�����r
     * @param val
     * @return
     */
    protected boolean isDW_CODE(char val) {

        int doubleByteLength = STRING.doubleByteLength(String.valueOf(val), EncodingHelper.Charset_UTF8);

        int Byteslength = String.valueOf(val).getBytes().length;

        return (doubleByteLength != Byteslength);
    }

    protected void logHexCode(String titleText) {
        byte[] bytes = titleText.getBytes();
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X ", b));
        }
        //log.debug("HEX[" + titleText + "]:" + sb.toString());
    }

}