package com.cathay.ep.z0.module;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.util.Transaction;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**<pre>
 * ���ʤ�� ���� ���ʻ��� ���ʤH�� �߮׳渹
2020/06/01 1.0 CREATE ������ 200414001917

 * 
 *     �@�B �{���\�෧�n�����G
*�ҲզW�� �j�Ӧ����������@�Ҳ� 
*�Ҳ�ID EP_Z0G150 
*���n���� �j�Ӧ����������@�Ҳ�
 * </pre>
 * @author ���´�
 *
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class EP_Z0G151 {
    private static final Logger log = Logger.getLogger(EP_Z0G151.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G151.SQL_queryList_001";

    private static final String SQL_queryLatestEvalMap_001 = "com.cathay.ep.z0.module.EP_Z0G151.SQL_queryLatestEvalMap_001";

    private static final String SQL_queryBaseAprCtrlMap_001 = "com.cathay.ep.z0.module.EP_Z0G151.SQL_queryBaseAprCtrlMap_001";

    /**�d�ߤj��Ų���ޱ��M��
     * @param Map reqMap
     * @return List<Map> rtnList
     * @throws ModuleException 
     * @throws DBException 
     */
    public List<Map> queryList(Map reqMap) throws ModuleException, DBException {
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String EVAL_SN_BEG = MapUtils.getString(reqMap, "EVAL_SN_BEG");
        String EVAL_SN_END = MapUtils.getString(reqMap, "EVAL_SN_END");
        if (reqMap == null || StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_001");//�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(EVAL_SN_BEG)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_002");//�ǤJ���ȩu�׶}�l���ŭ�
        }
        if (StringUtils.isBlank(EVAL_SN_END)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_003");//�ǤJ���ȩu�׵������o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("EVAL_SN_BEG", EVAL_SN_BEG);
        ds.setField("EVAL_SN_END", EVAL_SN_END);
        setFieldIfExist(ds, MapUtils.getString(reqMap, "INV_CD"), "INV_CD");
        setFieldIfExist(ds, MapUtils.getString(reqMap, "BASE_CD"), "BASE_CD");
        setFieldIfExist(ds, MapUtils.getString(reqMap, "APR_ID"), "APR_ID");
        if (StringUtils.isNotBlank(MapUtils.getString(reqMap, "BASE_BLD_NAME"))) {
            StringBuilder sb = new StringBuilder();
            ds.setField("BASE_BLD_NAME", sb.append('%').append(MapUtils.getString(reqMap, "BASE_BLD_NAME")).append('%').toString());
        }
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);
        EP_Z0G150 ep_Z0G150 = new EP_Z0G150();
        for (Map rtnMap : rtnList) {
            //�����ưȩ�
            this.getNameSafe("EP", "APR_ID", MapUtils.getString(rtnMap, "APR_ID"), rtnMap, "APR_ID_NM", "���o�N�X���奢��:�����ưȩ�");
            //�]�w�g�a�ت������N�X����
            ep_Z0G150.setBldKdName(rtnMap);
        }
        return rtnList;
    }

    /**���o�w�]���ȩu��
     * @return EVAL_SN
     */
    public String getEvalSeason() throws ModuleException {
        StringBuilder EVAL_SN = new StringBuilder();
        int YEAR = Calendar.getInstance().get(Calendar.YEAR);
        int MONTH = Calendar.getInstance().get(Calendar.MONTH) + 1;
        if (MONTH <= 2) {
            EVAL_SN.append((YEAR - 1912)).append("Q4");
        } else if (MONTH <= 5) {
            EVAL_SN.append((YEAR - 1911)).append("Q1");
        } else if (MONTH <= 8) {
            EVAL_SN.append((YEAR - 1911)).append("Q2");
        } else if (MONTH <= 11) {
            EVAL_SN.append((YEAR - 1911)).append("Q3");
        } else {
            EVAL_SN.append((YEAR - 1911)).append("Q4");
        }
        return EVAL_SN.toString();
    }

    /**���o�e�@�Ӧ��ȩu��
     * @param EVAL_SN
     * @return PRE_EVAL_SN
     */
    public String getPreEvalSeason(String EVAL_SN) throws ModuleException {
        if (StringUtils.isBlank(EVAL_SN)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G151_ERRMSG_009"));
        }
        StringBuilder PRE_EVAL_SN = new StringBuilder();
        int iEVALYr = Integer.parseInt(StringUtils.substring(EVAL_SN, 0, 3));
        int iEvalSN = Integer.parseInt(StringUtils.substring(EVAL_SN, EVAL_SN.length() - 1));
        if (iEvalSN == 1) {
            PRE_EVAL_SN.append(iEVALYr - 1).append("Q4");
        } else {
            PRE_EVAL_SN.append(iEVALYr).append('Q').append(iEvalSN - 1);
        }
        return PRE_EVAL_SN.toString();
    }

    /**�d�ߤj�Өưȩҳ̷s�ޱ�����
     * @param reqMap
     * @return rtnMap
     * @throws ModuleException
     * @throws DBException 
     */
    public Map queryLatestEvalMap(Map reqMap) throws ModuleException, DBException {
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        String APR_ID = MapUtils.getString(reqMap, "APR_ID");
        if (reqMap == null || StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_001");//�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(BASE_CD)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_004");//�ǤJ��a�N�����ŭ�
        }
        if (StringUtils.isBlank(APR_ID)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_005");//�ǤJ�ưȩҥN�����ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�d�ߤj�ӳ̪�@��Ų�����G (DTEPG230)
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("APR_ID", APR_ID);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryLatestEvalMap_001);

        //�����ưȩ�
        this.getNameSafe("EP", "APR_ID", MapUtils.getString(rtnMap, "APR_ID"), rtnMap, "APR_ID_NM", "���o�N�X���奢��:�����ưȩ�");
        return rtnMap;
    }

    /**�̰�a�M��d�ߤj��Ų���ޱ��M��
     * @param reqMap
     * @param baseList
     * @return
     * @throws ModuleException
     */
    public Map<String, Map> queryBaseAprCtrlMap(Map reqMap, List<String> baseList) throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        if (baseList == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G151_ERRMSG_010"));
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String DLG_APR_ID = MapUtils.getString(reqMap, "DLG_APR_ID");
        if (reqMap == null || StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_001");//�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(DLG_APR_ID)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_006");//�ǤJ��������ưȩҬ��ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("DLG_APR_ID", DLG_APR_ID);
        ds.setFieldValues("baseList", baseList);

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryBaseAprCtrlMap_001);
        EP_Z0G150 ep_Z0G150 = new EP_Z0G150();
        Map rtnMap = new HashMap();
        for (Map dataMap : rtnList) {
            //�����ưȩ�
            this.getNameSafe("EP", "APR_ID", MapUtils.getString(rtnMap, "APR_ID"), rtnMap, "APR_ID_NM", "���o�N�X���奢��:�����ưȩ�");
            //�]�w�g�a�ت������N�X����
            ep_Z0G150.setBldKdName(dataMap);
            rtnMap.put(MapUtils.getString(dataMap, "SUB_CPY_ID") + MapUtils.getString(dataMap, "BASE_CD"), dataMap);
        }
        return rtnMap;
    }

    /**�̰�a�M��d�ߤj��Ų���ޱ��M��
     * @param reqMap
     * @param selectList
     * @throws ModuleException
     */
    public void checkBaseDelegateCount(Map reqMap, List<Map> selectList) throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String DLG_APR_ID = MapUtils.getString(reqMap, "DLG_APR_ID");
        String DLG_EVAL_SN = MapUtils.getString(reqMap, "DLG_EVAL_SN");
        if (reqMap == null || StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_001");//�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(DLG_APR_ID)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_006");//�ǤJ��������ưȩҬ��ŭ�
        }
        if (StringUtils.isBlank(DLG_EVAL_SN)) {
            eie = getErrorInputException(eie, "EP_Z0G151_ERRMSG_007");//�ǤJ����u�׬��ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        List<String> baseList = new ArrayList();
        for (Map map : selectList) {
            baseList.add(MapUtils.getString(map, "BASE_CD"));
        }
        //�d�ߤj��Ų���ޱ��M�� (DTEPG151)
        Map<String, Map> rtnMap = this.queryBaseAprCtrlMap(reqMap, baseList);
        //�ˮֿ��~�T��
        StringBuilder sbChkApr = new StringBuilder();
        String APR_ID_NM = "";
        try {
            APR_ID_NM = FieldOptionList.getName("EP", "APR_ID", MapUtils.getString(reqMap, "DLG_APR_ID"));
        } catch (Exception e) {
            log.fatal("���o�N�X���奢��:�����ưȩ�", e);
        }
        //�v���ˮ֤j�Ӭ���M��
        for (Map dataMap : selectList) {
            Map ctrlMap = rtnMap.get(MapUtils.getString(dataMap, "SUB_CPY_ID") + MapUtils.getString(dataMap, "BASE_CD"));
            //�Y ctrlMap ����  �A�ˮֳ̪񬣥�ޱ�����
            int iPassSeason = calPassSeason(MapUtils.getString(ctrlMap, "APN_STR_SN"), MapUtils.getString(ctrlMap, "EVAL_SN"));
            //�Y�s�򬣥�6�� �ݶ��j�@�~�~�i���s����  �A��X�ˮֿ��~�T�� sbChkApr
            if (MapUtils.getIntValue(ctrlMap, "APN_CNT") >= 6 && iPassSeason < 4) {
                //EP_Z0G151_ERRMSG_008  => {0}�e���ưȩ�:{1}�̪񬣥�u��:{2}�w�s�򦸼�:{3}
                sbChkApr.append(MessageUtil.getMessage("EP_Z0G151_ERRMSG_008", new String[] { MapUtils.getString(reqMap, "BASE_BLD_NAME"), APR_ID_NM, MapUtils.getString(ctrlMap, "EVAL_SN"), MapUtils.getString(ctrlMap, "APN_CNT") }));
                throw new ModuleException(sbChkApr.toString());
            }
        }
    }

    /**�p��g�L�u��
     * @param APN_STR_SN �}�l�e���u��
     * @param EVAL_SN ���ȩu��
     * @return iPassSeason ���j�u��
     */
    private Integer calPassSeason(String APN_STR_SN, String EVAL_SN) {
        int iYear = Integer.parseInt(StringUtils.substring(EVAL_SN, 0, 3));
        int iSeason = Integer.parseInt(StringUtils.substring(EVAL_SN, EVAL_SN.length() - 1));
        int iPassSeason = 0;
        if (StringUtils.isNotEmpty(APN_STR_SN)) {
            int iBegYear = Integer.parseInt(StringUtils.substring(APN_STR_SN, 0, 3));
            int iBegSeason = Integer.parseInt(StringUtils.substring(APN_STR_SN, APN_STR_SN.length() - 1));
            //�g�L�u��
            iPassSeason = ((iYear - iBegYear) * 4 + (iSeason - iBegSeason));
        }
        return iPassSeason;
    }

    /**
     * ��wEIE����
     * 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String value, String key) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * <pre>
     * �w���s��FieldOptionList
     * �J��catch Exception�ì���log�B�a�J�ŭ�
     * </pre>
     * @param sysId
     * @param fieldName
     * @param option
     * @param rtnMap    �^��Map
     * @param rtnKeyName   �N�����^Map��key��
     * @param errMsg    log����
     */
    private void getNameSafe(String sysId, String fieldName, String option, Map rtnMap, String rtnKeyName, String errMsg) {
        try {
            String name = FieldOptionList.getName(sysId, fieldName, option);
            rtnMap.put(rtnKeyName, name);
        } catch (Exception e) {
            log.fatal(errMsg, e);
            rtnMap.put(rtnKeyName, "");
        }
    }

}
