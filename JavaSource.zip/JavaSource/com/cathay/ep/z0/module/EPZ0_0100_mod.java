package com.cathay.ep.z0.module;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.util.FieldOptionList;
import com.cathay.rpt.CsvUtils;

/**
 * <pre>
 * DATE Description Author
 * 2014/02/26  Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �a���H�Ƹ�ƤW���ˮּҲ�
 * �Ҳ�ID    EPZ0_0100_mod
 * ���n����    �a���H�Ƹ�ƤW���ˮּҲ� 
 * </pre>
 * @author ����[
 * @since 2014/3/14
 */
@SuppressWarnings("unchecked")
public class EPZ0_0100_mod {

    /**
     * �ˮ֤W��
     * @param reqMap
     * @throws ErrorInputException
     * @throws IOException
     */
    public void checkUpload(Map reqMap) throws ErrorInputException, IOException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, MessageUtil.getMessage("EPZ0_0100_mod_MSG_001"));//�ǤJ�ѼƤ��o����
        }
        String FL_TP = MapUtils.getString(reqMap, "FL_TP");
        if (StringUtils.isBlank(FL_TP)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPZ0_0100_mod_MSG_002"));//�ǤJ�ɮ��������o���ŭ�!
        } else if (!("1".equals(FL_TP) || "2".equals(FL_TP))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPZ0_0100_mod_MSG_003"));//�ǤJ�ɮ��������~�A�ݬ�[1 OR 2]!
        }
        String DIV_TP = MapUtils.getString(reqMap, "DIV_TP");
        if (StringUtils.isBlank(DIV_TP)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPZ0_0100_mod_MSG_004"));//�ǤJ���O���o���ŭ�!
        }
        FileItem UPL_FILE = (FileItem) reqMap.get("UPL_FILE");
        if (UPL_FILE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPZ0_0100_mod_MSG_005"));//�ǤJ�W���ɮפ��o���ŭ�!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        List<String> lFields = FieldOptionList.getAllName("EP", "FL_FLD_" + FL_TP);
        //FL_FLD_1>>DIV_NO,DIV_SHORT_NAME,NAME,EMPLOYEE_ID,EMP_NO,EMAIL EMAIL,IS_MGR
        //FL_FLD_2>>DIV_NO,DIV_SHORT_NAME,DIV_EMAIL,MGR_ID
        int lFields_size = lFields.size();

        List<String[]> dataList = CsvUtils.parseCsvData(UPL_FILE.getInputStream());
        boolean isFirstRow = true;
        for (String[] data : dataList) {

            if (isFirstRow) {
                //���Ĥ@����Y���ƥػݭn�ۦP 
                if (data.length != lFields_size) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPZ0_0100_mod_MSG_006", new Object[] { lFields }));//�ǤJ�W�������~�A�������:{0} 
                }
                //���Ĥ@����Y���W�٬O�_�ۦP
                for (int index = 0; index < lFields_size; index++) {
                    if (!lFields.get(index).equals(data[index])) {
                        throw new ErrorInputException(MessageUtil.getMessage("EPZ0_0100_mod_MSG_006", new Object[] { lFields }));//�ǤJ�W�������~�A�������:{0} 
                    }
                }
                isFirstRow = false;
            } else {

                String DIV_NO = data[0].substring(0, 1);
                if (!DIV_TP.equals(DIV_NO)) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPZ0_0100_mod_MSG_007"));//�ǤJ�W���ɮ׳��P���O���@�P 
                }
            }
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
