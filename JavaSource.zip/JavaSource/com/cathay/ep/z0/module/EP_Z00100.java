package com.cathay.ep.z0.module;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.rpt.CsvUtils;
import com.cathay.util.Transaction;
import com.cathay.util.TransactionHelper.Platform;
import com.igsapp.db.DataSet;
import com.igsapp.ext.service.crypto.CryptoUtility;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE Description Author
 * 2014/02/26  Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �a���H�Ƹ�ƤW�Ǻ��@�Ҳ�
 * �Ҳ�ID    EP_Z00100
 * ���n����    �a���H�Ƹ�ƤW�Ǻ��@�Ҳ�
 * </pre>
 * @author ����[
 * @since 2014/3/14
 * 2018/08/29 ���ݵo�i��B2C�����B2B�A�t�X�վ�DB�s�u
 */
@SuppressWarnings("unchecked")
public class EP_Z00100 {

    private static final Logger log = Logger.getLogger(EP_Z00100.class);

    private static final String SQL_query_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_query_001";

    private static final String SQL_query_002 = "com.cathay.ep.z0.module.EP_Z00100.SQL_query_002";

    private static final String SQL_writeDTEPZ110_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_writeDTEPZ110_001";

    private static final String SQL_writeDTEPZ110_002 = "com.cathay.ep.z0.module.EP_Z00100.SQL_writeDTEPZ110_002";

    private static final String SQL_updateUser_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_updateUser_001";

    private static final String SQL_getEmpName_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_getEmpName_001";

    private static final String SQL_getDivName_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_getDivName_001";

    private static final String SQL_getDivMgrEmail_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_getDivMgrEmail_001";

    private static final String SQL_getDivEmail_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_getDivEmail_001";

    private static final String SQL_getEmpEmail_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_getEmpEmail_001";

    private static final String SQL_creatDiv_002 = "com.cathay.ep.z0.module.EP_Z00100.SQL_creatDiv_002";

    private static final String SQL_creatDiv_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_creatDiv_001";

    private static final String SQL_updateDiv_002 = "com.cathay.ep.z0.module.EP_Z00100.SQL_updateDiv_002";

    private static final String SQL_updateDiv_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_updateDiv_001";

    private static final String SQL_createUser_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_createUser_001";

    private static final String SQL_createUser_002 = "com.cathay.ep.z0.module.EP_Z00100.SQL_createUser_002";

    private static final String SQL_writeDTEPZ120_003 = "com.cathay.ep.z0.module.EP_Z00100.SQL_writeDTEPZ120_003";

    private static final String SQL_writeDTEPZ120_002 = "com.cathay.ep.z0.module.EP_Z00100.SQL_writeDTEPZ120_002";

    private static final String SQL_writeDTEPZ120_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_writeDTEPZ120_001";

    private static final String SQL_writeDTEPZ110_003 = "com.cathay.ep.z0.module.EP_Z00100.SQL_writeDTEPZ110_003";

    private static final String SQL_getEmpList_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_getEmpList_001";

    private static final String SQL_getEmpListByName_001 = "com.cathay.ep.z0.module.EP_Z00100.SQL_getEmpListByName_001";

    /**
     * �d�߸�Ʒ���
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> query(Map reqMap, boolean isReal, ResponseContext resp, boolean isFirstQuery, Integer startWith, Integer endWith)
            throws ModuleException {

        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, MessageUtil.getMessage("EP_Z00100_MSG_001"));//�ǤJ�ѼƤ��o����
        }
        String FL_TP = MapUtils.getString(reqMap, "FL_TP");
        if (StringUtils.isBlank(FL_TP)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z00100_MSG_002"));//�ǤJ�ɮ��������o���ŭ�!
        } else if (!("1".equals(FL_TP) || "2".equals(FL_TP))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z00100_MSG_003"));//�ǤJ�ɮ��������~�A�ݬ�[1 OR 2]!
        }
        String DIV_TP = MapUtils.getString(reqMap, "DIV_TP");
        if (StringUtils.isBlank(DIV_TP)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z00100_MSG_004"));//�ǤJ���O���o���ŭ�!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();

        if (isReal) {
            ds.setFetchRange(startWith, endWith);//�u�����\�� �_����ƦC �]�w
        }
        //�d�ߤW�Ǹ��
        ds.setField("DIV_TP", DIV_TP);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList;
        if ("1".equals(FL_TP)) { //�H��
            rtnList = VOTool.findToMaps(ds, SQL_query_001);
        } else {
            //���
            rtnList = VOTool.findToMaps(ds, SQL_query_002);
        }

        if (isReal && isFirstQuery) {
            resp.addOutputData("totalOfRecords", ds.getQueryTotalCount()); // ���o-�`����,�u�����\��T�w�ѼƦW��
        }

        return rtnList;

    }

    /**
     * ��ƤW��
     * @param reqMap
     * @param user
     * @throws Exception
     * 2018/08/29 ���ݵo�i��B2C�����B2B�A�t�X�վ�DB�s�u
     */
    public void upload(Map reqMap, UserObject user) throws Exception {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, MessageUtil.getMessage("EP_Z00100_MSG_001"));//�ǤJ�ѼƤ��o����
        }
        String FL_TP = MapUtils.getString(reqMap, "FL_TP");
        if (StringUtils.isBlank(FL_TP)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z00100_MSG_002"));//�ǤJ�ɮ��������o���ŭ�!
        } else if (!("1".equals(FL_TP) || "2".equals(FL_TP))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z00100_MSG_003"));//�ǤJ�ɮ��������~�A�ݬ�[1 OR 2]!
        }
        String DIV_TP = MapUtils.getString(reqMap, "DIV_TP");
        if (StringUtils.isBlank(DIV_TP)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z00100_MSG_004"));//�ǤJ���O���o���ŭ�!
        }
        FileItem UPL_FILE = (FileItem) reqMap.get("UPL_FILE");
        if (UPL_FILE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z00100_MSG_005"));//�ǤJ�W���ɮפ��o���ŭ�!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //���o���W�٩w�q
        List lFields = FieldOptionList.getAllOption("EP", "FL_FLD_" + FL_TP);
        //FL_FLD_1>>DIV_NO,DIV_SHORT_NAME,NAME,EMPLOYEE_ID,EMP_NO,EMAIL EMAIL,IS_MGR
        //FL_FLD_2>>DIV_NO,DIV_SHORT_NAME,DIV_EMAIL,MGR_ID
        DataSet ds = Transaction.getDataSet();
        //���o �H���M��;�������
        List<Map> rtnList;
        try {
            rtnList = this.query(reqMap, false, null, false, null, null);
        } catch (DataNotFoundException e) {
            //�d�L��Ƶ������`
            rtnList = new ArrayList<Map>();
        }
        String today = DATE.getDBDate();
        Timestamp current_time = DATE.currentTime();

        //2018/08/29 ���ݵo�i��B2C�����B2B�A�t�X�վ�DB�s�u
        DataSet ds_b2c = Transaction.getDataSet(Platform.B2B);
        //��XA_MODE �N�W���ɮ׼g�J B2C�P IM ��Ʈw
        if ("1".equals(FL_TP)) {//�H�Ƹ�� 

            List<String> listIDs = new ArrayList<String>();
            for (Map data : rtnList) {
                listIDs.add(MapUtils.getString(data, "EMPLOYEE_ID"));
            }

            //�N��Ƽg�J DTEPZ110 
            List<Map> listMap = writeDTEPZ110(lFields, UPL_FILE, DIV_TP, SUB_CPY_ID, user, ds, today, current_time);

            //�N�H����Ƽg�J DTA0_EMPLOYEE, DTZZA006
            writeEmployeeToB2C(listMap, listIDs, ds_b2c, today, current_time);

        } else { //�����

            List<String> listDIVs = new ArrayList<String>();
            for (Map data : rtnList) {
                listDIVs.add(MapUtils.getString(data, "DIV_NO"));
            }

            //�N��Ƽg�J DTEPZ120 
            List<Map> listMap = writeDTEPZ120(lFields, UPL_FILE, DIV_TP, SUB_CPY_ID, user, ds, today, current_time);

            //�N�H����Ƽg�J DTZ0_UNIT, DTZ0_UNITMANAGER
            writeDivToB2C(listMap, listDIVs, ds_b2c, today);

        }
    }

    /**
     * �H����ƤW��
     * @param fldList
     * @param uplFile
     * @param DIV_TP
     * @param user
     * @param ds
     * @return
     * @throws ModuleException
     * @throws IOException
     */
    private List<Map> writeDTEPZ110(List<String> fldList, FileItem uplFile, String DIV_TP, String SUB_CPY_ID, UserObject user, DataSet ds,
            String today, Timestamp current_time) throws ModuleException, IOException {

        ds.clear();
        //�NDTEPZ110 ��� �g�J LOG��
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("DIV_TP", DIV_TP);
        try {
            DBUtil.executeUpdate(ds, SQL_writeDTEPZ110_001);
        } catch (DataNotFoundException e) {
            //�d�L��Ƶ������`
            log.error("�d�L��Ƶ������`", e);
        }

        //�M��DTEPZ110���
        ds.clear();
        ds.setField("DIV_TP", DIV_TP);
        ds.setField("CURRENTDATE", DATE.getDBDate());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_writeDTEPZ110_002);
        } catch (DataNotFoundException e) {
            //�d�L��Ƶ������`
            log.error("�d�L��Ƶ������`", e);
        }

        List<Map> rtnList = new ArrayList<Map>();

        //���o����
        int fldSize = fldList.size();
        List<String[]> dataList = CsvUtils.parseCsvData(uplFile.getInputStream());
        boolean isFirstRow = true;
        String emp_id = user.getEmpID();
        String emp_name = user.getEmpName();
        for (String[] fields : dataList) {
            //�Ĥ@�欰���Y�A�����~��B�z�U�@��
            if (isFirstRow) {
                isFirstRow = false;
            } else {
                Map data = new HashMap();
                for (int i = 0; i < fldSize; i++) {
                    //�����N���A�N�ɮ׹������ȩ�J
                    data.put(fldList.get(i), fields[i]);
                }

                data.put("DIV_TP", DIV_TP);
                data.put("UPLOAD_DATE", today);
                data.put("CHG_DATE", current_time);
                data.put("CHG_ID", emp_id);
                data.put("CHG_NAME", emp_name);
                String DIV_NO = MapUtils.getString(data, "DIV_NO");
                data.put("ORI_DIV_NO", DIV_NO);
                data.put("DIV_NO", tranDivNo(DIV_NO));
                data.put("SUB_CPY_ID", SUB_CPY_ID);
                //�N data ���ȼg�J DTEPZ110 
                ds.clear();
                VOTool.mapToDataSet(data, ds);
                DBUtil.executeUpdate(ds, SQL_writeDTEPZ110_003);

                rtnList.add(data);
            }

        }
        return rtnList;
    }

    /**
     * ����ƤW��
     * @param fldList
     * @param uplFile
     * @param DIV_TP
     * @param user
     * @param ds
     * @return
     * @throws ModuleException
     * @throws IOException
     */
    private List<Map> writeDTEPZ120(List<String> fldList, FileItem uplFile, String DIV_TP, String SUB_CPY_ID, UserObject user, DataSet ds,
            String today, Timestamp current_time) throws ModuleException, IOException {

        ds.clear();
        //�NDTEPZ120 ��� �g�J LOG��
        ds.setField("DIV_TP", DIV_TP);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_writeDTEPZ120_001);
        } catch (DataNotFoundException e) {
            //�d�L��Ƶ������`
            log.error("�d�L��Ƶ������`", e);
        }

        //�M��DTEPZ120���
        ds.clear();
        ds.setField("DIV_TP", DIV_TP);
        ds.setField("CURRENTDATE", today);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_writeDTEPZ120_002);
        } catch (DataNotFoundException e) {
            //�d�L��Ƶ������`
            log.error("�d�L��Ƶ������`", e);
        }

        List<Map> rtnList = new ArrayList<Map>();

        //���o����
        int fldSize = fldList.size();
        List<String[]> dataList = CsvUtils.parseCsvData(uplFile.getInputStream());
        boolean isFirstRow = true;

        String emp_id = user.getEmpID();
        String emp_name = user.getEmpName();
        for (String[] fields : dataList) {
            //�Ĥ@�欰���Y�A�����~��B�z�U�@��
            if (isFirstRow) {
                isFirstRow = false;
            } else {
                Map data = new HashMap();
                for (int i = 0; i < fldSize; i++) {
                    //�����N���A�N�ɮ׹������ȩ�J
                    data.put(fldList.get(i), fields[i]);
                }

                data.put("DIV_TP", DIV_TP);
                data.put("UPLOAD_DATE", today);
                data.put("CHG_DATE", current_time);
                data.put("CHG_ID", emp_id);
                data.put("CHG_NAME", emp_name);
                String DIV_NO = MapUtils.getString(data, "DIV_NO");
                data.put("ORI_DIV_NO", DIV_NO);
                data.put("DIV_NO", tranDivNo(DIV_NO));
                data.put("SUB_CPY_ID", SUB_CPY_ID);
                //�N data ���ȼg�J DTEPZ120 
                ds.clear();
                VOTool.mapToDataSet(data, ds);
                DBUtil.executeUpdate(ds, SQL_writeDTEPZ120_003);

                rtnList.add(data);
            }

        }
        return rtnList;
    }

    /**
     *  �H����ƤW��
     * @param uplList
     * @param listIds
     * @param ds
     * @throws Exception
     */
    private void writeEmployeeToB2C(List<Map> uplList, List<String> listIds, DataSet ds, String today, Timestamp current_time)
            throws Exception {
        //�v���B�z�W�Ǹ��
        for (Map data : uplList) {
            //Format CXLHR.DTA0_EMPLOYEE
            data.put("EFFECT_DATE", DATE.toROCDate(today));//8 �X����~ 
            data.put("TRUTH_DATE", today);
            data.put("STATUS", "1"); //�ʺA
            data.put("DIV_NO", tranDivNo(MapUtils.getString(data, "DIV_NO")));
            data.put("POSITION", "EP"); //¾�ťN��
            data.put("USER_CATEGORY_ID", "EP");
            data.put("UPDATED_DT", data.get("UPLOAD_DATE"));
            data.put("UPDATED_USER_ID", data.get("CHG_ID"));
            if (listIds.contains(MapUtils.getString(data, "EMPLOYEE_ID"))) {
                try {
                    this.updateUser(data, ds);
                } catch (DataNotFoundException e) {
                    this.createUser(data, ds, current_time);
                }
            } else {
                this.createUser(data, ds, current_time);
            }
        }
    }

    /**
     * ����ƤW��
     * @param uplList
     * @param listDivs
     * @param ds
     * @throws UnsupportedEncodingException
     * @throws ModuleException
     */
    private void writeDivToB2C(List<Map> uplList, List<String> listDivs, DataSet ds, String today) throws UnsupportedEncodingException,
            ModuleException {
        //�v���B�z�W�Ǹ��
        for (Map data : uplList) {
            //Format CXLHR.DTA0_EMPLOYEE
            String DIV_NO = MapUtils.getString(data, "DIV_NO");
            data.put("DIV_NO", tranDivNo(DIV_NO));
            data.put("DIV_CHANGE_STATUS", "1");
            data.put("ETB_EFFECT_DATE", DATE.toROCDate(today));//��즨�ߥͮĤ��//8�X����~ 
            data.put("RVK_EFFECT_DATE", null);//8�X����~
            data.put("UNIT_ORG_ID", "EP");
            data.put("DIV_FULL_NAME", MessageUtil.getMessage("EP_Z00100_MSG_006")/*�M��Ӻ�*/+ MapUtils.getString(data, "DIV_SHORT_NAME"));
            //�P�_�O�_���s���
            if (listDivs.contains(DIV_NO)) {
                try {
                    this.updateDiv(data, ds, today);
                } catch (DataNotFoundException e) {
                    this.createDiv(data, ds, today);
                }
            } else {
                try {
                    this.createDiv(data, ds, today);
                } catch (DataDuplicateException dde) {
                    this.updateDiv(data, ds, today);
                }

            }
        }
    }

    /**
     * ��s�H�����
     * @param data
     * @param ds
     * @throws ModuleException
     */
    private void updateUser(Map data, DataSet ds) throws ModuleException {
        ds.clear();
        ds.setField("NAME", data.get("NAME")); //���u�m�W
        ds.setField("STATUS", data.get("STATUS")); //�H�ưʺA
        ds.setField("EFFECT_DATE", data.get("EFFECT_DATE")); //�u�@��ͮĤ��//8�X����~
        ds.setField("TRUTH_DATE", data.get("TRUTH_DATE")); //��ڥͮĤ��//Date
        ds.setField("DIV_NO", data.get("DIV_NO")); //���N��
        ds.setField("POSITION", data.get("POSITION")); //¾�ťN��
        ds.setField("EMAIL", data.get("EMAIL")); //�q�l�l��a�}
        ds.setField("USER_CATEGORY_ID", data.get("USER_CATEGORY_ID")); //�H���s��O�N��
        ds.setField("EMPLOYEE_ID", data.get("EMPLOYEE_ID"));
        DBUtil.executeUpdate(ds, SQL_updateUser_001);
    }

    /**
     * �s�W�H�����
     * @param data
     * @param ds
     * @throws Exception
     */
    private void createUser(Map data, DataSet ds, Timestamp current_time) throws Exception {

        //�u��s B2C �H����ơv
        //�s�W�H�����  
        String EMPLOYEE_ID = MapUtils.getString(data, "EMPLOYEE_ID");
        try {
            ds.clear();
            ds.setField("NAME", data.get("NAME")); //���u�m�W
            ds.setField("STATUS", data.get("STATUS")); //�H�ưʺA
            ds.setField("EFFECT_DATE", data.get("EFFECT_DATE")); //�u�@��ͮĤ��//8�X����~
            ds.setField("TRUTH_DATE", data.get("TRUTH_DATE")); //��ڥͮĤ��//Date
            ds.setField("DIV_NO", data.get("DIV_NO")); //���N��
            ds.setField("POSITION", data.get("POSITION")); //¾�ťN��
            ds.setField("EMAIL", data.get("EMAIL")); //�q�l�l��a�}
            ds.setField("USER_CATEGORY_ID", data.get("USER_CATEGORY_ID")); //�H���s��O�N��
            ds.setField("EMPLOYEE_ID", data.get("EMPLOYEE_ID"));
            if (data.get("UPDATED_DT") == null) {
                ds.setField("UPDATED_DT", data.get("UPDATED_DT"));
            } else {
                ds.setField("UPDATED_DT", DATE.getDBTimeStamp(data.get("UPDATED_DT").toString()));
            }
            ds.setField("UPDATED_USER_ID", data.get("UPDATED_USER_ID"));
            DBUtil.executeUpdate(ds, SQL_createUser_001);
        } catch (DataDuplicateException dde) {
            try {
                updateUser(data, ds);
            } catch (DataNotFoundException e) {
                //�d�L��Ƶ������`
                log.error("�d�L��Ƶ������`", e);
            }
        }

        try {
            //�s�WB2C�n�J��
            ds.clear();
            ds.setField("USER_ID", data.get("EMPLOYEE_ID")); //���u�N��
            CryptoUtility cu = CryptoUtility.getInstance();
            ds.setField("USER_PWD", cu.doEncrypt(EMPLOYEE_ID));//�K�X
            ds.setField("UPD_TIME", current_time); //�@�~�ɶ�
            ds.setField("UPD_ID", data.get("CHG_ID")); //�@�~�H��
            DBUtil.executeUpdate(ds, SQL_createUser_002);
        } catch (DataDuplicateException dde) {
            //��Ƥw�s�b�������`
            log.error("��Ƥw�s�b�������`", dde);
        }

    }

    /**
     * ��s�����
     * @param data
     * @param ds
     * @throws ModuleException
     */
    private void updateDiv(Map data, DataSet ds, String today) throws ModuleException {

        //�u��s B2C ����ơv
        //��s�����
        ds.clear();
        ds.setField("DIV_CHANGE_STATUS", data.get("DIV_CHANGE_STATUS")); //���ʺA
        ds.setField("ETB_EFFECT_DATE", data.get("ETB_EFFECT_DATE")); //��즨�ߥͮĤ��//8�X����~
        ds.setField("RVK_EFFECT_DATE", data.get("RVK_EFFECT_DATE")); //���M�P�ͮĤ��//8�X����~
        ds.setField("UNIT_ORG_ID", data.get("UNIT_ORG_ID")); //���s��O�N��
        ds.setField("DIV_SHORT_NAME", data.get("DIV_SHORT_NAME")); //���²��
        ds.setField("DIV_FULL_NAME", data.get("DIV_FULL_NAME")); //������
        ds.setField("DIV_OLD_NAME", data.get("DIV_OLD_NAME")); //����º�
        ds.setField("DIV_EMAIL", data.get("DIV_EMAIL")); //���H�c
        ds.setField("DIV_NO", data.get("DIV_NO")); //���N��
        DBUtil.executeUpdate(ds, SQL_updateDiv_001);

        ds.clear();
        ds.setField("MGR_DATE", DATE.toROCDate(today)); //�g�ޤ��  //8�X����~
        ds.setField("EMPLOYEE_ID", data.get("MGR_ID")); //�D��ID
        ds.setField("EXEMPT", null); //�K�ޤ��
        ds.setField("DIV_NO", data.get("DIV_NO")); //���N��
        DBUtil.executeUpdate(ds, SQL_updateDiv_002);

    }

    /**
     * �s�W�����
     * @param data
     * @param ds
     * @throws ModuleException
     */
    private void createDiv(Map data, DataSet ds, String today) throws ModuleException {

        ds.clear();
        ds.setField("DIV_CHANGE_STATUS", data.get("DIV_CHANGE_STATUS")); //���ʺA
        ds.setField("ETB_EFFECT_DATE", data.get("ETB_EFFECT_DATE")); //��즨�ߥͮĤ��//8�X����~
        ds.setField("RVK_EFFECT_DATE", data.get("RVK_EFFECT_DATE")); //���M�P�ͮĤ��//8�X����~
        ds.setField("UNIT_ORG_ID", data.get("UNIT_ORG_ID")); //���s��O�N��
        ds.setField("DIV_SHORT_NAME", data.get("DIV_SHORT_NAME")); //���²��
        ds.setField("DIV_FULL_NAME", data.get("DIV_FULL_NAME")); //������
        ds.setField("DIV_OLD_NAME", data.get("DIV_OLD_NAME")); //����º�
        ds.setField("DIV_EMAIL", data.get("DIV_EMAIL")); //���H�c
        ds.setField("DIV_NO", data.get("DIV_NO")); //���N��
        DBUtil.executeUpdate(ds, SQL_creatDiv_001);

        ds.clear();
        ds.setField("MGR_DATE", DATE.toROCDate(today)); //�g�ޤ��//8�X����~
        ds.setField("EMPLOYEE_ID", data.get("MGR_ID")); //�D��ID
        ds.setField("EXEMPT", null); //�K�ޤ��
        ds.setField("DIV_NO", data.get("DIV_NO")); //���N��
        DBUtil.executeUpdate(ds, SQL_creatDiv_002);

    }

    /**
     * ���N����X
     * @param divNo
     * @return
     * @throws UnsupportedEncodingException
     */
    private String tranDivNo(String divNo) throws UnsupportedEncodingException {
        if (!divNo.startsWith("EP9")) {
            String newDivNo = "EP9" + divNo.substring(1);
            return STRING.fillCharFromRightExt(newDivNo, 7, '0');
        } else {
            return STRING.fillCharFromRightExt(divNo, 7, '0');
        }
    }

    /**
     * �d�߼ӺޤH��EMail
     * @param empID
     * @param ds
     * @return
     * @throws ModuleException
     */
    public String getEmpEmail(String empID, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(empID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z00100_MSG_007"));//�H��ID���i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("empID", empID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_getEmpEmail_001);
        ds.next();
        return (String) ds.getField("EMAIL");
    }

    /**
     * �d�߼Ӻ޳��EMail
     * @param divNo
     * @param ds
     * @return
     * @throws ModuleException
     */
    public String getDivEmail(String divNo, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(divNo)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z00100_MSG_008"));//���N�����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("divNo", divNo);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_getDivEmail_001);
        ds.next();
        return (String) ds.getField("DIV_EMAIL");
    }

    /**
     * �d�߼Ӻ޳��D�޸��
     * @param divNo
     * @param ds
     * @return
     * @throws ModuleException
     */
    public Map getDivMgr(String divNo, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(divNo)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z00100_MSG_008"));//���N�����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("divNo", divNo);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_getDivMgrEmail_001);
        ds.next();
        return VOTool.dataSetToMap(ds);
    }

    /**
     * �d�߼Ӻ޳��W��
     * @param divNo
     * @param ds
     * @return
     * @throws ModuleException
     */
    public String getDivName(String divNo, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(divNo)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z00100_MSG_008"));//���N�����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("divNo", divNo);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_getDivName_001);
        ds.next();
        return (String) ds.getField("DIV_SHORT_NAME");
    }

    /**
     * �d�߼ӺޤH���W��
     * @param empId
     * @param ds
     * @return
     * @throws ModuleException
     */
    public Map getEmp(String empId, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(empId)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z00100_MSG_007"));//�H��ID���i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("empId", empId);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_getEmpName_001);
        ds.next();
        return VOTool.dataSetToMap(ds);
    }

    /**
     * �d�߳��H���M����
     * @param divNo
     * @param ds
     * @return
     * @throws ModuleException
     */
    public List<Map> getEmpList(String divNo, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(divNo)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z00100_MSG_008"));//���N�����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("divNo", divNo);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_getEmpList_001);
        List<Map> mapList = VOTool.dataSetToMaps(ds);
        List<Map> rtnList = new ArrayList<Map>();
        for (Map map : mapList) {
            Map newMap = new HashMap<String, String>();
            newMap.put("EMP_ID", MapUtils.getString(map, "EMPLOYEE_ID"));
            newMap.put("EMP_NAME", MapUtils.getString(map, "NAME"));
            rtnList.add(newMap);
        }
        return rtnList;
    }

    /**
     * [20190715] �d�߬������ǤH���M��
     * @param empName
     * @return
     * @throws ModuleException
     */
    public List<Map> getEmpListByName(String empName) throws ModuleException {

        DataSet ds = Transaction.getDataSet();
        StringBuilder sb = new StringBuilder();

        ds.setField("DIV_TP", "Q2" + '%');
        ds.setField("REQ_NM", sb.append('%').append(empName).append('%').toString());

        return VOTool.findToMaps(ds, SQL_getEmpListByName_001);

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}
