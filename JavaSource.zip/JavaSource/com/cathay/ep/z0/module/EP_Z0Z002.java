package com.cathay.ep.z0.module;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPZ002;
import com.cathay.ep.vo.DTEPZ002_LOG;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE    Description Author
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �t�ΥN�X�]�w�ɬd�ߺ��@�Ҳ�
 * �Ҳ�ID    EP_Z0Z002
 * ���n����    �t�ΥN�X�]�w�ɬd�ߺ��@�Ҳ�
 * </pre>
 * @author �L�ç�
 * @since 2016/11/28
 */
@SuppressWarnings("unchecked")
public class EP_Z0Z002 {

    private static final String SQL_queryDTEPZ002_001 = "com.cathay.ep.z0.module.EP_Z0Z002.SQL_queryDTEPZ002_001";

    private static final String SQL_deleteDTEPZ002_001 = "com.cathay.ep.z0.module.EP_Z0Z002.SQL_deleteDTEPZ002_001";

    /**
     * �d�ߨt�ΥN�X�M��
     * @param KEY1 �N�X����
     * @param KEY2 ���N�X
     * @param KEY3 �N�X
     * @return List<Map>
     * @throws ModuleException 
     */
    public List<Map> queryDTEPZ002(String KEY1, String KEY2, String KEY3, String SUB_CPY_ID) throws ModuleException {
        return this.queryDTEPZ002(KEY1, KEY2, KEY3, SUB_CPY_ID, true);
    }

    /**
     * �d�ߨt�ΥN�X�M��
     * @param KEY1 �N�X����
     * @param KEY2 ���N�X
     * @param KEY3 �N�X
     * @return List<Map>
     * @throws ModuleException 
     */
    public List<Map> queryDTEPZ002(String KEY1, String KEY2, String KEY3, String SUB_CPY_ID, boolean DataNotFoundIsError)
            throws ModuleException {
        if (StringUtils.isBlank(KEY1)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0Z002_MSG_001"));//�N�X�������o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("KEY1", KEY1);
        if (StringUtils.isNotEmpty(KEY2)) {
            ds.setField("KEY2", KEY2);
        }
        if (StringUtils.isNotEmpty(KEY3)) {
            ds.setField("KEY3", KEY3);
        }
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (DataNotFoundIsError) {
            return VOTool.findToMaps(ds, SQL_queryDTEPZ002_001);
        } else {
            return VOTool.findToMaps(ds, SQL_queryDTEPZ002_001, false);
        }
    }

    /**
     * �R���t�ΥN�X�M��
     * @param reqMap
     * @throws ModuleException 
     */
    public void deleteDTEPZ002(Map reqMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "EP_Z0Z002_MSG_004");//�ϥΪ̸�T���o����
        }
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_Z0Z002_MSG_002");//�t�ΥN�X�ɤ��o����
        }
        String KEY1 = MapUtils.getString(reqMap, "KEY1");
        String KEY2 = MapUtils.getString(reqMap, "KEY2");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(KEY1)) {
            eie = getErrorInputException(eie, "EP_Z0Z002_MSG_001");//�N�X�������o����
        }
        if (StringUtils.isBlank(KEY2)) {
            eie = getErrorInputException(eie, "EP_Z0Z002_MSG_003");//���N�X���o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        List<Map> List = this.queryDTEPZ002(KEY1, KEY2, null, SUB_CPY_ID, false);

        if (List != null) {
            String DIV_NO = user.getDivNo();
            String EMP_ID = user.getEmpID();
            String EMP_NM = user.getEmpName();

            Timestamp currentTime = DATE.currentTime();
            //�s�WLOG
            for (Map map : List) {
                DTEPZ002_LOG Z002Vo_Log = VOTool.mapToVO(DTEPZ002_LOG.class, map);
                Z002Vo_Log.setUPD_DATE(currentTime);
                Z002Vo_Log.setUPD_TYPE("D");
                Z002Vo_Log.setUPD_DIV_NO(DIV_NO);
                Z002Vo_Log.setUPD_ID(EMP_ID);
                Z002Vo_Log.setUPD_NAME(EMP_NM);
                VOTool.insert(Z002Vo_Log);
            }

            DataSet ds = Transaction.getDataSet();
            ds.setField("KEY1", KEY1);
            ds.setField("KEY2", KEY2);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_deleteDTEPZ002_001);
        }
    }

    /**
     * �s�W�t�ΥN�X�M��
     * @param reqMap
     * @param List
     * @param user �ϥΪ̸�T
     * @throws ModuleException 
     */
    public void insertDTEPZ002(Map reqMap, List<Map> List, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "EP_Z0Z002_MSG_004");//�ϥΪ̸�T���o����
        }
        if (List == null || List.isEmpty()) {
            eie = getErrorInputException(eie, "EP_Z0Z002_MSG_005");//�t�ΥN�X���Ӹ�Ƥ��o����
        }
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_Z0Z002_MSG_002");//�t�ΥN�X�ɤ��o����
        }
        String KEY1 = MapUtils.getString(reqMap, "KEY1");
        String KEY2 = MapUtils.getString(reqMap, "KEY2");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(KEY1)) {
            eie = getErrorInputException(eie, "EP_Z0Z002_MSG_001");//�N�X�������o����
        }
        if (StringUtils.isBlank(KEY2)) {
            eie = getErrorInputException(eie, "EP_Z0Z002_MSG_003");//���N�X���o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        for (Map map : List) {
            if (StringUtils.isBlank(MapUtils.getString(map, "KEY3"))) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0Z002_MSG_006"));//�N�X���o����
            }
        }

        String DIV_NO = user.getDivNo();
        String EMP_ID = user.getEmpID();
        String EMP_NM = user.getEmpName();

        Timestamp currentTime = DATE.currentTime();
        for (Map map : List) {
            map.put("KEY1", KEY1);
            map.put("KEY2", KEY2);
            map.put("SUB_CPY_ID", SUB_CPY_ID);
            DTEPZ002 Z002Vo = VOTool.mapToVO(DTEPZ002.class, map);
            Z002Vo.setCHG_DATE(currentTime);
            Z002Vo.setCHG_DIV_NO(DIV_NO);
            Z002Vo.setCHG_ID(EMP_ID);
            Z002Vo.setCHG_NAME(EMP_NM);
            VOTool.insert(Z002Vo);
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}