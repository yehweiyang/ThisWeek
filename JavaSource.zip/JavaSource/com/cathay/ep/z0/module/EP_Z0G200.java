package com.cathay.ep.z0.module;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014/09/17  Created ������
 * 
 * �@�B  �ҲզW��	��a�����ƺ��@�Ҳ�
 * �Ҳ�ID	EP_Z0G200
 * ���n����	��a�����ƺ��@�Ҳ�
 * </pre>
 * @author ������
 * @since 2014/12/29
 */
@SuppressWarnings("unchecked")
public class EP_Z0G200 {

    private static final Logger log = Logger.getLogger(EP_Z0G200.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G200.SQL_queryList_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0G200.SQL_queryMap_001";

    private static final String SQL_update_001 = "com.cathay.ep.z0.module.EP_Z0G200.SQL_update_001";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0G200.SQL_delete_001";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0G200.SQL_insert_001";

    private static final String SQL_confirm_001 = "com.cathay.ep.z0.module.EP_Z0G200.SQL_confirm_001";

    private static final String SQL_approve_001 = "com.cathay.ep.z0.module.EP_Z0G200.SQL_approve_001";

    /**
     * Ū����a����M��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G200_MSG_001"));//�ǤJ��T���o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G200_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
        }
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");

        List<Map> rtnList;
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotEmpty(BASE_CD)) {
            ds.setField("BASE_CD", sb.append("%").append(BASE_CD).append("%").toString());
        }

        String TRN_DATE_BEG = MapUtils.getString(reqMap, "TRN_DATE_BEG");
        setFieldIfExist(ds, "TRN_DATE_BEG", TRN_DATE_BEG);
        String TRN_DATE_END = MapUtils.getString(reqMap, "TRN_DATE_END");
        setFieldIfExist(ds, "TRN_DATE_END", TRN_DATE_END);

        String COST_CD = MapUtils.getString(reqMap, "COST_CD");
        setFieldIfExist(ds, "COST_CD", COST_CD);

        rtnList = VOTool.findToMaps(ds, SQL_queryList_001);

        for (Map rtnMap : rtnList) {
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "G0_TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            rtnMap.put("COST_CD_NM", FieldOptionList.getName("EP", "COST_CD", MapUtils.getString(rtnMap, "COST_CD")));
        }

        return rtnList;
    }

    /**
     * Ū����a��������
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryMap(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        String APLY_NO = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G200_MSG_001"));//�ǤJ��T���o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            if (StringUtils.isBlank(BASE_CD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_003"));//�ǤJ��a�N�����o���ŭ�
            }
            APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            if (StringUtils.isBlank(APLY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_004"));//�ǤJ�ץ�s�����o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        Map rtnMap = null;
        DataSet ds = Transaction.getDataSet();

        //�YAPLY_NO����
        //�H�ǤJ�����q�O�d�߮ץ�_��a�򥻸���ܧ����(DTEPB312)�G
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        StringBuilder sb = new StringBuilder();
        ds.setField("BASE_CD", sb.append("%").append(BASE_CD).append("%").toString());
        ds.setField("APLY_NO", APLY_NO);
        rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001, false);
        if (rtnMap != null) {
            //���o�u����v����:
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "G0_TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            //���o�u�����������A�v����:
            rtnMap.put("COST_CD_NM", FieldOptionList.getName("EP", "COST_CD", MapUtils.getString(rtnMap, "COST_CD")));
        }
        return rtnMap;

    }

    /**
     * �ק�
     * @param dataMap   ��a��������
     * @param user      �@�~�H��
     * @throws ModuleException 
     */
    public void update(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G200_MSG_001")); //�ǤJ��T���o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID", "");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(dataMap, "BASE_CD", "");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_003"));//�ǤJ��a�N�����o���ŭ�
        }
        String APLY_NO = MapUtils.getString(dataMap, "APLY_NO", "");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_004"));//�ǤJ�ץ�s�����o���ŭ�
        }

        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G103_MSG_006")); //�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //��s�������������T
        DataSet ds = Transaction.getDataSet();
        setDSFields(dataMap, ds);
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        DBUtil.executeUpdate(ds, SQL_update_001);
    }

    /**
     * �R��
     * @param dataMap   ��a��������
     * @param user      �@�~�H��
     * @throws ModuleException 
     */
    public void delete(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G200_MSG_001")); //�ǤJ��T���o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID", "");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(dataMap, "BASE_CD", "");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_003"));//�ǤJ��a�N�����o���ŭ�
        }
        String APLY_NO = MapUtils.getString(dataMap, "APLY_NO", "");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_004"));//�ǤJ�ץ�s�����o���ŭ�
        }

        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_006")); //�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�R���������������T
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("APLY_NO", APLY_NO);
        DBUtil.executeUpdate(ds, SQL_delete_001);
    }

    /**
     * �s�W
     * @param dataMap   ��a��������
     * @param user      �@�~�H��
     * @throws ModuleException 
     */
    public void insert(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G200_MSG_001")); //�ǤJ��T���o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID", "");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(dataMap, "BASE_CD", "");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_003"));//�ǤJ��a�N�����o���ŭ�
        }
        String APLY_NO = MapUtils.getString(dataMap, "APLY_NO", "");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_004"));//�ǤJ�ץ�s�����o���ŭ�
        }

        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_006")); //�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�s�W�������������T
        DataSet ds = Transaction.getDataSet();
        // SET FIELDS By dataMap
        setDSFields(dataMap, ds);
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        ds.setField("TRN_STS", "01");
        String TRN_KIND = MapUtils.getString(dataMap, "TRN_KIND");
        String[] TRN_KINDArray = { "EPG201", "EPG202", "EPG203", "EPG205" };
        if (ArrayUtils.contains(TRN_KINDArray, TRN_KIND)) {
            ds.setField("COST_CD", "1");
        } else {
            ds.setField("COST_CD", "0");
        }
        DBUtil.executeUpdate(ds, SQL_insert_001);
    }

    private void setDSFields(Map dataMap, DataSet ds) {
        ds.setField("SUB_CPY_ID", dataMap.get("SUB_CPY_ID"));
        ds.setField("BASE_CD", dataMap.get("BASE_CD"));
        ds.setField("APLY_NO", dataMap.get("APLY_NO"));
        ds.setField("TRN_AMT", StringUtils.isBlank(MapUtils.getString(dataMap, "TRN_AMT")) ? null : dataMap.get("TRN_AMT"));
        ds.setField("TRN_DATE", StringUtils.isBlank(MapUtils.getString(dataMap, "TRN_DATE")) ? null : dataMap.get("TRN_DATE"));
        ds.setField("IFRS_INV_RT", StringUtils.isBlank(MapUtils.getString(dataMap, "IFRS_INV_RT")) ? null : dataMap.get("IFRS_INV_RT"));
        ds.setField("DEAL_ID", dataMap.get("DEAL_ID"));
        ds.setField("DEAL_NM", dataMap.get("DEAL_NM"));
        ds.setField("CRT_DATE", StringUtils.isBlank(MapUtils.getString(dataMap, "CRT_DATE")) ? null : dataMap.get("CRT_DATE"));
        ds.setField("FIX_APLY_NO", dataMap.get("FIX_APLY_NO"));
        ds.setField("FIX_AMT", StringUtils.isBlank(MapUtils.getString(dataMap, "FIX_AMT")) ? null : dataMap.get("FIX_AMT"));
        ds.setField("LND_AMT", StringUtils.isBlank(MapUtils.getString(dataMap, "LND_AMT")) ? null : dataMap.get("LND_AMT"));
        ds.setField("BLD_AMT", StringUtils.isBlank(MapUtils.getString(dataMap, "BLD_AMT")) ? null : dataMap.get("BLD_AMT"));
        ds.setField("BUS_TAX", StringUtils.isBlank(MapUtils.getString(dataMap, "BUS_TAX")) ? null : dataMap.get("BUS_TAX"));
        ds.setField("D_LND_AREA", StringUtils.isBlank(MapUtils.getString(dataMap, "D_LND_AREA")) ? null : dataMap.get("D_LND_AREA"));
        ds.setField("D_BLD_AREA", StringUtils.isBlank(MapUtils.getString(dataMap, "D_BLD_AREA")) ? null : dataMap.get("D_BLD_AREA"));
        ds.setField("LND_COST", StringUtils.isBlank(MapUtils.getString(dataMap, "LND_COST")) ? null : dataMap.get("LND_COST"));
        ds.setField("BLD_COST", StringUtils.isBlank(MapUtils.getString(dataMap, "BLD_COST")) ? null : dataMap.get("BLD_COST"));
        ds.setField("LND_PL", StringUtils.isBlank(MapUtils.getString(dataMap, "LND_PL")) ? null : dataMap.get("LND_PL"));
        ds.setField("BLD_PL", StringUtils.isBlank(MapUtils.getString(dataMap, "BLD_PL")) ? null : dataMap.get("BLD_PL"));

        ds.setField("D_LND_EV", StringUtils.isBlank(MapUtils.getString(dataMap, "D_LND_EV")) ? null : dataMap.get("D_LND_EV"));
        ds.setField("D_BLD_EV", StringUtils.isBlank(MapUtils.getString(dataMap, "D_BLD_EV")) ? null : dataMap.get("D_BLD_EV"));
        ds.setField("SUM_CUR_DEPR", StringUtils.isBlank(MapUtils.getString(dataMap, "SUM_CUR_DEPR")) ? null : dataMap.get("SUM_CUR_DEPR"));
        ds.setField("SUM_D_DEPR_AMT", StringUtils.isBlank(MapUtils.getString(dataMap, "SUM_D_DEPR_AMT")) ? null : dataMap
                .get("SUM_D_DEPR_AMT"));
        ds.setField("LAND_ADD_TAX", StringUtils.isBlank(MapUtils.getString(dataMap, "LAND_ADD_TAX")) ? null : dataMap.get("LAND_ADD_TAX"));
        ds.setField("TOT_LND_AREA", StringUtils.isBlank(MapUtils.getString(dataMap, "TOT_LND_AREA")) ? null : dataMap.get("TOT_LND_AREA"));
        ds.setField("TOT_BLD_AREA", StringUtils.isBlank(MapUtils.getString(dataMap, "TOT_BLD_AREA")) ? null : dataMap.get("TOT_BLD_AREA"));
        ds.setField("TOT_LND_COST", StringUtils.isBlank(MapUtils.getString(dataMap, "TOT_LND_COST")) ? null : dataMap.get("TOT_LND_COST"));
        ds.setField("TOT_BLD_COST", StringUtils.isBlank(MapUtils.getString(dataMap, "TOT_BLD_COST")) ? null : dataMap.get("TOT_BLD_COST"));
        ds.setField("TOT_LND_EV", StringUtils.isBlank(MapUtils.getString(dataMap, "TOT_LND_EV")) ? null : dataMap.get("TOT_LND_EV"));
        ds.setField("TOT_BLD_EV", StringUtils.isBlank(MapUtils.getString(dataMap, "TOT_BLD_EV")) ? null : dataMap.get("TOT_BLD_EV"));
        ds.setField("TOT_DEPR_AMT", StringUtils.isBlank(MapUtils.getString(dataMap, "TOT_DEPR_AMT")) ? null : dataMap.get("TOT_DEPR_AMT"));
        ds.setField("TRN_STS", dataMap.get("TRN_STS"));
        ds.setField("CHG_DATE", dataMap.get("CHG_DATE"));
        ds.setField("CHG_DIV_NO", dataMap.get("CHG_DIV_NO"));
        ds.setField("CHG_ID", dataMap.get("CHG_ID"));
        ds.setField("CHG_NAME", dataMap.get("CHG_NAME"));
        ds.setField("COST_CD", dataMap.get("COST_CD"));
        ds.setField("COST_DATE", StringUtils.isBlank(MapUtils.getString(dataMap, "COST_DATE")) ? null : dataMap.get("COST_DATE"));
        ds.setField("COST_DIV_NO", dataMap.get("COST_DIV_NO"));
        ds.setField("COST_ID", dataMap.get("COST_ID"));
        ds.setField("COST_NAME", dataMap.get("COST_NAME"));
    }

    /**
     * ��s�����Ƥ��������B�z���A
     * @param dataMap   ��a��������
     * @param user      �@�~�H��
     * @throws ModuleException 
     */
    public void confirm(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G200_MSG_001")); //�ǤJ��T���o���ŭ�
        }
        try {
            dataMap = this.queryMap(dataMap);
        } catch (DataNotFoundException dnfe) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_005"));//�L�k���o������
        }

        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID", "");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(dataMap, "BASE_CD", "");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_003"));//�ǤJ��a�N�����o���ŭ�
        }
        String APLY_NO = MapUtils.getString(dataMap, "APLY_NO", "");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_004"));//�ǤJ�ץ�s�����o���ŭ�
        }

        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_006")); //�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //��s�������������T
        DataSet ds = Transaction.getDataSet();
        ds.setField("UPD_COST_CD", "2");
        ds.setField("COST_DATE", DATE.currentTime());
        ds.setField("COST_DIV_NO", user.getOpUnit());
        ds.setField("COST_ID", user.getEmpID());
        ds.setField("COST_NAME", user.getEmpName());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("COST_CD", "1");
        DBUtil.executeUpdate(ds, SQL_confirm_001);
    }

    /**
     * ������s�����Ƥ��������B�z���A
     * @param dataMap   ��a��������
     * @param user      �@�~�H��
     * @throws ModuleException 
     */
    public void cancelConfirm(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G200_MSG_001")); //�ǤJ��T���o���ŭ�
        }
        try {
            dataMap = this.queryMap(dataMap);
        } catch (DataNotFoundException dnfe) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_005"));//�L�k���o������
        }

        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID", "");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }
        String BASE_CD = MapUtils.getString(dataMap, "BASE_CD", "");
        if (StringUtils.isBlank(BASE_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_003"));//�ǤJ��a�N�����o���ŭ�
        }
        String APLY_NO = MapUtils.getString(dataMap, "APLY_NO", "");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_004"));//�ǤJ�ץ�s�����o���ŭ�
        }

        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_006")); //�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //��s�������������T
        DataSet ds = Transaction.getDataSet();
        ds.setField("UPD_COST_CD", "1");
        ds.setField("COST_DATE", DATE.currentTime());
        ds.setField("COST_DIV_NO", user.getOpUnit());
        ds.setField("COST_ID", user.getEmpID());
        ds.setField("COST_NAME", user.getEmpName());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("COST_CD", "2");
        DBUtil.executeUpdate(ds, SQL_confirm_001);
    }

    /**
     * �f��ץ��a������
     * @param BASE_CD
     * @param B301Vo
     * @param UPD_TIME
     * @throws Exception 
     */
    public void approve(String BASE_CD, DTEPB301 B301Vo, String UPD_TIME) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BASE_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_003"));//�ǤJ��a�N�����o���ŭ�
        }
        if (B301Vo == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_007"));//�ǤJ�߮׮ץ󤣱o���ŭ�
        }
        if (StringUtils.isBlank(UPD_TIME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_008"));//�ǤJ���ʤ���ɶ� ���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        Map dataMap = new HashMap();
        try {
            dataMap.put("SUB_CPY_ID", B301Vo.getSUB_CPY_ID());
            dataMap.put("BASE_CD", BASE_CD);
            dataMap.put("APLY_NO", B301Vo.getAPLY_NO());
            dataMap = this.queryMap(dataMap);
        } catch (DataNotFoundException dnfe) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G200_MSG_005"));//�L�k���o������
        }

        //��s���������P���¸��
        new EP_Z0G220().approve(BASE_CD, B301Vo, UPD_TIME);

        //��s�������������T
        DataSet ds = Transaction.getDataSet();
        ds.setField("CHG_DATE", DATE.toTimestamp(UPD_TIME));
        ds.setField("CHG_DIV_NO", B301Vo.getLST_PROC_DIV());
        ds.setField("CHG_ID", B301Vo.getLST_PROC_ID());
        ds.setField("CHG_NAME", B301Vo.getLST_PROC_NAME());
        ds.setField("TRN_STS", "02");
        ds.setField("SUB_CPY_ID", B301Vo.getSUB_CPY_ID());
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("APLY_NO", B301Vo.getAPLY_NO());

        DBUtil.executeUpdate(ds, SQL_approve_001);
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * SQL�����D���n�Ѽ�
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }
}
