package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.a3.module.EP_A30060;
import com.cathay.ep.f1.module.EP_F10500;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2015/01/20  Created ������
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �j�Ӧ��J��X���p�Ҳ�
 * �Ҳ�ID    EP_Z0G410
 * ���n����    �j�Ӧ��J��X���p
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EP_Z0G410 {
    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G410.SQL_queryList_001";

    private static final Logger log = Logger.getLogger(EP_Z0G410.class);

    private static final String SQL_process_001 = "com.cathay.ep.z0.module.EP_Z0G410.SQL_process_001";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0G410.SQL_delete_001";

    /**
     * Ū����a�Y�ɧQ�βv
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String CAL_YM = null;
        String COST_KD = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_003"));//�ǤJ�p��~�뤣�o���ŭ�
            }
            COST_KD = MapUtils.getString(reqMap, "COST_KD");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_005"));//�ǤJ�����������o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�߯������J��X���p��DTEPG410)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CAL_YM", CAL_YM);
        ds.setField("COST_KD", COST_KD);
        
        //150506 Modified�W�[�b�U�O
        String BAL_TYPE = MapUtils.getString(reqMap,"BAL_TYPE");
        if("SG".equals(BAL_TYPE)){
            ds.setField("BAL_TYPE_LIST", "1");//B.BAL_TYPE IN {��SF��,  ��GL��}
        }else if(StringUtils.isNotBlank(BAL_TYPE)){
            ds.setField("BAL_TYPE", BAL_TYPE);
        }
        
        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);

        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //���j�Ӻ���
            rtnMap.put("INV_BLD_KD_NM", FieldOptionList.getName("EP", "INV_BLD_KD", MapUtils.getString(rtnMap, "INV_BLD_KD")));

            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * �R��
     * @param dataMap
     * @param user
     * @throws ModuleException
     */
    private void delete(Map dataMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String CAL_YM = null;
        String COST_KD = null;
        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            CAL_YM = MapUtils.getString(dataMap, "CAL_YM");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G420_MSG_003"));//�ǤJ�p��~�뤣�o���ŭ�
            }
            COST_KD = MapUtils.getString(dataMap, "COST_KD");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_005"));//�ǤJ�����������o���ŭ�
            }

        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CAL_YM", CAL_YM);
        ds.setField("COST_KD", COST_KD);
        DBUtil.executeUpdate(ds, SQL_delete_001);
    }

    /**
     * ���³B�z
     * @param dataMap
     * @param user
     * @throws ModuleException
     * @throws SQLException
     * @throws DBException 
     * @throws SQLException 
     */
    public void process(Map dataMap, UserObject user) throws ModuleException, DBException, SQLException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String CAL_YM = null;

        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
            CAL_YM = MapUtils.getString(dataMap, "CAL_YM");
            if (StringUtils.isBlank(CAL_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_003"));//�ǤJ�p��~�뤣�o���ŭ�
            }

        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G410_MSG_004"));//�ǤJ�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //���o�p��϶�
        String BEG_DATE = DATE.getMonthFirstDate(CAL_YM);//����Ĥ@��
        String END_DATE = DATE.getMonthLastDate(BEG_DATE);//�����̫�@��

        //���o�������J����
        List<Map> recList = new EP_A30060().queryList("3", SUB_CPY_ID, CAL_YM, "");
        Map<String, Map> recMaps = new HashMap<String, Map>();
        for (Map data : recList) {
            recMaps.put((String) data.get("BLD_CD"), data);
        }
        //���o��µ�O��
        Map fixMap = Collections.EMPTY_MAP;
        try {
            fixMap = new EP_F10500().queryforCLR_AMT(SUB_CPY_ID, BEG_DATE, END_DATE);
        } catch (DataNotFoundException e) {

        }

        //���o�|��
        EP_Z0G420 theEP_Z0G420 = new EP_Z0G420();
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("CAL_YM", CAL_YM);
        Map taxMap;
        try {
            taxMap = theEP_Z0G420.queryBldTax(reqMap);
        } catch (DataNotFoundException e) {
            throw new ModuleException("�d�L�|�����");
        }
        //1:��a�J����(�~��);2:�޲z�O(�~��);3:�|��(�~);4:�O�I�O(�~)

        //���o�޲z�O��X
        Map feeMap = theEP_Z0G420.queryBldFee(reqMap);//BSLD_CD
        //4:�O�I�O(�~)

        //���o�O�I�O��X
        Map premMap;
        try {
            premMap = theEP_Z0G420.queryPrem(reqMap);//BSLD_CD
        } catch (DataNotFoundException e) {
            int calYM = Integer.parseInt(CAL_YM);
            Map newreqMap = new HashMap();
            calYM = calYM - 100;
            newreqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            newreqMap.put("CAL_YM", Integer.toString(calYM));

            premMap = theEP_Z0G420.queryPrem(newreqMap);

        }

        String COST_KD = MapUtils.getString(dataMap, "COST_KD");

        //���o��a�������
        reqMap.put("INV_EFF_CD", "1");
        reqMap.put("COST_KD", COST_KD);
        Map baseMap = theEP_Z0G420.queryBaseInfo(reqMap);
        List<String> baseList = new ArrayList<String>();
        baseList.addAll(baseMap.keySet());

        //�R���j�Ӧ��䷧�p
        try {
            this.delete(dataMap, user);
        } catch (DataNotFoundException de) {
            //�L��Ƶ������`
        }

        //1:��a�J����(�~��)
        //�B�z���update
        BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        Timestamp tTime = DATE.currentTime();
        String EmpID = user.getEmpID();
        String OpUnit = user.getOpUnit();
        String EmpName = user.getEmpName();
        BigDecimal twelve = new BigDecimal(12);
        try {

            buds.preparedBatch(SQL_process_001);
            //�j�ӵ��ƴX�ʵ� ���B�z
            for (String bldCD : baseList) {
                Map recMap = recMaps.get(bldCD);
                if (recMap == null) {
                    recMap = Collections.EMPTY_MAP;
                }
                //���o�j�ӫO�O                        
                BigDecimal premVal = STRING.objToBigDecimal(premMap.get(bldCD), BigDecimal.ZERO); //�L�ȵ��s

                //���o�j�ӷ����µ�O��
                BigDecimal fixVal = STRING.objToBigDecimal(fixMap.get(bldCD), BigDecimal.ZERO); //�L�ȵ��s

                //���o�j�ӷ�����u�|��
                Map tax = (Map) taxMap.get(bldCD); //�� EMPTY_MAP 

                //���o�j�ӷ���O��
                Map fee = (Map) feeMap.get(bldCD); //�L�ȵ� EMPTY_MAP

                //���o�j�Ӱ�a�������
                Map bldBase = (Map) baseMap.get(bldCD); //�L�ȵ� EMPTY_MAP
                if (tax == null || tax.isEmpty()) {
                    tax = Collections.EMPTY_MAP;
                }
                if (fee == null || fee.isEmpty()) {
                    fee = Collections.EMPTY_MAP;
                }
                if (bldBase == null || bldBase.isEmpty()) {
                    bldBase = Collections.EMPTY_MAP;
                }
                //�p��b���J
                BigDecimal NET_AMT = STRING.objToBigDecimal(recMap.get("NET_SAL_AMT"), BigDecimal.ZERO).add(
                    STRING.objToBigDecimal(fee.get("SLF_RNT_AMT"), BigDecimal.ZERO)).subtract(
                    STRING.objToBigDecimal(fee.get("DIFF_FEE"), BigDecimal.ZERO).add(
                        STRING.objToBigDecimal(fee.get("EMPTY_FEE"), BigDecimal.ZERO))).subtract(fixVal).subtract(premVal).subtract(
                    STRING.objToBigDecimal(tax.get("HOUSE_TAX"), BigDecimal.ZERO)).subtract(
                    STRING.objToBigDecimal(tax.get("LAND_TAX"), BigDecimal.ZERO));
                BigDecimal BLD_COST_AMT = STRING.objToBigDecimal(bldBase.get("BLD_COST_AMT"), BigDecimal.ZERO);
                BigDecimal RNT_SIZE = STRING.objToBigDecimal(bldBase.get("RNT_SIZE"), BigDecimal.ZERO);
                BigDecimal SLF_SIZE = STRING.objToBigDecimal(bldBase.get("SLF_SIZE"), BigDecimal.ZERO);
                BigDecimal BLD_SIZE = STRING.objToBigDecimal(bldBase.get("BLD_SIZE"), BigDecimal.ZERO);
                BigDecimal NET_SAL_AMT = STRING.objToBigDecimal(recMap.get("NET_SAL_AMT"), BigDecimal.ZERO);

                BigDecimal SLF_RNT_AMT = STRING.objToBigDecimal(fee.get("SLF_RNT_AMT"), BigDecimal.ZERO);

                BigDecimal RNT_RT = STRING.objToBigDecimal(bldBase.get("RNT_RT"), BigDecimal.ZERO);
                buds.setField("COST_KD", COST_KD);
                buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                buds.setField("BLD_CD", bldCD);
                buds.setField("CAL_YM", CAL_YM);
                buds.setField("IFRS_INV_RT", bldBase.get("IFRS_INV_RT"));
                buds.setField("BLD_SIZE", BLD_SIZE);
                buds.setField("RNT_RT", RNT_RT);
                buds.setField("INV_RNT_SIZE", bldBase.get("INV_RNT_SIZE"));
                buds.setField("FL_EVAL", bldBase.get("FL_EVAL"));
                buds.setField("COST_AMT", bldBase.get("COST_AMT"));
                buds.setField("BLD_AREA", bldBase.get("BLD_AREA"));
                buds.setField("LND_AREA", bldBase.get("LND_AREA"));
                buds.setField("PRK_AREA", bldBase.get("PRK_AREA"));
                buds.setField("INV_BLD_KD", bldBase.get("INV_BLD_KD"));
                buds.setField("BLD_NAME", bldBase.get("BLD_NAME"));
                buds.setField("MNG_AMT", bldBase.get("MNG_AMT"));
                buds.setField("RNT_SIZE", RNT_SIZE);
                buds.setField("SLF_SIZE", SLF_SIZE);
                BigDecimal USE_RT = BigDecimal.ZERO;
                if (BLD_SIZE.compareTo(BigDecimal.ZERO) != 0) {
                    USE_RT = (RNT_SIZE.add(SLF_SIZE)).divide(BLD_SIZE, 4, BigDecimal.ROUND_HALF_UP);
                }

                buds.setField("USE_RT", USE_RT);

                buds.setField("NET_SAL_AMT", NET_SAL_AMT);
                buds.setField("SUM_NET_AMT", recMap.get("SUM_NET_AMT"));

                buds.setField("ALL_RNT_AMT", USE_RT.compareTo(BigDecimal.ZERO) == 0 ? BigDecimal.ZERO : NET_SAL_AMT.divide(USE_RT, 4,
                    BigDecimal.ROUND_HALF_UP));////�Y USE_RT = ��

                buds.setField("BLD_COST_AMT", BLD_COST_AMT);
                buds.setField("NET_AMT", NET_AMT);
                buds.setField("HOUSE_TAX", tax.get("HOUSE_TAX"));
                buds.setField("LAND_TAX", tax.get("LAND_TAX"));
                buds.setField("PREM_AMT", premVal);
                buds.setField("FIX_AMT", fixVal);
                buds.setField("FEE_AMT", STRING.objToBigDecimal(fee.get("DIFF_FEE"), BigDecimal.ZERO).add(
                    STRING.objToBigDecimal(fee.get("EMPTY_FEE"), BigDecimal.ZERO)));
                buds.setField("SLF_RNT_AMT", SLF_RNT_AMT);
                BigDecimal GRS_RTN_RT = BigDecimal.ZERO;
                BigDecimal NET_RTN_RT = BigDecimal.ZERO;
                if (BLD_COST_AMT.compareTo(BigDecimal.ZERO) != 0) {
                    GRS_RTN_RT = (NET_SAL_AMT.add(SLF_RNT_AMT)).multiply(twelve).divide(BLD_COST_AMT, 5, BigDecimal.ROUND_HALF_UP);
                    NET_RTN_RT = NET_AMT.multiply(twelve).divide(BLD_COST_AMT, 5, BigDecimal.ROUND_HALF_UP);
                }
                buds.setField("GRS_RTN_RT", GRS_RTN_RT);
                buds.setField("NET_RTN_RT", NET_RTN_RT);
                buds.setField("CHG_DATE", tTime);
                buds.setField("CHG_DIV_NO", OpUnit);
                buds.setField("CHG_ID", EmpID);
                buds.setField("CHG_NAME", EmpName);

                buds.addBatch();

            }
            buds.executeBatch();
            Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
            if (theErrorObject.length > 0) {
                for (int k = 0; k < theErrorObject.length; k++) {
                    Map errorDataMap = (Map) theErrorObject[k][1];
                    log.error("��s��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap, (Exception) theErrorObject[k][2]);
                }
                //��s��Ʀ��~
                throw new ModuleException(MessageUtil.getMessage("�s�W��Ʀ��~"));//�s�W��Ʀ��~
            }
        } catch (Exception e) {
            log.error(e, e);
            throw new ModuleException(e);//�妸�s�W����
        } finally {
            if (buds != null) {
                buds.close();
            }
        }

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
