package com.cathay.ep.z0.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPF140;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * DATE Description Author
2014/08/15  Created ����i
�@�B  �{���\�෧�n�����G
�ҲզW��    �������R���@�Ҳ�
�Ҳ�ID    EP_Z0F140
���n����    �������R���@�Ҳ�
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EP_Z0F140 {
    private static final String SQL_queryF140List_001 = "com.cathay.ep.z0.module.EP_Z0F140.SQL_queryF140List_001";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0F140.SQL_insert_001";

    private static final String SQL_insert_002 = "com.cathay.ep.z0.module.EP_Z0F140.SQL_insert_002";

    /**
     * Ū����µ�ץ�_�������R�ɲM��
     * @param F140Vo
     * @return
     * @throws ModuleException
     */
    public List<Map> queryF140List(DTEPF140 F140Vo) throws ModuleException {
        ErrorInputException eie = null;
        String APLY_NO = "";
        String SUB_CPY_ID = "";
        if (F140Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F140_MSG_001"));//��µ�ץ�_�������R�ɤ��i���� 
        } else {
            APLY_NO = F140Vo.getAPLY_NO();
            SUB_CPY_ID = F140Vo.getSUB_CPY_ID();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_002")); //�ǤJ�����q�O���i����!
            }
            if (StringUtils.isBlank(APLY_NO) && StringUtils.isBlank(F140Vo.getMAT_NM())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_003")); //�ǤJ�ץ�s�����i����!
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�����q�O�ζǤJ�ѼƬd�߭�µ�ץ�_�������R��(DTEPF140)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (StringUtils.isNotBlank(APLY_NO) && APLY_NO.length() == 6) {
            APLY_NO = APLY_NO + "%";
        }
        if (StringUtils.isNotBlank(APLY_NO)) {
            ds.setField("APLY_NO", APLY_NO);
        }
        if (F140Vo.getMEMO_NO() != null) {
            ds.setField("MEMO_NO", F140Vo.getMEMO_NO());
        }
        if (F140Vo.getPRO_NO() != null) {
            ds.setField("PRO_NO", F140Vo.getPRO_NO());
        }
        if (F140Vo.getPRT_NO() != null) {
            ds.setField("PRT_NO", F140Vo.getPRT_NO());
        }
        if (StringUtils.isNotBlank(F140Vo.getMAT_ID())) {
            ds.setField("MAT_ID", F140Vo.getMAT_ID());
        }
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotBlank(F140Vo.getMAT_NM())) {
            ds.setField("MAT_NM", sb.append("%").append(F140Vo.getMAT_NM()).append("%").toString());
        }
        return VOTool.findToMaps(ds, SQL_queryF140List_001);
    }

    /**
     * Ū����µ�ץ�_�������R�ɲM��
     * @param F140Vo
     * @return
     * @throws ModuleException
     */
    public List<Map> queryF140List(Map F140Vo) throws ModuleException {
        ErrorInputException eie = null;
        String APLY_NO = "";
        String SUB_CPY_ID = "";
        String MAT_NM = "";
        if (F140Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F140_MSG_001"));//��µ�ץ�_�������R�ɤ��i���� 
        } else {
            APLY_NO = MapUtils.getString(F140Vo, "APLY_NO");
            SUB_CPY_ID = MapUtils.getString(F140Vo, "SUB_CPY_ID");
            MAT_NM = MapUtils.getString(F140Vo, "MAT_NM");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_002")); //�ǤJ�����q�O���i����!
            }
            if (StringUtils.isBlank(APLY_NO) && StringUtils.isBlank(MAT_NM)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_003")); //�ǤJ�ץ�s�����i����!
            }
        }
        if (eie != null) {
            throw eie;
        }
        String MEMO_NO = MapUtils.getString(F140Vo, "MEMO_NO");
        String PRO_NO = MapUtils.getString(F140Vo, "PRO_NO");
        String PRT_NO = MapUtils.getString(F140Vo, "PRT_NO");
        String MAT_ID = MapUtils.getString(F140Vo, "MAT_ID");
        String DATE_S = MapUtils.getString(F140Vo, "DATE_S");
        String DATE_E = MapUtils.getString(F140Vo, "DATE_E");

        //�H�����q�O�ζǤJ�ѼƬd�߭�µ�ץ�_�������R��(DTEPF140)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (StringUtils.isNotBlank(APLY_NO) && APLY_NO.length() == 6) {
            APLY_NO = APLY_NO + "%";
        }
        if (StringUtils.isNotBlank(APLY_NO)) {
            ds.setField("APLY_NO", APLY_NO);
        }
        if (StringUtils.isNotBlank(MEMO_NO)) {
            ds.setField("MEMO_NO", MEMO_NO);
        }
        if (StringUtils.isNotBlank(PRO_NO)) {
            ds.setField("PRO_NO", PRO_NO);
        }
        if (StringUtils.isNotBlank(PRT_NO)) {
            ds.setField("PRT_NO", PRT_NO);
        }
        if (StringUtils.isNotBlank(MAT_ID)) {
            ds.setField("MAT_ID", MAT_ID);
        }
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotBlank(MAT_NM)) {
            ds.setField("MAT_NM", sb.append("%").append(MAT_NM).append("%").toString());
        }
        if (StringUtils.isNotBlank(DATE_S)) {
            ds.setField("INPUT_DATES", DATE_S);
            ds.setField("INPUT_DATEE", DATE_E);
        }
        return VOTool.findToMaps(ds, SQL_queryF140List_001);
    }

    /**
     * �s�W��µ�ץ�_�������R���
     * @param F140Vo
     * @param user
     * @throws ModuleException
     */
    public void insert(DTEPF140 F140Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        String APLY_NO = "";
        Integer MEMO_NO = null;
        Integer PRO_NO = null;
        String SUB_CPY_ID = "";
        if (F140Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_001"));//��µ�ץ�_�������R�ɤ��i���� 
        } else {
            APLY_NO = F140Vo.getAPLY_NO();
            MEMO_NO = F140Vo.getMEMO_NO();
            PRO_NO = F140Vo.getPRO_NO();
            SUB_CPY_ID = F140Vo.getSUB_CPY_ID();
            if (MEMO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_004")); //�Ƨѿ��渹���i����!
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_003")); //�ǤJ�ץ�s�����i����!
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
            if (PRO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_005")); //�u�اǸ����i����!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_006"));//�ǤJ�ϥΪ̸�T���i���� 
        }
        if (eie != null) {
            throw eie;
        }
        //�s�W��µ�ץ�_�������R��DTEPF140�G
        DataSet ds = Transaction.getDataSet();
        //���o���u�اǸ����̤j��µ�Ǹ�+1
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("MEMO_NO", MEMO_NO);
        ds.setField("PRO_NO", PRO_NO);
        DBUtil.searchAndRetrieve(ds, SQL_insert_002, false);
        ds.next();
        Integer PRT_NO_OLD = (Integer) ds.getField("PRT_NO");

        if (PRT_NO_OLD != null) {
            F140Vo.setPRT_NO(PRT_NO_OLD + 1);
        } else {
            F140Vo.setPRT_NO(1);
        }

        ds.clear();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("MEMO_NO", MEMO_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("PRO_NO", F140Vo.getPRO_NO());
        ds.setField("PRT_NO", F140Vo.getPRT_NO());
        ds.setField("MAT_ID", F140Vo.getMAT_ID());
        ds.setField("MAT_NM", F140Vo.getMAT_NM());
        ds.setField("CNT", F140Vo.getCNT());
        ds.setField("UNIT", F140Vo.getUNIT());
        ds.setField("PRICE", F140Vo.getPRICE());
        ds.setField("EST_AMT", F140Vo.getEST_AMT());
        DBUtil.executeUpdate(ds, SQL_insert_001);
        /*
        //�O���f�妨�����R���{
        Map DBF110Map = new EP_Z0F110().queryMap(F120Vo.getAPLY_NO());
        RZ_N0Z001 theRZ_N0Z001 = new RZ_N0Z001();
        String AUTH_DESC = "�s�W�������R" + F140Vo.getMAT_NM();
        DBF110Map.put("LST_PROC_DATE", DATE.currentTime());
        DBF110Map.put("LST_PROC_ID", user.getEmpID());
        DBF110Map.put("LST_PROC_DIV", user.getOpUnit());
        new RZ_N0Z001().insertLogOnly(VOTool.mapToVO(DTEPF110.class, DBF110Map), AUTH_DESC);*/

    }

    /**
     * �ק��µ�ץ�_�������R���
     * @param F140Vo
     * @param user
     * @throws Exception
     */
    public void update(DTEPF140 F140Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String APLY_NO = "";
        Integer MEMO_NO = null;
        Integer PRO_NO = null;
        Integer PRT_NO = null;
        String SUB_CPY_ID = null;
        if (F140Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_001"));//��µ�ץ�_�������R�ɤ��i���� 
        } else {
            APLY_NO = F140Vo.getAPLY_NO();
            MEMO_NO = F140Vo.getMEMO_NO();
            PRO_NO = F140Vo.getPRO_NO();
            PRT_NO = F140Vo.getPRT_NO();
            SUB_CPY_ID = F140Vo.getSUB_CPY_ID();
            if (MEMO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_004")); //�Ƨѿ��渹���i����!
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_003")); //�ǤJ�ץ�s�����i����!
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
            if (PRO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_005")); //�u�اǸ����i����!
            }
            if (PRT_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_007")); //��µ�Ǹ����i����!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_006"));//�ǤJ�ϥΪ̸�T���i���� 
        }
        if (eie != null) {
            throw eie;
        }
        //�ק��µ�ץ�_�������R��DTEPF140
        VOTool.update(F140Vo);
        /*
        //�O���f��u�{�������{ 
        String AUTH_DESC = "�ק令�����R" + F140Vo.getMAT_NM();
        
        Map DBF110Map = new EP_Z0F110().queryMap(APLY_NO);
        DBF110Map.put("LST_PROC_DATE", DATE.currentTime());//�@�~�ɶ�
        DBF110Map.put("LST_PROC_ID", user.getEmpID());//�@�~�H��
        DBF110Map.put("LST_PROC_DIV", user.getOpUnit());//�@�~���
        new RZ_N0Z001().insertLogOnly(VOTool.mapToVO(DTEPF110.class, DBF110Map), AUTH_DESC);*/

    }

    /**
     * �R����µ�ץ�_�������R���
     * @param F140Vo
     * @param user
     * @throws Exception
     */
    public void delete(DTEPF140 F140Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String APLY_NO = "";
        Integer MEMO_NO = null;
        String SUB_CPY_ID = "";
        //Integer PRO_NO = null;
        //Integer PRT_NO = null;
        if (F140Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_001"));//��µ�ץ�_�������R�ɤ��i���� 
        } else {
            APLY_NO = F140Vo.getAPLY_NO();
            MEMO_NO = F140Vo.getMEMO_NO();
            SUB_CPY_ID = F140Vo.getSUB_CPY_ID();
            //PRO_NO = F140Vo.getPRO_NO();
            //PRT_NO = F140Vo.getPRT_NO();
            if (MEMO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_004")); //�Ƨѿ��渹���i����!
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_003")); //�ǤJ�ץ�s�����i����!
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
            /*if (PRO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_005")); //�u�اǸ����i����!
            }
            if (PRT_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_007")); //��µ�Ǹ����i����!
            }*/
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F140_MSG_006"));//�ǤJ�ϥΪ̸�T���i���� 
        }
        if (eie != null) {
            throw eie;
        }
        //�R����µ�ץ�_�������R��DTEPF140
        VOTool.delBySample(F140Vo);
        /*
        String AUTH_DESC = "�R���������R" + F140Vo.getMAT_NM();
        Map DBF110Map = new EP_Z0F110().queryMap(APLY_NO);
        DBF110Map.put("LST_PROC_DATE", DATE.currentTime());//�@�~�ɶ�
        DBF110Map.put("LST_PROC_ID", user.getEmpID());//�@�~�H��
        DBF110Map.put("LST_PROC_DIV", user.getOpUnit());//�@�~���
        new RZ_N0Z001().insertLogOnly(VOTool.mapToVO(DTEPF110.class, DBF110Map), AUTH_DESC);*/

    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
