package com.cathay.ep.z0.module;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPG150;
import com.cathay.ep.vo.DTEPG150_LOG;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE        Description Author �߮׳渹
 * 2020/06/01  Created     ������  200414001917
 * 
 * �ҲզW��    �j�Ӧ����������@�Ҳ�
 * �Ҳ�ID     EP_Z0G150
 * ���n����    �j�Ӧ����������@�Ҳ�
 * </pre>
 * @author ���۾�
 * @since 2020/06/05
 *
 */

@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0G150 {

    private static final Logger log = Logger.getLogger(EP_Z0G150.class);

    private static final String SQL_qeuryList_001 = "com.cathay.ep.z0.module.EP_Z0G150.SQL_qeuryList_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0G150.SQL_queryMap_001";

    private static final String SQL_updateRecord_001 = "com.cathay.ep.z0.module.EP_Z0G150.SQL_updateRecord_001";

    private static final String SQL_updateUseCheck_001 = "com.cathay.ep.z0.module.EP_Z0G150.SQL_updateUseCheck_001";

    private static final String SQL_batchUpdate_001 = "com.cathay.ep.z0.module.EP_Z0G150.SQL_batchUpdate_001";

    private static final String SQL_queryByBaseList_001 = "com.cathay.ep.z0.module.EP_Z0G150.SQL_queryByBaseList_001";

    /**
     * �d�ߤj�Ӧ��������M��
     * @param reqMap �d�߱���
     * @return �j�Ӧ��������]�w DETEPG150(�h��)
     * @throws ModuleException 
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { "EP_Z0G150_ERRMSG_002" }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}  EP_Z0G150_ERRMSG_002 -> �d�߱���
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { "EP_Z0G150_ERRMSG_003" }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}  EP_Z0G150_ERRMSG_003 -> �����q�O
        }

        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        String EVAL_ZONE = MapUtils.getString(reqMap, "EVAL_ZONE");
        setFieldIfExist(ds, EVAL_ZONE, "EVAL_ZONE");
        String EVAL_TP = MapUtils.getString(reqMap, "EVAL_TP");
        setFieldIfExist(ds, EVAL_TP, "EVAL_TP");

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_qeuryList_001);
        //�v���B�z�^�ǲM��G
        for (Map rtnMap : rtnList) {
            //�]�w�N�X����
            setBldNmInfo(rtnMap);
        }

        return rtnList;
    }

    /**
     * �d�ߤj�Ӧ��������]�w
     * @param reqMap �d�߱���
     * @return �j�Ӧ�������DETEPG150
     * @throws ModuleException 
     */
    public Map queryMap(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { "EP_Z0G150_ERRMSG_002" }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}  EP_Z0G150_ERRMSG_002 -> �d�߱���
        }
        List<String> strArry = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_003");//EP_Z0G150_ERRMSG_003 -> �����q�O
        }
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_004");//EP_Z0G150_ERRMSG_004 -> ��a�N��
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);

        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001);
        //�]�w���������N�X����
        setBldNmInfo(rtnMap);

        return rtnMap;
    }

    /**
     * ���o���Ȥj�Ӹ�T
     * @param reqMap �d�߱���
     * @return ���o�j�Ӧ��Ȱϰ��T
     * @throws ModuleException 
     */
    public Map getBuildEvalZone(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { "EP_Z0G150_ERRMSG_002" }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}  EP_Z0G150_ERRMSG_002 -> �d�߱���
        }
        List<String> strArry = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_003");//EP_Z0G150_ERRMSG_003 -> �����q�O
        }
        String INV_CD = MapUtils.getString(reqMap, "INV_CD");
        if (StringUtils.isBlank(INV_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_005");//EP_Z0G150_ERRMSG_005 -> ���N��
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        //���o��a�å��վ\�]�w
        Map G110Map = null;
        try {
            G110Map = new EP_Z0G110().queryMap(reqMap);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException("EP_Z0G150_ERRMSG_006");//EP_Z0G150_ERRMSG_006 -> �L�k�z�L�å��վ\�]�w���o�����ϰ�
        }
        String CITY_ID = MapUtils.getString(G110Map, "CITY_ID");
        this.getNameSafe("EP", "EVAL_CITY_ZONE", CITY_ID, G110Map, "EVAL_ZONE", "���o�N�X���奢��");
        if (StringUtils.isBlank(MapUtils.getString(G110Map, "EVAL_ZONE"))) {
            throw new ModuleException("EP_Z0G150_ERRMSG_007");//EP_Z0G150_ERRMSG_007 -> �L�k�z�L�å��վ\�]�w�������o���Ȱϰ�
        }
        String EVAL_ZONE = MapUtils.getString(G110Map, "EVAL_ZONE");
        this.getNameSafe("EP", "EVAL_ZONE", EVAL_ZONE, G110Map, "EVAL_ZONE_NM", "���o�N�X���奢��:���Ȱϰ�");
        //�]�w�Ъ��W��
        G110Map.put("EVAL_BLD_NAME", MapUtils.getString(G110Map, "BASE_BLD_NAME", ""));

        return G110Map;
    }

    /**
     * �s�W�j�Ӧ��������]�w
     * @param g150Map   �j�Ӧ��������]�w
     * @param user      �@�~�H��
     * @throws ModuleException 
     */
    public void insertRecord(Map g150Map, UserObject user) throws ModuleException {
        List<String> strArry = null;
        if (g150Map == null || g150Map.isEmpty()) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_008");//EP_Z0G150_ERRMSG_008 -> �j�Ӧ��������]�w
        }
        if (user == null) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_009");//EP_Z0G150_ERRMSG_009 -> �@�~�H��
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        String SUB_CPY_ID = MapUtils.getString(g150Map, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_003");//EP_Z0G150_ERRMSG_003 -> �����q�O
        }
        String BASE_CD = MapUtils.getString(g150Map, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_004");//EP_Z0G150_ERRMSG_004 -> ��a�N��
        }
        String EVAL_ZONE = MapUtils.getString(g150Map, "EVAL_ZONE");
        if (StringUtils.isBlank(EVAL_ZONE)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_010");//EP_Z0G150_ERRMSG_010 -> ���Ȱϰ�
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        //�H�ǤJ�j�Ӧ��������]�w�g�J (DTEPG150)�G
        DTEPG150 G150VO = VOTool.mapToVO(DTEPG150.class, g150Map);
        G150VO.setCHG_DATE(DATE.currentTime());
        G150VO.setCHG_ID(user.getEmpID());
        G150VO.setCHG_NAME(user.getEmpName());
        G150VO.setCHG_DIV_NO(user.getOpUnit());
        VOTool.insert(G150VO);
    }

    /**
     * �R���j�Ӧ��������]�w
     * @param reqMap �d�߱���
     * @throws ModuleException 
     */
    public void deleteRecord(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { "EP_Z0G150_ERRMSG_002" }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}  EP_Z0G150_ERRMSG_002 -> �d�߱���
        }
        List<String> strArry = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_003");//EP_Z0G150_ERRMSG_003 -> �����q�O
        }
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_004");//EP_Z0G150_ERRMSG_004 -> ��a�N��
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        DTEPG150 G150VO = new DTEPG150();
        G150VO.setSUB_CPY_ID(SUB_CPY_ID);
        G150VO.setBASE_CD(BASE_CD);
        VOTool.delByPK(G150VO);
    }

    /**
     * ��s�j�Ӧ��������]�w
     * @param g150Map  �j�Ӧ��������]�w
     * @param user     �@�~�H��
     * @param updTime  �@�~�ɶ�
     * @return �ˮְT��
     * @throws ModuleException 
     */
    public void updateRecord(Map g150Map, UserObject user, Timestamp updTime) throws ModuleException {
        List<String> strArry = null;
        if (g150Map == null || g150Map.isEmpty()) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_008");//EP_Z0G150_ERRMSG_008 -> �j�Ӧ��������]�w
        }
        if (user == null) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_009");//EP_Z0G150_ERRMSG_009 -> �@�~�H��
        }
        if (updTime == null) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_011");//EP_Z0G150_ERRMSG_011 -> �@�~�ɶ�
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        String SUB_CPY_ID = MapUtils.getString(g150Map, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_003");//EP_Z0G150_ERRMSG_003 -> �����q�O
        }
        String BASE_CD = MapUtils.getString(g150Map, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_004");//EP_Z0G150_ERRMSG_004 -> ��a�N��
        }
        String EVAL_ZONE = MapUtils.getString(g150Map, "EVAL_ZONE");
        if (StringUtils.isBlank(EVAL_ZONE)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_010");//EP_Z0G150_ERRMSG_010 -> ���Ȱϰ�
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("EVAL_ZONE", EVAL_ZONE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("CHG_DATE", updTime);
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        String REG_TP = MapUtils.getString(g150Map, "REG_TP");
        setFieldIfExist(ds, REG_TP, "REG_TP");
        String ACC_MD = MapUtils.getString(g150Map, "ACC_MD");
        setFieldIfExist(ds, ACC_MD, "ACC_MD");
        String ASAQ_KD = MapUtils.getString(g150Map, "ASAQ_KD");
        setFieldIfExist(ds, ASAQ_KD, "ASAQ_KD");
        String EVAL_TP = MapUtils.getString(g150Map, "EVAL_TP");
        setFieldIfExist(ds, EVAL_TP, "EVAL_TP");
        String EVAL_BLD_NAME = MapUtils.getString(g150Map, "EVAL_BLD_NAME");
        setFieldIfExist(ds, EVAL_BLD_NAME, "EVAL_BLD_NAME");
        String CITY_ID = MapUtils.getString(g150Map, "CITY_ID");
        setFieldIfExist(ds, CITY_ID, "CITY_ID");
        String CITY_NM = MapUtils.getString(g150Map, "CITY_NM");
        setFieldIfExist(ds, CITY_NM, "CITY_NM");
        String LND_KIND = MapUtils.getString(g150Map, "LND_KIND");
        setFieldIfExist(ds, LND_KIND, "LND_KIND");
        String BLD_KD_01 = MapUtils.getString(g150Map, "BLD_KD_01", "N");//�Y�L�ȵ� ��N��
        setFieldIfExist(ds, BLD_KD_01, "BLD_KD_01");
        String BLD_KD_02 = MapUtils.getString(g150Map, "BLD_KD_02", "N");//�Y�L�ȵ� ��N��
        setFieldIfExist(ds, BLD_KD_02, "BLD_KD_02");
        String BLD_KD_03 = MapUtils.getString(g150Map, "BLD_KD_03", "N");//�Y�L�ȵ� ��N��
        setFieldIfExist(ds, BLD_KD_03, "BLD_KD_03");
        String BLD_KD_04 = MapUtils.getString(g150Map, "BLD_KD_04", "N");//�Y�L�ȵ� ��N��
        setFieldIfExist(ds, BLD_KD_04, "BLD_KD_04");
        String BLD_KD_05 = MapUtils.getString(g150Map, "BLD_KD_05", "N");//�Y�L�ȵ� ��N��
        setFieldIfExist(ds, BLD_KD_05, "BLD_KD_05");
        String BLD_KD_06 = MapUtils.getString(g150Map, "BLD_KD_06", "N");//�Y�L�ȵ� ��N��
        setFieldIfExist(ds, BLD_KD_06, "BLD_KD_06");
        String BLD_KD_OTH = MapUtils.getString(g150Map, "BLD_KD_OTH");
        setFieldIfExist(ds, BLD_KD_OTH, "BLD_KD_OTH");
        String INV_CMP = MapUtils.getString(g150Map, "INV_CMP");
        setFieldIfExist(ds, INV_CMP, "INV_CMP");
        String SPF_DTL_CD = MapUtils.getString(g150Map, "SPF_DTL_CD");
        setFieldIfExist(ds, SPF_DTL_CD, "SPF_DTL_CD");
        DBUtil.executeUpdate(ds, SQL_updateRecord_001);
    }

    /**
     * ��s�j�ӧY�ɧQ���ˮֵ����覡
     * @param reqMap    �j�Ӧ��������]�w
     * @param user      �@�~�H��
     * @return �ˮְT��
     * @throws ModuleException 
     */
    public void updateUseCheck(Map reqMap, UserObject user) throws ModuleException {
        List<String> strArry = null;
        if (reqMap == null || reqMap.isEmpty()) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_008");//EP_Z0G150_ERRMSG_008 -> �j�Ӧ��������]�w
        }
        if (user == null) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_009");//EP_Z0G150_ERRMSG_009 -> �@�~�H��
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        String formatErrorMsg = "";
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_003");//EP_Z0G150_ERRMSG_003 -> �����q�O
        }
        String BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_004");//EP_Z0G150_ERRMSG_004 -> ��a�N��
        }
        String CAL_YM = MapUtils.getString(reqMap, "CAL_YM");
        if (StringUtils.isBlank(CAL_YM)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_012");//EP_Z0G150_ERRMSG_012 -> �Y�ɧQ���ˮ֦~��
        } else if (!DATE.isDate(CAL_YM + "01", "########")) {
            formatErrorMsg = MessageUtil.getMessage("EP_Z0G150_ERRMSG_021");//EP_Z0G150_ERRMSG_021 -> �Y�ɧQ���ˮ֦~��榡���~
        }
        String USE_CHK = MapUtils.getString(reqMap, "USE_CHK");
        if (StringUtils.isBlank(USE_CHK)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_013");//EP_Z0G150_ERRMSG_013 -> �Y�ɧQ���ˮ�
        }
        if (StringUtils.isBlank(formatErrorMsg) && strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        if (StringUtils.isNotBlank(formatErrorMsg)) {
            StringBuilder sb = new StringBuilder();
            if (strArry != null) {
                sb.append(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));
                STRING.newLine(sb);
            }
            sb.append(formatErrorMsg);
            throw new ErrorInputException(sb.toString());//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}   EP_Z0G150_ERRMSG_021 �Y�ɧQ���ˮ֦~��榡���~
        }

        Timestamp updTime = DATE.currentTime();
        String strAccMode = ""; //�w�]�ŭȤ��B�z
        //���o�j�Ӧ��������]�w
        Map g150Map = queryMap(reqMap);
        //�A�ηs�k�O ���ŦX�Y�ɧQ���ˮ֮ɡA�s�ʧ�s�����覡��2 ����
        String REG_TP = MapUtils.getString(g150Map, "REG_TP");
        if ("2".equals(REG_TP)) {
            if (!"Y".equals(USE_CHK)) {
                strAccMode = "2";
            }
        }
        //�s�W�j�Ӧ��������]�w����LOG
        this.insertLog(g150Map, user, updTime);
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("CAL_YM", CAL_YM);
        ds.setField("USE_CHK", USE_CHK);
        ds.setField("CHG_DATE", updTime);
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        setFieldIfExist(ds, strAccMode, "ACC_MD");
        DBUtil.executeUpdate(ds, SQL_updateUseCheck_001);
    }

    /**
     * �s�W�j�Ӧ��������]�w����LOG
     * @param g150Map       �j�Ӧ��������]�w
     * @param user          �@�~�H��
     * @param updDateTime   ���ʮɶ�
     * @throws ModuleException 
     */
    public void insertLog(Map g150Map, UserObject user, Timestamp updDateTime) throws ModuleException {
        List<String> strArry = null;
        if (g150Map == null || g150Map.isEmpty()) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_008");//EP_Z0G150_ERRMSG_008 -> �j�Ӧ��������]�w
        }
        if (user == null) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_009");//EP_Z0G150_ERRMSG_009 -> �@�~�H��
        }
        if (updDateTime == null) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_014");//EP_Z0G150_ERRMSG_014 -> ���ʮɶ�
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        String SUB_CPY_ID = MapUtils.getString(g150Map, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_003");//EP_Z0G150_ERRMSG_003 -> �����q�O
        }
        String BASE_CD = MapUtils.getString(g150Map, "BASE_CD");
        if (StringUtils.isBlank(BASE_CD)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_004");//EP_Z0G150_ERRMSG_004 -> ��a�N��
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }

        //�H�ǤJ�j�Ӧ��������]�w���� (DTEPG150_LOG)�G
        DTEPG150_LOG G150_LOG = VOTool.mapToVO(DTEPG150_LOG.class, g150Map);
        G150_LOG.setUPD_ID(user.getEmpID());
        G150_LOG.setUPD_NAME(user.getEmpName());
        G150_LOG.setUPD_DATE(updDateTime);
        VOTool.insert(G150_LOG);
    }

    /**
     * �妸��s�j�Ӭ���ưȩ�
     * @param g150List  ��a���Ȭ�����ӡA���e��mapG150
     * @param DLG_EVAL_SN   ���ȩu��
     * @param APR_ID    ���Ȩưȩ�
     * @throws ModuleException 
     * @throws DBException 
     */
    public void batchUpdate(List<Map> g150List, String DLG_EVAL_SN, String APR_ID) throws ModuleException, DBException {
        List<String> strArry = null;
        if (g150List == null || g150List.isEmpty()) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_015");//EP_Z0G150_ERRMSG_015 -> ��a���Ȭ������
        }
        if (StringUtils.isBlank(DLG_EVAL_SN)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_016");//EP_Z0G150_ERRMSG_016 -> ���ȩu��
        }
        if (StringUtils.isBlank(APR_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_017");//EP_Z0G150_ERRMSG_017 -> ���Ȩưȩ�
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }
        final String buds_DLG_EVAL_SN = DLG_EVAL_SN;
        final String buds_APR_ID = APR_ID;
        BatchConstructor.processByBatch(g150List, SQL_batchUpdate_001, false, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL, new BatchConstructor.ListHandler() {
            protected <T> void setField(T object, BatchUpdateDataSet buds) throws DBException {
                Map mapG150 = (Map) object;
                buds.setField("DLG_EVAL_SN", buds_DLG_EVAL_SN);//���Ȭ���u��
                buds.setField("DLG_APR_ID", buds_APR_ID);//���Ȭ���ưȩ�
                buds.setField("SUB_CPY_ID", mapG150.get("SUB_CPY_ID"));//�����q�O
                buds.setField("BASE_CD", mapG150.get("BASE_CD"));//��a�N��
                addBatchAndJoinGroup(buds);
            }
        });
    }

    /**
     * �ˮֵ����覡�O�_�ŦX�Y�ɧQ��
     * @param reqMap �j�Ӧ��������]�w
     * @throws ModuleException 
     */
    public void checkAccMode(Map g150Map) throws ModuleException {
        if (g150Map == null || g150Map.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { "EP_Z0G150_ERRMSG_008" }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}  EP_Z0G150_ERRMSG_008 -> �j�Ӧ��������]�w
        }

        String REG_TP = MapUtils.getString(g150Map, "REG_TP");
        if ("2".equals(REG_TP)) {
            //�ˮ֧Y�ɧQ���ˮֵ��G�O�_�q�L
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH, -1);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
            String lastYM = sdf.format(cal.getTime());//�̾ڨt�Φ~����o�W�@�Ӧ~�� (yyyymm)
            g150Map.put("CAL_YM", lastYM);
            try {
                Map g152Map = new EP_Z0G152().queryMap(g150Map);
                if (!"Y".equals(MapUtils.getString(g152Map, "USE_CHK"))) {
                    throw new ModuleException("EP_Z0G150_ERRMSG_018");//EP_Z0G150_ERRMSG_018 -> �Y�ɧQ��{0}�ˮ֥��q�L�A���i�Τ�������
                }
            } catch (DataNotFoundException dnfe) {
                throw new ModuleException("EP_Z0G150_ERRMSG_019");//EP_Z0G150_ERRMSG_019 -> �d�L�A�ΧY�ɧQ�ηs�k�O{0}���ˮֵ��G
            }
        }
    }

    /**
     * �̰�a�M��d�ߤj�Ӧ��������M��
     * @param SUB_CPY_ID  �����q�O
     * @param baseList    ��a�M��
     * @return
     * @throws ModuleException 
     */
    public List<Map> queryByBaseList(String SUB_CPY_ID, List<String> baseList) throws ModuleException {
        List<String> strArry = null;
        if (baseList == null || baseList.isEmpty()) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_020");//EP_Z0G150_ERRMSG_020 -> ��a�M��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            strArry = getArrayList(strArry, "EP_Z0G150_ERRMSG_003");//EP_Z0G150_ERRMSG_003 -> �����q�O
        }
        if (strArry != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G150_ERRMSG_001", new String[] { StringUtils.join(strArry, "�B") }));//EP_Z0G150_ERRMSG_001 -> �U�C�ǤJ�ѼƤ��o���ŭ�:{0}
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("baseList", baseList);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryByBaseList_001);
        for (Map rtnMap : rtnList) {
            //�]�w���ȳ]�w�N�X����
            setBldNmInfo(rtnMap);
        }
        return rtnList;
    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String value, String key) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * �]�w�j�Ӥg�a�ت������N�X����
     * @param rtnMap �j�Ӧ�������DETEPG150
     */
    public void setBldKdName(Map rtnMap) {
        String LND_KIND = MapUtils.getString(rtnMap, "LND_KIND");
        this.getNameSafe("EP", "LND_KIND", LND_KIND, rtnMap, "LND_KIND_NM", "���o�N�X���奢��:�g�a����");
        
        List<String> strArry = null;
        String[] allBLD_KIND = new String[] { "BLD_KD_01", "BLD_KD_02", "BLD_KD_03", "BLD_KD_04", "BLD_KD_05", "BLD_KD_06" };
        for (String BLD_KIND : allBLD_KIND) {
            if ("Y".equals(MapUtils.getString(rtnMap, BLD_KIND))) {
                try {
                    int length = BLD_KIND.length();
                    strArry = getArrayList(strArry, FieldOptionList.getName("EP", "BLD_KIND", BLD_KIND.substring(length - 2, length)));
                } catch (Exception e) {
                    log.fatal("���o�N�X���奢��:�ت�����", e);
                }
            }
        }
        if (strArry != null) {
            rtnMap.put("BLD_KIND_NM", StringUtils.join(strArry, "�B"));
        } else {
            rtnMap.put("BLD_KIND_NM", "");
        }
    }
    
    /**
     * �]�w�j�Ӧ��������N�X����
     * @param rtnMap �j�Ӧ�������DETEPG150
     */
    private void setBldNmInfo(Map rtnMap) {
        String REG_TP = MapUtils.getString(rtnMap, "REG_TP");
        this.getNameSafe("EP", "REG_TP", REG_TP, rtnMap, "REG_TP_NM", "���o�N�X���奢��:�Y�ɧQ�Ϊk�O");
        String ACC_MD = MapUtils.getString(rtnMap, "ACC_MD");
        this.getNameSafe("EP", "ACC_MD", ACC_MD, rtnMap, "ACC_MD_NM", "���o�N�X���奢��:�����覡");
        String EVAL_TP = MapUtils.getString(rtnMap, "EVAL_TP");
        this.getNameSafe("EP", "EVAL_TP", EVAL_TP, rtnMap, "EVAL_TP_NM", "���o�N�X���奢��:�g�a����");
        String EVAL_ZONE = MapUtils.getString(rtnMap, "EVAL_ZONE");
        this.getNameSafe("EP", "EVAL_ZONE", EVAL_ZONE, rtnMap, "EVAL_ZONE_NM", "���o�N�X���奢��:���Ȱϰ�");
        String INV_CMP = MapUtils.getString(rtnMap, "INV_CMP");
        this.getNameSafe("EP", "INV_CMP", INV_CMP, rtnMap, "INV_CMP_NM", "���o�N�X���奢��:���զ�");
        String APR_ID = MapUtils.getString(rtnMap, "APR_ID");
        this.getNameSafe("EP", "APR_ID", APR_ID, rtnMap, "APR_ID_NM", "���o�N�X���奢��:�̪���Ȩưȩ�");
        //�]�w�j�Ӥg�a�ت������N�X����
        setBldKdName(rtnMap);
    }

    /**
     * <pre>
     * �w���s��FieldOptionList
     * �J��catch Exception�ì���log�B�a�J�ŭ�
     * </pre>
     * @param sysId
     * @param fieldName
     * @param option
     * @param rtnMap    �^��Map
     * @param rtnKeyName   �N�����^Map��key��
     * @param errMsg    log����
     */
    private void getNameSafe(String sysId, String fieldName, String option, Map rtnMap, String rtnKeyName, String errMsg) {
        try {
            String name = FieldOptionList.getName(sysId, fieldName, option);
            rtnMap.put(rtnKeyName, name);
        } catch (Exception e) {
            log.fatal(errMsg, e);
            rtnMap.put(rtnKeyName, "");
        }
    }

    /**
     * ���oArrayList<String>����
     * ErrorInputException
     * @param strArry
     * @param errMsg
     * @return 
     */
    private List<String> getArrayList(List strArry, String errMsg) {
        if (strArry == null) {
            strArry = new ArrayList<String>();
        }
        strArry.add(errMsg);
        return strArry;
    }
}
