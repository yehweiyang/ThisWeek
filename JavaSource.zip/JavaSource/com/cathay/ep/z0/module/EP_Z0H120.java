package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.CathayAPI;
import com.cathay.common.util.CathayAPI.API_Platform;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.common.util.http.HttpClientHelper.HttpResponseType;
import com.cathay.ep.vo.DTEPH120;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE        Description Author
 * 2020/04/24  Created     ���f��
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �w�s��ޱ������@�Ҳ�
 * �Ҳ�ID    EP_Z0H120
 * ���n����    �w�s��ޱ������@�Ҳ�
 * </pre>
 * @author ���f��
 * @since  2020-04-24
 * 2020/05/19 �վ�i�������B�z
 *
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class EP_Z0H120 {

    static final private Logger log = Logger.getLogger(EP_Z0H120.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0H120.SQL_queryList_001";

    private static final String SQL_queryByTrdNo_001 = "com.cathay.ep.z0.module.EP_Z0H120.SQL_queryByTrdNo_001";

    private static final String SQL_insertDeposit_001 = "com.cathay.ep.z0.module.EP_Z0H120.SQL_insertDeposit_001";

    private static final String SQL_expire_001 = "com.cathay.ep.z0.module.EP_Z0H120.SQL_expire_001";

    /**
     * �d�ߤ��ʲ��w�s�M��
     * @param reqMapA
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMapA, ResponseContext resp) throws ModuleException {
        if (reqMapA == null || reqMapA.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0H120_MSG_001"));//�d�߱��󤣥i����
        }
        String SP_CD = MapUtils.getString(reqMapA, "SP_CD");
        if (StringUtils.isBlank(SP_CD)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0H120_MSG_002"));//�@�~�D�餣�i����
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SP_CD", SP_CD);
        this.setFieldsIfExsits(reqMapA, ds, "FD_NO");
        this.setFieldsIfExsits(reqMapA, ds, "ORG_ID");
        this.setFieldsIfExsits(reqMapA, ds, "CRC");
        this.setFieldsIfExsits(reqMapA, ds, "INT_STS");

        String FD_QRY_TYPE = MapUtils.getString(reqMapA, "FD_QRY_TYPE");
        if ("D".equals(FD_QRY_TYPE)) {
            this.setFieldsIfExsits(MapUtils.getString(reqMapA, "STR_DATE"), ds, "QRY_DATE_BEG_1");
            this.setFieldsIfExsits(MapUtils.getString(reqMapA, "END_DATE"), ds, "QRY_DATE_END_1");
        } else if ("E".equals(FD_QRY_TYPE)) {
            this.setFieldsIfExsits(MapUtils.getString(reqMapA, "STR_DATE"), ds, "QRY_DATE_BEG_2");
            this.setFieldsIfExsits(MapUtils.getString(reqMapA, "END_DATE"), ds, "QRY_DATE_END_2");
        }
        List<Map> rtnList = new ArrayList();
        int ser_no = 0;
        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        BigDecimal TOT_TRD_AMT = BigDecimal.ZERO;
        BigDecimal TOT_EST_EXP_AMT = BigDecimal.ZERO;
        BigDecimal TOT_EXP_ACC_AMT = BigDecimal.ZERO;
        DecimalFormat df = new DecimalFormat("0.00%");
        while (ds.next()) {
            ser_no++;
            Map map = VOTool.dataSetToMap(ds);
            map.put("SER_NO", ser_no);
            map.put("INV_TERM_VALUE_NM", MapUtils.getString(map, "INV_TERM_VALUE", "") + FieldOptionList.getName("EP", "INV_TERM_UNIT", MapUtils.getString(map, "INV_TERM_UNIT", "")));
            map.put("ORG_NM", FieldOptionList.getName("EP", "ORG_ID", MapUtils.getString(map, "ORG_ID")));
            map.put("INV_TERM_UNIT_NM", FieldOptionList.getName("EP", "INV_TERM_UNIT", MapUtils.getString(map, "INV_TERM_UNIT")));
            map.put("CRC_NM", FieldOptionList.getName("EP", "CRC", MapUtils.getString(map, "CRC")));
            map.put("TRD_KD_NM", FieldOptionList.getName("EP", "TRD_KD", MapUtils.getString(map, "TRD_KD")));
            map.put("INT_PAY_KD_NM", FieldOptionList.getName("EP", "INT_PAY_KD", MapUtils.getString(map, "INT_PAY_KD")));
            map.put("INT_STS_NM", FieldOptionList.getName("EP", "INT_STS", MapUtils.getString(map, "INT_STS")));

            BigDecimal TRD_RATE = STRING.objToBigDecimal(map.get("TRD_RATE"), BigDecimal.ZERO);
            String sTRD_RATE = df.format(TRD_RATE);
            map.put("TRD_RATE", sTRD_RATE);
            map.put("TRD_RATE_1", StringUtils.split(sTRD_RATE, "%")[0]);//�h%

            map.put("EST_INT_AMT_1", map.get("EST_INT_AMT"));
            map.put("EST_INT_AMT", this.formaterAMTNumber(STRING.objToBigDecimal(map.get("EST_INT_AMT"), BigDecimal.ZERO)));
            rtnList.add(map);

            //�p��X�p
            TOT_TRD_AMT = TOT_TRD_AMT.add(STRING.objToBigDecimal(map.get("TRD_AMT"), BigDecimal.ZERO));
            TOT_EST_EXP_AMT = TOT_EST_EXP_AMT.add(STRING.objToBigDecimal(map.get("EST_EXP_AMT"), BigDecimal.ZERO));
            TOT_EXP_ACC_AMT = TOT_EXP_ACC_AMT.add(STRING.objToBigDecimal(map.get("EXP_ACC_AMT"), BigDecimal.ZERO));
        }
        resp.addOutputData("SER_NO", ser_no);
        resp.addOutputData("TOT_TRD_AMT", TOT_TRD_AMT);
        resp.addOutputData("TOT_EST_EXP_AMT", TOT_EST_EXP_AMT);
        resp.addOutputData("TOT_EXP_ACC_AMT", TOT_EXP_ACC_AMT);

        return rtnList;

    }

    /**
     * �d�ߤ��ʲ��w�s��]�w
     * @param TRD_NO
     * @return
     * @throws ModuleException
     */
    public Map queryByTrdNo(String TRD_NO) throws ModuleException {
        if (StringUtils.isBlank(TRD_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0H120_MSG_003"));//�����s�����i����
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("TRD_NO", TRD_NO);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryByTrdNo_001);

        DecimalFormat df = new DecimalFormat("0.00%");
        BigDecimal TRD_RATE = STRING.objToBigDecimal(rtnMap.get("TRD_RATE"), BigDecimal.ZERO);
        String sTRD_RATE = df.format(TRD_RATE);
        rtnMap.put("TRD_RATE", sTRD_RATE);
        rtnMap.put("TRD_RATE_1", StringUtils.split(sTRD_RATE, "%")[0]);//�h%

        rtnMap.put("EST_INT_AMT", this.formaterAMTNumber(STRING.objToBigDecimal(rtnMap.get("EST_INT_AMT"), BigDecimal.ZERO)));

        rtnMap.put("INT_STS_NM", FieldOptionList.getName("EP", "INT_STS", MapUtils.getString(rtnMap, "INT_STS")));
        return rtnMap;
    }

    /**
     * �s�W���ʲ��w�s��
     * @param reqMapB
     * @param user
     * @throws ModuleException
     */
    public void insert(Map reqMapB, UserObject user) throws ModuleException {

        this.checkMap(reqMapB, user);

        String currentDate = DATE.toDate_yyyyMMdd(DATE.getDBDate());
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user); // �����q�O
        String TRD_NO = theEP_Z0Z001.createNextNo(SUB_CPY_ID, "006", currentDate, "TRD_NO", currentDate, 6);
        reqMapB.put("TRD_NO", TRD_NO);

        //�Q�v�ন�ʤ���
        reqMapB.put("TRD_RATE", STRING.objToBigDecimal(reqMapB.get("TRD_RATE"), BigDecimal.ZERO).divide(new BigDecimal("100")));

        reqMapB.put("SP_NM", FieldOptionList.getName("EP", "SP_CD", MapUtils.getString(reqMapB, "SP_CD")));
        reqMapB.put("ORG_NM", FieldOptionList.getName("EP", "ORG_ID", MapUtils.getString(reqMapB, "ORG_ID")));
        reqMapB.put("INT_STS", "0");//�s�W
        reqMapB.put("TRD_KD", "1");

        reqMapB.put("EST_INT_AMT", this.calEpxireIntAmt(reqMapB));
        reqMapB.put("EST_INT_AMT_1", this.formaterAMTNumber(STRING.objToBigDecimal(reqMapB.get("EST_INT_AMT"), BigDecimal.ZERO)));

        Timestamp currentTime = DATE.currentTime();
        reqMapB.put("INPUT_DATE", currentTime);
        reqMapB.put("INPUT_ID", user.getUserID());
        reqMapB.put("INPUT_NAME", user.getEmpName());
        reqMapB.put("INPUT_DIV_NO", user.getOpUnit());

        reqMapB.put("CHG_DATE", currentTime);
        reqMapB.put("CHG_ID", user.getUserID());
        reqMapB.put("CHG_NAME", user.getEmpName());
        reqMapB.put("CHG_DIV_NO", user.getOpUnit());
        DataSet ds = Transaction.getDataSet();
        VOTool.mapToDataSet(reqMapB, ds);
        DBUtil.executeUpdate(ds, SQL_insertDeposit_001);
    }

    /**
     * ��s���ʲ��w�s��
     * @param reqMapB
     * @param user
     */
    public void update(Map reqMapB, UserObject user) throws ModuleException {
        this.checkMap(reqMapB, user);

        reqMapB.put("SP_NM", FieldOptionList.getName("EP", "SP_CD", MapUtils.getString(reqMapB, "SP_CD")));
        reqMapB.put("ORG_NM", FieldOptionList.getName("EP", "ORG_ID", MapUtils.getString(reqMapB, "ORG_ID")));

        //�Q�v�ন�ʤ���
        reqMapB.put("TRD_RATE", STRING.objToBigDecimal(reqMapB.get("TRD_RATE"), BigDecimal.ZERO).divide(new BigDecimal("100")));
        reqMapB.put("EST_INT_AMT", this.calEpxireIntAmt(reqMapB));
        reqMapB.put("EST_INT_AMT_1", this.formaterAMTNumber(STRING.objToBigDecimal(reqMapB.get("EST_INT_AMT"), BigDecimal.ZERO)));
        reqMapB.put("INT_STS", "0");

        Timestamp currentTime = DATE.currentTime();
        reqMapB.put("INPUT_DATE", currentTime);
        reqMapB.put("INPUT_ID", user.getUserID());
        reqMapB.put("INPUT_NAME", user.getEmpName());
        reqMapB.put("INPUT_DIV_NO", user.getOpUnit());

        reqMapB.put("CHG_DATE", currentTime);
        reqMapB.put("CHG_ID", user.getUserID());
        reqMapB.put("CHG_NAME", user.getEmpName());
        reqMapB.put("CHG_DIV_NO", user.getOpUnit());
        DTEPH120 DTEPH120vo = VOTool.mapToVO(DTEPH120.class, reqMapB);
        VOTool.update(DTEPH120vo);
    }

    /**
     * �R��
     * @param TRD_NO
     * @throws ModuleException
     */
    public void delete(String TRD_NO) throws ModuleException {
        if (StringUtils.isBlank(TRD_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0H120_MSG_003"));//�����s�����i����
        }
        DTEPH120 DTEPH120vo = new DTEPH120();
        DTEPH120vo.setTRD_NO(TRD_NO);
        VOTool.delByPK(DTEPH120vo);
    }

    /**
     * �T�{���ʲ��w�s��
     * @param reqMapB
     * @param user
     * @throws ModuleException
     */
    public void confirm(Map reqMapB, UserObject user) throws ModuleException {
        this.checkMap_confirm(reqMapB, user);

        reqMapB.put("INT_STS", "1");

        //�Q�v�ন�ʤ���
        reqMapB.put("TRD_RATE", STRING.objToBigDecimal(reqMapB.get("TRD_RATE"), BigDecimal.ZERO).divide(new BigDecimal("100")));
        reqMapB.put("EST_INT_AMT", this.calEpxireIntAmt(reqMapB));
        reqMapB.put("EST_INT_AMT_1", this.formaterAMTNumber(STRING.objToBigDecimal(reqMapB.get("EST_INT_AMT"), BigDecimal.ZERO)));

        Timestamp currentTime = DATE.currentTime();
        reqMapB.put("CFM_DT", currentTime);
        reqMapB.put("CFM_ID", user.getUserID());
        reqMapB.put("CFM_NM", user.getEmpName());
        reqMapB.put("CFM_DIV_NO", user.getOpUnit());

        reqMapB.put("CHG_DATE", currentTime);
        reqMapB.put("CHG_ID", user.getUserID());
        reqMapB.put("CHG_NAME", user.getEmpName());
        reqMapB.put("CHG_DIV_NO", user.getOpUnit());

        DTEPH120 DTEPH120vo = VOTool.mapToVO(DTEPH120.class, reqMapB);
        VOTool.update(DTEPH120vo);
    }

    /**
     * ������ʲ��w�s��
     * @param TRD_NO
     * @param reqMapC
     * @param user
     * @throws ModuleException
     */
    public void expire(String TRD_NO, Map reqMapC, UserObject user) throws ModuleException {

        if (StringUtils.isBlank(TRD_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0H120_MSG_005"));//�ǤJ�����s�����o���ŭ�!
        }

        //�P�_�w�s�������� 
        String trdKind;
        String EXP_TRD_NO = MapUtils.getString(reqMapC, "EXP_TRD_NO");
        if ("2".equals(EXP_TRD_NO) || "4".equals(EXP_TRD_NO)) {
            trdKind = "2";//���
        } else {
            trdKind = "3";//�Ѭ�
        }

        //��s���ʲ��w�s�檬�A������G
        DataSet ds = Transaction.getDataSet();
        ds.setField("TRD_KD", trdKind);
        ds.setField("INT_STS", "2");
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        ds.setField("CHG_DIV_NO", user.getOpUnit());
        ds.setField("TRD_NO", TRD_NO);

        DBUtil.executeUpdate(ds, SQL_expire_001);
    }

    /**
     * �i�����ʲ��w�s��
     * @param h120Map
     * @param reqMapC
     * @param user
     * @return
     * @throws ModuleException
     */
    public String extendDeposit(Map h120Map, Map reqMapC, UserObject user) throws ModuleException {

        if (StringUtils.isBlank(MapUtils.getString(h120Map, "TRD_NO"))) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0H120_MSG_005"));//�ǤJ�w�s�榨���s�����o���ŭ�!
        }
        //���o�t�Τ��
        String currentDate = DATE.toDate_yyyyMMdd(DATE.getDBDate());
        Timestamp currentTime = DATE.currentTime();
        String TRD_DATE = MapUtils.getString(reqMapC, "EXP_TRD_DATE");
        String EXP_DATE = MapUtils.getString(reqMapC, "EXT_EXP_DATE");
        BigDecimal TRD_AMT = this.formaterAMTNumber2BigDecimal(MapUtils.getString(reqMapC, "EXT_AMT"));
        BigDecimal TRD_RATE = STRING.objToBigDecimal(StringUtils.split(MapUtils.getString(h120Map, "TRD_RATE"), "%")[0], BigDecimal.ZERO).divide(new BigDecimal("100"));
        String CRC = MapUtils.getString(h120Map, "CRC");
        String ORG_ID = MapUtils.getString(h120Map, "ORG_ID");

        //���o�����s�� 
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user); // �����q�O
        String extTrdNo = new EP_Z0Z001().createNextNo(SUB_CPY_ID, "006", currentDate, "TRD_NO", currentDate, 6);
        DataSet ds = Transaction.getDataSet();
        ds.setField("TRD_NO", extTrdNo);
        ds.setField("SP_CD", h120Map.get("SP_CD"));
        ds.setField("SP_NM", h120Map.get("SP_NM"));
        ds.setField("ORG_ID", ORG_ID);
        ds.setField("ORG_NM", h120Map.get("ORG_NM"));
        ds.setField("ACC_NO", h120Map.get("ACC_NO"));
        ds.setField("FD_NO", h120Map.get("FD_NO"));
        ds.setField("TRD_DATE", TRD_DATE);
        ds.setField("EXP_DATE", EXP_DATE);
        ds.setField("TRD_AMT", TRD_AMT);
        ds.setField("INV_TERM_VALUE", reqMapC.get("INV_TERM_VALUE"));
        ds.setField("INV_TERM_UNIT", reqMapC.get("INV_TERM_UNIT"));
        //�ʤ�����Q�v
        ds.setField("TRD_RATE", TRD_RATE);

        ds.setField("INT_STS", "0");
        ds.setField("CRC", CRC);
        ds.setField("TRD_KD", "4");
        ds.setField("INT_PAY_KD", h120Map.get("INT_PAY_KD"));
        ds.setField("INPUT_DATE", currentTime);
        ds.setField("INPUT_ID", user.getEmpID());
        ds.setField("INPUT_NAME", user.getEmpName());
        ds.setField("INPUT_DIV_NO", user.getOpUnit());
        ds.setField("CHG_DATE", currentTime);
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        ds.setField("CHG_DIV_NO", user.getOpUnit());

        ds.setField("EST_INT_AMT", this.calEpxireIntAmt(TRD_DATE, EXP_DATE, TRD_AMT, TRD_RATE, CRC, ORG_ID));

        DBUtil.executeUpdate(ds, SQL_insertDeposit_001);

        //�̭������T�B�̷� reqMapC ��T�A�s�W�@��DTEPH121 
        return extTrdNo;
    }

    /**
     * �̷ӥ�����Ū���p���]�w�p�����Q�����B
     * 
     * @param String     TRD_DATE �p�������� (�w�s��s�ڤ� TRD_DATE)
     * @param String     EXP_DATE �p�������� (�w�s������ EXP_DATE)
     * @param BigDecimal TRD_AMT �w�s����B (�w�s������ TRD_AMT)
     * @param BigDecimal TRD_RATE �w�s�Q�v (�w�s������ TRD_RATE)
     * @param String     CRC ���O (�w�s����O CRC)
     * @param ORG_ID     ������N�� (�w�s�������ID ORG_ID)
     * @return BigDecimal �Q�����B
     */
    public BigDecimal calEpxireIntAmt(String TRD_DATE, String EXP_DATE, BigDecimal TRD_AMT, BigDecimal TRD_RATE, String CRC, String ORG_ID) throws ModuleException {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("TRD_DATE", TRD_DATE);
        param.put("EXP_DATE", EXP_DATE);

        param.put("TRD_AMT", TRD_AMT.toPlainString());
        param.put("TRD_RATE", TRD_RATE.toPlainString());
        param.put("CRC", CRC);

        setAPIParamByOrgID(ORG_ID, param);

        String apiURL = FieldOptionList.getName("EP", "RTG_INT_API", "API_URL");
        return callAPICalEpxireInt(param, apiURL);
    }

    /**
     * �̷ӥ�����Ū���p���]�w�p�����Q�����B
     * @param Map  �w�s�����
     * @return BigDecimal �Q�����B
     */
    public BigDecimal calEpxireIntAmt(Map mapH120) throws ModuleException {
        String ORG_ID = MapUtils.getString(mapH120, "ORG_ID");

        Map<String, Object> param = new HashMap<String, Object>();
        param.putAll(mapH120);
        setAPIParamByOrgID(ORG_ID, param);
        String apiURL = FieldOptionList.getName("EP", "RTG_INT_API", "API_URL");
        return callAPICalEpxireInt(param, apiURL);
    }

    /**
     * �̷ӥ�����]�w�p���覡
     * @param ORG_ID ������
     * @param param
     */
    private void setAPIParamByOrgID(String ORG_ID, Map<String, Object> param) {
        String strIS_ODD = FieldOptionList.getName("EP", "RTG_INT_API", "IS_ODD");
        boolean IS_ODD = "Y".equals(strIS_ODD);
        String RATE_FREQ = FieldOptionList.getName("EP", "RTG_INT_API", "RATE_FREQ");

        String MD_TYPE = FieldOptionList.getName("EP", "API_MD_TYPE", ORG_ID);
        String DAYCNTS = FieldOptionList.getName("EP", "API_DAYCNTS", ORG_ID);
        param.put("DAYCNTS", DAYCNTS);
        param.put("MD_TYPE", MD_TYPE);
        param.put("IS_ODD", IS_ODD);
        param.put("RATE_FREQ", RATE_FREQ);
    }

    /**
     * �I�s IM API RTG0/calFractionAndInt �p��w�s�Q�� RT_G00520.calFractionAndInt
     * 20200428:�t�X���ʲ��ݨD�s�W�Ҳյ����ʲ��I�s�ϥ�
     * 
     * @param String     strINT_DATES �p�������� (�w�s��s�ڤ� TRD_DATE)
     * @param String     strINT_DATEE �p�������� (�w�s������ EXP_DATE)
     * @param String     DAYCNTS �ѼƳ]�w(1�GACT/ACT�B2�GACT/30�B3�GACT/365) (������]�w)
     * @param String     MD_TYPE �p���覡(M�G����BD�G����) (������]�w)
     * @param BigDecimal TRD_AMT �w�s����B
     * @param BigDecimal RATE �w�s�Q�v TRD_RATE
     * @param String     CRC ���O
     * @param boolean    IS_ODD ��s����
     * @param String     RATE_FREQ �I���覡
     * @return String �Q�����B
     */
    private BigDecimal callAPICalEpxireInt(Map param, String apiURL) throws ModuleException {

        BigDecimal interest = BigDecimal.ZERO;

        try {

            String result = (String) CathayAPI.build(API_Platform.IM).getService(apiURL).setParams(param).call(HttpResponseType.STRING); // TODO ���^�Ǫ���result�n�����ơA���楿�`�T����Json String�榡
            Map rtnMap = VOTool.jsonToMap(result);
            log.debug("returnCode: " + rtnMap.get("returnCode"));
            String strIntAmt = MapUtils.getString(rtnMap, "detail");
            log.debug("debug:" + strIntAmt);
            interest = new BigDecimal(rtnMap.get("detail").toString());
        } catch (ModuleException e) {
            log.error(e, e);
        } catch (Exception e) {
            log.error(e, e);
        }
        return interest;

    }

    /**
     * 
     * @param reqMap
     * @param user
     * @throws ModuleException
     */
    private void checkMap(Map reqMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_006"));//���ʲ��w�s�椣�o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_007"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "SP_CD"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_002"));//�@�~�D�餣�i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "ORG_ID"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_008"));//�����H���i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "ACC_NO"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_009"));//���s�b�����i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "TRD_AMT"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_010"));//�w�s���B���i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "CRC"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_011"));//���O���i����
        }
        String TRD_DATE = MapUtils.getString(reqMap, "TRD_DATE");
        if (StringUtils.isBlank(TRD_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_012"));//�s�ڤ餣�i����
        }
        if (!"4".equals(MapUtils.getString(reqMap, "INV_TERM_UNIT"))) {
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "INV_TERM_VALUE"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_013"));//�������i����
            }
        }
        String EXP_DATE = MapUtils.getString(reqMap, "EXP_DATE");
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "EXP_DATE"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_014"));//����餣�i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "INT_PAY_KD"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_015"));//�Q���J�b�覡���i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "TRD_RATE"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_016"));//�Q�v���i����
        }
        if (eie != null) {
            throw eie;
        }

        if (DATE.diffDay(EXP_DATE, TRD_DATE) > 0) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0H120_MSG_017")); //�s�ڤ饲���p������
        }

    }

    /**
    * �T�{ - �ˮ֥����϶�
    * @param reqMap
    * @param user
    * @throws ModuleException
    */
    private void checkMap_confirm(Map reqMap, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_006"));//���ʲ��w�s�椣�o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_007"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "SP_CD"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_002"));//�@�~�D�餣�i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "ORG_ID"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_008"));//�����H���i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "ACC_NO"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_009"));//���s�b�����i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "TRD_AMT"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_010"));//�w�s���B���i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "CRC"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_011"));//���O���i����
        }
        String TRD_DATE = MapUtils.getString(reqMap, "TRD_DATE");
        if (StringUtils.isBlank(TRD_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_012"));//�s�ڤ餣�i����
        }
        if (!"4".equals(MapUtils.getString(reqMap, "INV_TERM_UNIT"))) {
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "INV_TERM_VALUE"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_013"));//�������i����
            }
        }
        String EXP_DATE = MapUtils.getString(reqMap, "EXP_DATE");
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "EXP_DATE"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_014"));//����餣�i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "INT_PAY_KD"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_015"));//�Q���J�b�覡���i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "TRD_RATE"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_016"));//�Q�v���i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "FD_NO"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_018"));//�w�s�渹���i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "APLY_DATE"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_019"));//�e��������i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "TRD_FILE_NO"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_020"));//�w�s��v���ɤ��i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "INT_AMT"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_021"));//�w���J�b�Q�����i����
        }
        if (StringUtils.isBlank(MapUtils.getString(reqMap, "EST_EXP_AMT"))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0H120_MSG_022"));//�w������`�B���i����
        }
        if (eie != null) {
            throw eie;
        }

        if (DATE.diffDay(EXP_DATE, TRD_DATE) > 0) {
            throw new ModuleException(MessageUtil.getMessage("EP_Z0H120_MSG_017")); //�s�ڤ饲���p������
        }

    }

    /**
     * ����~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �]�w�d�߸��
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setFieldsIfExsits(Map reqMap, DataSet ds, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }

    }

    /**
     * �]�w�d�߸��
     * @param value
     * @param ds
     * @param key
     */
    private void setFieldsIfExsits(String value, DataSet ds, String key) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }

    }

    /**
     * �N���B��3��@�r���A�p��2��
     * @param AMT BigDecimal
     * @return amt String
     */
    private String formaterAMTNumber(BigDecimal AMT) {

        NumberFormat formatter = new DecimalFormat("#,##0.00");
        String amt = "";
        try {
            amt = formatter.format(AMT);
        } catch (Exception e) {
            log.fatal("��������B�z�A�^�Ǥ@�ӪŭȦ^�h");
        }
        return amt;
    }

    /**
     * �N���B�h���r��
     * @param AMT BigDecimal
     * @return amt String
     */
    private BigDecimal formaterAMTNumber2BigDecimal(String AMT) {

        BigDecimal rtn = BigDecimal.ZERO;
        try {
            double d1 = new DecimalFormat().parse(AMT).doubleValue();
            rtn = STRING.objToBigDecimal(String.valueOf(d1), BigDecimal.ZERO);

        } catch (Exception e) {
            log.fatal("��������B�z�A�^�Ǥ@�ӪŭȦ^�h");
        }
        return rtn;

    }
}
