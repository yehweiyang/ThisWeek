package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPG221;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014/12/09  Created ������
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��a���������R�P�Ҳ�
 * �Ҳ�ID    EP_Z0G221 
 * ���n����    ��a�����������@�Ҳ�
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EP_Z0G221 {
    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G221.SQL_queryList_001";

    private static final String SQL_queryMapList_001 = "com.cathay.ep.z0.module.EP_Z0G221.SQL_queryMapList_001";

    private static final Logger log = Logger.getLogger(EP_Z0G221.class);

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0G221.SQL_insert_001";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0G221.SQL_delete_001";

    private static final String[] g221forBigDecimal = { "D_COST_AMT_INV", "D_COST_AMT", "D_LOSS_AMT", "D_LOSS_AMT_INV", "D_DEPR_AMT",
            "D_DEPR_AMT_INV", "D_YR_DEPR", "D_YR_DEPR_INV", "CUR_DEPR", "D_LY_DEPR" };

    private BigDecimal BD_15 = new BigDecimal("15");    
    
    //private static final String SQL_approve_001 = "com.cathay.ep.z0.module.EP_Z0G221.SQL_approve_001";

    /**
     * Ū������R�P���ӲM��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        String APLY_NO = null;
        String DEPR_KD = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_003")); //�ǤJ��a�N�����o���ŭ�
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_004")); //�ǤJ�ץ�s�����o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_KD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_005")); //�ǤJ�������O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�߮ץ�_��a�������������� (DTEPG221)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("DEPR_KD", DEPR_KD);
        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        List<Map> rtnList = new ArrayList();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //���O
            rtnMap.put("KIND_NM", FieldOptionList.getName("EP", "KIND", MapUtils.getString(rtnMap, "KIND")));
            //�u������  
            rtnMap.put("SUB_ITEM_NO_NM", FieldOptionList.getName("EP", "SUB_ITEM_NO", MapUtils.getString(rtnMap, "SUB_ITEM_NO")));

            rtnMap.put("DEPR_KD_NM", FieldOptionList.getName("EP", "DEPR_KD", MapUtils.getString(rtnMap, "DEPR_KD")));
            rtnList.add(rtnMap);
        }
        return rtnList;

    }

    /**
     * Ū������R�P���ӲM��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryMapList(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        String APLY_NO = null;

        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            APLY_NO = MapUtils.getString(reqMap, "APLY_NO");

            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_003")); //�ǤJ��a�N�����o���ŭ�
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_004")); //�ǤJ�ץ�s�����o���ŭ�
            }

        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�d�߮ץ�_��a�������������� (DTEPG221)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BASE_CD", BASE_CD);
        ds.setField("APLY_NO", APLY_NO);
        DBUtil.searchAndRetrieve(ds, SQL_queryMapList_001);

        Map<String, List<Map>> keyMap = new HashMap();
        StringBuilder sb = new StringBuilder();
        List<Map> keyList;
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);

            //���O
            rtnMap.put("KIND_NM", FieldOptionList.getName("EP", "KIND", MapUtils.getString(rtnMap, "KIND")));
            //�u������  
            rtnMap.put("SUB_ITEM_NO_NM", FieldOptionList.getName("EP", "SUB_ITEM_NO", MapUtils.getString(rtnMap, "SUB_ITEM_NO")));
            String key = sb.append(MapUtils.getString(rtnMap, "SUB_CPY_ID")).append(MapUtils.getString(rtnMap, "BASE_CD")).append(
                MapUtils.getString(rtnMap, "APLY_NO")).append(MapUtils.getString(rtnMap, "DEPR_KD")).toString();
            sb.setLength(0);
            if (keyMap.containsKey(key)) {
                keyMap.get(key).add(rtnMap);
            } else {
                keyList = new ArrayList();
                keyList.add(rtnMap);
                keyMap.put(key, keyList);

            }
        }
        return keyMap;
    }

    /**
     * Ū����������R�P�պ�
     * @param reqMap
     * @param costList
     * @return
     * @throws ModuleException
     */
    public List<Map> trialDeCost(Map reqMap, List<Map> costList) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BASE_CD = null;
        String APLY_NO = null;
        String DEPR_KD = null;
        BigDecimal TOT_LND_AREA = null;
        BigDecimal D_LND_AREA = null;
        BigDecimal TOT_BLD_AREA = null;
        BigDecimal D_BLD_AREA = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            BASE_CD = MapUtils.getString(reqMap, "BASE_CD");
            APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            DEPR_KD = MapUtils.getString(reqMap, "DEPR_KD");
            TOT_LND_AREA = STRING.objToBigDecimal(reqMap.get("TOT_LND_AREA"), null);
            D_LND_AREA = STRING.objToBigDecimal(reqMap.get("D_LND_AREA"), null);
            TOT_BLD_AREA = STRING.objToBigDecimal(reqMap.get("TOT_BLD_AREA"), null);
            D_BLD_AREA = STRING.objToBigDecimal(reqMap.get("D_BLD_AREA"), null);
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(BASE_CD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_003")); //�ǤJ��a�N�����o���ŭ�
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_004")); //�ǤJ�ץ�s�����o���ŭ�
            }
            if (StringUtils.isBlank(DEPR_KD)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_005")); //�ǤJ�������O���o���ŭ�
            }
            if (TOT_LND_AREA == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_006")); //�ǤJ�g�a���n���o���ŭ�
            }
            if (D_LND_AREA == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_007")); //�ǤJ�g�a��֭��n���o���ŭ�
            }
            if (TOT_BLD_AREA == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_008")); //�ǤJ�ت����n���o���ŭ�
            }
            if (D_BLD_AREA == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_009")); //�ǤJ�ت���֭��n���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        BigDecimal dRatio_1 = D_LND_AREA.divide(TOT_LND_AREA, 16, BigDecimal.ROUND_HALF_UP);
        BigDecimal dRatio_2 = D_BLD_AREA.divide(TOT_BLD_AREA, 16, BigDecimal.ROUND_HALF_UP);
        //�v���B�z costList ���������R�P���

        for (Map cMap : costList) {
            String CAL_DATE = MapUtils.getString(reqMap, "TRN_DATE");
            log.debug("�R�P�����:" + CAL_DATE);
            BigDecimal D_COST_AMT = BigDecimal.ZERO;
            BigDecimal D_LOSS_AMT = BigDecimal.ZERO;
            BigDecimal D_LY_DEPR = BigDecimal.ZERO;
            BigDecimal CUR_DEPR = BigDecimal.ZERO;
            BigDecimal D_DEPR_AMT = BigDecimal.ZERO;
            BigDecimal D_YR_DEPR = BigDecimal.ZERO;

            String D_CAL_DATE = CAL_DATE;
            cMap.put("D_CAL_DATE", D_CAL_DATE);
            BigDecimal COST_AMT = STRING.objToBigDecimal(cMap.get("COST_AMT"), BigDecimal.ZERO);
            BigDecimal LOSS_AMT = STRING.objToBigDecimal(cMap.get("LOSS_AMT"), BigDecimal.ZERO);
            if ("1".equals(MapUtils.getString(cMap, "KIND"))) {
                //�U�C�ƭȭp��A�|�ˤ��J����
                D_COST_AMT = COST_AMT.multiply(dRatio_1).setScale(0, BigDecimal.ROUND_HALF_UP);
                D_LOSS_AMT = LOSS_AMT.multiply(dRatio_1).setScale(0, BigDecimal.ROUND_HALF_UP);
                D_LY_DEPR = BigDecimal.ZERO;
                CUR_DEPR = BigDecimal.ZERO;
                D_DEPR_AMT = BigDecimal.ZERO;
                D_YR_DEPR = BigDecimal.ZERO;

            } else {
                //�U�C�ƭȭp��A�|�ˤ��J����
                D_COST_AMT = COST_AMT.multiply(dRatio_2).setScale(0, BigDecimal.ROUND_HALF_UP);
                D_LOSS_AMT = LOSS_AMT.multiply(dRatio_2).setScale(0, BigDecimal.ROUND_HALF_UP);
                D_LY_DEPR = STRING.objToBigDecimal(cMap.get("LY_DEPR"), BigDecimal.ZERO).multiply(dRatio_2).setScale(0,
                    BigDecimal.ROUND_HALF_UP);
                //�p���p��骺�������¼�
                log.fatal("CAL_DT:"+ CAL_DATE+", cMap:" + cMap + ", reqMap:"+ reqMap);
                
                CUR_DEPR = this.calDeprToDate(reqMap, cMap, CAL_DATE).setScale(0, BigDecimal.ROUND_HALF_UP);
                D_DEPR_AMT = STRING.objToBigDecimal(cMap.get("DEPR_AMT"), BigDecimal.ZERO).multiply(dRatio_2).setScale(0,
                    BigDecimal.ROUND_HALF_UP);
                D_YR_DEPR = STRING.objToBigDecimal(cMap.get("YR_DEPR"), BigDecimal.ZERO).multiply(dRatio_2).setScale(0,
                    BigDecimal.ROUND_HALF_UP);

            }
            cMap.put("D_COST_AMT", D_COST_AMT);
            cMap.put("D_LOSS_AMT", D_LOSS_AMT);
            cMap.put("D_LY_DEPR", D_LY_DEPR);
            cMap.put("CUR_DEPR", CUR_DEPR);
            cMap.put("D_DEPR_AMT", D_DEPR_AMT);
            cMap.put("D_YR_DEPR", D_YR_DEPR);

            //���O
            cMap.put("KIND_NM", FieldOptionList.getName("EP", "KIND", MapUtils.getString(cMap, "KIND")));
            //�u������  
            cMap.put("SUB_ITEM_NO_NM", FieldOptionList.getName("EP", "SUB_ITEM_NO", MapUtils.getString(cMap, "SUB_ITEM_NO")));

            cMap.put("DEPR_KD_NM", FieldOptionList.getName("EP", "DEPR_KD", MapUtils.getString(cMap, "DEPR_KD")));
        }
        return costList;
    }

    /**
     * �p�⥻�����¼�
     * @param reqMap
     * @param cMap
     * @param CAL_DT
     * @return
     * @throws ModuleException
     */
    private BigDecimal calDeprToDate(Map reqMap, Map cMap, String CAL_DT) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }

        }
        if (cMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_010")); //�ǤJ���������R�P��Ƥ��o���ŭ�
        }
        if (StringUtils.isBlank(CAL_DT)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_011")); //�ǤJ�p��餣�o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        String DEPR_YM = DATE.getYearAndMonth(CAL_DT);
//        boolean isIFRS = false;
        // boolean isDEPR = false;
        boolean isFinalDEPR = false;
        //�P�_���­p��覡
//        if ("3".equals(MapUtils.getString(reqMap, "DEPR_KD")) && "2".equals(MapUtils.getString(cMap, "ACC_TP"))) {
//            isIFRS = true;
//        }
        BigDecimal TWELVE = new BigDecimal(12);
        BigDecimal LY_DEPR_MON = BigDecimal.ZERO;//�h�~�֧���
        String COST_DT = DATE.getYearAndMonth((MapUtils.getString(cMap, "COST_DT")));
        String MM_DEPR_YM = DEPR_YM.substring(4, 6);
        BigDecimal TOT_DERP_MON = BigDecimal.ZERO;
        //�����O���ت��A�~�ݭn����
        if ("2".equals(MapUtils.getString(cMap, "KIND"))) {
            //isDEPR = true;
            String YY_DEPR_YM = DEPR_YM.substring(0, 4);
            String YY_COST_DT = COST_DT.substring(0, 4);
            if (!YY_DEPR_YM.equals(YY_COST_DT)) {
                LY_DEPR_MON = (new BigDecimal(YY_DEPR_YM).subtract(new BigDecimal(YY_COST_DT)).subtract(BigDecimal.ONE)).multiply(TWELVE)
                        .add(STRING.objToBigDecimal(cMap.get("FST_YR_MON"), BigDecimal.ZERO));
            }
            //���¦~��
            BigDecimal DEPR_YR = STRING.objToBigDecimal(cMap.get("DEPR_YR"), BigDecimal.ZERO);
            //�@�Τ��
            TOT_DERP_MON = (DEPR_YR.add(BigDecimal.ONE)).multiply(TWELVE);
        }
        //�̫�@���u��
        if (LY_DEPR_MON.add(new BigDecimal(MM_DEPR_YM)).compareTo(TOT_DERP_MON) >= 0) {
            isFinalDEPR = true;
        }
        //�{�C����
        BigDecimal COST_AMT = BigDecimal.ZERO;
        if ("2".equals(MapUtils.getString(reqMap, "DEPR_KD"))) {
            log.debug("[DEPR_KD_2] COST_AMT:" + cMap.get("COST_AMT") + ",LOSS_AMT:" + cMap.get("LOSS_AMT"));
            COST_AMT = STRING.objToBigDecimal(cMap.get("COST_AMT"), BigDecimal.ZERO).subtract(
                STRING.objToBigDecimal(cMap.get("LOSS_AMT"), BigDecimal.ZERO));
        } else {
            COST_AMT = STRING.objToBigDecimal(cMap.get("COST_AMT"), BigDecimal.ZERO);
        }
        //�h�~�ײֿn����
        BigDecimal LY_DEPR = BigDecimal.ZERO;
        //�e�����~�ײֿn����
        BigDecimal PRE_YR_DEPR = BigDecimal.ZERO;
        if ("01".equals(MM_DEPR_YM)) {
            LY_DEPR = STRING.objToBigDecimal(cMap.get("DEPR_AMT"), BigDecimal.ZERO);
        } else {
            PRE_YR_DEPR = STRING.objToBigDecimal(cMap.get("YR_DEPR"), BigDecimal.ZERO);
            LY_DEPR = STRING.objToBigDecimal(cMap.get("LY_DEPR"), BigDecimal.ZERO);
        }
        //���~�ײֿn����
        BigDecimal YR_DEPR = BigDecimal.ZERO;
        if (isFinalDEPR) {
            log.debug("FinalDepr COST_AMT:" + COST_AMT);
            YR_DEPR = COST_AMT.subtract(STRING.objToBigDecimal(cMap.get("LY_DEPR"), BigDecimal.ZERO));
        } else {
            log.debug("COST_AMT:" + COST_AMT + ", LY_DEPR:" + LY_DEPR + ",TOT_DERP_MON:" + TOT_DERP_MON + ",MM_DEPR_YM:" + MM_DEPR_YM
                    + ",LY_DEPR_MON:" + LY_DEPR_MON);
            // 2015/02/06 ���~�� ���¤���p��
            BigDecimal YR_DEPR_MM = getDeprMonth(DEPR_YM,  COST_DT); 
            YR_DEPR = (COST_AMT.subtract(LY_DEPR)).divide(TOT_DERP_MON.subtract(LY_DEPR_MON), 6, BigDecimal.ROUND_HALF_UP).multiply(
                YR_DEPR_MM).setScale(0, BigDecimal.ROUND_HALF_UP);
            if ((YR_DEPR.add(LY_DEPR)).compareTo(COST_AMT) > 0) {
                YR_DEPR = COST_AMT.subtract(LY_DEPR);
            }
        }
        log.debug("YR_DEPR:" + YR_DEPR + ", PRE_YR_DEPR:" + PRE_YR_DEPR);
        String[] CAL_DT_array = DATE.parseNumber(CAL_DT);
        String[] CAL_LAST_array = DATE.parseNumber(DATE.getMonthLastDate(CAL_DT));
        BigDecimal DD_CAL_D = new BigDecimal(CAL_DT_array[2]).subtract(BigDecimal.ONE);
        BigDecimal CAL_DAYS = new BigDecimal(CAL_LAST_array[2]);
        return (YR_DEPR.subtract(PRE_YR_DEPR)).multiply(DD_CAL_D).divide(CAL_DAYS, 0, BigDecimal.ROUND_HALF_UP);//�|�ˤ��J��???
    }

    /**
     * �s�W��������R�P����
     * @param reqMap
     * @param costList
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void insert(Map reqMap, List<Map> costList, UserObject user) throws ModuleException, DBException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
        }
        if (costList == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_010")); //�ǤJ���������R�P��Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_012")); //�ǤJ�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�v���B�z costList  //���������R�P���
        //�B�z���update
        BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���
        Timestamp tTime = DATE.currentTime();
        String EmpID = user.getEmpID();
        String OpUnit = user.getOpUnit();
        String EmpName = user.getEmpName();
        BigDecimal D_LND_COST = BigDecimal.ZERO;
        BigDecimal D_BLD_COST = BigDecimal.ZERO;

        BigDecimal SUM_D_LOSS_AMT = BigDecimal.ZERO;
        BigDecimal SUM_CUR_DEPR = BigDecimal.ZERO;
        BigDecimal SUM_D_LY_DEPR = BigDecimal.ZERO;
        BigDecimal SUM_D_DEPR_AMT = BigDecimal.ZERO;
        BigDecimal SUM_D_YR_DEPR = BigDecimal.ZERO;

        BigDecimal TOT_LND_COST = BigDecimal.ZERO;
        BigDecimal SUM_D_LND_LOSS = BigDecimal.ZERO;
        BigDecimal TOT_BLD_COST = BigDecimal.ZERO;
        BigDecimal SUM_D_BLD_LOSS = BigDecimal.ZERO;
        BigDecimal TOT_DEPR_AMT = BigDecimal.ZERO;

        try {
            int batchCount;

            buds.preparedBatch(SQL_insert_001);

            batchCount = (costList.size() / commit_size) + 1;

            BigDecimal IFRS_INV_RT = STRING.objToBigDecimal(reqMap.get("IFRS_INV_RT"), BigDecimal.ZERO);

            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? costList.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {

                        Map G221Map = costList.get(j);
                        this.BigDecimaltoZeroforMap(G221Map);

                        DTEPG221 DTEPG221VO = VOTool.mapToVO(DTEPG221.class, G221Map);
                        BigDecimal D_COST_AMT = DTEPG221VO.getD_COST_AMT();
                        BigDecimal COST_AMT = DTEPG221VO.getCOST_AMT();
                        if ("2".equals(DTEPG221VO.getDEPR_KD())) {
                            COST_AMT = COST_AMT.subtract(DTEPG221VO.getLOSS_AMT());
                            D_COST_AMT = D_COST_AMT.subtract(DTEPG221VO.getD_LOSS_AMT());
                        }
                        String KIND = DTEPG221VO.getKIND();
                        DTEPG221VO.setD_COST_AMT_INV(D_COST_AMT.multiply(IFRS_INV_RT).setScale(0, BigDecimal.ROUND_HALF_UP));
                        DTEPG221VO.setD_COST_AMT_SLF(D_COST_AMT.subtract(DTEPG221VO.getD_COST_AMT_INV()));

                        DTEPG221VO
                                .setD_LOSS_AMT_INV(DTEPG221VO.getD_LOSS_AMT().multiply(IFRS_INV_RT).setScale(0, BigDecimal.ROUND_HALF_UP));
                        DTEPG221VO.setD_LOSS_AMT_SLF(DTEPG221VO.getD_LOSS_AMT().subtract(DTEPG221VO.getD_LOSS_AMT_INV()));

                        DTEPG221VO
                                .setD_DEPR_AMT_INV(DTEPG221VO.getD_DEPR_AMT().multiply(IFRS_INV_RT).setScale(0, BigDecimal.ROUND_HALF_UP));
                        DTEPG221VO.setD_DEPR_AMT_SLF(DTEPG221VO.getD_DEPR_AMT().subtract(DTEPG221VO.getD_DEPR_AMT_INV()));

                        DTEPG221VO.setD_YR_DEPR_INV(DTEPG221VO.getD_YR_DEPR().multiply(IFRS_INV_RT).setScale(0, BigDecimal.ROUND_HALF_UP));
                        DTEPG221VO.setD_YR_DEPR_SLF(DTEPG221VO.getD_YR_DEPR().subtract(DTEPG221VO.getD_YR_DEPR_INV()));

                        if ("1".equals(KIND)) {
                            TOT_LND_COST = TOT_LND_COST.add(COST_AMT);
                            SUM_D_LND_LOSS = SUM_D_LND_LOSS.add(DTEPG221VO.getD_LOSS_AMT());
                        } else if ("2".equals(KIND)) {
                            TOT_BLD_COST = TOT_BLD_COST.add(COST_AMT);
                            SUM_D_BLD_LOSS = SUM_D_BLD_LOSS.add(DTEPG221VO.getD_LOSS_AMT());
                            TOT_DEPR_AMT = TOT_DEPR_AMT.add(DTEPG221VO.getDEPR_AMT());
                        }

                        //�p��X�p�R�P��
                        if ("1".equals(KIND)) {
                            D_LND_COST = D_LND_COST.add(D_COST_AMT);
                        } else {
                            D_BLD_COST = D_BLD_COST.add(D_COST_AMT);
                        }
                        SUM_D_LOSS_AMT = SUM_D_LOSS_AMT.add(DTEPG221VO.getD_LOSS_AMT());
                        SUM_CUR_DEPR = SUM_CUR_DEPR.add(DTEPG221VO.getCUR_DEPR());
                        SUM_D_LY_DEPR = SUM_D_LY_DEPR.add(DTEPG221VO.getD_LY_DEPR());
                        SUM_D_DEPR_AMT = SUM_D_DEPR_AMT.add(DTEPG221VO.getD_DEPR_AMT());
                        SUM_D_YR_DEPR = SUM_D_YR_DEPR.add(DTEPG221VO.getD_YR_DEPR());

                        buds.setField("SUB_CPY_ID", DTEPG221VO.getSUB_CPY_ID());
                        buds.setField("BASE_CD", DTEPG221VO.getBASE_CD());
                        buds.setField("APLY_NO", DTEPG221VO.getAPLY_NO());
                        buds.setField("DEPR_KD", DTEPG221VO.getDEPR_KD());
                        buds.setField("COST_SEQ", DTEPG221VO.getCOST_SEQ());
                        //buds.setField("TRN_KIND", DTEPG221VO.getTRN_KIND());
                        buds.setField("D_CAL_DATE", DTEPG221VO.getD_CAL_DATE());
                        buds.setField("KIND", DTEPG221VO.getKIND());
                        buds.setField("COST_AMT", DTEPG221VO.getCOST_AMT());
                        buds.setField("D_RATIO", DTEPG221VO.getD_RATIO());
                        buds.setField("D_COST_AMT", DTEPG221VO.getD_COST_AMT());
                        buds.setField("COST_AMT_INV", DTEPG221VO.getCOST_AMT_INV());
                        buds.setField("D_COST_AMT_INV", DTEPG221VO.getD_COST_AMT_INV());
                        buds.setField("COST_AMT_SLF", DTEPG221VO.getCOST_AMT_SLF());
                        buds.setField("D_COST_AMT_SLF", DTEPG221VO.getD_COST_AMT_SLF());
                        buds.setField("LOSS_AMT", DTEPG221VO.getLOSS_AMT());
                        buds.setField("D_LOSS_AMT", DTEPG221VO.getD_LOSS_AMT());
                        buds.setField("D_LOSS_AMT_INV", DTEPG221VO.getD_LOSS_AMT_INV());
                        buds.setField("D_LOSS_AMT_SLF", DTEPG221VO.getD_LOSS_AMT_SLF());
                        buds.setField("LY_DEPR", DTEPG221VO.getLY_DEPR());
                        buds.setField("D_LY_DEPR", DTEPG221VO.getD_LY_DEPR());
                        buds.setField("CUR_DEPR", DTEPG221VO.getCUR_DEPR());
                        buds.setField("DEPR_AMT", DTEPG221VO.getDEPR_AMT());
                        buds.setField("D_DEPR_AMT", DTEPG221VO.getD_DEPR_AMT());
                        buds.setField("DEPR_AMT_INV", DTEPG221VO.getDEPR_AMT_INV());
                        buds.setField("D_DEPR_AMT_INV", DTEPG221VO.getD_DEPR_AMT_INV());
                        buds.setField("DEPR_AMT_SLF", DTEPG221VO.getDEPR_AMT_SLF());
                        buds.setField("D_DEPR_AMT_SLF", DTEPG221VO.getD_DEPR_AMT_SLF());
                        buds.setField("YR_DEPR", DTEPG221VO.getYR_DEPR());
                        buds.setField("D_YR_DEPR", DTEPG221VO.getD_YR_DEPR());
                        buds.setField("YR_DEPR_INV", DTEPG221VO.getYR_DEPR_INV());
                        buds.setField("D_YR_DEPR_INV", DTEPG221VO.getD_YR_DEPR_INV());
                        buds.setField("YR_DEPR_SLF", DTEPG221VO.getYR_DEPR_SLF());
                        buds.setField("D_YR_DEPR_SLF", DTEPG221VO.getD_YR_DEPR_SLF());
                        buds.setField("ITEM_STS", DTEPG221VO.getITEM_STS());

                        buds.setField("CHG_DATE", tTime);
                        buds.setField("CHG_DIV_NO", OpUnit);
                        buds.setField("CHG_ID", EmpID);
                        buds.setField("CHG_NAME", EmpName);

                        buds.addBatch();

                    }
                    buds.executeBatch();
                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap,
                                (Exception) theErrorObject[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException(MessageUtil.getMessage("�s�W��Ʀ��~"));//�s�W��Ʀ��~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException(e);//�妸�s�W����
                }
            }//end 

        } finally {
            if (buds != null) {
                buds.close();
            }
        }
        //�s�W��a�R�P��T
        Map sumMap = new HashMap();
        sumMap.putAll(reqMap);
        sumMap.put("D_LND_COST", D_LND_COST);
        sumMap.put("D_BLD_COST", D_BLD_COST);
        sumMap.put("SUM_D_LOSS_AMT", SUM_D_LOSS_AMT);
        sumMap.put("SUM_CUR_DEPR", SUM_CUR_DEPR);
        sumMap.put("SUM_D_LY_DEPR", SUM_D_LY_DEPR);
        sumMap.put("SUM_D_DEPR_AMT", SUM_D_DEPR_AMT);
        sumMap.put("SUM_D_YR_DEPR", SUM_D_YR_DEPR);
        sumMap.put("TOT_LND_COST", TOT_LND_COST);
        sumMap.put("SUM_D_LND_LOSS", SUM_D_LND_LOSS);
        sumMap.put("TOT_BLD_COST", TOT_BLD_COST);
        sumMap.put("SUM_D_BLD_LOSS", SUM_D_BLD_LOSS);
        sumMap.put("TOT_DEPR_AMT", TOT_DEPR_AMT);
        sumMap.put("CHG_DATE", tTime);
        sumMap.put("CHG_DIV_NO", OpUnit);
        sumMap.put("CHG_ID", EmpID);
        sumMap.put("CHG_NAME", EmpName);
        sumMap.put("D_COST_CD", 1); //�ݳB�z�A����X����Ю֮ɧ�s
        new EP_Z0G220().insert(sumMap);
    }

    /**
     * ������������R�P����
     * @param reqMap
     * @param costList
     * @param user
     * @throws ModuleException
     */
    public void delete(Map reqMap, List<Map> costList, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_001")); //�ǤJ���󤣱o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_002")); //�ǤJ�����q�O���o���ŭ�
            }
        }
        if (costList == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_010")); //�ǤJ���������R�P��Ƥ��o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0G221_MSG_012")); //�ǤJ�@�~�H�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        for (Map cMap : costList) {
            ds.clear();
            ds.setField("SUB_CPY_ID", cMap.get("SUB_CPY_ID"));
            ds.setField("BASE_CD", cMap.get("BASE_CD"));
            ds.setField("APLY_NO", cMap.get("APLY_NO"));
            ds.setField("DEPR_KD", cMap.get("DEPR_KD"));
            ds.setField("COST_SEQ", cMap.get("COST_SEQ"));
            DBUtil.executeUpdate(ds, SQL_delete_001);
        }

        //�R�� �R�P�����T
        new EP_Z0G220().delete(reqMap);

    }

    private void BigDecimaltoZeroforMap(Map G221Map) {

        for (String key : g221forBigDecimal) {
            G221Map.put(key, STRING.objToBigDecimal(G221Map.get(key), BigDecimal.ZERO));
        }
    }
    
	public BigDecimal getDeprMonth(String DEPR_YM, String COST_DT) {
		String DEPR_YM_YY = DEPR_YM.substring(0, 4);
		String DEPR_YM_MM = DEPR_YM.substring(4, 6);
		String[] CAL_LAST_array = DATE.parseNumber(COST_DT);
		String YY_COST_DT = CAL_LAST_array[0];
		BigDecimal YR_MM = new BigDecimal(DEPR_YM_MM);
		if(YY_COST_DT.equals(DEPR_YM_YY)) {
			String MM_COST_DT = CAL_LAST_array[1];
			String DD_COST_DT = CAL_LAST_array[2];
			BigDecimal MM_COST = new BigDecimal(MM_COST_DT);
			if(new BigDecimal(DD_COST_DT).compareTo(BD_15)<=0 ) {
				MM_COST = MM_COST.subtract(BigDecimal.ONE);	
			}
			YR_MM = YR_MM.subtract(MM_COST);            		
		}
		return YR_MM;
	}

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
