package com.cathay.ep.z0.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPF170;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2013/07/01  Created ����i
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �j�ӤH���]�w���@�Ҳ�
 * �Ҳ�ID    EP_Z0F170
 * ���n����    �j�ӤH���]�w���@�Ҳ�
 * </pre>
 * @author ����[
 * @since 2014/10/13
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0F170 {

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0F170.SQL_insert_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0F170.SQL_queryMap_001";

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0F170.SQL_queryList_001";

    private static final String SQL_update_001 = "com.cathay.ep.z0.module.EP_Z0F170.SQL_update_001";

    /**
     * Ū���j�ӤH���]�w�ɲM��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException("�ǤJ�Ѽ�(reqMap)���i����");
        }
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "�ǤJ�����q�O���o���ŭ�");
        }
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "�ǤJ�j�ӥN�����o���ŭ�");
        }
        if (eie != null) {
            throw eie;
        }

        //�H�ǤJ�����q�O�Τj�ӥN���d�ߤj�ӤH���]�w��(DTEPF170)�G
        DataSet ds = Transaction.getDataSet();
        boolean isBLD_CD = STRING.isMatchPattern(BLD_CD, "^\\w+$");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        String key_word = new StringBuilder().append("%").append(BLD_CD).append("%").toString();
        ds.setField("BLD_CD", key_word);
        ds.setField("BLD_NAME", key_word);

        List<Map> BLD_CDList = VOTool.findToMaps(ds, SQL_queryList_001);
        for (Map BLD_CDMap : BLD_CDList) {
            if (isBLD_CD) {
                BLD_CDMap.put("INPUT_CD", BLD_CDMap.get("BLD_CD"));
                BLD_CDMap.put("INPUT_NM", BLD_CDMap.get("BLD_NAME"));
            } else {
                BLD_CDMap.put("INPUT_CD", BLD_CDMap.get("BLD_NAME"));
                BLD_CDMap.put("INPUT_NM", BLD_CDMap.get("BLD_CD"));
            }
        }

        return BLD_CDList;
    }

    /**
     * Ū���j�ӤH���]�w��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map queryMap(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException("�ǤJ�Ѽ�(reqMap)���i����");
        }
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "�ǤJ�����q�O���o���ŭ�");
        }
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "�ǤJ�j�ӥN�����o���ŭ�");
        }
        if (eie != null) {
            throw eie;
        }

        //�H�ǤJ�����q�O�Τj�ӥN���d�ߤj�ӤH���]�w��(DTEPF170)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", BLD_CD);

        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001);
        //[20190731] �N�P�_���q�D�{�����Ҳդ��@��
        String BLD_USE_CD = MapUtils.getString(rtnMap, "A110_BLD_USE_CD");
        if ("01".equals(BLD_USE_CD)) {
            //[20190715] �YA110_BLD_USE_CD = 01 , �{���޲z�H�� �]�w 
            rtnMap.put("REQ_USR_NM", rtnMap.get("Z110_NAME"));
        } else if ("03".equals(BLD_USE_CD) || "04".equals(BLD_USE_CD)) {
            //[20190715] �YA110_BLD_USE_CD = 03 or 04 , �{���޲z�H���]�w
            rtnMap.put("REQ_USR_NM", rtnMap.get("BLD_USR_NAME"));
            rtnMap.put("REQ_ID", rtnMap.get("BLD_USR_ID"));
            rtnMap.put("REQ_NM", rtnMap.get("CLC_DIV_NM"));
        }

        return rtnMap;
    }

    /**
     * �s�W�j�ӤH���]�w��
     * @param F170VO
     * @param user
     * @throws ModuleException
     */
    public void insert(DTEPF170 F170VO, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String BLD_CD = null;
        if (F170VO == null) {
            eie = getErrorInputException(eie, "�ǤJ�j�ӤH���]�w�ɤ��i����");
        } else {
            SUB_CPY_ID = F170VO.getSUB_CPY_ID();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, "�ǤJ�����q�O���o���ŭ�");
            }
            BLD_CD = F170VO.getBLD_CD();
            if (StringUtils.isBlank(BLD_CD)) {
                eie = getErrorInputException(eie, "�ǤJ�j�ӥN�����o���ŭ�");
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, "�ϥΪ̸�T���i����");
        }
        if (eie != null) {
            throw eie;
        }

        //�s�W�j�ӤH���]�w�� DTEPF170�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("BLD_NAME", F170VO.getBLD_NAME());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("REQ_DIV", F170VO.getREQ_DIV());
        ds.setField("REQ_NM", F170VO.getREQ_NM());
        ds.setField("REQ_ID", F170VO.getREQ_ID());
        ds.setField("FIX_DIV_ID", F170VO.getFIX_DIV_ID());
        ds.setField("FIX_GROUP_ID", F170VO.getFIX_GROUP_ID());
        ds.setField("SUBCON_GROUP_ID", F170VO.getSUBCON_GROUP_ID());
        ds.setField("ARA_CD", F170VO.getARA_CD());
        ds.setField("ZIP_CODE", F170VO.getZIP_CODE());
        ds.setField("ZIP_NAME", F170VO.getZIP_NAME());
        ds.setField("BLD_ADDR", F170VO.getBLD_ADDR());
        ds.setField("BLD_USE_CD", F170VO.getBLD_USE_CD());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        //VOTool.insert(F170Vo);
        DBUtil.executeUpdate(ds, SQL_insert_001);

    }

    /**
     * �R���j�ӤH���]�w��
     * @param F170VO
     * @param user
     * @throws ModuleException
     */
    public void delete(DTEPF170 F170VO, UserObject user) throws ModuleException {

        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (F170VO == null) {
            eie = getErrorInputException(eie, "�ǤJ�j�ӤH���]�w�ɤ��i����");
        } else {
            if (StringUtils.isBlank(F170VO.getSUB_CPY_ID())) {
                eie = getErrorInputException(eie, "�ǤJ�����q�O���o���ŭ�");
            }
            if (StringUtils.isBlank(F170VO.getBLD_CD())) {
                eie = getErrorInputException(eie, "�ǤJ�j�ӥN�����o���ŭ�");
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, "�ϥΪ̸�T���i����");
        }
        if (eie != null) {
            throw eie;
        }

        VOTool.delByPK(F170VO);
    }

    /**
     * �ק�j�ӤH���]�w��
     * @param F170VO
     * @param user
     * @throws ModuleException 
     */
    public void update(DTEPF170 F170VO, UserObject user) throws ModuleException {

        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        String SUB_CPY_ID = F170VO.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "�ǤJ�����q�O���o���ŭ�");
        }
        String BLD_CD = F170VO.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "�ǤJ�j�ӥN�����o���ŭ�");
        }
        if (eie != null) {
            throw eie;
        }

        //�ק�j�ӤH���]�w�� DTEPF170�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("BLD_CD", BLD_CD); //PK
        setFieldIfExist(ds, "BLD_NAME", F170VO.getBLD_NAME());
        setFieldIfExist(ds, "SUB_CPY_ID", SUB_CPY_ID);
        setFieldIfExist(ds, "REQ_DIV", F170VO.getREQ_DIV());
        setFieldIfExist(ds, "REQ_NM", F170VO.getREQ_NM());
        setFieldIfExist(ds, "REQ_ID", F170VO.getREQ_ID());
        setFieldIfExist(ds, "FIX_DIV_ID", F170VO.getFIX_DIV_ID());
        setFieldIfExist(ds, "FIX_GROUP_ID", F170VO.getFIX_GROUP_ID());
        setFieldIfExist(ds, "SUBCON_GROUP_ID", F170VO.getSUBCON_GROUP_ID());
        setFieldIfExist(ds, "ARA_CD", F170VO.getARA_CD());
        setFieldIfExist(ds, "ZIP_CODE", F170VO.getZIP_CODE());
        setFieldIfExist(ds, "ZIP_NAME", F170VO.getZIP_NAME());
        setFieldIfExist(ds, "BLD_ADDR", F170VO.getBLD_ADDR());
        setFieldIfExist(ds, "BLD_USE_CD", F170VO.getBLD_USE_CD());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());

        //VOTool.update(F170Vo);
        DBUtil.executeUpdate(ds, SQL_update_001);

    }

    /**
     * SQL�����D���n�Ѽ�
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

}
