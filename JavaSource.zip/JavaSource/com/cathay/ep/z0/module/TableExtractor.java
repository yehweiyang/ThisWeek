package com.cathay.ep.z0.module;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;

import org.jsoup.nodes.Document;

import com.cathay.ep.vo.DTEPZ300;
import com.cathay.ep.vo.DTEPZ301;

/**
 * <pre>
 * TableExtractor
 * </pre>
 * 
 * @author
 * @since 2015/5/22
 * @since [2019-04-29] �ӽЮ�190123001147 - �u�Ƶ{��
 */
public class TableExtractor extends NewsExtractor {
    /**
     * �غc�l
     * @param site
     */
    public TableExtractor(DTEPZ300 site) {
        super(site);
    }

    //private static final Logger log = Logger.getLogger(TableExtractor.class);

    // [20190429] �R�����եε{��

    /**
     * �ѪR����(STEP 2)
     * �мgNewsExtractor.digesNews(site)
     */
    public List<DTEPZ301> digestNews(DTEPZ300 site) throws IOException, MalformedURLException {
        String url = site.getURL();

        Document doc = getDocument(site);
        //log.debug("### DOC::" + StringUtils.substring(doc.text(), 0, 100));
        //log.debug("### DOC::" + doc.text());
        String selector = site.getSELECTOR();
        List<DTEPZ301> matchNews = extractTable(doc, url, selector);
        return matchNews;
    }

}
