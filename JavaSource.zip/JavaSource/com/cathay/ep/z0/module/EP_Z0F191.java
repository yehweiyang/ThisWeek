package com.cathay.ep.z0.module;

import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2019/5/24 Created �L�ç�
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �j�ӳ]�ƺ��װO���@�μҲ�
 * �Ҳ�ID      EP_Z0F191
 * ���n����    �j�ӳ]�ƺ��װO���@�μҲ�
 * </pre>
 * @author 
 * @since 2019/5/24
 */
@SuppressWarnings("unchecked")
public class EP_Z0F191 {
    
    private static final String SQL_queryDTEPF191MaxSerNo_001 = "com.cathay.ep.z0.module.EP_Z0F191.SQL_queryDTEPF191MaxSerNo_001";
    
    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0F191.SQL_delete_001";

    /**
     * �d�̤߳j�y����
     * @param inMap
     * @return 
     * @throws Exception
     */

    public int queryDTEPF191MaxSerNo(Map inMap) throws ModuleException {
        if (inMap == null || inMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F191_MSG_001")); //�ǤJ�ѼƦ��~
        }
        String APLY_NO = MapUtils.getString(inMap, "APLY_NO");
        String SUB_CPY_ID = MapUtils.getString(inMap, "SUB_CPY_ID");
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F191_MSG_002")); //�ץ�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F191_MSG_003")); //�����q�O���o����
        }
        if (eie != null) {
            throw eie;
        }
        
        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO",  MapUtils.getString(inMap, "APLY_NO"));
        ds.setField("SUB_CPY_ID", MapUtils.getString(inMap, "SUB_CPY_ID"));
        DBUtil.searchAndRetrieve(ds, SQL_queryDTEPF191MaxSerNo_001);
        
        ds.next();
        return ds.getField(0) == null ? 0 : (Integer) ds.getField(0);
    }

    /**
     * �R���j�ӳ]�ƺ��װO�����
     * @param APLY_NO
     * @param SUB_CPY_ID
     * @param isDataNotFoundError
     * @throws ModuleException
     */
    public void delete(String APLY_NO, String SUB_CPY_ID, boolean isDataNotFoundError) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F191_MSG_002")); //�ץ�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F191_MSG_003")); //�����q�O���o����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_delete_001, isDataNotFoundError);
    }
    
    /**
     * �걵���~�T��
     * @param eie
     * @param msg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(msg);
        return eie;
    }
}