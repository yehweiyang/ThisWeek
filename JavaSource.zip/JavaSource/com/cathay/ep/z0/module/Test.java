package com.cathay.ep.z0.module;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.im.util.MessageUtil;

public class Test {
public static void main(String[] args) {
//    System.out.println(StringUtils.isEmpty(""));
//    System.out.println(StringUtils.isEmpty("  "));
//    System.out.println(StringUtils.isBlank(""));
//    System.out.println(StringUtils.isBlank("  "));
//    Map reqMap = new HashMap();
//    System.out.println(MapUtils.getString(reqMap, "INV_CD"));;
//    System.out.println(MapUtils.getString(reqMap, "INV_CD")==null);
//    System.out.println(StringUtils.isBlank("   "));
    System.out.println(MessageUtil.getMessage("A{0}A{1}A", new String[] { "1", "2" }));
}
}
