package com.cathay.ep.z0.module;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DTEPC304 ��X�O�����@�Ҳ�
 * </pre>
 * @author ����[
 * @since 2015/9/3
 */
@SuppressWarnings("unchecked")
public class EP_Z0C304 {

    private static final String SQL_query5_001 = "com.cathay.ep.z0.module.EP_Z0C304.SQL_query5_001";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0C304.SQL_delete_001";

    private static final String SQL_delete_002 = "com.cathay.ep.z0.module.EP_Z0C304.SQL_delete_002";

    /** ����EP_Z0C304:SQL�Ҳդ�
     * �d����Xú�ڬ���
     * @param RCV_YM �����~��
     * @param PAY_NO ú�O�s��
     * @param SWP_DATE ��X���
     * @return ��Xú�ڬ������
     * @throws ModuleException
     */
    public Map query5(String RCV_YM, String PAY_NO, String RCV_NO, String SWP_DATE, String SUB_CPY_ID) throws ModuleException {
        // ��J�Ѽ��ˮ�
        ErrorInputException eie = null;
        if (StringUtils.isBlank(RCV_YM)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_006")); //�����~�뤣�i���ť�
        }
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_007")); //ú�O�s�����i���ť�
        }
        if (StringUtils.isBlank(RCV_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_011")); //�����s�����i���ť�
        }
        if (StringUtils.isBlank(SWP_DATE) || !DATE.isDate(SWP_DATE)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_008")); //��X������i���ťեB�ݬ����T����榡
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("SWP_DATE", SWP_DATE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findOneToMap(ds, SQL_query5_001, false);
    }

    /**
     * ��J�ˮ�
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getEieInstance(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * ��X�����d�� 10/11:modified by i9301216 for ��X�����S��byPK�R��
     * @param RCV_NO
     * @param PAY_KIND
     * @param CRT_NO
     * @param CUS_NO
     * @param RCV_YM
     * @param SWP_DATE
     * @param EXT_NO
     * @return
     * @throws ModuleException
     */
    public Map qryC304forDel(String RCV_NO, String PAY_KIND, String CRT_NO, String CUS_NO, String RCV_YM, String SWP_DATE, String EXT_NO,
            String SUB_CPY_ID, DataSet ds) throws ModuleException {
        ds.clear();
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("PAY_KIND", PAY_KIND);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("SWP_DATE", SWP_DATE);
        ds.setField("EXT_NO", EXT_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        return VOTool.findOneToMap(ds, SQL_delete_001, false);
    }

    public void deleteC304(String RCV_NO, String PAY_KIND, String CRT_NO, String CUS_NO, String RCV_YM, String SWP_DATE, String EXT_NO,
            String SUB_CPY_ID, DataSet ds) throws ModuleException {
        ds.clear();
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("PAY_KIND", PAY_KIND);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("SWP_DATE", SWP_DATE);
        ds.setField("EXT_NO", EXT_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_delete_002);

    }
}
