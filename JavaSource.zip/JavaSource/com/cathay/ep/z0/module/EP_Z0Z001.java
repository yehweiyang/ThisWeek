package com.cathay.ep.z0.module;

import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NextNumberUtility;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.dk.f0.module.DK_F0Z002;
import com.cathay.dk.f0.module.DK_F0Z003;
import com.cathay.ep.module.EP_DBModule;
import com.cathay.ep.vo.DTEPZ001;
import com.cathay.util.ReturnCode;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE        Description                Author
 * 2013/07/01  Created                    ����i
 * 2018/01/11  ��ءG�P�_�����q�O�O�_�X�b   ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �Ǹ����o�@�μҲ�
 * �Ҳ�ID    EP_Z0Z001
 * ���n����    �Ǹ����o�@�μҲ�
 * 
 * 
 * [2018-01-24] �ק��
 * ���:�P�_�����q�O�O�_�X�b
 * 
 * 
 * </pre>
 * @author �x�Ԫ�
 * @since  2013-08-23
 */
@SuppressWarnings("unchecked")
public class EP_Z0Z001 extends EP_DBModule {

    private static final Logger log = Logger.getLogger(EP_Z0Z001.class);

    /** �y�����Ѽ�  */
    private static final String[] fields = { "SUB_CPY_ID", "SYS_CODE", "PARM1", "PARM2" };

    /**
     * ���o�y����
     * @param  SUB_CPY_ID  String  �����q�O
     * @param  SYS_CODE    String  �t�ΥN��
     * @param  PARAM1      String  �ѼƤ@
     * @param  PARAM2      String  �ѼƤG
     * @return SER_NO      int     �y����
     */
    public int createNextNumber(String SUB_CPY_ID, String SYS_CODE, String PARAM1, String PARAM2) throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        validate(SUB_CPY_ID, SYS_CODE, PARAM1, PARAM2);
        //�H���w���ѼƱq DTEPZ001 �����ͬy���� 
        int SER_NO = -1;
        String[] fieldKeys = { SUB_CPY_ID, SYS_CODE, PARAM1, PARAM2 };

        DataSet ds = getDataSet();

        ds.beginTransaction();
        try {
            SER_NO = NextNumberUtility.getNextNumber("DBEP.DTEPZ001", "SER_NO", fields, fieldKeys, ds);
            ds.endTransaction();
        } catch (Exception e) {
            try {
                ds.rollbackTransaction();
            } catch (DBException e1) {
            }
        }

        if (SER_NO == -1) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0Z001_ERRMSG_001"));//��s�y���Ǹ������ɦ��~
        }
        return SER_NO;

    }

    /**
     * �����o�y����
     * @param SUB_CPY_ID �����q�O
     * @param SYS_CODE �t�ΥN��
     * @param PARAM1 �ѼƤ@
     * @param PARAM2 �ѼƤG
     * @param size ���o�Ӽ�
     * @return
     * @throws ModuleException
     */
    public int[] createNextNumberforBatch(String SUB_CPY_ID, String SYS_CODE, String PARAM1, String PARAM2, int size)
            throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        validate(SUB_CPY_ID, SYS_CODE, PARAM1, PARAM2);
        //�H���w���ѼƱq DTEPZ001 �����;��y���� 
        String[] fieldKeys = { SUB_CPY_ID, SYS_CODE, PARAM1, PARAM2 };

        int[] SER_NOs = null;

        DataSet ds = getDataSet();

        ds.beginTransaction();

        try {
            SER_NOs = NextNumberUtility.getNextNumber("DBEP.DTEPZ001", "SER_NO", fields, fieldKeys, ds, size);
            ds.endTransaction();
        } catch (Exception e) {
            try {
                ds.rollbackTransaction();
            } catch (DBException e1) {
            }
        }

        if (SER_NOs == null || SER_NOs.length == 0 || SER_NOs[0] == -1) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0Z001_ERRMSG_001"));//��s�y���Ǹ������ɦ��~
        }

        return SER_NOs;

    }

    /**
     * �ˬd�ѼƬO�_���T
     * @param SUB_CPY_ID   String  �����q�O
     * @param SYS_CODE     String  �t�ΥN��
     * @param PARAM1       String  �ѼƤ@
     * @param PARAM2       String  �ѼƤG
     */
    public void validate(String SUB_CPY_ID, String SYS_CODE, String PARAM1, String PARAM2) throws ErrorInputException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        } else {
            //���o�����q�O
            Map SUB_CPY_IDMap = FieldOptionList.getName("EP", "SER_NO_SUB_CPY_ID");
            String MapstrSUB_CPY_ID = MapUtils.getString(SUB_CPY_IDMap, SUB_CPY_ID);
            if (StringUtils.isBlank(MapstrSUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_ERRMSG_005", new Object[] { MapstrSUB_CPY_ID })); //�����q�O���~:{0}

            }
        }
        if (StringUtils.isBlank(SYS_CODE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_MSG_002"));//�t�ΥN�����o����

        } else {
            //���o�t�ΥN��
            Map SYS_CODEMap = FieldOptionList.getName("EP", "SER_NO_SYS_CODE");
            //(ex:01:�ץ�s�� �K)
            //�ˮ֨t�ΥN��
            String MapstrSYS_CODE = MapUtils.getString(SYS_CODEMap, SYS_CODE);
            if (StringUtils.isBlank(MapstrSYS_CODE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_ERRMSG_006", new Object[] { MapstrSYS_CODE })); //�t�ΥN�����~:{0}

            }
        }
        if (StringUtils.isBlank(PARAM1) || PARAM1.length() >= 20) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_ERRMSG_003", new Object[] { PARAM1 }));//�ѼƤ@���~:{0}���ץ��ݤp��20

        }
        if (StringUtils.isBlank(PARAM2) || PARAM2.length() >= 20) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_ERRMSG_004", new Object[] { PARAM2 }));//�ѼƤG���~:{0}���ץ��ݤp��20
        }
        if (eie != null) {
            throw eie;
        }

    }

    /**
     *  ���o�s�X�y����
     * @param SUB_CPY_ID  String  �����q�O
     * @param SYS_CODE    String  �t�ΥN��
     * @param PARAM1      String  �ѼƤ@
     * @param PARAM2      String  �ѼƤG
     * @param NEXT_NO     String  �y�����e�s�X
     * @param LENGTH      int     �y��������
     * @return SER_NO  String  
     * @throws ModuleException
     */
    public String createNextNo(String SUB_CPY_ID, String SYS_CODE, String PARAM1, String PARAM2, String NEXT_NO, int LENGTH)
            throws ModuleException {
        if (StringUtils.isBlank(NEXT_NO)) {
            NEXT_NO = "";
        }
        int OLD_SER_NO = this.createNextNumber(SUB_CPY_ID, SYS_CODE, PARAM1, PARAM2);
        return new StringBuffer().append(NEXT_NO).append(STRING.fillZero(String.valueOf(OLD_SER_NO), LENGTH, null)).toString();

    }

    /**
     * ����s�y����
     * @param SUB_CPY_ID  String  �����q�O
     * @param SYS_CODE    String  �t�ΥN��
     * @param PARAM1      String  �ѼƤ@
     * @param PARAM2      String  �ѼƤG
     * @param SER_NO      String  �y����
     */
    public void updateSER_NO(String SUB_CPY_ID, String SYS_CODE, String PARAM1, String PARAM2, String SER_NO) throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        validate(SUB_CPY_ID, SYS_CODE, PARAM1, PARAM2);
        //�ˮ֬y����
        //�Y�����šA�����Ʀr�A���פj��Q�X
        //�h��X���~�T��:���y�����ݬ�10��H�U���Ʀr��;
        if (!NumberUtils.isDigits(SER_NO) || SER_NO.length() > 10) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0Z001_MSG_008"));//�y�����ݬ�10��H�U���Ʀr
        }
        DTEPZ001 Z001VO = new DTEPZ001();
        //��s�y���Ǹ�������DTEPZ001�G
        Z001VO.setSUB_CPY_ID(SUB_CPY_ID);
        Z001VO.setSYS_CODE(SYS_CODE);
        Z001VO.setPARM1(PARAM1);
        Z001VO.setPARM2(PARAM2);
        Z001VO.setSER_NO(Integer.valueOf(SER_NO));

        if (VOTool.findByPK(Z001VO, false) != null) {
            VOTool.update(Z001VO);
        } else {
            //�Y��s�L��ƫh�s�W�@��
            VOTool.insert(Z001VO);

        }
    }

    /**
     * �d�߬y���Ǹ�
     * @param SUB_CPY_ID
     * @param SYS_CODE
     * @param PARAM1
     * @param PARAM2
     * @return
     */
    public int queryNumber(String SUB_CPY_ID, String SYS_CODE, String PARAM1, String PARAM2) throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        validate(SUB_CPY_ID, SYS_CODE, PARAM1, PARAM2);
        DTEPZ001 Z001VO = new DTEPZ001();
        //�y���Ǹ������� DTEPZ001�G
        Z001VO.setSUB_CPY_ID(SUB_CPY_ID);
        Z001VO.setSYS_CODE(SYS_CODE);
        Z001VO.setPARM1(PARAM1);
        Z001VO.setPARM2(PARAM2);
        return VOTool.findByPKWithUR(Z001VO).getSER_NO();

    }

    /**
     * �d�߸g�����Ǹ�
     * @param SUB_CPY_ID
     * @param USER_ID
     * @param ACNT_DATE
     * @param rm
     * @return
     * @throws Exception
     */
    public String getTRN_SER_NO(String SUB_CPY_ID, String USER_ID, String ACNT_DATE, ReturnMessage rm) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(ACNT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_MSG_012"));//�b�餣�o���ŭ�
        }
        if (StringUtils.isBlank(USER_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_MSG_013"));//�ϥΪ�ID���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String TRN_SER_NO;
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {
            TRN_SER_NO = new DK_F0Z002().getSER_NO(USER_ID, ACNT_DATE, rm);

        } else {
            try {
                TRN_SER_NO = String.valueOf(this.createNextNumber(SUB_CPY_ID, "045", USER_ID, ACNT_DATE));
                rm.setReturnCode(ReturnCode.OK);
            } catch (Exception e) {
                log.error("�d�߸g�����Ǹ�����");
                rm.setReturnCode(ReturnCode.ERROR);
                rm.setException(e);
                TRN_SER_NO = null;
            }
        }
        return TRN_SER_NO;
    }

    /* ���:�P�_�����q�O�O�_�X�b */
    /**
     * �d�߶ǲ��帹
     * @param SUB_CPY_ID
     * @param DK_KIND
     * @param DIV_NO
     * @param USER_ID
     * @param SLIP_LOT_NO
     * @param ACNT_DATE
     * @param rm
     * @return
     * @throws Exception
     */
    public String getSLIP_SET_NO(String SUB_CPY_ID, String DK_KIND, String DIV_NO, String USER_ID, String SLIP_LOT_NO, String ACNT_DATE,
            ReturnMessage rm) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(DK_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_MSG_009"));//�Ҳպ������o���ŭ�
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_MSG_010"));//�ǲ���줣�o���ŭ� 
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_MSG_011"));//�ǲ��ո����o���ŭ�
        }
        if (StringUtils.isBlank(ACNT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_MSG_012"));//�b�餣�o���ŭ�
        }
        if (StringUtils.isBlank(USER_ID) && "1".equals(DK_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0Z001_MSG_013"));//�ϥΪ�ID���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String slipSetNo = null;
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {
            DK_F0Z003 theDK_F0Z003 = new DK_F0Z003();
            if ("1".equals(DK_KIND)) {
                slipSetNo = theDK_F0Z003.getSLIP_SET_NO(DIV_NO, USER_ID, SLIP_LOT_NO, ACNT_DATE, rm);
            } else if ("2".equals(DK_KIND)) {
                slipSetNo = theDK_F0Z003.getSLIP_SET_NO2(DIV_NO, SLIP_LOT_NO, ACNT_DATE, rm);
            }
        } else {
            try {
                slipSetNo = String.valueOf(this.createNextNumber(SUB_CPY_ID, SLIP_LOT_NO, DIV_NO, ACNT_DATE));
                rm.setReturnCode(ReturnCode.OK);
            } catch (Exception e) {
                log.error("�d�߶ǲ��帹����", e);
                rm.setReturnCode(ReturnCode.ERROR);
                rm.setException(e);
                slipSetNo = null;
            }
        }
        return slipSetNo;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
