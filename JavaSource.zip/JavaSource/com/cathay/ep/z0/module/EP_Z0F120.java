package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.EmployeeDetail;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.f1.module.EPF1_0102_mod;
import com.cathay.ep.f1.module.EP_F10310;
import com.cathay.ep.vo.DTEPF110;
import com.cathay.ep.vo.DTEPF120;
import com.cathay.ep.vo.DTEPF121;
import com.cathay.ep.vo.DTEPF130;
import com.cathay.ep.vo.DTEPF140;
import com.cathay.ep.vo.DTEPZ003;
import com.cathay.rz.n0.module.RZ_N00100;
import com.cathay.rz.n0.module.RZ_N0Z001;
import com.cathay.rz.vo.DTRZN001;
import com.cathay.rz.vo.DTRZN003;
import com.cathay.rz.vo.DTRZN010;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * DATE Description Author
2014/08/15  Created ����i
 * 2018/03/07  �t�X��ؽվ� ����[
 �@�B  �{���\�෧�n�����G
�ҲզW��    �Ƨѿ����@�Ҳ�
 �Ҳ�ID    EP_F10102
 ���n����    �Ƨѿ����@�Ҳ�
 
 * @author �Ťl��
 *2019/09/24 AllenTsai �W�ǳ����ɵL�k�ѪR�A�վ�ѪR�W��A�N�������Ӽg�J�������R����
 *  1.�վ�h�C��X���ƶ���
 *  2.�W�[�ѪR�Ƶ����
 *  3.���ئ@�Ω�P�W���X(e.g. PE�O�źޡA���P�ؤo�v������)
 *  4.�קK�r��W�L300�r
 */
@SuppressWarnings("unchecked")
public class EP_Z0F120 {
    public static final String ST_400 = "400";

    public static final String ST_410 = "410";

    public static final String ST_411 = "411";

    public static final String ST_412 = "412";

    public static final String ST_420 = "420";

    public static final String ST_440 = "440";

    public static final String ST_441 = "441";

    public static final String ST_450 = "450";

    public static final String ST_451 = "451";

    public static final String ST_452 = "452";

    public static final String ST_460 = "460";

    public static final String ST_470 = "470";

    public static final String ST_480 = "480";

    public static final String ST_485 = "485";

    public static final String ST_490 = "490";

    public static final String ST_499 = "499";

    private static final String SQL_queryF120List_001 = "com.cathay.ep.z0.module.EP_Z0F120.SQL_queryF120List_001";

    private static final String SQL_queryF120List_002 = "com.cathay.ep.z0.module.EP_Z0F120.SQL_queryF120List_002";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0F120.SQL_insert_001";

    private static final String SQL_query_001 = "com.cathay.ep.z0.module.EP_Z0F120.SQL_query_001";

    private static final String SQL_getMaxMEMO_NO_001 = "com.cathay.ep.z0.module.EP_Z0F120.SQL_getMaxMEMO_NO_001";

    private static final Logger log = Logger.getLogger(EP_Z0F120.class);

    /**
     * Ū����µ�ץ�_�Ƨѿ��ɲM��
     * @param F120Vo
     * @return
     * @throws Exception 
     */
    public List<Map> queryF120List(DTEPF120 F120Vo) throws Exception {
        return queryF120List(F120Vo, false, null, false, 0, 0, null);
    }

    /**
     * Ū����µ�ץ�_�Ƨѿ��ɲM��
     * @param F120Vo
     * @return
     * @throws Exception 
     */
    public List<Map> queryF120List(DTEPF120 F120Vo, boolean isReal, ResponseContext resp, boolean isFirstQuery, Integer startWith,
            Integer endWith, UserObject user) throws Exception {
        String APLY_NO = null;
        String SUB_CPY_ID = null;
        if (F120Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_F10102_MSG_001"));//��µ�ץ�_�Ƨѿ��ɤ��i���� 
        } else {
            APLY_NO = F120Vo.getAPLY_NO();
            if (StringUtils.isBlank(APLY_NO)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i����
            }
            SUB_CPY_ID = F120Vo.getSUB_CPY_ID();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        //�H�����q�O�ζǤJ�ѼƬd�߭�µ�ץ�_�Ƨѿ���(DTEPF120)�B��µ�ץ�_�Ƨѿ��h�^�O����(DTEPF121)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (F120Vo.getMEMO_NO() != null) {
            ds.setField("MEMO_NO", F120Vo.getMEMO_NO());
        }

        if (isReal) {
            ds.setFetchRange(startWith, endWith);//�u�����\�� �_����ƦC �]�w
        }

        DBUtil.searchAndRetrieve(ds, SQL_queryF120List_001);
        if (isReal && isFirstQuery) {
            resp.addOutputData("totalOfRecords", ds.getQueryTotalCount()); // ���o-�`����,�u�����\��T�w�ѼƦW��
        }

        List<Map> rtnList = new ArrayList();
        EP_F10310 theEP_F10310 = new EP_F10310();
        PersonnelData pd = new PersonnelData();

        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //��ޥ�
            rtnMap.put("IS_BM_NM", FieldOptionList.getName("EP", "IS_BM_F102", MapUtils.getString(rtnMap, "IS_BM")));
            //�@�~�i��
            setOP_STATUS_NM(rtnMap);
            //�@�~�H��
            String LST_PROC_DIV = MapUtils.getString(rtnMap, "LST_PROC_DIV");
            String LST_PROC_ID = MapUtils.getString(rtnMap, "LST_PROC_ID");
            if (StringUtils.isNotEmpty(LST_PROC_DIV)) {
                if (LST_PROC_DIV.startsWith("EP9")) {
                    Map empMap;
                    try {
                        empMap = theEP_F10310.getEmpMap(LST_PROC_ID, true, SUB_CPY_ID);
                        rtnMap.put("LST_PROC_NM", empMap.get("NAME"));
                        rtnMap.put("LST_PROC_DIV_NM", empMap.get("DIV_SHORT_NAME"));
                    } catch (Exception e) {
                        rtnMap.put("LST_PROC_NM", "�L���H��");
                        rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                    }
                } else {
                    EmployeeDetail emp;
                    try {
                        emp = pd.getByEmployeeID2(LST_PROC_ID);
                        if (emp != null) {
                            rtnMap.put("LST_PROC_NM", emp.getName());
                            rtnMap.put("LST_PROC_DIV_NM", pd.getByEmployeeID(LST_PROC_ID).getDivShortName());
                        } else {
                            rtnMap.put("LST_PROC_NM", "�L���H��");
                            rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                        }
                    } catch (SQLException e) {
                        rtnMap.put("LST_PROC_NM", "�L���H��");
                        rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                    }
                }
            }
            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * Ū����µ�ץ�_�Ƨѿ��ɲM��
     * @param APLY_NO
     * @param MEMO_NO
     * @return
     * @throws ModuleException
     */
    public List<Map> queryF120List(String APLY_NO, String MEMO_NO, String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i���� 
        }
        if (StringUtils.isBlank(MEMO_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_003"));//�Ƨѿ��渹���i���� 
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�H�����q�O�ζǤJ�ѼƬd�߭�µ�ץ�_�Ƨѿ���(DTEPF120)�B��µ�ץ�_�Ƨѿ��h�^�O����(DTEPF121)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("MEMO_NO", MEMO_NO);
        return VOTool.findToMaps(ds, SQL_queryF120List_002);

    }

    /**
     * Ū����µ�ץ�_�Ƨѿ��ɲM��
     * @param APLY_NO
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException
     */
    public List<Map> queryF120List(String APLY_NO, String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i���� 
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�H�����q�O�ζǤJ�ѼƬd�߭�µ�ץ�_�Ƨѿ���(DTEPF120)�B��µ�ץ�_�Ƨѿ��h�^�O����(DTEPF121)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);
        return VOTool.findToMaps(ds, SQL_queryF120List_002);

    }

    /**
     * �s�W��µ�ץ�_�Ƨѿ����
     * @param F120Vo
     * @param user
     * @return MEMO_NO
     * @throws Exception
     */
    public int insert(DTEPF120 F120Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (F120Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_001"));//��µ�ץ�_�Ƨѿ��ɤ��i���� 
        } else {
            if (StringUtils.isBlank(F120Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i����
            }
            SUB_CPY_ID = F120Vo.getSUB_CPY_ID();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (eie != null) {
            throw eie;
        }
        //�s�W��µ�ץ�_�Ƨѿ���DTEPF120�G
        //���o���Ƨѿ��Ǹ����̤j�Ƨѿ��Ǹ�+1
        int MEMO_NO = getMaxMEMO_NO(F120Vo);
        //���o��µ�ץ�򥻸����
        Map DBF110Map = new EP_Z0F110().queryMap(F120Vo.getAPLY_NO(), SUB_CPY_ID);
        String APLY_TP = MapUtils.getString(DBF110Map, "APLY_TP");
        String FLOW_TYPE = "EPF1_0240";
        if (EP_Z0F110.ST_3.equals(APLY_TP)) {
            FLOW_TYPE = "EPF1_0340";
        }

        //�O���f��Ƨѿ����{
        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String AUTH_DESC = "�s�W�Ƨѿ�" + MEMO_NO;
        String strFlowNo = new RZ_N0Z001().startFlow(FLOW_TYPE, AUTH_DESC, AUTH_DESC + "(" + user.getEmpName() + ")", CHG_ID, CHG_DIV_NO);

        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", F120Vo.getAPLY_NO());
        ds.setField("MEMO_NO", MEMO_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("IS_BM", F120Vo.getIS_BM());
        ds.setField("MEMO_MO", F120Vo.getMEMO_MO());
        ds.setField("MEMO_AMT", ObjectUtils.toString(F120Vo.getMEMO_AMT(), "0"));
        //ds.setField("PPL_FILE_NO", F120Vo.getPPL_FILE_NO());
        //ds.setField("MEMO_FILE_NO", F120Vo.getMEMO_FILE_NO());
        ds.setField("PPL_FILE_NO", "");
        ds.setField("MEMO_FILE_NO", "");

        ds.setField("CFM_WORK_MO", F120Vo.getCFM_WORK_MO());
        //ds.setField("MGR_PPL_MO", F120Vo.getMGR_PPL_MO());
        ds.setField("SUBCON_GROUP_ID", F120Vo.getSUBCON_GROUP_ID());
        ds.setField("FLOW_NO", strFlowNo);
        ds.setField("OP_STATUS", ST_410);
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getDivNo());
        ds.setField("LST_PROC_NM", user.getEmpName());
        DBUtil.executeUpdate(ds, SQL_insert_001);

        return MEMO_NO;
    }

    /**
     * �ק��µ�ץ�_�Ƨѿ����
     * @param F120Vo
     * @param user
     * @throws Exception 
     */
    public void update(DTEPF120 F120Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;
        if (F120Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_001"));//��µ�ץ�_�Ƨѿ��ɤ��i���� 
        } else {
            if (StringUtils.isBlank(F120Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i����
            }
            if (F120Vo.getMEMO_NO() == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_003"));//�Ƨѿ��渹���i����
            }
            if (StringUtils.isBlank(F120Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (eie != null) {
            throw eie;
        }
        //�ץ�������ʡA���ܳƧѿ��y�{����
        //�ק��µ�ץ�_�Ƨѿ���DTEPF120
        F120Vo.setLST_PROC_DATE(DATE.currentTime());
        F120Vo.setLST_PROC_DIV(user.getOpUnit());
        F120Vo.setLST_PROC_ID(user.getEmpID());
        F120Vo.setLST_PROC_NM(user.getEmpName());
        VOTool.update(F120Vo);
        //�O���f��Ƨѿ����{
        /*
        //���o��µ�ץ�򥻸����
        Map DBF110Map = new EP_Z0F110().queryMap(F120Vo.getAPLY_NO());
        RZ_N0Z001 theRZ_N0Z001 = new RZ_N0Z001();
        String AUTH_DESC = "�ק�Ƨѿ�" + F120Vo.getMEMO_NO();
        DBF110Map.put("LST_PROC_DATE", DATE.currentTime());
        DBF110Map.put("LST_PROC_ID", user.getEmpID());
        DBF110Map.put("LST_PROC_DIV", user.getOpUnit());

        theRZ_N0Z001.insertLogOnly(VOTool.mapToVO(DTEPF110.class, DBF110Map), AUTH_DESC);*/

    }

    /**
     * �R����µ�ץ�_�Ƨѿ����
     * @param F120Vo
     * @param user
     * @throws ModuleException
     */
    public void delete(DTEPF120 F120Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (F120Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_001"));//��µ�ץ�_�Ƨѿ��ɤ��i���� 
        } else {
            if (StringUtils.isBlank(F120Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i����
            }
            if (F120Vo.getMEMO_NO() == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_003"));//�Ƨѿ��渹���i����
            }
            if (StringUtils.isBlank(F120Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (eie != null) {
            throw eie;
        }
        //�R����µ�ץ�_�Ƨѿ���DTEPF120
        VOTool.delByPK(F120Vo);
        //�O���f��Ƨѿ����{
        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String COMMENT = "�R���Ƨѿ�" + F120Vo.getMEMO_NO();
        new RZ_N0Z001().deleteFlow(F120Vo.getFLOW_NO(), "�R��", COMMENT + "(" + user.getEmpName() + ")", CHG_ID, CHG_DIV_NO);

    }

    /**
     * �ק��µ�ץ�_�Ƨѿ��h�^���
     * @param F120Vo
     * @param user
     * @param BACK_MO
     * @param BACK_TP
     * @throws ModuleException
     */
    public void back(DTEPF120 F120Vo, UserObject user, String BACK_MO, String BACK_OP_STATUS, String APLY_TP) throws ModuleException {
        ErrorInputException eie = null;
        if (F120Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_001"));//��µ�ץ�_�Ƨѿ��ɤ��i���� 
        } else {
            if (StringUtils.isBlank(F120Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i����
            }
            if (F120Vo.getMEMO_NO() == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_003"));//�Ƨѿ��渹���i����
            }
            if (StringUtils.isBlank(F120Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (StringUtils.isBlank(BACK_MO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_005"));//�h�󻡩����i����
        }
        if (StringUtils.isBlank(BACK_OP_STATUS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_006"));//�h��������i����
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (eie != null) {
            throw eie;
        }
        //�ק��µ�ץ�_�Ƨѿ��h�������DTEPF121
        DTEPF121 DTEPF121Vo = new DTEPF121();
        VOTool.copyVOFromTo(VOTool.findByPKWithUR(F120Vo), DTEPF121Vo);
        Timestamp currentTime = DATE.currentTime();
        DTEPF121Vo.setLST_PROC_DATE(currentTime);
        DTEPF121Vo.setBACK_DATE(currentTime);
        DTEPF121Vo.setBACK_DIV(user.getOpUnit());//�h����
        DTEPF121Vo.setBACK_ID(user.getEmpID());//�h��H��
        DTEPF121Vo.setBACK_MO(BACK_MO);//�h�󻡩�  
        DTEPF121Vo.setBACK_TP("-");//�h����� //151123 modified
        DTEPF121Vo.setPRE_OP_STATUS(BACK_OP_STATUS);//�h��e���A //151123 modified
        DTEPF121Vo.setLST_PROC_NM(user.getEmpName());
        VOTool.insert(DTEPF121Vo);
        //�ק��µ�ץ�_�Ƨѿ���DTEPF120
        String AUTH_DESC = "";

        RZ_N00100 theRZ_N00100 = new RZ_N00100();
        //String STATUS_NM;
        String RTN_STATUS_NM;
        if ("2".equals(APLY_TP)) {
            //STATUS_NM = theRZ_N00100.queryStatusNM("EPF1_0240", F120Vo.getOP_STATUS());
            RTN_STATUS_NM = theRZ_N00100.queryStatusNM("EPF1_0240", BACK_OP_STATUS);
        } else {
            //STATUS_NM = theRZ_N00100.queryStatusNM("EPF1_0340", F120Vo.getOP_STATUS());
            RTN_STATUS_NM = theRZ_N00100.queryStatusNM("EPF1_0340", BACK_OP_STATUS);
        }
        AUTH_DESC = AUTH_DESC + "�h�^";
        String COMMENT = new StringBuilder().append("�Ƨѿ�(").append(F120Vo.getMEMO_NO()).append(")�h�^").append(RTN_STATUS_NM).toString();
        /*
        if (EP_Z0F110.ST_1.equals(BACK_TP)) {
            //�D��ñ�ְh�^
            OP_STATUS = ST_410;
            AUTH_DESC = "�D��ñ�ְh�^";
            sb.append("�Ƨѿ�").append(F120Vo.getMEMO_NO()).append("�D��ñ�ְh�^");
        } else if (EP_Z0F110.ST_2.equals(BACK_TP)) {
            //��������h�^(���s���w�t��) 
            OP_STATUS = ST_450;
            AUTH_DESC = "��������h�^";
            sb.append("�Ƨѿ�").append(F120Vo.getMEMO_NO()).append("��������h�^(���s���w�t��)");
        } else if (EP_Z0F110.ST_3.equals(BACK_TP)) {
            //��������h�^(���s�����u�k) 
            OP_STATUS = ST_410;
            AUTH_DESC = "��������h�^";
            sb.append("�Ƨѿ�").append(F120Vo.getMEMO_NO()).append("��������h�^(���s�����u�k)");
            F120Vo.setPPL_FILE_NO("");
            F120Vo.setMEMO_FILE_NO("");
        }
        */
        //String COMMENT = sb.toString() + "(" + user.getEmpName() + ")�A�h�^��]:" + BACK_MO;
        F120Vo.setOP_STATUS(BACK_OP_STATUS);
        F120Vo.setLST_PROC_DIV(user.getOpUnit());
        F120Vo.setLST_PROC_ID(user.getEmpID());
        F120Vo.setLST_PROC_DATE(currentTime);
        VOTool.update(F120Vo);

        //�O���f��Ƨѿ����{
        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        new RZ_N0Z001().assignOPStatus(F120Vo.getFLOW_NO(), AUTH_DESC, COMMENT, BACK_OP_STATUS, CHG_ID, CHG_DIV_NO);

    }

    /**
     *  �ק��µ�ץ�_�Ƨѿ��y�{�h��
     * @param F120Vo
     * @param user
     * @throws Exception
     */
    public void reject(DTEPF120 F120Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;
        if (F120Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_001"));//��µ�ץ�_�Ƨѿ��ɤ��i���� 
        } else {
            if (StringUtils.isBlank(F120Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i����
            }
            if (F120Vo.getMEMO_NO() == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_003"));//�Ƨѿ��渹���i����
            }
            if (StringUtils.isBlank(F120Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (eie != null) {
            throw eie;
        }
        boolean isReject = true;
        //���o��µ�ץ�򥻸����
        Map DBF110Map = new EP_Z0F110().queryMap(F120Vo.getAPLY_NO(), F120Vo.getSUB_CPY_ID());
        String APLY_TP = MapUtils.getString(DBF110Map, "APLY_TP");
        //�ק��µ�ץ�_�Ƨѿ���DTEPF120�y�{�����A�h�^�W�@��
        DTEPF120 DBF120Vo = new DTEPF120();
        DBF120Vo = VOTool.findByPKWithUR(F120Vo);
        String OP_STATUS = DBF120Vo.getOP_STATUS();

        //DTRZN003 voDTRZN003 = getFLOW_TYPE_DATA(APLY_TP, OP_STATUS, EP_Z0F110.ST_2);

        String AUTH_DESC = "";
        String tmpOP_STATUS = "";
        StringBuilder COMMENT = new StringBuilder();

        if (ST_420.equals(OP_STATUS)) {//�e��(�ݽT�{�u�k)
            tmpOP_STATUS = ST_410;
            AUTH_DESC = "�����e��";
            isReject = false;
        } else if (ST_440.equals(OP_STATUS)) {//�T�{�u�k(�ݬ���(�o�]��))
            AUTH_DESC = "�����T�{�u�k";
        } else if (ST_450.equals(OP_STATUS)) {//�o�]�դw����(�ݴ������)
            if (EP_Z0F110.ST_2.equals(APLY_TP)) {
                //2:�@���
                F120Vo.setSUBCON_GROUP_ID("");
                AUTH_DESC = "��������(�o�]��)";
            } else if (EP_Z0F110.ST_3.equals(APLY_TP)) {
                //3:�����
                AUTH_DESC = "�����w�ƬI�u";
            }
        } else if (ST_460.equals(OP_STATUS)) {//�������(�ݽT�{����)
            tmpOP_STATUS = ST_450;
            AUTH_DESC = "�����������";
            isReject = false;
        } else if (ST_470.equals(OP_STATUS)) {//�T�{����(�ݳq���I�u)
            if (EP_Z0F110.ST_2.equals(APLY_TP)) {
                //2:�@���
                AUTH_DESC = "�����T�{����";
            } else if (EP_Z0F110.ST_3.equals(APLY_TP)) {
                //3:�����
                AUTH_DESC = "��������w����B";
            }
        } else if (ST_480.equals(OP_STATUS)) {
            AUTH_DESC = "�����q���I�u";
        }
        COMMENT.append("�Ƨѿ�:").append(F120Vo.getMEMO_NO()).append("�A").append(AUTH_DESC).append("(").append(user.getEmpName()).append(")");

        //�O���f��Ƨѿ����{
        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        if (isReject) {
            new RZ_N0Z001().rejectFlow(F120Vo.getFLOW_NO(), AUTH_DESC, COMMENT.toString(), CHG_ID, CHG_DIV_NO);
        } else {
            new RZ_N0Z001().assignOPStatus(F120Vo.getFLOW_NO(), AUTH_DESC, COMMENT.toString(), tmpOP_STATUS, CHG_ID, CHG_DIV_NO);
        }

        F120Vo.setOP_STATUS(getFLOW_DATA(F120Vo).getOP_STATUS());
        F120Vo.setLST_PROC_DIV(user.getOpUnit());
        F120Vo.setLST_PROC_ID(user.getEmpID());
        F120Vo.setLST_PROC_DATE(DATE.currentTime());
        VOTool.update(F120Vo);
    }

    /**
     * ��µ�ץ�W���ɮ�
     * @param F120Vo
     * @param fileItem
     * @param user
     * @param typ //0:(�e�֪�)�u��sF140||1:(�e�֪�)�u��sF130||2:�Ƨѿ�||3:(�e�֪�,�o�]��)��sF130�PF140
     * @throws Exception 
     */
    public String upload(DTEPF120 F120Vo, FileItem fileItem, UserObject user, String type) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (F120Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_001"));//��µ�ץ�_�Ƨѿ��ɤ��i���� 
        } else {
            if (StringUtils.isBlank(F120Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i����
            }
            if (F120Vo.getMEMO_NO() == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_003"));//�Ƨѿ��渹���i����
            }
            SUB_CPY_ID = F120Vo.getSUB_CPY_ID();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (fileItem == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_007"));//�Ƨѿ��q�l�ɮפ��i����
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (eie != null) {
            throw eie;
        }
        //Ū��������ñ���
        String strfiName = fileItem.getName();
        String[] fisubNamearr = strfiName.split("\\.");
        String[] fiNamearr = fisubNamearr[0].split("\\\\");
        String FILE_TYPE = fisubNamearr[fisubNamearr.length - 1].toUpperCase();

        Timestamp currentTime = DATE.currentTime();
        BigDecimal MEMO_AMT = BigDecimal.ZERO;
        String chkFILE = "";
        log.debug("### upload.type::" + type);
        //0:(�e�֪�)�u��sF140||1:(�e�֪�)�u��sF130||2:�Ƨѿ�||3:(�e�֪�,�o�]��)��sF130�PF140
        if (EP_Z0F110.ST_1.equals(type) || "0".equals(type) || "3".equals(type)) {
            //�ˮֹq�l�ɮ榡�O�_���T�A�e�֪��ˮֹq�l�ɮ׮榡(XLS�AXLSX�榡)
            if (!"XLS".equals(FILE_TYPE) && !"XLSX".equals(FILE_TYPE)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_F10102_MSG_008"));//�ǤJ�Ƨѿ��q�l�ɮװ��ɦW���~
            }
            DTEPF130 DTEPF130VO = new DTEPF130();
            DTEPF130VO.setAPLY_NO(F120Vo.getAPLY_NO());//�ץ�s��
            DTEPF130VO.setMEMO_NO(F120Vo.getMEMO_NO());//�Ƨѿ��渹
            DTEPF130VO.setSUB_CPY_ID(SUB_CPY_ID);//�����q�O
            DTEPF130VO.setLST_PROC_DATE(currentTime);//�@�~�ɶ�
            DTEPF130VO.setLST_PROC_ID(user.getEmpID());//�@�~�H��
            DTEPF130VO.setLST_PROC_DIV(user.getOpUnit());//�@�~���

            Sheet sheet1 = null;

            Map tmpMap = new HashMap();
            if (EP_Z0F110.ST_1.equals(type) || "3".equals(type)) {//����(����)

                List<Map> fileF140List = new ArrayList();
                log.debug("�e�֪�:�s�W(����)");
                //2019/0924 AllenTsai �վ�Coding By Interface �קK���Ƶ{���X
                Workbook wb = null;
                if ("xls".equalsIgnoreCase(FILE_TYPE)) {
                	wb = new HSSFWorkbook(new POIFSFileSystem(fileItem.getInputStream()));
                } else {
                	wb = new XSSFWorkbook(fileItem.getInputStream());
                }
                if(wb==null) {
                	throw new IllegalArgumentException("��J�ɮ׫DExcel�榡");
                }
                int wbCountSheet = wb.getNumberOfSheets();
                int lastSheet = wbCountSheet - 1;
                int proNo = 1;
                for (int i = 0; i < wbCountSheet; i++) {
                    if (i != 0) {
                        sheet1 = wb.getSheetAt(i);
                        List<Map> dataList =this.processExcelData(sheet1, tmpMap, proNo);
                        fileF140List.addAll(dataList);
                    }
                }

                //�M��F140����
                EP_Z0F140 theEP_Z0F140 = new EP_Z0F140();
                DTEPF140 F140Vo = new DTEPF140();
                F140Vo.setAPLY_NO(F120Vo.getAPLY_NO());//�ץ�s��
                F140Vo.setMEMO_NO(F120Vo.getMEMO_NO());//�Ƨѿ��渹
                F140Vo.setSUB_CPY_ID(SUB_CPY_ID);
                try {
                    theEP_Z0F140.delete(F140Vo, user);
                } catch (DataNotFoundException e) {
                    //�d�L��Ƶ������`
                }
                //�s�WF140
                DTEPF140 DTEPF140VO = new DTEPF140();
                int i = 1;
                for (Map fileMap : fileF140List) {
                    DTEPF140VO.setAPLY_NO(F120Vo.getAPLY_NO());//�ץ�s��
                    DTEPF140VO.setMEMO_NO(F120Vo.getMEMO_NO());//�Ƨѿ��渹
                    DTEPF140VO.setSUB_CPY_ID(SUB_CPY_ID);//�����q�O
                    DTEPF140VO.setPRO_NO(MapUtils.getInteger(fileMap, "PRO_NO", 1));
                    DTEPF140VO.setPRT_NO(i);
                    DTEPF140VO.setCNT(MapUtils.getInteger(fileMap, "CNT", 0));
                    //2018-06-21 �վ�g�J���
                    DTEPF140VO.setUNIT(MapUtils.getString(fileMap, "UNIT"));
                    DTEPF140VO.setPRICE(MapUtils.getInteger(fileMap, "PRICE", 0));//���Ƴ��
                    //                    DTEPF140VO.setPRICE(STRING.objToBigDecimal(fileMap.get("PRICE"), BigDecimal.ZERO));
                    DTEPF140VO.setMAT_NM(MapUtils.getString(fileMap, "PROJECT_TP"));
                    DTEPF140VO.setEST_AMT(MapUtils.getInteger(fileMap, "EST_AMT", 0));//���B
                    //                    DTEPF140VO.setEST_AMT(STRING.objToBigDecimal(fileMap.get("EST_AMT"), BigDecimal.ZERO));
                    i++;
                    try {
                        theEP_Z0F140.insert(DTEPF140VO, user);

                    } catch (Exception e) {
                        log.fatal("==========Exception=========", e);
                        chkFILE = "Y";
                    }
                }
            }
            if ("0".equals(type) || "3".equals(type)) {//����(�u�{����)

                log.debug("�e�֪�:�R��>�s�W(�u�{����)");
                //�R����µ�ץ�_�u�{������DTEPF130�H�ץ�s���R��
                new EP_Z0F130().deleteByUpload(DTEPF130VO, user);

                if ("xls".equalsIgnoreCase(FILE_TYPE)) {
                    HSSFWorkbook wb = new HSSFWorkbook(new POIFSFileSystem(fileItem.getInputStream()));
                    sheet1 = wb.getSheetAt(0);
                } else {
                    XSSFWorkbook wb = new XSSFWorkbook(fileItem.getInputStream());
                    sheet1 = wb.getSheetAt(0);
                }
                List<Map> fileF130List = new ArrayList();
                this.processExcelFirstData(fileF130List, sheet1, tmpMap);

                //�s�WF130
                String[] index_WAR_MON = { "�s", "��", "�L", "��", "�v", "��", "��", "�m", "��", "�h" };
                EP_Z0F130 theEP_Z0F130 = new EP_Z0F130();
                for (Map fileMap : fileF130List) {
                    String PROJECT_TP = MapUtils.getString(fileMap, "PROJECT_TP");
                    String WAR_MON = (String) tmpMap.get(PROJECT_TP);
                    fileMap.put("WAR_MON", WAR_MON);
                    int real_WAR_MON = ArrayUtils.indexOf(index_WAR_MON, WAR_MON);
                    DTEPF130VO.setPROJECT_TP(PROJECT_TP);
                    if (real_WAR_MON < 0) {
                        DTEPF130VO.setWAR_MON(BigDecimal.ZERO);
                    } else {
                        DTEPF130VO.setWAR_MON(new BigDecimal(real_WAR_MON));
                    }
                    DTEPF130VO.setCNT(STRING.objToBigDecimal(fileMap.get("CNT"), BigDecimal.ZERO));
                    DTEPF130VO.setUNIT(MapUtils.getString(fileMap, "UNIT"));
                    DTEPF130VO.setPRICE(STRING.objToBigDecimal(fileMap.get("PRICE"), BigDecimal.ZERO));
                    BigDecimal EST_AMT = STRING.objToBigDecimal(fileMap.get("EST_AMT"), BigDecimal.ZERO);
                    MEMO_AMT = MEMO_AMT.add(EST_AMT);
                    DTEPF130VO.setEST_AMT(EST_AMT);
                    DTEPF130VO.setCLR_AMT(EST_AMT);
                    DTEPF130VO.setACT_AMT(EST_AMT);
                    DTEPF130VO.setPR_AMT(EST_AMT);
                    DTEPF130VO.setCNT(STRING.objToBigDecimal(fileMap.get("CNT"), BigDecimal.ZERO));
                    //160129 modified:�w�]�M��Ӻ�
                    DTEPF130VO.setSUP_ID("70577266");
                    try {
                        theEP_Z0F130.insert(DTEPF130VO, user);
                    } catch (Exception e) {
                        chkFILE = "Y";
                    }
                }
            }

        }
        //���o��µ�ץ�_�Ƨѿ���DTEPF120
        DTEPF120 DBF120Vo = VOTool.findByPKWithUR(F120Vo);
        //�ɮפW��
        DTEPZ003 EPZ003VO = new DTEPZ003();
        EPZ003VO.setFILE_NM(fiNamearr[fiNamearr.length - 1]);//�ɮצW��
        EPZ003VO.setFILE_KIND(FILE_TYPE);//�ɮ׺���
        EPZ003VO.setSUB_CPY_ID(SUB_CPY_ID);//�����q�O
        EPZ003VO.setINS_DT(currentTime);//��J���
        EPZ003VO.setINS_ID(user.getEmpID()); //��J�H��
        EPZ003VO.setINS_DIVNO(user.getOpUnit());//��J���

        if ((EP_Z0F110.ST_1.equals(type) || "0".equals(type) || "3".equals(type)) && StringUtils.isBlank(DBF120Vo.getPPL_FILE_NO())) {
            String FILE_NO = new EP_Z00010().insert(EPZ003VO, fileItem, user); //�W�ǧe�֪��ɮ�
            //DBF120Vo.setMEMO_AMT(MEMO_AMT);
            DBF120Vo.setPPL_FILE_NO(FILE_NO);//�e�֪��ɮ׽s��
        } else if ((EP_Z0F110.ST_1.equals(type) || "0".equals(type) || "3".equals(type))
                && StringUtils.isNotBlank(DBF120Vo.getPPL_FILE_NO())) {
            EP_Z0Z003 z003Mod = new EP_Z0Z003();
            //���ɮ׽s���A��s�e�֪�
            z003Mod.updateByFileNo(DBF120Vo.getPPL_FILE_NO(), EPZ003VO, user, fileItem);
            //            
            //            
            //            EPZ003VO.setFILE_VER(1);
            //            //DBF120Vo.setMEMO_AMT(MEMO_AMT);
            //            Map map = new EP_Z00010().queryList(VOTool.voToMap(EPZ003VO)).get(0);
            //            EPZ003VO.setFILE_ID(MapUtils.getString(map, "FILE_ID"));
            //            new EP_Z00010().update(EPZ003VO, "N", fileItem); //��s�e�֪��ɮ�
        } else if (EP_Z0F110.ST_2.equals(type) && StringUtils.isBlank(DBF120Vo.getMEMO_FILE_NO())) {
            String FILE_NO = new EP_Z00010().insert(EPZ003VO, fileItem, user); //�W�ǳƧѿ��ɮ�
            DBF120Vo.setMEMO_FILE_NO(FILE_NO);//�Ƨѿ��ɮ׽s��
        } else if (EP_Z0F110.ST_2.equals(type) && StringUtils.isNotBlank(DBF120Vo.getMEMO_FILE_NO())) {
            EPZ003VO.setFILE_NO(DBF120Vo.getMEMO_FILE_NO());
            new EP_Z00010().update(EPZ003VO, "N", fileItem, user); //��s�Ƨѿ��ɮ�
        }
        //�ק��µ�ץ�_�Ƨѿ���DTEPF120�ɮ׽s��
        DBF120Vo.setLST_PROC_DIV(user.getOpUnit());
        DBF120Vo.setLST_PROC_ID(user.getEmpID());
        DBF120Vo.setLST_PROC_DATE(DATE.currentTime());
        VOTool.update(DBF120Vo);
        return chkFILE;
        /*
        //�O���f��Ƨѿ����{
        Map DBF110Map = new EP_Z0F110().queryMap(F120Vo.getAPLY_NO());
        DBF110Map.put("LST_PROC_DATE", currentTime);//�@�~�ɶ�
        DBF110Map.put("LST_PROC_ID", user.getEmpID()); //�@�~�H��
        DBF110Map.put("LST_PROC_DIV", user.getOpUnit());//�@�~���
        StringBuilder sb = new StringBuilder();
        if (EP_Z0F110.ST_1.equals(type)) {
            sb.append("�Ƨѿ�").append("�e�֪��ɮפW��");//
        } else if (EP_Z0F110.ST_2.equals(type)) {
            sb.append("�Ƨѿ�").append("�Ƨѿ��ɮפW��");//
        }
        new RZ_N0Z001().insertLogOnly(VOTool.mapToVO(DTEPF110.class, DBF110Map), sb.toString());*/
    }

    /**
     * �ק��µ�ץ�_�Ƨѿ��y�{�i��
     * @param F120Vo
     * @param user
     * @throws Exception
     */
    public void approve(DTEPF120 F120Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (F120Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_001"));//��µ�ץ�_�Ƨѿ��ɤ��i���� 
        } else {
            if (StringUtils.isBlank(F120Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i����
            }
            if (F120Vo.getMEMO_NO() == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_003"));//�Ƨѿ��渹���i����
            }
            SUB_CPY_ID = F120Vo.getSUB_CPY_ID();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (eie != null) {
            throw eie;
        }
        //���o��µ�ץ�򥻸����
        Map DBF110Map = new EP_Z0F110().queryMap(F120Vo.getAPLY_NO(), SUB_CPY_ID);
        String APLY_TP = MapUtils.getString(DBF110Map, "APLY_TP");
        //�ק��µ�ץ�_�Ƨѿ���DTEPF120�y�{�i��
        DTEPF120 DBF120Vo = new DTEPF120();
        DBF120Vo = VOTool.findByPKWithUR(F120Vo);
        String SUBCON_GROUP_ID = F120Vo.getSUBCON_GROUP_ID();
        String SUB_CON_GRP_NM = null;
        if (StringUtils.isNotBlank(SUBCON_GROUP_ID)) {
            SUB_CON_GRP_NM = (String) new EP_F10310().getEmpMap(SUBCON_GROUP_ID, true, SUB_CPY_ID).get("NAME");
        }

        String OLD_OP_STATUS = DBF120Vo.getOP_STATUS();

        DTRZN003 voDTRZN003 = getFLOW_TYPE_DATA(APLY_TP, OLD_OP_STATUS, EP_Z0F110.ST_1);

        String AUTH_DESC = voDTRZN003.getAUTH_DESC();
        StringBuilder COMMENT = new StringBuilder();
        COMMENT.append("�Ƨѿ�:").append(F120Vo.getMEMO_NO()).append("�A").append(AUTH_DESC).append("(").append(user.getEmpName()).append(")");

        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }

        RZ_N0Z001 theRZ_N0Z001 = new RZ_N0Z001();
        theRZ_N0Z001.approveFlow(F120Vo.getFLOW_NO(), AUTH_DESC, COMMENT.toString(), CHG_ID, CHG_DIV_NO);

        //�ק��µ�ץ�_�Ƨѿ���DTEPF120�y�{�����A�h�^�W�@��
        Timestamp currentTime = DATE.currentTime();

        DTRZN010 n010VO = this.getFLOW_DATA(F120Vo);
        String n010STS = n010VO.getOP_STATUS();
        F120Vo.setOP_STATUS(n010STS);
        F120Vo.setLST_PROC_DIV(user.getOpUnit());
        F120Vo.setLST_PROC_ID(user.getEmpID());
        F120Vo.setLST_PROC_DATE(currentTime);
        F120Vo.setLST_PROC_NM(user.getEmpName());
        //�]�w�o�]�դH��
        if ("440".equals(OLD_OP_STATUS)) {
            F120Vo.setSUBCON_GROUP_ID(SUBCON_GROUP_ID);
            F120Vo.setSUBCON_GROUP_NM(SUB_CON_GRP_NM);
        }

        //�]�w�q���I�u����@�P����q���I�u���
        Date INFM_CONS_DATE = F120Vo.getINFM_CONS_DATE();
        if ("2".equals(APLY_TP)) {
            if ("476".equals(n010STS) && INFM_CONS_DATE == null) {
                F120Vo.setINFM_CONS_DATE(DATE.timestampToDate(currentTime));//�q���I�u���
            }
        } else if ("3".equals(APLY_TP)) {
            if ("472".equals(n010STS) && F120Vo.getPRE_CONS_DATE() == null) {//����I�u�~�D�q��
                F120Vo.setPRE_CONS_DATE(DATE.timestampToDate(currentTime));//����I�u�q�����
            } else if ("476".equals(n010STS) && INFM_CONS_DATE == null) {//�I�u�~�D�q��
                F120Vo.setINFM_CONS_DATE(DATE.timestampToDate(currentTime));//�q���I�u���
            }
        }

        VOTool.update(F120Vo);

        try {
            DTEPF130 F130 = new DTEPF130();
            F130.setAPLY_NO(F120Vo.getAPLY_NO());
            F130.setMEMO_NO(F120Vo.getMEMO_NO());
            F130.setSUB_CPY_ID(SUB_CPY_ID);
            String userID = user.getEmpID();
            String userOpUnit = user.getOpUnit();
            List<Map> rtnF130List = new EP_Z0F130().queryF130List(F130);
            for (Map rtnMap : rtnF130List) {
                F130 = VOTool.mapToVO(DTEPF130.class, rtnMap);
                F130.setLST_PROC_DATE(currentTime);
                F130.setLST_PROC_ID(userID);
                F130.setLST_PROC_DIV(userOpUnit);
                VOTool.update(F130);
            }
        } catch (DataNotFoundException dnfe) {
            //�d�L��Ƶ������`
            log.error("�d�L��Ƶ������`", dnfe);
        }
    }

    /**
     * ���P��µ�ץ�_�Ƨѿ����
     * @param F120Vo
     * @param user
     * @throws ModuleException
     */
    public void cancel(DTEPF120 F120Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (F120Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_001"));//��µ�ץ�_�Ƨѿ��ɤ��i���� 
        } else {
            if (StringUtils.isBlank(F120Vo.getAPLY_NO())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_002"));//�ץ�s�����i����
            }
            if (StringUtils.isBlank(F120Vo.getSUB_CPY_ID())) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
            if (F120Vo.getMEMO_NO() == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_003"));//�Ƨѿ��渹���i����
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        if (eie != null) {
            throw eie;
        }

        //�O���f��Ƨѿ����{
        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }

        String COMMENT = "�P�׳Ƨѿ�" + F120Vo.getMEMO_NO() + "(" + user.getEmpName() + ")";
        new RZ_N0Z001().assignOPStatus(F120Vo.getFLOW_NO(), "�P��", COMMENT, ST_499, CHG_ID, CHG_DIV_NO);

        //�ק��µ�ץ�_�Ƨѿ���DTEPF120
        F120Vo.setOP_STATUS(ST_499);
        F120Vo.setLST_PROC_DIV(user.getOpUnit());
        F120Vo.setLST_PROC_ID(user.getEmpID());
        F120Vo.setLST_PROC_DATE(DATE.currentTime());
        F120Vo.setLST_PROC_NM(user.getEmpName());
        VOTool.update(F120Vo);
    }

    /**
     * �d�߫ݿ��µ�ץ�
     * @param F110Vo
     * @param User
     * @return
     * @throws Exception 
     */
    public List<Map> query(DTEPF110 F110Vo, UserObject user, String DATE_S, String DATE_E, String TODO_STATUS) throws Exception {
        ErrorInputException eie = null;

        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10102_MSG_004"));//�ǤJ�ϥΪ̸�T���i����! 
        }
        String SUB_CPY_ID = F110Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�H�����q�O�ζǤJ�ѼƬd�߭�µ�ץ�_�Ƨѿ���(DTEPF120)�B��µ�ץ�_�Ƨѿ��h�^�O����(DTEPF121)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //ds.setField("APLY_TP", F110Vo.getAPLY_TP());
        setFieldIfExist(ds, F110Vo.getAPLY_TP(), "APLY_TP");
        setFieldIfExist(ds, F110Vo.getBLD_CD(), "BLD_CD");
        //ds.setField("EMPID", user.getEmpID());

        // Map f110Map = VOTool.voToMap(F110Vo);
        String roleTP = this.getRoleTp(user, SUB_CPY_ID);
        log.debug("### roleTP:" + roleTP);
        //���o��µ�ץ�ݿ�i�ת��A
        String F110_TODO_STS = FieldOptionList.getName("EP", "F0400_TODO_STS", "F110_" + roleTP);
        String[] F110_TODO_STS_LIST;
        if (StringUtils.isNotBlank(F110_TODO_STS)) {
            F110_TODO_STS_LIST = F110_TODO_STS.split("\\|");
        } else {
            F110_TODO_STS_LIST = new String[] { "100" };
        }
        //���o�Ƨѿ��ݿ�i�ת��A
        String F120_TODO_STS = FieldOptionList.getName("EP", "F0400_TODO_STS", "F120_" + roleTP);
        String[] F120_TODO_STS_LIST;
        if (StringUtils.isNotBlank(F120_TODO_STS)) {
            F120_TODO_STS_LIST = F120_TODO_STS.split("\\|");
        } else {
            F120_TODO_STS_LIST = new String[] { "410" };
        }

        if (!"I".equals(roleTP)) {
            ds.setFieldValues("F110_TODO_STS_LIST", F110_TODO_STS_LIST);
            ds.setFieldValues("F120_TODO_STS_LIST", F120_TODO_STS_LIST);
        }

        //�{���޲z�H���A�i����ҤU�N�z��J�ץ�A���L�o���
        if ("1".equals(roleTP)) {
            ds.setField("INPUT_DIV_NO", user.getOpUnit());
        }
        //��µ��
        if ("3".equals(roleTP)) {
            ds.setField("FIX_DIV_ID", user.getEmpID());
        }
        //��µ��
        if ("4".equals(roleTP)) {
            ds.setField("FIX_GROUP_ID", user.getEmpID());
        }
        if ("8".equals(roleTP)) {
            ds.setField("SUBCON_GROUP_ID", user.getEmpID());
        }

        if (StringUtils.isNotBlank(TODO_STATUS)) {
            ds.setField("OP_STATUS", TODO_STATUS);
        } else {
            if (StringUtils.isNotBlank(DATE_S)) {
                ds.setField("DATE_S", DATE_S);
                ds.setField("DATE_E", DATE_E);
            }
        }

        DBUtil.searchAndRetrieve(ds, SQL_query_001);
        List<Map> rtnList = new ArrayList();
        EPF1_0102_mod theEPF1_0102_mod = new EPF1_0102_mod();

        boolean isFIX_DIV_ASSIGN = ("3".equals(roleTP) && theEPF1_0102_mod.isItSuperRole(FieldOptionList.getName("EP", "EP_ROLES",
            "FIX_DIV_ROLE"), user));//"RLEP015"��µ�쬣��
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            log.debug("rtnMap:" + rtnMap);

            if ("3".equals(roleTP) && !isFIX_DIV_ASSIGN && StringUtils.isBlank(MapUtils.getString(rtnMap, "FIX_DIV_ID"))) {
                log.debug("��µ��g��A�Y�D��µ����L�o������ץ�");
                continue;//�D��µ����L�o������ץ�
            }

            //�ư��D�{���H�����ץ�A�i����ҤU�N�z��J�ץ�
            if ("1".equals(roleTP)) {

                if (!theEPF1_0102_mod.isInputUser(rtnMap, user)) {
                    continue;
                }
            }

            //�ץ����
            rtnMap.put("APLY_TP_NM", FieldOptionList.getName("EP", "APLY_TP_F101", MapUtils.getString(rtnMap, "APLY_TP")));
            //�ϥΪ��p����
            rtnMap.put("USE_TP_NM", FieldOptionList.getName("EP", "USE_TP_F101", MapUtils.getString(rtnMap, "USE_TP")));
            //�@�~�i��
            setOP_STATUS_NM(rtnMap);

            rtnList.add(rtnMap);
        }
        if (rtnList.size() == 0) {
            throw new DataNotFoundException("�d�L�ݿ�M��");
        }
        return rtnList;
    }

    /**
     * ���o�Ƨѿ��h�^���d�U�Կ��
     * @param APLY_TP 2:�@���;3:�����
     * @param OP_STATUS �Ƨѿ����d
     * @return �h�^�y�{���d�M��
     * @throws ModuleException 
     */
    public List<Map> getBackStatus(String APLY_TP, String OP_STATUS, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_TP)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F160_MSG_004"));//�ǤJ�ץ�������o���ŭ�!
        }
        if (StringUtils.isBlank(OP_STATUS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F120_ERRMSG_001"));//�Ƨѿ����A���i����!
        }
        if (eie != null) {
            throw eie;
        }

        //        RZ_N00300 theRZ_N00300 = new RZ_N00300();
        DTRZN001 vo = new DTRZN001();
        //        List<DTRZN003> N003list;
        if ("2".equals(APLY_TP)) {
            //            N003list = theRZ_N00300.queryN003("EPF1_0240");//�@��I�u�Ƨѿ��y�{
            vo.setFLOW_TYPE("EPF1_0240");
        } else {
            //            N003list = theRZ_N00300.queryN003("EPF1_0340");//����I�u�Ƨѿ��y�{
            vo.setFLOW_TYPE("EPF1_0340");
        }
        List<DTRZN001> n001List = new RZ_N00100().queryDTRZN001(vo);

        boolean isNotFixDiv = !user.getRoles().containsKey("RLEP014");//�D��µ��H��>>�h�^���Alist�L�o����µ�쪬�A

        //�v���P�_�A�C�X�f�媬�A�b�ץ󪬺A���e��
        List<Map> rtnList = new ArrayList<Map>();
        //        int OP_STATUS_int = MapUtils.getIntValue(OpStatusSerNo, OP_STATUS);
        Map opStats_NotFixDiv = FieldOptionList.getFieldOptions("EP", "OP_STATUS_NOT_FIXDIV_F120");
        BigDecimal chkSerNo = BigDecimal.ZERO;
        for (DTRZN001 n001 : n001List) {
            if (n001.getOP_STATUS().equals(OP_STATUS)) {
                chkSerNo = n001.getSER_NO();
                break;
            }
        }
        for (DTRZN001 n001 : n001List) {
            if (n001.getSER_NO().equals(BigDecimal.ZERO)) {
                continue;
            }

            //�D��µ��A��ܯS�w���A
            if ((isNotFixDiv && opStats_NotFixDiv.containsKey(n001.getOP_STATUS())) || !isNotFixDiv) {
                if (n001.getSER_NO().compareTo(chkSerNo) < 0) {
                    Map<String, String> rtnMap = new HashMap<String, String>();
                    rtnMap.put("BACK_OP_STATUS", n001.getOP_STATUS());
                    rtnMap.put("BACK_STATUS_NM", n001.getOP_STATUS_NM());
                    rtnList.add(rtnMap);
                }
            }
        }

        return rtnList;
    }

    public Map getOpStatusSerNo(List<DTRZN001> N001list) {
        Map rtnMap = new HashMap();
        for (DTRZN001 N001 : N001list) {
            rtnMap.put(N001.getOP_STATUS(), N001.getSER_NO());
        }
        return rtnMap;
    }

    /**
     * ���o�@�~�i�פ���
     * @param rtnMap
     */
    public void setOP_STATUS_NM(Map rtnMap) {
        String APLY_TP = MapUtils.getString(rtnMap, "APLY_TP");
        if (EP_Z0F110.ST_1.equals(APLY_TP)) {
            //�s�P�ץ�
            rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS_F501", MapUtils.getString(rtnMap, "OP_STATUS")));
        } else {
            //�@��Υ���
            String OP_STATUS = MapUtils.getString(rtnMap, "OP_STATUS");
            String OP_STATUS_MEMO = MapUtils.getString(rtnMap, "OP_STATUS_MEMO");
            if (ST_400.equals(OP_STATUS) && StringUtils.isNotBlank(OP_STATUS_MEMO)) {//�Ƨѿ����A
                if (EP_Z0F120.ST_490.equals(OP_STATUS_MEMO)) {
                    setOP_STATIS_NM_BY_F130(rtnMap);//�ݧ��u
                } else {
                    if (EP_Z0F110.ST_2.equals(APLY_TP)) {
                        //�@��Ƨѿ�
                        rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS_F504", MapUtils.getString(rtnMap,
                            "OP_STATUS_MEMO")));
                    } else if (EP_Z0F110.ST_3.equals(APLY_TP)) {
                        //����Ƨѿ�
                        rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS_F503", MapUtils.getString(rtnMap,
                            "OP_STATUS_MEMO")));
                    }
                }
            } else {
                //�@��Υ���ץ�
                rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS_F502", OP_STATUS));
            }
        }

        String PRE_OP_STATUS = MapUtils.getString(rtnMap, "PRE_OP_STATUS");
        if (StringUtils.isNotBlank(PRE_OP_STATUS)) {//�h��e���A
            if (EP_Z0F110.ST_2.equals(APLY_TP)) {
                //�@��Ƨѿ�
                rtnMap
                        .put("PRE_OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS_F504", MapUtils
                                .getString(rtnMap, "PRE_OP_STATUS")));
            } else if (EP_Z0F110.ST_3.equals(APLY_TP)) {
                //����Ƨѿ�
                rtnMap
                        .put("PRE_OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS_F503", MapUtils
                                .getString(rtnMap, "PRE_OP_STATUS")));
            }
        }
    }

    /**
     * ���o�@�~�i�פ���
     * @param rtnMap
     */
    private void setOP_STATIS_NM_BY_F130(Map rtnMap) {
        String APLY_NO = MapUtils.getString(rtnMap, "APLY_NO");
        String MEMO_NO = MapUtils.getString(rtnMap, "MEMO_NO");
        String SUB_CPY_ID = MapUtils.getString(rtnMap, "SUB_CPY_ID");
        DTEPF130 F130Vo = new DTEPF130();
        F130Vo.setAPLY_NO(APLY_NO);
        F130Vo.setSUB_CPY_ID(SUB_CPY_ID);
        F130Vo.setMEMO_NO(NumberUtils.createInteger(MEMO_NO));
        boolean isFinal = true;
        try {

            List<Map> mapList = new EP_Z0F130().queryF130List(F130Vo);
            for (Map map : mapList) {
                String FINAL_DATE = MapUtils.getString(map, "FINAL_DATE");
                //���u(400:�ݽT�{���u+490:�w�w�ƬI�u)
                if (StringUtils.isBlank(FINAL_DATE)) {
                    //�@��Ƨѿ��B����Ƨѿ�
                    isFinal = false;
                }
            }
        } catch (Exception e) {
            log.fatal("", e);
        }
        if (isFinal) {
            rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS_F504", "492"));
        } else {
            rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS_F504", "491"));
        }
    }

    /**
     * Ū��EXCEL ���e  FOR ����
     * @param sheet1
     * @param tmpMap
     * @return
     * @throws ModuleException 
     * 2019/09/24 AllenTsai �վ�ѪR�޿�A�ѪR������Excel�� 
     */
    public List<Map> processExcelData( Sheet sheet1, Map tmpMap, int proNo) throws ModuleException {
    	List<Map> dataList = new ArrayList<Map> ();

        //int ht = 0;
        //int tempht = 1;
        boolean tempboolean = false;
        boolean tempboolean2 = false;
        //�P�_����
        boolean commentFlag = false;
        //�P�_�s��h�C���ƶ���
        boolean continueItemFlag = false;
        int chkStop = 0;
        //List<Map> rtnList = new ArrayList();
        int iAmtCol = 5;
        int iColMemo = 7;
        String itemPrefix = "";        
        log.debug("################ Rows:"+ sheet1.getPhysicalNumberOfRows());
        //2019/09/24 AllenTsai �վ㶵���Ǹ��� 3�A�קK�榡 
        for (int i = 3; i < sheet1.getPhysicalNumberOfRows(); i++) {//Row(���L���Y)
            if (tempboolean2) {
                break;
            }

            Row row = sheet1.getRow(i);
            //2019/09/24 AllenTsai �קK �X���x�s�� Row �^�� Null, �קKNullPointException 
            if(row ==null) {
            	log.debug(">>>>>> No Row["+i+"]  Continue");
            	continue;
            }
            short cellnum = row.getLastCellNum();
            String tmpStr;
            StringBuilder tmpSB = new StringBuilder();

            //String tmpStr2;
            //String tmpStr3;
            String tmpStr4;
            String tmpStr5;
            String tmpStr6;
            String tmpStr7;
            String tmpStr8;
            String chkStr;
            
            String tmpStr9;
            /*if (i == 10) { ���ˬd�~�D�O�_������H��

                Cell tmpcell = row.getCell(5);

                tmpcell.setCellType(Cell.CELL_TYPE_STRING); // ��������নString
                String tmpBLD_OWER = tmpcell.getStringCellValue();
                if (!tmpBLD_OWER.equals("����H��")) {
                    throw new ModuleException(MessageUtil.getMessage("EP_F10102_MSG_009"));//�нT�{�~�D
                }
            }*/
            if (!tempboolean) {
                /*for (int j = 0; j < cellnum; j++) {//for ��
                    Cell cell = row.getCell(j);
                    if (cell != null) {
                        try {
                            cell.setCellType(Cell.CELL_TYPE_STRING); // ��������নString
                            tmpStr = cell.getStringCellValue();
                        } catch (NullPointerException e) {
                            throw e;
                        }
                    } else {//�Y�L�Ȭ���
                        tmpStr = "";
                    }
                    if ("����".equals(tmpStr)) {
                        tempboolean = true;
                        break;
                    } //else
                }*/

                Cell cell = row.getCell(0);
                if (cell != null) {
                    try {
                        cell.setCellType(Cell.CELL_TYPE_STRING); // ��������নString
                        tmpStr = cell.getStringCellValue();
                    } catch (NullPointerException e) {
                        throw e;
                    }
                } else {//�Y�L�Ȭ���
                    tmpStr = "";
                }

                if ("����".equals(tmpStr)) {
                	//2019/09/24 AllenTsai �W�[�Ƶ����ѪR�A���o�W��P�t�Ӹ�T 
                	for(int h=5;h<7;h++) {
                		String head = getCellValue(row.getCell(h));
                		head =StringUtils.replace(head, " ", "");
                		head =StringUtils.replace(head, "\t", "");
                		head =StringUtils.replace(head, "�@", "");
                		if(head.equals("�Ƶ�")){
                			iColMemo = h;
                			break;
                	    }
                	}
                    tempboolean = true;
                } //else

            } else {

                Map rntMap = new HashMap();
                Cell cellj = row.getCell(0);//����
                Cell cell4 = row.getCell(1);//���ƤΤu�{����                                                                                                                                
                Cell cell5 = row.getCell(2); //���
                Cell cell6 = row.getCell(3); //�ƶq 
                Cell cell7 = row.getCell(4); //���           
                Cell cell8 = row.getCell(5); //���B
                Cell cell9 = row.getCell(iColMemo); //�Ƶ�

                chkStr = this.getCellValue(cellj);
                tmpStr4 = this.getCellValue(cell4);
                tmpStr5 = this.getCellValue(cell5);
                tmpStr6 = this.getCellValue(cell6);
                tmpStr7 = this.getCellValue(cell7);
                tmpStr8 = this.getCellValue(cell8);
                tmpStr9 = this.getCellValue(cell9);
              //2019/09/24 AllenTsai �W�[�X�֦h�C���X�A�ư�������� 
                if(chkStr.indexOf("��")>=0 || chkStr.indexOf("����")>=0 ) {
                	//�ѪR����ѡA�ѪRExcel �۰�Sheet
                    commentFlag = true;
                    continue;
                } else if (StringUtils.isBlank(chkStr) && StringUtils.isBlank(tmpStr4) && StringUtils.isBlank(tmpStr5)
                        && StringUtils.isBlank(tmpStr6) && StringUtils.isBlank(tmpStr7) && StringUtils.isBlank(tmpStr8)) {//�Y�����欰�ūh��
                    chkStop++;
                    continueItemFlag = false;
                    if (chkStop == 20) {//�s��ťդQ�C ���U�@��SHEET
                        tempboolean2 = true;
                        tempboolean = false;
                        break;
                    }

                } else {
                    tempboolean2 = false;
                    tempboolean = true;
                    //2019/09/24 ���ťզ�A���_�s��h�C�B�z
                    chkStop = 0;
                	if(StringUtils.isNotBlank(chkStr) && StringUtils.isNotBlank(tmpStr4) && NumberUtils.isNumber(chkStr)){
                		itemPrefix = 	tmpStr4;               		    
               	    } 

                    if (StringUtils.isNotBlank(tmpStr4)
                    		&&(StringUtils.isNotBlank(chkStr) || StringUtils.isNotBlank(tmpStr5))
                            && ( (StringUtils.isNotBlank(tmpStr7) && STRING.isNumeric(tmpStr7)) 
                            		|| (StringUtils.isNotBlank(tmpStr8) && STRING.isNumeric(tmpStr8)))) {//���,���B�����ťB�����Ʀr
                    	if(StringUtils.isNotBlank(chkStr) && StringUtils.isNotBlank(tmpStr4) && !NumberUtils.isNumber(chkStr)){
                    		tmpStr4 = addItemPrefix(tmpSB, itemPrefix, tmpStr4);            		    
                   	    } 
                    	continueItemFlag = true;
                    	commentFlag = false;
                    	tmpStr4 = addMemoToMatName(tmpSB, tmpStr4, tmpStr9);
                        rntMap.put("PROJECT_TP", tmpStr4);
                        rntMap.put("UNIT", tmpStr5);
                        rntMap.put("PRO_NO", proNo);
                        rntMap.put("CNT", tmpStr6);
                        rntMap.put("PRICE", tmpStr7);
                        rntMap.put("EST_AMT", tmpStr8);

                        dataList.add(rntMap);
                    } else if(continueItemFlag && StringUtils.isBlank(chkStr) && StringUtils.isNotBlank(tmpStr4)) {
                    	//2019/09/24 AllenTsai �X�֦h�C��X���ƶ��ئW�١A�ư��p�p���A�P�_
                    	String tmpStr4Chk =StringUtils.replace(tmpStr4, " ", ""); 
                    	if(tmpStr4Chk.indexOf("�p�p")<0 && tmpStr4Chk.indexOf("�`�p")<0 && tmpStr4Chk.indexOf("�X�p")<0) {
                    		if(!commentFlag) {
                        		if(dataList.size()>0) {
                            		Map dataMap = dataList.get(dataList.size()-1);
                                	String projectTp = MapUtils.getString(dataMap, "PROJECT_TP");
                                	tmpStr4 = addMemoToMatName(tmpSB, tmpStr4, tmpStr9);
                                	tmpSB.setLength(0);                            	
                                	tmpSB.append(projectTp).append(" ").append(tmpStr4);
                                	projectTp = tmpSB.toString();
                                	//2019/10/05 AllenTsai �קK���׹L�� �̦h300�r
                                	projectTp =  StringUtils.abbreviate(projectTp, 300);
                                	
                                	tmpSB.setLength(0);
                                	dataMap.put("PROJECT_TP", projectTp);
                        		}
                    		}
                    	}
                    } 
                }

            }

        }

        return dataList;
    }

	//2019/09/24 AllenTsai �N�Ƶ�����X����ƶ���
    private String addMemoToMatName(StringBuilder tmpSB, String tmpStr4, String tmpStr9) {
		if(StringUtils.isNotEmpty(tmpStr9)) {
			tmpSB.setLength(0);
			tmpSB.append(tmpStr4).append("(").append(tmpStr9).append(")");
			tmpStr4 = tmpSB.toString();
			tmpSB.setLength(0);
		}
		return tmpStr4;
	}
    //
    private String addItemPrefix(StringBuilder tmpSB, String itemPrefix, String tmpStr4) {
    	String itemName = tmpStr4;
		if(!tmpStr4.startsWith(itemPrefix)) {
			tmpSB.setLength(0);
			tmpSB.append(itemPrefix).append(" ").append(tmpStr4);
			itemName = tmpSB.toString();
			tmpSB.setLength(0);
		}
		return itemName;
	}    

    private String getCellValue(Cell cellj) {
        try {
            if (cellj != null) {
                cellj.setCellType(Cell.CELL_TYPE_STRING); // ��������নString
                return cellj.getStringCellValue();
            }
        } catch (Exception e) {
            return "";
        }
        return "";
    }

    /**
     * Ū��EXCEL ���e  FOR ����
     * @param sheet1
     * @param tmpMap
     * @return
     * @throws ModuleException 
     */
    private List<Map> processExcelFirstData(List<Map> fileList, Sheet sheet1, Map tmpMap) throws ModuleException {

        int ht = 0;
        int tempht = 1;
        boolean tempboolean = false;
        boolean tempboolean2 = false;
        int chkStop = 0;
        //List<Map> rtnList = new ArrayList();
        for (int i = 6; i < sheet1.getPhysicalNumberOfRows(); i++) {//Row(���L���Y)
            if (tempboolean2) {
                break;
            }

            Row row = sheet1.getRow(i);
            short cellnum = row.getLastCellNum();
            String tmpStr;

            String tmpStr2;
            String tmpStr3;
            String tmpStr4;
            String tmpStr5;
            String tmpStr6;
            String tmpStr7;
            String tmpStr8;
            String chkStr;
            if (i == 10) {

                Cell tmpcell = row.getCell(5);

                tmpcell.setCellType(Cell.CELL_TYPE_STRING); // ��������নString
                String tmpBLD_OWER = tmpcell.getStringCellValue();
                if (!tmpBLD_OWER.equals("����H��")) {
                    throw new ModuleException(MessageUtil.getMessage("EP_F10102_MSG_009"));//�нT�{�~�D
                }
            }
            if (!tempboolean) {
                for (int j = 0; j < cellnum; j++) {//for ��
                    Cell cell = row.getCell(j);
                    if (cell != null) {
                        cell.setCellType(Cell.CELL_TYPE_STRING); // ��������নString
                        tmpStr = cell.getStringCellValue();
                    } else {//�Y�L�Ȭ���
                        tmpStr = "";
                    }
                    if ("�O�T".equals(tmpStr)) {
                        ht = row.getHeight();//�����O�T���C�ҦX�֪�����
                        Cell cell2 = row.getCell(j + 1); //���q�]��
                        Cell cell3 = row.getCell(j + 4); //�L

                        tmpStr2 = this.getCellValue(cell2);
                        tmpStr3 = this.getCellValue(cell3);
                        tmpMap.put(tmpStr2, tmpStr3);
                    } else if (ht > 1 && ht != tempht) {
                        Cell cell2 = row.getCell(j + 1); //���q�]��
                        Cell cell3 = row.getCell(j + 4); //�L

                        tmpStr2 = this.getCellValue(cell2);
                        tmpStr3 = this.getCellValue(cell3);
                        tmpMap.put(tmpStr2, tmpStr3);
                        tempht++;
                    }
                    if ("����".equals(tmpStr)) {
                        tempboolean = true;
                        break;
                    } //else

                }

            } else {

                Map rntMap = new HashMap();
                Cell cellj = row.getCell(0);//����
                Cell cell4 = row.getCell(2);//���ƤΤu�{����                                                                                                                                
                Cell cell5 = row.getCell(20); //��  
                Cell cell6 = row.getCell(22); //�ƶq 
                Cell cell7 = row.getCell(25); //���           
                Cell cell8 = row.getCell(29); //���B

                chkStr = this.getCellValue(cellj);
                tmpStr4 = this.getCellValue(cell4);
                tmpStr5 = this.getCellValue(cell5);
                tmpStr6 = this.getCellValue(cell6);
                tmpStr7 = this.getCellValue(cell7);
                tmpStr8 = this.getCellValue(cell8);

                if (StringUtils.isBlank(chkStr)) {
                    tempboolean2 = true;
                    tempboolean = false;
                    break;
                } else {
                    rntMap.put("PROJECT_TP", tmpStr4);
                    rntMap.put("UNIT", tmpStr5);
                    rntMap.put("CNT", tmpStr6);
                    rntMap.put("PRICE", tmpStr7);
                    rntMap.put("EST_AMT", tmpStr8);
                    fileList.add(rntMap);
                }
            }
        }

        return fileList;
    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String value, String key) {

        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * ���o�̤j�Ƨѿ��Ǹ�MEMO_NO
     * @param F120Vo
     * @return
     * @throws ModuleException
     */
    private int getMaxMEMO_NO(DTEPF120 F120Vo) throws ModuleException {

        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", F120Vo.getAPLY_NO());
        ds.setField("SUB_CPY_ID", F120Vo.getSUB_CPY_ID());
        DBUtil.searchAndRetrieve(ds, SQL_getMaxMEMO_NO_001);
        ds.next();
        return NumberUtils.toInt(ds.getField("MEMO_NO").toString());
    }

    /**
     * ���o�y�{���
     * @param F120Vo
     * @return
     * @throws ModuleException
     */
    private DTRZN010 getFLOW_DATA(DTEPF120 F120Vo) throws ModuleException {
        DTRZN010 voDTRZN010 = new DTRZN010();
        voDTRZN010.setFLOW_NO(F120Vo.getFLOW_NO());
        return new RZ_N00100().queryDTRZN010(voDTRZN010).get(0);
    }

    /**
     * ���o�y�{�i�h�����
     * @param APLY_TP
     * @param OP_STATUS
     * @param aprove
     * @return
     * @throws ModuleException
     */
    private DTRZN003 getFLOW_TYPE_DATA(String APLY_TP, String OP_STATUS, String aprove) throws ModuleException {
        String FLOW_TYPE = "EPF1_0240";
        if (EP_Z0F110.ST_3.equals(APLY_TP)) {
            FLOW_TYPE = "EPF1_0340";
        }
        DTRZN003 voDTRZN003 = new DTRZN003();
        voDTRZN003.setFLOW_TYPE(FLOW_TYPE);
        if (EP_Z0F110.ST_1.equals(aprove)) {
            //�i��
            voDTRZN003.setOPSTATUS_FROM(OP_STATUS);
        } else if (EP_Z0F110.ST_2.equals(aprove)) {
            //�h��
            voDTRZN003.setOPSTATUS_TO(OP_STATUS);
        }

        return new RZ_N00100().queryDTRZN003(voDTRZN003).get(0);
    }

    /**
     * <pre>
     * ���o�y�{�i�h�����
     * @param APLY_TP
     * @param OP_STATUS
     * @param aprove
     * @return roleTp
     * 1    �{���޲z�H��
     * 2    ��µ�쬣��
     * 3    ��µ��
     * 4    ��µ��
     * 5    ��µ��b�ȸg��
     * 6    ��µ�հƲz
     * 7    ��µ�ոg�z
     * 8    ������
     * 9    �����լ���
     * A    �����հƲz
     * B    �����ոg�z
     * @throws ModuleException
     * </pre>
     */
    public String getRoleTp(UserObject user, String SUB_CPY_ID) {

        EPF1_0102_mod mod = new EPF1_0102_mod();
        String user_EMPID = user.getEmpID();
        //��µ��b�ȤH��
        String[] ACCOUNT_IDS = FieldOptionList.getName("EP", "ACCOUNTS_ID", "ACCOUNTS_IDS").split(",");
        //��µ��W�űb��
        String[] fixSuperId = FieldOptionList.getName("EP", "SUPER_ID", "FIX_SUPER_ID").split(",");
        //��µ�նW�űb��
        String[] fixSuperIdMap = FieldOptionList.getName("EP", "SUPER_ID", "FIXG_SUPER_ID").split(",");
        //�o�]�նW�űb��
        //String[] subconSuperIdMap = FieldOptionList.getName("EP", "SUPER_ID", "SUBCONG_SUPER_ID").split(",");
        //String FIX_GROUP_ROLE = FieldOptionList.getName("EP", "EP_ROLES", "FIX_GROUP_ROLE");//"RLEP016"��µ��
        //��A
        String RLZZ0EP = FieldOptionList.getName("EP", "DIV_F106", "RLZZ0EP");
        String roleTp = "X";

        //���ʲ���µ�쬣�� ��µ�쬣��	2
        /*if ((mod.isItSuperRole(FIX_DIV_ROLE, user)) || mod.isSuperIdMap(fixSuperId, user)) {
            roleTp = "2";
        }*/

        //��µ��t�d�H ��µ��	3
        if (user.getRoles().containsKey("RLEP014") || mod.isSuperIdMap(fixSuperId, user)) {
            log.debug("IS_FIX_DIV");
            roleTp = "3";
        }

        //��µ��b�ȸg��    5
        if (mod.isSuperIdMap(ACCOUNT_IDS, user)) {
            roleTp = "5";
        }

        //�D��
        String IS_MGR = "";
        if (user.getDivNo().startsWith("EP9")) {
            try {
                Map map1 = new EP_Z00100().getEmp(user_EMPID, SUB_CPY_ID);
                IS_MGR = MapUtils.getString(map1, "IS_MGR");
            } catch (ModuleException e) {
                log.error("�d�߼ӺޤH�� ����", e);
            }
        }

        //        4	��µ��
        String FIX_GROUP_ROLE1 = FieldOptionList.getName("EP", "EP_ROLES", "FIX_GROUP_ROLE1");//"ROZZEP5"�_�ϭ�µ��
        String FIX_GROUP_ROLE2 = FieldOptionList.getName("EP", "EP_ROLES", "FIX_GROUP_ROLE2");//"ROZZEP6"���n�ϭ�µ��
        if (mod.isItSuperRole(FIX_GROUP_ROLE1, user) || mod.isItSuperRole(FIX_GROUP_ROLE2, user) || mod.isSuperIdMap(fixSuperIdMap, user)) {
            roleTp = "4";
        }

        // ��µ�հƲz	6
        //�M��_�ϭ�µ�ղժ�
        if (mod.isSubconMgr(IS_MGR, FIX_GROUP_ROLE1, user)) {
            roleTp = "6";
        }
        //�M�餤�n�ϭ�µ�ղժ�
        if (mod.isSubconMgr(IS_MGR, FIX_GROUP_ROLE2, user)) {
            roleTp = "6";
        }

        //      * ��µ�ոg�z	7
        //�M����µ��
        String FIX_GROUP_ROLE0 = FieldOptionList.getName("EP", "EP_ROLES", "FIX_GROUP_ROLE0");//"ROZZEP4"��µ��
        if (mod.isSubconMgr(IS_MGR, FIX_GROUP_ROLE0, user)) {
            roleTp = "7";
        }

        //      * ������	        
        String SUBCON_GROUP_ROLE1 = FieldOptionList.getName("EP", "EP_ROLES", "SUBCON_GROUP_ROLE1");
        if (mod.isItSuperRole(SUBCON_GROUP_ROLE1, user)) {
            roleTp = "8";
        }

        //�޲z��  �����լ���	9
        String SUBCON_GROUP_ROLE0 = FieldOptionList.getName("EP", "EP_ROLES", "SUBCON_GROUP_ROLE0");//" "�޲z��
        String SUBCON_GROUP_ROLE2 = FieldOptionList.getName("EP", "EP_ROLES", "SUBCON_GROUP_ROLE2");//"ROZZEP2"��F��
        if (mod.isSubconMgr(IS_MGR, SUBCON_GROUP_ROLE1, user) || mod.isItSuperRole(SUBCON_GROUP_ROLE2, user)) {
            roleTp = "9";
        }

        //�M��o�]��  �����հƲz	A
        if (mod.isSubconMgr(IS_MGR, SUBCON_GROUP_ROLE1, user)) {
            roleTp = "A";
        }

        //�M���F�޲z�� �����ոg�z	B
        if ((mod.isSubconMgr(IS_MGR, SUBCON_GROUP_ROLE0, user))) {
            roleTp = "B";
        }

        // �t�κ��@�H�� IT
        if (mod.isItSuperRole(RLZZ0EP, user)) {
            roleTp = "I";
        }

        //�߮פH    �{���޲z�H��    1
        if ("X".equals(roleTp)) {
            log.debug("IS_INPUT_USER");
            roleTp = "1";
        }

        return roleTp;
    }
}
