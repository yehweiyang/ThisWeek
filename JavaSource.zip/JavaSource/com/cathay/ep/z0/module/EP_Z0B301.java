package com.cathay.ep.z0.module;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2015-03-12  Created Allen Tsai
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �߮׺��@�Ҳ�
 * �Ҳ�ID    EP_Z0B301
 * ���n����    �߮׺��@�Ҳ�
 * </pre>
 * @author �Ťl��
 * [190125] �վ�PMD(Ensure batch resources are closed in Finally after used)
 */
@SuppressWarnings("unchecked")
public class EP_Z0B301 {
    //private static final Logger log = Logger.getLogger(EP_Z0B301.class);

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0B301.SQL_insert_001";
    private static final String SQL_doQuery_001 = "com.cathay.ep.z0.module.EP_Z0B301.SQL_doQuery_001";

    /**
     * �s�W��s�D�ɮץ����
     * @param reqMap    
     * @return
     * @throws ModuleException
     * @throws SQLException
     */
    public void insertBatch(List<Map> reqList) throws ModuleException, DBException {

        ErrorInputException eie = null;

        //20190125�G�վ�PMD(Ensure batch resources are closed in Finally after used)
        BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        buds.preparedBatch(SQL_insert_001);
        try {
            for (Map reqMap : reqList) {
                String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
                String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
                String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
                String UPD_TRN_KIND = MapUtils.getString(reqMap, "UPD_TRN_KIND");
                String UPD_DATE = MapUtils.getString(reqMap, "UPD_DATE");
                String CHG_ID = MapUtils.getString(reqMap, "CHG_ID");
                String CHG_DIV_NO = MapUtils.getString(reqMap, "CHG_DIV_NO");
                String CHG_NAME = MapUtils.getString(reqMap, "CHG_NAME");
                if (StringUtils.isBlank(SUB_CPY_ID)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_002"));//�����q�O���o���ŭ�
                }
                if (StringUtils.isBlank(BLD_CD)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_003"));//�j�ӥN�����o���ŭ�
                }
                if (StringUtils.isBlank(UPD_TRN_KIND)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_004"));//�J�ɥ���������o���ŭ�
                }
                if (StringUtils.isBlank(UPD_DATE)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_005"));//�J�ɤ�����o���ŭ�
                }
                if (StringUtils.isBlank(CHG_ID)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_006"));//����ID���o���ŭ�
                }
                if (StringUtils.isBlank(CHG_DIV_NO)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_007"));//���ʳ�줣�o���ŭ�
                }
                if (StringUtils.isBlank(CHG_NAME)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_008"));//���ʩm�W���o���ŭ�
                }

                buds.setField("APLY_NO", APLY_NO);
                buds.setField("TRN_KIND", UPD_TRN_KIND);
                buds.setField("BLD_CD", BLD_CD);
                buds.setField("CRT_NO", null);
                buds.setField("PRE_CRT_NO", null);
                buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                buds.setField("INPUT_DATE", UPD_DATE);
                buds.setField("INPUT_DIV_NO", CHG_DIV_NO);
                buds.setField("INPUT_ID", CHG_ID);
                buds.setField("INPUT_NAME", CHG_NAME);
                buds.setField("IS_REG", null);
                buds.setField("REG_STR_DATE", null);
                buds.setField("REG_END_DATE", null);
                buds.setField("REG_APLY_NO", null);
                buds.setField("FLOW_NO", "XX");
                buds.setField("OP_STATUS", "04");
                buds.setField("LST_PROC_DATE", UPD_DATE);
                buds.setField("LST_PROC_ID", CHG_ID);
                buds.setField("LST_PROC_DIV", CHG_DIV_NO);
                buds.setField("LST_PROC_NAME", CHG_NAME);
                buds.setField("REG_TRN_KIND", null);
                buds.setField("NEW_RNTSTR_DATE", null);
                buds.setField("NEW_RNTEND_DATE", null);
                buds.setField("IS_NOW_UPDATE", null);
                buds.addBatch();
            }

            int buds_Ret[] = buds.executeBatch();

            Object errObject[][] = new ErrorHandler().getErrorArray(buds.getBatchUpdateErrorArray(), buds_Ret, buds.getBatchMapsArray(),
                ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

            if (errObject != null && errObject.length > 0) {
                for (int i = 0; i < errObject.length; i++) {
                    throw new ModuleException((SQLException) errObject[i][2]);
                }
            }
        } finally {
            if (buds != null) {
                buds.close();
            }
        }

    }
    
    /**
     * �d�ץ��ܧ�������
     * @param CRT_NO �����N��
     * @param TRN_KINDs �������
     * @param SUB_CPY_ID �����q�O
     * @return �ץ��ܧ�������
     * @throws ModuleException
     * 20190620���D��20190102-0007�b�߮׿�J�δ����פ�e�����פ�ɡA���ˮָӥ�O�_�w���t�q�s�����A
     * �Y���h���ݲפ�A���t�αƵ{�ۦ�פ�A�קK�d�L�«���������
     */
    public List<Map> doQuery(String CRT_NO, String[] TRN_KINDs, String SUB_CPY_ID) throws ModuleException {
        // �Ѽ��ˮ�
        ErrorInputException eie = null;
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_009")); //�����N�����o����
        }
        if (TRN_KINDs == null || TRN_KINDs.length == 0) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_004")); //�J�ɥ���������o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_002")); //�����q�O���o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        // �d�߸�Ƴ]�w
        DataSet ds = Transaction.getDataSet();
        ds.setField("CRT_NO", CRT_NO);
        ds.setFieldValues("TRN_KINDs", TRN_KINDs);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_doQuery_001);
    }
    
    /**
     * �d�ץ��ܧ�������
     * @param CRT_NO �����N��
     * @param TRN_KINDs �������
     * @param SUB_CPY_ID �����q�O
     * @param IS_END �O�_����(Y/N)
     * @return �ץ��ܧ�������
     * @throws ModuleException
     * 20190719�]�I��۰ʥͮıƵ{�����D�����`�N�¥�פ���p�A�G���קK�L�k�A�H�u���סA�վ㦨�ˮ֬O�_�������ץ�
     */
    public List<Map> doQuery(String CRT_NO, String[] TRN_KINDs, String SUB_CPY_ID, String IS_END) throws ModuleException {
        // �Ѽ��ˮ�
        ErrorInputException eie = null;
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_009")); //�����N�����o����
        }
        if (TRN_KINDs == null || TRN_KINDs.length == 0) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_004")); //�J�ɥ���������o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0B301_MSG_002")); //�����q�O���o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        // �d�߸�Ƴ]�w
        DataSet ds = Transaction.getDataSet();
        ds.setField("CRT_NO", CRT_NO);
        ds.setFieldValues("TRN_KINDs", TRN_KINDs);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (StringUtils.isNotBlank(IS_END)) {
            ds.setField("IS_END", IS_END); 
        }
        return VOTool.findToMaps(ds, SQL_doQuery_001);
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }
}
