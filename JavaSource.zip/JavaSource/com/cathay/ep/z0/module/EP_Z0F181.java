package com.cathay.ep.z0.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2015/12/22 Created ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��޶O�뵲�����ɺ��@�Ҳ�
 * �Ҳ�ID      EP_Z0F181
 * ���n����    ��޶O�뵲�����ɺ��@�Ҳ�
 * </pre>
 * @author �d�ÿ�
 * @since 2015/01/11
 */
@SuppressWarnings("unchecked")
public class EP_Z0F181 {

    //private static final Logger log = Logger.getLogger(EP_Z0F181.class);

    private static final String SQL_queryByCMM_APLY_NO_001 = "com.cathay.ep.z0.module.EP_Z0F181.SQL_queryByCMM_APLY_NO_001";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0F181.SQL_insert_001";

    private static final String SQL_deleteByCMM_APLY_NO_001 = "com.cathay.ep.z0.module.EP_Z0F181.SQL_deleteByCMM_APLY_NO_001";

    /**
     * �d����޶O���Ӹ��
     * @param CMM_APLY_NO ��޶O�뵲�s��
     * @return ��޶O�M��
     * @throws ModuleException
     */
    public List<Map> queryByCMM_APLY_NO(String CMM_APLY_NO) throws ModuleException {

        if (StringUtils.isBlank(CMM_APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F181_MSG_001")); // ��޶O�뵲�s�����i����
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("CMM_APLY_NO", CMM_APLY_NO);
        return VOTool.findToMaps(ds, SQL_queryByCMM_APLY_NO_001);
    }

    /**
     * �s�W��޶O���
     * @param F180Map
     * @throws ModuleException
     * @throws DBException 
     */
    public void insert(List<Map> F181List) throws ModuleException, DBException {

        if (F181List == null || F181List.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F181_MSG_002")); // �ǤJ�ѼƤ��i����
        }

        ErrorInputException eie = null;
        for (int i = 0; i < F181List.size(); i++) {
            Map F181Map = F181List.get(i);
            if (StringUtils.isBlank(MapUtils.getString(F181Map, "CMM_APLY_NO"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F181_MSG_003", new Object[] { i + 1 })); // ��{0}����޶O�뵲�s�����i����
            }
            if (StringUtils.isBlank(MapUtils.getString(F181Map, "APLY_NO"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F181_MSG_004", new Object[] { i + 1 })); // ��{0}����µ�ץ�s�����i����
            }
            if (StringUtils.isBlank(MapUtils.getString(F181Map, "APLY_TP"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F181_MSG_005", new Object[] { i + 1 })); // ��{0}���ץ�������i����
            }
            if (StringUtils.isBlank(MapUtils.getString(F181Map, "USE_TP"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F181_MSG_006", new Object[] { i + 1 })); // ��{0}���ϥΪ��p�������i����
            }
            if (StringUtils.isBlank(MapUtils.getString(F181Map, "BLD_CD"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F181_MSG_007", new Object[] { i + 1 })); // ��{0}���j�ӥN�����i����
            }
            if (StringUtils.isBlank(MapUtils.getString(F181Map, "BLD_NM"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F181_MSG_008", new Object[] { i + 1 })); // ��{0}���j�ӦW�٤��i����
            }
            if (StringUtils.isBlank(MapUtils.getString(F181Map, "CLR_AMT"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F181_MSG_009", new Object[] { i + 1 })); // ��{0}����µ�O�Τ��i����
            }
            if (StringUtils.isBlank(MapUtils.getString(F181Map, "CMM_FEE"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F181_MSG_010", new Object[] { i + 1 })); // ��{0}����޶O���i����
            }
        }

        if (eie != null) {
            throw eie;
        }

        //        BatchUpdateDataSet buds = null;
        //        try {
        //            buds = Transaction.getBatchUpdateDataSet();
        //            buds.preparedBatch(SQL_insert_001);
        //
        //            String[] fields = new String[] { "CMM_APLY_NO", "APLY_NO", "APLY_TP", "USE_TP", "BLD_CD", "BLD_NM", "SUP_ID", "SUP_NM","FIX_MO",
        //                    "USR_FINAL_DATE", "END_APLY_DATE", "CLR_AMT", "CMM_FEE", "LST_PROC_DATE", "LST_PROC_ID", "LST_PROC_DIV" };
        //
        //            for (int i = 0; i < F181List.size(); i++) {
        //                Map F181Map = F181List.get(i);
        //                for (String field : fields) {
        //                    buds.setField(field, F181Map.get(field));
        //                }
        //                buds.addBatch();
        //            }
        //            buds.executeBatch();
        //
        //            Object[][] errors = buds.getBatchUpdateErrorArray();
        //
        //            if (errors.length > 0) {
        //                for (Object[] err : errors) {
        //                    log.error("�s�W��" + ((Integer) err[0] + 1) + "����Ʀ��~  Insert setField = " + err[1], (Exception) err[2]);
        //                }
        //                throw new ModuleException(MessageUtil.getMessage("EP_Z0F181_MSG_011")); // �s�W��޶O�뵲�����ɦ��~
        //            }
        //        } finally {
        //            if (buds != null) {
        //                buds.close();
        //            }
        //        }

        String[] fields = new String[] { "CMM_APLY_NO", "APLY_NO", "APLY_TP", "USE_TP", "BLD_CD", "BLD_NM", "SUP_ID", "SUP_NM", "FIX_MO",
                "USR_FINAL_DATE", "END_APLY_DATE", "CLR_AMT", "CMM_FEE", "LST_PROC_DATE", "LST_PROC_ID", "LST_PROC_DIV" };

        DataSet ds = Transaction.getDataSet();
        for (Map F181Map : F181List) {
            ds.clear();
            for (String field : fields) {
                ds.setField(field, F181Map.get(field));
            }
            DBUtil.executeUpdate(ds, SQL_insert_001);
        }
    }

    /**
     * �R����޶O���Ӹ��
     * @param CMM_APLY_NO ��޶O�뵲�s��
     * @return 
     * @throws ModuleException
     */
    public void deleteByCMM_APLY_NO(String CMM_APLY_NO) throws ModuleException {

        if (StringUtils.isBlank(CMM_APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F181_MSG_001")); // ��޶O�뵲�s�����i����
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("CMM_APLY_NO", CMM_APLY_NO);
        DBUtil.executeUpdate(ds, SQL_deleteByCMM_APLY_NO_001);
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {

        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}