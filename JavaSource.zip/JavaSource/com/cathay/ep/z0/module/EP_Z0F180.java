package com.cathay.ep.z0.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2015/12/22 Created ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��޶O�뵲�O���ɺ��@�Ҳ�
 * �Ҳ�ID      EP_Z0F180
 * ���n����    ��޶O�뵲�O���ɺ��@�Ҳ�
 * </pre>
 * @author �d�ÿ�
 * @since 2015/01/11
 */
@SuppressWarnings("unchecked")
public class EP_Z0F180 {

    private static final String SQL_queryByPK_001 = "com.cathay.ep.z0.module.EP_Z0F180.SQL_queryByPK_001";

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0F180.SQL_queryList_001";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0F180.SQL_insert_001";

    private static final String SQL_delete_001 = "com.cathay.ep.z0.module.EP_Z0F180.SQL_delete_001";

    private static final String SQL_updateOP_STATUS_001 = "com.cathay.ep.z0.module.EP_Z0F180.SQL_updateOP_STATUS_001";

    /**
     * �d����޶O���
     * @param CMM_APLY_NO ��޶O�뵲�s��
     * @return ��޶O�M��
     * @throws ModuleException
     */
    public Map queryByPK(String CMM_APLY_NO, String SUB_CPY_ID) throws ModuleException {

        if (StringUtils.isBlank(CMM_APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F180_MSG_001")); // ��޶O�뵲�s�����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("CMM_APLY_NO", CMM_APLY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findOneToMap(ds, SQL_queryByPK_001);
    }

    /**
     * �d����޶O���
     * @param reqMap �d�߱���
     * @param SUB_CPY_ID �����q�O
     * @return ��޶O�M��
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap, String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_002")); // �d�߱��󤣥i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_003")); // �����q�O���i����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setFieldIfExist(ds, reqMap, "CMM_YM");
        setFieldIfExist(ds, reqMap, "OP_STATUS");
        return VOTool.findToMaps(ds, SQL_queryList_001);
    }

    /**
     * �s�W��޶O���
     * @param F180Map
     * @throws ModuleException
     */
    public void insert(Map F180Map) throws ModuleException {

        if (F180Map == null || F180Map.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F180_MSG_004")); // �ǤJ�ѼƤ��i����
        }

        ErrorInputException eie = null;

        String CMM_APLY_NO = MapUtils.getString(F180Map, "CMM_APLY_NO");
        String SUB_CPY_ID = MapUtils.getString(F180Map, "SUB_CPY_ID");
        String CMM_YM = MapUtils.getString(F180Map, "CMM_YM");
        String FLOW_NO = MapUtils.getString(F180Map, "FLOW_NO");
        String OP_STATUS = MapUtils.getString(F180Map, "OP_STATUS");
        String LST_PROC_DATE = MapUtils.getString(F180Map, "LST_PROC_DATE");
        String LST_PROC_ID = MapUtils.getString(F180Map, "LST_PROC_ID");
        String LST_PROC_DIV = MapUtils.getString(F180Map, "LST_PROC_DIV");

        if (StringUtils.isBlank(CMM_APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_001")); // ��޶O�뵲�s�����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_003")); // �����q�O���i����
        }
        if (StringUtils.isBlank(CMM_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_005")); // �뵲�~�뤣�i���� 
        }
        if (StringUtils.isBlank(FLOW_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_006")); // �f��y�{�s�����i���� 
        }
        if (StringUtils.isBlank(OP_STATUS)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_007")); // �@�~�i�פ��i����
        }
        if (StringUtils.isBlank(LST_PROC_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_008")); // �@�~�ɶ����i����
        }
        if (StringUtils.isBlank(LST_PROC_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_009")); // �@�~�H�����i����
        }
        if (StringUtils.isBlank(LST_PROC_DIV)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_010")); // �@�~��줣�i����
        }

        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("CMM_APLY_NO", CMM_APLY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CMM_YM", CMM_YM);
        ds.setField("CMM_CNT", F180Map.get("CMM_CNT"));
        ds.setField("TOT_CLR_AMT", F180Map.get("TOT_CLR_AMT"));
        ds.setField("TOT_CMM_FEE", F180Map.get("TOT_CMM_FEE"));
        ds.setField("UNTAX_AMT", F180Map.get("UNTAX_AMT"));
        ds.setField("TAX_AMT", F180Map.get("TAX_AMT"));
        ds.setField("INPUT_ID", F180Map.get("INPUT_ID"));
        ds.setField("INPUT_DIV_NO", F180Map.get("INPUT_DIV_NO"));
        ds.setField("INPUT_DATE", F180Map.get("INPUT_DATE"));
        ds.setField("SUP_ID", F180Map.get("SUP_ID"));
        ds.setField("SUP_NM", F180Map.get("SUP_NM"));
        ds.setField("FLOW_NO", FLOW_NO);
        ds.setField("OP_STATUS", OP_STATUS);
        ds.setField("CASE_NO", F180Map.get("CASE_NO"));
        ds.setField("PAY_DATE", F180Map.get("PAY_DATE"));
        ds.setField("PAY_CFM_DATE", F180Map.get("PAY_CFM_DATE"));
        ds.setField("ACC_SECVER_DATE", F180Map.get("ACC_SECVER_DATE"));
        ds.setField("LST_PROC_DATE", LST_PROC_DATE);
        ds.setField("LST_PROC_ID", LST_PROC_ID);
        ds.setField("LST_PROC_DIV", LST_PROC_DIV);

        DBUtil.executeUpdate(ds, SQL_insert_001);
    }

    /**
     * �R���޲z�O�O��
     * @param CMM_APLY_NO ��ޤ뵲�s��
     * @throws ModuleException
     */
    public void delete(String CMM_APLY_NO, String SUB_CPY_ID) throws ModuleException {

        if (StringUtils.isBlank(CMM_APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0F180_MSG_001")); // ��޶O�뵲�s�����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("CMM_APLY_NO", CMM_APLY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_delete_001);
    }

    /**
     * ��s��޶O�O�����A
     * @param reqMap
     * @param UPD_TYPE ��s����
     * @throws ModuleException
     */
    public void updateOP_STATUS(Map reqMap, String UPD_TYPE) throws ModuleException {

        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_004")); // �ǤJ�ѼƤ��i����
        }
        if (StringUtils.isBlank(UPD_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_011")); // ��s�������i����
        }
        if (eie != null) {
            throw eie;
        }

        String CMM_APLY_NO = MapUtils.getString(reqMap, "CMM_APLY_NO");
        String OP_STATUS = MapUtils.getString(reqMap, "OP_STATUS");
        String LST_PROC_DATE = MapUtils.getString(reqMap, "LST_PROC_DATE");
        String LST_PROC_ID = MapUtils.getString(reqMap, "LST_PROC_ID");
        String LST_PROC_DIV = MapUtils.getString(reqMap, "LST_PROC_DIV");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String CASE_NO = null;
        String PAY_DATE = null;
        String PAY_CFM_DATE = null;
        String ACC_SECVER_DATE = null;

        if (StringUtils.isBlank(CMM_APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_001")); // ��޶O�뵲�s�����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(OP_STATUS)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_007")); // �@�~�i�פ��i����
        }
        if (StringUtils.isBlank(LST_PROC_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_008")); // �@�~�ɶ����i����
        }
        if (StringUtils.isBlank(LST_PROC_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_009")); // �@�~�H�����i����
        }
        if (StringUtils.isBlank(LST_PROC_DIV)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_010")); // �@�~��줣�i����
        }
        if ("1".equals(UPD_TYPE)) {
            CASE_NO = MapUtils.getString(reqMap, "CASE_NO");
            PAY_DATE = MapUtils.getString(reqMap, "PAY_DATE");
            if (StringUtils.isBlank(CASE_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_012")); // �дڰO���s�����i����
            }
            if (StringUtils.isBlank(PAY_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_013")); // �дڤ�����i����
            }
        } else if ("3".equals(UPD_TYPE)) {
            PAY_CFM_DATE = MapUtils.getString(reqMap, "PAY_CFM_DATE");
            ACC_SECVER_DATE = MapUtils.getString(reqMap, "ACC_SECVER_DATE");
            if (StringUtils.isBlank(PAY_CFM_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_014")); // �дڽT�{������i����
            }
            if (StringUtils.isBlank(ACC_SECVER_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0F180_MSG_015")); // �|�p�Ю֤�����i����
            }
        }

        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("CMM_APLY_NO", CMM_APLY_NO);
        ds.setField("OP_STATUS", OP_STATUS);
        ds.setField("LST_PROC_DATE", LST_PROC_DATE);
        ds.setField("LST_PROC_ID", LST_PROC_ID);
        ds.setField("LST_PROC_DIV", LST_PROC_DIV);
        if ("1".equals(UPD_TYPE)) {
            ds.setField("CASE_NO", CASE_NO);
            ds.setField("PAY_DATE", PAY_DATE);
        } else if ("2".equals(UPD_TYPE)) {
            ds.setField("CASE_NO", null);
            ds.setField("PAY_DATE", null);
        } else if ("3".equals(UPD_TYPE)) {
            ds.setField("PAY_CFM_DATE", PAY_CFM_DATE);
            ds.setField("ACC_SECVER_DATE", ACC_SECVER_DATE);
        }
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_updateOP_STATUS_001);
    }

    /**
     * SQL�����D���n�Ѽ�
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, Map rtnMap, String key) {
        String value = MapUtils.getString(rtnMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {

        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}