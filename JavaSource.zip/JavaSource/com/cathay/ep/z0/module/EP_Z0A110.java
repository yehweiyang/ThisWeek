package com.cathay.ep.z0.module;

import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.common.util.http.HttpClientHelper;
import com.cathay.common.util.http.HttpClientHelper.HttpResponseType;
import com.cathay.common.util.security.AESHelper;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �޲z�j�Ӭd�߼Ҳ�
 * </pre>
 * @author �©s��
 * @since 2019/7/9
 * 2019/11/08 AllenTsai �t�X�q�l�a��API�վ�token�PAPI Request�PResponse�B�z
 * 2019/11/11 AllenTsai �վ�w��T�{�P�_����
 **/
@SuppressWarnings({ "rawtypes", "unchecked" })
public class EP_Z0A110 {
    /** logger */
    private static final Logger log = Logger.getLogger(EP_Z0A110.class);
    
    private static final String SQL_queryTownByArea_001 = "com.cathay.ep.z0.module.EP_Z0A110.SQL_queryTownByArea_001";

    private static final String SQL_queryCity_001 = "com.cathay.ep.z0.module.EP_Z0A110.SQL_queryCity_001";

    private static final String SQL_queryTown_001 = "com.cathay.ep.z0.module.EP_Z0A110.SQL_queryTown_001";

    private static final String SQL_updateGeoLocation_001 = "com.cathay.ep.z0.module.EP_Z0A110.SQL_updateGeoLocation_001";

    private static final String SQL_queryByBldCD_001 = "com.cathay.ep.z0.module.EP_Z0A110.SQL_queryByBldCD_001";

    private static final String SQL_addBldData_001 = "com.cathay.ep.z0.module.EP_Z0A110.SQL_addBldData_001";

    private static final String SQL_queryByBldCDList_001 = "com.cathay.ep.z0.module.EP_Z0A110.SQL_queryByBldCDList_001";

    /**
     * ���o�ϰ��F��
     * @param SUB_CPY_ID �����q�O
     * @param ARA_CD �ϰ�O
     * @return
     * @throws ModuleException
     */
    public List<String> queryTownByArea(String SUB_CPY_ID, String ARA_CD) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, "EP_Z0A110_MSG_001");//��J�����q�O(SUB_CPY_ID)���i����
        }
        if (StringUtils.isBlank(ARA_CD)) {
            eie = getEie(eie, "EP_Z0A110_MSG_002");//��J�ϰ�O(ARA_CD)���i����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("ARA_CD", ARA_CD);

        DBUtil.searchAndRetrieve(ds, SQL_queryTownByArea_001);

        List<String> rtnList = new ArrayList<String>();

        while (ds.next()) {
            String TOWN = STRING.objToStr(ds.getField("TOWN"), "");
            if (StringUtils.isNotBlank(TOWN)) {
                rtnList.add(TOWN);
            }
        }

        return rtnList;

    }

    /**
     * �d�߿���
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException
     */
    public List<Map> queryCity(String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0A110_MSG_001"));//��J�����q�O(SUB_CPY_ID)���i����
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        return VOTool.findToMaps(ds, SQL_queryCity_001);

    }

    /**
     * �d�ߦ�F��
     * @param SUB_CPY_ID
     * @param CITY
     * @return
     * @throws ModuleException
     */
    public List<String> queryTown(String SUB_CPY_ID, String CITY) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, "EP_Z0A110_MSG_001");//��J�����q�O(SUB_CPY_ID)���i����
        }
        if (StringUtils.isBlank(CITY)) {
            eie = getEie(eie, "EP_Z0A110_MSG_003");//��J����(CITY)���i����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CITY", CITY);

        DBUtil.searchAndRetrieve(ds, SQL_queryTown_001);

        List<String> rtnList = new ArrayList<String>();

        while (ds.next()) {
            String TOWN = STRING.objToStr(ds.getField("TOWN"), "");
            if (StringUtils.isNotBlank(TOWN)) {
                rtnList.add(TOWN);
            }
        }

        return rtnList;
    }

    /**
     * �j�Ӯy�и�Ƨ�sAPI
     * @param reqMap
     * @throws ModuleException 
     */
    public void updateGeoLocation(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0A110_MSG_009"));//��JreqMap���i����
        }
        ErrorInputException eie = null;

        String X = MapUtils.getString(reqMap, "X");
        if (StringUtils.isBlank(X)) {
            eie = getEie(eie, "EP_Z0A110_MSG_004");//��JX�y�Ф��i����
        }
        String Y = MapUtils.getString(reqMap, "Y");
        if (StringUtils.isBlank(Y)) {
            eie = getEie(eie, "EP_Z0A110_MSG_005");//��JY�y�Ф��i����
        }
        String LV = MapUtils.getString(reqMap, "LV");
        if (StringUtils.isBlank(LV)) {
            eie = getEie(eie, "EP_Z0A110_MSG_008");//��J�w�쵥��(LV)���i����
        }
        String CFM_ID = MapUtils.getString(reqMap, "CFM_ID");
        if (StringUtils.isBlank(CFM_ID)) {
            eie = getEie(eie, "EP_Z0A110_MSG_006");//��J�w��T�{�H��(CFM_ID)���i����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, "EP_Z0A110_MSG_001");//��J�����q�O(SUB_CPY_ID)���i����
        }
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getEie(eie, "EP_Z0A110_MSG_007");//��J�j�ӥN��(BLD_CD)���i����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("X", X);//X�y��
        ds.setField("Y", Y);//Y�y��
        ds.setField("LV", LV);//�w�쵥��
        ds.setField("CFM_ID", CFM_ID);//�w��T�{�H��
        ds.setField("CFM_DATE", DATE.getDBTimeStamp());//�w��T�{�ɶ�
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        ds.setField("BLD_CD", BLD_CD);//�j�ӥN��

        this.setFieldIfExist(ds, "CITY", reqMap);
        this.setFieldIfExist(ds, "TOWN", reqMap);

        DBUtil.executeUpdate(ds, SQL_updateGeoLocation_001);

    }

    /**
     * [20190715]
     * @param SUB_CPY_ID
     * @param BLD_CD
     * @return
     * @throws ModuleException
     */
    public Map queryByBldCD(String SUB_CPY_ID, String BLD_CD) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, "EP_Z0A110_MSG_001");//��J�����q�O(SUB_CPY_ID)���i����
        }
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getEie(eie, "EP_Z0A110_MSG_007");//��J�j�ӥN��(BLD_CD)���i����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", BLD_CD);

        return VOTool.findOneToMap(ds, SQL_queryByBldCD_001);

    }

    /**
     * [20190723] �����q�l�a��API MAP001
     * @param reqMap
     * @throws ModuleException
     */
    public void addBldData(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0A110_MSG_009"));//��JreqMap���i����
        }
        ErrorInputException eie = null;

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, "EP_Z0A110_MSG_001");//��J�����q�O(SUB_CPY_ID)���i����
        }
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getEie(eie, "EP_Z0A110_MSG_007");//��J�j�ӥN��(BLD_CD)���i����
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("CITY", reqMap.get("CITY"));
        ds.setField("TOWN", reqMap.get("TOWN"));
        ds.setField("X", reqMap.get("X"));
        ds.setField("Y", reqMap.get("Y"));
        ds.setField("LV", reqMap.get("LV"));
        ds.setField("CHG_ID", reqMap.get("CHG_ID"));
        ds.setField("CHG_DATE", reqMap.get("CHG_DATE"));
        ds.setField("CFM_CD", reqMap.get("CFM_CD"));
        ds.setField("CFM_ID", reqMap.get("CFM_ID"));
        ds.setField("CFM_DATE", reqMap.get("CFM_DATE"));

        DBUtil.executeUpdate(ds, SQL_addBldData_001);

    }

    /**
     * [20190723] �����q�l�a��API MAP002
     * @param bldList
     * @return
     * @throws ModuleException
     */
    public List<Map> queryByBldCDList(List<String> bldList) throws ModuleException {
        if (bldList == null || bldList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0A110_MSG_010"));//��J�j�ӽs���M�椣�i����
        }
        DataSet ds = Transaction.getDataSet();
        ds.setFieldValues("bldList", bldList);

        return VOTool.findToMaps(ds, SQL_queryByBldCDList_001);
    }

    /**
     * [20190723] �I�s�����q�l�a��API MAP001
     * @param mapA110
     * @throws Exception
     */
    public void callAPIMap001(Map mapA110, String userId) throws Exception {
        Map reqMap = new HashMap();
        reqMap.put("reqMap", mapA110);
        String jsonStr = VOTool.toJSON(reqMap);
        Object result = new EP_Z0A110().callAPI("MAP001", jsonStr, userId);
        Map rtnMap = VOTool.jsonToMap(VOTool.toJSON(result));
        if (ReturnCode.OK != MapUtils.getIntValue(rtnMap, "returnCode", 1)) {
            throw new ModuleException();
        }

    }

    /**
     * [20190723] �I�s�����q�l�a��API MAP002
     * 2019/11/08 AllenTsai �t�X�q�l�a��API�վ�/api/CathayLifeBuilding��غ޲z�j�ӪŶ���Ƭd�� �I�s API
     * @param bldList
     * @return
     * @throws Exception
     */
    public List<Map> callAPIMap002(List<String> bldList, String userId) throws Exception {

        Map reqMap = new HashMap();
        reqMap.put("buildingNo", bldList);
        
        Map appInfo = new HashMap();
        appInfo.put("appId", "EP");
        appInfo.put("sourceCode", userId);
        reqMap.put("appInfo", appInfo);
        String jsonStr = VOTool.toJSON(reqMap);
        
        log.debug("callAPIMap002 JSON:"+jsonStr);
        Object result = callAPI("MAP002", jsonStr, userId);
        log.debug("/api/CathayLifeBuilding��غ޲z�j�ӪŶ���Ƭd��:\n"+result);
        Map rtnMap = VOTool.jsonToMap(VOTool.toJSON(result));
        String strSuccess = MapUtils.getString(rtnMap , "success");
		log.debug("success: "+strSuccess);
        Object detail = MapUtils.getObject(rtnMap, "result");
        log.debug(detail.getClass());
        if(strSuccess.equals("true")) {        	  
        	List<Map> rtnList = (List<Map>)  detail;
        	for(Map rtnData: rtnList) {
        	    String lv = MapUtils.getString(rtnData, "lv");
        	    if("99".equals(lv)) {
        	    	rtnData.put("CFM_CD", "Y");
        	    } else {
        	    	rtnData.put("CFM_CD", "N");
        	    }
        	}
        	return rtnList;
        }
        return Collections.EMPTY_LIST;
        	
    }

    /**
     * [20190723] �@�ΩI�sAPI
     * 2019/11/08 AllenTsai �t�X�q�l�a��API�վ�token�]�ȳB�z
     * @param apiCode
     * @param jsonStr
     * @return
     * @throws Exception
     */
    public String callAPI(String apiCode, String jsonStr, String userID) throws Exception {
        String ip = InetAddress.getLocalHost().getHostAddress();
        HttpClientHelper hc = new HttpClientHelper();
        String requestURL = FieldOptionList.getName("EP", "EMAP_API", apiCode);
        StringBuilder sb = new StringBuilder();
        Calendar cal = Calendar.getInstance();
        String strToken = sb.append("DT=").append(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(cal.getTime())).append("+UserID=")
                .append(userID).append("+Source=ep").toString();
        String aesKey = FieldOptionList.getName("EP", "EMAP_ENTRY", "AES_KEY");
        String token = new AESHelper(aesKey, true).encryptString(strToken);
        log.debug("Token:" +strToken);
        log.debug("AESToken:" +token);
        log.debug("Request JSON:" + jsonStr);
        Map requestHeader = new HashMap();
        requestHeader.put("token",  token);
        requestHeader.put("Accept", "text/json");
        requestHeader.put("Accept-Charset", "UTF-8");
        long begTime = System.currentTimeMillis();
        Object result = hc.getHttpResponseByJSON(requestURL, requestHeader, jsonStr, HttpResponseType.STRING, "UTF-8");
        long endTime = System.currentTimeMillis();
        log.debug("API:"+requestURL +", �I�s�ɶ�:" + (endTime- begTime) +" ms");
        return (result == null ? null : result.toString());
    }

    /**
     *  �B�zErrorInputException
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getEie(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * �p�G���ȫhsetField
     * @param ds
     * @param key
     * @param reqMap
     */
    private void setFieldIfExist(DataSet ds, String key, Map reqMap) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

}
