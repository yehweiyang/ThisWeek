package com.cathay.ep.z0.module;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.STRING;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * �@�B  �ҲզW�� �j�Ӧ��Ⱥ��@�Ҳ�
 * �Ҳ�ID	EP_Z0G230 
 * ���n����	�j�Ӧ��Ⱥ��@�Ҳ�

 * </pre>
 * @author ������
 * @since 2020/06/08
 */
@SuppressWarnings("unchecked")
public class EP_Z0G230 {

    private static final Logger log = Logger.getLogger(EP_Z0G230.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.z0.module.EP_Z0G230.SQL_queryList_001";

    /**
     * Ū����a���ȩ��ӲM��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G230_MSG_001"));//�ǤJ��T���o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0G230_MSG_002"));//�ǤJ�����q�O���o���ŭ�
            }
        }

        //TODO �̷�Spec 
        List<Map> rtnList = Collections.EMPTY_LIST;
        return rtnList;
    }

    /**
     * �R��
     * @param dataMap
     * @param user
     * @throws Exception
     * @deprecated
     */
    public void delete(Map dataMap, UserObject user) throws Exception {
    	if(true) {
    		throw new UnsupportedOperationException("Deprecated Opearation");
    	}
    }

    /**
     * �פJ��a���ȩ��Ӹ��
     * @param reqMap
     * @param fileItem
     * @param user 
     * @throws IOException 
     * @throws ModuleException 
     * @throws DBException
     * @deprecated  
     */
    public void importFile(Map reqMap, FileItem fileItem, UserObject user) throws IOException, ModuleException, DBException {    
    	if(true) {
    		throw new UnsupportedOperationException("Deprecated Opearation");
    	}
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * SQL�����D���n�Ѽ�
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }

    /**
     *  ���o������T
     * @param DATA_MAP �u�@����T
     * @param FILE_MAP EXCEL�ɮ׸�T
     * @return ������T
     * @throws ModuleException
     * @throws IOException 
     */
    public List<Map> getExcelData(Map reqMap, FileItem fi, UserObject user) throws ModuleException, IOException {
    	if(true) {
    		throw new UnsupportedOperationException("Deprecated Opearation");
    	}
    	return Collections.EMPTY_LIST;
    }

    private ErrorInputException getEie(boolean isPass, String msg, ErrorInputException eie) {
        if (isPass) {
            return eie;
        }
        if (eie == null) {
            return new ErrorInputException(msg);
        }
        eie.appendMessage(msg);
        return eie;
    }

    private ErrorInputException getEieIfNotNumber(Map testMap, String key, ErrorInputException eie) {
        return getEie(STRING.isNumeric(MapUtils.getString(testMap, key, "N")), "��J�Ѽ� [" + key + "] ���o���ŭȥB�������ƭ�", eie);
    }

    private ErrorInputException getEieIfBlank(Map testMap, String key, ErrorInputException eie) {
        return getEie(StringUtils.isNotBlank(MapUtils.getString(testMap, key)), "��J�Ѽ� [" + key + "] ���o���ŭ�", eie);
    }
}
