package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPI101;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE        Description Author
 * 2016/11/14  Created     �_�ɪ�
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ���ո���ɬd�ߺ��@�Ҳ�
 * �Ҳ�ID    EP_Z0I101
 * ���n����    ���ո���ɬd�ߺ��@�Ҳ�
 * </pre>
 * @author �����
 * @since  2016-11-28
 * 
 *[20190703]�t�X�q�l�a�ϱM�׷s�W��kAPI 
 *[20190807]�վ�Ÿm�v�z��B�z�AAPI��J�ƭȬ���ڼƭȫD�ʤ���
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class EP_Z0I101 {
    private static final String SQL_insertDTEPI101_001 = "com.cathay.ep.z0.module.EP_Z0I101.SQL_insertDTEPI101_001";

    private static final String SQL_updateDTEPI101_001 = "com.cathay.ep.z0.module.EP_Z0I101.SQL_updateDTEPI101_001";

    private static final String SQL_updateDTEPI101ByCust_001 = "com.cathay.ep.z0.module.EP_Z0I101.SQL_updateDTEPI101ByCust_001";

    private static final String SQL_deleteDTEPI101_001 = "com.cathay.ep.z0.module.EP_Z0I101.SQL_deleteDTEPI101_001";

    private static final String SQL_queryDTEPI101_001 = "com.cathay.ep.z0.module.EP_Z0I101.SQL_queryDTEPI101_001";

    private static final String SQL_queryLstSn_001 = "com.cathay.ep.z0.module.EP_Z0I101.SQL_queryLstSn_001";

    private static final String SQL_insertDTEPI101_LOG_001 = "com.cathay.ep.z0.module.EP_Z0I101.SQL_insertDTEPI101_LOG_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.z0.module.EP_Z0I101.SQL_queryMap_001";

    private static final String SQL_qrySurveyByBuild_001 = "com.cathay.ep.z0.module.EP_Z0I101.SQL_qrySurveyByBuild_001";

    private static final String SQL_qrySurveyByBuildList_001 = "com.cathay.ep.z0.module.EP_Z0I101.SQL_qrySurveyByBuildList_001";

    /**
     * �s�W���ո�� 
     *          �ѼƦW��   �榡         ����
     * @param   map     Map         ���ո�Ƹ�T
     * @param   user    userObject  �ϥΪ̸�T
     * @throws ModuleException 
     */
    public void insertDTEPI101(Map map, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (map == null || map.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_001"));//���ո�Ƹ�T���o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_002")); //�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = MapUtils.getString(map, "SUB_CPY_ID");//�����q�O
        String INV_CD = MapUtils.getString(map, "INV_CD");//���դj�ӥN��
        String INV_YR = MapUtils.getString(map, "INV_YR");//�~
        String INV_SN = MapUtils.getString(map, "INV_SN");//�u

        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I101_MSG_003"));//�����q�O���o����
        eie = checkStringParam(eie, INV_CD, MessageUtil.getMessage("EP_Z0I101_MSG_004"));//���դj�ӥN�����o����
        eie = checkStringParam(eie, INV_YR, MessageUtil.getMessage("EP_Z0I101_MSG_005"));//�~���o����
        eie = checkStringParam(eie, INV_SN, MessageUtil.getMessage("EP_Z0I101_MSG_006"));//�u���o����
        if (eie != null) {
            throw eie;
        }

        String[] keys1 = new String[] { "SUB_CPY_ID", "INV_CD", "INV_SN", "CUST_IN", "CUST_OUT", "MEMO", "INV_ID", "INV_NAME" };
        String[] keys2 = new String[] { "INV_YR", "EPT_SIZE", "OFFER_AMT", "BASE_AMT", "RNT_PRK_AMT", "EXP_AMT", "RDC_RNT_SIZE",
                "ADD_RNT_SIZE", "SHOP_OFFER_AMT", "SHOP_BASE_AMT" };

        DataSet ds = Transaction.getDataSet();
        for (String key : keys1) {
            if (StringUtils.isBlank(MapUtils.getString(map, key))) {
                ds.setField(key, "");
            } else {
                ds.setField(key, map.get(key));
            }
        }
        for (String key : keys2) {
            if (StringUtils.isBlank(MapUtils.getString(map, key))) {
                ds.setField(key, null);
            } else {
                ds.setField(key, map.get(key));
            }
        }
        ds.setField("CHG_DATE", DATE.currentTime());//���ʤ���ɶ�
        ds.setField("CHG_DIV_NO", user.getDivNo());//���ʳ��
        ds.setField("CHG_ID", user.getEmpID());//���ʤH��ID
        ds.setField("CHG_NAME", user.getEmpName());//���ʤH���m�W

        DBUtil.executeUpdate(ds, SQL_insertDTEPI101_001);
    }

    /**
     * �ק參�ո�� 
     *          �ѼƦW��   �榡         ����
     * @param   map     Map         �򥻸�Ƹ�T
     * @param   user    userObject  �ϥΪ̸�T
     * @throws ModuleException 
     */
    public void updateDTEPI101(Map map, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (map == null || map.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_001"));//���ո�Ƹ�T���o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_002")); //�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = MapUtils.getString(map, "SUB_CPY_ID");
        String INV_CD = MapUtils.getString(map, "INV_CD");
        String INV_YR = MapUtils.getString(map, "INV_YR");
        String INV_SN = MapUtils.getString(map, "INV_SN");
        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I101_MSG_003"));//�����q�O���o����
        eie = checkStringParam(eie, INV_CD, MessageUtil.getMessage("EP_Z0I101_MSG_004"));//���դj�ӥN�����o����
        eie = checkStringParam(eie, INV_YR, MessageUtil.getMessage("EP_Z0I101_MSG_005"));//�~���o����
        eie = checkStringParam(eie, INV_SN, MessageUtil.getMessage("EP_Z0I101_MSG_006"));//�u���o����

        if (eie != null) {
            throw eie;
        }
        //���d�߭n���ʪ���� 
        Map reqMap = new HashMap<String, String>();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("INV_CD", INV_CD);
        reqMap.put("INV_YR", INV_YR);
        reqMap.put("INV_SN", INV_SN);
        Map rtnMap = this.queryMap(reqMap);//���o�n���ʪ����

        //        String[] keys = new String[] { "SUB_CPY_ID", "INV_CD", "INV_YR", "INV_SN", "EPT_SIZE", "OFFER_AMT", "BASE_AMT", "RNT_PRK_AMT",
        //                "EXP_AMT", "RDC_RNT_SIZE", "ADD_RNT_SIZE", "SHOP_OFFER_AMT", "SHOP_BASE_AMT", "CUST_IN", "CUST_OUT", "MEMO", "INV_ID",
        //                "INV_NAME" };
        String[] keys1 = new String[] { "SUB_CPY_ID", "INV_CD", "INV_SN", "CUST_IN", "CUST_OUT", "MEMO", "INV_ID", "INV_NAME" };
        String[] keys2 = new String[] { "INV_YR", "EPT_SIZE", "OFFER_AMT", "BASE_AMT", "RNT_PRK_AMT", "EXP_AMT", "RDC_RNT_SIZE",
                "ADD_RNT_SIZE", "SHOP_OFFER_AMT", "SHOP_BASE_AMT" };

        //�N���ʫe����ƥ��s�W��DTEPI101_LOG   
        DataSet ds = Transaction.getDataSet();
        //        for (String key : keys) {
        //            ds.setField(key, rtnMap.get(key));
        //        }
        for (String key : keys1) {
            if (StringUtils.isBlank(MapUtils.getString(rtnMap, key))) {
                ds.setField(key, "");
            } else {
                ds.setField(key, rtnMap.get(key));
            }
        }
        for (String key : keys2) {
            if (StringUtils.isBlank(MapUtils.getString(rtnMap, key))) {
                ds.setField(key, null);
            } else {
                ds.setField(key, rtnMap.get(key));
            }
        }
        ds.setField("CHG_DATE", rtnMap.get("CHG_DATE"));
        ds.setField("CHG_DIV_NO", rtnMap.get("CHG_DIV_NO"));
        ds.setField("CHG_ID", rtnMap.get("CHG_ID"));
        ds.setField("CHG_NAME", rtnMap.get("CHG_NAME"));
        ds.setField("UPD_DATE", DATE.currentTime());//�J�ɤ���ɶ�
        ds.setField("UPD_TYPE", "U");
        ds.setField("UPD_DIV_NO", user.getDivNo()); //LOG���ʤH�����N��
        ds.setField("UPD_ID", user.getEmpID());//LOG���ʤH��ID 
        ds.setField("UPD_NAME", user.getEmpName());//LOG���ʤH���m�W 

        DBUtil.executeUpdate(ds, SQL_insertDTEPI101_LOG_001);

        //���ʫe����Ʒs�W��LOG��A�~��sDTEPI101�����
        ds.clear();
        //        for (String key : keys) {
        //            ds.setField(key, map.get(key));
        //        }
        for (String key : keys1) {
            if (StringUtils.isBlank(MapUtils.getString(map, key))) {
                ds.setField(key, "");
            } else {
                ds.setField(key, map.get(key));
            }
        }
        for (String key : keys2) {
            if (StringUtils.isBlank(MapUtils.getString(map, key))) {
                ds.setField(key, null);
            } else {
                ds.setField(key, map.get(key));
            }
        }
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getDivNo());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());

        DBUtil.executeUpdate(ds, SQL_updateDTEPI101_001);

    }

    /**
     * �ק參�ո�Ƥ��Ȥ�y�ʸ��
     *          �ѼƦW��   �榡         ����
     * @param   map     Map         ���ո�Ƹ�T
     * @param   user    userObject  �ϥΪ̸�T
     * @throws ModuleException 
     */
    public void updateDTEPI101ByCust(Map map, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (map == null || map.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_001"));//���ո�Ƹ�T���o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_002")); //�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = MapUtils.getString(map, "SUB_CPY_ID");
        String INV_CD = MapUtils.getString(map, "INV_CD");
        String INV_YR = MapUtils.getString(map, "INV_YR");
        String INV_SN = MapUtils.getString(map, "INV_SN");
        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I101_MSG_003"));//�����q�O���o����
        eie = checkStringParam(eie, INV_CD, MessageUtil.getMessage("EP_Z0I101_MSG_004"));//���դj�ӥN�����o����
        eie = checkStringParam(eie, INV_YR, MessageUtil.getMessage("EP_Z0I101_MSG_005"));//�~���o����
        eie = checkStringParam(eie, INV_SN, MessageUtil.getMessage("EP_Z0I101_MSG_006"));//�u���o����
        if (eie != null) {
            throw eie;
        }

        //���d�߭n���ʪ���� 
        Map reqMap = new HashMap<String, String>();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("INV_CD", INV_CD);
        reqMap.put("INV_YR", INV_YR);
        reqMap.put("INV_SN", INV_SN);
        Map rtnMap = this.queryMap(reqMap);//���o�n���ʪ����

        //        String[] keys = new String[] { "SUB_CPY_ID", "INV_CD", "INV_YR", "INV_SN", "EPT_SIZE", "OFFER_AMT", "BASE_AMT", "RNT_PRK_AMT",
        //                "EXP_AMT", "RDC_RNT_SIZE", "ADD_RNT_SIZE", "SHOP_OFFER_AMT", "SHOP_BASE_AMT", "CUST_IN", "CUST_OUT", "MEMO", "INV_ID",
        //                "INV_NAME", "CHG_DATE", "CHG_DIV_NO", "CHG_ID", "CHG_NAME" };

        String[] keys1 = new String[] { "SUB_CPY_ID", "INV_CD", "INV_SN", "CUST_IN", "CUST_OUT", "MEMO", "INV_ID", "INV_NAME",
                "CHG_DIV_NO", "CHG_ID", "CHG_NAME" };
        String[] keys2 = new String[] { "INV_YR", "EPT_SIZE", "OFFER_AMT", "BASE_AMT", "RNT_PRK_AMT", "EXP_AMT", "RDC_RNT_SIZE",
                "ADD_RNT_SIZE", "SHOP_OFFER_AMT", "SHOP_BASE_AMT", "CHG_DATE" };

        //�N�n���ʪ���Ʒs�W��DTEPI100_LOG
        DataSet ds = Transaction.getDataSet();
        //        for (String key : keys) {
        //            ds.setField(key, rtnMap.get(key));
        //        }
        for (String key : keys1) {
            if (StringUtils.isBlank(MapUtils.getString(rtnMap, key))) {
                ds.setField(key, "");
            } else {
                ds.setField(key, rtnMap.get(key));
            }
        }
        for (String key : keys2) {
            if (StringUtils.isBlank(MapUtils.getString(rtnMap, key))) {
                ds.setField(key, null);
            } else {
                ds.setField(key, rtnMap.get(key));
            }
        }
        ds.setField("UPD_DATE", DATE.currentTime());//�J�ɤ���ɶ�
        ds.setField("UPD_TYPE", "U");
        ds.setField("UPD_DIV_NO", user.getDivNo()); //LOG���ʤH�����N��
        ds.setField("UPD_ID", user.getEmpID());//LOG���ʤH��ID 
        ds.setField("UPD_NAME", user.getEmpName());//LOG���ʤH���m�W 
        DBUtil.executeUpdate(ds, SQL_insertDTEPI101_LOG_001);

        //�ק參�ո�Ƥ��Ȥ�y�ʸ��
        String[] keyss1 = new String[] { "SUB_CPY_ID", "INV_CD", "INV_SN", "CUST_IN", "CUST_OUT", "MEMO", "INV_ID", "INV_NAME" };
        String[] keyss2 = new String[] { "INV_YR", "RDC_RNT_SIZE", "ADD_RNT_SIZE" };
        ds.clear();
        //        for (String key : keyss) {
        //            ds.setField(key, map.get(key));
        //        }
        for (String key : keyss1) {
            if (StringUtils.isBlank(MapUtils.getString(map, key))) {
                ds.setField(key, "");
            } else {
                ds.setField(key, map.get(key));
            }
        }
        for (String key : keyss2) {
            if (StringUtils.isBlank(MapUtils.getString(map, key))) {
                ds.setField(key, null);
            } else {
                ds.setField(key, map.get(key));
            }
        }
        ds.setField("CHG_DATE", DATE.currentTime());
        ds.setField("CHG_DIV_NO", user.getDivNo());
        ds.setField("CHG_ID", user.getEmpID());
        ds.setField("CHG_NAME", user.getEmpName());
        DBUtil.executeUpdate(ds, SQL_updateDTEPI101ByCust_001);
    }

    /**
     * �R�����ո��
     *          �ѼƦW��   �榡         ����
     * @param   map     Map         ���ո�Ƹ�T
     * @param   user    userObject  �ϥΪ̸�T
     * @throws ModuleException 
     */
    public void deleteDTEPI101(Map map, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (map == null || map.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_001"));//���ո�Ƹ�T���o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_002")); //�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = MapUtils.getString(map, "SUB_CPY_ID");
        String INV_CD = MapUtils.getString(map, "INV_CD");
        String INV_YR = MapUtils.getString(map, "INV_YR");
        String INV_SN = MapUtils.getString(map, "INV_SN");

        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I101_MSG_003"));//�����q�O���o����
        eie = checkStringParam(eie, INV_CD, MessageUtil.getMessage("EP_Z0I101_MSG_004"));//���դj�ӥN�����o����

        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        //���d�߭n���ʪ���� 
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INV_CD", INV_CD);
        if (StringUtils.isNotBlank(INV_YR)) {
            ds.setField("INV_YR", INV_YR);
        }
        if (StringUtils.isNotBlank(INV_SN)) {
            ds.setField("INV_SN", INV_SN);
        }
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001);

        String[] keys1 = new String[] { "SUB_CPY_ID", "INV_CD", "INV_SN", "CUST_IN", "CUST_OUT", "MEMO", "INV_ID", "INV_NAME",
                "CHG_DIV_NO", "CHG_ID", "CHG_NAME" };
        String[] keys2 = new String[] { "INV_YR", "EPT_SIZE", "OFFER_AMT", "BASE_AMT", "RNT_PRK_AMT", "EXP_AMT", "RDC_RNT_SIZE",
                "ADD_RNT_SIZE", "SHOP_OFFER_AMT", "SHOP_BASE_AMT", "CHG_DATE" };

        ds.clear();
        //�N�n���ʪ���Ʒs�W��DTEPI100_LOG
        //        for (String key : keys) {
        //            ds.setField(key, rtnMap.get(key));
        //        }
        for (String key : keys1) {
            if (StringUtils.isBlank(MapUtils.getString(rtnMap, key))) {
                ds.setField(key, "");
            } else {
                ds.setField(key, rtnMap.get(key));
            }
        }
        for (String key : keys2) {
            if (StringUtils.isBlank(MapUtils.getString(rtnMap, key))) {
                ds.setField(key, null);
            } else {
                ds.setField(key, rtnMap.get(key));
            }
        }
        ds.setField("UPD_DATE", DATE.currentTime());//�J�ɤ���ɶ�
        ds.setField("UPD_TYPE", "D");
        ds.setField("UPD_DIV_NO", user.getDivNo()); //LOG���ʤH�����N��
        ds.setField("UPD_ID", user.getEmpID());//LOG���ʤH��ID 
        ds.setField("UPD_NAME", user.getEmpName());//LOG���ʤH���m�W 
        DBUtil.executeUpdate(ds, SQL_insertDTEPI101_LOG_001);

        //�}�l�R�����
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INV_CD", INV_CD);

        if (StringUtils.isNotBlank(INV_YR)) {
            ds.setField("INV_YR", INV_YR);
        }
        if (StringUtils.isNotBlank(INV_SN)) {
            ds.setField("INV_SN", INV_SN);
        }

        DBUtil.executeUpdate(ds, SQL_deleteDTEPI101_001);
    }

    /**
     * �d�ߥ��ո��
     *          �ѼƦW��   �榡         ����
     * @param   Map      Map      
     * @return  rtnList  List<Map>  ���ո�Ʃ���   
     * @throws ModuleException 
     */
    public List<Map> queryDTEPI101(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I101_MSG_001"));//���ո�Ƹ�T���o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I101_MSG_003"));//�����q�O���o����

        if (eie != null) {
            throw eie;
        }
        String[] keys = new String[] { "SUB_CPY_ID", "INV_CD", "INV_YR", "INV_SN" };
        DataSet ds = Transaction.getDataSet();
        for (String key : keys) {

            String Stringkey = MapUtils.getString(reqMap, key);

            if (StringUtils.isNotEmpty(Stringkey)) {
                ds.setField(key, reqMap.get(key));
            }
        }

        DBUtil.searchAndRetrieve(ds, SQL_queryDTEPI101_001);
        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map map = VOTool.dataSetToMap(ds);
            String INV_SN = MapUtils.getString(map, "INV_SN");
            map.put("INV_SN_NM", FieldOptionList.getName("EP", "I1_INV_SN", INV_SN)); //�u����
            rtnList.add(map);
        }

        return rtnList;
    }

    /**
     * �d�ߥ��ո��
     *          �ѼƦW��   �榡         ����
     * @param   Map      Map      
     * @return  rtnList  List<Map>  ���ո�Ʃ���   
     * @throws ModuleException 
     */
    public DTEPI101 queryLstSn(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I101_MSG_001"));//���ո�Ƹ�T���o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String INV_CD = MapUtils.getString(reqMap, "INV_CD");
        String INV_SN = MapUtils.getString(reqMap, "INV_SN");
        String INV_YR_vaild = MapUtils.getString(reqMap, "INV_YR");
        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_Z0I101_MSG_003"));//�����q�O���o����
        eie = checkStringParam(eie, INV_CD, MessageUtil.getMessage("EP_Z0I101_MSG_004"));//���դj�ӥN�����o����
        eie = checkStringParam(eie, INV_YR_vaild, MessageUtil.getMessage("EP_Z0I101_MSG_005"));//�~���o����
        eie = checkStringParam(eie, INV_SN, MessageUtil.getMessage("EP_Z0I101_MSG_006"));//�u���o����

        if (eie != null) {
            throw eie;
        }
        //�@��C�u�@�@�����աA�G��C�b�~�@�@������
        //�ҥH�W�u���ո�Ƨ��̪񥫽ո��
        Integer INV_YR = MapUtils.getInteger(reqMap, "INV_YR");
        Integer IntINV_SN = MapUtils.getInteger(reqMap, "INV_SN");
        //        if (IntINV_SN == 1) { //Q1
        //            IntINV_SN = 4; //Q4
        //            INV_YR = INV_YR - 1;
        //        } else {
        //            IntINV_SN = IntINV_SN - 1;
        //        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INV_CD", INV_CD);
        ds.setField("INV_YR", INV_YR);
        ds.setField("INV_SN", IntINV_SN);

        return VOTool.findOneToVO(DTEPI101.class, ds, SQL_queryLstSn_001);
    }

    /**
     * [20190703] ���դj�ӳ̪�3�~���ո�Ƭd��API
     * @param reqMap
     * @return
     * @throws ModuleException 
     */
    public List<Map> qrySurveyByBuild(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I101_MSG_007"));//��JreqMap���i����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_003"));//�����q�O���o����
        }
        String INV_CD = MapUtils.getString(reqMap, "INV_CD");
        if (StringUtils.isBlank(INV_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_004"));//���դj�ӥN�����o����
        }
        if (eie != null) {
            throw eie;
        }

        int MIN_INV_YR = Calendar.getInstance().get(Calendar.YEAR) - 1911 - 3;

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INV_CD", INV_CD);
        ds.setField("MIN_INV_YR", MIN_INV_YR);
        DBUtil.searchAndRetrieve(ds, SQL_qrySurveyByBuild_001);

        //���o�d�߰϶�(��T�~)
        String[] qryPeriod = this.queryPeriod(3);

        List<Map> rtnList = new ArrayList<Map>();

        StringBuilder sb = new StringBuilder();

        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            int INV_YR = MapUtils.getIntValue(rtnMap, "INV_YR") + 1911;
            sb.setLength(0);
            String invYRSN = sb.append(Integer.toString(INV_YR)).append('Q').append(MapUtils.getString(rtnMap, "INV_SN")).toString();
            //�p�G���b�϶����ܫh���^��
            if (invYRSN.compareTo(qryPeriod[0]) < 0 || invYRSN.compareTo(qryPeriod[1]) > 0) {
                continue;
            }
            BigDecimal EPT_SIZE_BD = STRING.objToBigDecimal(rtnMap.get("EPT_SIZE"), BigDecimal.ZERO);
            BigDecimal RNT_SIZE_BD = STRING.objToBigDecimal(rtnMap.get("RNT_SIZE"), BigDecimal.ONE);
            //EPT_RT �Ÿm�v  = EPT_SIZE / RNT_SIZE,�|�ˤ��J��p���I�Ĥ���
            rtnMap.put("EPT_RT", EPT_SIZE_BD.divide(RNT_SIZE_BD, 5, RoundingMode.HALF_UP).toPlainString());
            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * [20190703] ���զ污�d��API
     * @param reqMap
     * @param MKT_BLD_LIST ���դj�ӽs���M��
     * @return
     * @throws ModuleException
     */
    public List<Map> qrySurveyByBuildList(Map reqMap, List<String> MKT_BLD_LIST) throws ModuleException {
        return this.qrySurveyByBuildList(reqMap, MKT_BLD_LIST, null, false, 0, 0, false);
    }

    /**
     * [20190704] ���զ污�d��API(�u����)
     * @param reqMap
     * @param MKT_BLD_LIST
     * @param resp
     * @param isFirstQuery
     * @param startWith
     * @param endWith
     * @param isPrint
     * @return
     * @throws ModuleException
     */
    public List<Map> qrySurveyByBuildList(Map reqMap, List<String> MKT_BLD_LIST, ResponseContext resp, boolean isFirstQuery, int startWith,
            int endWith, boolean isPrint) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I101_MSG_007"));//��JreqMap���i����
        }
        //�u���e���W�d�߬O�u����,�Φ��P�_�O API call �٬O�����d�� 
        boolean isFetch = resp != null;

        if (!isFetch && !isPrint) {
            //�u��API call �~�|�j�ӽs���M��Ѽ�
            if (MKT_BLD_LIST == null || MKT_BLD_LIST.isEmpty()) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I101_MSG_015"));//��J���դj�ӽs���M��(MKT_BLD_LIST)���i����
            }
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_003"));//�����q�O���o����
        }
        String INV_YR_BEG = MapUtils.getString(reqMap, "INV_YR_BEG");
        if (StringUtils.isBlank(INV_YR_BEG) || !StringUtils.isNumeric(INV_YR_BEG)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_008"));//��J�~�װ_�l��(INV_YR_BEG)���i���ũΫD�Ʀr
        }
        String INV_YR_END = MapUtils.getString(reqMap, "INV_YR_END");
        if (StringUtils.isBlank(INV_YR_END) || !StringUtils.isNumeric(INV_YR_END)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0I101_MSG_009"));//��J�~�׵�����(INV_YR_END)���i���ũΫD�Ʀr
        }
        if (eie != null) {
            throw eie;
        }
        if (INV_YR_BEG.compareTo(INV_YR_END) > 0) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I101_MSG_010"));//�~�װ_�l�Ȥ���j�󵲧���
        }

        DataSet ds = Transaction.getDataSet();

        if (isFetch || isPrint) {
            //�u���e���d�ߤ~�|�����Ѽ�
            this.setFieldIfExist(reqMap, "TOWN", ds);//��F��
            this.setFieldIfExist(reqMap, "OFC_CLS", ds);//�줽����
            this.setFieldIfExist(reqMap, "BLD_KD", ds);//�c�y
            this.setFieldIfExist(reqMap, "ZONE_CD", ds);//���հϰ�
            String CITY_CD = MapUtils.getString(reqMap, "CITY_CD");
            if (StringUtils.isNotBlank(CITY_CD)) {
                ds.setField("CITY", FieldOptionList.getName("EP", "I1_CITY_CD", CITY_CD));
            }
            //����
            String HOUSE_AGE_LOW = MapUtils.getString(reqMap, "HOUSE_AGE_LOW");
            String HOUSE_AGE_HIGH = MapUtils.getString(reqMap, "HOUSE_AGE_HIGH");

            if (StringUtils.isNotBlank(HOUSE_AGE_HIGH) && StringUtils.isNumeric(HOUSE_AGE_HIGH)) {
                //�Y HOUSE_AGE_HIGH ���� , BLD_END_DATE_STR = �t�Τ�� - HOUSE_AGE_HIGH �~
                String BLD_END_DATE_STR = DATE.addDate(DATE.getDBDate(), Integer.parseInt(HOUSE_AGE_HIGH) * (-1), 0, 0);
                ds.setField("BLD_END_DATE_STR", BLD_END_DATE_STR);
            }
            if (StringUtils.isNotBlank(HOUSE_AGE_LOW) && StringUtils.isNumeric(HOUSE_AGE_LOW)) {
                //�Y HOUSE_AGE_LOW ���� , BLD_END_DATE_END = �t�Τ�� - HOUSE_AGE_LOW �~
                String BLD_END_DATE_END = DATE.addDate(DATE.getDBDate(), Integer.parseInt(HOUSE_AGE_LOW) * (-1), 0, 0);
                ds.setField("BLD_END_DATE_END", BLD_END_DATE_END);
            }
            //�Y�O�d�ߤ~�ίu����,�ץX�h����
            if (isFetch) {
                ds.setFetchRange(startWith, endWith);
            }

        } else {
            //�u��API call �~�|�����Ѽ�
            ds.setFieldValues("MKT_BLD_LIST", MKT_BLD_LIST);
        }

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INV_YR_BEG", Integer.parseInt(INV_YR_BEG) - 1911);//�ഫ����~
        ds.setField("INV_YR_END", Integer.parseInt(INV_YR_END) - 1911);//�ഫ����~

        String BASE_AMT_LOW = MapUtils.getString(reqMap, "BASE_AMT_LOW");//���������̧C��
        boolean isBASE_AMT_LOW = StringUtils.isNotBlank(BASE_AMT_LOW);
        String BASE_AMT_HIGH = MapUtils.getString(reqMap, "BASE_AMT_HIGH");//���������̰���
        boolean isBASE_AMT_HIGH = StringUtils.isNotBlank(BASE_AMT_HIGH);

        //�˦X���������O�_���Ʀr
        //[20190802] �令���ΦP�ɿ�J,���}�ˮ֦s�b�M�O�_���Ʀr
        if ((isBASE_AMT_HIGH && !StringUtils.isNumeric(BASE_AMT_HIGH)) || (isBASE_AMT_LOW && !StringUtils.isNumeric(BASE_AMT_LOW))) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I101_MSG_016"));//���������ݬ��Ʀr
        }
        //[20190802] �p�G�̰��̧C�Ȧ��P�ɿ�J�h�ˮ֤j�p���Y
        if (isBASE_AMT_LOW && isBASE_AMT_HIGH) {
            if (this.CompareBD(BASE_AMT_LOW, BASE_AMT_HIGH) > 0) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I101_MSG_012"));//���������̧C�ȻݧC��̰���
            }
        }
        if (isBASE_AMT_LOW) {
            ds.setField("BASE_AMT_LOW", BASE_AMT_LOW);
        }
        if (isBASE_AMT_HIGH) {
            ds.setField("BASE_AMT_HIGH", BASE_AMT_HIGH);
        }

        String EPT_RT_LOW = MapUtils.getString(reqMap, "EPT_RT_LOW");//�Ÿm�v�̧C��
        boolean isEPT_RT_LOW = StringUtils.isNotBlank(EPT_RT_LOW);
        String EPT_RT_HIGH = MapUtils.getString(reqMap, "EPT_RT_HIGH");//�Ÿm�v�̰���
        boolean isEPT_RT_HIGH = StringUtils.isNotBlank(EPT_RT_HIGH);

        //�p�G�Ÿm�v�W���ΤU���s�b����,�ˮ֬O�_���Ʀr
        if ((isEPT_RT_LOW && !NumberUtils.isNumber(EPT_RT_LOW)) || (isEPT_RT_HIGH && !NumberUtils.isNumber(EPT_RT_HIGH))) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I101_MSG_017"));//�Ÿm�v�ݬ��Ʀr
        }
        //�p�G�Ÿm�v�W���M�U�����s�b,�ˮ֤j�p���Y
        if (isEPT_RT_LOW && isEPT_RT_HIGH) {
            if (this.CompareBD(EPT_RT_LOW, EPT_RT_HIGH) > 0) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_Z0I101_MSG_014"));//�Ÿm�v�̧C�ȻݧC��̰���
            }
        }
        BigDecimal BD_100 = new BigDecimal("100");
        //[20190807]�վ�Ÿm�v�z��B�z�AAPI��J�ƭȬ���ڼƭȫD�ʤ���
        BigDecimal bdEPT_RT_HIGH = STRING.objToBigDecimal(EPT_RT_HIGH, BigDecimal.ONE);
        BigDecimal bdEPT_RT_LOW = STRING.objToBigDecimal(EPT_RT_LOW, BigDecimal.ZERO);
        DBUtil.searchAndRetrieve(ds, SQL_qrySurveyByBuildList_001);

        List<Map> rtnList = new ArrayList<Map>();

        Map OFC_CLS_Map = FieldOptionList.getFieldOptions("EP", "I1_OFC_CLS");

        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            BigDecimal EPT_SIZE = STRING.objToBigDecimal(rtnMap.get("EPT_SIZE"), BigDecimal.ZERO);
            BigDecimal RNT_SIZE = STRING.objToBigDecimal(rtnMap.get("RNT_SIZE"), BigDecimal.ONE);
            //EPT_RT �Ÿm�v =  EPT_SIZE /  RNT_SIZE�A�|�ˤ��J��p���I�Ĥ��줭�J��p���I�Ĥ���
            BigDecimal EPT_RT = EPT_SIZE.divide(RNT_SIZE, 5, RoundingMode.HALF_UP);
            //�p�G�n�L�o�Ÿm�v,�åB�Ÿm�v�S���b�϶����h���L
            //�p�G����JEPT_RT_HIGH , EPT_RT ����W�����h���L
            if (isEPT_RT_HIGH && (EPT_RT.compareTo(bdEPT_RT_HIGH) > 0)) {
                continue;
            }
            //�p�G����JEPT_RT_LOW , EPT_RT �C��U�����h���L
            if ((isEPT_RT_LOW && EPT_RT.compareTo(bdEPT_RT_LOW) < 0)) {
                continue;
            }
            //[20190708] �t�X�e����ܸ�ץX�B�z�ʤ���
            if (isFetch || isPrint) {
                rtnMap.put("EPT_RT", EPT_RT.multiply(BD_100).setScale(2, RoundingMode.HALF_UP).toPlainString() + '%');
            } else {
                rtnMap.put("EPT_RT", EPT_RT);
            }
            int INV_YR = MapUtils.getIntValue(rtnMap, "INV_YR") + 1911;
            rtnMap.put("INV_YR", INV_YR);
            String CITY_CD_CODE = "I1_ZONE_CD_" + MapUtils.getString(rtnMap, "CITY_CD");
            //���հϰ�W��
            rtnMap.put("ZONE_CD_NM", FieldOptionList.getName("EP", CITY_CD_CODE, MapUtils.getString(rtnMap, "ZONE_CD")));
            //�줽�ǵ��ŦW��
            rtnMap.put("OFC_CLS_NM", OFC_CLS_Map.get(MapUtils.getString(rtnMap, "OFC_CLS")));
            //[20190802] �s�W��ܤj�Ӻc�y
            rtnMap.put("BLD_KD_NM", FieldOptionList.getName("EP", "I1_BLD_KD", MapUtils.getString(rtnMap, "BLD_KD")));

            rtnList.add(rtnMap);
        }

        if (isFetch && isFirstQuery) {
            resp.addOutputData("totalOfRecords", ds.getQueryTotalCount());
        }

        return rtnList;
    }

    /**
     * [20190703] �p��d�߰϶�
     * @param lastNY(�p��~�϶�)
     * @return
     */
    public String[] queryPeriod(int lastNY) {
        Date dd = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dd);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int season = month / 4 + 1;

        if (season == 1) {
            String endYS = (year - 1) + "Q4";
            String begYS = (year - lastNY) + "Q1";
            return new String[] { begYS, endYS };

        } else {
            String endYS = (year) + "Q" + (season - 1);
            String begYS = (year - lastNY) + "Q" + (season);
            return new String[] { begYS, endYS };
        }
    }

    /**
     * �s�WLOG�ɨϥάd�߸��
     * @param reqMap
     * @return Map
     */
    private Map queryMap(Map reqMap) throws ModuleException {

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", reqMap.get("SUB_CPY_ID"));
        ds.setField("INV_CD", reqMap.get("INV_CD"));
        ds.setField("INV_YR", reqMap.get("INV_YR"));
        ds.setField("INV_SN", reqMap.get("INV_SN"));
        return VOTool.findOneToMap(ds, SQL_queryMap_001);

    }

    /**
     * [20190703] ����j�p
     * @param str1
     * @param str2
     * @return
     */
    private int CompareBD(String str1, String str2) {
        BigDecimal BD1 = STRING.objToBigDecimal(str1, BigDecimal.ZERO);
        BigDecimal BD2 = STRING.objToBigDecimal(str2, BigDecimal.ZERO);
        return BD1.compareTo(BD2);
    }

    /**
     * [20190703]�Y�Ȧs�b�~���
     * @param reqMap
     * @param key
     * @param ds
     */
    private void setFieldIfExist(Map reqMap, String key, DataSet ds) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * 
     * @param eie
     * @param parameter
     * @param errMsg
     * @return
     */
    private ErrorInputException checkStringParam(ErrorInputException eie, String parameter, String errMsg) {
        if (StringUtils.isBlank(parameter)) {
            if (eie == null) {
                eie = new ErrorInputException();
            }
            eie.appendMessage(errMsg);
        }
        return eie;
    }

    /**
     * 
     * @param eie
     * @param parameter
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
