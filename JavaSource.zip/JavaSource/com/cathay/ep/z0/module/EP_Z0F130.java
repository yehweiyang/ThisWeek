package com.cathay.ep.z0.module;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.EmployeeDetail;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.f1.module.EP_F10310;
import com.cathay.ep.vo.DTEPF120;
import com.cathay.ep.vo.DTEPF130;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * DATE Description Author
2014/08/15  Created ����i
�@�B  �{���\�෧�n�����G
�ҲզW��    �u�{�������@�Ҳ�
�Ҳ�ID    EP_F10103
���n����    �u�{�������@�Ҳ�
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EP_Z0F130 {
    private static final String SQL_queryF130List_001 = "com.cathay.ep.z0.module.EP_Z0F130.SQL_queryF130List_001";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0F130.SQL_insert_001";

    private static final String SQL_deleteByUpload_001 = "com.cathay.ep.z0.module.EP_Z0F130.SQL_deleteByUpload_001";

    private static final String SQL_getMaxPRO_NO_001 = "com.cathay.ep.z0.module.EP_Z0F130.SQL_getMaxPRO_NO_001";

    private static final String SQL_updateConsDate_001 = "com.cathay.ep.z0.module.EP_Z0F130.SQL_updateConsDate_001";

    private static final String SQL_updateFinalDate_001 = "com.cathay.ep.z0.module.EP_Z0F130.SQL_updateFinalDate_001";

    /**
     * Ū����µ�ץ�_�u�{�����ɲM��
     * @param F130Vo
     * @return
     * @throws Exception
     */
    public List<Map> queryF130List(DTEPF130 F130Vo) throws Exception {
        return queryF130List(F130Vo, false, null, false, 0, 0, null);
    }

    /**
     * Ū����µ�ץ�_�u�{�����ɲM��
     * @param F130Vo
     * @return
     * @throws Exception
     */
    public List<Map> queryF130List(DTEPF130 F130Vo, boolean isReal, ResponseContext resp, boolean isFirstQuery, Integer startWith,
            Integer endWith, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String APLY_NO = "";
        String SUB_CPY_ID = "";
        if (F130Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_F10103_MSG_001"));//��µ�ץ�_�u�{�����ɤ��i���� 
        } else {
            APLY_NO = F130Vo.getAPLY_NO();
            SUB_CPY_ID = F130Vo.getSUB_CPY_ID();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_002")); //�ǤJ�����q�O����!
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_003")); //�ǤJ�ץ�s�����i����!
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�H�����q�O�ζǤJ�ѼƬd�߭�µ�ץ�_�u�{������(DTEPF130)�G
        DataSet ds = Transaction.getDataSet();
        if (StringUtils.isNotBlank(APLY_NO) && APLY_NO.length() == 6) {
            APLY_NO = APLY_NO + "%";
        }
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (F130Vo.getMEMO_NO() != null) {
            ds.setField("MEMO_NO", F130Vo.getMEMO_NO());
        }
        if (F130Vo.getPRO_NO() != null) {
            ds.setField("PRO_NO", F130Vo.getPRO_NO());
        }
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        if (F130Vo.getCONS_SDATE() != null) {
            ds.setField("CONS_SDATE", df.format(F130Vo.getCONS_SDATE()));
        }
        if (F130Vo.getCONS_EDATE() != null) {
            ds.setField("CONS_EDATE", df.format(F130Vo.getCONS_EDATE()));
        }
        if (F130Vo.getPRO_NO() != null) {
            ds.setField("PRO_NO", F130Vo.getPRO_NO());
        }

        setFieldIfExist(ds, F130Vo.getPROJECT_TP(), "PROJECT_TP");
        setFieldIfExist(ds, F130Vo.getSUP_ID(), "SUP_ID");
        setFieldIfExist(ds, F130Vo.getIS_CONT(), "IS_CONT");
        setFieldIfExist(ds, F130Vo.getPRO_OWN(), "PRO_OWN");
        setFieldIfExist(ds, F130Vo.getCONT_NO(), "CONT_NO");

        if (isReal) {
            ds.setFetchRange(startWith, endWith);//�u�����\�� �_����ƦC �]�w
        }

        DBUtil.searchAndRetrieve(ds, SQL_queryF130List_001);

        if (isReal && isFirstQuery) {
            resp.addOutputData("totalOfRecords", ds.getQueryTotalCount()); // ���o-�`����,�u�����\��T�w�ѼƦW��
        }

        List<Map> rtnList = new ArrayList();
        EP_Z0F110 theEP_Z0F110 = new EP_Z0F110();
        EP_F10310 theEP_F10310 = new EP_F10310();
        PersonnelData pd = new PersonnelData();
        ReturnMessage rm = new ReturnMessage();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //�t�ӦW��
            String SUP_ID = MapUtils.getString(rtnMap, "SUP_ID");
            if (StringUtils.isNotBlank(SUP_ID)) {
                try {
                    rtnMap.put("SUP_NM", theEP_Z0F110.setSUP_NM(SUP_ID));
                } catch (Exception e) {
                    rtnMap.put("SUP_NM", "");
                }
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(MessageUtil.getMessage("EP_F10103_MSG_004"));//���o�t�ӦW�ٸ��o�Ϳ��~
                }
            } else {
                rtnMap.put("SUP_NM", "");
            }

            //�u�{�k��
            rtnMap.put("PRO_OWN_NM", FieldOptionList.getName("EP", "PRO_OWN", MapUtils.getString(rtnMap, "PRO_OWN")));
            //�X����
            rtnMap.put("IS_CONT_NM", FieldOptionList.getName("EP", "IS_CONT", MapUtils.getString(rtnMap, "IS_CONT")));

            String LST_PROC_DIV = MapUtils.getString(rtnMap, "LST_PROC_DIV");
            String LST_PROC_ID = MapUtils.getString(rtnMap, "LST_PROC_ID");
            if (StringUtils.isNotEmpty(LST_PROC_DIV)) {
                if (LST_PROC_DIV.startsWith("EP9")) {
                    Map empMap;
                    try {
                        empMap = theEP_F10310.getEmpMap(LST_PROC_ID, true, SUB_CPY_ID);
                        rtnMap.put("LST_PROC_NM", empMap.get("NAME"));
                        rtnMap.put("LST_PROC_DIV_NM", empMap.get("DIV_SHORT_NAME"));
                    } catch (Exception e) {
                        rtnMap.put("LST_PROC_NM", "�L���H��");
                        rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                    }
                } else {
                    EmployeeDetail emp;
                    try {
                        emp = pd.getByEmployeeID2(LST_PROC_ID);
                        if (emp != null) {
                            rtnMap.put("LST_PROC_NM", emp.getName());
                            rtnMap.put("LST_PROC_DIV_NM", pd.getByEmployeeID(LST_PROC_ID).getDivShortName());
                        } else {
                            rtnMap.put("LST_PROC_NM", "�L���H��");
                            rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                        }
                    } catch (SQLException e) {
                        rtnMap.put("LST_PROC_NM", "�L���H��");
                        rtnMap.put("LST_PROC_DIV_NM", "�L�����");
                    }
                }
            }

            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * �s�W��µ�ץ�_�u�{�������
     * @param F130Vo
     * @param user
     * @throws ModuleException
     */
    public int insert(DTEPF130 F130Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        String APLY_NO = "";
        String SUB_CPY_ID = "";
        Integer MEMO_NO = null;
        if (F130Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_001"));//��µ�ץ�_�u�{�����ɤ��i���� 
        } else {
            APLY_NO = F130Vo.getAPLY_NO();
            MEMO_NO = F130Vo.getMEMO_NO();
            SUB_CPY_ID = F130Vo.getSUB_CPY_ID();
            if (MEMO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_005")); //�Ƨѿ��渹���i����!
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_003")); //�ǤJ�ץ�s�����i����!
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_006"));//�ǤJ�ϥΪ̸�T���i���� 
        }
        if (eie != null) {
            throw eie;
        }
        //�s�W��µ�ץ�_�u�{������DTEPF130�G
        //���o���u�اǸ����̤j�u�اǸ�+1
        int PRO_NO = getMaxPRO_NO(F130Vo);
        F130Vo.setPRO_NO(PRO_NO);
        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("MEMO_NO", MEMO_NO);
        ds.setField("PRO_NO", F130Vo.getPRO_NO());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("PROJECT_TP", F130Vo.getPROJECT_TP());
        ds.setField("WAR_MON", F130Vo.getWAR_MON());
        ds.setField("CNT", F130Vo.getCNT());
        ds.setField("UNIT", F130Vo.getUNIT());
        ds.setField("PRICE", F130Vo.getPRICE());
        ds.setField("EST_AMT", ObjectUtils.toString(F130Vo.getEST_AMT(), "0"));
        ds.setField("SUP_ID", F130Vo.getSUP_ID());
        ds.setField("CLR_AMT", ObjectUtils.toString(F130Vo.getCLR_AMT(), "0"));
        ds.setField("ACT_AMT", ObjectUtils.toString(F130Vo.getACT_AMT(), "0"));
        ds.setField("PR_AMT", ObjectUtils.toString(F130Vo.getPR_AMT(), "0"));
        ds.setField("PRO_OWN", F130Vo.getPRO_OWN());
        //�w�]���D�X����
        if (StringUtils.isBlank(F130Vo.getIS_CONT())) {
            ds.setField("IS_CONT", "2");
        } else {
            ds.setField("IS_CONT", F130Vo.getIS_CONT());
        }
        ds.setField("CONT_NO", F130Vo.getCONT_NO());
        ds.setField("CONT_AMT", ObjectUtils.toString(F130Vo.getCONT_AMT(), "0"));
        ds.setField("CONS_SDATE", F130Vo.getCONS_SDATE());
        ds.setField("CONS_EDATE", F130Vo.getCONS_EDATE());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        DBUtil.executeUpdate(ds, SQL_insert_001);

        //�O���f��u�{�������{

        /*String AUTH_DESC = "�s�W�u�{����";
        new RZ_N0Z001().insertLogOnly(F120Vo, AUTH_DESC);*/
        return PRO_NO;
    }

    /**
     * �ק��µ�ץ�_�u�{�������
     * @param F130Vo
     * @param user
     * @throws Exception
     */
    public void update(DTEPF130 F130Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String APLY_NO = "";
        Integer MEMO_NO = null;
        Integer PRO_NO = null;
        String SUB_CPY_ID = null;
        if (F130Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_001"));//��µ�ץ�_�u�{�����ɤ��i���� 
        } else {
            APLY_NO = F130Vo.getAPLY_NO();
            MEMO_NO = F130Vo.getMEMO_NO();
            PRO_NO = F130Vo.getPRO_NO();
            SUB_CPY_ID = F130Vo.getSUB_CPY_ID();
            if (MEMO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_005")); //�Ƨѿ��渹���i����!
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_003")); //�ǤJ�ץ�s�����i����!
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
            if (PRO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_007")); //�u�اǸ����i����!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_006"));//�ǤJ�ϥΪ̸�T���i���� 
        }
        if (eie != null) {
            throw eie;
        }
        //�ק��µ�ץ�_�u�{������DTEPF130
        Timestamp currentTime = DATE.currentTime();
        String userID = user.getEmpID();
        String userOpUnit = user.getOpUnit();
        F130Vo.setLST_PROC_DATE(currentTime);
        F130Vo.setLST_PROC_ID(userID);
        F130Vo.setLST_PROC_DIV(userOpUnit);
        VOTool.update(F130Vo);

        //�ק��µ�ץ�_�Ƨѿ�DTEPF120���Ƨѿ����B
        BigDecimal MEMO_AMT = new EP_Z0F130().queryMemoAmtByF130ActAmt(APLY_NO, String.valueOf(MEMO_NO), SUB_CPY_ID);
        DTEPF120 F120Vo = new DTEPF120();
        F120Vo.setAPLY_NO(APLY_NO);
        F120Vo.setMEMO_NO(MEMO_NO);
        F120Vo.setSUB_CPY_ID(SUB_CPY_ID);
        F120Vo = VOTool.findByPKWithUR(F120Vo);
        F120Vo.setLST_PROC_DATE(currentTime);
        F120Vo.setLST_PROC_ID(userID);
        F120Vo.setLST_PROC_DIV(userOpUnit);
        F120Vo.setMEMO_AMT(MEMO_AMT);
        VOTool.update(F120Vo);

        //�O���f��u�{�������{ 
        /*String AUTH_DESC = "�ק�u�{����";

        Map DBF110Map = new EP_Z0F110().queryMap(APLY_NO);
        DBF110Map.put("LST_PROC_DATE", DATE.currentTime());//�@�~�ɶ�
        DBF110Map.put("LST_PROC_ID", user.getEmpID());//�@�~�H��
        DBF110Map.put("LST_PROC_DIV", user.getOpUnit());//�@�~���
        new RZ_N0Z001().insertLogOnly(VOTool.mapToVO(DTEPF110.class, DBF110Map), AUTH_DESC);*/

    }

    /**
     * �R����µ�ץ�_�u�{�������
     * @param F130Vo
     * @param user
     * @throws Exception
     */
    public void delete(DTEPF130 F130Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String APLY_NO = "";
        Integer MEMO_NO = null;
        Integer PRO_NO = null;
        String PROJECT_TP = "";
        String SUB_CPY_ID = "";
        if (F130Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_001"));//��µ�ץ�_�u�{�����ɤ��i���� 
        } else {
            APLY_NO = F130Vo.getAPLY_NO();
            MEMO_NO = F130Vo.getMEMO_NO();
            PRO_NO = F130Vo.getPRO_NO();
            PROJECT_TP = F130Vo.getPROJECT_TP();
            SUB_CPY_ID = F130Vo.getSUB_CPY_ID();

            if (MEMO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_005")); //�Ƨѿ��渹���i����!
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_003")); //�ǤJ�ץ�s�����i����!
            }
            if (PRO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_007")); //�u�اǸ����i����!
            }
            if (StringUtils.isBlank(PROJECT_TP)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_008")); //�ǤJ�u�{�������i����!
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_006"));//�ǤJ�ϥΪ̸�T���i���� 
        }
        if (eie != null) {
            throw eie;
        }
        //�R����µ�ץ�_�u�{������DTEPF130
        VOTool.delByPK(F130Vo);

        //�ק��µ�ץ�_�Ƨѿ�DTEPF120���Ƨѿ����B
        BigDecimal MEMO_AMT = BigDecimal.ZERO;
        try {
            MEMO_AMT = new EP_Z0F130().queryMemoAmtByF130ActAmt(APLY_NO, String.valueOf(MEMO_NO), SUB_CPY_ID);
        } catch (DataNotFoundException e) {
            MEMO_AMT = BigDecimal.ZERO;
        }
        DTEPF120 F120Vo = new DTEPF120();
        F120Vo.setAPLY_NO(F130Vo.getAPLY_NO());
        F120Vo.setMEMO_NO(F130Vo.getMEMO_NO());
        F120Vo.setSUB_CPY_ID(SUB_CPY_ID);
        F120Vo = VOTool.findByPKWithUR(F120Vo);
        F120Vo.setMEMO_AMT(MEMO_AMT);
        F120Vo.setLST_PROC_DATE(DATE.currentTime());
        F120Vo.setLST_PROC_DIV(user.getOpUnit());
        F120Vo.setLST_PROC_ID(user.getEmpID());
        VOTool.update(F120Vo);

        //�O���f��u�{�������{ 
        /*String AUTH_DESC = "�R���u�{����";

        Map DBF110Map = new EP_Z0F110().queryMap(APLY_NO);
        DBF110Map.put("LST_PROC_DATE", DATE.currentTime());//�@�~�ɶ�
        DBF110Map.put("LST_PROC_ID", user.getEmpID());//�@�~�H��
        DBF110Map.put("LST_PROC_DIV", user.getOpUnit());//�@�~���
        new RZ_N0Z001().insertLogOnly(VOTool.mapToVO(DTEPF110.class, DBF110Map), AUTH_DESC);*/
    }

    /**
     *  �R����µ�ץ�_�u�{�������
     * @param F130Vo
     * @param user
     * @throws Exception
     */
    public void deleteByUpload(DTEPF130 F130Vo, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String APLY_NO = "";
        String SUB_CPY_ID = "";
        if (F130Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_001"));//��µ�ץ�_�u�{�����ɤ��i���� 
        } else {
            APLY_NO = F130Vo.getAPLY_NO();
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_003")); //�ǤJ�ץ�s�����i����!
            }
            SUB_CPY_ID = F130Vo.getSUB_CPY_ID();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }

        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_006"));//�ǤJ�ϥΪ̸�T���i���� 
        }
        if (eie != null) {
            throw eie;
        }
        //�R����µ�ץ�_�u�{������DTEPF130
        //VOTool.delByPK(F130Vo);
        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("MEMO_NO", F130Vo.getMEMO_NO());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_deleteByUpload_001, false);

        //�O���f��u�{�������{
        /*Map DBF110Map = new EP_Z0F110().queryMap(APLY_NO);
        DBF110Map.put("LST_PROC_DATE", DATE.currentTime());//�@�~�ɶ�
        DBF110Map.put("LST_PROC_ID", user.getEmpID());//�@�~�H��
        DBF110Map.put("LST_PROC_DIV", user.getOpUnit());//�@�~���
        new RZ_N0Z001().insertLogOnly(VOTool.mapToVO(DTEPF110.class, DBF110Map), "�R��(���s�W�ǧe�֪�)");*/

    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String value, String key) {

        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * ���o�̤j�u�اǸ�PRO_NO
     * @param F120Vo
     * @return
     * @throws ModuleException
     */
    private int getMaxPRO_NO(DTEPF130 F130Vo) throws ModuleException {

        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", F130Vo.getAPLY_NO());
        ds.setField("MEMO_NO", F130Vo.getMEMO_NO());
        ds.setField("SUB_CPY_ID", F130Vo.getSUB_CPY_ID());
        DBUtil.searchAndRetrieve(ds, SQL_getMaxPRO_NO_001);
        ds.next();
        return NumberUtils.toInt(ds.getField("PRO_NO").toString());
    }

    /**
     * ���o�Ƨѿ��U�u�{�����`���B
     * @param APLY_NO
     * @param MEMO_NO
     * @param SUB_CPY_ID
     * @return
     * @throws Exception
     */
    public BigDecimal queryMemoAmtByF130ActAmt(String APLY_NO, String MEMO_NO, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_002")); //�ǤJ�����q�O����!
        }
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_003")); //�ǤJ�ץ�s�����i����!
        }
        if (StringUtils.isBlank(MEMO_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_005")); //�Ƨѿ��渹���i����!
        }

        if (eie != null) {
            throw eie;
        }
        //�H�����q�O�ζǤJ�ѼƬd�߭�µ�ץ�_�u�{������(DTEPF130)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("MEMO_NO", MEMO_NO);
        DBUtil.searchAndRetrieve(ds, SQL_queryF130List_001);
        BigDecimal CLR_AMT = BigDecimal.ZERO;
        while (ds.next()) {
            CLR_AMT = CLR_AMT.add(NumberUtils.createBigDecimal(ObjectUtils.toString(ds.getField("CLR_AMT"))));
        }
        return CLR_AMT;
    }

    /**
     * �ק��µ�ץ�_�u�{�������_��W�I�u���
     * @param F130Vo ��µ�ץ�_�u�{������
     * @throws ModuleException 
     */
    public void updateConsDate(DTEPF130 F130Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        String APLY_NO = null;
        Integer MEMO_NO = null;
        String SUB_CPY_ID = null;
        if (F130Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_001"));//��µ�ץ�_�u�{�����ɤ��i���� 
        } else {
            SUB_CPY_ID = F130Vo.getSUB_CPY_ID();
            APLY_NO = F130Vo.getAPLY_NO();
            MEMO_NO = F130Vo.getMEMO_NO();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_003"));//�ǤJ�ץ�s�����i����!
            }
            if (MEMO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_005"));//�Ƨѿ��渹���i����!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_006"));//�ǤJ�ϥΪ̸�T���i���� 
        }
        if (eie != null) {
            throw eie;
        }

        //�ק��µ�ץ�_�u�{������DTEPF130
        DataSet ds = Transaction.getDataSet();
        ds.setField("CONS_SDATE", F130Vo.getCONS_SDATE());
        ds.setField("CONS_EDATE", F130Vo.getCONS_EDATE());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("MEMO_NO", MEMO_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_updateConsDate_001);

    }

    /**
     * �ק��µ�ץ�_�u�{�������_��W���u���
     * @param F130Vo ��µ�ץ�_�u�{������
     * @throws ModuleException 
     */
    public void updateFinalDate(DTEPF130 F130Vo, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        String APLY_NO = null;
        Integer MEMO_NO = null;
        Integer PRO_NO = null;
        String SUB_CPY_ID = null;
        if (F130Vo == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_001"));//��µ�ץ�_�u�{�����ɤ��i���� 
        } else {
            APLY_NO = F130Vo.getAPLY_NO();
            MEMO_NO = F130Vo.getMEMO_NO();
            PRO_NO = F130Vo.getPRO_NO();
            SUB_CPY_ID = F130Vo.getSUB_CPY_ID();
            if (StringUtils.isBlank(APLY_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_003"));//�ǤJ�ץ�s�����i����!
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
            if (MEMO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_005"));//�Ƨѿ��渹���i����!
            }
            if (PRO_NO == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_007")); //�u�اǸ����i����!
            }
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10103_MSG_006"));//�ǤJ�ϥΪ̸�T���i���� 
        }
        if (eie != null) {
            throw eie;
        }

        //�ק��µ�ץ�_�u�{������DTEPF130
        DataSet ds = Transaction.getDataSet();
        ds.setField("FINAL_DATE", DATE.today());
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("MEMO_NO", MEMO_NO);
        ds.setField("PRO_NO", PRO_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_updateFinalDate_001);

    }

}
