package com.cathay.ep.z0.module;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPC201;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014-12-02  Created �Ťl��
 * 2018-03-02  ��� ����[
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �㯲�����@�Ҳ�
 * �Ҳ�ID    EP_Z0C201
 * ���n����    SQL�㯲���Ҳ�
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_Z0C201 {
    private static final Logger log = Logger.getLogger(EP_Z0C201.class);

    private static final String SQL_insert_001 = "com.cathay.ep.z0.module.EP_Z0C201.SQL_insert_001";

    private static final String SQL_confirm_001 = "com.cathay.ep.z0.module.EP_Z0C201.SQL_confirm_001";

    private static final String SQL_cancel_001 = "com.cathay.ep.z0.module.EP_Z0C201.SQL_cancel_001";

    private static final String SQL_deleteDTEPC201_001 = "com.cathay.ep.z0.module.EP_Z0C201.SQL_deleteDTEPC201_001";

    private boolean isDebug = log.isDebugEnabled();

    private static final String SQL_updateINV_AMTforZero_001 = "com.cathay.ep.z0.module.EP_Z0C201.SQL_updateINV_AMTforZero_001";

    private static final String SQL_updateINV_NO_001 = "com.cathay.ep.z0.module.EP_Z0C201.SQL_updateINV_NO_001";

    private static final String SQL_queryDTEPC201_001 = "com.cathay.ep.z0.module.EP_Z0C201.SQL_queryDTEPC201_001";

    /**
     * �d�ߩ㯲��������
     * @param INT_YM �p���~��
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param SUB_CPY_ID �����q�O
     * @param PAY_NO ú�O�s��
     * @return rtnList ���O����
     * @throws ModuleException
     */
    public List<Map> queryDTEPC201(String INT_YM, String CRT_NO, String CUS_NO, String SUB_CPY_ID, String PAY_NO) throws ModuleException {

        if (StringUtils.isBlank(INT_YM)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C20010_MSG_018"));//�p���~�뤣�o���ŭ�
        }

        //�d�ߩ㯲��������
        DataSet ds = Transaction.getDataSet();
        ds.setField("INT_YM", INT_YM);
        if (StringUtils.isNotBlank(CRT_NO)) {
            ds.setField("CRT_NO", CRT_NO);
        }
        if (StringUtils.isNotBlank(CUS_NO)) {
            ds.setField("CUS_NO", CUS_NO);
        }
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (StringUtils.isNotBlank(PAY_NO)) {
            ds.setField("PAY_NO", PAY_NO);
        }

        int cnt = DBUtil.searchAndRetrieve(ds, SQL_queryDTEPC201_001, false);
        if (cnt == 0) {
            throw new DataNotFoundException(MessageUtil.getMessage("EP_C20010_MSG_013"));//�d�L�㯲�����
        }
        List<Map> rtnList = new ArrayList();
        int seqCnt = 0;
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //�|�O
            rtnMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE")));
            //�@�~�i��
            rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS", MapUtils.getString(rtnMap, "OP_STATUS", "").trim()));
            rtnMap.put("SEQ", ++seqCnt);//�Ǹ�
            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**�妸�g�JDTEPC201
     * @param insertList
     * @throws ModuleException 
     * @throws DBException 
     * @throws DBException 
     */
    public void insertList(List<DTEPC201> insertList) throws ModuleException, DBException {

        BatchConstructor.processByBatch(insertList, SQL_insert_001, false, ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL, new BatchConstructor.ListHandler() {
            EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();

            StringBuilder sb = new StringBuilder();

            protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {

                try {
                    DTEPC201 C201 = (DTEPC201) Object;
                    String SUB_CPY_ID = C201.getSUB_CPY_ID();
                    sb.setLength(0);
                    //���o�㯲���s��=�����q�O(2)+�����~��(6)+"I"+�y����(4)
                    int SER_NO = theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "022", "001", C201.getINT_YM().toString());
                    String INT_NO = sb.append(SUB_CPY_ID).append(C201.getINT_YM()).append("I").append(STRING.fillZero(String.valueOf(SER_NO), 4, EncodingHelper.Charset_UTF8)).toString();
                    if (isDebug) {
                        log.debug("INT_NO=" + INT_NO);
                    }
                    buds.setField("INT_NO", INT_NO);
                    buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    buds.setField("INT_YM", C201.getINT_YM());
                    buds.setField("CRT_NO", C201.getCRT_NO());
                    buds.setField("CUS_NO", C201.getCUS_NO());
                    buds.setField("PAY_NO", C201.getPAY_NO());
                    buds.setField("BLD_CD", C201.getBLD_CD());
                    buds.setField("DIV_NO", C201.getDIV_NO());
                    buds.setField("ID", C201.getID());
                    buds.setField("CUS_NAME", C201.getCUS_NAME());
                    buds.setField("PMI_S_DATE", C201.getPMI_S_DATE());
                    buds.setField("PMI_E_DATE", C201.getPMI_E_DATE());
                    buds.setField("PASS_DAY", C201.getPASS_DAY());
                    buds.setField("PMS_AMT", C201.getPMS_AMT());
                    buds.setField("RAT_CD", C201.getRAT_CD());
                    buds.setField("PIM_RATE", C201.getPIM_RATE());
                    buds.setField("PMI_AMT", C201.getPMI_AMT());
                    buds.setField("PMI_TAX", C201.getPMI_TAX());
                    buds.setField("INV_NO", C201.getINV_NO());
                    buds.setField("INV_AMT", C201.getINV_AMT());
                    buds.setField("TAX_TYPE", C201.getTAX_TYPE());
                    buds.setField("ACNT_DATE", C201.getACNT_DATE());
                    buds.setField("ACNT_ID", C201.getACNT_ID());
                    buds.setField("ACNT_NAME", C201.getACNT_NAME());
                    buds.setField("ACNT_DIV_NO", C201.getACNT_DIV_NO());
                    buds.setField("SLIP_LOT_NO", C201.getSLIP_LOT_NO());
                    buds.setField("SLIP_SET_NO", C201.getSLIP_SET_NO());
                    buds.setField("FLOW_NO", "");
                    buds.setField("OP_STATUS", "0");
                    buds.setField("LST_PROC_DATE", C201.getLST_PROC_DATE());
                    buds.setField("LST_PROC_ID", C201.getLST_PROC_ID());
                    buds.setField("LST_PROC_DIV", C201.getLST_PROC_DIV());
                    buds.setField("LST_PROC_NAME", C201.getLST_PROC_NAME());
                    buds.setField("SWP_DATE", C201.getSWP_DATE());
                    buds.setField("ORN_AMT", C201.getORN_AMT());
                    buds.setField("RCV_NO", C201.getRCV_NO());
                    buds.setField("INV_TRANS_TYPE", C201.getINV_TRANS_TYPE());
                    addBatchAndJoinGroup(buds);
                } catch (ModuleException me) {
                    throw new DBException(me);
                }
            }
        });

    }

    /**
     * �㯲���ӽT�{
     * @param INT_NOs
     * @param ACNT_MAP
     * @throws ModuleException
     * @throws DBException
     */
    public void confirm(List<Map> DTEPC201_VO_List, Map ACNT_MAP) throws ModuleException, DBException {
        ErrorInputException eie = null;
        if (DTEPC201_VO_List == null || DTEPC201_VO_List.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C201_MSG_002")); //�ǤJ�㯲���s�����o����!
        }
        if (ACNT_MAP == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C201_MSG_003")); //�ǤJ�b�ȸ�T���o����!
        }
        if (eie != null) {
            throw eie;
        }
        //��s�f��i�סG

        String NEW_OP_STATUS = this.getNextOpStatus("EPC2_0030", MapUtils.getString(ACNT_MAP, "OP_STATUS"));
        BatchUpdateDataSet buds = Transaction.getBatchUpdateDataSet();
        try {
            buds.preparedBatch(SQL_confirm_001);
            String ACNT_DATE = MapUtils.getString(ACNT_MAP, "ACNT_DATE");
            String ACNT_DIV_NO = MapUtils.getString(ACNT_MAP, "ACNT_DIV_NO");
            String SLIP_LOT_NO = MapUtils.getString(ACNT_MAP, "SLIP_LOT_NO");
            String SlipSetNo = MapUtils.getString(ACNT_MAP, "SlipSetNo");
            String UserTrnSerno = MapUtils.getString(ACNT_MAP, "UserTrnSerno");
            String ACNT_ID = MapUtils.getString(ACNT_MAP, "ACNT_ID");
            String ACNT_NAME = MapUtils.getString(ACNT_MAP, "ACNT_NAME");
            String TrnDate = MapUtils.getString(ACNT_MAP, "LST_PROC_DATE");
            String SUB_CPY_ID = MapUtils.getString(ACNT_MAP, "SUB_CPY_ID");
            for (Map C201Map : DTEPC201_VO_List) {
                String INT_NO = MapUtils.getString(C201Map, "INT_NO");
                String INV_NO = MapUtils.getString(C201Map, "INV_NO");
                buds.setField("INV_NO", INV_NO);
                buds.setField("ACNT_DATE", ACNT_DATE);
                buds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
                buds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
                buds.setField("SlipSetNo", SlipSetNo);
                buds.setField("UserTrnSerno", UserTrnSerno);
                buds.setField("ACNT_ID", ACNT_ID);
                buds.setField("ACNT_NAME", ACNT_NAME);
                buds.setField("OP_STATUS_NEW", NEW_OP_STATUS);
                buds.setField("LST_PROC_DATE", TrnDate);
                buds.setField("LST_PROC_ID", ACNT_ID);
                buds.setField("LST_PROC_DIV", ACNT_DIV_NO);
                buds.setField("LST_PROC_NAME", ACNT_NAME);
                buds.setField("INT_NO", INT_NO);
                buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                buds.addBatch();
            }

            int buds_Ret[] = buds.executeBatch();

            Object errObject[][] = new ErrorHandler().getErrorArray(buds.getBatchUpdateErrorArray(), buds_Ret, buds.getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

            if (errObject != null && errObject.length > 0) {
                for (int i = 0; i < errObject.length; i++) {
                    throw new ModuleException((SQLException) errObject[i][2]);
                }
            }
        } finally {
            if (buds != null) {
                buds.close();
            }
        }
    }

    /**
     * �㯲�����Ө����T�{
     * @param acntMap
     * @throws ModuleException
     */
    public void cancel(Map acntMap) throws ModuleException {
        if (acntMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C201_MSG_003")); //�ǤJ�b�ȸ�T���o����!
        }
        String NEW_OP_STATUS = this.getPreOpStatus("EPC2_0030", MapUtils.getString(acntMap, "OP_STATUS"));
        DataSet ds = Transaction.getDataSet();
        ds.setField("NEW_OP_STATUS", NEW_OP_STATUS);
        ds.setField("LST_PROC_DATE", acntMap.get("LST_PROC_DATE"));
        ds.setField("LST_PROC_ID", acntMap.get("LST_PROC_ID"));
        ds.setField("LST_PROC_DIV", acntMap.get("LST_PROC_DIV"));
        ds.setField("LST_PROC_NAME", acntMap.get("LST_PROC_NAME"));
        ds.setField("ACNT_DATE", acntMap.get("ACNT_DATE"));
        ds.setField("ACNT_DIV_NO", acntMap.get("ACNT_DIV_NO"));
        ds.setField("SLIP_LOT_NO", acntMap.get("SLIP_LOT_NO"));
        ds.setField("SLIP_SET_NO", acntMap.get("SLIP_SET_NO"));
        ds.setField("SUB_CPY_ID", acntMap.get("SUB_CPY_ID"));
        DBUtil.executeUpdate(ds, SQL_cancel_001);
    }

    /**
     * �R���㯲������
     * @param INT_NO
     * @throws ModuleException
     */
    public void deleteDTEPC201(String INT_NO, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(INT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C201_MSG_002"));//�㯲���s�����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("INT_NO", INT_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_deleteDTEPC201_001);
        } catch (DataNotFoundException dnfe) {

            throw new ModuleException(MessageUtil.getMessage("EP_Z0C201_MSG_005", new Object[] { INT_NO }));//�㯲���s��{0}�w�T�{�A���o�R��
        }
    }

    /**
     * ��s�㮧���B=0�����T�{�㯲�����
     * @param tmpMap
     * @throws ModuleException
     */
    public void updateINV_AMTforZero(Map tmpMap) throws ModuleException {
        if (tmpMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C201_MSG_004"));//�ǤJ�ѼƤ��o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(tmpMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("INT_YM", tmpMap.get("INT_YM"));
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        String BLD_CD = MapUtils.getString(tmpMap, "BLD_CD");
        if (StringUtils.isNotBlank(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//�D��ؤ��d���
            ds.setField("DIV_NO", tmpMap.get("DIV_NO"));
        }
        ds.setField("LST_PROC_DATE", tmpMap.get("LST_PROC_DATE"));
        ds.setField("LST_PROC_ID", tmpMap.get("LST_PROC_ID"));
        ds.setField("LST_PROC_DIV", tmpMap.get("LST_PROC_DIV"));
        ds.setField("LST_PROC_NAME", tmpMap.get("LST_PROC_NAME"));
        DBUtil.executeUpdate(ds, SQL_updateINV_AMTforZero_001);
    }

    /**
     * ���o�f��]�w��ư_�l�i��
     * @param FLOW_TYPE
     * @return
     * @throws ModuleException
     */
    public String getStartOpStatus(String FLOW_TYPE) throws ModuleException {
        if (StringUtils.isBlank(FLOW_TYPE)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_Z0C201_MSG_006")); //�f��y�{�������o����!
        }
        //�f��]�w
        //Map FLOW_TYPE_Map = FieldOptionList.getName("EP", FLOW_TYPE);

        return "0";
        //return MapUtils.getString(FLOW_TYPE_Map, "0");
    }

    /**
     * ���o�f��y�{�@�~�i�׳]�w
     * @param FLOW_TYPE
     * @param OP_STATUS
     * @return
     * @throws ModuleException
     */
    public String getNextOpStatus(String FLOW_TYPE, String OP_STATUS) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(FLOW_TYPE)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C201_MSG_006")); //�f��y�{�������o����!
        }
        if (StringUtils.isBlank(OP_STATUS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C201_MSG_007")); //�@�~�i�פ��o����!
        }
        if (eie != null) {
            throw eie;
        }
        return FieldOptionList.getName("EP", FLOW_TYPE, OP_STATUS);
    }

    /**
     * ���o�f��]�w��ƤW�@�@�~�i�ץN�X
     * @param FLOW_TYPE
     * @param OP_STATUS
     * @return
     * @throws ModuleException
     */
    public String getPreOpStatus(String FLOW_TYPE, String OP_STATUS) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(FLOW_TYPE)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C201_MSG_006")); //�f��y�{�������o����!
        }
        if (StringUtils.isBlank(OP_STATUS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C201_MSG_007")); //�@�~�i�פ��o����!
        }
        if (eie != null) {
            throw eie;
        }
        //�f��]�w
        String PRE_OP_STATUS = null;
        Map FLOW_TYPE_Map = FieldOptionList.getName("EP", FLOW_TYPE);
        for (Object every_key : FLOW_TYPE_Map.keySet()) {
            String tmp_OP_STATUS = MapUtils.getString(FLOW_TYPE_Map, every_key);
            if (tmp_OP_STATUS.equals(OP_STATUS)) {
                PRE_OP_STATUS = ObjectUtils.toString(every_key);
                break;
            }
        }
        return PRE_OP_STATUS;
    }

    /**
     * �q�l�o��:�o���}�߫�^���o�����X
     * @param List<Map> C201List
     * @param UserObject user
     * @throws ModuleException
     */
    public void updateInvNo(List<Map> C201List, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        if (C201List == null || C201List.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_027")); //������Ƥ��o����
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_Z0C101_MSG_004")); //�ǤJ�ϥΪ̸�T���o����!
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        String LST_PROC_ID = user.getEmpID();
        String LST_PROC_DIV = user.getOpUnit();
        String LST_PROC_NAME = user.getEmpName();

        for (Map rtnMap : C201List) {
            ds.setField("LST_PROC_DATE", DATE.currentTime()); //�@�~�B�z�ɶ�
            ds.setField("INV_NO", MapUtils.getString(rtnMap, "INV_NO"));
            ds.setField("INT_NO", MapUtils.getString(rtnMap, "INT_NO"));
            ds.setField("SUB_CPY_ID", MapUtils.getString(rtnMap, "SUB_CPY_ID"));
            ds.setField("LST_PROC_ID", LST_PROC_ID); //�@�~�B�z�H��ID//TODO��X
            ds.setField("LST_PROC_DIV", LST_PROC_DIV); //�@�~�B�z���
            ds.setField("LST_PROC_NAME", LST_PROC_NAME); //�@�~�B�z�H���m�W
            DBUtil.executeUpdate(ds, SQL_updateINV_NO_001);
        }
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }
}
