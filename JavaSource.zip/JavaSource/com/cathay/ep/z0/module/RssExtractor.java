package com.cathay.ep.z0.module;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.util.http.TrustAllSSLSocketFactory;
import com.cathay.ep.vo.DTEPZ300;
import com.cathay.ep.vo.DTEPZ301;
import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.FeedException;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.XmlReader;

/**
 * <pre>
 * RssExtractor
 * </pre>
 * 
 * @author
 * @since 2015/5/22
 * @since [2019-04-29] �ӽЮ�190123001147 - �u�Ƶ{��
 */
@SuppressWarnings("unchecked")
public class RssExtractor extends NewsExtractor {
    private Logger log = Logger.getLogger(RssExtractor.class);

    /**
     * �غc�l
     * @param site
     */
    public RssExtractor(DTEPZ300 site) {
        super(site);
    }

    /**
     * �ѪR����(STEP 2)
     * �мgNewsExtractor.digesNews(site)
     */
    public List<DTEPZ301> digestNews(DTEPZ300 site) throws IOException, MalformedURLException {
        String rssUrl = site.getURL();
        List<DTEPZ301> matchNews = new ArrayList<DTEPZ301>();

        // trustEveryone();
        //[20190429] �վ�ssl�{�Ҥ�k(��Ω��h�@��)
        new TrustAllSSLSocketFactory();

        URL feedUrl = new URL(rssUrl);
        SyndFeedInput input = new SyndFeedInput();
        SyndFeed feed;
        try {
            URLConnection urlConnection = feedUrl.openConnection();
            urlConnection.setConnectTimeout(getConnectTimeout());
            XmlReader reader = new XmlReader(urlConnection);
            feed = input.build(reader);
            //log.debug("### DOC::" + StringUtils.substring(feed.toString(), 0, 100));
        } catch (FeedException e1) {
            log.error("RSS�ѪR����");
            throw new IOException(e1.getMessage());
        }

        List<SyndEntry> feeds = feed.getEntries();
        //int i = 0;
        for (SyndEntry itm : feeds) {
            //i++;
            String linkUrl = itm.getLink();
            try {
                String urlEncoding = site.getENCODING();
                if (StringUtils.isBlank(urlEncoding)) {
                    urlEncoding = "UTF-8";
                }
                linkUrl = java.net.URLDecoder.decode(linkUrl, urlEncoding);
            } catch (UnsupportedEncodingException e) {
                log.error("UrlDecode Failed", e);
                throw new IOException(e.getMessage());
            }

            String title = itm.getTitle();

            DTEPZ301 theNews = initDTEPZ301(site);
            theNews.setTITLE(title);
            theNews.setURL(this.extractUrl(rssUrl, linkUrl));
            if (itm.getDescription() != null) {//[190515] ���������i��L�]description
                theNews.setMEMO(itm.getDescription().getValue());
            }
            if (itm.getPublishedDate() != null) {
                theNews.setPUBLISH_DT(new Timestamp(itm.getPublishedDate().getTime()));
            }
            matchNews.add(theNews);
        }

        return matchNews;

    }
}
