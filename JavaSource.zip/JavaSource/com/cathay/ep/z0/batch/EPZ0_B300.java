package com.cathay.ep.z0.batch;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.BatchConstructor.Options;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.vo.DTEPZ301;
import com.cathay.ep.vo.DTEPZ302;
import com.cathay.ep.z0.module.EP_Z0Z300;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.rz.s0.module.RZ_S00300;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * Date Version Description Author
 * 2015/05/14  1.0 Created ������
 * 2018/03/12  1.1 �վ���~�T���H�H ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ���ʲ������T���T���妸�q��
 * �{���W��    EPZ0_B300
 * �@�~�覡    BATCH
 * ���n����    �Ƶ{���ͤ��ʲ������T��
 * �w����ƶq   5000 (�̤j��)
 * �@�~�W��    JAEPDZ010
 * �~�ȧO EP
 * ���t�ΦW��   Z0
 * �B�z�g��    ��
 * ����B�z���  3000
 * </pre>
 * @author ����[
 * @since 2015/5/22
 *        2018/6/27:�վ����H�H���~�q���T�����e
 */
@SuppressWarnings( { "rawtypes", "unchecked" })
public class EPZ0_B300 extends EP_BatchBean {
    /** logger */
    private Logger log = Logger.getLogger(EPZ0_B300.class);

    private BatchUpdateDataSet budsZ300;

    private BatchUpdateDataSet budsZ301;

    private BatchUpdateDataSet budsZ302;

    private int commit_size = 1000;

    private int batchCount;

    private boolean pass803 = true;

    private List<Map> FailList = new ArrayList<Map>();

    private static final String SQL_query_001 = "com.cathay.ep.z0.batch.EPZ0_B300.SQL_query_001";

    private static final String SQL_query_002 = "com.cathay.ep.z0.batch.EPZ0_B300.SQL_query_002";

    private static final String SQL_insert_001 = "com.cathay.ep.z0.batch.EPZ0_B300.SQL_insert_001";

    private static final String SQL_insert_002 = "com.cathay.ep.z0.batch.EPZ0_B300.SQL_insert_002";

    public EPZ0_B300() throws Exception {
        budsZ300 = getBatchUpdateDataSet();
        budsZ301 = getBatchUpdateDataSet();
        budsZ302 = getBatchUpdateDataSet();
    }

    @Override
    public void execute(String[] args) throws Exception {
        final BatchConstructor bc = new BatchConstructor("JAEPDZ010", "EPZ0_B300", "��");
        try {
            String EVENT_TYPE;
            final String SUB_CPY_ID;
            final String EVENT_ID;
            final String PRC_DATE;
            //�Ѽ��ˮ�
            // args = [ "�T���`��(EPRZ001:���ʲ�,EPRZ002:��޷s��)" , "�����q�O" , "EVENT_ID" , "PRC_DATE"(�ɱH�H��) ]
            if (args == null) {
                setExitCode(ERROR);
                throw new ErrorInputException(MessageUtil.getMessage("EPZ0_B300_MSG_001"));//�ǤJ�ѼƭӼƿ��~
            }
            int arg_length = args.length;
            if (arg_length > 4 || arg_length < 2) {
                setExitCode(ERROR);
                throw new ErrorInputException(MessageUtil.getMessage("EPZ0_B300_MSG_001"));//�ǤJ�ѼƭӼƿ��~
            }
            EVENT_TYPE = args[0];
            SUB_CPY_ID = args[1];
            EVENT_ID = (arg_length >= 3) ? args[2] : null;
            PRC_DATE = (arg_length == 4) ? args[3] : null;

            if (StringUtils.isBlank(EVENT_TYPE) || StringUtils.isBlank(SUB_CPY_ID)) {
                setExitCode(ERROR);
                throw new ErrorInputException(MessageUtil.getMessage("EPZ0_B300_MSG_002"));//�ǤJ�ѼƤ��i����
            }

            /* 161003:����:����������Ұ���
            Date today = DATE.today();
            if (!WorkDate.isWorkingDay(today)) {
                log.fatal("�D�u�@�餣����,���=" + today);
                return;
            }*/

            //�ɱH�H
            if (StringUtils.isNotBlank(PRC_DATE)) {

                if (StringUtils.isBlank(EVENT_ID)) {
                    setExitCode(ERROR);
                    throw new ErrorInputException(MessageUtil.getMessage("EPZ0_B300_MSG_002"));//�ǤJ�ѼƤ��i����
                }

                final List<Map> recpList = getMailList(SUB_CPY_ID, EVENT_ID);
                final String PCS_DT_s = DATE.timestampToDate(PRC_DATE).toString();
                final RZ_S00300 mRZ_S00300 = new RZ_S00300();
                //�s�T��
                Options op = bc.getOptions();
                op.setTerminated(true);
                bc.execute(new BatchConstructor.DataBaseHandler() {
                    List<DTEPZ301> newsList;

                    @Override
                    protected boolean searchProcess(BatchQueryDataSet bqds) throws DBException {
                        bqds.setField("EVENT_ID", EVENT_ID);
                        bqds.setField("PCS_DT", PRC_DATE);

                        bqds.searchAndRetrieve(SQL_query_001);
                        if (bqds.getTotalCount() == 0) {
                            log.fatal("�d�L�T�����");
                            return false;
                        }
                        newsList = new ArrayList<DTEPZ301>();
                        return true;
                    }

                    @Override
                    protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {
                        DTEPZ301 news = new DTEPZ301();
                        news.setEVENT_ID((String) bqds.getField("EVENT_ID"));
                        news.setPCS_SEQ((Integer) bqds.getField("PCS_SEQ"));
                        news.setURL((String) bqds.getField("URL"));
                        news.setTITLE(ObjectUtils.toString(bqds.getField("TITLE")));
                        news.setMEMO(ObjectUtils.toString(bqds.getField("MEMO")));
                        news.setINFO_SOURCE(ObjectUtils.toString(bqds.getField("INFO_SOURCE")));
                        news.setPCS_DT(DATE.toTimestamp(ObjectUtils.toString(bqds.getField("PCS_DT"))));
                        newsList.add(news);
                    }

                    @Override
                    protected void lastProcess() throws Exception {
                        //�H�e���ʲ������T��
                        sendNewsToReceivers(EVENT_ID, newsList, recpList, PCS_DT_s, mRZ_S00300);
                    }
                });

                //���~�T��
                op.setTerminated(true);
                bc.execute(new BatchConstructor.DataBaseHandler() {
                    List<DTEPZ302> errorList;

                    @Override
                    protected boolean searchProcess(BatchQueryDataSet bqds) throws DBException {
                        bqds.setField("EVENT_ID", EVENT_ID);
                        bqds.setField("PCS_DT", PRC_DATE);

                        bqds.searchAndRetrieve(SQL_query_002);
                        if (bqds.getTotalCount() == 0) {
                            log.fatal("�d�L���~�T�����");
                            return false;
                        }
                        errorList = new ArrayList<DTEPZ302>();
                        return true;
                    }

                    @Override
                    protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {
                        DTEPZ302 errors = new DTEPZ302();
                        errors.setEVENT_ID((String) bqds.getField("EVENT_ID"));
                        errors.setPCS_SEQ((Integer) bqds.getField("PCS_SEQ"));
                        errors.setPCS_DT(DATE.toTimestamp(ObjectUtils.toString(bqds.getField("PCS_DT"))));
                        errors.setINFO_SOURCE((String) bqds.getField("INFO_SOURCE"));
                        errors.setURL((String) bqds.getField("URL"));
                        errors.setENCODING(ObjectUtils.toString(bqds.getField("ENCODING")));
                        errors.setKEYWORD(ObjectUtils.toString(bqds.getField("KEYWORD")));
                        errors.setEXTRACTOR(ObjectUtils.toString(bqds.getField("EXTRACTOR")));
                        errors.setUSER_AGENT(ObjectUtils.toString(bqds.getField("USER_AGENT")));
                        errors.setERR_MSG(ObjectUtils.toString(bqds.getField("ERR_MSG")));
                        errors.setSTACK_TRACE(ObjectUtils.toString(bqds.getField("STACK_TRACE")));
                        errorList.add(errors);
                    }

                    @Override
                    protected void lastProcess() throws Exception {

                        //���o���~�T���H��q����H�A�ƥ�N���᭱�[_ER
                        List<Map> errRecpList = null;
                        try {
                            errRecpList = getMailList(SUB_CPY_ID, EVENT_ID + "_ER");
                        } catch (DataNotFoundException dnfe) {
                            //�Y�L�h�έ쥻��Mail�M��H�e
                        }

                        //�H�e���~�T��
                        if (errRecpList != null && !errRecpList.isEmpty()) {
                            sendErrorToReceivers(EVENT_ID, errorList, errRecpList, PCS_DT_s, mRZ_S00300);
                        } else {
                            sendErrorToReceivers(EVENT_ID, errorList, recpList, PCS_DT_s, mRZ_S00300);
                        }
                    }
                });

            } else {//����ѪR+�H�H

                Set<String> EVENT_IDs;
                //1.    ���ͤ��ʲ������T���q��
                //1.1 Ū�������T���q����H�ɮ׳]�w
                if (StringUtils.isNotBlank(EVENT_ID)) {
                    EVENT_IDs = new HashSet<String>();
                    EVENT_IDs.add(EVENT_ID);
                } else {
                    //�S���wEVENT_ID,�h������
                    EVENT_IDs = FieldOptionList.getName("EP", "EVENT_" + EVENT_TYPE).keySet();
                }

                //1.2 �v�@�ƥ�ѪR�����T���q��
                EP_Z0Z300 theEP_Z0Z300 = new EP_Z0Z300();
                RZ_S00300 mRZ_S00300 = new RZ_S00300();
                boolean sendMailHasError = false;
                DataSet ds = Transaction.getDataSet();
                int sendMailCnt = 0;
                for (String EVENTID : EVENT_IDs) {
                    Timestamp PCS_DT = DATE.currentTime(); //�C�@�ƥ���o�@���@�~�}�l�ɶ�
                    log.fatal("EVENT_ID=" + EVENTID);
                    log.fatal("PCS_DT=" + PCS_DT);
                    Map<String, Object> rtnMap;
                    try {
                        rtnMap = theEP_Z0Z300.getNews(EVENTID);
                    } catch (DataNotFoundException dnfe) {
                        //�o�Ϳ��~�A������~�B�z A
                        log.fatal("�d�L�]�w��(Z300)", dnfe);
                        setExitCode(ERROR);
                        continue;
                    } catch (Exception e) {
                        //�o�Ϳ��~�A������~�B�z A
                        log.fatal("Ū���T�����`", e);
                        setExitCode(ERROR);
                        continue;
                    }

                    try {
                        //��X���ʲ������T������
                        this.insertNews(rtnMap, PCS_DT);

                        //��X���ʲ������T�����`����
                        this.insertError(rtnMap, PCS_DT);

                        //��sZ300�̷s�d�߮ɶ�
                        budsZ300 = theEP_Z0Z300.updatePCS_DATEforBatch(budsZ300, commit_size, rtnMap, PCS_DT);

                    } catch (Exception e) {
                        String MSG = new StringBuilder().append(MessageUtil.getMessage("EPZ0_B300_MSG_003")/*�T���g�J��Ʈw�o�Ϳ��~*/).append(
                            "�AEVENT_ID=").append(EVENTID).append(",PRC_DATE=").append(PCS_DT).toString();
                        log.fatal(MSG, e);
                        bc.addErrorLog(MSG, e);
                        setExitCode(ERROR);

                        this.formatFailMsg(FailList, EVENTID, null, MSG + e.getMessage());
                    }

                    List<Map> recpList = new ArrayList<Map>();
                    String PCS_DT_s = DATE.timestampToDate(PCS_DT).toString();
                    log.fatal("send Mail EVENTID::" + EVENTID);
                    if (!"EP_RZ101".equals(EVENTID)) {//IM_PORTAL���ݱH�H
                        //�H�H�B�z
                        //�H�e���ʲ������T��
                        try {
                            //[190515] ���d�߮���A�H�X
                            ds.clear();
                            ds.setField("EVENT_ID", EVENTID);
                            ds.setField("PCS_DT", PCS_DT);
                            List<DTEPZ301> newsListForMail = VOTool.findToVOs(DTEPZ301.class, ds, SQL_query_001, false);

                            //���o�H��q����H
                            recpList = getMailList(SUB_CPY_ID, EVENTID);

                            if (newsListForMail != null && newsListForMail.size() > 0) {
                                //�L�H�e�ﹳ�J���H�H
                                if (recpList.size() > 0) {
                                    //�H�e���ʲ������T��
                                    String rtnMessage = sendNewsToReceivers(EVENTID, newsListForMail, recpList, PCS_DT_s, mRZ_S00300);
                                    if (StringUtils.isNotBlank(rtnMessage)) {
                                        throw new ModuleException(rtnMessage);
                                    }
                                }
                            }
                        } catch (Exception e) {
                            //�Y�O�o�e���~�A��������{��
                            String MSG = new StringBuilder().append(MessageUtil.getMessage("EPZ0_B300_MSG_004")/*�H��o�e�o�Ϳ��~*/).append(
                                "�AEVENT_ID=").append(EVENTID).append(",PRC_DATE=").append(PCS_DT).toString();
                            log.fatal(MSG, e);
                            bc.addErrorLog(MSG, e);

                            this.formatFailMsg(FailList, EVENTID, null, MSG + e.getMessage());
                            sendMailHasError = true;
                        }
                    }

                    //�H�e���ʲ����~�T��
                    //�վ�L�׬O�_�ӱH�H�ҥi�]�w������~�T��
                    try {
                        //[190515] ���d�߮���A�H�X
                        ds.clear();
                        ds.setField("EVENT_ID", EVENTID);
                        ds.setField("PCS_DT", PCS_DT);
                        List<DTEPZ302> errorsListForMail = VOTool.findToVOs(DTEPZ302.class, ds, SQL_query_002, false);

                        if (errorsListForMail != null && errorsListForMail.size() > 0) {
                            //���o���~�T���H��q����H�A�ƥ�N���᭱�[_ER
                            try {
                                recpList = getMailList(SUB_CPY_ID, EVENTID + "_ER");
                            } catch (DataNotFoundException dnfe) {
                                //�Y�L�h�έ쥻��Mail�M��H�e
                            }

                            //�L�H�e�ﹳ�J���H�H
                            if (recpList.size() > 0) {
                                String rtnMessage = sendErrorToReceivers(EVENTID, errorsListForMail, recpList, PCS_DT_s, mRZ_S00300);
                                if (StringUtils.isNotBlank(rtnMessage)) {
                                    throw new ModuleException(rtnMessage);
                                }
                            }
                        } else {
                            String MSG = new StringBuilder().append(MessageUtil.getMessage("EPZ0_B300_MSG_006")/*�L���~�T��*/).append(
                                "�AEVENT_ID=").append(EVENTID).append(",PRC_DATE=").append(PCS_DT).toString();
                            log.fatal(MSG);
                            bc.addErrorLog(MSG, "�L���~�T��");
                        }
                    } catch (Exception e) {
                        //�Y�O�o�e���~�A��������{��
                        String MSG = new StringBuilder().append(MessageUtil.getMessage("EPZ0_B300_MSG_004")/*�H��o�e�o�Ϳ��~*/).append(
                            "�AEVENT_ID=").append(EVENTID).append("_ER").append(",PRC_DATE=").append(PCS_DT).toString();
                        log.fatal(MSG, e);
                        bc.addErrorLog(MSG, e);

                        this.formatFailMsg(FailList, EVENTID + "_ER", null, MSG + e.getMessage());
                        sendMailHasError = true;
                    }

                }//end for

                //[190515] �g�J��ƩαH�H���ѳq���B�z
                if (sendMailHasError || !FailList.isEmpty()
                        || "Y".equals(FieldOptionList.getName("EP", "TEST_CONTROL", "EPZ0_B300_ERRORMAIL"))) {
                    log.fatal("�H�H�o�Ϳ��~,�q��:sendMailHasError:" + sendMailHasError + "||sendMailCnt:" + sendMailCnt + "||FailList.size:"
                            + FailList.size());
                    //���o���~�T���H��q����H�A�ƥ�N���᭱�[_ER
                    List<Map> recpList = getMailList(SUB_CPY_ID, "EPZ0_MAILCHK");

                    //180627:�վ����H�H���~�q���T�����e
                    sendMailFailToReceivers("EPZ0_MAILCHK", FailList, recpList, DATE.currentTime().toString(), mRZ_S00300);
                }

            }//end of �ѪR+�H�H

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("����ɵo�Ϳ��~", e);
        } finally {
            bc.writeErrorLog();//�N���~�T���g�JLog��

            if (budsZ300 != null)
                budsZ300.close();
            if (budsZ301 != null)
                budsZ300.close();
            if (budsZ302 != null)
                budsZ300.close();

            if (getExitCode() == OK) {
                int batchConstructorExitCode = bc.getExitCode();
                if (batchConstructorExitCode != OK) {
                    setExitCode(batchConstructorExitCode);
                }
            }

            printExitCode(getExitCode());
        }

    }

    /**
     * ���o�H��q����H
     * @param SUB_CPY_ID
     * @param EVENT_ID
     * @return
     * @throws ModuleException
     */
    private List<Map> getMailList(String SUB_CPY_ID, String EVENT_ID) throws ModuleException {
        //1.    ���o�ƥ�q����H
        List<DTEPZ103> mailList = new EP_Z10030().getMailList(SUB_CPY_ID, EVENT_ID).get(SUB_CPY_ID);

        //2.  �榡�ƱH��q��
        List<Map> recList = new ArrayList<Map>();
        for (DTEPZ103 z103 : mailList) {
            Map recepit = new HashMap();
            recepit.put("EVENT_ID", EVENT_ID);
            recepit.put("USER_ID", z103.getID());
            recepit.put("USER_EMAIL", z103.getEMAIL());
            recList.add(recepit);
        }
        return recList;

    }

    /**
     * �H�H_�s�T��
     * @param eventID
     * @param news
     * @param recpList
     * @param PCS_DT
     * @param mRZ_S00300
     * @throws ModuleException
     */
    private String sendNewsToReceivers(String eventID, List<DTEPZ301> news, List<Map> recpList, String PCS_DT, RZ_S00300 mRZ_S00300)
            throws ModuleException {
        List<Map> newsList = new ArrayList<Map>();
        int serNo = 0;
        StringBuilder sb = new StringBuilder();
        for (DTEPZ301 z301 : news) {
            Map newMap = new HashMap();
            serNo++;
            newMap.put("SER_NO", Integer.toString(serNo));
            newMap //<p align="left">��r�a��</p>
                    .put("SUBJECT", sb.append("<p align='left'><a href=").append(z301.getURL()).append(">").append(z301.getTITLE()).append(
                        "</a></p>").toString());
            newMap.put("INFO_SOURCE", z301.getINFO_SOURCE());
            newMap.put("PCS_DT", PCS_DT);
            newsList.add(newMap);
            sb.setLength(0);
        }

        //�]�w�H�󥻤�tittle
        List<Map> tittle = new ArrayList<Map>();
        String[][] tittleArray = { { "SER_NO", "�Ǹ�", "5" }, { "INFO_SOURCE", "�T���ӷ�", "20" }, { "SUBJECT", "�D��", "50" },
                { "PCS_DT", "�T���B�z�ɶ�", "15" } };
        for (String[] fiels : tittleArray) {
            Map tittleMap = new HashMap();
            tittleMap.put("FIELD", fiels[0]);
            tittleMap.put("FIELD_NM", fiels[1]);
            tittleMap.put("FIELD_SIZE", fiels[2]);
            tittle.add(tittleMap);
        }

        String rtnMessage = mRZ_S00300.createRecord(eventID, "EP", DATE.today(), recpList, tittle, newsList);

        log.fatal("�o�e�����G" + rtnMessage);
        return rtnMessage;
    }

    /**
     * �H�H_���~�T��
     * @param eventID
     * @param errSites
     * @param recpList
     * @param pcsDT
     * @param mRZ_S00300
     * @throws ModuleException
     */
    private String sendErrorToReceivers(String eventID, List<DTEPZ302> errSites, List<Map> recpList, String pcsDT, RZ_S00300 mRZ_S00300)
            throws ModuleException {

        List<Map> errList = new ArrayList<Map>();
        int serNo = 0;
        StringBuilder sb = new StringBuilder();
        for (DTEPZ302 z302 : errSites) {
            Map errMap = new HashMap();
            serNo++;
            errMap.put("SER_NO", Integer.toString(serNo));
            errMap.put("INFO_SOURCE", sb.append("<a href=").append(z302.getURL()).append(">").append(z302.getINFO_SOURCE()).append("</a>")
                    .toString());
            sb.setLength(0);
            errMap.put("ERR_MSG", sb.append("�ѪR���~:").append(z302.getERR_MSG()).toString());
            sb.setLength(0);
            errMap.put("PCS_DT", pcsDT);
            errList.add(errMap);
        }

        //�]�w�H�󥻤�tittle
        List<Map> tittle = new ArrayList<Map>();
        String[][] tittleArray = { { "SER_NO", "�Ǹ�", "5" }, { "INFO_SOURCE", "�T���ӷ�", "25" }, { "ERR_MSG", "�B�z���G", "60" },
                { "PCS_DT", "�T���B�z�ɶ�", "10" } };
        for (String[] fiels : tittleArray) {
            Map tittleMap = new HashMap();
            tittleMap.put("FIELD", fiels[0]);
            tittleMap.put("FIELD_NM", fiels[1]);
            tittleMap.put("FIELD_SIZE", fiels[2]);
            tittle.add(tittleMap);
        }
        String rtnMessage = mRZ_S00300.createRecord(eventID + "ER", "EP", DATE.today(), recpList, tittle, errList);
        log.debug("�o�e�����G" + rtnMessage);
        return rtnMessage;
    }

    /**
     * [190515] �H�H_�H�H���ѰT��
     * @param eventID
     * @param errSites
     * @param recpList
     * @param pcsDT
     * @param mRZ_S00300
     * @throws ModuleException
     */
    //sendMailFailToReceivers("EPZ0_MAILCHK", FailList, recpList, DATE.currentTime().toString(), mRZ_S00300);
    private String sendMailFailToReceivers(String eventID, List<Map> FailList, List<Map> recpList, String pcsDT, RZ_S00300 mRZ_S00300)
            throws ModuleException {

        int serNo = 0;
        for (Map failMap : FailList) {
            serNo++;
            failMap.put("NO", Integer.toString(serNo));
            failMap.put("PCS_SEQ", MapUtils.getString(failMap, "PCS_SEQ", ""));
        }

        //�]�w�H�󥻤�tittle
        List<Map> tittle = new ArrayList<Map>();
        String[][] tittleArray = { { "NO", "�Ǹ�", "5" }, { "EVENT_ID", "�ƥ�N��", "10" }, { "PCS_SEQ", "�B�z�Ǹ�", "5" },
                { "FAIL_MSG", "���~�T��", "80" } };
        for (String[] fiels : tittleArray) {
            Map tittleMap = new HashMap();
            tittleMap.put("FIELD", fiels[0]);
            tittleMap.put("FIELD_NM", fiels[1]);
            tittleMap.put("FIELD_SIZE", fiels[2]);
            tittle.add(tittleMap);
        }
        String rtnMessage = mRZ_S00300.createRecord(eventID, "EP", DATE.today(), recpList, tittle, FailList);
        log.debug("�o�e�����G" + rtnMessage);
        return rtnMessage;
    }

    /**
     * �s�WDTEPZ301
     * @param rtnMap
     * @param PCS_DT
     * @return
     * @throws Exception 
     */
    private List<DTEPZ301> insertNews(Map<String, Object> rtnMap, Timestamp PCS_DT) throws Exception {
        budsZ301.clear();
        budsZ301.preparedBatch(SQL_insert_001);
        List<DTEPZ301> newsList = (List<DTEPZ301>) rtnMap.get("NEWS");

        if (newsList != null && !newsList.isEmpty()) {
            //�Ynews ����ơA�z�L BUDS ���@����X

            batchCount = (newsList.size() / commit_size) + 1;
            for (int i = 1; i <= batchCount; i++) {
                int initS = (i - 1) * commit_size;
                int initE = (i == batchCount) ? newsList.size() : i * commit_size; //�������
                budsZ301.beginTransaction(); //�������}�l
                try {
                    // �v���B�z
                    for (int j = initS; j < initE; j++) {
                        DTEPZ301 news = newsList.get(j);
                        budsZ301.setField("EVENT_ID", news.getEVENT_ID());
                        budsZ301.setField("PCS_SEQ", news.getPCS_SEQ());
                        budsZ301.setField("URL", news.getURL());
                        budsZ301.setField("INFO_SOURCE", news.getINFO_SOURCE());
                        budsZ301.setField("TITLE", getTextByByteLen(news.getTITLE(), 1100));//�̦줸�I����
                        budsZ301.setField("MEMO", getTextByByteLen(news.getMEMO(), 900));//�̦줸�I����
                        budsZ301.setField("PCS_DT", PCS_DT);
                        Timestamp PUBLISH_DT = news.getPUBLISH_DT();
                        budsZ301.setField("PUBLISH_DT", (PUBLISH_DT != null) ? PUBLISH_DT : PCS_DT);
                        budsZ301.addBatch();

                    }// while loop end

                    budsZ301.executeBatch();

                    Object theErrorObject[][] = budsZ301.getBatchUpdateErrorArray();
                    boolean sqlerror803 = false;
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {

                            SQLException sqlerror = (SQLException) theErrorObject[k][2];
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            if (-803 == sqlerror.getErrorCode()) {
                                sqlerror803 = true;
                            } else {
                                sqlerror803 = false;
                            }

                            String failMsg = new StringBuilder().append("�s�W�T������,��").append(theErrorObject[k][0]).append(
                                "����Ʀ��~ Insert setField = ").append(errorDataMap).toString();
                            Exception excp = (Exception) theErrorObject[k][2];
                            log.fatal(failMsg, excp);
                            this.formatFailMsg(FailList, MapUtils.getString(errorDataMap, "EVENT_ID"), MapUtils.getString(errorDataMap,
                                "PCS_SEQ"), failMsg + excp.getMessage());
                        }
                        if (pass803 && sqlerror803) {
                            log.fatal("�s�W��Ʀ��~[sql code = -803],PASS");
                        } else {
                            //��s��Ʀ��~
                            //throw new ModuleException(MessageUtil.getMessage("�s�W��Ʀ��~"));//�s�W��Ʀ��~  
                        }
                    }

                    budsZ301.endTransaction();

                } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                    budsZ301.endTransaction(); //��rollback
                    throw e; //�Y�o�Ϳ��~�h�{���X�פ�
                }
            } //for loop end
        }
        return newsList;
    }

    /**
     * �s�WDTEPZ302
     * @param rtnMap
     * @param PCS_DT
     * @return
     * @throws Exception 
     */
    private List<DTEPZ302> insertError(Map<String, Object> rtnMap, Timestamp PCS_DT) throws Exception {
        budsZ302.clear();
        budsZ302.preparedBatch(SQL_insert_002);
        List<DTEPZ302> errorsList = (List<DTEPZ302>) rtnMap.get("ERR_SITES");

        if (errorsList != null && !errorsList.isEmpty()) {
            //�Ynews ����ơA�z�L BUDS ���@����X

            batchCount = (errorsList.size() / commit_size) + 1;
            for (int i = 1; i <= batchCount; i++) {
                int initS = (i - 1) * commit_size;
                int initE = (i == batchCount) ? errorsList.size() : i * commit_size; //�������
                budsZ302.beginTransaction(); //�������}�l
                try {
                    // �v���B�z
                    for (int j = initS; j < initE; j++) {
                        DTEPZ302 errors = errorsList.get(j);
                        budsZ302.setField("EVENT_ID", errors.getEVENT_ID());
                        budsZ302.setField("PCS_SEQ", errors.getPCS_SEQ());
                        budsZ302.setField("INFO_SOURCE", errors.getINFO_SOURCE());
                        budsZ302.setField("URL", errors.getURL());
                        budsZ302.setField("ENCODING", errors.getENCODING());
                        budsZ302.setField("KEYWORD", errors.getKEYWORD());
                        budsZ302.setField("EXTRACTOR", errors.getEXTRACTOR());
                        budsZ302.setField("USER_AGENT", errors.getUSER_AGENT());
                        budsZ302.setField("ERR_MSG", getTextByByteLen(errors.getERR_MSG(), 200));
                        budsZ302.setField("STACK_TRACE", getTextByByteLen(errors.getSTACK_TRACE(), 1200));
                        budsZ302.setField("PCS_DT", PCS_DT);
                        budsZ302.addBatch();
                    }// while loop end
                    budsZ302.executeBatch();

                    Object theErrorObject[][] = budsZ302.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];

                            String failMsg = new StringBuilder().append("��s���~�T��,��").append(theErrorObject[k][0]).append(
                                "����Ʀ��~ Insert setField = ").append(errorDataMap).toString();
                            Exception excp = (Exception) theErrorObject[k][2];
                            log.fatal(failMsg, excp);
                            this.formatFailMsg(FailList, MapUtils.getString(errorDataMap, "EVENT_ID"), MapUtils.getString(errorDataMap,
                                "PCS_SEQ"), failMsg + excp.getMessage());
                        }
                        //��s��Ʀ��~
                        //throw new ModuleException(MessageUtil.getMessage("�s�W��Ʀ��~ "));//�s�W��Ʀ��~ 
                    }

                    budsZ302.endTransaction();

                } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                    budsZ302.endTransaction();//��rollback
                    throw e; //�Y�o�Ϳ��~�h�{���X�פ�
                }
            } //for loop end
        }
        return errorsList;
    }

    /**
     * �^���r�����
     * @param errMsg
     * @param byteLen
     * @return
     */
    private String getTextByByteLen(String errMsg, int byteLen) {
        if (StringUtils.isBlank(errMsg)) {
            return "";
        }
        try {
            //[20190507] �u��:���D�Bmemo�r�ƺI�_�A�קK�g�J��Ʈw���L��
            errMsg = STRING.subStringByByteArray(errMsg, byteLen, false, EncodingHelper.Charset_UTF8);
        } catch (Exception e1) {
            errMsg = errMsg.substring(0, (byteLen / 3));
        }
        return errMsg;
    }

    private void formatFailMsg(List<Map> FailList, String EVENT_ID, String PCS_SEQ, String failMsg) {
        Map failMap = new HashMap();
        failMap.put("EVENT_ID", EVENT_ID);
        failMap.put("PCS_SEQ", PCS_SEQ);
        failMap.put("FAIL_MSG", failMsg);
        FailList.add(failMap);
    }
}