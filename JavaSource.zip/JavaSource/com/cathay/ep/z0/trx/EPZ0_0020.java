package com.cathay.ep.z0.trx;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.CustomerBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.vo.DTEPZ003;
import com.cathay.ep.z0.module.EPZ0_0020_mod;
import com.cathay.ep.z0.module.EP_Z00010;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.FileStoreUtil;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 *     Date       Version Description Author
 *     2013/8/6    1.0    Created     ����i
 *     2018/03/07  �t�X��ؽվ� ����[
 *     
 *     UCEPZ0_0020_�ɮפW��
 *     
 *     �@�B  �{���\�෧�n�����G
 *     �{���\��    �ɮפW��
 *     �{���W��    EPZ0_0020
 *     �@�~�覡    ONLINE
 *     ���n����    (1) ��l
 *                 (2) �s�W �w �W���ɮ�
 *                 (3) �ק� �w �ק��ɮת���
 *                 (4) �v���]�w �w �s�����ɮ��v���]�wEPZ0_0030 
 *                 (5) �^�W�@�� �w �s���ܤW�@�������A�^���ɮ׽s��
 *     ���s���v    �M��FUNC_ID = EPZ00020
 *     �h��y�t    �M��
 *     �����q���
 *     �榡���js  �M��
 *     ����hotkey.js �M��
 * </pre>
 * @author �x�Ԫ�
 * @since  2013-08-28
 */
@SuppressWarnings("unchecked")
public class EPZ0_0020 extends CustomerBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPZ0_0020.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);

        try {
            String LP_JSON = ObjectUtils.toString(req.getParameter("LP_JSON"), null); // LP_JSON
            if (StringUtils.isNotBlank(LP_JSON)) {
                resp.addOutputData("LP_JSON", LP_JSON);
                //�ɭ����A�O�_����^
                String IS_BACK = ObjectUtils.toString(req.getParameter("IS_BACK"), "N");
                resp.addOutputData("IS_BACK", IS_BACK);

                // JSON�r���ફ��
                List<Map> listLP_JSON = VOTool.jsonAryToMaps(LP_JSON);
                int count = listLP_JSON.size() - 1;
                if (count >= 0) {
                    // ��@ VOTool.setParamsFromLP_JSON(req);
                    //���o�̫�@��LP_JSON
                    Map LP_JSONparams = listLP_JSON.get(count);

                    boolean isCheckParamsInRequest = "N".equals(IS_BACK);
                    resp.addOutputData("LP_JSONparams", LP_JSONparams);

                    //���O��^�ɱNLP_JSON�r���h�̫�@�Ӫ���
                    if (!isCheckParamsInRequest) {
                        Map LP_Map = new HashMap();
                        LP_Map.put("FILE_NO", listLP_JSON.get(0).get("FILE_NO"));
                        LP_Map.put("FILE_NM", listLP_JSON.get(0).get("FILE_NM"));
                        LP_Map.put("FILE_VER", listLP_JSON.get(0).get("FILE_VER"));
                        LP_Map.put("FILE_VER", listLP_JSON.get(0).get("FILE_VER"));
                        LP_Map.put("LINK_FROM", listLP_JSON.get(0).get("LINK_FROM"));
                        LP_Map.put("FILE_REMARK", listLP_JSON.get(0).get("FILE_REMARK"));
                        LP_Map.put("IS_NO_CHK", listLP_JSON.get(0).get("IS_NO_CHK"));
                        resp.addOutputData("LP_Map", VOTool.toJSON(LP_Map));
                        listLP_JSON.remove(count);
                        resp.addOutputData("LP_JSON", VOTool.toJSON(listLP_JSON));
                    }

                }
            } else {
                resp.addOutputData("FILE_NO", req.getParameter("FILE_NO"));//�ɮ׽s��
                resp.addOutputData("FILE_NM", req.getParameter("FILE_NM"));//�ɮצW��
                resp.addOutputData("FILE_VER", req.getParameter("FILE_VER"));//�ɮת���
                resp.addOutputData("FILE_REMARK", req.getParameter("FILE_REMARK"));//�ɮ׳Ƶ�
                resp.addOutputData("LINK_FROM", req.getParameter("LINK_FROM"));
                resp.addOutputData("IS_NO_CHK", req.getParameter("IS_NO_CHK"));
            }
        } catch (Exception e) {
            log.error("LP_JSON�ѪR���~�I", e);
        }
        /*resp.addOutputData("FILE_NO", req.getParameter("FILE_NO"));//�ɮ׽s��
        resp.addOutputData("FILE_NM", req.getParameter("FILE_NM"));//�ɮצW��
        resp.addOutputData("FILE_VER", req.getParameter("FILE_VER"));//�ɮת���
        resp.addOutputData("FILE_REMARK", req.getParameter("FILE_REMARK"));//�ɮ׳Ƶ�*/

        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);//�����q�O
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPZ0_0020_ERRMSG_001");//���o�����q�O����
        }
        return resp;
    }

    /**
     * ��l(�d��)
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            /*�ˮ֬O�_�i�ק�(�ݬ��ɮ׽s���t�d�H) */
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("FILE_NO", req.getParameter("FILE_NO"));//�ǤJ���u�ɮ׽s���v
            reqMap.put("INS_ID", user.getEmpID());// �ǤJ���u��J�H���v
            if (!"Y".equals(req.getParameter("IS_NO_CHK"))) {
                new EPZ0_0020_mod().checkINS_ID(reqMap);
            }
            List<Map> rtnList = new EP_Z00010().queryList(reqMap);
            resp.addOutputData("rtnList", rtnList);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���

        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        String FILE_NO = null;
        try {
            //���o�e���W�W�Ǫ�����
            FileItem fi = FileStoreUtil.parseUploadStream(req);

            //�Nuser�������Ʀs��chkMap
            String chkMapstr = req.getParameter("chkMap");
            String LINK_FROM = req.getParameter("LINK_FROM");
            FILE_NO = req.getParameter("FILE_NO_view");
            BigDecimal fi_Size = new BigDecimal(String.valueOf((float) fi.getSize() / 1024 / 1024)).setScale(3, BigDecimal.ROUND_HALF_UP);

            if ("EPF10101".equals(LINK_FROM) || "EPF10102".equals(LINK_FROM)) {
                if (fi_Size.compareTo(new BigDecimal(2.000)) > 0) {
                    throw new ModuleException(MessageUtil.getMessage("EPZ0_0020_ERRMSG_chkUPLOAD"));//�ɮפj�p���i�W�L2MB�A�Э��s�T�{�ɮפj�p
                }
            }
            Map chkMap = new HashMap();
            String EmpID = user.getEmpID();
            if (StringUtils.isNotBlank(chkMapstr)) {
                chkMap = VOTool.jsonToMap(chkMapstr);
                FILE_NO = MapUtils.getString(chkMap, "FILE_NO");
                //����ˮ֡G
                //�ˮ֬O�_�i�s�W�ɮ� 
                /*�O�_�i�s�W(�ݬ��ɮ׽s���t�d�H) */
                chkMap.put("INS_ID", EmpID);//��J�H��

                if (!"Y".equals(req.getParameter("IS_NO_CHK"))) {
                    new EPZ0_0020_mod().checkINS_ID(chkMap);
                }
            }
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            chkMap.put("SUB_CPY_ID", SUB_CPY_ID);//�����q�O

            //����s�W�{��
            DTEPZ003 EPZ003VO = new DTEPZ003();
            EPZ003VO.setFILE_NO(FILE_NO);//�ɮ׽s��
            String strfiName = fi.getName();
            String[] fisubNamearr = strfiName.split("\\.");
            EPZ003VO.setFILE_KIND(fisubNamearr[fisubNamearr.length - 1]);//�ɮ׺���(���ɦW)
            String[] fiNamearr = fisubNamearr[0].split("\\\\");

            EPZ003VO.setFILE_NM(fiNamearr[fiNamearr.length - 1]);//�ɮצW��
            EPZ003VO.setFILE_REMARK(req.getParameter("FILE_REMARK"));//�ɮ׳Ƶ�
            EPZ003VO.setSUB_CPY_ID(SUB_CPY_ID);//�����q�O
            EPZ003VO.setINS_DT(DATE.currentTime()); //��J���
            EPZ003VO.setINS_ID(EmpID); //��J�H��

            EPZ003VO.setINS_DIVNO(user.getOpUnit());//��J���

            Transaction.begin();
            try {
                FILE_NO = new EP_Z00010().insert(EPZ003VO, fi, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00004");//�s�W����
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00005");//�s�W����
        } finally {
            try {
                //�^�Ǫ����
                Map<String, Object> map = new HashMap<String, Object>();
                map.put(IConstantMap.ErrMsg, msg);
                map.put("FILE_NO", FILE_NO);

                EncodingHelper.send2iframe(req, map, msg);

            } catch (Exception e) {
                log.error("�W�ǵ��G����", e);
            }
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {
            //���o�e���W�W�Ǫ�����
            FileItem fi = FileStoreUtil.parseUploadStream(req);
            //�Nuser�������Ʀs��chkMap
            Map chkMap = VOTool.jsonToMap(req.getParameter("chkMap"));
            String FILE_NO = MapUtils.getString(chkMap, "FILE_NO");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            chkMap.put("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            String UPD_TYP = req.getParameter("UPD_TYP");
            chkMap.put("UPD_TYP", UPD_TYP);
            //�ˮ֬O�_�i�ק��ɮ� 
            /*�O�_�i�ק�(�ݬ��ɮ׽s���t�d�H) */
            new EPZ0_0020_mod().checkINS_ID(chkMap);
            //��ƳB�z�G�Y���~�hROLLBACK
            //����ק�{��
            DTEPZ003 EPZ003VO = new DTEPZ003();
            EPZ003VO.setFILE_ID(MapUtils.getString(chkMap, "FILE_ID"));
            EPZ003VO.setFILE_NO(FILE_NO);//�ɮ׽s��
            String strfiName = fi.getName();
            if (StringUtils.isNotBlank(strfiName)) {
                String[] fisubNamearr = strfiName.split("\\.");
                EPZ003VO.setFILE_KIND(fisubNamearr[fisubNamearr.length - 1]);//�ɮ׺���(���ɦW)
                String[] fiNamearr = fisubNamearr[0].split("\\\\");
                EPZ003VO.setFILE_NM(fiNamearr[fiNamearr.length - 1]);//�ɮצW��
            } else {
                fi = null;
                EPZ003VO.setFILE_KIND(MapUtils.getString(chkMap, "FILE_KIND"));
                EPZ003VO.setFILE_NM(MapUtils.getString(chkMap, "FILE_NM"));
            }
            EPZ003VO.setFILE_VER(MapUtils.getInteger(chkMap, "FILE_VER"));//�ɮת��� 
            EPZ003VO.setFILE_REMARK(req.getParameter("FILE_REMARK"));//�ɮ׳Ƶ�
            EPZ003VO.setSUB_CPY_ID(SUB_CPY_ID);//�����q�O
            EPZ003VO.setINS_DT(DATE.currentTime()); //��J���
            EPZ003VO.setINS_ID(user.getEmpID());//��J�H��
            EPZ003VO.setINS_DIVNO(user.getOpUnit());//��J���

            Transaction.begin();
            try {
                new EP_Z00010().update(EPZ003VO, UPD_TYP, fi, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPZ0_0020_MSG_001");//�ק粒��
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPZ0_0020_ERRMSG_002");//�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPZ0_0020_ERRMSG_002");//�ק異��
        } finally {

            try {
                //�^�Ǫ����
                Map<String, Object> map = new HashMap<String, Object>();
                map.put(IConstantMap.ErrMsg, msg);

                EncodingHelper.send2iframe(req, map, msg);

            } catch (Exception e) {
                log.error("�W�ǵ��G����", e);
            }
        }

        return resp;
    }

}
