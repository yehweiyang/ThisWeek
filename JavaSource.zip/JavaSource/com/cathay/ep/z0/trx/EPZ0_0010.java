package com.cathay.ep.z0.trx;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.CustomerBean;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.vo.DTEPZ003;
import com.cathay.ep.vo.DTEPZ004;
import com.cathay.ep.z0.module.EPZ0_0010_mod;
import com.cathay.ep.z0.module.EP_Z00010;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.RptUtils;
import com.cathay.rz.t0.module.RZ_T0Z001;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 *     Date        Version Description Author
 *     2013/8/6    1.0     Created     ����i
 *     2018/03/07  �t�X��ؽվ� ����[
 *     UCEPZ0_0010_�ɮ׬d��
 *     
 *     �@�B  �{���\�෧�n�����G
 *      �{���\��    �ɮ׬d��
 *      �{���W��    EPZ0_0010
 *      �@�~�覡    ONLINE
 *      ���n����    (1) ��l
 *                  (2) �d�� �w �ϥΪ̫��U�d�߫��s��A�I�sEP_Z00010�Ҳը��o�ɮײM���ơC
 *                  (3) �R�� �w �R���ɮ�
 *                  (4) �ɮפW�� �w �s����EPZ0_0020�s�W�ɮ�
 *                  (5) �U�� �w �ɮפU��
 *                  (6) �ɮ׽s�� �w �s�����ɮפW��EPZ0_0020��s�ɮ�
 *      ���s���v    �M��FUNC_ID = EPZ00010
 *      �h��y�t    �M��
 *      �����q���
 *      �榡���js  �M��
 *      ����hotkey.js �M��
 * </pre>
 * @author �x�Ԫ�
 * @since  2013-08-28 
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPZ0_0010 extends CustomerBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPZ0_0010.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);
        try {
            String LP_JSON = ObjectUtils.toString(req.getParameter("LP_JSON"), null); // LP_JSON

            if (StringUtils.isNotBlank(LP_JSON)) {
                resp.addOutputData("LP_JSON", LP_JSON);
                //�ɭ����A�O�_����^
                String IS_BACK = ObjectUtils.toString(req.getParameter("IS_BACK"), "N");
                resp.addOutputData("IS_BACK", IS_BACK);

                // JSON�r���ફ��
                List<Map> listLP_JSON = VOTool.jsonAryToMaps(LP_JSON);
                int count = listLP_JSON.size() - 1;
                if (count >= 0) {
                    // ��@ VOTool.setParamsFromLP_JSON(req);
                    //���o�̫�@��LP_JSON
                    Map LP_JSONparams = listLP_JSON.get(count);

                    boolean isCheckParamsInRequest = "N".equals(IS_BACK);
                    resp.addOutputData("LP_JSONparams", LP_JSONparams);

                    //���O��^�ɱNLP_JSON�r���h�̫�@�Ӫ���
                    if (!isCheckParamsInRequest) {
                        Map LP_Map = new HashMap();
                        LP_Map.put("LINK_FROM", listLP_JSON.get(0).get("LINK_FROM"));
                        LP_Map.put("FILE_NO", listLP_JSON.get(0).get("FILE_NO"));
                        LP_Map.put("FILE_NM", listLP_JSON.get(0).get("FILE_NM"));
                        LP_Map.put("FILE_REMARK", listLP_JSON.get(0).get("FILE_REMARK"));
                        LP_Map.put("IS_NO_CHK", listLP_JSON.get(0).get("IS_NO_CHK"));
                        resp.addOutputData("LP_Map", VOTool.toJSON(LP_Map));
                        listLP_JSON.remove(count);
                        resp.addOutputData("LP_JSON", VOTool.toJSON(listLP_JSON));
                    }

                }
            } else {
                resp.addOutputData("LINK_FROM", req.getParameter("LINK_FROM"));
                resp.addOutputData("FILE_NO", req.getParameter("FILE_NO"));//�ɮ׽s��
                resp.addOutputData("FILE_NM", req.getParameter("FILE_NM"));//�ɮצW��
                resp.addOutputData("FILE_REMARK", req.getParameter("FILE_REMARK"));//�ɮ׳Ƶ�
                resp.addOutputData("IS_NO_CHK", req.getParameter("IS_NO_CHK"));//�O�_�ˮֱ��v
                resp.addOutputData("IS_FIX_NO", req.getParameter("IS_FIX_NO"));//�O�_����µ�ץ�
            }
        } catch (Exception e) {
            log.error("LP_JSON�ѪR���~�I", e);
        }

        /*resp.addOutputData("FILE_NO", req.getParameter("FILE_NO"));//�ɮ׽s��
        resp.addOutputData("FILE_NM", req.getParameter("FILE_NM"));//�ɮצW��
        resp.addOutputData("FILE_REMARK", req.getParameter("FILE_REMARK"));//�ɮ׳Ƶ�
        resp.addOutputData("IS_NO_CHK", req.getParameter("IS_NO_CHK"));//�O�_�ˮֱ��v*/

        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);//�����q�O
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPZ0_0010_ERRMSG_001");//���o�����q�O����
        }
        resp.addOutputData("EmpID", user.getEmpID());
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            this.query(reqMap);
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPZ0_0010_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �R��
     * @param req 
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            List<DTEPZ003> chkList = VOTool.jsonAryToVOs(DTEPZ003.class, req.getParameter("chkList"));
            String EmpID = user.getEmpID();
            EPZ0_0010_mod theEPZ0_0010_mod = new EPZ0_0010_mod();
            for (DTEPZ003 EPZ003VO : chkList) {
                EPZ003VO.setINS_ID(EmpID); //��J�H��
                theEPZ0_0010_mod.checkINS_ID(EPZ003VO);
            }
            EP_Z00010 theEP_Z00010 = new EP_Z00010();

            Transaction.begin();
            try {
                for (DTEPZ003 EPZ003VO : chkList) {
                    theEP_Z00010.delete(EPZ003VO, user);
                }
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00010");//�R������
            try {
                Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
                this.query(reqMap);
            } catch (DataNotFoundException e) {
                log.error("�R�������A�d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00012");//�R�����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPZ0_0010_ERRMSG_002");//�@�~����
            }
        } catch (Exception e) {
            log.error("�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPZ0_0010_ERRMSG_002");//�@�~����
        }

        return resp;
    }

    /**
     * �ɮפU��
     * @param req
     * @return
     */
    public ResponseContext doDownload(RequestContext req) {
        try {
            DTEPZ004 EPZ004VO = VOTool.jsonToVO(DTEPZ004.class, req.getParameter("EPZ004VO"));
            if (!"Y".equals(req.getParameter("IS_NO_CHK"))) {
                if (!user.getEmpID().equals(EPZ004VO.getINS_ID())) {
                    new EPZ0_0010_mod().checkCOM_DATE(EPZ004VO, user);
                }
            }
            //���o�ɮ׽s��
            //�I��U����A�i���o�ɮ׸��|�äU���ɮ�
            //[20200519] fix bug:�ǤJ�����q�O�Ϥ���ءB���
            String[] fileInfoData = new RZ_T0Z001().getDownloadFilePathByDiv(req.getParameter("FILE_ID"), user.getCOMP_ID());

            //�^�ǵ�����
            RptUtils.cryptoDownloadParameterToResp(fileInfoData[0], fileInfoData[1], resp);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPZ0_0010_ERRMSG_003");//�ɮפU������
            }
        } catch (Exception e) {
            log.error("�ɮפU������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPZ0_0010_ERRMSG_003");//�ɮפU������
        }
        return resp;
    }

    /**
     * �d��
     * @param reqMap
     * @throws ModuleException
     * @throws SQLException
     */
    private void query(Map reqMap) throws ModuleException, SQLException {
        List<Map> rtnList = new EP_Z00010().queryList(reqMap);
        resp.addOutputData("rtnList", rtnList);
    }
}