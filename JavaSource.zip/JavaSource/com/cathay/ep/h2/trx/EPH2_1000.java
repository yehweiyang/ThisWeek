package com.cathay.ep.h2.trx;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Map;
import java.util.Random;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.security.AESHelper;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.common.util.annotation.CallMethod;
import com.igsapp.common.util.annotation.TxBean;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * �q�l�a�ϤJ�f
 * </pre>
 * @author �©s��
 * @since 2019/7/17
 * [20190807] �վ�UserRoles�ϥ�containsKey �P�_�O�_��ƯS�w�������
 * [20191113] �վ�W�[�J�f���}�s��
 */
@TxBean
@SuppressWarnings({ "rawtypes" })
public class EPH2_1000 extends UCBean {
    /** log */
    private static final Logger log = Logger.getLogger(EPH2_1000.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /**
     * �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@
     */
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        //�@�w�n invoke super.start() �H�����v���ˮ�
        super.start(req);
        //�I�s�۩w����l�ʧ@
        initApp(req);
        return null;
    }

    /**
     * �{�Ǧۤv����l�ʧ@�A�q�`�����X ResponseContext �� UserObject �γ]�w ReturnMessage
     */
    private void initApp(RequestContext req) {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        user = this.getUserObject(req);
        msg = new ReturnMessage();
        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);
        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        resp.setResponseCode(CallMethod.CODE_SUCCESS);
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    @CallMethod(action = "prompt", url = "/EP/H2/EPH2_1000/EPH21000.jsp")
    public ResponseContext doPrompt(RequestContext req) {
        try {
            String BLD_TYPE = req.getParameter("BLD_TYPE");
            if (StringUtils.isBlank(BLD_TYPE)) {
                BLD_TYPE = "";
            }
            String BLD_CD = req.getParameter("BLD_CD");
            if (StringUtils.isBlank(BLD_CD)) {
                BLD_CD = "";
            }
            Map EMAP_ENTRY_Map = FieldOptionList.getFieldOptions("EP", "EMAP_ENTRY");
            Map EMAP_PARAM_Map = FieldOptionList.getFieldOptions("EP", "EMAP_PARAM");
            //�q�l�a�Ϯץ����
            Map EMAP_CASE_TYPE = FieldOptionList.getFieldOptions("EP", "EMAP_CASE_TYPE");
          //�q�l�a�Ϩ������
            Map EMAP_ROLE_TYPE = FieldOptionList.getFieldOptions("EP", "EMAP_ROLE_TYPE");

            String URL = MapUtils.getString(EMAP_ENTRY_Map, "URL");
            String DT = MapUtils.getString(EMAP_PARAM_Map, "DT");
            String DIV_NO = MapUtils.getString(EMAP_PARAM_Map, "DIV_NO");
            String DIV_NAME = MapUtils.getString(EMAP_PARAM_Map, "DIV_NAME");
            String ID = MapUtils.getString(EMAP_PARAM_Map, "ID");
            String NAME = MapUtils.getString(EMAP_PARAM_Map, "NAME");
            String ROLE = MapUtils.getString(EMAP_PARAM_Map, "ROLE");
            String BLD_CD_NM = MapUtils.getString(EMAP_PARAM_Map, "BLD_CD");
            String BLD_TYPE_NM = MapUtils.getString(EMAP_PARAM_Map, "BLD_TYPE");
            String TARGET = MapUtils.getString(EMAP_PARAM_Map, "TARGET");
            String SYS = MapUtils.getString(EMAP_PARAM_Map, "SYS");

            StringBuilder sb = new StringBuilder();
            Calendar cal = Calendar.getInstance();
            sb.append(DT).append('=').append(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(cal.getTime()));
            sb.append('+').append(DIV_NO).append('=').append(user.getOpUnit());
            sb.append('+').append(DIV_NAME).append('=').append(user.getDivShortName());
            sb.append('+').append(ID).append('=').append(user.getEmpID());
            sb.append('+').append(NAME).append('=').append(user.getEmpName());
            String userRole = MapUtils.getString(EMAP_ROLE_TYPE, this.getRoleType(),"");
            sb.append('+').append(ROLE).append('=').append(userRole);
            sb.append('+').append(BLD_CD_NM).append('=').append(BLD_CD);
            sb.append('+').append(BLD_TYPE_NM).append('=').append(MapUtils.getString(EMAP_CASE_TYPE, BLD_TYPE,""));
            sb.append('+').append(TARGET).append('=').append("1");
            sb.append('+').append(SYS).append('=').append("EP");
            sb.append('+').append(this.getRandomAZ());
           log.debug("MapEntry: "+sb.toString());
            String aesKey = MapUtils.getString(EMAP_ENTRY_Map, "AES_KEY");
            String TOKEN = new AESHelper(aesKey, true).encryptString(sb.toString());            
            log.debug("Map Entry TOKEN:"+TOKEN);
            String urlToken = getUrlEncodeUTF8(TOKEN);
            log.debug("URLTOKEN:"+urlToken);
            sb.setLength(0);
            String mapEntryURL = sb.append(URL).append("?token=").append(urlToken).toString();
            log.debug("MapEntryURL:"+ mapEntryURL);
			resp.addOutputData("URL", mapEntryURL);
            if(StringUtils.isNotEmpty(BLD_TYPE)) {
            	resp.addOutputData("AUTO_CLOSE", "Y");
            }
        } catch (Exception e) {
            log.error("��}�q�l�a�ϵo�Ϳ��~", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH2_1000_ERRMSG_001");//��}�q�l�a�ϵo�Ϳ��~
        }
        return resp;
    }

    

    /**
     * �নUTF8�榡
     * @param val
     * @return
     * @throws UnsupportedEncodingException
     */
    private String getUrlEncodeUTF8(String val) throws UnsupportedEncodingException {
        String xmString = new String(val.getBytes("UTF-8"));
        String xmlUTF8 = URLEncoder.encode(xmString, "UTF-8");
        return xmlUTF8;
    }
    /**
     * ���o�H�������v��
     * @param user
     * @return 1:���ʲ��޲z�ӿ�;2:���ʲ��޲z�D��;3:���ʲ��޲z;4:���ʲ�����
     */
    private String getRoleType() {
        Map<String, String> mapEntry = FieldOptionList.getFieldOptions("EP", "EMAP_ENTRY");
        String fixRole = MapUtils.getString(mapEntry, "ROLE");
        if(StringUtils.isNotEmpty(fixRole)) {
        	return fixRole;
        }


        //���ʲ��޲z��ӿ쨤�� (�޲z��: 1)
        Map<String, String> mapUserRoles = FieldOptionList.getFieldOptions("EP", "EMAP_MGT_ROLE");
        //���ʲ��q�l�a�Ϩt�κ޲z���� (�޲z��:2�B ����:4)
        Map<String, String> mapAdmRoles = FieldOptionList.getFieldOptions("EP", "EMAP_ADM_ROLE");
        //���ʲ����쨤�� (����: 3)
        Map<String, String> mapInvRoles = FieldOptionList.getFieldOptions("EP", "EMAP_INV_ROLE");
      //�q�l�a�Ϩt�κ޲z���� (���ʲ���T��)
        Map<String, String> mapSysAdminRoles = FieldOptionList.getFieldOptions("EP", "EMAP_SYS_ROLE");

        Hashtable userRoles = user.getRoles();

        // �O�_�����ʲ����쨤��
        boolean isEpInvUser = false;
        for (String key : mapInvRoles.keySet()) {
            if (userRoles.containsKey(key)) {
            	isEpInvUser = true;
            	break;
            }
        }        
        //�q�l�a�Ϩt�κ޲z�H��
        for (String key : mapAdmRoles.keySet()) {
            if (userRoles.containsKey(key)) {
            	if(isEpInvUser) {
            		//���ʲ�����t�κ޲z�H��
            		return "4";
            	} else {
            		//���ʲ��޲z��t�κ޲z�H��
            		return "2";	
            	}
                
            }
        }


        //�q�l�a�Ϩt�κ޲z���� 5
        for (String key : mapSysAdminRoles.keySet()) {
            if (userRoles.containsKey(key)) {
                return "5";
            }
        }


        //���ʲ����쨤�� 3
        if(isEpInvUser) {
        	return "3";
        }
        
        for (String key : mapUserRoles.keySet()) {
            if (userRoles.containsKey(key)) {
                return "1";
            }
        }
        //�@��ϥΪ�
        return "0";

    }

    /**
     * ���o�H��a~z�r��
     * @return
     */
    private char getRandomAZ() {
        int ia = (int) 'a';
        int iz = (int) 'z';
        int ranInt = this.getRandomNumberInRange(ia, iz);
        return new Character((char) ranInt);
    }

    /**
     * ���o�b�϶������H���Ʀr
     * @param min
     * @param max
     * @return
     */
    private int getRandomNumberInRange(int min, int max) {
        if (min > max) {
            throw new IllegalArgumentException("max must be greater than min");
        }
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
}
