package com.cathay.ep.b3.module;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 * DATE    Description Author
 * 2013/11/20  Created ���կ�
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �f�ֲM�U���@�Ҳ�
 * �Ҳ�ID    EP_B30050
 * ���n����    �f�ֲM�U���@�Ҳ�
 * </pre>
 * @author �¶��� 
 * @since 2013/12/5  
 */
@SuppressWarnings("unchecked")
public class EP_B30050 {

    private static final String SQL_queryList_001 = "com.cathay.ep.b3.module.EP_B30050.SQL_queryList_001";

    /**
     * Ū���ץ�_�ܧ�����ɲM��
     * @param SUB_CPY_ID �����q�O
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(String SUB_CPY_ID, Map reqMap, ResponseContext resp, boolean isFirstQuery, Integer startWith, Integer endWith)
            throws ModuleException {
        //�ˮֶǤJ�Ѽ�
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30050_MSG_001"));//�d�߱��󤣱o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {//
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30050_MSG_002"));//�����q�O���o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        String APLY_STR_DATE = MapUtils.getString(reqMap, "APLY_STR_DATE");
        String APLY_END_DATE = MapUtils.getString(reqMap, "APLY_END_DATE");
        if (StringUtils.isNotBlank(APLY_STR_DATE) && !DATE.isDate(APLY_STR_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30050_MSG_003"));//�ǤJ�߮װ_�����榡���~
        }
        if (StringUtils.isNotBlank(APLY_END_DATE) && !DATE.isDate(APLY_END_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30050_MSG_004"));//�ǤJ�߮ר������榡���~
        }
        if (eie != null) {
            throw eie;
        }
        

        String APLY_STS = MapUtils.getString(reqMap, "APLY_STS");
        String INPUT_DIV_NO = MapUtils.getString(reqMap, "INPUT_DIV_NO");
        String INPUT_NAME = MapUtils.getString(reqMap, "INPUT_NAME");
        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if ("1".equals(APLY_STS)) { //�ݼf��
            ds.setFieldValues("OP_STATUS", new String[] { "02" });//02�e��ݼf
        } else {
            ds.setFieldValues("OP_STATUS", new String[] { "03", "04" });//03�w���ݤJ�� 04����
        }
        if (StringUtils.isNotBlank(APLY_STR_DATE)) {
            ds.setField("APLY_STR_DATE", APLY_STR_DATE);
        }
        if (StringUtils.isNotBlank(APLY_END_DATE)) {
            ds.setField("APLY_END_DATE", APLY_END_DATE);
        }
        if (StringUtils.isNotBlank(INPUT_DIV_NO)) {
            ds.setField("INPUT_DIV_NO", INPUT_DIV_NO);
        }

        if (StringUtils.isNotBlank(INPUT_NAME)) {
            ds.setField("INPUT_NAME", INPUT_NAME);
        }

        Set<String> expTrnKind = FieldOptionList.getName("EP", "APRV_NOT_QUERY_B401").keySet(); //103.5.20�d�߱ư�������N��(��USER�ݨD) �ثe���ư�EPA007�j�Өϥη��p��s

        if(expTrnKind != null){
            ds.setFieldValues("expTrnKind", expTrnKind.toArray());
        }
        
        if (isFirstQuery) {
            DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
            resp.addOutputData("totalOfRecords", ds.count()); // ���o-�`����,�u�����\��T�w�ѼƦW��
        }

        ds.setFetchRange(startWith, endWith);//�u�����\�� �_����ƦC �]�w
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);

        Integer indexStart = startWith;
        for (Map map : rtnList) {
            map.put("PK_SER_NO", indexStart++);
            map.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(map, "TRN_KIND")));
            map.put("OP_STATUS_NM", FieldOptionList.getName("EP", "APLY_OP_STATUS", MapUtils.getString(map, "OP_STATUS", "").trim()));
        }

        return rtnList;

    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}
