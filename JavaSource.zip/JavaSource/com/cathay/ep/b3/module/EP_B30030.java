package com.cathay.ep.b3.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.a1.module.EP_A10030;
import com.cathay.ep.a1.module.EP_A10040;
import com.cathay.ep.b1.module.EP_B10010;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.b1.module.EP_B10100;
import com.cathay.ep.vo.DTEPA103;
import com.cathay.ep.vo.DTEPA104;
import com.cathay.ep.vo.DTEPB101;
import com.cathay.ep.vo.DTEPB102;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPB303;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/** 
 * <pre>
 * DATE    Description Author
 * 2013/09/13  Created ���կ�
 * 2018/03/07   �t�X��ؽվ� ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �����״��ܧ���@�Ҳ�
 * �Ҳ�ID    EP_B30030
 * ���n����    �����״��ܧ���@�Ҳ�
 * </pre>
 * @author �¶��� 
 * @since 2013/11/18  
 */
@SuppressWarnings("unchecked")
public class EP_B30030 {

    private static final String SQL_queryList_001 = "com.cathay.ep.b3.module.EP_B30030.SQL_queryList_001";

    private static final Logger log = Logger.getLogger(EP_B30030.class);

    /**
     * Ū�������״��ܧ�����ɲM��
     * @param reqMap
     * @return rtnList ����_�ӯ�������DTEPB303(�h��)
     * @throws ModuleException 
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {

        //�ǤJ�Ѽ��ˮ�
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_B30030_MSG_001"));//�ǤJ��Ƥ��i����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_003"));//�ǤJ�ץ�s�����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        DataSet ds = Transaction.getDataSet();
        if (StringUtils.isNotBlank(CRT_NO)) {
            ds.setField("CRT_NO", CRT_NO);
        }
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);

        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        List<Map> rtnList = new ArrayList();
        while (ds.next()) {
            Map tmpMap = VOTool.dataSetToMap(ds);
            tmpMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(tmpMap, "TRN_KIND_EPB301")));
            rtnList.add(tmpMap);
        }

        return rtnList;

    }

    /**
     * �s�W
     * @param reqMap
     * @param TRN_KIND �������
     * @param BLD_CD �j�ӥN��
     * @throws ModuleException
     */
    public void insert(Map reqMap, String TRN_KIND, String BLD_CD) throws ModuleException {
        //�ˮֶǤJ�Ѽ�
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_B30030_MSG_001"));//�ǤJ��Ƥ��i����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        String RNT_END_DATE = MapUtils.getString(reqMap, "RNT_END_DATE");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_003"));//�ǤJ�ץ�s�����o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_004"));//�ǤJ�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_005"));//�ǤJ�Ȥ�Ǹ����o���ŭ�
        }
        if (StringUtils.isBlank(RNT_END_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_006"));//�ǤJ������o���ŭ�
        }
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_007"));//�ǤJ����������o���ŭ�
        }
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_008"));//�ǤJ�j�ӥN�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�զ��ӯ����ܧ���
        Map B102Map = new HashMap();
        B102Map.put("SUB_CPY_ID", SUB_CPY_ID);
        B102Map.put("CRT_NO", CRT_NO);
        B102Map.put("CUS_NO", CUS_NO);
        DTEPB303 B303Vo = VOTool.mapToVO(DTEPB303.class, new EP_B10020().queryMap(B102Map));
        B303Vo.setAPLY_NO(APLY_NO);
        B303Vo.setDATA_TYPE("A");
        String today = DATE.getDBDate();
        if ("EPB004".equals(TRN_KIND)) {//�����״�(����)
            B303Vo.setRNT_STR_DATE(Date.valueOf(DATE.addDate(B303Vo.getRNT_END_DATE().toString(), 0, 0, 1))); //�����״������_�鬰�������1��
            B303Vo.setRNT_END_DATE(Date.valueOf(RNT_END_DATE));
            B303Vo.setRNT_AMT(str2Big(reqMap, "RNT_AMT", null));
            B303Vo.setPMS_AMT(str2Big(reqMap, "PMS_AMT", null));
        } else {
            B303Vo.setRNT_END_DATE(Date.valueOf(RNT_END_DATE));
            //���e�פ�B�������� <= ���Ѫ�
            if (("EPB007".equals(TRN_KIND)) && !(DATE.diffDay(today, RNT_END_DATE) > 0)) {
                B303Vo.setCUS_STS("3");
            } else if ("EPB005".equals(TRN_KIND) || "EPB006".equals(TRN_KIND)) {
                B303Vo.setCUS_STS("3");
            }

        }
        if (!"EPB007".equals(TRN_KIND) && !"EPB005".equals(TRN_KIND)) {//103.6.19 USER���D��20140619094402: ���e�פ�]�w����ΫȤ��ӤS�����F�y���H�����D, ���S�w���O�ݶ}�H�����o�����Ȥ�, �G�|�N�����״����b�����_�餧�e(USER���Ѭ��L�k�}�o��).�z�p���Ѭ��]�n�i�H�ר�<�l��
            if (DATE.diffDay(B303Vo.getRNT_END_DATE(), B303Vo.getRNT_STR_DATE()) > 0) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_B30030_MSG_017"));//��J������~, �ק��ӯ��ᤧ�_����j�󨴯���
            }
        }
        new EP_B10020().insertDTEPB303(B303Vo, "U", null); //�ާ@���� U �ק�

        //��s�ץ��ܧ�����j�ӤΫ�����T
        DTEPB301 EPB301VO = new DTEPB301();
        EPB301VO.setAPLY_NO(B303Vo.getAPLY_NO());
        EPB301VO.setCRT_NO(B303Vo.getCRT_NO());
        EPB301VO.setBLD_CD(BLD_CD);
        EPB301VO.setSUB_CPY_ID(SUB_CPY_ID);
        new EP_B30010().updateDTEPB301MainInfo(EPB301VO);

    }

    /**
     * �����״��ܧ��Ю֤J�D��
     * @param B301Vo
     * @param UPD_TIME ��s����ɶ�
     * @param crtInfoList
     * @throws Exception 
     */
    public void approve(DTEPB301 B301Vo, Timestamp UPD_TIME, List<Map> crtInfoList) throws Exception {

        //�ˮֶǤJ�Ѽ�
        if (B301Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_B30030_MSG_001"));//�ǤJ��Ƥ��i����
        }
        ErrorInputException eie = null;

        if (StringUtils.isBlank(B301Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(B301Vo.getAPLY_NO())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_003"));//�ǤJ�ץ�s�����o���ŭ�
        }
        if (StringUtils.isBlank(B301Vo.getCRT_NO())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_004"));//�ǤJ�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(B301Vo.getBLD_CD())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_008"));//�ǤJ�j�ӥN�����o���ŭ�
        }
        if (StringUtils.isBlank(B301Vo.getTRN_KIND())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_007"));//�ǤJ����������o���ŭ�
        }
        if (StringUtils.isBlank(B301Vo.getINPUT_DIV_NO())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_009"));//�ǤJ��J�H����줣�o���ŭ�
        }
        if (StringUtils.isBlank(B301Vo.getINPUT_NAME())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_010"));//�ǤJ��J�H���m�W���o���ŭ�
        }
        if (StringUtils.isBlank(B301Vo.getINPUT_ID())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_011"));//�ǤJ��J�H�����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        Map reqMap = VOTool.voToMap(B301Vo);
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        String reqSUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String reqCRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String reqBLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        //���o�쫴����T
        Map tmpMap = new HashMap();
        tmpMap.put("SUB_CPY_ID", reqSUB_CPY_ID);
        tmpMap.put("CRT_NO", reqCRT_NO);

        Map mainMap = new EP_B10010().queryMap(tmpMap);
        DTEPB101 orgB101Vo = VOTool.mapToVO(DTEPB101.class, mainMap);
        //���o�״��ܧ�Ȧs�ɸ��
        List<Map> rtnList = queryList(reqMap);

        EP_B10020 theEP_B10020 = new EP_B10020();
        EP_B10100 theEP_B10100 = new EP_B10100();
        EP_B30020 theEP_B30020 = new EP_B30020();
        String B301_INPUT_DIV_NO = B301Vo.getINPUT_DIV_NO();
        String B301_INPUT_ID = B301Vo.getINPUT_ID();
        String B301_INPUT_NAME = B301Vo.getINPUT_NAME();
        String B301_APLY_NO = B301Vo.getAPLY_NO();
        String B301_TRN_KIND = B301Vo.getTRN_KIND();

        String today = DATE.getDBDate();
        String TRN_KIND = B301_TRN_KIND;
        //�]�w�ϥΪ̸�T
        Map userMap = new HashMap();
        userMap.put("CHG_DIV_NO", B301_INPUT_DIV_NO);
        userMap.put("CHG_ID", B301_INPUT_ID);
        userMap.put("CHG_NAME", B301_INPUT_NAME);
        for (Map rtnMap : rtnList) {
            //��s�ǧO�B�z
            updRmProc(rtnMap, TRN_KIND, UPD_TIME);
            //��s����B�z
            updCarProc(rtnMap, TRN_KIND, UPD_TIME);

            //���o��ӯ����T
            tmpMap.put("CUS_NO", MapUtils.getString(rtnMap, "CUS_NO"));

            Map cusMap = theEP_B10020.queryMap(tmpMap);
            //�H�Ȧs�ɸ�Ƨ�s�ӯ�����
            DTEPB102 B102Vo = VOTool.mapToVO(DTEPB102.class, rtnMap);
            B102Vo.setCHG_DATE(UPD_TIME);
            B102Vo.setCHG_DIV_NO(B301_INPUT_DIV_NO);
            B102Vo.setCHG_ID(B301_INPUT_ID);
            B102Vo.setCHG_NAME(B301_INPUT_NAME);
            B102Vo.setAPLY_NO(B301_APLY_NO);
            B102Vo.setTRN_KIND(B301_TRN_KIND);
            B102Vo.setRNT_CHG_ID(B301_INPUT_ID);
            B102Vo.setRNT_CHG_NAME(B301_INPUT_NAME);
            B102Vo.setRNT_CHG_DATE(UPD_TIME);
            B102Vo.setRNT_CHG_APLYNO(B301_APLY_NO);
            B102Vo.setRNT_CHG_TRNKD(B301_TRN_KIND);
            if ("EPB007".equals(B301_TRN_KIND) && !(DATE.diffDay(today, MapUtils.getString(rtnMap, "RNT_END_DATE")) > 0)) {
                //�Y���e�פ�f�֮�, �ܧ�󪺫����״�<=����, �Y�w����, �h���A�אּ�פ�(�i���J�ɩ|������, ���f�֮ɤw�����h���M���אּ����)
                B102Vo.setCUS_STS("3");
            }

            theEP_B10020.updateDTEPB102(B102Vo, DATE.currentTime().toString(), APLY_NO, TRN_KIND);

            //�Y���������EPB007���e�פ�B��������>���Ѫ�(���|���W��s���פ�ץ�)�ݰ�IFRS�B�z
            //�w��פ���ݭn�B�zIFRS
            if ("EPB007".equals(TRN_KIND)) {
                rtnMap.put("TRN_KIND", B301_TRN_KIND);
                if (DATE.diffDay(today, MapUtils.getString(rtnMap, "RNT_END_DATE")) > 0
                        && !"B".equals(MapUtils.getString(rtnMap, "DATA_TYPE"))) {
                    mainMap.put("DATA_TYPE", "O");
                    Map chkMap = theEP_B10100.IFRSProc(mainMap, rtnMap, mainMap, cusMap, "U", "N", userMap);
                    if (MapUtils.getBoolean(chkMap, "IS_MAIL", false)) {
                        Map mailMap = new HashMap();
                        mailMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", TRN_KIND));
                        mailMap.put("CRT_NO", MapUtils.getString(cusMap, "CRT_NO"));
                        mailMap.put("CUS_NO", MapUtils.getString(cusMap, "CUS_NO"));
                        mailMap.put("INFM_MSG", MessageUtil.getMessage("EP_B30030_MSG_016"));//�жi��IFRS�պ�T�{�@�~
                        crtInfoList.add(mailMap);
                    }
                }
            } else if ("EPB004".equals(TRN_KIND)) {//�����״�(����)
                rtnMap.put("BLD_CD", reqBLD_CD);
                //�ɤJ�����ɳB�z
                DTEPB102 orgB102Vo = VOTool.mapToVO(DTEPB102.class, cusMap);
                BigDecimal diffRnt = str2Big(rtnMap, "RNT_AMT", null).subtract(orgB102Vo.getRNT_AMT());
                BigDecimal diffPms = str2Big(rtnMap, "PMS_AMT", null).subtract(orgB102Vo.getPMS_AMT());

                if (diffRnt.compareTo(BigDecimal.ZERO) > 0) {//�����t�B > 0                	
                    theEP_B30020.diffToC101Proc(orgB101Vo, B102Vo, rtnMap, diffRnt, "1", TRN_KIND, B301Vo, UPD_TIME);
                }
                if (diffPms.compareTo(BigDecimal.ZERO) > 0) {//����t�B  > 0                	
                    theEP_B30020.diffToC101Proc(orgB101Vo, B102Vo, rtnMap, diffPms, "2", TRN_KIND, B301Vo, UPD_TIME);
                }
            }

        }

        //��s�������
        //���o�̷s�����ӯ���[�`���Ϊ��B
        Map rtnMapNew = theEP_B10020.getCrtSum(reqSUB_CPY_ID, reqCRT_NO, null, "1", false);

        Map B101Map = new HashMap();

        boolean hasB102 = false;
        //�D�����״����ܧ�Y�w�L���īȤᶷ��s�������A
        if (!"EPB004".equals(TRN_KIND)) {
            //���o���īȤ��
            Map B102Map = new HashMap();
            B102Map.put("SUB_CPY_ID", reqSUB_CPY_ID);
            B102Map.put("CRT_NO", reqCRT_NO);
            B102Map.put("QuerySts", "1");
            List<Map> B102List = null;
            try {
                B102List = theEP_B10020.queryList(B102Map);
            } catch (DataNotFoundException dnfe) {
                log.error(dnfe);
            }

            if (B102List == null) {
                if ("EPB005".equals(TRN_KIND)) {//�Ѭ�(�۩l�L��)
                    B101Map.put("CRT_STS", "5");//�Ѭ�
                } else if ("EPB006".equals(TRN_KIND)) { //�����פ�
                    B101Map.put("CRT_STS", "4");//����פ�
                } else if ("EPB007".equals(TRN_KIND)) { //���e�פ�
                    B101Map.put("CRT_STS", "3");//���e�פ�
                }

            } else {//B102�|����L���ĩӯ���, �G�n��sB101�`����, ���������T
                hasB102 = true;
            }

        }

        B101Map.put("SUB_CPY_ID", reqSUB_CPY_ID);
        B101Map.put("BLD_CD", reqBLD_CD);
        B101Map.put("CRT_NO", reqCRT_NO);
        B101Map.put("UPD_TRN_KIND", TRN_KIND);
        B101Map.put("UPD_DATE", UPD_TIME);
        B101Map.put("UPD_APLY_NO", APLY_NO);
        B101Map.put("CHG_DIV_NO", MapUtils.getString(reqMap, "INPUT_DIV_NO"));
        B101Map.put("CHG_ID", MapUtils.getString(reqMap, "INPUT_ID"));
        B101Map.put("CHG_NAME", MapUtils.getString(reqMap, "INPUT_NAME"));
        if ("EPB004".equals(TRN_KIND) || hasB102) {//103.05.14�P�z�p�T�{,�ȩ����״�(����)����s������T, ��L�ܧ�O�d�����¸�T�H�Ѭd��. 103.5.19 �Y�������ĩӯ���h�綷��sB101�W�ƪ��B����T(�_�h��user�ۦ�ק�B101)
            B101Map.put("RNT_TOT_SIZE", MapUtils.getString(rtnMapNew, "SUM_RNT_SIZE"));
            B101Map.put("RNT_TOT_AMT", MapUtils.getString(rtnMapNew, "SUM_RNT_AMT"));
            B101Map.put("PMS_TOT_AMT", MapUtils.getString(rtnMapNew, "SUM_PMS_AMT"));
        }
        new EP_B10010().updatePartCrtInfo(B101Map);
        //��s�j�Ӹ��
        //new EP_A10010().updateSum(reqBLD_CD, B301Vo, UPD_TIME.toString());//��s�j�Ӹ�T >> ��ѥ߮�EP_B30010 approve�ɧ�s

    }

    /**
    * �M�ūǧO�B�z
    * @param reqMap
    * @param TRN_KIND �������
    * @param UPD_DATE ���ʤ���ɶ�
    * @throws ModuleException
     * @throws IllegalAccessException 
    */
    public void updRmProc(Map reqMap, String TRN_KIND, Timestamp UPD_DATE) throws ModuleException, IllegalAccessException {
        //�ˮֶǤJ�Ѽ�:
        //�ˮֶǤJ�Ѽ�
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_B30030_MSG_001"));//�ǤJ��Ƥ��i����
        }

        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_004"));//�ǤJ�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_005"));//�ǤJ�Ȥ�Ǹ����o���ŭ�
        }
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_007"));//�ǤJ����������o���ŭ�
        }
        if (UPD_DATE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_012"));//�ǤJ���ʤ���ɶ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //���o�өӯ��ᤧ�ǧO����
        List<Map> rtnList = null;
        try {
            rtnList = new EP_B10020().queryRm(reqMap);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L�ӯ���ǧO���", dnfe);
        }
        String RNT_END_DATE = MapUtils.getString(reqMap, "RNT_END_DATE");
        String dateUPD_DATE = DATE.timestampToDate(UPD_DATE).toString();
        String IS_NEWCRT_UPD = MapUtils.getString(reqMap, "IS_NEWCRT_UPD");
        String IS_NEWCRT_CLR = MapUtils.getString(reqMap, "IS_NEWCRT_CLR");
        EP_A10030 theEP_A10030 = new EP_A10030();
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        //��s�ǧO�O����
        String[] UPD_TYPE1 = { "CRT_NO", "CUS_NO", "USE_TYPE", "RNT_SIZE", "MGT_SIZE", "FNL_AMT", "RNT_STR_DATE", "RNT_END_DATE",
                "CHG_DATE", "CHG_DIV_NO", "CHG_ID", "CHG_NAME", "APLY_NO", "TRN_KIND" };

        String[] UPD_TYPE2 = { "RNT_END_DATE", "CHG_DATE", "CHG_DIV_NO", "CHG_ID", "CHG_NAME", "APLY_NO", "TRN_KIND" };
        if (rtnList != null) {
            for (Map rtnMap : rtnList) {

                String INPUT_DIV_NO_EPB301 = MapUtils.getString(reqMap, "INPUT_DIV_NO_EPB301");
                String INPUT_ID_EPB301 = MapUtils.getString(reqMap, "INPUT_ID_EPB301");
                Map caseMap = new HashMap();
                caseMap.put("APLY_NO", APLY_NO);
                caseMap.put("TRN_KIND", TRN_KIND);
                caseMap.put("INPUT_DIV_NO", INPUT_DIV_NO_EPB301);
                caseMap.put("INPUT_ID", INPUT_ID_EPB301);
                caseMap.put("INPUT_NAME", MapUtils.getString(reqMap, "INPUT_NAME_EPB301"));

                //���e�פ�w����̥ߧY��s�D��,������������ѧ妸��s. ��method �P�O�_�t�q�s����s�@��
                if (("EPB005".equals(TRN_KIND) || "EPB006".equals(TRN_KIND))
                        || ("EPB007".equals(TRN_KIND) && DATE.diffDay(RNT_END_DATE, dateUPD_DATE) >= 0) || "Y".equals(IS_NEWCRT_CLR)) {

                    rtnMap.put("CRT_NO", null);
                    rtnMap.put("CUS_NO", 0);
                    rtnMap.put("USE_TYPE", "3");
                    rtnMap.put("RNT_SIZE", 0);
                    rtnMap.put("MGT_SIZE", 0);
                    rtnMap.put("FNL_AMT", 0);
                    rtnMap.put("RNT_STR_DATE", null);
                    rtnMap.put("RNT_END_DATE", null);
                    rtnMap.put("CHG_DATE", UPD_DATE);
                    rtnMap.put("CHG_DIV_NO", INPUT_DIV_NO_EPB301);
                    rtnMap.put("CHG_ID", INPUT_ID_EPB301);
                    rtnMap.put("CHG_NAME", MapUtils.getString(reqMap, "INPUT_NAME_EPB301"));
                    rtnMap.put("APLY_NO", APLY_NO);
                    rtnMap.put("TRN_KIND", TRN_KIND);

                    theEP_A10030.updateDTEPA103ByInput(VOTool.mapToVO(DTEPA103.class, rtnMap), UPD_DATE.toString(), caseMap, UPD_TYPE1);// �ק�j�ӫǧO�O����
                } else if (("EPB007".equals(TRN_KIND) && DATE.diffDay(dateUPD_DATE, RNT_END_DATE) > 0) || "Y".equals(IS_NEWCRT_UPD)) {
                    //���e�פ�ɶ�����̥u��s�ǧO�״�
                    rtnMap.put("RNT_END_DATE", RNT_END_DATE);
                    rtnMap.put("CHG_DATE", UPD_DATE);
                    rtnMap.put("CHG_DIV_NO", INPUT_DIV_NO_EPB301);
                    rtnMap.put("CHG_ID", INPUT_ID_EPB301);
                    rtnMap.put("CHG_NAME", MapUtils.getString(reqMap, "INPUT_NAME_EPB301"));
                    rtnMap.put("APLY_NO", APLY_NO);
                    rtnMap.put("TRN_KIND", TRN_KIND);

                    theEP_A10030.updateDTEPA103ByInput(VOTool.mapToVO(DTEPA103.class, rtnMap), UPD_DATE.toString(), caseMap, UPD_TYPE2);// �ק�j�ӫǧO�O����
                }

            }
        }

    }

    /**
     * �M�Ũ���B�z
     * @param reqMap
     * @param TRN_KIND �������
     * @param UPD_DATE ���ʤ���ɶ�
     * @throws ModuleException
     * @throws IllegalAccessException 
     */
    public void updCarProc(Map reqMap, String TRN_KIND, Timestamp UPD_DATE) throws ModuleException, IllegalAccessException {
        //�ˮֶǤJ�Ѽ�:
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_B30030_MSG_001"));//�ǤJ��Ƥ��i����
        }

        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        String RNT_STR_DATE = MapUtils.getString(reqMap, "RNT_STR_DATE");
        String RNT_END_DATE = MapUtils.getString(reqMap, "RNT_END_DATE");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_002"));//�ǤJ�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_004"));//�ǤJ�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_005"));//�ǤJ�Ȥ�Ǹ����o���ŭ�
        }
        String IS_NEWCRT_UPD = MapUtils.getString(reqMap, "IS_NEWCRT_UPD");
        String IS_NEWCRT_CLR = MapUtils.getString(reqMap, "IS_NEWCRT_CLR");
        if ("EPB004".equals(TRN_KIND)) {
            if (StringUtils.isBlank(RNT_STR_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_013"));//�ǤJ�_��������o���ŭ�
            }
            if (StringUtils.isBlank(RNT_END_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_014"));//�ǤJ����������o���ŭ�
            }
        }
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_007"));//�ǤJ����������o���ŭ�
        }
        if (UPD_DATE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30030_MSG_012"));//�ǤJ���ʤ���ɶ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //���o�өӯ��ᤧ�������
        List<Map> rtnList = null;
        try {
            rtnList = new EP_B10020().queryCar(reqMap);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L�ӯ��ᨮ����", dnfe);
        }
        String dateUPD_DATE = DATE.timestampToDate(UPD_DATE).toString();
        EP_A10040 theEP_A10040 = new EP_A10040();
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        String[] UPD_TYPE1 = { "RNT_STR_DATE", "RNT_END_DATE", "CHG_DATE", "CHG_DIV_NO", "CHG_ID", "CHG_NAME", "APLY_NO", "TRN_KIND" };
        String[] UPD_TYPE2 = { "RNT_END_DATE", "CHG_DATE", "CHG_DIV_NO", "CHG_ID", "CHG_NAME", "APLY_NO", "TRN_KIND" };
        String[] UPD_TYPE3 = { "CRT_NO", "CUS_NO", "USR_NAME", "CAR_NO", "PRK_PER", "USE_TYPE", "CAR_RNT_AMT", "RNT_STR_DATE",
                "RNT_END_DATE", "CHG_DATE", "CHG_DIV_NO", "CHG_ID", "CHG_NAME", "APLY_NO", "TRN_KIND" };
        //��s�ǧO�O����
        if (rtnList != null) {

            for (Map rtnMap : rtnList) {

                String INPUT_DIV_NO_EPB301 = MapUtils.getString(reqMap, "INPUT_DIV_NO_EPB301");
                String INPUT_ID_EPB301 = MapUtils.getString(reqMap, "INPUT_ID_EPB301");
                Map caseMap = new HashMap();
                caseMap.put("APLY_NO", APLY_NO);
                caseMap.put("TRN_KIND", TRN_KIND);
                caseMap.put("INPUT_DIV_NO", INPUT_DIV_NO_EPB301);
                caseMap.put("INPUT_ID", INPUT_ID_EPB301);
                caseMap.put("INPUT_NAME", MapUtils.getString(reqMap, "INPUT_NAME_EPB301"));

                if ("EPB004".equals(TRN_KIND)) {//�����״�
                    rtnMap.put("RNT_STR_DATE", RNT_STR_DATE);
                    rtnMap.put("RNT_END_DATE", RNT_END_DATE);
                    rtnMap.put("CHG_DATE", UPD_DATE);
                    rtnMap.put("CHG_DIV_NO", INPUT_DIV_NO_EPB301);
                    rtnMap.put("CHG_ID", INPUT_ID_EPB301);
                    rtnMap.put("CHG_NAME", MapUtils.getString(reqMap, "INPUT_NAME_EPB301"));
                    rtnMap.put("APLY_NO", APLY_NO);
                    rtnMap.put("TRN_KIND", TRN_KIND);

                    theEP_A10040.updateDTEPA104ByInput(VOTool.mapToVO(DTEPA104.class, rtnMap), UPD_DATE.toString(), caseMap, UPD_TYPE1); //�ק郞��O����
                } else if (("EPB007".equals(TRN_KIND) && DATE.diffDay(dateUPD_DATE, RNT_END_DATE) > 0) || "Y".equals(IS_NEWCRT_UPD)) {
                    //�����״��ɶ�����̥u��s�ǧO�״�
                    rtnMap.put("RNT_END_DATE", RNT_END_DATE);
                    rtnMap.put("CHG_DATE", UPD_DATE);
                    rtnMap.put("CHG_DIV_NO", INPUT_DIV_NO_EPB301);
                    rtnMap.put("CHG_ID", INPUT_ID_EPB301);
                    rtnMap.put("CHG_NAME", MapUtils.getString(reqMap, "INPUT_NAME_EPB301"));
                    rtnMap.put("APLY_NO", APLY_NO);
                    rtnMap.put("TRN_KIND", TRN_KIND);

                    theEP_A10040.updateDTEPA104ByInput(VOTool.mapToVO(DTEPA104.class, rtnMap), UPD_DATE.toString(), caseMap, UPD_TYPE2); //�ק郞��O����
                    //���e�פ�w����̥ߧY��s�D��,��    ����������ѧ妸��s. ��method �P�O�_�t�q�s����s�@��

                } else if (("EPB005".equals(TRN_KIND) || "EPB006".equals(TRN_KIND))
                        || ("EPB007".equals(TRN_KIND) && DATE.diffDay(RNT_END_DATE, dateUPD_DATE) >= 0) || ("Y".equals(IS_NEWCRT_CLR))) {
                    rtnMap.put("CRT_NO", null);
                    rtnMap.put("CUS_NO", 0);
                    rtnMap.put("USR_NAME", null);
                    rtnMap.put("CAR_NO", null);
                    rtnMap.put("PRK_PER", null);
                    rtnMap.put("USE_TYPE", "3");
                    rtnMap.put("CAR_RNT_AMT", 0);
                    rtnMap.put("RNT_STR_DATE", null);
                    rtnMap.put("RNT_END_DATE", null);
                    rtnMap.put("CHG_DATE", UPD_DATE);
                    rtnMap.put("CHG_DIV_NO", INPUT_DIV_NO_EPB301);
                    rtnMap.put("CHG_ID", INPUT_ID_EPB301);
                    rtnMap.put("CHG_NAME", MapUtils.getString(reqMap, "INPUT_NAME_EPB301"));
                    rtnMap.put("APLY_NO", APLY_NO);
                    rtnMap.put("TRN_KIND", TRN_KIND);

                    theEP_A10040.updateDTEPA104ByInput(VOTool.mapToVO(DTEPA104.class, rtnMap), UPD_DATE.toString(), caseMap, UPD_TYPE3); //�ק郞��O����
                }

            }
        }

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �ഫ BigDecimal �榡
     * @param map
     * @param key
     * @param defaultValue
     * @return
     */
    private BigDecimal str2Big(Map map, String key, String defaultValue) {
        String s = MapUtils.getString(map, key, defaultValue);

        return StringUtils.isNotBlank(s) ? new BigDecimal(s) : null;
    }

}
