package com.cathay.ep.b3.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.b1.module.EP_B10100;
import com.cathay.ep.vo.DTEPB104;
import com.cathay.ep.vo.DTEPB104_LOG;
import com.cathay.ep.vo.DTEPB105;
import com.cathay.ep.vo.DTEPB105_LOG;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPB304;
import com.cathay.ep.vo.DTEPB305;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2013/10/19  Created ���կ�
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �Ȥ�K���կ����@�Ҳ�
 * �Ҳ�ID    EP_B30040
 * ���n����    �Ȥ�K���կ����@�Ҳ�
 * </pre>
 * @author ����[
 * @since 2013-11-01
 */
@SuppressWarnings("unchecked")
public class EP_B30040 {

    private static final Logger log = Logger.getLogger(EP_B30040.class);

    private static boolean isDebug = log.isDebugEnabled();

    private static final String SQL_getAdjRntList_001 = "com.cathay.ep.b3.module.EP_B30040.SQL_getAdjRntList_001";

    private static final String SQL_getAdjRntList_002 = "com.cathay.ep.b3.module.EP_B30040.SQL_getAdjRntList_002";

    private static final String SQL_getNoRntList_001 = "com.cathay.ep.b3.module.EP_B30040.SQL_getNoRntList_001";

    private static final String SQL_getNoRntList_002 = "com.cathay.ep.b3.module.EP_B30040.SQL_getNoRntList_002";

    private static final String SQL_insert_001 = "com.cathay.ep.b3.module.EP_B30040.SQL_insert_001";

    private static final String SQL_insert_002 = "com.cathay.ep.b3.module.EP_B30040.SQL_insert_002";

    private static final String SQL_approve_001 = "com.cathay.ep.b3.module.EP_B30040.SQL_approve_001";

    private static final String SQL_getNextAdjRntDt_001 = "com.cathay.ep.b3.module.EP_B30040.SQL_getNextAdjRntDt_001";

    private static final String SQL_resetTmp_001 = "com.cathay.ep.b3.module.EP_B30040.SQL_resetTmp_001";

    private static final String SQL_resetTmp_002 = "com.cathay.ep.b3.module.EP_B30040.SQL_resetTmp_002";

    /**
     *  Ū���կ��϶���ƲM��
     * @param SUB_CPY_ID    �����q�O
     * @param CRT_NO        �����N��
     * @param CUS_NO        �Ȥ�Ǹ�
     * @param APLY_NO       �ץ�s��
     * @param IS_CHK_TEMP   �O�_�Ȭd�Ȧs��(�Y�Ȧs�ɵL�ȫh���d�D��)
     * @param IS_GETTEMP_ALL �O�_���o�Ȧs�ɩҦ����(�Y�DY�h�u���s�W��)
     * @return  rtnList     �կ��϶��]�w�M�� (�h��)
     * @throws ModuleException
     */
    public List<Map> getAdjRntList(String SUB_CPY_ID, String CRT_NO, String CUS_NO, String APLY_NO, String IS_CHK_TEMP,
            String IS_GETTEMP_ALL) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_001"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_002"));//�����N�����o���ŭ�
        }
        if ("Y".equals(IS_CHK_TEMP) && StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_003"));//�ץ�s�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        List<Map> rtnList = null;

        //�YAPLY_NO�D��//�d�߫���_�կ��]�w�Ȧs��(DTEPB305)
        if (StringUtils.isNotBlank(APLY_NO)) {

            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("APLY_NO", APLY_NO);
            if (!"Y".equals(IS_GETTEMP_ALL)) {
                ds.setField("DATA_TYPE", "I");
            }
            if (StringUtils.isNotEmpty(CUS_NO)) {
                ds.setField("CUS_NO", CUS_NO);
            }
            rtnList = VOTool.findToMaps(ds, SQL_getAdjRntList_001, false);
        }

        Map<String, BigDecimal> orgAmtMap = null; //�ӯ����l����Map(�̭�l�����p��C���կ��᯲��)

        //�YrtnList���� �BIS_CHK_TEMP <> ��Y��, �d�߫���_�կ��]�w��(DTEPB105)
        if ((rtnList == null || rtnList.isEmpty()) && !"Y".equals(IS_CHK_TEMP)) {
            ds.clear();
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("CRT_NO", CRT_NO);
            if (StringUtils.isNotEmpty(CUS_NO)) {
                ds.setField("CUS_NO", CUS_NO);
            }
            rtnList = VOTool.findToMaps(ds, SQL_getAdjRntList_002);

            //���o��l����map (�d�ӯ��ᤧ��l����)
            Map tmpMap = new HashMap();
            tmpMap.put("SUB_CPY_ID", SUB_CPY_ID);
            tmpMap.put("CRT_NO", CRT_NO);
            tmpMap.put("CUS_NO", CUS_NO);
            try {
                List<Map> cusList = new EP_B10020().queryTenentList(tmpMap); //�ӯ���D�ɸ�T
                //�P���a�T�{, �]�¨t�εL��l�������, �Y�����Τ믲���p��|�����D, �ثe�u���T�w�կ��ηs�t�Ϊ���~�|���T) >> �¨t������ORG_RNT_AMT ����
                orgAmtMap = new HashMap<String, BigDecimal>();
                for (Map cusMap : cusList) {
                    BigDecimal ORG_RNT_AMT = (BigDecimal) cusMap.get("ORG_RNT_AMT");
                    if (ORG_RNT_AMT != null) {
                        orgAmtMap.put(MapUtils.getString(cusMap, "CUS_NO"), ORG_RNT_AMT);
                    }
                }
            } catch (DataNotFoundException dnfe) {
                log.error(dnfe);//�Y�L��Ƥ������~

            }

        }

        if (rtnList != null) {
            BigDecimal BD_100 = new BigDecimal("100");
            for (Map rtnMap : rtnList) {
                rtnMap.put("ADJ_UNIT_NM", FieldOptionList.getName("EP", "ADJ_UNIT", MapUtils.getString(rtnMap, "ADJ_UNIT")));
                rtnMap.put("IS_MAN_ADJ_NM", FieldOptionList.getName("EP", "IS_MAN_ADJ_B304", MapUtils.getString(rtnMap, "IS_MAN_ADJ")));
                if (StringUtils.isNotBlank(MapUtils.getString(rtnMap, "CRT_NO_C102"))) {
                    rtnMap.put("ADJ_STS_NM", MessageUtil.getMessage("EP_B30040_MSG_014"));//�w����
                }

                //103.4.25���a�ݨD�ܧ�p��Ѧҽվ㯲��, �e���W�[���SHOW�X�ѦҤ��վ㯲��
                if (StringUtils.isBlank(APLY_NO) && orgAmtMap != null) {//(��menutree�d�D�ɮɤ~�B�z)
                    String rtnCUS_NO = MapUtils.getString(rtnMap, "CUS_NO");
                    if (!orgAmtMap.containsKey(rtnCUS_NO)) {
                        continue;
                    }
                    BigDecimal calAMT = orgAmtMap.get(rtnCUS_NO);
                    String rtnADJ_UNIT = MapUtils.getString(rtnMap, "ADJ_UNIT");
                    BigDecimal rtnADJ_UNIT_NUM = (BigDecimal) MapUtils.getObject(rtnMap, "ADJ_UNIT_NUM", BigDecimal.ZERO);
                    BigDecimal REF_ADJRNT_AMT = null;
                    if ("1".equals(rtnADJ_UNIT)) {//��
                        REF_ADJRNT_AMT = calAMT.add(rtnADJ_UNIT_NUM);
                        orgAmtMap.put(rtnCUS_NO, REF_ADJRNT_AMT);
                    } else if ("2".equals(rtnADJ_UNIT)) {//%��
                        REF_ADJRNT_AMT = calAMT.add(calAMT.multiply(rtnADJ_UNIT_NUM).divide(BD_100, 0, BigDecimal.ROUND_HALF_UP));
                        orgAmtMap.put(rtnCUS_NO, REF_ADJRNT_AMT);
                    }
                    rtnMap.put("REF_ADJRNT_AMT", REF_ADJRNT_AMT);

                }

            }
        }

        return rtnList;

    }

    /**
     * Ū���K���϶���ƲM��
     * @param SUB_CPY_ID        �����q�O
     * @param CRT_NO            �����N��
     * @param CUS_NO            �Ȥ�Ǹ�
     * @param APLY_NO           �ץ�s��
     * @param IS_CHK_TEMP       �O�_�Ȭd�Ȧs��(�Y�Ȧs�ɵL�ȫh���d�D��)
     * @param IS_GETTEMP_ALL    �O�_���o�Ȧs�ɩҦ����(�Y�DY�h�u���s�W��)
     * @return  rtnList         �K���϶��]�w�M��(�h��)
     * @throws ModuleException
     */
    public List<Map> getNoRntList(String SUB_CPY_ID, String CRT_NO, String CUS_NO, String APLY_NO, String IS_CHK_TEMP, String IS_GETTEMP_ALL)
            throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_001"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_002"));//�����N�����o���ŭ�
        }
        if ("Y".equals(IS_CHK_TEMP) && StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_003"));//�ץ�s�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�YAPLY_NO�D��//�d�߫���_�կ��]�w�Ȧs��(DTEPB305)
        DataSet ds = Transaction.getDataSet();
        List<Map> rtnList = null;
        if (StringUtils.isNotBlank(APLY_NO)) {
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("APLY_NO", APLY_NO);
            if (!"Y".equals(IS_GETTEMP_ALL)) { //�s�W��(�ק�e�Ҽg�JD, �ק��Ҽg�JI)
                ds.setField("DATA_TYPE", "I");
            }
            if (StringUtils.isNotEmpty(CUS_NO)) {
                ds.setField("CUS_NO", CUS_NO);
            }

            rtnList = VOTool.findToMaps(ds, SQL_getNoRntList_001, false);
        }

        //�YrtnList���� �BIS_CHK_TEMP <> ��Y��, �d�߫���_�կ��]�w��(DTEPB105)
        if ((rtnList == null || rtnList.isEmpty()) && !"Y".equals(IS_CHK_TEMP)) {
            ds.clear();
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("CRT_NO", CRT_NO);
            if (StringUtils.isNotEmpty(CUS_NO)) {
                ds.setField("CUS_NO", CUS_NO);
            }
            rtnList = VOTool.findToMaps(ds, SQL_getNoRntList_002);
        }
        if (rtnList != null) {
            for (Map rtnMap : rtnList) {
                rtnMap.put("EXP_KIND_NM", FieldOptionList.getName("EP", "EXP_KIND", MapUtils.getString(rtnMap, "EXP_KIND")));
            }
        }

        return rtnList;

    }

    /**
     * �s�W�K���կ��϶�
     * @param SUB_CPY_ID
     * @param CRT_NO
     * @param CUS_NO
     * @param APLY_NO
     * @param BLD_CD
     * @param B104_List
     * @param B105_List
     * @param CHG_ITEM
     * @param ADJ_SAME
     * @param NORNT_SAME
     * @param IS_DLT_ADJ
     * @param IS_DLT_NORNT
     * @param LAST_DATE
     * @param user
     * @throws ModuleException
     */
    public void insert(String SUB_CPY_ID, String CRT_NO, String CUS_NO, String APLY_NO, String BLD_CD, List<Map> B104_List,
            List<Map> B105_List, String CHG_ITEM, boolean ADJ_SAME, boolean NORNT_SAME, boolean IS_DLT_ADJ, boolean IS_DLT_NORNT,
            Date LAST_DATE, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        boolean B104ListEmpty = B104_List == null || B104_List.isEmpty();
        boolean B105ListEmpty = B105_List == null || B105_List.isEmpty();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_001"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_002"));//�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_003"));//�ץ�s�����o���ŭ�
        }

        if ("1".equals(CHG_ITEM)) {//�կ��϶�
            if (IS_DLT_ADJ) {
                if (!B105ListEmpty) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_015"));//�R���կ��϶����~, �R���󤣱o��J�կ��϶�
                }
            } else {
                if (B105ListEmpty) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_016"));//�կ��϶��]�w���~, �|����J�կ��϶�
                }
            }

        } else if ("2".equals(CHG_ITEM)) {//�K���϶�
            if (IS_DLT_NORNT) {
                if (!B104ListEmpty) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_017"));//�R���K���϶����~, �R���󤣱o��J�K���϶�
                }
            } else {
                if (B104ListEmpty) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_018"));//�K���϶��]�w���~, �|����J�K���϶�
                }
            }
        } else {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_019"));//���ʶ��ؿ��~
        }

        if (!B104ListEmpty) {
            if (!CRT_NO.equals(MapUtils.getString(B104_List.get(0), "CRT_NO"))
                    || !SUB_CPY_ID.equals(MapUtils.getString(B104_List.get(0), "SUB_CPY_ID"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_004"));//�K���϶��]�w�������N���Τ����q�O���~
            }
        }
        if (!B105ListEmpty) {
            if (!CRT_NO.equals(MapUtils.getString(B105_List.get(0), "CRT_NO"))
                    || !SUB_CPY_ID.equals(MapUtils.getString(B105_List.get(0), "SUB_CPY_ID"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_005"));//�կ��϶��]�w�������N���Τ����q�O���~
            }
        }
        if (eie != null) {
            throw eie;
        }

        //���o�ӯ�����
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("APLY_NO", APLY_NO);
        reqMap.put("CRT_NO", CRT_NO);
        //���o�ӯ�����
        List<Map> B102NEWList;
        try {
            B102NEWList = this.queryCUSList(reqMap);
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            B102NEWList = null;
        }
        if (B102NEWList == null || B102NEWList.isEmpty()) {
            throw new ModuleException(MessageUtil.getMessage("EP_B30040_MSG_020"));//�ӯ����Ʃ|������, �Х��إߩӯ�����
        }

        List<Map> MainB104_List;
        List<Map> MainB105_List;
        try {
            //���o�D�ɧK���϶�
            MainB104_List = getNoRntList(SUB_CPY_ID, CRT_NO, null, null, null, null);
        } catch (DataNotFoundException dnfe) {
            log.error("���o�D�ɧK���϶��d�L���", dnfe);
            MainB104_List = Collections.EMPTY_LIST;
        }

        try {
            //���o�D�ɽկ��϶�
            MainB105_List = getAdjRntList(SUB_CPY_ID, CRT_NO, null, null, null, null);
        } catch (DataNotFoundException dnfe) {
            log.error("���o�D�ɽկ��϶��d�L���", dnfe);
            MainB105_List = Collections.EMPTY_LIST;
        }

        boolean mainB104ListEmpty = MainB104_List == null || MainB104_List.isEmpty();
        boolean mainB105ListEmpty = MainB105_List == null || MainB105_List.isEmpty();
        if (IS_DLT_ADJ) {
            if (mainB105ListEmpty) {
                throw new ModuleException(MessageUtil.getMessage("EP_B30040_MSG_021"));//�|���]�w�D�ɽկ��϶�, ���o�R��
            }

        } else if (IS_DLT_NORNT) {
            if (mainB104ListEmpty) {
                throw new ModuleException(MessageUtil.getMessage("EP_B30040_MSG_022"));//�|���]�w�D�ɧK���϶�, ���o�R��
            }
        }
        if ("1".equals(CHG_ITEM)) {//�կ��϶�
            if (mainB105ListEmpty && B105ListEmpty) {
                throw new ModuleException(MessageUtil.getMessage("EP_B30040_MSG_023"));//�D�ɽկ��϶��έק��կ��϶����o�Ҭ��ŭ�
            }
        } else {
            if (mainB104ListEmpty && B104ListEmpty) {
                throw new ModuleException(MessageUtil.getMessage("EP_B30040_MSG_006"));//�D�ɧK���϶��έק��K���϶����o�Ҭ��ŭ�
            }

        }

        DataSet ds = Transaction.getDataSet();
        if ("1".equals(CHG_ITEM)) {//�կ��϶��]�w
            //�M�Žկ��϶��Ȧs�ɸ�T
            if (!B105ListEmpty) {

                if (ADJ_SAME) {//�Ҧ��կ��Ȥ�ҬۦP
                    this.deleteEPB305(APLY_NO, null, null, ds);
                } else {

                    //�R���Ȧs�� 
                    String lastCUS_NO = null;
                    boolean isFirst = true;
                    for (Map tmpB105Map : B105_List) { //�R���Ȧs��
                        String tmpCUS_NO = MapUtils.getString(tmpB105Map, "CUS_NO");
                        String tmpCRT_NO = MapUtils.getString(tmpB105Map, "CRT_NO");

                        if (isFirst || !lastCUS_NO.equals(tmpCUS_NO)) {//tmpB105Map.CUS_NO �P�e�����P
                            this.deleteEPB305(APLY_NO, tmpCRT_NO, tmpCUS_NO, ds);
                            isFirst = false;
                            lastCUS_NO = tmpCUS_NO;
                        }
                    }
                }

            } else if (IS_DLT_ADJ) {
                if (StringUtils.isBlank(CUS_NO)) {
                    this.deleteEPB305(APLY_NO, null, null, ds);
                } else {
                    this.deleteEPB305(APLY_NO, CRT_NO, CUS_NO, ds);
                }

            }
        } else if ("2".equals(CHG_ITEM)) {//�K���϶��]�w
            //�M�ŧK���϶��Ȧs�ɸ�T
            if (!B104ListEmpty) {

                if (NORNT_SAME) {//�Ҧ��K���Ȥ�ҬۦP
                    this.deleteEPB304(APLY_NO, null, null, ds);
                } else {
                    //�R���Ȧs�� 
                    String lastCUS_NO = null;
                    boolean isFirst = true;
                    for (Map tmpB104Map : B104_List) {
                        String tmpCUS_NO = MapUtils.getString(tmpB104Map, "CUS_NO");
                        String tmpCRT_NO = MapUtils.getString(tmpB104Map, "CRT_NO");
                        if (isFirst || !lastCUS_NO.equals(tmpCUS_NO)) {//tmpB104Map.CUS_NO �P�e�����P
                            this.deleteEPB304(APLY_NO, tmpCRT_NO, tmpCUS_NO, ds);
                            lastCUS_NO = tmpCUS_NO;
                            isFirst = false;
                        }
                    }
                }
            } else if (IS_DLT_NORNT) {
                if (StringUtils.isBlank(CUS_NO)) {
                    this.deleteEPB304(APLY_NO, null, null, ds);
                } else {
                    this.deleteEPB304(APLY_NO, CRT_NO, CUS_NO, ds);
                }
            }
        }

        //�g�J�K���Ȧs�ɸ��, �D�ɸ�ƬҼg�JD�R��, �ק���Ƭҥ�I�s�W   
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        if ("2".equals(CHG_ITEM)) {//�K���϶��]�w

            if (!B104ListEmpty) {
                if (NORNT_SAME) {//�Ҧ��K���Ȥ�ҬۦP
                    for (Map mainB104Map : MainB104_List) {
                        DTEPB304 B304Vo = VOTool.mapToVO(DTEPB304.class, mainB104Map);
                        B304Vo.setAPLY_NO(APLY_NO);
                        B304Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "010", APLY_NO, "APLY_NO"));
                        B304Vo.setDATA_TYPE("D");
                        VOTool.insert(B304Vo);
                    }
                    for (Map B102Map : B102NEWList) {
                        for (Map B104Map : B104_List) {//�s�W�ק����
                            DTEPB304 B304Vo = VOTool.mapToVO(DTEPB304.class, B104Map);
                            B304Vo.setAPLY_NO(APLY_NO);
                            B304Vo.setCUS_NO(toInteger(B102Map, "CUS_NO", null));
                            B304Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "010", APLY_NO, "APLY_NO"));
                            B304Vo.setDATA_TYPE("I");
                            VOTool.insert(B304Vo);
                        }
                    }

                } else {//�R�������ܧ󤧫Ȥ�Ǹ��D�ɸ�ƨüg�J�����ܧ󤧫Ȥ���
                    boolean isFirst = true;
                    String lastCUS_NO = null;
                    for (Map B104Map : B104_List) {
                        String tmpCUS_NO = MapUtils.getString(B104Map, "CUS_NO");
                        if (isFirst || !lastCUS_NO.equals(tmpCUS_NO)) {//�P�@�ӫȤ�u�R���D�ɤ@��
                            //�R���D��
                            for (Map mainB104Map : MainB104_List) {
                                String mainCUS_NO = MapUtils.getString(mainB104Map, "CUS_NO");
                                if (mainCUS_NO.equals(tmpCUS_NO)) {
                                    DTEPB304 B304Vo = VOTool.mapToVO(DTEPB304.class, mainB104Map);
                                    B304Vo.setAPLY_NO(APLY_NO);
                                    B304Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "010", APLY_NO, "APLY_NO"));
                                    B304Vo.setDATA_TYPE("D");
                                    VOTool.insert(B304Vo);
                                }

                            }
                            lastCUS_NO = tmpCUS_NO;
                            isFirst = false;
                        }

                    }

                    //�s�W�ק����
                    for (Map B104Map : B104_List) {
                        DTEPB304 B304Vo = VOTool.mapToVO(DTEPB304.class, B104Map);
                        B304Vo.setAPLY_NO(APLY_NO);
                        B304Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "010", APLY_NO, "APLY_NO"));
                        B304Vo.setDATA_TYPE("I");
                        VOTool.insert(B304Vo);
                    }

                }

            } else if (IS_DLT_NORNT) {//�YB104_List�L�ȥB���R���K���϶�
                if (StringUtils.isBlank(CUS_NO)) {
                    //�R�����������D�ɸ��
                    for (Map mainB104Map : MainB104_List) {//�R���D��
                        DTEPB304 B304Vo = VOTool.mapToVO(DTEPB304.class, mainB104Map);
                        B304Vo.setAPLY_NO(APLY_NO);
                        B304Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "010", APLY_NO, "APLY_NO"));
                        B304Vo.setDATA_TYPE("D");
                        VOTool.insert(B304Vo);
                    }

                } else {//�R�����w�Ȥ�Ǹ��K�����
                    for (Map mainB104Map : MainB104_List) {//�R���D�ɸӫȤ���
                        if (MapUtils.getString(mainB104Map, "CUS_NO").equals(CUS_NO)) {
                            DTEPB304 B304Vo = VOTool.mapToVO(DTEPB304.class, mainB104Map);
                            B304Vo.setAPLY_NO(APLY_NO);
                            B304Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "010", APLY_NO, "APLY_NO"));
                            B304Vo.setDATA_TYPE("D");
                            VOTool.insert(B304Vo);
                        }
                    }

                }
            }

        }

        //�g�J�կ��Ȧs�ɸ��, �D�ɸ�ƬҼg�JD�R��, �ק���Ƭҥ�I�s�W
        if ("1".equals(CHG_ITEM)) {//�կ��϶�

            if (!B105ListEmpty) {
                if (ADJ_SAME) {//�Ҧ��կ��Ȥ�ҬۦP
                    for (Map mmainB105Map : MainB105_List) {//�R���D��
                        DTEPB305 B305Vo = VOTool.mapToVO(DTEPB305.class, mmainB105Map);
                        B305Vo.setAPLY_NO(APLY_NO);
                        B305Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "011", APLY_NO, "APLY_NO"));
                        B305Vo.setDATA_TYPE("D");
                        VOTool.insert(B305Vo);
                    }
                    for (Map B102Map : B102NEWList) {
                        for (Map B105Map : B105_List) {//�s�W�ק����
                            DTEPB305 B305Vo = VOTool.mapToVO(DTEPB305.class, B105Map);
                            B305Vo.setAPLY_NO(APLY_NO);
                            B305Vo.setCUS_NO(toInteger(B102Map, "CUS_NO", null));
                            B305Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "011", APLY_NO, "APLY_NO"));
                            B305Vo.setDATA_TYPE("I");
                            VOTool.insert(B305Vo);
                        }
                    }

                } else {//�R�������ܧ󤧫Ȥ�Ǹ��D�ɸ�ƨüg�J�����ܧ󤧫Ȥ���

                    boolean isFirst = true;
                    String lastCUS_NO = null;
                    for (Map B105Map : B105_List) {
                        String tmpCUS_NO = MapUtils.getString(B105Map, "CUS_NO");
                        if (isFirst || !lastCUS_NO.equals(tmpCUS_NO)) {//�P�@�ӫȤ�u�R���D�ɤ@��
                            //�R���D��
                            for (Map mainB105Map : MainB105_List) {
                                String mainCUS_NO = MapUtils.getString(mainB105Map, "CUS_NO");
                                if (mainCUS_NO.equals(tmpCUS_NO)) {
                                    DTEPB305 B305Vo = VOTool.mapToVO(DTEPB305.class, mainB105Map);
                                    B305Vo.setAPLY_NO(APLY_NO);
                                    B305Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "011", APLY_NO, "APLY_NO"));
                                    B305Vo.setDATA_TYPE("D");
                                    VOTool.insert(B305Vo);
                                }

                            }
                            lastCUS_NO = tmpCUS_NO;
                            isFirst = false;
                        }

                    }

                    //�s�W�ק����
                    for (Map B105Map : B105_List) {
                        DTEPB305 B305Vo = VOTool.mapToVO(DTEPB305.class, B105Map);
                        B305Vo.setAPLY_NO(APLY_NO);
                        B305Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "011", APLY_NO, "APLY_NO"));
                        B305Vo.setDATA_TYPE("I");
                        VOTool.insert(B305Vo);
                    }

                }

            } else if (IS_DLT_ADJ) {//�YB105_List�L�ȥB���R���կ��϶�
                if (StringUtils.isBlank(CUS_NO)) {
                    //�R�����������D�ɸ��
                    for (Map mainB105Map : MainB105_List) {//�R���D��
                        DTEPB305 B305Vo = VOTool.mapToVO(DTEPB305.class, mainB105Map);
                        B305Vo.setAPLY_NO(APLY_NO);
                        B305Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "011", APLY_NO, "APLY_NO"));
                        B305Vo.setDATA_TYPE("D");
                        VOTool.insert(B305Vo);
                    }

                } else {//�R�����w�Ȥ�Ǹ��K�����
                    for (Map mainB105Map : MainB105_List) {//�R���D�ɸӫȤ���
                        if (MapUtils.getString(mainB105Map, "CUS_NO").equals(CUS_NO)) {
                            DTEPB305 B305Vo = VOTool.mapToVO(DTEPB305.class, mainB105Map);
                            B305Vo.setAPLY_NO(APLY_NO);
                            B305Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "011", APLY_NO, "APLY_NO"));
                            B305Vo.setDATA_TYPE("D");
                            VOTool.insert(B305Vo);
                        }
                    }

                }
            }
        }

        //�ˮ�IFRS������J�e�ᤧ�s�§K���կ��϶�
        chkNewSec(SUB_CPY_ID, CRT_NO, CUS_NO, APLY_NO, MainB104_List, MainB105_List, CHG_ITEM, ADJ_SAME, NORNT_SAME, IS_DLT_ADJ,
            IS_DLT_NORNT, LAST_DATE, user);

        //��s�ץ��ܧ�����j�ӤΫ�����T
        DTEPB301 B301vo = new DTEPB301();
        B301vo.setSUB_CPY_ID(SUB_CPY_ID);
        B301vo.setAPLY_NO(APLY_NO);
        B301vo.setCRT_NO(CRT_NO);
        B301vo.setBLD_CD(BLD_CD);
        new EP_B30010().updateDTEPB301MainInfo(B301vo);

    }

    /**
     * �K���կ��϶��Ю֤J�D��
     * @param B301Vo    
     * @param UPD_TIME  ��s����ɶ�
     * @param crtInfoList
     * @throws ModuleException
     */
    public void approve(DTEPB301 B301Vo, Timestamp UPD_TIME, List<Map> crtInfoList) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String APLY_NO = null;
        String CRT_NO = null;
        String BLD_CD = null;
        String TRN_KIND = null;
        String INPUT_DIV_NO = null;
        String INPUT_NAME = null;
        String INPUT_ID = null;

        if (B301Vo == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_007"));//�ǤJ��Ƥ��o���ŭ�
        } else {
            SUB_CPY_ID = B301Vo.getSUB_CPY_ID();
            APLY_NO = B301Vo.getAPLY_NO();
            CRT_NO = B301Vo.getCRT_NO();
            BLD_CD = B301Vo.getBLD_CD();
            TRN_KIND = B301Vo.getTRN_KIND();
            INPUT_DIV_NO = B301Vo.getINPUT_DIV_NO();
            INPUT_NAME = B301Vo.getINPUT_NAME();
            INPUT_ID = B301Vo.getINPUT_ID();

            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_001"));//�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(APLY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_003"));//�ץ�s�����o���ŭ�
            }
            if (StringUtils.isBlank(CRT_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_002"));//�����N�����o���ŭ�
            }
            if (StringUtils.isBlank(BLD_CD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_008"));//�j�ӥN�����o���ŭ�
            }
            if (StringUtils.isBlank(TRN_KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_009"));//����������o���ŭ�
            }
            if (StringUtils.isBlank(INPUT_DIV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_010"));//��J�H����줣�o���ŭ�
            }
            if (StringUtils.isBlank(INPUT_NAME)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_011"));//��J�H���m�W���o���ŭ�
            }
            if (StringUtils.isBlank(INPUT_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_012"));//��J�H�����o���ŭ�
            }

        }
        if (UPD_TIME == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_013"));//��s����ɶ����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        //�K���϶��]�w��Ƨ�s
        List<Map> B304_List;//�K���Ȧs���
        try {
            B304_List = getNoRntList(SUB_CPY_ID, CRT_NO, null, APLY_NO, "Y", "Y");
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L��Ƶ������`", dnfe);
            B304_List = null;
        }
        if (isDebug) {
            log.debug("B304_List::" + B304_List);
        }

        Set<String> keepCUS_NOs = new HashSet<String>();

        if (!(B304_List == null || B304_List.isEmpty())) {//���ק�K���϶�)
            //���o�D�ɧK���϶�, �N�D�ɧK���϶��g�JLOG��R��
            List<Map> MainB104_List;
            try {
                MainB104_List = getNoRntList(SUB_CPY_ID, CRT_NO, null, null, null, null);
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L��Ƶ������`", dnfe);
                MainB104_List = null;
            }

            //�N�ܧ��K���Ȧs�ɸ�Ƨ�s��K���D��(�g�J�s�W��çR���D�ɸ��)
            for (Map B304Map : B304_List) {

                String tmpDATA_TYPE = MapUtils.getString(B304Map, "DATA_TYPE");
                String tmpCUS_NO = MapUtils.getString(B304Map, "CUS_NO");
                keepCUS_NOs.add(tmpCUS_NO);
                if ("D".equals(tmpDATA_TYPE)) {
                    if (!(MainB104_List == null || MainB104_List.isEmpty())) {
                        for (Map MainB104Map : MainB104_List) {
                            if (MapUtils.getString(MainB104Map, "CUS_NO").equals(tmpCUS_NO)
                                    && MapUtils.getString(MainB104Map, "EXP_KIND").equals(MapUtils.getString(B304Map, "EXP_KIND"))
                                    && MapUtils.getString(MainB104Map, "EXP_STR_DATE").equals(MapUtils.getString(B304Map, "EXP_STR_DATE"))) {
                                DTEPB104_LOG B104Vo_Log = VOTool.mapToVO(DTEPB104_LOG.class, MainB104Map);
                                B104Vo_Log.setUPD_DATE(UPD_TIME);
                                B104Vo_Log.setUPD_APLY_NO(B301Vo.getAPLY_NO());
                                B104Vo_Log.setUPD_TRN_KIND(B301Vo.getTRN_KIND());
                                VOTool.insert(B104Vo_Log);

                                DTEPB104 B104Vo = VOTool.mapToVO(DTEPB104.class, MainB104Map);
                                VOTool.delByPK(B104Vo);
                                break;
                            }
                        }
                    }

                } else if ("I".equals(tmpDATA_TYPE)) {
                    DTEPB104 B104Vo = VOTool.mapToVO(DTEPB104.class, B304Map);
                    B104Vo.setCHG_DATE(UPD_TIME);
                    B104Vo.setCHG_DIV_NO(B301Vo.getINPUT_DIV_NO());
                    B104Vo.setCHG_ID(B301Vo.getINPUT_ID());
                    B104Vo.setCHG_NAME(B301Vo.getINPUT_NAME());
                    B104Vo.setAPLY_NO(B301Vo.getAPLY_NO());
                    B104Vo.setTRN_KIND(B301Vo.getTRN_KIND());
                    VOTool.insert(B104Vo);
                }

            }
        }

        //�կ��϶��]�w��Ƨ�s
        List<Map> B305_List;

        //�կ��Ȧs���:
        try {
            B305_List = getAdjRntList(SUB_CPY_ID, CRT_NO, null, APLY_NO, "Y", "Y");
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L��Ƶ������`", dnfe);
            B305_List = null;
        }
        if (isDebug) {
            log.debug("B305_List::" + B305_List);
        }
        if (!(B305_List == null || B305_List.isEmpty())) { //�կ��Ȧs��ƫD�ŭ�(���ק�կ��϶�)

            //���o�D�ɽկ��϶�, �N�D�ɽկ��϶��g�JLOG��R��
            List<Map> MainB105_List;
            try {
                MainB105_List = getAdjRntList(SUB_CPY_ID, CRT_NO, null, null, null, null);
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L��Ƶ������`", dnfe);
                MainB105_List = null;
            }

            //�N�ܧ��կ��Ȧs�ɸ�Ƨ�s��կ��D��(�g�J�s�W��çR���D�ɸ��)
            for (Map B305Map : B305_List) {
                String tmpDATA_TYPE = MapUtils.getString(B305Map, "DATA_TYPE");
                String tmpCUS_NO = MapUtils.getString(B305Map, "CUS_NO");
                keepCUS_NOs.add(tmpCUS_NO);
                if ("D".equals(tmpDATA_TYPE)) {
                    if (!(MainB105_List == null || MainB105_List.isEmpty())) {
                        for (Map MainB105Map : MainB105_List) {
                            if (MapUtils.getString(MainB105Map, "CUS_NO").equals(tmpCUS_NO)
                                    && MapUtils.getString(MainB105Map, "ADJ_RNT_SDATE")
                                            .equals(MapUtils.getString(B305Map, "ADJ_RNT_SDATE"))) {

                                DTEPB105_LOG B105Vo_Log = VOTool.mapToVO(DTEPB105_LOG.class, MainB105Map);
                                B105Vo_Log.setUPD_DATE(UPD_TIME);
                                B105Vo_Log.setUPD_APLY_NO(B301Vo.getAPLY_NO());
                                B105Vo_Log.setUPD_TRN_KIND(B301Vo.getTRN_KIND());
                                VOTool.insert(B105Vo_Log);

                                DTEPB105 B105Vo = VOTool.mapToVO(DTEPB105.class, MainB105Map);
                                VOTool.delByPK(B105Vo);
                                break;

                            }
                        }
                    }

                } else if ("I".equals(tmpDATA_TYPE)) {

                    DTEPB105 B105Vo = VOTool.mapToVO(DTEPB105.class, B305Map);
                    B105Vo.setCHG_DATE(UPD_TIME);
                    B105Vo.setCHG_DIV_NO(B301Vo.getINPUT_DIV_NO());
                    B105Vo.setCHG_ID(B301Vo.getINPUT_ID());
                    B105Vo.setCHG_NAME(B301Vo.getINPUT_NAME());
                    B105Vo.setAPLY_NO(B301Vo.getAPLY_NO());
                    B105Vo.setTRN_KIND(B301Vo.getTRN_KIND());
                    VOTool.insert(B105Vo);

                }
            }
        }

        if (!(B304_List == null || B304_List.isEmpty()) || !(B305_List == null || B305_List.isEmpty())) {
            DataSet ds = Transaction.getDataSet();
            ds.setField("SUB_CPY_ID", B301Vo.getSUB_CPY_ID());
            ds.setField("CRT_NO", B301Vo.getCRT_NO());
            ds.setFieldValues("CUS_NOs", keepCUS_NOs.toArray());
            List<Map> B107_List = VOTool.findToMaps(ds, SQL_approve_001, false);

            if (B107_List != null) {
                //�]�w�ϥΪ̸�T
                Map userMap = new HashMap();
                userMap.put("CHG_DIV_NO", B301Vo.getINPUT_DIV_NO());
                userMap.put("CHG_ID", B301Vo.getINPUT_ID());
                userMap.put("CHG_NAME", B301Vo.getINPUT_NAME());

                EP_B10100 theEP_B10100 = new EP_B10100();
                for (Map B107Map : B107_List) {
                    B107Map.put("APLY_NO", B301Vo.getAPLY_NO());
                    B107Map.put("TRN_KIND", B301Vo.getTRN_KIND());
                    Map chkMap = theEP_B10100.updB107(B107Map, "U", "Y", userMap);
                    if (MapUtils.getBoolean(chkMap, "IS_MAIL", false)) {
                        Map rtnMap = new HashMap();
                        rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", TRN_KIND));
                        rtnMap.put("CRT_NO", B107Map.get("CRT_NO"));
                        rtnMap.put("CUS_NO", B107Map.get("CUS_NO"));
                        rtnMap.put("INFM_MSG", MessageUtil.getMessage("EP_B30040_MSG_027"));//�կ��K���ܧ�A�жi��IFRS�պ�T�{�@�~
                        crtInfoList.add(rtnMap);
                    }
                }
            }
        }

    }

    /**
     * ���o�����U�����կ���M��
     * @param SUB_CPY_ID
     * @param CRT_NO_ARRAY
     * @return
     * @throws ModuleException
     */
    public List<Map> getNextAdjRntDt(String SUB_CPY_ID, String[] CRT_NO_ARRAY) throws ModuleException {

        //�ˮֶǤJ�Ѽ�:
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_B30040_MSG_001"));//�����q�O���o���ŭ�
        }

        //DTEPB105��DTEPC102 �Ҧ������ union DTEPB105����Ʀ�DTEPC102 �L���
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (CRT_NO_ARRAY != null && CRT_NO_ARRAY.length > 0) {
            ds.setFieldValues("CRT_NO_ARRAYs", CRT_NO_ARRAY);
        }
        return VOTool.findToMaps(ds, SQL_getNextAdjRntDt_001);
    }

    /**
     *  Ū���կ��K�������ӯ�����
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryCUSList(Map reqMap) throws ModuleException {

        //�ˮֶǤJ�Ѽ�:
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_B30040_MSG_007"));//�ǤJ��Ƥ��o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_001"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_002"));//�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_003"));//�ץ�s�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        EP_B10020 theEP_B10020 = new EP_B10020();
        //���o�ӯ�����
        List<Map> B102List;
        try {
            B102List = theEP_B10020.queryList(reqMap);//�Y���ŭȤ������~
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            B102List = null;
        }
        List<Map> B102NEWList;
        if (!(B102List == null || B102List.isEmpty()) && StringUtils.isNotBlank(MapUtils.getString(B102List.get(0), "APLY_NO"))) {
            B102NEWList = new ArrayList();
            for (Map B102Map : B102List) {
                String DATA_TYPE = MapUtils.getString(B102Map, "DATA_TYPE");
                if ("I".equals(DATA_TYPE) || "A".equals(DATA_TYPE)) {//�u�d�U�����ܧ���
                    B102NEWList.add(B102Map);
                }
            }

        } else {//�Ȧs�ɬd�L���
            reqMap.put("APLY_NO", null);
            B102NEWList = theEP_B10020.queryList(reqMap);
        }

        return B102NEWList;

    }

    /**
     * �ˮַs�կ��K���϶��X�z��
     * @param SUB_CPY_ID �����q�O
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param APLY_NO �ץ�s��
     * @param oldB104_List �K���϶��]�w���(��D�ɸ��)
     * @param oldB105_List �կ��϶��]�w���(��D�ɸ��)
     * @param CHG_ITEM ���ʶ��� 1 �կ��϶� 2 �K���϶�
     * @param ADJ_SAME �Ȥ�կ���ƬҬۦP
     * @param NORNT_SAME �Ȥ�K����ƬҬۦP
     * @param IS_DLT_ADJ �O�_�R���կ��϶�
     * @param IS_DLT_NORNT �O�_�R���K���϶�
     * @param LAST_DATE �W�Ӥ�̫�@��
     * @param user
     * @throws ModuleException
     */
    public void chkNewSec(String SUB_CPY_ID, String CRT_NO, String CUS_NO, String APLY_NO, List<Map> oldB104_List, List<Map> oldB105_List,
            String CHG_ITEM, boolean ADJ_SAME, boolean NORNT_SAME, boolean IS_DLT_ADJ, boolean IS_DLT_NORNT, Date LAST_DATE, UserObject user)
            throws ModuleException {
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_001"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_003"));//�ץ�s�����o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_002"));//�����N�����o���ŭ�
        }
        if (!("1".equals(CHG_ITEM) || "2".equals(CHG_ITEM))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_024"));//���ʶ��إu�i��1��2
        }
        if (eie != null) {
            throw eie;
        }
        LocaleDisplay locale = new LocaleDisplay("EP", user);
        String sLAST_DATE = LAST_DATE.toString();
        EP_B30040 theEP_B30040 = new EP_B30040();
        EP_B10100 theEP_B10100 = new EP_B10100();
        boolean IS_IFRS_CRT = false;
        List<Map> newB104_List;
        List<Map> newB105_List;
        //���o�s�կ��϶�(�u���s�W��)
        try {
            newB105_List = theEP_B30040.getAdjRntList(SUB_CPY_ID, CRT_NO, null, APLY_NO, "Y", "N");
        } catch (DataNotFoundException dnfe) {
            newB105_List = null;
        }
        //���o�s�K���϶�(�u���s�W��)
        try {
            newB104_List = theEP_B30040.getNoRntList(SUB_CPY_ID, CRT_NO, null, APLY_NO, "Y", "N");
        } catch (DataNotFoundException dnfe) {
            newB104_List = null;
        }
        //���o�O�_IFRS��������
        if (ADJ_SAME || NORNT_SAME || (StringUtils.isBlank(CUS_NO) && (IS_DLT_ADJ || IS_DLT_NORNT))) {//��i�������|���ʪ����p
            //�O�_��IFRS��������
            IS_IFRS_CRT = theEP_B10100.chkCrtIsIFRS(SUB_CPY_ID, CRT_NO, null);
        }

        if ("1".equals(CHG_ITEM)) {//�կ��϶�
            if (oldB105_List == null || oldB105_List.isEmpty()) {//��կ��϶����ūh���ݤ��
                return;
            }

            MultiKeyMap mkmB105 = new MultiKeyMap();
            Map keyB105Map = new HashMap();

            if (newB105_List != null) {
                //���դ����

                for (Map newB105Map : newB105_List) {
                    List<BigDecimal> BDs;
                    String key1 = MapUtils.getString(newB105Map, "ADJ_RNT_SDATE");
                    String key2 = MapUtils.getString(newB105Map, "ADJ_RNT_EDATE");
                    String key3 = MapUtils.getString(newB105Map, "ADJ_UNIT");

                    if (!mkmB105.containsKey(key1, key2, key3)) {
                        BDs = new ArrayList();
                        mkmB105.put(key1, key2, key3, BDs);

                    } else {
                        BDs = (List<BigDecimal>) mkmB105.get(key1, key2, key3);
                    }
                    String strADJ_UNIT_NUM = MapUtils.getString(newB105Map, "ADJ_UNIT_NUM");
                    if (StringUtils.isNotBlank(strADJ_UNIT_NUM)) {
                        BDs.add(new BigDecimal(strADJ_UNIT_NUM));
                    }

                    if (!keyB105Map.containsKey(key1)) {
                        keyB105Map.put(key1, null);
                    }
                }
            }

            if (IS_DLT_ADJ) {//�R���կ��϶�
                if (StringUtils.isBlank(CUS_NO)) {
                    if (IS_IFRS_CRT) {
                        for (Map oldB105Map : oldB105_List) {
                            String ADJ_RNT_SDATE = MapUtils.getString(oldB105Map, "ADJ_RNT_SDATE");
                            String ADJ_RNT_EDATE = MapUtils.getString(oldB105Map, "ADJ_RNT_EDATE");
                            if (this.chkNewSecMsgRule1(ADJ_RNT_SDATE, ADJ_RNT_EDATE, sLAST_DATE, MapUtils.getString(oldB105Map,
                                "CRT_NO_C102"))) {
                                String oldCUS_NO = MapUtils.getString(oldB105Map, "CUS_NO");
                                this.chkNewSecThrowMsg1(locale, oldCUS_NO, ADJ_RNT_SDATE, ADJ_RNT_EDATE);
                            }
                        }

                    }
                } else {
                    boolean IS_IFRS_CUS = theEP_B10100.chkCrtIsIFRS(SUB_CPY_ID, CRT_NO, Integer.valueOf(CUS_NO));
                    if (IS_IFRS_CUS) {
                        for (Map oldB105Map : oldB105_List) {
                            String oldCUS_NO = MapUtils.getString(oldB105Map, "CUS_NO");
                            if (CUS_NO.equals(oldCUS_NO)) {
                                String ADJ_RNT_SDATE = MapUtils.getString(oldB105Map, "ADJ_RNT_SDATE");
                                String ADJ_RNT_EDATE = MapUtils.getString(oldB105Map, "ADJ_RNT_EDATE");

                                if (this.chkNewSecMsgRule1(ADJ_RNT_SDATE, ADJ_RNT_EDATE, sLAST_DATE, MapUtils.getString(oldB105Map,
                                    "CRT_NO_C102"))) {
                                    this.chkNewSecThrowMsg1(locale, oldCUS_NO, ADJ_RNT_SDATE, ADJ_RNT_EDATE);

                                }
                            }
                        }
                    }

                }
            } else if (ADJ_SAME) {//�Ҧ���ƬҬۦP                
                if (IS_IFRS_CRT) {
                    for (Map oldB105Map : oldB105_List) {
                        String ADJ_RNT_SDATE = MapUtils.getString(oldB105Map, "ADJ_RNT_SDATE");
                        String ADJ_RNT_EDATE = MapUtils.getString(oldB105Map, "ADJ_RNT_EDATE");
                        String oldCUS_NO = MapUtils.getString(oldB105Map, "CUS_NO");
                        if (this.chkNewSecMsgRule1(ADJ_RNT_SDATE, ADJ_RNT_EDATE, sLAST_DATE, MapUtils.getString(oldB105Map, "CRT_NO_C102"))) {
                            boolean isOK = this.chkNewSec_Exe1(mkmB105, keyB105Map, oldB105Map, ADJ_RNT_SDATE, ADJ_RNT_EDATE, sLAST_DATE);
                            if (!isOK) {
                                this.chkNewSecThrowMsg1(locale, oldCUS_NO, ADJ_RNT_SDATE, ADJ_RNT_EDATE);
                            }

                        }

                    }
                }
            } else {//�̷Ӧ����ʨ쪺�Ȥ�Ǹ�����s�¸��
                Map cusNoMap = new HashMap();
                for (Map newB105Map : newB105_List) {
                    String newCUS_NO = MapUtils.getString(newB105Map, "CUS_NO");
                    if (!cusNoMap.containsKey(newCUS_NO)) { //�@�ӧǸ��u��@��
                        boolean IS_IFRS_CUS = theEP_B10100.chkCrtIsIFRS(SUB_CPY_ID, CRT_NO, Integer.valueOf(newCUS_NO));
                        if (IS_IFRS_CUS) {

                            for (Map oldB105Map : oldB105_List) {
                                String oldCUS_NO = MapUtils.getString(oldB105Map, "CUS_NO");
                                String ADJ_RNT_SDATE = MapUtils.getString(oldB105Map, "ADJ_RNT_SDATE");
                                String ADJ_RNT_EDATE = MapUtils.getString(oldB105Map, "ADJ_RNT_EDATE");
                                if (oldCUS_NO.equals(newCUS_NO)) {
                                    if (this.chkNewSecMsgRule1(ADJ_RNT_SDATE, ADJ_RNT_EDATE, sLAST_DATE, MapUtils.getString(oldB105Map,
                                        "CRT_NO_C102"))) {
                                        boolean isOK = this.chkNewSec_Exe1(mkmB105, keyB105Map, oldB105Map, ADJ_RNT_SDATE, ADJ_RNT_EDATE,
                                            sLAST_DATE);
                                        if (!isOK) {
                                            this.chkNewSecThrowMsg1(locale, oldCUS_NO, ADJ_RNT_SDATE, ADJ_RNT_EDATE);
                                        }

                                    }

                                }
                            }
                        }
                        cusNoMap.put(newCUS_NO, null);
                    }

                }

            }

        } else {//�K���϶�
            if (oldB104_List == null || oldB104_List.isEmpty()) {//��կ��϶����ūh���ݤ��
                return;
            }

            MultiKeyMap mkmB104 = new MultiKeyMap();
            Map keyB104Map = new HashMap();
            if (newB104_List != null) {
                for (Map newB104Map : newB104_List) {
                    String key1 = MapUtils.getString(newB104Map, "EXP_STR_DATE");
                    String key2 = MapUtils.getString(newB104Map, "EXP_END_DATE");

                    if (!mkmB104.containsKey(key1, key2)) {
                        mkmB104.put(key1, key2, null);

                    }

                    if (!keyB104Map.containsKey(key1)) {
                        keyB104Map.put(key1, null);
                    }
                }
            }

            if (IS_DLT_NORNT) {//�R���կ��϶�
                if (StringUtils.isBlank(CUS_NO)) {
                    if (IS_IFRS_CRT) {
                        for (Map oldB104Map : oldB104_List) {
                            String EXP_STR_DATE = MapUtils.getString(oldB104Map, "EXP_STR_DATE");
                            String EXP_END_DATE = MapUtils.getString(oldB104Map, "EXP_END_DATE");
                            if (this.chkNewSecMsgRule2(EXP_STR_DATE, EXP_END_DATE, sLAST_DATE)) {
                                String oldCUS_NO = MapUtils.getString(oldB104Map, "CUS_NO");
                                this.chkNewSecThrowMsg2(locale, oldCUS_NO, EXP_STR_DATE, EXP_END_DATE);
                            }
                        }

                    }
                } else {
                    boolean IS_IFRS_CUS = theEP_B10100.chkCrtIsIFRS(SUB_CPY_ID, CRT_NO, Integer.valueOf(CUS_NO));
                    if (IS_IFRS_CUS) {
                        for (Map oldB104Map : oldB104_List) {
                            String oldCUS_NO = MapUtils.getString(oldB104Map, "CUS_NO");
                            if (CUS_NO.equals(oldCUS_NO)) {
                                String EXP_STR_DATE = MapUtils.getString(oldB104Map, "EXP_STR_DATE");
                                String EXP_END_DATE = MapUtils.getString(oldB104Map, "EXP_END_DATE");
                                if (this.chkNewSecMsgRule2(EXP_STR_DATE, EXP_END_DATE, sLAST_DATE)) {
                                    this.chkNewSecThrowMsg2(locale, oldCUS_NO, EXP_STR_DATE, EXP_END_DATE);
                                }
                            }
                        }
                    }

                }
            } else if (NORNT_SAME) {//�Ҧ���ƬҬۦP

                if (IS_IFRS_CRT) {

                    for (Map oldB104Map : oldB104_List) {
                        String EXP_STR_DATE = MapUtils.getString(oldB104Map, "EXP_STR_DATE");
                        String EXP_END_DATE = MapUtils.getString(oldB104Map, "EXP_END_DATE");
                        String oldCUS_NO = MapUtils.getString(oldB104Map, "CUS_NO");

                        if (this.chkNewSecMsgRule2(EXP_STR_DATE, EXP_END_DATE, sLAST_DATE)) {
                            boolean isOK = this.chkNewSec_Exe2(mkmB104, keyB104Map, EXP_STR_DATE, EXP_END_DATE, sLAST_DATE);
                            if (!isOK) {
                                this.chkNewSecThrowMsg2(locale, oldCUS_NO, EXP_STR_DATE, EXP_END_DATE);
                            }

                        }

                    }
                }
            } else {//�̷Ӧ����ʨ쪺�Ȥ�Ǹ�����s�¸��
                Map cusNoMap = new HashMap();
                for (Map newB104Map : newB104_List) {
                    String newCUS_NO = MapUtils.getString(newB104Map, "CUS_NO");
                    if (!cusNoMap.containsKey(newCUS_NO)) { //�@�ӧǸ��u��@��
                        boolean IS_IFRS_CUS = theEP_B10100.chkCrtIsIFRS(SUB_CPY_ID, CRT_NO, Integer.valueOf(newCUS_NO));
                        if (IS_IFRS_CUS) {

                            for (Map oldB104Map : oldB104_List) {
                                String oldCUS_NO = MapUtils.getString(oldB104Map, "CUS_NO");
                                String EXP_STR_DATE = MapUtils.getString(oldB104Map, "EXP_STR_DATE");
                                String EXP_END_DATE = MapUtils.getString(oldB104Map, "EXP_END_DATE");
                                if (oldCUS_NO.equals(newCUS_NO)) {
                                    if (this.chkNewSecMsgRule2(EXP_STR_DATE, EXP_END_DATE, sLAST_DATE)) {
                                        boolean isOK = this.chkNewSec_Exe2(mkmB104, keyB104Map, EXP_STR_DATE, EXP_END_DATE, sLAST_DATE);
                                        if (!isOK) {
                                            this.chkNewSecThrowMsg2(locale, oldCUS_NO, EXP_STR_DATE, EXP_END_DATE);
                                        }

                                    }

                                }
                            }
                        }
                        cusNoMap.put(newCUS_NO, null);
                    }

                }

            }

        }

    }

    /**
     * ���]�Ȧs�ɸ��
    * @param SUB_CPY_ID �����q�O
    * @param CRT_NO �����N��
    * @param CUS_NO �Ȥ�Ǹ�
    * @param APLY_NO �ץ�s��
    * @param CHG_ITEM ���ʶ��� 1 �կ��϶� 2 �K���϶�
    * @throws ModuleException
    */
    public void resetTmp(String SUB_CPY_ID, String CRT_NO, String CUS_NO, String APLY_NO, String CHG_ITEM) throws ModuleException {

        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_001"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_003"));//�ץ�s�����o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_002"));//�����N�����o���ŭ�
        }
        if (!("1".equals(CHG_ITEM) || "2".equals(CHG_ITEM))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_B30040_MSG_024"));//���ʶ��إu�i��1��2
        }
        if (eie != null) {
            throw eie;
        }
        //�R���Ȧs�ɸ��
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("CRT_NO", CRT_NO);
        if (StringUtils.isNotEmpty(CUS_NO)) {
            ds.setField("CUS_NO", CUS_NO);
        }

        if ("1".equals(CHG_ITEM)) {//�կ��϶�
            DBUtil.executeUpdate(ds, SQL_resetTmp_001, false);

        } else {
            DBUtil.executeUpdate(ds, SQL_resetTmp_002, false);
        }

    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �R���Žկ��϶��Ȧs�ɸ�T
     * @param APLY_NO
     * @param CRT_NO
     * @param CUS_NO
     * @param ds
     * @throws ModuleException
     */
    private void deleteEPB305(String APLY_NO, String CRT_NO, String CUS_NO, DataSet ds) throws ModuleException {
        ds.clear();
        ds.setField("APLY_NO", APLY_NO);
        if (StringUtils.isNotEmpty(CRT_NO)) {
            ds.setField("CRT_NO", CRT_NO);
        }
        if (StringUtils.isNotEmpty(CUS_NO)) {
            ds.setField("CUS_NO", CUS_NO);
        }

        DBUtil.executeUpdate(ds, SQL_insert_002, false);

    }

    /**
     * �R���K���϶��Ȧs�ɸ�T
     * @param APLY_NO
     * @param CRT_NO
     * @param CUS_NO
     * @param ds
     * @throws ModuleException
     */
    private void deleteEPB304(String APLY_NO, String CRT_NO, String CUS_NO, DataSet ds) throws ModuleException {
        ds.clear();
        ds.setField("APLY_NO", APLY_NO);
        if (StringUtils.isNotEmpty(CRT_NO)) {
            ds.setField("CRT_NO", CRT_NO);
        }
        if (StringUtils.isNotEmpty(CUS_NO)) {
            ds.setField("CUS_NO", CUS_NO);
        }

        DBUtil.executeUpdate(ds, SQL_insert_001, false);

    }

    /**
     * String ��Integer
     * @param map
     * @param key
     * @param nullValue
     * @return
     */
    private Integer toInteger(Map map, String key, Integer nullValue) {
        String v = MapUtils.getString(map, key);
        if (StringUtils.isNotBlank(v)) {
            return Integer.valueOf(v);
        }
        return nullValue;
    }

    /**
     * ���ͽկ��ˮְT��
     * @param locale
     * @param cusNo
     * @param ADJ_RNT_SDATE
     * @param ADJ_RNT_EDATE
     * @return
     * @throws ModuleException
     */
    private String chkNewSecThrowMsg1(LocaleDisplay locale, String cusNo, String ADJ_RNT_SDATE, String ADJ_RNT_EDATE)
            throws ModuleException {
        String date1 = locale.formatDate(Date.valueOf(ADJ_RNT_SDATE), "/", ADJ_RNT_SDATE);
        String date2 = locale.formatDate(Date.valueOf(ADJ_RNT_EDATE), "/", ADJ_RNT_EDATE);
        throw new ModuleException(MessageUtil.getMessage("EP_B30040_MSG_025", new Object[] { cusNo, date1, date2 }));//���u�k�����w�{�C�A���o�R�������կ����!�Ȥ�Ǹ�:{0}�A�կ��_��:{1}�A�կ�����:{2}
    }

    /**
     * ���ͧK���ˮְT��
     * @param locale
     * @param cusNo
     * @param EXP_STR_DATE
     * @param EXP_END_DATE
     * @return
     * @throws ModuleException
     */
    private String chkNewSecThrowMsg2(LocaleDisplay locale, String cusNo, String EXP_STR_DATE, String EXP_END_DATE) throws ModuleException {
        String date1 = locale.formatDate(Date.valueOf(EXP_STR_DATE), "/", EXP_STR_DATE);
        String date2 = locale.formatDate(Date.valueOf(EXP_END_DATE), "/", EXP_END_DATE);
        throw new ModuleException(MessageUtil.getMessage("EP_B30040_MSG_026", new Object[] { cusNo, date1, date2 }));//���u�k�����w�{�C�A���o�R�������K�����!�Ȥ�Ǹ�:{0}�A�K���_��:{1}�A�K������:{2}
    }

    /**
     * �կ����
     * @param mkmB105
     * @param keyB105Map
     * @param oldB105Map
     * @param ADJ_RNT_SDATE
     * @param ADJ_RNT_EDATE
     * @param LAST_DATE
     * @return
     */
    private boolean chkNewSec_Exe1(MultiKeyMap mkmB105, Map keyB105Map, Map oldB105Map, String ADJ_RNT_SDATE, String ADJ_RNT_EDATE,
            String LAST_DATE) {
        boolean isOK = false;

        if (DATE.diffDay(ADJ_RNT_EDATE, LAST_DATE) >= 0) {
            BigDecimal oldADJ_UNIT_NUM = new BigDecimal(MapUtils.getString(oldB105Map, "ADJ_UNIT_NUM"));
            String oldADJ_UNIT = MapUtils.getString(oldB105Map, "ADJ_UNIT");
            if (mkmB105.containsKey(ADJ_RNT_SDATE, ADJ_RNT_EDATE, oldADJ_UNIT)) {
                List<BigDecimal> BDs = (List<BigDecimal>) mkmB105.get(ADJ_RNT_SDATE, ADJ_RNT_EDATE, oldADJ_UNIT);
                for (BigDecimal num : BDs) {
                    if (num.compareTo(oldADJ_UNIT_NUM) == 0) {
                        return true;
                    }
                }
            }

        } else {
            if (keyB105Map.containsKey(ADJ_RNT_SDATE)) {
                isOK = true;
            }

        }
        return isOK;

    }

    /**
     * �K�����
     * @param mkmB104
     * @param keyB104Map
     * @param EXP_STR_DATE
     * @param EXP_END_DATE
     * @param LAST_DATE
     * @return
     */
    private boolean chkNewSec_Exe2(MultiKeyMap mkmB104, Map keyB104Map, String EXP_STR_DATE, String EXP_END_DATE, String LAST_DATE) {
        boolean isOK = false;

        if (DATE.diffDay(EXP_END_DATE, LAST_DATE) >= 0) {

            if (mkmB104.containsKey(EXP_STR_DATE, EXP_END_DATE)) {
                isOK = true;
            }

        } else {
            if (keyB104Map.containsKey(EXP_STR_DATE)) {
                isOK = true;
            }

        }
        return isOK;

    }

    /**
     * �կ�disable�W�h
     * @param ADJ_RNT_SDATE
     * @param ADJ_RNT_EDATE
     * @param LAST_DATE
     * @param CRT_NO_C102
     * @return
     */
    private boolean chkNewSecMsgRule1(String ADJ_RNT_SDATE, String ADJ_RNT_EDATE, String LAST_DATE, String CRT_NO_C102) {
        return DATE.diffDay(ADJ_RNT_SDATE, LAST_DATE) >= 0 || DATE.diffDay(ADJ_RNT_EDATE, LAST_DATE) >= 0
                || StringUtils.isNotBlank(CRT_NO_C102);
    }

    /**
     * �K��disable�W�h
     * @param EXP_STR_DATE
     * @param EXP_END_DATE
     * @param LAST_DATE
     * @return
     */
    private boolean chkNewSecMsgRule2(String EXP_STR_DATE, String EXP_END_DATE, String LAST_DATE) {
        return DATE.diffDay(EXP_STR_DATE, LAST_DATE) >= 0 || DATE.diffDay(EXP_END_DATE, LAST_DATE) >= 0;
    }
}
