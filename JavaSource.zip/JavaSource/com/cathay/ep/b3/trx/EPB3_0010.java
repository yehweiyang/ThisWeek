package com.cathay.ep.b3.trx;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.b1.module.EPB1_0010_mod;
import com.cathay.ep.b3.module.EPB3_0010_mod;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.vo.DTEPB101;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2013/8/14   1.0 Created ���կ�
 * [20181105] Modified �H�H���~�B�z
 * UCEPB3_0010_�߮׿�J
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �߮׿�J
 * �{���W��    EPB3_0010
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 *             (2) �߮� �w ���ѨϥΪ̷s�W�j�ӤΫ����ܧ�e�f�ץ�C
 *             (3) �e�� �V ���ѨϥΪ̴���e�f�ܧ�ץ�C
 *             (4) �����e�� �w ���ѨϥΪ̨����e�f���椧�ܧ�ץ�C
 *             (5) �R�� �w ���ѨϥΪ̧R���߮׸�ơC
 *             (6) �f�� �w ���ѨϥΪ̼f���ܧ�ץ�C
 *             (7) ���P �w ���ѨϥΪ̨����w����s���ץ�C
 *             (8) �^�W�� �w �ϥΪ̥i�z�L�����s�^�W�h�e���C
 * ���s���v    �M��
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 * �h���d��    �L                                      
 * </pre>
 * @author �x�Ԫ�
 * @since 2013/12/10
 * 20200407 �{���U�[�����¤�k
 */
@SuppressWarnings("unchecked")
public class EPB3_0010 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPB3_0010.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);
        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPB3_0010_ERRMSG_001");//���o�����q�O����
        }
        //�ץ����
        resp.addOutputData("APLY_KIND_LIST", FieldOptionList.getName("EP", "APLY_KIND_B301"));
        //BLD_TRNKD_B301(�j��), CRT_TRNKD_B301(����), TERM_TRNKD_B301(�����ܧ�), NCRT_TRNKD_B301(�t�q�s��)
        resp.addOutputData("LINK_FROM", req.getParameter("LINK_FROM"));
        resp.addOutputData("APLY_NO", req.getParameter("APLY_NO"));
        //�������

        //for EPG40100
        resp.addOutputData("APLY_KIND", req.getParameter("APLY_KIND"));
        resp.addOutputData("G0_TRN_KIND", req.getParameter("G0_TRN_KIND"));
        resp.addOutputData("BLD_CD", req.getParameter("BASE_CD"));
        resp.addOutputData("BLD_NAME", req.getParameter("BASE_BLD_NAME"));

        resp.addOutputData("D_APLY_NO", req.getParameter("D_APLY_NO"));
        //for EPG40100

        //�ץ����� NOW_UPDATE_LIST
        resp.addOutputData("NOW_UPDATE_LIST", FieldOptionList.getName("EP", "NOW_UPDATE"));

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            String LINK_FROM = req.getParameter("LINK_FROM");
            String APLY_NO = req.getParameter("APLY_NO");
            if (StringUtils.isNotBlank(LINK_FROM) && StringUtils.isBlank(APLY_NO)) {
                throw new ErrorInputException("EPB3_0010_ERRMSG_002");//�ץ�s�������ǤJ
            }
            this.query(APLY_NO, LINK_FROM, new EP_B30010());

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB3_0010_ERRMSG_003");//�d�L���ץ�s����T
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �ˮ�(�s�W)
     * @param req
     * @return
     */
    public ResponseContext doCheckInsert(RequestContext req) {
        try {
            DTEPB301 B301VO = VOTool.jsonToVO(DTEPB301.class, req.getParameter("B301VO"));
            //�ˮ֥D�ɬO�_�i�ק�A���i�h��X���~
            String CRT_NO = B301VO.getCRT_NO();
            String PRE_CRT_NO = B301VO.getPRE_CRT_NO();
            String SUB_CPY_ID = B301VO.getSUB_CPY_ID();
            if (StringUtils.isNotBlank(CRT_NO) || StringUtils.isNotBlank(PRE_CRT_NO)) {
                DTEPB101 B101Vo = new DTEPB101();
                B101Vo.setSUB_CPY_ID(SUB_CPY_ID);
                EPB3_0010_mod theEPB3_0010_mod = new EPB3_0010_mod();
                if (StringUtils.isNotBlank(CRT_NO)) {
                    B101Vo.setCRT_NO(CRT_NO);
                    //�ˮ֫����N���ݦs�b
                    new EPB1_0010_mod().checkDTEPB101CRT_NO(B101Vo, true);

                    resp.addOutputData("isReg", theEPB3_0010_mod.checkDTEPB301CrtNo(B301VO, "U"));
                    resp.addOutputData("has_TRN_CRT_NEW", theEPB3_0010_mod.checkHasNewCrtNo(B301VO, "U"));//�������w���s�������A�i�H�z�L�w����ץ��i��ץ�
                }
                if (StringUtils.isNotBlank(PRE_CRT_NO)) {
                    B101Vo.setCRT_NO(PRE_CRT_NO);
                    new EPB1_0010_mod().checkDTEPB101CRT_NO(B101Vo, true);
                    B301VO.setCRT_NO(PRE_CRT_NO);
                    if (theEPB3_0010_mod.checkDTEPB301CrtNo(B301VO, "U")) {
                        throw new ModuleException(MessageUtil.getMessage("EPB3_0010_ERRMSG_026", new Object[] { PRE_CRT_NO }));//�«����|���w���󥼧�s�D��! ���i�ץ��«����N��:�u{0}�v���
                    }
                }
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0010_ERRMSG_004");//�߮��ˮ֥���
            }
        } catch (Exception e) {
            log.error("�߮��ˮ֥���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0010_ERRMSG_004");//�߮��ˮ֥���
        }

        return resp;
    }

    /**
     * �s�W(�߮�)
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {

            Map B301Map = VOTool.jsonToMap(req.getParameter("B301VO"));
            DTEPB301 B301VO = VOTool.mapToVO(DTEPB301.class, B301Map);
            String APLY_KIND = (String) B301Map.get("APLY_KIND");

            Map userMap = new HashMap();
            userMap.put("CHG_DIV_NO", user.getOpUnit());
            userMap.put("CHG_ID", user.getEmpID());
            userMap.put("CHG_NAME", user.getEmpName());
            userMap.put("D_APLY_NO", B301Map.get("D_APLY_NO"));
            String name = user.getEmpName();
            log.debug("@@@@@@@@@@@@@@@@@@@@@@@@@@@@" + name);
            byte[] binary = name.getBytes("big5");
            for (byte bb : binary) {
                log.debug(Integer.toHexString(bb & 0XFF));
            }
            Timestamp Time = DATE.currentTime();
            B301VO.setINPUT_DATE(Time);
            B301VO.setLST_PROC_DATE(Time);
            EP_B30010 theEP_B30010 = new EP_B30010();
            Map rtnMap;

            Transaction.begin();
            try {
                rtnMap = theEP_B30010.insert(B301VO, userMap, false, APLY_KIND);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB3_0010_MSG_005");//�߮ק���
            try {
                this.query(MapUtils.getString(rtnMap, "APLY_NO"), req.getParameter("LINK_FROM"), theEP_B30010);
            } catch (DataNotFoundException e) {
                log.error("�s�W�����A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB3_0010_MSG_006");//�߮ק����A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataDuplicateException dde) {
            log.error("�s�W���ѡA��Ƥw�s�b", dde);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_DUP, "MEP00006");//�s�W���ѡA��Ƥw�s�b
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00005");//�s�W����
        }

        return resp;
    }

    /**
     * �ˮ�(�e��B�f��)
     * @param req
     * @return
     */
    public ResponseContext doCheckSubmit(RequestContext req) {
        try {
            DTEPB301 B301Vo = VOTool.jsonToVO(DTEPB301.class, req.getParameter("B301VO"));
            B301Vo = VOTool.findByPKWithUR(B301Vo);
            String OP_STATUS = B301Vo.getOP_STATUS();
            if (StringUtils.isNotBlank(OP_STATUS)) {
                B301Vo.setOP_STATUS(OP_STATUS.trim());
            }
            //�ˮָӰe���ƬO�_���T�A�_�h��X���~
            EPB3_0010_mod theEPB3_0010_mod = new EPB3_0010_mod();
            theEPB3_0010_mod.checkComm(B301Vo);
            //�ˮ֩ӯ��_���O�_���T
            if ("submit".equals(req.getParameter("action"))) {
                Map chkMap = theEPB3_0010_mod.checkRntDate(B301Vo);
                //�YchkMap.IS_DIFF �� true
                Boolean IS_DIFF = MapUtils.getBoolean(chkMap, "IS_DIFF", false);
                resp.addOutputData("IS_DIFF", IS_DIFF);
                if (IS_DIFF) {
                    StringBuffer sb = new StringBuffer();
                    sb.append(MapUtils.getString(chkMap, "MSG", ""));
                    STRING.newLine(sb);
                    resp.addOutputData("MSG", sb.append(MessageUtil.getMessage("EPB3_0010_MSG_027")).toString()); //�ӯ���_����P�ǧO�Ψ���_�����P�A�O�_�~��@�~�H
                }
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0010_ERRMSG_025");//�ˮ֥���
            }
        } catch (Exception e) {
            log.error("�ˮ֥���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0010_ERRMSG_025"); //�ˮ֥���
        }

        return resp;
    }

    /**
     * �e��
     * @param req
     * @return
     */
    public ResponseContext doSubmit(RequestContext req) {
        try {
            DTEPB301 B301Vo = VOTool.jsonToVO(DTEPB301.class, req.getParameter("B301VO"));
            B301Vo = VOTool.findByPKWithUR(B301Vo);
            String OP_STATUS = B301Vo.getOP_STATUS();
            if (StringUtils.isNotBlank(OP_STATUS)) {
                B301Vo.setOP_STATUS(OP_STATUS.trim());
            }
            EP_B30010 theEP_B30010 = new EP_B30010();

            Transaction.begin();
            try {
                theEP_B30010.submit(B301Vo, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB3_0010_MSG_007");//�e�󧹦�
            try {
                this.query(B301Vo.getAPLY_NO(), req.getParameter("LINK_FROM"), theEP_B30010);
            } catch (DataNotFoundException e) {
                log.error("�e�󧹦��A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB3_0010_MSG_008");//�e�󧹦��A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB3_0010_ERRMSG_014");//�e�󥢱ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0010_ERRMSG_009");//�e�󥢱�
            }
        } catch (Exception e) {
            log.error("�e�󥢱�", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0010_ERRMSG_009");//�e�󥢱�
        }

        return resp;
    }

    /**
     * �����e��
     * @param req
     * @return
     */
    public ResponseContext doCancelSubmit(RequestContext req) {
        try {
            DTEPB301 B301Vo = VOTool.jsonToVO(DTEPB301.class, req.getParameter("B301VO"));
            B301Vo = VOTool.findByPKWithUR(B301Vo);
            String OP_STATUS = B301Vo.getOP_STATUS();
            if (StringUtils.isNotBlank(OP_STATUS)) {
                B301Vo.setOP_STATUS(OP_STATUS.trim());
            }
            EP_B30010 theEP_B30010 = new EP_B30010();

            Transaction.begin();
            try {
                theEP_B30010.cancelSubmit(B301Vo, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB3_0010_MSG_010");//�����e�󧹦�
            try {
                this.query(B301Vo.getAPLY_NO(), req.getParameter("LINK_FROM"), theEP_B30010);
            } catch (DataNotFoundException e) {
                log.error("�����e�󧹦��A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB3_0010_MSG_011");//�����e�󧹦��A�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB3_0010_ERRMSG_015");//�����e�󥢱ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0010_ERRMSG_012");//�����e�󥢱�
            }
        } catch (Exception e) {
            log.error("�����e�󥢱�", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0010_ERRMSG_012");//�����e�󥢱�
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            DTEPB301 B301Vo = VOTool.jsonToVO(DTEPB301.class, req.getParameter("B301VO"));
            EP_B30010 theEP_B30010 = new EP_B30010();

            Transaction.begin();
            try {
                theEP_B30010.delete(B301Vo, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00010");//�R������
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB3_0010_ERRMSG_013");//�R�����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00011");//�R������
            }
        } catch (Exception e) {
            log.error("�R���@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00011");//�R������
        }

        return resp;
    }

    /**
     * �f��
     * @param req
     * @return
     */
    public ResponseContext doApprove(RequestContext req) {
        try {
            DTEPB301 B301Vo = VOTool.jsonToVO(DTEPB301.class, req.getParameter("B301VO"));
            B301Vo = VOTool.findByPKWithUR(B301Vo);
            String OP_STATUS = B301Vo.getOP_STATUS();
            if (StringUtils.isNotBlank(OP_STATUS)) {
                B301Vo.setOP_STATUS(OP_STATUS.trim());
            }
            EP_B30010 theEP_B30010 = new EP_B30010();
            String rtnMsg = "";
            Transaction.begin();
            try {
                rtnMsg = theEP_B30010.approve(B301Vo, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            //[20181105] Modified �H�H���~�B�z
            if (StringUtils.isNotBlank(rtnMsg)) {
                resp.addOutputData("RTN_MSG", "�f�֧����A�H�H���ѡA�нT�{�H�U�@�~�G" + STRING.lineSeparator + rtnMsg);
            }

            try {
                this.query(B301Vo.getAPLY_NO(), req.getParameter("LINK_FROM"), theEP_B30010);
            } catch (DataNotFoundException e) {
                log.error("�f�֧����A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB3_0010_MSG_019");//�f�֧����A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB3_0010_ERRMSG_016");//�f�֥��ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0010_ERRMSG_017");//�f�֥���
            }
        } catch (Exception e) {
            log.error("�f�֥���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0010_ERRMSG_017");//�f�֥���
        }

        return resp;
    }

    /**
     * ���o������ؤU�Կ��
     * @param req
     * @return
     */
    public ResponseContext doGetTRN_KIND_List(RequestContext req) {
        try {
            resp.addOutputData("TRN_KIND_LIST", FieldOptionList.getFieldOptions("EP", req.getParameter("APLY_KIND")));
        } catch (Exception e) {
            log.error("���o������ؤU�Կ�楢��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0010_ERRMSG_020");//���o������ؤU�Կ�楢��
        }

        return resp;
    }


    /**
     * ���P
     * @param req
     * @return
     */
    public ResponseContext doCancel(RequestContext req) {
        try {
            DTEPB301 B301Vo = VOTool.jsonToVO(DTEPB301.class, req.getParameter("B301VO"));
            B301Vo = VOTool.findByPKWithUR(B301Vo);
            B301Vo.setOP_STATUS(B301Vo.getOP_STATUS().trim());
            EP_B30010 theEP_B30010 = new EP_B30010();

            Transaction.begin();
            try {
                theEP_B30010.cancel(B301Vo, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB3_0010_MSG_021");//���P����
            try {
                this.query(B301Vo.getAPLY_NO(), req.getParameter("LINK_FROM"), theEP_B30010);
            } catch (DataNotFoundException e) {
                log.error("���P�����A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB3_0010_MSG_022");//���P�����A�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB3_0010_ERRMSG_024");//���P���ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0010_ERRMSG_023");//���P����
            }
        } catch (Exception e) {
            log.error("���P����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0010_ERRMSG_023");//���P����
        }

        return resp;
    }

    /**
     * ��l�d��
     * @param APLY_NO
     * @param LINK_FROM
     * @param theEP_B30010
     * @throws ModuleException
     */
    private void query(String APLY_NO, String LINK_FROM, EP_B30010 theEP_B30010) throws ModuleException {
        Map rtnB301Map = new EP_B30010().queryMap(APLY_NO);

        String OP_STATUS = MapUtils.getString(rtnB301Map, "OP_STATUS").trim();
        //  rtnB301Map.put("OP_STATUS", OP_STATUS); //�ץ�@�~�i��
        String REG_TRN_KIND = MapUtils.getString(rtnB301Map, "REG_TRN_KIND");
        //�������
        rtnB301Map.put("OP_TYPE", user.getEmpID().equals(MapUtils.getString(rtnB301Map, "INPUT_ID")) ? "P" : "Q");
        //�̥���������o�������
        //�e����ܭ��ҲM��TAB_LIST = COPY �@��FieldOptionList.getName(��EP��, TRN_KIND  + ��_TAB��)  //EX:���o�N�X������EPA001_TAB�w�q����ܭ���
        //�ץ����APLY_KD
        //��M APLY_KIND_NM
        String TRN_KIND = MapUtils.getString(rtnB301Map, "TRN_KIND");
        Map APLY_KIND_B301 = FieldOptionList.getName("EP", "APLY_KIND_B301");
        for (Object every_key : APLY_KIND_B301.keySet()) {
            String every_key_str = every_key.toString();
            Map every_key_map = FieldOptionList.getName("EP", every_key_str);
            if (every_key_map.containsKey(TRN_KIND)) {
                rtnB301Map.put("APLY_KIND", every_key_str);
                rtnB301Map.put("APLY_KIND_NM", APLY_KIND_B301.get(every_key_str));
                break;
            }
        }
        StringBuilder sb = new StringBuilder();

        //���O���f�֥�����y�{�����]�wtab(���٬O�n��ܤj�өΫ��������ƭ��Ҫ̳]�w�b���N�X��Ӥ�)
        Set NOTAB_TRN_B301_Set = FieldOptionList.getName("EP", "NOTAB_TRN_B301").keySet();
        List<Map> TAB_LIST = new ArrayList<Map>();
        if (!NOTAB_TRN_B301_Set.contains(TRN_KIND)) {
            Map TAB_Map = FieldOptionList.getFieldOptions("EP", sb.append(TRN_KIND).append("_TAB").toString(), false);
            for (Object every_key : TAB_Map.keySet()) {
                Map map = new HashMap();
                map.put("id", every_key);
                map.put("title", MapUtils.getString(TAB_Map, every_key, ""));
                TAB_LIST.add(map);
            }
        }
        resp.addOutputData("rtnB301Map", rtnB301Map);
        if (StringUtils.isNotBlank(APLY_NO) && !rtnB301Map.isEmpty()) {
            List<Map> rtnLIST = theEP_B30010.showTabs(APLY_NO, TAB_LIST, OP_STATUS, LINK_FROM, REG_TRN_KIND, MapUtils.getString(rtnB301Map,
                "SUB_CPY_ID"));
            if (rtnLIST != null && !rtnLIST.isEmpty()) {
                resp.addOutputData("TAB_LIST", rtnLIST);
            }

        }

    }
}
