package com.cathay.ep.b3.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.b3.module.EPB3_0010_mod;
import com.cathay.ep.b3.module.EPB3_0030_mod;
import com.cathay.ep.b3.module.EP_B30030;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPB303;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 * Date    Version Description Author
 * 2013/9/11   1.0 Created ���կ�
 * 
 * UCEPB3_0030_�����״��ܧ�
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �����״��ܧ�
 * �{���W��    EPB3_0030
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 * (2) �d�� �w �ϥΪ̫��U�d�߫��s��A�I�sEP_B10020�Ҳը��o�ӯ���M���ơC
 * (3) ���� �w �}�ҵ������ѨϥΪ̬d�߫�����ƤΩӯ���A�I���a�^�A�����������C
 * (4) ��J �w �s�W�ץ󲧰ʶ���
 * (5) �簣 �w �R���ץ󲧰ʶ���
 * </pre>
 * @author �¶��� 
 * @since 2013/12/29  
 */
@SuppressWarnings("unchecked")
public class EPB3_0030 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPB3_0030.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            //����
            VOTool.setParamsFromLP_JSON(req);

            resp.addOutputData("USER_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));//�����q�O
            resp.addOutputData("APLY_NO", req.getParameter("APLY_NO"));//�ץ�s��
            resp.addOutputData("IN_CRT_NO", req.getParameter("IN_CRT_NO"));//�����N��
            resp.addOutputData("IN_CUS_NO", req.getParameter("IN_CUS_NO"));//�Ȥ�Ǹ�
            resp.addOutputData("USER_ID", user.getEmpID());
            resp.addOutputData("LINK_FROM", req.getParameter("LINK_FROM"));//�W��ǤJ�e��

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (Exception e) {
            log.error("��l����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00029");//��l����
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            String errorMsg = query(VOTool.jsonToMap(req.getParameter("reqMap")));
            if (StringUtils.isNotBlank(errorMsg)) {
                throw new DataNotFoundException(errorMsg);
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            //ReturnCode.OK ��l:�d�L��Ƶ������`�A���q�T��
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, dnfe.getMessage());//�d�L�ӯ�����   �d�L�ץ��ܧ���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * ��J
     * @param req
     * @return
     */
    public ResponseContext doInput(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");

            //�]�w��s�ץ�_�ܧ������T
            DTEPB301 EPB301VO = new DTEPB301();
            EPB301VO.setAPLY_NO(MapUtils.getString(reqMap, "APLY_NO"));
            EPB301VO.setSUB_CPY_ID(MapUtils.getString(reqMap, "SUB_CPY_ID"));
            EPB301VO.setCRT_NO(CRT_NO);
            List<Map> insList = VOTool.jsonAryToMaps(req.getParameter("records"));

            //�ˮ�1�O�_����������L�|���������ץ� 2 ���ץ�O�_�i����
            boolean isReg = new EPB3_0010_mod().checkDTEPB301CrtNo(EPB301VO, "U");
            if (isReg) {
                throw new ModuleException(MessageUtil.getMessage("EPB3_0030_UI_MSG_003", new String[] { CRT_NO }));//�������|���w���󥼧�s�D��! ���i�ץ����������u{0}�v���
            }

            Map paramMap = VOTool.jsonToMap(req.getParameter("paramMap"));
            String TRN_KIND = MapUtils.getString(paramMap, "TRN_KIND");
            String RNT_TYPE = MapUtils.getString(paramMap, "RNT_TYPE");
            String CRT_STS = MapUtils.getString(paramMap, "CRT_STS");
            String CRT_DATE = MapUtils.getString(paramMap, "CRT_DATE");
            String BLD_CD = MapUtils.getString(paramMap, "BLD_CD");
            EPB3_0030_mod theEPB3_0030_mod = new EPB3_0030_mod();
            //�v���B�zinsList, �ˮָ�ƦX�z��
            for (Map rtnMap : insList) {
                theEPB3_0030_mod.chkInput(rtnMap, TRN_KIND, RNT_TYPE, CRT_STS, CRT_DATE);
            }
            EP_B30030 theEP_B30030 = new EP_B30030();

            Transaction.begin();
            try {
                //����s�W�{��
                for (Map rtnMap : insList) {
                    theEP_B30030.insert(rtnMap, TRN_KIND, BLD_CD);
                }
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB3_0030_UI_MSG_004");//��J����

            //���d���
            String errorMsg = query(reqMap);
            if (StringUtils.isNotBlank(errorMsg)) {
                StringBuilder sb = new StringBuilder();
                //��J����,���d+errorMsg
                sb.append(MessageUtil.getMessage("EPB3_0030_UI_MSG_004")).append(MessageUtil.getMessage("EPB3_0030_UI_MSG_005")).append(
                    errorMsg);

                MessageUtil.setMsg(msg, sb.toString());
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataDuplicateException dde) {
            log.error("", dde);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_DUP, "EPB3_0030_UI_MSG_007");//��J���ѡA��Ƥw�s�b
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0030_UI_MSG_008");//��J����
            }
        } catch (Exception e) {
            log.error("��J�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0030_UI_MSG_008");//��J����
        }

        return resp;
    }

    /**
     * �簣
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String isConfirm = req.getParameter("isConfirm");

            //�]�w��s�ץ�_�ܧ������T
            if (!"Y".equals(isConfirm)) {//�즸����簣
                DTEPB301 EPB301VO = new DTEPB301();
                EPB301VO.setAPLY_NO(MapUtils.getString(reqMap, "APLY_NO"));
                EPB301VO.setSUB_CPY_ID(MapUtils.getString(reqMap, "SUB_CPY_ID"));
                EPB301VO.setCRT_NO(MapUtils.getString(reqMap, "CRT_NO"));
                boolean isReg = new EPB3_0010_mod().checkDTEPB301CrtNo(EPB301VO, "U");
                if (isReg) {
                    resp.addOutputData("isConfirm", "Y");
                    return resp;
                }
            }

            List<DTEPB303> EPB303VOList = VOTool.jsonAryToVOs(DTEPB303.class, req.getParameter("records"));
            EP_B10020 theEP_B10020 = new EP_B10020();
            Transaction.begin();
            try {
                for (DTEPB303 EPB303VO : EPB303VOList) {
                    theEP_B10020.deleteDTEPB303(EPB303VO);
                }
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPB3_0030_UI_MSG_009");//�簣����

            //���d���
            String errorMsg = query(reqMap);
            if (StringUtils.isNotBlank(errorMsg)) {
                StringBuilder sb = new StringBuilder();
                //�簣����,���d+errorMsg
                sb.append(MessageUtil.getMessage("EPB3_0030_UI_MSG_009")).append(MessageUtil.getMessage("EPB3_0030_UI_MSG_005")).append(
                    errorMsg);
                MessageUtil.setMsg(msg, sb.toString());
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB3_0030_UI_MSG_012");//�簣���ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0030_UI_MSG_013");//�簣����
            }
        } catch (Exception e) {
            log.error("�簣����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPB3_0030_UI_MSG_013"));//�簣����
        }

        return resp;
    }

    /**
     * �d�ߥD�ɸ��,�ץ��ɸ��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    private String query(Map reqMap) throws ModuleException {
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");

        StringBuilder errMsg = new StringBuilder();
        if (StringUtils.isNotBlank(CRT_NO)) {// �Y�����N������,�d�D�ɸ��
            //�d�D�ɸ��
            try {
                reqMap.put("APLY_NO", null);
                List<Map> rtnBList = new EP_B10020().queryTenentList(reqMap);

                // 20161228 LogSecurity
                try{
              		List<Map> logSecurityList = new ArrayList<Map>();
              		for (Map tmpRecord : rtnBList) {
              			Map logSecurityMap = new HashMap();
              			// �Ȥ�m�W
              			logSecurityMap.put("CUS_NAME", 
              					MapUtils.getString(tmpRecord,"CUS_NAME", ""));
              			logSecurityList.add(logSecurityMap);
              		}
              		logSecurity(logSecurityList);
              		logSecurityList.clear();
                } catch(Throwable e) {
                	log.warn(e, e);
                } 
                
                Map map1 = rtnBList.get(0);
                resp.addOutputData("RNT_TYPE", MapUtils.getString(map1, "RNT_TYPE_B101"));//�Ĥ@���������ӯ��O
                resp.addOutputData("BLD_CD", MapUtils.getString(map1, "BLD_CD_B101"));//�Ĥ@�����j�ӥN��
                resp.addOutputData("CRT_DATE", MapUtils.getString(map1, "CRT_DATE_B101")); //�Ĥ@����ñ�����
                resp.addOutputData("CRT_STS", MapUtils.getString(map1, "CRT_STS_B101"));
                resp.addOutputData("CRT_STS_NM", MapUtils.getString(map1, "CRT_STS_NM"));//�Ĥ@�����������p���
                resp.addOutputData("MAINCNT", rtnBList.size());
                resp.addOutputData("rtnBList", rtnBList);

            } catch (DataNotFoundException dnfe) {
                log.error("", dnfe);
                errMsg.append(MessageUtil.getMessage("EPB3_0030_UI_MSG_001"));//�d�L�ӯ�����
            }
            reqMap.put("APLY_NO", APLY_NO);
        }
        //�d�ץ��ɸ��

        if (StringUtils.isNotBlank(APLY_NO)) {// �Y�ץ�s������,�d�ץ��ɸ��
            try {
                reqMap.put("CRT_NO", null);

                List<Map> rtnCList = new EP_B30030().queryList(reqMap);
                Map map1 = rtnCList.get(0);
                resp.addOutputData("TRN_KIND", MapUtils.getString(map1, "TRN_KIND_EPB301", ""));//�Ĥ@�����ץ�@�~�i��
                resp.addOutputData("OP_STATUS", MapUtils.getString(map1, "OP_STATUS_EPB301", "").trim());//�Ĥ@�����ץ�@�~�i��
                resp.addOutputData("INPUT_ID", MapUtils.getString(map1, "INPUT_ID_EPB301", ""));//�Ĥ@������J�H��ID
                resp.addOutputData("rtnCList", rtnCList);
                resp.addOutputData("CHGCNT", rtnCList.size());
                if (StringUtils.isBlank(MapUtils.getString(map1, "APLY_NO"))) {
                    throw new DataNotFoundException();
                }
                resp.addOutputData("isShow", "Y");//�O�_��ܦb�϶�C
            } catch (DataNotFoundException dnfe) {
                log.error("", dnfe);
                if (errMsg.length() > 0) {
                    STRING.newLine(errMsg);
                }
                errMsg.append(MessageUtil.getMessage("EPB3_0030_UI_MSG_002"));//�d�L�ץ��ܧ���
                resp.addOutputData("isShow", "N");
            }
            reqMap.put("CRT_NO", CRT_NO);
        }

        return errMsg.toString();
    }

}
