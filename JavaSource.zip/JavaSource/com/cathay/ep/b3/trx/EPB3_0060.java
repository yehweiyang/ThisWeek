package com.cathay.ep.b3.trx;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.b3.module.EP_B30060;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 * Date    Version Description Author
 * 2013/10/11  1.0 Created ���կ�
 * 2018/03/28  2.0 �t�X��ؾɤJ ����[
 * 
 * UCEPB3_0060_���������B�z
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ���������B�z
 * �{���W��    EPB3_0060
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 * (2) ���� �w �}�ҵ������ѨϥΪ̬d�߫�����ơA�I���a�^�A�����������C
 * (3) �d�� �w ���ѨϥΪ̬d�߫����������ӡC
 * (4) �C�L - ���ѨϥΪ̦C�L�����������ӡC
 * (5) �U�� - ���ѨϥΪ̤U�������������ӡC
 * (6) ����T�{ �w ���ѨϥΪ̤Ŀ���ӫ�N�Ŀ��ư�����B�z�C
 * 
 * </pre>
 * @author �¶��� 
 * @since 2013/11/26  
 */
@SuppressWarnings("unchecked")
public class EPB3_0060 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPB3_0060.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            EP_Z00030 theEP_Z00030 = new EP_Z00030();
            String SUB_CPY_ID = theEP_Z00030.getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            resp.addOutputData("isAccountSubCpy", theEP_Z00030.isAccountSubCpy(SUB_CPY_ID));//�O�_�����
            String DIV_NO = user.getOpUnit();
            resp.addOutputData("DIV_NO", DIV_NO);
            resp.addOutputData("DIV_NM", new EP_A10010().getDivName(DIV_NO, SUB_CPY_ID));

            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.MONTH, -1);//��@�Ӥ�
            resp.addOutputData("LAST_YM", new SimpleDateFormat("yyyyMM").format(calendar.getTime()));

        } catch (Exception e) {
            log.error("��l����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00029");//��l����
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
        	List<Map> rtnList =  query(req.getParameter("SUB_CPY_ID"), req.getParameter("END_YM"), req.getParameter("CRT_NO"), req
                     .getParameter("CUS_NO"));
            // 20161227 LogSecurity
            try{
          		List<Map> logSecurityList = new ArrayList<Map>();
          		for (Map tmpRecord : rtnList) {
          			Map logSecurityMap = new HashMap();
          			logSecurityMap.put("ID", 
          					MapUtils.getString(tmpRecord,"ID", ""));          			
          			// �Ȥ�m�W
          			logSecurityMap.put("CUS_NAME", 
          					MapUtils.getString(tmpRecord,"CUS_NAME", ""));
          			logSecurityList.add(logSecurityMap);
          		}
          		logSecurity(logSecurityList);
          		logSecurityList.clear();
            } catch(Throwable e) {
            	log.warn(e, e);
            }           	
        	
            resp.addOutputData("rtnList", rtnList);
            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {
            List<Map> prtList = VOTool.jsonAryToMaps(req.getParameter("records"));
            EP_B30060 theEP_B30060 = new EP_B30060();

            //�զ�PDF����
            Map printMap = theEP_B30060.dueDtlPrint(prtList, req.getParameter("DIV_NM"), user); //�C�L�������
            // 20161206 LogSecurity
            try{
          		List<Map> logSecurityList = new ArrayList<Map>();
                List<Map> detail  = (List<Map> )printMap.get("detail");
          		for (Map tmpRecord : detail) {
          			Map logSecurityMap = new HashMap();
          		    // �ҥ�s��
          			logSecurityMap.put("ID", 
          					MapUtils.getString(tmpRecord,"ID", ""));          			
          			// �Ȥ�m�W
          			logSecurityMap.put("CUS_NAME", 
          					MapUtils.getString(tmpRecord,"CUS_NAME", ""));
          			logSecurityList.add(logSecurityMap);
          		}
          		logSecurity(logSecurityList);
          		logSecurityList.clear();
            } catch(Throwable e) {
            	log.warn(e, e);
            } 

            
            //����PDF����
            theEP_B30060.print(printMap, resp);

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPB3_0060_UI_MSG_001"));//�C�L����

            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPB3_0060_UI_MSG_001"));//�C�L����
        }

        return resp;
    }

    /**
     * ����T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {
        try {
            List<Map> endList = VOTool.jsonAryToMaps(req.getParameter("records"));

            Transaction.begin();
            try {
                new EP_B30060().endProc(endList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB3_0060_UI_MSG_002");//����B�z�����A�гq���f�֤H���Ю�

            try {
                resp.addOutputData("rtnList", query(req.getParameter("SUB_CPY_ID"), req.getParameter("END_YM"), req.getParameter("CRT_NO"),
                    req.getParameter("CUS_NO")));
            } catch (Exception e) {
                log.error("����B�z�����A�гq���f�֤H���Ю֡A���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPB3_0060_UI_MSG_003");//����B�z�����A�гq���f�֤H���Ю֡A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0060_UI_MSG_004");//����B�z����
            }
        } catch (Exception e) {
            log.error("����B�z�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0060_UI_MSG_004");//����B�z����
        }

        return resp;
    }

    /**
     * �U��
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {
        try {

            Map reqMap = new HashMap();
            reqMap.put("IS_EXPORT_XLS", "Y");
            reqMap.put("gridJSON", req.getParameter("gridJSON"));
            //�����ɦW  DUE_YYYYMMDD.xls
            reqMap.put("fileName", new StringBuilder(MessageUtil.getMessage("EPB3_0060_UI_MSG_005")).append("_").append(
                DATE.toDate_yyyyMMdd(DATE.getDBDate())));
            List<Map> rtnList = new EP_B30060().queryList(reqMap, req.getParameter("SUB_CPY_ID"), req.getParameter("END_YM"), req.getParameter("CRT_NO"), req
                    .getParameter("CUS_NO"), resp);
            // 20161227 LogSecurity
            try{
          		List<Map> logSecurityList = new ArrayList<Map>();
          		for (Map tmpRecord : rtnList) {
          			Map logSecurityMap = new HashMap();
          			logSecurityMap.put("ID", 
          					MapUtils.getString(tmpRecord,"ID", ""));          			
          			// �Ȥ�m�W
          			logSecurityMap.put("CUS_NAME", 
          					MapUtils.getString(tmpRecord,"CUS_NAME", ""));
          			logSecurityList.add(logSecurityMap);
          		}
          		logSecurity(logSecurityList);
          		logSecurityList.clear();
            } catch(Throwable e) {
            	log.warn(e, e);
            }   
            
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�U������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPB3_0060_UI_MSG_006"));//�U������
        }

        return resp;
    }

    /**
     * �d�߫����ӯ�������ƲM��
     * @param SUB_CPY_ID
     * @param END_YM
     * @param CRT_NO
     * @param CUS_NO
     * @return
     * @throws Exception
     */
    private List<Map> query(String SUB_CPY_ID, String END_YM, String CRT_NO, String CUS_NO) throws Exception {
        return new EP_B30060().queryList(null, SUB_CPY_ID, END_YM, CRT_NO, CUS_NO, null);
    }
}
