package com.cathay.ep.b3.trx;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.b1.module.EP_B10010;
import com.cathay.ep.b1.module.EP_B10100;
import com.cathay.ep.b3.module.EPB3_0010_mod;
import com.cathay.ep.b3.module.EPB3_0040_mod;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.b3.module.EP_B30040;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 * Date    Version Description Author
 * 2013/10/18  1.0 Created ���կ�
 * 
 * UCEPB3_0040_�Ȥ�կ��K���]�w
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �Ȥ�կ��K���]�w
 * �{���W��    EPB3_0040
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 * (2) �d�� �w �ϥΪ̫��U�d�߫��s��A���o�Ȥ�կ��K���]�w�M��C
 * (3) ���� �w �}�ҵ������ѨϥΪ̬d�߫�����ơA�I���a�^�A�����������C
 * (4) �R���϶� �w ���ѨϥΪ̧R���w�]�w���K���կ��϶�
 * (5) �s�W�϶� �w ���ѨϥΪ̷s�W�K���կ��϶�
 * (6) ��J �w �N�w�]�w���K���կ��϶��g�J�ɮ�
 * 
 * </pre>
 * @author �¶��� 
 * @since 2013/12/6  
 */
@SuppressWarnings("unchecked")
public class EPB3_0040 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPB3_0040.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    private boolean isDebug = log.isDebugEnabled();

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            //����
            VOTool.setParamsFromLP_JSON(req);
            String APLY_NO = req.getParameter("APLY_NO");
            resp.addOutputData("USER_ID", user.getEmpID());
            String DB_DATE = DATE.getDBDate();
            resp.addOutputData("MONTH", DB_DATE.split("-")[1]);
            resp.addOutputData("USER_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));//�����q�O
            resp.addOutputData("LINK_FROM", req.getParameter("LINK_FROM"));//�W��ǤJ�e��
            resp.addOutputData("APLY_NO", APLY_NO);//�ץ�s��
            resp.addOutputData("IN_CRT_NO", req.getParameter("IN_CRT_NO"));//�����N��
            resp.addOutputData("IN_CUS_NO", req.getParameter("IN_CUS_NO"));//�Ȥ�Ǹ�
            resp.addOutputData("IN_CHG_ITEM", req.getParameter("IN_CHG_ITEM"));//���ʶ���
            //�W�Ӥ�̫�@��
            resp.addOutputData("LAST_DATE", DATE.getMonthLastDate(DATE.addDate(DB_DATE, 0, -1, 0)));

            if (StringUtils.isNotBlank(APLY_NO)) {
                //�϶�C���
                //�u�կ����v�U�Կ��G 
                resp.addOutputData("ADJ_UNIT_LIST", VOTool.toJSON(FieldOptionList.getName("EP", "ADJ_UNIT")));
                //�u�H�u�վ�v�U�Կ��G
                resp.addOutputData("IS_MAN_ADJ_LIST", VOTool.toJSON(FieldOptionList.getName("EP", "IS_MAN_ADJ_B304")));

                //�϶�D���
                //�u�K�������v�U�Կ��G 
                resp.addOutputData("EXP_KIND_LIST", VOTool.toJSON(FieldOptionList.getName("EP", "EXP_KIND")));
            }

            //�u���ʶ��ءv�U�Կ��G 
            resp.addOutputData("CHG_LIST", FieldOptionList.getName("EP", "CHG_ITEM_B304"));

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (Exception e) {
            log.error("��l����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00029");//��l����
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String rtnMsg = query(reqMap, "Y".equals(req.getParameter("isInit")), MapUtils.getString(reqMap, "CHG_ITEM"));

            StringBuilder sb = new StringBuilder();
            sb.append(MessageUtil.getMessage("MEP00002"));//�d�ߧ���
            if (rtnMsg.length() > 0) {
                STRING.newLine(sb);
                sb.append(rtnMsg);
            }

            MessageUtil.setMsg(msg, sb.toString());

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            //ReturnCode.OK ��l:�d�L��Ƶ������`�A���q�T��
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * ��J
     * @param req
     * @return
     */
    public ResponseContext doInput(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
            String CHG_ITEM = MapUtils.getString(reqMap, "CHG_ITEM");
            String LAST_DATE = req.getParameter("LAST_DATE");

            //�]�w��s�ץ�_�ܧ������T
            DTEPB301 EPB301VO = new DTEPB301();
            EPB301VO.setAPLY_NO(MapUtils.getString(reqMap, "APLY_NO"));
            EPB301VO.setSUB_CPY_ID(MapUtils.getString(reqMap, "SUB_CPY_ID"));
            EPB301VO.setCRT_NO(CRT_NO);

            //�ˮ�1�O�_����������L�|���������ץ� 2 ���ץ�O�_�i����
            boolean isReg = new EPB3_0010_mod().checkDTEPB301CrtNo(EPB301VO, "U");
            if (isReg) {
                throw new ModuleException(MessageUtil.getMessage("EPB3_0040_UI_MSG_003", new String[] { CRT_NO }));//�������|���w���󥼧�s�D��! ���i�ץ����������u{0}�v���
            }

            boolean ADJ_SAME = "Y".equals(MapUtils.getString(reqMap, "ADJ_SAME", ""));
            boolean NORNT_SAME = "Y".equals(MapUtils.getString(reqMap, "NORNT_SAME", ""));

            boolean IS_DLT_ADJ = "Y".equals(MapUtils.getString(reqMap, "IS_DLT_ADJ"));
            boolean IS_DLT_NORNT = "Y".equals(MapUtils.getString(reqMap, "IS_DLT_NORNT"));
            List<Map> rtnCList = VOTool.jsonAryToMaps(req.getParameter("rtnCList"));
            List<Map> rtnDList = VOTool.jsonAryToMaps(req.getParameter("rtnDList"));

            Map paramMap = VOTool.jsonToMap(req.getParameter("paramMap"));
            String BLD_CD = MapUtils.getString(paramMap, "BLD_CD");

            //�ˮָ�ƦX�z��
            new EPB3_0040_mod().checkInput(SUB_CPY_ID, CRT_NO, APLY_NO, rtnDList, rtnCList, ADJ_SAME, NORNT_SAME, user);

            //����s�W�{��
            Transaction.begin();
            try {
                //�g�J�K���կ��ܧ����
                new EP_B30040().insert(SUB_CPY_ID, CRT_NO, CUS_NO, APLY_NO, BLD_CD, rtnDList, rtnCList, CHG_ITEM, ADJ_SAME, NORNT_SAME,
                    IS_DLT_ADJ, IS_DLT_NORNT, Date.valueOf(LAST_DATE), user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            //���d���
            StringBuilder sb = new StringBuilder();
            try {
                reqMap.put("CUS_NO", "");//���d�d�ߩҦ��Ȥ���
                String rtnMsg = query(reqMap, false, CHG_ITEM);
                sb.append(MessageUtil.getMessage("EPB3_0040_UI_MSG_004"));//��J����
                if (rtnMsg.length() > 0) {
                    STRING.newLine(sb);
                    sb.append(rtnMsg);
                }
                MessageUtil.setMsg(msg, sb.toString());
            } catch (Exception e) {
                log.error("��J�����A��ƭ��s�d�ߥ���", e);
                MessageUtil.setMsg(msg, MessageUtil.getMessage("EPB3_0040_UI_MSG_005"));//��J�����A��ƭ��s�d�ߥ���
            }

            MessageUtil.setMsg(msg, sb.toString());

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataDuplicateException dde) {
            log.error("", dde);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_DUP, "EPB3_0040_UI_MSG_006");//��J���ѡA��Ƥw�s�b
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0040_UI_MSG_007");//��J����
            }
        } catch (Exception e) {
            log.error("��J�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0040_UI_MSG_007");//��J����
        }

        return resp;
    }

    /**
     * �d�߫���ܦ�[�կ��϶� /�K���϶�]
     * @param req
     * @return
     */
    public ResponseContext doShow(RequestContext req) {
        try {

            String CHG_ITEM = req.getParameter("CHG_ITEM");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            String CRT_NO = req.getParameter("CRT_NO");
            String CUS_NO = req.getParameter("CUS_NO");
            List<Map> rtnList;
            if ("1".equals(CHG_ITEM)) {//�կ��϶�
                rtnList = new EP_B30040().getAdjRntList(SUB_CPY_ID, CRT_NO, CUS_NO, null, null, null);
            } else {//�K���϶�
                rtnList = new EP_B30040().getNoRntList(SUB_CPY_ID, CRT_NO, CUS_NO, null, null, null);
            }
            resp.addOutputData("rtnList", rtnList);
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �M�Ų��ʸ��
     * @param req
     * @return
     */
    public ResponseContext doReset(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
            String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String CHG_ITEM = MapUtils.getString(reqMap, "CHG_ITEM");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            //���]�Ȧs�ɸ��
            Transaction.begin();
            try {
                new EP_B30040().resetTmp(SUB_CPY_ID, CRT_NO, CUS_NO, APLY_NO, CHG_ITEM);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            //���d���
            StringBuilder sb = new StringBuilder();
            try {
                reqMap.put("CUS_NO", "");//���d�d�ߩҦ��Ȥ���
                String rtnMsg = query(reqMap, false, CHG_ITEM);
                sb.append(MessageUtil.getMessage("EPB3_0040_UI_MSG_014"));//���]����
                if (rtnMsg.length() > 0) {
                    STRING.newLine(sb);
                    sb.append(rtnMsg);
                }
                MessageUtil.setMsg(msg, sb.toString());
            } catch (Exception e) {
                log.error("���]�����A��ƭ��s�d�ߥ���", e);
                MessageUtil.setMsg(msg, MessageUtil.getMessage("EPB3_0040_UI_MSG_015"));//���]�����A��ƭ��s�d�ߥ���
            }

            MessageUtil.setMsg(msg, sb.toString());

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB3_0040_UI_MSG_016");//���]����
            }
        } catch (Exception e) {
            log.error("���]�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB3_0040_UI_MSG_016");//���]����
        }

        return resp;
    }

    /**
     * �d��
     * @param reqMapParam
     * @param isInit
     * @param CHG_ITEM
     * @return
     * @throws ModuleException
     */
    private String query(Map reqMapParam, boolean isInit, String CHG_ITEM) throws ModuleException {

        String SUB_CPY_ID = MapUtils.getString(reqMapParam, "SUB_CPY_ID");
        String APLY_NO = MapUtils.getString(reqMapParam, "APLY_NO");
        String IN_CRT_NO = MapUtils.getString(reqMapParam, "CRT_NO");
        String IN_CUS_NO = MapUtils.getString(reqMapParam, "CUS_NO");//�Ȥ�Ǹ�
        resp.addOutputData("CHG_ITEM_P", CHG_ITEM);

        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);

        boolean APLY_NOIsNotBlank = StringUtils.isNotBlank(APLY_NO);

        // �Y�ץ�s��APLY_NO ����
        if (APLY_NOIsNotBlank) {//�ץ�s������
            reqMap.put("IS_CHK_TEMP", "Y");
            reqMap.put("APLY_NO", APLY_NO);
            //�d�߮ץ����
            Map aplyMap = new EP_B30010().queryMap(APLY_NO);
            String OP_STATUS = MapUtils.getString(aplyMap, "OP_STATUS", ""); //�ץ�@�~�i��
            String INPUT_ID = MapUtils.getString(aplyMap, "INPUT_ID"); //�ץ��J�H��
            String aplyCRT_NO = MapUtils.getString(aplyMap, "CRT_NO"); //�����N��
            if (isInit && StringUtils.isNotBlank(aplyCRT_NO)) {
                IN_CRT_NO = aplyCRT_NO;//�N�����N���]������
            }
            resp.addOutputData("OP_STATUS", OP_STATUS.trim());
            resp.addOutputData("INPUT_ID", INPUT_ID);
            if (!"01".equals(OP_STATUS) || !INPUT_ID.equals(user.getEmpID())) {
                CHG_ITEM = "all";//���d
                resp.addOutputData("CHG_ITEM_P", CHG_ITEM);
            }
        }

        Map tmpMap = new HashMap();
        tmpMap.put("SUB_CPY_ID", SUB_CPY_ID);
        tmpMap.put("CRT_NO", IN_CRT_NO);
        tmpMap.put("CUS_NO", IN_CUS_NO);
        String LastMonandDate = DATE.getLastMonthLastDate();
        //String tmpYYYYMM = DATE.getYearAndMonth(LastMonandDate);
        try {
            List<Map> listB107 = new EP_B10100().queryList(tmpMap);
            int Max_REV_YYMM = 0;
            for (Map B107Map : listB107) {
                String REV_YYMM = MapUtils.getString(B107Map, "REV_YYMM");
                if (StringUtils.isBlank(REV_YYMM) || "191100".equals(REV_YYMM)) {
                    REV_YYMM = "191101";//�Y�S�{�C�LIFRS ����A���@�̤p���
                }
                int tmp_REV_YYMM = Integer.valueOf(REV_YYMM);
                if (tmp_REV_YYMM > Max_REV_YYMM) {
                    Max_REV_YYMM = tmp_REV_YYMM;
                }
            }
            resp.addOutputData("LAST_DATE", DATE.getMonthLastDate(String.valueOf(Max_REV_YYMM)));
            if (isDebug) {
                log.debug("@@@LAST_DATE=" + DATE.getMonthLastDate(String.valueOf(Max_REV_YYMM)));
            }
        } catch (DataNotFoundException e) {//�d�L��� �LIFRS��� ���@�̤p���
            resp.addOutputData("LAST_DATE", "1911-01-01");
            log.error("�d�L���@@@LAST_DATE=1911-01-01");
        }
        resp.addOutputData("QRY_CRT_NO", IN_CRT_NO);
        String OK_MSG = "";

        //�Y�����N��IN_CRT_NO���� 
        if (StringUtils.isNotBlank(IN_CRT_NO)) {
            reqMap.put("CRT_NO", IN_CRT_NO);
            reqMap.put("CUS_NO", IN_CUS_NO);

            //�������
            Map rtnBMap;
            try {
                rtnBMap = new EP_B10010().queryMap(reqMap);
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L�������", dnfe);
                rtnBMap = null;
            }
            if (rtnBMap == null || rtnBMap.isEmpty()) {
                throw new ModuleException(MessageUtil.getMessage("EPB3_0040_UI_MSG_001"));//�d�L�������
            }
            resp.addOutputData("rtnBMap", rtnBMap);
            resp.addOutputData("BLD_CD", MapUtils.getString(rtnBMap, "BLD_CD"));

            //�ӯ�����
            List<Map> rtnEList;
            EP_B30040 theEP_B30040 = new EP_B30040();
            if (APLY_NOIsNotBlank) {//�ץ�s������
                try {
                    rtnEList = theEP_B30040.queryCUSList(reqMap);
                } catch (DataNotFoundException dnfe) {
                    log.error("�d�L�ӯ�����", dnfe);
                    rtnEList = null;
                }

                if (rtnEList == null || rtnEList.isEmpty()) {
                    throw new ModuleException(MessageUtil.getMessage("EPB3_0040_UI_MSG_013"));//�d�L�ӯ�����

                }

                resp.addOutputData("rtnEList", rtnEList);
            }

            boolean IS_TMP_ADJ = false;
            boolean ADJ_HAS = false;//�կ���ƬO�_�����
            boolean IS_TMP_NORNT = false;
            boolean NORNT_HAS = false;//�K����ƬO�_�����

            //�կ����
            List<Map> rtnCList = null;
            if ("1".equals(CHG_ITEM) || "all".equals(CHG_ITEM)) {
                try {

                    rtnCList = theEP_B30040.getAdjRntList(SUB_CPY_ID, IN_CRT_NO, IN_CUS_NO, APLY_NO, null, "Y");
                    resp.addOutputData("rtnCList", rtnCList);

                    if (!(rtnCList == null || rtnCList.isEmpty())) {
                        IS_TMP_ADJ = "DTEPB305".equals(MapUtils.getString(rtnCList.get(0), "TB"));
                        ADJ_HAS = true;
                    } else {
                        throw new DataNotFoundException();
                    }

                } catch (DataNotFoundException dnfe) {
                    log.error("�d�L�կ����", dnfe);
                }
            }
            //�K�����
            List<Map> rtnDList = null;
            if ("2".equals(CHG_ITEM) || "all".equals(CHG_ITEM)) {
                try {
                    rtnDList = theEP_B30040.getNoRntList(SUB_CPY_ID, IN_CRT_NO, IN_CUS_NO, APLY_NO, null, "Y");
                    resp.addOutputData("rtnDList", rtnDList);

                    if (!(rtnDList == null || rtnDList.isEmpty())) {
                        IS_TMP_NORNT = "DTEPB304".equals(MapUtils.getString(rtnDList.get(0), "TB"));
                        NORNT_HAS = true;
                    } else {
                        throw new DataNotFoundException();
                    }
                } catch (DataNotFoundException dnfe) {
                    log.error("�d�L�K�����", dnfe);
                }
            }

            //  �O�_IFRS��������
            resp.addOutputData("IS_IFRS", new EP_B10100().chkCrtIsIFRS(SUB_CPY_ID, IN_CRT_NO, StringUtils.isNotBlank(IN_CUS_NO) ? Integer
                    .valueOf(IN_CUS_NO) : null) ? "Y" : "N");

            StringBuilder okMsg = new StringBuilder();

            List<Map> rtnFList = new ArrayList();
            if (ADJ_HAS) {

                if (IS_TMP_ADJ) {
                    okMsg.append(MessageUtil.getMessage("EPB3_0040_UI_MSG_008"));//�կ����Өӷ�: �����ܧ��ơC
                } else {
                    okMsg.append(MessageUtil.getMessage("EPB3_0040_UI_MSG_009"));//�կ����Өӷ�: �D�ɸ�ơC
                }

                //���o�ȧR����Ȥ���: rtnFList
                getRtnFList(rtnCList, rtnFList);
            }

            if (NORNT_HAS) {
                if (okMsg.length() > 0) {
                    STRING.newLine(okMsg);
                }
                if (IS_TMP_NORNT) {
                    okMsg.append(MessageUtil.getMessage("EPB3_0040_UI_MSG_010"));//�K�����Өӷ�: �����ܧ��ơC
                } else {
                    okMsg.append(MessageUtil.getMessage("EPB3_0040_UI_MSG_011"));//�K�����Өӷ�: �D�ɸ�ơC
                }

                //���o�ȧR����Ȥ���: rtnFList
                getRtnFList(rtnDList, rtnFList);

            }

            resp.addOutputData("rtnFList", rtnFList);

            if (APLY_NOIsNotBlank) {
                OK_MSG = okMsg.toString();
            }

        }

        return OK_MSG;

    }

    /**
     * ���o�ȧR����Ȥ���
     * @param qryList
     * @param rtnFList
     */
    private void getRtnFList(List<Map> qryList, List<Map> rtnFList) {

        boolean hasChg = false;
        boolean isOnlyDlt = true;
        //�ȧR����Ȥ���: rtnFList
        Map cusMap = new HashMap();
        for (Map rtnMap : qryList) {
            String cusNo = MapUtils.getString(rtnMap, "CUS_NO");
            if (!cusMap.isEmpty() && !cusMap.containsKey(cusNo)) {
                if (hasChg && isOnlyDlt) {
                    rtnFList.add((Map) cusMap.get("rtnMap"));
                }
                cusMap.clear();
            }

            if (cusMap.isEmpty()) {
                hasChg = false;
                isOnlyDlt = true;
                cusMap.put(cusNo, cusNo);
                cusMap.put("rtnMap", rtnMap);
            }
            String DATA_TYPE = MapUtils.getString(rtnMap, "DATA_TYPE");
            if ("I".equals(DATA_TYPE) || "D".equals(DATA_TYPE)) {
                hasChg = true;
                if ("I".equals(DATA_TYPE)) {
                    isOnlyDlt = false;
                }
            }

        }
        if (!cusMap.isEmpty()) {
            if (hasChg && isOnlyDlt) {
                rtnFList.add((Map) cusMap.get("rtnMap"));
            }
            cusMap.clear();
        }
    }
}
