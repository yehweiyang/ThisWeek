package com.cathay.ep.h3.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.z0.module.EP_Z0H120;
import com.cathay.ep.z0.module.EP_Z0H121;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.common.util.annotation.CallMethod;
import com.igsapp.common.util.annotation.TxBean;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Version Description Author
 * 2020/05/04   1.0     Created ������
 * 
 * UCEPH3_1000_�w�s��ޱ���
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �w�s��ޱ���
 * �{���W��    EPH3_1000
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 *              (2) �d�� �w ���ѨϥΪ̬d�߯���믲���ֹ��ơC
 *              (3) �U�� �w ���ѨϥΪ̤U���d�ߵ��G�C
 *              (4) �s�W �V �NB�Ϫ���Ʀs�J���ʲ��w�s��
 *              (4) �T�{ �V 
 *              (4) ��� �V 
 *              (4) �ק� �V 
 * ���s���v    ���M��
 * �����q���
 * �榡���js  �M��
 * �h��y�t    �M��
 * �h���d��     �L         v������          �u����
 * </pre>                                     
 * @author ���f��
 * @since 2020-05-04
 */
@TxBean
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPH3_1000 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPH3_1000.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    private EP_Z0H120 theEP_Z0H120 = new EP_Z0H120();

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode(CallMethod.CODE_SUCCESS);
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    @CallMethod(action = "prompt", url = "/EP/H3/EPH3_1000/EPH31000.jsp")
    public ResponseContext doPrompt(RequestContext req) {
        try {
            resp.addOutputData("SP_CD_LIST", FieldOptionList.getName("EP", "SP_CD"));
        } catch (Exception e) {
            log.error("���o�@�~�D�饢��", e);
            MessageUtil.setErrorMsg(msg, "EPH3_1000_MSG_001");//���o�@�~�D�饢��
        }
        try {
            resp.addOutputData("ORG_ID_LIST", FieldOptionList.getName("EP", "ORG_ID"));
        } catch (Exception e) {
            log.error("���o�����H����", e);
            MessageUtil.setErrorMsg(msg, "EPH3_1000_MSG_002");//���o�����H����
        }
        try {
            resp.addOutputData("CRC_LIST", FieldOptionList.getName("EP", "CRC"));
        } catch (Exception e) {
            log.error("���o���O����", e);
            MessageUtil.setErrorMsg(msg, "EPH3_1000_MSG_003");//���o���O����
        }
        try {
            resp.addOutputData("INT_STS_LIST", FieldOptionList.getName("EP", "INT_STS"));
        } catch (Exception e) {
            log.error("���o�w�s�檬�A����", e);
            MessageUtil.setErrorMsg(msg, "EPH3_1000_MSG_004");//���o�w�s�檬�A����
        }
        try {
            resp.addOutputData("FD_QRY_TYPE_LIST", FieldOptionList.getName("EP", "FD_QRY_TYPE"));
        } catch (Exception e) {
            log.error("���o�w�s�d�ߤ����������", e);
            MessageUtil.setErrorMsg(msg, "EPH3_1000_MSG_005");//���o�w�s�d�ߤ����������
        }
        try {
            resp.addOutputData("INV_TERM_UNIT_LIST", FieldOptionList.getName("EP", "INV_TERM_UNIT"));
        } catch (Exception e) {
            log.error("���o�w�s�ӧ@������쥢��", e);
            MessageUtil.setErrorMsg(msg, "EPH3_1000_MSG_006");//���o�w�s�ӧ@������쥢��
        }
        try {
            resp.addOutputData("INT_PAY_KD_LIST", FieldOptionList.getName("EP", "INT_PAY_KD"));
        } catch (Exception e) {
            log.error("���o�Q���J�b�覡����", e);
            MessageUtil.setErrorMsg(msg, "EPH3_1000_MSG_007");//���o�Q���J�b�覡����
        }
        try {
            resp.addOutputData("EXP_TRD_KD_LIST", FieldOptionList.getName("EP", "EXP_TRD_KD"));
        } catch (Exception e) {
            log.error("���o��������������", e);
            MessageUtil.setErrorMsg(msg, "EPH3_1000_MSG_008");//���o��������������
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    @CallMethod(action = "query", type = CallMethod.TYPE_AJAX)
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> rtnList = theEP_Z0H120.queryList(reqMap, resp);
            resp.addOutputData("rtnList", rtnList);

            //�P�_�O�_���d
            if (!"Y".equals(req.getParameter("reQuery"))) {
                MessageUtil.setMsg(msg, "EPH3_1000_MSG_009");//�d�ߧ���
            }
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_011");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_010");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH3_1000_MSG_010");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �ھڦ����s���d��
     * @param req
     * @return
     */
    @CallMethod(action = "queryByTrdNo", type = CallMethod.TYPE_AJAX)
    public ResponseContext doQueryByTRD_NO(RequestContext req) {

        try {
            String TRD_NO = req.getParameter("TRD_NO");
            Map rtnMap = theEP_Z0H120.queryByTrdNo(TRD_NO);

            resp.addOutputData("rtnMap", rtnMap);

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_011");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_010");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH3_1000_MSG_010");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    @CallMethod(action = "insert", type = CallMethod.TYPE_AJAX)
    public ResponseContext doInsert(RequestContext req) {
        try {
            Map reqMapB = VOTool.jsonToMap(req.getParameter("reqMapB"));
            theEP_Z0H120.insert(reqMapB, user);
            reqMapB.put("INT_STS_NM", FieldOptionList.getName("EP", "INT_STS", MapUtils.getString(reqMapB, "INT_STS")));
            resp.addOutputData("TRD_NO", reqMapB.get("TRD_NO"));
            resp.addOutputData("rtnMap", reqMapB);
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPH3_1000_MSG_012");//�s�W���\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_013");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH3_1000_MSG_013");//�s�W����
        }
        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    @CallMethod(action = "update", type = CallMethod.TYPE_AJAX)
    public ResponseContext doUpdate(RequestContext req) {

        try {
            Map reqMapB = VOTool.jsonToMap(req.getParameter("reqMapB"));

            Map h120Map = theEP_Z0H120.queryByTrdNo(MapUtils.getString(reqMapB, "TRD_NO"));
            if (!"0".equals(MapUtils.getString(h120Map, "INT_STS"))) {
                throw new ModuleException(MessageUtil.getMessage("EP_Z0H120_MSG_004"));//�w�s�檬�A�D�ݽT�{�A���i����T�{�@�~
            }

            theEP_Z0H120.update(reqMapB, user);
            reqMapB.put("INT_STS_NM", FieldOptionList.getName("EP", "INT_STS", MapUtils.getString(reqMapB, "INT_STS")));
            resp.addOutputData("TRD_NO", reqMapB.get("TRD_NO"));
            resp.addOutputData("rtnMap", reqMapB);

            //���d
            try {
                List<Map> rtnList = new EP_Z0H120().queryList(reqMapB, resp);
                resp.addOutputData("rtnList", rtnList);
            } catch (Exception e) {
                log.error("�ק令�\�A�����d����", e);
                MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH3_1000_MSG_014");//�ק令�\�A�����d����
            }
            MessageUtil.setMsg(msg, "EPH3_1000_MSG_015");//�ק粒��

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_016");//�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH3_1000_MSG_016");//�ק異��
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    @CallMethod(action = "delete", type = CallMethod.TYPE_AJAX)
    public ResponseContext doDelete(RequestContext req) {

        try {
            String TRD_NO = req.getParameter("TRD_NO");
            theEP_Z0H120.delete(TRD_NO);
            MessageUtil.setMsg(msg, "EPH3_1000_MSG_017");//�R������

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_018");//�R������
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH3_1000_MSG_018");//�R������
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    @CallMethod(action = "confirm", type = CallMethod.TYPE_AJAX)
    public ResponseContext doConfirm(RequestContext req) {
        try {
            Map reqMapB = VOTool.jsonToMap(req.getParameter("reqMapB"));

            Map h120Map = theEP_Z0H120.queryByTrdNo(MapUtils.getString(reqMapB, "TRD_NO"));
            if (!"0".equals(MapUtils.getString(h120Map, "INT_STS"))) {
                throw new ModuleException(MessageUtil.getMessage("EP_Z0H120_MSG_023"));//�w�s�檬�A�D�ݽT�{�A���i����T�{�@�~
            }

            theEP_Z0H120.confirm(reqMapB, user);
            resp.addOutputData("EST_INT_AMT", reqMapB.get("EST_INT_AMT_1"));
            reqMapB.put("INT_STS_NM", FieldOptionList.getName("EP", "INT_STS", MapUtils.getString(reqMapB, "INT_STS")));
            resp.addOutputData("TRD_NO", reqMapB.get("TRD_NO"));
            resp.addOutputData("rtnMap", reqMapB);
            //���d
            try {
                List<Map> rtnList = new EP_Z0H120().queryList(reqMapB, resp);
                resp.addOutputData("rtnList", rtnList);
            } catch (Exception e) {
                log.error("�T�{���\�A�����d����", e);
                MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH3_1000_MSG_019");//�T�{���\�A�����d����
            }
            MessageUtil.setMsg(msg, "EPH3_1000_MSG_020");//�T�{����

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�T�{����", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_021" + me.getMessage());//�T�{����

            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH3_1000_MSG_021" + e.getMessage());//�T�{����
        }

        return resp;
    }

    /**
     * ���
     * @param req
     * @return
     */
    @CallMethod(action = "expire", type = CallMethod.TYPE_AJAX)
    public ResponseContext doExpire(RequestContext req) {
        try {

            String TRD_NO = req.getParameter("TRD_NO");
            Map reqMapC = VOTool.jsonToMap(req.getParameter("reqMapC"));
            reqMapC.put("INV_TERM_VALUE", reqMapC.get("INV_TERM_VALUE_C"));
            reqMapC.put("INV_TERM_UNIT", reqMapC.get("INV_TERM_UNIT_C"));
            Map h120Map = theEP_Z0H120.queryByTrdNo(TRD_NO);
            if (!"1".equals(MapUtils.getString(h120Map, "INT_STS"))) {
                throw new ModuleException("EPH3_1000_MSG_026");//�w�s�檬�A������A���i�������@�~
            }
            //�i���J�b���B�w�]�����t�����F�i�����P��t�s�s��A�Ҧ���쳣�i�H�ק�(����ȤW���i��|�o�ͩw�s�渹�S����s������)�C
            if ("4".equals(MapUtils.getString(reqMapC, "EXP_TRD_KD"))) {
                String extTrdNo = theEP_Z0H120.extendDeposit(h120Map, reqMapC, user);
                //�̭������T�B�̷� reqMapC ��T�A�s�W�@��DTEPH121
                reqMapC.put("EXT_TRD_NO", extTrdNo);
                reqMapC.put("TRD_NO", TRD_NO);
            } else {
                reqMapC.put("EXT_TRD_NO", null);
            }

            //�s�W�w�s��������
            new EP_Z0H121().insertExpRecord(TRD_NO, reqMapC, user);
            //��s�w�s�������A
            theEP_Z0H120.expire(TRD_NO, reqMapC, user);
            reqMapC.put("INT_STS_NM", FieldOptionList.getName("EP", "INT_STS", "2"));
            h120Map = theEP_Z0H120.queryByTrdNo(TRD_NO);
            resp.addOutputData("rtnMap", h120Map);
            MessageUtil.setMsg(msg, "EPH3_1000_MSG_022");//�������

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_023");//�������

            }
        } catch (Exception e) {
            log.error("�������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH3_1000_MSG_023");//�������
        }

        return resp;
    }

    /**
     * �U��
     * @param req
     * @return
     */
    @CallMethod(action = "export", type = CallMethod.TYPE_AJAX)
    public ResponseContext doExport(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> rtnList = theEP_Z0H120.queryList(reqMap, resp);

            String gridJSON = MapUtils.getString(reqMap, "gridJSON");
            String SP_CD = MapUtils.getString(reqMap, "SP_CD");
            String INT_STS = MapUtils.getString(reqMap, "INT_STS");

            StringBuilder fileName = new StringBuilder();
            fileName.append(FieldOptionList.getName("EP", "SP_CD", SP_CD));
            fileName.append("_�w�s�����_");
            fileName.append(FieldOptionList.getName("EP", "INT_STS", INT_STS));
            fileName.append(".xls");

            Map<String, Object> dataTotalMap = new HashMap<String, Object>();
            dataTotalMap.put("totalTitle", "�X�p");
            dataTotalMap.put("totalColumns", new String[] { "TRD_AMT", "EST_EXP_AMT", "EXP_ACC_AMT" });

            XlsUtils xlsUtils = new XlsUtils(fileName.toString(), rtnList, resp);
            xlsUtils.initExportSetting(gridJSON, dataTotalMap);
            xlsUtils.execute(new XlsUtils.ListProcessHandler() {
            });

            MessageUtil.setMsg(msg, "EPH3_1000_MSG_024");//�U������
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_011");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH3_1000_MSG_025");//�U������
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH3_1000_MSG_025");//�U������
        }

        return resp;
    }

    /**
     * ���o���s�b�����s��
     * @param req
     * @return
     */
    @CallMethod(action = "accountList", type = CallMethod.TYPE_AJAX)
    public ResponseContext doAccountList(RequestContext req) {
        String SP_CD = req.getParameter("SP_CD");
        Map<String, String> map = FieldOptionList.getName("EP", "ACC_NO_" + SP_CD);
        List<Map> acc_list = new ArrayList();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            Map map1 = new HashMap();
            map1.put("key", entry.getKey());
            map1.put("value", entry.getValue());
            acc_list.add(map1);
        }
        resp.addOutputData("ACC_NO", acc_list);
        return resp;
    }

}
