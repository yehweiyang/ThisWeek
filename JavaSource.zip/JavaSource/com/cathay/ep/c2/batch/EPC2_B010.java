package com.cathay.ep.c2.batch;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.ep.c2.module.EP_C21010;
import com.cathay.ep.c2.module.EP_C21020;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.util.ReturnCode;
import com.cathay.util.streamserve.TextFormatter;
import com.cathay.util.streamserve.TextSourceApp;
import com.cathay.zz.x0.module.ZZ_X0Z004;
import com.cathay.zz.x0.module.ZZ_X0Z007;

/**
 * <pre>
 * �{���\��    AFP�������ͧ妸
 * �{���W��   EPC2_B010.java
 * </pre>
 * @author ��s�a
 * @since 2014/7/29
 */
@SuppressWarnings("unchecked")
public class EPC2_B010 extends EP_BatchBean {

    /** log */
    private static final Logger log = Logger.getLogger(EPC2_B010.class);

    /**  �@�~�W�� */
    private static final String JOB_NAME = "EPC2_B010";

    /** �{���W�� */
    private static final String PROGRAM = "EPC2_B010";

    /** �~�ȧO */
    private static final String BUSINESS = "EP";

    /** ���t�ΦW�� */
    private static final String SUBSYSTEM = "C1";

    /** ����g�� */
    private static final String PERIOD = "��";

    /** �]�� true �Ѥ����O�p�Ƥμg���~�T��, false �Шϥ� ErrorLog ��CountManager �ۦ�g���~�T���έp�� */
    private static final boolean isAUTO_WRITELOG = false;

    public EPC2_B010() throws Exception {

        //�]�w�����O���غc�l,�ǤJ true �Ѥ����O�p�Ƥμg���~�T��
        super(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isAUTO_WRITELOG);

    }

    public void execute(String args[]) throws Exception { //����妸�@�~      

        ZZ_X0Z004 theZZ_X0Z004 = null;

        try {
            String FROM_PROGRAM;
            String FIELD1;
            String FIELD2;
            String FIELD3;
            String SUB_CPY_ID;
            String ID;
            String IP;

            if (args != null && args.length == 7) {

                FROM_PROGRAM = args[0];
                FIELD1 = args[1];
                FIELD2 = args[2];
                FIELD3 = args[3];
                SUB_CPY_ID = args[4];
                ID = args[5];
                IP = args[6];

            } else {
                String[] ZZ_X0Z007args = new ZZ_X0Z007(PROGRAM).retrieveParam(null, 7);

                if (ZZ_X0Z007args == null || ZZ_X0Z007args.length != 7) {
                    setExitCode(ERROR);
                    log.fatal("�ǤJ�ѼƦ��~");
                    return;
                }
                FROM_PROGRAM = ZZ_X0Z007args[0];
                FIELD1 = ZZ_X0Z007args[1];
                FIELD2 = ZZ_X0Z007args[2];
                FIELD3 = ZZ_X0Z007args[3];
                SUB_CPY_ID = ZZ_X0Z007args[4];
                ID = ZZ_X0Z007args[5];
                IP = ZZ_X0Z007args[6];
            }

            log.fatal("FROM_PROGRAM:" + FROM_PROGRAM);
            log.fatal("FIELD1:" + FIELD1);
            log.fatal("FIELD2:" + FIELD2);
            log.fatal("FIELD3:" + FIELD3);
            log.fatal("SUB_CPY_ID:" + SUB_CPY_ID);
            log.fatal("ID:" + ID);
            log.fatal("IP:" + IP);

            //�z�L�u�W�妸����Ҳհ���
            theZZ_X0Z004 = new ZZ_X0Z004(PROGRAM, ID);
            ReturnMessage rm = new ReturnMessage();

            //�ŧi�妸�}�l
            theZZ_X0Z004.startBatch(rm);

            if (rm.getReturnCode() != ReturnCode.OK) {
                String errorMsg = "�s�W�妸�ʱ��ɵo�Ϳ��~";
                setExitCode(ERROR);
                log.error(errorMsg);
                throw new ModuleException(errorMsg);
            }

            List<Map> prtList;
            if ("EPC2_1010".equals(FROM_PROGRAM)) {
                //17.11.22:�]�վ�q�l�o���C�L,���妸�w�L�ϥ�,�i�U�[ TODO
                prtList = new EP_C21010().query(FIELD1, null, null, null, null, SUB_CPY_ID);
            } else {
                prtList = new EP_C21020().query(FIELD1, FIELD2, null, SUB_CPY_ID);
            }

            StringBuilder sbf = new StringBuilder();

            String PDF_FILENAME = TextSourceApp.getPDF_FILENAME("EPC2_B010", TextSourceApp.AFP_EXT_TYPE);

            fmtHeader(ID, IP, PDF_FILENAME, sbf);
            fmtItem(prtList, sbf);

            if (sbf.length() > 0) {

                Properties prop = new Properties();
                prop.setProperty(TextSourceApp.PROP_STREAMSERVE_FILE_NAME, PDF_FILENAME); //�]�w�ɦW

                TextSourceApp outputterApp = new TextSourceApp(prop);
                outputterApp.transferBatchReport(sbf.toString(), "AFP01");
            }

        } catch (Exception e) {
            log.fatal("����ɵo�Ϳ��~", e);
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�

        } finally {

            //�z�L�u�W�妸����Ҳհ���
            ReturnMessage rm = new ReturnMessage();

            //�ŧi�妸����
            if (theZZ_X0Z004 != null) {
                theZZ_X0Z004.endBatch(rm);
            }

            printExitCode(getExitCode()); //�^�ǵ� Control_M ���T���N�X , �{���פ�
        }
    }

    /**
     * �����ɮ׸�T
     * @param UserID
     * @param IP
     * @param PDF_FILENAME
     * @param sbf
     * @throws Exception
     */
    private void fmtHeader(String UserID, String IP, String PDF_FILENAME, StringBuilder sbf) throws Exception {

        Map pm = new HashMap();

        pm.put("EPC2B010_id", "EPC2_B010");
        pm.put("EPC2B010_ip", IP);
        pm.put("EPC2B010_pdf_FILENAME", PDF_FILENAME); // PDF �ɦW
        pm.put("EPC2B010_user_id", UserID);

        TextFormatter.JasperToStreamSrv.transform("EPC2_B010_HEADER", pm);//�Ƨ�
        sbf.append(TextFormatter.format(pm));//�զ�header�r��
    }

    /**
     * ���ͤ��e��T
     * @param dataList
     * @param sbf
     * @throws Exception
     */
    private void fmtItem(List<Map> dataList, StringBuilder sbf) throws Exception {

        StringBuilder sb = new StringBuilder();

        //�]�w����϶�
        String[] MONTH_RANGEs = { "1-2", "3-4", "5-6", "7-8", "9-10", "11-12" };
        int THIS_DAY = 0;//�Ѽ�
        int THIS_MONTH = 0;//������
        int THIS_YEAR = 0;//����~        

        DecimalFormat df = new DecimalFormat("#,##0");

        Map<String, String> itemMap = new HashMap<String, String>();

        String oldkey = null;

        int i = 1;

        for (Map dataMap : dataList) {
            String INV_DATE = MapUtils.getString(dataMap, "INV_DATE", "");//�}�ߤ��

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(Date.valueOf(INV_DATE));
            THIS_DAY = calendar.get(Calendar.DATE);//�Ѽ�
            THIS_MONTH = calendar.get(Calendar.MONTH) + 1;//������
            THIS_YEAR = calendar.get(Calendar.YEAR) - 1911;//����~
            sb.append("���إ���").append(THIS_YEAR).append("�~");

            if (THIS_MONTH % 2 == 0) {
                sb.append(MONTH_RANGEs[(THIS_MONTH / 2) - 1]);
            } else {
                sb.append(MONTH_RANGEs[THIS_MONTH / 2]);
            }
            String MONTH_RANGE = sb.append("���").toString();
            sb.setLength(0);

            String PAY_KIND = MapUtils.getString(dataMap, "PAY_KIND");
            String PIN_NAME = MapUtils.getString(dataMap, "PIN_NAME", "");
            String INV_NO = MapUtils.getString(dataMap, "INV_NO", "");
            String PAY_KIND_NM = FieldOptionList.getName("EPC", "PAY_KIND_FOUR", PAY_KIND);
            String PAY_S_DATE_ROC = DATE.toROCDate(MapUtils.getString(dataMap, "PAY_S_DATE", "1913-01-01"));
            String PAY_E_DATE_ROC = DATE.toROCDate(MapUtils.getString(dataMap, "PAY_E_DATE", "1913-01-01"));
            String FLD_NO = MapUtils.getString(dataMap, "FLD_NO", "");
            String ROOM_NO = MapUtils.getString(dataMap, "ROOM_NO", "");
            String PRK_NO = MapUtils.getString(dataMap, "PRK_NO", "");
            String DCT_TYPE = MapUtils.getString(dataMap, "DCT_TYPE", "");//���ڤ覡  1:�H�Υd  2:���~
            String CARD_NO = MapUtils.getString(dataMap, "CARD_NO", "");
            String CRT_NO = MapUtils.getString(dataMap, "CRT_NO", "");
            String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID", "");
            String TAX_TYPE = MapUtils.getString(dataMap, "TAX_TYPE", "");
            String TAX_FREE_CD = MapUtils.getString(dataMap, "TAX_FREE_CD", "");
            String JOB_TYPE = MapUtils.getString(dataMap, "JOB_TYPE", "");

            String key = SUB_CPY_ID + INV_NO;

            String START_ON_NEW_PAGE;

            if (oldkey != null && !StringUtils.equals(oldkey, key)) {
                START_ON_NEW_PAGE = "Y";
            } else {
                START_ON_NEW_PAGE = "N";
            }

            //�]�w�~�W
            if (!"6".equals(PAY_KIND)) {
                sb.append("�X��").append(MapUtils.getString(dataMap, "BLD_NAME", ""));
            } else {
                sb.append(PIN_NAME.length() >= 6 ? PIN_NAME.substring(0, 6) : PIN_NAME.substring(0, PIN_NAME.length()));
            }

            String INV_NAME_1 = sb.toString();
            sb.setLength(0);

            if ("6".equals(PAY_KIND)) {
                if (PIN_NAME.length() >= 6) {
                    sb.append(PIN_NAME.substring(6, PIN_NAME.length()));
                }
            } else if ("7".equals(PAY_KIND)) {
                sb.append(PAY_KIND_NM);
            } else {
                sb.append(PAY_S_DATE_ROC).append(" - ").append(PAY_E_DATE_ROC).append("  ").append(PAY_KIND_NM);
            }

            String INV_NAME_2 = sb.toString();
            sb.setLength(0);

            if (StringUtils.isBlank(FLD_NO)) {
                if (StringUtils.isNotBlank(PRK_NO)) {
                    sb.append(PRK_NO);
                }
            } else {
                sb.append(FLD_NO).append(" ").append(ROOM_NO);
            }

            String INV_NAME_3 = sb.toString();
            sb.setLength(0);

            if (StringUtils.isBlank(INV_NAME_2)) {
                INV_NAME_2 = INV_NAME_3;
                INV_NAME_3 = "";
            }

            if ("1".equals(DCT_TYPE)) {
                sb.append("ñ�b�d���X�G").append(StringUtils.right(CARD_NO, 4));
            }

            if (CRT_NO.startsWith("OZ")) {
                sb.append("ñ�b�d���X�G").append(StringUtils.right(CRT_NO, 4));
            }

            String INV_NAME_4 = sb.toString();
            sb.setLength(0);

            if (StringUtils.isBlank(INV_NAME_3)) {
                INV_NAME_3 = INV_NAME_4;
                INV_NAME_4 = "";
            }

            if ("3".equals(TAX_TYPE)) {
                if (StringUtils.isBlank(CRT_NO)) {
                    //�L�����s�� ���C�L �K�|���Ҹ�
                } else {
                    sb.append("�K�|���Ҹ��G").append(StringUtils.trim(TAX_FREE_CD));
                }
            }
            String INV_NAME_5 = sb.toString();
            sb.setLength(0);

            if (StringUtils.isBlank(INV_NAME_4)) {
                INV_NAME_4 = INV_NAME_5;
                INV_NAME_5 = "";
            }

            boolean isThree = (!"00".equals(JOB_TYPE) || StringUtils.isBlank(JOB_TYPE));

            String ID = StringUtils.trim(MapUtils.getString(dataMap, "ID", ""));
            String UBN;//�Τ@�s��

            if (isThree) {
                if (StringUtils.isNotBlank(ID) && NumberUtils.isNumber(ID) && ID.length() == 8) {
                    UBN = ID;
                } else {
                    UBN = "�@";
                }
            } else {
                UBN = "�@";
            }

            //�]�w�`�p���B(�Ҭ���ƭ�,�G�L����˥h���Ʀ�)
            BigDecimal INV_AMT = ((BigDecimal) MapUtils.getObject(dataMap, "INV_AMT", BigDecimal.ZERO)).setScale(0, BigDecimal.ROUND_DOWN);
            BigDecimal SAL_AMT = ((BigDecimal) MapUtils.getObject(dataMap, "SAL_AMT", BigDecimal.ZERO)).setScale(0, BigDecimal.ROUND_DOWN);
            BigDecimal TAX_AMT = ((BigDecimal) MapUtils.getObject(dataMap, "TAX_AMT", BigDecimal.ZERO)).setScale(0, BigDecimal.ROUND_DOWN);
            BigDecimal TOTAL_AMT = SAL_AMT.add(TAX_AMT).setScale(0, BigDecimal.ROUND_DOWN);//�L����˥h���Ʀ�

            String taxAmt;
            String TAX_TYPE_A = "";
            String TAX_TYPE_B = "";
            String TAX_TYPE_C = "";

            if ("1".equals(TAX_TYPE) || "2".equals(TAX_TYPE)) {
                TAX_TYPE_A = "V";//��~�|-���|
                if ((TAX_AMT.compareTo(new BigDecimal("0")) != 0) && (StringUtils.isNotBlank(ID) && NumberUtils.isNumber(ID))) {
                    taxAmt = df.format(TAX_AMT);
                } else {
                    taxAmt = "";
                }
            } else if ("3".equals(TAX_TYPE)) {
                TAX_TYPE_B = "V";//��~�|-�s�|�v
                taxAmt = "";
            } else if ("4".equals(TAX_TYPE)) {
                TAX_TYPE_C = "V";//��~�|-�K�|
                taxAmt = "";
            } else {
                taxAmt = "";
            }

            String INV_FORMATE;
            String salAmt;

            if (isThree) {
                //N�p�� 
                if (StringUtils.isNotBlank(ID) && NumberUtils.isNumber(ID) && ID.length() == 8) {
                    INV_FORMATE = "�T�p��";
                    salAmt = df.format(SAL_AMT);//�P���B
                } else {
                    INV_FORMATE = "�G�p��";
                    salAmt = df.format(TOTAL_AMT);//�P���B+�|�B
                }
            } else {
                INV_FORMATE = "�G�p��";
                salAmt = df.format(TOTAL_AMT);//�P���B+�|�B
            }

            if (i % 2 != 0) {

                itemMap.put("CHK_NO_1", MapUtils.getString(dataMap, "CHK_NO", ""));//�ˬd���X
                itemMap.put("CRT_NO_1", MapUtils.getString(dataMap, "CRT_NO", ""));//�Ȥ�N�� 
                itemMap.put("CUS_NAME_1", MapUtils.getString(dataMap, "CUS_NAME", "�@"));//�R���H 

                //�]�w�`�p���B��r
                String strTOTAL_AMT = STRING.fillZero(TOTAL_AMT.toPlainString(), 9);
                char[] DIGITs = strTOTAL_AMT.toCharArray();
                int index = 1;
                for (char N : DIGITs) {
                    itemMap.put("DIGIT_1_" + index, STRING.toROCMoneyFormat(String.valueOf(N), "", false));
                    index++;
                }

                itemMap.put("INV_AMT_1", df.format(INV_AMT));//�o�����B
                itemMap.put("INV_FORMATE_1", INV_FORMATE);
                itemMap.put("INV_NAME_1_1", INV_NAME_1);//�~�W 
                itemMap.put("INV_NAME_1_2", INV_NAME_2);//�~�W 
                itemMap.put("INV_NAME_1_3", INV_NAME_3);//�~�W 
                itemMap.put("INV_NAME_1_4", INV_NAME_4);//�~�W
                itemMap.put("INV_NAME_1_5", INV_NAME_5);//�~�W
                itemMap.put("INV_NO_1", INV_NO);//�o�����X 
                itemMap.put("MONTH_RANGE_1", MONTH_RANGE);//����϶�
                itemMap.put("SAL_AMT_1", salAmt);//�P���B
                itemMap.put("SER_NO_1", MapUtils.getString(dataMap, "SER_NO", ""));//�y����
                itemMap.put("START_ON_NEW_PAGE_1", START_ON_NEW_PAGE);//�O�_�}�l�s�@��
                itemMap.put("TAX_AMT_1", taxAmt);//��~�|���B  
                itemMap.put("TAX_TYPE_A_1", TAX_TYPE_A);//��~�|-���|
                itemMap.put("TAX_TYPE_B_1", TAX_TYPE_B);//��~�|-�s�|�v
                itemMap.put("TAX_TYPE_C_1", TAX_TYPE_C);//��~�|-�K�|
                itemMap.put("THIS_DAY_1", String.valueOf(THIS_DAY));//�o���}�ߤ��-��
                itemMap.put("THIS_MONTH_1", String.valueOf(THIS_MONTH));//�o���}�ߤ��-�� 
                itemMap.put("THIS_YEAR_1", String.valueOf(THIS_YEAR));//�o���}�ߤ��-�~ 
                itemMap.put("TOTAL_AMT_1", df.format(TOTAL_AMT));//�P���B+��~�|�X�p
                itemMap.put("UBN_1", UBN);//�Τ@�s��

            } else {

                itemMap.put("CHK_NO_2", MapUtils.getString(dataMap, "CHK_NO", ""));//�ˬd���X
                itemMap.put("CRT_NO_2", MapUtils.getString(dataMap, "CRT_NO", ""));//�Ȥ�N�� 
                itemMap.put("CUS_NAME_2", MapUtils.getString(dataMap, "CUS_NAME", "�@"));//�R���H 

                //�]�w�`�p���B��r
                String strTOTAL_AMT = STRING.fillZero(TOTAL_AMT.toPlainString(), 9);
                char[] DIGITs = strTOTAL_AMT.toCharArray();
                int index = 1;
                for (char N : DIGITs) {
                    itemMap.put("DIGIT_2_" + index, STRING.toROCMoneyFormat(String.valueOf(N), "", false));
                    index++;
                }

                itemMap.put("INV_AMT_2", df.format(INV_AMT));//�o�����B
                itemMap.put("INV_FORMATE_2", INV_FORMATE);
                itemMap.put("INV_NAME_2_1", INV_NAME_1);//�~�W 
                itemMap.put("INV_NAME_2_2", INV_NAME_2);//�~�W 
                itemMap.put("INV_NAME_2_3", INV_NAME_3);//�~�W 
                itemMap.put("INV_NAME_2_4", INV_NAME_4);//�~�W
                itemMap.put("INV_NAME_2_5", INV_NAME_5);//�~�W
                itemMap.put("INV_NO_2", INV_NO);//�o�����X 
                itemMap.put("MONTH_RANGE_2", MONTH_RANGE);//����϶�
                itemMap.put("SAL_AMT_2", salAmt);//�P���B
                itemMap.put("SER_NO_2", MapUtils.getString(dataMap, "SER_NO", ""));//�y����
                itemMap.put("START_ON_NEW_PAGE_2", START_ON_NEW_PAGE);//�O�_�}�l�s�@��
                itemMap.put("TAX_AMT_2", taxAmt);//��~�|���B  
                itemMap.put("TAX_TYPE_A_2", TAX_TYPE_A);//��~�|-���|
                itemMap.put("TAX_TYPE_B_2", TAX_TYPE_B);//��~�|-�s�|�v
                itemMap.put("TAX_TYPE_C_2", TAX_TYPE_C);//��~�|-�K�|
                itemMap.put("THIS_DAY_2", String.valueOf(THIS_DAY));//�o���}�ߤ��-��
                itemMap.put("THIS_MONTH_2", String.valueOf(THIS_MONTH));//�o���}�ߤ��-�� 
                itemMap.put("THIS_YEAR_2", String.valueOf(THIS_YEAR));//�o���}�ߤ��-�~ 
                itemMap.put("TOTAL_AMT_2", df.format(TOTAL_AMT));//�P���B+��~�|�X�p
                itemMap.put("UBN_2", UBN);//�Τ@�s��
            }

            if (i % 2 == 0) {
                TextFormatter.JasperToStreamSrv.transform("EPC2_B010_ITEM", itemMap);
                sbf.append(TextFormatter.format(itemMap));
                itemMap.clear();
            }

            i++;
            oldkey = key;
        }

        if (!itemMap.isEmpty()) {
            itemMap.put("CHK_NO_2", "");//�ˬd���X
            itemMap.put("CRT_NO_2", "");//�Ȥ�N�� 
            itemMap.put("CUS_NAME_2", "");//�R���H 
            for (int j = 1; j < 10; j++) {
                itemMap.put("DIGIT_2_" + j, "");
            }

            itemMap.put("INV_AMT_2", "");//�o�����B
            itemMap.put("INV_FORMATE_2", "");
            itemMap.put("INV_NAME_2_1", "");//�~�W 
            itemMap.put("INV_NAME_2_2", "");//�~�W 
            itemMap.put("INV_NAME_2_3", "");//�~�W 
            itemMap.put("INV_NAME_2_4", "");//�~�W
            itemMap.put("INV_NAME_2_5", "");//�~�W
            itemMap.put("INV_NO_2", "");//�o�����X 
            itemMap.put("MONTH_RANGE_2", "");//����϶�
            itemMap.put("SAL_AMT_2", "");//�P���B
            itemMap.put("SER_NO_2", "");//�y����
            itemMap.put("START_ON_NEW_PAGE_2", "");//�O�_�}�l�s�@��
            itemMap.put("TAX_AMT_2", "");//��~�|���B  
            itemMap.put("TAX_TYPE_A_2", "");//��~�|-���|
            itemMap.put("TAX_TYPE_B_2", "");//��~�|-�s�|�v
            itemMap.put("TAX_TYPE_C_2", "");//��~�|-�K�|
            itemMap.put("THIS_DAY_2", "");//�o���}�ߤ��-��
            itemMap.put("THIS_MONTH_2", "");//�o���}�ߤ��-�� 
            itemMap.put("THIS_YEAR_2", "");//�o���}�ߤ��-�~ 
            itemMap.put("TOTAL_AMT_2", "");//�P���B+��~�|�X�p
            itemMap.put("UBN_2", "");//�Τ@�s��

            TextFormatter.JasperToStreamSrv.transform("EPC2_B010_ITEM", itemMap);
            sbf.append(TextFormatter.format(itemMap));
            itemMap.clear();
        }
    }
}
