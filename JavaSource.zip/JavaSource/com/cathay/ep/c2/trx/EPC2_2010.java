package com.cathay.ep.c2.trx;

import java.io.BufferedReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.dd.b0.module.DD_B0Z018;
import com.cathay.ep.c2.module.EPC2_2010_mod;
import com.cathay.ep.c2.module.EP_C22010;
import com.cathay.ep.vo.DTEPC202;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z1.module.EP_Z10020;
import com.cathay.util.FileStoreUtil;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date     Version Description Author
 * 2013/9/6     1.0 Created     ������
 * 
 * �{���\�� �o�����ӿ�J
 * �{���W��    EPC2_2010.java
 * �@�~�覡    ONLINE
 * ���n����    �\�໡��:
 * 1.  �d�� - �d�ߵo��������
 * 2.  �s�W �V �s�W�o��������
 * 3.  �ק� �V �ק�o��������
 * 4.  �W�� �V �N�r�����j��r�ɷs�W�o��������
 * ���s���v    FUNC_ID = EPC22010
 * 
 * [20180221] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ� 
 * 
 * @author ����[
 * @since 2013-10-11
 */
@SuppressWarnings("unchecked")
public class EPC2_2010 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_2010.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        //���o�����q�O
        String SUB_CPY_ID;
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        } catch (ErrorInputException e) {
            SUB_CPY_ID = "";
            log.error("���o�����q�O����", e);
        }

        //�~�W�N���U�Կ��
        try {
            /* [20180221] �W�[�P�_���I�sEP_Z00030  */
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                resp.addOutputData("PIN_CODE_LIST", new DD_B0Z018().queryDtddb070(""));
            } else {
                //�D��ث~�W�N�����N�X�]�w
                resp.addOutputData("PIN_CODE_LIST", FieldOptionList.getFieldOptions("EP", "PIN_CODE"));
            }

        } catch (ModuleException e) {
            log.error("�~�W�N���U�Կ�沣�ͥ���", e);
        }
        //ú�ں����U�Կ��
        Map PAY_KIND_MAP = new HashMap();
        PAY_KIND_MAP.put("6", FieldOptionList.getName("EP", "PAY_KIND", "6")); //�������J
        resp.addOutputData("PAY_KIND_LIST", PAY_KIND_MAP);

        //�|�O�U�Կ��
        resp.addOutputData("TAX_TYPE_LIST", FieldOptionList.getFieldOptions("EP", "TAX_TYPE"));

        //�Ȥ�m�W�U�Կ��
        try {
            resp.addOutputData("CUS_NAME_LIST", new EP_Z10020().queryList(SUB_CPY_ID, "", ""));
        } catch (ModuleException e) {
            log.error("�Ȥ�m�W�U�Կ�沣�ͥ���", e);
        }

        resp.addOutputData("INV_DATE", DATE.getDBDate());
        resp.addOutputData("SLIP_DATE", DATE.getDBDate());

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));

            resp.addOutputData("rtnList", query(dataMap));

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC2_2010_MEG_001"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    private List<Map> query(Map dataMap) throws ModuleException {
        new EPC2_2010_mod().checkQuery(dataMap);

        String CUS_NAME = MapUtils.getString(dataMap, "CUS_NAME");
        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
        /*
        if (StringUtils.isBlank(CUS_NAME)) {
            return new EP_C22010().queryDTEPC202(MapUtils.getString(dataMap, "RCV_YM"), MapUtils.getString(dataMap, "PIN_CODE"));
        }else{
        	return new EP_C22010().queryDTEPC202_1(CUS_NAME);
        }*/
        List<Map> rtnList;
        if (StringUtils.isNotBlank(CUS_NAME)
                && (StringUtils.isBlank(MapUtils.getString(dataMap, "RCV_YM")) && StringUtils.isBlank(MapUtils.getString(dataMap,
                    "PIN_CODE")))) {
            rtnList = new EP_C22010().queryDTEPC202_1(CUS_NAME, SUB_CPY_ID);
        } else {
            rtnList = new EP_C22010().queryDTEPC202(MapUtils.getString(dataMap, "RCV_YM"), MapUtils.getString(dataMap, "PIN_CODE"),
                SUB_CPY_ID);
        }

        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map rtnMap : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", rtnMap.get("ID"));
            logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);
        }
        logSecurity(logSecurityList);

        return rtnList;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            new EPC2_2010_mod().checkInsert(dataMap);
            dataMap.put("INV_CD", "0");
            dataMap.put("CHG_ID", user.getEmpID());
            dataMap.put("CHG_DIV_NO", user.getOpUnit());
            dataMap.put("CHG_NAME", user.getEmpName());
            dataMap.put("user", user);
            Transaction.begin();
            try {
                DTEPC202 C202VO = new EP_C22010().insertDTEPC202(dataMap);
                resp.addOutputData("C202VO", C202VO);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC2_2010_MEG_006"));//�s�W�o����Ƨ���

            //�M�ūȤ�W�١A�ԯd�����~��+�~�W�N���d��
            dataMap.put("CUS_NAME", "");

            try {
                resp.addOutputData("rtnList", query(dataMap));
            } catch (DataNotFoundException dnfe) {
                log.debug("�s�W����,�d�L���");
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC2_2010_MEG_005"));//�s�W�o����ƥ���
            }
        } catch (Exception e) {
            log.error("�s�W�o����ƥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC2_2010_MEG_005"));//�s�W�o����ƥ���
        }

        return resp;
    }

    /**
     * �ץ�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {
            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            new EPC2_2010_mod().checkUpdate(dataMap);
            dataMap.put("CHG_ID", user.getEmpID());
            dataMap.put("CHG_DIV_NO", user.getOpUnit());
            dataMap.put("CHG_NAME", user.getEmpName());
            Transaction.begin();
            try {
                new EP_C22010().updateDTEPC202(dataMap);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC2_2010_MEG_002"));//�ק�o����Ʀ��\

            try {
                resp.addOutputData("rtnList", query(dataMap));
            } catch (DataNotFoundException dnfe) {
                log.debug("�ק粒��,�d�L���");
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC2_2010_MEG_003"));//�ק�o����ƥ���
            }
        } catch (Exception e) {
            log.error("�ק�o����ƥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC2_2010_MEG_003"));//�ק�o����ƥ���
        }

        return resp;
    }

    /**
     * �W��
     * @param req
     * @return
     */
    public ResponseContext doUpload(RequestContext req) {
        try {
            FileItem IMPORT_FILE = FileStoreUtil.parseUploadStream(req); // �פJ�ɮ�
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");

            List<Map> dataList = pasreTXT_CSV(IMPORT_FILE);
            log.debug("dataList>>>>>>>>>>" + dataList);

            EPC2_2010_mod theEPC2_2010_mod = new EPC2_2010_mod();
            EP_C22010 theEP_C22010 = new EP_C22010();
            Transaction.begin();
            try {
                for (Map dataMap : dataList) {
                    dataMap.put("SUB_CPY_ID", SUB_CPY_ID);
                    log.debug(">>>>>>>>>>>>>�}�l�ˮ֤W�Ǹ��");
                    theEPC2_2010_mod.checkInsert(dataMap);
                    //�p����B
                    Map amtMap = theEP_C22010.calAmt(MapUtils.getString(dataMap, "TAX_TYPE"), new BigDecimal(MapUtils.getString(dataMap,
                        "INV_AMT")), new BigDecimal(MapUtils.getString(dataMap, "SAL_AMT")));

                    dataMap.put("INV_AMT", MapUtils.getString(amtMap, "INV_AMT")); //�o�����B
                    dataMap.put("SAL_AMT", MapUtils.getString(amtMap, "SAL_AMT")); //�P���B
                    dataMap.put("user", user); //userObject

                    //�s�W�ɮ�
                    log.debug(">>>>>>>>>>>>>�}�l�s�W�W�Ǹ��");
                    theEP_C22010.insertDTEPC202(dataMap);
                }
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC2_2010_MEG_004")); //�W�ǵo����ƥ���
            }
        } catch (Exception e) {
            log.error("�W�ǵo����ƥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC2_2010_MEG_004"));//�W�ǵo����ƥ���
        } finally {
            this.send2iframe(req);
        }
        return resp;
    }

    /**
     * �ѪRtxt, csv��(��","���j)
     * @param IMPORT_FILE
     * @return
     * @throws Exception
     */
    private List<Map> pasreTXT_CSV(FileItem IMPORT_FILE) throws Exception {

        String FILE_TYPE = IMPORT_FILE.getName().substring(IMPORT_FILE.getName().lastIndexOf(".") + 1); // �ɮ�����: csv, xls, xlsx
        if (!("csv".equalsIgnoreCase(FILE_TYPE) || "txt".equalsIgnoreCase(FILE_TYPE))) {
            throw new Exception("�ɦW���~");
        }

        BufferedReader br = EncodingHelper.getBufferedReader(IMPORT_FILE.getInputStream()); // �إ߽w�İ�

        List<Map> dataList = new ArrayList<Map>();

        try {
            String line;
            String[] tokens;
            String CHG_ID = user.getEmpID();
            String CHG_DIV_NO = user.getOpUnit();
            String CHG_NAME = user.getEmpName();

            while ((line = br.readLine()) != null) {

                tokens = line.split(","); //��ƪ����j�Ÿ���","
                if (tokens.length == 1) { //�p�G���ťզ�
                    continue;
                } else if (tokens.length != 13) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPC2_2010_MEG_007")); //�ɮ׮榡���~�A���ˬd���ƥجO�_���T
                }

                String TAX_TYPE = tokens[5].trim();
                String INV_AMT = tokens[7].trim();
                String SAL_AMT = tokens[8].trim();
                Map textMap = new HashMap();
                textMap.put("RCV_YM", DATE.getY2KYearAndMonth(tokens[0].trim())); // �����~��
                textMap.put("PIN_CODE", tokens[1].trim()); // �~�W�N��
                textMap.put("PAY_KIND", tokens[2].trim());//ú�ں���
                textMap.put("CUS_NAME", tokens[3].trim()); // �Ȥ�m�W
                textMap.put("ID", tokens[4].trim()); // �ҥ󸹽X
                textMap.put("TAX_TYPE", TAX_TYPE);//�|�O
                textMap.put("PIN_NAME", tokens[6].trim());//�~�W
                textMap.put("INV_AMT", INV_AMT);//�o�����B
                textMap.put("SAL_AMT", SAL_AMT);//�P���B
                textMap.put("SLIP_DATE", DATE.toY2KDate(tokens[9].trim()));//�ǲ����
                textMap.put("INV_DATE", DATE.toY2KDate(tokens[10].trim())); //�}�ߤ��
                textMap.put("SLIP_DIV_NO", tokens[11].trim()); //�s�����
                textMap.put("SLIP_SEQ_NO", tokens[12].trim()); //�ǲ��Ǹ�
                textMap.put("INV_CD", "0"); // �o�����p
                textMap.put("TRN_KIND", "EPC201");//�������
                textMap.put("CHG_ID", CHG_ID);//���ʤH��ID
                textMap.put("CHG_DIV_NO", CHG_DIV_NO);//���ʳ��N��
                textMap.put("CHG_NAME", CHG_NAME);//���ʤH���m�W

                dataList.add(textMap);
            }
        } finally {
            if (br != null) {
                br.close();
            }
        }

        return dataList;
    }

    /**
     * �N����নhtml�榡�^�Ǧܵe���W��iframe
     * @param req
     * @throws Exception
     */
    private void send2iframe(RequestContext req) {
        try {

            //---------- �n�^�Ǫ����(start) ----------
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(IConstantMap.ErrMsg, msg);

            //---------- �n�^�Ǫ����(end) ----------
            EncodingHelper.send2iframe(req, map, msg);

        } catch (Exception e) {
            log.error(e, e);
            msg.setReturnCode(ReturnCode.ERROR);
            msg.setMsgDesc(e.getMessage());
        }
    }

    /**
     * ���o�Ȥ�W��(�s��)
     * @param req
     * @return
     */
    public ResponseContext doGetCUS_NAME(RequestContext req) {
        try {
            String CUS_NAME = "";
            if (StringUtils.isNotBlank(req.getParameter("ID"))) {
                CUS_NAME = MapUtils.getString(new EP_Z10020().queryList(req.getParameter("SUB_CPY_ID"), "", req.getParameter("ID")).get(0),
                    "CUS_NAME");
            }

            resp.addOutputData("CUS_NAME", CUS_NAME);
            //MessageUtil.setMsg(msg, "MI00020" );
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            //MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��");
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00630");
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630");
        }

        return resp;
    }

    /**
     * �p����B(�s��)
     * @param req
     * @return
     */
    public ResponseContext doGetAMT(RequestContext req) {
        try {
            resp.addOutputData("amtMap", new EP_C22010().calAmt(req.getParameter("TAX_TYPE"), getBigDecimal(req.getParameter("INV_AMT")),
                getBigDecimal(req.getParameter("SAL_AMT"))));
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��");
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00630");
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630");
        }

        return resp;
    }

    private BigDecimal getBigDecimal(String val) {
        if (StringUtils.isBlank(val)) {
            return null;
        }
        return new BigDecimal(val);
    }
}
