package com.cathay.ep.c2.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.c2.module.EP_C23120;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Description                                 Author
 * 2013/8/5     Created                                     �\�a�s
 * �@�B  �{���\�෧�n�����G
 * �ҲզW�� ú�O�ҩ��d�ߧ@�~
 * �Ҳ�ID  EPC2_3120
 * ���n���� (1) �d�ߡGú�O��Ƭd��
 *        (2) �C�L�G�C�Lú�O���ӳ���
 *</pre>
 * @author ù�ΫT
 * @since 2014-01-07
 */
@SuppressWarnings("unchecked")
public class EPC2_3120 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_3120.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        StringBuilder sb = new StringBuilder();//�������~�T��

        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user); // �����q�O
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            sb.append(eie.getMessage());
        }

        if (sb.length() > 0) {
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, sb.toString());
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            //�d�ߩ㯲�����Ӹ��
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            BigDecimal RCV_YEAR = getBigDecimal(reqMap.get("RCV_YEAR"), null);
            String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
            String CUS_NAME = MapUtils.getString(reqMap, "CUS_NAME");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            if (RCV_YEAR == null) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_C23120_ERRMSG_001"));
            }
            if (!DATE.isROCDate(RCV_YEAR + "0101", false)) {
                throw new ErrorInputException(MessageUtil.getMessage("EPC2_3120_ERRMSG_CHECK_YEAY_FORMAT"));
            }
            //            if (StringUtils.isBlank(BLD_CD) && StringUtils.isBlank(CUS_NAME)) {
            //                throw new ErrorInputException(MessageUtil.getMessage("EPC2_3120_ERRMSG_CHECK_CUSNAME_OR_BLDCD_REQUIRED"));
            //            }

            List<Map> resultList = query(SUB_CPY_ID, RCV_YEAR, BLD_CD, CUS_NAME);
            resp.addOutputData("rtnList", resultList);
            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * ��@�d��
     * @param RCV_YEAR �~��
     * @param BLD_CD �j�ӥN��
     * @param CUS_NAME �Ȥ�W��
     * @return
     * @throws ModuleException
     */
    private List<Map> query(String SUB_CPY_ID, BigDecimal RCV_YEAR, String BLD_CD, String CUS_NAME) throws ModuleException {

        List<Map> resultList = new EP_C23120().queryList(SUB_CPY_ID, RCV_YEAR, BLD_CD, CUS_NAME);
        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map rtnMap : resultList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);
        }
        logSecurity(logSecurityList);

        return resultList;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> queryList = VOTool.jsonAryToMaps(req.getParameter("queryList"));

            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map rtnMap : queryList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);

            BigDecimal RCV_YEAR = getBigDecimal(reqMap.get("RCV_YEAR"), null);

            EP_C23120 ep_c23120 = new EP_C23120();
            Map rptMap = ep_c23120.doFmtRpt(queryList, RCV_YEAR, user);
            ep_c23120.prtRpt(rptMap, resp);

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC2_3120_ERRMSG_PRINT_SUCCESS"));//�C�L���\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil
                            .getMessage("EPC2_3120_ERRMSG_PRINT_FAILED"));//�C�L����
                }
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC2_3120_ERRMSG_PRINT_FAILED"));//�C�L����
        }

        return resp;
    }

    /**
     * �ഫ����Ƭ�Bigdecimal
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }

        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }

        return defaultValue;
    }

}
