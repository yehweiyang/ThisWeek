package com.cathay.ep.c2.trx;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.hr.WorkDate;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.c0.module.EP_C0Z002;
import com.cathay.ep.c2.module.EPC2_2040_mod;
import com.cathay.ep.c2.module.EP_C22040;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.CsvUtils;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Version Description Author
 * 2013-11-12   1.0     Created ���|��
 * 2018-03-12   2.0     ��ؾɤJ    ����[     
 * 
 * UCEPC2_2040_�o���b�ȳB�z
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �o���b�ȳB�z
 * �{���W��    EPC2_2040
 * �@�~�覡    ONLINE
 * ���n����    ���\�ध�D�n�ت����d�ߵo�����X�öi��o���@�o�@�~�C
 * (1) �d�ߡG��J�o���b�ȸ�ơC
 * (2) �ǲ��T�{�G�b�ȸg��i�ھګݧ@�b���o���T�{���ͱb�Ȥ����C
 * (3) �ǲ������G�b�ȸg��i�N�w�X�b(�|���ഫ�ǲ��ζǲ��w�h��)���o�����ӡA�@�����b�ȽT�{(�R�������b�Ȥ���)
 * [2018-06-22] �ק��
 * �s�W���s �ץX�C���� �M�ץN�� :P201702080001
 *</pre>
 * @author ����[
 * @since 2013-12-09
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC2_2040 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_2040.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        String OpUnit = user.getOpUnit();
        try {
            /*2018-06-22 ��X�Ҳ� ���e�ݥ���s����P�_����DOWNLOAD*/
            EP_Z00030 theEP_Z00030 = new EP_Z00030();
            String SUB_CPY_ID = theEP_Z00030.getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
            //2018-03-13 �վ���W�٧���Ҳ�
            resp.addOutputData("DIV_NAME", new EP_A10010().getDivName(OpUnit, SUB_CPY_ID));
            resp.addOutputData("DOWNLOAD", theEP_Z00030.isAccountSubCpy(SUB_CPY_ID));

        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC2_2040_ERRMSG_001");//���o�����q�O����
        } catch (SQLException e) {
            log.error("��l����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00029");//��l����
        }
        resp.addOutputData("ACC_TYPE", FieldOptionList.getFieldOptions("EP", "ACC_TYPE_C204"));//�@�o����
        resp.addOutputData("ACC_ACTION", FieldOptionList.getFieldOptions("EP", "ACC_ACTION_C204"));//�X�b���A

        //�b�Ⱥ����vACNT_TYPE_List
        resp.addOutputData("ACNT_TYPE_List", FieldOptionList.getFieldOptions("EP", "ACNT_TYPE"));
        resp.addOutputData("OP_UNIT", OpUnit);
        resp.addOutputData("EMP_NAME", user.getEmpName());
        resp.addOutputData("EMP_ID", user.getEmpID());
        //resp.addOutputData("DIV_NAME", user.getOpUnitShortName());

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            //new EPC2_2040_mod().checkSubCpyId(MapUtils.getString(reqMap, "SUB_CPY_ID"));//��ؾɤJ���d�ˮ�

            reqMap.put("EMP_ID", user.getEmpID());
            reqMap.put("EMP_NAME", user.getEmpName());
            //180703:��س��W��
            String DIV_NAME = new EP_A10010().getDivName(user.getOpUnit(), SUB_CPY_ID);
            reqMap.put("DIV_NAME", DIV_NAME);

            this.query(reqMap, new EP_C22040());

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_2040_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }
        return resp;
    }

    /**
     * �ǲ��T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> confirmList = VOTool.jsonAryToMaps(req.getParameter("confirmList"));
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            reqMap.put("EMP_ID", user.getEmpID());
            reqMap.put("EMP_NAME", user.getEmpName());
            //180703:��س��W��
            String DIV_NAME = new EP_A10010().getDivName(user.getOpUnit(), SUB_CPY_ID);
            reqMap.put("DIV_NAME", DIV_NAME);

            //���o�ǲ����tmpAcntDate
            String tmpAcntDate = MapUtils.getString(reqMap, "ACNT_DATE");
            if (StringUtils.isNotBlank(tmpAcntDate) && DATE.isDate(tmpAcntDate)) {
                reqMap.put("ACNT_DATE", tmpAcntDate);
            } else {
                Date currentDate = DATE.today();
                if (WorkDate.isWorkingDay(currentDate)) {
                    reqMap.put("ACNT_DATE", currentDate);
                } else {
                    //�Y CURRENT DATE ���O �u�@��ASET�ǲ����= �U�@�u�@��C
                    reqMap.put("ACNT_DATE", new Date(WorkDate.getNextXWorkingDate(currentDate, 1).getTime()));
                }
            }
            //2018-08-29���D��20180507-0063�վ㦨�i�H�h��
            new EPC2_2040_mod().checkAcntDate(reqMap, confirmList);

            EP_C22040 theEP_C22040 = new EP_C22040();

            String rtnMsg = null;
            Transaction.setXAMode();
            Transaction.begin();
            try {
                //2018-08-29���D��20180507-0063�վ㦨�i�H�h��
                rtnMsg = theEP_C22040.confirm(reqMap, confirmList);
                if (StringUtils.isNotBlank(rtnMsg) && !rtnMsg.startsWith("rtnMsg:")) {//�D��عq�l�o�����榳�~���~�T��
                    reqMap.put("SLIP_SET_NO", rtnMsg);
                    reqMap.put("ACC_ACTION", "Y");
                    resp.addOutputData("reqMap", reqMap);
                }
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            if (StringUtils.isNotBlank(rtnMsg) && rtnMsg.startsWith("rtnMsg:")) { //��ةI�sws����
                throw new ModuleException(rtnMsg.substring(7));
            } else {
                MessageUtil.setMsg(msg, "EPC2_2040_ERRMSG_002");//�ǲ��T�{����
                try {
                    this.query(reqMap, theEP_C22040);
                } catch (DataNotFoundException e) {
                    log.error("�ǲ��T�{����,�d�L���", e);
                    MessageUtil.setMsg(msg, "EPC2_2040_ERRMSG_003");//�ǲ��T�{�����A�d�L���
                }
            }
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPC2_2040_ERRMSG_004");//�@�~���ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_2040_ERRMSG_005");//�@�~����
            }
        } catch (Exception e) {
            log.error("�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_2040_ERRMSG_005");//�@�~����
        }

        return resp;
    }

    /**
     * �ǲ�����
     * @param req
     * @return
     */
    public ResponseContext doUnConfirm(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            Map rtnMap = VOTool.jsonToMap(req.getParameter("rtnMap"));
            EP_C22040 theEP_C22040 = new EP_C22040();
            EPC2_2040_mod theEPC2_2040_mod = new EPC2_2040_mod();
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            String EmpId = user.getEmpID();
            reqMap.put("EMP_ID", EmpId);
            reqMap.put("EMP_NAME", user.getEmpName());
            //180703:��س��W��
            String DIV_NAME = new EP_A10010().getDivName(user.getOpUnit(), SUB_CPY_ID);
            reqMap.put("DIV_NAME", DIV_NAME);

            //CHECK�O�_���쵲�b�H��
            theEPC2_2040_mod.checkAcntID(EmpId, MapUtils.getString(rtnMap, "D_ACNT_ID"));
            //�ˮֶǲ��O�_���b���w���b���i�����T�{
            theEPC2_2040_mod.checkAcntData(reqMap, EmpId);
            //�ˬd��������b���B�O�_�w�X�b�R�P���Y�w�X�b�A�h���i���P
            theEPC2_2040_mod.checkC104Data(reqMap);

            String rtnMsg = null;
            Transaction.setXAMode();
            Transaction.begin();
            try {
                rtnMsg = theEP_C22040.unconfirm(reqMap);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            if (StringUtils.isNotBlank(rtnMsg)) { //��ةI�sws����
                throw new ModuleException(rtnMsg);
            } else {
                try {
                    reqMap.put("ACNT_DATE", null);
                    reqMap.put("SLIP_SET_NO", null);
                    reqMap.put("ACC_ACTION", "N");
                    resp.addOutputData("reqMap", reqMap);
                    this.query(reqMap, theEP_C22040);
                    MessageUtil.setMsg(msg, "EPC2_2040_ERRMSG_006");//�ǲ���������
                } catch (DataNotFoundException e) {
                    log.error("�ǲ��T�{����,�d�L���", e);
                    MessageUtil.setMsg(msg, "EPC2_2040_ERRMSG_007");//�ǲ����������A�d�L���
                }
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPC2_2040_ERRMSG_004");//�@�~���ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_2040_ERRMSG_005");//�@�~����
            }
        } catch (Exception e) {
            log.error("�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_2040_ERRMSG_005");//�@�~����
        }

        return resp;
    }

    /**
     * �@�άd��
     * @param SUB_CPY_ID
     * @param INV_NO
     * @param theEP_C22030
     * @throws ModuleException
     */
    private void query(Map reqMap, EP_C22040 theEP_C22040) throws ModuleException {

        BigDecimal SAL_TOT = BigDecimal.ZERO;
        BigDecimal TAX_TOT = BigDecimal.ZERO;
        BigDecimal INV_TOT = BigDecimal.ZERO;
        BigDecimal RNT_TOT = BigDecimal.ZERO;
        BigDecimal PRP_TOT = BigDecimal.ZERO;
        BigDecimal RJT_A_TOT = BigDecimal.ZERO;
        BigDecimal RJT_T_TOT = BigDecimal.ZERO;
        //20200212 �W�[�P�_�O�_����T�դH���A��T�դH�����d���
        boolean isITuser = user.getRoles().contains("RLZZ0EP");
        reqMap.put("isITuser", (isITuser) ? "Y" : "N"); //�O�_����T�ը���
        List<Map> resultList = theEP_C22040.query(reqMap);
        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        int i = 1;
        for (Map rtnMap : resultList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", rtnMap.get("ID"));
            logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);

            rtnMap.put("NO", i++);

            SAL_TOT = SAL_TOT.add(getBigDecimal(rtnMap.get("SAL_AMT"), BigDecimal.ZERO));
            TAX_TOT = TAX_TOT.add(getBigDecimal(rtnMap.get("TAX_AMT"), BigDecimal.ZERO));
            INV_TOT = INV_TOT.add(getBigDecimal(rtnMap.get("INV_AMT"), BigDecimal.ZERO));
            RNT_TOT = RNT_TOT.add(getBigDecimal(rtnMap.get("RNT_AMT"), BigDecimal.ZERO));
            PRP_TOT = PRP_TOT.add(getBigDecimal(rtnMap.get("PRP_AMT"), BigDecimal.ZERO));
            RJT_A_TOT = RJT_A_TOT.add(getBigDecimal(rtnMap.get("RJT_AMT"), BigDecimal.ZERO));
            RJT_T_TOT = RJT_T_TOT.add(getBigDecimal(rtnMap.get("RJT_TAX"), BigDecimal.ZERO));
        }

        Map totList = new HashMap();
        totList.put("SAL_AMT", SAL_TOT);
        totList.put("TAX_AMT", TAX_TOT);
        totList.put("INV_AMT", INV_TOT);
        totList.put("RNT_AMT", RNT_TOT);
        totList.put("PRP_AMT", PRP_TOT);
        totList.put("RJT_AMT", RJT_A_TOT);
        totList.put("RJT_TAX", RJT_T_TOT);

        logSecurity(logSecurityList);
        resp.addOutputData("resultList", resultList);
        resp.addOutputData("totList", totList);
    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

    /**
     * �C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("EMP_ID", user.getEmpID());
            reqMap.put("EMP_NAME", user.getEmpName());
            reqMap.put("DIV_NAME", user.getOpUnitShortName());

            EP_C0Z002 theEP_C0Z002 = new EP_C0Z002();
            Transaction.begin();
            try {
                //���o��������
                Map SlipMap = new EP_C22040().printRpt(reqMap);
                //���������Ʈ榡��
                Map parmMap = theEP_C0Z002.doFormat(SlipMap, user);

                //logSecurity
                logSecurity(parmMap.get("detail"));

                //�C�L����
                theEP_C0Z002.doPrint(parmMap, resp);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPC2_2040_ERRMSG_008");//�C�L����
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_2040_ERRMSG_009");//�C�L����
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_2040_ERRMSG_009");//�C�L����
        }

        return resp;
    }

    /*2018-06-25 �s�W�ץX�C����*/
    /**
     *  �ץXCSV
     * @param req
     * @return
     */
    public ResponseContext doExportCsv(RequestContext req) {

        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("EMP_ID", user.getEmpID());
            reqMap.put("EMP_NAME", user.getEmpName());
            reqMap.put("DIV_NAME", user.getOpUnitShortName());
            List<Map> rtnList = new EP_C22040().queryForCsv(reqMap);

            StringBuilder sb = new StringBuilder();
            //�ɦW:+�e��.�b��+���o���B�z_��+�e��.�@�o����(����)
            String fileName = sb.append(MapUtils.getString(reqMap, "ACNT_DATE", "")).append(MessageUtil.getMessage("EPC2_2040_UI_MSG_001")).append('_').append(MapUtils.getString(reqMap, "ACC_TYPE_NM", "")).toString();

            CsvUtils csvUtils = new CsvUtils(fileName, rtnList, resp);

            //�����D
            String[] colTitles = new String[] { "�����N��", "�Ȥ�W��", "�Τ@�s��", "�o�����X", "ú�ں���", "�o�����p", "�P���B", "��~�|�B", "�o�����B", "ú�کl��", "ú�ڲ״�", "�Ӽh�O", "�ǧO" };

            //���key
            String[] colKeys = new String[] { "CRT_NO", "CUS_NAME", "ID", "INV_NO", "PAY_KIND", "INV_CD", "SAL_AMT", "TAX_AMT", "INV_AMT", "PAY_S_DATE", "PAY_E_DATE", "FLD_NO", "ROOM_NO" };

            csvUtils.initExportSetting(colTitles, colKeys);

            //����ץX
            csvUtils.execute(new CsvUtils.ListProcessHandler() {
            });

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_2040_UI_MSG_002");//�ɮפU������
            }
        } catch (Exception e) {
            log.error("�ɮפU������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_2040_UI_MSG_002");//�ɮפU������
        }
        return resp;
    }

}
