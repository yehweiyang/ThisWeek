package com.cathay.ep.c2.trx;

import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C203;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date     Description Author
 * 2013/8/12    Created �\�a�s
 *
 *
 * UCEPC2_1030_�o�����X�޲z�@�~
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �o�����X�޲z�@�~
 * �{���W��    EPC2_1030
 * �@�~�覡    ONLINE
 * ���n����     (1) �d�ߡG�d�ߵo�����X��
 *              (2) �s�W�G�s�W�o�����X��
 *              (3) �ק�G�ק�o�����X��
 *
 * @author ����[
 * @since 2013-10-04
 */
@SuppressWarnings("unchecked")
public class EPC2_1030 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_1030.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.getMessage("EPC2_1030_ERRMSG_001");//���o�����q�O����
        }
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            resp.addOutputData("rtnMap", query(req.getParameter("INV_YM_QRY"), req.getParameter("SUB_CPY_ID")));

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߦ��\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC2_1030_UI_001"));//���ƶW�L
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            Transaction.begin();
            try {
                new EP_Z0C203().insertC203(reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00004"));//�s�W����

            String INV_YM_QRY = MapUtils.getString(reqMap, "INV_YM");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            try {
                resp.addOutputData("rtnMap", query(INV_YM_QRY, SUB_CPY_ID));
            } catch (DataNotFoundException dnfe) {
                log.debug("�s�W����,�d�L���");
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00005"));//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00005"));//�s�W����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            Transaction.begin();
            try {
                new EP_Z0C203().updateC203(reqMap);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00007"));//�ץ�����

            String INV_YM_QRY = MapUtils.getString(reqMap, "INV_YM");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            try {
                resp.addOutputData("rtnMap", query(INV_YM_QRY, SUB_CPY_ID));
            } catch (DataNotFoundException dnfe) {
                log.debug("�ק粒��,�d�L���");
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00009"));//�ץ����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00008"));//�ץ�����
            }
        } catch (Exception e) {
            log.error("�ץ�����", e);//�ץ�����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00008"));//�ץ�����
        }

        return resp;
    }

    /**
     * ��@�d��
     * @param INV_YM_QRY
     * @return
     * @throws ModuleException
     */
    private Map query(String INV_YM_QRY, String SUB_CPY_ID) throws ModuleException {

        Map rtnMap = new EP_Z0C203().queryMap(SUB_CPY_ID, INV_YM_QRY);
        rtnMap.put("INV_SNO_1", STRING.fillZero(MapUtils.getString(rtnMap, "INV_SNO_1"), 8));
        rtnMap.put("INV_SNO_2", STRING.fillZero(MapUtils.getString(rtnMap, "INV_SNO_2"), 8));
        rtnMap.put("INV_ENO_1", STRING.fillZero(MapUtils.getString(rtnMap, "INV_ENO_1"), 8));
        rtnMap.put("INV_ENO_2", STRING.fillZero(MapUtils.getString(rtnMap, "INV_ENO_2"), 8));
        return rtnMap;
    }

}
