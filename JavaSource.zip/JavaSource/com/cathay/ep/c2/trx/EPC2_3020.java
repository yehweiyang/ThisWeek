package com.cathay.ep.c2.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.dd.b0.module.DD_B0Z018;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.c2.module.EP_C23020;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Description Author
 * 2013/8/15    Created �\�a�s
 *
 * UCEPC2_3020_�o����X�d�ߧ@�~
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �o����X�d�ߧ@�~
 * �{���W��    EPC2_3020
 * �@�~�覡    ONLINE
 * ���n����    (1) �d�ߡG�o���ɬd��
 * (2) �o�����ӤU���G�N�d�X����ƥHcsv�ɳ����e�{
 * (3) �W�s���G�s����EPC2_3010�d�o������
 * </pre>
 * 
 * [20180221] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * 
 * @author ����[
 * @since 2014-01-02
 */
@SuppressWarnings("unchecked")
public class EPC2_3020 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_3020.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);
        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        VOTool.setParamsFromLP_JSON(req);

        resp.addOutputData("CRT_NO", req.getParameter("CRT_NO"));
        resp.addOutputData("QUERYTYPE", req.getParameter("QUERYTYPE"));
        resp.addOutputData("CUS_NO", req.getParameter("CUS_NO"));

        //�u�o�������v�U�Կ��
        resp.addOutputData("INV_CDList", FieldOptionList.getFieldOptions("EPC", "INV_CD"));
        //�uú�ں����v�U�Կ��
        resp.addOutputData("PAY_KIND_ONEList", FieldOptionList.getFieldOptions("EPC", "PAY_KIND_FOUR"));

        resp.addOutputData("BAL_TYPEList", FieldOptionList.getFieldOptions("EP", "BAL_TYPE"));

        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
        } catch (Exception e) {
            log.error("���o�����q�O����");
        }

        //�~�W�N���U�Կ��       
        try {
            /* [20180221] �W�[�P�_���I�sEP_Z00030  */
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                resp.addOutputData("PIN_CODEList", new DD_B0Z018().queryDtddb070(""));
            } else {
                List<Map> PIN_CODEList = new ArrayList<Map>();
                Map tmpMap = FieldOptionList.getFieldOptions("EP", "PIN_CODE");
                for(Object key : tmpMap.keySet()){
                    Map PIN_CODEMap = new HashMap();
                    PIN_CODEMap.put("PIN_CODE", key);
                    PIN_CODEMap.put("PIN_NAME", tmpMap.get(key));
                    PIN_CODEList.add(PIN_CODEMap);
                }
                resp.addOutputData("PIN_CODEList", PIN_CODEList);
            }
        } catch (ModuleException e) {
            log.error("�~�W�N���U�Կ�沣�ͥ���", e);
        }

        List bld_cdList = new ArrayList();
        try {
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            List<Map> rtnList = new EP_A10010().queryList(reqMap);
            for (Map rtnmp : rtnList) {
                Map newmp = new HashMap();
                newmp.put("key", rtnmp.get("BLD_CD"));
                newmp.put("value", rtnmp.get("BLD_NAME"));
                bld_cdList.add(newmp);
            }
        } catch (Exception e) {
            log.error("", e);
        }
        resp.addOutputData("BLD_CDList", bld_cdList);
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));

            //150706:�T�جd�ߤ�k�X�֦��@��
            List<Map> rtnList = new EP_C23020().queryListTYPE1(reqMap, resp);

            BigDecimal INV_TOT = BigDecimal.ZERO;
            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map rtnMap : rtnList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("ID", rtnMap.get("ID"));
                logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                logSecurityList.add(logSecurityMap);

                INV_TOT = INV_TOT.add(getBigDecimal(rtnMap.get("INV_AMT"), BigDecimal.ZERO));
            }
            logSecurity(logSecurityList);
            Map TOTMap = new HashMap();
            TOTMap.put("CRT_NO", rtnList.size());
            TOTMap.put("TAX_AMT", MessageUtil.getMessage("EPC2_3020_UI_TOT2"));
            TOTMap.put("INV_AMT", INV_TOT);
            resp.addOutputData("rtnList", rtnList);
            resp.addOutputData("TOTMap", TOTMap);

            MessageUtil.setMsg(msg, "MI00020");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_3020_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00630");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �ɮפU��
     * @param req
     * @return
     */
    public ResponseContext doExportCSV(RequestContext req) {

        try {
            Map<String, Object> reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
            reqMap.put("FILE_TYPE", "CSV");

            //�u��������Ӭd��
            String fileName = MessageUtil.getMessage("EPC2_3020_MSG_FILE_NAME")/*�o������_*/+ DATE.toDate_yyyyMMdd(DATE.getDBDate());
            reqMap.put("gridJSON", req.getParameter("gridJSON"));
            reqMap.put("fileName", fileName);

            //�ץX
            //150706:�T�جd�ߤ�k�X�֦��@��
            EP_C23020 theEP_C23020 = new EP_C23020();
            logSecurity(theEP_C23020.queryListTYPE1(reqMap, resp));
            MessageUtil.setMsg(msg, "EPC2_3020_ERRMSG_001");//�ץX����
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_3020_ERRMSG_002");//�ץX����
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_3020_ERRMSG_002");//�ץX����
        }
        return resp;
    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }
}
