package com.cathay.ep.c2.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.c2.module.EPC2_0010_mod;
import com.cathay.ep.c2.module.EP_C20010;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C201;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 * Date    Version Description Author
 * 2013/10/1   1.0 Created     ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �㯲�����B�z
 * �{���W��    EPC2_0010.java
 * �@�~�覡    ONLINE
 * ���n����    �\�໡��:
 * 1.  �d�� - �d�ߩ㯲��������
 * 2.  ú�ڬd�� �V �d��ú�ڬ���
 * 3.  ��� �V
 * 3.1�����G�d�߿�J�p���~��ú�ڬ�����A���g�J�㯲��������
 * 3.2��@���G�d��ú�ڬ�����A�w��Ŀﶵ�ءA�v�@�g�J�㯲��������
 * 4.  �R�� �V �N���T�{�㯲�������ɧR��                             
 * </pre>
 * @author �¶��� 
 * @since 2013/11/6  
 */
@SuppressWarnings("unchecked")
public class EPC2_0010 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_0010.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            int iCUR_YM = Integer.parseInt(DATE.getTodayYearAndMonth().toString()) - 191100;

            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user); // �����q�O
            resp.addOutputData("INT_YM_CHK", Integer.toString(iCUR_YM));
            resp.addOutputData("INT_YM_ALL", Integer.toString(iCUR_YM));
            resp.addOutputData("INT_YM_SINGLE", Integer.toString(iCUR_YM));
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (Exception e) {
            log.error("��l����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00029"));//��l����
        }
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            //�d�ߩ㯲�����Ӹ��
            resp.addOutputData("rtnList", query1(req.getParameter("radioType"), VOTool.jsonToMap(req.getParameter("dataMap"))));

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * ú�ڬd��
     * @param req
     * @return
     */
    public ResponseContext doQueryPay(RequestContext req) {
        try {
            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            resp.addOutputData("rtnList", query2(dataMap));

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * ���
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            EPC2_0010_mod theEPC2_0010_mod = new EPC2_0010_mod();
            //�ˮֿ�J���
            String radioType = req.getParameter("radioType");
            if ("A".equals(radioType)) {//�����
                theEPC2_0010_mod.checkQueryRadio(dataMap);
            } else {//��@���
                theEPC2_0010_mod.checkInsert(dataMap);
            }

            //������
            List<Map> dataList = "S".equals(radioType) ? VOTool.jsonAryToMaps(req.getParameter("dataList")) : null;
            String INT_YM = MapUtils.getString(dataMap, "INT_YM");
            String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            EP_C20010 theEP_C20010 = new EP_C20010();

            Transaction.begin();
            try {
                if ("A".equals(radioType)) {//�����
                    theEP_C20010.confirmAdd(INT_YM, SUB_CPY_ID, user);
                } else {//��@���
                    for (Map tmpMap : dataList) {
                        theEP_C20010.confirmAddSingle(INT_YM, SUB_CPY_ID, MapUtils.getString(tmpMap, "CRT_NO"), MapUtils.getString(tmpMap,
                            "CUS_NO"), MapUtils.getString(tmpMap, "RCV_NO"), MapUtils.getString(tmpMap, "PAY_NO"), user);
                    }
                }
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC2_0010_UI_MSG_004"));//��󦨥\

            //���s�d�ߩ㯲�����Ӹ��
            try {
                resp.addOutputData("rtnList", query1(radioType, VOTool.jsonToMap(req.getParameter("dataMap"))));
            } catch (DataNotFoundException dnfe) {
                log.error("��󦨥\,���d�d�L���", dnfe);
                MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC2_0010_UI_MSG_002"));//��󦨥\,���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC2_0010_UI_MSG_001"));//��󥢱�
            }
        } catch (Exception e) {
            log.error("��󥢱�", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC2_0010_UI_MSG_001"));//��󥢱�
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            String INT_YM = MapUtils.getString(dataMap, "INT_YM");
            String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            List<Map> dataList = VOTool.jsonAryToMaps(req.getParameter("dataList"));
            EP_C20010 theEP_C20010 = new EP_C20010();
            EP_Z0C201 theEP_Z0C201 = new EP_Z0C201();
            Transaction.begin();
            try {
                for (Map map : dataList) {
                    theEP_Z0C201.deleteDTEPC201(MapUtils.getString(map, "INT_NO"), SUB_CPY_ID);

                    //���s�p�������������
                    theEP_C20010.updateDTEPC105("4", INT_YM, SUB_CPY_ID, MapUtils.getString(map, "INV_AMT"), "D");
                }

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC2_0010_UI_MSG_005"));//�R�����T�{�㯲�����ӧ���

            //���s�d�ߩ㯲�����Ӹ��
            try {
                resp.addOutputData("rtnList", query1(req.getParameter("radioType"), VOTool.jsonToMap(req.getParameter("dataMap"))));
            } catch (DataNotFoundException dnfe) {
                log.error("�R�����\,���d�d�L���", dnfe);
                MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC2_0010_UI_MSG_006"));//�R�����\�A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_0010_UI_MSG_003");//�R�����T�{�㯲�����ӥ���
            }
        } catch (Exception e) {
            log.error("�R�����T�{�㯲�����ӥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC2_0010_UI_MSG_003"));//�R�����T�{�㯲�����ӥ���
        }

        return resp;
    }

    /**
     * �s�ʨ��o�Ȥ�W��
     * @param req
     * @return
     */
    public ResponseContext doGetCusName(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            resp.addOutputData("CUS_NAME", MapUtils.getString(new EP_B10020().queryMap(reqMap), "CUS_NAME", ""));
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �d�ߩ㯲�����Ӹ��
     * @param radioType
     * @param dataMap
     * @return
     * @throws ModuleException
     */

    private List<Map> query1(String radioType, Map dataMap) throws ModuleException {
        //����ˮ�
        new EPC2_0010_mod().checkQueryRadio(dataMap);

        EP_C20010 theEP_C20010 = new EP_C20010();
        String INT_YM = MapUtils.getString(dataMap, "INT_YM");
        List<Map> rtnList;
        if ("S".equals(radioType)) {//��@��� 
            rtnList = theEP_C20010.queryDTEPC201(INT_YM, MapUtils.getString(dataMap, "CRT_NO"), MapUtils.getString(dataMap, "CUS_NO"),
                MapUtils.getString(dataMap, "SUB_CPY_ID"), MapUtils.getString(dataMap, "PAY_NO"));

            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map rtnMap : rtnList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("ID", rtnMap.get("ID"));
                logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);

        } else {//����� 
            //rtnList = theEP_C20010.queryDTEPC201(INT_YM, "", "", "", "");
            rtnList = theEP_C20010.queryDTEPC105("4", INT_YM, MapUtils.getString(dataMap, "SUB_CPY_ID"));
        }

        return rtnList;
    }

    /**
     * �d��ú�ک��Ӹ��
     * @param dataMap
     * @return
     * @throws ModuleException
     */
    private List<Map> query2(Map dataMap) throws ModuleException {

        //����ˮ�
        new EPC2_0010_mod().checkQueryC301C306(dataMap);
        List<Map> rtnList = new EP_C20010().queryDTEPC301306(MapUtils.getString(dataMap, "INT_YM"), MapUtils.getString(dataMap, "CRT_NO"),
            MapUtils.getString(dataMap, "CUS_NO"), MapUtils.getString(dataMap, "RCV_NO"), MapUtils.getString(dataMap, "PAY_NO"), MapUtils
                    .getString(dataMap, "SUB_CPY_ID"));

        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map rtnMap : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", rtnMap.get("ID"));
            logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);
        }
        logSecurity(logSecurityList);

        return rtnList;
    }

}
