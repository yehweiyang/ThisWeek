package com.cathay.ep.c2.trx;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.hr.WorkDate;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.ep.c2.module.EPC2_0030_mod;
import com.cathay.ep.c2.module.EP_C20030;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Version Description Author
 * 2013/12/5    1.0 Created     ������
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �㯲�����ӽT�{
 * �{���W��    EPC2_0030.java
 * �@�~�覡    ONLINE
 * ���n����    �\�໡��:
 * 1.  �d�� - �d�ߩ㯲��������
 * 2.  �T�{ - �s�W�o���ɡB�^��㯲�������ɡB��sú�ڬ����ɡB�X�|�p�b
 * 3.  �����T�{ �V ���P�o���ɡB�٭�㯲�������ɡB�٭�ú�ڬ����ɡB�R���|�p�b
 * 4.  �����C�L
 * ���s���v    FUNC_ID = EPC20030
 * </pre>                                    
 * @author ����[
 * @since 2013-12-17
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC2_0030 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_0030.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.getMessage("EPC2_2030_ERRMSG_001");//���o�����q�O����
        }
        resp.addOutputData("OP_STATUS_List", FieldOptionList.getFieldOptions("EP", "OP_STATUS_C201"));

        //�b�Ⱥ����vACNT_TYPE_List
        resp.addOutputData("ACNT_TYPE_List", FieldOptionList.getFieldOptions("EP", "ACNT_TYPE"));
        resp.addOutputData("ACNT_DIV_NO", user.getUserDivNo());

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            //�O�_�������d��(�u�����\��T�w�Ѽ�) 
            boolean isFirstQuery = "Y".equals(req.getParameter("isFirstQuery"));
            String loadStrat = req.getParameter("loadStrat");
            String loadEnd = req.getParameter("loadEnd");
            Integer startWith = STRING.isNumeric(loadStrat) ? Integer.valueOf(loadStrat) : -1;
            Integer endWith = STRING.isNumeric(loadEnd) ? Integer.valueOf(loadEnd) : -1;
            Map param = VOTool.jsonToMap(req.getParameter("param"));

            Map dataMap = VOTool.jsonToMap(MapUtils.getString(param, "dataMap"));

            dataMap.put("isFirstQuery", isFirstQuery);
            dataMap.put("startWith", startWith);
            dataMap.put("endWith", endWith);

            new EPC2_0030_mod().checkQuery(dataMap);

            List<Map> rtnList = queryRPage(dataMap, new EP_C20030(), resp);

            resp.addOutputData("records", rtnList);

            if (isFirstQuery) {
                MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_0030_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }
        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {
        try {

            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            dataMap.put("User", user);

            EP_C20030 theEP_C20030 = new EP_C20030();

            //���o�ǲ����
            String SLIP_DATE = req.getParameter("SLIP_DATE");
            if (StringUtils.isBlank(SLIP_DATE)) {
                Date TODAY = DATE.today();
                if (WorkDate.isWorkingDay(TODAY)) {
                    dataMap.put("ACNT_DATE", TODAY);
                } else {
                    dataMap.put("ACNT_DATE", new Date(WorkDate.getNextXWorkingDate(TODAY, 1).getTime()).toString());
                }
            } else {
                dataMap.put("ACNT_DATE", SLIP_DATE);
            }
            Transaction.setXAMode();
            Transaction.begin();
            Map reqMap = new HashMap();
            try {
                reqMap = theEP_C20030.confirm(dataMap);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            String rtnMsg = MapUtils.getString(reqMap, "rtnMsg");
            if (StringUtils.isNotBlank(rtnMsg)) { //��ةI�sws����
                throw new ModuleException(rtnMsg);
            } else {
                resp.addOutputData("SLIP_SET_NO", MapUtils.getString(reqMap, "SLIP_SET_NO"));
                resp.addOutputData("ACNT_DATE", DATE.formatToROCDate(MapUtils.getString(reqMap, "ACNT_DATE")));

                MessageUtil.setMsg(msg, "EPC2_0030_ERRMSG_001");//�T�{���\
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPC2_0030_ERRMSG_002");//�T�{���ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_0030_ERRMSG_003");//�T�{����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_0030_ERRMSG_003");//�T�{����
        }
        return resp;
    }

    /**
     * �����T�{
     * @param req
     * @return
     */
    /* 20200205 �w�L�ϥ�
    public ResponseContext doCancel(RequestContext req) {
        try {
            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
    
            dataMap.put("User", user);
    
            EP_C20030 theEP_C20030 = new EP_C20030();
            Transaction.setXAMode();
            Transaction.begin();
            try {
                theEP_C20030.cancel(dataMap);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
    
            try {
                List<Map> rtnList = query(dataMap, theEP_C20030);
                resp.addOutputData("rtnList", rtnList);
                resp.addOutputData("totMap", getTOT(rtnList));
            } catch (Exception e) {
                log.error("�����T�{���\,�d�L���", e);
            }
    
            MessageUtil.setMsg(msg, "EPC2_0030_ERRMSG_004");//�����T�{���\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPC2_0030_ERRMSG_005");//�����T�{���ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_0030_ERRMSG_006");//�����T�{����
            }
        } catch (Exception e) {
            log.error("�����T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_0030_ERRMSG_006");//�����T�{����
        }
    
        return resp;
    }*/

    /**
     * �����C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {

            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            EP_C20030 theEP_C20030 = new EP_C20030();

            List<Map> rtnList = query(dataMap, theEP_C20030);
            Map totMap = getTOT(rtnList);

            Map reqMap = formateList(rtnList, totMap, dataMap, user);

            JasperReportUtils.addOutputRptDataToResp("EPC2_0030", (Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), resp);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC2_0030_ERRMSG_007"));//�C�L����

            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC2_0030_ERRMSG_007"));//�C�L����
        }

        return resp;
    }

    /**
     * �@�άd��
     * @param SUB_CPY_ID
     * @param INV_NO
     * @param theEP_C22030
     * @throws Exception 
     */
    private List<Map> query(Map dataMap, EP_C20030 theEP_C20030) throws Exception {

        String OP_STATUS = MapUtils.getString(dataMap, "OP_STATUS");
        String INT_YM = MapUtils.getString(dataMap, "INT_YM");

        List<Map> rtnList = null;
        if ("0".equals(OP_STATUS)) { ////���T�{
            rtnList = theEP_C20030.queryUnCfmDTEPC201(INT_YM, user.getDivNo(), MapUtils.getString(dataMap, "BLD_CD"), "", MapUtils.getString(dataMap, "ACNT_TYPE"), MapUtils.getString(dataMap, "SUB_CPY_ID"));
        } else if ("1".equals(OP_STATUS)) {//�w�T�{
            rtnList = theEP_C20030.queryDTEPC201(INT_YM, MapUtils.getString(dataMap, "BLD_CD"), MapUtils.getString(dataMap, "ACNT_DATE"), MapUtils.getString(dataMap, "ACNT_DIV_NO"), MapUtils.getString(dataMap, "SLIP_LOT_NO"),
                MapUtils.getString(dataMap, "SLIP_SET_NO"), MapUtils.getString(dataMap, "ACNT_TYPE"), MapUtils.getString(dataMap, "SUB_CPY_ID"), OP_STATUS);
        } else if ("2".equals(OP_STATUS)) {//�|�p�w�Ю�/���o�����X
            rtnList = theEP_C20030.queryDTEPC201(INT_YM, MapUtils.getString(dataMap, "BLD_CD"), MapUtils.getString(dataMap, "ACNT_DATE"), MapUtils.getString(dataMap, "ACNT_DIV_NO"), MapUtils.getString(dataMap, "SLIP_LOT_NO"),
                MapUtils.getString(dataMap, "SLIP_SET_NO"), MapUtils.getString(dataMap, "ACNT_TYPE"), MapUtils.getString(dataMap, "SUB_CPY_ID"), OP_STATUS);
        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EPC2_0030_ERRMSG_008"));//�f�֪��A��J���~
        }

        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map rtnMap : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", rtnMap.get("ID"));
            logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);
        }
        logSecurity(logSecurityList);

        return rtnList;

    }

    /**
     * �@�ίu�����d��
     * @param SUB_CPY_ID
     * @param INV_NO
     * @param theEP_C22030
     * @throws Exception 
     */
    private List<Map> queryRPage(Map dataMap, EP_C20030 theEP_C20030, ResponseContext resp) throws Exception {

        String OP_STATUS = MapUtils.getString(dataMap, "OP_STATUS");
        String INT_YM = MapUtils.getString(dataMap, "INT_YM");

        boolean isFirstQuery = MapUtils.getBooleanValue(dataMap, "isFirstQuery");
        Integer startWith = MapUtils.getInteger(dataMap, "startWith");
        Integer endWith = MapUtils.getInteger(dataMap, "endWith");

        List<Map> rtnList = null;
        if ("0".equals(OP_STATUS)) { ////���T�{
            rtnList = theEP_C20030.queryUnCfmDTEPC201(INT_YM, user.getDivNo(), MapUtils.getString(dataMap, "BLD_CD"), "", MapUtils.getString(dataMap, "ACNT_TYPE"), MapUtils.getString(dataMap, "SUB_CPY_ID"), resp, isFirstQuery, startWith, endWith);
        } else if ("1".equals(OP_STATUS)) {//�w�T�{
            rtnList = theEP_C20030.queryDTEPC201(INT_YM, MapUtils.getString(dataMap, "BLD_CD"), MapUtils.getString(dataMap, "ACNT_DATE"), MapUtils.getString(dataMap, "ACNT_DIV_NO"), MapUtils.getString(dataMap, "SLIP_LOT_NO"),
                MapUtils.getString(dataMap, "SLIP_SET_NO"), MapUtils.getString(dataMap, "ACNT_TYPE"), MapUtils.getString(dataMap, "SUB_CPY_ID"), OP_STATUS, resp, isFirstQuery, startWith, endWith);
        } else if ("2".equals(OP_STATUS)) {//�|�p�w�Ю�/���o�����X
            rtnList = theEP_C20030.queryDTEPC201(INT_YM, MapUtils.getString(dataMap, "BLD_CD"), MapUtils.getString(dataMap, "ACNT_DATE"), MapUtils.getString(dataMap, "ACNT_DIV_NO"), MapUtils.getString(dataMap, "SLIP_LOT_NO"),
                MapUtils.getString(dataMap, "SLIP_SET_NO"), MapUtils.getString(dataMap, "ACNT_TYPE"), MapUtils.getString(dataMap, "SUB_CPY_ID"), OP_STATUS, resp, isFirstQuery, startWith, endWith);
        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EPC2_0030_ERRMSG_008"));//�f�֪��A��J���~
        }

        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map rtnMap : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", rtnMap.get("ID"));
            logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);
        }
        logSecurity(logSecurityList);

        return rtnList;

    }

    /**
     * �p��X�p
     * @param rtnList
     * @return
     */
    private Map getTOT(List<Map> rtnList) {
        BigDecimal PMI_AMT_TOTAL = BigDecimal.ZERO;
        BigDecimal PMI_TAX_TOTAL = BigDecimal.ZERO;
        BigDecimal INV_AMT_TOTAL = BigDecimal.ZERO;
        BigDecimal PMS_AMT_TOTAL = BigDecimal.ZERO;
        int i = 1;
        for (Map C201_Map : rtnList) {
            C201_Map.put("NO", i++);
            String INV_CD = MapUtils.getString(C201_Map, "INV_CD");
            if (StringUtils.isNotBlank(INV_CD) && !"0".equals(INV_CD)) {
                continue;
            }
            PMI_AMT_TOTAL = PMI_AMT_TOTAL.add(getBigDecimal(C201_Map.get("PMI_AMT"), BigDecimal.ZERO));
            PMI_TAX_TOTAL = PMI_TAX_TOTAL.add(getBigDecimal(C201_Map.get("PMI_TAX"), BigDecimal.ZERO));
            INV_AMT_TOTAL = INV_AMT_TOTAL.add(getBigDecimal(C201_Map.get("INV_AMT"), BigDecimal.ZERO));
            PMS_AMT_TOTAL = PMS_AMT_TOTAL.add(getBigDecimal(C201_Map.get("PMS_AMT"), BigDecimal.ZERO));
        }
        Map totMap = new HashMap();
        totMap.put("PMI_AMT", PMI_AMT_TOTAL);
        totMap.put("PMI_TAX", PMI_TAX_TOTAL);
        totMap.put("INV_AMT", INV_AMT_TOTAL);
        totMap.put("PMS_AMT", PMS_AMT_TOTAL);

        return totMap;
    }

    /**
     * �B�z�������
     * @param rtnList
     * @param totMap
     * @param dataMap
     * @return
     */
    private Map formateList(List<Map> rtnList, Map totMap, Map dataMap, UserObject user) {

        List<Map> detail = new ArrayList();

        int index = 1;
        StringBuilder sb = new StringBuilder();
        LocaleDisplay locale = new LocaleDisplay("EP", user);
        for (Map prtMap : rtnList) {
            Map formateMap = new HashMap();
            formateMap.put("NO", String.valueOf(index++));
            formateMap.put("CRT_NO", MapUtils.getString(prtMap, "CRT_NO", ""));
            formateMap.put("CUS_NO", MapUtils.getString(prtMap, "CUS_NO", ""));
            formateMap.put("ID", MapUtils.getString(prtMap, "ID", ""));
            formateMap.put("CUS_NAME", MapUtils.getString(prtMap, "CUS_NAME", ""));
            formateMap.put("PMI_AMT", decimalToStr(prtMap, "PMI_AMT", locale));
            formateMap.put("PMI_TAX", decimalToStr(prtMap, "PMI_TAX", locale));
            formateMap.put("INV_AMT", decimalToStr(prtMap, "INV_AMT", locale));
            formateMap.put("PMI_S_DATE", str2LocaleDate(prtMap, "PMI_S_DATE", locale));
            formateMap.put("PMI_E_DATE", str2LocaleDate(prtMap, "PMI_E_DATE", locale));
            formateMap.put("PASS_DAY", MapUtils.getString(prtMap, "PASS_DAY", ""));
            formateMap.put("PMS_AMT", decimalToStr(prtMap, "PMS_AMT", locale));
            formateMap.put("RAT_CD", MapUtils.getString(prtMap, "RAT_CD", ""));

            BigDecimal PIM_RATE = getBigDecimal(prtMap.get("PIM_RATE"), null);
            DecimalFormat df = new DecimalFormat();
            df.applyPattern("#.#############");

            if (PIM_RATE == null) {
                formateMap.put("PIM_RATE", "");
            } else {
                formateMap.put("PIM_RATE", df.format(PIM_RATE));
            }

            formateMap.put("INV_NO", MapUtils.getString(prtMap, "INV_NO", ""));
            sb.setLength(0);
            formateMap.put("TAX_TYPE", sb.append(MapUtils.getString(prtMap, "TAX_TYPE", "")).append(" ").append(MapUtils.getString(prtMap, "TAX_TYPE_NM", "")).toString());
            formateMap.put("LST_PROC_DATE", str2LocaleDate(MapUtils.getString(prtMap, "LST_PROC_DATE", "").split(" ")[0], locale));
            sb.setLength(0);
            formateMap.put("OP_STATUS", sb.append(MapUtils.getString(prtMap, "OP_STATUS", "")).append(" ").append(MapUtils.getString(prtMap, "OP_STATUS_NM", "")).toString());
            formateMap.put("LST_PROC_NAME", MapUtils.getString(prtMap, "LST_PROC_NAME", ""));
            sb.setLength(0);
            formateMap.put("ACNT_DATA", sb.append(str2LocaleDate(prtMap, "ACNT_DATE", locale)).append("-").append(MapUtils.getString(prtMap, "ACNT_DIV_NO", "")).append("-").append(MapUtils.getString(prtMap, "SLIP_SET_NO", "")).append("-")
                    .append(MapUtils.getString(prtMap, "SLIP_SEQ_NO", "")).toString());

            detail.add(formateMap);
        }

        Map params = new HashMap();
        String OP_STATUS = MapUtils.getString(dataMap, "OP_STATUS", "");

        params.put("REPORT_ID", "EPC2_0030");
        params.put("PRINT_DATE", DATE.getDBDate());
        params.put("PRINT_TIME", DATE.getDBTime());

        params.put("INT_YM", locale.formatDateym(dataMap.get("INT_YM"), ""));
        params.put("BLD_CD", MapUtils.getString(dataMap, "BLD_CD", "") + MapUtils.getString(dataMap, "BLD_NAME", ""));
        params.put("OP_STATUS", OP_STATUS);
        params.put("OP_STATUS_NM", MapUtils.getString(dataMap, "OP_STATUS_NM", ""));
        params.put("ACNT_DIV_NO", MapUtils.getString(dataMap, "ACNT_DIV_NO", ""));
        params.put("ACNT_DATE", str2LocaleDate(dataMap, "ACNT_DATE", locale));
        params.put("SLIP_SET_NO", MapUtils.getString(dataMap, "SLIP_SET_NO", ""));
        params.put("SLIP_LOT_NO", MapUtils.getString(dataMap, "SLIP_LOT_NO", ""));
        params.put("SLIP_SEQ_NO", MapUtils.getString(dataMap, "SLIP_SEQ_NO", ""));
        params.put("TOT_PMI_AMT", decimalToStr(totMap, "PMI_AMT", locale));
        params.put("TOT_PMI_TAX", decimalToStr(totMap, "PMI_TAX", locale));
        params.put("TOT_INV_AMT", decimalToStr(totMap, "INV_AMT", locale));
        params.put("TOT_PMS_AMT", decimalToStr(totMap, "PMS_AMT", locale));

        Map rtnMap = new HashMap();
        rtnMap.put("params", params);
        rtnMap.put("detail", detail);

        return rtnMap;

    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

    /**
     * ��LocaleDisplay�ഫ�d����榡
     * @param map
     * @param key
     * @param local
     * @return
     */
    private String decimalToStr(Map map, String key, LocaleDisplay local) {
        return local.formatNumber(map.get(key), 0, "");
    }

    /**
     * ��LocaleDisplay�ഫ����榡
     * @param map
     * @param key
     * @param defaultValue
     * @return
     */
    private String str2LocaleDate(Map map, String key, LocaleDisplay locale) {
        String str = MapUtils.getString(map, key);
        return str2LocaleDate(str, locale);

    }

    /**
     * ��LocaleDisplay�ഫ����榡
     * @param str
     * @param locale
     * @return
     */
    private String str2LocaleDate(String str, LocaleDisplay locale) {
        return StringUtils.isNotBlank(str) ? locale.formatDate(Date.valueOf(str), "/", "") : "";
    }
}
