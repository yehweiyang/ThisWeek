package com.cathay.ep.c2.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.dd.e0.module.DD_E0Z006;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.c0.module.EP_C0Z001;
import com.cathay.ep.c2.eInvWsForREM.eInvHelper;
import com.cathay.ep.c2.eInvWsForREM.eInvServiceSoap_PortType;
import com.cathay.ep.c2.module.EP_C21010;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.db.DBException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 *  Date    Version Description Author
 *  2013/08/07  1.0 Created ���i��
 *  
 * UCEPC2_1010_�o�����}��
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �o�����}��
 * �{���W��    EPC2_1010
 * �@�~�覡    ONLINE
 * ���n����    (1) �d�ߡG�d�߫ݶ}�ߵo����ơC
 *             (2) �}�ߡG�}�ߵo���C
 *             
 * [20180221] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ� 
 * 
 * [20200220]�ק�� ����z
 * ��عq�l�o���ɤJ
 * 
 * @author ����[
 * @since 2013-10-03
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC2_1010 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_1010.class);

    private static final boolean isDebugEnable = log.isDebugEnabled();

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            try {
                resp.addOutputData("PAY_KIND_LIST", FieldOptionList.getFieldOptions("EPC", "PAY_KIND_FOUR"));//�o������
            } catch (Exception e) {
                log.error("�o�������M����o����");
            }
            String SUB_CPY_ID = null;
            try {
                SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
                resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�ϥΪ̤����q�O���
            } catch (Exception e) {
                log.error("�����q�O���o����");
            }
            try {
                Map map = new HashMap();
                map.put("SUB_CPY_ID", SUB_CPY_ID);
                resp.addOutputData("BLD_USR_IDList", new EP_A10010().queryAgentList(map));//�j�Ӹg��M��
            } catch (Exception e) {
                log.error("�j�Ӹg��M����o����");
            }
            try {
                resp.addOutputData("INV_TYPE_LIST", FieldOptionList.getName("EP", "CUS_INV_TYPE"));//�Ȥ����
            } catch (Exception e) {
                log.error("�Ȥ�������o����");
            }
            try {
                resp.addOutputData("ELE_INV_START", FieldOptionList.getName("EP", "ELE_INV", "START_YM"));//�q�l�o���ɤJ
            } catch (Exception e) {
                log.error("�q�l�o���ɤJ�ɶ����o����");
            }

            /* [20180221] �W�[�ǤJ�ѼƩI�sEP_Z00030  */
            resp.addOutputData("isAccountSubCpy", new EP_Z00030().isAccountSubCpy(SUB_CPY_ID));

        } catch (Exception e) {
            log.error("��l����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00029");//��l����
        }
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            this.query(req);

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߦ��\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �}��
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {
            if (isDebugEnable) {
                log.debug("@@@@@ doUpdate.start!!");
            }
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
            EP_C21010 theEP_C21010 = new EP_C21010();
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            List<Map> dataList = theEP_C21010.queryByInvNOs(RCV_YM, SUB_CPY_ID, reqList);
            if (isDebugEnable) {
                log.debug("@@@@@ doUpdate.call print!!");
            }
            String errMsg = null;
            // �C�L�o�����\�M��A��عq�l�o���I�s�t��ws�C�L���\�~��s���
            EP_C0Z001 theEP_C0Z001 = new EP_C0Z001();
            /* [20180221] �W�[�P�_���I�sEP_Z00030  */
            // [20200220] �����P�_���I�sEP_Z00030/�W�[��عq�l�o�����y
            Integer PRINT_CNT = null;
            List<Map> sucessList = new ArrayList<Map>();
            if (RCV_YM.compareTo(FieldOptionList.getName("EP", "ELE_INV", "START_YM")) < 0) {//�D�q�l�o��
                Map parmMap = theEP_C0Z001.doFormat(dataList);
                theEP_C0Z001.doPrint(parmMap, resp);
                sucessList = dataList;
            } else if ("01".equals(SUB_CPY_ID)) { // ��عq�l�o��
                if (isDebugEnable) {
                    log.debug("@@@@@ doUpdate.call print REM.EP part start!!");
                }
                eInvHelper theeInvHelper = new eInvHelper(user.getEmpID());
                eInvServiceSoap_PortType service = theeInvHelper.initService();//�w���ŧiservice�A�קK�C���^�鳣�n�ŧi�@��

                PRINT_CNT = new Integer(FieldOptionList.getName("EP", "eInvWsForRemSetting", "PRINT_CNT"));

                int printFlag = 1;
                for (Map dataMap : dataList) {
                    if (printFlag > PRINT_CNT) {
                        break;
                    }
                    try {
                        // �I�s�t��ws�C�L�o��
                        dataMap.put("PRINT_TYPE", "1"); // ���}��
                        theeInvHelper.printInv(dataMap, service);
                        sucessList.add(dataMap);
                    } catch (Exception e) {
                        //�C�L���ѡA�o�����X�G%s
                        errMsg = MessageUtil.getMessage("EPC2_1010_UI_004", new String[] { MapUtils.getString(dataMap, "INV_NO"), e.getMessage() });
                        log.fatal(errMsg, e);
                        break; //���@�������N���_�j��
                    } catch (Throwable t) {
                        //�C�L���ѡA�o�����X�G%s
                        errMsg = MessageUtil.getMessage("EPC2_1010_UI_004", new String[] { MapUtils.getString(dataMap, "INV_NO"), t.getMessage() });
                        log.fatal(errMsg, t);
                        break; //���@�������N���_�j��
                    }
                    printFlag++;
                }
                if (isDebugEnable) {
                    log.debug("@@@@@ doUpdate.call print REM.EP part end!! printFlag:" + printFlag + ",sucessList.size:" + sucessList.size());
                }
            } else { // ��عq�l�o��
                if (isDebugEnable) {
                    log.debug("@@@@@ doUpdate.call print cathay.EP part start!!");
                }
                //�h�Ǥ����q�O,�d�߫~�W
                Map parmMap = theEP_C0Z001.doFormatForElcInv(dataList, SUB_CPY_ID);
                sucessList = dataList;
                List<Map> B2BList = (List<Map>) parmMap.get("B2BList");
                DD_E0Z006 theDD_E0Z006 = new DD_E0Z006();
                if (B2BList.size() > 0) {
                    Map printMap = new HashMap();
                    printMap.put("printList", B2BList);
                    theDD_E0Z006.printElcInvB2B(printMap, resp);
                }
                List<Map> B2CList = (List<Map>) parmMap.get("B2CList");
                if (B2CList.size() > 0) {
                    Map printMap = new HashMap();
                    printMap.put("printList", B2CList);
                    theDD_E0Z006.printElcInvB2C_2(printMap, resp);
                }
                if (isDebugEnable) {
                    log.debug("@@@@@ doUpdate.call print cathay.EP part end!!");
                }
            }

            if (sucessList != null && !sucessList.isEmpty()) {//�����\�C�L�o�����A��s�o���C�L���
                if (isDebugEnable) {
                    log.debug("@@@@@ doUpdate.Transaction begin!!");
                }
                Transaction.begin();
                try {
                    theEP_C21010.update(sucessList, user);
                    Transaction.commit();
                } catch (Exception e) {
                    Transaction.rollback();
                    throw e;
                }
                if (isDebugEnable) {
                    log.debug("@@@@@ doUpdate.Transaction end!!");
                }
            }

            try {
                this.query(req);
            } catch (DataNotFoundException dnfe) {
                log.error("�}�ߦ��\�A���s�d�߬d�L���", dnfe);
            }

            // [20200220]�վ�T��//�}�ߦ��\
            String rtnMsg = MessageUtil.getMessage("EPC2_1010_UI_001");//�}�ߦ��\
            if (sucessList.size() != dataList.size()) {
                if (PRINT_CNT != null && sucessList.size() == PRINT_CNT) {
                    rtnMsg = MessageUtil.getMessage("EPC2_1010_UI_001");//�}�ߦ��\
                } else {
                    rtnMsg = MessageUtil.getMessage("EPC2_1010_UI_003", new String[] { errMsg }); //�|�������\�C�L�o���A�Ь���A���T�{
                }
            }
            MessageUtil.setMsg(msg, rtnMsg);

            if (isDebugEnable) {
                log.debug("@@@@@ doUpdate.end!!");
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�}�ߥ���", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_1010_UI_002");//�}�ߥ���
            }
        } catch (Exception e) {
            log.error("�@�~����", e);//�}�ߥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_1010_UI_002");//�}�ߥ���
        }

        return resp;
    }

    /**
     * ���-�q�l�o��:�ˮ֦C�L����
     * @param req
     * @return
     */
    public ResponseContext doPrintCntConfirm(RequestContext req) {
        try {
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));

            Integer PRINT_CNT = new Integer(FieldOptionList.getName("EP", "eInvWsForRemSetting", "PRINT_CNT"));
            if (reqList.size() > PRINT_CNT) {
                resp.addOutputData("rtnMsg", MessageUtil.getMessage("EPC2_1010_UI_005", new Integer[] { PRINT_CNT }));//���קK�q�l�o���C�L��ƹL�h�ɭP�t�β��`�A�O�_����C�L�H(�C��{0}��)
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�}�ߥ���", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_1010_UI_002");//�}�ߥ���
            }
        } catch (Exception e) {
            log.error("�@�~����", e);//�}�ߥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_1010_UI_002");//�}�ߥ���
        }

        return resp;
    }

    //[20200212] �R����streamserve�{���A�w�L�ϥ�

    /**
     * �W�߬d��
     * @param req
     * @throws ModuleException
     * @throws DBException
     */
    private void query(RequestContext req) throws ModuleException, DBException {
        Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

        List<Map> dataList = new EP_C21010().query(MapUtils.getString(reqMap, "RCV_YM"), MapUtils.getString(reqMap, "BLD_CD"), MapUtils.getString(reqMap, "PAY_KIND"), MapUtils.getString(reqMap, "INV_TYPE"), MapUtils.getString(reqMap, "BLD_USR_ID"),
            MapUtils.getString(reqMap, "SUB_CPY_ID"));
        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map rtnMap : dataList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
            logSecurityMap.put("ID", rtnMap.get("ID"));
            logSecurityList.add(logSecurityMap);
        }
        logSecurity(logSecurityList);
        resp.addOutputData("dataList", dataList);
    }

}
