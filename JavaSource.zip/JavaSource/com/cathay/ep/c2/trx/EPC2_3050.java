package com.cathay.ep.c2.trx;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.c2.module.EP_C23050;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Description Author
 * 2013/9/4     Created �\�a�s
 * UCEPC2_3050_��b���Ӫ��d�ߧ@�~
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ��b���Ӫ��d�ߧ@�~
 * �{���W��    EPC2_3050
 * �@�~�覡    ONLINE
 * ���n����    (1) �d�ߡG�̳����榡�d�߷J�`�o����
 *              (2) �U���G�U����csv����
 *              (3) �C�L�G�C�L��pdf����
 * </pre>
 * 
 * [20180306] �ק��
 * ���:�s�W�o���C���ɤU��
 * 
 * @author ����[
 * @since 2014-01-22
 */
@SuppressWarnings("unchecked")
public class EPC2_3050 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_3050.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        String SUB_CPY_ID = "";
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        try {
            SUB_CPY_ID = theEP_Z00030.getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_3050_ERRMSG_003");//���o�����q�O����
        }

        /* [20180306] ���:�s�W�o���C���ɤU��  */
        Map RPT_TYPEList = null;
        try {
            RPT_TYPEList = FieldOptionList.getFieldOptions("EPC", "RPT_TYPE");
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//�D��ؤ~���U���o���C����
                RPT_TYPEList.remove("8");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            RPT_TYPEList = Collections.EMPTY_MAP;
        }

        resp.addOutputData("RPT_TYPEList", RPT_TYPEList);
        try {
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                resp.addOutputData("CLCDVList", FieldOptionList.getFieldOptions("EPC", "CLCDV"));
            } else {
                resp.addOutputData("CLCDVList", FieldOptionList.getFieldOptions("EP", "AGT_DIV_" + SUB_CPY_ID));
            }
        } catch (ErrorInputException e) {
            log.error("���o��쥢��", e);
        }
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            BigDecimal RCV_YM = new BigDecimal(req.getParameter("RCV_YM"));
            String RPT_TYPE = req.getParameter("RPT_TYPE");
            String CLCDV = req.getParameter("CLCDV");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");

            EP_C23050 theEP_C23050 = new EP_C23050();
            if ("1".equals(RPT_TYPE)) {
                Map dataMap = theEP_C23050.queryRpt1(RCV_YM, SUB_CPY_ID);
                resp.addOutputData("rtnList", theEP_C23050.rpt1Trans2JspForm(dataMap, SUB_CPY_ID));
            } else if ("2".equals(RPT_TYPE)) {
                List<Map> rtnList = theEP_C23050.queryRpt2(RCV_YM, CLCDV, SUB_CPY_ID);//user.getDivNo());
                BigDecimal SAL_AMT = BigDecimal.ZERO;
                BigDecimal TAX_AMT = BigDecimal.ZERO;
                BigDecimal INV_AMT = BigDecimal.ZERO;
                for (Map rtnMap : rtnList) {
                    SAL_AMT = SAL_AMT.add(getBigDecimal(rtnMap.get("SAL_AMT"), BigDecimal.ZERO));
                    TAX_AMT = TAX_AMT.add(getBigDecimal(rtnMap.get("TAX_AMT"), BigDecimal.ZERO));
                    INV_AMT = INV_AMT.add(getBigDecimal(rtnMap.get("INV_AMT"), BigDecimal.ZERO));
                }
                Map TOTMap = new HashMap();
                TOTMap.put("SAL_AMT", SAL_AMT);
                TOTMap.put("TAX_AMT", TAX_AMT);
                TOTMap.put("INV_AMT", INV_AMT);
                resp.addOutputData("TOTMap", TOTMap);
                resp.addOutputData("rtnList", rtnList);
            } else if ("3".equals(RPT_TYPE)) {
                Map rtnMap = theEP_C23050.queryRpt3(RCV_YM, SUB_CPY_ID);
                List<Map> rtnList = (List<Map>) rtnMap.get("rptList");
                this.setLogSecurity(rtnList);
                resp.addOutputData("rtnList", rtnList);
                resp.addOutputData("TOTMap", rtnMap.get("TOTAL_SAL_AMT"));
            } else if ("4".equals(RPT_TYPE)) {
                List<Map> rtnList = theEP_C23050.queryRpt4(RCV_YM, CLCDV, SUB_CPY_ID);//user.getDivNo());
                BigDecimal TOT_ACNT_AMT = BigDecimal.ZERO;
                BigDecimal TOT_DACNT_AMT = BigDecimal.ZERO;
                BigDecimal TOT_BAL_AMT = BigDecimal.ZERO;
                for (Map rtnMap : rtnList) {
                    TOT_ACNT_AMT = TOT_ACNT_AMT.add(getBigDecimal(rtnMap.get("ACNT_AMT"), BigDecimal.ZERO));
                    TOT_DACNT_AMT = TOT_DACNT_AMT.add(getBigDecimal(rtnMap.get("DACNT_AMT"), BigDecimal.ZERO));
                    TOT_BAL_AMT = TOT_BAL_AMT.add(getBigDecimal(rtnMap.get("BAL_AMT"), BigDecimal.ZERO));
                }
                Map TOTMap = new HashMap();
                TOTMap.put("ACNT_AMT", TOT_ACNT_AMT);
                TOTMap.put("DACNT_AMT", TOT_DACNT_AMT);
                TOTMap.put("BAL_AMT", TOT_BAL_AMT);
                this.setLogSecurity(rtnList);
                resp.addOutputData("rtnList", rtnList);
                resp.addOutputData("TOTMap", TOTMap);
            } else if ("5".equals(RPT_TYPE)) {
                Map rtnMap = theEP_C23050.queryRpt5(RCV_YM, true, CLCDV, SUB_CPY_ID);
                if (rtnMap == null) {
                    resp.addOutputData("overSize", true);
                } else {
                    List<Map> rtnList = (List<Map>) rtnMap.get("rtnList");
                    this.setLogSecurity(rtnList);
                    resp.addOutputData("rtnList", rtnList);
                    resp.addOutputData("TOTMap", rtnMap.get("TOTMap"));
                }
            } else if ("6".equals(RPT_TYPE)) {
                Map dataMap = theEP_C23050.queryRpt6(RCV_YM, CLCDV, SUB_CPY_ID);//user.getDivNo());

                List<Map> rtnList = (List<Map>) dataMap.get("rptList");
                this.setLogSecurity(rtnList);
                resp.addOutputData("rtnList", rtnList);
                resp.addOutputData("TOTMap", dataMap.get("rptMap"));
            } else if ("7".equals(RPT_TYPE)) {

                Map dataMap = theEP_C23050.queryRpt7(RCV_YM, CLCDV, SUB_CPY_ID);//user.getDivNo());

                List<Map> rtnList = (List<Map>) dataMap.get("rptList");
                this.setLogSecurity(rtnList);
                resp.addOutputData("rtnList", rtnList);
                resp.addOutputData("TOTMap", dataMap.get("rptMap"));
            } else if ("8".equals(RPT_TYPE)) { /* [20180306] ���:�s�W�o���C���ɤU��  */
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, "EPC2_3050_ERRMSG_004");//�o���C���ɽЪ����U��!
                return resp;
            }

            MessageUtil.setMsg(msg, "MI00020");//�d�ߦ��\
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00630");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630");//�d�ߥ���
        }

        return resp;
    }

    private void setLogSecurity(List<Map> rtnList) {
        logSecurity(rtnList);
    }

    /**
     * �U��
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {

        try {
            BigDecimal RCV_YM = new BigDecimal(req.getParameter("RCV_YM"));
            String RPT_TYPE = req.getParameter("RPT_TYPE");
            String CLCDV = req.getParameter("CLCDV");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            //new EP_C23050().exportXLS(RPT_TYPE, RCV_YM, user.getDivNo(), resp, user);
            List<Map> rtnList = new EP_C23050().exportXLS(RPT_TYPE, RCV_YM, CLCDV, resp, user, SUB_CPY_ID);
            this.setLogSecurity(rtnList);
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_3050_ERRMSG_001");//�U������
            }
        } catch (Exception e) {
            log.error("�U������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_3050_ERRMSG_001");//�U������
        }
        return resp;
    }

    /**
     * �C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {

        try {
            BigDecimal RCV_YM = new BigDecimal(req.getParameter("RCV_YM"));
            String RPT_TYPE = req.getParameter("RPT_TYPE");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            EP_C23050 theEP_C23050 = new EP_C23050();

            if ("1".equals(RPT_TYPE)) {
                Map reqMap = theEP_C23050.doFmtRpt1(RCV_YM, user, SUB_CPY_ID);
                theEP_C23050.prtRpt1(reqMap, resp);
            } else if ("3".equals(RPT_TYPE)) {
                Map reqMap = theEP_C23050.doFmtRpt3(RCV_YM, user, SUB_CPY_ID);
                theEP_C23050.prtRpt3(reqMap, resp);
                this.setLogSecurity((List<Map>) reqMap.get("detail"));
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC2_3050_ERRMSG_002");//�C�L����
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC2_3050_ERRMSG_002");//�C�L����
        }
        return resp;
    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

}
