/**
 * ServiceLocator.java
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.cathay.ep.c2.eInvWsForREM;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashSet;
import java.util.Iterator;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;

import org.apache.axis.AxisFault;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.client.Service;
import org.apache.axis.client.Stub;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.cathay.common.util.FieldOptionList;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class eInvServiceLocator extends Service implements eInvService {

    private static final Logger log = Logger.getLogger(eInvServiceLocator.class);

    public eInvServiceLocator() {
        //�O�_����ws log
        String CLOSS_LOG;
        try {
            CLOSS_LOG = FieldOptionList.getName("EP", "eInvWsForRemSetting", "CLOSS_LOG");
        } catch (Exception e) {
            CLOSS_LOG = "N";
        }
        log.debug("#### CLOSS_LOG::" + CLOSS_LOG);
        if ("Y".equals(CLOSS_LOG)) {
            //����ws log
            try {
                Logger.getLogger("org.apache.axis").setLevel(Level.ERROR);
                Logger.getLogger("org.apache.axis.ConfigurationException").setLevel(Level.ERROR);
                Logger.getLogger("org.apache.axis.transport.HTTPSender").setLevel(Level.ERROR);
                Logger.getLogger("org.apache.common.beanutils.converters.AbstractConverter").setLevel(Level.ERROR);
                Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.ERROR);
                Logger.getLogger("httpclient.wire.header").setLevel(Level.ERROR);
                Logger.getLogger("httpclient.wire.content").setLevel(Level.ERROR);
                Logger.getLogger("httpclient.wire.content").setLevel(Level.ERROR);
            } catch (Throwable e) {
                log.fatal("set log option error!", e);
            }
        }
    }

    public eInvServiceLocator(EngineConfiguration config) {
        super(config);
    }

    public eInvServiceLocator(String wsdlLoc, QName sName) throws ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ServiceSoap
    //�u���γo��
    //private String ServiceSoap_address = "http://invoice.cetustek.com.tw/INVWSS/service.asmx";
    private String ServiceSoap_address = getServiceSoapAddress();

    public String getServiceSoapAddress() {
        String serviceURL = null;
        try {
            serviceURL = FieldOptionList.getName("EP", "eInvWsForRemSetting", "SERVICE_SOAP_URL");
            log.debug("�q�l�o���A�ȺݤfserviceURL: " + serviceURL);
            if (StringUtils.isEmpty(serviceURL)) {
                log.fatal("�q�l�o���A�Ⱥݤf�|���]�w[eInvWsForRemSetting.SERVICE_SOAP_URL]");
            }
        } catch (Exception e) {
            log.fatal("�q�l�o���A�Ⱥݤf�|���]�w[eInvWsForRemSetting.SERVICE_SOAP_URL]");
        }
        return serviceURL;
        //return ServiceSoap_address;
    }

    // The WSDD service name defaults to the port name.
    private String ServiceSoapWSDDServiceName = "ServiceSoap";

    public String getServiceSoapWSDDServiceName() {
        return ServiceSoapWSDDServiceName;
    }

    public void setServiceSoapWSDDServiceName(String name) {
        ServiceSoapWSDDServiceName = name;
    }

    public eInvServiceSoap_PortType getServiceSoap() throws ServiceException {
        URL endpoint;
        try {
            endpoint = new URL(ServiceSoap_address);
        } catch (MalformedURLException e) {
            throw new ServiceException(e);
        }
        return getServiceSoap(endpoint);
    }

    public eInvServiceSoap_PortType getServiceSoap(URL portAddress) throws ServiceException {
        try {
            eInvServiceSoap_BindingStub _stub = new eInvServiceSoap_BindingStub(portAddress, this);
            _stub.setPortName(getServiceSoapWSDDServiceName());
            return _stub;
        } catch (AxisFault e) {
            return null;
        } catch (Throwable t) {
            log.error("may init error....", t);
            return null;
        }
    }

    public void setServiceSoapEndpointAddress(String address) {
        ServiceSoap_address = address;
    }

    // Use to get a proxy class for ServiceSoap12
    //private String ServiceSoap12_address = "http://invoice.cetustek.com.tw/INVWSS/service.asmx";
    private String ServiceSoap12_address = getServiceSoap12Address();

    public String getServiceSoap12Address() {
        String serviceURL = FieldOptionList.getName("EP", "eInvWsForRemSetting", "SERVICE_SOAP12_URL");
        //log.debug("�q�l�o���A�Ⱥݤf(soap12)serviceURL: " + serviceURL);
        if (StringUtils.isEmpty(serviceURL)) {
            throw new RuntimeException("�q�l�o���A�Ⱥݤf�|���]�w[eInvWsForRemSetting.SERVICE_SOAP12_URL]");
        }
        return serviceURL;
        //return ServiceSoap12_address;
    }

    // The WSDD service name defaults to the port name.
    private String ServiceSoap12WSDDServiceName = "ServiceSoap12";

    public String getServiceSoap12WSDDServiceName() {
        return ServiceSoap12WSDDServiceName;
    }

    public void setServiceSoap12WSDDServiceName(String name) {
        ServiceSoap12WSDDServiceName = name;
    }

    public eInvServiceSoap_PortType getServiceSoap12() throws ServiceException {
        URL endpoint;
        try {
            endpoint = new URL(ServiceSoap12_address);
        } catch (MalformedURLException e) {
            throw new ServiceException(e);
        }
        return getServiceSoap12(endpoint);
    }

    public eInvServiceSoap_PortType getServiceSoap12(URL portAddress) throws ServiceException {
        try {
            eInvServiceSoap12Stub _stub = new eInvServiceSoap12Stub(portAddress, this);
            _stub.setPortName(getServiceSoap12WSDDServiceName());
            return _stub;
        } catch (AxisFault e) {
            return null;
        }
    }

    public void setServiceSoap12EndpointAddress(String address) {
        ServiceSoap12_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     * This service has multiple ports for a given interface;
     * the proxy implementation returned may be indeterminate.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws ServiceException {
        try {
            if (eInvServiceSoap_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                eInvServiceSoap_BindingStub _stub = new eInvServiceSoap_BindingStub(new URL(ServiceSoap_address), this);
                _stub.setPortName(getServiceSoapWSDDServiceName());
                return _stub;
            }
            if (eInvServiceSoap_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                eInvServiceSoap12Stub _stub = new eInvServiceSoap12Stub(new URL(ServiceSoap12_address), this);
                _stub.setPortName(getServiceSoap12WSDDServiceName());
                return _stub;
            }
        } catch (Throwable t) {
            throw new ServiceException(t);
        }
        throw new ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(QName portName, Class serviceEndpointInterface) throws ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        String inputPortName = portName.getLocalPart();
        if ("ServiceSoap".equals(inputPortName)) {
            return getServiceSoap();
        } else if ("ServiceSoap12".equals(inputPortName)) {
            return getServiceSoap12();
        } else {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public QName getServiceName() {
        return new QName("http://tempuri.org/", "Service");
    }

    private HashSet ports = null;

    public Iterator getPorts() {
        if (ports == null) {
            ports = new HashSet();
            ports.add(new QName("http://tempuri.org/", "ServiceSoap"));
            ports.add(new QName("http://tempuri.org/", "ServiceSoap12"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(String portName, String address) throws ServiceException {

        if ("ServiceSoap".equals(portName)) {
            setServiceSoapEndpointAddress(address);
        } else if ("ServiceSoap12".equals(portName)) {
            setServiceSoap12EndpointAddress(address);
        } else { // Unknown Port Name
            throw new ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(QName portName, String address) throws ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
