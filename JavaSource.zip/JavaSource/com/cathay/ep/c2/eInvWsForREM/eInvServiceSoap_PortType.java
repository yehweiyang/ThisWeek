/**
 * ServiceSoap_PortType.java
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.cathay.ep.c2.eInvWsForREM;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface eInvServiceSoap_PortType extends Remote {
    public String API_CreateInvoice(String data, String posid) throws RemoteException;
    public String API_CancelInvoice(String data, String posid) throws RemoteException;
    public String API_QueryInvoiceByOrderid(String data, String posid) throws RemoteException;
    public String API_PrintInvoice(String data, String posid) throws RemoteException;
    public String API_CreateAllowance(String data, String posid) throws RemoteException;
    public String API_CancelAllowance(String data, String posid) throws RemoteException;
    public String API_PrintAllowance(String data, String posid) throws RemoteException;
}
