/**
 * Service.java
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.cathay.ep.c2.eInvWsForREM;

import java.net.URL;

import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

public interface eInvService extends Service {
    public java.lang.String getServiceSoapAddress();

    public eInvServiceSoap_PortType getServiceSoap() throws ServiceException;

    public eInvServiceSoap_PortType getServiceSoap(URL portAddress) throws ServiceException;

    public String getServiceSoap12Address();

    public eInvServiceSoap_PortType getServiceSoap12() throws ServiceException;

    public eInvServiceSoap_PortType getServiceSoap12(URL portAddress) throws ServiceException;
}
