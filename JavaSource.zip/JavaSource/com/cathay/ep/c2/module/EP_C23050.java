package com.cathay.ep.c2.module;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.dd.b0.module.DD_B0Z018;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.RptUtils;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2013/8/28   1.0 �s�W  �\�a�s
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ��b���Ӫ��d�߼Ҳ�
 * �{���W��    EP_C23050
 * ���n����    �qC202�o���ɾ�X�d�߸��
 * </pre>
 * 
 * 
 * [2018-01-24] �ק��
 * ��ؾɤJ�G�Ϥ�call DK �Ҳ�
 * 
 * [2018-03-02]�ק��
 * ���: �o���C����
 * 
 * [2018-07-12]�ק�� 
 * ���(���D��:20180712-0057): �o���C���ɰ��D�վ�
 * 
 * @author ù�ΫT 
 * @since 2014/1/17
 * [2019.03.29]�H��PMD�W�h�{���ץ�[���D��s��201903130011]SQL �R�W�W�h���~ 'com.cathay.ep.c3.module.EP_C30040.SQL_updateChkInfo_002'
 */
@SuppressWarnings({ "unchecked", "rawtypes", "static-access" })
public class EP_C23050 {
    private static final Logger log = Logger.getLogger(EP_C23050.class);

    private static final String SQL_queryRpt1_001 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt1_001";

    private static final String SQL_queryRpt1_002 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt1_002";

    //private static final String SQL_queryRpt1_003 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt1_003";

    //private static final String SQL_queryRpt1_004 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt1_004";

    private static final String SQL_queryRpt2_001 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt2_001";

    private static final String SQL_queryRpt3_001 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt3_001";

    private static final String SQL_queryRpt4_001 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt4_001";

    private static final String SQL_queryRpt4_002 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt4_002";

    private static final String SQL_queryRpt5_001 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt5_001";

    private static final String SQL_queryRpt6_001 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt6_001";

    private static final String SQL_queryRpt6_002 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt6_002";

    private static final String SQL_queryRpt7_001 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt7_001";

    private static final String SQL_queryRpt7_002 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt7_002";

    private static final String SQL_queryRpt8_001 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt8_001";

    private static final String SQL_queryRpt4_003 = "com.cathay.ep.c2.module.EP_C23050.SQL_queryRpt4_003";

    //[2019.03.29]�H��PMD�W�h�{���ץ��GSQL �R�W�W�h���~ 'com.cathay.ep.c3.module.EP_C30040.SQL_updateChkInfo_002'
    //private static final String SQL_updateChkInfo_002 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateChkInfo_002";

    /**
     * �d��b���Ӫ����
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @return �����θ��
     * @throws ModuleException
     * @throws SQLException
     */
    public Map queryRpt1(BigDecimal YEAR_MONTH, String SUB_CPY_ID) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (YEAR_MONTH == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (eie != null) {
            throw eie;
        }

        Map PIN_NAMEmap = new HashMap();
        /* ��ؾɤJ�G�Ϥ�call DK�Ҳ� */
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {
            List<Map> PIN_CODE_LIST = new DD_B0Z018().queryDtddb070("");//�~�W�N�X/����
            for (Map mp : PIN_CODE_LIST) {
                PIN_NAMEmap.put(MapUtils.getString(mp, "PIN_CODE", ""), MapUtils.getString(mp, "PIN_NAME", ""));
            }
        } else {
            PIN_NAMEmap = FieldOptionList.getFieldOptions("EP", "PIN_CODE");
        }

        //�W�b�����M�� �V �D�j��
        DataSet ds = Transaction.getDataSet();
        ds.setField("YEAR_MONTH", YEAR_MONTH);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rptList = VOTool.findToMaps(ds, SQL_queryRpt1_001, false);
        if (rptList == null) {
            rptList = new ArrayList<Map>();
        } else {
            for (Map mp : rptList) {
                mp.put("PIN_NAME", PIN_NAMEmap.get(MapUtils.getString(mp, "PIN_CODE", "")));
            }
        }
        ds.clear();
        ds.setField("YEAR_MONTH", YEAR_MONTH);
        //20190703���D��s�� 20190703-0092  
        //��ر��v���ʲ��޲z�t�ξɤJ�ɡA�s�Wú�ں���"8�X�����a"�C�b�j�Ӧ����v�@�~(�p��w�P����)�ι�b���Ӫ��ɥ��Nú�ں���"8�X�����a"�����B��i�h�C
        ds.setFieldValues("PAY_KIND_1", new String[] { "1", "4", "5", "7", "8" });
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //�U�b�����M�� �V�j��-����
        List<Map> rptList1 = VOTool.findToMaps(ds, SQL_queryRpt1_002, false);
        if (rptList1 == null) {
            rptList1 = new ArrayList<Map>();
        }
        ds.clear();
        ds.setField("YEAR_MONTH", YEAR_MONTH);
        ds.setField("PAY_KIND_2", "2");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //�U�b�����M�� �V�j��-�㯲��
        List<Map> rptList2 = VOTool.findToMaps(ds, SQL_queryRpt1_002, false);
        if (rptList2 == null) {
            rptList2 = new ArrayList<Map>();
        }
        ds.clear();
        ds.setField("YEAR_MONTH", YEAR_MONTH);
        ds.setField("PAY_KIND_3", "3");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //�U�b�����M�� �V�j��-�޲z�O
        List<Map> rptList3 = VOTool.findToMaps(ds, SQL_queryRpt1_002, false);
        if (rptList3 == null) {
            rptList3 = new ArrayList<Map>();
        }
        //�����N�X�त��
        DivData dd = new DivData();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        for (Map tempMap : rptList1) {
            tempMap.put("DIV_NAME", this.getDivName(SUB_CPY_ID, MapUtils.getString(tempMap, "DIV_NO"), theEP_Z00030, dd));
            tempMap.put("PIN_NAME", this.getDivName(SUB_CPY_ID, MapUtils.getString(tempMap, "DIV_NO"), theEP_Z00030, dd));
        }
        for (Map tempMap : rptList2) {
            tempMap.put("DIV_NAME", this.getDivName(SUB_CPY_ID, MapUtils.getString(tempMap, "DIV_NO"), theEP_Z00030, dd));
            tempMap.put("PIN_NAME", this.getDivName(SUB_CPY_ID, MapUtils.getString(tempMap, "DIV_NO"), theEP_Z00030, dd));
        }
        for (Map tempMap : rptList3) {
            tempMap.put("DIV_NAME", this.getDivName(SUB_CPY_ID, MapUtils.getString(tempMap, "DIV_NO"), theEP_Z00030, dd));
            tempMap.put("PIN_NAME", this.getDivName(SUB_CPY_ID, MapUtils.getString(tempMap, "DIV_NO"), theEP_Z00030, dd));
        }

        Map rtnMap = new HashMap();
        rtnMap.put("rptList", rptList);
        rtnMap.put("rptList1", rptList1);
        rtnMap.put("rptList2", rptList2);
        rtnMap.put("rptList3", rptList3);
        return rtnMap;
    }

    /**
     * ����1����নJSP�Ϊ��榡
     * @param rtnMap �������
     * @return �e����ܥ�list
     * @throws ErrorInputException 
     */
    public List<Map> rpt1Trans2JspForm(Map rtnMap, String SUB_CPY_ID) throws ErrorInputException {
        //�W�b�����M�� �V �D�j��
        List<Map> rptList = (List<Map>) rtnMap.get("rptList");
        //�U�b�����M�� �V�j��-����
        List<Map> rptList1 = (List<Map>) rtnMap.get("rptList1");
        //�U�b�����M�� �V�j��-�㯲��
        List<Map> rptList2 = (List<Map>) rtnMap.get("rptList2");
        //�U�b�����M�� �V�j��-�޲z�O
        List<Map> rptList3 = (List<Map>) rtnMap.get("rptList3");

        //�[�`
        Map sumRpt1 = new HashMap();//����
        sumRpt1.put("PIN_NAME", MessageUtil.getMessage("EP_C23050_MSG_RENT_SUBTOTAL"));//�������J�p�p
        Map sumRpt2 = new HashMap();//�㯲��
        sumRpt2.put("PIN_NAME", MessageUtil.getMessage("EP_C23050_MSG_DEPOSIT_SUBTOTAL"));//�㯲�����J�p�p
        Map sumRpt3 = new HashMap();//�޲z�O
        sumRpt3.put("PIN_NAME", MessageUtil.getMessage("EP_C23050_MSG_FEE_SUBTOTAL"));//�޲z�O���J�p�p
        Map sumRptB = new HashMap();//�U�b��
        Map sumRptTOTAL = new HashMap();//����
        sumRptTOTAL.put("PIN_NAME", MessageUtil.getMessage("EP_C23050_MSG_TOTAL"));//�X�p

        for (Map tempMap : rptList) {
            sumRpt1Map(sumRptTOTAL, tempMap);
        }
        for (Map tempMap : rptList1) {
            sumRpt1Map(sumRptTOTAL, tempMap);
            sumRpt1Map(sumRptB, tempMap);
            sumRpt1Map(sumRpt1, tempMap);
        }
        for (Map tempMap : rptList2) {
            sumRpt1Map(sumRptTOTAL, tempMap);
            sumRpt1Map(sumRptB, tempMap);
            sumRpt1Map(sumRpt2, tempMap);
        }
        for (Map tempMap : rptList3) {
            sumRpt1Map(sumRptTOTAL, tempMap);
            sumRpt1Map(sumRptB, tempMap);
            sumRpt1Map(sumRpt3, tempMap);
        }

        boolean isAccountSubCpy = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);
        //�X�ָ��
        List<Map> finalList = new ArrayList<Map>();
        finalList.addAll(rptList);//�W�b���M��:����
        if (isAccountSubCpy) {//�D��ؤ�����ܦU������
            finalList.add(sumRptB);//�U�b���X�p
            finalList.addAll(rptList1);//����
        }
        finalList.add(sumRpt1);//�����p�p
        if (isAccountSubCpy) {//�D��ؤ�����ܦU������
            finalList.addAll(rptList2);//�㯲��
        }
        finalList.add(sumRpt2);//�㯲���p�p
        if (isAccountSubCpy) {//�D��ؤ�����ܦU������
            finalList.addAll(rptList3);//�޲z�O
        }
        finalList.add(sumRpt3);//�޲z�O�p�p
        finalList.add(sumRptTOTAL);//�X�p
        return finalList;
    }

    /**
     * ����1��ƥ[�`��
     * @param sumMap �X�pMap
     * @param tempMap ���Map
     */
    public void sumRpt1Map(Map sumMap, Map tempMap) {
        String[] keyArr = { "SAL_AMT3", "SAL_AMT2", "SAL_AMT_SUM", "SAL_AMT_NOTAX", "TAX_AMT3", "TAX_AMT2", "TAX_AMT_SUM", "INV_AMT" };

        for (String key : keyArr) {
            BigDecimal sumBD = getBigDecimal(sumMap.get(key));
            sumMap.put(key, sumBD.add(getBigDecimal(tempMap.get(key))));
        }
    }

    /**
     * ��z��b���Ӫ��������榡
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @return �����ΰѼ�
     * @throws SQLException 
     */
    public Map doFmtRpt1(BigDecimal YEAR_MONTH, UserObject user, String SUB_CPY_ID) throws ModuleException, SQLException {
        if (YEAR_MONTH == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //�d���
        Map rtnMap = queryRpt1(YEAR_MONTH, SUB_CPY_ID);
        //�W�b�����M�� �V �D�j��
        List<Map> rptList = (List) rtnMap.get("rptList");
        //�U�b�����M�� �V�j��-����
        List<Map> rptList1 = (List) rtnMap.get("rptList1");
        //�U�b�����M�� �V�j��-�㯲��
        List<Map> rptList2 = (List) rtnMap.get("rptList2");
        //�U�b�����M�� �V�j��-�޲z�O
        List<Map> rptList3 = (List) rtnMap.get("rptList3");

        Map<String, Object> totalAmtMap = new HashMap<String, Object>();
        totalAmtMap.put("SAL_AMT3", BigDecimal.ZERO);//�T�p��
        totalAmtMap.put("SAL_AMT2", BigDecimal.ZERO);//�G�p��
        totalAmtMap.put("SAL_AMT_SUM", BigDecimal.ZERO);//�p�p(�t�K�|)
        totalAmtMap.put("SAL_AMT_NOTAX", BigDecimal.ZERO);//�K�|���B
        totalAmtMap.put("TAX_AMT3", BigDecimal.ZERO);//�|�B-�T�p��
        totalAmtMap.put("TAX_AMT2", BigDecimal.ZERO);//�|�B-�G�p��
        totalAmtMap.put("TAX_AMT_SUM", BigDecimal.ZERO);//�|�B-�p�p
        totalAmtMap.put("INV_AMT", BigDecimal.ZERO);//�X�p
        totalAmtMap.put("HAS_SUB", "N");//(�s��key)N:���ݭn���Ӥp�p,�u��ܦX�p
        totalAmtMap.put("NEED_PRINT", "Y");
        totalAmtMap.put("PIN_CODE", "");
        totalAmtMap.put("PIN_NAME", MessageUtil.getMessage("EP_C23050_MSG_TOTAL"));//�X�p

        boolean isAccountSubCpy = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);
        //�j�ӯ������J+�j�ө㯲�����J+�j�Ӻ޲z�O
        doFmtRpt1_AddSubTotal(rptList1, totalAmtMap, isAccountSubCpy);
        doFmtRpt1_AddSubTotal(rptList2, totalAmtMap, isAccountSubCpy);
        doFmtRpt1_AddSubTotal(rptList3, totalAmtMap, isAccountSubCpy);

        //�W�b�����M�� �V �D�j��
        Map<String, Object> sumRantAndIntAndFeeMap = new HashMap<String, Object>();
        sumRantAndIntAndFeeMap.put("SAL_AMT3", totalAmtMap.get("SAL_AMT3"));
        sumRantAndIntAndFeeMap.put("SAL_AMT2", totalAmtMap.get("SAL_AMT2"));
        sumRantAndIntAndFeeMap.put("SAL_AMT_SUM", totalAmtMap.get("SAL_AMT_SUM"));
        sumRantAndIntAndFeeMap.put("SAL_AMT_NOTAX", totalAmtMap.get("SAL_AMT_NOTAX"));
        sumRantAndIntAndFeeMap.put("TAX_AMT3", totalAmtMap.get("TAX_AMT3"));
        sumRantAndIntAndFeeMap.put("TAX_AMT2", totalAmtMap.get("TAX_AMT2"));
        sumRantAndIntAndFeeMap.put("TAX_AMT_SUM", totalAmtMap.get("TAX_AMT_SUM"));
        sumRantAndIntAndFeeMap.put("INV_AMT", totalAmtMap.get("INV_AMT"));
        sumRantAndIntAndFeeMap.put("PIN_CODE", "");
        sumRantAndIntAndFeeMap.put("PIN_NAME", "");
        sumRantAndIntAndFeeMap.put("HAS_SUB", "Y");//(�s��key)Y:�ݭn���Ӥp�p
        sumRantAndIntAndFeeMap.put("NEED_PRINT", isAccountSubCpy ? "Y" : "N");//��ؤ����L����

        //�j�ӯ������J+�j�ө㯲�����J+�j�Ӻ޲z�O+�D�j��
        doFmtRpt1_AddSubTotal(rptList, totalAmtMap, isAccountSubCpy);

        //Add the 'D' part.
        if (rptList.size() > 0) {
            //Because of rptList is including sub total, and we have to remove it.
            rptList.remove(rptList.size() - 1);
        }
        rptList.add(sumRantAndIntAndFeeMap);
        rptList.add(totalAmtMap);

        //convert to String
        LocaleDisplay LD = new LocaleDisplay("EP", user);
        convertString(rptList, LD);
        convertString(rptList1, LD);
        convertString(rptList2, LD);
        convertString(rptList3, LD);

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("REPORT_ID", "EP_C23050_1");
        param.put("PRINT_DATE", LD.formatDate(DATE.today(), "/", ""));//�C�L���
        param.put("isAccountSubCpy", isAccountSubCpy ? "Y" : "N");//�O�_���

        param.put("YEAR_MONTH", LD.formatDateym(YEAR_MONTH, ""));//��Ʀ~��
        Map<String, Object> subparam_1 = new HashMap<String, Object>();
        subparam_1.put("REPORT_ID", "EP_C23050_1_1");
        Map<String, Object> subparam_2 = new HashMap<String, Object>();
        subparam_2.put("REPORT_ID", "EP_C23050_1_2");
        Map<String, Object> subparam_3 = new HashMap<String, Object>();
        subparam_3.put("REPORT_ID", "EP_C23050_1_3");

        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("detail", rptList);
        resultMap.put("detail_1", rptList1);
        resultMap.put("detail_2", rptList2);
        resultMap.put("detail_3", rptList3);
        resultMap.put("params", param);
        resultMap.put("params_1", subparam_1);
        resultMap.put("params_2", subparam_2);
        resultMap.put("params_3", subparam_3);

        return resultMap;
    }

    /**
     * �C�L��b���Ӫ���k
     * @param reqMap
     * @param resp
     */
    public void prtRpt1(Map reqMap, ResponseContext resp) {
        JasperReportUtils.addOutputRptDataToResp(
            new String[] { "EP_C23050_01", "EP_C23050_1_1", "EP_C23050_1_2", "EP_C23050_1_3" },
            new Map[] { (Map) reqMap.get("params"), (Map) reqMap.get("params_1"), (Map) reqMap.get("params_2"),
                    (Map) reqMap.get("params_3") },
            new List[] { (List) reqMap.get("detail"), (List) reqMap.get("detail_1"), (List) reqMap.get("detail_2"),
                    (List) reqMap.get("detail_3") }, resp);
    }

    /**
     * �d�j�ө��Ӫ����
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @param DIV_NO �ӿ��O
     * @return �����θ��
     * @throws ModuleException 
     */
    public List<Map> queryRpt2(BigDecimal YEAR_MONTH, String DIV_NO, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (YEAR_MONTH == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        //        if (StringUtils.isBlank(DIV_NO)) {
        //            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23050_ERRMSG_002"));//�ӿ��O���i����
        //        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("YEAR_MONTH", YEAR_MONTH);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setFieldIfExist(ds, "DIV_NO", DIV_NO);

        return VOTool.findToMaps(ds, SQL_queryRpt2_001);
    }

    /**
     * �d�K�|���Ӫ����
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @return �����θ��
     * @throws ModuleException
     * @throws SQLException
     */
    public Map queryRpt3(BigDecimal YEAR_MONTH, String SUB_CPY_ID) throws ModuleException, SQLException {
        if (YEAR_MONTH == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("YEAR_MONTH", YEAR_MONTH);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rptList = VOTool.findToMaps(ds, SQL_queryRpt3_001);

        String oldPayKindDivNo = rptList.size() > 0 ? MapUtils.getString((Map) rptList.get(0), "PAY_KIND")
                + MapUtils.getString((Map) rptList.get(0), "DIV_NO") : null;
        BigDecimal TOTAL_SAL_AMT = BigDecimal.ZERO;//All data
        BigDecimal SUM_SAL_AMT = BigDecimal.ZERO;//every group
        Map<String, Object> subTotalMap = new HashMap<String, Object>();

        //�����N�X, PAY_KIND�त��
        DivData dd = new DivData();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        Map<String, String> DNMap = new HashMap<String, String>();
        Map<String, String> PNMap = new HashMap<String, String>();
        for (Map tempMap : rptList) {
            String _DIV_NO = MapUtils.getString(tempMap, "DIV_NO");
            String DIV_NAME = MapUtils.getString(DNMap, _DIV_NO);
            if (StringUtils.isEmpty(DIV_NAME)) {
                DIV_NAME = this.getDivName(SUB_CPY_ID, _DIV_NO, theEP_Z00030, dd);
                tempMap.put("DIV_NAME", DIV_NAME);
                DNMap.put(_DIV_NO, DIV_NAME);
            } else {
                tempMap.put("DIV_NAME", DIV_NAME);
            }

            String _PAY_KIND = MapUtils.getString(tempMap, "PAY_KIND");
            String PAY_KIND_NM = MapUtils.getString(PNMap, _PAY_KIND);
            if (StringUtils.isEmpty(PAY_KIND_NM)) {
                PAY_KIND_NM = FieldOptionList.getName("EPC", "PAY_KIND", _PAY_KIND);
                tempMap.put("PAY_KIND_NM", PAY_KIND_NM);
                DNMap.put(_PAY_KIND, PAY_KIND_NM);
            } else {
                tempMap.put("PAY_KIND_NM", PAY_KIND_NM);
            }

            ///���s
            String PAY_KIND = MapUtils.getString(tempMap, "PAY_KIND");
            String DIV_NO = MapUtils.getString(tempMap, "DIV_NO");

            if (!oldPayKindDivNo.equals(PAY_KIND + DIV_NO)) {
                TOTAL_SAL_AMT = TOTAL_SAL_AMT.add(getBigDecimal(subTotalMap.get("SUM_SAL_AMT")));
                oldPayKindDivNo = PAY_KIND + DIV_NO;
                SUM_SAL_AMT = BigDecimal.ZERO;
            }

            SUM_SAL_AMT = SUM_SAL_AMT.add(getBigDecimal(tempMap.get("SAL_AMT")));
            tempMap.put("SUM_SAL_AMT", SUM_SAL_AMT);
            subTotalMap = tempMap;

        }
        TOTAL_SAL_AMT = TOTAL_SAL_AMT.add(getBigDecimal(subTotalMap.get("SUM_SAL_AMT")));

        Map rtnMap = new HashMap();
        rtnMap.put("rptList", rptList);
        rtnMap.put("TOTAL_SAL_AMT", TOTAL_SAL_AMT);

        return rtnMap;
    }

    /**
     * 1.�d�K�|���Ӫ����
     * 2.�]���D�{���Ppdf�����@��, �֪O�|���ۼv�T, 
     *   �ҥH��W���������pdf�M�Τ�k 2014/02/05
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @return �����θ��
     * @throws ModuleException
     * @throws SQLException
     */
    public Map queryRpt3ForPdf(BigDecimal YEAR_MONTH, String SUB_CPY_ID) throws ModuleException, SQLException {
        if (YEAR_MONTH == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("YEAR_MONTH", YEAR_MONTH);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rptList = VOTool.findToMaps(ds, SQL_queryRpt3_001);

        String oldPayKindDivNo = rptList.size() > 0 ? MapUtils.getString((Map) rptList.get(0), "PAY_KIND")
                + MapUtils.getString((Map) rptList.get(0), "DIV_NO") : null;

        BigDecimal TOTAL_SAL_AMT = BigDecimal.ZERO;//All data
        BigDecimal SUM_SAL_AMT = BigDecimal.ZERO;//every group
        Map<String, Object> subTotalMap = new HashMap<String, Object>();

        //�����N�X, PAY_KIND�त��
        DivData dd = new DivData();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        Map<String, String> DNMap = new HashMap<String, String>();
        Map<String, String> PNMap = new HashMap<String, String>();
        for (Map tempMap : rptList) {
            String _DIV_NO = MapUtils.getString(tempMap, "DIV_NO");
            String DIV_NAME = MapUtils.getString(DNMap, _DIV_NO);
            if (StringUtils.isEmpty(DIV_NAME)) {
                DIV_NAME = this.getDivName(SUB_CPY_ID, _DIV_NO, theEP_Z00030, dd);
                tempMap.put("DIV_NAME", DIV_NAME);
                DNMap.put(_DIV_NO, DIV_NAME);
            } else {
                tempMap.put("DIV_NAME", DIV_NAME);
            }

            String _PAY_KIND = MapUtils.getString(tempMap, "PAY_KIND");
            String PAY_KIND_NM = MapUtils.getString(PNMap, _PAY_KIND);
            if (StringUtils.isEmpty(PAY_KIND_NM)) {
                PAY_KIND_NM = FieldOptionList.getName("EPC", "PAY_KIND", _PAY_KIND);
                tempMap.put("PAY_KIND_NM", PAY_KIND_NM);
                DNMap.put(_PAY_KIND, PAY_KIND_NM);
            } else {
                tempMap.put("PAY_KIND_NM", PAY_KIND_NM);
            }

            ///���s
            String PAY_KIND = MapUtils.getString(tempMap, "PAY_KIND");
            String DIV_NO = MapUtils.getString(tempMap, "DIV_NO");

            if (!oldPayKindDivNo.equals(PAY_KIND + DIV_NO)) {
                TOTAL_SAL_AMT = TOTAL_SAL_AMT.add(getBigDecimal(subTotalMap.get("SUM_SAL_AMT")));
                oldPayKindDivNo = PAY_KIND + DIV_NO;
                SUM_SAL_AMT = BigDecimal.ZERO;
            }

            SUM_SAL_AMT = SUM_SAL_AMT.add(getBigDecimal(tempMap.get("SAL_AMT")));
            tempMap.put("SUM_SAL_AMT", SUM_SAL_AMT);
            subTotalMap = tempMap;

        }
        TOTAL_SAL_AMT = TOTAL_SAL_AMT.add(getBigDecimal(subTotalMap.get("SUM_SAL_AMT")));

        Map rtnMap = new HashMap();
        rtnMap.put("rptList", rptList);
        rtnMap.put("TOTAL_SAL_AMT", TOTAL_SAL_AMT);

        return rtnMap;

    }

    /**
     * ��z�K�|���Ӫ������榡
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @return �����ΰѼ�
     * @throws ModuleException
     * @throws SQLException
     */
    public Map doFmtRpt3(BigDecimal YEAR_MONTH, UserObject user, String SUB_CPY_ID) throws ModuleException, SQLException {

        if (YEAR_MONTH == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        List<Map> rptList = (List) queryRpt3ForPdf(YEAR_MONTH, SUB_CPY_ID).get("rptList");
        String oldPayKindDivNo = rptList.size() > 0 ? MapUtils.getString((Map) rptList.get(0), "PAY_KIND")
                + MapUtils.getString((Map) rptList.get(0), "DIV_NO") : "";
        BigDecimal TOTAL_SAL_AMT = BigDecimal.ZERO;//All data
        BigDecimal SUM_SAL_AMT = BigDecimal.ZERO;//every group
        Map<String, Object> subTotalMap = new HashMap<String, Object>();
        for (Map dataMap : rptList) {
            String PAY_KIND = MapUtils.getString(dataMap, "PAY_KIND");
            String DIV_NO = MapUtils.getString(dataMap, "DIV_NO");

            if (!oldPayKindDivNo.equals(PAY_KIND + DIV_NO)) {
                TOTAL_SAL_AMT = TOTAL_SAL_AMT.add(getBigDecimal(subTotalMap.get("SUM_SAL_AMT")));
                oldPayKindDivNo = PAY_KIND + DIV_NO;
                SUM_SAL_AMT = BigDecimal.ZERO;
            }

            SUM_SAL_AMT = SUM_SAL_AMT.add(getBigDecimal(dataMap.get("SAL_AMT")));
            dataMap.put("SUM_SAL_AMT", SUM_SAL_AMT);
            subTotalMap = dataMap;
        }
        TOTAL_SAL_AMT = TOTAL_SAL_AMT.add(getBigDecimal(subTotalMap.get("SUM_SAL_AMT")));
        LocaleDisplay LD = new LocaleDisplay("EP", user);
        convertString(rptList, LD);//To convert all data to String format.
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("TOTAL_SAL_AMT", LD.formatNumber(TOTAL_SAL_AMT, 0, ""));
        param.put("REPORT_ID", "EP_C23050_03");
        param.put("PRINT_DATE", LD.formatDate(DATE.today(), "/", ""));//�C�L���
        param.put("YEAR_MONTH", LD.formatDateym(YEAR_MONTH, ""));//�o���~��
        Map<String, Object> rtnMap = new HashMap<String, Object>();
        rtnMap.put("detail", rptList);
        rtnMap.put("params", param);

        return rtnMap;
    }

    /**
     * �C�L�K�|���Ӥ�k
     * @param reqMap
     * @param resp
     */
    public void prtRpt3(Map reqMap, ResponseContext resp) {
        JasperReportUtils.addOutputRptDataToResp("EP_C23050_03", (Map) reqMap.get("params"), (List) reqMap.get("detail"), resp);
    }

    /**
     * �d�Ȧ��l�B�����
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @param DIV_NO �ӿ��O
     * @return �����θ��
     * @throws ModuleException
     * @throws SQLException
     * @throws DBException 
     */
    public List<Map> queryRpt4(BigDecimal YEAR_MONTH, String DIV_NO, String SUB_CPY_ID) throws ModuleException, SQLException, DBException {
        if (YEAR_MONTH == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        Date INPUT_DATE = Date.valueOf(DATE.addDate(DATE.getDBDate(YEAR_MONTH.toString() + "01"), 0, 1, 0));//�U�Ӥ�1��
        BatchQueryDataSet bqds = null;
        List<Map> rptList = new ArrayList<Map>();

        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            String SUB_ACNT_CODE = "";
            if ("8300100".equals(DIV_NO)) {
                SUB_ACNT_CODE = "17002";
            } else if ("8300200".equals(DIV_NO)) {
                SUB_ACNT_CODE = "17003";
            }
            setFieldIfExist(bqds, "SUB_ACNT_CODE", SUB_ACNT_CODE);
            bqds.setField("INPUT_DATE", INPUT_DATE);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            /* [20180302] �[�P�_��  */
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                bqds.searchAndRetrieve(SQL_queryRpt4_001);//�]�w�d��SQL
            } else {
                bqds.searchAndRetrieve(SQL_queryRpt4_002);
            }

            int groupCount = 2000;//�C�妸�d��2000�����
            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��
            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map map = VOTool.dataSetToMap(bqds);
                    rptList.add(map);
                }
            }

        } finally {
            if (bqds != null) {
                bqds.close();//�����妸�d�߳s�u
            }
        }

        if (rptList.size() == 0) {
            throw new DataNotFoundException("�d�L���");
        }
        DataSet ds = Transaction.getDataSet();
        //����त��
        DivData dd = new DivData();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        for (Map tempMap : rptList) {
            ds.clear();
            ds.setField("CHK_SET_NO", MapUtils.getString(tempMap, "CHK_SET_NO"));
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            //[2019.03.29]�H��PMD�W�h�{���ץ��GSQL �R�W�W�h���~ 'com.cathay.ep.c3.module.EP_C30040.SQL_updateChkInfo_002'
            //Map CHK_INFO = VOTool.findOneToMap(ds, SQL_updateChkInfo_002, false);
            Map CHK_INFO = VOTool.findOneToMap(ds, SQL_queryRpt4_003, false);
            tempMap.put("CHK_DATE", MapUtils.getString(CHK_INFO, "CHK_DATE", ""));
            tempMap.put("DIV_NAME", this.getDivName(SUB_CPY_ID, MapUtils.getString(tempMap, "DIV_NO"), theEP_Z00030, dd));
        }

        return rptList;
    }

    /**
     * �d�����l�B�����
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @return �����θ��
     * @throws ModuleException
     * @throws SQLException
     * @throws DBException 
     */
    public Map queryRpt5(BigDecimal YEAR_MONTH, boolean isQuery, String CLCDV, String SUB_CPY_ID) throws ModuleException, SQLException,
            DBException {
        if (YEAR_MONTH == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        Date INPUT_DATE = Date.valueOf(DATE.addDate(DATE.getDBDate(YEAR_MONTH.toString() + "01"), 0, 1, 0));//�U�Ӥ�1��

        BatchQueryDataSet bqds = null;
        List<Map> rptList = new ArrayList<Map>();
        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            bqds.setField("YEAR_MONTH", YEAR_MONTH);
            bqds.setField("INPUT_DATE", INPUT_DATE);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            setFieldIfExist(bqds, "DIV_NO", CLCDV);
            bqds.searchAndRetrieve(SQL_queryRpt5_001);//�]�w�d��SQL
            int groupCount = 2000;//�C�妸�d��2000�����
            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��
            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map map = VOTool.dataSetToMap(bqds);
                    rptList.add(map);
                }
            }
        } finally {
            if (bqds != null) {
                bqds.close();//�����妸�d�߳s�u
            }
        }

        if (rptList.size() == 0) {
            throw new DataNotFoundException("�d�L���");
        }

        if (isQuery) {
            if (rptList.size() > 100) {
                return null;
            }
        }

        //����त��
        DivData dd = new DivData();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        Map<String, String> DNMap = new HashMap<String, String>();

        BigDecimal TOT_INV_AMT = BigDecimal.ZERO;
        BigDecimal TOT_SPR_AMT = BigDecimal.ZERO;
        BigDecimal TOT_PAY_AMT = BigDecimal.ZERO;
        String DIV_NO = null;
        BigDecimal SUB_INV_AMT = null;
        BigDecimal SUB_SPR_AMT = null;
        BigDecimal SUB_PAY_AMT = null;
        List<Map> groupList = new ArrayList<Map>();
        List dataList = new ArrayList();
        for (Map tempMap : rptList) {
            String DIV_NO_map = MapUtils.getString(tempMap, "DIV_NO");

            String DIV_NAME = MapUtils.getString(DNMap, DIV_NO);
            if (StringUtils.isEmpty(DIV_NAME)) {
                DIV_NAME = this.getDivName(SUB_CPY_ID, DIV_NO, theEP_Z00030, dd);
                tempMap.put("DIV_NAME", DIV_NAME);
                DNMap.put(DIV_NO, DIV_NAME);
            } else {
                tempMap.put("DIV_NAME", DIV_NAME);
            }

            //���s
            if (!DIV_NO_map.equals(DIV_NO)) {
                if (DIV_NO != null) {
                    Map subMap = new HashMap();
                    subMap.put("DIV_NO", DIV_NO);
                    subMap.put("INV_AMT", SUB_INV_AMT);
                    subMap.put("SPR_AMT", SUB_SPR_AMT);
                    subMap.put("PAY_AMT", SUB_PAY_AMT);
                    groupList.add(subMap);
                    dataList.add(groupList);
                }
                SUB_INV_AMT = getBigDecimal(tempMap.get("INV_AMT"));
                SUB_SPR_AMT = getBigDecimal(tempMap.get("SPR_AMT"));
                SUB_PAY_AMT = getBigDecimal(tempMap.get("PAY_AMT"));
                DIV_NO = DIV_NO_map;
                groupList = new ArrayList<Map>();
                groupList.add(tempMap);
            } else {
                SUB_INV_AMT = SUB_INV_AMT.add(getBigDecimal(tempMap.get("INV_AMT")));
                SUB_SPR_AMT = SUB_SPR_AMT.add(getBigDecimal(tempMap.get("SPR_AMT")));
                SUB_PAY_AMT = SUB_PAY_AMT.add(getBigDecimal(tempMap.get("PAY_AMT")));
                groupList.add(tempMap);
            }
            //�`�p
            TOT_INV_AMT = TOT_INV_AMT.add(getBigDecimal(tempMap.get("INV_AMT")));
            TOT_SPR_AMT = TOT_SPR_AMT.add(getBigDecimal(tempMap.get("SPR_AMT")));
            TOT_PAY_AMT = TOT_PAY_AMT.add(getBigDecimal(tempMap.get("PAY_AMT")));

        }
        Map subMap = new HashMap();
        subMap.put("DIV_NO", DIV_NO);
        subMap.put("INV_AMT", SUB_INV_AMT);
        subMap.put("SPR_AMT", SUB_SPR_AMT);
        subMap.put("PAY_AMT", SUB_PAY_AMT);
        groupList.add(subMap);
        dataList.add(groupList);

        Map TOTMap = new HashMap();
        TOTMap.put("INV_AMT", TOT_INV_AMT);
        TOTMap.put("SPR_AMT", TOT_SPR_AMT);
        TOTMap.put("PAY_AMT", TOT_PAY_AMT);

        Map rtnMap = new HashMap();
        rtnMap.put("rtnList", dataList);
        rtnMap.put("TOTMap", TOTMap);

        return rtnMap;
    }

    /**
     * 1.�d�����l�B�����
     * 2.�]���D�{���Ppdf�����@��, �֪O�|���ۼv�T, 
     *   �ҥH��W���������pdf�M�Τ�k 2014/02/05
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @return �����θ��
     * @throws ModuleException
     * @throws SQLException
     
    public Map queryRpt5ForPdf(BigDecimal YEAR_MONTH, boolean isQuery) throws ModuleException, SQLException {
        if (YEAR_MONTH == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }

        Date INPUT_DATE = Date.valueOf(DATE.addDate(DATE.getDBDate(YEAR_MONTH.toString() + "01"), 0, 1, 0));//�U�Ӥ�1��
        DataSet ds = Transaction.getDataSet();
        ds.setField("YEAR_MONTH", YEAR_MONTH);
        ds.setField("INPUT_DATE", INPUT_DATE);
        List<Map> rptList = VOTool.findToMaps(ds, SQL_queryRpt5_001);
        if (isQuery) {
            if (rptList.size() > 100) {
                return null;
            }
        }

        //����त��
        DivData dd = new DivData();
        Map<String, String> DNMap = new HashMap<String, String>();

        BigDecimal TOT_INV_AMT = BigDecimal.ZERO;
        BigDecimal TOT_SPR_AMT = BigDecimal.ZERO;
        BigDecimal TOT_PAY_AMT = BigDecimal.ZERO;
        String DIV_NO = null;
        BigDecimal SUB_INV_AMT = null;
        BigDecimal SUB_SPR_AMT = null;
        BigDecimal SUB_PAY_AMT = null;
        List<Map> groupList = null;
        List dataList = new ArrayList();
        for (Map tempMap : rptList) {
            String DIV_NO_map = MapUtils.getString(tempMap, "DIV_NO");

            String DIV_NAME = MapUtils.getString(DNMap, DIV_NO);
            if (StringUtils.isEmpty(DIV_NAME)) {
                DIV_NAME = dd.getUnit4ShortName(DIV_NO);
                tempMap.put("DIV_NAME", DIV_NAME);
                DNMap.put(DIV_NO, DIV_NAME);
            } else {
                tempMap.put("DIV_NAME", DIV_NAME);
            }

            //���s
            if (!DIV_NO_map.equals(DIV_NO)) {
                if (DIV_NO != null) {
                    Map subMap = new HashMap();
                    subMap.put("DIV_NO", DIV_NO);
                    subMap.put("INV_AMT", SUB_INV_AMT);
                    subMap.put("SPR_AMT", SUB_SPR_AMT);
                    subMap.put("PAY_AMT", SUB_PAY_AMT);
                    groupList.add(subMap);
                    dataList.add(groupList);
                }
                SUB_INV_AMT = getBigDecimal(tempMap.get("INV_AMT"));
                SUB_SPR_AMT = getBigDecimal(tempMap.get("SPR_AMT"));
                SUB_PAY_AMT = getBigDecimal(tempMap.get("PAY_AMT"));
                DIV_NO = DIV_NO_map;
                groupList = new ArrayList<Map>();
                groupList.add(tempMap);
            } else {
                SUB_INV_AMT = SUB_INV_AMT.add(getBigDecimal(tempMap.get("INV_AMT")));
                SUB_SPR_AMT = SUB_SPR_AMT.add(getBigDecimal(tempMap.get("SPR_AMT")));
                SUB_PAY_AMT = SUB_PAY_AMT.add(getBigDecimal(tempMap.get("PAY_AMT")));
                groupList.add(tempMap);
            }
            //�`�p
            TOT_INV_AMT = TOT_INV_AMT.add(getBigDecimal(tempMap.get("INV_AMT")));
            TOT_SPR_AMT = TOT_SPR_AMT.add(getBigDecimal(tempMap.get("SPR_AMT")));
            TOT_PAY_AMT = TOT_PAY_AMT.add(getBigDecimal(tempMap.get("PAY_AMT")));

        }
        Map subMap = new HashMap();
        subMap.put("DIV_NO", DIV_NO);
        subMap.put("INV_AMT", SUB_INV_AMT);
        subMap.put("SPR_AMT", SUB_SPR_AMT);
        subMap.put("PAY_AMT", SUB_PAY_AMT);
        groupList.add(subMap);
        dataList.add(groupList);

        Map TOTMap = new HashMap();
        TOTMap.put("INV_AMT", TOT_INV_AMT);
        TOTMap.put("SPR_AMT", TOT_SPR_AMT);
        TOTMap.put("PAY_AMT", TOT_PAY_AMT);

        Map rtnMap = new HashMap();
        rtnMap.put("rtnList", dataList);
        rtnMap.put("TOTMap", TOTMap);

        return rtnMap;

    }*/

    /**
     * �d���Ȧ��J�b�����
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @param DIV_NO �ӿ��O
     * @param SUB_CPY_ID �����q�O
     * @return �����θ��
     * @throws ModuleException
     * @throws SQLException
     */
    public Map queryRpt6(BigDecimal YEAR_MONTH, String DIV_NO, String SUB_CPY_ID) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (YEAR_MONTH == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //        if (StringUtils.isBlank(DIV_NO)) {
        //            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23050_ERRMSG_002"));//�ӿ��O���i����
        //        }
        if (eie != null) {
            throw eie;
        }

        Date INPUT_DATE_S = Date.valueOf(DATE.getDBDate(YEAR_MONTH.toString() + "01"));//�Ӥ�1��
        Date INPUT_DATE_E = Date.valueOf(DATE.addDate(DATE.getDBDate(YEAR_MONTH.toString() + "01"), 0, 1, 0));//�U�Ӥ�1��

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INPUT_DATE_S", INPUT_DATE_S);
        ds.setField("INPUT_DATE_E", INPUT_DATE_E);
        setFieldIfExist(ds, "DIV_NO", DIV_NO);
        List<Map> rptList = new ArrayList();
        /* [20180302] �[�P�_��  */
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            rptList = VOTool.findToMaps(ds, SQL_queryRpt6_001);
        } else {
            rptList = VOTool.findToMaps(ds, SQL_queryRpt6_002);
        }
        List group1List = new ArrayList();
        List<Map> group2List = new ArrayList<Map>();
        List dataList = new ArrayList();

        String DIV_NO_temp = null;
        String DIV_NAME = null;
        String SLIP_DATE = null;
        int count = 0;
        BigDecimal SUB2_TOT_ACNT_AMT = BigDecimal.ZERO;
        BigDecimal SUB2_TOT_BAL_AMT = BigDecimal.ZERO;

        BigDecimal SUB1_TOT_ACNT_AMT = BigDecimal.ZERO;
        BigDecimal SUB1_TOT_BAL_AMT = BigDecimal.ZERO;

        BigDecimal SUB3_TOT_ACNT_AMT = BigDecimal.ZERO;
        BigDecimal SUB3_TOT_BAL_AMT = BigDecimal.ZERO;

        //����त��
        DivData dd = new DivData();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        for (Map tempMap : rptList) {
            String DIV_NO_map = MapUtils.getString(tempMap, "DIV_NO");
            tempMap.put("DIV_NAME", this.getDivName(SUB_CPY_ID, DIV_NO_map, theEP_Z00030, dd));

            //���s
            //dataMap={ rptList : [ group1List : [ group2List : [ { dataMap } , { sub2Tot} ] , { sub1Tot } ] ] , rptMap : { rptMap } }
            String SLIP_DATE_map = MapUtils.getString(tempMap, "SLIP_DATE");
            if (!SLIP_DATE_map.equals(SLIP_DATE)) {
                if (SLIP_DATE != null) {
                    //�HSLIP_DATE���s���p�p��
                    Map sub2Tot = new HashMap();
                    sub2Tot.put("SLIP_DATE", SLIP_DATE);
                    sub2Tot.put("count", count);
                    sub2Tot.put("ACNT_AMT", SUB2_TOT_ACNT_AMT);
                    sub2Tot.put("BAL_AMT", SUB2_TOT_BAL_AMT);
                    group2List.add(sub2Tot);
                    group1List.add(group2List);
                    group2List = new ArrayList<Map>();
                }
                group2List.add(tempMap);

                SUB2_TOT_ACNT_AMT = getBigDecimal(tempMap.get("ACNT_AMT"));
                SUB2_TOT_BAL_AMT = getBigDecimal(tempMap.get("BAL_AMT"));

                count = 1;
                SLIP_DATE = SLIP_DATE_map;
            } else {
                SUB2_TOT_ACNT_AMT = SUB2_TOT_ACNT_AMT.add(getBigDecimal(tempMap.get("ACNT_AMT")));
                SUB2_TOT_BAL_AMT = SUB2_TOT_BAL_AMT.add(getBigDecimal(tempMap.get("BAL_AMT")));
                count++;
                group2List.add(tempMap);
            }

            //�HDIV_NO���s���X�p
            if (!DIV_NO_map.equals(DIV_NO_temp)) {
                if (DIV_NO_temp != null) {
                    Map sub1Tot = new HashMap();
                    sub1Tot.put("DIV_NO", DIV_NO_temp);
                    sub1Tot.put("DIV_NAME", DIV_NAME);
                    sub1Tot.put("ACNT_AMT", SUB1_TOT_ACNT_AMT);
                    sub1Tot.put("BAL_AMT", SUB1_TOT_BAL_AMT);
                    group1List.add(sub1Tot);
                    dataList.add(group1List);
                    group1List = new ArrayList();

                    SUB3_TOT_ACNT_AMT = SUB1_TOT_ACNT_AMT;
                    SUB3_TOT_BAL_AMT = SUB1_TOT_BAL_AMT;
                }

                SUB1_TOT_ACNT_AMT = getBigDecimal(tempMap.get("ACNT_AMT"));
                SUB1_TOT_BAL_AMT = getBigDecimal(tempMap.get("BAL_AMT"));

                DIV_NO_temp = DIV_NO_map;
                DIV_NAME = MapUtils.getString(tempMap, "DIV_NAME");
            } else {
                SUB1_TOT_ACNT_AMT = SUB1_TOT_ACNT_AMT.add(getBigDecimal(tempMap.get("ACNT_AMT")));
                SUB1_TOT_BAL_AMT = SUB1_TOT_BAL_AMT.add(getBigDecimal(tempMap.get("BAL_AMT")));
            }

        }

        Map sub2Tot = new HashMap();
        sub2Tot.put("SLIP_DATE", SLIP_DATE);
        sub2Tot.put("count", count);
        sub2Tot.put("ACNT_AMT", SUB2_TOT_ACNT_AMT);
        sub2Tot.put("BAL_AMT", SUB2_TOT_BAL_AMT);
        group2List.add(sub2Tot);
        group1List.add(group2List);

        Map sub1Tot = new HashMap();
        sub1Tot.put("DIV_NO", DIV_NO_temp);
        sub1Tot.put("DIV_NAME", DIV_NAME);
        sub1Tot.put("ACNT_AMT", SUB1_TOT_ACNT_AMT);
        sub1Tot.put("BAL_AMT", SUB1_TOT_BAL_AMT);
        group1List.add(sub1Tot);
        dataList.add(group1List);

        //        ds.clear();
        //        ds.setField("INPUT_DATE_S", INPUT_DATE_S);
        //        ds.setField("INPUT_DATE_E", INPUT_DATE_E);
        //        Map rptMap = VOTool.findOneToMap(ds, SQL_queryRpt6_002);

        Map rptMap = new HashMap();
        rptMap.put("ACNT_AMT", SUB1_TOT_ACNT_AMT.add(SUB3_TOT_ACNT_AMT));
        rptMap.put("BAL_AMT", SUB1_TOT_BAL_AMT.add(SUB3_TOT_BAL_AMT));

        Map dataMap = new HashMap();
        dataMap.put("rptList", dataList);
        dataMap.put("rptMap", rptMap);
        return dataMap;
    }

    /**
     * �d���Ȧ��R�b�����
     * @param YEAR_MONTH �o���~��(�褸�~)
     * @param DIV_NO �ӿ��O
     * @param SUB_CPY_ID �����q�O
     * @return �����θ��
     * @throws ModuleException
     * @throws SQLException
     */
    public Map queryRpt7(BigDecimal YEAR_MONTH, String DIV_NO, String SUB_CPY_ID) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (YEAR_MONTH == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //        if (StringUtils.isBlank(DIV_NO)) {
        //            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23050_ERRMSG_002"));//�ӿ��O���i����
        //        }
        if (eie != null) {
            throw eie;
        }

        Date INPUT_DATE_S = Date.valueOf(DATE.getDBDate(YEAR_MONTH.toString() + "01"));//�Ӥ�1��
        Date INPUT_DATE_E = Date.valueOf(DATE.addDate(DATE.getDBDate(YEAR_MONTH.toString() + "01"), 0, 1, 0));//�U�Ӥ�1��

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INPUT_DATE_S", INPUT_DATE_S);
        ds.setField("INPUT_DATE_E", INPUT_DATE_E);
        setFieldIfExist(ds, "DIV_NO", DIV_NO);
        /* [20180302] �[�P�_��  */
        List<Map> rptList = new ArrayList();
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            rptList = VOTool.findToMaps(ds, SQL_queryRpt7_001);
        } else {
            rptList = VOTool.findToMaps(ds, SQL_queryRpt7_002);
        }

        List group1List = new ArrayList();
        List<Map> group2List = new ArrayList<Map>();
        List dataList = new ArrayList();

        String DIV_NO_temp = null;
        String DIV_NAME = null;
        String SLIP_DATE = null;
        int count = 0;
        BigDecimal SUB2_TOT_DACNT_AMT_NEW = BigDecimal.ZERO;
        BigDecimal SUB2_TOT_BAL_AMT = BigDecimal.ZERO;

        BigDecimal SUB1_TOT_DACNT_AMT_NEW = BigDecimal.ZERO;
        BigDecimal SUB1_TOT_BAL_AMT = BigDecimal.ZERO;

        BigDecimal SUB3_TOT_DACNT_AMT_NEW = BigDecimal.ZERO;
        BigDecimal SUB3_TOT_BAL_AMT = BigDecimal.ZERO;

        //����त��
        DivData dd = new DivData();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        for (Map tempMap : rptList) {
            String DIV_NO_map = MapUtils.getString(tempMap, "DIV_NO");
            tempMap.put("DIV_NAME", this.getDivName(SUB_CPY_ID, DIV_NO_map, theEP_Z00030, dd));

            //���s
            //dataMap={ rptList : [ group1List : [ group2List : [ { dataMap } , { sub2Tot} ] , { sub1Tot } ] ] , rptMap : { rptMap } }
            String SLIP_DATE_map = MapUtils.getString(tempMap, "SLIP_DATE");
            if (!SLIP_DATE_map.equals(SLIP_DATE)) {

                if (SLIP_DATE != null) {
                    //�HSLIP_DATE���s���p�p��
                    Map sub2Tot = new HashMap();
                    sub2Tot.put("SLIP_DATE", SLIP_DATE);
                    sub2Tot.put("count", count);
                    sub2Tot.put("DACNT_AMT_NEW", SUB2_TOT_DACNT_AMT_NEW);
                    sub2Tot.put("BAL_AMT", SUB2_TOT_BAL_AMT);
                    group2List.add(sub2Tot);
                    group1List.add(group2List);
                    group2List = new ArrayList<Map>();
                }
                group2List.add(tempMap);

                SUB2_TOT_DACNT_AMT_NEW = getBigDecimal(tempMap.get("DACNT_AMT_NEW"));
                SUB2_TOT_BAL_AMT = getBigDecimal(tempMap.get("BAL_AMT"));

                count = 1;
                SLIP_DATE = SLIP_DATE_map;

            } else {
                SUB2_TOT_DACNT_AMT_NEW = SUB2_TOT_DACNT_AMT_NEW.add(getBigDecimal(tempMap.get("DACNT_AMT_NEW")));
                SUB2_TOT_BAL_AMT = SUB2_TOT_BAL_AMT.add(getBigDecimal(tempMap.get("BAL_AMT")));
                count++;
                group2List.add(tempMap);
            }

            //�HDIV_NO���s���X�p
            if (!DIV_NO_map.equals(DIV_NO_temp)) {
                if (DIV_NO_temp != null) {
                    Map sub1Tot = new HashMap();
                    sub1Tot.put("DIV_NO", DIV_NO_temp);
                    sub1Tot.put("DIV_NAME", DIV_NAME);
                    sub1Tot.put("DACNT_AMT_NEW", SUB1_TOT_DACNT_AMT_NEW);
                    sub1Tot.put("BAL_AMT", SUB1_TOT_BAL_AMT);
                    group1List.add(sub1Tot);
                    dataList.add(group1List);
                    group1List = new ArrayList();

                    SUB3_TOT_DACNT_AMT_NEW = SUB1_TOT_DACNT_AMT_NEW;
                    SUB3_TOT_BAL_AMT = SUB1_TOT_BAL_AMT;
                }
                SUB1_TOT_DACNT_AMT_NEW = getBigDecimal(tempMap.get("DACNT_AMT_NEW"));
                SUB1_TOT_BAL_AMT = getBigDecimal(tempMap.get("BAL_AMT"));

                DIV_NO_temp = DIV_NO_map;
                DIV_NAME = MapUtils.getString(tempMap, "DIV_NAME");
            } else {
                SUB1_TOT_DACNT_AMT_NEW = SUB1_TOT_DACNT_AMT_NEW.add(getBigDecimal(tempMap.get("DACNT_AMT_NEW")));
                SUB1_TOT_BAL_AMT = SUB1_TOT_BAL_AMT.add(getBigDecimal(tempMap.get("BAL_AMT")));
            }

        }

        Map sub2Tot = new HashMap();
        sub2Tot.put("SLIP_DATE", SLIP_DATE);
        sub2Tot.put("count", count);
        sub2Tot.put("DACNT_AMT_NEW", SUB2_TOT_DACNT_AMT_NEW);
        sub2Tot.put("BAL_AMT", SUB2_TOT_BAL_AMT);
        group2List.add(sub2Tot);
        group1List.add(group2List);

        Map sub1Tot = new HashMap();
        sub1Tot.put("DIV_NO", DIV_NO_temp);
        sub1Tot.put("DIV_NAME", DIV_NAME);
        sub1Tot.put("DACNT_AMT_NEW", SUB1_TOT_DACNT_AMT_NEW);
        sub1Tot.put("BAL_AMT", SUB1_TOT_BAL_AMT);
        group1List.add(sub1Tot);
        dataList.add(group1List);

        //Map rptMap = VOTool.findOneToMap(ds, SQL_queryRpt7_002);
        Map rptMap = new HashMap();
        rptMap.put("DACNT_AMT_NEW", SUB1_TOT_DACNT_AMT_NEW.add(SUB3_TOT_DACNT_AMT_NEW));
        rptMap.put("BAL_AMT", SUB1_TOT_BAL_AMT.add(SUB3_TOT_BAL_AMT));

        Map rtnMap = new HashMap();
        rtnMap.put("rptList", dataList);
        rtnMap.put("rptMap", rptMap);
        return rtnMap;
    }

    /**
     * (�D���)�o���C���ɤU�� [20180302]
     * @param YEAR_MONTH
     * @param DIV_NO
     * @param SUB_CPY_ID
     * @param resp
     * @return 
     * @throws Exception
     */
    public List<Map> queryRpt8(BigDecimal YEAR_MONTH, String DIV_NO, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (YEAR_MONTH == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23050_ERRMSG_001"));//�п�J�o���~��
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if (YEAR_MONTH.remainder(new BigDecimal("2")).equals(BigDecimal.ZERO)) {//�P�_�O�_����Ʀ~
            throw new ModuleException("�o���C���ɬd�߽п�J�_�Ʀ~��");
        }

        //180502:�d�ߦP�o�����X����Ӥ�
        List<BigDecimal> YEAR_MONTHs = new ArrayList<BigDecimal>();
        YEAR_MONTHs.add(YEAR_MONTH);
        YEAR_MONTHs.add(YEAR_MONTH.add(BigDecimal.ONE));

        ds.setFieldValues("YEAR_MONTH", YEAR_MONTHs);
        setFieldIfExist(ds, "DIV_NO", DIV_NO);

        return VOTool.findToMaps(ds, SQL_queryRpt8_001);
    }

    /**
     * �ഫ����Ƭ�Bigdecimal
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }

        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }

        return BigDecimal.ZERO;
    }

    /**
     * private �d�߸�ƫ��A�� ='key'
     * @param ds
     * @param criteria
     */
    private void setFieldIfExist(DataSet ds, String key, String criteria) {
        if (StringUtils.isNotEmpty(criteria)) {
            ds.setField(key, criteria);
        }
    }

    /**
     * To calculate the sub total of List, List1, List2, List3.
     * @param rptList
     * @param totalAmtMap
     * @return Map<String, BigDecimal>
     */
    private void doFmtRpt1_AddSubTotal(List<Map> rptList, Map<String, Object> totalAmtMap, boolean isAccountSubCpy) {
        String subTotal = MessageUtil.getMessage("EP_C23050_MSG_SUBTOTAL");//�p�p

        BigDecimal TEMP_SUM_SAL_AMT3 = BigDecimal.ZERO;//�T�p��
        BigDecimal TEMP_SUM_SAL_AMT2 = BigDecimal.ZERO;//�G�p��
        BigDecimal TEMP_SUM_SAL_AMT_SUM = BigDecimal.ZERO;//�p�p(�t�K�|)
        BigDecimal TEMP_SUM_SAL_AMT_NOTAX = BigDecimal.ZERO;//�K�|���B
        BigDecimal TEMP_SUM_TAX_AMT3 = BigDecimal.ZERO;//�|�B-�T�p��
        BigDecimal TEMP_SUM_TAX_AMT2 = BigDecimal.ZERO;//�|�B-�G�p��
        BigDecimal TEMP_SUM_TAX_AMT_SUM = BigDecimal.ZERO;//�|�B-�p�p
        BigDecimal TEMP_SUM_INV_AMT = BigDecimal.ZERO;//�X�p

        for (Map map : rptList) {
            TEMP_SUM_SAL_AMT3 = TEMP_SUM_SAL_AMT3.add(getBigDecimal(map.get("SAL_AMT3")));
            TEMP_SUM_SAL_AMT2 = TEMP_SUM_SAL_AMT2.add(getBigDecimal(map.get("SAL_AMT2")));
            TEMP_SUM_SAL_AMT_SUM = TEMP_SUM_SAL_AMT_SUM.add(getBigDecimal(map.get("SAL_AMT_SUM")));
            TEMP_SUM_SAL_AMT_NOTAX = TEMP_SUM_SAL_AMT_NOTAX.add(getBigDecimal(map.get("SAL_AMT_NOTAX")));
            TEMP_SUM_TAX_AMT3 = TEMP_SUM_TAX_AMT3.add(getBigDecimal(map.get("TAX_AMT3")));
            TEMP_SUM_TAX_AMT2 = TEMP_SUM_TAX_AMT2.add(getBigDecimal(map.get("TAX_AMT2")));
            TEMP_SUM_TAX_AMT_SUM = TEMP_SUM_TAX_AMT_SUM.add(getBigDecimal(map.get("TAX_AMT_SUM")));
            TEMP_SUM_INV_AMT = TEMP_SUM_INV_AMT.add(getBigDecimal(map.get("INV_AMT")));
            map.put("HAS_SUB", "Y");//((�s��key)Y:�ݭn���Ӥp�p
            map.put("NEED_PRINT", isAccountSubCpy ? "Y" : "N");//��ؤ����L����
        }

        Map subTotalAmtMap = new HashMap();
        subTotalAmtMap.put("DIV_NAME", subTotal);
        subTotalAmtMap.put("SAL_AMT3", TEMP_SUM_SAL_AMT3);
        subTotalAmtMap.put("SAL_AMT2", TEMP_SUM_SAL_AMT2);
        subTotalAmtMap.put("SAL_AMT_SUM", TEMP_SUM_SAL_AMT_SUM);
        subTotalAmtMap.put("SAL_AMT_NOTAX", TEMP_SUM_SAL_AMT_NOTAX);
        subTotalAmtMap.put("TAX_AMT3", TEMP_SUM_TAX_AMT3);
        subTotalAmtMap.put("TAX_AMT2", TEMP_SUM_TAX_AMT2);
        subTotalAmtMap.put("TAX_AMT_SUM", TEMP_SUM_TAX_AMT_SUM);
        subTotalAmtMap.put("INV_AMT", TEMP_SUM_INV_AMT);
        subTotalAmtMap.put("NEED_PRINT", "Y");
        rptList.add(subTotalAmtMap);

        BigDecimal TOTAL_SAL_AMT3 = (BigDecimal) totalAmtMap.get("SAL_AMT3");
        BigDecimal TOTAL_SAL_AMT2 = (BigDecimal) totalAmtMap.get("SAL_AMT2");
        BigDecimal TOTAL_SAL_AMT_SUM = (BigDecimal) totalAmtMap.get("SAL_AMT_SUM");
        BigDecimal TOTAL_SAL_AMT_NOTAX = (BigDecimal) totalAmtMap.get("SAL_AMT_NOTAX");
        BigDecimal TOTAL_TAX_AMT3 = (BigDecimal) totalAmtMap.get("TAX_AMT3");
        BigDecimal TOTAL_TAX_AMT2 = (BigDecimal) totalAmtMap.get("TAX_AMT2");
        BigDecimal TOTAL_TAX_AMT_SUM = (BigDecimal) totalAmtMap.get("TAX_AMT_SUM");
        BigDecimal TOTAL_INV_AMT = (BigDecimal) totalAmtMap.get("INV_AMT");
        TOTAL_SAL_AMT3 = TOTAL_SAL_AMT3.add(TEMP_SUM_SAL_AMT3);
        TOTAL_SAL_AMT2 = TOTAL_SAL_AMT2.add(TEMP_SUM_SAL_AMT2);
        TOTAL_SAL_AMT_SUM = TOTAL_SAL_AMT_SUM.add(TEMP_SUM_SAL_AMT_SUM);
        TOTAL_SAL_AMT_NOTAX = TOTAL_SAL_AMT_NOTAX.add(TEMP_SUM_SAL_AMT_NOTAX);
        TOTAL_TAX_AMT3 = TOTAL_TAX_AMT3.add(TEMP_SUM_TAX_AMT3);
        TOTAL_TAX_AMT2 = TOTAL_TAX_AMT2.add(TEMP_SUM_TAX_AMT2);
        TOTAL_TAX_AMT_SUM = TOTAL_TAX_AMT_SUM.add(TEMP_SUM_TAX_AMT_SUM);
        TOTAL_INV_AMT = TOTAL_INV_AMT.add(TEMP_SUM_INV_AMT);
        totalAmtMap.put("SAL_AMT3", TOTAL_SAL_AMT3);
        totalAmtMap.put("SAL_AMT2", TOTAL_SAL_AMT2);
        totalAmtMap.put("SAL_AMT_SUM", TOTAL_SAL_AMT_SUM);
        totalAmtMap.put("SAL_AMT_NOTAX", TOTAL_SAL_AMT_NOTAX);
        totalAmtMap.put("TAX_AMT3", TOTAL_TAX_AMT3);
        totalAmtMap.put("TAX_AMT2", TOTAL_TAX_AMT2);
        totalAmtMap.put("TAX_AMT_SUM", TOTAL_TAX_AMT_SUM);
        totalAmtMap.put("INV_AMT", TOTAL_INV_AMT);

    }

    /**
     * Deliver decimal/int to iReport will cause many problems,
     * so All data will be convert to String.
     * @param rtnMap
     */
    private void convertString(List<Map> rptList, LocaleDisplay LD) {
        for (Map rtnMap : rptList) {
            Iterator it = rtnMap.keySet().iterator();
            while (it.hasNext()) {
                String key = (String) it.next();
                Object obj = rtnMap.get(key);
                if (obj == null) {
                    rtnMap.put(key, "");
                } else if (obj instanceof BigDecimal) {

                    rtnMap.put(key, LD.formatNumber(obj, 0, ""));
                } else {
                    rtnMap.put(key, obj.toString());
                }
            }
        }
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param msg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(msg);
        return eie;
    }

    //---------------------------------------------�ץX--------------------------------------------------//
    /**
     * 
     * @param RPT_TYPE
     * @param RCV_YM
     * @param DIV_NO
     * @param resp
     * @throws Exception
     */
    public List<Map> exportXLS(String RPT_TYPE, BigDecimal RCV_YM, String DIV_NO, ResponseContext resp, UserObject user, String SUB_CPY_ID)
            throws Exception {
        FileOutputStream fileOutputString = null;
        try {
            // ���ͼȦs��
            File downloadFile;
            StringBuilder sb = new StringBuilder();
            String fileName;
            HSSFWorkbook workbook = new HSSFWorkbook();// �u�@��
            LocaleDisplay LD = new LocaleDisplay("EP", user);// �u�@��
            List<Map> rtnList;
            if ("2".equals(RPT_TYPE)) {
                //�ɦW: �j�ө��Ӫ�_YYYYMMDD.xls 
                sb.append(MessageUtil.getMessage("EP_C23050_UI_FILENAME_2")/*�j�ө��Ӫ�_*/).append(DATE.toDate_yyyyMMdd(DATE.getDBDate()))
                        .append(".xls");
                fileName = sb.toString();
                sb.setLength(0);
                HSSFSheet sheet = workbook.createSheet(fileName);
                export2(workbook, sheet, RCV_YM, DIV_NO, LD, SUB_CPY_ID);

                // ���ͼȦs��
                downloadFile = RptUtils.createTempFile(fileName);

                rtnList = new ArrayList<Map>();//�S���Ӹ�
            } else if ("4".equals(RPT_TYPE)) {
                //�ɦW: �Ȧ��l�B��_YYYYMMDD.xls 
                sb.append(MessageUtil.getMessage("EP_C23050_UI_FILENAME_4")/*�Ȧ��l�B��_*/).append(DATE.toDate_yyyyMMdd(DATE.getDBDate()))
                        .append(".xls");
                fileName = sb.toString();
                sb.setLength(0);
                HSSFSheet sheet = workbook.createSheet(fileName);
                rtnList = export4(workbook, sheet, RCV_YM, DIV_NO, LD, SUB_CPY_ID);

                // ���ͼȦs��
                downloadFile = RptUtils.createTempFile(fileName);
            } else if ("5".equals(RPT_TYPE)) {
                //�ɦW: �����l�B��_YYYYMMDD.xls 
                sb.append(MessageUtil.getMessage("EP_C23050_UI_FILENAME_5")/*�����l�B��_*/).append(DATE.toDate_yyyyMMdd(DATE.getDBDate()))
                        .append(".xls");
                fileName = sb.toString();
                sb.setLength(0);
                HSSFSheet sheet = workbook.createSheet(fileName);
                rtnList = export5(workbook, sheet, RCV_YM, LD, DIV_NO, SUB_CPY_ID);

                // ���ͼȦs��
                downloadFile = RptUtils.createTempFile(fileName);
            } else if ("6".equals(RPT_TYPE)) {
                //�ɦW: ���Ȧ��J�b��_YYYYMMDD.xls 
                sb.append(MessageUtil.getMessage("EP_C23050_UI_FILENAME_6")/*���Ȧ��J�b��_*/).append(DATE.toDate_yyyyMMdd(DATE.getDBDate()))
                        .append(".xls");
                fileName = sb.toString();
                sb.setLength(0);
                HSSFSheet sheet = workbook.createSheet(fileName);
                rtnList = export6(workbook, sheet, RCV_YM, DIV_NO, LD, SUB_CPY_ID);

                // ���ͼȦs��
                downloadFile = RptUtils.createTempFile(fileName);
            } else if ("7".equals(RPT_TYPE)) {
                //�ɦW: ���Ȧ��R�b��_YYYYMMDD.xls 
                sb.append(MessageUtil.getMessage("EP_C23050_UI_FILENAME_7")/*���Ȧ��R�b��_*/).append(DATE.toDate_yyyyMMdd(DATE.getDBDate()))
                        .append(".xls");
                fileName = sb.toString();
                sb.setLength(0);
                HSSFSheet sheet = workbook.createSheet(fileName);
                rtnList = export7(workbook, sheet, RCV_YM, DIV_NO, LD, SUB_CPY_ID);

                // ���ͼȦs��
                downloadFile = RptUtils.createTempFile(fileName);
            } else if ("8".equals(RPT_TYPE)) {
                // [20180302]
                // �ɦW: �o���C����_YYYMM.txt //YYYMM���d�߱���:�����~��
                sb.append("�o���C����_").append(RCV_YM).append(".txt");
                fileName = sb.toString();
                sb.setLength(0);
                // ���ͼȦs��
                rtnList = this.queryRpt8(RCV_YM, DIV_NO, SUB_CPY_ID);
                downloadFile = this.export8(rtnList, RCV_YM, fileName);
            } else {
                throw new ErrorInputException("EP_C23050_ERRMSG_003");//�����������ŦX�w��
            }

            if (!"8".equals(RPT_TYPE)) {
                // ��X excel �ɪ����|
                fileOutputString = new FileOutputStream(downloadFile.getPath());
                workbook.write(fileOutputString);
            }
            RptUtils.cryptoDownloadParameterToResp(fileName, downloadFile, resp);

            return rtnList;
        } finally {
            if (fileOutputString != null) {
                fileOutputString.close();
            }
        }

    }

    /**
     * 
     * @param workbook
     * @param sheet
     * @param RCV_YM
     * @param DIV_NO
     * @throws ModuleException
     */
    private void export2(HSSFWorkbook workbook, HSSFSheet sheet, BigDecimal RCV_YM, String DIV_NO, LocaleDisplay LD, String SUB_CPY_ID)
            throws ModuleException {

        //�d��
        List<Map> rtnList = this.queryRpt2(RCV_YM, DIV_NO, SUB_CPY_ID);

        //���W��
        String[] columName = new String[] { "EPC2_3050_UI_BLD_CD", "EPC2_3050_UI_BLD_NAME", "EPC2_3050_UI_SAL_AMT_2",
                "EPC2_3050_UI_TAX_AMT", "EPC2_3050_UI_INV_AMT_2" };

        // �]�w���j�p
        getSheetColumnWidth(sheet, columName.length);

        int beginRow = 0;
        //�]�wTitle
        HSSFRow row = sheet.createRow(beginRow);
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���", "ALL");//���Y
        setColumn(sheet, row, style0, 0, LD.formatDateym(RCV_YM, "") + MessageUtil.getMessage("EPC2_3050_UI_GRID_2"), false, true,
            beginRow, beginRow, 0, columName.length - 2);//�U�j�ө���
        setColumn(sheet, row, createStyle(workbook, 5, "�s�ө���", null), 8, "�L�s���:\n" + LD.formatDate(DATE.today(), "/", ""), false, false,
            null, null, null, null);
        beginRow++;

        //�]�w���W��
        HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���", "ALL");//�����Y
        getColumnName(sheet, row, columName, style1, beginRow);
        beginRow++;

        //-----------------------------���Ӹ��(�t�X�p,�s�դp�p)-----------------------//
        //�]�wSTYLE
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���", "ALL");//���Ӥ�r
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���", "ALL");//���ӼƦr

        BigDecimal TOT_SAL_AMT = BigDecimal.ZERO;
        BigDecimal TOT_TAX_AMT = BigDecimal.ZERO;
        BigDecimal TOT_INV_AMT = BigDecimal.ZERO;

        //����
        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);

            //���Ӹ��
            row = sheet.createRow(beginRow);
            setColumn(sheet, row, style2, 0, MapUtils.getString(rtnMap, "BLD_CD"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 1, MapUtils.getString(rtnMap, "BLD_NAME").trim(), false, false, null, null, null, null);
            setColumn(sheet, row, style3, 2, LD.formatNumber(rtnMap.get("SAL_AMT"), 0, null), true, false, null, null, null, null);
            setColumn(sheet, row, style3, 3, LD.formatNumber(rtnMap.get("TAX_AMT"), 0, null), true, false, null, null, null, null);
            setColumn(sheet, row, style3, 4, LD.formatNumber(rtnMap.get("INV_AMT"), 0, null), true, false, null, null, null, null);
            beginRow++;

            //�X�p�p��
            TOT_SAL_AMT = TOT_SAL_AMT.add(getBigDecimal(rtnMap.get("SAL_AMT")));
            TOT_TAX_AMT = TOT_TAX_AMT.add(getBigDecimal(rtnMap.get("TAX_AMT")));
            TOT_INV_AMT = TOT_INV_AMT.add(getBigDecimal(rtnMap.get("INV_AMT")));
        }
        //�X�p
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EPC2_3050_UI_TOT")/*�`�p*/, false, true, beginRow, beginRow, 0, 1);
        setColumn(sheet, row, style3, 2, LD.formatNumber(TOT_SAL_AMT, 0, null), true, false, null, null, null, null);
        setColumn(sheet, row, style3, 3, LD.formatNumber(TOT_TAX_AMT, 0, null), true, false, null, null, null, null);
        setColumn(sheet, row, style3, 4, LD.formatNumber(TOT_INV_AMT, 0, null), true, false, null, null, null, null);
        //-----------------------------���Ӹ��(�t�X�p,�s�դp�p)-----------------------//

    }

    /**
     * �إߪ��椺�e(qry4)    
     * @param workbook
     * @param sheet
     * @param RCV_YM
     * @param DIV_NO
     * @throws ModuleException
     * @throws SQLException
     * @throws DBException 
     */
    private List<Map> export4(HSSFWorkbook workbook, HSSFSheet sheet, BigDecimal RCV_YM, String DIV_NO, LocaleDisplay LD, String SUB_CPY_ID)
            throws ModuleException, SQLException, DBException {

        //�d��
        List<Map> rtnList = this.queryRpt4(RCV_YM, DIV_NO, SUB_CPY_ID);

        //���W��
        String[] columName = new String[] { "EPC2_3050_UI_BLD_CD", "EPC2_3050_UI_TMP_NO", "EPC2_3050_UI_SLIP_DATE_6",
                "EPC2_3050_UI_CRT_NO", "EPC2_3050_UI_CUS_NO", "EPC2_3050_UI_CUS_NAME", "EPC2_3050_UI_ACNT_AMT", "EPC2_3050_UI_DACNT_AMT",
                "EPC2_3050_UI_BAL_AMT_4", "EPC2_3050_UI_CHK_DATE" };

        // �]�w���j�p
        getSheetColumnWidth4(sheet, columName.length);

        sheet.setMargin(sheet.TopMargin, (double) 0.2);//�o��O�^�T, ���Oexcel���]�w�O����
        sheet.setMargin(sheet.BottomMargin, (double) 0.2);
        sheet.setMargin(sheet.LeftMargin, (double) 0.16);
        sheet.setMargin(sheet.RightMargin, (double) 0.16);

        int beginRow = 0;
        //�]�wTitle
        HSSFRow row = sheet.createRow(beginRow);
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���", null);//���Y
        setColumn(sheet, row, style0, 0, LD.formatDateym(RCV_YM, "") + MessageUtil.getMessage("EPC2_3050_UI_GRID_4"), false, true,
            beginRow, beginRow, 0, columName.length - 3);
        setColumn(sheet, row, createStyle(workbook, 5, "�s�ө���", null), 8, "�L�s���:\n" + LD.formatDate(DATE.today(), "/", ""), false, false,
            null, null, null, null);
        beginRow++;

        //�]�w���W��
        HSSFCellStyle style1 = createStyle_2(workbook, 1, "�s�ө���", "TOT", 10, 21);//�����Y
        getColumnName(sheet, row, columName, style1, beginRow);
        beginRow++;

        //-----------------------------���Ӹ��(�t�X�p,�s�դp�p)-----------------------//
        //�]�wSTYLE
        HSSFCellStyle style2 = createStyle_2(workbook, 2, "�s�ө���", null, 10, 23);//���Ӥ�r
        HSSFCellStyle style4 = createStyle_2(workbook, 4, "�s�ө���", null, 10, 23);//���Ӥ�r(�a��)
        HSSFCellStyle style3 = createStyle_2(workbook, 3, "�s�ө���", null, 10, 23);//���ӼƦr

        BigDecimal TOT_ACNT_AMT = BigDecimal.ZERO;
        BigDecimal TOT_DACNT_AMT = BigDecimal.ZERO;
        BigDecimal TOT_BAL_AMT = BigDecimal.ZERO;

        String OLD_BLD_CD = "";

        //����
        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);

            String BLD_CD = MapUtils.getString(rtnMap, "BLD_CD");
            String div_no = MapUtils.getString(rtnMap, "DIV_NO");
            String div_name = MapUtils.getString(rtnMap, "DIV_NAME");

            if (i > 0 && !OLD_BLD_CD.equals(BLD_CD)) {
                row = sheet.createRow(beginRow);
                setColumn(sheet, row, style1, 0, "", false, false, null, null, null, null);
                setColumn(sheet, row, style1, 1, "", false, false, null, null, null, null);
                setColumn(sheet, row, style1, 2, "", false, false, null, null, null, null);
                setColumn(sheet, row, style1, 3, "", false, false, null, null, null, null);
                setColumn(sheet, row, style1, 4, "", false, false, null, null, null, null);
                setColumn(sheet, row, style1, 5, "", false, false, null, null, null, null);
                setColumn(sheet, row, style1, 6, "", true, false, null, null, null, null);
                setColumn(sheet, row, style1, 7, "", true, false, null, null, null, null);
                setColumn(sheet, row, style1, 8, "", true, false, null, null, null, null);
                setColumn(sheet, row, style1, 9, "", false, false, null, null, null, null);
                beginRow++;
            }

            String SLIP_DATE = MapUtils.getString(rtnMap, "SLIP_DATE");
            if (DATE.isDate(SLIP_DATE)) {
                SLIP_DATE = LD.formatDate(Date.valueOf(SLIP_DATE), "", "");
            }
            String CHK_DATE = MapUtils.getString(rtnMap, "CHK_DATE", "");
            if (DATE.isDate(CHK_DATE)) {
                CHK_DATE = LD.formatDate(Date.valueOf(CHK_DATE), "", "");
            }
            //���Ӹ��
            row = sheet.createRow(beginRow);
            row.setHeightInPoints((short) 16);
            setColumn(sheet, row, style2, 0, MapUtils.getString(rtnMap, "BLD_CD"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 1, MapUtils.getString(rtnMap, "TMP_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 2, SLIP_DATE, false, false, null, null, null, null);
            setColumn(sheet, row, style2, 3, MapUtils.getString(rtnMap, "CRT_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 4, MapUtils.getString(rtnMap, "CUS_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style4, 5, MapUtils.getString(rtnMap, "CUS_NAME").trim(), false, false, null, null, null, null);
            setColumn(sheet, row, style3, 6, LD.formatNumber(rtnMap.get("ACNT_AMT"), 0, null), true, false, null, null, null, null);
            setColumn(sheet, row, style3, 7, LD.formatNumber(rtnMap.get("DACNT_AMT"), 0, null), true, false, null, null, null, null);
            setColumn(sheet, row, style3, 8, LD.formatNumber(rtnMap.get("BAL_AMT"), 0, null), true, false, null, null, null, null);
            setColumn(sheet, row, style2, 9, CHK_DATE, false, false, null, null, null, null);

            OLD_BLD_CD = BLD_CD;
            beginRow++;

            //�X�p�p��
            TOT_ACNT_AMT = TOT_ACNT_AMT.add(getBigDecimal(rtnMap.get("ACNT_AMT")));
            TOT_DACNT_AMT = TOT_DACNT_AMT.add(getBigDecimal(rtnMap.get("DACNT_AMT")));
            TOT_BAL_AMT = TOT_BAL_AMT.add(getBigDecimal(rtnMap.get("BAL_AMT")));

            boolean printSum = true;
            if (i < rtnList.size() - 1) {
                String div_no_next = MapUtils.getString(rtnList.get(i + 1), "DIV_NO");
                if (div_no.equals(div_no_next)) {
                    printSum = false;
                }
            }
            if (printSum) {
                //�ǲ���� �p�p
                row = sheet.createRow(beginRow);
                setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EPC2_3050_UI_QRY4_RCV_YM")/*�ǲ����:*/
                        + LD.formatDateym(RCV_YM, ""), false, true, beginRow, beginRow, 0, 5);
                setColumn(sheet, row, style2, 6, "", false, false, null, null, null, null);
                setColumn(sheet, row, style3, 7, LD.formatNumber(TOT_DACNT_AMT, 0, null), true, false, null, null, null, null);
                setColumn(sheet, row, style2, 8, "", false, false, null, null, null, null);
                setColumn(sheet, row, style2, 9, "", false, false, null, null, null, null);
                beginRow++;
                //�X�p
                row = sheet.createRow(beginRow);
                setColumn(sheet, row, style2, 0, div_no + " " + div_name, false, true, beginRow, beginRow, 0, 5);
                setColumn(sheet, row, style3, 6, LD.formatNumber(TOT_ACNT_AMT, 0, null), true, false, null, null, null, null);
                setColumn(sheet, row, style3, 7, LD.formatNumber(TOT_DACNT_AMT, 0, null), true, false, null, null, null, null);
                setColumn(sheet, row, style3, 8, LD.formatNumber(TOT_BAL_AMT, 0, null), true, false, null, null, null, null);
                setColumn(sheet, row, style2, 9, "", false, false, null, null, null, null);
                beginRow++;
                beginRow++;

                TOT_ACNT_AMT = BigDecimal.ZERO;
                TOT_DACNT_AMT = BigDecimal.ZERO;
                TOT_BAL_AMT = BigDecimal.ZERO;
            }
        }

        return rtnList;

        //-----------------------------���Ӹ��(�t�X�p,�s�դp�p)-----------------------//

    }

    /**
     * �إߪ��椺�e(qry5)
     * @param workbook
     * @param sheet
     * @param RCV_YM
     * @throws ModuleException
     * @throws SQLException
     * @throws DBException 
     */
    private List<Map> export5(HSSFWorkbook workbook, HSSFSheet sheet, BigDecimal RCV_YM, LocaleDisplay LD, String CLCDV, String SUB_CPY_ID)
            throws ModuleException, SQLException, DBException {

        //�d��
        Map rtnMap = this.queryRpt5(RCV_YM, false, CLCDV, SUB_CPY_ID);

        //���W��
        String[] columName = new String[] { "EPC2_3050_UI_BLD_CD", "EPC2_3050_UI_CRT_NO", "EPC2_3050_UI_CUS_NO", "EPC2_3050_UI_CUS_NAME",
                "EPC2_3050_UI_PAY_S_DATE", "EPC2_3050_UI_PAY_E_DATE", "EPC2_3050_UI_INV_AMT", "EPC2_3050_UI_SPR_AMT",
                "EPC2_3050_UI_PAY_AMT", "EPC2_3050_UI_INV_NO" };

        // �]�w���j�p
        sheet.setColumnWidth(0, 20 * 256);
        sheet.setColumnWidth(1, 20 * 256);
        sheet.setColumnWidth(2, 20 * 256);
        sheet.setColumnWidth(3, 50 * 256);
        sheet.setColumnWidth(4, 20 * 256);
        sheet.setColumnWidth(5, 20 * 256);
        sheet.setColumnWidth(6, 20 * 256);
        sheet.setColumnWidth(7, 20 * 256);
        sheet.setColumnWidth(8, 20 * 256);
        sheet.setColumnWidth(9, 20 * 256);

        int beginRow = 0;
        //�]�wTitle
        HSSFRow row = sheet.createRow(beginRow);
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���", "ALL");//���Y
        setColumn(sheet, row, style0, 0, LD.formatDateym(RCV_YM, "") + MessageUtil.getMessage("EPC2_3050_UI_GRID_5"), false, true,
            beginRow, beginRow, 0, columName.length - 1);
        beginRow++;

        //�]�w���W��
        HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���", "ALL");//�����Y
        getColumnName(sheet, row, columName, style1, beginRow);
        beginRow++;

        //-----------------------------���Ӹ��(�t�X�p,�s�դp�p)-----------------------//
        //�]�wSTYLE
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���", "ALL");//���Ӥ�r
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���", "ALL");//���ӼƦr

        //����
        List dataList = (List) rtnMap.get("rtnList");
        Map TOTMap = (Map) rtnMap.get("TOTMap");
        //detail
        for (int i = 0; i < dataList.size(); i++) {
            List groupList = (List) dataList.get(i);
            String DIV_NO = MapUtils.getString((Map) groupList.get(0), "DIV_NO");
            int length = groupList.size();

            for (int k = 0; k < length; k++) {
                Map dataMap = (Map) groupList.get(k);
                //�s�դp�p
                if (k == length - 1) {//groupList�̫�@�� == subTot

                    row = sheet.createRow(beginRow);
                    setColumn(sheet, row, style2, 0, DIV_NO, false, true, beginRow, beginRow, 0, 5);
                    setColumn(sheet, row, style3, 6, LD.formatNumber(dataMap.get("INV_AMT"), 0, null), true, false, null, null, null, null);
                    setColumn(sheet, row, style3, 7, LD.formatNumber(dataMap.get("SPR_AMT"), 0, null), true, false, null, null, null, null);
                    setColumn(sheet, row, style3, 8, LD.formatNumber(dataMap.get("PAY_AMT"), 0, null), true, false, null, null, null, null);
                    setColumn(sheet, row, style2, 9, "", false, false, null, null, null, null);
                    beginRow++;

                } else {
                    //���Ӹ��
                    row = sheet.createRow(beginRow);
                    setColumn(sheet, row, style2, 0, MapUtils.getString(dataMap, "BLD_CD"), false, false, null, null, null, null);
                    setColumn(sheet, row, style2, 1, MapUtils.getString(dataMap, "CRT_NO"), false, false, null, null, null, null);
                    setColumn(sheet, row, style2, 2, MapUtils.getString(dataMap, "CUS_NO"), false, false, null, null, null, null);
                    setColumn(sheet, row, style2, 3, MapUtils.getString(dataMap, "CUS_NAME").trim(), false, false, null, null, null, null);
                    setColumn(sheet, row, style2, 4, LD.formatDate((Date) dataMap.get("PAY_S_DATE"), "/", null), false, false, null, null,
                        null, null);
                    setColumn(sheet, row, style2, 5, LD.formatDate((Date) dataMap.get("PAY_E_DATE"), "/", null), false, false, null, null,
                        null, null);
                    setColumn(sheet, row, style3, 6, LD.formatNumber(dataMap.get("INV_AMT"), 0, null), true, false, null, null, null, null);
                    setColumn(sheet, row, style3, 7, LD.formatNumber(dataMap.get("SPR_AMT"), 0, null), true, false, null, null, null, null);
                    setColumn(sheet, row, style3, 8, LD.formatNumber(dataMap.get("PAY_AMT"), 0, null), true, false, null, null, null, null);
                    setColumn(sheet, row, style2, 9, MapUtils.getString(dataMap, "INV_NO"), false, false, null, null, null, null);
                    beginRow++;
                }
            }
        }

        //�X�p
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EPC2_3050_UI_TOT")/*�`�p*/, false, true, beginRow, beginRow, 0, 5);
        setColumn(sheet, row, style3, 6, LD.formatNumber(TOTMap.get("INV_AMT"), 0, null), true, false, null, null, null, null);
        setColumn(sheet, row, style3, 7, LD.formatNumber(TOTMap.get("SPR_AMT"), 0, null), true, false, null, null, null, null);
        setColumn(sheet, row, style3, 8, LD.formatNumber(TOTMap.get("PAY_AMT"), 0, null), true, false, null, null, null, null);
        setColumn(sheet, row, style2, 9, "", false, false, null, null, null, null);
        //-----------------------------���Ӹ��(�t�X�p,�s�դp�p)-----------------------//

        return dataList;
    }

    /**
     * �إߪ��椺�e(qry6)
     * @param workbook
     * @param sheet
     * @param RCV_YM
     * @param DIV_NO
     * @throws ModuleException
     * @throws SQLException
     */
    private List<Map> export6(HSSFWorkbook workbook, HSSFSheet sheet, BigDecimal RCV_YM, String DIV_NO, LocaleDisplay LD, String SUB_CPY_ID)
            throws ModuleException, SQLException {

        //�d��
        Map rtnMap = this.queryRpt6(RCV_YM, DIV_NO, SUB_CPY_ID);

        List rtnList = (List) rtnMap.get("rptList");
        Map TOTMap = (Map) rtnMap.get("rptMap");

        //���W��
        String[] columName = new String[] { "EPC2_3050_UI_SLIP_DATE_6", "EPC2_3050_UI_TMP_NO", "EPC2_3050_UI_CUS_NO", "EPC2_3050_UI_ID",
                "EPC2_3050_UI_ACNT_AMT", "EPC2_3050_UI_BAL_AMT_6", "EPC2_3050_UI_BLD_NAME", "EPC2_3050_UI_BLD_CD" };

        // �]�w���j�p
        getSheetColumnWidthForQry7(sheet, columName.length);

        sheet.setMargin(sheet.TopMargin, (double) 0.2);//�o��O�^�T, ���Oexcel���]�w�O����
        sheet.setMargin(sheet.BottomMargin, (double) 0.2);
        sheet.setMargin(sheet.LeftMargin, (double) 0.16);
        sheet.setMargin(sheet.RightMargin, (double) 0.16);

        int beginRow = 0;
        //�]�wTitle
        HSSFRow row = sheet.createRow(beginRow);
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���", null);//���Y
        setColumn(sheet, row, style0, 0, LD.formatDateym(RCV_YM, "") + MessageUtil.getMessage("EPC2_3050_UI_GRID_6"), false, true,
            beginRow, beginRow, 0, columName.length - 3);
        setColumn(sheet, row, createStyle(workbook, 5, "�s�ө���", null), 6, "�L�s���:\n" + LD.formatDate(DATE.today(), "/", ""), false, true,
            beginRow, beginRow, 6, 7);
        beginRow++;

        //�]�w���W��
        HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���", null);//�����Y
        getColumnName(sheet, row, columName, style1, beginRow);
        beginRow++;
        //�ĤG��
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style1, 0, "", false, false, null, null, null, null);
        setColumn(sheet, row, style1, 1, MessageUtil.getMessage("EPC2_3050_UI_CRT_NO"), false, false, null, null, null, null);
        setColumn(sheet, row, style1, 2, MessageUtil.getMessage("EPC2_3050_UI_CUS_NAME"), false, true, beginRow, beginRow, 2, 5);
        setColumn(sheet, row, style1, 6, "", false, true, beginRow, beginRow, 6, 7);
        beginRow++;

        //-----------------------------���Ӹ��(�t�X�p,�s�դp�p)-----------------------//
        //�]�wSTYLE
        HSSFCellStyle style8 = createStyle(workbook, 4, "�s�ө���", null);//�Ȥ�W��((�m��))
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���", null);//�@����Ӥ�r
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���", null);//�@����ӼƦr
        HSSFCellStyle style4 = createStyle(workbook, 2, "�s�ө���", "BUTTOM");//��p�p��r((����+���u))
        HSSFCellStyle style5 = createStyle(workbook, 3, "�s�ө���", "BUTTOM");//��p�p�Ʀr((����+���u))
        HSSFCellStyle style6 = createStyle(workbook, 2, "�s�ө���", "TOT");//�X�p�`�p��r((����))
        HSSFCellStyle style7 = createStyle(workbook, 3, "�s�ө���", "TOT");//�X�p�`�p�Ʀr((����))

        //detail
        for (int group1 = 0; group1 < rtnList.size(); group1++) {
            List group1List = (List) rtnList.get(group1);

            for (int group2 = 0; group2 < group1List.size(); group2++) {
                if (group2 == group1List.size() - 1) {
                    //�ĤG�hgroup�p�p
                    Map dataMap = (Map) group1List.get(group2);
                    row = sheet.createRow(beginRow);
                    setColumn(sheet, row, style6, 0, MapUtils.getString(dataMap, "DIV_NO") + MapUtils.getString(dataMap, "DIV_NAME"),
                        false, true, beginRow, beginRow, 0, 3);
                    setColumn(sheet, row, style7, 4, LD.formatNumber(dataMap.get("ACNT_AMT"), 0, null), true, false, null, null, null, null);
                    setColumn(sheet, row, style7, 5, LD.formatNumber(dataMap.get("BAL_AMT"), 0, null), true, false, null, null, null, null);
                    setColumn(sheet, row, style6, 6, "", false, true, beginRow, beginRow, 6, 7);
                    beginRow++;
                    if (group1 == 0) {
                        beginRow++;
                    }
                } else {
                    List group2List = (List) group1List.get(group2);
                    for (int index = 0; index < group2List.size(); index++) {
                        Map dataMap = (Map) group2List.get(index);
                        if (index == (group2List.size() - 1)) {
                            row = sheet.createRow(beginRow);
                            beginRow++;
                            //�̤p�hgroup�p�p
                            row = sheet.createRow(beginRow);
                            setColumn(sheet, row, style4, 0,
                                LD.formatDate(Date.valueOf(MapUtils.getString(dataMap, "SLIP_DATE")), "/", null), false, true, beginRow,
                                beginRow, 0, 1);
                            setColumn(sheet, row, style4, 2, MessageUtil.getMessage("EPC2_3050_UI_COUNT")/*����:*/
                                    + MapUtils.getString(dataMap, "count"), false, true, beginRow, beginRow, 2, 3);
                            setColumn(sheet, row, style5, 4, LD.formatNumber(dataMap.get("ACNT_AMT"), 0, null), true, false, null, null,
                                null, null);
                            setColumn(sheet, row, style5, 5, LD.formatNumber(dataMap.get("BAL_AMT"), 0, null), true, false, null, null,
                                null, null);
                            setColumn(sheet, row, style4, 6, "", false, true, beginRow, beginRow, 6, 7);

                            beginRow++;

                        } else {
                            //�C��data
                            row = sheet.createRow(beginRow);
                            setColumn(sheet, row, style2, 0, LD.formatDate((Date) dataMap.get("SLIP_DATE"), "/", null), false, false, null,
                                null, null, null);
                            setColumn(sheet, row, style2, 1, MapUtils.getString(dataMap, "TMP_NO"), false, false, null, null, null, null);
                            setColumn(sheet, row, style2, 2, MapUtils.getString(dataMap, "CUS_NO"), false, false, null, null, null, null);
                            setColumn(sheet, row, style2, 3, MapUtils.getString(dataMap, "ID"), false, false, null, null, null, null);
                            setColumn(sheet, row, style3, 4, LD.formatNumber(dataMap.get("ACNT_AMT"), 0, null), true, false, null, null,
                                null, null);
                            setColumn(sheet, row, style3, 5, LD.formatNumber(dataMap.get("BAL_AMT"), 0, null), true, false, null, null,
                                null, null);
                            setColumn(sheet, row, style8, 6, MapUtils.getString(dataMap, "BLD_NAME"), false, false, null, null, null, null);
                            setColumn(sheet, row, style2, 7, MapUtils.getString(dataMap, "BLD_CD"), false, false, null, null, null, null);
                            beginRow++;

                            row = sheet.createRow(beginRow);
                            setColumn(sheet, row, style2, 0, "", false, false, null, null, null, null);
                            setColumn(sheet, row, style2, 1, MapUtils.getString(dataMap, "CRT_NO"), false, false, null, null, null, null);
                            setColumn(sheet, row, style8, 2, MapUtils.getString(dataMap, "CUS_NAME").trim(), false, true, beginRow,
                                beginRow, 2, 6);
                            //setColumn(sheet, row, style2, 6, "", false, true, beginRow, beginRow, 6, 7);
                            beginRow++;
                        }
                    }
                }
            }
        }
        //�`�p
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style6, 0, MessageUtil.getMessage("EPC2_3050_UI_TOT")/*�`�p*/, false, true, beginRow, beginRow, 0, 3);
        setColumn(sheet, row, style7, 4, LD.formatNumber(TOTMap.get("ACNT_AMT"), 0, null), true, false, null, null, null, null);
        setColumn(sheet, row, style7, 5, LD.formatNumber(TOTMap.get("BAL_AMT"), 0, null), true, false, null, null, null, null);
        setColumn(sheet, row, style6, 6, "", false, true, beginRow, beginRow, 6, 7);

        //-----------------------------���Ӹ��(�t�X�p,�s�դp�p)-----------------------//

        return rtnList;
    }

    /**
     * �إߪ��椺�e(qry7)
     * @param workbook
     * @param sheet
     * @param RCV_YM
     * @param DIV_NO
     * @throws ModuleException
     * @throws SQLException
     */
    private List<Map> export7(HSSFWorkbook workbook, HSSFSheet sheet, BigDecimal RCV_YM, String DIV_NO, LocaleDisplay LD, String SUB_CPY_ID)
            throws ModuleException, SQLException {

        //�d��
        Map rtnMap = this.queryRpt7(RCV_YM, DIV_NO, SUB_CPY_ID);

        List rtnList = (List) rtnMap.get("rptList");
        Map TOTMap = (Map) rtnMap.get("rptMap");

        //���W��
        String[] columName = new String[] { "EPC2_3050_UI_SLIP_DATE_7", "EPC2_3050_UI_TMP_NO", "EPC2_3050_UI_CUS_NO", "EPC2_3050_UI_ID",
                "EPC2_3050_UI_DACNT_AMT_NEW", "EPC2_3050_UI_BAL_AMT_7", "EPC2_3050_UI_BLD_NAME", "EPC2_3050_UI_BLD_CD" };

        // �]�w���j�p
        getSheetColumnWidthForQry7(sheet, columName.length);

        sheet.setMargin(sheet.TopMargin, (double) 0.2);//�o��O�^�T, ���Oexcel���]�w�O����
        sheet.setMargin(sheet.BottomMargin, (double) 0.2);
        sheet.setMargin(sheet.LeftMargin, (double) 0.16);
        sheet.setMargin(sheet.RightMargin, (double) 0.16);

        int beginRow = 0;
        //�]�wTitle
        HSSFRow row = sheet.createRow(beginRow);
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���", null);//���Y
        setColumn(sheet, row, style0, 0, LD.formatDateym(RCV_YM, "") + MessageUtil.getMessage("EPC2_3050_UI_GRID_7"), false, true,
            beginRow, beginRow, 0, 5);
        setColumn(sheet, row, createStyle(workbook, 5, "�s�ө���", null), 6, "�L�s���:\n" + LD.formatDate(DATE.today(), "/", ""), false, true,
            beginRow, beginRow, 6, 7);
        beginRow++;

        //�]�w���W��
        HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���", null);//�����Y
        getColumnName(sheet, row, columName, style1, beginRow);
        beginRow++;
        //�ĤG��
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style1, 0, "", false, false, null, null, null, null);
        setColumn(sheet, row, style1, 1, MessageUtil.getMessage("EPC2_3050_UI_CRT_NO"), false, false, null, null, null, null);
        setColumn(sheet, row, style1, 2, MessageUtil.getMessage("EPC2_3050_UI_CUS_NAME"), false, true, beginRow, beginRow, 2, 5);
        setColumn(sheet, row, style1, 6, "", false, true, beginRow, beginRow, 6, 7);
        beginRow++;

        //-----------------------------���Ӹ��(�t�X�p,�s�դp�p)-----------------------//
        //�]�wSTYLE
        HSSFCellStyle style8 = createStyle(workbook, 4, "�s�ө���", null);//�Ȥ�W��((�m��))
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���", null);//�@����Ӥ�r
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���", null);//�@����ӼƦr
        HSSFCellStyle style4 = createStyle(workbook, 2, "�s�ө���", "BUTTOM");//��p�p��r((����+���u))
        HSSFCellStyle style5 = createStyle(workbook, 3, "�s�ө���", "BUTTOM");//��p�p�Ʀr((����+���u))
        HSSFCellStyle style6 = createStyle(workbook, 2, "�s�ө���", "TOT");//�X�p�`�p��r((����))
        HSSFCellStyle style7 = createStyle(workbook, 3, "�s�ө���", "TOT");//�X�p�`�p�Ʀr((����))

        //detail
        for (int group1 = 0; group1 < rtnList.size(); group1++) {
            List group1List = (List) rtnList.get(group1);

            for (int group2 = 0; group2 < group1List.size(); group2++) {
                if (group2 == group1List.size() - 1) {
                    //�ĤG�hgroup�p�p
                    Map dataMap = (Map) group1List.get(group2);
                    row = sheet.createRow(beginRow);
                    setColumn(sheet, row, style6, 0, MapUtils.getString(dataMap, "DIV_NO") + MapUtils.getString(dataMap, "DIV_NAME"),
                        false, true, beginRow, beginRow, 0, 3);
                    setColumn(sheet, row, style7, 4, LD.formatNumber(dataMap.get("DACNT_AMT_NEW"), 0, null), true, false, null, null, null,
                        null);
                    setColumn(sheet, row, style7, 5, LD.formatNumber(dataMap.get("BAL_AMT"), 0, null), true, false, null, null, null, null);
                    setColumn(sheet, row, style6, 6, "", false, true, beginRow, beginRow, 6, 7);
                    beginRow++;
                    if (group1 == 0) {
                        beginRow++;
                    }
                } else {
                    List group2List = (List) group1List.get(group2);
                    for (int index = 0; index < group2List.size(); index++) {
                        Map dataMap = (Map) group2List.get(index);
                        if (index == (group2List.size() - 1)) {

                            row = sheet.createRow(beginRow);
                            beginRow++;
                            //setColumn(sheet, row, style4, 6, "", false, true, beginRow, beginRow, 6, 7);
                            //�̤p�hgroup�p�p
                            row = sheet.createRow(beginRow);
                            setColumn(sheet, row, style4, 0,
                                LD.formatDate(Date.valueOf(MapUtils.getString(dataMap, "SLIP_DATE")), "/", null), false, true, beginRow,
                                beginRow, 0, 1);
                            setColumn(sheet, row, style4, 2, MessageUtil.getMessage("EPC2_3050_UI_COUNT")/*����:*/
                                    + MapUtils.getString(dataMap, "count"), false, true, beginRow, beginRow, 2, 3);
                            setColumn(sheet, row, style5, 4, LD.formatNumber(dataMap.get("DACNT_AMT_NEW"), 0, null), true, false, null,
                                null, null, null);
                            setColumn(sheet, row, style5, 5, LD.formatNumber(dataMap.get("BAL_AMT"), 0, null), true, false, null, null,
                                null, null);
                            setColumn(sheet, row, style4, 6, "", false, true, beginRow, beginRow, 6, 7);

                            beginRow++;

                        } else {
                            //�C��data
                            row = sheet.createRow(beginRow);
                            setColumn(sheet, row, style2, 0,
                                LD.formatDate(Date.valueOf(MapUtils.getString(dataMap, "SLIP_DATE")), "/", null), false, false, null, null,
                                null, null);
                            setColumn(sheet, row, style2, 1, MapUtils.getString(dataMap, "TMP_NO"), false, false, null, null, null, null);
                            setColumn(sheet, row, style2, 2, MapUtils.getString(dataMap, "CUS_NO"), false, false, null, null, null, null);
                            setColumn(sheet, row, style2, 3, MapUtils.getString(dataMap, "ID"), false, false, null, null, null, null);
                            setColumn(sheet, row, style3, 4, LD.formatNumber(dataMap.get("DACNT_AMT_NEW"), 0, null), true, false, null,
                                null, null, null);
                            setColumn(sheet, row, style3, 5, LD.formatNumber(dataMap.get("BAL_AMT"), 0, null), true, false, null, null,
                                null, null);
                            setColumn(sheet, row, style8, 6, MapUtils.getString(dataMap, "BLD_NAME"), false, false, null, null, null, null);
                            setColumn(sheet, row, style2, 7, MapUtils.getString(dataMap, "BLD_CD"), false, false, null, null, null, null);
                            beginRow++;

                            row = sheet.createRow(beginRow);
                            setColumn(sheet, row, style2, 0, "", false, false, null, null, null, null);
                            setColumn(sheet, row, style2, 1, MapUtils.getString(dataMap, "CRT_NO"), false, false, null, null, null, null);

                            setColumn(sheet, row, style8, 2, StringUtils.trim(MapUtils.getString(dataMap, "CUS_NAME")), false, true,
                                beginRow, beginRow, 2, 6);
                            //setColumn(sheet, row, style2, 6, "", false, true, beginRow, beginRow, 6, 7);
                            beginRow++;
                        }
                    }
                }
            }
        }
        //�`�p
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style6, 0, MessageUtil.getMessage("EPC2_3050_UI_TOT")/*�`�p*/, false, true, beginRow, beginRow, 0, 3);
        setColumn(sheet, row, style7, 4, LD.formatNumber(TOTMap.get("DACNT_AMT_NEW"), 0, null), true, false, null, null, null, null);
        setColumn(sheet, row, style7, 5, LD.formatNumber(TOTMap.get("BAL_AMT"), 0, null), true, false, null, null, null, null);
        setColumn(sheet, row, style6, 6, "", false, true, beginRow, beginRow, 6, 7);

        //-----------------------------���Ӹ��(�t�X�p,�s�դp�p)-----------------------//

        return rtnList;
    }

    private File export8(List<Map> rptList, BigDecimal YEAR_MONTH, String fileName) throws Exception {

        StringBuilder sb = new StringBuilder();
        BufferedWriter bw = null;
        File file = RptUtils.createTempFile(fileName);
        try {
            bw = EncodingHelper.getBufferedWriter(file);
            // �ܼƪ�l�ơG
            String VAR1 = "151506607"; //TODO �N�X?
            String VAR2 = "48798595"; //TODO �N�X?
            int index = 1;

            //�v���g�J
            for (Map map : rptList) {
                //180712 :���]�w�]��,�קK�X�{"NULL"
                String RCV_YM_ROC = MapUtils.getString(map, "YEAR_MONTH", "");//�C���ɧ���Ʈw�����~��,�d�߱����J�_�Ƥ�,���d��Ӥ�(ex.YEAR_MONTH=201805;��201805,06���)
                String TAX_CD = MapUtils.getString(map, "TAX_CD", "");
                String TYPE_CODE = MapUtils.getString(map, "TYPE_CODE", "");
                String BUILD_ID = STRING.fillBlank(MapUtils.getString(map, "BUILD_ID", ""), 8, EncodingHelper.DefaultCharset);
                String INVOICE_NO = MapUtils.getString(map, "INVOICE_NO", "");

                //180712 �վ�:
                //�k�H:INVOICE_AMOUNT = SAL_AMT(���t�|),INVOICE_TAX = TAX_AMT
                //�D�k�H:INVOICE_AMOUNT = SAL_AMT+TAX_AMT(�t�|),INVOICE_TAX = 0
                int SAL_AMT = MapUtils.getIntValue(map, "SAL_AMT", 0);
                int TAX_AMT = MapUtils.getIntValue(map, "TAX_AMT", 0);
                int INVOICE_AMOUNT;
                int INVOICE_TAX;
                if (StringUtils.isNotBlank(BUILD_ID)) {//�k�H(���νs)
                    INVOICE_AMOUNT = SAL_AMT;
                    INVOICE_TAX = TAX_AMT;
                } else {
                    INVOICE_AMOUNT = SAL_AMT + TAX_AMT;
                    INVOICE_TAX = 0;
                }

                String sTAXTP = "";
                if ("2".equals(TAX_CD)) {//180712 �վ�: 2:0�|�v
                    sTAXTP = "1";
                }

                //STR = TYPE_CODE + VAR1 + ����0(index,7) + YEAR_MONTH + BUILD_ID + VAR2 
                //+ INVOICE_NO + ����0(INVOICE_AMOUNT,12) + TAX_CD + ����0(INVOICE_TAX,10) + " " + "      " + " " + sTAXTP
                sb.setLength(0);
                sb.append(TYPE_CODE).append(VAR1).append(STRING.fillZero(String.valueOf(index), 7, EncodingHelper.DefaultCharset))
                        .append(RCV_YM_ROC).append(BUILD_ID).append(VAR2).append(INVOICE_NO)
                        .append(STRING.fillZero(String.valueOf(INVOICE_AMOUNT), 12, EncodingHelper.DefaultCharset)).append(TAX_CD)
                        .append(STRING.fillZero(String.valueOf(INVOICE_TAX), 10, EncodingHelper.DefaultCharset)).append("        ")
                        .append(sTAXTP).append(STRING.lineSeparator);
                index++;
                bw.write(sb.toString());
            }
            bw.flush();
        } finally {
            if (bw != null) {
                bw.close();
            }
        }
        return file;
    }

    /**
     * �]�w���j�p
     * @param sheet
     */
    private void getSheetColumnWidth(HSSFSheet sheet, int colCount) {
        for (int i = 0; i < colCount; i++) {
            sheet.setColumnWidth(i, 30 * 256);
        }

    }

    private void getSheetColumnWidth4(HSSFSheet sheet, int colCount) {
        sheet.setColumnWidth(0, 45 * 32);
        sheet.setColumnWidth(1, 94 * 32);
        sheet.setColumnWidth(2, 53 * 32);
        sheet.setColumnWidth(3, 89 * 32);
        sheet.setColumnWidth(4, 29 * 32);
        sheet.setColumnWidth(5, 232 * 32);
        sheet.setColumnWidth(6, 75 * 32);
        sheet.setColumnWidth(7, 75 * 32);
        sheet.setColumnWidth(8, 75 * 32);
        sheet.setColumnWidth(9, 67 * 32);
    }

    /**
     * �]�w���j�p
     * @param sheet
     */
    private void getSheetColumnWidthForQry7(HSSFSheet sheet, int colCount) {
        sheet.setColumnWidth(0, 81 * 32);
        sheet.setColumnWidth(1, 130 * 32);
        sheet.setColumnWidth(2, 50 * 32);
        sheet.setColumnWidth(3, 115 * 32);
        sheet.setColumnWidth(4, 98 * 32);
        sheet.setColumnWidth(5, 98 * 32);
        sheet.setColumnWidth(6, 149 * 32);
        sheet.setColumnWidth(7, 81 * 32);
    }

    /**
     * �]�w���W��
     * @param sheet
     * @param colName 
     * @param style1
     * @param beginRow
     */
    private void getColumnName(HSSFSheet sheet, HSSFRow row, String[] colName, HSSFCellStyle style1, int beginRow) {
        int count = colName.length;
        row = sheet.createRow(beginRow);
        for (int i = 0; i < count; i++) {
            setColumn(sheet, row, style1, i, MessageUtil.getMessage(colName[i]), false, false, null, null, null, null);
        }
    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @return
     */
    private HSSFCellStyle createStyle(HSSFWorkbook workbook, int type, String font_type, String Border) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();
        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12); // �j�p
        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);
        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�j���Y
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            font.setFontHeightInPoints((short) 22); // �j�p         
        } else if (type == 1) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.BLACK.index);
            font.setColor(HSSFColor.BLACK.index);
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 3) {//���ӼƦr
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        } else if (type == 5) {
            font.setFontHeightInPoints((short) 10); // �j�p
        }
        style.setFont(font);

        if ("ALL".equals(Border)) {
            //�~��
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        } else if ("BUTTOM".equals(Border)) {
            style.setBorderBottom(HSSFCellStyle.BORDER_DOUBLE);
            font.setBoldweight(Font.BOLDWEIGHT_BOLD);//����
        } else if ("TOT".equals(Border)) {
            font.setBoldweight(Font.BOLDWEIGHT_BOLD);//����
            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        }
        return style;
    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @return
     */
    private HSSFCellStyle createStyle_2(HSSFWorkbook workbook, int type, String font_type, String Border, int fontSize, int fontHeight) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();
        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) fontSize); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);
        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�j���Y
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            font.setFontHeightInPoints((short) 22); // �j�p         
        } else if (type == 1) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.BLACK.index);
            font.setColor(HSSFColor.BLACK.index);
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 3) {//���ӼƦr
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        } else if (type == 5) {
            font.setFontHeightInPoints((short) 10); // �j�p
        }
        style.setFont(font);

        if ("ALL".equals(Border)) {
            //�~��
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        } else if ("BUTTOM".equals(Border)) {
            style.setBorderBottom(HSSFCellStyle.BORDER_DOUBLE);
            font.setBoldweight(Font.BOLDWEIGHT_BOLD);//����
        } else if ("TOT".equals(Border)) {
            font.setBoldweight(Font.BOLDWEIGHT_BOLD);//����
            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        }
        return style;
    }

    /**
     *  �]�w���
     * @param sheet
     * @param bodyRow
     * @param style ���A
     * @param columnNumber ���ͲĴX��cell
     * @param content  ���
     * @param isNumeric �O�_���Ʀr���
     * @param doCombine �O�_�ݦX���x�s��
     * @param firstRow
     * @param lastRow
     * @param firstCol
     * @param lastCol
     */
    private void setColumn(HSSFSheet sheet, HSSFRow bodyRow, HSSFCellStyle style, Integer columnNumber, String content, boolean isNumeric,
            boolean doCombine, Integer firstRow, Integer lastRow, Integer firstCol, Integer lastCol) {

        HSSFCell bodyCell;
        bodyCell = bodyRow.createCell(columnNumber);
        bodyCell.setCellStyle(style);

        if (doCombine) {
            for (int s = firstCol; s <= lastCol; s++) {
                bodyCell = bodyRow.createCell(s);
                bodyCell.setCellStyle(style);
            }

            //�X���x�s��
            CellRangeAddress range_inputCount = new CellRangeAddress(firstRow, lastRow, firstCol, lastCol);
            sheet.addMergedRegion(range_inputCount);

            bodyCell = bodyRow.getCell(firstCol);
        }

        if (isNumeric) {
            if (StringUtils.isNotBlank(content)) {
                bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                bodyCell.setCellValue(content);
            }
        } else {
            HSSFRichTextString text = new HSSFRichTextString(content);
            bodyCell.setCellValue(text);
        }
    }

    /**
     * �̤����q�O���o���W��
     * @param SUB_CPY_ID
     * @param DIV_NO
     * @param theEP_Z00030
     * @param dd
     * @return
     */
    private String getDivName(String SUB_CPY_ID, String DIV_NO, EP_Z00030 theEP_Z00030, DivData dd) {
        String DIV_NAME = "";
        try {
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                DIV_NAME = dd.getUnit4ShortName(DIV_NO);
            } else {
                DIV_NAME = FieldOptionList.getName("EP", "DIVNO_" + SUB_CPY_ID, DIV_NO);
            }
        } catch (Exception e) {
            log.error("���o���W�ٿ��~", e);
        }

        return DIV_NAME;
    }

}
