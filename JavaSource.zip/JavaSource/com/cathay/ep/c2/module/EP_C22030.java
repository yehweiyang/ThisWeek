package com.cathay.ep.c2.module;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.c0.module.EP_C0Z001;
import com.cathay.ep.z0.module.EP_Z0C101;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE     Description     Author
 * 2013/09/17   Created     ���|��
 * 2018/01/29   1.1      �վ�o���~�W�榡         ����[
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �o���@�o���@�Ҳ�
 * �Ҳ�ID    EP_C22030
 * ���n����    �o���@�o���@�Ҳ�
 * </pre>
 * 
 * @author ����[
 * @since 2013-11-22
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C22030 {

    private static final String SQL_getEPC201_001 = "com.cathay.ep.c2.module.EP_C22030.SQL_getEPC201_001";

    private static final String SQL_query_001 = "com.cathay.ep.c2.module.EP_C22030.SQL_query_001";

    private static final String SQL_confirm_001 = "com.cathay.ep.c2.module.EP_C22030.SQL_confirm_001";

    //private static final String SQL_confirm_002 = "com.cathay.ep.c2.module.EP_C22030.SQL_confirm_002";

    //private static final String SQL_confirm_003 = "com.cathay.ep.c2.module.EP_C22030.SQL_confirm_003";

    private static final String SQL_confirm_004 = "com.cathay.ep.c2.module.EP_C22030.SQL_confirm_004";

    private static final String SQL_confirm_005 = "com.cathay.ep.c2.module.EP_C22030.SQL_confirm_005";

    //private static final String SQL_unconfirm_001 = "com.cathay.ep.c2.module.EP_C22030.SQL_unconfirm_001";

    //private static final String SQL_unconfirm_002 = "com.cathay.ep.c2.module.EP_C22030.SQL_unconfirm_002";

    private static final String SQL_unconfirm_003 = "com.cathay.ep.c2.module.EP_C22030.SQL_unconfirm_003";

    private static final String SQL_unconfirm_004 = "com.cathay.ep.c2.module.EP_C22030.SQL_unconfirm_004";

    /**
     * �o�����X��Ƭd��
     * @param SUB_CPY_ID    �����q�O
     * @param INV_NO        �o�����X
     * @return  rtnMap      �o�����X���
     * @throws ModuleException
     */
    public Map query(String SUB_CPY_ID, String INV_NO) throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22030_MSG_001"));//�����q�O���������
        }
        if (StringUtils.isBlank(INV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22030_MSG_002"));//�o�����X���������
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_query_001);

        //�B�z�N�X����
        //�s�W����^�ǲM�� 
        rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
        rtnMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE")));
        rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND_FOUR", MapUtils.getString(rtnMap, "PAY_KIND")));
        rtnMap.put("INV_CD_NM", FieldOptionList.getName("EP", "INV_CD", MapUtils.getString(rtnMap, "INV_CD")));

        //�վ�~�W�榡
        new EP_C0Z001().getPIN_NAMEForQuery(rtnMap, null, null);

        return rtnMap;
    }

    /**
     * �o���@�o�T�{
     * @param invNoMap  �o������
     * @param EMP_ID    �T�{�H��
     * @param EMP_NAME  �T�{�H���m�W
     * @param DIV_NO    �T�{�H�����
     * @throws ModuleException
     * @throws SQLException
     */
    public void confirm(Map invNoMap, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22030_MSG_003"));//�o�����Ӭ��������
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22030_MSG_004"));//�T�{�H�����������
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22030_MSG_005"));//�T�{�H���m�W���������
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22030_MSG_006"));//�T�{�H����쬰�������
        }
        if (eie != null) {
            throw eie;
        }

        String trn_kind;
        String inv_cd;
        //���o�����Ѽ�:�O�_���X�bisAcnt�B�������trn_kind�B�o�����Ainv_cd
        String PAY_KIND = MapUtils.getString(invNoMap, "PAY_KIND");
        if ("6".equals(PAY_KIND)) {
            trn_kind = "EPC205";//�@�o���X�b
            inv_cd = "3";//�@�o���X�b
        } else {
            trn_kind = "EPC204";//�o���@�o
            inv_cd = "1";//�o���@�o
        }

        DataSet ds = Transaction.getDataSet();
        String SUB_CPY_ID = MapUtils.getString(invNoMap, "SUB_CPY_ID");
        String INV_NO = MapUtils.getString(invNoMap, "INV_NO");
        String CRT_NO = MapUtils.getString(invNoMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(invNoMap, "CUS_NO");
        String RCV_YM = MapUtils.getString(invNoMap, "RCV_YM");
        String strCurrTimeStamp = DATE.getDBTimeStamp();

        //�Y�������o���A�h���P�_�O�_����s����_�ӯ�����(DTEPB102)
        String strAplyNo = "";
        if ("1".equals(PAY_KIND)) {
            ds.setField("INV_NO", INV_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("CUS_NO", CUS_NO);
            ds.setField("RCV_YM", RCV_YM);
            DBUtil.searchAndRetrieve(ds, SQL_confirm_001);
            ds.next();
            int cnt = (Integer) ds.getField(0);

            if (cnt == 0) {//�Y�L�s�}���o����ơA�h��s����_�ӯ�����(DTEPB102)
                Map updMapB301 = new HashMap();
                updMapB301.put("SUB_CPY_ID", SUB_CPY_ID);
                updMapB301.put("BLD_CD", invNoMap.get("BLD_CD"));
                updMapB301.put("CRT_NO", CRT_NO);
                updMapB301.put("UPD_TRN_KIND", trn_kind);
                updMapB301.put("UPD_DATE", strCurrTimeStamp);
                updMapB301.put("CHG_ID", EMP_ID);
                updMapB301.put("CHG_DIV_NO", DIV_NO);
                updMapB301.put("CHG_NAME", EMP_NAME);

                strAplyNo = new EP_B30010().insertForUpdMain(updMapB301);

                updMapB301.clear();
                updMapB301.put("SUB_CPY_ID", SUB_CPY_ID);
                updMapB301.put("CUS_NO", CUS_NO);
                updMapB301.put("CRT_NO", CRT_NO);
                updMapB301.put("UPD_TRN_KIND", trn_kind);
                updMapB301.put("UPD_DATE", strCurrTimeStamp);
                updMapB301.put("UPD_APLY_NO", strAplyNo);
                updMapB301.put("CHG_ID", EMP_ID);
                updMapB301.put("CHG_DIV_NO", DIV_NO);
                updMapB301.put("CHG_NAME", EMP_NAME);
                updMapB301.put("NEXT_PAY_DATE", invNoMap.get("PAY_S_DATE"));
                new EP_B10020().updateCUSInfo(updMapB301);
            }

        }

        String RCV_NO = MapUtils.getString(invNoMap, "RCV_NO");
        //�Yú�ں�����1:�����B3: �޲z�O�B4:�H�����B5:���X���a�B7:��L�A�h��s�����ɻP�f��i��
        if ("1".equals(PAY_KIND) || "3".equals(PAY_KIND) || "4".equals(PAY_KIND) || "5".equals(PAY_KIND) || "7".equals(PAY_KIND) || "8".equals(PAY_KIND)) {
            //�I�s�������@�Ҳէ�s�������A
            new EP_Z0C101().failInvoice(invNoMap, EMP_ID, EMP_NAME, DIV_NO);
            //�d�������ɨ��o�f��s��strFlowNo
            /*ds.clear();
            ds.setField("RCV_NO", RCV_NO);
            DBUtil.searchAndRetrieve(ds, SQL_confirm_002);
            ds.next();
            String strFlowNo = (String) ds.getField(0);
            
            new RZ_N0Z001().assignOPStatus(strFlowNo, "�o���@�o", "�@�o�T�{", "99", EMP_ID, DIV_NO);//�f��y�{�s���B�@�~�����B��ܻ����B�@�~�H���B�@�~���
            ds.clear();
            ds.setField("LST_PROC_DATE", strCurrTimeStamp);
            ds.setField("EMP_ID", EMP_ID);
            ds.setField("DIV_NO", DIV_NO);
            ds.setField("EMP_NAME", EMP_NAME);
            ds.setField("RCV_NO", RCV_NO);
            DBUtil.executeUpdate(ds, SQL_confirm_003);*/

        }

        //�Yú�ں�����3: �޲z�O�A�h��s�޲z�O���u�������(DTEPC103)
        if ("3".equals(PAY_KIND)) {
            ds.clear();
            ds.setField("RCV_NO", RCV_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_confirm_004);
        }

        //��s�o����(DTEPC202)
        ds.clear();
        ds.setField("INV_CD", inv_cd);
        ds.setField("TRN_KIND", trn_kind);
        ds.setField("CHG_DATE", strCurrTimeStamp);
        ds.setField("CHG_DIV_NO", DIV_NO);
        ds.setField("CHG_ID", EMP_ID);
        ds.setField("CHG_NAME", EMP_NAME);
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", strAplyNo);
        DBUtil.executeUpdate(ds, SQL_confirm_005);

    }

    /**
     * �o���@�o����
     * @param invNoMap  �o������
     * @param userObj   �����H����T
     * @throws ModuleException
     */
    public void unconfirm(Map invNoMap, UserObject userObj) throws ModuleException {
        ErrorInputException eie = null;
        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22030_MSG_003"));//�o�����Ӭ��������
        }
        if (userObj == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22030_MSG_007"));//�����H����T���������
        }
        if (eie != null) {
            throw eie;
        }

        //�Y�o���@�o���z�s�������šA�h����_��s����_�ӯ�����(DTEPB102)
        String APLY_NO = MapUtils.getString(invNoMap, "APLY_NO");
        String SUB_CPY_ID = MapUtils.getString(invNoMap, "SUB_CPY_ID");
        if (StringUtils.isNotBlank(APLY_NO)) {
            String CRT_NO = MapUtils.getString(invNoMap, "CRT_NO");
            String CUS_NO = MapUtils.getString(invNoMap, "CUS_NO");
            Map updMapB102 = new HashMap();
            updMapB102.put("SUB_CPY_ID", SUB_CPY_ID);
            updMapB102.put("CRT_NO", CRT_NO);
            updMapB102.put("CUS_NO", CUS_NO);
            if ("1".equals(MapUtils.getString(invNoMap, "INV_CD"))) {
                updMapB102.put("UPD_TRN_KIND", "EPC204");
            } else {
                updMapB102.put("UPD_TRN_KIND", "EPC205");
            }
            updMapB102.put("UPD_DATE", MapUtils.getString(invNoMap, "D_CFM_DATE"));
            updMapB102.put("UPD_APLY_NO", APLY_NO);

            new EP_B10020().recoverCUSInfo(updMapB102, userObj);
        }

        DataSet ds = Transaction.getDataSet();
        //�Yú�ں�����1:�����B3: �޲z�O�B4:�H�����B5:���X���a�B7:��L�A�h��s�����ɻP�f��i��
        String PAY_KIND = MapUtils.getString(invNoMap, "PAY_KIND");
        String RCV_NO = MapUtils.getString(invNoMap, "RCV_NO");
        String EMP_ID = userObj.getEmpID();
        String OpUnit = userObj.getOpUnit();
        String EMP_NAME = userObj.getEmpName();
        String CURRENTTIMESTAMP = DATE.getDBTimeStamp();
        if ("1".equals(PAY_KIND) || "3".equals(PAY_KIND) || "4".equals(PAY_KIND) || "5".equals(PAY_KIND) || "7".equals(PAY_KIND) || "8".equals(PAY_KIND)) {
            //�I�s�������@�Ҳզ^�_�������A
            new EP_Z0C101().cancelFailInvoice(invNoMap, EMP_ID, EMP_NAME, OpUnit);
            //�d�������ɨ��o�f��s��strFlowNo
            /*ds.setField("RCV_NO", RCV_NO);
            DBUtil.searchAndRetrieve(ds, SQL_unconfirm_001);
            ds.next();
            String strFlowNo = (String) ds.getField(0);
            
            String strO_STATUS = new RZ_N0Z001().getPreStatus(strFlowNo, userObj);
            ds.clear();
            ds.setField("OP_STATUS", strO_STATUS);
            //ds.setField("OP_STATUS", "1");
            ds.setField("LST_PROC_DATE", CURRENTTIMESTAMP);
            ds.setField("LST_PROC_ID", EMP_ID);
            ds.setField("LST_PROC_DIV", OpUnit);
            ds.setField("LST_PROC_NAME", EMP_NAME);
            ds.setField("RCV_NO", RCV_NO);
            DBUtil.executeUpdate(ds, SQL_unconfirm_002);*/

        }

        if ("3".equals(PAY_KIND)) {
            ds.clear();
            ds.setField("RCV_NO", RCV_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_unconfirm_003);
        }

        ds.clear();
        ds.setField("CHG_DATE", CURRENTTIMESTAMP);
        ds.setField("CHG_ID", EMP_ID);
        ds.setField("CHG_DIV_NO", OpUnit);
        ds.setField("CHG_NAME", EMP_NAME);
        ds.setField("INV_NO", MapUtils.getString(invNoMap, "INV_NO"));
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_unconfirm_004);
    }

    /**
     * ���o�㯲�������ɸ��
     * @param SUB_CPY_ID    �����q�O
     * @param INV_NO        �o�����X
     * @return  rtnMap      �o�����X���
     * @throws ModuleException
     */
    public Map getEPC201(String SUB_CPY_ID, String INV_NO) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22030_MSG_001"));//�����q�O���������
        }
        if (StringUtils.isBlank(INV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22030_MSG_002"));//�o�����X���������
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findOneToMap(ds, SQL_getEPC201_001);

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
