package com.cathay.ep.c2.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.WorkDate;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.vo.DTEPB101;
import com.cathay.ep.vo.DTEPC201;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C201;
import com.cathay.util.Transaction;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/** 
 * <pre>
 * DATE Description Author 
 * 2013/10/1   Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��  �㯲�����B�z�Ҳ�
 * �Ҳ�ID    EP_C20010
 * ���n����  �㯲�����B�z�Ҳ�
 * </pre>
 * @author �¶��� 
 * @since 2013/10/31  
 * [20200203] ��عq�l�o���ɤJ : ����keep�o����Τ覡�B�R���L�ϥε{��
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C20010 {
    private static final Logger log = Logger.getLogger(EP_C20010.class);

    private static final String SQL_queryDTEPC301306_001 = "com.cathay.ep.c2.module.EP_C20010.SQL_queryDTEPC301306_001";

    private static final String SQL_deleteDTEPC201_001 = "com.cathay.ep.c2.module.EP_C20010.SQL_deleteDTEPC201_001";

    private static final String SQL_confirmAdd_001 = "com.cathay.ep.c2.module.EP_C20010.SQL_confirmAdd_001";

    private static final String SQL_confirmAdd_002 = "com.cathay.ep.c2.module.EP_C20010.SQL_confirmAdd_002";

    private static final String SQL_insertDTEPC105_001 = "com.cathay.ep.c2.module.EP_C20010.SQL_insertDTEPC105_001";

    private static final String SQL_queryDTEPC105_001 = "com.cathay.ep.c2.module.EP_C20010.SQL_queryDTEPC105_001";

    //private static final String SQL_queryDTEPC201_001 = "com.cathay.ep.c2.module.EP_C20010.SQL_queryDTEPC201_001";

    private static final String SQL_confirmAddSingle_001 = "com.cathay.ep.c2.module.EP_C20010.SQL_confirmAddSingle_001";

    private static final String SQL_innerProcess_001 = "com.cathay.ep.c2.module.EP_C20010.SQL_innerProcess_001";

    private static final String SQL_updateDTEPC105_001 = "com.cathay.ep.c2.module.EP_C20010.SQL_updateDTEPC105_001";

    //private static final String SQL_insertDTEPC201_001 = "com.cathay.ep.c2.module.EP_C20010.SQL_insertDTEPC201_001";

    private boolean isDebug = log.isDebugEnabled();

    private BigDecimal bd105 = new BigDecimal("1.05");

    private BigDecimal bd005 = new BigDecimal("0.05");

    EP_Z00030 theEP_Z00030 = new EP_Z00030();

    /**
     * ������ú�کl��~�״����������B�p��
     * @param inMap ��J�Ѽ�
     * @return tmpSUBPMS �������B
     * @throws ModuleException
     */
    private BigDecimal calSUBPMS(Map inMap) throws ModuleException {

        if (inMap == null || inMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C20010_MSG_001"));//�ǤJ��Ƥ��i����
        }

        String STRDT = MapUtils.getString(inMap, "STRDT"); //�p���_��
        String STPDT = MapUtils.getString(inMap, "STPDT"); //�p������
        BigDecimal PMSAM = obj2Big(inMap, "PMSAM", null);//������B
        BigDecimal PIMRT = obj2Big(inMap, "PIMRT", null);//�㯲����Q�v
        ErrorInputException eie = null;
        if (StringUtils.isBlank(STRDT) || !DATE.isDate(STRDT)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_003"));//�p���_�餣�o���ŭȥB�ݬ�����榡
        }
        if (StringUtils.isBlank(STPDT) || !DATE.isDate(STPDT)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_004"));//�p�����餣�o���ŭȥB�ݬ�����榡
        }
        if (PMSAM == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_005"));//������B���o���ŭ�
        }
        if (PIMRT == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_006"));//�㯲����Q�v���o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }

        //�ŧi�ܼ�
        BigDecimal intD = BigDecimal.ZERO;//�p���_�����
        BigDecimal tmpSUBPMS = BigDecimal.ZERO;//�������B
        //String tmpNEXT;//������
        String tmpDATE = STRDT; //����̫�@��

        //�p��Ĥ@�Ӥ�(�}��)
        if (DATE.diffDay(STRDT, STPDT) >= 0) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(Date.valueOf(STRDT));
            intD = new BigDecimal(String.valueOf(cal.getActualMaximum(Calendar.DAY_OF_MONTH)));//160219 modified by i9301216:��WorkDate.getDaysOfMonth �ݩ����~��i�h,���~
            int intSTRDT = Integer.parseInt(getMonth(STRDT));
            int intSTPDT = Integer.parseInt(getMonth(STPDT));
            if (intSTRDT < intSTPDT) {//�_�W���h�Ӥ�

                //  tmpSUBPMS = tmpSUBPMS  + PMSAM * PIMRT * ((intD - Day(tmpDATE) + 1) / intD)
                BigDecimal t = intD.subtract(new BigDecimal(getDay(tmpDATE))).add(BigDecimal.ONE);
                //���|�ˤ��J�A�֥[tmpSUBPMS
                tmpSUBPMS = tmpSUBPMS.add(PMSAM.multiply(PIMRT).multiply(t).divide(intD, 0, BigDecimal.ROUND_HALF_UP));
            } else {//�_�W��b����
                //tmpSUBPMS = tmpSUBPMS + PMSAM * PIMRT * ((DATE. diffDay (STRDT, STPDT) + 1) / intD) 
                BigDecimal t = new BigDecimal(String.valueOf(DATE.diffDay(STRDT, STPDT) + 1));
                //���|�ˤ��J�A�֥[tmpSUBPMS
                tmpSUBPMS = tmpSUBPMS.add(PMSAM.multiply(PIMRT).multiply(t).divide(intD, 0, BigDecimal.ROUND_HALF_UP));
            }

            //�p���������
            //tmpNEXT = DATE.getMonthFirstDate(ctoDate(WorkDate.getNextXMonth(Date.valueOf(STRDT), 1))); //���o�p���_�馸��1��
            tmpDATE = DATE.getMonthLastDate(ctoDate(WorkDate.getNextXMonth(Date.valueOf(STRDT), 1))); //���o�p���_�馸��̫�1��

            while (DATE.diffDay(tmpDATE, STPDT) >= 0) {
                tmpSUBPMS = tmpSUBPMS.add(PMSAM.multiply(PIMRT).multiply(BigDecimal.ONE).setScale(0, BigDecimal.ROUND_HALF_UP));// ���|�ˤ��J�A�֥[
                //tmpNEXT = DATE.getMonthFirstDate(ctoDate(WorkDate.getNextXMonth(Date.valueOf(tmpDATE), 1))); //�A���o����1��
                tmpDATE = DATE.getMonthLastDate(ctoDate(WorkDate.getNextXMonth(Date.valueOf(tmpDATE), 1))); //���o�p���_�馸��̫�1��
            }

            //�p��̫�@�Ӥ�(�P�_�O�_������)
            int inttmpDATE = Integer.parseInt(getMonth(DATE.getLastMonthFirstDate(tmpDATE)));
            if (intSTPDT != inttmpDATE) {
                cal.setTime(Date.valueOf(STPDT));
                intD = new BigDecimal(String.valueOf(cal.getActualMaximum(Calendar.DAY_OF_MONTH)));//160219 modified by i9301216:��WorkDate.getDaysOfMonth �ݩ����~��i�h,���~
                //(PMSAM * PIMRT * (Day(STPDT) / intD)
                BigDecimal t = new BigDecimal(getDay(STPDT));
                tmpSUBPMS = tmpSUBPMS.add(PMSAM.multiply(PIMRT).multiply(t).divide(intD, 0, BigDecimal.ROUND_HALF_UP));//�|�ˤ��J�A�֥[
            }

        }
        return tmpSUBPMS;
    }

    /**
     * �p��㯲��
     * @param inMap ��J�Ѽ�
     * @return tmpPMSINT �㯲�����B
     * @throws ModuleException
     */
    private BigDecimal calPMSINT(Map inMap) throws ModuleException {

        if (inMap == null || inMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C20010_MSG_001"));//�ǤJ��Ƥ��i����
        }

        String SWPDT = MapUtils.getString(inMap, "SWPDT");//��X��
        String PMISD = MapUtils.getString(inMap, "PMISD");//�p���_��
        String BEGDT = MapUtils.getString(inMap, "BEGDT");
        String ENDDT = MapUtils.getString(inMap, "ENDDT");
        BigDecimal PAYAM = obj2Big(inMap, "PAYAM", null);//��ú���B
        BigDecimal CSHAM = obj2Big(inMap, "CSHAM", null);
        BigDecimal PIMRT = obj2Big(inMap, "PIMRT", null);
        if (PAYAM == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C20010_MSG_025"));//��ú���B���i���ŭ�
        }

        //�ŧi�ܼ�
        BigDecimal tmpPMSINT = BigDecimal.ZERO;// �㯲�����B
        String dtBFSWP; //��X�e�@��
        String dtBFBEG; //����X�e�@��
        String dtSWPDT = null;
        String newSWP_DATE;
        if (DATE.isDate(SWPDT)) {
            dtSWPDT = SWPDT;
        }

        if (PAYAM.compareTo(BigDecimal.ZERO) == 0) { //'������X
            //�p���_��b����
            if (DATE.diffDay(BEGDT, PMISD) >= 0 && DATE.diffDay(PMISD, ENDDT) >= 0) {
                //'��X��>����
                if (DATE.diffDay(ENDDT, SWPDT) > 0) {
                    tmpPMSINT = calSUBPMS(addToInMap(PMISD, ENDDT, CSHAM, PIMRT));
                }

                //'��X��b����
                if (DATE.diffDay(BEGDT, SWPDT) >= 0 && DATE.diffDay(SWPDT, ENDDT) >= 0) {
                    dtBFSWP = DATE.addDate(dtSWPDT, 0, 0, -1);
                    tmpPMSINT = calSUBPMS(addToInMap(PMISD, dtBFSWP, CSHAM, PIMRT));
                }
            }

            //�p���_��<����
            if (DATE.diffDay(PMISD, BEGDT) > 0) {
                //��X��>����
                if (DATE.diffDay(ENDDT, SWPDT) > 0) {
                    dtBFBEG = DATE.addDate(BEGDT, 0, 0, -1);
                    tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(PMISD, dtBFBEG, CSHAM, PIMRT))); //�զ�MAP�ǤJ
                    tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(BEGDT, ENDDT, CSHAM, PIMRT))); //�զ�MAP�ǤJ
                } else {
                    //'��X��b����
                    if (DATE.diffDay(BEGDT, SWPDT) >= 0 && DATE.diffDay(SWPDT, ENDDT) >= 0) {
                        dtBFBEG = DATE.addDate(BEGDT, 0, 0, -1);
                        tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(PMISD, dtBFBEG, CSHAM, PIMRT))); //�զ�MAP�ǤJ
                        dtBFSWP = DATE.addDate(dtSWPDT, 0, 0, -1);
                        tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(BEGDT, dtBFSWP, CSHAM, PIMRT))); //�զ�MAP�ǤJ
                    } else {//'��X��<����
                        dtBFSWP = DATE.addDate(dtSWPDT, 0, 0, -1);
                        tmpPMSINT = calSUBPMS(addToInMap(PMISD, dtBFSWP, CSHAM, PIMRT));//�զ�MAP�ǤJ
                    }
                }

            }

        } else { //������X OR �L��X
            //'�p���_��b����

            if (DATE.diffDay(BEGDT, PMISD) >= 0 && DATE.diffDay(PMISD, ENDDT) >= 0) {
                //�L��X�� OR ��X��>����
                if (SWPDT == null || DATE.diffDay(ENDDT, SWPDT) > 0) {
                    tmpPMSINT = calSUBPMS(addToInMap(PMISD, ENDDT, CSHAM, PIMRT));
                }

                //��X��<���� 89/04/24
                else if (DATE.diffDay(SWPDT, BEGDT) > 0) {
                    tmpPMSINT = calSUBPMS(addToInMap(PMISD, ENDDT, PAYAM, PIMRT));
                }

                //��X��b����
                else if (DATE.diffDay(BEGDT, SWPDT) >= 0 && DATE.diffDay(SWPDT, ENDDT) >= 0) {
                    dtBFSWP = DATE.addDate(dtSWPDT, 0, 0, -1);
                    tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(PMISD, dtBFSWP, CSHAM, PIMRT)));
                    tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(dtSWPDT, ENDDT, PAYAM, PIMRT)));
                }
            }

            //'�p���_��<����
            if (DATE.diffDay(PMISD, BEGDT) > 0) {
                //'�L��X�� OR ��X��>����
                if (SWPDT == null || DATE.diffDay(ENDDT, SWPDT) > 0) {
                    dtBFBEG = DATE.addDate(BEGDT, 0, 0, -1);
                    tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(PMISD, dtBFBEG, CSHAM, PIMRT)));
                    tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(BEGDT, ENDDT, CSHAM, PIMRT)));
                } else {
                    //��X�� < �p���}�l��A���p��㯲��
                    newSWP_DATE = dtSWPDT;
                    if (DATE.diffDay(dtSWPDT, PMISD) > 0) {
                        newSWP_DATE = PMISD;
                    }
                    //'��X��b����
                    if (DATE.diffDay(BEGDT, SWPDT) >= 0 && DATE.diffDay(SWPDT, ENDDT) >= 0) {
                        dtBFBEG = DATE.addDate(BEGDT, 0, 0, -1);
                        tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(PMISD, dtBFBEG, CSHAM, PIMRT)));
                        dtBFSWP = DATE.addDate(dtSWPDT, 0, 0, -1);
                        tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(BEGDT, dtBFSWP, CSHAM, PIMRT)));
                        tmpPMSINT = tmpPMSINT.add(tmpPMSINT.add(calSUBPMS(addToInMap(dtSWPDT, ENDDT, PAYAM, PIMRT))));
                    } else {//'��X��<����
                        //��X�� < �p���}�l��A���p��㯲��
                        if (DATE.diffDay(dtSWPDT, PMISD) > 0) {
                            dtBFBEG = DATE.addDate(BEGDT, 0, 0, -1);
                            tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(PMISD, dtBFBEG, PAYAM, PIMRT)));
                            tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(BEGDT, ENDDT, PAYAM, PIMRT)));
                        } else {
                            dtBFSWP = DATE.addDate(dtSWPDT, 0, 0, -1);
                            tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(PMISD, dtBFSWP, CSHAM, PIMRT)));
                            dtBFBEG = DATE.addDate(BEGDT, 0, 0, -1);
                            tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(newSWP_DATE, dtBFBEG, PAYAM, PIMRT)));
                            tmpPMSINT = tmpPMSINT.add(calSUBPMS(addToInMap(BEGDT, ENDDT, PAYAM, PIMRT)));
                        }
                    }
                }
            }
        }
        return tmpPMSINT;
    }

    /**
     * ���
     * @param INT_YM �p���~��(�榡�GYYYYMM)
     * @param user �@�~�H����T
     * @throws ModuleException
     */

    public void confirmAdd(String INT_YM, String SUB_CPY_ID, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(INT_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_018"));//�p���~�뤣�o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_026"));//�����q�O���i����
        }
        if (eie != null) {
            throw eie;
        }
        //�ŧi�ܼ�
        String dtBEGDT; //'���
        String dtENDDT;//'�멳
        String dtNXTDT; // '�U���

        //�d�ߩ�����
        DataSet ds = Transaction.getDataSet();
        ds.setField("INT_YM", INT_YM);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        int cnt = DBUtil.searchAndRetrieve(ds, SQL_confirmAdd_001, false);
        if (cnt > 0) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20010_MSG_007"));//�w��L�㯲�����
        }
        //�]�w�_�W��
        dtBEGDT = DATE.getMonthFirstDate(INT_YM); //���o�p���~���1��
        dtENDDT = DATE.getMonthLastDate(INT_YM); //���o�p���~��̫�1��
        dtNXTDT = DATE.getMonthFirstDate(DATE.addDate(dtBEGDT, 0, 1, 0)); //���o�p���_�馸���1��

        //�d��ú�ڬ���
        ds.clear();
        BatchQueryDataSet bqds = null;
        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            bqds.setField("dtNXTDT", dtNXTDT);
            bqds.setField("dtBEGDT", dtBEGDT);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);

            bqds.searchAndRetrieve(SQL_confirmAdd_002);

            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            if (totalcount == 0) {//���:�Y�Ӥ�L�կ�����������`
                throw new DataNotFoundException("�d�L���");
            }
            int groupCount = 2000;//�C�妸�d��2000�����
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��

            List<Map> rtnList = new ArrayList<Map>();

            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map rtnMap = VOTool.dataSetToMap(bqds);
                    rtnList.add(rtnMap);
                }
            }

            log.debug("$$$$$$ 1.rtnList.size:" + rtnList.size());

            int tmpEXNUM = 0; //�s�WDTEPC201���
            BigDecimal tmpEXSUM = BigDecimal.ZERO; //�s�WDTEPC201�֭p�o�����B

            if (rtnList != null) {

                //���o�Q�v���
                //20200206 �u�ơG�d�L�Q�v��Ʃ߿�
                Map MONTH_RATE_MAP;
                try {
                    ds.clear();
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    //ds.setField("RATE_CD", RATE_CD);
                    ds.setField("YEAR", DATE.getY2KYear(DATE.getMonthFirstDate(INT_YM)));
                    List<Map> tmpRATE_List = VOTool.findToMaps(ds, SQL_innerProcess_001);
                    MONTH_RATE_MAP = new HashMap();
                    for (Map tmpRate : tmpRATE_List) {
                        MONTH_RATE_MAP.put(tmpRate.get("RATE_CD"), tmpRate.get("MONTH_RATE"));
                    }
                } catch (DataNotFoundException dnfe) {
                    throw new ModuleException("�d�L�Q�v��ơA�нT�{�O�_�w�s�W�Ӧ~�צ~�Q�v");
                }

                //�P�_�O�_���q�l�o��
                BigDecimal START_YM = STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO);
                boolean isEleInv = (new BigDecimal(INT_YM).compareTo(START_YM) >= 0);
                log.debug("##### isEleInv::" + isEleInv);

                List<DTEPC201> insertList = new ArrayList<DTEPC201>();
                for (Map rtnMap : rtnList) {
                    rtnMap.put("isEleInv", isEleInv);
                    String SWP_DATE = MapUtils.getString(rtnMap, "SWP_DATE");
                    String PMI_S_DATE = MapUtils.getString(rtnMap, "PMI_S_DATE");

                    if (((BigDecimal) rtnMap.get("PAY_AMT")).compareTo(BigDecimal.ZERO) == 0) {
                        if (StringUtils.isBlank(SWP_DATE) || StringUtils.isBlank(PMI_S_DATE)) {
                            continue;
                        } else {
                            if (DATE.diffDay(dtBEGDT, MapUtils.getString(rtnMap, "SWP_DATE")) <= 0 && DATE.diffDay(dtBEGDT, MapUtils.getString(rtnMap, "PMI_S_DATE")) <= 0) {
                                continue;
                            }
                        }
                    }

                    /*
                    //�Y�P�_�����ú���B��0(������X), ����
                    if (((BigDecimal) rtnMap.get("PAY_AMT")).compareTo(BigDecimal.ZERO) == 0) {
                       continue;
                    }
                    */

                    //�֥[�o�����B
                    tmpEXSUM = tmpEXSUM.add(innerProcess(rtnMap, INT_YM, dtBEGDT, dtENDDT, dtNXTDT, user, MONTH_RATE_MAP, insertList));
                    //�֭p�s�W���
                    tmpEXNUM++;
                }

                new EP_Z0C201().insertList(insertList);

                log.debug("$$$$$$ 2.tmpEXSUM:" + tmpEXSUM);
                log.debug("$$$$$$ 3.tmpEXNUM:" + tmpEXNUM);
            }

            //�s�W��������
            Map inMap = new HashMap();
            inMap.put("EXT_TYPE", "4");//������
            inMap.put("EXT_YM", INT_YM);//���~��
            inMap.put("CNT", tmpEXNUM);//���
            inMap.put("AMT", tmpEXSUM);//���B
            inMap.put("SUB_CPY_ID", SUB_CPY_ID);
            inMap.put("USEROBJECT", user);//�@�~�H����T
            insertDTEPC105(inMap);
        } catch (DBException dbe) {
            log.error("�d�ߥ���", dbe);
            throw new ModuleException(dbe);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            throw dnfe;
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            throw new ModuleException(e.getMessage());
        } finally {
            try {
                if (bqds != null) {
                    bqds.close();//�����妸�d�߳s�u
                }
            } catch (DBException e) {
            }

        }

    }

    /**
     * �s�W��������
     * @param inMap
     * @throws ModuleException
     */
    public void insertDTEPC105(Map inMap) throws ModuleException {
        if (inMap == null || inMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C20010_MSG_001"));//�ǤJ��Ƥ��i����
        }

        UserObject userObj = (UserObject) inMap.get("USEROBJECT");
        if (userObj == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C20010_MSG_002"));//�ϥΪ̪��󤣥i����
        }
        String SUB_CPY_ID = MapUtils.getString(inMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C20010_MSG_026"));//�����q�O���i����
        }

        String timeStamp = DATE.getDBTimeStamp();
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("EXT_TYPE", inMap.get("EXT_TYPE"));
        ds.setField("EXT_YM", inMap.get("EXT_YM"));
        ds.setField("CNT", inMap.get("CNT"));
        ds.setField("AMT", inMap.get("AMT"));
        ds.setField("EXT_DATE", timeStamp);
        ds.setField("CHG_DATE", timeStamp);
        ds.setField("CHG_DIV_NO", userObj.getDivNo());
        ds.setField("CHG_ID", userObj.getEmpID());
        ds.setField("CHG_NAME", userObj.getEmpName());

        DBUtil.executeUpdate(ds, SQL_insertDTEPC105_001);

    }

    /**
     * �d�ߩ��O����
     * @param EXT_TYPE ������
     * @param EXT_YM ���~��
     * @param SUB_CPY_ID �����q�O
     * @return rtnList ���O����
     * @throws ModuleException
     */
    public List<Map> queryDTEPC105(String EXT_TYPE, String EXT_YM, String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(EXT_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_016"));//���������o���ŭ�
        }
        if (StringUtils.isBlank(EXT_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_017"));//���~�뤣�o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_026"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("EXT_TYPE", EXT_TYPE);
        ds.setField("EXT_YM", EXT_YM);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryDTEPC105_001, false);

        if (rtnList == null) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20010_MSG_010"));//�d�L�����
        }
        return rtnList;
    }

    /**
     * ��s���O����
     * @param EXT_TYPE
     * @param EXT_YM
     * @param SUB_CPY_ID
     * @param INV_AMT
     * @param Type
     * @throws ModuleException
     */
    public void updateDTEPC105(String EXT_TYPE, String EXT_YM, String SUB_CPY_ID, String INV_AMT, String Type) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(EXT_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_016"));//���������o���ŭ�
        }
        if (StringUtils.isBlank(EXT_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_017"));//���~�뤣�o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_026"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(INV_AMT)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_027"));//�o�����B���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        Map rtnMap = queryDTEPC105(EXT_TYPE, EXT_YM, SUB_CPY_ID).get(0);
        BigDecimal CNT = obj2Big(rtnMap, "CNT", BigDecimal.ZERO); //���
        BigDecimal AMT = obj2Big(rtnMap, "AMT", BigDecimal.ZERO); //���B
        BigDecimal B_INV_AMT = "D".equals(Type) ? new BigDecimal(INV_AMT).negate() : new BigDecimal(INV_AMT); //�o�����B
        CNT = "D".equals(Type) ? CNT.subtract(BigDecimal.ONE) : CNT.add(BigDecimal.ONE);

        DataSet ds = Transaction.getDataSet();
        ds.setField("EXT_TYPE", EXT_TYPE);
        ds.setField("EXT_YM", EXT_YM);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CNT", CNT);
        ds.setField("AMT", AMT.add(B_INV_AMT));

        DBUtil.executeUpdate(ds, SQL_updateDTEPC105_001);
    }

    /**
     * ��@�ɩ��
     * @param INT_YM �p���~��(�榡�GYYYYMM)
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param RCV_NO �����s��
     * @param PAY_NO ú�O�s��
     * @param user �@�~�H����T
     * @throws ModuleException
     */
    public void confirmAddSingle(String INT_YM, String SUB_CPY_ID, String CRT_NO, String CUS_NO, String RCV_NO, String PAY_NO, UserObject user) throws ModuleException {

        if (StringUtils.isBlank(INT_YM)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C20010_MSG_018"));//�p���~�뤣�o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C20010_MSG_026"));//�����q�O���o���ŭ�
        }
        //�ŧi�ܼ�
        String dtBEGDT; //���
        String dtENDDT;//�멳
        String dtNXTDT; //�U���

        //�]�w�_�W��
        dtBEGDT = DATE.getMonthFirstDate(INT_YM); //���o�p���~���1��
        dtENDDT = DATE.getMonthLastDate(INT_YM); //���o�p���~��̫�1��
        dtNXTDT = DATE.getMonthFirstDate(DATE.addDate(dtBEGDT, 0, 1, 0)); //���o�p���_�馸���1��

        //�d�ߩ㯲������
        try {
            List<Map> C201List = queryDTEPC201(INT_YM, CRT_NO, CUS_NO, SUB_CPY_ID, PAY_NO);
            EP_C22010 theEP_C22010 = new EP_C22010();
            //�v�o�����X�d�ߵo����
            for (Map C201Map : C201List) {
                try {
                    if ("0".equals(MapUtils.getString(C201Map, "OP_STATUS"))) {
                        throw new ModuleException(MessageUtil.getMessage("EP_C20010_MSG_028"));//�������㯲�������w�s�b,�G���ɩ�
                    }

                    List<Map> rtnListC202 = theEP_C22010.queryDTEPC202ByInvno(MapUtils.getString(C201Map, "INV_NO"), SUB_CPY_ID);

                    if ("0".equals(MapUtils.getString(rtnListC202.get(0), "INV_CD"))) {
                        throw new ModuleException(MessageUtil.getMessage("EP_C20010_MSG_011"));//�������㯲�������w�s�b�B�o���å��@�o,�G���ɩ�
                    }
                } catch (DataNotFoundException dnfe) {
                    log.error("�d�L�o���ɸ��", dnfe);
                }

            }
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L�㯲�����Ӹ��", dnfe);
        }

        //�d��ú�ڬ���
        DataSet ds = Transaction.getDataSet();
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("dtNXTDT", dtNXTDT);
        //ds.setField("RCV_YM", INT_YM);
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_confirmAddSingle_001, false);
        if (rtnList == null) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20010_MSG_012"));//�L���������ú�ڬ���,�L�k����㯲��
        }

        BigDecimal tmpEXSUM = BigDecimal.ZERO; //�s�WDTEPC201�֭p�o�����B

        //���o�Q�v���
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("YEAR", DATE.getY2KYear(DATE.getMonthFirstDate(INT_YM)));
        List<Map> tmpRATE_List = VOTool.findToMaps(ds, SQL_innerProcess_001, false);
        Map MONTH_RATE_MAP = new HashMap();
        for (Map tmpRate : tmpRATE_List) {
            MONTH_RATE_MAP.put(tmpRate.get("RATE_CD"), tmpRate.get("MONTH_RATE"));
        }

        //�P�_�O�_���q�l�o��
        BigDecimal START_YM = STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO);
        boolean isEleInv = (new BigDecimal(INT_YM).compareTo(START_YM) >= 0);
        log.debug("##### isEleInv::" + isEleInv);

        List<DTEPC201> insertList = new ArrayList<DTEPC201>();
        for (Map rtnMap : rtnList) {
            rtnMap.put("isEleInv", isEleInv);
            //�֥[�o�����B
            tmpEXSUM = tmpEXSUM.add(innerProcess(rtnMap, INT_YM, dtBEGDT, dtENDDT, dtNXTDT, user, MONTH_RATE_MAP, insertList));
        }
        try {
            new EP_Z0C201().insertList(insertList);
        } catch (DBException dbe) {
            throw new ModuleException(dbe);
        }

        //��s��������
        updateDTEPC105("4", INT_YM, SUB_CPY_ID, tmpEXSUM.toString(), "I");
    }

    /**
     * �d�ߩ㯲��������
     * @param INT_YM �p���~��
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param SUB_CPY_ID �����q�O
     * @param PAY_NO ú�O�s��
     * @return rtnList ���O����
     * @throws ModuleException
     */
    public List<Map> queryDTEPC201(String INT_YM, String CRT_NO, String CUS_NO, String SUB_CPY_ID, String PAY_NO) throws ModuleException {

        //[20200326] sql�Ҳդ� 
        return new EP_Z0C201().queryDTEPC201(INT_YM, CRT_NO, CUS_NO, SUB_CPY_ID, PAY_NO);
    }

    /**
     * �R���㯲������
     * @param INT_NO �㯲���s��
     * @throws ModuleException
     */
    public void deleteDTEPC201(String INT_NO, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(INT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_019"));//�㯲���s�����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_026"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("INT_NO", INT_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            DBUtil.executeUpdate(ds, SQL_deleteDTEPC201_001);
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            throw new ModuleException(MessageUtil.getMessage("EP_C20010_MSG_014", new Object[] { INT_NO }));//�㯲���s��{0}�w�T�{�A���o�R��
        }
    }

    /**
     * ú�ڬd��
     * @param RCV_YM �p���~��
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param RCV_NO �����s��
     * @param PAY_NO ú�O�s��
     * @param SUB_CPY_ID �����q�O
     * @return rtnList ���O����
     * @throws ModuleException
     */
    public List<Map> queryDTEPC301306(String RCV_YM, String CRT_NO, String CUS_NO, String RCV_NO, String PAY_NO, String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;
        /*
         if (StringUtils.isBlank(RCV_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_020"));//�p���~�뤣�o���ŭ�
        }
        */
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_021"));//�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_022"));//�Ȥ�Ǹ����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_026"));//�����q�O���o���ŭ�
        }
        /*
        if (StringUtils.isBlank(RCV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_023"));//�����s�����o���ŭ�
        }
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20010_MSG_024"));//ú�O�s�����o���ŭ�
        }
        */
        if (eie != null) {
            throw eie;
        }

        //�d��ú�ڬ���
        DataSet ds = Transaction.getDataSet();
        //ds.setField("RCV_YM", RCV_YM);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //ds.setField("RCV_NO", RCV_NO);
        //ds.setField("PAY_NO", PAY_NO);

        int cnt = DBUtil.searchAndRetrieve(ds, SQL_queryDTEPC301306_001, false);
        if (cnt == 0) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20010_MSG_015"));//�d�Lú�ڬ������
        }
        List<Map> rtnList = new ArrayList<Map>();
        int seqCnt = 0;
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EP", "PAY_KIND", MapUtils.getString(rtnMap, "PAY_KIND"))); //ú�ں���
            rtnMap.put("PAY_TYPE_NM", FieldOptionList.getName("EP", "PAY_TYPE", MapUtils.getString(rtnMap, "PAY_TYPE"))); //ú�ڤ覡
            rtnMap.put("SEQ", ++seqCnt);//�Ǹ�
            rtnList.add(rtnMap);
        }

        return rtnList;

    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }

    /**
     * ��wEIE���� 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * ����calSUBPMS()�ǤJ�Ѽ�Formate
     * @param STRDT �p���_��
     * @param STPDT �p������
     * @param PMSAM ������B
     * @param PIMRT �㯲����Q�v
     * @return
     * @throws ModuleException
     */
    private Map addToInMap(String STRDT, String STPDT, BigDecimal PMSAM, BigDecimal PIMRT) throws ModuleException {
        Map tmpMap = new HashMap();
        tmpMap.put("STRDT", STRDT);
        tmpMap.put("STPDT", STPDT);
        tmpMap.put("PMSAM", PMSAM);
        tmpMap.put("PIMRT", PIMRT);

        return tmpMap;

    }

    /**
     * ���o���
     * @param dateFormate
     * @return
     * @throws ModuleException
     */
    private String getMonth(String dateFormate) throws ModuleException {
        return dateFormate.split("-")[1];
    }

    /**
     * ���o�Ѽ�
     * @param dateFormate
     * @return
     * @throws ModuleException
     */
    private String getDay(String dateFormate) throws ModuleException {
        return dateFormate.split("-")[2];
    }

    /**
     * ������O�૬
     * @param date
     * @return
     */
    private String ctoDate(java.util.Date date) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

        return df.format(date);
    }

    private String[] BLD_CDarys = new String[] { "A", "B", "C", "D", "E", "T" };

    /**
     * @param rtnMap
     * @param INT_YM
     * @param dtBEGDT
     * @param dtENDDT
     * @param dtNXTDT
     * @param user
     * @return
     * @throws ModuleException
     */
    private BigDecimal innerProcess(Map rtnMap, String INT_YM, String dtBEGDT, String dtENDDT, String dtNXTDT, UserObject user, Map MONTH_RATE_MAP, List<DTEPC201> insertList) throws ModuleException {

        String TAX_TYPE;
        String RATE_CD;
        String PIM_RATE;
        String DIV_NO;
        String PMI_E_DATE;
        String PMI_S_DATE;
        String SUB_CPY_ID = MapUtils.getString(rtnMap, "SUB_CPY_ID");
        BigDecimal PASS_DAY;
        BigDecimal PMS_AMT;
        BigDecimal tmpCAL = null;
        BigDecimal PMI_TAX; //'�|�B
        BigDecimal PMI_AMT; //'�P���B
        BigDecimal INV_AMT; //'�o�����B

        //�ˬd�����O�_�s�b
        String CRT_NO = MapUtils.getString(rtnMap, "CRT_NO"); //�����N��
        DTEPB101 EPB101VO = new DTEPB101();
        EPB101VO.setCRT_NO(CRT_NO);
        EPB101VO.setSUB_CPY_ID(SUB_CPY_ID);
        EPB101VO = VOTool.findByPK(EPB101VO, false);
        if (EPB101VO == null || EPB101VO.getRATE_CD() == null) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20010_MSG_008", new Object[] { CRT_NO }));//"�L({0})���������"
        }

        TAX_TYPE = EPB101VO.getTAX_TYPE(); //�|�O
        RATE_CD = EPB101VO.getRATE_CD(); //�Q�v�N��

        //�㯲����Q�v
        PIM_RATE = MapUtils.getString(MONTH_RATE_MAP, RATE_CD); //�㯲����Q�v
        if (StringUtils.isBlank(PIM_RATE)) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20010_MSG_009", new Object[] { CRT_NO }));//"�L({0})�~�קQ�v���"
        }

        //�̾ڤj�ӥN���Ĥ@�X�P�_�ӿ�O
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//���:�t�X��ؾɤJ���A101.�j�Ӻ޲z���,���קK��سW�h���v�T�����{���سW�h
            if (ArrayUtils.contains(BLD_CDarys, MapUtils.getString(rtnMap, "BLD_CD").substring(0, 1))) {
                DIV_NO = "8300100"; //���ʲ��ޤ@
            } else {
                DIV_NO = "8300200"; //���ʲ��ޤG
            }
        } else {
            DIV_NO = MapUtils.getString(rtnMap, "CLC_DIV_NO");
        }

        //�]�w�p���פ�
        BigDecimal xPAY_AMT = (BigDecimal) rtnMap.get("PAY_AMT");
        if (isDebug) {
            log.debug("@@@xPAY_AMT=" + xPAY_AMT);
        }
        if (xPAY_AMT.compareTo(BigDecimal.ZERO) == 0) {
            String xSWP_DATE = MapUtils.getString(rtnMap, "SWP_DATE");
            if (isDebug) {
                log.debug("@@@xPAY_AMT��0");
                log.debug("@@@xSWP_DATE=" + xSWP_DATE);
                log.debug("@@@dtNXTDT=" + dtNXTDT);
            }
            if (DATE.diffDay(dtNXTDT, xSWP_DATE) < 0) {
                PMI_E_DATE = DATE.addDate(xSWP_DATE, 0, 0, -1);
                if (isDebug)
                    log.debug("@@@PMI_E_DATE(��X��e�@��)=" + PMI_E_DATE);
            } else {
                PMI_E_DATE = dtENDDT;
                if (isDebug)
                    log.debug("@@@PMI_E_DATE(�멳)=" + PMI_E_DATE);
            }
        } else {
            PMI_E_DATE = dtENDDT;
            if (isDebug)
                log.debug("@@@����XPMI_E_DATE(�멳)=" + PMI_E_DATE);
        }

        PMI_S_DATE = MapUtils.getString(rtnMap, "PMI_S_DATE");
        //�g�L�Ѽ�
        PASS_DAY = new BigDecimal(String.valueOf(DATE.diffDay(PMI_S_DATE, PMI_E_DATE) + 1));

        //��ú���B        
        PMS_AMT = xPAY_AMT;

        //�p��㯲��
        Map inMap1 = new HashMap();
        String xPAY_TYPE = MapUtils.getString(rtnMap, "PAY_TYPE");
        String CSHAM = "";
        inMap1.put("PAYAM", rtnMap.get("PAY_AMT"));//��ú���B
        inMap1.put("SWPDT", rtnMap.get("SWP_DATE"));//��X���
        inMap1.put("PMISD", rtnMap.get("PMI_S_DATE"));//�㮧�p���_��
        inMap1.put("BEGDT", dtBEGDT);//���
        inMap1.put("ENDDT", dtENDDT);//�멳
        inMap1.put("PIMRT", PIM_RATE);//�㯲����Q�v
        CSHAM = MapUtils.getString(rtnMap, "ORN_AMT", "");//��ú���B
        inMap1.put("CSHAM", CSHAM);
        if (isDebug) {
            log.debug("@@@rtnMap=" + rtnMap);
            log.debug("@@@xPAY_TYPE=" + xPAY_TYPE);
            log.debug("@@@CSHAM=" + CSHAM);
            log.debug("@@@inMap1=" + inMap1);
        }
        tmpCAL = calPMSINT(inMap1);
        if (isDebug) {
            log.debug("@@@tmpCAL=" + tmpCAL);
        }

        //�̵|�O�]�w���|�B�� �B���P���B���B���o�����B��
        if ("3".equals(TAX_TYPE) || "4".equals(TAX_TYPE)) {
            PMI_TAX = BigDecimal.ZERO; //'�|�B
            PMI_AMT = tmpCAL; //'�P���B
            INV_AMT = tmpCAL; //'�o�����B

        } else {
            //PMI_TAX = (tmpCAL / 1.05 * 0.05)
            PMI_TAX = tmpCAL.divide(bd105, 12, BigDecimal.ROUND_HALF_UP).multiply(bd005).setScale(0, BigDecimal.ROUND_HALF_UP);//�|�ˤ��J���ܭӦ�
            PMI_AMT = tmpCAL.subtract(PMI_TAX);
            INV_AMT = tmpCAL;
        }

        //�զ�inMap�g�JDTEPC201
        DTEPC201 DTEPC201VO = new DTEPC201();
        DTEPC201VO.setINT_YM(new BigDecimal(INT_YM));//�p���~��
        DTEPC201VO.setSUB_CPY_ID(SUB_CPY_ID);
        DTEPC201VO.setCRT_NO(MapUtils.getString(rtnMap, "CRT_NO"));//�����N��
        DTEPC201VO.setCUS_NO((Integer) MapUtils.getObject(rtnMap, "CUS_NO"));//�Ȥ�Ǹ�
        DTEPC201VO.setPAY_NO(MapUtils.getString(rtnMap, "PAY_NO"));//ú�O�s��
        DTEPC201VO.setBLD_CD(MapUtils.getString(rtnMap, "BLD_CD"));//�j�ӥN��
        DTEPC201VO.setDIV_NO(DIV_NO);//�ӿ���
        DTEPC201VO.setID(MapUtils.getString(rtnMap, "ID"));//�ҥ󸹽X
        log.debug("==========### CUS_NAME=" + MapUtils.getString(rtnMap, "CUS_NAME"));
        DTEPC201VO.setCUS_NAME(MapUtils.getString(rtnMap, "CUS_NAME"));//�Ȥ�W��
        DTEPC201VO.setPMI_S_DATE(Date.valueOf(PMI_S_DATE));//�p���_��
        DTEPC201VO.setPMI_E_DATE(Date.valueOf(PMI_E_DATE));//�p���פ�
        DTEPC201VO.setPASS_DAY(PASS_DAY);// �g�L�Ѽ�
        DTEPC201VO.setPMS_AMT(PMS_AMT);//������B
        DTEPC201VO.setRAT_CD(RATE_CD);// �㮧�Q�v�N��
        DTEPC201VO.setPIM_RATE(new BigDecimal(PIM_RATE));//�㯲����Q�v
        DTEPC201VO.setPMI_AMT(PMI_AMT);//�㯲�����B
        DTEPC201VO.setPMI_TAX(PMI_TAX);//�㯲���|�B
        DTEPC201VO.setINV_AMT(INV_AMT);//�o�����B
        DTEPC201VO.setTAX_TYPE(TAX_TYPE);//�|�O
        DTEPC201VO.setLST_PROC_ID(user.getEmpID());//�@�~�H��ID
        DTEPC201VO.setLST_PROC_DIV(user.getDivNo());//�@�~���N��
        DTEPC201VO.setLST_PROC_NAME(user.getEmpName());//�@�~�H���m�W
        DTEPC201VO.setLST_PROC_DATE(DATE.currentTime());//�@�~�ɶ�

        DTEPC201VO.setRCV_NO(MapUtils.getString(rtnMap, "RCV_NO"));//�����s��
        //�����l���B
        if (StringUtils.isEmpty(CSHAM)) {
            DTEPC201VO.setORN_AMT(BigDecimal.ZERO);
        } else {
            DTEPC201VO.setORN_AMT(new BigDecimal(CSHAM));

        }
        //��X���
        String swpDate = MapUtils.getString(rtnMap, "SWP_DATE");
        if (swpDate == null) {
            DTEPC201VO.setSWP_DATE(null);
        } else {
            DTEPC201VO.setSWP_DATE(Date.valueOf(swpDate));//��X���

        }

        // [20200203] ��عq�l�o���ɤJ 
        String INV_TRANS_TYPE;
        if (MapUtils.getBooleanValue(rtnMap, "isEleInv", false)) {//�q�l�o��
            INV_TRANS_TYPE = MapUtils.getString(rtnMap, "INV_TRANS_TYPE", "A");

            //20200319 �t�ӡG��بS���ʶR�H�eEMAIL���A�ȡA�Gb2b�o���ҥH�ȥ����D
            if ("01".equals(SUB_CPY_ID) && "B".equals(INV_TRANS_TYPE)) {
                INV_TRANS_TYPE = "A";
            }
        } else {//�µo���Ҭ��ȥ�
            INV_TRANS_TYPE = "A";
        }
        DTEPC201VO.setINV_TRANS_TYPE(INV_TRANS_TYPE);

        insertList.add(DTEPC201VO);
        //new EP_Z0C201().insert(DTEPC201VO, user);
        return tmpCAL;
    }

    /**�妸�g�JDTEPC201
     * @param insertList
     * @throws ModuleException 
     * @throws DBException 
     * @throws DBException 
     * [20200326] SQL�ҲդơGEP_Z0C201.insertList
     */
    /*private void insertDTEPC201List(List<DTEPC201> insertList) throws ModuleException, DBException {
    
        BatchConstructor.processByBatch(insertList, SQL_insertDTEPC201_001, false, ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL, new BatchConstructor.ListHandler() {
            EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
    
            StringBuilder sb = new StringBuilder();
    
            protected <T> void setField(T Object, BatchUpdateDataSet buds) throws DBException {
    
                try {
                    DTEPC201 C201 = (DTEPC201) Object;
                    String SUB_CPY_ID = C201.getSUB_CPY_ID();
                    sb.setLength(0);
                    //���o�㯲���s��=�����q�O(2)+�����~��(6)+"I"+�y����(4)
                    int SER_NO = theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "022", "001", C201.getINT_YM().toString());
                    String INT_NO = sb.append(SUB_CPY_ID).append(C201.getINT_YM()).append("I").append(STRING.fillZero(String.valueOf(SER_NO), 4, EncodingHelper.Charset_UTF8)).toString();
                    if (isDebug) {
                        log.debug("INT_NO=" + INT_NO);
                    }
                    buds.setField("INT_NO", INT_NO);
                    buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    buds.setField("INT_YM", C201.getINT_YM());
                    buds.setField("CRT_NO", C201.getCRT_NO());
                    buds.setField("CUS_NO", C201.getCUS_NO());
                    buds.setField("PAY_NO", C201.getPAY_NO());
                    buds.setField("BLD_CD", C201.getBLD_CD());
                    buds.setField("DIV_NO", C201.getDIV_NO());
                    buds.setField("ID", C201.getID());
                    buds.setField("CUS_NAME", C201.getCUS_NAME());
                    buds.setField("PMI_S_DATE", C201.getPMI_S_DATE());
                    buds.setField("PMI_E_DATE", C201.getPMI_E_DATE());
                    buds.setField("PASS_DAY", C201.getPASS_DAY());
                    buds.setField("PMS_AMT", C201.getPMS_AMT());
                    buds.setField("RAT_CD", C201.getRAT_CD());
                    buds.setField("PIM_RATE", C201.getPIM_RATE());
                    buds.setField("PMI_AMT", C201.getPMI_AMT());
                    buds.setField("PMI_TAX", C201.getPMI_TAX());
                    buds.setField("INV_NO", C201.getINV_NO());
                    buds.setField("INV_AMT", C201.getINV_AMT());
                    buds.setField("TAX_TYPE", C201.getTAX_TYPE());
                    buds.setField("ACNT_DATE", C201.getACNT_DATE());
                    buds.setField("ACNT_ID", C201.getACNT_ID());
                    buds.setField("ACNT_NAME", C201.getACNT_NAME());
                    buds.setField("ACNT_DIV_NO", C201.getACNT_DIV_NO());
                    buds.setField("SLIP_LOT_NO", C201.getSLIP_LOT_NO());
                    buds.setField("SLIP_SET_NO", C201.getSLIP_SET_NO());
                    buds.setField("FLOW_NO", "");
                    buds.setField("OP_STATUS", "0");
                    buds.setField("LST_PROC_DATE", C201.getLST_PROC_DATE());
                    buds.setField("LST_PROC_ID", C201.getLST_PROC_ID());
                    buds.setField("LST_PROC_DIV", C201.getLST_PROC_DIV());
                    buds.setField("LST_PROC_NAME", C201.getLST_PROC_NAME());
                    buds.setField("SWP_DATE", C201.getSWP_DATE());
                    buds.setField("ORN_AMT", C201.getORN_AMT());
                    buds.setField("RCV_NO", C201.getRCV_NO());
                    buds.setField("INV_TRANS_TYPE", C201.getINV_TRANS_TYPE());
                    addBatchAndJoinGroup(buds);
                } catch (ModuleException me) {
                    throw new DBException(me);
                }
            }
        });
    
    }*/

}
