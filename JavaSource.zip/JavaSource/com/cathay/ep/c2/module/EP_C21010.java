package com.cathay.ep.c2.module;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.b2.module.EP_B20020;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;

/**
 * DATE Description Author
 * 2013/08/07  Created ���i��

 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �o�����}�ߺ��@�Ҳ�
 * �Ҳ�ID    EP_C21010
 * ���n����    �o�����}�ߺ��@�Ҳ�
 *
 * @author ����[
 * @since 2013-09-30
 */
@SuppressWarnings("unchecked")
public class EP_C21010 {
    private static final Logger log = Logger.getLogger(EP_C21010.class);

    private static final String SQL_query_001 = "com.cathay.ep.c2.module.EP_C21010.SQL_query_001";

    private static final String SQL_update_001 = "com.cathay.ep.c2.module.EP_C21010.SQL_update_001";

    private static final String SQL_queryByInvNos_001 = "com.cathay.ep.c2.module.EP_C21010.SQL_queryByInvNos_001";

    /**
     * �d�߫ݦC�L�o�����
     * @param RCV_YM �����~��
     * @param BLD_CD �j�ӥN��
     * @param PAY_KIND �o������
     * @return rtnList �ݦC�L�o�����
     * @throws ModuleException
     */
    public List<Map> query(String RCV_YM, String BLD_CD, String PAY_KIND, String INV_TYPE, String BLD_USR_ID, String SUB_CPY_ID)
            throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(RCV_YM) || RCV_YM.length() != 6 || !StringUtils.isNumeric(RCV_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21010_MSG_001"));//�����~�뤣�o���ŭȥB�ݬ�6�X�Ʀr
        }

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }
        //��bqds
        BatchQueryDataSet bqds = null;
        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            bqds.setField("RCV_YM", RCV_YM);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            if (StringUtils.isNotBlank(BLD_CD)) {
                bqds.setField("BLD_CD", BLD_CD);
            }
            if (StringUtils.isNotBlank(BLD_USR_ID)) {
                bqds.setField("BLD_USR_ID", BLD_USR_ID);
            }
            if ("".equals(PAY_KIND)) { //����(���ʲ���) �ư��޲z�O
                bqds.setField("IS_ALL", "1");
            } else {
                bqds.setField("PAY_KIND", PAY_KIND);
            }
            if (StringUtils.isNotBlank(INV_TYPE)) {
                bqds.setField("INV_TYPE", INV_TYPE);
            }

            bqds.searchAndRetrieve(SQL_query_001);

            int groupCount = 2000;//�C�妸�d��2000�����
            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            if (totalcount == 0) {
                log.error("�d�L���");
                throw new DataNotFoundException("�d�L���");
            }
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��

            List<Map> dataList = new ArrayList<Map>();
            EP_B20020 theEP_B20020 = new EP_B20020();
            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map dataMap = VOTool.dataSetToMap(bqds);
                    //�d�ߵ|�O����
                    dataMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(dataMap, "TAX_TYPE")));

                    //�d�ߵo�����p����
                    dataMap.put("INV_CD_NM", FieldOptionList.getName("EP", "INV_CD", MapUtils.getString(dataMap, "INV_CD")));

                    String DCT_TYPE = MapUtils.getString(dataMap, "DCT_TYPE", "");
                    if ("1".equals(DCT_TYPE)) {
                        Map B202Map = new HashMap();
                        B202Map.put("ID", MapUtils.getString(dataMap, "ID", ""));
                        B202Map.put("SUB_CPY_ID", SUB_CPY_ID);
                        Map CARD_MAP = theEP_B20020.queryMap(B202Map);
                        dataMap.put("CARD_NO", MapUtils.getString(CARD_MAP, "CARD_NO", ""));
                    }
                    dataList.add(dataMap);
                }

            }
            return dataList;

        } catch (DBException dbe) {
            log.error("�d�ߥ���", dbe);
            throw new ModuleException(dbe);
        } catch (DataNotFoundException e) {
            log.error("�d�L���", e);
            throw new DataNotFoundException(e);
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            throw new ModuleException(e);
        } finally {
            try {
                if (bqds != null) {
                    bqds.close();//�����妸�d�߳s�u
                }
            } catch (DBException e) {
            }
        }

    }

    /**
     * queryByInvNos �d�߫ݦC�L�o�����
     * @param RCV_YM
     * @param BLD_CD
     * @param PAY_KIND
     * @param BLD_USR_ID
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException
     */
    public List<Map> queryByInvNOs(String RCV_YM, String SUB_CPY_ID, List<Map> reqList) throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(RCV_YM) || RCV_YM.length() != 6 || !StringUtils.isNumeric(RCV_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21010_MSG_001"));//�����~�뤣�o���ŭȥB�ݬ�6�X�Ʀr
        }

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (reqList == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21010_MSG_002"));//�o����ƲM�椣�i���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        List<String> InvNoList = new ArrayList<String>();
        for (Map map : reqList) {
            InvNoList.add(MapUtils.getString(map, "INV_NO"));
        }

        if (InvNoList == null || InvNoList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C21010_MSG_003"));//�o�����X�M�椣�i���ŭ�
        }

        //��bqds
        BatchQueryDataSet bqds = null;
        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            bqds.setField("RCV_YM", RCV_YM);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            bqds.setFieldValues("InvNoList", InvNoList);

            bqds.searchAndRetrieve(SQL_queryByInvNos_001);

            int groupCount = 2000;//�C�妸�d��2000�����
            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            if (totalcount == 0) {
                log.error("�d�L���");
                throw new DataNotFoundException("�d�L���");
            }
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��

            List<Map> dataList = new ArrayList<Map>();
            EP_B20020 theEP_B20020 = new EP_B20020();
            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map dataMap = VOTool.dataSetToMap(bqds);

                    //�d�ߵ|�O����
                    dataMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(dataMap, "TAX_TYPE")));
                    //�d�ߵo�����p����
                    dataMap.put("INV_CD_NM", FieldOptionList.getName("EP", "INV_CD", MapUtils.getString(dataMap, "INV_CD")));
                    //���oñ�b�d��
                    String DCT_TYPE = MapUtils.getString(dataMap, "DCT_TYPE", "");
                    if ("1".equals(DCT_TYPE)) {
                        Map B202Map = new HashMap();
                        B202Map.put("ID", MapUtils.getString(dataMap, "ID", ""));
                        B202Map.put("SUB_CPY_ID", SUB_CPY_ID);
                        Map CARD_MAP = theEP_B20020.queryMap(B202Map);
                        dataMap.put("CARD_NO", MapUtils.getString(CARD_MAP, "CARD_NO", ""));
                    }
                    dataList.add(dataMap);
                }

            }
            return dataList;

        } catch (DBException dbe) {
            log.error("�d�ߥ���", dbe);
            throw new ModuleException(dbe);
        } catch (DataNotFoundException e) {
            log.error("�d�L���", e);
            throw new DataNotFoundException(e);
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            throw new ModuleException(e);
        } finally {
            try {
                if (bqds != null) {
                    bqds.close();//�����妸�d�߳s�u
                }
            } catch (DBException e) {
            }
        }

    }

    /**
     * ��s�ݶ}�ߵo�����C�L���
     * @param RCV_YM        �����~��
     * @param BLD_CD        �j�ӥN��
     * @param PAY_KIND      �o������
     * @param USER_ID       USER ID
     * @param USER_NAME     USER�m�W
     * @param USER_DIV_NO   USER���N��
     * @throws ModuleException
     * @throws DBException 
     */
    public void update(List<Map> dataList, UserObject user) throws ModuleException, DBException {

        ErrorInputException eie = null;
        if (dataList == null || dataList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21010_MSG_002"));//�o����ƲM�椣�i���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21010_MSG_004"));//�n�J�H����T���i���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String CurrentTime = DATE.getDBTimeStamp();
        String USER_DIV_NO = user.getDivNo();
        String USER_ID = user.getEmpID();
        String USER_NAME = user.getEmpName();
        String INV_NO;

        //��s�o�� (C202)
        //�B�z���update
        BatchUpdateDataSet buds = null;
        //�p����妸��
        int commit_size = 200; //�@��200���i�H�ݨD���ܵ���
        try {
            int batchCount;

            buds = Transaction.getBatchUpdateDataSet();
            buds.preparedBatch(SQL_update_001);
            batchCount = (dataList.size() / commit_size) + 1;

            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? dataList.size() : i * commit_size;

                    for (int j = initS; j < initE; j++) {
                        Map dataMap = dataList.get(j);
                        INV_NO = MapUtils.getString(dataMap, "INV_NO");
                        buds.setField("RCV_YM", MapUtils.getString(dataMap, "RCV_YM"));
                        buds.setField("PRT_DATE", CurrentTime);
                        buds.setField("TRN_KIND", "02");
                        buds.setField("CHE_DATE", CurrentTime);
                        buds.setField("CHG_DIV_NO", USER_DIV_NO);
                        buds.setField("CHG_ID", USER_ID);
                        buds.setField("CHG_NAME", USER_NAME);
                        buds.setField("SUB_CPY_ID", MapUtils.getString(dataMap, "SUB_CPY_ID"));
                        buds.setField("INV_NO", INV_NO);
                        buds.addBatch();
                    }
                    buds.executeBatch();

                    Object theErrorObject[][] = buds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("��s��Ʀ��~ setField = " + errorDataMap, (Exception) theErrorObject[k][2]);
                        }
                        //��s��Ʀ��~
                        throw new ModuleException("��s�o���C�L������~");
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException("��s�o���C�L������~");
                }
            }//end ��s�o�� (C202)

        } finally {
            if (buds != null) {
                buds.close();
            }
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}
