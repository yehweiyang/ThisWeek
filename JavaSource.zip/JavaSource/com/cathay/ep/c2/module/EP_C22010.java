package com.cathay.ep.c2.module;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPC202;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * DATE     Description Author
 * 2013/9/3     Created ������
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �o�����ӿ�J�Ҳ�
 * �Ҳ�ID    EP_C22010
 * ���n����    �o�����ӿ�J�Ҳ�
 * 
 * @author ����[
 * @since 2013-10-09
 */
@SuppressWarnings("unchecked")
public class EP_C22010 {

    private static final String SQL_updateDTEPC202_001 = "com.cathay.ep.c2.module.EP_C22010.SQL_updateDTEPC202_001";

    private static final String SQL_queryDTEPC202_001 = "com.cathay.ep.c2.module.EP_C22010.SQL_queryDTEPC202_001";

    private static final String SQL_insertDTEPC202_001 = "com.cathay.ep.c2.module.EP_C22010.SQL_insertDTEPC202_001";

    private static final String SQL_queryDTEPC202_1_001 = "com.cathay.ep.c2.module.EP_C22010.SQL_queryDTEPC202_1_001";

    private static final String SQL_queryPrt_date_001 = "com.cathay.ep.c2.module.EP_C22010.SQL_queryPrt_date_001";

    private static final String SQL_queryDTEPC202ByInvno_001 = "com.cathay.ep.c2.module.EP_C22010.SQL_queryDTEPC202ByInvno_001";

    /**
     * �s�W�o����
     * @param inMap ��J�Ѽ�
     * @throws ModuleException
     */
    public DTEPC202 insertDTEPC202(Map inMap) throws ModuleException {
        ErrorInputException eie = null;
        String RCV_YM = null;
        String TAX_TYPE = null;
        String SUB_CPY_ID = null;
        UserObject user = null;

        if (inMap == null || inMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_001"));//��J�ѼƤ��o���ŭ�
        } else {
            RCV_YM = MapUtils.getString(inMap, "RCV_YM");
            TAX_TYPE = MapUtils.getString(inMap, "TAX_TYPE");
            user = (UserObject) inMap.get("user");
            SUB_CPY_ID = MapUtils.getString(inMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(RCV_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_002"));//�����~�뤣�o���ŭ�
            }
            if (StringUtils.isBlank(TAX_TYPE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_003"));//�|�O���o���ŭ�
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
            if (user == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_017"));//userObject���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        //�NinMap�ରDTEPC202_VO
        DTEPC202 DTEPC202_VO = VOTool.mapToVO(DTEPC202.class, inMap);

        //RCV_YM = String.valueOf(Integer.parseInt(RCV_YM) + 191100);
        BigDecimal SAL_AMT = DTEPC202_VO.getSAL_AMT();
        BigDecimal TAX_AMT = DTEPC202_VO.getTAX_AMT();
        BigDecimal INV_AMT = DTEPC202_VO.getINV_AMT();
        //�p��"�o�����B"�B "�P���B"�B "��~�|�B"
        Map amtMap = calAmt(TAX_TYPE, INV_AMT, SAL_AMT);
        INV_AMT = obj2Decimal(amtMap.get("INV_AMT")); //�o�����B 
        SAL_AMT = obj2Decimal(amtMap.get("SAL_AMT")); //�P���B
        TAX_AMT = obj2Decimal(amtMap.get("TAX_AMT")); //��~�|�B
        DTEPC202_VO.setINV_AMT(INV_AMT);
        DTEPC202_VO.setSAL_AMT(SAL_AMT);
        DTEPC202_VO.setTAX_AMT(TAX_AMT);

        //        //���o�����q�O
        //        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
        //        DTEPC202_VO.setSUB_CPY_ID(SUB_CPY_ID);

        EP_C21030 theEP_C21030 = new EP_C21030();
        //���o�o�����X�άy����
        String[] INV_NOs = theEP_C21030.getInvNo(SUB_CPY_ID, RCV_YM);
        String INV_NO = INV_NOs[0];
        String SER_NO = INV_NOs[1];

        DataSet ds = Transaction.getDataSet();

        ds.setField("INV_NO", INV_NO);
        ds.setField("SER_NO", SER_NO);
        String CHK_NO = theEP_C21030.getCHK_NO(INV_NO);
        ds.setField("CHK_NO", CHK_NO);//���o�ˬd���X
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("PIN_CODE", MapUtils.getString(inMap, "PIN_CODE"));
        ds.setField("PAY_KIND", MapUtils.getString(inMap, "PAY_KIND"));
        ds.setField("CUS_NAME", MapUtils.getString(inMap, "CUS_NAME"));
        ds.setField("ID", MapUtils.getString(inMap, "ID"));
        ds.setField("PIN_NAME", MapUtils.getString(inMap, "PIN_NAME"));
        ds.setField("SAL_AMT", SAL_AMT);
        ds.setField("TAX_TYPE", TAX_TYPE);
        ds.setField("TAX_AMT", TAX_AMT);
        ds.setField("INV_AMT", INV_AMT);
        ds.setField("SLIP_DATE", MapUtils.getString(inMap, "SLIP_DATE"));
        ds.setField("SLIP_DIV_NO", MapUtils.getString(inMap, "SLIP_DIV_NO"));
        ds.setField("SLIP_SEQ_NO", MapUtils.getIntValue(inMap, "SLIP_SEQ_NO", 0));
        ds.setField("INV_DATE", MapUtils.getString(inMap, "INV_DATE"));
        ds.setField("INV_CD", MapUtils.getString(inMap, "INV_CD"));
        ds.setField("TRN_KIND", "EPC202");
        ds.setField("CHG_ID", MapUtils.getString(inMap, "CHG_ID"));
        ds.setField("CHG_DIV_NO", MapUtils.getString(inMap, "CHG_DIV_NO"));
        ds.setField("CHG_NAME", MapUtils.getString(inMap, "CHG_NAME"));
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        DTEPC202_VO.setINV_NO(INV_NO);
        DTEPC202_VO.setSER_NO(SER_NO);
        DTEPC202_VO.setCHK_NO(CHK_NO);
        DTEPC202_VO.setTRN_KIND("EPC202");
        DTEPC202_VO.setCHG_DATE(DATE.currentTime());

        DBUtil.executeUpdate(ds, SQL_insertDTEPC202_001);
        return DTEPC202_VO;
    }

    /**
     * �d�ߵo����
     * @param RCV_YM    �����~��
     * @param PIN_CODE  �~�W�N��
     * @return  rtnList �o������
     * @throws ModuleException
     */
    public List<Map> queryDTEPC202(String RCV_YM, String PIN_CODE, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(RCV_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_001"));//�����~��
        }
        if (StringUtils.isBlank(PIN_CODE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_006"));//�~�W�N�����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("PIN_CODE", PIN_CODE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryDTEPC202_001, false);
        if (rtnList == null) {
            throw new ModuleException(MessageUtil.getMessage("EP_C22010_MSG_007", new Object[] { RCV_YM, PIN_CODE }));//"���o�{�����~�묰"+RCV_YM+"�P�~�W�N����"+PIN_CODE+"���o��"  ���o�{�����~�묰{0}�P�~�W�N����{1}���o��
        }
        //�W�[�����������rtnList���C
        for (Map rtnMap : rtnList) {
            //�o�����p
            rtnMap.put("INV_CD_NM", FieldOptionList.getName("EP", "INV_CD", MapUtils.getString(rtnMap, "INV_CD")));
            //�������
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            //ú�ں���
            rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EP", "PAY_KIND", MapUtils.getString(rtnMap, "PAY_KIND")));
            //�|�O
            rtnMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE")));

            //rtnMap.put("RCV_YM", (MapUtils.getIntValue(rtnMap, "RCV_YM") - 191100));
        }
        return rtnList;
    }

    /**
     * �d�ߵo����
     * @param CUS_NAME  �Ȥ�m�W
     * @return  rtnList �o������
     * @throws ModuleException
     */
    public List<Map> queryDTEPC202_1(String CUS_NAME, String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;

        if (StringUtils.isBlank(CUS_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_008"));//�Ȥ�m�W���o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CUS_NAME", CUS_NAME);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryDTEPC202_1_001, false);

        if (rtnList == null) {
            throw new ModuleException(MessageUtil.getMessage("EP_C22010_MSG_009", new Object[] { CUS_NAME }));//"���o�{�Ȥ�m�W����+CUS_NAME+"���o��"   ���o�{�Ȥ�m�W��{0}���o��
        }
        //�W�[�����������rtnList���C
        for (Map rtnMap : rtnList) {
            //�o�����p
            rtnMap.put("INV_CD_NM", FieldOptionList.getName("EP", "INV_CD", MapUtils.getString(rtnMap, "INV_CD")));
            //�������
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            //ú�ں���
            rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EP", "PAY_KIND", MapUtils.getString(rtnMap, "PAY_KIND")));
            //�|�O
            rtnMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE")));

        }

        return rtnList;
    }

    /**
     * �d�ߵo����
     * @param INV_NO �o�����X
     * @return rtnList �o������
     * @throws ModuleException
     */
    public List<Map> queryDTEPC202ByInvno(String INV_NO, String SUB_CPY_ID) throws ModuleException {

        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_queryDTEPC202ByInvno_001);

    }

    /**
     * �d�ߵo����(�C�L���)
     * @param PIN_CODE  �~�W�N��
     * @param CUS_NAME  �Ȥ�m�W
     * @param INV_NO    �o�����X
     * @param CHK_NO    �ˬd���X
     * @return  rtnList �o������
     * @throws ModuleException
     */
    public List<Map> queryPrt_date(String PIN_CODE, String CUS_NAME, String INV_NO, String CHK_NO, String SUB_CPY_ID)
            throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(PIN_CODE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_006"));//�~�W�N�����o���ŭ�
        }
        //if (StringUtils.isBlank(CUS_NAME)) {
        //    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_008"));//�Ȥ�m�W���o���ŭ�
        //}
        if (StringUtils.isBlank(INV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_010"));//�o�����X���o���ŭ�
        }
        if (StringUtils.isBlank(CHK_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_011"));//�ˬd���X���o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("PIN_CODE", PIN_CODE);
        ds.setField("CUS_NAME", CUS_NAME);
        ds.setField("INV_NO", INV_NO);
        ds.setField("CHK_NO", CHK_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_queryPrt_date_001);

    }

    /**
     * �ק�o����
     * @param inMap ��J�Ѽ�
     * @throws ModuleException
     */
    public void updateDTEPC202(Map inMap) throws ModuleException {

        ErrorInputException eie = null;
        String RCV_YM = null;
        String TAX_TYPE = null;
        String PIN_CODE = null;
        String CUS_NAME = null;
        String INV_NO = null;
        String CHK_NO = null;
        String TRN_KIND = null;
        String SUB_CPY_ID = null;

        if (inMap == null || inMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_001"));//��J�ѼƤ��o���ŭ�
        } else {
            RCV_YM = MapUtils.getString(inMap, "RCV_YM");
            TAX_TYPE = MapUtils.getString(inMap, "TAX_TYPE");
            PIN_CODE = MapUtils.getString(inMap, "PIN_CODE");
            CUS_NAME = MapUtils.getString(inMap, "CUS_NAME");
            INV_NO = MapUtils.getString(inMap, "INV_NO");
            CHK_NO = MapUtils.getString(inMap, "CHK_NO");
            TRN_KIND = MapUtils.getString(inMap, "TRN_KIND");
            SUB_CPY_ID = MapUtils.getString(inMap, "SUB_CPY_ID");

            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(RCV_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_002"));//�����~�뤣�o���ŭ�
            }
            if (StringUtils.isBlank(TAX_TYPE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_003"));//�|�O���o���ŭ�
            }
            if (StringUtils.isBlank(PIN_CODE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_006"));//�~�W�N�����o���ŭ�
            }
            //if (StringUtils.isBlank(CUS_NAME)) {
            //    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_008"));//�Ȥ�m�W���o���ŭ�
            //}
            if (StringUtils.isBlank(INV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_010"));//�o�����X���o���ŭ�
            }
            if (StringUtils.isBlank(CHK_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_011"));//�ˬd���X���o���ŭ�
            }
            if (StringUtils.isBlank(TRN_KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_004"));//����������o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        BigDecimal SAL_AMT = obj2Decimal(inMap.get("SAL_AMT"));
        BigDecimal TAX_AMT = obj2Decimal(inMap.get("TAX_AMT"));
        BigDecimal INV_AMT = obj2Decimal(inMap.get("INV_AMT"));

        //�p�⡨�o�����B���B ���P���B���B ����~�|�B��
        Map amtMap = calAmt(TAX_TYPE, INV_AMT, SAL_AMT);
        INV_AMT = obj2Decimal(amtMap.get("INV_AMT")); //�o�����B 
        SAL_AMT = obj2Decimal(amtMap.get("SAL_AMT")); //�P���B
        TAX_AMT = obj2Decimal(amtMap.get("TAX_AMT")); //��~�|�B

        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_KIND", MapUtils.getString(inMap, "PAY_KIND"));
        ds.setField("ID", MapUtils.getString(inMap, "ID"));
        ds.setField("SAL_AMT", SAL_AMT);
        ds.setField("TAX_TYPE", TAX_TYPE);
        ds.setField("TAX_AMT", TAX_AMT);
        ds.setField("INV_AMT", INV_AMT);
        ds.setField("SLIP_DATE", MapUtils.getString(inMap, "SLIP_DATE"));
        ds.setField("SLIP_DIV_NO", MapUtils.getString(inMap, "SLIP_DIV_NO"));
        ds.setField("SLIP_SEQ_NO", MapUtils.getString(inMap, "SLIP_SEQ_NO"));
        ds.setField("INV_DATE", MapUtils.getString(inMap, "INV_DATE"));
        ds.setField("TRN_KIND", TRN_KIND);
        ds.setField("PIN_NAME", MapUtils.getString(inMap, "PIN_NAME"));
        ds.setField("CHG_ID", MapUtils.getString(inMap, "CHG_ID"));
        ds.setField("CHG_DIV_NO", MapUtils.getString(inMap, "CHG_DIV_NO"));
        ds.setField("CHG_NAME", MapUtils.getString(inMap, "CHG_NAME"));
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("PIN_CODE", PIN_CODE);
        ds.setField("CUS_NAME", CUS_NAME);
        ds.setField("INV_NO", INV_NO);
        ds.setField("CHK_NO", CHK_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        DBUtil.executeUpdate(ds, SQL_updateDTEPC202_001);

    }

    /**
     * �p����B
     * @param TAX_TYPE  �|�O
     * @param INV_AMT   �o�����B
     * @param SAL_AMT   �P���B
     * @return  amtMap  ���B(�o�����B�B�P���B�B��~�|�B)
     * @throws ModuleException
     */
    public Map calAmt(String TAX_TYPE, BigDecimal INV_AMT, BigDecimal SAL_AMT) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(TAX_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_003"));//�|�O���o���ŭ�
        }/*
                                                        if (INV_AMT == null) {
                                                            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_012"));//�o�����B���o���ŭ�
                                                        }
                                                        
                                                        if (SAL_AMT == null) {
                                                            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22010_MSG_013"));//�P���B���o���ŭ�
                                                        }*/
        if (eie != null) {
            throw eie;
        }
        Map amtMap = new HashMap();

        if ("1".equals(TAX_TYPE)) {
            if (INV_AMT.compareTo(BigDecimal.ZERO) == 0) { //���t
                throw new ModuleException(MessageUtil.getMessage("EP_C22010_MSG_014"));//"���t�|�o�����B���o��0"
            }
            amtMap.put("INV_AMT", INV_AMT);//�o�����B
            BigDecimal TAX_AMT = (INV_AMT.divide(new BigDecimal("1.05"), 2, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal("0.05")))
                    .setScale(0, BigDecimal.ROUND_HALF_UP);
            amtMap.put("TAX_AMT", TAX_AMT);//��~�|�B
            amtMap.put("SAL_AMT", INV_AMT.subtract(TAX_AMT));//�P���B

        } else if ("2".equals(TAX_TYPE)) { //�~�[
            if (SAL_AMT.compareTo(BigDecimal.ZERO) == 0) {
                throw new ModuleException(MessageUtil.getMessage("EP_C22010_MSG_015"));//"�~�[�|�P����B���o��0"
            }
            amtMap.put("SAL_AMT", SAL_AMT);//�P���B
            BigDecimal TAX_AMT = SAL_AMT.multiply(new BigDecimal("0.05")).setScale(0, BigDecimal.ROUND_HALF_UP);
            amtMap.put("TAX_AMT", TAX_AMT);//��~�|�B
            amtMap.put("INV_AMT", SAL_AMT.add(TAX_AMT));//�o�����B
        } else if ("3".equals(TAX_TYPE) || "4".equals(TAX_TYPE)) { //0�|�v //�K�|
            if (SAL_AMT.compareTo(BigDecimal.ZERO) == 0) {
                throw new ModuleException(MessageUtil.getMessage("EP_C22010_MSG_016"));//"0�|�v�P����B���o��0"
            }
            amtMap.put("SAL_AMT", SAL_AMT);//�P���B
            amtMap.put("TAX_AMT", 0);//��~�|�B
            amtMap.put("INV_AMT", SAL_AMT);//�o�����B

        }
        return amtMap;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal obj2Decimal(Object obj) {
        if (obj == null) {

            return BigDecimal.ZERO;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }

        String str = String.valueOf(obj);

        if (StringUtils.isBlank(str)) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal(str);
    }

}
