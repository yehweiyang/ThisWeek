package com.cathay.ep.c2.module;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.c0.module.EP_C0Z001;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.rpt.CsvUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Version     Description   Author
 * 2013/8/15    1.0     �s�W          �\�a�s
 * 2018/01/29   1.1      �վ�o���~�W�榡         ����[
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �o���ɺ�X�d�߼Ҳ�
 * �{���W��    EP_C23020
 * ���n����    �d��DTEPC202_�o���ɸ��
 * </pre>
 * @author �� �� �[
 * @since 2013-11-04
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C23020 {

    /** �R�A�� log ���� **/
    //private static final Logger log = Logger.getLogger(EP_C23020.class);
    private static final String SQL_queryListTYPE1_001 = "com.cathay.ep.c2.module.EP_C23020.SQL_queryListTYPE1_001";

    //private static final String SQL_queryListTYPE2_001 = "com.cathay.ep.c2.module.EP_C23020.SQL_queryListTYPE2_001";

    private static final String SQL_queryListTYPE3_001 = "com.cathay.ep.c2.module.EP_C23020.SQL_queryListTYPE3_001";

    private CsvUtils csvUtils;

    private boolean isExport = false;

    /**
     * �d�ߵo���ɸ��(�j�ӥN��)
     * @param RCV_YM    �����~��
     * @param BLD_CD    �j�ӥN��
     * @param INV_CD    �o������
     * @param PAY_KIND  ú�ں���
     * @return  rtnList �o����List
     * @throws Exception 
     */
    public List<Map> queryListTYPE1(Map reqMap, ResponseContext resp) throws Exception {
        //150706:�T�جd�ߤ�k�X�֦��@��

        DataSet ds = getDataSetByExport(reqMap, resp);

        String QUERYTYPE = MapUtils.getString(reqMap, "QUERYTYPE");
        String INV_DATE_YM = MapUtils.getString(reqMap, "INV_DATE_YM");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if ("QUERYTYPE_1".equals(QUERYTYPE)) {//TYPE1
            if (reqMap == null || reqMap.isEmpty()) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_C23020_MSG_001"));//�п�J�����~�� 
            }
            BigDecimal RCV_YM = getBigDecimal(reqMap.get("RCV_YM"), null);
            ds.setField("RCV_YM", RCV_YM);
            String INV_CD = MapUtils.getString(reqMap, "INV_CD");
            if (StringUtils.isNotBlank(INV_CD)) {
                if ("1".equals(INV_CD)) {
                    ds.setField("INV_CD_1", "1");
                } else {
                    ds.setField("INV_CD_2", "1");
                    ds.setField("INV_CD", INV_CD);
                }
            }
        } else if ("QUERYTYPE_2".equals(QUERYTYPE)) {//TYPE2
            String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
            String ID = MapUtils.getString(reqMap, "ID");
            if (INV_DATE_YM == null && StringUtils.isBlank(PAY_KIND) && StringUtils.isBlank(ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_C23020_MSG_002"));//�Цܤֿ�J�@�Ӭd�߱���
            }
            ds.setField("QRYTYPE2", "1");
        } else {//TYPE3
            String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
            if (StringUtils.isBlank(CRT_NO)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_C23020_MSG_004"));//�����N�����i����
            }
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("QRYTYPE3", "1");
        }
        if (StringUtils.isNotBlank(INV_DATE_YM)) {
            String INV_DATE_YMstr = INV_DATE_YM + "01";
            String INV_DATE_S = DATE.toDateFormat(INV_DATE_YMstr, "yyyyMMdd", "yyyy-MM-dd");
            String INV_DATE_E = DATE.addDate(INV_DATE_S, 0, 1, 0);
            ds.setField("INV_DATE_S", INV_DATE_S);
            ds.setField("INV_DATE_E", INV_DATE_E);
        }
        setFieldIfExsits(reqMap, ds, "BLD_CD");
        setFieldIfExsits(reqMap, ds, "ID");
        setFieldIfExsits(reqMap, ds, "PAY_KIND");
        setFieldIfExsits(reqMap, ds, "CUS_NO");

        String BAL_TYPE = MapUtils.getString(reqMap, "BAL_TYPE");
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        if ("CA".equals(BAL_TYPE)) {
            List<String> SG_BLD_CDs = theEP_Z0G103.getSG_BLD_CDbyBAL_TYPE(SUB_CPY_ID, "SG");
            ds.setFieldValues("CA_BLD_CDs", SG_BLD_CDs);//BLD_CD not in SG_BLD_CDs
        } else if (StringUtils.isNotBlank(BAL_TYPE)) {
            List<String> SG_BLD_CDs = theEP_Z0G103.getSG_BLD_CDbyBAL_TYPE(SUB_CPY_ID, BAL_TYPE);//���֩ΰ��_���j�ӲM��
            ds.setFieldValues("SG_BLD_CDs", SG_BLD_CDs);
        }

        setFieldIfExsits(reqMap, ds, "PIN_CODE");

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if (isExport) {
            //�^��logSecurityList
            return export(ds, SQL_queryListTYPE1_001, SUB_CPY_ID);
        } else { //�d��
            List<Map> rtnList = null;
            rtnList = VOTool.findToMaps(ds, SQL_queryListTYPE1_001);
            //���o����

            Map PIN_NAMEs = new EP_C0Z001().getPIN_NAMEs(SUB_CPY_ID, null);
            StringBuilder sb = new StringBuilder();
            for (Map rtnMap : rtnList) {
                //ú�ں���
                String BAL_TYPE_tmp = theEP_Z0G103.getBAL_TYPE(MapUtils.getString(rtnMap, "SUB_CPY_ID"), MapUtils.getString(rtnMap,
                    "BLD_CD"));
                rtnMap.put("BAL_TYPE", BAL_TYPE_tmp);
                rtnMap.put("BAL_TYPE_NM", FieldOptionList.getName("EP", "BAL_TYPE", BAL_TYPE_tmp));
                rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND_FOUR", MapUtils.getString(rtnMap, "PAY_KIND")));
                String PAY_S_DATE = MapUtils.getString(rtnMap, "PAY_S_DATE");
                if (StringUtils.isNotBlank(PAY_S_DATE)) {
                    rtnMap.put("PAY_S_DATE", DATE.formatToROCDate(PAY_S_DATE));
                }
                String PAY_E_DATE = MapUtils.getString(rtnMap, "PAY_E_DATE");
                if (StringUtils.isNotBlank(PAY_E_DATE)) {
                    rtnMap.put("PAY_E_DATE", DATE.formatToROCDate(PAY_E_DATE));
                }
                rtnMap.put("INV_CD", FieldOptionList.getName("EPC", "INV_CD", MapUtils.getString(rtnMap, "INV_CD")));

                rtnMap.put("INV_TYPE_NM", FieldOptionList.getName("EP", "CUS_INV_TYPE", MapUtils.getString(rtnMap, "INV_TYPE")));
                rtnMap.put("TRANS_TYPE_NM", FieldOptionList.getName("EP", "TRANS_TYPE", MapUtils.getString(rtnMap, "TRANS_TYPE")));

                //�վ�~�W�榡
                new EP_C0Z001().getPIN_NAMEForQuery(rtnMap, sb, PIN_NAMEs);
            }

            return rtnList;
        }

    }

    /**
     * �d�ߵo���ɸ��(�Τ@�s��)
     * @param INV_DATE_YM   �}�ߤ�����褸�~��
     * @param ID            �Τ@�s��
     * @param PAY_KIND      ú�ں���
     * @return  rtnList     �o����List
     * @throws Exception 
     */
    /*public List<Map> queryListTYPE2(Map reqMap, ResponseContext resp) throws Exception {

        String INV_DATE_YM = MapUtils.getString(reqMap, "INV_DATE_YM");
        String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
        String ID = MapUtils.getString(reqMap, "ID");
        if (INV_DATE_YM == null && StringUtils.isBlank(PAY_KIND) && StringUtils.isBlank(ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23020_MSG_002"));//�Цܤֿ�J�@�Ӭd�߱���
        }

        DataSet ds = getDataSetByExport(reqMap, resp);

        if (StringUtils.isNotBlank(INV_DATE_YM)) {
            String INV_DATE_YMstr = INV_DATE_YM + "01";
            String INV_DATE_S = DATE.toDateFormat(INV_DATE_YMstr, "yyyyMMdd", "yyyy-MM-dd");
            String INV_DATE_E = DATE.addDate(INV_DATE_S, 0, 1, 0);
            ds.setField("INV_DATE_S", INV_DATE_S);
            ds.setField("INV_DATE_E", INV_DATE_E);
        }
        if (StringUtils.isNotBlank(ID)) {
            ds.setField("ID", ID);
        }
        if (StringUtils.isNotBlank(PAY_KIND)) {
            ds.setField("PAY_KIND", PAY_KIND);
        }
        ds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        ds.setField("QRYTYPE2", "1");
        if (isExport) {
            export(ds, SQL_queryListTYPE1_001);
            return null;
        } else { //�d��
            List<Map> rtnList = null;
            rtnList = VOTool.findToMaps(ds, SQL_queryListTYPE1_001);
            //���o����
            for (Map rtnMap : rtnList) {
                //ú�ں���
                rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND_FOUR", MapUtils.getString(rtnMap, "PAY_KIND")));
                String PAY_S_DATE = MapUtils.getString(rtnMap, "PAY_S_DATE");
                if (StringUtils.isNotBlank(PAY_S_DATE)) {
                    rtnMap.put("PAY_S_DATE", DATE.formatToROCDate(PAY_S_DATE));
                }
                String PAY_E_DATE = MapUtils.getString(rtnMap, "PAY_E_DATE");
                if (StringUtils.isNotBlank(PAY_E_DATE)) {
                    rtnMap.put("PAY_E_DATE", DATE.formatToROCDate(PAY_E_DATE));
                }
                rtnMap.put("INV_CD", FieldOptionList.getName("EPC", "INV_CD", MapUtils.getString(rtnMap, "INV_CD")));
            }

            return rtnList;
        }

    }*/

    /**
     * �d�ߵo���ɸ��(�Ȥ�W��)
     * @param INV_DATE_YM   �}�ߤ�����褸�~��
     * @param CRT_NO        �����N��
     * @param CUS_NO        �Ȥ�Ǹ�
     * @param PAY_KIND      ú�ں���
     * @return  rtnList     �o����List
     * @throws Exception 
     * @throws Exception 
     */
    public List<Map> queryListTYPE3(BigDecimal INV_DATE_YM, String CRT_NO, String CUS_NO, String PAY_KIND, Map reqMap, ResponseContext resp)
            throws Exception {
        if (StringUtils.isBlank(CRT_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23020_MSG_004"));//�����N�����i����
        }
        //        if (StringUtils.isBlank(CUS_NO)) {
        //            throw new ErrorInputException(MessageUtil.getMessage("EP_C23020_MSG_003"));//�Ȥ�Ǹ����i����
        //        }

        DataSet ds;
        if (reqMap != null) {
            ds = getDataSetByExport(reqMap, resp);
        } else {
            ds = Transaction.getDataSet();
        }
        ds.setField("CRT_NO", CRT_NO);
        if (StringUtils.isNotBlank(CUS_NO)) {
            ds.setField("CUS_NO", CUS_NO);
        }
        if (INV_DATE_YM != null) {
            String INV_DATE_YMstr = INV_DATE_YM.toString() + "01";
            String INV_DATE_S = DATE.toDateFormat(INV_DATE_YMstr, "yyyyMMdd", "yyyy-MM-dd");
            String INV_DATE_E = DATE.addDate(INV_DATE_S, 0, 1, 0);

            ds.setField("INV_DATE_S", INV_DATE_S);
            ds.setField("INV_DATE_E", INV_DATE_E);
        }
        if (StringUtils.isNotBlank(PAY_KIND)) {
            ds.setField("PAY_KIND", PAY_KIND);
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if (isExport) {
            export(ds, SQL_queryListTYPE3_001, SUB_CPY_ID);
            return null;
        } else { //�d��
            List<Map> rtnList = null;
            rtnList = VOTool.findToMaps(ds, SQL_queryListTYPE3_001);

            //20180227:��method�u�Ψ��ˮֵo����,���ݲի~�W
            //�_�h�|���s�u���D(EPB3_0010.approve�btransaction��(�LXA)��DS_EP�s�u�|������DDtable)
            //Map PIN_NAMEs = new EP_C0Z001().getPIN_NAMEs(SUB_CPY_ID, null);
            //���o����
            for (Map rtnMap : rtnList) {
                //ú�ں���
                rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND_FOUR", MapUtils.getString(rtnMap, "PAY_KIND")));
                String PAY_S_DATE = MapUtils.getString(rtnMap, "PAY_S_DATE");
                if (StringUtils.isNotBlank(PAY_S_DATE)) {
                    rtnMap.put("PAY_S_DATE", DATE.formatToROCDate(PAY_S_DATE));
                }
                String PAY_E_DATE = MapUtils.getString(rtnMap, "PAY_E_DATE");
                if (StringUtils.isNotBlank(PAY_E_DATE)) {
                    rtnMap.put("PAY_E_DATE", DATE.formatToROCDate(PAY_E_DATE));
                }
                rtnMap.put("INV_CD", FieldOptionList.getName("EPC", "INV_CD", MapUtils.getString(rtnMap, "INV_CD")));

                //�վ�~�W�榡
                //20180227:��method�u�Ψ��ˮֵo����,���ݲի~�W
                //�_�h�|���s�u���D(EPB3_0010.approve�btransaction��(�LXA)��DS_EP�s�u�|������DDtable)
                //new EP_C0Z001().getPIN_NAMEForQuery(rtnMap, sb, PIN_NAMEs);
            }

            return rtnList;
        }
    }

    /**
     * �̥\��M�w DataSet ����
     * @param reqMap
     * @param resp
     * @return
     * @throws IOException
     */
    private DataSet getDataSetByExport(Map reqMap, ResponseContext resp) throws IOException {

        String fileName = (String) reqMap.get("fileName");

        if ("CSV".equals(reqMap.get("FILE_TYPE"))) {//�ץXcsv
            csvUtils = new CsvUtils(fileName, resp);
        } else {//�d��
            csvUtils = null;
        }

        isExport = csvUtils != null;
        DataSet ds = null;
        if (isExport) {
            ds = Transaction.getBatchQueryDataSet();
        } else {
            ds = Transaction.getDataSet();
        }
        return ds;
    }

    /**
     * �@�ζץX
     * @param ds
     * @param sql
     * @throws Exception
     */
    private List<Map> export(DataSet ds, String sql, String SUB_CPY_ID) throws Exception {

        BatchQueryDataSet bqds = ((BatchQueryDataSet) ds);
        try {
            bqds.searchAndRetrieve(sql);

            String[] title = new String[] { MessageUtil.getMessage("EPC2_3020_UI_RCV_YM")/*�����~��*/,
                    MessageUtil.getMessage("EPC2_3020_UI_CRT_NO")/*�����N��*/, MessageUtil.getMessage("EPC2_3020_UI_CUS_NAME")/*�Ȥ�W��*/,
                    MessageUtil.getMessage("EPC2_3020_UI_ID")/*�Τ@�s��*/, MessageUtil.getMessage("EPC2_3020_UI_INV_NO")/*�o�����X*/,
                    MessageUtil.getMessage("EPC2_3020_UI_PAY_KIND")/*ú�ں���*/, MessageUtil.getMessage("EPC2_3020_UI_PIN_CODE")/*�~�W�N��*/,
                    MessageUtil.getMessage("EPC2_3020_UI_PIN_NAME") /*�~�W*/
                    , MessageUtil.getMessage("EPC2_3020_UI_BLD_CD")/*�j�ӥN��*/, MessageUtil.getMessage("EPC2_3020_UI_CUS_NO")/*�Ȥ�Ǹ�*/,
                    MessageUtil.getMessage("EPC2_3020_UI_SAL_AMT")/*�P���B*/, MessageUtil.getMessage("EPC2_3020_UI_TAX_AMT")/*��~�|�B*/,
                    MessageUtil.getMessage("EPC2_3020_UI_INV_AMT")/*�o�����B*/, MessageUtil.getMessage("EPC2_3020_UI_PAY_S_DATE")/*ú�کl��*/,
                    MessageUtil.getMessage("EPC2_3020_UI_PAY_E_DATE")/*ú�ڲ״�*/, MessageUtil.getMessage("EPC2_3020_UI_FLD_NO")/*�Ӽh�O*/,
                    MessageUtil.getMessage("EPC2_3020_UI_ROOM_NO") /*�ǧO*/, MessageUtil.getMessage("EPC2_3020_UI_BAL_TYPE") /*�b�U�O*/,
                    MessageUtil.getMessage("EPC2_1010_UI_CUS_USR") /*�Ȥ����*/, MessageUtil.getMessage("EPB2_0010_UI_INV_TYPE") /*�o�����I�覡*/};

            String[] template = new String[] { "RCV_YM2", "CRT_NO", "CUS_NAME", "ID", "INV_NO", "PAY_KIND_NM", "PIN_CODE", "PIN_NAME",
                    "BLD_CD", "CUS_NO", "SAL_AMT", "TAX_AMT", "INV_AMT", "PAY_S_DATE", "PAY_E_DATE", "FLD_NO", "ROOM_NO", "BAL_TYPE_NM",
                    "INV_TYPE_NM", "TRANS_TYPE_NM" };

            //�X�p���
            String[] columns = new String[] { "INV_AMT" };
            Map<String, Object> dataTotalMap = new HashMap<String, Object>();
            dataTotalMap.put("totalTitle", MessageUtil.getMessage("EPC2_3020_UI_TOT3"));//�X�p
            dataTotalMap.put("totalColumns", columns);
            csvUtils.initBatchExportSetting(title, template, dataTotalMap);

            EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
            List<Map> logSecurityList = new ArrayList<Map>();
            Map PIN_NAMEs = new EP_C0Z001().getPIN_NAMEs(SUB_CPY_ID, null);
            StringBuilder sb = new StringBuilder();
            while (csvUtils.fetchData(bqds)) {
                while (csvUtils.next(bqds)) {
                    Map rtnMap = csvUtils.getCurrentMap();

                    Map logSecurityMap = new HashMap();
                    logSecurityMap.put("ID", rtnMap.get("ID"));
                    logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                    logSecurityList.add(logSecurityMap);

                    rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND_FOUR", MapUtils.getString(rtnMap, "PAY_KIND")));

                    String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(MapUtils.getString(rtnMap, "SUB_CPY_ID"), MapUtils.getString(rtnMap,
                        "BLD_CD"));
                    rtnMap.put("BAL_TYPE", BAL_TYPE);
                    rtnMap.put("BAL_TYPE_NM", FieldOptionList.getName("EP", "BAL_TYPE", StringUtils.isBlank(BAL_TYPE) ? "CA" : BAL_TYPE));

                    rtnMap.put("INV_TYPE_NM", FieldOptionList.getName("EP", "CUS_INV_TYPE", MapUtils.getString(rtnMap, "INV_TYPE")));
                    rtnMap.put("TRANS_TYPE_NM", FieldOptionList.getName("EP", "TRANS_TYPE", MapUtils.getString(rtnMap, "TRANS_TYPE")));

                    //�վ�~�W�榡
                    new EP_C0Z001().getPIN_NAMEForQuery(rtnMap, sb, PIN_NAMEs);

                    csvUtils.batchCreateCsv();
                }
            }

            return logSecurityList;
        } finally {
            if (bqds != null) {
                bqds.close();
            }
        }
    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

    /**
     * �d�߸�ƫ��A�� 'key'
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setFieldIfExsits(Map reqMap, DataSet ds, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

}
