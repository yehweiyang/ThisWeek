package com.cathay.ep.c2.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.STRING;
import com.cathay.dd.e0.module.DD_E0Z008;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2017-11-29  Created ����[
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    (�|�p)�o�������Ю��ˮּҲ�
 * �Ҳ�ID    EPC2_1040_mod
 * ���n����    (�|�p)�o�������Ю��ˮּҲ�
 * </pre>
 * @author ����[  
 * @since 2017-11-29
 */
@SuppressWarnings("unchecked")
public class EPC2_1040_mod {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_1040_mod.class);

    private static final String SQL_checkC104Data_001 = "com.cathay.ep.c2.module.EPC2_1040_mod.SQL_checkC104Data_001";

    private static final String SQL_checkConfirm_002 = "com.cathay.ep.c2.module.EPC2_1040_mod.SQL_checkConfirm_002";

    private static final String SQL_checkConfirm_001 = "com.cathay.ep.c2.module.EPC2_1040_mod.SQL_checkConfirm_001";

    /**
     * �ˮ֤����q�O
     * @param SUB_CPY_ID    �����q�O
     * @throws Exception 
     */
    public List<Map> checkConfirm(List<Map> selectList) throws Exception {
        ErrorInputException eie = null;
        if (selectList == null || selectList.isEmpty()) {
            throw new ErrorInputException("�ǤJ��T���i����");
        }
        Map<String, Integer> SLIP_INFO_CNT = new HashMap<String, Integer>();
        Map<String, BigDecimal> SLIP_INFO_AMT = new HashMap<String, BigDecimal>();
        List<Map> SLIP_INFO = new ArrayList<Map>();
        StringBuilder sb = new StringBuilder();

        DataSet ds = Transaction.getDataSet();
        //�̶ǲ���T��z
        for (Map selectMap : selectList) {
            String ACNT_INFO = MapUtils.getString(selectMap, "ACNT_INFO");
            if (SLIP_INFO_CNT.containsKey(ACNT_INFO)) {//�w�s�L,�ȧ�s����/���B
                SLIP_INFO_CNT.put(ACNT_INFO, SLIP_INFO_CNT.get(ACNT_INFO) + 1);
                SLIP_INFO_AMT.put(ACNT_INFO, STRING.objToBigDecimal(SLIP_INFO_AMT.get(ACNT_INFO), BigDecimal.ZERO).add(
                    STRING.objToBigDecimal(selectMap.get("INV_AMT"), BigDecimal.ZERO)));
            } else {
                SLIP_INFO_CNT.put(ACNT_INFO, 1);
                SLIP_INFO_AMT.put(ACNT_INFO, STRING.objToBigDecimal(selectMap.get("INV_AMT"), BigDecimal.ZERO));

                //�ǲ��Ю֥�
                String ACNT_DATE = MapUtils.getString(selectMap, "ACNT_DATE");
                String ACNT_DIV_NO = MapUtils.getString(selectMap, "ACNT_DIV_NO");
                String SLIP_LOT_NO = MapUtils.getString(selectMap, "SLIP_LOT_NO");
                String SLIP_SET_NO = MapUtils.getString(selectMap, "SLIP_SET_NO");
                String TRN_SER_NO = MapUtils.getString(selectMap, "TRN_SER_NO");
                String SUB_CPY_ID = MapUtils.getString(selectMap, "SUB_CPY_ID");

                Map SLIP_Map = new HashMap();
                SLIP_Map.put("ACNT_INFO", ACNT_INFO);
                SLIP_Map.put("ACNT_DATE", ACNT_DATE);
                SLIP_Map.put("CE_DIV_NO", ACNT_DIV_NO.substring(0, 5));
                SLIP_Map.put("SLIP_LOT_NO", SLIP_LOT_NO);
                SLIP_Map.put("SLIP_SET_NO", SLIP_SET_NO);
                SLIP_Map.put("TRN_SER_NO", TRN_SER_NO);
                SLIP_Map.put("SUB_CPY_ID", SUB_CPY_ID);
                SLIP_Map.put("CE_CURR_TYPE", "NTD");//�x��

                //�̶ǲ���T�d�ߦP�ǲ������B�`�M/���
                ds.clear();
                ds.setField("ACNT_DATE", ACNT_DATE);
                ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
                ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
                ds.setField("SLIP_SET_NO", SLIP_SET_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                if ("EP3".equals(SLIP_LOT_NO) || "EPF".equals(SLIP_LOT_NO)) {//�㯲��
                    SLIP_Map.put("DB_SLIP_INFO_CNT", VOTool.findOneToMap(ds, SQL_checkConfirm_001));
                } else {//����.�޲z�O
                    SLIP_Map.put("DB_SLIP_INFO_CNT", VOTool.findOneToMap(ds, SQL_checkConfirm_002));
                }
                SLIP_INFO.add(SLIP_Map);
            }
        }

        //�̶ǲ���T(SLIP_INFO)�d�߰]�|�t�Τ��ǲ����B
        List<Map> tmpSLIP_INFO_DK;
        try {
            tmpSLIP_INFO_DK = new DD_E0Z008().chkEP_AMT(SLIP_INFO);
        } catch (DataNotFoundException dnfe) {
            log.error("�|�p�t�άd�L���ǲ���T::"+dnfe);
            throw new DataNotFoundException("�|�p�t�άd�L���ǲ���T");
        }
        Map SLIP_INFO_DK = new HashMap();
        for (Map tmp : tmpSLIP_INFO_DK) {
            sb.setLength(0);
            sb.append(DATE.formatToROCDate(MapUtils.getString(tmp, "ACNT_DATE"))).append('-').append(tmp.get("SLIP_LOT_NO")).append('-')
                    .append(tmp.get("SLIP_SET_NO"));
            SLIP_INFO_DK.put(sb.toString(), tmp.get("AMT"));
        }

        log.debug("#@#@# SLIP_INFO_CNT:" + SLIP_INFO_CNT);
        log.debug("#@#@# SLIP_INFO_AMT:" + SLIP_INFO_AMT);
        log.debug("#@#@# SLIP_INFO:" + SLIP_INFO);

        //����/���B���
        for (Map SLIP_INFO_MAP : SLIP_INFO) {
            String ACNT_INFO = MapUtils.getString(SLIP_INFO_MAP, "ACNT_INFO");
            //1.�ˮ֦P�ǲ��O�_���䥦����
            /*
            Map DB_SLIP_INFO_CNT = (Map) SLIP_INFO_MAP.get("DB_SLIP_INFO_CNT");
            Integer DB_CNT = MapUtils.getInteger(DB_SLIP_INFO_CNT, "CNT");
            Integer CNT = MapUtils.getInteger(SLIP_INFO_CNT, ACNT_INFO);
            if (CNT != DB_CNT) {
                sb.setLength(0);
                getErrorInputException(eie, sb.append("�ǲ�:").append(ACNT_INFO).append("�������(").append(CNT).append(")�P�t��(").append(DB_CNT)
                        .append(")���@�P!").toString());
                continue;
            }*/
            //2.�ˮֶǲ����B=�|�p�t�ΤW���B
            BigDecimal AMT = STRING.objToBigDecimal(SLIP_INFO_AMT.get(ACNT_INFO), BigDecimal.ZERO);
            BigDecimal DK_AMT = STRING.objToBigDecimal(SLIP_INFO_DK.get(ACNT_INFO), BigDecimal.ZERO);
            if (DK_AMT.compareTo(AMT) != 0) {
                sb.setLength(0);
                getErrorInputException(eie, sb.append("�ǲ�:").append(ACNT_INFO).append("������B(").append(AMT).append(")�P�|�p�t�Ϊ��B(").append(
                    DK_AMT).append(")���@�P!").toString());
                continue;
            }
        }

        if (eie != null) {
            throw eie;
        }

        return SLIP_INFO;

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}
