package com.cathay.ep.c2.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.WorkDate;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dk.a0.bo.DK_AAZ011_bo;
import com.cathay.dk.a0.module.DK_A0Z003;
import com.cathay.dk.f0.bo.DK_F0Z003_bo;
import com.cathay.dk.f0.module.DK_F0Z003;
import com.cathay.dk.f0.module.DK_F0Z011;
import com.cathay.ep.c2.eInvWsForREM.eInvHelper;
import com.cathay.ep.c2.eInvWsForREM.eInvServiceSoap_PortType;
import com.cathay.ep.vo.DTEPC202;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C201;
import com.cathay.ep.z0.module.EP_Z0C202;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE     Description Author
 * 2013/10/1    Created ������
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �㯲�����B�z�Ҳ�
 * �Ҳ�ID     EP_C20010
 * ���n����    �㯲�����B�z�Ҳ�
 * </pre>
 * 
 * 
 * [2018-01-24] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * [2020-02-06] �u�ơG�վ�T�{�B�b�ȽT�{�g�k
 *  
 * [20200220] �ק�� ����z
 * ��عq�l�o���ɤJ
 *  
 * @author ����[
 * @since 2013-12-13
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C20030 {
    private static final Logger log = Logger.getLogger(EP_C20030.class);

    //private static final String SQL_insertDTEPC202_001 = "com.cathay.ep.c2.module.EP_C20030.SQL_insertDTEPC202_001";

    private static final String SQL_queryUnCfmDTEPC201_001 = "com.cathay.ep.c2.module.EP_C20030.SQL_queryUnCfmDTEPC201_001";

    private static final String SQL_queryDTEPC201_001 = "com.cathay.ep.c2.module.EP_C20030.SQL_queryDTEPC201_001";

    //private static final String SQL_confirmAcnt_001 = "com.cathay.ep.c2.module.EP_C20030.SQL_confirmAcnt_001";

    //private static final String SQL_cancelConfirmAcnt_001 = "com.cathay.ep.c2.module.EP_C20030.SQL_cancelConfirmAcnt_001";

    // private static final String SQL_cancelConfirmAcnt_002 = "com.cathay.ep.c2.module.EP_C20030.SQL_cancelConfirmAcnt_002";

    //private static final String SQL_confirm_001 = "com.cathay.ep.c2.module.EP_C20030.SQL_confirm_001";

    //private static final String SQL_confirm_002 = "com.cathay.ep.c2.module.EP_C20030.SQL_confirm_002";

    //private static final String SQL_confirm_003 = "com.cathay.ep.c2.module.EP_C20030.SQL_confirm_003";

    private static final String SQL_confirm_004 = "com.cathay.ep.c2.module.EP_C20030.SQL_confirm_004";

    //private static final String SQL_confirm_005 = "com.cathay.ep.c2.module.EP_C20030.SQL_confirm_005";

    //private static final String SQL_cancel_001 = "com.cathay.ep.c2.module.EP_C20030.SQL_cancel_001";

    //private static final String SQL_cancel_002 = "com.cathay.ep.c2.module.EP_C20030.SQL_cancel_002";

    //private static final String SQL_cancel_003 = "com.cathay.ep.c2.module.EP_C20030.SQL_cancel_003";

    //private static final String SQL_cancel_004 = "com.cathay.ep.c2.module.EP_C20030.SQL_cancel_004";

    private static final Logger Log = Logger.getLogger(EP_C20030.class);

    private boolean isDebug = Log.isDebugEnabled();

    // [20200224]insertDTEPC202()����EP_Z0C202

    /**
     * �d�ߩ㯲�����ө|���T�{���
     * @param INT_YM    �p���~��
     * @param DIV_NO    �ӿ���
     * @param BLD_CD    �j�ӥN��
     * @param QRY_KD    �d�ߺ��� 1:���B>0 2.���B=0
     * @return
     * @throws ModuleException
     */
    public List<Map> queryUnCfmDTEPC201(String INT_YM, String DIV_NO, String BLD_CD, String QRY_KD, String ACNT_TYPE, String SUB_CPY_ID) throws ModuleException {
        return this.queryUnCfmDTEPC201(INT_YM, DIV_NO, BLD_CD, QRY_KD, ACNT_TYPE, SUB_CPY_ID, null, false, 0, 0);
    }

    /**
     * �d�ߩ㯲�����ө|���T�{���
     * @param INT_YM    �p���~��
     * @param DIV_NO    �ӿ���
     * @param BLD_CD    �j�ӥN��
     * @param QRY_KD    �d�ߺ��� 1:���B>0 2.���B=0
     * @return
     * @throws ModuleException
     */
    public List<Map> queryUnCfmDTEPC201(String INT_YM, String DIV_NO, String BLD_CD, String QRY_KD, String ACNT_TYPE, String SUB_CPY_ID, ResponseContext resp, boolean isFirstQuery, Integer startWith, Integer endWith) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(INT_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_001"));//�p���~�뤣�i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //[20200422] ��عq�l�o��:�s�W�ˮ֬d��OP_STATUS=0(���T�{)�ɡA�d�߱���:�j�ӥN���A���������A�קK�@���Ю֦h��
        boolean isAccountSubCpy = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);
        if (!isAccountSubCpy && "1".equals(QRY_KD) && StringUtils.isBlank(BLD_CD)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_026")); //�d��"���T�{"�㯲���A�ݿ�J�d�߱���:�j�ӥN���A�קK�Юֵ��ƹL�h
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("INT_YM", INT_YM);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID) && StringUtils.isNotBlank(DIV_NO)) {//��ؤ��d���d��
            ds.setField("DIV_NO", DIV_NO);
        }
        if (StringUtils.isNotBlank(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }
        if (StringUtils.isNotBlank(QRY_KD)) {
            if ("1".equals(QRY_KD)) {
                ds.setField("QRY_KD1", QRY_KD);
            } else if ("2".equals(QRY_KD)) {
                ds.setField("QRY_KD2", QRY_KD);
            }
        }

        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else {
            ds.setField("ACNT_TYPE2", "2");
        }

        log.debug("#### queryUnCfmDTEPC201.SQL.start ####");
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryUnCfmDTEPC201_001, false);
        log.debug("#### queryUnCfmDTEPC201.SQL.end ####");
        if (rtnList == null || rtnList.size() == 0) {
            throw new DataNotFoundException(MessageUtil.getMessage("EP_C20030_MSG_004"));//�d�L�㯲�����ӥ��T�{���
        }

        Map totalMap = new HashMap();
        totalMap.put("text", "�X�p");
        totalMap.put("textAlign", "center");
        totalMap.put("value", this.getTOT(rtnList));

        List totalList = new ArrayList();
        totalList.add(totalMap);

        boolean isRealPage = resp != null;
        //�u�����\�� �_����ƦC �]�w
        if (isRealPage) {
            resp.addOutputData("totalCountOfRecords", totalList);
            ds.setFetchRange(startWith, endWith);
            rtnList = VOTool.findToMaps(ds, SQL_queryUnCfmDTEPC201_001, false);
            this.getNO(rtnList, startWith);
        }
        if (isRealPage && isFirstQuery) {
            // ���o-�`����,�u�����\��T�w�ѼƦW��
            resp.addOutputData("totalOfRecords", ds.getQueryTotalCount());
        }
        log.debug("#### queryUnCfmDTEPC201.for.start ####");
        for (Map rtnMap : rtnList) {
            rtnMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE")));
            rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS", MapUtils.getString(rtnMap, "OP_STATUS")));
            rtnMap.put("INV_TRANS_TYPE_NM", FieldOptionList.getName("EP", "TRANS_TYPE", MapUtils.getString(rtnMap, "INV_TRANS_TYPE")));
        }
        log.debug("#### queryUnCfmDTEPC201.for.end ####");

        return rtnList;
    }

    /**
     * �d�ߩ㯲�����Ӹ��(�H�X�b��T�d��)
     * @param INT_YM        �p���~��
     * @param BLD_CD        �j�ӥN��
     * @param ACNT_DATE     �b��
     * @param ACNT_DIV_NO   �ӿ���
     * @param SLIP_LOT_NO   �帹
     * @param SLIP_SET_NO   �ո�
     * @return
     * @throws Exception 
     */
    public List<Map> queryDTEPC201(String INT_YM, String BLD_CD, String ACNT_DATE, String ACNT_DIV_NO, String SLIP_LOT_NO, String SLIP_SET_NO, String ACNT_TYPE, String SUB_CPY_ID, String OP_STATUS) throws Exception {

        return this.queryDTEPC201(INT_YM, BLD_CD, ACNT_DATE, ACNT_DIV_NO, SLIP_LOT_NO, SLIP_SET_NO, ACNT_TYPE, SUB_CPY_ID, OP_STATUS, null, false, 0, 0);
    }

    /**
     * �d�ߩ㯲�����Ӹ��(�H�X�b��T�d��)
     * @param INT_YM        �p���~��
     * @param BLD_CD        �j�ӥN��
     * @param ACNT_DATE     �b��
     * @param ACNT_DIV_NO   �ӿ���
     * @param SLIP_LOT_NO   �帹
     * @param SLIP_SET_NO   �ո�
     * @return
     * @throws Exception 
     */
    public List<Map> queryDTEPC201(String INT_YM, String BLD_CD, String ACNT_DATE, String ACNT_DIV_NO, String SLIP_LOT_NO, String SLIP_SET_NO, String ACNT_TYPE, String SUB_CPY_ID, String OP_STATUS, ResponseContext resp, boolean isFirstQuery,
            Integer startWith, Integer endWith) throws Exception {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(INT_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_001"));//�p���~�륲����J
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("INT_YM", INT_YM);
        if (StringUtils.isNotBlank(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }
        if (StringUtils.isNotBlank(ACNT_DATE)) {
            ds.setField("ACNT_DATE", ACNT_DATE);
        }
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID) && StringUtils.isNotBlank(ACNT_DIV_NO)) {//��ؤ��d���d��
            ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        }
        //        if (StringUtils.isNotBlank(SLIP_LOT_NO)) {
        //            ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
        //        }
        if (StringUtils.isNotBlank(SLIP_SET_NO)) {
            ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        }
        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else {
            ds.setField("ACNT_TYPE2", "2");
        }

        if (StringUtils.isNotBlank(OP_STATUS)) {
            ds.setField("OP_STATUS", OP_STATUS);
        }

        log.debug("#### queryDTEPC201.SQL.start ####");
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryDTEPC201_001, false);
        log.debug("#### queryDTEPC201.SQL.end ####");

        if (rtnList == null || rtnList.size() == 0) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20030_MSG_009"));//�d�L�㯲�����Ӹ��
        }

        Map totalMap = new HashMap();
        totalMap.put("text", "�X�p");
        totalMap.put("textAlign", "center");
        totalMap.put("value", this.getTOT(rtnList));

        List totalList = new ArrayList();
        totalList.add(totalMap);

        boolean isRealPage = resp != null;
        //�u�����\�� �_����ƦC �]�w
        if (isRealPage) {
            resp.addOutputData("totalCountOfRecords", totalList);
            ds.setFetchRange(startWith, endWith);
            rtnList = VOTool.findToMaps(ds, SQL_queryDTEPC201_001, false);
            this.getNO(rtnList, startWith);
        }

        if (isRealPage && isFirstQuery) {
            // ���o-�`����,�u�����\��T�w�ѼƦW��
            resp.addOutputData("totalOfRecords", ds.getQueryTotalCount());
        }

        DK_F0Z003 theDK_F0Z003 = new DK_F0Z003();
        MultiKeyMap mkSlipMap = new MultiKeyMap();

        log.debug("#### queryDTEPC201.for.start ####");

        /* ��ؾɤJ:�Ϥ�call DK�Ҳ� */
        boolean isAccountSubCpy = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);//2018-01-24

        for (Map rtnMap : rtnList) {
            //���o�ǲ��Ǹ�
            String mapACNT_DATE = MapUtils.getString(rtnMap, "ACNT_DATE");
            String mapSLIP_LOT_NO = MapUtils.getString(rtnMap, "SLIP_LOT_NO");
            String mapSLIP_SET_NO = MapUtils.getString(rtnMap, "SLIP_SET_NO");
            String mapACNT_DIV_NO = MapUtils.getString(rtnMap, "ACNT_DIV_NO");
            String SLIP_SEQ_NO = "";
            //181226:�վ�Y�L�b�餣�d�ǲ���T,�קK���T�{�ɤ@��CALL DK
            if (StringUtils.isNotBlank(mapACNT_DATE) && isAccountSubCpy) {
                if (mkSlipMap.containsKey(mapACNT_DATE, mapSLIP_LOT_NO, mapSLIP_SET_NO, mapACNT_DIV_NO)) {
                    SLIP_SEQ_NO = (String) mkSlipMap.get(mapACNT_DATE, mapSLIP_LOT_NO, mapSLIP_SET_NO, mapACNT_DIV_NO);
                } else {
                    ReturnMessage RM = new ReturnMessage();
                    DK_F0Z003_bo Z003BO = theDK_F0Z003.doSwitch("1", mapACNT_DATE, mapSLIP_LOT_NO, mapSLIP_SET_NO, mapACNT_DIV_NO, RM);
                    if (RM.getReturnCode() == ReturnCode.OK) {
                        SLIP_SEQ_NO = Z003BO.getSLIP_NO();
                    }
                    mkSlipMap.put(mapACNT_DATE, mapSLIP_LOT_NO, mapSLIP_SET_NO, mapACNT_DIV_NO, SLIP_SEQ_NO);
                }
            }

            rtnMap.put("SLIP_SEQ_NO", SLIP_SEQ_NO);
            rtnMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE")));
            rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS", MapUtils.getString(rtnMap, "OP_STATUS")));
            rtnMap.put("INV_CD_NM", FieldOptionList.getName("EP", "INV_CD", MapUtils.getString(rtnMap, "INV_CD")));
            rtnMap.put("INV_TRANS_TYPE_NM", FieldOptionList.getName("EP", "TRANS_TYPE", MapUtils.getString(rtnMap, "INV_TRANS_TYPE")));
        }

        log.debug("#### queryDTEPC201.for.end ####");

        return rtnList;
    }

    /**
     *  �����㯲���b�ȽT�{
     * @param reqMap    �b�ȸ�T
     * @throws Exception
     */
    /*20200205:�w�L�ϥ�
    public void cancelConfirmAcnt(Map reqMap) throws Exception {
        ErrorInputException eie = null;
        String ACNT_DATE = null;
        String ACNT_DIV_NO = null;
        String SLIP_SET_NO = null;
        String SLIP_LOT_NO = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_010"));//�b�ȸ�T���i����
        } else {
            ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
            if (StringUtils.isBlank(ACNT_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_005"));//�b�Ȥ��������J
            }
            ACNT_DIV_NO = MapUtils.getString(reqMap, "ACNT_DIV_NO");
            if (StringUtils.isBlank(ACNT_DIV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_011"));//�b�ȳ�쥲����J
            }
            SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
            if (StringUtils.isBlank(SLIP_SET_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_008"));//�ǲ��ո�������J
            }
            SLIP_LOT_NO = MapUtils.getString(reqMap, "SLIP_LOT_NO");
            if (StringUtils.isBlank(SLIP_LOT_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_007"));//�ǲ��帹������J
            }
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
    
        //�����b��
        DTDKF001 DTDKF001_Bo = new DTDKF001();
        DTDKF001_Bo.setACNT_DIV_NO(ACNT_DIV_NO);
        DTDKF001_Bo.setACNT_DATE(ACNT_DATE);
        DTDKF001_Bo.setSLIP_LOT_NO(SLIP_LOT_NO);
        DTDKF001_Bo.setSLIP_SET_NO(SLIP_SET_NO);
        ReturnMessage rm = new ReturnMessage();
        new DK_F0Z017().deleteByACNT_DIV_NO(DTDKF001_Bo, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20030_MSG_019"));//�I�s�|�p�����b�ȼҲյo�Ϳ��~
        }
    
        //��s�f��i�סG
        DataSet ds = Transaction.getDataSet();
        VOTool.mapToDataSet(reqMap, ds);
        List<DTEPC201> DTEPC01_VO_List = VOTool.find(DTEPC201.class, SQL_cancelConfirmAcnt_001, ds);
        //RZ_N0Z001 theRZ_N0Z001 = new RZ_N0Z001();
        DTEPC201 DTEPC201_VO_last = new DTEPC201();
        Timestamp currentTime = DATE.currentTime();
        for (DTEPC201 DTEPC201_VO : DTEPC01_VO_List) {
            //FORMAT �@�~�H����T
            DTEPC201_VO.setLST_PROC_DATE(currentTime);
            DTEPC201_VO.setLST_PROC_ID(MapUtils.getString(reqMap, "ACNT_ID"));
            DTEPC201_VO.setLST_PROC_DIV(ACNT_DIV_NO);
            DTEPC201_VO.setLST_PROC_NAME(MapUtils.getString(reqMap, "ACNT_NAME"));
            //theRZ_N0Z001.rejectFlow(DTEPC201_VO);
            DTEPC201_VO_last = DTEPC201_VO;
        }
        Map ACNTMap = new HashMap();
        ACNTMap.put("ACNT_DATE", ACNT_DATE);
        ACNTMap.put("ACNT_DIV_NO", ACNT_DIV_NO);
        ACNTMap.put("SLIP_LOT_NO", SLIP_LOT_NO);
        ACNTMap.put("SLIP_SET_NO", SLIP_SET_NO);
        ACNTMap.put("LST_PROC_DATE", DTEPC201_VO_last.getLST_PROC_DATE());
        ACNTMap.put("LST_PROC_ID", DTEPC201_VO_last.getLST_PROC_ID());
        ACNTMap.put("LST_PROC_DIV", DTEPC201_VO_last.getLST_PROC_DIV());
        ACNTMap.put("LST_PROC_NAME", DTEPC201_VO_last.getLST_PROC_NAME());
        ACNTMap.put("SUB_CPY_ID", SUB_CPY_ID);
    
        new EP_Z0C201().cancel(ACNTMap);
        ds.clear();
        ds.setField("LST_PROC_DATE", DTEPC201_VO_last.getLST_PROC_DATE());
        ds.setField("LST_PROC_ID", DTEPC201_VO_last.getLST_PROC_ID());
        ds.setField("LST_PROC_DIV", DTEPC201_VO_last.getLST_PROC_DIV());
        ds.setField("LST_PROC_NAME", DTEPC201_VO_last.getLST_PROC_NAME());
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
        ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        DBUtil.executeUpdate(ds, SQL_cancelConfirmAcnt_002);
    }*/

    /**
     * �㯲�����ӽT�{
     * @param reqMap    ��J�Ѽ�
     * @throws Exception
     */
    public Map confirm(Map reqMap) throws Exception {
        ErrorInputException eie = null;
        UserObject user = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_002"));//��J�ѼƤ��i����
        } else {
            user = (UserObject) reqMap.get("User");
            if (user == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_003"));//�ϥΪ̸�T���i����
            }
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID"); //�n�J�̤������q�O
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        String INT_YM = MapUtils.getString(reqMap, "INT_YM");
        String BLD_CD_reqMap = MapUtils.getString(reqMap, "BLD_CD");
        String user_div_no = user.getUserDivNo();
        String user_emp_id = user.getEmpID();
        String user_emp_name = user.getEmpName();
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");

        //�ˮ̬֨d�߱�����o���T�{�㯲�����
        //QRY_KD="" �Ҧ����T�{
        List<Map> DTEPC201_VO_List = this.queryUnCfmDTEPC201(INT_YM, user_div_no, BLD_CD_reqMap, "", ACNT_TYPE, SUB_CPY_ID);

        //QRY_KD=1 �㮧���B>0
        List<Map> DTEPC201_VO_List1 = null;
        try {
            DTEPC201_VO_List1 = this.queryUnCfmDTEPC201(INT_YM, user_div_no, BLD_CD_reqMap, "1", ACNT_TYPE, SUB_CPY_ID);
        } catch (DataNotFoundException dnfe) {
            //�d�L�������`
        }

        //QRY_KD=2 �㮧���B=0
        List<Map> DTEPC201_VO_List2 = null;
        try {
            DTEPC201_VO_List2 = this.queryUnCfmDTEPC201(INT_YM, user_div_no, BLD_CD_reqMap, "2", ACNT_TYPE, SUB_CPY_ID);
        } catch (DataNotFoundException dnfe) {
            //�d�L�������`
        }

        EPC2_0030_mod theEPC2_0030_mod = new EPC2_0030_mod();
        //�ˮ��`���B
        theEPC2_0030_mod.checkConfirmData(DTEPC201_VO_List, DTEPC201_VO_List1, DTEPC201_VO_List2);
        //�ˮ֦U�����B
        theEPC2_0030_mod.checkConfirm(reqMap, DTEPC201_VO_List);

        EP_C21030 theEP_C21030 = new EP_C21030();
        DataSet ds = Transaction.getDataSet();

        Timestamp currentTimets = DATE.currentTime();
        //�o�������~��
        BigDecimal RCV_YM = STRING.objToBigDecimal(reqMap.get("INT_YM"), BigDecimal.ZERO);
        //�q�l�o���}�l�ϥΤ��
        BigDecimal START_YM = STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO);

        //���T�{�㯲���B�㮧���B= 0, ��s�㯲���p���_��
        if (DTEPC201_VO_List2 != null) {
            //��s�㮧���B=0�����T�{�㯲����� (���X�b�B���}�o��)
            ds.clear();
            Map updateMap = new HashMap();
            updateMap.put("INT_YM", INT_YM);
            updateMap.put("DIV_NO", user_div_no);
            updateMap.put("LST_PROC_DATE", currentTimets);
            updateMap.put("LST_PROC_ID", user_emp_id);
            updateMap.put("LST_PROC_DIV", user_div_no);
            updateMap.put("LST_PROC_NAME", user_emp_name);
            updateMap.put("SUB_CPY_ID", SUB_CPY_ID);
            if (StringUtils.isNotBlank(BLD_CD_reqMap)) {
                updateMap.put("BLD_CD", BLD_CD_reqMap);
            }
            try {
                new EP_Z0C201().updateINV_AMTforZero(updateMap);
            } catch (DataNotFoundException dnfe) {
                //���i��Ӥ�S���㮧���B=0�����
            }

            for (Map DTEPC201_Map : DTEPC201_VO_List2) {
                //���o�U�@�㯲���p���_�B����
                Date PAY_E_DATE = (Date) DTEPC201_Map.get("PMI_E_DATE");
                String N_PMI_SD = DATE.addDate(PAY_E_DATE.toString(), 0, 0, 1);
                String N_PMI_ED = DATE.getMonthLastDate(N_PMI_SD).toString(); //���Ӧ~��̫�@��

                // ��sú�ڬ����ɤ��㮧�_��βפ�
                ds.clear();
                ds.setField("PAY_NO", DTEPC201_Map.get("PAY_NO"));
                ds.setField("PAY_S_DATE", N_PMI_SD);
                ds.setField("PAY_E_DATE", N_PMI_ED);
                ds.setField("CHG_ID", user_emp_id);
                ds.setField("CHG_DIV_NO", user_div_no);
                ds.setField("CHG_NAME", user_emp_name);
                ds.setField("CHG_DATE", currentTimets);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.executeUpdate(ds, SQL_confirm_004);
            }
        }

        String rtnMsg = StringUtils.EMPTY;
        //���T�{�㯲���B�㮧���B>0 �~�}�o�� �ΥX�b
        if (DTEPC201_VO_List1 != null) {

            //���o�o�����
            String INV_DATE = DATE.getDBDate();
            while (!WorkDate.isWorkingDay(Date.valueOf(INV_DATE))) {
                INV_DATE = DATE.addDate(INV_DATE, 0, 0, 1);
            }

            List<DTEPC202> sucessC202List = new ArrayList<DTEPC202>(); // �s�W�o���M��
            List<Map> sucessC201List = new ArrayList<Map>(); // �}�ߵo�����\�A�ݥX�b�M��

            if (RCV_YM.compareTo(START_YM) < 0) { //�D�q�l�o��

                //180124 ���D��:�q�l�o���㯲�����ӵL�k�T�{(�|�h���ª��o�����X�]�w��)
                //�����o�o�����X
                List<Map> rtnListInvno;
                try {
                    rtnListInvno = theEP_C21030.getInvNos(SUB_CPY_ID, INT_YM, DTEPC201_VO_List1.size()); //��������)
                } catch (Exception e) {
                    throw new ModuleException("�|�����o�o�����X�]�w��!!");
                }
                int i = 0;
                for (Map DTEPC201_Map : DTEPC201_VO_List1) {

                    //���o�j�ӦW�١B�ǧO�B����
                    /* 20200205�G��� queryUnCDTEPC201�d�߮ɤ@�֬d�X
                    Map FLD_ROOM_PRK = this.getFLD_ROOM_PRK(SUB_CPY_ID, CRT_NO, CUS_NO, ds);*/
                    String FLD_NO = MapUtils.getString(DTEPC201_Map, "FLD_NO", "");
                    String ROOM_NO = MapUtils.getString(DTEPC201_Map, "ROOM_NO", "");
                    String PRK_NO = MapUtils.getString(DTEPC201_Map, "PRK_NO", "");
                    String BLD_NAME = MapUtils.getString(DTEPC201_Map, "BLD_NAME", "");

                    //�]�w�~�W
                    StringBuilder sb = new StringBuilder();
                    String PMI_S_DATE = MapUtils.getString(DTEPC201_Map, "PMI_S_DATE");
                    String PMI_E_DATE = MapUtils.getString(DTEPC201_Map, "PMI_E_DATE");
                    if (StringUtils.isNotBlank(PMI_S_DATE) && DATE.isDate(PMI_S_DATE)) {
                        PMI_S_DATE = DATE.toROCDate(PMI_S_DATE);
                    }
                    if (StringUtils.isNotBlank(PMI_E_DATE) && DATE.isDate(PMI_E_DATE)) {
                        PMI_E_DATE = DATE.toROCDate(PMI_E_DATE);
                    }
                    String PIN_NAME = sb.append(MessageUtil.getMessage("EP_C20030_MSG_023")).append(BLD_NAME).append("_").append(PMI_S_DATE).append("_").append(PMI_E_DATE).append("_").append(FLD_NO).append("_").append(ROOM_NO).append("_")
                            .append(PRK_NO).toString();//"�X��_"
                    sb.setLength(0);

                    //�]�w�o�����X�B�y�����B�ˬd�X
                    String INV_NO = MapUtils.getString(rtnListInvno.get(i), "INV_NO");
                    String SER_NO = MapUtils.getString(rtnListInvno.get(i), "SER_NO");
                    String CHK_NO = theEP_C21030.getCHK_NO(INV_NO);
                    i++;

                    //�g�J�o����
                    //20200205:��ξ��s�W
                    DTEPC202 C202vo = VOTool.mapToVO(DTEPC202.class, DTEPC201_Map);
                    C202vo.setRCV_YM(STRING.objToBigDecimal(INT_YM, null));
                    C202vo.setRCV_NO(null);//�㯲���o���L�����s��
                    C202vo.setPAY_KIND("2");
                    C202vo.setPIN_NAME(PIN_NAME);
                    C202vo.setSAL_AMT(STRING.objToBigDecimal(DTEPC201_Map.get("PMI_AMT"), BigDecimal.ZERO));
                    C202vo.setTAX_AMT(STRING.objToBigDecimal(DTEPC201_Map.get("PMI_TAX"), BigDecimal.ZERO));
                    C202vo.setPAY_S_DATE((Date) DTEPC201_Map.get("PMI_S_DATE"));
                    C202vo.setPAY_E_DATE((Date) DTEPC201_Map.get("PMI_E_DATE"));
                    C202vo.setINV_DATE(Date.valueOf(INV_DATE));
                    C202vo.setINV_CD("0");
                    C202vo.setINV_NO(INV_NO);
                    C202vo.setSER_NO(SER_NO);
                    C202vo.setCHK_NO(CHK_NO);
                    C202vo.setTRN_KIND("EPC202");
                    C202vo.setCHG_DATE(currentTimets);
                    C202vo.setCHG_DIV_NO(user.getDivNo());
                    C202vo.setCHG_ID(user.getEmpID());
                    C202vo.setCHG_NAME(user.getEmpName());
                    C202vo.setTRANS_TYPE("A");//�D�q�l�o���A��Τ覡�Ҭ�A�ȥ�
                    sucessC202List.add(C202vo);

                    DTEPC201_Map.put("INV_NO", INV_NO);
                    sucessC201List.add(DTEPC201_Map);
                } //end for
            } else if ("01".equals(SUB_CPY_ID)) {// ��عq�l�o���G�I�s�t��WS���͵o�����X
                //20200320 ��عq�l�o���]�o�������W�h�̷��Ѥ�����D�A�G�ȯ�}�߷���o���A���i���e�}�U��o��
                if (RCV_YM.compareTo(new BigDecimal(DATE.getTodayYearAndMonth())) > 0) {
                    //�]�q�l�o�������W�h�A���i�w�}�o��
                    throw new ModuleException(MessageUtil.getMessage("EP_C20030_MSG_028"));
                }

                //��عq�l�o��:�ŧieInvHelper��eInv Ws service
                eInvHelper theEInvHelper = new eInvHelper(user.getEmpID());
                eInvServiceSoap_PortType service = theEInvHelper.initService();

                for (Map DTEPC201_Map : DTEPC201_VO_List1) {
                    DTEPC201_Map.put("RCV_YM", INT_YM); // �����~��
                    DTEPC201_Map.put("RCV_NO", null); // �����s��  //�㯲���o���L�����s��
                    DTEPC201_Map.put("PAY_KIND", "2"); // ú�ں���:2=���
                    DTEPC201_Map.put("SAL_AMT", DTEPC201_Map.get("PMI_AMT")); // �P���B
                    DTEPC201_Map.put("TAX_AMT", DTEPC201_Map.get("PMI_TAX")); // ��~�|�B
                    DTEPC201_Map.put("PAY_S_DATE", DTEPC201_Map.get("PMI_S_DATE")); // ú�کl��
                    DTEPC201_Map.put("PAY_E_DATE", DTEPC201_Map.get("PMI_E_DATE")); // ú�ڲ״�
                    DTEPC201_Map.put("INV_DATE", INV_DATE); // �}�ߤ��
                    DTEPC201_Map.put("TRN_KIND", "EPC202"); // ������� //�o���}��
                    DTEPC201_Map.put("LST_PROC_DATE", currentTimets); // ���ʤH�����
                    DTEPC201_Map.put("LST_PROC_DIV", user_div_no); // ���ʤH�����
                    DTEPC201_Map.put("LST_PROC_ID", user_emp_id); // ���ʤH��ID
                    DTEPC201_Map.put("LST_PROC_NAME", user_emp_name); // ���ʤH��
                    DTEPC201_Map.put("SOURCE", "C201"); // �ӷ� //�㯲��
                    try {
                        Map resultMap = theEInvHelper.createInv(DTEPC201_Map, service);
                        DTEPC202 C202 = (DTEPC202) resultMap.get("C202");
                        String INV_NO = C202.getINV_NO();//�o�����X
                        sucessC202List.add(C202);

                        DTEPC201_Map.put("INV_NO", INV_NO);
                        sucessC201List.add(DTEPC201_Map);
                    } catch (Exception e) {
                        // �I�s�q�l�o��ws���ѡA�㯲���s���G{0}�A���~�T���G{1}
                        rtnMsg = MessageUtil.getMessage("EP_C20030_MSG_027", new String[] { MapUtils.getString(DTEPC201_Map, "INT_NO"), e.getMessage() });
                        log.fatal(rtnMsg, e);

                        // ��عq�l�o���G�I�s�t��WS�C�@�����Ѳפ�j��
                        break;
                    } catch (Throwable t) {
                        // �I�s�q�l�o��ws���ѡA�㯲���s���G{0}�A���~�T���G{1}
                        rtnMsg = MessageUtil.getMessage("EP_C20030_MSG_027", new String[] { MapUtils.getString(DTEPC201_Map, "INT_NO"), t.getMessage() });
                        log.fatal(rtnMsg, t);

                        // ��عq�l�o���G�I�s�t��WS�C�@�����Ѳפ�j��
                        break;
                    }
                } //end for

                reqMap.put("rtnMsg", rtnMsg);
            } else {//��عq�l�o���A�����͵o���ɡA���n�X�b

                for (Map DTEPC201_Map : DTEPC201_VO_List1) {
                    sucessC201List.add(DTEPC201_Map);
                }
            } //END OF �q�l�o���P�_

            //20200205:��ξ��s�W�o����
            new EP_Z0C202().insertInvList(sucessC202List);

            //[20200422] ���U����ú��A���o�����X��岣�ͫ�A��
            if (sucessC201List != null && !sucessC201List.isEmpty()) {//�����\�}�ߵo����     

                for (Map DTEPC201_Map : sucessC201List) {
                    // ��s�㯲������ //[20200422] confirmAcnt�@�_��s

                    //���o�U�@�㯲���p���_�B����
                    Date PAY_E_DATE = (Date) DTEPC201_Map.get("PMI_E_DATE");
                    String N_PMI_SD = DATE.addDate(PAY_E_DATE.toString(), 0, 0, 1);
                    String N_PMI_ED = DATE.getMonthLastDate(N_PMI_SD).toString(); //���Ӧ~��̫�@��

                    // ��sú�ڬ�����(C301)���㮧�_��βפ�
                    ds.clear();
                    ds.setField("PAY_NO", DTEPC201_Map.get("PAY_NO"));
                    ds.setField("PAY_S_DATE", N_PMI_SD);
                    ds.setField("PAY_E_DATE", N_PMI_ED);
                    ds.setField("CHG_ID", user_emp_id);
                    ds.setField("CHG_DIV_NO", user_div_no);
                    ds.setField("CHG_NAME", user_emp_name);
                    ds.setField("CHG_DATE", currentTimets);
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    DBUtil.executeUpdate(ds, SQL_confirm_004);
                }

                //�v���X�|�p�b                     
                //reqMap.put("ACNT_DATE", reqMap.get("ACNT_DATE"));//�b�Ȥ��
                reqMap.put("ACNT_DIV_NO", user_div_no); //�b�ȳ��
                reqMap.put("ACNT_ID", user_emp_id); //�b�ȤH��ID
                reqMap.put("ACNT_NAME", user_emp_name);//�b�ȤH���m�W
                return this.confirmAcnt(reqMap, sucessC201List);
            }

        } //DTEPC201_VO_List1 != null
        return reqMap;
    }

    /**
     * �㯲���b�ȽT�{
     * @param reqMap            �b�ȸ�T
     * @param DTEPC201_VO_List  ����������
     * @return
     * @throws Exception
     */
    public Map confirmAcnt(Map reqMap, List<Map> DTEPC201_VO_List) throws Exception {
        //�Ѽ��ˮ�
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_010"));//�b�ȸ�T���i����
        }
        if (DTEPC201_VO_List == null || DTEPC201_VO_List.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_012"));//���������ɤ��i����
        }
        String ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
        String ACNT_DIV_NO = MapUtils.getString(reqMap, "ACNT_DIV_NO");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

        if (StringUtils.isBlank(ACNT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_005"));//�b�Ȥ��������J
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_011"));//�b�ȳ�쥲����J
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        long time1 = 0;
        long time2 = 0;

        if (isDebug) {
            Log.debug("============================confirmAcnt start========================================");
            time1 = System.currentTimeMillis();
        }

        //���o�ǲ��帹
        String SLIP_LOT_NO = MapUtils.getString(reqMap, "SLIP_LOT_NO");
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        //reqMap.put("SLIP_LOT_NO", SLIP_LOT_NO); //���ʲ��㯲���ǲ�

        reqMap.put("ACNT_DATE", ACNT_DATE);

        ReturnMessage rm = new ReturnMessage();

        //���o�g�����Ǹ�UserTrnSerno
        String ACNT_ID = MapUtils.getString(reqMap, "ACNT_ID");
        //String UserTrnSerno = new DK_F0Z002().getSER_NO(ACNT_ID, ACNT_DATE, rm); 2018-01-24

        //���o�������ɶ�
        String TrnDate = DATE.getDBTimeStamp();
        DK_A0Z003 theDK_A0Z003 = new DK_A0Z003();
        //RZ_N0Z001 theRZ_N0Z001 = new RZ_N0Z001();

        long time3 = 0;
        long time4 = 0;
        if (isDebug) {
            Log.debug("============================confirmAcnt start========================================");
            time3 = System.currentTimeMillis();
        }

        String ACNT_NAME = MapUtils.getString(reqMap, "ACNT_NAME");

        Set<String> INT_NOs = new HashSet<String>();

        //�̷� BAL_TYPE �֭p INT_AMT�P TAX_AMT
        Map<String, Map<String, BigDecimal>> BALTYPE_SUM_MAP = new HashMap();
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        for (Map DTEPC201_Map : DTEPC201_VO_List) {
            //���o�b�U�O
            String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(MapUtils.getString(DTEPC201_Map, "SUB_CPY_ID"), MapUtils.getString(DTEPC201_Map, "BLD_CD"));

            Map<String, BigDecimal> SUM_MAP = (Map<String, BigDecimal>) MapUtils.getObject(BALTYPE_SUM_MAP, BAL_TYPE, new HashMap<String, BigDecimal>());

            INT_NOs.add((String) DTEPC201_Map.get("INT_NO"));

            BigDecimal INT_AMT = (BigDecimal) DTEPC201_Map.get("PMI_AMT");
            BigDecimal TAX_AMT = (BigDecimal) DTEPC201_Map.get("PMI_TAX");

            //�[�`�㮧���B�Ω㯲���|�B
            if (INT_AMT != null && INT_AMT.compareTo(BigDecimal.ZERO) > 0) {
                SUM_MAP.put("TOT_INT_AMT", STRING.objToBigDecimal(SUM_MAP.get("TOT_INT_AMT"), BigDecimal.ZERO).add(INT_AMT));
            }
            if (TAX_AMT != null && TAX_AMT.compareTo(BigDecimal.ZERO) > 0) {
                SUM_MAP.put("TOT_TAX_AMT", STRING.objToBigDecimal(SUM_MAP.get("TOT_TAX_AMT"), BigDecimal.ZERO).add(TAX_AMT));
            }
            BALTYPE_SUM_MAP.put(BAL_TYPE, SUM_MAP);
        }

        if (isDebug) {
            time4 = System.currentTimeMillis();
            Log.debug("============================approve::cost time>>>>>" + (time4 - time3) + "============================");
        }

        /* ��ؾɤJ:�Ϥ�call DK�Ҳ� */
        //���o�ǲ��ո�
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        String SlipSetNo = theEP_Z0Z001.getSLIP_SET_NO(SUB_CPY_ID, "2", ACNT_DIV_NO, null, SLIP_LOT_NO, ACNT_DATE, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20030_MSG_013"));//���o�ǲ��ո��o�Ϳ��~
        }
        reqMap.put("SLIP_SET_NO", SlipSetNo);

        /* ��ؾɤJ:�Ϥ�call DK�Ҳ� */
        //���o�g�����Ǹ�
        String UserTrnSerno = theEP_Z0Z001.getTRN_SER_NO(SUB_CPY_ID, ACNT_ID, ACNT_DATE, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20030_MSG_014"));//���o�g�����Ǹ��o�Ϳ��~
        }

        //�v�����ͱb�Ȥ���
        List<DK_AAZ011_bo> DK_AAZ011_bo_List = new ArrayList<DK_AAZ011_bo>();
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {
            Set<String> BAL_TYPEs = BALTYPE_SUM_MAP.keySet();
            for (String BAL_TYPE : BAL_TYPEs) {
                Map<String, BigDecimal> SUM_MAP = BALTYPE_SUM_MAP.get(BAL_TYPE);

                //(1)   �㮧���B
                BigDecimal TOT_INT_AMT = STRING.objToBigDecimal(SUM_MAP.get("TOT_INT_AMT"), BigDecimal.ZERO);
                if (TOT_INT_AMT.compareTo(BigDecimal.ZERO) > 0) {
                    DK_AAZ011_bo Z011BO_1 = new DK_AAZ011_bo();
                    Z011BO_1.setINPUT_ID(ACNT_ID);
                    Z011BO_1.setINPUT_NAME(ACNT_NAME);
                    Z011BO_1.setTRN_DATE(TrnDate);
                    Z011BO_1.setTRN_SER_NO(UserTrnSerno);
                    Z011BO_1.setSLIP_LOT_NO(SLIP_LOT_NO);
                    Z011BO_1.setSLIP_SET_NO(SlipSetNo);
                    Z011BO_1.setREL_FILE_NO("DTEPC201");
                    Z011BO_1.setACNT_DATE(ACNT_DATE);
                    Z011BO_1.setTRN_KIND("EPC005");
                    Z011BO_1.setMEMO(MessageUtil.getMessage("EP_C20030_MSG_015"));// "���ʲ�_�㯲��"
                    Z011BO_1.setACNT_DIV_NO(ACNT_DIV_NO);
                    Z011BO_1.setKIND_CODE("");
                    Z011BO_1.setCURR("NTD");
                    Z011BO_1.setCNT("1");
                    Z011BO_1.setBUS_CODE("EP");
                    Z011BO_1.setBUS_TRAN_CODE("1");
                    Z011BO_1.setITEM("3");
                    Z011BO_1.setTYPE("1");
                    Z011BO_1.setBANK_NO(null);
                    Z011BO_1.setACNT_NO(null);
                    Z011BO_1.setAMT(TOT_INT_AMT.toPlainString());
                    Z011BO_1.setDIV_NO_C101(ACNT_DIV_NO);
                    Z011BO_1.setACNT_TYPE(ACNT_TYPE);
                    Z011BO_1.setBAL_TYPE(BAL_TYPE);

                    DK_AAZ011_bo_List.add(Z011BO_1);
                }

                //(2) �㯲���|�B
                BigDecimal TOT_TAX_AMT = STRING.objToBigDecimal(SUM_MAP.get("TOT_TAX_AMT"), BigDecimal.ZERO);
                if (TOT_TAX_AMT.compareTo(BigDecimal.ZERO) > 0) {
                    DK_AAZ011_bo Z011BO_2 = new DK_AAZ011_bo();
                    Z011BO_2.setINPUT_ID(ACNT_ID);
                    Z011BO_2.setINPUT_NAME(ACNT_NAME);
                    Z011BO_2.setTRN_DATE(TrnDate);
                    Z011BO_2.setTRN_SER_NO(UserTrnSerno);
                    Z011BO_2.setSLIP_LOT_NO(SLIP_LOT_NO);
                    Z011BO_2.setSLIP_SET_NO(SlipSetNo);
                    Z011BO_2.setREL_FILE_NO("DTEPC201");
                    Z011BO_2.setACNT_DATE(ACNT_DATE);
                    Z011BO_2.setTRN_KIND("EPC005");
                    Z011BO_2.setMEMO(MessageUtil.getMessage("EP_C20030_MSG_015"));//"���ʲ�_�㯲��" 
                    Z011BO_2.setACNT_DIV_NO(ACNT_DIV_NO);
                    Z011BO_2.setKIND_CODE("");
                    Z011BO_2.setCURR("NTD");
                    Z011BO_2.setCNT("1");
                    Z011BO_2.setBUS_CODE("EP");
                    Z011BO_2.setBUS_TRAN_CODE("1");
                    Z011BO_2.setITEM("3");
                    Z011BO_2.setTYPE("2");
                    Z011BO_2.setBANK_NO(null);
                    Z011BO_2.setACNT_NO(null);
                    Z011BO_2.setAMT(TOT_TAX_AMT.toPlainString());
                    Z011BO_2.setDIV_NO_C101(ACNT_DIV_NO);
                    Z011BO_2.setACNT_TYPE(ACNT_TYPE);
                    Z011BO_2.setBAL_TYPE(BAL_TYPE);

                    DK_AAZ011_bo_List.add(Z011BO_2);
                }
            }

            if (DK_AAZ011_bo_List.size() > 0) {
                //PASS�b�Ȥ鵲�t��
                theDK_A0Z003.doInsert(DK_AAZ011_bo_List, rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ErrorInputException(MessageUtil.getMessage("EP_C20030_MSG_016")); //PASS�b�Ȥ鵲�t�εo�Ϳ��~
                }
                //�ˮֱb�ȬO�_����
                new DK_F0Z011().isBalance2(ACNT_DIV_NO, ACNT_ID, ACNT_DATE, SLIP_LOT_NO, SlipSetNo, rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(MessageUtil.getMessage("EP_C20030_MSG_018"));//�ˮֱb�ȬO�_���ŵo�Ϳ��~
                }
            }

        }

        //�N�b�ȸ�T�^��㯲��������
        Map ACNTMap = new HashMap();
        ACNTMap.put("OP_STATUS", MapUtils.getString(DTEPC201_VO_List.get(0), "OP_STATUS"));
        ACNTMap.put("ACNT_DATE", ACNT_DATE);
        ACNTMap.put("ACNT_DIV_NO", ACNT_DIV_NO);
        ACNTMap.put("SLIP_LOT_NO", SLIP_LOT_NO);
        ACNTMap.put("SlipSetNo", SlipSetNo);
        ACNTMap.put("UserTrnSerno", UserTrnSerno);
        ACNTMap.put("ACNT_ID", ACNT_ID);
        ACNTMap.put("ACNT_NAME", ACNT_NAME);
        ACNTMap.put("LST_PROC_DATE", TrnDate);
        ACNTMap.put("LST_PROC_ID", ACNT_ID);
        ACNTMap.put("LST_PROC_DIV", ACNT_DIV_NO);
        ACNTMap.put("LST_PROC_NAME", ACNT_NAME);
        ACNTMap.put("SUB_CPY_ID", SUB_CPY_ID);
        new EP_Z0C201().confirm(DTEPC201_VO_List, ACNTMap);

        if (isDebug) {
            time2 = System.currentTimeMillis();
            Log.debug("============================confirmAcnt (have approve)::cost time>>>>>" + (time2 - time1) + "============================");
            Log.debug("============================confirmAcnt end========================================");
        }

        return reqMap;
    }

    /**
     *  �����㯲���b�ȽT�{
     * @param reqMap    �b�ȸ�T
     * @throws Exception
     */
    /*20200205:�w�L�ϥ�
    public void cancelConfirmAcnt(Map reqMap) throws Exception {
        ErrorInputException eie = null;
        String ACNT_DATE = null;
        String ACNT_DIV_NO = null;
        String SLIP_SET_NO = null;
        String SLIP_LOT_NO = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_010"));//�b�ȸ�T���i����
        } else {
            ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
            if (StringUtils.isBlank(ACNT_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_005"));//�b�Ȥ��������J
            }
            ACNT_DIV_NO = MapUtils.getString(reqMap, "ACNT_DIV_NO");
            if (StringUtils.isBlank(ACNT_DIV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_011"));//�b�ȳ�쥲����J
            }
            SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
            if (StringUtils.isBlank(SLIP_SET_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_008"));//�ǲ��ո�������J
            }
            SLIP_LOT_NO = MapUtils.getString(reqMap, "SLIP_LOT_NO");
            if (StringUtils.isBlank(SLIP_LOT_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_007"));//�ǲ��帹������J
            }
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
    
        //�����b��
        DTDKF001 DTDKF001_Bo = new DTDKF001();
        DTDKF001_Bo.setACNT_DIV_NO(ACNT_DIV_NO);
        DTDKF001_Bo.setACNT_DATE(ACNT_DATE);
        DTDKF001_Bo.setSLIP_LOT_NO(SLIP_LOT_NO);
        DTDKF001_Bo.setSLIP_SET_NO(SLIP_SET_NO);
        ReturnMessage rm = new ReturnMessage();
        new DK_F0Z017().deleteByACNT_DIV_NO(DTDKF001_Bo, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(MessageUtil.getMessage("EP_C20030_MSG_019"));//�I�s�|�p�����b�ȼҲյo�Ϳ��~
        }
    
        //��s�f��i�סG
        DataSet ds = Transaction.getDataSet();
        VOTool.mapToDataSet(reqMap, ds);
        List<DTEPC201> DTEPC01_VO_List = VOTool.find(DTEPC201.class, SQL_cancelConfirmAcnt_001, ds);
        //RZ_N0Z001 theRZ_N0Z001 = new RZ_N0Z001();
        DTEPC201 DTEPC201_VO_last = new DTEPC201();
        Timestamp currentTime = DATE.currentTime();
        for (DTEPC201 DTEPC201_VO : DTEPC01_VO_List) {
            //FORMAT �@�~�H����T
            DTEPC201_VO.setLST_PROC_DATE(currentTime);
            DTEPC201_VO.setLST_PROC_ID(MapUtils.getString(reqMap, "ACNT_ID"));
            DTEPC201_VO.setLST_PROC_DIV(ACNT_DIV_NO);
            DTEPC201_VO.setLST_PROC_NAME(MapUtils.getString(reqMap, "ACNT_NAME"));
            //theRZ_N0Z001.rejectFlow(DTEPC201_VO);
            DTEPC201_VO_last = DTEPC201_VO;
        }
        Map ACNTMap = new HashMap();
        ACNTMap.put("ACNT_DATE", ACNT_DATE);
        ACNTMap.put("ACNT_DIV_NO", ACNT_DIV_NO);
        ACNTMap.put("SLIP_LOT_NO", SLIP_LOT_NO);
        ACNTMap.put("SLIP_SET_NO", SLIP_SET_NO);
        ACNTMap.put("LST_PROC_DATE", DTEPC201_VO_last.getLST_PROC_DATE());
        ACNTMap.put("LST_PROC_ID", DTEPC201_VO_last.getLST_PROC_ID());
        ACNTMap.put("LST_PROC_DIV", DTEPC201_VO_last.getLST_PROC_DIV());
        ACNTMap.put("LST_PROC_NAME", DTEPC201_VO_last.getLST_PROC_NAME());
        ACNTMap.put("SUB_CPY_ID", SUB_CPY_ID);
    
        new EP_Z0C201().cancel(ACNTMap);
        ds.clear();
        ds.setField("LST_PROC_DATE", DTEPC201_VO_last.getLST_PROC_DATE());
        ds.setField("LST_PROC_ID", DTEPC201_VO_last.getLST_PROC_ID());
        ds.setField("LST_PROC_DIV", DTEPC201_VO_last.getLST_PROC_DIV());
        ds.setField("LST_PROC_NAME", DTEPC201_VO_last.getLST_PROC_NAME());
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
        ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        DBUtil.executeUpdate(ds, SQL_cancelConfirmAcnt_002);
    }*/

    /**
     * ���o�Ӽh/�ǧO/������
     * @param SUB_CPY_ID
     * @param CRT_NO
     * @param CUS_NO
     * @param ds
     * @return
     * @throws ModuleException
     */
    /* //20200205 �u�ơG��� queryUnCDTEPC201�d�߮ɤ@�֬d�X
    public Map getFLD_ROOM_PRK(String SUB_CPY_ID, String CRT_NO, int CUS_NO, DataSet ds) throws ModuleException {
        
        //�]�w�Ӽh���
        String ROOM_NO = "";
        String FLD_NO = "";
        String PRK_NO = "";
    
        ds.clear();
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        Map tmpMap = VOTool.findOneToMap(ds, SQL_confirm_001, false);
    
        if (tmpMap != null && !tmpMap.isEmpty()) {
            FLD_NO = MapUtils.getString(tmpMap, "FLD_NO");
            ROOM_NO = MapUtils.getString(tmpMap, "ROOM_NO");
            if (StringUtils.isBlank(FLD_NO) || StringUtils.isBlank(ROOM_NO)) {//�S���ǧO�A��쨮��
                PRK_NO = MapUtils.getString(tmpMap, "PRK_NO");
            }
        }
    
        Map rtnMap = new HashMap();
        rtnMap.put("PRK_NO", PRK_NO);
        rtnMap.put("FLD_NO", FLD_NO);
        rtnMap.put("ROOM_NO", ROOM_NO);
        rtnMap.put("BLD_NAME", tmpMap.get("BLD_NAME"));
        return rtnMap;
    }*/

    /**
     * �㯲�����Ө����T�{
     * @param reqMap    ��J�Ѽ�
     * @throws Exception
     */
    /* 20200205 �w�L�ϥ�
    public void cancel(Map reqMap) throws Exception {
        ErrorInputException eie = null;
        UserObject user = null;
        String ACNT_DATE = null;
        String ACNT_DIV_NO = null;
        String SLIP_SET_NO = null;
        String SLIP_LOT_NO = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_002"));//��J�ѼƤ��i����
        } else {
            user = (UserObject) reqMap.get("User");
            if (user == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_003"));//�ϥΪ̸�T���i����
            }
            ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
            if (StringUtils.isBlank(ACNT_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_005"));//�b�Ȥ��������J
            }
            ACNT_DIV_NO = MapUtils.getString(reqMap, "ACNT_DIV_NO");
            if (StringUtils.isBlank(ACNT_DIV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_011"));//�b�ȳ�쥲����J
            }
            SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
            if (StringUtils.isBlank(SLIP_SET_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_008"));//�ǲ��ո�������J
            }
            SLIP_LOT_NO = MapUtils.getString(reqMap, "SLIP_LOT_NO");
            if (StringUtils.isBlank(SLIP_LOT_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C20030_MSG_007"));//�ǲ��帹������J
            }
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
    
        //�ˮֵe�����o���
        new EPC2_0030_mod().checkCancel(reqMap);
    
        String user_div_no = user.getUserDivNo();
        String user_emp_id = user.getEmpID();
        String user_emp_name = user.getEmpName();
    
        //���o���٭�㯲������
        DataSet ds = Transaction.getDataSet();
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
        ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<DTEPC201> DTEPC201_VO_List = VOTool.find(DTEPC201.class, SQL_cancel_001, ds);
    
        String currentTime = DATE.getDBTimeStamp();
        for (DTEPC201 DTEPC201_VO : DTEPC201_VO_List) {
    
            //�v����s�o���ɬ����@�o���X�b��
            ds.clear();
            ds.setField("INV_NO", DTEPC201_VO.getINV_NO());
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_cancel_002);
            // �٭�㯲������
            ds.clear();
            ds.setField("INT_NO", DTEPC201_VO.getINT_NO());
            ds.setField("LST_PROC_ID", user_emp_id);
            ds.setField("LST_PROC_DIV", user_div_no);
            ds.setField("LST_PROC_NAME", user_emp_name);
            ds.setField("LST_PROC_DATE", currentTime);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_cancel_003);
            // �٭�ú�ڬ����ɤ��㮧�_��βפ�
            ds.clear();
            ds.setField("PAY_NO", DTEPC201_VO.getPAY_NO());
            ds.setField("CHG_ID", user_emp_id);
            ds.setField("CHG_DIV_NO", user_div_no);
            ds.setField("CHG_NAME", user_emp_name);
            ds.setField("CHG_DATE", currentTime);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_cancel_004);
        }
        // �R���|�p�b
        reqMap.put("ACNT_DATE", ACNT_DATE);//�b�Ȥ��
        reqMap.put("ACNT_DIV_NO", user_div_no); //�b�ȳ��
        reqMap.put("ACNT_ID", user_emp_id); //�b�ȤH��ID
        reqMap.put("ACNT_NAME", user_emp_name);//�b�ȤH���m�W
        reqMap.put("SLIP_SET_NO", SLIP_SET_NO); //�ǲ��ո�
        reqMap.put("SLIP_LOT_NO", SLIP_LOT_NO);//�ǲ��帹
    
        this.cancelConfirmAcnt(reqMap);
    
    }*/

    /**
     * �p��X�p
     * @param rtnList
     * @return
     */
    private Map getTOT(List<Map> rtnList) {
        BigDecimal PMI_AMT_TOTAL = BigDecimal.ZERO;
        BigDecimal PMI_TAX_TOTAL = BigDecimal.ZERO;
        BigDecimal INV_AMT_TOTAL = BigDecimal.ZERO;
        BigDecimal PMS_AMT_TOTAL = BigDecimal.ZERO;
        int i = 1;
        for (Map C201_Map : rtnList) {
            C201_Map.put("NO", i++);
            String INV_CD = MapUtils.getString(C201_Map, "INV_CD");
            if (StringUtils.isNotBlank(INV_CD) && !"0".equals(INV_CD)) {
                continue;
            }
            PMI_AMT_TOTAL = PMI_AMT_TOTAL.add(STRING.objToBigDecimal(C201_Map.get("PMI_AMT"), BigDecimal.ZERO));
            PMI_TAX_TOTAL = PMI_TAX_TOTAL.add(STRING.objToBigDecimal(C201_Map.get("PMI_TAX"), BigDecimal.ZERO));
            INV_AMT_TOTAL = INV_AMT_TOTAL.add(STRING.objToBigDecimal(C201_Map.get("INV_AMT"), BigDecimal.ZERO));
            PMS_AMT_TOTAL = PMS_AMT_TOTAL.add(STRING.objToBigDecimal(C201_Map.get("PMS_AMT"), BigDecimal.ZERO));
        }
        Map totMap = new HashMap();
        totMap.put("PMI_AMT", PMI_AMT_TOTAL);
        totMap.put("PMI_TAX", PMI_TAX_TOTAL);
        totMap.put("INV_AMT", INV_AMT_TOTAL);
        totMap.put("PMS_AMT", PMS_AMT_TOTAL);

        return totMap;
    }

    /**
     * �]�w�Ǹ�
     * @param rtnList
     * @param startWith
     * @return
     */
    private void getNO(List<Map> rtnList, Integer startWith) {
        for (int i = 0; i < rtnList.size(); i++) {
            Map C201Map = rtnList.get(i);
            C201Map.put("NO", startWith + i);
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}
