package com.cathay.ep.c2.module;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.RptUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Description                                 Author
 * 2013/8/15  Created                                     �\�a�s
 * 2018/3/31  ���                                     ����[
 * �@�B  �{���\�෧�n�����G
 * �ҲզW�� ú�O�ҩ��d�߼Ҳ�
 * �Ҳ�ID  EP_C23120 
 * ���n���� �d��DTEPB102_�ӯ������ɸ��
 *</pre>
 * @author ù�ΫT
 * @since 2014-01-07
 */
@SuppressWarnings("unchecked")
public class EP_C23120 {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EP_C23120.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.c2.module.EP_C23120.SQL_queryList_001";

    //private static final String SQL_queryForRptParams_001 = "com.cathay.ep.c2.module.EP_C23120.SQL_queryForRptParams_001";

    private static final String SQL_queryForRptDetail_001 = "com.cathay.ep.c2.module.EP_C23120.SQL_queryForRptDetail_001";

    private static final String SQL_queryForRptDetail_002 = "com.cathay.ep.c2.module.EP_C23120.SQL_queryForRptDetail_002";

    /**
     * �d��ú�O���
     * @param RCV_YEAR �����~��
     * @param BLD_CD �j�ӥN��
     * @param CUS_NAME �Ȥ�W��
     * @return ú�O���List
     * @throws ModuleException
     */
    public List<Map> queryList(String SUB_CPY_ID,BigDecimal RCV_YEAR, String BLD_CD, String CUS_NAME) throws ModuleException {
        ErrorInputException eie = null;
        if (RCV_YEAR == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23120_ERRMSG_001"));//�п�J�����~��
        }
        //        if (StringUtils.isBlank(BLD_CD) && StringUtils.isBlank(CUS_NAME)) {
        //            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23120_ERRMSG_002"));//�п�J�j�ӥN���ΫȤ�W��
        //        }
        if (eie != null) {
            throw eie;
        }

        BatchQueryDataSet bqds = null;
        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            bqds.setField("RCV_YEAR", RCV_YEAR);
            setFieldIfExist(bqds, "BLD_CD", BLD_CD);
            StringBuilder sb = new StringBuilder();
            setLikeFieldsIfExsits(bqds, "CUS_NAME", CUS_NAME, sb);

            bqds.searchAndRetrieve(SQL_queryList_001);

            int groupCount = 2000;//�C�妸�d��2000�����
            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            if (totalcount == 0) {
                throw new DataNotFoundException("�d�L���");
            }
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��

            List<Map> rtnList = new ArrayList<Map>();
            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map rtnMap = VOTool.dataSetToMap(bqds);

                    rtnMap.put("YEAR_AMT", getBigDecimal(rtnMap.get("INV_AMT")).subtract(getBigDecimal(rtnMap.get("RJT_AMT"))));

                    rtnList.add(rtnMap);
                }
            }
            return rtnList;
        } catch (DBException dbe) {
            log.error("�d�ߥ���", dbe);
            throw new ModuleException(dbe);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            throw dnfe;
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            throw new ModuleException(e);
        } finally {
            try {
                if (bqds != null) {
                    bqds.close();//�����妸�d�߳s�u
                }
            } catch (DBException e) {
            }

        }
    }

    /**
     * ��zú�O�ҩ������榡
     * @param checkList
     * @param RCV_YEAR
     * @return �����ΰѼ�
     * @throws ModuleException
     */
    public Map doFmtRpt(List<Map> checkList, BigDecimal RCV_YEAR, UserObject user) throws ModuleException {
        LocaleDisplay display = new LocaleDisplay("EP", user);

        //[20180326] �̤����q�O���o���q��T 
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user); // �����q�O
        Map COMP_INFO = FieldOptionList.getFieldOptions("EP", "COMP_INFO_" + SUB_CPY_ID);

        //�]�w�^�ǭ�
        Map rtnMap = new HashMap();
        Map param = new HashMap();
        param.put("REPORT_ID", "EP_C23120");
        param.put("PRINT_DATE", display.formatDate(DATE.today(), "/", ""));//�C�L���
        //[20180326]���q��T 
        param.put("COMP_NAME", MapUtils.getString(COMP_INFO, "COMP_NAME"));
        param.put("COMP_OWNER", MapUtils.getString(COMP_INFO, "COMP_OWNER"));
        param.put("COMP_ADDR", MapUtils.getString(COMP_INFO, "COMP_ADDR"));
        param.put("COMP_ID", MapUtils.getString(COMP_INFO, "COMP_ID"));

        rtnMap.put("params", param);
        rtnMap.put("detail", queryForRptDetail(checkList, RCV_YEAR, display, Transaction.getDataSet()));

        return rtnMap;
    }

    /**
     * �d�߳������Map
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param RCV_YEAR �����~��(�褸�~)
     * @return ú�O���Map
     * @throws ModuleException
     */
    public Map queryForRptParams(Map tempMap, Map addMap, BigDecimal RCV_YEAR) throws ModuleException {
        ErrorInputException eie = null;
        if (RCV_YEAR == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23120_ERRMSG_001"));//�п�J�����~��
        }
        if (eie != null) {
            throw eie;
        }

        /*DataSet ds = Transaction.getDataSet();
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("RCV_YEAR", RCV_YEAR);*/

        Map rtnMap = new HashMap();
        rtnMap.put("BLD_ADDR", replaceNull(addMap, MapUtils.getString(tempMap, "BLD_CD"), "")); //�a�}�Τ@�@�}�l�N�d�X��
        rtnMap.put("CUS_NAME", replaceNull(tempMap, "CUS_NAME", ""));
        rtnMap.put("BLD_NAME", replaceNull(tempMap, "BLD_NAME", ""));
        rtnMap.put("FLD_NO", replaceNull(tempMap, "FLD_NO", ""));
        rtnMap.put("ROOM_NO", replaceNull(tempMap, "ROOM_NO", ""));

        return rtnMap;
    }

    /**
     * �d�߳������List
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param RCV_YEAR �����~��(�褸�~)
     * @return ú�O���Map
     * @throws ModuleException
     */
    /*public Map queryForRptDetail(String CRT_NO, String CUS_NO, BigDecimal RCV_YEAR) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23120_ERRMSG_003")); //�����N�����i����
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23120_ERRMSG_004")); //�Ȥ�Ǹ����i����
        }
        if (RCV_YEAR == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C23120_ERRMSG_001"));//�п�J�����~��
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("RCV_YEAR", RCV_YEAR);
        List<Map> inv_no_list = VOTool.findToMaps(ds, SQL_queryForRptDetail_001);

        //�v���������h�ɪ��B
        Map detailMap = new HashMap();
        BigDecimal totalAmount = BigDecimal.ZERO;
        DecimalFormat df = new DecimalFormat("#,##0.##");
        Integer monthInt;

        for (Map tempMap : inv_no_list) {

            ds.clear();
            String INV_NO = MapUtils.getString(tempMap, "INV_NO");
            ds.setField("INV_NO", INV_NO);
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("CUS_NO", CUS_NO);

            Map C204Map = VOTool.findOneToMap(ds, SQL_queryForRptDetail_002);
            BigDecimal INV_AMT = getBigDecimal(tempMap.get("INV_AMT"));
            INV_AMT = INV_AMT.subtract(getBigDecimal(C204Map.get("RJT_AMT")));

            if (INV_AMT.compareTo(BigDecimal.ZERO) != 0) {//���Ȥ~��J�����M��

                monthInt = getInteger(tempMap.get("RCV_YM")) % 100;
                String CNMonth = DATE.getCNum(String.valueOf(monthInt)) + "��";
                detailMap.put(monArray[monthInt] + "INV_AMT", df.format(INV_AMT));
                detailMap.put(monArray[monthInt], CNMonth);
                detailMap.put(monArray[monthInt] + "INV_NO", INV_NO);
                totalAmount = totalAmount.add(INV_AMT);
            }
            detailMap.put("RNT_SIZE", df.format(getBigDecimal(tempMap.get("RNT_SIZE"))));
        }
        detailMap.put("INV_AMT", df.format(totalAmount));

        return detailMap;
    }*/

    /**
     * �C�Lú�O�ҩ�
     * @param reqMap
     * @param resp
     * @throws ModuleException 
     */
    public void prtRpt(Map reqMap, ResponseContext resp) throws ModuleException {
        //JasperReportUtils.addOutputRptDataToResp("EP_C23120", (Map) reqMap.get("params"), (List) reqMap.get("detail"), resp);

        String fileName = new StringBuilder().append("PAYMENTPROOF_").append(DATE.getROCDate()).append(".pdf").toString();

        String createFileFullPath = RptUtils.createTempFile(fileName).getAbsolutePath();
        try {
            new RptUtils().createPDFFile((Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), createFileFullPath);
        } catch (Exception e) {
            throw new ModuleException("���ͦ���PDF����:" + e.getMessage());
        }
        try {
            RptUtils.cryptoDownloadParameterToResp(fileName, createFileFullPath, resp);
        } catch (Exception e) {
            throw new ModuleException("�^�ǥ[�K��������|�o�Ϳ��~:" + e.getMessage());
        }
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �d�߸�ƫ��A�� 'key'
     * @param ds
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * �d�߸�Ƥ覡 like'%key%'
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setLikeFieldsIfExsits(DataSet ds, String key, String value, StringBuilder sb) {
        if (StringUtils.isNotBlank(value)) {
            sb.append('%').append(value).append('%');
            ds.setField(key, sb.toString());
            sb.setLength(0);
        }
    }

    /**
     * �ഫ����Ƭ�Bigdecimal
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }

        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }

        return BigDecimal.ZERO;
    }

    /**
     * �ഫ����Ƭ�Integer
     * @param obj
     * @return
     */
    private Integer getInteger(Object obj) throws ModuleException {
        if (obj == null) {
            //�����~�묰�ũθ�Ʀ��~
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23120_ERRMSG_005"));
        }
        if (obj instanceof Integer) {
            return (Integer) obj;
        }

        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new Integer(str);
        }

        //�����~�묰�ũθ�Ʀ��~
        throw new ErrorInputException(MessageUtil.getMessage("EP_C23120_ERRMSG_005"));
    }

    private String replaceNull(Map map, String key, String defaultValue) {
        if (map.get(key) == null) {
            return defaultValue;
        }
        return MapUtils.getString(map, key, defaultValue);
    }

    /**
     * format ����detail
     * @param checkList
     * @param RCV_YEAR
     * @param locale
     * @param ds
     * @return
     * @throws ModuleException
     */
    public List queryForRptDetail(List<Map> checkList, BigDecimal RCV_YEAR, LocaleDisplay locale, DataSet ds) throws ModuleException {
        log.debug("%%%%% format detail start %%%%% : " + System.currentTimeMillis());
        List<Map> rtnList = new ArrayList<Map>();//�̲׭n�L��details

        DecimalFormat df = new DecimalFormat("#,##0.##");
        Integer monthInt;
        boolean isAll = (checkList == null || checkList.isEmpty());

        /* 160308 : modified for ��ְj�餤�d�ߦ���
        BigDecimal totalAmount;
        Map dataPoolMap = new HashMap();
        for (Map checkMap : checkList) {

             String CRT_NO = MapUtils.getString(checkMap, "CRT_NO");
             String CUS_NO = MapUtils.getString(checkMap, "CUS_NO");
             if (StringUtils.isBlank(CRT_NO) || StringUtils.isBlank(CUS_NO)) {
                 //�����s��, �Ȥ�Ǹ����Ҧ���, �нT�{��A�C�L
                 throw new ErrorInputException(MessageUtil.getMessage("EP_C23120_ERRMSG_006"));
             }

             if (dataPoolMap.get(CRT_NO + CUS_NO) == null) {
                 dataPoolMap.put(CRT_NO + CUS_NO, "");
             } else {
                 continue;
             }*/

        log.debug("#### isAll::" + isAll);

        List<Map> inv_no_list;
        Map addMap = new HashMap();
        if (isAll) {//����

            ds.clear();
            ds.setField("RCV_YEAR", RCV_YEAR);
            inv_no_list = VOTool.findToMaps(ds, SQL_queryForRptDetail_001);

            //�����o�j�Ӧa�}
            addMap = this.getAddressMap(RCV_YEAR, null, ds);

        } else {//�����
            inv_no_list = new ArrayList<Map>();
            List<String> crt_no_list = new ArrayList<String>();
            Map dataPoolMap = new HashMap();
            for (Map checkMap : checkList) {
                String CRT_NO = MapUtils.getString(checkMap, "CRT_NO");
                String CUS_NO = MapUtils.getString(checkMap, "CUS_NO");
                if (StringUtils.isBlank(CRT_NO) || StringUtils.isBlank(CUS_NO)) {
                    //�����s��, �Ȥ�Ǹ����Ҧ���, �нT�{��A�C�L
                    throw new ErrorInputException(MessageUtil.getMessage("EP_C23120_ERRMSG_006"));
                }

                if (dataPoolMap.get(CRT_NO + CUS_NO) == null) {
                    dataPoolMap.put(CRT_NO + CUS_NO, "");
                } else {
                    continue;
                }

                ds.clear();
                ds.setField("CRT_NO", CRT_NO);
                ds.setField("CUS_NO", checkMap.get("CUS_NO"));
                ds.setField("RCV_YEAR", RCV_YEAR);
                inv_no_list.addAll(VOTool.findToMaps(ds, SQL_queryForRptDetail_001));
                crt_no_list.add(CRT_NO);
            }

            //�����o�j�Ӧa�}
            addMap = this.getAddressMap(RCV_YEAR, crt_no_list, ds);
        }

        //ú�����B�X�p
        BigDecimal totalAmount = BigDecimal.ZERO;
        boolean first = true;
        String tmpCRT_CUS_NO = "";
        for (Map<String, Object> tempMap : inv_no_list) {

            //���s:by crt_no,cus_no
            String INV_NO = MapUtils.getString(tempMap, "INV_NO");
            String tempCRT_NO = MapUtils.getString(tempMap, "CRT_NO");
            String tempCUS_NO = MapUtils.getString(tempMap, "CUS_NO");
            String tempStr = tempCRT_NO + tempCUS_NO;
            if (first || StringUtils.isBlank(tmpCRT_CUS_NO) || (!tmpCRT_CUS_NO.equals(tempStr))) {//���P�s
                if (!first && StringUtils.isNotBlank(tmpCRT_CUS_NO)) {
                    //group footer fields ���s �ݽs��W�s��footer : RCV_YEAR , �X�p
                    Map temp = rtnList.get(rtnList.size() - 1);
                    temp.put("TOT_INV_AMT", df.format(totalAmount));
                    temp.put("RCV_YEAR", locale.formatDatey(RCV_YEAR.toPlainString(), ""));
                    totalAmount = BigDecimal.ZERO;//�k�s
                }
                tmpCRT_CUS_NO = tempStr;
                first = true;
            } else {
                first = false;
            }

            /* ��X���B:�X�֦b�d�ߵo�����B���ySQL(SQL_queryForRptDetail_001)
            ds.clear();
            ds.setField("INV_NO", INV_NO);
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("CUS_NO", CUS_NO);
            Map C204Map = VOTool.findOneToMap(ds, SQL_queryForRptDetail_002);*/
            BigDecimal INV_AMT = getBigDecimal(tempMap.get("INV_AMT"));
            INV_AMT = INV_AMT.subtract(STRING.objToBigDecimal(tempMap.get("RJT_AMT"), BigDecimal.ZERO));

            if (INV_AMT.compareTo(BigDecimal.ZERO) != 0) {//�o�����B������X���B��,���Ȥ~��J�����M��
                Map rtnMap = new HashMap();
                monthInt = getInteger(tempMap.get("RCV_YM")) % 100;
                rtnMap.put("CRT_NO", tempCRT_NO);
                rtnMap.put("CUS_NO", tempCUS_NO);
                rtnMap.put("MONTH", String.valueOf(monthInt));
                rtnMap.put("MONTH_NM", DATE.getCNum(String.valueOf(monthInt)) + "��");
                rtnMap.put("INV_AMT", df.format(INV_AMT));
                rtnMap.put("INV_NO", INV_NO);
                totalAmount = totalAmount.add(INV_AMT);

                //group header fields : �ӫ����Ȥ�Ĥ@����,�d�ߩӯ�����
                if (first) {
                    Map paramMap = queryForRptParams(tempMap, addMap, RCV_YEAR);
                    paramMap.put("RNT_SIZE", df.format(getBigDecimal(tempMap.get("RNT_SIZE"))));
                    rtnMap.putAll(paramMap);
                    first = false;
                }
                rtnList.add(rtnMap);
            }
        }

        //group footer fields ���s �ݽs��W�s��footer : RCV_YEAR , �X�p
        Map temp = rtnList.get(rtnList.size() - 1);
        temp.put("TOT_INV_AMT", df.format(totalAmount));
        temp.put("RCV_YEAR", locale.formatDatey(RCV_YEAR.toPlainString(), ""));

        // }

        log.debug("%%%%% format detail end %%%%% : " + System.currentTimeMillis());
        return rtnList;
    }

    private Map<String, String> getAddressMap(BigDecimal RCV_YEAR, List<String> crt_no_list, DataSet ds) throws ModuleException {
        Map<String, String> addMap = new HashMap<String, String>();
        ds.clear();
        if (crt_no_list != null && !crt_no_list.isEmpty()) {
            ds.setFieldValues("CRT_NOs", crt_no_list);
        }
        ds.setField("RCV_YEAR", RCV_YEAR);
        DBUtil.searchAndRetrieve(ds, SQL_queryForRptDetail_002);
        while (ds.next()) {
            addMap.put(STRING.objToStr(ds.getField("BLD_CD"), ""), STRING.objToStr(ds.getField("BLD_ADDR"), ""));
        }
        return addMap;
    }
}
