package com.cathay.ep.c2.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.common.util.validate.ValidateUtil;
import com.cathay.dd.e0.module.DD_E0Z001;
import com.cathay.dd.e0.module.DD_E0Z008;
import com.cathay.ep.b2.module.EP_B20020;
import com.cathay.ep.c0.module.EP_C0Z001;
import com.cathay.ep.vo.DTEPZ002;
import com.cathay.ep.z0.module.EP_Z0C101;
import com.cathay.ep.z0.module.EP_Z0C201;
import com.cathay.ep.z0.module.EP_Z0C202;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.ep.z1.module.EP_Z1Z002;
import com.cathay.rpt.XlsUtils;
import com.cathay.rpt.XlsUtils.SORT_RULE;
import com.cathay.rpt.datasource.xls.ColumnOptions;
import com.cathay.rpt.datasource.xls.ColumnSetting;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.cathay.util.TransactionHelper;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date         Version  Description  Author
 * 2017/10/26   1.0      �s�W         ����[
 * 2018/01/29   1.1      �վ�o���~�W�榡         ����[
 * 2018/02/22   1.2      �|�p�Ю֧����^�����D�B�z         ����[
 * 2019/01/16   1.3      ���D��s�� 20190116-0013    ����[
 * 2020/01/12            �NgetPIN_NAME����EP_C0Z001
 * 
 *  �{���\��  ��عq�l�o���|�p�Юֺ��@�Ҳ�
 *  �{���W��    EP_C21040
 *  ���n����    1.  �o������(�VDD�|�Ȩt�Ψ���),���͵o����DTEPC202
 *              2.  �̾ڵo������(�����B�㯲��)��s�o�����X(DTEPC101�BDTEPC102)
 *              3.  Call DK�Ҳնi��ǲ��Ю�           
 *  ##�C��ߤW��s�o���ɦ�DD�|�Ȩt��
 *  </pre>
 * @author �d����
 * @since 2017/11/13
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C21040 {

    private static final Logger log = Logger.getLogger(EP_C21040.class);

    private boolean isDebug = log.isDebugEnabled();

    /** �X�p��� */
    private String[] fieldsForGroupTotal = { "INV_AMT", "SAL_AMT", "TAX_AMT" };

    private static final String SQL_query_001 = "com.cathay.ep.c2.module.EP_C21040.SQL_query_001";

    private static final String SQL_updateInvForDD_001 = "com.cathay.ep.c2.module.EP_C21040.SQL_updateInvForDD_001";

    private static final String SQL_updateInvForDD_002 = "com.cathay.ep.c2.module.EP_C21040.SQL_updateInvForDD_002";

    private static final String SQL_updateInvForDD_003 = "com.cathay.ep.c2.module.EP_C21040.SQL_updateInvForDD_003";

    private static final String SQL_updateInvForDD_004 = "com.cathay.ep.c2.module.EP_C21040.SQL_updateInvForDD_004";

    private static final String SQL_updateInvForDD_005 = "com.cathay.ep.c2.module.EP_C21040.SQL_updateInvForDD_005";

    private static final String SQL_getFLD_ROOM_PRK_001 = "com.cathay.ep.c2.module.EP_C21040.SQL_getFLD_ROOM_PRK_001";

    private static final String SQL_query_002 = "com.cathay.ep.c2.module.EP_C21040.SQL_query_002";

    private static final String SQL_confirm_001 = "com.cathay.ep.c2.module.EP_C21040.SQL_confirm_001";

    private static final String SQL_confirm_002 = "com.cathay.ep.c2.module.EP_C21040.SQL_confirm_002";

	private static final String SQL_updateInvForDD_006 = "com.cathay.ep.c2.module.EP_C21040.SQL_updateInvForDD_006";

    /**
     * query �d�߫ݼf�o��
     * @param reqMap �d�߱���
     * @return rtnList �o�����XList
     * @throws ModuleException 
     */
    public List<Map> query(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C21040_MSG_001"));// �ǤJ�d�߱��󬰪�

        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_002")); // �ǤJ�����q�O���o����
        }

        String ACNT_DATE_S = MapUtils.getString(reqMap, "ACNT_DATE_S");
        if (StringUtils.isBlank(ACNT_DATE_S)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_003")); // �ǤJ�_�l�餣�o����
        } else if (!DATE.isDate(ACNT_DATE_S)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_016"));// �ǤJ�_�l��榡���~
        }

        String ACNT_DATE_E = MapUtils.getString(reqMap, "ACNT_DATE_E");
        if (StringUtils.isBlank(ACNT_DATE_E)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_004"));// �ǤJ�����餣�o����
        } else if (!DATE.isDate(ACNT_DATE_E)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_017"));//  �ǤJ������榡���~
        }

        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        StringBuilder sb = new StringBuilder();
        List<Map> rtnList = new ArrayList<Map>();

        String KIND = MapUtils.getString(reqMap, "KIND");
        boolean isAll = StringUtils.isBlank(KIND);

        String STATUS = MapUtils.getString(reqMap, "OP_STATUS");
        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
        String DIV_NO = MapUtils.getString(reqMap, "DIV_NO");

        if (StringUtils.isNotBlank(KIND)) {
            String s_SLIP_LOT_NO = FieldOptionList.getName("EP", "C21040_SLIP_LOT_NO", KIND);
            String[] SLIP_LOT_NOs = s_SLIP_LOT_NO.split(",");
            ds.setFieldValues("SLIP_LOT_NOs", SLIP_LOT_NOs);
        }

        if (isAll || "1".equals(KIND) || "2".equals(KIND)) {//����/�޲z�O
            this.setDataSet(ds, STATUS, SLIP_SET_NO, DIV_NO, SUB_CPY_ID, ACNT_DATE_S, ACNT_DATE_E);
            List<Map> c101List = VOTool.findToMaps(ds, SQL_query_001, false);

            if (c101List != null && !c101List.isEmpty()) {
                rtnList.addAll(c101List);
            }
        }

        if (isAll || "3".equals(KIND)) {//�㯲��

            //�d�㯲������
            this.setDataSet(ds, STATUS, SLIP_SET_NO, DIV_NO, SUB_CPY_ID, ACNT_DATE_S, ACNT_DATE_E);
            List<Map> c201List = VOTool.findToMaps(ds, SQL_query_002, false);

            if (c201List != null && !c201List.isEmpty()) {

                rtnList.addAll(c201List);
            }
        }

        if (rtnList == null || rtnList.isEmpty()) {
            throw new DataNotFoundException("�d�L���");
        }

        for (Map rtnMap : rtnList) {
            // �b�ȸ�T
            sb.setLength(0);
            sb.append(DATE.formatToROCDate(MapUtils.getString(rtnMap, "ACNT_DATE"))).append('-').append(rtnMap.get("SLIP_LOT_NO")).append('-').append(rtnMap.get("SLIP_SET_NO"));
            rtnMap.put("ACNT_INFO", sb.toString());
        }

        Collections.sort(rtnList, new sortRule());

        return rtnList;
    }

    /**
     * �̶ǲ���T�d������/�㯲������
     * @param reqMap
     * @param selectList
     * @return
     * @throws ModuleException
     */
    public List<Map> queryDetail(Map reqMap, List<Map> selectList) throws ModuleException {

        List<Object[]> C201_ACNT_DATE = new ArrayList<Object[]>();
        List<Object[]> C201_ACNT_DIV_NO = new ArrayList<Object[]>();
        List<Object[]> C201_SLIP_LOT_NO = new ArrayList<Object[]>();
        List<Object[]> C201_SLIP_SET_NO = new ArrayList<Object[]>();
        List<Object[]> C101_ACNT_DATE = new ArrayList<Object[]>();
        List<Object[]> C101_ACNT_DIV_NO = new ArrayList<Object[]>();
        List<Object[]> C101_SLIP_LOT_NO = new ArrayList<Object[]>();
        List<Object[]> C101_SLIP_SET_NO = new ArrayList<Object[]>();
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String STATUS = MapUtils.getString(reqMap, "OP_STATUS");
        for (Map selectMap : selectList) {
            String SOURCE = MapUtils.getString(selectMap, "SOURCE");
            if ("C201".equals(SOURCE)) {//�d�ߩ㯲��
                C201_ACNT_DATE.add(new String[] { MapUtils.getString(selectMap, "ACNT_DATE") });
                C201_ACNT_DIV_NO.add(new String[] { MapUtils.getString(selectMap, "ACNT_DIV_NO") });
                C201_SLIP_LOT_NO.add(new String[] { MapUtils.getString(selectMap, "SLIP_LOT_NO") });
                C201_SLIP_SET_NO.add(new String[] { MapUtils.getString(selectMap, "SLIP_SET_NO") });
            } else {//�d������
                C101_ACNT_DATE.add(new String[] { MapUtils.getString(selectMap, "ACNT_DATE") });
                C101_ACNT_DIV_NO.add(new String[] { MapUtils.getString(selectMap, "ACNT_DIV_NO") });
                C101_SLIP_LOT_NO.add(new String[] { MapUtils.getString(selectMap, "SLIP_LOT_NO") });
                C101_SLIP_SET_NO.add(new String[] { MapUtils.getString(selectMap, "SLIP_SET_NO") });
            }
        }

        List<Map> rtnList = new ArrayList<Map>();
        StringBuilder sb = new StringBuilder();
        //150202:�ϥΰʺAsql,�L�k��bqds
        DataSet ds = Transaction.getDataSet();
        if (!C201_ACNT_DATE.isEmpty()) {//�㯲��
            //���d�����Ӽh/�ǧO/����
            this.setDataSet(ds, SUB_CPY_ID, C201_ACNT_DATE, C201_ACNT_DIV_NO, C201_SLIP_LOT_NO, C201_SLIP_SET_NO);
            Map FLD_ROOM_PRK = this.getFLD_ROOM_PRK(ds);

            this.setDataSet(ds, SUB_CPY_ID, C201_ACNT_DATE, C201_ACNT_DIV_NO, C201_SLIP_LOT_NO, C201_SLIP_SET_NO);
            if (StringUtils.isNotBlank(STATUS)) {
                if ("0".equals(STATUS)) {
                    ds.setField("OP_STATUS", "1");
                } else {
                    ds.setField("OP_STATUS", "2");
                }
            }
            List<Map> c201List = VOTool.findToMaps(ds, SQL_confirm_001, false);

            if (c201List != null && !c201List.isEmpty()) {
                if (FLD_ROOM_PRK != null && !FLD_ROOM_PRK.isEmpty()) {
                    //set�Ӽh/�ǧO/����
                    for (Map c201Map : c201List) {
                        Map tmpFLD_ROOM_PRK = (Map) FLD_ROOM_PRK.get(sb.append(MapUtils.getString(c201Map, "CRT_NO")).append("-").append(MapUtils.getString(c201Map, "CUS_NO")).toString());
                        sb.setLength(0);
                        c201Map.put("PRK_NO", tmpFLD_ROOM_PRK.get("PRK_NO"));
                        c201Map.put("FLD_NO", tmpFLD_ROOM_PRK.get("FLD_NO"));
                        c201Map.put("ROOM_NO", tmpFLD_ROOM_PRK.get("ROOM_NO"));
                    }
                }
                rtnList.addAll(c201List);
            }

        }

        if (!C101_ACNT_DATE.isEmpty()) {//����
            this.setDataSet(ds, SUB_CPY_ID, C101_ACNT_DATE, C101_ACNT_DIV_NO, C101_SLIP_LOT_NO, C101_SLIP_SET_NO);
            if (StringUtils.isNotBlank(STATUS)) {
                if ("0".equals(STATUS)) {
                    ds.setField("OP_STATUS", "30");
                } else {
                    ds.setField("OP_STATUS", "35");
                }
            }
            List<Map> c101List = VOTool.findToMaps(ds, SQL_confirm_002, false);
            if (c101List != null && !c101List.isEmpty()) {
                rtnList.addAll(c101List);
            }
        }

        if (rtnList == null || rtnList.isEmpty()) {
            throw new DataNotFoundException("�d�L���Ӹ��");
        }

        EP_B20020 theEP_B20020 = new EP_B20020();
        EP_C0Z001 theEP_C0Z001 = new EP_C0Z001();
        StringBuilder invErrMsg = new StringBuilder();
        for (Map rtnMap : rtnList) {

            String SOURCE = MapUtils.getString(rtnMap, "SOURCE");
            String OP_STATUS = MapUtils.getString(rtnMap, "OP_STATUS");
            String PAY_KIND = MapUtils.getString(rtnMap, "PAY_KIND");
            String OP_STATUS_NM;

            String kind;
            if ("C201".equals(SOURCE)) {
                // ���A
                OP_STATUS_NM = FieldOptionList.getName("EP", "OP_STATUS_C201", OP_STATUS);

                // �ӷ����� �㯲��  
                kind = "3";
            } else {
                // ���A
                OP_STATUS_NM = FieldOptionList.getName("EPC", "OP_STATUS_C101", OP_STATUS);

                // �ӷ����� �޲z�O
                if ("3".equals(PAY_KIND)) {
                    kind = "2";
                } else {
                    kind = "1";
                }
            }
            rtnMap.put("OP_STATUS_NM", OP_STATUS_NM);
            rtnMap.put("KIND_NM", FieldOptionList.getName("EP", "C21040_KIND", kind));

            //ñ�b�d�d��
            if ("1".equals(MapUtils.getString(rtnMap, "DCT_TYPE", ""))) {
                Map B202Map = new HashMap();
                B202Map.put("ID", MapUtils.getString(rtnMap, "ID", ""));
                B202Map.put("SUB_CPY_ID", SUB_CPY_ID);
                Map CARD_MAP = theEP_B20020.queryMap(B202Map);
                rtnMap.put("CARD_NO", MapUtils.getString(CARD_MAP, "CARD_NO", ""));
            }

            //�~�W
            theEP_C0Z001.getPIN_NAME(rtnMap, sb);

            //[20200327] �q�l�o��������T(email/���㸹�X)
            //���K�ˮ�email�θ��㸹�X�O�_���šA�קK�妸���楢��
            String TRANS_TYPE = MapUtils.getString(rtnMap, "TRANS_TYPE");
            if ("B".equals(TRANS_TYPE)) {//email
                String CUS_EMAIL = MapUtils.getString(rtnMap, "CUS_EMAIL");
                if (StringUtils.isBlank(CUS_EMAIL)) {
                    //�����N��:{0}-{1},�Ȥ���-EMAIL����
                    invErrMsg = invErrMsg.append(MessageUtil.getMessage("EP_C21040_MSG_018", new String[] { MapUtils.getString(rtnMap, "CRT_NO"), MapUtils.getString(rtnMap, "CUS_NO") })).append(STRING.lineSeparator);
                }
                rtnMap.put("DEVICE_NO", CUS_EMAIL);//email
            } else if ("C".equals(TRANS_TYPE)) {//����
                //�����N��:{0}-{1},�Ȥ���-����s������
                String INV_DEVICE_TYPE = MapUtils.getString(rtnMap, "INV_DEVICE_TYPE");
                String INV_DEVICE_NO = MapUtils.getString(rtnMap, "INV_DEVICE_NO");
                if (StringUtils.isBlank(INV_DEVICE_TYPE) || StringUtils.isBlank(INV_DEVICE_NO)) {
                    invErrMsg = invErrMsg.append(MessageUtil.getMessage("EP_C21040_MSG_019", new String[] { MapUtils.getString(rtnMap, "CRT_NO"), MapUtils.getString(rtnMap, "CUS_NO") })).append(STRING.lineSeparator);
                }
                sb.setLength(0);
                rtnMap.put("DEVICE_NO", sb.append(INV_DEVICE_TYPE).append(":").append(INV_DEVICE_NO).toString());//�o���ӤH��������:�o���ӤH���㸹�X
            } else if ("D".equals(TRANS_TYPE)) {//����
                String INV_DEVICE_NO = MapUtils.getString(rtnMap, "INV_DEVICE_NO");
                rtnMap.put("DEVICE_NO", INV_DEVICE_NO);
            }
                
        }
        if (invErrMsg.length() > 0) {
            throw new ModuleException(invErrMsg.toString());
        }

        //�Ƨ�
        Collections.sort(rtnList, new sortRule());

        if (isDebug) {
            log.debug("############ rtnList:::: " + rtnList);
        }

        return rtnList;
    }

    /**
     * �]�w�d�߱���
     * @param ds
     * @param SUB_CPY_ID
     * @param ACNT_DATE
     * @param ACNT_DIV_NO
     * @param SLIP_LOT_NO
     * @param SLIP_SET_NO
     */
    private void setDataSet(DataSet ds, String SUB_CPY_ID, List<Object[]> ACNT_DATE, List<Object[]> ACNT_DIV_NO, List<Object[]> SLIP_LOT_NO, List<Object[]> SLIP_SET_NO) {
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldStmt("ACNT_DATE", ACNT_DATE);
        ds.setFieldStmt("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setFieldStmt("SLIP_LOT_NO", SLIP_LOT_NO);
        ds.setFieldStmt("SLIP_SET_NO", SLIP_SET_NO);
    }

    /**
     * confirm �}�߽T�{(�o������)
     * @param reqMap �d�߱���
     * @param selectList ����M��
     * @param user 
     * @throws Exception 
     */
    public void confirm(Map reqMap, List<Map> selectList, List<Map> SLIP_INFO, UserObject user) throws Exception {

        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_005"));// �ǤJ�d�߱��󤣱o����
        }

        if (selectList == null || selectList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_006"));// �ǤJ����M�椣�o����
        }

        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_007"));// �ǤJuser���o����
        }

        if (eie != null) {
            throw eie;
        }

        //�d�ߩ���
        List<Map> detailList = this.queryDetail(reqMap, selectList);

        // �Ȧs�����Ю֤��ǲ��帹,�ո�(�ǲ��Ю֥�)
        List<Map> InvList = new ArrayList<Map>();
        List<Map> RCV_LIST = new ArrayList<Map>(); //�^�������ɲM��
        List<Map> INT_LIST = new ArrayList<Map>(); //�^���㯲���ɲM��
        Map INVMap = new HashMap();

        // �ǲ��Ю�
        Map ACNT_MAP = new HashMap();
        ACNT_MAP.put("CASE_TYPE", "A");
        ACNT_MAP.put("USE_TYPE", "EP1");
        ACNT_MAP.put("OPID", user.getUserID());
        ACNT_MAP.put("OPNAME", user.getEmpName());
        ACNT_MAP.put("OPUNIT", user.getDivNo());
        List<Map> rtnACNT_LIST = new DD_E0Z008().cfmEP_ACNT(ACNT_MAP, SLIP_INFO);
        Map DK_ACNT_MAP = new HashMap();
        StringBuilder sb = new StringBuilder();
        for (Map tmpACNT_MAP : rtnACNT_LIST) {
            sb.setLength(0);
            sb.append(DATE.formatToROCDate(MapUtils.getString(tmpACNT_MAP, "ACNT_DATE"))).append('-').append(tmpACNT_MAP.get("SLIP_LOT_NO")).append('-').append(tmpACNT_MAP.get("SLIP_SET_NO"));
            DK_ACNT_MAP.put(sb.toString(), tmpACNT_MAP.get("CE_SLPSEQ_NO"));
        }

        // format C202
        BigDecimal SER_NO = BigDecimal.ZERO;
        for (Map selectMap : detailList) {
            Boolean isMakInv = true;
            String PAY_KIND = MapUtils.getString(selectMap, "PAY_KIND");

            if ("3".equals(PAY_KIND)) { //ú�ں���=3�޲z�O
                //�Y���޲z�O->�ˮָӴɤj�ӬO�_�ݶ}�o��
                isMakInv = this.checkMakeInv(selectMap);
            }
            /*if (isDebug) {
                log.debug("@@@isMakInv=" + isMakInv);
            }*/

            BigDecimal INV_AMT = STRING.objToBigDecimal(selectMap.get("INV_AMT"), BigDecimal.ZERO);
            if (isMakInv && (INV_AMT.compareTo(BigDecimal.ZERO) != 0)) { // 150430 modify :(�K��)�������B=0 ���ݶ}�o�� 
                //�յo����
                Map C202 = this.formatDTEPC202(selectMap, SER_NO, DK_ACNT_MAP, user, sb);

                String ACNT_INFO = MapUtils.getString(selectMap, "ACNT_INFO");
                List<Map> INVList;
                if (!INVMap.containsKey(ACNT_INFO)) {
                    INVList = new ArrayList<Map>();
                } else {
                    INVList = (List<Map>) INVMap.get(ACNT_INFO);
                }
                INVList.add(C202);
                INVMap.put(ACNT_INFO, INVList);
            } else {
                //�L�}�o��:�ǳƧ�s����/�㯲�����A�M��
                if ("2".equals(PAY_KIND)) {
                    selectMap.put("INT_NO", selectMap.get("PRE_KEY"));
                    INT_LIST.add(selectMap);
                } else {
                    selectMap.put("RCV_NO", selectMap.get("PRE_KEY"));
                    RCV_LIST.add(selectMap);
                }
            }

            SER_NO = SER_NO.add(BigDecimal.ONE);
        }

        // �H���X
        int[] RandomNoList = new EP_Z0Z001().createNextNumberforBatch("00", "044", DATE.getTodayYearAndMonth(), DATE.getTodayYearAndMonth(), detailList.size());

        // ����
        Map invNoMap = new HashMap();
        DD_E0Z001 theDD_E0Z001 = new DD_E0Z001();
        Map tmpMap = new HashMap();
        for (Object key : INVMap.keySet()) {
            InvList = (List<Map>) INVMap.get(key);
            Map tmpInvMap = InvList.get(0);
            tmpMap.put("INV_YM", tmpInvMap.get("RCV_YM"));
            tmpMap.put("USE_YM", tmpInvMap.get("RCV_YM"));
            tmpMap.put("USE_TYPE", "EP1");
            tmpMap.put("GET_CNT", InvList.size());
            tmpMap.put("INV_DATE", tmpInvMap.get("INV_DATE"));
            List<Map> invNoList = theDD_E0Z001.getINV_NO(tmpMap);
            invNoMap.put(key, invNoList);
        }

        //call EP_Z0C202 insert DTEPC202
        Map rtnMap = new EP_Z0C202().insertDTEPC202(INVMap, invNoMap, RandomNoList);

        //�^���o�����X�Χ�s����
        RCV_LIST.addAll((List<Map>) rtnMap.get("RCV_LIST"));
        INT_LIST.addAll((List<Map>) rtnMap.get("INT_LIST"));

        if (RCV_LIST != null && !RCV_LIST.isEmpty()) {
            new EP_Z0C101().updateInvNo(RCV_LIST, user); //����
        }
        if (INT_LIST != null && !INT_LIST.isEmpty()) {
            new EP_Z0C201().updateInvNo(INT_LIST, user); //�㯲��
        }

    }

    /**
     * �i��عq�l�o���j
     * formatDTEPC202
     * @param selectMap �d�߱���
     * @param SER_NO �Ǹ�
     * @return C202 
     * @throws ErrorInputException 
     */
    public Map formatDTEPC202(Map selectMap, BigDecimal SER_NO, Map DK_ACNT_MAP, UserObject user, StringBuilder sb) throws ErrorInputException {

        ErrorInputException eie = null;

        if (selectMap == null || selectMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_005"));// �ǤJ�d�߱��󤣱o����
        }

        if (SER_NO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_008"));// �ǤJ�Ǹ����o����
        }

        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_007"));// �ǤJuser���o����
        }

        if (eie != null) {
            throw eie;
        }

        String FLD_NO = MapUtils.getString(selectMap, "FLD_NO");
        if (StringUtils.isBlank(FLD_NO)) {
            selectMap.put("FLD_NO", "");
        }
        String ROOM_NO = MapUtils.getString(selectMap, "ROOM_NO");
        if (StringUtils.isBlank(ROOM_NO)) {
            selectMap.put("ROOM_NO", "");
        }

        String PRK_NO = MapUtils.getString(selectMap, "PRK_NO");
        if (StringUtils.isBlank(PRK_NO)) {
            selectMap.put("PRK_NO", "");
        }

        Map C202 = new HashMap(selectMap);
        C202.put("INV_CD", "0");
        C202.put("INV_DATE", selectMap.get("ACNT_DATE"));
        C202.put("SER_NO", SER_NO.add(BigDecimal.ONE));
        C202.put("CHK_NO", "");
        C202.put("TRN_KIND", "EPC201");
        C202.put("CHG_DATE", DATE.currentTime());
        //180131:���s:�o���ӽФH�������ʲ��H��,��������X�b�H��
        C202.put("CHG_DIV_NO", selectMap.get("ACNT_DIV_NO"));
        C202.put("CHG_ID", selectMap.get("ACNT_ID"));
        C202.put("CHG_NAME", selectMap.get("ACNT_NAME"));

        //�ǲ���T
        sb.setLength(0);
        String ACNTO_INFO = sb.append(DATE.formatToROCDate(MapUtils.getString(selectMap, "ACNT_DATE"))).append('-').append(selectMap.get("SLIP_LOT_NO")).append('-').append(selectMap.get("SLIP_SET_NO")).toString();
        C202.put("SLIP_DATE", selectMap.get("ACNT_DATE"));
        C202.put("SLIP_SEQ_NO", DK_ACNT_MAP.get(ACNTO_INFO));
        C202.put("SLIP_DIV_NO", selectMap.get("ACNT_DIV_NO"));

        //�P�_�o���Ȥ�����G���q�渹(���νs)>B2B,�ӤH�Ψ�L>B2C
        //20190116 ���D��s�� 20190116-0013 �վ�Ȥ�����P�_:
        /* �ҥ����:
         * 1 �νs => B2B
         * 2 ID => B2C
         * 3 �@�Ӹ��X => B2C
         * 4 �䥦 �� �L�Ȥ��� => B2B/B2C(�P�_ID�O�_���νs)
         */
        String ID = MapUtils.getString(selectMap, "ID", "").trim();//��ID�᭱���ťժ����p
        String ID_TYPE = MapUtils.getString(selectMap, "ID_TYPE");
        if (StringUtils.isNotBlank(ID_TYPE) && "1".equals(ID_TYPE)) {//1 �νs > ���q�渹
            C202.put("INV_TYPE", "A");
        } else if (StringUtils.isNotBlank(ID_TYPE) && ("2".equals(ID_TYPE) || "3".equals(ID_TYPE))) {//2 ID �� 3 �@�� > �ӤH
            C202.put("INV_TYPE", "B");
        } else {//��������Ȥ���(DTEPB201) ��  4 �䥦 > �P�_ID�O�_���νs
            if (StringUtils.isNotBlank(ID) && (ValidateUtil.checkCOID(ID) || ("N".equals(FieldOptionList.getName("EP", "ELE_INV", "C101_PASS_VAILD")) && "99999999".equals(ID)))) {//�P�_�O�_�����q�渹
                C202.put("INV_TYPE", "A");
            } else {
                C202.put("INV_TYPE", "B");
            }
        }
        C202.put("ID", ID);

        //�o�����I�覡:�w�]�ȥ�
        C202.put("TRANS_TYPE", MapUtils.getString(selectMap, "TRANS_TYPE", "A"));

        //�P�_�~�W�N��
        String SOURCE = MapUtils.getString(selectMap, "SOURCE");
        if ("C101".equals(SOURCE)) {
            if ("3".equals(MapUtils.getString(C202, "PAY_KIND"))) {//�޲z�O
                C202.put("PIN_CODE", "A3");
            } else {//����
                C202.put("PIN_CODE", "A1");
            }
            C202.put("RCV_NO", C202.get("PRE_KEY"));
        } else {//���
            C202.put("PIN_CODE", "A2");
            C202.put("INT_NO", C202.get("PRE_KEY"));
        }

        return C202;
    }

    /**
     * updateInvForDD �o���@�o/�P�h�^�����ʲ�
     * @param CASE_TYPE �ץ�����
     * @param InvList �@�o/�P�h�M�� 
     * @param SUB_CPY_ID �����q�O
     * @throws ErrorInputException, ModuleException 
     * @throws ModuleException 
     * @throws DBException 
     */
    public void updateInvForDD(String CASE_TYPE, List<Map> InvList, final String SUB_CPY_ID) throws ErrorInputException, ModuleException, DBException {

        ErrorInputException eie = null;

        if (InvList == null || InvList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C21040_MSG_009"));// �ǤJ�@�o/�P�h�M�椣�o����
        }

        if (StringUtils.isBlank(CASE_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_010"));// �ǤJ�ץ��������o����
        }

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21040_MSG_002"));// �ǤJ�����q�O���o����
        }

        if (eie != null) {
            throw eie;
        }

        List<String> EP_KEYList = new ArrayList<String>();
        List<Map> C204List_field = new ArrayList<Map>();
        for (Map InvList_Map : InvList) {
            String EP_KEY = MapUtils.getString(InvList_Map, "EPKEY");

            //2018.02.22:�@�o�������n�^��������A
            if (EP_KEY.contains("-")) {
                Map temp = new HashMap();
                String[] key = EP_KEY.split("-");
                temp.put("INV_NO", key[0]);
                temp.put("SER_NO", key[1]);
                C204List_field.add(temp);
                EP_KEYList.add(key[0]);
            } else {
                EP_KEYList.add(EP_KEY);
            }
        }

        //2018.02.22:�@�o�������n�^��������A
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("EP_KEYList", EP_KEYList);
        // ��s�o���ɪ��A
        DBUtil.executeUpdate(ds, SQL_updateInvForDD_001);

        //����
        if ("C".equals(CASE_TYPE)) {
            //1.��s�o���P�h�ɪ��A(�妸��s)
            BatchConstructor.processByBatch(C204List_field, SQL_updateInvForDD_002, false, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL, new BatchConstructor.ListHandler() {
                protected <T> void setField(T object, BatchUpdateDataSet buds) throws DBException {

                    Map EP_KEY = (Map) object;

                    buds.setField("INV_NO", EP_KEY.get("INV_NO"));
                    buds.setField("SER_NO", EP_KEY.get("SER_NO"));
                    buds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    addBatchAndJoinGroup(buds);
                }
            });

            //2.��s����/�w�����B(�妸��s)
            BatchQueryDataSet bqds = null;
            BatchUpdateDataSet buds_C101 = null;
            BatchUpdateDataSet buds_C104 = null;
            BatchUpdateDataSet buds_C301 = null;
            try {
                int fetch_size = TransactionHelper.getInstance().getBatchFetchSize();//���o������
                bqds = Transaction.getBatchQueryDataSet();
                buds_C101 = Transaction.getBatchUpdateDataSet();
                buds_C104 = Transaction.getBatchUpdateDataSet();
                buds_C301 = Transaction.getBatchUpdateDataSet();
                buds_C101.preparedBatch(SQL_updateInvForDD_004);
                buds_C104.preparedBatch(SQL_updateInvForDD_005);
                buds_C301.preparedBatch(SQL_updateInvForDD_006);
                ErrorHandler theErrorHandler = new ErrorHandler();
                StringBuilder sb = new StringBuilder();

                for (Map field : C204List_field) {

                    bqds.setField("INV_NO", field.get("INV_NO"));
                    bqds.setField("SER_NO", field.get("SER_NO"));
                    bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    bqds.searchAndRetrieve(SQL_updateInvForDD_003);
                    int totalCount = bqds.getTotalCount();
                    int currentIndex = 1;
                    int startIndex = currentIndex;
                    int endIndex = startIndex + fetch_size;

                    while (currentIndex <= totalCount) {

                        bqds.fetchData(startIndex, endIndex);
                        bqds.beforeFirst();

                        while (bqds.next()) {
                            Map invMap = VOTool.dataSetToMap(bqds);
                            String rcvC201 = MapUtils.getString(invMap, "RCV_NO_C201");
                            //�㯲���P�f�h�^
                            if(StringUtils.isNotEmpty(rcvC201)) {
                            	//PMI_S_DATE = '2018-04-17', PMI_E_DATE
                                buds_C301.setField("PMI_S_DATE", MapUtils.getString(invMap, "PMI_S_DATE"));
                                buds_C301.setField("PMI_E_DATE", MapUtils.getString(invMap, "PMI_E_DATE"));
                                buds_C301.setField("PAY_NO", bqds.getField("PAY_NO_C201"));
                                buds_C301.setField("RCV_NO", bqds.getField("RCV_NO_C201"));
                                buds_C301.setField("SUB_CPY_ID", bqds.getField("SUB_CPY_ID_C201"));
                                buds_C301.addBatch();
                            } else {
                                //2018.02.21:�̭�Ҳ�(EP_C22040)�p��������B
                                //���o�U�����B
                                if (log.isDebugEnabled()) {
                                    log.debug("invMap = " + invMap);
                                }
                                Map accMap = this.getAccAmts(invMap);
                                if (log.isDebugEnabled()) {
                                    log.debug("accMap = " + accMap);
                                }
                                BigDecimal DEL_RCV_AMT = STRING.objToBigDecimal(accMap.get("DEL_RCV_AMT"), BigDecimal.ZERO);
                                BigDecimal DEL_PRP_AMT = STRING.objToBigDecimal(accMap.get("DEL_PRP_AMT"), BigDecimal.ZERO);
                                boolean DEL_PRP_AMT_compare = DEL_PRP_AMT.compareTo(BigDecimal.ZERO) != 0;

                                if (DEL_RCV_AMT.compareTo(BigDecimal.ZERO) != 0 || DEL_PRP_AMT_compare) {

                                    // ��s�����ɾl�B
                                    BigDecimal C204_SPR_AMT = STRING.objToBigDecimal(bqds.getField("SPR_AMT"), BigDecimal.ZERO);
                                    BigDecimal C204_PRP_SP_AMT_BD = STRING.objToBigDecimal(bqds.getField("PRP_SP_AMT"), BigDecimal.ZERO);
                                    BigDecimal SPR_AMT = C204_SPR_AMT.subtract(DEL_RCV_AMT);
                                    BigDecimal PRP_SP_AMT = C204_PRP_SP_AMT_BD.subtract(DEL_PRP_AMT);

                                    buds_C101.setField("SPR_AMT", SPR_AMT);
                                    buds_C101.setField("PRP_SP_AMT", PRP_SP_AMT);
                                    buds_C101.setField("SUB_CPY_ID", bqds.getField("SUB_CPY_ID"));
                                    buds_C101.setField("RCV_NO", bqds.getField("RCV_NO"));
                                    buds_C101.addBatch();

                                }

                                if (DEL_PRP_AMT_compare) {

                                    // ��s�w��������������(DTEPC104)
                                    //2018.02.21:�վ��s����������`(���@�w�����T�{���w��������)
                                    buds_C104.setField("DEL_PRP_AMT", DEL_PRP_AMT);
                                    buds_C104.setField("SUB_CPY_ID", bqds.getField("SUB_CPY_ID"));
                                    buds_C104.setField("RCV_NO", bqds.getField("RCV_NO"));
                                    buds_C104.addBatch();
                                }
                            }

                        }

                        int[] budsRet_C101 = buds_C101.executeBatch();
                        int[] budsRet_C104 = buds_C104.executeBatch();
                        int[] budsRet_C301 = buds_C301.executeBatch();

                        Object theErrorObject_C101[][] = theErrorHandler.getErrorArray(buds_C101.getBatchUpdateErrorArray(), budsRet_C101, buds_C101.getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);
                        boolean hasError = false;
                        if (theErrorObject_C101.length > 0) {
                            hasError = true;
                            for (int k = 0; k < theErrorObject_C101.length; k++) {
                                Map errorDataMap = (Map) theErrorObject_C101[k][1];
                                log.fatal(sb.append("��s�����ɾl�B��  ").append(theErrorObject_C101[k][0]).append("����Ʀ��~ Update setField = ").append(errorDataMap).toString(), (Exception) theErrorObject_C101[k][2]);
                                sb.setLength(0);
                            }
                        }

                        Object theErrorObject_C104[][] = theErrorHandler.getErrorArray(buds_C104.getBatchUpdateErrorArray(), budsRet_C104, buds_C104.getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);
                        if (theErrorObject_C104.length > 0) {
                            hasError = true;
                            for (int k = 0; k < theErrorObject_C104.length; k++) {
                                Map errorDataMap = (Map) theErrorObject_C104[k][1];
                                log.fatal(sb.append("��s�w�������������ɲ� ").append(theErrorObject_C104[k][0]).append("����Ʀ��~Update setField =").append(errorDataMap).toString(), (Exception) theErrorObject_C104[k][2]);
                                sb.setLength(0);
                            }
                        }
                        
                        Object theErrorObject_C301[][] = theErrorHandler.getErrorArray(buds_C301.getBatchUpdateErrorArray(), budsRet_C301,
                        		buds_C301.getBatchMapsArray(), ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);
                            if (theErrorObject_C301.length > 0) {
                                hasError = true;
                                for (int k = 0; k < theErrorObject_C301.length; k++) {
                                    Map errorDataMap = (Map) theErrorObject_C301[k][1];
                                    log.fatal(sb.append("��s���ú�O�����ɭp���_��� ").append(theErrorObject_C301[k][0]).append("����Ʀ��~Update setField =")
                                            .append(errorDataMap).toString(), (Exception) theErrorObject_C301[k][2]);
                                    sb.setLength(0);
                                }
                            }                        

                        if (hasError) {
                            throw new ModuleException(MessageUtil.getMessage("EP_C21040_MSG_015"));// �妸�B�z��Ʈɦ��~
                        }
                        currentIndex = endIndex;
                    }
                }
            } finally {
                if (bqds != null) {
                    bqds.close();
                }
                if (buds_C101 != null) {
                    buds_C101.close();
                }
                if (buds_C104 != null) {
                    buds_C104.close();
                }
            }
        }
    }

    /**
     * ���o�P�h�U�b�Ȫ��B
     * @param invNoMap  �o������
     * @return  accMap  �P�h�X�b���B
     * @throws ErrorInputException 
     */
    public Map getAccAmts(Map invNoMap) throws ErrorInputException {

        ErrorInputException eie = null;

        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_015"));//�o�����Ӥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        //��l�U���X�b���B:
        BigDecimal intAmt = BigDecimal.ZERO;
        BigDecimal intMngAmt = BigDecimal.ZERO;
        BigDecimal pmiAmt = BigDecimal.ZERO;
        BigDecimal pmTax = BigDecimal.ZERO;
        BigDecimal g002Amt = BigDecimal.ZERO;
        BigDecimal rcvAmt = BigDecimal.ZERO;
        BigDecimal cashAmt = BigDecimal.ZERO;
        BigDecimal chkAmt = BigDecimal.ZERO;
        BigDecimal bankAmt1 = BigDecimal.ZERO;
        BigDecimal bankAmt2 = BigDecimal.ZERO;
        BigDecimal salAmt = BigDecimal.ZERO;
        BigDecimal taxAmt = BigDecimal.ZERO;
        BigDecimal prpAmt = BigDecimal.ZERO;
        BigDecimal DEL_RCV_AMT = BigDecimal.ZERO;
        BigDecimal DEL_PRP_AMT = BigDecimal.ZERO;
        BigDecimal rntAmt = BigDecimal.ZERO;
        //�q�l�o��:�s�W�w�ޥX�b
        BigDecimal mngAmt = BigDecimal.ZERO;
        BigDecimal mngTaxAmt = BigDecimal.ZERO;
        BigDecimal mngRjtAmt = BigDecimal.ZERO;

        BigDecimal RJT_AMT = STRING.objToBigDecimal(invNoMap.get("RJT_AMT"), BigDecimal.ZERO);
        BigDecimal RJT_TAX = STRING.objToBigDecimal(invNoMap.get("RJT_TAX"), BigDecimal.ZERO);

        //���o�U���X�b���B
        String PAY_KIND = MapUtils.getString(invNoMap, "PAY_KIND");
        if ("2".equals(PAY_KIND)) {
            intAmt = RJT_AMT;
            intMngAmt = RJT_TAX;
            pmiAmt = RJT_AMT;
            pmTax = RJT_TAX;
            rntAmt = RJT_AMT;
        } else {//�D�㯲���o��

            BigDecimal SPR_AMT = STRING.objToBigDecimal(invNoMap.get("SPR_AMT"), BigDecimal.ZERO);
            BigDecimal PRP_SP_AMT = STRING.objToBigDecimal(invNoMap.get("PRP_SP_AMT"), BigDecimal.ZERO);
            if (isDebug) {
                log.debug("�D�㯲���o��  SPR_AMT:" + SPR_AMT + ",PRP_SP_AMT: " + PRP_SP_AMT);
            }

            //�����l�B����
            if (SPR_AMT.compareTo(BigDecimal.ZERO) != 0) {
                if (SPR_AMT.compareTo(RJT_AMT.add(RJT_TAX)) > 0) {
                    DEL_RCV_AMT = SPR_AMT;
                } else {
                    DEL_RCV_AMT = RJT_AMT.add(RJT_TAX);
                }
            } else {
                DEL_RCV_AMT = BigDecimal.ZERO;
            }

            //�w���l�B����
            if (PRP_SP_AMT.compareTo(BigDecimal.ZERO) != 0) {
                if (PRP_SP_AMT.compareTo(RJT_AMT) < 0) {
                    DEL_PRP_AMT = PRP_SP_AMT;
                } else {
                    DEL_PRP_AMT = RJT_AMT;
                }
            } else {
                DEL_PRP_AMT = BigDecimal.ZERO;
            }

            if (SPR_AMT.compareTo(BigDecimal.ZERO) > 0) {//��ú��:�䥦������
                rcvAmt = DEL_RCV_AMT;
            }
            if (isDebug) {
                log.debug("SPR_AMT: " + SPR_AMT + " RJT_AMT.add(RJT_TAX).subtract(SPR_AMT): " + RJT_AMT.add(RJT_TAX).subtract(SPR_AMT));
            }
            if (SPR_AMT.compareTo(BigDecimal.ZERO) <= 0 || (RJT_AMT.add(RJT_TAX).subtract(SPR_AMT)).compareTo(BigDecimal.ZERO) > 0) {//�wú��:�h�O
                String PAY_TYPE = MapUtils.getString(invNoMap, "PAY_TYPE");

                if ("4".equals(PAY_TYPE)) {
                    //�Ȧ����B
                    g002Amt = RJT_AMT.add(RJT_TAX).subtract(SPR_AMT);
                } else if ("1".equals(PAY_TYPE)) {
                    //�w�s�{��
                    cashAmt = RJT_AMT.add(RJT_TAX).subtract(SPR_AMT);
                } else if ("2".equals(PAY_TYPE)) {
                    //�䲼���B
                    chkAmt = RJT_AMT.add(RJT_TAX).subtract(SPR_AMT);
                } else if ("3".equals(PAY_TYPE)) {//�״�
                    //�Ȧ�s�ڪ��B
                    bankAmt1 = RJT_AMT.add(RJT_TAX).subtract(SPR_AMT);
                } else {//�P�b
                    bankAmt2 = RJT_AMT.add(RJT_TAX).subtract(SPR_AMT);
                }
            }

            if (PRP_SP_AMT.compareTo(BigDecimal.ZERO) == 0) {//�L�w��
                salAmt = RJT_AMT;
                taxAmt = RJT_TAX;
                rntAmt = RJT_AMT;
            } else {
                prpAmt = DEL_PRP_AMT;
                taxAmt = RJT_TAX;
                BigDecimal RJT_PRP_SP = RJT_AMT.subtract(PRP_SP_AMT);
                if (RJT_PRP_SP.compareTo(BigDecimal.ZERO) > 0) {//�������B-�w���l�B>0(�������B �W�L �w���l�B)
                    salAmt = RJT_PRP_SP;
                    rntAmt = RJT_PRP_SP;
                }
            }

        }
        Map accMap = new HashMap();
        accMap.put("INT_AMT", intAmt);
        accMap.put("INT_MNG_AMT", intMngAmt);
        accMap.put("PMI_AMT", pmiAmt);
        accMap.put("PMI_TAX", pmTax);
        accMap.put("G002_AMT", g002Amt);
        accMap.put("RCV_AMT", rcvAmt);
        accMap.put("CASH_AMT", cashAmt);
        accMap.put("CHK_AMT", chkAmt);
        accMap.put("BANK_AMT1", bankAmt1);
        accMap.put("BANK_AMT2", bankAmt2);
        accMap.put("SAL_AMT", salAmt);
        accMap.put("TAX_AMT", taxAmt);
        accMap.put("PRP_AMT", prpAmt);
        accMap.put("DEL_RCV_AMT", DEL_RCV_AMT);
        accMap.put("DEL_PRP_AMT", DEL_PRP_AMT);
        accMap.put("RJT_RNT_AMT", rntAmt);
        accMap.put("MNG_AMT", mngAmt);
        accMap.put("MNG_TAX_AMT", mngTaxAmt);
        accMap.put("MNG_RJT_AMT", mngRjtAmt);

        return accMap;
    }

    /**
     * checkMakeInv
     * @param selectMap
     * @return
     * @throws ModuleException
     */
    private boolean checkMakeInv(Map selectMap) throws ModuleException {

        //Ū���޲z�O���}�o�����]�w��
        try {

            String SUB_CPY_ID = MapUtils.getString(selectMap, "SUB_CPY_ID");
            List<DTEPZ002> SysSetList = new EP_Z1Z002().getSysSetList("EPC1", "3", null, SUB_CPY_ID);

            for (DTEPZ002 Z002VO : SysSetList) {

                //ú�ں���=��3���޲z�O�A�B�j�ӥN���s�b��]�w��
                String PAY_KIND = MapUtils.getString(selectMap, "PAY_KIND");
                String BLD_CD = MapUtils.getString(selectMap, "BLD_CD");

                if ("3".equals(PAY_KIND) && BLD_CD.compareTo(Z002VO.getVALUE1()) == 0) {
                    return false;
                }
            }
        } catch (DataNotFoundException dnfe) {

        }
        BigDecimal INV_AMT = STRING.objToBigDecimal((selectMap.get("INV_AMT")), BigDecimal.ZERO);

        if (isDebug) {
            log.debug("@@@selectMap.get(\"INV_AMT\")=" + selectMap.get("INV_AMT"));
            log.debug("@@@selectMap.get(\"INV_AMT\").compareTo(BigDecimal.ZERO)=" + (INV_AMT.compareTo(BigDecimal.ZERO) == 0));
        }

        //�o�����B=0 ���}�o��
        if (INV_AMT.compareTo(BigDecimal.ZERO) == 0) {
            return false;
        }

        return true;
    }

    /**
     * ���o ErrorInputException
     * @param eie
     * @param message
     * @return eie
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String message) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(message);
        return eie;
    }

    /**
     * (�㯲��)���o�����Ӽh/�ǧO/����
     * @param ds
     * @return
     * @throws ModuleException
     */
    private Map getFLD_ROOM_PRK(DataSet ds) throws ModuleException {
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_getFLD_ROOM_PRK_001, false);

        Map rtnMap = new HashMap();
        StringBuilder sb = new StringBuilder();
        if (rtnList != null && !rtnList.isEmpty()) {
            for (Map tmpMap : rtnList) {
                sb.setLength(0);
                rtnMap.put(sb.append(MapUtils.getString(tmpMap, "CRT_NO")).append("-").append(MapUtils.getString(tmpMap, "CUS_NO")).toString(), tmpMap);
            }
        }
        return rtnMap;
    }

    /**
     * ��dataSet
     * @param ds
     * @param STATUS
     * @param SLIP_SET_NO
     * @param PRE_KEY
     * @param SUB_CPY_ID
     * @param ACNT_DATE_S
     * @param ACNT_DATE_E
     */
    private void setDataSet(DataSet ds, String STATUS, String SLIP_SET_NO, String DIV_NO, String SUB_CPY_ID, String ACNT_DATE_S, String ACNT_DATE_E) {
        ds.clear();
        if (StringUtils.isNotBlank(STATUS)) {
            if ("0".equals(STATUS)) {
                ds.setField("OP_STATUS_1", "1");
            } else {
                ds.setField("OP_STATUS_2", "1");
            }
        }
        if (StringUtils.isNotBlank(SLIP_SET_NO)) {
            ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        }
        if (StringUtils.isNotBlank(DIV_NO)) {
            ds.setField("DIV_NO", DIV_NO);
        }
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("ACNT_DATE_S", ACNT_DATE_S);
        ds.setField("ACNT_DATE_E", ACNT_DATE_E);
    }

    /**
     * <pre>
     * �N rtnList �Ƨǩһݤ�Comparator
     * @author i9300625
     * </pre>
     */
    private class sortRule implements Comparator<Map> {
        String[] compareKey = new String[] { "ACNT_INFO", "BLD_USR_ID", "BLD_CD", "ID" };

        public int compare(Map aMap, Map bMap) {
            int i = 0;
            for (String key : compareKey) {
                String aValue = MapUtils.getString(aMap, key, "");
                String bValue = MapUtils.getString(bMap, key, "");
                i = aValue.compareTo(bValue);
                if (i != 0) {
                    return i;
                }
            }
            return i;
        }
    }

    /**
     * �ץX�o������
     * @param reqMap
     * @param ACNT_INFO_MAP
     * @param user
     * @param resp
     * @return
     * @throws Exception
     */
    public ResponseContext export(Map reqMap, Map ACNT_INFO_MAP, ResponseContext resp) throws Exception {

        List<Map> selectList = new ArrayList<Map>();
        selectList.add(ACNT_INFO_MAP);
        List<Map> detailList = this.queryDetail(reqMap, selectList);

        String ACNT_INFO = MapUtils.getString(ACNT_INFO_MAP, "ACNT_INFO");
        String ACNT_DIV_NO = MapUtils.getString(ACNT_INFO_MAP, "ACNT_DIV_NO");
        String ACNT_NM = MapUtils.getString(ACNT_INFO_MAP, "ACNT_NAME");

        //�����ɦW :�o������_+���+_+ACNT_INFO.xls
        StringBuilder sb = new StringBuilder();
        String fileName = sb.append("�o������_").append(ACNT_DIV_NO).append("_").append(ACNT_INFO).toString();

        //�]�w��Ʈ榡
        List<List<ColumnSetting>> titles = new ArrayList<List<ColumnSetting>>();
        List<List<ColumnSetting>> records = new ArrayList<List<ColumnSetting>>();
        //�]�w"�Ĥ@��"
        sb.setLength(0);
        String BASE_BLD_NAME = MapUtils.getString(reqMap, "BASE_BLD_NAME");
        if (StringUtils.isNotBlank(BASE_BLD_NAME)) {
            sb.append(BASE_BLD_NAME);
        }

        setTitles(titles, records, ACNT_INFO, ACNT_DIV_NO + ACNT_NM);

        //�ץXexcel
        Map<String, Object> dataTotalMap = new HashMap<String, Object>();
        dataTotalMap.put("totalTitle", MessageUtil.getMessage("EPG3_0310_UI_SUM"));
        dataTotalMap.put("totalColumns", fieldsForGroupTotal);

        XlsUtils xlsUtils = new XlsUtils(fileName, detailList, resp);
        xlsUtils.parseToSheetSetting(fileName, titles, records);
        xlsUtils.initExportSetting(dataTotalMap);
        xlsUtils.execute(new XlsUtils.ListProcessHandler() {
            /**
             * �v���B�z
             */
            @Override
            protected boolean dataOutputProcess(Map dataMap) {
                return true;//true:�����n�ץX ; false:�������ץX
            }

        });

        return resp;
    }

    /**
     * �]�w�ץX���榡
     * @param titles
     * @param records
     * @param title
     */
    private void setTitles(List<List<ColumnSetting>> titles, List<List<ColumnSetting>> records, String ACNT_INFO, String ACNT_NAME) {

        //�ɮפ��e�Ĥ@��Х[�W�H�U���
        List<ColumnSetting> titleRow = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(titleRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPC2_1040_UI_ACNT_INFO")); //title="�ǲ���T:"
        XlsUtils.addColumnAttrs(titleRow, XlsUtils.EMPTY, ACNT_INFO, new ColumnOptions(1, 3)); //title=(�ǲ���T)
        XlsUtils.addColumnAttrs(titleRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPC2_1040_UI_ACNT_NAME")); //title="�b�ȽT�{�H��:"
        XlsUtils.addColumnAttrs(titleRow, XlsUtils.EMPTY, ACNT_NAME, new ColumnOptions(1, 3)); //title=(�b�ȽT�{�H��)
        titles.add(titleRow);

        List<ColumnSetting> firstRow = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPC2_1040_UI_KIND_NM"));//����  
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPC2_1040_UI_PRE_KEY"));//�s��  
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPC2_1040_UI_PIN_NAME"));//�~�W 
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPC2_1040_UI_INV_AMT"));//�o�����B
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPC2_1040_UI_SAL_AMT"));//�P���B 
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPC2_1040_UI_TAX_AMT"));//�|�B  
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPC2_1040_UI_INV_NO"));//�o�����X 
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPC2_1040_UI_OP_STATUS_NM"));//���A
        titles.add(firstRow);

        //���e
        List<ColumnSetting> firstRow_ = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow_, "KIND_NM", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "PRE_KEY", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "PIN_NAME", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "INV_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "SAL_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "TAX_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "INV_NO", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "OP_STATUS_NM", XlsUtils.EMPTY);
        records.add(firstRow_);

    }
}
