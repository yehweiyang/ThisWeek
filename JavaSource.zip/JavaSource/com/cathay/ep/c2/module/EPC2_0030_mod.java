package com.cathay.ep.c2.module;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;

/**
 * <pre>
 * DATE     Description Author
 * 2013/12/02   Created ������
 *  
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �㯲�����ӽT�{�ˮּҲ�
 * �{���W��    EPC2_0030_mod.java
 * �@�~�覡    MODULE
 * ���n����    �ˮֵe���W�o�����ӿ�J�Ҳ�
 * </pre>
 * @author ����[
 * @since 2013-12-13
 */
@SuppressWarnings("unchecked")
public class EPC2_0030_mod {

    private static final Logger Log = Logger.getLogger(EP_C20030.class);

    private boolean isDebug = Log.isDebugEnabled();
    /**
     * �T�{����ˮ�
     * @param dataMap       �e��������T
     * @param unConfirmList ���T�{���
     * @throws ModuleException
     */
    public void checkConfirm(Map dataMap, List<Map> unConfirmList) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_0030_mod_MSG_001"));//�ǤJ��T���o����
        }
        if (unConfirmList == null || unConfirmList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_0030_mod_MSG_002"));//���T�{��Ƥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        BigDecimal pmi_amt_sum = BigDecimal.ZERO;
        BigDecimal pmi_tax_sum = BigDecimal.ZERO;
        BigDecimal inv_amt_sum = BigDecimal.ZERO;

        for (Map unconfirmMap : unConfirmList) {
            pmi_amt_sum = pmi_amt_sum.add(getBigDecimal(unconfirmMap.get("PMI_AMT"), BigDecimal.ZERO));
            pmi_tax_sum = pmi_tax_sum.add(getBigDecimal(unconfirmMap.get("PMI_TAX"), BigDecimal.ZERO));
            inv_amt_sum = inv_amt_sum.add(getBigDecimal(unconfirmMap.get("INV_AMT"), BigDecimal.ZERO));
        }

        if (pmi_amt_sum.compareTo(getBigDecimal(dataMap.get("PMI_AMT_TOTAL"), BigDecimal.ZERO)) != 0
                || pmi_tax_sum.compareTo(getBigDecimal(dataMap.get("PMI_TAX_TOTAL"), BigDecimal.ZERO)) != 0
                || inv_amt_sum.compareTo(getBigDecimal(dataMap.get("INV_AMT_TOTAL"), BigDecimal.ZERO)) != 0) {
            throw new ModuleException(MessageUtil.getMessage("EPC2_0030_mod_MSG_003"));//�㯲���P���B�ε|�B�X�p���~
        }

    }

    public void checkConfirmData(List<Map> unConfirmList, List<Map> unConfirmList1,List<Map> unConfirmList2) throws ModuleException {
        ErrorInputException eie = null;
        if (unConfirmList == null || unConfirmList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_0030_mod_MSG_002"));//���T�{��Ƥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        BigDecimal pms_amt_sum = BigDecimal.ZERO;
        Integer pms_amt_cnt = 0;

        BigDecimal pms_amt_sum1 = BigDecimal.ZERO;//�㮧���B>0
        Integer pms_amt_cnt1 = 0;
        
        BigDecimal pms_amt_sum2 = BigDecimal.ZERO;//�㮧���B=0
        Integer pms_amt_cnt2 = 0;

        for (Map unconfirmMap : unConfirmList) {
            pms_amt_sum = pms_amt_sum.add(getBigDecimal(unconfirmMap.get("PMS_AMT"), BigDecimal.ZERO));
            pms_amt_cnt++;
        }
        if(unConfirmList1 != null){
            for (Map unconfirmMap1 : unConfirmList1) {
                pms_amt_sum1= pms_amt_sum1.add(getBigDecimal(unconfirmMap1.get("PMS_AMT"), BigDecimal.ZERO));
                pms_amt_cnt1++;
            }
            
        }
        if(unConfirmList2 != null){
            for (Map unconfirmMap2 : unConfirmList2) {
                pms_amt_sum2 = pms_amt_sum2.add(getBigDecimal(unconfirmMap2.get("PMS_AMT"), BigDecimal.ZERO));
                pms_amt_cnt2++;
            }
            
        }


        if(isDebug){
            Log.debug("@@@pms_amt_sum="+pms_amt_sum);
            Log.debug("@@@pms_amt_sum1="+pms_amt_sum1);
            Log.debug("@@@pms_amt_sum2="+pms_amt_sum2);
            Log.debug("@@@pms_amt_sum.compareTo(pms_amt_sum1.add(pms_amt_sum2)) ="+pms_amt_sum.compareTo(pms_amt_sum1.add(pms_amt_sum2)) );

            Log.debug("@@@pms_amt_cnt="+pms_amt_cnt);
            Log.debug("@@@pms_amt_cnt1="+pms_amt_cnt1);
            Log.debug("@@@pms_amt_cnt2="+pms_amt_cnt2);
            Log.debug("@@@pms_amt_cnt.compareTo(pms_amt_cnt1+pms_amt_cnt2) ="+pms_amt_cnt.compareTo(pms_amt_cnt1+pms_amt_cnt2) );

        }
        if (pms_amt_sum.compareTo(pms_amt_sum1.add(pms_amt_sum2)) != 0
                || pms_amt_cnt.compareTo(pms_amt_cnt1+pms_amt_cnt2) != 0)        {
            throw new ModuleException(MessageUtil.getMessage("EPC2_0030_mod_MSG_006"));//���T�{����ˮ֦��~(�㮧>0�Ω㮧=0)
        }

    }

    /**
     * �d�߸���ˮ�
     * @param dataMap   �e��������T
     * @throws ErrorInputException
     */
    public void checkQuery(Map dataMap) throws ErrorInputException {
        if (dataMap == null || dataMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EPC2_0030_mod_MSG_001"));//�ǤJ��T���o����
        }
        if (StringUtils.isBlank(MapUtils.getString(dataMap, "INT_YM"))) {
            throw new ErrorInputException(MessageUtil.getMessage("EPC2_0030_mod_MSG_004"));//�Х���J�p���~��d��
        }
    }

    /**
     * �����T�{����ˮ�
     * @param dataMap   �e��������T
     * @throws ErrorInputException
     */
    public void checkCancel(Map dataMap) throws ErrorInputException {
        if (dataMap == null || dataMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EPC2_0030_mod_MSG_001"));//�ǤJ��T���o����
        }

        if (dataMap.get("ACNT_DATE") == null || StringUtils.isBlank(MapUtils.getString(dataMap, "ACNT_DIV_NO"))
                || StringUtils.isBlank(MapUtils.getString(dataMap, "SLIP_LOT_NO"))
                || StringUtils.isBlank(MapUtils.getString(dataMap, "SLIP_SET_NO"))) {
            throw new ErrorInputException(MessageUtil.getMessage("EPC2_0030_mod_MSG_005"));//�Х���J����b�ȸ�T(�b��B�J�b���B�帹�B�ո�)
        }

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

}
