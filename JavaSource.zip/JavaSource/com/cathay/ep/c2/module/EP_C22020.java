package com.cathay.ep.c2.module;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dc.b0.module.DC_B0Z028;
import com.cathay.dc.bo.DTDCB014;
import com.cathay.dd.e0.module.DD_E0Z006;
import com.cathay.dj.a0.bo.DJ_A0Z016_vo;
import com.cathay.dj.a0.module.DJ_A0Z016;
import com.cathay.ep.c0.module.EP_C0Z001;
import com.cathay.ep.vo.DTEPC204;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE     Description Author
 * 2013/09/10   Created ���|��
 * 2018/01/29   1.1      �վ�o���~�W�榡         ����[
 * 2018/08/10   �q�l�o���ɤJ��޲z�O�����ݥX�b        ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �P�f�h�^���@�Ҳ�
 * �Ҳ�ID     EP_C22020
 * ���n����    �P�f�h�^���@�Ҳ�
 *</pre>
 * @author ����[
 * @since 2013-11-26
 * 2019/12/25 AllenTsai �վ�㯲���o���P�f�h�^�B�zú�ں�������
 */

@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C22020 {

    private static final Logger log = Logger.getLogger(EP_C22020.class);

    private boolean isDebug = log.isDebugEnabled();

    private static final String SQL_query1_001 = "com.cathay.ep.c2.module.EP_C22020.SQL_query1_001";

    private static final String SQL_query2_001 = "com.cathay.ep.c2.module.EP_C22020.SQL_query2_001";

    private static final String SQL_queryTotRjtAmt_001 = "com.cathay.ep.c2.module.EP_C22020.SQL_queryTotRjtAmt_001";

    private static final String SQL_getRmtCnt_001 = "com.cathay.ep.c2.module.EP_C22020.SQL_getRmtCnt_001";

    private static final String SQL_confirm_001 = "com.cathay.ep.c2.module.EP_C22020.SQL_confirm_001";

    private static final String SQL_confirm_002 = "com.cathay.ep.c2.module.EP_C22020.SQL_confirm_002";

    private static final String SQL_unConfirm_003 = "com.cathay.ep.c2.module.EP_C22020.SQL_unConfirm_003";

    private static final String SQL_unConfirm_002 = "com.cathay.ep.c2.module.EP_C22020.SQL_unConfirm_002";

    private static final String SQL_unConfirm_001 = "com.cathay.ep.c2.module.EP_C22020.SQL_unConfirm_001";

    private static final String SQL_update_001 = "com.cathay.ep.c2.module.EP_C22020.SQL_update_001";

    private static final String SQL_confirm_003 = "com.cathay.ep.c2.module.EP_C22020.SQL_confirm_003";

    private static final String SQL_unConfirm_004 = "com.cathay.ep.c2.module.EP_C22020.SQL_unConfirm_004";

    /**
     *  �o�����X��Ƭd��
     * @param SUB_CPY_ID    �����q�O
     * @param INV_NO        �o�����X
     * @return  rtnMap      �o�����X���
     * @throws ModuleException
     */
    public Map query1(String SUB_CPY_ID, String INV_NO) throws ModuleException {
        return this.query1(SUB_CPY_ID, INV_NO, true);
    }

    public Map query1(String SUB_CPY_ID, String INV_NO, boolean pinNameForQuery) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_001"));//�����q�O���������
        }
        if (StringUtils.isBlank(INV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_002"));//�o�����X���������
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_query1_001);

        //�B�z�N�X����
        // �s�W����^�ǲM�� 
        rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
        rtnMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE")));
        rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EP", "PAY_KIND", MapUtils.getString(rtnMap, "PAY_KIND")));
        rtnMap.put("INV_CD_NM", FieldOptionList.getName("EP", "INV_CD", MapUtils.getString(rtnMap, "INV_CD")));

        //�վ�~�W�榡
        if (pinNameForQuery) {
            new EP_C0Z001().getPIN_NAMEForQuery(rtnMap, null, null);
        }

        return rtnMap;
    }

    /**
     * �d�߾P�f�h�^����
     * @param SUB_CPY_ID    �����q�O
     * @param INV_NO    �o�����X
     * @return  resultList  �P�f�h�^���
     * @throws DBException
     * @throws ModuleException
     */
    public List<Map> query2(String SUB_CPY_ID, String INV_NO) throws DBException, ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_001"));//�����q�O���������
        }
        if (StringUtils.isBlank(INV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_002"));//�o�����X���������
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> resultList = VOTool.findToMaps(ds, SQL_query2_001, false);
        if (resultList == null) {
            return Collections.EMPTY_LIST;
        }

        //�B�z�N�X����
        //�s�W����^�ǲM�� :�h�O�覡�P��צ�w�W��
        DC_B0Z028 theDC_B0Z028 = new DC_B0Z028();
        for (Map rtnMap : resultList) {
            rtnMap.put("PAY_TYPE_NM", FieldOptionList.getName("EP", "PAY_TYPE_C204", MapUtils.getString(rtnMap, "PAY_TYPE")));

            String RMT_BANK_ID = MapUtils.getString(rtnMap, "RMT_BANK_NO");
            if ("00".equals(MapUtils.getString(rtnMap, "SUB_CPY_ID")) && StringUtils.isNotBlank(RMT_BANK_ID)) {
                ReturnMessage rm = new ReturnMessage();
                DTDCB014 DTDCB104vo = theDC_B0Z028.getBankInfo(RMT_BANK_ID, rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(rm.getMsgDesc());
                } else {
                    rtnMap.put("RMT_ACNT_NM", DTDCB104vo.getBANK_SNAME());
                }
            } else {
                rtnMap.put("RMT_ACNT_NM", "");
            }

        }
        return resultList;
    }

    /**
     * �d�߾P�f�h�^����
     * @param SUB_CPY_ID    �����q�O
     * @param INV_NO        �o�����X
     * @return  resultList  �P�f�h�^���
     * @throws ModuleException
     */
    public Map queryTotRjtAmt(String SUB_CPY_ID, String INV_NO) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_001"));//�����q�O���������
        }
        if (StringUtils.isBlank(INV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_002"));//�o�����X���������
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findOneToMap(ds, SQL_queryTotRjtAmt_001);

    }

    /**
     * ���o�P�f�h�^����
     * @param SUB_CPY_ID    �����q�O
     * @param INV_NO        �o�����X
     * @return  rtnCnt      �P�f�h�^����
     * @throws ModuleException
     */
    public int getRmtCnt(String SUB_CPY_ID, String INV_NO) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_001"));//�����q�O���������
        }
        if (StringUtils.isBlank(INV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_002"));//�o�����X���������
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_getRmtCnt_001);
        ds.next();
        return (Integer) ds.getField(0);
    }

    /**
     * ���o�o�������`�B
     * @param rjtMap    �P�f�h�^����
     * @param invNoMap  �o������
     * @param EMP_ID    �T�{�H��
     * @param EMP_NAME  �T�{�H���m�W
     * @param DIV_NO    �T�{���
     * @throws ModuleException
     * @throws UnsupportedEncodingException
     */
    public void confirm(Map rjtMap, Map invNoMap, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException, UnsupportedEncodingException {
        ErrorInputException eie = null;

        if (rjtMap == null || rjtMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_003"));//�P�f�h�^���Ӥ��i����
        }
        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_004"));//�o�����Ӥ��i����
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_005"));//�T�{�H�����������
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_006"));//�T�{�H���m�W���������
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_007"));//�T�{��쬰�������
        }
        if (eie != null) {
            throw eie;
        }

        String PAY_TYPE = MapUtils.getString(rjtMap, "PAY_TYPE");
        String SUB_CPY_ID = MapUtils.getString(rjtMap, "SUB_CPY_ID");
        String ACPT_BANK_NO = MapUtils.getString(rjtMap, "ACPT_BANK_NO");
        String INV_NO = MapUtils.getString(rjtMap, "INV_NO");
        String PAY_KIND = MapUtils.getString(invNoMap, "PAY_KIND");
        String strRmtBankNo;
        String strRmtAcntNo;
        if ("3".equals(PAY_TYPE) && "00".equals(SUB_CPY_ID)) {//�h�O�覡=�״ڥB����إ�
            DJ_A0Z016_vo dj_A0Z016_vo = DJ_A0Z016.getRmtBankInfoByAcptBankNo(ACPT_BANK_NO, "NTD", true);

            //���ڦ�w�B���O�B�O�_���o�w�]�ץX��w
            strRmtBankNo = dj_A0Z016_vo.getRMT_BANK_NO();//��צ�w
            strRmtAcntNo = dj_A0Z016_vo.getRMT_ACNT_NO();//��ױb��
        } else {
            strRmtBankNo = "";
            strRmtAcntNo = "";
        }

        //ú�ں�������3�޲z�O�M6�������J�A�h�g�J�o���P�f�h�^���
        if (!"6".equals(PAY_KIND)) {
            int strSerNo = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "019", "EPC204", INV_NO); //�����q�O�B�t�ΧO:�P�f�h�^�o���y�����B�P�h�s���B�o�����X
            DTEPC204 dtepc204_vo = new DTEPC204();
            dtepc204_vo.setINV_NO(INV_NO);
            dtepc204_vo.setSER_NO(new BigDecimal(strSerNo));
            dtepc204_vo.setSUB_CPY_ID(SUB_CPY_ID);
            dtepc204_vo.setRCV_YM(obj2Decimal(invNoMap.get("RCV_YM"), false));
            dtepc204_vo.setCRT_NO(MapUtils.getString(invNoMap, "CRT_NO"));
            dtepc204_vo.setCUS_NO(MapUtils.getInteger(invNoMap, "CUS_NO"));
            dtepc204_vo.setCUS_NAME(MapUtils.getString(invNoMap, "CUS_NAME"));
            dtepc204_vo.setID(MapUtils.getString(invNoMap, "ID"));
            dtepc204_vo.setINV_AMT(obj2Decimal(invNoMap.get("INV_AMT"), true));
            dtepc204_vo.setSAL_AMT(obj2Decimal(invNoMap.get("SAL_AMT"), true));
            dtepc204_vo.setTAX_AMT(obj2Decimal(invNoMap.get("TAX_AMT"), true));
            dtepc204_vo.setTAX_TYPE(MapUtils.getString(invNoMap, "TAX_TYPE"));
            dtepc204_vo.setRJT_AMT(MapUtils.getInteger(rjtMap, "RJT_AMT"));
            dtepc204_vo.setRJT_TAX(MapUtils.getInteger(rjtMap, "RJT_TAX"));
            dtepc204_vo.setRJT_S_DATE(Date.valueOf(MapUtils.getString(rjtMap, "RJT_S_DATE")));
            dtepc204_vo.setRJT_E_DATE(Date.valueOf(MapUtils.getString(rjtMap, "RJT_E_DATE")));
            dtepc204_vo.setRJT_RNT_AMT(obj2Decimal(rjtMap.get("RJT_AMT"), false).add(obj2Decimal(rjtMap.get("RJT_TAX"), false)));
            dtepc204_vo.setR_ACNT_DATE(null);
            dtepc204_vo.setR_ACNT_ID(null);
            dtepc204_vo.setR_ACNT_DIV_NO(null);
            dtepc204_vo.setR_SLPLOT_NO(null);
            dtepc204_vo.setR_SLPSET_NO(null);
            dtepc204_vo.setPAY_TYPE(PAY_TYPE);
            dtepc204_vo.setACPT_BANK_NO(STRING.fillCharFromLeftExt(ACPT_BANK_NO.trim(), 7, '0'));
            dtepc204_vo.setACPT_ACNT_NO(STRING.fillCharFromLeftExt(MapUtils.getString(rjtMap, "ACPT_ACNT_NO").trim(), 16, '0'));
            dtepc204_vo.setACPT_ACNT_NAME(MapUtils.getString(rjtMap, "ACPT_ACNT_NAME"));
            dtepc204_vo.setACPT_ID(MapUtils.getString(rjtMap, "ACPT_ID"));
            dtepc204_vo.setRMT_BANK_NO(strRmtBankNo);
            dtepc204_vo.setRMT_ACNT_NO(strRmtAcntNo);
            dtepc204_vo.setTRN_KIND("EPC203");//�P�f�h�^
            dtepc204_vo.setCHG_DATE(DATE.currentTime());
            dtepc204_vo.setCHG_DIV_NO(DIV_NO);
            dtepc204_vo.setCHG_ID(EMP_ID);
            dtepc204_vo.setCHG_NAME(EMP_NAME);
            VOTool.insert(dtepc204_vo);
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("CHG_DIV_NO", DIV_NO);
        ds.setField("CHG_ID", EMP_ID);
        ds.setField("CHG_NAME", EMP_NAME);
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_confirm_001);

        if (!("2".equals(PAY_KIND) || "6".equals(PAY_KIND))) { //ú�ں�������2����M6�������J�A�h��s������(DTEPC101)
            ds.clear();
            ds.setField("LST_PROC_DIV", DIV_NO);
            ds.setField("LST_PROC_ID", EMP_ID);
            ds.setField("LST_PROC_NAME", EMP_NAME);
            ds.setField("RCV_NO", MapUtils.getString(invNoMap, "RCV_NO"));
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_confirm_002);
        }
        if ("3".equals(PAY_KIND)) {//ú�ں�����3�޲z�O�A�h��s�޲z�O���u(DTEPC103)
            ds.clear();
            ds.setField("RCV_NO", MapUtils.getString(invNoMap, "RCV_NO"));
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_confirm_003);
        }
    }

    /**
     * �P�f�h�^����
     * @param rjtMap    �P�f�h�^����
     * @param invNoMap  �o������
     * @param EMP_ID    �T�{�H��
     * @param EMP_NAME  �T�{�H���m�W
     * @param DIV_NO    �T�{���
     * @throws ModuleException
     */
    public void unConfirm(Map rjtMap, Map invNoMap, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException {
        ErrorInputException eie = null;

        if (rjtMap == null || rjtMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_003"));//�P�f�h�^���Ӥ��i����
        }
        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_004"));//�o�����Ӥ��i����
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_005"));//�T�{�H�����������
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_006"));//�T�{�H���m�W���������
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_007"));//�T�{��쬰�������
        }
        if (eie != null) {
            throw eie;
        }
        log.debug("invNoMap: "+invNoMap);
        log.debug("rjtMap: "+rjtMap);

        String PAY_KIND = MapUtils.getString(invNoMap, "PAY_KIND");
        String SUB_CPY_ID = MapUtils.getString(rjtMap, "SUB_CPY_ID");
        String INV_NO = MapUtils.getString(rjtMap, "INV_NO");

        int intCnt = this.getRmtCnt(SUB_CPY_ID, INV_NO);

        DataSet ds = Transaction.getDataSet();

        //ú�ں�������3�޲z�O�M6�������J�A�h�R���o���P�f�h�^���
        //180810:�q�l�o���ɤJ��޲z�O�����ݥX�b
        if (!("6".equals(PAY_KIND))) {
            ds.setField("INV_NO", INV_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("SER_NO", MapUtils.getString(rjtMap, "SER_NO"));
            DBUtil.executeUpdate(ds, SQL_unConfirm_001);
        }

        if (intCnt == 1) {//�o���Ҧ��P�f�h�^���ӥu��1���A�h��s�o�����
            ds.clear();
            ds.setField("CHG_DIV_NO", DIV_NO);
            ds.setField("CHG_ID", EMP_ID);
            ds.setField("CHG_NAME", EMP_NAME);
            ds.setField("INV_NO", INV_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_unConfirm_002);

            //ú�ں�������2����B�o���Ҧ��P�f�h�^���ӥu��1���A�h��s������(DTEPC101)
            if (!"2".equals(PAY_KIND)) {
                ds.clear();
                ds.setField("LST_PROC_DIV", DIV_NO);
                ds.setField("LST_PROC_ID", EMP_ID);
                ds.setField("LST_PROC_NAME", EMP_NAME);
                ds.setField("RCV_NO", MapUtils.getString(invNoMap, "RCV_NO"));
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.executeUpdate(ds, SQL_unConfirm_003);
            }

            //180810:�q�l�o���ɤJ��޲z�O�����ݥX�b
            if ("3".equals(PAY_KIND)) {//ú�ں�����3�޲z�O�A�h��s�޲z�O���u(DTEPC103)
                ds.clear();
                ds.setField("RCV_NO", MapUtils.getString(invNoMap, "RCV_NO"));
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.executeUpdate(ds, SQL_unConfirm_004);
            }
        }
    }

    /**
     * �P�f�h�^�ק�
     * @param rjtMap    �P�f�h�^����
     * @param EMP_ID    �ק�H��
     * @param EMP_NAME  �ק�H���m�W
     * @param DIV_NO    �ק���
     * @throws ModuleException
     */
    public void update(Map rjtMap, String EMP_ID, String EMP_NAME, String DIV_NO) throws ModuleException {
        ErrorInputException eie = null;

        if (rjtMap == null || rjtMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_003"));//�P�f�h�^���Ӥ��i����
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_005"));//�T�{�H�����������
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_006"));//�T�{�H���m�W���������
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_007"));//�T�{��쬰�������
        }
        if (eie != null) {
            throw eie;
        }

        String SUB_CPY_ID = MapUtils.getString(rjtMap, "SUB_CPY_ID");
        String ACPT_BANK_NO = MapUtils.getString(rjtMap, "ACPT_BANK_NO");
        String strRmtBankNo;
        String strRmtAcntNo;
        if ("3".equals(MapUtils.getString(rjtMap, "PAY_TYPE")) && "00".equals(SUB_CPY_ID)) {
            DJ_A0Z016_vo dj_A0Z016_vo = DJ_A0Z016.getRmtBankInfoByAcptBankNo(ACPT_BANK_NO, "NTD", true);
            //���ڦ�w�B���O�B�O�_���o�w�]�ץX��w
            strRmtBankNo = dj_A0Z016_vo.getRMT_BANK_NO();
            strRmtAcntNo = dj_A0Z016_vo.getRMT_ACNT_NO();
        } else {
            strRmtBankNo = "";
            strRmtAcntNo = "";
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("ACPT_BANK_NO", ACPT_BANK_NO);
        ds.setField("ACPT_ACNT_NO", MapUtils.getString(rjtMap, "ACPT_ACNT_NO"));
        ds.setField("ACPT_ACNT_NAME", MapUtils.getString(rjtMap, "ACPT_ACNT_NAME"));
        ds.setField("ACPT_ID", MapUtils.getString(rjtMap, "ACPT_ID"));
        ds.setField("RMT_BANK_NO", strRmtBankNo);
        ds.setField("RMT_ACNT_NO", strRmtAcntNo);
        ds.setField("DIV_NO", DIV_NO);
        ds.setField("EMP_ID", EMP_ID);
        ds.setField("EMP_NAME", EMP_NAME);
        ds.setField("INV_NO", MapUtils.getString(rjtMap, "INV_NO"));
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("SER_NO", MapUtils.getString(rjtMap, "SER_NO"));
        DBUtil.executeUpdate(ds, SQL_update_001);
    }

    /**
     * �C�L������
     * 
     * @param reqMap �P�h��T
     * @param invNoMap �o����T
     * @param resp
     * @throws Exception 
     */
    public void print(Map reqMap, Map invNoMap, ResponseContext resp) throws Exception {

        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_003"));//�P�f�h�^���Ӥ��i����
        }
        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22020_MSG_004"));//�o�����Ӥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        //���d
        invNoMap = this.query1(MapUtils.getString(invNoMap, "SUB_CPY_ID"), MapUtils.getString(invNoMap, "INV_NO"), false);

        log.debug("### invNoMap = " + invNoMap);

        List<Map> printList = new ArrayList();
        Map tempMap = new HashMap();
        tempMap.put("INV_NO", MapUtils.getString(invNoMap, "INV_NO"));
        tempMap.put("CASE_TYPE", "C");//�P�h
        tempMap.put("CASE_STATUS", "3");

        //���o�~�W
        if (isDebug) {
            log.debug("### b.PIN_NAME = " + MapUtils.getString(invNoMap, "PIN_NAME"));
            log.debug("### b.PIN_NAME = " + MapUtils.getString(tempMap, "PIN_NAME"));
            log.debug("### b.CASE_MEMO = " + MapUtils.getString(invNoMap, "CASE_MEMO"));
            log.debug("### b.CASE_MEMO = " + MapUtils.getString(tempMap, "CASE_MEMO"));
        }
        new EP_C0Z001().getPIN_NAMEForPrint(invNoMap, tempMap, new StringBuilder(), null);

        //2018-08-29�o�������[�����������
        StringBuilder sb = new StringBuilder();
        String sCASE_MEMO = MapUtils.getString(tempMap, "CASE_MEMO");
        sCASE_MEMO = sb.append(sCASE_MEMO).append(STRING.lineSeparator).append("���������G").append(STRING.lineSeparator).append(DATE.toROCDate(MapUtils.getString(reqMap, "RJT_S_DATE"))).append("-")
                .append(DATE.toROCDate(MapUtils.getString(reqMap, "RJT_E_DATE"))).toString();
        tempMap.put("CASE_MEMO", sCASE_MEMO);

        if (isDebug) {
            log.debug("### a.PIN_NAME = " + MapUtils.getString(invNoMap, "PIN_NAME"));
            log.debug("### a.PIN_NAME = " + MapUtils.getString(tempMap, "PIN_NAME"));
            log.debug("### a.CASE_MEMO = " + MapUtils.getString(invNoMap, "CASE_MEMO"));
            log.debug("### a.CASE_MEMO = " + MapUtils.getString(tempMap, "CASE_MEMO"));
        }

        tempMap.put("USE_TYPE", "EP1");
        tempMap.put("AMT", obj2Decimal(reqMap.get("RJT_AMT"), false).add(obj2Decimal(reqMap.get("RJT_TAX"), false)));
        tempMap.put("TAX_AMT", obj2Decimal(reqMap.get("RJT_TAX"), true));
        tempMap.put("PROD_AMT", obj2Decimal(reqMap.get("RJT_AMT"), true));
        tempMap.put("INV_YM", MapUtils.getString(invNoMap, "RCV_YM"));
        tempMap.put("INV_TP", "07");

        String TAX_TYPE = MapUtils.getString(invNoMap, "TAX_TYPE");
        if ("1".equals(TAX_TYPE) || "2".equals(TAX_TYPE)) {
            tempMap.put("TAX_TP", "1");//���|
        } else if ("3".equals(TAX_TYPE)) {
            tempMap.put("TAX_TP", "2");//�s�|�v
        } else if ("4".equals(TAX_TYPE)) {
            tempMap.put("TAX_TP", "3");//�K�|
        }

        tempMap.put("SELLER_NM", MessageUtil.getMessage("EP_C22020_MSG_008")); //����H��
        tempMap.put("SELLER_BAN", "03374707");
        tempMap.put("BUYER_NM", MapUtils.getString(invNoMap, "CUS_NAME"));
        tempMap.put("BUYER_BAN", MapUtils.getString(invNoMap, "ID"));
        tempMap.put("CE_CURR_TYPE", "NTD");
        tempMap.put("INV_TS", MapUtils.getString(invNoMap, "INV_DATE") + " 00:00:00.000");
        tempMap.put("ORI_INV_TS", MapUtils.getString(invNoMap, "INV_DATE") + " 00:00:00.000");

        printList.add(tempMap);

        Map printMap = new HashMap();
        printMap.put("printList", printList);

        log.debug("### printMap = " + printMap);
        new DD_E0Z006().printRtnRpt(printMap, resp);

    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal obj2Decimal(Object obj, boolean isNull) {
        if (obj == null) {
            if (isNull) {
                return null;
            }
            return BigDecimal.ZERO;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }

        String str = String.valueOf(obj);

        if (StringUtils.isBlank(str)) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal(str);
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
