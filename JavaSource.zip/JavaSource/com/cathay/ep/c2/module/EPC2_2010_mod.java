package com.cathay.ep.c2.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.Id;
import com.cathay.common.util.STRING;

/**
 * DATE Description Author
 * 2013/9/3    Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �o�����ӿ�J�Ҳ�
 * �Ҳ�ID    EP_C22010
 * ���n����    �o�����ӿ�J�Ҳ�
 *
 * @author ����[
 * @since  2013-10-09
 */
@SuppressWarnings("unchecked")
public class EPC2_2010_mod {
    private static final Logger log = Logger.getLogger(EPC2_2010_mod.class);

    /**
     * �s�W����ˮ�
     * @param dataMap   �e��������T
     * @throws ModuleException
     */
    public void checkInsert(Map dataMap) throws ModuleException {

        ErrorInputException eie = null;
        String RCV_YM = null;
        String PIN_CODE = null;
        String SLIP_DATE = null;
        String INV_DATE = null;
        String SUB_CPY_ID = null;
        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_001"));//��J�ѼƤ��o���ŭ�
        } else {
            RCV_YM = MapUtils.getString(dataMap, "RCV_YM");
            PIN_CODE = MapUtils.getString(dataMap, "PIN_CODE");
            SLIP_DATE = MapUtils.getString(dataMap, "SLIP_DATE");
            INV_DATE = MapUtils.getString(dataMap, "INV_DATE");
            SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(RCV_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_002"));//�п�J�����~��
            }
            if (StringUtils.isBlank(PIN_CODE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_003"));//�п�ܫ~�W�N��
            }
            if (StringUtils.isBlank(SLIP_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_005"));//�п�J�ǲ����
            }
            if (StringUtils.isBlank(INV_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_006"));//�п�J�}�ߤ��
            }
        }
        if (eie != null) {
            throw eie;
        }

        String firstDate = DATE.getMonthFirstDate();
        if (firstDate.equals(DATE.getDBDate())) {
            return;
        } else {
            StringBuilder sb = new StringBuilder();
            String INV_AMT = MapUtils.getString(dataMap, "INV_AMT");
            String checkCode = sb.append(RCV_YM).append(PIN_CODE).append(INV_AMT).toString();

            String checkInsert = FieldOptionList.getName("EP", "CHECK_INVNO", checkCode);
            log.error("checkCode>>>>>" + checkCode);
            log.error("checkInsert>>>>>" + checkInsert);
            if (!"Y".equals(checkInsert)) {
                int YearNMonth = Integer.valueOf(DATE.getTodayYearAndMonth());

                if (YearNMonth > Integer.valueOf(RCV_YM)) {
                    throw new ModuleException(MessageUtil.getMessage("EPC2_2010_mod_MSG_007", new Object[] { RCV_YM }));//"�����~��"+dataMap.RCV_YM+"�p��{���~��"  �����~��{0}�p��{���~��
                }
                if (YearNMonth > Integer.valueOf(DATE.getYearAndMonth(INV_DATE))) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_012", new Object[] { INV_DATE }));//"�}�ߦ~��"+dataMap.INV_DATE +"�p��{���~��"  �}�ߦ~��{0}�p��{���~��
                }
                if (eie != null) {
                    throw eie;
                }
            }
        }

        //�ˮֲνs�s�X
        String ID = MapUtils.getString(dataMap, "ID");
        if (StringUtils.isNotEmpty(ID)) {
            this.checkUniSN(ID, true);
        }

        //�ˮ֫~�W�r��
        String PIN_NAME = MapUtils.getString(dataMap, "PIN_NAME");
        if (STRING.doubleByteLength(PIN_NAME) > 200) {
            throw new ModuleException(MessageUtil.getMessage("EPC2_2010_mod_MSG_025"));//�~�W���׹L��

        }

    }

    /**
     * �d�߸���ˮ�
     * @param dataMap    �e��������T
     * @throws ModuleException
     */
    public void checkQuery(Map dataMap) throws ModuleException {
        ErrorInputException eie = null;

        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_001"));//��J�ѼƤ��o���ŭ�
        } else {
            String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        String RCV_YM = MapUtils.getString(dataMap, "RCV_YM");
        String PIN_CODE = MapUtils.getString(dataMap, "PIN_CODE");
        String CUS_NAME = MapUtils.getString(dataMap, "CUS_NAME");

        if ((StringUtils.isBlank(RCV_YM) || StringUtils.isBlank(PIN_CODE)) && StringUtils.isBlank(CUS_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_013"));//"�оܤ@(�����~��Ϋ~�W�N��) �� (�Ȥ�m�W)�@�d��
        } else if (StringUtils.isNotBlank(RCV_YM)) {
            String firstDate = DATE.getMonthFirstDate();
            if (firstDate.equals(DATE.getDBDate())) {
                return;
            } else {
                StringBuilder sb = new StringBuilder();
                String INV_AMT = MapUtils.getString(dataMap, "INV_AMT");
                String checkCode = sb.append(RCV_YM).append(PIN_CODE).append(INV_AMT).toString();

                String checkInsert = FieldOptionList.getName("EP", "CHECK_INVNO", checkCode);
                if (!"Y".equals(checkInsert)) {
                    String YearNMonth = DATE.getTodayYearAndMonth();

                    if (Integer.parseInt(RCV_YM) < Integer.parseInt(YearNMonth)) {
                        eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_008", new Object[] { RCV_YM }));//"�����~��"+dataMap.RCV_YM +"�p��{���~��"  �����~��{0}�j��{���~��
                    }
                    if (Integer.parseInt(RCV_YM.substring(RCV_YM.length() - 2, RCV_YM.length())) > 12) {
                        eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_009", new Object[] { RCV_YM }));//"�����~��"+ dataMap.RCV_YM+"��J���~"  �����~��{0}��J���~
                    }
                }
                if (eie != null) {
                    throw eie;
                }
            }
        }

    }

    /**
     * �ק����ˮ�
     * @param dataMap   �e��������T
     * @throws ModuleException
     */
    public void checkUpdate(Map dataMap) throws ModuleException {
        ErrorInputException eie = null;
        String RCV_YM = null;
        String RCV_YM_OLD = null;
        String PIN_CODE = null;
        String PIN_CODE_OLD = null;
        String CUS_NAME = null;
        String CUS_NAME_OLD = null;
        String INV_DATE = null;
        String INV_NO = null;
        String CHK_NO = null;
        String SUB_CPY_ID = null;
        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_001"));//��J�ѼƤ��o���ŭ�
        } else {
            RCV_YM = MapUtils.getString(dataMap, "RCV_YM");
            RCV_YM_OLD = MapUtils.getString(dataMap, "RCV_YM_OLD");
            PIN_CODE = MapUtils.getString(dataMap, "PIN_CODE");
            PIN_CODE_OLD = MapUtils.getString(dataMap, "PIN_CODE_OLD");
            CUS_NAME = MapUtils.getString(dataMap, "CUS_NAME");
            CUS_NAME_OLD = MapUtils.getString(dataMap, "CUS_NAME_OLD");
            INV_NO = MapUtils.getString(dataMap, "INV_NO");
            INV_DATE = MapUtils.getString(dataMap, "INV_DATE");
            CHK_NO = MapUtils.getString(dataMap, "CHK_NO");
            SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");

            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(RCV_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_002"));//�п�J�����~��
            }
            if (StringUtils.isBlank(RCV_YM_OLD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_014"));//(��)�����~�뤣�i����
            }
            if (StringUtils.isBlank(PIN_CODE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_015"));//�п�J�~�W�N��
            }
            if (StringUtils.isBlank(PIN_CODE_OLD)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_016"));//(��)�~�W�N�����i����
            }
            //if (StringUtils.isBlank(CUS_NAME)) {
            //    eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_017"));//�п�J�Ȥ�m�W
            //}
            //if (StringUtils.isBlank(CUS_NAME_OLD)) {
            //    eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_018"));//(��)�Ȥ�m�W���i����
            //}
            if (StringUtils.isBlank(INV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_019"));//�п�J�o�����X
            }
            if (StringUtils.isBlank(CHK_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_020"));//�п�J�ˬd���X
            }
        }
        if (eie != null) {
            throw eie;
        }

        if (!RCV_YM.equals(RCV_YM_OLD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_021"));//"�����~�뤣�i�ץ�
        }
        if (!PIN_CODE.equals(PIN_CODE_OLD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_022"));//"�~�W�N�����i�ץ�
        }
        if (!StringUtils.contains(CUS_NAME, CUS_NAME_OLD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_023"));//"�Ȥ�W�٤��i�ץ�
        }
        String YearNMonth = DATE.getTodayYearAndMonth();
        if (!YearNMonth.equals(DATE.getYearAndMonth(INV_DATE))) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_012", new Object[] { INV_DATE }));//"�}�ߦ~��"+dataMap.INV_DATE +"������{���~��"  �}�ߦ~��{0}������{���~��
        }

        //�ˮֲνs�s�X
        String ID = MapUtils.getString(dataMap, "ID");
        if (StringUtils.isNotEmpty(ID)) {
            this.checkUniSN(ID, true);
        }

        //�ˬd�o���O�_���L�L
        List<Map> rtnList = new EP_C22010().queryPrt_date(PIN_CODE, CUS_NAME, INV_NO, CHK_NO, SUB_CPY_ID);
        String PRT_DATE = MapUtils.getString(rtnList.get(0), "PRT_DATE");
        if (StringUtils.isNotBlank(PRT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC2_2010_mod_MSG_024"));//"�o���w�C�L���i�ץ�"
        }

        if (eie != null) {
            throw eie;
        }
    }

    /**
     * �νs�ˮ�
     * @param ID
     * @param chkOtheID
     * @throws ModuleException 
     */
    public void checkUniSN(String ID, Boolean chkOtheID) throws ModuleException {
        if (StringUtils.isBlank(ID)) {
            throw new ErrorInputException("�ǤJ�Τ@�s�����i����");
        }

        Id theId = new Id();
        if (!theId.checkUniSN(ID)) {
            String chkIdRes = FieldOptionList.getName("EP", "ERR_UNI_SN", ID);
            if (StringUtils.isEmpty(chkIdRes) || !StringUtils.equals(chkIdRes, "Y")) {
                if (chkOtheID && (!theId.checkID1(ID) || !theId.checkID2(ID))) {
                    throw new ModuleException("�Τ@�s���s�X���~�AID=" + ID);
                } else if (!chkOtheID) {
                    throw new ModuleException("�Τ@�s���s�X���~�AID=" + ID);
                }
            }
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}
