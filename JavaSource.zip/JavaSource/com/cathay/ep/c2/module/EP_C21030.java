package com.cathay.ep.c2.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.z0.module.EP_Z0C203;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * Date Version Description      Author
 * 2013/8/14    1.0 �s�W         �\�a�s
 * 2013/9/12    1.1 �s�W������k  �\�a�s
 *
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �o�����X�޲z�Ҳ�
 * �{���W��    EP_C21030
 *
 * ���n����    ���@DTEPC203_�o�����X�ɸ��
 * 
 * @author ����[
 * @since 2013-10-02
 */
@SuppressWarnings("unchecked")
public class EP_C21030 {

    /** log */
    private static final Logger log = Logger.getLogger(EP_C21030.class);

    private static final String SQL_getInvNo_001 = "com.cathay.ep.c2.module.EP_C21030.SQL_getInvNo_001";

    private static final String SQL_getInvNo_002 = "com.cathay.ep.c2.module.EP_C21030.SQL_getInvNo_002";

    private static final String SQL_getInvNos_001 = "com.cathay.ep.c2.module.EP_C21030.SQL_getInvNos_001";

    private static final String SQL_getInvNos_002 = "com.cathay.ep.c2.module.EP_C21030.SQL_getInvNos_002";

    /**
     * ���o�@�յo�����X�άy����
     * @param SUB_CPY_ID    �����q�N�X
     * @param INV_YM        �o���~��
     * @return  INV_NOs[]
     * @throws ModuleException
     */
    public String[] getInvNo(String SUB_CPY_ID, String INV_YM) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21030_MSG_001"));//�����q�N�X ���i����
        }
        if (StringUtils.isBlank(INV_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21030_MSG_002"));//�o���~�뤣�i����
        }
        if (eie != null) {
            throw eie;
        }

        if (0 == Integer.parseInt(INV_YM) % 2) {
            INV_YM = "" + (Integer.parseInt(INV_YM) - 1);
        }

        BigDecimal iINVNO;
        BigDecimal iSERNO;

        //�d�߸ӵo���~�뤧�o�����X�ɸ��
        EP_Z0C203 mod = new EP_Z0C203();
        Map DTEPC203_VO = mod.queryMap(SUB_CPY_ID, INV_YM);

        BigDecimal INV_SNO_1 = obj2Decimal(DTEPC203_VO.get("INV_SNO_1"), false);
        BigDecimal INV_ENO_1 = obj2Decimal(DTEPC203_VO.get("INV_ENO_1"), false);
        BigDecimal INV_SNO_2 = obj2Decimal(DTEPC203_VO.get("INV_SNO_2"), false);
        BigDecimal INV_ENO_2 = obj2Decimal(DTEPC203_VO.get("INV_ENO_2"), false);
        BigDecimal SEQ_NO_1 = obj2Decimal(DTEPC203_VO.get("SEQ_NO_1"), false);
        BigDecimal SEQ_NO_2 = obj2Decimal(DTEPC203_VO.get("SEQ_NO_2"), false);
        String INV_CD_1 = MapUtils.getString(DTEPC203_VO, "INV_CD_1");
        String INV_CD_2 = MapUtils.getString(DTEPC203_VO, "INV_CD_2");
        BigDecimal INV_LNO_1 = obj2Decimal(DTEPC203_VO.get("INV_LNO_1"), false);
        BigDecimal INV_LNO_2 = obj2Decimal(DTEPC203_VO.get("INV_LNO_2"), false);

        String SER_NO;
        String INV_NO;

        DataSet ds = Transaction.getDataSet();
        StringBuilder sb = new StringBuilder();
        if (INV_LNO_1.compareTo(INV_ENO_1) >= 0) {//�Ĥ@�ճ̫�@�X=�����X:�}�l�ҥγƥεo��
            if (INV_LNO_2.compareTo(INV_ENO_2) >= 0) {
                throw new ModuleException(MessageUtil.getMessage("EP_C21030_MSG_012")); //�ƥεo�����X�w�Χ�
            } else {
                if (INV_LNO_2.compareTo(BigDecimal.ZERO) == 0) {
                    iINVNO = INV_SNO_2;
                    iSERNO = BigDecimal.ONE;
                } else {
                    iINVNO = INV_LNO_2.add(BigDecimal.ONE);
                    iSERNO = SEQ_NO_2.add(BigDecimal.ONE);
                }

                SER_NO = STRING.fillZero(String.valueOf(iSERNO), 5);
                INV_NO = sb.append(INV_CD_2).append(STRING.fillZero(String.valueOf(iINVNO), 8)).toString();
                //��s�o�����X��
                ds.setField("iINVNO", iINVNO);
                ds.setField("iSERNO", iSERNO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                ds.setField("INV_YM", INV_YM);
                DBUtil.executeUpdate(ds, SQL_getInvNo_001);
            }
        } else {
            if (INV_LNO_1.compareTo(BigDecimal.ZERO) == 0) {
                iINVNO = INV_SNO_1;
                iSERNO = BigDecimal.ONE;
            } else {
                iINVNO = INV_LNO_1.add(BigDecimal.ONE);
                iSERNO = SEQ_NO_1.add(BigDecimal.ONE);
            }
            SER_NO = STRING.fillZero(String.valueOf(iSERNO), 5);
            INV_NO = sb.append(INV_CD_1).append(STRING.fillZero(String.valueOf(iINVNO), 8)).toString();

            //��s�o�����X��
            ds.setField("iINVNO", iINVNO);
            ds.setField("iSERNO", iSERNO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("INV_YM", INV_YM);
            DBUtil.executeUpdate(ds, SQL_getInvNo_002);
        }

        return new String[] { INV_NO, SER_NO };
    }

    /**
     * ���o�h�յo�����X�άy����
     * @param SUB_CPY_ID    �����q�N�X
     * @param INV_YM        �o���~��
     * @param num           ��������
     * @return  rtnList
     * @throws ModuleException
     */
    public List<Map> getInvNos(String SUB_CPY_ID, String INV_YM, int num) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21030_MSG_001"));//�����q�N�X ���i����
        }
        if (StringUtils.isBlank(INV_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C21030_MSG_002"));//�o���~�뤣�i����
        }
        if (eie != null) {
            throw eie;
        }

        if (0 == Integer.parseInt(INV_YM) % 2) {
            INV_YM = "" + (Integer.parseInt(INV_YM) - 1);
        }

        //�d�߸ӵo���~�뤧�o�����X�ɸ��
        EP_Z0C203 mod = new EP_Z0C203();
        Map DTEPC203_VO = mod.queryMap(SUB_CPY_ID, INV_YM);

        BigDecimal iINVNO = null;
        BigDecimal iSERNO = null;
        BigDecimal iINVNO1 = null;
        BigDecimal iSERNO1 = null;
        BigDecimal iINVNO2 = null;
        BigDecimal iSERNO2 = null;

        BigDecimal INV_SNO_1 = obj2Decimal(DTEPC203_VO.get("INV_SNO_1"), false);
        BigDecimal INV_ENO_1 = obj2Decimal(DTEPC203_VO.get("INV_ENO_1"), false);
        BigDecimal INV_SNO_2 = obj2Decimal(DTEPC203_VO.get("INV_SNO_2"), false);
        BigDecimal INV_ENO_2 = obj2Decimal(DTEPC203_VO.get("INV_ENO_2"), false);
        BigDecimal SEQ_NO_1 = obj2Decimal(DTEPC203_VO.get("SEQ_NO_1"), false);
        BigDecimal SEQ_NO_2 = obj2Decimal(DTEPC203_VO.get("SEQ_NO_2"), false);
        String INV_CD_1 = MapUtils.getString(DTEPC203_VO, "INV_CD_1");
        String INV_CD_2 = MapUtils.getString(DTEPC203_VO, "INV_CD_2");
        BigDecimal INV_LNO_1 = obj2Decimal(DTEPC203_VO.get("INV_LNO_1"), false);
        BigDecimal INV_LNO_2 = obj2Decimal(DTEPC203_VO.get("INV_LNO_2"), false);

        List<Map> rtnList = new ArrayList<Map>();
        BigDecimal num_bd = new BigDecimal(num);

        DataSet ds = Transaction.getDataSet();

        StringBuilder sb = new StringBuilder();
        if ((INV_LNO_1.add(num_bd)).compareTo(INV_ENO_1) > 0) {//����num_db����|�W�X�Ĥ@�սd��
            BigDecimal num_firstArea = INV_ENO_1.subtract(INV_LNO_1);//�Ĥ@�սd�򤺳Ѫ��i��
            BigDecimal num_secondArea = num_bd.subtract(num_firstArea);//�ϥγƥθ��X���i��
            //�ϥγƥεo�����X
            if ((INV_LNO_2.add(num_secondArea)).compareTo(INV_ENO_2) > 0) {
                throw new ModuleException(MessageUtil.getMessage("EP_C21030_MSG_012")); //�ƥεo�����X�w�Χ�
            } else {
                iINVNO1 = INV_LNO_1;
                iSERNO1 = SEQ_NO_1;
                iINVNO2 = INV_LNO_2;
                iSERNO2 = SEQ_NO_2;
                for (int i = 1; i <= num; i++) {
                    if (iINVNO1.compareTo(INV_ENO_1) < 0) {//�W���̫�@�X�٦b�Ĥ@�սd��
                        if (iINVNO1.compareTo(BigDecimal.ZERO) == 0) {
                            iINVNO1 = INV_SNO_1;
                            iSERNO1 = BigDecimal.ONE;
                        } else {
                            iINVNO1 = iINVNO1.add(BigDecimal.ONE);
                            iSERNO1 = iSERNO1.add(BigDecimal.ONE);
                        }
                        Map tempMap = new HashMap();
                        tempMap.put("SER_NO", STRING.fillZero(String.valueOf(iSERNO1), 5));
                        tempMap.put("INV_NO", sb.append(INV_CD_1).append(STRING.fillZero(String.valueOf(iINVNO1), 8)).toString());
                        sb.setLength(0);
                        rtnList.add(tempMap);
                    } else {
                        if (iINVNO2.compareTo(BigDecimal.ZERO) == 0) {
                            iINVNO2 = INV_SNO_2;
                            iSERNO2 = BigDecimal.ONE;
                        } else {
                            iINVNO2 = iINVNO2.add(BigDecimal.ONE);
                            iSERNO2 = iSERNO2.add(BigDecimal.ONE);
                        }
                        Map tempMap = new HashMap();
                        tempMap.put("SER_NO", STRING.fillZero(String.valueOf(iSERNO2), 5));
                        //sb.delete(0, sb.length());
                        tempMap.put("INV_NO", sb.append(INV_CD_2).append(STRING.fillZero(String.valueOf(iINVNO2), 8)).toString());
                        sb.setLength(0);
                        rtnList.add(tempMap);
                    }
                }
                //��s�o�����X��
                new EP_Z0C203().updInvLNo2(iINVNO1,iSERNO1,iINVNO2,iSERNO2,SUB_CPY_ID,INV_YM,ds);
            }

        } else {
            iINVNO = INV_LNO_1;
            iSERNO = SEQ_NO_1;
            for (int i = 1; i <= num; i++) {
                if (iINVNO.compareTo(BigDecimal.ZERO) == 0) {
                    iINVNO = INV_SNO_1;
                    iSERNO = BigDecimal.ONE;
                } else {
                    iINVNO = iINVNO.add(BigDecimal.ONE);
                    iSERNO = iSERNO.add(BigDecimal.ONE);
                }
                Map tempMap = new HashMap();
                tempMap.put("SER_NO", STRING.fillZero(String.valueOf(iSERNO), 5));
                //sb.delete(0, sb.length());
                tempMap.put("INV_NO", sb.append(INV_CD_1).append(STRING.fillZero(String.valueOf(iINVNO), 8)).toString());
                sb.setLength(0);
                rtnList.add(tempMap);
            }
            //��s�o�����X��
            ds.clear();
            ds.setField("iINVNO", iINVNO);
            ds.setField("iSERNO", iSERNO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("INV_YM", INV_YM);
            DBUtil.executeUpdate(ds, SQL_getInvNos_001);

        }

        return rtnList;
    }

    /**
     * �ˬd���X���o�Ҳ�
     * @param INV_NO    �o�����X
     * @return  CHK_NO  �ˬd���X
     * @throws ErrorInputException
     */
    public String getCHK_NO(String INV_NO) throws ErrorInputException {

        if (StringUtils.isBlank(INV_NO) || INV_NO.length() < 10) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C21030_MSG_013"));//�o�����X���i����
        }

        //�ŧi�ܼ�
        int T1, T2, T3, T4, T5, T6, T7, T8;
        int PRAM1 = 0, PRAM2 = 0;
        double N;
        String tmpN;

        //��ѵo�����X
        String A1 = INV_NO.substring(0, 1);
        String A2 = INV_NO.substring(1, 2);
        String N1 = INV_NO.substring(2, 3);
        String N2 = INV_NO.substring(3, 4);
        String N3 = INV_NO.substring(4, 5);
        String N4 = INV_NO.substring(5, 6);
        String N5 = INV_NO.substring(6, 7);
        String N6 = INV_NO.substring(7, 8);
        String N7 = INV_NO.substring(8, 9);
        String N8 = INV_NO.substring(9, 10);

        //�Ĥ@�X�B�z
        if (("A,J,S").indexOf(A1) >= 0) {
            PRAM1 = 17;
        } else if (("B,K,T").indexOf(A1) >= 0) {
            PRAM1 = 74;
        } else if (("C,L,U").indexOf(A1) >= 0) {
            PRAM1 = 41;
        } else if (("D,M,V").indexOf(A1) >= 0) {
            PRAM1 = 38;
        } else if (("E,N,W").indexOf(A1) >= 0) {
            PRAM1 = 92;
        } else if (("F,O,X").indexOf(A1) >= 0) {
            PRAM1 = 65;
        } else if (("G,P,Y").indexOf(A1) >= 0) {
            PRAM1 = 89;
        } else if (("H,Q,Z").indexOf(A1) >= 0) {
            PRAM1 = 23;
        } else if (("I,R").indexOf(A1) >= 0) {
            PRAM1 = 56;
        }
        //�ѥk�ܥ����Ĥ@�X
        N1 = String.valueOf((Integer.parseInt(N1) + PRAM1) % 10);

        //�ĤG�X�B�z
        if (("A,J,S").indexOf(A2) >= 0) {
            PRAM2 = 75;
        } else if (("B,K,T").indexOf(A2) >= 0) {
            PRAM2 = 42;
        } else if (("C,L,U").indexOf(A2) >= 0) {
            PRAM2 = 18;
        } else if (("D,M,V").indexOf(A2) >= 0) {
            PRAM2 = 86;
        } else if (("E,N,W").indexOf(A2) >= 0) {
            PRAM2 = 29;
        } else if (("F,O,X").indexOf(A2) >= 0) {
            PRAM2 = 53;
        } else if (("G,P,Y").indexOf(A2) >= 0) {
            PRAM2 = 94;
        } else if (("H,Q,Z").indexOf(A2) >= 0) {
            PRAM2 = 37;
        } else if (("I,R").indexOf(A2) >= 0) {
            PRAM2 = 61;
        }
        //�ѥk�ܥ����Ĥ@�X
        N8 = String.valueOf((Integer.parseInt(N8) + PRAM2) % 10);

        T1 = Integer.parseInt(N1) * 8;
        T2 = Integer.parseInt(N2) * 7;
        T3 = Integer.parseInt(N3) * 6;
        T4 = Integer.parseInt(N4) * 5;
        T5 = Integer.parseInt(N5) * 4;
        T6 = Integer.parseInt(N6) * 3;
        T7 = Integer.parseInt(N7) * 2;
        T8 = Integer.parseInt(N8) * 1;

        T1 = (T1 / 10) + (T1 % 10);
        T2 = (T2 / 10) + (T2 % 10);
        T3 = (T3 / 10) + (T3 % 10);
        T4 = (T4 / 10) + (T4 % 10);
        T5 = (T5 / 10) + (T5 % 10);
        T6 = (T6 / 10) + (T6 % 10);
        T7 = (T7 / 10) + (T7 % 10);
        T8 = (T8 / 10) + (T8 % 10);

        N1 = String.valueOf(T1 % 10);
        N2 = String.valueOf(T2 % 10);
        N3 = String.valueOf(T3 % 10);
        N4 = String.valueOf(T4 % 10);
        N5 = String.valueOf(T5 % 10);
        N6 = String.valueOf(T6 % 10);
        N7 = String.valueOf(T7 % 10);
        N8 = String.valueOf(T8 % 10);

        String N_string = new StringBuilder().append(N1).append(N2).append(N3).append(N4).append(N5).append(N6).append(N7).append(N8)
                .toString();
        N = ((Integer.parseInt(N_string) * PRAM1) + PRAM1) * 2;
        //N_string = String.valueOf(N);
        N_string = new BigDecimal(N).toPlainString();
        tmpN = N_string.substring((N_string.length() - 8), N_string.length());

        N1 = tmpN.substring(0, 1);
        N2 = tmpN.substring(1, 2);
        N3 = tmpN.substring(2, 3);
        N4 = tmpN.substring(3, 4);
        N5 = tmpN.substring(4, 5);
        N6 = tmpN.substring(5, 6);
        N7 = tmpN.substring(6, 7);
        N8 = tmpN.substring(7, 8);

        String CHK_NO;
        switch (Integer.parseInt(N6)) {
            case 1:
                CHK_NO = new StringBuilder().append(N5).append(N6).append(N7).append(N8).append(N1).append(N2).append(N3).append(N4)
                        .toString();
                break;
            case 2:
                CHK_NO = new StringBuilder().append(N8).append(N2).append(N3).append(N4).append(N5).append(N6).append(N7).append(N1)
                        .toString();
                break;
            case 3:
                CHK_NO = new StringBuilder().append(N3).append(N2).append(N1).append(N5).append(N4).append(N8).append(N7).append(N6)
                        .toString();
                break;
            case 4:
                CHK_NO = new StringBuilder().append(N2).append(N1).append(N4).append(N3).append(N6).append(N5).append(N8).append(N7)
                        .toString();
                break;
            case 5:
                CHK_NO = new StringBuilder().append(N7).append(N8).append(N5).append(N6).append(N3).append(N4).append(N1).append(N2)
                        .toString();
                break;
            case 6:
                CHK_NO = new StringBuilder().append(N6).append(N7).append(N8).append(N5).append(N4).append(N1).append(N2).append(N3)
                        .toString();
                break;
            case 7:
                CHK_NO = new StringBuilder().append(N7).append(N6).append(N5).append(N4).append(N3).append(N2).append(N1).append(N8)
                        .toString();
                break;
            case 8:
                CHK_NO = new StringBuilder().append(N1).append(N2).append(N8).append(N7).append(N6).append(N5).append(N4).append(N3)
                        .toString();
                break;
            case 9:
                CHK_NO = new StringBuilder().append(N1).append(N5).append(N6).append(N7).append(N2).append(N3).append(N4).append(N8)
                        .toString();
                break;
            case 0:
                CHK_NO = new StringBuilder().append(N1).append(N2).append(N3).append(N4).append(N5).append(N6).append(N7).append(N8)
                        .toString();
                break;
            default:
                CHK_NO = null;
                break;
        }

        return CHK_NO;

    }

    /**
     * ��wEIE���� 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal obj2Decimal(Object obj, boolean isNull) {
        if (obj == null) {
            if (isNull) {
                return null;
            }
            return BigDecimal.ZERO;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }

        String str = String.valueOf(obj);

        if (StringUtils.isBlank(str)) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal(str);
    }

}
