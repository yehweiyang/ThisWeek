package com.cathay.ep.c2.module.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.AuthUtil;
import com.cathay.dd.e0.module.DD_E0Z003;
import com.cathay.ep.c2.module.EP_C22040;
import com.cathay.rpt.RptUtils;
import com.cathay.util.DBTestCase;
import com.cathay.util.Transaction;

public class EP_C22040Test2 extends DBTestCase {
    private static Logger log = Logger.getLogger(EP_C22040Test2.class);

    EP_C22040 theEP_C22040 = new EP_C22040();

    UserObject user;

    public EP_C22040Test2(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testqueryForCSV() {
        log.debug("==============================���� testqueryForCSV �}�l==============================");
        try {
            log.debug("------------------------------�t�V�ר�1���ն}�l------------------------------");
            theEP_C22040.queryForCsv(null);
            log.debug("------------------------------�t�V�ר�1���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�1���զ��\------------------------------");
            log.error("", e);
        }
        try {
            log.debug("------------------------------�t�V�ר�2���ն}�l------------------------------");
            Map reqMap = new HashMap();
            theEP_C22040.queryForCsv(reqMap);
            log.debug("------------------------------�t�V�ר�2���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�2���զ��\------------------------------");
            log.error("", e);
        }
        try {
            log.debug("------------------------------�t�V�ר�3���ն}�l------------------------------");
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", "");
            reqMap.put("ACC_TYPE", "");
            reqMap.put("ACC_ACTION", "");
            theEP_C22040.queryForCsv(reqMap);
            log.debug("------------------------------�t�V�ר�3���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�3���զ��\------------------------------");
            log.error("", e);
        }
        try {
            log.debug("------------------------------�t�V�ר�4���ն}�l------------------------------");
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", "");
            reqMap.put("ACC_TYPE", "");
            reqMap.put("ACC_ACTION", "Y");
            theEP_C22040.queryForCsv(reqMap);
            log.debug("------------------------------�t�V�ר�4���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�4���զ��\------------------------------");
            log.error("", e);
        }
        try {
            log.debug("------------------------------�t�V�ר�5���ն}�l------------------------------");
            Map reqMap = new HashMap();
            reqMap.put("DIV_NO", "8300100");
            reqMap.put("SUB_CPY_ID", "AA");
            reqMap.put("ACC_TYPE", "2");
            reqMap.put("ACC_ACTION", "X");
            reqMap.put("ACNT_DATE", "2017-11-15");
            reqMap.put("SLIP_SET_NO", "1");
            theEP_C22040.queryForCsv(reqMap);
            log.debug("------------------------------�t�V�ר�5���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�5���զ��\------------------------------");
            log.error("", e);
        }

        try {
            log.debug("------------------------------�t�V�ר�6���ն}�l------------------------------");
            Map reqMap = new HashMap();
            reqMap.put("DIV_NO", "8300100");
            reqMap.put("SUB_CPY_ID", "00");
            reqMap.put("ACC_TYPE", "6");
            reqMap.put("ACC_ACTION", "Y");
            reqMap.put("ACNT_TYPE", "1");
            reqMap.put("ACNT_DATE", "2017-07-15");
            theEP_C22040.queryForCsv(reqMap);
            log.debug("------------------------------�t�V�ר�6���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�6���զ��\------------------------------");
            log.error("", e);
        }
        
        try {
            log.debug("------------------------------�t�V�ר�7���ն}�l------------------------------");
            Map reqMap = new HashMap();
            reqMap.put("DIV_NO", "8300100");
            reqMap.put("SUB_CPY_ID", "00");
            reqMap.put("ACC_TYPE", "5");
            reqMap.put("ACC_ACTION", "Y");
            reqMap.put("ACNT_TYPE", "1");
            reqMap.put("ACNT_DATE", "2017-07-15");
            theEP_C22040.queryForCsv(reqMap);
            log.debug("------------------------------�t�V�ר�7���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�7���զ��\------------------------------");
            log.error("", e);
        } 
        try {
            log.debug("------------------------------�t�V�ר�8���ն}�l------------------------------");
            Map reqMap = new HashMap();
            reqMap.put("DIV_NO", "8300100");
            reqMap.put("SUB_CPY_ID", "00");
            reqMap.put("ACC_TYPE", "7");
            reqMap.put("ACC_ACTION", "Y");
            reqMap.put("ACNT_TYPE", "1");
            reqMap.put("ACNT_DATE", "2017-07-15");
            theEP_C22040.queryForCsv(reqMap);
            log.debug("------------------------------�t�V�ר�8���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�8���զ��\------------------------------");
            log.error("", e);
        } 
//        try {
//            log.debug("------------------------------�t�V�ר�9���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACC_TYPE", "4");
//            reqMap.put("ACC_ACTION", "Y");
//            reqMap.put("ACNT_TYPE", "1");
//            reqMap.put("ACNT_DATE", "2017-07-15");
//            theEP_C22040.queryForCsv(reqMap);
//            log.debug("------------------------------�t�V�ר�9���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�9���զ��\------------------------------");
//            log.error("", e);
//        }         
        try {
            log.debug("------------------------------�t�V�ר�10���ն}�l------------------------------");
            Map reqMap = new HashMap();
            reqMap.put("DIV_NO", "8300100");
            reqMap.put("SUB_CPY_ID", "00");
            reqMap.put("ACC_TYPE", "3");
            reqMap.put("ACC_ACTION", "Y");
            reqMap.put("ACNT_TYPE", "1");
            reqMap.put("ACNT_DATE", "2017-07-15");
            theEP_C22040.queryForCsv(reqMap);
            log.debug("------------------------------�t�V�ר�10���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�10���զ��\------------------------------");
            log.error("", e);
        } 
        try {
            log.debug("------------------------------���V�ר�1���ն}�l------------------------------");
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", "00");
            reqMap.put("DIV_NO", "8300100");
            reqMap.put("ACC_TYPE", "1");
            reqMap.put("ACC_ACTION", "Y");
            reqMap.put("ACNT_TYPE", "1");
            reqMap.put("ACNT_DATE", "2018-03-31");
            theEP_C22040.queryForCsv(reqMap);
            log.debug("------------------------------���V�ר�1���զ��\------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------���V�ר�1���ե���------------------------------");
            log.error("", e);
        }
        try {
            log.debug("------------------------------���V�ר�2���ն}�l------------------------------");
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", "00");
            reqMap.put("DIV_NO", "8300100");
            reqMap.put("ACC_TYPE", "4");
            reqMap.put("ACC_ACTION", "Y");
            reqMap.put("ACNT_TYPE", "1");
            reqMap.put("ACNT_DATE", "2018-02-06");
            theEP_C22040.queryForCsv(reqMap);
            log.debug("------------------------------���V�ר�2���զ��\------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------���V�ר�2���ե���------------------------------");
            log.error("", e);
        }
        log.debug("==============================���� testqueryForCSV ����==============================");
    }    
    
    
    
    
    
    
    
//    public void testQuery() {
//        log.debug("==============================���� testQuery �}�l==============================");
//        try {
//            log.debug("------------------------------�t�V�ר�1���ն}�l------------------------------");
//            theEP_C22040.query(null);
//            log.debug("------------------------------�t�V�ר�1���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�1���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�2���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------�t�V�ר�2���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�2���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�3���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "");
//            reqMap.put("SUB_CPY_ID", "");
//            reqMap.put("ACC_TYPE", "");
//            reqMap.put("ACC_ACTION", "");
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------�t�V�ר�3���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�3���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�4���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "");
//            reqMap.put("SUB_CPY_ID", "");
//            reqMap.put("ACC_TYPE", "");
//            reqMap.put("ACC_ACTION", "Y");
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------�t�V�ר�4���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�4���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�5���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACC_TYPE", "2");
//            reqMap.put("ACC_ACTION", "X");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_SET_NO", "1");
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------�t�V�ר�5���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�5���զ��\------------------------------");
//            log.error("", e);
//        }
//
//        try {
//            log.debug("------------------------------�t�V�ר�6���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACC_TYPE", "6");
//            reqMap.put("ACC_ACTION", "Y");
//            reqMap.put("ACNT_TYPE", "1");
//            reqMap.put("ACNT_DATE", "2017-07-15");
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------�t�V�ר�6���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�6���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�1���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACC_TYPE", "1");
//            reqMap.put("ACC_ACTION", "N");
//            reqMap.put("ACNT_TYPE", "1");
//            reqMap.put("ACNT_DATE", "");
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------���V�ר�1���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�1���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�2���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACC_TYPE", "6");
//            reqMap.put("ACC_ACTION", "N");
//            reqMap.put("ACNT_TYPE", "1");
//
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------���V�ר�2���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�2���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�3���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACC_TYPE", "3");
//            reqMap.put("ACC_ACTION", "N");
//            reqMap.put("ACNT_TYPE", "1");
//            reqMap.put("ACNT_DATE", "");
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------���V�ר�3���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�3���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�4���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACC_TYPE", "4");
//            reqMap.put("ACC_ACTION", "N");
//            reqMap.put("ACNT_TYPE", "1");
//            reqMap.put("ACNT_DATE", "");
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------���V�ר�4���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�4���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�5���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACC_TYPE", "5");
//            reqMap.put("ACC_ACTION", "N");
//            reqMap.put("ACNT_TYPE", "1");
//            reqMap.put("ACNT_DATE", "");
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------���V�ר�5���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�5���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�6���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACC_TYPE", "6");
//            reqMap.put("ACC_ACTION", "N");
//            reqMap.put("ACNT_TYPE", "1");
//            reqMap.put("ACNT_DATE", "");
//            theEP_C22040.query(reqMap);
//            log.debug("------------------------------���V�ר�6���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�6���ե���------------------------------");
//            log.error("", e);
//        }
//        /*
//         �s�W�@����� ��   DBEP.DTEPC204 ���F�]�ĤG�ySQL
//        INV_NO  SER_NO  SUB_CPY_ID  RCV_YM  CRT_NO  CUS_NO  CUS_NAME    ID  INV_AMT SAL_AMT TAX_AMT TAX_TYPE    RJT_AMT RJT_TAX RJT_S_DATE  RJT_E_DATE  RJT_RNT_AMT RJT_SPR_AMT RJT_PRPSP_AMT   RJT_C104PRP_AMT R_ACNT_DATE R_ACNT_ID   R_ACNT_NAME R_ACNT_DIV_NO   R_SLPLOT_NO R_SLPSET_NO R_TRNSER_NO PAY_TYPE    ACPT_BANK_NO    ACPT_ACNT_NO    ACPT_ACNT_NAME  ACPT_ID RMT_BANK_NO RMT_ACNT_NO TRN_KIND    CHG_DATE    CHG_DIV_NO  CHG_ID  CHG_NAME
//        PN52313704  1   00  0                                                                                               5                           3                              
//         */
//        log.debug("==============================���� testQuery ����==============================");
//    }
//
//    public void testConfirm() {
//
//        //START_YM = 201712
//        //
//        //      SELECT *
//        //      FROM DBDJ.DTDJB006
//        //      WHERE DATE(INPUT_DATE) > '2017-11-21'
//        //        AND INPUT_ID = 'F28260014E';        
//        //�s��DBDJ�� DTDJB006���屼�~�୫��        
//        log.debug("==============================���� testConfirm �}�l==============================");
//
//        try {
//            log.debug("------------------------------�t�V�ר�1���ն}�l------------------------------");
//            theEP_C22040.confirm(null);
//            log.debug("------------------------------�t�V�ר�1���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�1���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�2���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            theEP_C22040.confirm(reqMap);
//            log.debug("------------------------------�t�V�ר�2���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�2���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�3���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "CP9");
//            theEP_C22040.confirm(reqMap);
//            log.debug("------------------------------�t�V�ר�3���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�3���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�1���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP6");
//            reqMap.put("ACC_TYPE", "4");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.confirm(reqMap);
//            log.debug("------------------------------���V�ר�1���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�1���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�2���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP6");
//            reqMap.put("ACC_TYPE", "3");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.confirm(reqMap);
//            log.debug("------------------------------���V�ר�2���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�2���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�3���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP6");
//            reqMap.put("ACC_TYPE", "5");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.confirm(reqMap);
//            log.debug("------------------------------���V�ר�3���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�3���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�4���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP5");
//            reqMap.put("ACC_TYPE", "2");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.confirm(reqMap);
//            log.debug("------------------------------���V�ר�4���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�4���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�5���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP4");
//            reqMap.put("ACC_TYPE", "1");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.confirm(reqMap);
//            log.debug("------------------------------���V�ר�5���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�5���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�6���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP6");
//            reqMap.put("ACC_TYPE", "6");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.confirm(reqMap);
//            log.debug("------------------------------���V�ר�6���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�6���ե���------------------------------");
//            log.error("", e);
//        }
//        //���V�ר�1 ACC_TYPE =4
//        //INV_NO = QD52314803 RCV_NO = 0020171013387
//        //SQL_CONFIRM_003�d�XSPR_AMT = 0.00 PRP_SP_AMT = 0.00
//        //���F�]�iSQL_CONFIRM_003�d�L��ƪ�����
//        //UPDATE DBEP.DTEPC101
//        //   SET RCV_NO = '1020171013387'
//        // WHERE RCV_NO = '0020171013387'
//        // AND SUB_CPY_ID = '00'
//        //��s�U����ƴN�i�^�_
//        //UPDATE DBEP.DTEPC204
//        //   SET R_ACNT_DATE = null, 
//        //       R_ACNT_ID = null, 
//        //       R_ACNT_NAME = null,
//        //       R_ACNT_DIV_NO = null,
//        //       R_SLPLOT_NO = null,
//        //       R_SLPSET_NO  = null,
//        //       R_TRNSER_NO = null, 
//        //       TRN_KIND = 'EPC203',  
//        //       RJT_RNT_AMT =  1050,
//        //       RJT_SPR_AMT = null,
//        //       RJT_PRPSP_AMT = null,
//        //       RJT_C104PRP_AMT = null
//        // WHERE INV_NO = 'QD52314803' AND SER_NO = 1 AND SUB_CPY_ID = '00'  
//        // ���F�]DD �N C204��INV_NO = 'QD52314803'����ACPT_BANK_NO ='0000000' ACPT_ACNT_NO='0000135790246899' ACPT_ACNT_NAME = '��O�]�ѥ��������q' ACPT_ID = '03374707  '�]����
//        //���V�ר�2 ACC_TYPE =3
//        //INV_NO = QD52314801 RCV_NO = 0020171013385
//        //SQL_CONFIRM_003�d�X SPR_AMT =0.00 PRP_SP_AMT = 98959.00
//        //DTEPC104�s�W�@�����F�]SQL_CONFIRM_005 PRP_AMT���j�I�i���h�������b�ק�
//        //RCV_NO  TRN_YM  PAY_KIND    CRT_NO  CUS_NO  DIV_NO  ID  CUS_NAME    INV_NO  PASS_DAY    PRP_S_DATE  PRP_E_DATE  PRP_AMT EXT_DATE    ACNT_DATE   ACNT_ID ACNT_NAME   ACNT_DIV_NO SLIP_LOT_NO SLIP_SET_NO SUB_CPY_ID  BLD_CD  BLD_USR_ID  BLD_USR_NAME
//        //0020171013385   201710  1   T1st    1   8300100 T1st        QD52314801              2000000.00                      EP6     00             
//        //��s�U����ƴN�i�^�_
//        //     UPDATE DBEP.DTEPC101
//        //        SET PRP_SP_AMT = 98959
//        //      WHERE RCV_NO = '0020171013385'
//        //        AND SUB_CPY_ID = '00'
//        //
//        //        UPDATE DBEP.DTEPC104
//        //        SET PRP_AMT = 2000000
//        //      WHERE RCV_NO = '0020171013385' 
//        //        AND (SLIP_SET_NO = 0 OR SLIP_SET_NO IS NULL) 
//        //        AND SUB_CPY_ID = '00' 
//        //        
//        //        UPDATE DBEP.DTEPC204
//        //        SET R_ACNT_DATE = null, 
//        //            R_ACNT_ID = null, 
//        //            R_ACNT_NAME = null,
//        //            R_ACNT_DIV_NO = null,
//        //            R_SLPLOT_NO = null,
//        //            R_SLPSET_NO  = null,
//        //            R_TRNSER_NO = null, 
//        //            TRN_KIND = 'EPC203',  
//        //            RJT_RNT_AMT =  1050,
//        //            RJT_SPR_AMT = null,
//        //            RJT_PRPSP_AMT = null,
//        //            RJT_C104PRP_AMT = null
//        //      WHERE INV_NO = 'QD52314801' AND SER_NO = 1 AND SUB_CPY_ID = '00'                 
//        //���V�ר�3 ACC_TYPE =5
//        // INV_NO = QD52313671 RCV_NO = 0020171010069
//        //DTEPC104���ηs�W���F�]���iSQL_CONFIRM_005
//        //���F�]�i�j�����s���
//        //UPDATE DBEP.DTEPC101
//        //   SET PRP_SP_AMT = 100000
//        // WHERE RCV_NO = '0020171010069'
//        //   AND SUB_CPY_ID = '00' 
//        //��s�U����ƴN�i�^�_(�W�@�y�]�n��s)
//        //        UPDATE DBEP.DTEPC204
//        //        SET R_ACNT_DATE = null, 
//        //            R_ACNT_ID = null, 
//        //            R_ACNT_NAME = null,
//        //            R_ACNT_DIV_NO = null,
//        //            R_SLPLOT_NO = null,
//        //            R_SLPSET_NO  = null,
//        //            R_TRNSER_NO = null, 
//        //            TRN_KIND = 'EPC203',  
//        //            RJT_RNT_AMT =  1050,
//        //            RJT_SPR_AMT = null,
//        //            RJT_PRPSP_AMT = null,
//        //            RJT_C104PRP_AMT = null,
//        //            RMT_BANK_NO = '0132077', --���Ƭ�0132011
//        //            RMT_ACNT_NO = '0000207030003938'--���Ƭ�135790246899    
//        //      WHERE INV_NO = 'QD52313671' AND SER_NO IN( '1','2') AND SUB_CPY_ID = '00'
//        //���V�ר�4 ACC_TYPE =2
//        //��s�U����ƴN�i�^�_
//        //        UPDATE DBEP.DTEPC202
//        //        SET D_ACNT_DATE = null,
//        //            D_ACNT_ID = null,
//        //            D_ACNT_DIV_NO = null,
//        //            D_SLPLOT_NO = null,
//        //            D_SLPSET_NO = null,
//        //            TRN_KIND = 'EPC204'
//        //      WHERE INV_NO = 'PN52314675' AND SUB_CPY_ID = '00'
//        //���V�ר�5  ACC_TYPE =1
//        //��s�U����ƴN�i�^�_
//        //        UPDATE DBEP.DTEPC202
//        //        SET D_ACNT_DATE = null,
//        //            D_ACNT_ID = null,
//        //            D_ACNT_DIV_NO = null,
//        //            D_SLPLOT_NO = null,
//        //            D_SLPSET_NO = null,
//        //            TRN_KIND = 'EPC204'
//        //     WHERE INV_NO IN ('QU52303717','QU52303719','QU52303727','QU52303729','QU52303776','QU52303785','QU52303810','QU52304098','QU52306297','QU52307715','QU52307716') AND SUB_CPY_ID = '00'
//        //���V�ר�6 ACC_TYPE = 6
//        //INV_NO = PN52313704 RCV_NO = 0020170813440
//        //SQL_CONFIRM_003�d�XSPR_AMT = 0.00 PRP_SP_AMT = 0.00
//        //
//        //INV_NO = QD52314488 RCV_NO = 0020171012491
//        //SQL_CONFIRM_003�d�XSPR_AMT = 0.00 PRP_SP_AMT = 0.00
//        //
//        //INV_NO = QU52307828 RCV_NO = 0020171112206
//        //SQL_CONFIRM_003�d�XSPR_AMT = 3000.00 PRP_SP_AMT = 2286.00        
//        //
//        //��s�U����ƴN�i�^�_
//        //     UPDATE DBEP.DTEPC101
//        //        SET PRP_SP_AMT = 0,
//        //        SPR_AMT = 0
//        //      WHERE RCV_NO = '0020170813440'
//        //        AND SUB_CPY_ID = '00'
//        //
//        //     UPDATE DBEP.DTEPC101
//        //        SET PRP_SP_AMT = 0,
//        //            SPR_AMT = 0
//        //      WHERE RCV_NO = '0020171012491'
//        //        AND SUB_CPY_ID = '00'
//        //
//        //     UPDATE DBEP.DTEPC101
//        //        SET PRP_SP_AMT = 2286,
//        //            SPR_AMT = 3000
//        //      WHERE RCV_NO = '0020171112206'
//        //        AND SUB_CPY_ID = '00'
//        //
//        //        UPDATE DBEP.DTEPC204
//        //        SET R_ACNT_DATE = null, 
//        //            R_ACNT_ID = null, 
//        //            R_ACNT_NAME = null,
//        //            R_ACNT_DIV_NO = null,
//        //            R_SLPLOT_NO = null,
//        //            R_SLPSET_NO  = null,
//        //            R_TRNSER_NO = null, 
//        //            TRN_KIND = '3',  
//        //            RJT_RNT_AMT = null,
//        //            RJT_SPR_AMT = null,
//        //            RJT_PRPSP_AMT = null,
//        //            RJT_C104PRP_AMT = null
//        //      WHERE INV_NO = 'PN52313704' AND SER_NO = 1 AND SUB_CPY_ID = '00'                 
//        //
//        //        UPDATE DBEP.DTEPC204
//        //        SET R_ACNT_DATE = null, 
//        //            R_ACNT_ID = null, 
//        //            R_ACNT_NAME = null,
//        //            R_ACNT_DIV_NO = null,
//        //            R_SLPLOT_NO = null,
//        //            R_SLPSET_NO  = null,
//        //            R_TRNSER_NO = null, 
//        //            TRN_KIND = 'EPC203',  
//        //            RJT_RNT_AMT =  1050,
//        //            RJT_SPR_AMT = null,
//        //            RJT_PRPSP_AMT = null,
//        //            RJT_C104PRP_AMT = null
//        //      WHERE INV_NO = 'QD52314488' AND SER_NO = 1 AND SUB_CPY_ID = '00'                 
//        //
//        //        UPDATE DBEP.DTEPC204
//        //        SET R_ACNT_DATE = null, 
//        //            R_ACNT_ID = null, 
//        //            R_ACNT_NAME = null,
//        //            R_ACNT_DIV_NO = null,
//        //            R_SLPLOT_NO = null,
//        //            R_SLPSET_NO  = null,
//        //            R_TRNSER_NO = null, 
//        //            TRN_KIND = 'EPC203',  
//        //            RJT_RNT_AMT =  3000,
//        //            RJT_SPR_AMT = null,
//        //            RJT_PRPSP_AMT = null,
//        //            RJT_C104PRP_AMT = null
//        //      WHERE INV_NO = 'QU52307828' AND SER_NO = 1 AND SUB_CPY_ID = '00'                 
//        //
//        log.debug("==============================���� testConfirm ����==============================");
//    }
//
//    public void testUnConfirm() {
//
//        log.debug("==============================���� testUnConfirm �}�l==============================");
//        try {
//            log.debug("------------------------------�t�V�ר�1���ն}�l------------------------------");
//            theEP_C22040.unconfirm(null);
//            log.debug("------------------------------�t�V�ר�1���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�1���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�2���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------�t�V�ר�2���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�2���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�3���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EPG");
//            reqMap.put("ACC_TYPE", "1");//�@�o����1(SLN=EPG)�B2(SLN=EPH)�B3(SLN=EPI)�B4(SLN=EPI)�B5(SLN=EPI)�B6(SLN=EPI)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "2");//�b�Ⱥ���2:��鲣�M
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------�t�V�ר�3���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�3���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�4���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EPH");
//            reqMap.put("ACC_TYPE", "2");//�@�o����1(SLN=EPG)�B2(SLN=EPH)�B3(SLN=EPI)�B4(SLN=EPI)�B5(SLN=EPI)�B6(SLN=EPI)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "2");//�b�Ⱥ���2:��鲣�M
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------�t�V�ר�4���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�4���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�5���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EPI");
//            reqMap.put("ACC_TYPE", "3");//�@�o����1(SLN=EPG)�B2(SLN=EPH)�B3(SLN=EPI)�B4(SLN=EPI)�B5(SLN=EPI)�B6(SLN=EPI)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "2");//�b�Ⱥ���2:��鲣�M
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------�t�V�ר�5���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�5���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�6���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EPI");
//            reqMap.put("ACC_TYPE", "4");//�@�o����1(SLN=EPG)�B2(SLN=EPH)�B3(SLN=EPI)�B4(SLN=EPI)�B5(SLN=EPI)�B6(SLN=EPI)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "2");//�b�Ⱥ���2:��鲣�M
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------�t�V�ר�6���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�6���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------�t�V�ר�7���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EPI");
//            reqMap.put("ACC_TYPE", "6");//�@�o����1(SLN=EPG)�B2(SLN=EPH)�B3(SLN=EPI)�B4(SLN=EPI)�B5(SLN=EPI)�B6(SLN=EPI)
//            reqMap.put("ACC_ACTION", "N");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "2");//�b�Ⱥ���2:��鲣�M
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------�t�V�ר�7���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�7���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�1���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP6");
//            reqMap.put("SLIP_SET_NO", "23");//TODO �C�����n��
//            reqMap.put("ACC_TYPE", "4");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "Y");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------���V�ר�1���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�1���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�2���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP6");
//            reqMap.put("SLIP_SET_NO", "24");//TODO �C�����n��
//            reqMap.put("ACC_TYPE", "3");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "Y");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------���V�ר�2���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�2���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�3���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP6");
//            reqMap.put("SLIP_SET_NO", "25");//TODO �C�����n��
//            reqMap.put("ACC_TYPE", "5");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "Y");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------���V�ר�3���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�3���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�4���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP5");
//            reqMap.put("SLIP_SET_NO", "6");//TODO �C�����n��
//            reqMap.put("ACC_TYPE", "2");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "Y");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------���V�ר�4���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�4���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�5���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP4");
//            reqMap.put("SLIP_SET_NO", "6");//TODO �C�����n��
//            reqMap.put("ACC_TYPE", "1");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "Y");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------���V�ר�5���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�5���ե���------------------------------");
//            log.error("", e);
//        }        
//        try {
//            log.debug("------------------------------���V�ר�6���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("EMP_ID", "F28260014E");
//            reqMap.put("EMP_NAME", "�󡳨|");
//            reqMap.put("SUB_CPY_ID", "00");
//            reqMap.put("ACNT_DATE", "2017-11-15");
//            reqMap.put("SLIP_LOT_NO", "EP6");
//            reqMap.put("SLIP_SET_NO", "26");//TODO �C�����n��
//            reqMap.put("ACC_TYPE", "6");//�@�o����1(SLN=EP4)�B2(SLN=EP5)�B3(SLN=EP6)�B4(SLN=EP6)�B5(SLN=EP6)�B6(SLN=EP6)
//            reqMap.put("ACC_ACTION", "Y");//�T�{���pY:�w�X�b�BN:���X�b�BX:�|�p�w�Ю�
//            reqMap.put("ACNT_TYPE", "1");//�b�Ⱥ���1:�@��
//            theEP_C22040.unconfirm(reqMap);
//            log.debug("------------------------------���V�ר�6���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�6���ե���------------------------------");
//            log.error("", e);
//        }
//        
//        /*
//        ���V�ר�1 ACC_TYPE = '4'
//        ����U�y�^�_���iconfirm
//UPDATE DBEP.DTEPC204       
//   SET R_ACNT_DATE = null,
//       R_ACNT_ID = null,
//       R_ACNT_DIV_NO = null,
//       R_SLPLOT_NO = null,
//       R_SLPSET_NO = null,
//       R_TRNSER_NO = null,
//       TRN_KIND = EPC203,
//       RJT_RNT_AMT = 1050,
//       RJT_SPR_AMT = null,
//       RJT_PRPSP_AMT = null,
//       RJT_C104PRP_AMT = null
// WHERE INV_NO = 'QD52314803'
//       AND SER_NO = '1'
//       AND SUB_CPY_ID = '00' 
//              
//         ���V�ר�2 ACC_TYPE = '3'
//         ����U�C�^�_���iconfirm
//UPDATE DBEP.DTEPC101         
//   SET SPR_AMT = 0,
//       PRP_SP_AMT  = 98959 
// WHERE RCV_NO = '0020171013385'
//   AND SUB_CPY_ID = '00'
//
//UPDATE DBEP.DTEPC104      
//   SET PRP_AMT = 2000000  
// WHERE RCV_NO = '0020171013385' 
//   AND (SLIP_SET_NO = 0 OR SLIP_SET_NO IS NULL) 
//   AND SUB_CPY_ID = '00'        
//        
//UPDATE DBEP.DTEPC204       
//   SET R_ACNT_DATE = null,
//       R_ACNT_ID = null,
//       R_ACNT_DIV_NO = null,
//       R_SLPLOT_NO = null,
//       R_SLPSET_NO = null,
//       R_TRNSER_NO = null,
//       TRN_KIND = EPC203,
//       RJT_RNT_AMT = 1050,
//       RJT_SPR_AMT = null,
//       RJT_PRPSP_AMT = null,
//       RJT_C104PRP_AMT = null
// WHERE INV_NO = 'QD52314801'
//       AND SER_NO = '1'
//       AND SUB_CPY_ID = '00' 
//
//         ���V�ר�3 ACC_TYPE = '5'
//         ����U�C�^�_���iconfirm
//UPDATE DBEP.DTEPC101         
//   SET SPR_AMT = 0,
//       PRP_SP_AMT  = 100000 
// WHERE RCV_NO = '0020171010069'
//   AND SUB_CPY_ID = '00'
//   
//UPDATE DBEP.DTEPC204       
//   SET R_ACNT_DATE = null,
//       R_ACNT_ID = null,
//       R_ACNT_DIV_NO = null,
//       R_SLPLOT_NO = null,
//       R_SLPSET_NO = null,
//       R_TRNSER_NO = null,
//       TRN_KIND = EPC203,
//       RJT_RNT_AMT = 1050,
//       RJT_SPR_AMT = null,
//       RJT_PRPSP_AMT = null,
//       RJT_C104PRP_AMT = null
// WHERE INV_NO = 'QD52313671'
//       AND SER_NO IN ('1','2')
//       AND SUB_CPY_ID = '00'    
//   
//         ���V�ר�4 ACC_TYPE = '2'
//         ����U�C�^�_���iconfirm   
//UPDATE DBEP.DTEPC202
//   SET D_ACNT_DATE = NULL,
//       D_ACNT_ID = NULL,
//       D_ACNT_DIV_NO = NULL,
//       D_SLPLOT_NO = NULL,
//       D_SLPSET_NO = NULL,
//       TRN_KIND = 'EPC204'
// WHERE INV_NO = ':PN52314675' AND SUB_CPY_ID = '00'
// 
//         ���V�ר�5 ACC_TYPE = '1'
//         ����U�C�^�_���iconfirm   
//UPDATE DBEP.DTEPC202
//   SET D_ACNT_DATE = NULL,
//       D_ACNT_ID = NULL,
//       D_ACNT_DIV_NO = NULL,
//       D_SLPLOT_NO = NULL,
//       D_SLPSET_NO = NULL,
//       TRN_KIND = 'EPC204'
// WHERE INV_NO IN ('QU52303717','QU52303719','QU52303727','QU52303729','QU52303776','QU52303785','QU52303810','QU52304098','QU52306297','QU52307715','QU52307716') AND SUB_CPY_ID = '00'
//
//         ���V�ר�6 ACC_TYPE = '6'
//         ����U�C�^�_���iconfirm  
//   
//UPDATE DBEP.DTEPC101
//   SET PRP_SP_AMT = 0,
//       SPR_AMT = 0
// WHERE RCV_NO = '0020170813440'
//   AND SUB_CPY_ID = '00'
//
//UPDATE DBEP.DTEPC101
//   SET PRP_SP_AMT = 0,
//       SPR_AMT = 0
// WHERE RCV_NO = '0020171012491'
//   AND SUB_CPY_ID = '00'
//        
//UPDATE DBEP.DTEPC101
//   SET PRP_SP_AMT = 2286,
//       SPR_AMT = 3000
// WHERE RCV_NO = '0020171112206'
//       AND SUB_CPY_ID = '00'   
// 
//UPDATE DBEP.DTEPC204
//   SET R_ACNT_DATE = null, 
//       R_ACNT_ID = null, 
//       R_ACNT_NAME = null,
//       R_ACNT_DIV_NO = null,
//       R_SLPLOT_NO = null,
//       R_SLPSET_NO  = null,
//       R_TRNSER_NO = null, 
//       TRN_KIND = '3',  
//       RJT_RNT_AMT = null,
//       RJT_SPR_AMT = null,
//       RJT_PRPSP_AMT = null,
//       RJT_C104PRP_AMT = null
// WHERE INV_NO = 'PN52313704' AND SER_NO = 1 AND SUB_CPY_ID = '00'                 
// 
//UPDATE DBEP.DTEPC204
//   SET R_ACNT_DATE = null, 
//       R_ACNT_ID = null, 
//       R_ACNT_NAME = null,
//       R_ACNT_DIV_NO = null,
//       R_SLPLOT_NO = null,
//       R_SLPSET_NO  = null,
//       R_TRNSER_NO = null, 
//       TRN_KIND = 'EPC203',  
//       RJT_RNT_AMT =  1050,
//       RJT_SPR_AMT = null,
//       RJT_PRPSP_AMT = null,
//       RJT_C104PRP_AMT = null
// WHERE INV_NO = 'QD52314488' AND SER_NO = 1 AND SUB_CPY_ID = '00'                 
//
//UPDATE DBEP.DTEPC204
//   SET R_ACNT_DATE = null, 
//       R_ACNT_ID = null, 
//       R_ACNT_NAME = null,
//       R_ACNT_DIV_NO = null,
//       R_SLPLOT_NO = null,
//       R_SLPSET_NO  = null,
//       R_TRNSER_NO = null, 
//       TRN_KIND = 'EPC203',  
//       RJT_RNT_AMT =  3000,
//       RJT_SPR_AMT = null,
//       RJT_PRPSP_AMT = null,
//       RJT_C104PRP_AMT = null
// WHERE INV_NO = 'QU52307828' AND SER_NO = 1 AND SUB_CPY_ID = '00'                     
//                 
//        */
//        log.debug("==============================���� testUnConfirm ����==============================");
//    }
//
//    public void testformatInvList() {
//        log.debug("==============================���� testformatInvList �}�l==============================");
//        try {
//            log.debug("------------------------------�t�V�ר�1���ն}�l------------------------------");
//            theEP_C22040.formatInvList(null, null, null);
//            log.debug("------------------------------�t�V�ר�1���ե���------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------�t�V�ר�1���զ��\------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�1���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            Map rtnMap = new HashMap();
//            reqMap.put("EMP_ID", "Y28618123D");
//            reqMap.put("EMP_NAME", "��O�S");
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("ACNT_DATE", "");
//            reqMap.put("SLIP_LOT_NO", "");
//            reqMap.put("SlipSetNo", "");
//            reqMap.put("UserTrnSerno", "");
//
//            rtnMap.put("PIN_NAME", "�X�� �`���q�j��");
//            rtnMap.put("INV_AMT", 3000);
//            rtnMap.put("TAX_AMT", 143);
//            rtnMap.put("SAL_AMT", 2857);
//            rtnMap.put("RCV_YM", 201709);
//            rtnMap.put("INV_NO", "QD52315011");
//            rtnMap.put("TAX_TYPE", "1");
//            rtnMap.put("SER_NO", "12062");
//            rtnMap.put("RJT_PAY_TYPE", "1");
//            //            rtnMap.put("RJT_PAY_TYPE", "2");
//            //            rtnMap.put("RJT_PAY_TYPE", "3");
//            //            rtnMap.put("RJT_PAY_TYPE", "4");
//            //            rtnMap.put("RJT_PAY_TYPE", "5");
//            rtnMap.put("ACPT_ID", "");
//            rtnMap.put("ACPT_ACNT_NAME", "");
//            rtnMap.put("ACPT_BANK_NO", "");
//            rtnMap.put("ACPT_ACNT_NO", "");
//
//            theEP_C22040.formatInvList("B", rtnMap, reqMap);
//            log.debug("------------------------------���V�ר�1���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�1���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�2���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            Map rtnMap = new HashMap();
//            reqMap.put("EMP_ID", "Y28618123D");
//            reqMap.put("EMP_NAME", "��O�S");
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("ACNT_DATE", "");
//            reqMap.put("SLIP_LOT_NO", "");
//            reqMap.put("SlipSetNo", "");
//            reqMap.put("UserTrnSerno", "");
//
//            rtnMap.put("PIN_NAME", "�X�� �`���q�j��");
//            rtnMap.put("INV_AMT", 3000);
//            rtnMap.put("TAX_AMT", 143);
//            rtnMap.put("SAL_AMT", 2857);
//            rtnMap.put("RCV_YM", 201709);
//            rtnMap.put("INV_NO", "QD52315011");
//            rtnMap.put("TAX_TYPE", "1");
//            rtnMap.put("SER_NO", "12062");
//            //            rtnMap.put("RJT_PAY_TYPE", "1");
//            rtnMap.put("RJT_PAY_TYPE", "2");
//            //            rtnMap.put("RJT_PAY_TYPE", "3");
//            //            rtnMap.put("RJT_PAY_TYPE", "4");
//            //            rtnMap.put("RJT_PAY_TYPE", "5");
//            rtnMap.put("ACPT_ID", "");
//            rtnMap.put("ACPT_ACNT_NAME", "");
//            rtnMap.put("ACPT_BANK_NO", "");
//            rtnMap.put("ACPT_ACNT_NO", "");
//            theEP_C22040.formatInvList("C", rtnMap, reqMap);
//            log.debug("------------------------------���V�ר�2���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�2���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�3���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            Map rtnMap = new HashMap();
//            reqMap.put("EMP_ID", "Y28618123D");
//            reqMap.put("EMP_NAME", "��O�S");
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("ACNT_DATE", "");
//            reqMap.put("SLIP_LOT_NO", "");
//            reqMap.put("SlipSetNo", "");
//            reqMap.put("UserTrnSerno", "");
//
//            rtnMap.put("PIN_NAME", "�X�� �`���q�j��");
//            rtnMap.put("INV_AMT", 3000);
//            rtnMap.put("TAX_AMT", 143);
//            rtnMap.put("SAL_AMT", 2857);
//            rtnMap.put("RCV_YM", 201709);
//            rtnMap.put("INV_NO", "QD52315011");
//            rtnMap.put("TAX_TYPE", "1");
//            rtnMap.put("SER_NO", "12062");
//            //            rtnMap.put("RJT_PAY_TYPE", "1");
//            //            rtnMap.put("RJT_PAY_TYPE", "2");
//            rtnMap.put("RJT_PAY_TYPE", "3");
//            //            rtnMap.put("RJT_PAY_TYPE", "4");
//            //            rtnMap.put("RJT_PAY_TYPE", "5");
//            rtnMap.put("ACPT_ID", "");
//            rtnMap.put("ACPT_ACNT_NAME", "");
//            rtnMap.put("ACPT_BANK_NO", "");
//            rtnMap.put("ACPT_ACNT_NO", "");
//            theEP_C22040.formatInvList("C", rtnMap, reqMap);
//            log.debug("------------------------------���V�ר�3���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�3���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�4���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            Map rtnMap = new HashMap();
//            reqMap.put("EMP_ID", "Y28618123D");
//            reqMap.put("EMP_NAME", "��O�S");
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("ACNT_DATE", "");
//            reqMap.put("SLIP_LOT_NO", "");
//            reqMap.put("SlipSetNo", "");
//            reqMap.put("UserTrnSerno", "");
//
//            rtnMap.put("PIN_NAME", "�X�� �`���q�j��");
//            rtnMap.put("INV_AMT", 3000);
//            rtnMap.put("TAX_AMT", 143);
//            rtnMap.put("SAL_AMT", 2857);
//            rtnMap.put("RCV_YM", 201709);
//            rtnMap.put("INV_NO", "QD52315011");
//            rtnMap.put("TAX_TYPE", "1");
//            rtnMap.put("SER_NO", "12062");
//            //            rtnMap.put("RJT_PAY_TYPE", "1");
//            //            rtnMap.put("RJT_PAY_TYPE", "2");
//            //            rtnMap.put("RJT_PAY_TYPE", "3");
//            rtnMap.put("RJT_PAY_TYPE", "4");
//            //            rtnMap.put("RJT_PAY_TYPE", "5");
//            rtnMap.put("ACPT_ID", "");
//            rtnMap.put("ACPT_ACNT_NAME", "");
//            rtnMap.put("ACPT_BANK_NO", "");
//            rtnMap.put("ACPT_ACNT_NO", "");
//            theEP_C22040.formatInvList("C", rtnMap, reqMap);
//            log.debug("------------------------------���V�ר�4���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�4���ե���------------------------------");
//            log.error("", e);
//        }
//        try {
//            log.debug("------------------------------���V�ר�5���ն}�l------------------------------");
//            Map reqMap = new HashMap();
//            Map rtnMap = new HashMap();
//            reqMap.put("EMP_ID", "Y28618123D");
//            reqMap.put("EMP_NAME", "��O�S");
//            reqMap.put("DIV_NO", "8300100");
//            reqMap.put("ACNT_DATE", "");
//            reqMap.put("SLIP_LOT_NO", "");
//            reqMap.put("SlipSetNo", "");
//            reqMap.put("UserTrnSerno", "");
//
//            rtnMap.put("PIN_NAME", "�X�� �`���q�j��");
//            rtnMap.put("INV_AMT", 3000);
//            rtnMap.put("TAX_AMT", 143);
//            rtnMap.put("SAL_AMT", 2857);
//            rtnMap.put("RCV_YM", 201709);
//            rtnMap.put("INV_NO", "QD52315011");
//            rtnMap.put("TAX_TYPE", "1");
//            rtnMap.put("SER_NO", "12062");
//            //            rtnMap.put("RJT_PAY_TYPE", "1");
//            //            rtnMap.put("RJT_PAY_TYPE", "2");
//            //            rtnMap.put("RJT_PAY_TYPE", "3");
//            //            rtnMap.put("RJT_PAY_TYPE", "4");
//            rtnMap.put("RJT_PAY_TYPE", "5");
//            rtnMap.put("ACPT_ID", "");
//            rtnMap.put("ACPT_ACNT_NAME", "");
//            rtnMap.put("ACPT_BANK_NO", "");
//            rtnMap.put("ACPT_ACNT_NO", "");
//            theEP_C22040.formatInvList("C", rtnMap, reqMap);
//            log.debug("------------------------------���V�ר�5���զ��\------------------------------");
//        } catch (Exception e) {
//            log.debug("------------------------------���V�ר�5���ե���------------------------------");
//            log.error("", e);
//        }
//        log.debug("==============================���� testformatInvList ����==============================");
//    }

}
