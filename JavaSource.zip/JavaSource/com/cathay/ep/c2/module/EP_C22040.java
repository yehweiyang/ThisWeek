package com.cathay.ep.c2.module;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.Id;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dd.e0.module.DD_E0Z008;
import com.cathay.dj.b0.module.DJ_B0Z010;
import com.cathay.dj.bo.DTDJB006;
import com.cathay.dj.c0.module.DJ_C0Z032;
import com.cathay.dk.a0.bo.DK_AAZ011_bo;
import com.cathay.dk.a0.module.DK_A0Z003;
import com.cathay.dk.bo.DTDKF001;
import com.cathay.dk.bo.DTDKG002;
import com.cathay.dk.f0.module.DK_F0Z011;
import com.cathay.dk.f0.module.DK_F0Z017;
import com.cathay.dk.g0.module.DK_G0Z002;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.c0.module.EP_C0Z001;
import com.cathay.ep.c2.eInvWsForREM.eInvHelper;
import com.cathay.ep.c2.eInvWsForREM.eInvServiceSoap_PortType;
import com.cathay.ep.c3.module.EP_C30020;
import com.cathay.ep.vo.DTEPC309;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C301;
import com.cathay.ep.z0.module.EP_Z0C309;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE     Description Author
 * 2013/11/12   Created ���|��
 * 2018/02/01   �q�l�o���u��:�վ�~�W�榡 ����[
 * 2018/03/12   ��ؾɤJ ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �o���b�ȳB�z�Ҳ�
 * �Ҳ�ID    EP_C22040
 * ���n����    �o���b�ȳB�z�Ҳ�
 * 
 * 2018/02/01 ���D�B�z:�����g�JDTDDE003���B���~
 * </pre>
 * 
 * [2018-01-24] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * [2018-06-20] �ק��
 * �s�Wmethod queryForCsv �M�ץN�� :P201702080001 
 * 
 * [20200218] �ק�� ����z
 * ��ءG�ɤJ�q�l�o��
 * 
 * @author ����[
 * @since 2013-12-03
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C22040 {

    private static final Logger log = Logger.getLogger(EP_C22040.class);

    private static final String SQL_query_001 = "com.cathay.ep.c2.module.EP_C22040.SQL_query_001";

    private static final String SQL_query_002 = "com.cathay.ep.c2.module.EP_C22040.SQL_query_002";

    private static final String SQL_confirm_001 = "com.cathay.ep.c2.module.EP_C22040.SQL_confirm_001";

    private static final String SQL_confirm_002 = "com.cathay.ep.c2.module.EP_C22040.SQL_confirm_002";

    private static final String SQL_confirm_003 = "com.cathay.ep.c2.module.EP_C22040.SQL_confirm_003";

    private static final String SQL_confirm_004 = "com.cathay.ep.c2.module.EP_C22040.SQL_confirm_004";

    private static final String SQL_confirm_005 = "com.cathay.ep.c2.module.EP_C22040.SQL_confirm_005";

    private static final String SQL_confirm_006 = "com.cathay.ep.c2.module.EP_C22040.SQL_confirm_006";

    private static final String SQL_unconfirm_001 = "com.cathay.ep.c2.module.EP_C22040.SQL_unconfirm_001";

    private static final String SQL_unconfirm_002 = "com.cathay.ep.c2.module.EP_C22040.SQL_unconfirm_002";

    private static final String SQL_unconfirm_003 = "com.cathay.ep.c2.module.EP_C22040.SQL_unconfirm_003";

    private static final String SQL_unconfirm_004 = "com.cathay.ep.c2.module.EP_C22040.SQL_unconfirm_004";

    private static final String SQL_unconfirm_005 = "com.cathay.ep.c2.module.EP_C22040.SQL_unconfirm_005";

    private static final String SQL_query_003 = "com.cathay.ep.c2.module.EP_C22040.SQL_query_003";

    private static final String SQL_queryForCsv_001 = "com.cathay.ep.c2.module.EP_C22040.SQL_queryForCsv_001";

    private static final String SQL_queryForCsv_002 = "com.cathay.ep.c2.module.EP_C22040.SQL_queryForCsv_002";

    /**
     * �d�������ɸ��
     * @param reqMap    �b�ȸ�T
     * @return  resultList
     * @throws ModuleException
     */
    public List<Map> query(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;
        String DIV_NO = null;
        String SUB_CPY_ID = null;
        String ACC_TYPE = null;
        String ACC_ACTION = null;
        String ACNT_DATE = null;
        String SLIP_SET_NO = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_001"));//�b�ȸ�T���i����
        } else {
            DIV_NO = MapUtils.getString(reqMap, "DIV_NO");
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            ACC_TYPE = MapUtils.getString(reqMap, "ACC_TYPE");
            ACC_ACTION = MapUtils.getString(reqMap, "ACC_ACTION");

            if (StringUtils.isBlank(DIV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_002"));//�ӿ��O���������
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_003"));//�����q�O���������
            }
            if (StringUtils.isBlank(ACC_TYPE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_004"));//�@�o�������������
            }
            if (StringUtils.isBlank(ACC_ACTION)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_005"));//�X�b���A���������
            } else if ("Y".equals(ACC_ACTION) || "X".equals(ACC_ACTION)) {
                ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
                SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
                if (StringUtils.isBlank(ACNT_DATE)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_006"));//�ǲ�������������
                }
                //                if (StringUtils.isBlank(SLIP_SET_NO)) {
                //                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_007"));//�ǲ��ո����������
                //                }
            }
        }
        if (eie != null) {
            throw eie;
        }
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        DataSet ds = Transaction.getDataSet();
        //IF�������ɵo��(1)�Ω㯲���o��(2)�hŪ���o����
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //20200212 �W�[�P�_�O�_����T�դH���A��T�դH�����d���
        String isITuser = MapUtils.getString(reqMap, "isITuser", "N");//�O�_����T�ը���
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID) && "N".equals(isITuser)) {//��ؤ��ݥd���
            ds.setField("DIV_NO", DIV_NO);
        }
        if (StringUtils.isNotBlank(ACNT_DATE)) {
            ds.setField("ACNT_DATE", ACNT_DATE);
        } else {
            ds.setField("ACNT_DATE_NULL", "1");
        }
        if (StringUtils.isNotBlank(SLIP_SET_NO)) {
            ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        }
        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else {
            ds.setField("ACNT_TYPE2", "2");
        }
        if ("Y".equals(ACC_ACTION)) {
            ds.setField("ACC_ACTION_Y", "1");
        } else if ("X".equals(ACC_ACTION)) {
            ds.setField("ACC_ACTION_X", "1");
        }
        if ("1".equals(ACC_TYPE) || "2".equals(ACC_TYPE)) {//�����ɵo���@�o�B�㯲���o���@�o
            if ("1".equals(ACC_TYPE)) {
                //20190703���D��s�� 20190703-0092  
                //��ر��v���ʲ��޲z�t�ξɤJ�ɡA�s�Wú�ں���"8�X�����a"�C�b�j�Ӧ����v�@�~(�p��w�P����)�ι�b���Ӫ��ɥ��Nú�ں���"8�X�����a"�����B��i�h�C
                ds.setFieldValues("PAY_KIND", new String[] { "1", "4", "5", "7", "8" });
            } else {
                ds.setFieldValues("PAY_KIND", new String[] { "2" });
            }
            return VOTool.findToMaps(ds, SQL_query_001);
        } else if ("7".equals(ACC_TYPE)) {//�޲z�O�@�o:�q�l�o���}�l��~�u�W�X�b
            ds.setField("RCV_YM", STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO));
            return VOTool.findToMaps(ds, SQL_query_003);
        } else {//�P�h
            ds.setField("RCV_YM", STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO));
            if ("3".equals(ACC_TYPE)) {
                ds.setFieldValues("PAY_TYPE", new String[] { "1" });
            } else if ("4".equals(ACC_TYPE)) {
                ds.setFieldValues("PAY_TYPE", new String[] { "2" });
            } else if ("5".equals(ACC_TYPE)) {
                ds.setFieldValues("PAY_TYPE", new String[] { "3" });
            } else if ("6".equals(ACC_TYPE)) {
                ds.setFieldValues("PAY_TYPE", new String[] { "4", "5" });
            }
            return VOTool.findToMaps(ds, SQL_query_002);
        }
    }

    /*2018-06-20 �M�ץN�� :P201702080001 �s�Wmethod*/
    /**
     * �d�������ɸ��
     * @param reqMap    �b�ȸ�T
     * @return  resultList
     * @throws ModuleException
     */
    public List<Map> queryForCsv(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String ACC_TYPE = null;
        String ACC_ACTION = null;
        String ACNT_DATE = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_001"));//�b�ȸ�T���i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            ACC_TYPE = MapUtils.getString(reqMap, "ACC_TYPE");
            ACC_ACTION = MapUtils.getString(reqMap, "ACC_ACTION");

            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_003"));//�����q�O���������
            }
            if (StringUtils.isBlank(ACC_TYPE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_004"));//�@�o�������������
            }
            if (StringUtils.isBlank(ACC_ACTION)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_005"));//�X�b���A���������
            } else if ("Y".equals(ACC_ACTION)) {
                ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
                if (StringUtils.isBlank(ACNT_DATE)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_026"));//�w�X�b���o���~�i�ץX�C���ɡA�B�b�Ȥ�����i���šC
                }
            }
        }

        if (eie != null) {
            throw eie;
        }
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        DataSet ds = Transaction.getDataSet();
        //IF�������ɵo��(1)�Ω㯲���o��(2)�hŪ���o����
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ��ݥd���
            ds.setField("DIV_NO", reqMap.get("DIV_NO"));
        }
        if (StringUtils.isNotBlank(ACNT_DATE)) {
            ds.setField("ACNT_DATE", ACNT_DATE);
        } else {
            ds.setField("ACNT_DATE_NULL", "1");
        }
        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
        if (StringUtils.isNotBlank(SLIP_SET_NO)) {
            ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        }
        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else {
            ds.setField("ACNT_TYPE2", "2");
        }
        if ("Y".equals(ACC_ACTION)) {
            ds.setField("ACC_ACTION_Y", "1");
        } else if ("X".equals(ACC_ACTION)) {
            ds.setField("ACC_ACTION_X", "1");
        }

        //�����ɵo���@�o�B�㯲���o���@�o
        if ("1".equals(ACC_TYPE) || "2".equals(ACC_TYPE) || "7".equals(ACC_TYPE)) {
            if ("1".equals(ACC_TYPE)) {
                //20190703���D��s�� 20190703-0092  
                //��ر��v���ʲ��޲z�t�ξɤJ�ɡA�s�Wú�ں���"8�X�����a"�C�b�j�Ӧ����v�@�~(�p��w�P����)�ι�b���Ӫ��ɥ��Nú�ں���"8�X�����a"�����B��i�h�C
                ds.setFieldValues("PAY_KIND", new String[] { "1", "4", "5", "7", "8" });
            } else if ("2".equals(ACC_TYPE)) {
                ds.setFieldValues("PAY_KIND", new String[] { "2" });
            } else {
                ds.setFieldValues("PAY_KIND", new String[] { "3" });
            }
            return VOTool.findToMaps(ds, SQL_queryForCsv_001);
        }

        //�P�h�o���hŪ���P�f�h�^��(�@�i�o���i��P�f�h�^�h��)
        ds.setField("RCV_YM", STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO));
        if ("3".equals(ACC_TYPE)) {
            ds.setFieldValues("PAY_TYPE", new String[] { "1" });
        } else if ("4".equals(ACC_TYPE)) {
            ds.setFieldValues("PAY_TYPE", new String[] { "2" });
        } else if ("5".equals(ACC_TYPE)) {
            ds.setFieldValues("PAY_TYPE", new String[] { "3" });
        } else if ("6".equals(ACC_TYPE)) {
            ds.setFieldValues("PAY_TYPE", new String[] { "4", "5" });
        }
        return VOTool.findToMaps(ds, SQL_queryForCsv_002);
    }

    /**
     * �o���@�b�T�{
     * <pre>
     * @param reqMap    �b�ȸ�T
     *      IV_NO       �ӿ��O
     *      ACC_TYPE    �@�o����
     *      ACNT_DATE   �ǲ����
     *      SLIP_SET_NO �ǲ��ո�
     *      ACC_ACTION  �X�b���A
     *      SUB_CPY_ID  �����q�O
     *      EMP_ID      �@�~�H��
     *      EMP_NAME    �@�~�H�m�W
     *      DIV_NAME    ��줤��
     * </pre>
     * @return  SlipSetNo   �b�Ȳո�
     * @throws Exception
     */
    public String confirm(Map reqMap, List<Map> confirmList) throws Exception {

        ErrorInputException eie = null;

        String ACNT_DATE = null;
        if (reqMap == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_001"));//�b�ȸ�T���i����
        } else if (confirmList == null || confirmList.size() == 0) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_001"));//�b�ȸ�T���i����
        } else {
            ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");

            if (StringUtils.isBlank(ACNT_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_006"));//�ǲ�������������
            }
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "SLIP_LOT_NO"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_025"));//�ǲ��帹���������
            }
        }
        if (eie != null) {
            throw eie;
        }

        String DIV_NO = MapUtils.getString(reqMap, "DIV_NO");
        String ACC_TYPE = MapUtils.getString(reqMap, "ACC_TYPE");
        String EMP_ID = MapUtils.getString(reqMap, "EMP_ID");
        String EMP_NAME = MapUtils.getString(reqMap, "EMP_NAME");

        String slipLotNo = MapUtils.getString(reqMap, "SLIP_LOT_NO");
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");

        ReturnMessage rm = new ReturnMessage();
        //�Ǹ�
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

        /* ��ؾɤJ:�Ϥ�call DK�Ҳ� */
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        String slipSetNo = theEP_Z0Z001.getSLIP_SET_NO(SUB_CPY_ID, "2", DIV_NO, null, slipLotNo, ACNT_DATE, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            log.error(rm.getMsgDesc());
            throw new ModuleException("���ǲ��Ǹ����~:" + rm.getMsgDesc());
        }
        reqMap.put("SlipSetNo", slipSetNo);

        //�g�����Ǹ�
        String UserTrnSerno = theEP_Z0Z001.getTRN_SER_NO(SUB_CPY_ID, EMP_ID, ACNT_DATE, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            log.error(rm.getMsgDesc());
            throw new ModuleException(rm.getMsgDesc());
        }
        reqMap.put("UserTrnSerno", UserTrnSerno);

        String trnDate = DATE.getDBTimeStamp();
        if (log.isDebugEnabled())
            log.debug("reqMap:" + reqMap);

        //List<Map> detailList = this.query(reqMap);
        List<Map> detailList = confirmList; //2018-08-29���D��20180507-0063�վ㦨�i�H�h��
        if (log.isDebugEnabled())
            log.debug("detailList:" + detailList);

        String CASE_TYPE = null;
        if ("1".equals(ACC_TYPE) || "2".equals(ACC_TYPE) || "7".equals(ACC_TYPE)) {
            CASE_TYPE = "B";//�@�o
        } else {
            CASE_TYPE = "C";//�P�h
        }
        DataSet ds = Transaction.getDataSet();

        List<DK_AAZ011_bo> DK_AAZ011_bo_List = new ArrayList<DK_AAZ011_bo>();
        List<Map> DTDDE003_List = new ArrayList<Map>();
        BigDecimal START_YM = STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO);
        BigDecimal RCV_YM = BigDecimal.ZERO;
        /* ��ؾɤJ:�Ϥ�call DK�Ҳ� */
        boolean isAccountSubCpy = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);//2018-01-24

        EP_C0Z001 theEP_C0Z001 = new EP_C0Z001();
        EP_Z0C301 theEP_Z0C301 = new EP_Z0C301();
        StringBuilder sb = new StringBuilder();
        Map PIN_NAMEmap = theEP_C0Z001.getPIN_NAMEs(MapUtils.getString(reqMap, "SUB_CPY_ID"), null);
        boolean isSUB_CPY_ID_01 = "01".equals(SUB_CPY_ID); // �O�_�����
        boolean isCASE_TYPE_B = "B".equals(CASE_TYPE);
        boolean isSucess = true; // �P�_�I�s�t��WS�O�_���榨�\
        String errMsg = null;
        eInvHelper theEInvHelper = null;
        eInvServiceSoap_PortType service = null;//�w���ŧiservice�A�קK�C���^�鳣�n�ŧi�@��
        if (isSUB_CPY_ID_01) { //��ؤ~�ݭn�ŧi
            theEInvHelper = new eInvHelper(EMP_ID);
            service = theEInvHelper.initService();
        }
        for (Map rtnMap : detailList) {
            // �g�JDTDDE003�o��������
            // [20200218]�վ�IF���c
            RCV_YM = STRING.objToBigDecimal(rtnMap.get("RCV_YM"), BigDecimal.ZERO);
            String INV_NO = MapUtils.getString(rtnMap, "INV_NO");
            if (RCV_YM.compareTo(START_YM) >= 0) { // �q�l�o��
                if (isAccountSubCpy) { // ���
                    // ��عq�l�o���~�|�g�JDTDDE003�o��������
                    DTDDE003_List.add(this.formatInvList(CASE_TYPE, rtnMap, reqMap, theEP_C0Z001, PIN_NAMEmap, sb));
                } else if (isSUB_CPY_ID_01) { // ���
                    // �I�s�t��WS�@�o�ζ}�ߧ�����
                    if (isCASE_TYPE_B) { // �@�o
                        try {
                            theEInvHelper.cancelInv(rtnMap, service);
                        } catch (Exception e) {
                            // �I�sws�@�o���ѡA�o���s���G{0}�A���~�T���G{1}
                            errMsg = MessageUtil.getMessage("EP_C22040_MSG_027", new String[] { INV_NO, e.getMessage() });
                            log.fatal(errMsg, e);
                            isSucess = false;
                        } catch (Throwable t) {
                            // �I�sws�@�o���ѡA�o���s���G{0}�A���~�T���G{1}
                            errMsg = MessageUtil.getMessage("EP_C22040_MSG_027", new String[] { INV_NO, t.getMessage() });
                            log.fatal(errMsg, t);
                            isSucess = false;
                        }
                    } else {
                        try {
                            theEInvHelper.createAllowance(rtnMap, service);
                        } catch (Exception e) {
                            // �I�sws�P�h���ѡA�o���s���G{0}�A���~�T���G{1}
                            errMsg = MessageUtil.getMessage("EP_C22040_MSG_028", new String[] { INV_NO, e.getMessage() });
                            log.fatal(errMsg, e);
                            isSucess = false;
                        } catch (Throwable t) {
                            //�I�sws�P�h���ѡA�o���s���G{0}�A���~�T���G{1}
                            errMsg = MessageUtil.getMessage("EP_C22040_MSG_028", new String[] { INV_NO, t.getMessage() });
                            log.fatal(errMsg, t);
                            isSucess = false;
                        }
                    }
                }
            }
            if (!isSucess) {
                // �I�sws���ѴN���~�����
                return "rtnMsg:" + errMsg;
            }

            String RCV_NO = MapUtils.getString(rtnMap, "RCV_NO");
            String SER_NO = MapUtils.getString(rtnMap, "RJT_SER_NO");
            List<DK_AAZ011_bo> tmpList = new ArrayList<DK_AAZ011_bo>();

            if ("1".equals(ACC_TYPE)) {//�����o���@�o
                if (isAccountSubCpy) {
                    tmpList = this.formatAcntBo1(rtnMap, ACNT_DATE, slipSetNo, UserTrnSerno, slipLotNo, EMP_ID, EMP_NAME, DIV_NO, trnDate, ACNT_TYPE);
                }

                ds.clear();
                ds.setField("ACNT_DATE", ACNT_DATE);
                ds.setField("EMP_ID", EMP_ID);
                ds.setField("SlipLotNo", slipLotNo);
                ds.setField("SlipSetNo", slipSetNo);
                ds.setField("TrnDate", trnDate);
                ds.setField("DIV_NO", DIV_NO);
                ds.setField("EMP_NAME", EMP_NAME);
                ds.setField("INV_NO", INV_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.executeUpdate(ds, SQL_confirm_001);

            } else if ("2".equals(ACC_TYPE)) {//����o���@�o
                if (isAccountSubCpy) {
                    tmpList = this.formatAcntBo2(rtnMap, ACNT_DATE, slipSetNo, UserTrnSerno, slipLotNo, EMP_ID, EMP_NAME, DIV_NO, trnDate, ACNT_TYPE);
                }

                ds.clear();
                ds.setField("ACNT_DATE", ACNT_DATE);
                ds.setField("DIV_NO", DIV_NO);
                ds.setField("SlipLotNo", slipLotNo);
                ds.setField("SlipSetNo", slipSetNo);
                ds.setField("TrnDate", trnDate);
                ds.setField("DIV_NO", DIV_NO);
                ds.setField("EMP_ID", EMP_ID);
                ds.setField("EMP_NAME", EMP_NAME);
                ds.setField("INV_NO", INV_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.executeUpdate(ds, SQL_confirm_002);

            } else if ("7".equals(ACC_TYPE)) {//�޲z�O�@�o
                if (isAccountSubCpy) {
                    tmpList = this.formatAcntBo4(rtnMap, ACNT_DATE, slipSetNo, UserTrnSerno, slipLotNo, EMP_ID, EMP_NAME, DIV_NO, trnDate, ACNT_TYPE);
                }

                ds.clear();
                ds.setField("ACNT_DATE", ACNT_DATE);
                ds.setField("EMP_ID", EMP_ID);
                ds.setField("SlipLotNo", slipLotNo);
                ds.setField("SlipSetNo", slipSetNo);
                ds.setField("TrnDate", trnDate);
                ds.setField("DIV_NO", DIV_NO);
                ds.setField("EMP_NAME", EMP_NAME);
                ds.setField("INV_NO", INV_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.executeUpdate(ds, SQL_confirm_001);

            } else {//�P�f�h�^

                if (!"2".equals(MapUtils.getString(rtnMap, "PAY_KIND"))) {//�D�㯲���o��: ���o�����P�w���l�B

                    ds.clear();
                    ds.setField("RCV_NO", RCV_NO);
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    int count = DBUtil.searchAndRetrieve(ds, SQL_confirm_003, false);
                    if (count > 0) {
                        ds.next();
                        rtnMap.put("INV_AMT", ds.getField("INV_AMT"));
                        rtnMap.put("C103_RCV_AMT", ds.getField("C103_RCV_AMT"));
                        rtnMap.put("SPR_AMT", ds.getField("SPR_AMT"));
                        rtnMap.put("PRP_SP_AMT", ds.getField("PRP_SP_AMT"));
                    } else {
                        rtnMap.put("INV_AMT", BigDecimal.ZERO);
                        rtnMap.put("C103_RCV_AMT", BigDecimal.ZERO);
                        rtnMap.put("SPR_AMT", BigDecimal.ZERO);
                        rtnMap.put("PRP_SP_AMT", BigDecimal.ZERO);
                    }

                } else {//�㯲���P�h
                    if (!isAccountSubCpy) {//[20200511] �D��ءA�n�^��p���_��(��جO�b�|�p�Ю֮ɦ^��)
                        String C201_PAY_NO = MapUtils.getString(rtnMap, "C201_PAY_NO");
                        String C201_RCV_NO = MapUtils.getString(rtnMap, "C201_RCV_NO");
                        String PMI_S_DATE = MapUtils.getString(rtnMap, "PMI_S_DATE");
                        String PMI_E_DATE = MapUtils.getString(rtnMap, "PMI_E_DATE");
                        theEP_Z0C301.updatePMI_S_DATE(C201_PAY_NO, C201_RCV_NO, SUB_CPY_ID, PMI_S_DATE, PMI_E_DATE);
                    }
                }
                //���o�U�����B
                if (log.isDebugEnabled()) {
                    log.debug("rtnMap = " + rtnMap);
                }
                Map accMap = this.getAccAmts(rtnMap);
                if (log.isDebugEnabled()) {
                    log.debug("accMap = " + accMap);
                }
                BigDecimal rtjC104PrpAmt = BigDecimal.ZERO;

                //�D��ؤ]�n�i�h�A�|�B�z�h�O�J�Ȧ�������
                tmpList = this.formatAcntBo3(accMap, rtnMap, ACNT_DATE, slipSetNo, UserTrnSerno, slipLotNo, EMP_ID, EMP_NAME, DIV_NO, trnDate, ACNT_TYPE, isAccountSubCpy);

                BigDecimal DEL_RCV_AMT = getBigDecimal(accMap.get("DEL_RCV_AMT"), BigDecimal.ZERO);
                BigDecimal DEL_PRP_AMT = getBigDecimal(accMap.get("DEL_PRP_AMT"), BigDecimal.ZERO);

                if (RCV_YM.compareTo(START_YM) < 0 || !isAccountSubCpy) {//�D��عq�l�o���A�^�������l�B�ιw�� (��عq�l�o���ݷ|�p�Ю֫�~��s)

                    if (DEL_RCV_AMT.compareTo(BigDecimal.ZERO) != 0 || DEL_PRP_AMT.compareTo(BigDecimal.ZERO) != 0) {//��s�����ɾl�B
                        ds.clear();
                        ds.setField("DEL_RCV_AMT", DEL_RCV_AMT);
                        ds.setField("DEL_PRP_AMT", DEL_PRP_AMT);
                        ds.setField("RCV_NO", RCV_NO);
                        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                        DBUtil.executeUpdate(ds, SQL_confirm_004);
                    }
                    if (DEL_PRP_AMT.compareTo(BigDecimal.ZERO) != 0) {//��s�w��������������(DTEPC104)
                        ds.clear();
                        ds.setField("DEL_PRP_AMT", DEL_PRP_AMT);
                        ds.setField("RCV_NO", RCV_NO);
                        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                        try {
                            DBUtil.executeUpdate(ds, SQL_confirm_005);
                            rtjC104PrpAmt = getBigDecimal(accMap.get("DEL_PRP_AMT"), BigDecimal.ZERO);
                        } catch (DataNotFoundException dnfe) {
                            log.error("��s�L��ơA�������`");
                        }
                    }
                }

                //��s�P�f�h�^��(DTEPC204)
                ds.clear();
                ds.setField("ACNT_DATE", ACNT_DATE);
                ds.setField("EMP_ID", EMP_ID);
                ds.setField("DIV_NO", DIV_NO);
                ds.setField("SlipLotNo", slipLotNo);
                ds.setField("SlipSetNo", slipSetNo);
                ds.setField("UserTrnSerno", UserTrnSerno);
                ds.setField("RJT_RNT_AMT", getBigDecimal(accMap.get("RJT_RNT_AMT"), BigDecimal.ZERO));
                ds.setField("DEL_RCV_AMT", DEL_RCV_AMT);
                ds.setField("DEL_PRP_AMT", DEL_PRP_AMT);
                ds.setField("rtjC104PrpAmt", rtjC104PrpAmt);
                ds.setField("TrnDate", trnDate);
                ds.setField("DIV_NO", DIV_NO);
                ds.setField("EMP_ID", EMP_ID);
                ds.setField("EMP_NAME", EMP_NAME);
                ds.setField("INV_NO", INV_NO);
                ds.setField("SER_NO", SER_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.executeUpdate(ds, SQL_confirm_006);

            }

            //�N tmpList�����M������[�JDK_AAZ011_bo_List�� 
            DK_AAZ011_bo_List.addAll(tmpList);

        } //FOR

        //��ءGPASS�b�Ȥ鵲�t��
        if (isAccountSubCpy) {

            //��عq�l�o���G�g�JDTDDE003
            //DTDDE003_List���Ȥ~��
            if (DTDDE003_List.size() > 0) {
                Map updE003reqMap = new HashMap();
                updE003reqMap.put("CASE_TYPE", CASE_TYPE);
                new DD_E0Z008().apply_E003ByEP(updE003reqMap, DTDDE003_List);
            }

            if (log.isDebugEnabled()) {
                log.debug("DK_AAZ011_bo_List = " + DK_AAZ011_bo_List);
            }

            new DK_A0Z003().doInsert(DK_AAZ011_bo_List, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                log.error(rm.getMsgDesc());
                //            throw new ModuleException(MessageUtil.getMessage("EP_C22040_MSG_013"));//PASS�b�Ȥ鵲�t�εo�Ϳ��~
                throw new ModuleException(rm.getMsgDesc());
            }

            //�ˮֱb�ȬO�_����
            new DK_F0Z011().isBalance2(DIV_NO, EMP_ID, ACNT_DATE, slipLotNo, slipSetNo, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                log.error(rm.getMsgDesc());
                //            throw new ModuleException(MessageUtil.getMessage("EP_C22040_MSG_014"));//�ˮֱb�ȬO�_���ŵo�Ϳ��~
                throw new ModuleException(rm.getMsgDesc());
            }
        }

        return slipSetNo;

    }

    /**
     * �զ������o���@�o�b�ȸ��
     * @param rtnMap        �o������
     * @param ACNT_DATE     �b�Ȥ��
     * @param SLIP_SET_NO   �ǲ��ո�
     * @param TRN_SER_NO    �g�����Ǹ�
     * @param SLIP_LOT_NO   �ǲ��帹
     * @param EMP_ID        �@�~�H��ID
     * @param EMP_NAME      �@�~�H���m�W
     * @param ACNT_DIV_NO   �@�b���
     * @param TRN_DATE      �@�~�ɶ�
     * @return  rtnList     �o���@�o�X�b���e
     * @throws ModuleException 
     */
    public List<DK_AAZ011_bo> formatAcntBo1(Map rtnMap, String ACNT_DATE, String SLIP_SET_NO, String TRN_SER_NO, String SLIP_LOT_NO, String EMP_ID, String EMP_NAME, String ACNT_DIV_NO, String TRN_DATE, String ACNT_TYPE) throws ModuleException {

        //1 ���O�P�_rtnMap.INV_AMT��rtnMap.TAX_AMT��rtnMap.PRP_SP_AMT��rtnMap.RNT_AMT �O�_�����ťB���B>0�A�Y�����B>0�̫h�U�۲եX���P������DK_AAZ011_bo�å[�JrtnList���C(rtnList���̦h4��DK_AAZ011_bo)

        ErrorInputException eie = null;

        if (rtnMap == null || rtnMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_015"));//�o�����Ӥ��i����
        }
        if (StringUtils.isBlank(ACNT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_016"));//�b�Ȥ�����������
        }
        if (StringUtils.isBlank(SLIP_SET_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_007"));//�ǲ��ո����������
        }
        if (StringUtils.isBlank(TRN_SER_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_017"));//�g�����Ǹ����������
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_018"));//�ǲ��帹���������
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_019"));//�@�~�H��ID���������
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_020"));//�@�~�H���m�W���������
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_021"));//�@�b��쬰�������
        }
        if (StringUtils.isBlank(TRN_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_022"));//�@�~�ɶ����������
        }
        if (eie != null) {
            throw eie;
        }

        String[] amt_type = new String[] { "INV_AMT", "TAX_AMT", "PRP_SP_AMT", "RNT_AMT" };
        String strType = null;
        List<DK_AAZ011_bo> rtnList = new ArrayList<DK_AAZ011_bo>();
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        for (String s_type : amt_type) {
            String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(MapUtils.getString(rtnMap, "SUB_CPY_ID"), MapUtils.getString(rtnMap, "BLD_CD"));
            BigDecimal strAMT = getBigDecimal(rtnMap.get(s_type), BigDecimal.ZERO);
            if (BigDecimal.ZERO.compareTo(strAMT) < 0) {
                if ("INV_AMT".equals(s_type)) {
                    strType = "1";//��L������
                } else if ("TAX_AMT".equals(s_type)) {
                    strType = "2";//�����|��
                } else if ("PRP_SP_AMT".equals(s_type)) {
                    strType = "3";//�w�����J
                } else {
                    strType = "4";//���ʲ��X�����J
                }

                DK_AAZ011_bo DK_AAZ011_bo = new DK_AAZ011_bo();
                DK_AAZ011_bo.setINPUT_ID(EMP_ID);
                DK_AAZ011_bo.setINPUT_NAME(EMP_NAME);
                DK_AAZ011_bo.setTRN_DATE(TRN_DATE);
                DK_AAZ011_bo.setTRN_SER_NO(TRN_SER_NO);
                DK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                DK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);
                DK_AAZ011_bo.setREL_FILE_NO("DTEPC202");
                DK_AAZ011_bo.setACNT_DATE(ACNT_DATE);
                DK_AAZ011_bo.setTRN_KIND("EPC204");
                DK_AAZ011_bo.setMEMO(MapUtils.getString(rtnMap, "INV_NO"));
                DK_AAZ011_bo.setACNT_DIV_NO(ACNT_DIV_NO);
                DK_AAZ011_bo.setKIND_CODE("");
                DK_AAZ011_bo.setCURR("NTD");
                DK_AAZ011_bo.setCNT("1");
                DK_AAZ011_bo.setBUS_CODE("EP");
                DK_AAZ011_bo.setBUS_TRAN_CODE("1");
                DK_AAZ011_bo.setITEM("4");// ���ʲ������o���@�o
                DK_AAZ011_bo.setTYPE(strType);
                DK_AAZ011_bo.setBANK_NO(null);
                DK_AAZ011_bo.setACNT_NO(null);
                DK_AAZ011_bo.setAMT(strAMT.toPlainString());
                DK_AAZ011_bo.setDIV_NO_C101(ACNT_DIV_NO);
                DK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);
                DK_AAZ011_bo.setBAL_TYPE(BAL_TYPE);
                rtnList.add(DK_AAZ011_bo);

            }
        }
        return rtnList;
    }

    /**
     * �զ��㯲�o���@�o�b�ȸ��
     * @param rtnMap        �o������
     * @param ACNT_DATE     �b�Ȥ��
     * @param SLIP_SET_NO   �ǲ��ո�
     * @param TRN_SER_NO    �g�����Ǹ�
     * @param SLIP_LOT_NO   �ǲ��帹
     * @param EMP_ID        �@�~�H��ID
     * @param EMP_NAME      �@�~�H���m�W
     * @param ACNT_DIV_NO   �@�b���
     * @param TRN_DATE      �@�~�ɶ�
     * @return  rtnList     �o���@�o�X�b���e
     * @throws ModuleException 
     */
    public List<DK_AAZ011_bo> formatAcntBo2(Map rtnMap, String ACNT_DATE, String SLIP_SET_NO, String TRN_SER_NO, String SLIP_LOT_NO, String EMP_ID, String EMP_NAME, String ACNT_DIV_NO, String TRN_DATE, String ACNT_TYPE) throws ModuleException {

        //1 ���O�P�_rtnMap.SAL_AMT��rtnMap.TAX_AMT �O�_�����ťB���B>0�A�Y�O�h�̦�2���B�U�۲եX��Ӥ��P������DK_AAZ011_bo�å[�JrtnList��

        ErrorInputException eie = null;

        if (rtnMap == null || rtnMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_015"));//�o�����Ӥ��i����
        }
        if (StringUtils.isBlank(ACNT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_016"));//�b�Ȥ�����������
        }
        if (StringUtils.isBlank(SLIP_SET_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_007"));//�ǲ��ո����������
        }
        if (StringUtils.isBlank(TRN_SER_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_017"));//�g�����Ǹ����������
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_018"));//�ǲ��帹���������
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_019"));//�@�~�H��ID���������
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_020"));//�@�~�H���m�W���������
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_021"));//�@�b��쬰�������
        }
        if (StringUtils.isBlank(TRN_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_022"));//�@�~�ɶ����������
        }
        if (eie != null) {
            throw eie;
        }

        String[] amt_type = new String[] { "SAL_AMT", "TAX_AMT" };
        String[] strType = null;
        List<DK_AAZ011_bo> rtnList = new ArrayList<DK_AAZ011_bo>();
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        for (String s_type : amt_type) {

            String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(MapUtils.getString(rtnMap, "SUB_CPY_ID"), MapUtils.getString(rtnMap, "BLD_CD"));
            BigDecimal strAMT = getBigDecimal(rtnMap.get(s_type), BigDecimal.ZERO);
            if (BigDecimal.ZERO.compareTo(strAMT) < 0) {
                if ("SAL_AMT".equals(s_type)) {
                    strType = new String[] { "1", "3" };//1(�Q����X)�B3(���ʲ����Q�q)
                } else {
                    strType = new String[] { "2", "4" };//2(�޲z�O��)�B4(�P���|�B)
                }

                for (String type : strType) {

                    DK_AAZ011_bo DK_AAZ011_bo = new DK_AAZ011_bo();
                    DK_AAZ011_bo.setINPUT_ID(EMP_ID);
                    DK_AAZ011_bo.setINPUT_NAME(EMP_NAME);
                    DK_AAZ011_bo.setTRN_DATE(TRN_DATE);
                    DK_AAZ011_bo.setTRN_SER_NO(TRN_SER_NO);
                    DK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);
                    DK_AAZ011_bo.setREL_FILE_NO("DTEPC202");
                    DK_AAZ011_bo.setACNT_DATE(ACNT_DATE);
                    DK_AAZ011_bo.setTRN_KIND("EPC204");
                    DK_AAZ011_bo.setMEMO(MapUtils.getString(rtnMap, "INV_NO"));
                    DK_AAZ011_bo.setACNT_DIV_NO(ACNT_DIV_NO);
                    DK_AAZ011_bo.setKIND_CODE("");
                    DK_AAZ011_bo.setCURR("NTD");
                    DK_AAZ011_bo.setCNT("1");
                    DK_AAZ011_bo.setBUS_CODE("EP");
                    DK_AAZ011_bo.setBUS_TRAN_CODE("1");
                    DK_AAZ011_bo.setITEM("5");// ���ʲ��㯲���o���@�o
                    DK_AAZ011_bo.setTYPE(type);
                    DK_AAZ011_bo.setBANK_NO(null);
                    DK_AAZ011_bo.setACNT_NO(null);
                    DK_AAZ011_bo.setAMT(strAMT.toPlainString());
                    DK_AAZ011_bo.setDIV_NO_C101(ACNT_DIV_NO);
                    DK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);
                    DK_AAZ011_bo.setBAL_TYPE(BAL_TYPE);
                    rtnList.add(DK_AAZ011_bo);
                }
            }
        }
        return rtnList;
    }

    /**
     * �զ��޲z�O�o���@�o�b�ȸ��
     * @param rtnMap        �o������
     * @param ACNT_DATE     �b�Ȥ��
     * @param SLIP_SET_NO   �ǲ��ո�
     * @param TRN_SER_NO    �g�����Ǹ�
     * @param SLIP_LOT_NO   �ǲ��帹
     * @param EMP_ID        �@�~�H��ID
     * @param EMP_NAME      �@�~�H���m�W
     * @param ACNT_DIV_NO   �@�b���
     * @param TRN_DATE      �@�~�ɶ�
     * @return  rtnList     �o���@�o�X�b���e
     * @throws ModuleException 
     * @throws ModuleException 
     */
    public List<DK_AAZ011_bo> formatAcntBo4(Map rtnMap, String ACNT_DATE, String SLIP_SET_NO, String TRN_SER_NO, String SLIP_LOT_NO, String EMP_ID, String EMP_NAME, String ACNT_DIV_NO, String TRN_DATE, String ACNT_TYPE) throws ModuleException {
        ErrorInputException eie = null;

        if (rtnMap == null || rtnMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_015"));//�o�����Ӥ��i����
        }
        if (StringUtils.isBlank(ACNT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_016"));//�b�Ȥ�����������
        }
        if (StringUtils.isBlank(SLIP_SET_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_007"));//�ǲ��ո����������
        }
        if (StringUtils.isBlank(TRN_SER_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_017"));//�g�����Ǹ����������
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_018"));//�ǲ��帹���������
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_019"));//�@�~�H��ID���������
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_020"));//�@�~�H���m�W���������
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_021"));//�@�b��쬰�������
        }
        if (StringUtils.isBlank(TRN_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_022"));//�@�~�ɶ����������
        }
        if (eie != null) {
            throw eie;
        }

        String[] amt_type = new String[] { "INV_AMT", "TAX_AMT", "SAL_AMT" };
        String strType = null;
        String strItem = null;
        List<DK_AAZ011_bo> rtnList = new ArrayList<DK_AAZ011_bo>();
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        for (String s_type : amt_type) {
            String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(MapUtils.getString(rtnMap, "SUB_CPY_ID"), MapUtils.getString(rtnMap, "BLD_CD"));
            BigDecimal strAMT = getBigDecimal(rtnMap.get(s_type), BigDecimal.ZERO);
            if (BigDecimal.ZERO.compareTo(strAMT) < 0) {
                if ("INV_AMT".equals(s_type)) {
                    strType = "8";//��L������
                    strItem = "7";
                } else if ("TAX_AMT".equals(s_type)) {
                    strType = "5";//�P���|�B
                    strItem = "4";
                } else {
                    strType = "6";//�������J�@
                    strItem = "4";
                }

                DK_AAZ011_bo DK_AAZ011_bo = new DK_AAZ011_bo();
                DK_AAZ011_bo.setINPUT_ID(EMP_ID);
                DK_AAZ011_bo.setINPUT_NAME(EMP_NAME);
                DK_AAZ011_bo.setTRN_DATE(TRN_DATE);
                DK_AAZ011_bo.setTRN_SER_NO(TRN_SER_NO);
                DK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                DK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);
                DK_AAZ011_bo.setREL_FILE_NO("DTEPC202");
                DK_AAZ011_bo.setACNT_DATE(ACNT_DATE);
                DK_AAZ011_bo.setTRN_KIND("EPC204");
                DK_AAZ011_bo.setMEMO(MapUtils.getString(rtnMap, "INV_NO"));
                DK_AAZ011_bo.setACNT_DIV_NO(ACNT_DIV_NO);
                DK_AAZ011_bo.setKIND_CODE("");
                DK_AAZ011_bo.setCURR("NTD");
                DK_AAZ011_bo.setCNT("1");
                DK_AAZ011_bo.setBUS_CODE("EP");
                DK_AAZ011_bo.setBUS_TRAN_CODE("1");
                DK_AAZ011_bo.setITEM(strItem);
                DK_AAZ011_bo.setTYPE(strType);
                DK_AAZ011_bo.setBANK_NO(null);
                DK_AAZ011_bo.setACNT_NO(null);
                DK_AAZ011_bo.setAMT(strAMT.toPlainString());
                DK_AAZ011_bo.setDIV_NO_C101(ACNT_DIV_NO);
                DK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);
                DK_AAZ011_bo.setBAL_TYPE(BAL_TYPE);
                rtnList.add(DK_AAZ011_bo);

            }
        }
        return rtnList;
    }

    /**
     * ���o�P�h�U�b�Ȫ��B
     * @param invNoMap  �o������
     * @return  accMap  �P�h�X�b���B
     * @throws ErrorInputException 
     */
    public Map getAccAmts(Map invNoMap) throws ErrorInputException {

        ErrorInputException eie = null;

        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_015"));//�o�����Ӥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        //��l�U���X�b���B:
        BigDecimal intAmt = BigDecimal.ZERO;
        BigDecimal intMngAmt = BigDecimal.ZERO;
        BigDecimal pmiAmt = BigDecimal.ZERO;
        BigDecimal pmTax = BigDecimal.ZERO;
        BigDecimal g002Amt = BigDecimal.ZERO;
        BigDecimal rcvAmt = BigDecimal.ZERO;
        BigDecimal cashAmt = BigDecimal.ZERO;
        BigDecimal chkAmt = BigDecimal.ZERO;
        BigDecimal bankAmt1 = BigDecimal.ZERO;
        BigDecimal bankAmt2 = BigDecimal.ZERO;
        BigDecimal salAmt = BigDecimal.ZERO;
        BigDecimal taxAmt = BigDecimal.ZERO;
        BigDecimal prpAmt = BigDecimal.ZERO;
        BigDecimal DEL_RCV_AMT = BigDecimal.ZERO;
        BigDecimal DEL_PRP_AMT = BigDecimal.ZERO;
        BigDecimal rntAmt = BigDecimal.ZERO;
        //�q�l�o��:�s�W�w�ޥX�b
        BigDecimal mngAmt = BigDecimal.ZERO;
        BigDecimal mngTaxAmt = BigDecimal.ZERO;
        BigDecimal mngRjtAmt = BigDecimal.ZERO;

        BigDecimal RJT_AMT = getBigDecimal(invNoMap.get("RJT_AMT"), BigDecimal.ZERO);
        BigDecimal RJT_TAX = getBigDecimal(invNoMap.get("RJT_TAX"), BigDecimal.ZERO);

        //���o�U���X�b���B
        String PAY_KIND = MapUtils.getString(invNoMap, "PAY_KIND");
        if ("2".equals(PAY_KIND)) {
            intAmt = RJT_AMT;
            intMngAmt = RJT_TAX;
            pmiAmt = RJT_AMT;
            pmTax = RJT_TAX;
            rntAmt = RJT_AMT;
        } else if ("3".equals(PAY_KIND)) {//�޲z�O�o��//2018.02.21:�վ�����^�������l�B

            // �޲z�O�����B�J�G�wú����"��X"�ܼȦ� > ����(����/����)
            //�ˮ֡G
            //1.�����q��=inv_amt>0
            //2.�������l�B =���u���Ӫ������������B(�w��+�D�w��)
            //3.�������B<=�o�����B(�w��)
            BigDecimal C103_RCV_AMT = getBigDecimal(invNoMap.get("C103_RCV_AMT"), BigDecimal.ZERO);
            BigDecimal OLD_RJT_AMT = getBigDecimal(invNoMap.get("OLD_RJT_AMT"), BigDecimal.ZERO);
            BigDecimal SPR_AMT = getBigDecimal(invNoMap.get("SPR_AMT"), BigDecimal.ZERO);
            BigDecimal INV_AMT = getBigDecimal(invNoMap.get("INV_AMT"), BigDecimal.ZERO);
            if ((C103_RCV_AMT.subtract(OLD_RJT_AMT)).compareTo(SPR_AMT) != 0) {//�����l�B =���u���Ӫ������������B(�w��+�D�w��)-�w�P�h���B
                throw new ErrorInputException("�޲z�O�o�����������N�wú���B��X!(�����l�B�G" + SPR_AMT + ",���u���������`�B�G" + C103_RCV_AMT + ",�w�������B�G" + OLD_RJT_AMT + ")");
            }
            log.debug("�޲z�O�o��  C103_RCV_AMT:" + C103_RCV_AMT + ",OLD_RJT_AMT:" + OLD_RJT_AMT + ",SPR_AMT:" + SPR_AMT + ",INV_AMT:" + INV_AMT);

            //�����l�B����(�U��)
            if (INV_AMT.compareTo(BigDecimal.ZERO) != 0) {
                if ((RJT_AMT.add(RJT_TAX)).compareTo(INV_AMT) == 0) {
                    DEL_RCV_AMT = RJT_AMT.add(RJT_TAX);
                    mngRjtAmt = DEL_RCV_AMT;
                } else {
                    throw new ErrorInputException("�޲z�O�o���������B����o�����B!(�������B�G" + RJT_AMT + ",�����|�B�G" + RJT_TAX + ",�o�����B�G" + INV_AMT + ")");
                }
            } else {
                throw new ErrorInputException("�޲z�O�o���������t�w�ު��B!(�����l�B�G" + SPR_AMT + ",�o�����B�G" + INV_AMT + ")");
            }

            //�ɤ�
            mngAmt = RJT_AMT;
            mngTaxAmt = RJT_TAX;
            rntAmt = RJT_AMT;

        } else {//�D�㯲���o��

            BigDecimal SPR_AMT = getBigDecimal(invNoMap.get("SPR_AMT"), BigDecimal.ZERO);
            BigDecimal PRP_SP_AMT = getBigDecimal(invNoMap.get("PRP_SP_AMT"), BigDecimal.ZERO);
            log.debug("�D�㯲���o��  SPR_AMT:" + SPR_AMT + ",PRP_SP_AMT: " + PRP_SP_AMT);

            //�����l�B����
            if (SPR_AMT.compareTo(BigDecimal.ZERO) != 0) {
                if (SPR_AMT.compareTo(RJT_AMT.add(RJT_TAX)) > 0) {
                    DEL_RCV_AMT = SPR_AMT;
                } else {
                    DEL_RCV_AMT = RJT_AMT.add(RJT_TAX);
                }
            } else {
                DEL_RCV_AMT = BigDecimal.ZERO;
            }

            //�w���l�B����
            if (PRP_SP_AMT.compareTo(BigDecimal.ZERO) != 0) {
                if (PRP_SP_AMT.compareTo(RJT_AMT) < 0) {
                    DEL_PRP_AMT = PRP_SP_AMT;
                } else {
                    DEL_PRP_AMT = RJT_AMT;
                }
            } else {
                DEL_PRP_AMT = BigDecimal.ZERO;
            }

            if (SPR_AMT.compareTo(BigDecimal.ZERO) > 0) {//��ú��:�䥦������
                rcvAmt = DEL_RCV_AMT;
            }

            log.debug("SPR_AMT: " + SPR_AMT + " RJT_AMT.add(RJT_TAX).subtract(SPR_AMT): " + RJT_AMT.add(RJT_TAX).subtract(SPR_AMT));
            if (SPR_AMT.compareTo(BigDecimal.ZERO) <= 0 || (RJT_AMT.add(RJT_TAX).subtract(SPR_AMT)).compareTo(BigDecimal.ZERO) > 0) {//�wú��:�h�O
                String PAY_TYPE = MapUtils.getString(invNoMap, "RJT_PAY_TYPE");

                if ("4".equals(PAY_TYPE)) {
                    //�Ȧ����B
                    g002Amt = RJT_AMT.add(RJT_TAX).subtract(SPR_AMT);
                } else if ("1".equals(PAY_TYPE)) {
                    //�w�s�{��
                    cashAmt = RJT_AMT.add(RJT_TAX).subtract(SPR_AMT);
                } else if ("2".equals(PAY_TYPE)) {
                    //�䲼���B
                    chkAmt = RJT_AMT.add(RJT_TAX).subtract(SPR_AMT);
                } else if ("3".equals(PAY_TYPE)) {//�״�
                    //�Ȧ�s�ڪ��B
                    bankAmt1 = RJT_AMT.add(RJT_TAX).subtract(SPR_AMT);
                } else {//�P�b
                    bankAmt2 = RJT_AMT.add(RJT_TAX).subtract(SPR_AMT);
                }
            }

            if (PRP_SP_AMT.compareTo(BigDecimal.ZERO) == 0) {//�L�w��
                salAmt = RJT_AMT;
                taxAmt = RJT_TAX;
                rntAmt = RJT_AMT;
            } else {
                prpAmt = DEL_PRP_AMT;
                taxAmt = RJT_TAX;
                BigDecimal RJT_PRP_SP = RJT_AMT.subtract(PRP_SP_AMT);
                if (RJT_PRP_SP.compareTo(BigDecimal.ZERO) > 0) {//�������B-�w���l�B>0(�������B �W�L �w���l�B)
                    salAmt = RJT_PRP_SP;
                    rntAmt = RJT_PRP_SP;
                }
            }

        }
        Map accMap = new HashMap();
        accMap.put("INT_AMT", intAmt);
        accMap.put("INT_MNG_AMT", intMngAmt);
        accMap.put("PMI_AMT", pmiAmt);
        accMap.put("PMI_TAX", pmTax);
        accMap.put("G002_AMT", g002Amt);
        accMap.put("RCV_AMT", rcvAmt);
        accMap.put("CASH_AMT", cashAmt);
        accMap.put("CHK_AMT", chkAmt);
        accMap.put("BANK_AMT1", bankAmt1);
        accMap.put("BANK_AMT2", bankAmt2);
        accMap.put("SAL_AMT", salAmt);
        accMap.put("TAX_AMT", taxAmt);
        accMap.put("PRP_AMT", prpAmt);
        accMap.put("DEL_RCV_AMT", DEL_RCV_AMT);
        accMap.put("DEL_PRP_AMT", DEL_PRP_AMT);
        accMap.put("RJT_RNT_AMT", rntAmt);
        accMap.put("MNG_AMT", mngAmt);
        accMap.put("MNG_TAX_AMT", mngTaxAmt);
        accMap.put("MNG_RJT_AMT", mngRjtAmt);

        return accMap;
    }

    /**
     * �զ��P�h�b�ȸ��
     * @param accMap        �P�h�X�b���B
     * @param invNoMap      �o������
     * @param ACNT_DATE     �b�Ȥ��
     * @param SLIP_SET_NO   �ǲ��ո�
     * @param TRN_SER_NO    �g�����Ǹ�
     * @param SLIP_LOT_NO   �ǲ��帹
     * @param EMP_ID        �@�~�H��ID
     * @param EMP_NAME      �@�~�H���m�W
     * @param ACNT_DIV_NO   �@�b���
     * @param TRN_DATE      �@�~�ɶ�
     * @return  rtnList     �o���@�o�X�b���e
     * @throws Exception 
     */
    public List<DK_AAZ011_bo> formatAcntBo3(Map accMap, Map invNoMap, String ACNT_DATE, String SLIP_SET_NO, String TRN_SER_NO, String SLIP_LOT_NO, String EMP_ID, String EMP_NAME, String ACNT_DIV_NO, String TRN_DATE, String ACNT_TYPE,
            boolean isAccountSubCpy) throws Exception {

        //1 ���O�P�_rtnMap.SAL_AMT��rtnMap.TAX_AMT �O�_�����ťB���B>0�A�Y�O�h�̦�2���B�U�۲եX��Ӥ��P������DK_AAZ011_bo�å[�JrtnList��
        log.debug("formatAcntBo3 accMap:" + accMap + ",invNoMap:" + invNoMap + ",ACNT_DATE:" + ACNT_DATE);
        ErrorInputException eie = null;

        if (accMap == null || accMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_024"));//�P�h�X�b���B���i����
        }
        if (invNoMap == null || invNoMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_015"));//�o�����Ӥ��i����
        }
        if (StringUtils.isBlank(ACNT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_016"));//�b�Ȥ�����������
        }
        if (StringUtils.isBlank(SLIP_SET_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_007"));//�ǲ��ո����������
        }
        if (StringUtils.isBlank(TRN_SER_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_017"));//�g�����Ǹ����������
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_018"));//�ǲ��帹���������
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_019"));//�@�~�H��ID���������
        }
        if (StringUtils.isBlank(EMP_NAME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_020"));//�@�~�H���m�W���������
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_021"));//�@�b��쬰�������
        }
        if (StringUtils.isBlank(TRN_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_022"));//�@�~�ɶ����������
        }
        if (eie != null) {
            throw eie;
        }

        Map typeMap = new HashMap();
        typeMap.put("INT_AMT", "12");
        typeMap.put("INT_MNG_AMT", "7");
        typeMap.put("PMI_AMT", "4");
        typeMap.put("PMI_TAX", "5");

        typeMap.put("RCV_AMT", "6");
        typeMap.put("CASH_AMT", "11");
        typeMap.put("CHK_AMT", "8");
        typeMap.put("BANK_AMT1", "9");
        typeMap.put("SAL_AMT", "1");
        typeMap.put("TAX_AMT", "2");
        typeMap.put("PRP_AMT", "3");
        typeMap.put("G002_AMT", "10");

        typeMap.put("MNG_AMT", "4,6");
        typeMap.put("MNG_TAX_AMT", "4,5");
        typeMap.put("MNG_RJT_AMT", "7,8");

        log.debug("typeMap:" + typeMap);
        String[] AMT_TYPE = new String[] { "INT_AMT", "INT_MNG_AMT", "PMI_AMT", "PMI_TAX", "RCV_AMT", "CASH_AMT", "CHK_AMT", "BANK_AMT1", "SAL_AMT", "TAX_AMT", "PRP_AMT", "G002_AMT", "MNG_AMT", "MNG_TAX_AMT", "MNG_RJT_AMT" };

        ReturnMessage rm = new ReturnMessage();
        DJ_B0Z010 theDJ_B0Z010 = new DJ_B0Z010();
        DJ_C0Z032 theDJ_C0Z032 = new DJ_C0Z032();
        List<DK_AAZ011_bo> rtnList = new ArrayList<DK_AAZ011_bo>();
        String strType = null;
        String strITEM = null;
        StringBuilder sb = new StringBuilder();

        /*2018-06-20 �M�ץN�� :P201702080001 PMD�o�{�Ѽƫŧi�L�ϥζ��K����*/
        Id theID = new Id();
        DK_G0Z002 theDK_G0Z002 = new DK_G0Z002();
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        EP_C30020 theEP_C30020 = new EP_C30020();
        EP_Z0C309 theEP_Z0C309 = new EP_Z0C309();

        for (String amt_type_s : AMT_TYPE) {
            BigDecimal strAmt = getBigDecimal(accMap.get(amt_type_s), BigDecimal.ZERO);
            log.debug("amt_type_s[" + amt_type_s + "] strAmt:" + strAmt);

            if (BigDecimal.ZERO.compareTo(strAmt) < 0) { //AMT���ȱo��

                String CRT_NO = MapUtils.getString(invNoMap, "CRT_NO");
                String CUS_NO = MapUtils.getString(invNoMap, "CUS_NO");
                String BLD_CD = MapUtils.getString(invNoMap, "BLD_CD");
                String ACPT_ID = MapUtils.getString(invNoMap, "ACPT_ID");
                String CUS_NAME = MapUtils.getString(invNoMap, "CUS_NAME");
                String INV_NO = MapUtils.getString(invNoMap, "INV_NO");
                String SUB_CPY_ID = MapUtils.getString(invNoMap, "SUB_CPY_ID");
                //5   ���o�b�U�O
                String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(SUB_CPY_ID, BLD_CD);

                //�g�JDK_AAZ011_bo
                strITEM = "6";
                strType = MapUtils.getString(typeMap, amt_type_s);
                if (strType.contains(",")) {
                    String[] tmpTypeArray = strType.split(",");
                    strITEM = tmpTypeArray[0];
                    strType = tmpTypeArray[1];
                }

                //�Ȧ����B accMap.G002_AMT>0:�Ȧ���ƶ��g�J�Ȧ���DTDKG002
                if ("G002_AMT".equals(amt_type_s)) {

                    DTDKG002 dtdkg002_bo = new DTDKG002();
                    dtdkg002_bo.setSYS_NO("EP");
                    dtdkg002_bo.setTRN_KIND("EPC204");
                    dtdkg002_bo.setTMP_CD("A");
                    if ("8300100".equals(ACNT_DIV_NO)) {
                        dtdkg002_bo.setTMP_KIND("965");
                    } else {
                        dtdkg002_bo.setTMP_KIND("966");
                    }
                    dtdkg002_bo.setINPUT_CD("1");
                    dtdkg002_bo.setACNT_ID(EMP_ID);
                    dtdkg002_bo.setACNT_NAME(EMP_NAME);
                    dtdkg002_bo.setACNT_IN_DATE(ACNT_DATE + " 00:00:00.000");
                    dtdkg002_bo.setACNT_SER_NO(TRN_SER_NO);
                    dtdkg002_bo.setACNT_DIV_NO(ACNT_DIV_NO);
                    //String ACNT_DIV_NAME = theDivData.getUnit4ShortName(ACNT_DIV_NO);
                    //2018-03-13 �վ���W�٧���Ҳ�
                    String ACNT_DIV_NAME = new EP_A10010().getDivName(ACNT_DIV_NO, SUB_CPY_ID);
                    if (StringUtils.isNotBlank(ACNT_DIV_NAME)) {
                        dtdkg002_bo.setACNT_DIV_NAME(ACNT_DIV_NAME);
                    } else {
                        dtdkg002_bo.setACNT_DIV_NAME("");
                    }
                    dtdkg002_bo.setACNT_DATE(ACNT_DATE);
                    dtdkg002_bo.setSLIP_DATE(ACNT_DATE);
                    dtdkg002_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                    dtdkg002_bo.setSLIP_SET_NO(SLIP_SET_NO);
                    String tmp = strAmt.toPlainString();
                    dtdkg002_bo.setACNT_AMT(tmp);
                    dtdkg002_bo.setBAL_AMT(tmp);
                    dtdkg002_bo.setTMP_IN_CD("C");//�P�f�h�^
                    dtdkg002_bo.setRESN_NO("99");
                    dtdkg002_bo.setRESN_NAME("�P�f�h�^");
                    dtdkg002_bo.setLST_CHG_DIV(ACNT_DIV_NO);
                    dtdkg002_bo.setLST_CHG_ID(EMP_ID);
                    dtdkg002_bo.setLST_CHG_DATE(TRN_DATE);
                    dtdkg002_bo.setPOLICY_NO(CRT_NO);
                    dtdkg002_bo.setPAY_TIMES(CUS_NO);
                    dtdkg002_bo.setAPLY_NO(BLD_CD);
                    String id = MapUtils.getString(invNoMap, "ID");
                    if (StringUtils.isNotEmpty(id) && id.length() == 10 && theID.checkID1(id)) {
                        dtdkg002_bo.setID_KIND("1");
                    } else if (theID.checkUniSN(id)) {
                        dtdkg002_bo.setID_KIND("3");
                    } else {
                        dtdkg002_bo.setID_KIND("2");
                    }
                    dtdkg002_bo.setID(id);
                    dtdkg002_bo.setCST_NAME(CUS_NAME);
                    dtdkg002_bo.setMEMO(INV_NO);
                    dtdkg002_bo.setCURR("NTD");

                    //�]�w�Ȧ��b�U�O
                    theEP_C30020.setBAL_TYPEforDKG002(dtdkg002_bo, BAL_TYPE);

                    log.debug("theDK_G0Z002.insertDTDKG002ForXA tdkg002_bo:" + dtdkg002_bo);
                    if (isAccountSubCpy) {
                        theDK_G0Z002.insertDTDKG002ForXA(dtdkg002_bo, rm);
                        if (rm.getReturnCode() != ReturnCode.OK) {
                            throw new ModuleException(rm.getMsgDesc());
                        }
                    } else {
                        //[20180227]�D��ا�gEP.�Ȧ���  
                        DTEPC309 C309 = new DTEPC309();
                        VOTool.copyVOFromTo(dtdkg002_bo, C309);
                        C309.setLST_CHG_DATE(DATE.currentTime());
                        C309.setACNT_IN_DATE(DATE.currentTime());
                        C309.setSUB_CPY_ID(SUB_CPY_ID);
                        theEP_Z0C309.insertDTEPC309(C309);
                    }
                    //end G002_AMT
                } else if (isAccountSubCpy) {

                    DK_AAZ011_bo DK_AAZ011_bo = new DK_AAZ011_bo();
                    DK_AAZ011_bo.setINPUT_ID(EMP_ID);
                    DK_AAZ011_bo.setINPUT_NAME(EMP_NAME);
                    DK_AAZ011_bo.setTRN_DATE(TRN_DATE);
                    DK_AAZ011_bo.setTRN_SER_NO(TRN_SER_NO);
                    DK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);
                    DK_AAZ011_bo.setREL_FILE_NO("DTEPC202");
                    DK_AAZ011_bo.setACNT_DATE(ACNT_DATE);
                    DK_AAZ011_bo.setTRN_KIND("EPC204");
                    DK_AAZ011_bo.setMEMO(INV_NO);
                    DK_AAZ011_bo.setACNT_DIV_NO(ACNT_DIV_NO);
                    DK_AAZ011_bo.setDIV_NO_C101(ACNT_DIV_NO);
                    DK_AAZ011_bo.setKIND_CODE("");
                    DK_AAZ011_bo.setCURR("NTD");
                    DK_AAZ011_bo.setCNT("1");
                    DK_AAZ011_bo.setBUS_CODE("EP");
                    DK_AAZ011_bo.setBUS_TRAN_CODE("1");
                    DK_AAZ011_bo.setITEM(strITEM);// ���ʲ��P�f�h�^
                    DK_AAZ011_bo.setTYPE(strType);
                    if ("CHK_AMT".equals(amt_type_s)) {
                        Map ACNT_MAP = theDJ_C0Z032.getChkAcntInfo(ACNT_DIV_NO, rm);
                        DK_AAZ011_bo.setBANK_NO(MapUtils.getString(ACNT_MAP, "BANK_NO"));
                        DK_AAZ011_bo.setACNT_NO(MapUtils.getString(ACNT_MAP, "ACNT_NO"));
                    } else {
                        DK_AAZ011_bo.setBANK_NO(MapUtils.getString(invNoMap, "RMT_BANK_NO"));
                        DK_AAZ011_bo.setACNT_NO(MapUtils.getString(invNoMap, "RMT_ACNT_NO"));
                    }
                    DK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);
                    DK_AAZ011_bo.setAMT(strAmt.toPlainString());
                    DK_AAZ011_bo.setBAL_TYPE(BAL_TYPE);
                    log.debug("DK_AAZ011_bo:"+DK_AAZ011_bo);
                    rtnList.add(DK_AAZ011_bo);

                    if ("CHK_AMT".equals(amt_type_s) || "BANK_AMT1".equals(amt_type_s) || "CASH_AMT".equals(amt_type_s)) {
                        DTDJB006 dtdjb006_bo = new DTDJB006();

                        if ("CHK_AMT".equals(amt_type_s)) { //CHK_AMT �g�Jdtdjb006_bo
                            dtdjb006_bo.setCHK_KIND("1");
                            dtdjb006_bo.setPAY_TYPE("3");//�䲼
                            dtdjb006_bo.setRMT_BANK_NO("");
                            dtdjb006_bo.setRMT_ACNT_NO("");
                            dtdjb006_bo.setACPT_BANK_NO("");
                            dtdjb006_bo.setACPT_ACNT_NO("");
                            dtdjb006_bo.setACPT_KIND("C");//�䲼
                        } else if ("CASH_AMT".equals(amt_type_s)) {
                            dtdjb006_bo.setCHK_KIND("");
                            dtdjb006_bo.setPAY_TYPE("2");//�{��
                            dtdjb006_bo.setRMT_BANK_NO("");
                            dtdjb006_bo.setRMT_ACNT_NO("");
                            dtdjb006_bo.setACPT_BANK_NO("");
                            dtdjb006_bo.setACPT_ACNT_NO("");
                            dtdjb006_bo.setACPT_KIND("3");//��{��                         
                        } else { //BANK_AMT1 �g�Jdtdjb006_bo
                            dtdjb006_bo.setCHK_KIND("1");
                            dtdjb006_bo.setPAY_TYPE("1");//�״�
                            dtdjb006_bo.setRMT_BANK_NO(MapUtils.getString(invNoMap, "RMT_BANK_NO"));
                            dtdjb006_bo.setRMT_ACNT_NO(MapUtils.getString(invNoMap, "RMT_ACNT_NO"));
                            dtdjb006_bo.setACPT_BANK_NO(MapUtils.getString(invNoMap, "ACPT_BANK_NO"));
                            dtdjb006_bo.setACPT_ACNT_NO(MapUtils.getString(invNoMap, "ACPT_ACNT_NO"));
                            dtdjb006_bo.setACPT_KIND("2");//�ӤH��
                        }

                        dtdjb006_bo.setPAY_DIV_NO(ACNT_DIV_NO);

                        dtdjb006_bo.setPAY_AMT(strAmt.toPlainString());
                        dtdjb006_bo.setNET_PAY_AMT(strAmt.toPlainString());
                        dtdjb006_bo.setPAY_DATE(ACNT_DATE);
                        dtdjb006_bo.setPAY_KIND("03");//���ʲ��P�f�h�O
                        dtdjb006_bo.setAPLY_NO(INV_NO);
                        dtdjb006_bo.setPOLICY_NO(CRT_NO + CUS_NO);
                        dtdjb006_bo.setSYS_NO("P");
                        dtdjb006_bo.setTAX_AMT("0");
                        dtdjb006_bo.setCLC_NO("");
                        dtdjb006_bo.setAGNT_ID(EMP_ID);
                        dtdjb006_bo.setAGNT_NAME(EMP_NAME);
                        dtdjb006_bo.setACPT_DIV_NO(ACNT_DIV_NO);
                        dtdjb006_bo.setACPT_ACNT_NAME(MapUtils.getString(invNoMap, "ACPT_ACNT_NAME"));
                        dtdjb006_bo.setACPT_ACNT_NPRT("");
                        dtdjb006_bo.setACPT_NAME(MapUtils.getString(invNoMap, "ACPT_ACNT_NAME"));
                        dtdjb006_bo.setACPT_NPRT("");
                        if (StringUtils.isNotEmpty(ACPT_ID) && ACPT_ID.length() == 10 && theID.checkID1(ACPT_ID)) {
                            dtdjb006_bo.setID_KIND("1");
                        } else if (theID.checkUniSN(ACPT_ID)) {
                            dtdjb006_bo.setID_KIND("3");
                        } else {
                            dtdjb006_bo.setID_KIND("2");
                        }
                        dtdjb006_bo.setID(ACPT_ID);
                        dtdjb006_bo.setMEMO("�P�f�h�^");
                        dtdjb006_bo.setAPLY_DIV_NO(ACNT_DIV_NO);
                        dtdjb006_bo.setINPUT_DATE(TRN_DATE);
                        dtdjb006_bo.setINPUT_ID(EMP_ID);
                        dtdjb006_bo.setINPUT_NAME(EMP_NAME);
                        dtdjb006_bo.setUSER_TRN_SERNO(TRN_SER_NO);
                        dtdjb006_bo.setEXTR_DATE("");
                        dtdjb006_bo.setYEAR(DATE.getROCYear(DATE.getDBDate()));//���ثe����~��
                        dtdjb006_bo.setFILE_NO("000000");
                        dtdjb006_bo.setSER_NO("0");
                        dtdjb006_bo.setACPT_SER_NO("1");
                        dtdjb006_bo.setSLIP_DATE(ACNT_DATE);
                        dtdjb006_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                        dtdjb006_bo.setSLIP_SET_NO(SLIP_SET_NO);
                        dtdjb006_bo.setPRE_KEY(sb.append(INV_NO).append(MapUtils.getString(invNoMap, "RJT_SER_NO")).append(MapUtils.getString(invNoMap, "SUB_CPY_ID")).toString());
                        sb.setLength(0);
                        dtdjb006_bo.setCURR("NTD");
                        dtdjb006_bo.setTRN_KIND("");
                        dtdjb006_bo.setBAL_TYPE(BAL_TYPE);
                        log.debug("DJ_B0Z010.insertDTDJB006:" + dtdjb006_bo);
                        //�g�J�ݵ��I��
                        theDJ_B0Z010.insertDTDJB006(dtdjb006_bo);
                    }
                }
            }
        } //End for

        return rtnList;
    }

    /**
     * ���������b�ȽT�{
     * <pre>
     * @param reqMap    �b�ȸ�T
     * DIV_NO       �ӿ��O
     * ACC_TYPE     �@�o����
     * ACNT_DATE    �ǲ����
     * SLIP_SET_NO  �ǲ��ո�
     * ACC_ACTION   �X�b���A
     * SUB_CPY_ID   �����q�O
     * EMP_ID       �@�~�H��
     * EMP_NAME     �@�~�H�m�W
     * DIV_NAME     ��줤��
     * </pre>
     * @throws Exception 
     */
    public String unconfirm(Map reqMap) throws Exception {
        // [20200220] �վ�^�ǫ��A��String
        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C22040_MSG_001"));//�b�ȸ�T���i����
        }
        if (eie != null) {
            throw eie;
        }

        //���o���Ӹ��
        List<Map> detailList = this.query(reqMap);

        String slipLotNo = "";
        String trnSerNo = "";
        String TrnDate = DATE.getDBTimeStamp();
        boolean blDelDJB006 = false;
        boolean blDelDKG002 = false;

        String DIV_NO = MapUtils.getString(reqMap, "DIV_NO");
        String EMP_ID = MapUtils.getString(reqMap, "EMP_ID");
        String EMP_NAME = MapUtils.getString(reqMap, "EMP_NAME");
        String ACC_TYPE = MapUtils.getString(reqMap, "ACC_TYPE");
        BigDecimal START_YM = STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO);
        BigDecimal RCV_YM = BigDecimal.ZERO;
        DataSet ds = Transaction.getDataSet();

        int cnt = 0;
        String CASE_TYPE = "";
        if ("1".equals(ACC_TYPE) || "2".equals(ACC_TYPE) || "7".equals(ACC_TYPE)) {
            CASE_TYPE = "B";
        } else {
            CASE_TYPE = "C";
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

        RCV_YM = STRING.objToBigDecimal(detailList.get(0).get("RCV_YM"), BigDecimal.ZERO);
        boolean isCallWS = RCV_YM.compareTo(START_YM) >= 0 && "01".equals(SUB_CPY_ID);
        // [20200220]�ˮְ�عq�l�o��
        if (isCallWS && "B".equals(CASE_TYPE)) {
            // �q�l�o�����i�����o���@�o
            throw new ModuleException(MessageUtil.getMessage("EP_C22040_MSG_030")); // �q�l�o�����i�����o���@�o
        }

        StringBuilder sb = new StringBuilder();
        List<Map> DTDDE003_List = new ArrayList<Map>();

        /* ��ؾɤJ:�Ϥ�call DK�Ҳ� */
        boolean isAccountSubCpy = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);//2018-01-24
        // �P�h���\�A�ݧR���Ȧ��M��
        List<String> delC309List = new ArrayList<String>();
        EP_C22020 theEP_C22020 = new EP_C22020();
        EP_Z0C301 theEP_Z0C301 = new EP_Z0C301();
        eInvHelper theeInvHelper = null;
        eInvServiceSoap_PortType service = null;//�w���ŧiservice�A�קK�C���^�鳣�n�ŧi�@��
        if ("01".equals(SUB_CPY_ID)) {//��ؤ~�ݭn�ŧi 
            theeInvHelper = new eInvHelper(EMP_ID);
            service = theeInvHelper.initService();
        }
        boolean isSuccess = true;
        String rtnMsg = StringUtils.EMPTY;
        for (Map rtnMap : detailList) {
            if (cnt == 0) {//����1�����
                slipLotNo = MapUtils.getString(rtnMap, "D_SLPLOT_NO"); //�ǲ��帹
                trnSerNo = MapUtils.getString(rtnMap, "D_TRNSER_NO"); //�P�h�g�����Ǹ�
                cnt++;
            }
            RCV_YM = STRING.objToBigDecimal(rtnMap.get("RCV_YM"), BigDecimal.ZERO);

            isCallWS = RCV_YM.compareTo(START_YM) >= 0 && "01".equals(SUB_CPY_ID);

            String INV_NO = MapUtils.getString(rtnMap, "INV_NO");

            String SER_NO = MapUtils.getString(rtnMap, "RJT_SER_NO");
            if ("1".equals(ACC_TYPE) || "7".equals(ACC_TYPE)) { // ���� �κ޲z�O �o���@�o
                ds.clear();
                ds.setField("TrnDate", TrnDate);
                ds.setField("DIV_NO", DIV_NO);
                ds.setField("EMP_ID", EMP_ID);
                ds.setField("EMP_NAME", EMP_NAME);
                ds.setField("INV_NO", INV_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);

                DBUtil.executeUpdate(ds, SQL_unconfirm_001);
            } else if ("2".equals(ACC_TYPE)) { // ����o���@�o
                ds.clear();
                ds.setField("TrnDate", TrnDate);
                ds.setField("DIV_NO", DIV_NO);
                ds.setField("EMP_ID", EMP_ID);
                ds.setField("EMP_NAME", EMP_NAME);
                ds.setField("INV_NO", INV_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);

                DBUtil.executeUpdate(ds, SQL_unconfirm_002);
            } else {
                // �P�f�h�^
                String PAY_TYPE = MapUtils.getString(rtnMap, "RJT_PAY_TYPE");
                String RCV_NO = MapUtils.getString(rtnMap, "RCV_NO");

                BigDecimal RJT_SPR_AMT = getBigDecimal(rtnMap.get("RJT_SPR_AMT"), BigDecimal.ZERO);
                BigDecimal RJT_AMT = getBigDecimal(rtnMap.get("RJT_AMT"), BigDecimal.ZERO);
                BigDecimal RJT_TAX = getBigDecimal(rtnMap.get("RJT_TAX"), BigDecimal.ZERO);
                if (log.isDebugEnabled()) {
                    log.debug(blDelDKG002 + ", blDelDKG002 = " + RJT_SPR_AMT.toString() + "," + RJT_AMT.toString() + "," + RJT_TAX.toString());
                }
                if ("4".equals(PAY_TYPE)) { // �P�h�覡���J�Ȧ�
                    if ((RJT_AMT.add(RJT_TAX).subtract(RJT_SPR_AMT)).compareTo(BigDecimal.ZERO) > 0) {
                        blDelDKG002 = true;
                    }
                } else if ("2".equals(PAY_TYPE) || "3".equals(PAY_TYPE)) { // �P�h�覡���䲼�ζ״�
                    blDelDJB006 = true;
                }

                if (log.isDebugEnabled()) {
                    log.debug("blDelDKG002 = " + blDelDKG002);
                }

                // [20200220] ��عq�l�o���A�I�s�t��WS
                if (isCallWS) {
                    // �����Ǹ� =INV_NO+'-'+C204.SER_NO
                    try {
                        theeInvHelper.cancelAllowance(rtnMap, service);
                    } catch (Exception e) {
                        // �I�sws�����P�h���ѡA�o���s���G{0}�A���~�T���G{1}
                        rtnMsg = MessageUtil.getMessage("EP_C22040_MSG_029", new String[] { INV_NO, e.getMessage() });
                        log.fatal(rtnMsg, e);
                        isSuccess = false;
                    } catch (Throwable t) {
                        // �I�sws�����P�h���ѡA�o���s���G{0}�A���~�T���G{1}
                        rtnMsg = MessageUtil.getMessage("EP_C22040_MSG_029", new String[] { INV_NO, t.getMessage() });
                        log.fatal(rtnMsg, t);
                        isSuccess = false;
                    }
                }
                if (!isSuccess) {
                    // [20200204]�I�sws���ѡA�פ�j��
                    break;
                }

                if (!isAccountSubCpy || RCV_YM.compareTo(START_YM) < 0) {
                    //[20200511] �D��ءA�n�^��p���_��(��جO�b�|�p�Ю֮ɦ^��)
                    if ("2".equals(MapUtils.getString(rtnMap, "PAY_KIND"))) {//�㯲���P�h
                        String C201_PAY_NO = MapUtils.getString(rtnMap, "C201_PAY_NO");
                        String C201_RCV_NO = MapUtils.getString(rtnMap, "C201_RCV_NO");

                        //���o�U�@�㯲���p���_�B����
                        String PMI_E_DATE = MapUtils.getString(rtnMap, "PMI_E_DATE");
                        String N_PMI_SD = DATE.addDate(PMI_E_DATE, 0, 0, 1);
                        String N_PMI_ED = DATE.getMonthLastDate(N_PMI_SD).toString(); //���Ӧ~��̫�@��

                        theEP_Z0C301.updatePMI_S_DATE(C201_PAY_NO, C201_RCV_NO, SUB_CPY_ID, N_PMI_SD, N_PMI_ED);
                    }
                    //��s�����l�B�B�w���l�B
                    BigDecimal RJT_PRPSP_AMT = getBigDecimal(rtnMap.get("RJT_PRPSP_AMT"), BigDecimal.ZERO);
                    if (RJT_SPR_AMT.compareTo(BigDecimal.ZERO) != 0 || RJT_PRPSP_AMT.compareTo(BigDecimal.ZERO) != 0) {
                        ds.clear();
                        ds.setField("RJT_SPR_AMT", RJT_SPR_AMT);
                        ds.setField("RJT_PRPSP_AMT", RJT_PRPSP_AMT);
                        ds.setField("RCV_NO", RCV_NO);
                        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                        DBUtil.executeUpdate(ds, SQL_unconfirm_003);
                    }
                    //��s�w���l�B
                    BigDecimal RJT_C104PRP_AMT = getBigDecimal(rtnMap.get("RJT_C104PRP_AMT"), BigDecimal.ZERO);
                    if (RJT_C104PRP_AMT.compareTo(BigDecimal.ZERO) != 0) {
                        ds.clear();
                        ds.setField("RJT_C104PRP_AMT", RJT_C104PRP_AMT);
                        ds.setField("RCV_NO", RCV_NO);
                        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                        DBUtil.executeUpdate(ds, SQL_unconfirm_004);
                    }

                    // [20200220] ��صo���A�������h���\�ݧR���Ȧ���
                    if (!isAccountSubCpy) {
                        delC309List.add(INV_NO);
                    }
                }

                //��sDTEPC204
                if (isCallWS) {
                    //20200414:��عq�l�o���A���������A�R��������(���M������Ǹ��ۦP�L�k���s�g�J�t�Ӹ�Ʈw)  
                    Map tmpMap = new HashMap();
                    tmpMap.put("SUB_CPY_ID", SUB_CPY_ID);
                    tmpMap.put("PAY_KIND", MapUtils.getString(rtnMap, "PAY_KIND"));
                    tmpMap.put("INV_NO", INV_NO);
                    tmpMap.put("SER_NO", MapUtils.getString(rtnMap, "RJT_SER_NO"));
                    tmpMap.put("RCV_NO", RCV_NO);
                    theEP_C22020.unConfirm(tmpMap, tmpMap, EMP_ID, EMP_NAME, DIV_NO);
                } else {
                    ds.clear();
                    ds.setField("TrnDate", TrnDate);
                    ds.setField("DIV_NO", DIV_NO);
                    ds.setField("EMP_ID", EMP_ID);
                    ds.setField("EMP_NAME", EMP_NAME);
                    ds.setField("INV_NO", INV_NO);
                    ds.setField("SER_NO", SER_NO);
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    DBUtil.executeUpdate(ds, SQL_unconfirm_005);
                }
            }

            /* ��ؾɤJ�G�Ϥ�call DK�Ҳ�  */
            if (isAccountSubCpy && RCV_YM.compareTo(START_YM) >= 0) {//��عq�l�o��
                Map E003Map = new HashMap();
                E003Map.put("CASE_TYPE", CASE_TYPE);
                E003Map.put("INV_NO", INV_NO);

                if ("B".equals(CASE_TYPE)) {
                    sb.append(INV_NO);
                } else if ("C".equals(CASE_TYPE)) {
                    sb.append(INV_NO).append('-').append(SER_NO);
                }
                E003Map.put("EPKEY", sb.toString());//"PRE_KEY"
                sb.setLength(0);
                DTDDE003_List.add(E003Map);
            }

        } //end for

        ReturnMessage rm = new ReturnMessage();

        String ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
        // �R���Ȧ����
        if (blDelDKG002) {
            String acntInDate = ACNT_DATE + " 00:00:00.000";
            if (isAccountSubCpy) {//���
                new DK_G0Z002().deleteDTDKG002ForXA(EMP_ID, acntInDate, trnSerNo, rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(rm.getMsgDesc());
                }
            } else {//���
                if (delC309List != null && !delC309List.isEmpty()) {
                    new EP_Z0C309().deleteDTEPC309ByACNT(SUB_CPY_ID, EMP_ID, acntInDate, trnSerNo, delC309List);
                }
            }
        }

        if (isAccountSubCpy) {//���
            //�R�����I��
            if (blDelDJB006) {
                //String acntInDate = ACNT_DATE + " 00:00:00.000";
                new DJ_B0Z010().deleteForNewPlatform_EP(ACNT_DATE, slipLotNo, SLIP_SET_NO, rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(rm.getMsgDesc());
                }
            }

            //����DD�o��������
            if (DTDDE003_List.size() > 0) {
                Map updE003reqMap = new HashMap();
                updE003reqMap.put("CASE_TYPE", CASE_TYPE);
                new DD_E0Z008().cancel_E003ByEP(updE003reqMap, DTDDE003_List);
            }

            //�R���|�p����
            DTDKF001 DTDKF001_Bo = new DTDKF001();
            DTDKF001_Bo.setACNT_DIV_NO(DIV_NO);
            DTDKF001_Bo.setACNT_DATE(ACNT_DATE);
            DTDKF001_Bo.setSLIP_LOT_NO(slipLotNo);
            DTDKF001_Bo.setSLIP_SET_NO(SLIP_SET_NO);
            new DK_F0Z017().deleteByACNT_DIV_NO(DTDKF001_Bo, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                log.error(rm.getMsgDesc());
                throw new ModuleException(MessageUtil.getMessage("EP_C22040_MSG_023"));//�I�s�|�p�����b�ȼҲյo�Ϳ��~

            }
        }

        return rtnMsg;
    }

    /**
     * �C�L����
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public Map printRpt(Map reqMap) throws ModuleException {

        String ACC_TYPE = MapUtils.getString(reqMap, "ACC_TYPE");
        log.debug("ACC_TYPE: " + ACC_TYPE);

        //���o���Ӹ��
        List<Map> detailList = this.query(reqMap);
        if (log.isDebugEnabled()) {
            log.debug("detailList = " + detailList);
        }

        //�N������ƥH�ǲ���T��KEY�զ��C�L�M����
        StringBuilder sb = new StringBuilder();
        Map TOTMap = new HashMap();
        Map<String, List<Map>> rtnMap = new TreeMap<String, List<Map>>();
        for (Map data : detailList) {

            //���o�b��KEY��: �ǲ���T�i�ǲ����,�ǲ��帹,�s�����,�ǲ��ո��j�զ��C

            String D_ACNT_DATE = MapUtils.getString(data, "D_ACNT_DATE");
            String D_SLPLOT_NO = MapUtils.getString(data, "D_SLPLOT_NO");
            String D_ACNT_DIV_NO = MapUtils.getString(data, "D_ACNT_DIV_NO");
            String D_SLP_SET_NO = MapUtils.getString(data, "D_SLPSET_NO");

            if (StringUtils.isNotBlank(D_ACNT_DATE) && StringUtils.isNotBlank(D_SLPLOT_NO) && StringUtils.isNotBlank(D_ACNT_DIV_NO) && StringUtils.isNotBlank(D_SLP_SET_NO)) {
                sb.setLength(0);
                String KEY = sb.append(D_ACNT_DATE).append(",").append(D_SLPLOT_NO).append(",").append(D_ACNT_DIV_NO).append(",").append(D_SLP_SET_NO).toString();
                Map tempMap = new HashMap();
                if ("3".equals(ACC_TYPE)) { //�{��
                    tempMap.put("PAY_TYPE", "2");
                } else if ("4".equals(ACC_TYPE)) {//�䲼
                    tempMap.put("PAY_TYPE", "3");
                } else {//�״�
                    tempMap.put("PAY_TYPE", "1");
                }
                tempMap.put("CRT_NO", data.get("CRT_NO"));
                tempMap.put("CUS_NO", data.get("CUS_NO"));
                tempMap.put("ID", data.get("ACPT_ID"));
                tempMap.put("BLD_CD", data.get("BLD_CD"));
                tempMap.put("CUS_NAME", data.get("CUS_NAME"));
                String ACPT_ACNT_NAME = MapUtils.getString(data, "ACPT_ACNT_NAME");
                //�P�f�h�^ �״ڰh�O �W�[��w�N�� �b��
                if ("5".equals(ACC_TYPE)) {
                    String ACPT_BANK_NO = MapUtils.getString(data, "ACPT_BANK_NO");
                    String ACPT_ACNT_NO = MapUtils.getString(data, "ACPT_ACNT_NO");
                    log.debug("ACPT_BANK_NO:" + ACPT_BANK_NO);
                    log.debug("ACPT_ACNT_NO:" + ACPT_ACNT_NO);
                    if (StringUtils.isNotBlank(ACPT_BANK_NO)) {
                        ACPT_ACNT_NAME = ACPT_ACNT_NAME + "�A��w�N��:" + ACPT_BANK_NO;
                    }
                    if (StringUtils.isNotBlank(ACPT_ACNT_NO)) {
                        ACPT_ACNT_NAME = ACPT_ACNT_NAME + "�A�Ȧ�b��:" + ACPT_ACNT_NO;
                    }
                }
                tempMap.put("ACPT_ACNT_NAME", ACPT_ACNT_NAME);

                tempMap.put("AMT", getBigDecimal(data.get("RJT_AMT"), BigDecimal.ZERO).add(getBigDecimal(data.get("RJT_TAX"), BigDecimal.ZERO)));
                List<Map> tempList;
                if (rtnMap.containsKey(KEY)) {
                    tempList = (List<Map>) rtnMap.get(KEY);
                } else {
                    tempList = new ArrayList<Map>();
                }
                TOTMap.put(KEY, getBigDecimal(TOTMap.get(KEY), BigDecimal.ZERO).add(getBigDecimal(tempMap.get("AMT"), BigDecimal.ZERO)));
                tempList.add(tempMap);
                rtnMap.put(KEY, tempList);
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("rtnMap = " + rtnMap);
        }
        Set keys = rtnMap.keySet();
        for (Object key : keys) {
            List<Map> tempList = (List<Map>) rtnMap.get(key);
            BigDecimal TOT_AMT = BigDecimal.ZERO;
            for (Map tempMap : tempList) {
                TOT_AMT = TOT_AMT.add(getBigDecimal(tempMap.get("AMT"), BigDecimal.ZERO));
                tempMap.put("TOTAL_AMT", TOTMap.get(key));
            }
        }
        return rtnMap;
    }

    /**
     * �զ�DD�o�����Ӫ�
     * @param CASE_TYPE   �ץ󫬺AB:�@�oC:�P�h
     * @param rtnMap      �o����T
     * @param reqMap     �b�Ȥ��
     * @return  invMap   �o�����e
     * @throws ModuleException 
     */
    public Map formatInvList(String CASE_TYPE, Map rtnMap, Map reqMap, EP_C0Z001 theEP_C0Z001, Map PIN_NAMEmap, StringBuilder sb) throws ModuleException {

        Timestamp tTime = DATE.currentTime();

        String EmpID = MapUtils.getString(reqMap, "EMP_ID");
        String EmpName = MapUtils.getString(reqMap, "EMP_NAME");
        String OpUnit = MapUtils.getString(reqMap, "DIV_NO");

        Map invMap = new HashMap();
        invMap.put("CASE_TYPE", CASE_TYPE);
        invMap.put("CASE_STATUS", "4");//�ݱb�ȽT�{

        //�վ�~�W�榡
        theEP_C0Z001.getPIN_NAMEForPrint(rtnMap, invMap, sb, PIN_NAMEmap);

        invMap.put("USE_TYPE", "EP1");
        invMap.put("INV_YM", rtnMap.get("RCV_YM"));

        String INV_NO = MapUtils.getString(rtnMap, "INV_NO");
        invMap.put("INV_NO", INV_NO);
        invMap.put("TAX_TP", rtnMap.get("TAX_TYPE"));
        invMap.put("ACNT_DATE", reqMap.get("ACNT_DATE"));
        invMap.put("SLIP_LOT_NO", reqMap.get("SLIP_LOT_NO"));
        invMap.put("SLIP_SET_NO", reqMap.get("SlipSetNo"));
        invMap.put("TRN_SER_NO", reqMap.get("UserTrnSerno"));
        invMap.put("CE_DIV_NO", OpUnit.substring(0, 5));
        invMap.put("CE_CURR_TYPE", "NTD");

        sb.setLength(0);
        if ("B".equals(CASE_TYPE)) {
            sb.append(INV_NO);
        } else if ("C".equals(CASE_TYPE)) {
            sb.append(INV_NO).append('-').append(MapUtils.getString(rtnMap, "RJT_SER_NO"));
        }
        invMap.put("EPKEY", sb.toString());
        invMap.put("CASE_MEMO", FieldOptionList.getName("EP", "ELE_INV", "CASE_MEMO_" + CASE_TYPE));
        sb.setLength(0);

        String PAY_TYPE = MapUtils.getString(rtnMap, "RJT_PAY_TYPE");
        String REFUND_TYPE = null;
        if ("B".equals(CASE_TYPE)) {//�@�o

            invMap.put("AMT", rtnMap.get("INV_AMT"));
            invMap.put("TAX_AMT", rtnMap.get("TAX_AMT"));
            invMap.put("PROD_AMT", rtnMap.get("SAL_AMT"));

            REFUND_TYPE = "N";//�o���@�o:������
        } else if ("C".equals(CASE_TYPE)) {//�P�h
            //������������B(���������������p)
            BigDecimal RJT_TAX = STRING.objToBigDecimal(rtnMap.get("RJT_TAX"), BigDecimal.ZERO);
            BigDecimal RJT_AMT = STRING.objToBigDecimal(rtnMap.get("RJT_AMT"), BigDecimal.ZERO);
            invMap.put("TAX_AMT", RJT_TAX);//�|�B
            invMap.put("PROD_AMT", RJT_AMT);//���|���B
            invMap.put("AMT", BigDecimal.ZERO.add(RJT_TAX).add(RJT_AMT));//�t�|���B

            if ("1".equals(PAY_TYPE)) {
                REFUND_TYPE = "1";
            } else if ("2".equals(PAY_TYPE)) {
                REFUND_TYPE = "2";
            } else if ("3".equals(PAY_TYPE)) {
                REFUND_TYPE = "3";
            } else if ("4".equals(PAY_TYPE)) {
                REFUND_TYPE = "N";
            } else if ("5".equals(PAY_TYPE)) {
                REFUND_TYPE = "5";
            }
        }
        invMap.put("REFUND_TYPE", REFUND_TYPE);
        invMap.put("BAL_AMT", "0");//�o���}�ߤ~��J,�@�o�P�h�ץ�@�v��0

        if ("3".equals(REFUND_TYPE)) {
            invMap.put("ACPT_ID", MapUtils.getString(rtnMap, "ACPT_ID").trim());
            invMap.put("ACPT_NAME", rtnMap.get("ACPT_ACNT_NAME"));
            invMap.put("ACPT_BANK_NO", rtnMap.get("ACPT_BANK_NO"));
            invMap.put("ACPT_ACNT_NO", rtnMap.get("ACPT_ACNT_NO"));
        } else {
            invMap.put("ACPT_ID", null);
            invMap.put("ACPT_NAME", null);
            invMap.put("ACPT_BANK_NO", null);
            invMap.put("ACPT_ACNT_NO", null);
        }
        invMap.put("OPR_ID", EmpID);
        invMap.put("OPR_NAME", EmpName);
        invMap.put("OPR_DIV_NO", OpUnit);
        invMap.put("OPR_TS", tTime);
        invMap.put("ACNT_CFM_ID", EmpID);
        invMap.put("ACNT_CFM_NAME", EmpName);
        invMap.put("ACNT_CFM_DIV_NO", OpUnit);
        invMap.put("ACNT_CFM_TS", tTime);
        return invMap;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

}
