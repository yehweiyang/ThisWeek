package com.cathay.ep.c2.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.c0.module.EP_C0Z001;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/** 
 * <pre>
 *   Date  Version Description Author
 * 2013/8/14   1.0 �s�W  �\�a�s
 * 2018/01/29   1.1      �վ�o���~�W�榡         ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �o���ɬd�߼Ҳ�
 * �{���W��    EP_C23010 
 * ���n����    �d��DTEPC202_�o���ɸ��
 * 
 * </pre>
 * @author �¶��� 
 * @since 2013/12/12  
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C23010 {
    private static final String SQL_queryMap_001 = "com.cathay.ep.c2.module.EP_C23010.SQL_queryMap_001";

    private static final String SQL_queryList_001 = "com.cathay.ep.c2.module.EP_C23010.SQL_queryList_001";

    /**
     * �d�ߵo���ɸ��
     * @param INV_NO �o�����X
     * @return
     * @throws ModuleException
     */
    public Map queryMap(String INV_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(INV_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23010_MSG_001"));//�ǤJ�o�����X���i���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001);
        getNM(rtnMap, "PAY_KIND", "PAY_KIND");
        getNM(rtnMap, "TAX_TYPE", "TAX_TYPE");
        getNM(rtnMap, "INV_CD", "INV_CD");
        getNM(rtnMap, "INV_TYPE", "CUS_INV_TYPE");
        getNM(rtnMap, "TRANS_TYPE", "TRANS_TYPE");

        //�վ�~�W�榡
        new EP_C0Z001().getPIN_NAMEForQuery(rtnMap, null, null);

        return rtnMap;

    }

    /**
     * �d�ߵo���P�h�ɸ��
     * @param INV_NO �o�����X
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(String INV_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(INV_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C23010_MSG_001"));//�ǤJ�o�����X���i���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("INV_NO", INV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        List<Map> rtnList = new ArrayList();
        while (ds.next()) {
            Map map = VOTool.dataSetToMap(ds);
            getNM(map, "PAY_TYPE", "PAY_TYPE_C204");
            rtnList.add(map);
        }

        return rtnList;
    }

    /**
     * ���N�X�������
     * @param map
     * @param key
     * @param codeKey
     */
    private void getNM(Map map, String key, String codeKey) {
        map.put(key + "_NM", FieldOptionList.getName("EP", codeKey, MapUtils.getString(map, key)));
    }
}
