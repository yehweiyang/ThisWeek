package com.cathay.ep.a3.trx;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.a3.module.EP_A30060;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
*
<pre>
Date    Version Description Author
2013/10/17  1.0 Created ������

UCEPA3_0060_�������J�d��

�{���\�෧�n�����G
    �{���\��    �������J�d��
    �{���W��    EPA3_0060
    �@�~�覡    ONLINE
    ���n����    
        (1) ��l�C
        (2) �d�� �w �ϥΪ̫��U���s��A�I�sEP_A30060�Ҳը��o�j�ӯ������J���ӡC
        (3) �ץX �w �ϥΪ̫��U���s��A�N�d�ߵ��G�ץXExcel�ɡC
    ���s���v    �M��FUNC_ID = EPA30060
    �h��y�t    �M��
    �����q���
    �榡���js  �M��
</pre>
 * @author ���t�s
 * @since 2014/1/16
 */
@SuppressWarnings("unchecked")
public class EPA3_0060 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPA3_0060.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        //�d�ߩӿ���        
        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("DIV_List", new EP_A30060().queryDivList(SUB_CPY_ID));
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        } catch (Exception e) {
            log.error("���o�ӿ���U�Կ�楢��", e);
        }

        //�d�ߺ���
        resp.addOutputData("SORT_List", FieldOptionList.getName("EP", "A35_SORT_TYPE"));
        resp.addOutputData("userDivNo", user.getDivNo());
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            List<Map> rtnList = new EP_A30060().queryList(req.getParameter("SORT_TYPE"), req.getParameter("SUB_CPY_ID"), req
                    .getParameter("RCV_YM"), req.getParameter("CLC_DIV_NO"));

            //�X�p
            BigDecimal countSAL_AMT = BigDecimal.ZERO;
            BigDecimal countPRP_AMT = BigDecimal.ZERO;
            BigDecimal countTRA_PRP_AMT = BigDecimal.ZERO;
            BigDecimal countRJT_RNT_AMT = BigDecimal.ZERO;
            BigDecimal countNET_SAL_AMT = BigDecimal.ZERO;
            BigDecimal countSUM_NET_AMT = BigDecimal.ZERO;

            for (Map dataMap : rtnList) {
                countSAL_AMT = countSAL_AMT.add(obj2Big(dataMap, "SAL_AMT", BigDecimal.ZERO));
                countPRP_AMT = countPRP_AMT.add(obj2Big(dataMap, "PRP_AMT", BigDecimal.ZERO));
                countTRA_PRP_AMT = countTRA_PRP_AMT.add(obj2Big(dataMap, "TRA_PRP_AMT", BigDecimal.ZERO));
                countRJT_RNT_AMT = countRJT_RNT_AMT.add(obj2Big(dataMap, "RJT_RNT_AMT", BigDecimal.ZERO));
                countNET_SAL_AMT = countNET_SAL_AMT.add(obj2Big(dataMap, "NET_SAL_AMT", BigDecimal.ZERO));
                countSUM_NET_AMT = countSUM_NET_AMT.add(obj2Big(dataMap, "SUM_NET_AMT", BigDecimal.ZERO));
            }

            resp.addOutputData("countSAL_AMT", countSAL_AMT);
            resp.addOutputData("countPRP_AMT", countPRP_AMT);
            resp.addOutputData("countTRA_PRP_AMT", countTRA_PRP_AMT);
            resp.addOutputData("countRJT_RNT_AMT", countRJT_RNT_AMT);
            resp.addOutputData("countNET_SAL_AMT", countNET_SAL_AMT);
            resp.addOutputData("countSUM_NET_AMT", countSUM_NET_AMT);

            resp.addOutputData("rtnList", rtnList);
            MessageUtil.setMsg(msg, "MI00020"); //�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632"); //�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028"); ////�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00630"); //�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630"); //�d�ߥ���
        }

        return resp;
    }

    /**
     * �ץX
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {

        try {

            EP_A30060 theEP_A30060 = new EP_A30060();
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SORT_TYPE = MapUtils.getString(reqMap, "SORT_TYPE");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
            String CLC_DIV_NO = MapUtils.getString(reqMap, "CLC_DIV_NO");
            //�j�M���G
            List<Map> rtnList = theEP_A30060.queryList(SORT_TYPE, SUB_CPY_ID, RCV_YM, CLC_DIV_NO);
            LocaleDisplay locale = new LocaleDisplay("EP", user);
            theEP_A30060.exportXLS(reqMap, rtnList, locale, resp);
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "�ɮפU������");
            }
        } catch (Exception e) {
            log.error("�ɮפU������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "�ɮפU������");
        }
        return resp;
    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }
}