package com.cathay.ep.a3.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.a3.module.EP_A30061;
import com.cathay.ep.c2.trx.EPC2_0030;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Version Description Author
 * 2013/10/18   1.0 Created     ������
 * 
 * UCEPA3_0061_�j�ӫȤ᯲�����J�d��
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �j�ӫȤ᯲�����J�d��
 * �{���W��    EPA3_0061
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l�C
 *             (2) �d�� �w �ϥΪ̫��U���s��A�I�sEP_A30061�Ҳը��o�j�ӫȤ᯲�����J���ӡC
 *             (3) �ץX �w �ϥΪ̫��U���s��A�N�d�ߵ��G�ץXExcel�ɡC
 * ���s���v    �M��FUNC_ID = EPA30061
 * �h���d��    (����v�䤤�@��)  �L   v������      �u����
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 * </pre>
 * @author ����[
 * @since 2014-01-16
 */

@SuppressWarnings("unchecked")
public class EPA3_0061 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_0030.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);
        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        VOTool.setParamsFromLP_JSON(req);

        resp.addOutputData("BLD_CD", req.getParameter("BLD_CD"));
        resp.addOutputData("RCV_YM", req.getParameter("RCV_YM"));
        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));//�����q�O
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPA3_0061_ERRMSG_001");//���o�����q�O����
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            List<Map> rtnList = new EP_A30061().queryList(req.getParameter("BLD_CD"), req.getParameter("SUB_CPY_ID"), req
                    .getParameter("RCV_YM"));

            //�p��X�p
            BigDecimal SAL_AMT = BigDecimal.ZERO;
            BigDecimal PRP_AMT = BigDecimal.ZERO;
            BigDecimal TRA_PRP_AMT = BigDecimal.ZERO;
            BigDecimal RJT_RNT_AMT = BigDecimal.ZERO;
            BigDecimal NET_SAL_AMT = BigDecimal.ZERO;
            BigDecimal SUM_NET_AMT = BigDecimal.ZERO;
            for (Map rtnMap : rtnList) {
                SAL_AMT = SAL_AMT.add(getBigDecimal(rtnMap.get("SAL_AMT"), BigDecimal.ZERO));
                PRP_AMT = PRP_AMT.add(getBigDecimal(rtnMap.get("PRP_AMT"), BigDecimal.ZERO));
                TRA_PRP_AMT = TRA_PRP_AMT.add(getBigDecimal(rtnMap.get("TRA_PRP_AMT"), BigDecimal.ZERO));
                RJT_RNT_AMT = RJT_RNT_AMT.add(getBigDecimal(rtnMap.get("RJT_RNT_AMT"), BigDecimal.ZERO));
                NET_SAL_AMT = NET_SAL_AMT.add(getBigDecimal(rtnMap.get("NET_SAL_AMT"), BigDecimal.ZERO));
                SUM_NET_AMT = SUM_NET_AMT.add(getBigDecimal(rtnMap.get("SUM_NET_AMT"), BigDecimal.ZERO));
            }

            // 20161206 LogSecurity
            try{
          		List<Map> logSecurityList = new ArrayList<Map>();
          		for (Map tmpRecord : rtnList) {
          			Map logSecurityMap = new HashMap();
          			// �Ȥ�m�W
          			logSecurityMap.put("CUS_NAME", 
          					MapUtils.getString(tmpRecord,"CUS_NAME", ""));
          			logSecurityList.add(logSecurityMap);
          		}
          		logSecurity(logSecurityList);
          		logSecurityList.clear();
            } catch(Throwable e) {
            	log.warn(e, e);
            }   
            
            Map totMap = new HashMap();
            totMap.put("SAL_AMT", SAL_AMT);
            totMap.put("PRP_AMT", PRP_AMT);
            totMap.put("TRA_PRP_AMT", TRA_PRP_AMT);
            totMap.put("RJT_RNT_AMT", RJT_RNT_AMT);
            totMap.put("NET_SAL_AMT", NET_SAL_AMT);
            totMap.put("SUM_NET_AMT", SUM_NET_AMT);
            resp.addOutputData("rtnList", rtnList);
            resp.addOutputData("totMap", totMap);

            MessageUtil.setMsg(msg, "MI00020");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�ߥ���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00630");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �ץX
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {
        try {
            Map reqMap = new HashMap();
            StringBuilder sb = new StringBuilder();
            String fileName = sb.append(MessageUtil.getMessage("EPA3_0061_UI_FILENAME")).append(DATE.toDate_yyyyMMdd(DATE.getDBDate()))
                    .append(".xls").toString();
            reqMap.put("gridJSON", req.getParameter("gridJSON"));
            reqMap.put("fileName", fileName);

            List<Map> rtnList = new EP_A30061().export(req.getParameter("BLD_CD"), req.getParameter("SUB_CPY_ID"), req.getParameter("RCV_YM"), reqMap, resp);
            // 20161206 LogSecurity
            try{
          		List<Map> logSecurityList = new ArrayList<Map>();
          		for (Map tmpRecord : rtnList) {
          			Map logSecurityMap = new HashMap();
          			// �Ȥ�m�W
          			logSecurityMap.put("CUS_NAME", 
          					MapUtils.getString(tmpRecord,"CUS_NAME", ""));
          			logSecurityList.add(logSecurityMap);
          		}
          		logSecurity(logSecurityList);
          		logSecurityList.clear();
            } catch(Throwable e) {
            	log.warn(e, e);
            }   
            
            MessageUtil.setMsg(msg, "EPA3_0061_ERRMSG_002");//�ץX���\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_0061_ERRMSG_003");//�ץX����
                }
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_0061_ERRMSG_003");//�ץX����
        }

        return resp;
    }

    /**
     * �j�M����-�j�ӫ�ĳ�M��
     * @param req
     * @return
     */
    public ResponseContext doSuggestBLD_CD(RequestContext req) {
        try {
            //�u�j�ӫ�ĳ�M��v��ĳ���G 
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_NAME", req.getParameter("suggestValue"));
            List<Map> rtnList = new EP_A10010().queryList(reqMap);
            List<Map> BLD_CDList = new ArrayList<Map>();
            for (Map map : rtnList) {
                Map trnMap = new HashMap();
                String BLD_NAME = MapUtils.getString(map, "BLD_NAME");
                String BLD_CD = MapUtils.getString(map, "BLD_CD");
                trnMap.put("BLD_NAME", BLD_NAME);
                trnMap.put("BLD_CD", BLD_CD);
                BLD_CDList.add(trnMap);
            }
            resp.addOutputData("suggestResult", BLD_CDList);
        } catch (Exception e) {
            log.error("�j�ӷj�M���ܬd�ߥ���", e);
        }
        return resp;

    }

    /**
     * �૬�A�M���w�]
     * 
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }
}
