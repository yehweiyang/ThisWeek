package com.cathay.ep.a3.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.a3.module.EP_A31100;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2014/01/03  1.0 Created ������
 * 
 * UCEPA3_1100_�j�Ӱ����Ҭd��
 * �@�B  �{���\�෧�n�����G
 *      �{���\��    �j�Ӱ����Ҭd��
 *      �{���W��    EPA3_1100
 *      �@�~�覡    ONLINE
 *      ���n����    (1) ��l�C
 *                  (2) �d�� �w �ϥΪ̫��U���s��A�����Ҹ�ơC
 *                  (3) �@�o �w ���O�Ŀﰱ���Ҫ��A���@�~�C
 *                  (4) �C�L���~ �w ���O�Ŀﰱ���Ҫ��A���C�L���~�C
 *                  (5) ���� �w �^�_�Ŀﰱ���Ҫ��A���ϥΤ��C
 *      ���s���v    �M��FUNC_ID = EPA31100
 *      �h���d��    ������
 *      �h��y�t    �M��
 *      �����q���  �榡���js  �M��
 * </pre>
 * @author �x�Ԫ�
 * @since 2014/1/21
 */
@SuppressWarnings("unchecked")
public class EPA3_1100 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPA3_1100.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);
        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);
        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);
        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, MessageUtil.getMessage("EPA3_1100_ERRMSG_001"));//���o�����q�O����
        }
        //�u�����Ҫ��A�v�U�Կ��G 
        resp.addOutputData("PRK_STS_List", FieldOptionList.getName("EP", "PRK_STS"));
        LocaleDisplay display = new LocaleDisplay("EP", user);
        resp.addOutputData("NOW_YR", display.formatDatey(DATE.today(), ""));
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            this.query(reqMap, new EP_A31100());
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }
        return resp;
    }

    /**
     * �@�άd��
     * @param reqMap
     * @param theEP_A31100
     */
    private void query(Map reqMap, EP_A31100 theEP_A31100) throws ModuleException {
        //�d�ߤj�ӲM��
        List<Map> rtnList = theEP_A31100.queryList(reqMap);
        resp.addOutputData("rtnList", rtnList);
        String PRK_STS = MapUtils.getString(reqMap, "PRK_STS");
        if (StringUtils.isBlank(PRK_STS)) {
            Map PRK_STS_TOTAL = new HashMap();
            int PRK_STS_1 = 0;
            int PRK_STS_2 = 0;
            int PRK_STS_3 = 0;
            for (Map rtnMap : rtnList) {
                String DATA_PRK_STS = MapUtils.getString(rtnMap, "PRK_STS");
                if ("1".equals(DATA_PRK_STS)) {
                    PRK_STS_1++;
                } else if ("2".equals(DATA_PRK_STS)) {
                    PRK_STS_2++;
                } else if ("3".equals(DATA_PRK_STS)) {
                    PRK_STS_3++;
                }
            }
            PRK_STS_TOTAL.put("PRK_STS_1", PRK_STS_1);
            PRK_STS_TOTAL.put("PRK_STS_2", PRK_STS_2);
            PRK_STS_TOTAL.put("PRK_STS_3", PRK_STS_3);
            resp.addOutputData("PRK_STS_TOTAL", PRK_STS_TOTAL);
        }
    }

    /**
     * �@�o
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            List<Map> updList = VOTool.jsonAryToMaps(req.getParameter("updList"));
            EP_A31100 theEP_A31100 = new EP_A31100();
            Transaction.begin();
            try {
                //��ƳB�z: �Y���~�hROLLBACK
                //���檬�A��s�{��
                theEP_A31100.update(updList, "2", user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPA3_1100_MSG_002");//�@�o����
            try {
                Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
                this.query(reqMap, theEP_A31100);
            } catch (DataNotFoundException e) {
                log.error("�@�o�����A�d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_1100_ERRMSG_003");//�@�o����
            }
        } catch (Exception e) {
            log.error("�@�o����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_1100_ERRMSG_003");//�@�o����
        }

        return resp;
    }

    /**
     * �C�L���~
     * @param req
     * @return
     */
    public ResponseContext doPrintError(RequestContext req) {
        try {
            List<Map> updList = VOTool.jsonAryToMaps(req.getParameter("updList"));
            EP_A31100 theEP_A31100 = new EP_A31100();
            Transaction.begin();
            try {
                //��ƳB�z: �Y���~�hROLLBACK
                //���檬�A��s�{��
                theEP_A31100.update(updList, "3", user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPA3_1100_MSG_004");//��s����
            try {
                Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
                this.query(reqMap, theEP_A31100);
            } catch (DataNotFoundException e) {
                log.error("��s�����A�d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_1100_ERRMSG_005");//��s����
            }
        } catch (Exception e) {
            log.error("��s����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_1100_ERRMSG_005");//��s����
        }

        return resp;
    }

    /**
     * ����
     * @param req
     * @return
     */
    public ResponseContext doCancel(RequestContext req) {
        try {
            List<Map> updList = VOTool.jsonAryToMaps(req.getParameter("updList"));
            EP_A31100 theEP_A31100 = new EP_A31100();
            Transaction.begin();
            try {
                //��ƳB�z: �Y���~�hROLLBACK
                //���檬�A��s�{��
                theEP_A31100.update(updList, "1", user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPA3_1100_MSG_006");//��������
            try {
                Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
                this.query(reqMap, theEP_A31100);
            } catch (DataNotFoundException e) {
                log.error("���������A�d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_1100_ERRMSG_007");//��������
            }
        } catch (Exception e) {
            log.error("��������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_1100_ERRMSG_007");//��������
        }

        return resp;
    }

    /**
     * �j�M����-�j�ӫ�ĳ�M��
     * @param req
     * @return
     */
    public ResponseContext doSuggestBLD_CD(RequestContext req) {
        try {
            //�u�j�ӫ�ĳ�M��v��ĳ���G 
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_NAME", req.getParameter("suggestValue"));
            List<Map> rtnList = new EP_A10010().queryList(reqMap);
            List<Map> BLD_CDList = new ArrayList<Map>();
            Map trnMap;
            for (Map map : rtnList) {
                trnMap = new HashMap();
                String BLD_NAME = MapUtils.getString(map, "BLD_NAME");
                String BLD_CD = MapUtils.getString(map, "BLD_CD");
                trnMap.put("BLD_NAME", BLD_NAME);
                trnMap.put("BLD_CD", BLD_CD);
                BLD_CDList.add(trnMap);
            }
            resp.addOutputData("suggestResult", BLD_CDList);
        } catch (Exception e) {
            log.error("�j�ӷj�M���ܬd�ߥ���", e);
        }
        return resp;
    }

    /**
     * �s�ʬd�ߤj�ӦW��
     * @param req
     * @return
     */
    public ResponseContext doGetBLD_NAME(RequestContext req) {
        try {
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_CD", req.getParameter("BLD_CD"));
            resp.addOutputData("BLD_NAME", MapUtils.getString(new EP_A10010().queryMap(reqMap), "BLD_NAME"));
        } catch (ErrorInputException eie) {
            log.debug(eie);
        } catch (DataNotFoundException dnfe) {
            log.debug("", dnfe);
        } catch (Exception e) {
            log.error("�s�ʬd�ߤj�ӦW�٥���", e);
        }
        return resp;
    }

}
