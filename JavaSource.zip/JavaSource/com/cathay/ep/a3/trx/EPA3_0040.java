package com.cathay.ep.a3.trx;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.a3.module.EP_A30040;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0A110;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.common.util.annotation.CallMethod;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2013/10/8   1.0 Created ������
 * 2018/3/26   2.0 �t�X��ؾɤJ�վ� ����[
 * 
 * UCEPA3_0040_�j�ӫȤ�d�� 
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �j�ӫȤ�d��
 * �{���W��    EPA3_0040
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l�C
 *             (2) �d�� �w �ϥΪ̫��U���s��A�I�sEP_A30040�Ҳը��o�j�ӫȤ�M��C
 *             (3) �C�L�����Ңw �ϥΪ̫��U���s��A�I�sEP_A30040�ҲզC�L�����ҡC
 *             ���s���v    �M��FUNC_ID = EPA30040
 *             �h���d��    ������
 *             �h��y�t    �M��
 *             �����q���
 *             �榡���js  �M��
 * </pre>
 * @author �x�Ԫ�
 * @since 2014/1/3
 * 
 * 2019/07/03 �©s��  ���D�渹:20190701113214 
 * 2019/07/25 �©s��  �t�X�q�l�a�ϭק�s�W��k
 * 2019/11/11 AllenTsai�t�X�q�l�a��API�վ�Token�W�[UserID
 * 2019/11/11 AllenTsai�t�X�q�l�a��API�վ�w��T�{�P�_�A�����s�W�q�l�a�ϫ��s
 * 2019/11/18 AllenTsai ���������եd�J�f�P�s�W�a�Ϥj�Ӫ����s
 * 2020/03/10 AllenTsai �վ㦳�]�w��ܹq�l�a�Ϥ~�I�s API
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPA3_0040 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPA3_0040.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);
        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);
        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode(CallMethod.CODE_SUCCESS);
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);

        try {
            EP_Z00030 theEP_Z00030 = new EP_Z00030();
            String SUB_CPY_ID = theEP_Z00030.getSUB_CPY_ID(user);
            //[20191230] �P�O�e���W�O�_��ܹq�l�a�Ϫ��J�f
            String isEPH21000 = "N";
            try{
            	isEPH21000 = FieldOptionList.getName("EP", "EMAP_ENTRY", "EPH21000");
            } catch(Exception e) {
                //[20190730] �S�]�w�N�X�h�ιw�]"N"
                log.error("�d�L�q�l�a�ϳ]�w��", e);            	
            }
            log.debug("isEPH21000:"+ isEPH21000);
            resp.addOutputData("isEPH21000", isEPH21000);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            resp.addOutputData("isAccountSubCpy", theEP_Z00030.isAccountSubCpy(SUB_CPY_ID));//�����q�O
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, MessageUtil.getMessage("EPA3_0040_ERRMSG_001"));//���o�����q�O����
        }
        //�u�ӯ������v�U�Կ��
        resp.addOutputData("RNT_KD_LIST", FieldOptionList.getName("EP", "RNT_KD"));

        resp.addOutputData("BLD_CD", req.getParameter("BLD_CD"));
        
        
        LocaleDisplay display = new LocaleDisplay("EP", user);
        resp.addOutputData("PRT_YR", display.formatDatey(DATE.today(), ""));

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            this.query(reqMap, new EP_A30040());
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �j�M����-�j�ӫ�ĳ�M��
     * @param req
     * @return
     */
    public ResponseContext doSuggestBLD_CD(RequestContext req) {
        try {
            //�u�j�ӫ�ĳ�M��v��ĳ���G 
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_NAME", req.getParameter("suggestValue"));
            List<Map> rtnList = new EP_A10010().queryList(reqMap);
            List<Map> BLD_CDList = new ArrayList<Map>();
            Map trnMap;
            for (Map map : rtnList) {
                trnMap = new HashMap();
                String BLD_NAME = MapUtils.getString(map, "BLD_NAME");
                String BLD_CD = MapUtils.getString(map, "BLD_CD");
                trnMap.put("BLD_NAME", BLD_NAME);
                trnMap.put("BLD_CD", BLD_CD);
                BLD_CDList.add(trnMap);
            }

            resp.addOutputData("suggestResult", BLD_CDList);
        } catch (Exception e) {
            log.error("�j�ӷj�M���ܬd�ߥ���", e);
        }
        return resp;
    }

    /**
     * �j�ӥN���s�ʲ��ͤj�ӦW��
     */
    public ResponseContext doChangeBLD_CD(RequestContext req) {
        try {
            //�u�j�ӫ�ĳ�M��v��ĳ���G 
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_CD", req.getParameter("BLD_CD").toUpperCase());
            List<Map> rtnList = new EP_A10010().queryList(reqMap);
            resp.addOutputData("BLD_NAME", MapUtils.getString(rtnList.get(0), "BLD_NAME"));
        } catch (Exception e) {
            log.error("�j�ӥN���s�ʤj�ӥN������", e);
        }
        return resp;
    }

    /**
     * �ץX
     * @param req
     * @return
     */
    public ResponseContext doExportXLS(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
            String BLD_NAME = "";
            try {
                BLD_NAME = MapUtils.getString(new EP_A10010().queryMap(reqMap), "BLD_NAME", "");
                reqMap.put("BLD_NAME", BLD_NAME);
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L�����j�ӦW��");
            }
            String fileName;
            if ("6".equals(MapUtils.getString(reqMap, "RNT_KD"))) {

                fileName = MessageUtil.getMessage("EPA3_0040_MSG_006", new Object[] { BLD_CD, BLD_NAME });//{0}�@{1}�j�ӫ�������     BLD_CD:{0}   BLD_NAME:{1}
            } else {
                fileName = MessageUtil.getMessage("EPA3_0040_MSG_003"); //�j�ӫȤ�
            }
            reqMap.put("fileName", new StringBuilder().append(fileName).append("_").append(DATE.toDate_yyyyMMdd(DATE.getDBDate()))
                    .toString());

            //�ץX
            List<Map> rtnList = new EP_A30040().exportXLS(reqMap, user, resp);

            // 20161206 LogSecurity
            try {
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map tmpRecord : rtnList) {
                    Map logSecurityMap = new HashMap();
                    // �Ȥ�m�W
                    logSecurityMap.put("CUS_NAME", MapUtils.getString(tmpRecord, "CUS_NAME", ""));
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);
                logSecurityList.clear();
            } catch (Throwable e) {
                log.warn(e, e);
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_0040_ERRMSG_002");//�ɮ׶ץX����
            }
        } catch (Exception e) {
            log.error("�ɮ׶ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_0040_ERRMSG_002");//�ɮ׶ץX����
        }
        return resp;
    }

    /**
     * �[�J
     * @param req
     * @return
     */
    public ResponseContext doAdd(RequestContext req) {
        try {
            List<Map> chkList = VOTool.jsonAryToMaps(req.getParameter("chkList"));
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String PRT_YR = MapUtils.getString(reqMap, "PRT_YR");
            EP_A30040 theEP_A30040 = new EP_A30040();
            theEP_A30040.checkAdd(PRT_YR, chkList);
            Transaction.begin();
            try {
                //�[�J�妸�C�L�M��
                theEP_A30040.add(PRT_YR, chkList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPA3_0040_MSG_004");//�[�J����
            try {
                this.query(reqMap, theEP_A30040);
            } catch (DataNotFoundException e) {
                log.error("�[�J�����A�d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_0040_ERRMSG_005");//�[�J�@�~����
            }
        } catch (Exception e) {
            log.error("�[�J�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_0040_ERRMSG_005");//�[�J�@�~����
        }

        return resp;
    }

    /**
     * �C�L������
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {
            List<Map> rtnList = VOTool.jsonAryToMaps(req.getParameter("rtnList"));
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            EP_A30040 theEP_A30040 = new EP_A30040();

            Transaction.begin();
            try {
                //�R���妸�C�L�M��
                if ("4".equals(MapUtils.getString(reqMap, "RNT_KD"))) {
                    theEP_A30040.remove(rtnList);
                }
                //�զ�PDF�C�L���
                Map printMap = theEP_A30040.prkperPrint(MapUtils.getString(reqMap, "PRT_YR"), rtnList, user, req.getParameter("PRD_IDX"));
                //����PDF����
                theEP_A30040.print(printMap, resp);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            try {
                this.query(reqMap, theEP_A30040);
            } catch (DataNotFoundException e) {
                log.error("�C�L�����A�d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPA3_0040_ERRMSG_006");//�C�L���ѡA�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_0040_ERRMSG_007");//�C�L����
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_0040_ERRMSG_007");//�C�L����
        }
        return resp;
    }

    /**
     * �簣
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            List<Map> chkList = VOTool.jsonAryToMaps(req.getParameter("chkList"));
            EP_A30040 theEP_A30040 = new EP_A30040();
            Transaction.begin();
            try {
                //�簣�妸�C�L�M��
                theEP_A30040.remove(chkList);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPA3_0040_MSG_008");//�簣����
            try {
                Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
                this.query(reqMap, theEP_A30040);
            } catch (DataNotFoundException e) {
                log.error("�簣�����A�d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_0040_ERRMSG_009");//�簣����
            }
        } catch (Exception e) {
            log.error("�簣�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_0040_ERRMSG_009");//�簣����
        }
        return resp;
    }

    /**
     * �Ӽh�C�L
     * @param req
     * @return
     */
    public ResponseContext doPrintRntStatus(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            EP_A30040 theEP_A30040 = new EP_A30040();
            //�զ�PDF�C�L���
            Map printMap = theEP_A30040.formatRent(reqMap, user);

            // 20161206 LogSecurity
            try {
                List<Map> rtnList = (List<Map>) printMap.get("detail");
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map tmpRecord : rtnList) {
                    Map logSecurityMap = new HashMap();
                    // �Ȥ�m�W
                    logSecurityMap.put("CUS_NAME", MapUtils.getString(tmpRecord, "CUS_NAME", ""));
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);
                logSecurityList.clear();
            } catch (Throwable e) {
                log.warn(e, e);
            }

            //����PDF����
            theEP_A30040.printRent(printMap, resp);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPA3_0040_ERRMSG_006");//�C�L���ѡA�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_0040_ERRMSG_007");//�C�L����
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_0040_ERRMSG_007");//�C�L����
        }
        return resp;
    }

    /**
     * �C�L�Y�ɧQ��
     * @param req
     * @return
     */
    public ResponseContext doPrintUse(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            EP_A30040 theEP_A30040 = new EP_A30040();
            //�զ�PDF�C�L���
            Map printMap = theEP_A30040.formatUse(reqMap, user);

            // 20161206 LogSecurity
            try {
                List<Map> rtnList = (List<Map>) printMap.get("detail");
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map tmpRecord : rtnList) {
                    Map logSecurityMap = new HashMap();
                    // �Ȥ�m�W
                    logSecurityMap.put("CUS_NAME", MapUtils.getString(tmpRecord, "CUS_NAME", ""));
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);
                logSecurityList.clear();
            } catch (Throwable e) {
                log.warn(e, e);
            }

            //����PDF����
            theEP_A30040.printUse(printMap, resp);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPA3_0040_ERRMSG_006");//�C�L���ѡA�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_0040_ERRMSG_007");//�C�L����
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_0040_ERRMSG_007");//�C�L����
        }
        return resp;
    }

    /**
     * �@�άd��
     * @param reqMap
     * @param theEP_A30040
     */
    private void query(Map reqMap, EP_A30040 theEP_A30040) throws SQLException, ModuleException {
        //�d�ߤj�Ӱ򥻸��
        String RNT_KD = MapUtils.getString(reqMap, "RNT_KD");
        if (!"4".equals(RNT_KD)) {
            resp.addOutputData("bldMap", theEP_A30040.queryMap(reqMap));
        }
        //�d�ߤj�ӫȤ�M��
        List<Map> rtnList = theEP_A30040.queryList(reqMap);
        if (rtnList == null || rtnList.isEmpty()) {
            throw new DataNotFoundException();
        }
        // 20161206 LogSecurity
        try {
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map tmpRecord : rtnList) {
                Map logSecurityMap = new HashMap();
                // �Ȥ�m�W
                logSecurityMap.put("CUS_NAME", MapUtils.getString(tmpRecord, "CUS_NAME", ""));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);
            logSecurityList.clear();
        } catch (Throwable e) {
            log.warn(e, e);
        }
        resp.addOutputData("rtnList", rtnList);

        //[20190723] �P�_�O�_���"�ݩw��T�{"
        boolean needConfirm = false;
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        List<String> bldList = new ArrayList<String>();
        bldList.add(BLD_CD);
        try {
            //[20191230] �P�O�e���W�O�_��ܹq�l�a�Ϫ��J�f
            String isEPH21000 = "N";
            //2020/03/10 �վ㦳�]�w��ܹq�l�a�Ϥ~�I�s API
            try{
            	isEPH21000 = FieldOptionList.getName("EP", "EMAP_ENTRY", "EPH21000");
            } catch(Exception e) {
                //[20190730] �S�]�w�N�X�h�ιw�]"N"
                log.error("�d�L�q�l�a�ϳ]�w��", e);            	
            }
            if("Y".equals(isEPH21000)) {
                String userId = MapUtils.getString(reqMap, "USER_ID","EPA4_0300");
                List<Map> newRtnList = new EP_Z0A110().callAPIMap002(bldList, userId);
                //[20190723] �p�GA110����ƫh���"�q�l�a��"���s
                if (newRtnList.size() > 0) {
                    Map mapA110 = newRtnList.get(0);
                    if (!"99".equals(MapUtils.getString(mapA110, "lv"))) {
                        //[20190723] �p�G�|���w��h���"�ݩw��T�{"
                        needConfirm = true;
                    }
                }         	
            }
            //2019/11/11 AllenTsai ��ƦP�B�z�L�妸���ɡA�����إߦa�Ϥj�ӫ��s
//          else {
//              //[20190723] �d�L������"�إߦa�Ϥj��"���s
//              hasListA110 = false;
//          }            
        } catch (Exception e) {
            log.error("���o�Ŷ���T����", e);
        }
        resp.addOutputData("needConfirm", needConfirm);

    }

}
