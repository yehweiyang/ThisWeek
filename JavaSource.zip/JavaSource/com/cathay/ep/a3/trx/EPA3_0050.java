package com.cathay.ep.a3.trx;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.ep.a3.module.EP_A30040;
import com.cathay.ep.a3.module.EP_A30050;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 * Date    Version Description Author
 * 2013/10/14  1.0 Created ������
 * 
 * UCEPA3_0050_�ϥη��p�d��
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �ϥη��p�d��
 * �{���W��    EPA3_0050
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l�C
 * (2) �d�� �w �ϥΪ̫��U���s��A�I�sEP_A30050�Ҳը��o�Ÿm�Ӽh�M��C
 * (3) �ץX �w �ϥΪ̫��U���s��A�N�d�ߵ��G�ץXExcel�ɡC
 * (2) ��s �w �ϥΪ̫��U���s��A�I�sEP_A30050��s�j�Өϥη��p�C
 * ���s���v    �M��FUNC_ID = EPA30050
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 * </pre>
 * @author �¶��� 
 * @since 2014/1/14  
 */
@SuppressWarnings("unchecked")
public class EPA3_0050 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPA3_0050.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    // private static final String BODY_ARRAY[] = {};
    //  private static final String BODY_ARRAY[] = {};

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        try {
            resp.addOutputData("SORT_LIST", FieldOptionList.getName("EP", "A35_SORT_TYPE"));//(1:�j�ӥN��; 2:�ϥΩʽ�)
        } catch (Exception e) {
            log.error("��l����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00029");//��l����
        }
        String SUB_CPY_ID = null;//���o�����q�O
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);//�����q�O            
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPB1_0010_ERRMSG_001");
        }
        resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            //�d�ߤj�Өϥη��p�M��
            this.query(req.getParameter("SORT_TYPE"));

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * ��s
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {

            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);

            Transaction.begin();
            try {
                new EP_A30050().update(SUB_CPY_ID, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPA3_0050_UI_MSG_001");//�ק粒��

            try {
                this.query(req.getParameter("SORT_TYPE"));
            } catch (Exception e) {
                log.error("�ק粒���A���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPA3_0050_UI_MSG_002");//�ק粒���A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA3_0050_UI_MSG_003");//�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA3_0050_UI_MSG_003");//�ק異��
        }

        return resp;
    }

    /**
     * �ץX
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {
        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            String SORT_TYPE = req.getParameter("SORT_TYPE");
            String EXP_ALL = req.getParameter("EXP_ALL");
            EP_A30050 theEP_A30050 = new EP_A30050();

            //���o�e���ϥθ��
            List<Map> rtnList = theEP_A30050.queryList(SUB_CPY_ID, SORT_TYPE, "1");

            LocaleDisplay locale = new LocaleDisplay("EP", user);

            //�ץXEexcel
            theEP_A30050.exportXLS(locale, SORT_TYPE, EXP_ALL, rtnList, resp);

        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPA3_0050_UI_MSG_005"));//�ץX����
                }
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA3_0050_UI_MSG_005"));//�ץX����
        }

        return resp;
    }

    /**
     * �d�ߤj�Өϥη��p�M��
     * @param SORT_TYPE
     * @throws SQLException 
     * @throws ModuleException 
     * @throws Exception
     */
    private void query(String SORT_TYPE) throws ModuleException, SQLException {
        //�����q�O
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
        List<Map> rtnList = new EP_A30050().queryList(SUB_CPY_ID, SORT_TYPE, "1");
        LocaleDisplay locale = new LocaleDisplay("EP", user);
        Map<String, BigDecimal> totMap = new HashMap<String, BigDecimal>();
        String totColumns[] = { "BLD_SIZE", "RNT_SIZE", "UN_RNT_SIZE", "SLF_SIZE", "BLD_PRK", "RNT_PRK", "AVL_PRK", "SLF_PRK", "RNT_AMT",
                "CUS_CNT", "DIV_CNT", "PART_CNT" };
        for (String col : totColumns) {
            totMap.put(col, BigDecimal.ZERO);
        }

        for (Map rtnMap : rtnList) {

            rtnMap.put("RNT_RT_1", locale.formatNumber(((BigDecimal) rtnMap.get("RNT_RT")).multiply(new BigDecimal("100")), 1, "") + "%");

            //�X�p�p��
            for (String col : totColumns) {
                BigDecimal total = totMap.get(col).add(obj2Big(rtnMap, col, BigDecimal.ZERO));
                totMap.put(col, total);
            }
        }
        resp.addOutputData("rtnList", rtnList);
        resp.addOutputData("totMap", totMap);
        resp.addOutputData("totRNT_RT", locale.formatNumber((new EP_A30040().getRentRate(totMap, "2", 3).multiply(new BigDecimal("100"))),
            1, "")
                + "%");//�p��X���v
    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param map
     * @param key
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            } else {
                String str = o.toString();
                if (StringUtils.isNotBlank(str)) {
                    return new BigDecimal(str);
                } else {
                    return defaultValue;
                }
            }
        }
        return defaultValue;
    }

}
