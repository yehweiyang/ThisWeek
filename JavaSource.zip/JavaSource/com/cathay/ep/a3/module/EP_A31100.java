package com.cathay.ep.a3.module;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2014/01/03  Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �����ҦC�L���@�Ҳ�
 * �Ҳ�ID    EP_A31100 
 * ���n����    �����ҦC�L���@�Ҳ�
 * </pre>
 * @author �x�Ԫ�
 * @since 2014/1/15
 */
@SuppressWarnings("unchecked")
public class EP_A31100 {
    private static final String SQL_queryList_001 = "com.cathay.ep.a3.module.EP_A31100.SQL_queryList_001";

    private static final String SQL_update_001 = "com.cathay.ep.a3.module.EP_A31100.SQL_update_001";

    /**
     * Ū���j�ӲM��
     * @param reqMap  Map 
     *                  <pre>
     *                  SUB_CPY_ID = �����q�O
     *                  �j�ӥN��    BLD_CD
     *                  �C�L�~��    PRT_YR
     *                  ����N��    PRK_NO
     *                  ���A  PRK_STS
     * @return  rtnList List<Map>   �j�ӲM��
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_A31100_MSG_001");//�ǤJ��Ƥ��o����!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A31100_MSG_002");//�j�ӥN�����o���ŭ�!
        }
        String PRT_YR = MapUtils.getString(reqMap, "PRT_YR");
        if (StringUtils.isBlank(PRT_YR)) {
            eie = getErrorInputException(eie, "EP_A31100_MSG_003");//����N�� ���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("PRT_YR", PRT_YR);
        setIfExist(ds, reqMap, "PRK_NO");
        setIfExist(ds, reqMap, "PRK_STS");
        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //���o�u���A�v����:
            rtnMap.put("PRK_STS_NM", FieldOptionList.getName("EP", "PRK_STS", MapUtils.getString(rtnMap, "PRK_STS")));
            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * ��s���A
     * @param updList  List<Map>   �����ҲM��
     * @param PRK_STS  String  �����Ҫ��A
     * @param user   UserObject  �@�~�H��
     */
    public void update(List<Map> updList, String PRK_STS, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (updList == null || updList.isEmpty()) {
            eie = getErrorInputException(eie, "EP_A31100_MSG_004");//�����ҲM�椣�o���ŭ�!
        }
        if (StringUtils.isBlank(PRK_STS)) {
            eie = getErrorInputException(eie, "EP_A31100_MSG_005");//�����Ҫ��A���o���ŭ�!
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_A31100_MSG_006");//�@�~�H�����o����!
        }
        if (eie != null) {
            throw eie;
        }

        Timestamp currentTime = DATE.currentTime();
        String EmpID = user.getEmpID();
        String DivNo = user.getDivNo();
        String EmpName = user.getEmpName();
        DataSet ds = Transaction.getDataSet();
        //�v���B�z���ʰ����ҦC�L����
        for (Map map : updList) {
            ds.clear();
            ds.setField("PRK_STS", PRK_STS);
            ds.setField("CHG_DATE", currentTime);
            ds.setField("EMP_ID", EmpID);
            ds.setField("DIV_NO", DivNo);
            ds.setField("EMP_NAME", EmpName);
            ds.setField("PRT_YR", MapUtils.getString(map, "PRT_YR"));
            ds.setField("BLD_CD", MapUtils.getString(map, "BLD_CD"));
            ds.setField("PRK_NO", MapUtils.getString(map, "PRK_NO"));
            ds.setField("SUB_CPY_ID", MapUtils.getString(map, "SUB_CPY_ID"));
            ds.setField("PRT_NO", MapUtils.getString(map, "PRT_NO"));
            DBUtil.executeUpdate(ds, SQL_update_001);
        }
    }

    /**
     * �P�_�ȬO�_�s�b�A�]�w��Ʈw����
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setIfExist(DataSet ds, Map reqMap, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}
