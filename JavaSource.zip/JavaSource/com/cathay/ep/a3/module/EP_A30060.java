package com.cathay.ep.a3.module;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.c1.module.EP_C1Z001;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.RptUtils;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * 2018/03/06 �t�X��ؾɤJ�վ� ����[
 * 
 * �ҲզW�� �j�ӯ������J�d�߼Ҳ�
 * �Ҳ�ID    EP_A30060
 * ���n����    �j�ӯ������J�d�߼Ҳ�
 * </pre>
 * @author �¶i��
 * @since  2013/12/19
 */
@SuppressWarnings("unchecked")
public class EP_A30060 {

    private static final String SQL_queryDivList_001 = "com.cathay.ep.a3.module.EP_A30060.SQL_queryDivList_001";

    private static final String SQL_queryList_001 = "com.cathay.ep.a3.module.EP_A30060.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.a3.module.EP_A30060.SQL_queryList_002";

    /**
     * Ū���j�ӯ������J�M��
     * @param SORT_TYPE
     * @param SUB_CPY_ID
     * @param RCV_YM
     * @param CLC_DIV_NO
     * @return
     * @throws ModuleException
     * @throws SQLException
     */
    public List<Map> queryList(String SORT_TYPE, String SUB_CPY_ID, String RCV_YM, String CLC_DIV_NO) throws ModuleException, SQLException {

        if (StringUtils.isBlank(RCV_YM)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30060_MSG_001")); //�����~�뤣�o����
        }

        StringBuilder sb = new StringBuilder();
        String RCV_YM_S = sb.append(RCV_YM.substring(0, 4)).append("01").toString();
        sb.setLength(0);

        //�d�ߤj�ӯ������J
        Map<String, Map> rntMap = queryRentMap(SUB_CPY_ID, RCV_YM_S, RCV_YM, CLC_DIV_NO);

        //�d�ߤj�ӲM��
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("CLC_DIV_NO", CLC_DIV_NO);
        List<Map> rtnList = new EP_A10010().queryList(reqMap);

        // �v���B�z�d�ߵ��G       
        Iterator<Map> iList = rtnList.iterator();
        while (iList.hasNext()) {
            Map data = iList.next();

            Map rentMap = rntMap.get(MapUtils.getString(data, "BLD_CD"));

            if (rentMap != null) {
                data.putAll(rentMap);
                //�]�w�j�өʽ� �ϰ�γ~
                data.put("BLD_KD_1_NM", FieldOptionList.getName("EP", "BLD_KD_1", MapUtils.getString(data, "BLD_KD_1", MapUtils.getString(
                    data, "BLD_KD_1"))));
            } else {
                iList.remove();
            }
        }

        if ("1".equals(SORT_TYPE) || "3".equals(SORT_TYPE)) {
            Collections.sort(rtnList, new order());
        } else {
            Collections.sort(rtnList, new order1());
        }
        if (!"3".equals(SORT_TYPE)) {
            DataSet ds = Transaction.getDataSet();
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("RCV_YM_S", RCV_YM_S);
            ds.setField("RCV_YM", RCV_YM);
            if (StringUtils.isNotEmpty(CLC_DIV_NO)) {
                ds.setField("CLC_DIV_NO", CLC_DIV_NO);
            }
            DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
            ds.next();
            Map zint = VOTool.dataSetToMap(ds);
            if (zint == null) {
                zint = new HashMap();
            }
            zint.put("BLD_CD", "ZINT");
            if (StringUtils.isNotEmpty(CLC_DIV_NO)) {
                zint.put("CLC_DIV_NO", CLC_DIV_NO);
            }
            zint.put("BLD_NAME", MessageUtil.getMessage("EP_A30060_MSG_008"));//�㯲��
            zint.put("SAL_AMT", "0");
            zint.put("PRP_AMT", "0");
            zint.put("TRA_PRP_AMT", "0");
            zint.put("RJT_RNT_AMT", "0");
            zint.put("BLD_KD_1_NM", "");

            //�p��������B
            String RCV_YM_BD = sb.append(RCV_YM).insert(4, "-").append("-01").toString();
            sb.setLength(0);
            String RCV_YM_ED = DATE.getMonthLastDate(RCV_YM_BD);
            String RCV_YM_S_BD = sb.append(RCV_YM_S).insert(4, "-").append("-01").toString();
            ds.clear();
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("RCV_YM_BD", RCV_YM_BD);
            ds.setField("RCV_YM_ED", RCV_YM_ED);
            ds.setField("RCV_YM_S_BD", RCV_YM_S_BD);
            if (StringUtils.isNotEmpty(CLC_DIV_NO)) {
                ds.setField("DIV_NO", CLC_DIV_NO);
            }
            DBUtil.searchAndRetrieve(ds, SQL_queryList_002);
            ds.next();
            Map rjtMap = VOTool.dataSetToMap(ds);
            if (rjtMap != null) {
                BigDecimal rjtAmt = obj2Big(rjtMap, "RJT_AMT", BigDecimal.ZERO);
                BigDecimal sumRjtAmt = obj2Big(rjtMap, "SUM_RJT_AMT", BigDecimal.ZERO);
                zint.put("RJT_RNT_AMT", rjtAmt);
                zint.put("NET_SAL_AMT", obj2Big(zint, "NET_SAL_AMT", BigDecimal.ZERO).subtract(rjtAmt));
                zint.put("SUM_NET_AMT", obj2Big(zint, "SUM_NET_AMT", BigDecimal.ZERO).subtract(sumRjtAmt));
            }

            rtnList.add(zint);
        }
        return rtnList;
    }

    /**
     * Ū���j�Ӻ޲z���M��
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException
     * @throws SQLException
     */
    public List<Map> queryDivList(String SUB_CPY_ID) throws ModuleException, SQLException {

        List<Map> rtnList = new ArrayList<Map>();
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//���
            DataSet ds = Transaction.getDataSet();
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.searchAndRetrieve(ds, SQL_queryDivList_001);

            EP_A10010 theEP_A10010 = new EP_A10010();
            while (ds.next()) {
                Map rtnMap = VOTool.dataSetToMap(ds);

                //�޲z���
                rtnMap.put("CLC_DIV_NO_NM", theEP_A10010.getDivName(MapUtils.getString(rtnMap, "CLC_DIV_NO"), SUB_CPY_ID));
                rtnList.add(rtnMap);
            }

        } else {//�D���
            Map DIV_MAP = FieldOptionList.getFieldOptions("EP", "AGT_DIV_" + SUB_CPY_ID);
            for (Object key : DIV_MAP.keySet()) {
                Map rtnMap = new HashMap();
                rtnMap.put("CLC_DIV_NO", key.toString());
                rtnMap.put("CLC_DIV_NO_NM", DIV_MAP.get(key));
                rtnList.add(rtnMap);
            }
        }
        return rtnList;
    }

    /**
     * �ץXEXCEL
     * @param reqMap
     * @param locale
     * @param resp
     * @throws Exception
     */
    public void exportXLS(Map reqMap, List<Map> rtnList, LocaleDisplay locale, ResponseContext resp) throws Exception {
        String SORT_TYPE = MapUtils.getString(reqMap, "SORT_TYPE");
        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
        String EXP_ALL = MapUtils.getString(reqMap, "EXP_ALL");
        String CLC_DIV_NO_NM = MapUtils.getString(reqMap, "CLC_DIV_NO_NM", "");
        String fileName;
        StringBuilder sb = new StringBuilder(DATE.toDate_yyyyMMdd(DATE.getDBDate())).append(".xls");

        if ("1".equals(SORT_TYPE)) {
            fileName = sb.insert(0, MessageUtil.getMessage("EP_A30060_MSG_003")).toString(); //�������J_�j�ӥN��_
        } else {
            fileName = sb.insert(0, MessageUtil.getMessage("EP_A30060_MSG_004")).toString(); //�������J_�ϥΩʽ�_
        }
        sb.setLength(0);

        FileOutputStream fileOutputString = null;
        try {
            HSSFWorkbook workbook = new HSSFWorkbook();// �u�@��
            HSSFSheet sheet = workbook.createSheet(fileName);
            sheet.setMargin(HSSFSheet.LeftMargin, 0);
            sheet.setMargin(HSSFSheet.RightMargin, 0);
            sheet.setMargin(HSSFSheet.TopMargin, 0);
            sheet.setMargin(HSSFSheet.BottomMargin, 0);

            boolean isNeedSub = "2".equals(SORT_TYPE);//���ƧǤ覡���ϥΩʽ�ݤp�p

            // �]�w���j�p
            getSheetColumnWidth(sheet, EXP_ALL, isNeedSub);

            //�]�w�C�L���Y
            workbook.setRepeatingRowsAndColumns(0, 0, 0, 0, 2);
            sheet.setHorizontallyCenter(true);//�C�L����m��

            //�g�J���Ӹ��
            createworkbook(locale, RCV_YM, CLC_DIV_NO_NM, workbook, sheet, isNeedSub, rtnList, EXP_ALL);

            // ���ͼȦs��
            File downloadFile = RptUtils.createTempFile(fileName);

            // ��X excel �ɪ����|
            String path = downloadFile.getPath();
            fileOutputString = new FileOutputStream(path);
            workbook.write(fileOutputString);
            RptUtils.cryptoDownloadParameterToResp(fileName, downloadFile, resp);

        } finally {
            if (fileOutputString != null) {
                fileOutputString.close();
            }
        }

    }

    /**
     * Ū���j�ӯ������J
     * @param SUB_CPY_ID
     * @param RCV_YM
     * @param CLC_DIV_NO
     * @param type
     * @return
     * @throws ModuleException
     */
    private Map<String, Map> queryRentMap(String SUB_CPY_ID, String RCV_YM_S, String RCV_YM, String CLC_DIV_NO) throws ModuleException {

        EP_C1Z001 theEP_C1Z001 = new EP_C1Z001();
        List<Map> rtnList = theEP_C1Z001.queryRNTAmtByBldcd(RCV_YM_S, RCV_YM, null, CLC_DIV_NO, SUB_CPY_ID);

        Map<String, Map> rentMap = new HashMap<String, Map>();
        if (rtnList != null) {
            for (Map rtnMap : rtnList) {
                //�������J�b�B = �������J(�L�ȵ��s) - �w�����J(�L�ȵ��s) + ��b�`���B(�L�ȵ��s) �V �P�f�h�^
                rtnMap.put("NET_SAL_AMT", obj2Big(rtnMap, "SAL_AMT", BigDecimal.ZERO).subtract(obj2Big(rtnMap, "PRP_AMT", BigDecimal.ZERO))
                        .add(obj2Big(rtnMap, "TRA_PRP_AMT", BigDecimal.ZERO).subtract(obj2Big(rtnMap, "RJT_RNT_AMT", BigDecimal.ZERO))));
                rtnMap.put("SUM_NET_AMT", obj2Big(rtnMap, "SUM_SAL_AMT", BigDecimal.ZERO).subtract(
                    obj2Big(rtnMap, "SUM_PRP_AMT", BigDecimal.ZERO)).add(obj2Big(rtnMap, "SUM_TRA_PRP_AMT", BigDecimal.ZERO)).subtract(
                    obj2Big(rtnMap, "SUM_RJT_RNT_AMT", BigDecimal.ZERO)));
                rentMap.put(MapUtils.getString(rtnMap, "BLD_CD"), rtnMap);
            }
        }

        return rentMap;

    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }

    /**
     * �]�w���j�p
     * @param sheet
     * @param EXP_ALL
     * @param isNeedSub
     */
    private void getSheetColumnWidth(HSSFSheet sheet, String EXP_ALL, boolean isNeedSub) {

        sheet.setColumnWidth(0, 27 * 256);
        sheet.setColumnWidth(1, 20 * 256);
        sheet.setColumnWidth(2, 20 * 256);
        sheet.setColumnWidth(3, 20 * 256);
        sheet.setColumnWidth(4, 20 * 256);
        sheet.setColumnWidth(5, 20 * 256);
        sheet.setColumnWidth(6, 20 * 256);
        if ("Y".equals(EXP_ALL) || isNeedSub) {
            sheet.setColumnWidth(7, 20 * 256);
        }

    }

    /**
     * ���ͩ��Ӹ��
     * @param RCV_YM
     * @param CLC_DIV_NO_NM
     * @param workbook
     * @param sheet
     * @param isNeedSub
     * @param rtnList
     * @param EXP_ALL
     * @throws ModuleException
     * @throws ParseException 
     */
    private void createworkbook(LocaleDisplay locale, String RCV_YM, String CLC_DIV_NO_NM, HSSFWorkbook workbook, HSSFSheet sheet,
            boolean isNeedSub, List<Map> rtnList, String EXP_ALL) throws ModuleException, ParseException {

        //�]�wSTYLE
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���");//���Y
        HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���");//�����Y
        HSSFCellStyle style7 = createStyle(workbook, 7, "�s�ө���");//���Ӥ�r�a�k

        HSSFRow row;
        int beginRow = 0;

        //�]�w����
        int totalColumns = 0;
        if ("Y".equals(EXP_ALL) || isNeedSub) {
            totalColumns = 8;
        } else {
            totalColumns = 7;
        }

        //���D
        //��1�� (�s�����:)
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style7, 0, MessageUtil.getMessage("EP_A30060_MSG_006", new Object[] { locale
                .formatDate(DATE.today(), "/", "") }), false, true, beginRow, beginRow, 0, totalColumns - 1);//�s�����:{0}
        beginRow++;

        //��2��[RCV_YM (e.g.103�~1��][�ӿ��줤��]�U�j�ӯ������J���Ӫ�
        String tmpRcvYmDate = DATE.toDateFormat(RCV_YM + "01", "yyyyMMdd", "yyyy-MM-dd");
        row = sheet.createRow(beginRow);
        StringBuilder sb = new StringBuilder();
        sb.append(MessageUtil.getMessage("EP_A30060_MSG_007", new Object[] { locale.formatDatey(tmpRcvYmDate, ""),
                tmpRcvYmDate.split("-")[1] }));
        sb.append(CLC_DIV_NO_NM);
        sb.append(MessageUtil.getMessage("EP_A30060_MSG_005"));
        setColumn(sheet, row, style0, 0, sb.toString(), false, true, beginRow, beginRow, 0, totalColumns - 1);//�U�j�ӯ������J���Ӫ�
        sb.setLength(0);
        beginRow++;

        //���Y
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style1, 0, MessageUtil.getMessage("EP_A30060_UI_006"), false, false, null, null, null, null);//�j�ӦW��
        setColumn(sheet, row, style1, 1, MessageUtil.getMessage("EP_A30060_UI_007"), false, false, null, null, null, null);//�������J
        setColumn(sheet, row, style1, 2, MessageUtil.getMessage("EP_A30060_UI_008"), false, false, null, null, null, null);//�w�����J
        setColumn(sheet, row, style1, 3, MessageUtil.getMessage("EP_A30060_UI_009"), false, false, null, null, null, null);//��b���B
        setColumn(sheet, row, style1, 4, MessageUtil.getMessage("EP_A30060_UI_010"), false, false, null, null, null, null);//�P�f�h�^
        setColumn(sheet, row, style1, 5, MessageUtil.getMessage("EP_A30060_UI_011"), false, false, null, null, null, null);//�������J�b�B
        setColumn(sheet, row, style1, 6, MessageUtil.getMessage("EP_A30060_UI_012"), false, false, null, null, null, null);//�֭p�`�B
        if ("Y".equals(EXP_ALL) || isNeedSub) {
            setColumn(sheet, row, style1, 7, MessageUtil.getMessage("EP_A30060_UI_013"), false, false, null, null, null, null);//�j�өʽ�      
        }

        beginRow++;

        //���Ӹ��(�t�X�p,�s�դp�p)
        createDetail(workbook, beginRow, sheet, row, isNeedSub, rtnList, totalColumns, EXP_ALL);

    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @param isNeedBorder
     * @return
     */
    private HSSFCellStyle createStyle(HSSFWorkbook workbook, int type, String font_type) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();

        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 16); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);

        //�Ʀr�榡
        HSSFDataFormat format = workbook.createDataFormat();
        boolean needSameBorder = true;
        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�j���Y
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            font.setFontHeightInPoints((short) 22); // �j�p         
            needSameBorder = false;
        } else if (type == 1) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.BLACK.index);
            font.setColor(HSSFColor.BLACK.index);
            style.setWrapText(true);//�۰ʧ��
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 3) {//��r�a�k
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        } else if (type == 5) {//���ӼƦr(�d����,�L�p�Ʀ�)
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
            style.setDataFormat(format.getFormat("#,##0"));
        } else if (type == 6) {//���ӼƦr(�d����,��p�Ʀ��3��)
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
            style.setDataFormat(format.getFormat("#,##0.000"));
        } else if (type == 7) {//��r�a�k
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
            needSameBorder = false;
        }

        style.setFont(font);

        //�~��
        if (needSameBorder) {
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        }

        return style;
    }

    /**
     * �]�w���
     * @param sheet
     * @param bodyRow
     * @param style
     * @param columnNumber
     * @param content
     * @param isNumeric
     * @param doCombine
     * @param firstRow
     * @param lastRow
     * @param firstCol
     * @param lastCol
     */
    private void setColumn(HSSFSheet sheet, HSSFRow bodyRow, HSSFCellStyle style, Integer columnNumber, String content, boolean isNumeric,
            boolean doCombine, Integer firstRow, Integer lastRow, Integer firstCol, Integer lastCol) {

        HSSFCell bodyCell;
        bodyCell = bodyRow.createCell(columnNumber);
        bodyCell.setCellStyle(style);

        if (doCombine) {
            for (int s = firstCol; s <= lastCol; s++) {
                bodyCell = bodyRow.createCell(s);
                bodyCell.setCellStyle(style);
            }

            //�X���x�s��
            CellRangeAddress range_inputCount = new CellRangeAddress(firstRow, lastRow, firstCol, lastCol);
            sheet.addMergedRegion(range_inputCount);

            bodyCell = bodyRow.getCell(firstCol);
        }

        if (isNumeric) {
            if (StringUtils.isNotBlank(content)) {
                bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                Double bodyText = new Double(content);
                bodyCell.setCellValue(bodyText);
            }
        } else {
            HSSFRichTextString text = new HSSFRichTextString(content);
            bodyCell.setCellValue(text);
        }
    }

    /**
     * �إߪ�����Ӹ��
     * @param beginRow
     * @param sheet
     * @param row
     * @param isNeedSub
     * @param rtnList
     * @param totalColumns
     * @param EXP_ALL
     * @throws ModuleException
     */
    private void createDetail(HSSFWorkbook workbook, int beginRow, HSSFSheet sheet, HSSFRow row, boolean isNeedSub, List<Map> rtnList,
            int totalColumns, String EXP_ALL) throws ModuleException {

        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���");//���Ӥ�r(�m��)
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���");//���Ӥ�r(�m�k)
        HSSFCellStyle style4 = createStyle(workbook, 4, "�s�ө���");//���Ӥ�r(�m��)
        HSSFCellStyle style5 = createStyle(workbook, 5, "�s�ө���");//���ӼƦr(�d����,�L�p�Ʀ�)

        Map<String, Map> groupMap = new HashMap<String, Map>();
        //�p�p,�X�p���
        String[] sumColumns = { "SAL_AMT", "PRP_AMT", "TRA_PRP_AMT", "RJT_RNT_AMT", "NET_SAL_AMT", "SUM_NET_AMT" };
        //�X�p�֭p��l
        Map<String, BigDecimal> totMap = new HashMap<String, BigDecimal>();
        for (String col : sumColumns) {
            totMap.put(col, BigDecimal.ZERO);
        }
        //����
        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);

            //�s�դp�p
            if (isNeedSub) {
                String BLD_KD_1_NM = MapUtils.getString(rtnMap, "BLD_KD_1_NM");
                Map<String, BigDecimal> subTotMap;
                //���s,���ͤ@���s�դp�p
                if (!groupMap.isEmpty() && !groupMap.containsKey(BLD_KD_1_NM)) {
                    Iterator entries = groupMap.entrySet().iterator();
                    entries.hasNext();
                    Entry thisEntry = (Entry) entries.next();
                    String groupkey = (String) thisEntry.getKey();
                    subTotMap = (Map) thisEntry.getValue();
                    row = sheet.createRow(beginRow);
                    setColumn(sheet, row, style3, 0, groupkey + MessageUtil.getMessage("EP_A30060_MSG_002"), false, false, null, null,
                        null, null);//�s�զW��+�p�p(�j�ӦW��)
                    setColumn(sheet, row, style5, 1, subTotMap.get("SAL_AMT").toPlainString(), true, false, null, null, null, null);//�������J
                    setColumn(sheet, row, style5, 2, subTotMap.get("PRP_AMT").toPlainString(), true, false, null, null, null, null);//�w�����J
                    setColumn(sheet, row, style5, 3, subTotMap.get("TRA_PRP_AMT").toPlainString(), true, false, null, null, null, null);//��b���B
                    setColumn(sheet, row, style5, 4, subTotMap.get("RJT_RNT_AMT").toPlainString(), true, false, null, null, null, null);//�P�f�h�^
                    setColumn(sheet, row, style5, 5, subTotMap.get("NET_SAL_AMT").toPlainString(), true, false, null, null, null, null);//�������J�b�B
                    setColumn(sheet, row, style5, 6, subTotMap.get("SUM_NET_AMT").toPlainString(), true, false, null, null, null, null);//�֭p�`�B
                    setColumn(sheet, row, style4, 7, null, false, false, null, null, null, null);//�j�өʽ� 
                    beginRow++;
                    groupMap.clear();

                }
                if (groupMap.isEmpty()) {
                    subTotMap = new HashMap<String, BigDecimal>();
                    for (String col : sumColumns) {
                        subTotMap.put(col, BigDecimal.ZERO);
                    }
                    groupMap.put(BLD_KD_1_NM, subTotMap);
                } else {
                    subTotMap = groupMap.get(BLD_KD_1_NM);
                }

                //�s�դp�p�p��
                for (String col : sumColumns) {
                    BigDecimal total = subTotMap.get(col).add(obj2Big(rtnMap, col, BigDecimal.ZERO));
                    subTotMap.put(col, total);
                }
            }

            //���Ӹ��
            row = sheet.createRow(beginRow);

            String BLD_NM = MapUtils.getString(rtnMap, "BLD_NAME", "");
            if ("N".equals(EXP_ALL) && BLD_NM.length() > 6) {
                BLD_NM = BLD_NM.substring(0, 6);
            }
            StringBuilder sb = new StringBuilder();
            sb.append(MapUtils.getString(rtnMap, "BLD_CD", "")).append(" ").append(BLD_NM);
            String BLD_CD_NAME = sb.toString();
            sb.setLength(0);
            setColumn(sheet, row, style4, 0, BLD_CD_NAME, false, false, null, null, null, null); //�j�ӦW��
            setColumn(sheet, row, style5, 1, MapUtils.getString(rtnMap, "SAL_AMT"), true, false, null, null, null, null);//�������J
            setColumn(sheet, row, style5, 2, MapUtils.getString(rtnMap, "PRP_AMT"), true, false, null, null, null, null); //�w�����J
            setColumn(sheet, row, style5, 3, MapUtils.getString(rtnMap, "TRA_PRP_AMT"), true, false, null, null, null, null);//��b���B
            setColumn(sheet, row, style5, 4, MapUtils.getString(rtnMap, "RJT_RNT_AMT"), true, false, null, null, null, null);//�P�f�h�^
            setColumn(sheet, row, style5, 5, MapUtils.getString(rtnMap, "NET_SAL_AMT"), true, false, null, null, null, null); //�������J�b�B
            setColumn(sheet, row, style5, 6, MapUtils.getString(rtnMap, "SUM_NET_AMT"), true, false, null, null, null, null);//�֭p�`�B
            if ("Y".equals(EXP_ALL) || isNeedSub) {
                setColumn(sheet, row, style4, 7, MapUtils.getString(rtnMap, "BLD_KD_1_NM"), false, false, null, null, null, null); //�j�өʽ�  
            }

            beginRow++;

            //�X�p�p��
            for (String col : sumColumns) {
                BigDecimal total = totMap.get(col).add(obj2Big(rtnMap, col, BigDecimal.ZERO));
                totMap.put(col, total);
            }

        }

        //�̫�@���s�տ�X
        if (!groupMap.isEmpty()) {

            Iterator entries = groupMap.entrySet().iterator();
            entries.hasNext();
            Entry thisEntry = (Entry) entries.next();
            String groupkey = (String) thisEntry.getKey();
            Map<String, BigDecimal> subTotMap = (Map) thisEntry.getValue();
            row = sheet.createRow(beginRow);
            setColumn(sheet, row, style3, 0, groupkey + MessageUtil.getMessage("EP_A30060_MSG_002"), false, false, null, null, null, null);//�s�զW��+�p�p(�j�ӦW��)
            setColumn(sheet, row, style5, 1, subTotMap.get("SAL_AMT").toPlainString(), true, false, null, null, null, null);//�������J
            setColumn(sheet, row, style5, 2, subTotMap.get("PRP_AMT").toPlainString(), true, false, null, null, null, null);//�w�����J
            setColumn(sheet, row, style5, 3, subTotMap.get("TRA_PRP_AMT").toPlainString(), true, false, null, null, null, null);//��b���B
            setColumn(sheet, row, style5, 4, subTotMap.get("RJT_RNT_AMT").toPlainString(), true, false, null, null, null, null);//�P�f�h�^
            setColumn(sheet, row, style5, 5, subTotMap.get("NET_SAL_AMT").toPlainString(), true, false, null, null, null, null);//�������J�b�B
            setColumn(sheet, row, style5, 6, subTotMap.get("SUM_NET_AMT").toPlainString(), true, false, null, null, null, null);//�֭p�`�B
            setColumn(sheet, row, style4, 7, null, false, false, null, null, null, null);//�j�өʽ� 
            beginRow++;
            groupMap.clear();

        }

        //�X�p
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EP_A30060_UI_001"), false, false, null, null, null, null); //�X�p(�j�ӦW��)
        setColumn(sheet, row, style5, 1, totMap.get("SAL_AMT").toPlainString(), true, false, null, null, null, null);//�������J
        setColumn(sheet, row, style5, 2, totMap.get("PRP_AMT").toPlainString(), true, false, null, null, null, null);//�w�����J
        setColumn(sheet, row, style5, 3, totMap.get("TRA_PRP_AMT").toPlainString(), true, false, null, null, null, null);//��b���B
        setColumn(sheet, row, style5, 4, totMap.get("RJT_RNT_AMT").toPlainString(), true, false, null, null, null, null);//�P�f�h�^
        setColumn(sheet, row, style5, 5, totMap.get("NET_SAL_AMT").toPlainString(), true, false, null, null, null, null);//�������J�b�B
        setColumn(sheet, row, style5, 6, totMap.get("SUM_NET_AMT").toPlainString(), true, false, null, null, null, null);//�֭p�`�B
        if ("Y".equals(EXP_ALL) || isNeedSub) {
            setColumn(sheet, row, style4, 7, null, false, false, null, null, null, null);//�j�өʽ� 
        }

    }

    /**
     * <pre>
     * �N rtnList �Ƨǩһݤ�Comparator
     * @author i9300625
     * </pre>
     */
    private class order implements Comparator<Map> {

        public int compare(Map aMap, Map bMap) {

            String aValue = MapUtils.getString(aMap, "BLD_CD", "");
            String bValue = MapUtils.getString(bMap, "BLD_CD", "");

            int i = aValue.compareTo(bValue);

            return i;

        }
    }

    /**
     * <pre>
     * �N rtnList �Ƨǩһݤ�Comparator
     * @author i9300625
     * </pre>
     */
    private class order1 implements Comparator<Map> {

        public int compare(Map aMap, Map bMap) {

            String aValue = MapUtils.getString(aMap, "BLD_KD_1", "");
            String bValue = MapUtils.getString(bMap, "BLD_KD_1", "");

            int i = aValue.compareTo(bValue);

            return i;

        }
    }
}
