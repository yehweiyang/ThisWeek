package com.cathay.ep.a3.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.rpt.RptUtils;
import com.cathay.rpt.XlsUtils;
import com.cathay.rpt.XlsUtils.Options;
import com.cathay.rpt.XlsUtils.SORT_RULE;
import com.cathay.rpt.datasource.xls.ColumnOptions;
import com.cathay.rpt.datasource.xls.ColumnSetting;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 *DATE  Description Author
 *2013/10/08  Created ������
 *2018/03/20  ��ؾɤJ ����[
 *
 *�@�B  �{���\�෧�n�����G
 *�ҲզW��    �j�ӫȤ�d�߼Ҳ�
 *�Ҳ�ID    EP_A30040
 *���n����    �j�ӫȤ�d�߼Ҳ�
 *
 * </pre>
 * @author �x�Ԫ�
 * @since 2014/1/2
 */
@SuppressWarnings("unchecked")
public class EP_A30040 {
    private static final BigDecimal BD_100 = new BigDecimal("100");

    private static final Logger log = Logger.getLogger(EP_A30040.class);

    private static final String SQL_queryList1_001 = "com.cathay.ep.a3.module.EP_A30040.SQL_queryList1_001";

    private static final String SQL_queryList2_001 = "com.cathay.ep.a3.module.EP_A30040.SQL_queryList2_001";

    private static final String SQL_queryList3_001 = "com.cathay.ep.a3.module.EP_A30040.SQL_queryList3_001";

    private static final String SQL_queryList5_001 = "com.cathay.ep.a3.module.EP_A30040.SQL_queryList5_001";

    private static final String SQL_printLog_001 = "com.cathay.ep.a3.module.EP_A30040.SQL_printLog_001";

    private static final String SQL_remove_001 = "com.cathay.ep.a3.module.EP_A30040.SQL_remove_001";

    private static final String SQL_checkAdd_001 = "com.cathay.ep.a3.module.EP_A30040.SQL_checkAdd_001";

    private static final String SQL_getPrintNo_001 = "com.cathay.ep.a3.module.EP_A30040.SQL_getPrintNo_001";

    private static final String[] RNT_KDs = new String[] { "1", "2", "3", "4", "5", "6" };

    private static final String SQL_queryList6_001 = "com.cathay.ep.a3.module.EP_A30040.SQL_queryList6_001";

    /**
     * [20190801] API�s��	EPA004	qryRoomList	 API�W��	��ؤj�ӫǧO��Ƭd��API		
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryRoomListWithRsv(Map reqMap) throws ModuleException {
    	reqMap.put("RNT_KD", "1"); //�ӯ�����=�Ӽh�A�d�߫ǧO�O��
    	List<Map> rtnList = queryList(reqMap);
    	try{
    		reqMap.put("QRY_RSV_KD", "Y"); 
    		List<Map> rsvList = new EP_A30020().queryList(reqMap);
    		MultiKeyMap mkmap = new MultiKeyMap();
    		for(Map rsvData: rsvList){
    			
    			mkmap.put(rsvData.get("BLD_CD"), rsvData.get("FLD_NO"), rsvData.get("ROOM_NO") , rsvData);
    		}
    		//���o�ǧO�O�d�O��
    		for(Map rtnMap: rtnList) {
    			Map rsvData = (Map) mkmap.get(rtnMap.get("BLD_CD"), rtnMap.get("FLD_NO"), rtnMap.get("ROOM_NO") );
    			log.debug("RSVMap:"+ rsvData);
    			if(rsvData !=null && rsvData.containsKey("RSV_KD")) {
        			log.debug("RSVMap:"+ rsvData);
        			rtnMap.put("IS_RSV", rsvData.get("IS_RSV"));
        			rtnMap.put("RSV_KD", rsvData.get("RSV_KD"));
        			rtnMap.put("RSV_KD_NM", rsvData.get("RSV_KD_NM"));
        			rtnMap.put("RSV_MEMO", rsvData.get("RSV_MEMO"));
    			}
    		}
    	} catch(DataNotFoundException dnfe) {
    		//ignone DataNotFoundException 
    	}
    	
        return rtnList;
    }        
    
    /**
     * Ū���j�Ӹ��
     * @param reqMap Map 
     *          <pre>
     *          SUB_CPY_ID = �����q�O
     *          BLD_CD  = �j�ӥN��
     *          BLD_NAME = �j�ӦW��
     *          CRT_NO = �����N��
     *          </pre>
     * @return rtnMap  Map �j�ӲM��
     */
    public Map queryMap(Map reqMap) throws SQLException, ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30040_MSG_001"));//�j�Ӹ�Ƭd�߱��󤣱o���ŭ�!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        //�H�ǤJ�j�ӥN���d�ߤj�Ӱ򥻸�ơG
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BLD_CD", BLD_CD);
        EP_A10010 theEP_A10010 = new EP_A10010();
        Map rtnMap = theEP_A10010.queryMap(reqMap);
        //��s�ϥη��p
        Map<String, Map> sumInfo = new HashMap<String, Map>();
        sumInfo.put(BLD_CD, rtnMap);
        theEP_A10010.setSumInfo(BLD_CD, SUB_CPY_ID, sumInfo);
        rtnMap = sumInfo.get(BLD_CD);

        rtnMap.put("RNT_RT", new EP_A30040().getRentRate(rtnMap, "1"));
        //���o�`���
        rtnMap.put("TOT_PMS_AMT", new EP_B10020().getBldRmPms(BLD_CD, SUB_CPY_ID));
        return rtnMap;

    }

    /**
     * @param reqMap
     * @param rntType
     * @return
     * @throws ErrorInputException
     */
    public String getRentRate(Map reqMap, String rntType) throws ErrorInputException {
        BigDecimal rate = this.getRentRate(reqMap, rntType, 2);
        StringBuffer sb = new StringBuffer();
        String strRate = sb.append(rate.multiply(BD_100)).append("%").toString();
        sb.setLength(0);
        return strRate;
    }

    /**
     * �p��X���v
     * @param reqMap  Map �j�Ӱ򥻸��
     * @param rntType String  ���ۥΤ��X���v(1:100%; 2:0%)
     * @return RNT_RT  String  �X���v
     */
    public BigDecimal getRentRate(Map reqMap, String rntType, int scale) throws ErrorInputException {
        if (StringUtils.isBlank(rntType)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30040_MSG_002"));//���ۥΤ��X���v���o���ŭ�!
        }

        if (reqMap == null || reqMap.isEmpty()) {
            return BigDecimal.ZERO;
        }
        BigDecimal BLD_SIZE = obj2Big(reqMap, "BLD_SIZE", BigDecimal.ZERO);
        BigDecimal SLF_SIZE = obj2Big(reqMap, "SLF_SIZE", BigDecimal.ZERO);
        // �p��X���v
        //�i�X�����n 
        BigDecimal RNT_SIZE_TOT = BLD_SIZE.subtract(SLF_SIZE);
        if (BigDecimal.ZERO.compareTo(RNT_SIZE_TOT) == 0) {
            return "1".equals(rntType) ? BigDecimal.ONE : BigDecimal.ZERO;
        }
        BigDecimal RNT_SIZE = obj2Big(reqMap, "RNT_SIZE", BigDecimal.ZERO);
        return RNT_SIZE.divide(RNT_SIZE_TOT, scale, BigDecimal.ROUND_HALF_UP);
        //(�|�ˤ��J��p�ƨ��)
    }

    /**
     * Ū���j�ӫȤ�M��
     * @param reqMap  Map 
     *              <pre>
     *              SUB_CPY_ID = �����q�O
     *              BLD_CD  = �j�ӥN��
     *              BLD_NAME = �j�ӦW��
     *              CRT_NO = �����N��
     *              RNT_KD = �ӯ�����
     *              CUS_NO
     *              </pre>
     * @return rtnList List<Map>   �j�ӲM��
     */
    public List<Map> queryAllRoomList(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30040_MSG_003"));//�j�ӫȤ�d�߱��󤣱o����!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        DBUtil.searchAndRetrieve(ds, SQL_queryList5_001, false);
        List<Map> rtnList = new ArrayList<Map>();
        MultiKeyMap regMap = new MultiKeyMap();
        while (ds.next()) {
            //�v���B�z�d�ߵ��G
            Map data = VOTool.dataSetToMap(ds);
            //�n�O�γ~
            data.put("FLD_TYPE_NM", getNM("FLD_TYPE", data, "FLD_TYPE"));
            //�ϥΪ��p
            data.put("USE_TYPE_NM", getNM("USE_TYPE", data, "USE_TYPE"));
            //���ϥΩʽ�
            data.put("USE_KD_NM", getNM("USE_KD", data, "USE_KD"));

            String reg = MapUtils.getString(data, "REG");
            String rntStrDate = MapUtils.getString(data, "RNT_STR_DATE", "");
            if ("Y".equals(reg) && StringUtils.isNotEmpty(rntStrDate)) {

                regMap.put(MapUtils.getString(data, "BLD_CD"), MapUtils.getString(data, "FLD_NO"), MapUtils.getString(data, "ROOM_NO"),
                    MapUtils.getString(data, "REG"));
            }
            rtnList.add(data);
        }

        Iterator<Map> iList = rtnList.iterator();
        StringBuilder sb = new StringBuilder();
        while (iList.hasNext()) {
            Map data = iList.next();
            String reg = MapUtils.getString(data, "REG");
            String USE_TYPE = MapUtils.getString(data, "USE_TYPE");
            boolean isDelete = false;
            // ��ǧO�Ÿm�ǧO�A�p�G���w����A�j�ӫȤᤣ��� �Ÿm�ǧO
            if ("N".equals(reg) && "3".equals(USE_TYPE)) {
                String regRoom = (String) regMap.get(MapUtils.getString(data, "BLD_CD"), MapUtils.getString(data, "FLD_NO"), MapUtils
                        .getString(data, "ROOM_NO"));
                if (regRoom != null) {
                    iList.remove();
                    isDelete = true;
                }
            }

            if (!isDelete) {
                String CRT_NO = MapUtils.getString(data, "CRT_NO", "");
                String CUS_NO = MapUtils.getString(data, "CUS_NO", "");
                BigDecimal ROOM_SIZE = obj2Big(data, "ROOM_SIZE", BigDecimal.ZERO);
                BigDecimal FLD_SIZE = obj2Big(data, "FLD_SIZE", BigDecimal.ZERO);
                BigDecimal BLD_SIZE = obj2Big(data, "BLD_SIZE", BigDecimal.ZERO);
                BigDecimal FLD_RT = BigDecimal.ZERO;
                BigDecimal BLD_RT = BigDecimal.ZERO;
                if (FLD_SIZE.compareTo(BigDecimal.ZERO) != 0) {
                    FLD_RT = ROOM_SIZE.divide(FLD_SIZE, 13, BigDecimal.ROUND_HALF_UP);
                }
                if (BLD_SIZE.compareTo(BigDecimal.ZERO) != 0) {
                    BLD_RT = ROOM_SIZE.divide(BLD_SIZE, 13, BigDecimal.ROUND_HALF_UP);
                }

                data.put("CRT_NO_CUS_NO", sb.append(CRT_NO).append("_").append(CUS_NO).toString());
                sb.setLength(0);
                data.put("FLD_RT", FLD_RT);
                data.put("BLD_RT", BLD_RT);

            }

        }

        return rtnList;

    }

    /**
     * Ū���j�ӫȤ�M��
     * @param reqMap  Map 
     *              <pre>
     *              SUB_CPY_ID = �����q�O
     *              BLD_CD  = �j�ӥN��
     *              BLD_NAME = �j�ӦW��
     *              CRT_NO = �����N��
     *              RNT_KD = �ӯ�����(1:�Ӽh;2����;3:����;4:�妸����; 5:�Ҧ��Ӽh; 6:�Ӽh��������)
     *              CUS_NO
     *              </pre>
     * @return rtnList List<Map>   �j�ӲM��
     * @throws DBException 
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30040_MSG_003"));//�j�ӫȤ�d�߱��󤣱o����!
        }
        String RNT_KD = MapUtils.getString(reqMap, "RNT_KD");

        if (StringUtils.isBlank(RNT_KD)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30040_MSG_015"));//�ӯ��������o���ŭ�!
        } else if (!ArrayUtils.contains(RNT_KDs, RNT_KD)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30040_MSG_004", new Object[] { RNT_KD }));//�ǤJ�ӯ�����{0}���~!
        }

        DataSet ds = Transaction.getDataSet();
        if ("1".equals(RNT_KD) || "5".equals(RNT_KD)) {
            //�d�߼Ӽh�M��
            //�d�L��Ƶ������` 
            return this.queryList1(reqMap, ds);
        }
        if ("2".equals(RNT_KD)) {
            //�d�ߨ���M��
            //�d�L��Ƶ������` 
            return this.queryList2(reqMap, ds);
        }
        if ("3".equals(RNT_KD)) {
            List rtnList = new ArrayList<Map>();
            //�d�߼Ӽh�M��
            //�d�L��Ƶ������` 
            List List1 = this.queryList1(reqMap, ds);
            if (List1 != null && !List1.isEmpty()) {
                rtnList.addAll(List1);
            }
            List List2 = this.queryList2(reqMap, ds);
            //�d�ߨ���M��
            //�d�L��Ƶ������` 
            if (List2 != null && !List2.isEmpty()) {
                rtnList.addAll(List2);
            }
            return rtnList;
        }
        //�d�ߧ妸�����ҲM��
        if ("4".equals(RNT_KD)) {
            return this.queryList3(reqMap, ds);
        }

        // "6".equals(RNT_KD) 
        //�d�߼Ӽh�ӯ���������
        return this.queryList6(reqMap, ds);
        //�d�L��Ƶ������` , rtntList = emptyLise

    }

    /**
     * Ū���j�Ӱ����ҧǸ�
     * @param reqMap    Map 
     *                  <pre>
     *                  BLD_CD  = �j�ӥN��
     *                  PRK_NO = ������
     *                  </pre>
     * @param SUB_CPY_ID  String  �����q�O
     * @param prtYear  String �C�L�~��(�褸�~)
     * @param DATA_TYPE   String  �������
     * @return  SERNO   int �j�Ӱ����ҧǸ�
     */
    public int getPrintNo(Map reqMap, String SUB_CPY_ID, String prtYear, String DATA_TYPE) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(prtYear)) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_007");//�C�L�~�����o���ŭ�!
        }
        if (StringUtils.isBlank(DATA_TYPE)) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_008");//����������o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //���o�Ǹ� 
        DataSet ds = Transaction.getDataSet();
        ds.setField("prtYear", prtYear);
        ds.setField("DATA_TYPE", DATA_TYPE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (reqMap != null && !reqMap.isEmpty()) {
            setFieldIfMapExist(reqMap, "BLD_CD", ds);
            setFieldIfMapExist(reqMap, "PRK_NO", ds);
        }
        DBUtil.searchAndRetrieve(ds, SQL_getPrintNo_001);
        ds.next();
        return ((Integer) ds.getField(0)) + 1;
    }

    /**
     * �����ҦC�L�榡�B�z
     * @param PRT_YR String  �C�L�~�� (�褸�~)
     * @param prtList List<Map>   �C�L�M��
     * @param user  UserObject  �ϥΪ̸�T
     * @param PRT_IDX String  �C�L�_�l��m
     * @return rtnMap  Map �����C�L�Ѽ�
     */
    public Map prkperPrint(String PRT_YR, List<Map> prtList, UserObject user, String PRT_IDX) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(PRT_YR)) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_007");//�C�L�~�����o���ŭ�!
        }
        if (prtList == null || prtList.isEmpty()) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_009");//�C�L�M�椣�o���ŭ�!
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_010");//�ϥΪ̸�T���o���ŭ�!
        }
        if (StringUtils.isBlank(PRT_IDX)) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_016");//�C�L�_�l��m���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);

        List<Map> detail = new ArrayList<Map>();

        //���o�C�L�Ǹ�
        int serNo = this.getPrintNo(null, SUB_CPY_ID, PRT_YR, "P");
        String EmpName = user.getEmpName();
        String DivNo = user.getDivNo();
        String EmpID = user.getEmpID();
        Timestamp currentTime = DATE.currentTime();
        StringBuffer sb = new StringBuffer();
        DataSet ds = Transaction.getDataSet();
        int int_PRT_IDX = Integer.valueOf(PRT_IDX);
        Map nowMap = null;
        if (int_PRT_IDX > 1) {
            nowMap = new HashMap();
            detail.add(nowMap);
        }
        LocaleDisplay display = new LocaleDisplay("EP", user);
        int i = int_PRT_IDX;
        for (Map map : prtList) {
            Map rtnMap = this.printLog(map, PRT_YR, serNo, SUB_CPY_ID, "P", DivNo, EmpID, EmpName, currentTime, sb, ds, display);
            if (rtnMap != null && !rtnMap.isEmpty()) {
                serNo++;
                String BLD_NAME = MapUtils.getString(rtnMap, "BLD_NAME", "");
                String USR_NAME = MapUtils.getString(rtnMap, "CUS_NAME", "");
                String PRT_NO = MapUtils.getString(rtnMap, "PRT_NO", "");
                String PRK_NO = MapUtils.getString(rtnMap, "PRK_NO", "");

                String EFF_DATE = MapUtils.getString(rtnMap, "EFF_DATE", "");
                if (i % 6 == 1) {
                    nowMap = new HashMap();
                    nowMap.put("BLD_NAME_1", BLD_NAME);
                    nowMap.put("USR_NAME_1", USR_NAME);
                    nowMap.put("PRT_NO_1", PRT_NO);
                    nowMap.put("PRK_NO_1", PRK_NO);
                    nowMap.put("EFF_DATE_1", EFF_DATE);
                    detail.add(nowMap);
                } else if (i % 6 == 2) {
                    nowMap.put("BLD_NAME_2", BLD_NAME);
                    nowMap.put("USR_NAME_2", USR_NAME);
                    nowMap.put("PRT_NO_2", PRT_NO);
                    nowMap.put("PRK_NO_2", PRK_NO);
                    nowMap.put("EFF_DATE_2", EFF_DATE);
                } else if (i % 6 == 3) {
                    nowMap.put("BLD_NAME_3", BLD_NAME);
                    nowMap.put("USR_NAME_3", USR_NAME);
                    nowMap.put("PRT_NO_3", PRT_NO);
                    nowMap.put("PRK_NO_3", PRK_NO);
                    nowMap.put("EFF_DATE_3", EFF_DATE);
                } else if (i % 6 == 4) {
                    nowMap.put("BLD_NAME_4", BLD_NAME);
                    nowMap.put("USR_NAME_4", USR_NAME);
                    nowMap.put("PRT_NO_4", PRT_NO);
                    nowMap.put("PRK_NO_4", PRK_NO);
                    nowMap.put("EFF_DATE_4", EFF_DATE);
                } else if (i % 6 == 5) {
                    nowMap.put("BLD_NAME_5", BLD_NAME);
                    nowMap.put("USR_NAME_5", USR_NAME);
                    nowMap.put("PRT_NO_5", PRT_NO);
                    nowMap.put("PRK_NO_5", PRK_NO);
                    nowMap.put("EFF_DATE_5", EFF_DATE);
                } else {
                    nowMap.put("BLD_NAME_6", BLD_NAME);
                    nowMap.put("USR_NAME_6", USR_NAME);
                    nowMap.put("PRT_NO_6", PRT_NO);
                    nowMap.put("PRK_NO_6", PRK_NO);
                    nowMap.put("EFF_DATE_6", EFF_DATE);
                }
                i++;
            }
        }

        //�]�w�^�ǭ�
        Map rtnMap = new HashMap();
        Map param = new HashMap();
        param.put("REPORT_ID", "EP_A30040");
        rtnMap.put("params", param);
        rtnMap.put("detail", detail);

        return rtnMap;

    }

    /**
     * �[�J�����ҧ妸�C�L�M��
     * @param PRT_YR  String  �C�L�~�� (�褸�~)
     * @param prtList  List<Map>   �C�L�M��
     * @param user  UserObject  �ϥ�
     */
    public void add(String PRT_YR, List<Map> prtList, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(PRT_YR)) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_007");//�C�L�~�����o���ŭ�!
        }
        if (prtList == null || prtList.isEmpty()) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_009");//�C�L�M�椣�o���ŭ�!
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_010");//�ϥΪ̸�T���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
        // ���o�C�L�Ǹ�
        int serNo = this.getPrintNo(null, SUB_CPY_ID, PRT_YR, "B");
        //�v���B�zrtnList��� 
        String EmpName = user.getEmpName();
        String DivNo = user.getDivNo();
        String EmpID = user.getEmpID();
        Timestamp currentTime = DATE.currentTime();
        StringBuffer sb = new StringBuffer();
        DataSet ds = Transaction.getDataSet();
        for (Map map : prtList) {
            Map rtnMap = this.printLog(map, PRT_YR, serNo, SUB_CPY_ID, "B", DivNo, EmpID, EmpName, currentTime, sb, ds, null);
            if (rtnMap != null && !rtnMap.isEmpty()) {
                serNo++;
            }
        }
    }

    /**
     * �簣�����ҧ妸�C�L�M��
     * @param prtList  List<Map>   �C�L�M��
     */
    public void remove(List<Map> prtList) throws ModuleException {
        if (prtList == null || prtList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30040_MSG_009"));//�C�L�M�椣�o���ŭ�!
        }
        DataSet ds = Transaction.getDataSet();
        //�v���B�zrtnList��� 
        for (Map data : prtList) {
            ds.clear();
            ds.setField("PRT_YR", MapUtils.getString(data, "PRT_YR"));
            ds.setField("BLD_CD", MapUtils.getString(data, "BLD_CD"));
            ds.setField("PRK_NO", MapUtils.getString(data, "PRK_NO"));
            ds.setField("SUB_CPY_ID", MapUtils.getString(data, "SUB_CPY_ID"));
            ds.setField("PRT_NO", MapUtils.getString(data, "PRT_NO"));
            DBUtil.executeUpdate(ds, SQL_remove_001);
        }

    }

    /**
     * �[�J�����ҧ妸�C�L�M���ˮ�
     * @param PRT_YR  String  �C�L�~��
     * @param prtList List<Map>   �C�L�M��
     */
    public void checkAdd(String PRT_YR, List<Map> prtList) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(PRT_YR)) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_007");//�C�L�~�����o���ŭ�!
        }
        if (prtList == null || prtList.isEmpty()) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_009");//�C�L�M�椣�o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�v���B�zrtnList��� 
        DataSet ds = Transaction.getDataSet();
        StringBuffer chkMessage = new StringBuffer();
        for (Map data : prtList) {
            log.debug(" �[�J�����ҧ妸�C�L�M��: " + data);
            ds.clear();
            String BLD_CD = MapUtils.getString(data, "BLD_CD");
            String PRK_NO = MapUtils.getString(data, "PRK_NO");
            String PRK_PER = MapUtils.getString(data, "PRK_PER");
            ds.setField("PRT_YR", PRT_YR);
            ds.setField("BLD_CD", MapUtils.getString(data, "BLD_CD"));
            ds.setField("PRK_NO", PRK_NO);
            ds.setField("SUB_CPY_ID", MapUtils.getString(data, "SUB_CPY_ID"));
            ds.setField("PRT_NO", MapUtils.getString(data, "PRT_NO"));
            int count = DBUtil.searchAndRetrieve(ds, SQL_checkAdd_001, false);
            if (count > 0) {
                chkMessage.append(BLD_CD).append('_').append(PRK_NO).append(MessageUtil.getMessage("EP_A30040_MSG_011"));//�w�[�J�妸�M��
            } else {
                if (!"Y".equals(PRK_PER)) {
                    chkMessage.append(BLD_CD).append('_').append(PRK_NO).append(MessageUtil.getMessage("EP_A30040_MSG_012"));//�]�w���C�L������
                }
                String USR_NAME = MapUtils.getString(data, "USR_NAME");
                String CRT_NO = MapUtils.getString(data, "CRT_NO");
                String RNT_END_DATE = MapUtils.getString(data, "RNT_END_DATE");
                String RNT_END_DATE_Y = DATE.isDate(RNT_END_DATE) ? DATE.getY2KYear(RNT_END_DATE) : "";
                if (StringUtils.isBlank(USR_NAME) && StringUtils.isBlank(CRT_NO)) {
                    chkMessage.append(BLD_CD).append('_').append(PRK_NO).append(MessageUtil.getMessage("EP_A30040_MSG_013"));//�D�X���ΦۥΨ���
                }
                if (StringUtils.isNotBlank(USR_NAME) && StringUtils.isNotBlank(RNT_END_DATE_Y) && PRT_YR.compareTo(RNT_END_DATE_Y) > 0) {
                    chkMessage.append(BLD_CD).append('_').append(PRK_NO).append(MessageUtil.getMessage("EP_A30040_MSG_014")); //�C�L�~��>�������
                }
                String USE_TYPE = MapUtils.getString(data, "USE_TYPE");
                if (StringUtils.isNotBlank(USE_TYPE) && "3".equals(USE_TYPE)) {
                    chkMessage.append(BLD_CD).append('_').append(PRK_NO).append(MessageUtil.getMessage("EPA3_0040_UI_CHECK_PRINT_EMPTY"));//�Ÿm����
                }
            }
        }
        if (chkMessage.length() > 0) {
            throw new ModuleException(chkMessage.toString());
        }

    }

    /**
     * �C�L������
     * @param reqMap
     * @param resp
     * @throws ModuleException 
     */
    public void print(Map reqMap, ResponseContext resp) throws ModuleException {
        //JasperReportUtils.addOutputRptDataToResp("EP_A30040", (Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), resp);

        String fileName = new StringBuilder().append("PARKINGPERMIT_").append(DATE.getROCDate()).append(".pdf").toString();

        String createFileFullPath = RptUtils.createTempFile(fileName).getAbsolutePath();
        try {
            new RptUtils().createPDFFile((Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), createFileFullPath);
        } catch (Exception e) {
            throw new ModuleException("���ͦ���PDF����:" + e.getMessage());
        }
        try {
            RptUtils.cryptoDownloadParameterToResp(fileName, createFileFullPath, resp);
        } catch (Exception e) {
            throw new ModuleException("�^�ǥ[�K��������|�o�Ϳ��~:" + e.getMessage());
        }

    }

    /**
     * �ӯ����p�榡�B�z
    * @param reqMap Map 
    *               <pre>
    *               SUB_CPY_ID = �����q�O
    *               BLD_CD  = �j�ӥN��
    *               BLD_NAME = �j�ӦW��
    *               PRT_TP = 1 �˭q���U ; 2:��@�j��
    *               PRINT_PAGE_BEG  �C�L���X�}�l
    *               </pre>
    * @return rtnMap   Map �����C�L�Ѽ�
     * @throws SQLException
     * @throws ModuleException
     */
    public Map formatRent(Map reqMap, UserObject user) throws SQLException, ModuleException {
        LocaleDisplay locale = new LocaleDisplay("EP", user);
        //�Y�d�L��Ƶ������`�A����ܪų���
        //���o�j�Ӱ򥻸��
        Map bldMap = this.queryMap(reqMap);
        //���o�ӯ����p����
        List<Map> rtnList = this.queryList5(reqMap, locale);

        //�C���C�L���
        String PAGE_LINE_COUNTstr = FieldOptionList.getName("EP", "BLD_BOOKS", "PAGE_LINE_COUNT");
        int PAGE_LINE_COUNTint = NumberUtils.isDigits(PAGE_LINE_COUNTstr) ? Integer.valueOf(PAGE_LINE_COUNTstr) : 0;

        int rtnListsizeint = rtnList.size();

        //�C�L�_�l���X
        BigDecimal PRINT_PAGE_BEG = STRING.objToBigDecimal(reqMap.get("PRINT_PAGE_BEG"), BigDecimal.ONE);

        //���o�`���q������T
        BigDecimal rate = this.getRentRate(bldMap, "1", 4);
        bldMap.put("RNT_RT", rate.multiply(BD_100));
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");

        //BLD�`���ݭn�Ŷ�
        String SPACE_summary;

        if ("A045".equals(BLD_CD)) {
            this.setA045Summary(bldMap, rtnList);
            //ireport  detail3 120/ detail1 23
            SPACE_summary = FieldOptionList.getName("EP", "BLD_BOOKS", "SPACE_A45");
        } else {
            //ireport  detail4 43/ detail1 23 
            SPACE_summary = FieldOptionList.getName("EP", "BLD_BOOKS", "SPACE_OTH");
        }
        //BLD�`���ݭn�Ŷ�
        int summaryEmpty = NumberUtils.isDigits(SPACE_summary) ? Integer.valueOf(SPACE_summary) : 0;

        BigDecimal PRINT_PAGE_END = PRINT_PAGE_BEG;
        String PRINT_PAGE_ENDstr = PRINT_PAGE_BEG.toString();
        for (int i = 0; i < rtnListsizeint; i++) {
            Map<String, Object> rtnMap = rtnList.get(i);
            for (String every_key : rtnMap.keySet()) {
                Object obj = MapUtils.getObject(rtnMap, every_key, "");
                if (obj instanceof BigDecimal) {
                    if (every_key.indexOf("SIZE") != -1) {
                        rtnMap.put(every_key, locale.formatNumber(obj, 3, "0"));
                    } else {
                        rtnMap.put(every_key, locale.formatNumber(obj, 0, "0"));
                    }
                } else if (obj instanceof Date) {
                    rtnMap.put(every_key, locale.formatDate((Date) obj, "/", ""));
                } else {
                    rtnMap.put(every_key, obj.toString());
                }
            }
            if (i != 0 && i % PAGE_LINE_COUNTint == 0) {
                PRINT_PAGE_END = PRINT_PAGE_END.add(BigDecimal.ONE);
            }
            rtnMap.put("MEMO_DATA", "DETAIL");
            rtnMap.put("PRINT_PAGE_BEG", PRINT_PAGE_BEG);
            PRINT_PAGE_ENDstr = PRINT_PAGE_END.toString();
            rtnMap.put("PRINT_PAGE_END", PRINT_PAGE_ENDstr);

        }
        for (Object every_key : bldMap.keySet()) {
            Object obj = MapUtils.getObject(bldMap, every_key, "");
            if (BigDecimal.class.isInstance(obj)) {
                if (every_key.toString().indexOf("RNT_RT") != -1) {
                    bldMap.put(every_key, locale.formatNumber(obj, 2, "0.00") + "%");
                } else {
                    bldMap.put(every_key, locale.formatNumber(obj, 3, "0"));
                }
            } else {
                bldMap.put(every_key, obj.toString());
            }
        }

        if (!rtnList.isEmpty()) {
            Map lastMap = new HashMap();
            lastMap.put("MEMO_DATA", "last");
            int parameter = rtnListsizeint % PAGE_LINE_COUNTint;
            //�P�_�`���O�_���~
            if (rtnListsizeint > PAGE_LINE_COUNTint - summaryEmpty && (parameter == 0 || parameter + summaryEmpty > PAGE_LINE_COUNTint)) {
                PRINT_PAGE_END = PRINT_PAGE_END.add(BigDecimal.ONE);
                PRINT_PAGE_ENDstr = PRINT_PAGE_END.toString();
            }
            lastMap.put("PRINT_PAGE_END", PRINT_PAGE_ENDstr);
            rtnList.add(lastMap);
        } else {
            Map emptyMap = new HashMap();
            emptyMap.put("PRINT_PAGE_END", PRINT_PAGE_ENDstr);
            rtnList.add(emptyMap);
        }

        Map rtnMap = new HashMap();
        bldMap.put("REPORT_ID", "EP_A30040_01");
        bldMap.put("PRINT_DATE", locale.formatDate(DATE.today(), "/", ""));
        bldMap.put("PRINT_PAGE_BEG", PRINT_PAGE_BEG);
        bldMap.put("PRINT_PAGE_END", PRINT_PAGE_ENDstr);
        bldMap.put("PAGE_LINE_COUNT", PAGE_LINE_COUNTint);//�C���C�L����

        rtnMap.put("params", bldMap);
        rtnMap.put("detail", rtnList);
        return rtnMap;

    }

    /**
     * �C�L�Ӽh�ӯ����p
     * @param reqMap  Map 
     * @param req  RequestContext  
     * @param resp  ResponseContext     
     */
    public void printRent(Map reqMap, ResponseContext resp) {
        JasperReportUtils.addOutputRptDataToResp("EP_A30040_01", (Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), resp);
    }

    /**
     * �ץXxls
    * @param reqMap
    * @param resp
    */
    public List<Map> exportXLS(Map reqMap, UserObject user, ResponseContext resp) throws Exception {

        List<Map> rtnList = this.queryList(reqMap);

        //���Y�]�w
        List<List<ColumnSetting>> titles = new ArrayList<List<ColumnSetting>>();
        List<ColumnSetting> titleMainNMRow = new ArrayList<ColumnSetting>();
        titles.add(titleMainNMRow);

        List<ColumnSetting> titleMainRow = new ArrayList<ColumnSetting>();
        titles.add(titleMainRow);

        List<ColumnSetting> titleNMRow = new ArrayList<ColumnSetting>();
        titles.add(titleNMRow);
        List<List<ColumnSetting>> records = new ArrayList<List<ColumnSetting>>();
        List<ColumnSetting> firstRow_ = new ArrayList<ColumnSetting>();
        records.add(firstRow_);
        String RNT_KD = MapUtils.getString(reqMap, "RNT_KD");
        int colLen = 0;
        if ("1".equals(RNT_KD)) {
            //�Ӽh,�ǧO,�Ȥ�W��,�ǧO���n,�X�����n,���(���|),�_�����,�쯲���
            //�ϥγ��,�C�W����,�C�W����,�ϥΪ��p,�����N��,�Ȥ�Ǹ�,�Τ@�s��,�n�O�γ~,���ϥΩʽ�,�b���n
            //�޲z�O���n
            String[] columns = { "FLD_NO", "ROOM_NO", "CUS_NAME", "ROOM_SIZE", "RNT_SIZE", "FNL_AMT", "RNT_STR_DATE", "RNT_END_DATE",
                    "USE_DIV_NAME", "AVG_AMT", "CLR_AMT", "USE_TYPE_NM", "CRT_NO", "CUS_NO", "ID", "FLD_TYPE_NM", "USE_KD_NM", "NET_SIZE",
                    "MGT_SIZE" };
            colLen = columns.length;
            xlsSettingCol(columns, titleNMRow, firstRow_);

        } else if ("2".equals(RNT_KD) || "4".equals(RNT_KD)) {
            //����N��,�Ȥ�W��,����,�ϥΪ̦W��,�믲��,�_�����,�쯲���,�O�_�C�L������
            //�C�L�Ǹ�,�ϥΪ��p,�����N��,�Τ@�s��
            String[] columns = { "PRK_NO", "CUS_NAME", "CAR_NO", "USR_NAME", "CAR_RNT_AMT", "RNT_STR_DATE", "RNT_END_DATE", "PRK_PER",
                    "PRT_NO_SHOW", "USE_TYPE_NM", "CRT_NO", "ID" };
            colLen = columns.length;
            xlsSettingCol(columns, titleNMRow, firstRow_);
        } else if ("3".equals(RNT_KD)) {
            //�Ӽh,�ǧO,����N��,�Ȥ�W��,�_�����,�쯲���,�ϥγ��,���(���|)
            //�믲��,�����N��,�Ȥ�Ǹ�,�Τ@�s��,�ϥΪ��p,���ϥΩʽ�,�ǧO���n,�޲z�O���n
            String[] columns = { "FLD_NO", "ROOM_NO", "PRK_NO", "CUS_NAME", "RNT_STR_DATE", "RNT_END_DATE", "USE_DIV_NAME", "FNL_AMT",
                    "CAR_RNT_AMT", "CRT_NO", "CUS_NO", "ID", "USE_TYPE_NM", "USE_KD_NM", "ROOM_SIZE", "MGT_SIZE" };
            colLen = columns.length;
            xlsSettingCol(columns, titleNMRow, firstRow_);
        } else if ("6".equals(RNT_KD)) {
            //�����N��,�Ȥ�Ǹ�,�Ȥ�W��,�_�����,�쯲���

            String[] columns = { "CRT_NO", "CUS_NO", "CUS_NAME", "RNT_STR_DATE", "RNT_END_DATE", "FLD_NO", "PRK_NO" };
            colLen = columns.length;
            xlsSettingCol(columns, titleNMRow, firstRow_);
        }
        //���Y�W�ٳ]�w
        //�j�ӥN��
        XlsUtils.addColumnAttrs(titleMainNMRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPA3_0040_UI_BLD_CD"), new ColumnOptions(1, 1,
                SORT_RULE.STRING));

        //�j�ӦW��
        XlsUtils.addColumnAttrs(titleMainNMRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPA3_0040_UI_BLD_NAME"), new ColumnOptions(1, 1,
                SORT_RULE.STRING));

        XlsUtils.addColumnAttrs(titleMainNMRow, XlsUtils.EMPTY, "", new ColumnOptions(1, 2, SORT_RULE.STRING));

        //�C�L���
        XlsUtils.addColumnAttrs(titleMainNMRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPA3_0040_PRINT_DATE"), new ColumnOptions(1, 1,
                SORT_RULE.STRING));
        int emptyCol = colLen - 5;
        if (emptyCol > 0) {
            XlsUtils.addColumnAttrs(titleMainNMRow, XlsUtils.EMPTY, "", new ColumnOptions(2, emptyCol, SORT_RULE.STRING));
        }
        //���Y���e�]�w

        XlsUtils.addColumnAttrs(titleMainRow, XlsUtils.EMPTY, MapUtils.getString(reqMap, "BLD_CD", ""), new ColumnOptions(1, 1,
                SORT_RULE.STRING));

        XlsUtils.addColumnAttrs(titleMainRow, XlsUtils.EMPTY, MapUtils.getString(reqMap, "BLD_NAME", ""), new ColumnOptions(1, 1,
                SORT_RULE.STRING));
        //�D�����ī�������
        XlsUtils.addColumnAttrs(titleMainRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPA3_0040_EXPORT_TITLE"), new ColumnOptions(1, 2,
                SORT_RULE.STRING));
        final LocaleDisplay display = new LocaleDisplay("EP", user);
        XlsUtils.addColumnAttrs(titleMainRow, XlsUtils.EMPTY, display.formatDate(DATE.today(), "/", ""), new ColumnOptions(1, 1,
                SORT_RULE.STRING));

        String fileName = MapUtils.getString(reqMap, "fileName", "");
        XlsUtils xlsUtils = new XlsUtils(fileName, rtnList, resp);
        xlsUtils.parseToSheetSetting(fileName.split("_")[0], titles, records);
        xlsUtils.initExportSetting();
        Options options = xlsUtils.getOptions();
        options.setNumberFormatPattern("#,##0.##");
        xlsUtils.execute(new XlsUtils.ListProcessHandler() {

            protected boolean dataOutputProcess(Map dataMap) {
                for (Object everyKey : dataMap.keySet()) {
                    String key = (String) everyKey;
                    if (key.indexOf("DATE") != -1) {
                        dataMap.put(key, display.formatDate((Date) dataMap.get(key), "/", ""));
                    }
                }
                return true;
            }
        });
        return rtnList;

    }

    /**
     * �Y�ɧQ�ή榡�B�z
     * @param reqMap
     * @param user
     * @return
     * @throws SQLException
     * @throws ModuleException
     */
    public Map formatUse(Map reqMap, UserObject user) throws SQLException, ModuleException {
        LocaleDisplay locale = new LocaleDisplay("EP", user);
        //�Y�d�L��Ƶ������`�A����ܪų���
        //�YPRINT_PAGE_BEG �L�ȡA PRINT_PAGE_BEG = 1

        //���o�j�Ӱ򥻸��
        Map bldMap;
        Map baseMap;
        try {
            bldMap = this.queryMap(reqMap);
        } catch (DataNotFoundException dnfe) {
            bldMap = new HashMap();
        }
        //���o�j�Ӱ�a���
        try {
            List<Map> bldList = new EP_Z0G103().queryList(reqMap);
            if (bldList.size() > 1) {
                //�YbldList �W�L�@���A��X���~�T���A�Ӥj�ӥN�����h����a�����
                throw new ModuleException("�Ӥj�ӥN�����h����a�����");
            }
            baseMap = bldList.get(0);
        } catch (DataNotFoundException dnfe) {
            baseMap = new HashMap();
        }

        //�]�w�C�L�Ѽ�
        Map headMap = new HashMap();
        headMap.put("BLD_CD", bldMap.get("BLD_CD"));
        headMap.put("BLD_NAME", bldMap.get("BLD_NAME"));
        headMap.put("BLD_SIZE", bldMap.get("BLD_SIZE"));
        headMap.put("RNT_SIZE", bldMap.get("RNT_SIZE"));
        BigDecimal INV_RNT_SIZE = STRING.objToBigDecimal(baseMap.get("INV_RNT_SIZE"), BigDecimal.ZERO);
        headMap.put("INV_RNT_SIZE", INV_RNT_SIZE);

        //�]�w�i�X�����n�B�ۥέ��n
        bldMap.put("BLD_SIZE", INV_RNT_SIZE);
        bldMap.put("SLF_SIZE", 0);
        BigDecimal rate = this.getRentRate(bldMap, "1", 4); //�ʤ��� 2 ��A�p��p��4��
        headMap.put("RNT_RT", rate.multiply(BD_100));

        for (Object every_key : headMap.keySet()) {
            Object obj = MapUtils.getObject(headMap, every_key, "");
            if (BigDecimal.class.isInstance(obj)) {
                if (every_key.toString().indexOf("RNT_RT") != -1) {
                    headMap.put(every_key, locale.formatNumber(obj, 2, "0.00") + "%");
                } else {
                    headMap.put(every_key, locale.formatNumber(obj, 4, "0"));
                }
            } else {
                headMap.put(every_key, obj.toString());
            }
        }

        //���o�ӯ����p���ӡA�O�d�X���ǧO����
        List<Map> rtnList = this.queryList5(reqMap, locale);
        Iterator<Map> iList = rtnList.iterator();
        while (iList.hasNext()) {
            Map data = iList.next();
            // �����D�X�����ǧO
            if (!"1".equals(MapUtils.getString(data, "USE_TYPE"))) {
                iList.remove();
            }
        }

        //�C���C�L���
        BigDecimal PRINT_PAGE_BEG = STRING.objToBigDecimal(reqMap.get("PRINT_PAGE_BEG"), BigDecimal.ONE);

        //�C���C�L���
        BigDecimal PAGE_LINE_COUNT = STRING.objToBigDecimal(FieldOptionList.getName("EP", "BLD_BOOKS", "PAGE_LINE_COUNT"), BigDecimal.ONE);
        BigDecimal PAGE_MAX_LINE = STRING.objToBigDecimal(FieldOptionList.getName("EP", "BLD_BOOKS", "PAGE_MAX_LINE"), BigDecimal.ONE);

        BigDecimal listSize = new BigDecimal(rtnList.size());
        BigDecimal PRINT_PAGE_END = PRINT_PAGE_BEG;

        //format List�榡
        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);
            for (String every_key : rtnMap.keySet()) {
                Object obj = MapUtils.getObject(rtnMap, every_key, "");
                if (obj instanceof BigDecimal) {
                    if (every_key.indexOf("SIZE") != -1) {
                        rtnMap.put(every_key, locale.formatNumber(obj, 3, "0"));
                    } else {
                        rtnMap.put(every_key, locale.formatNumber(obj, 0, "0"));
                    }
                } else if (obj instanceof Date) {
                    rtnMap.put(every_key, locale.formatDate((Date) obj, "/", ""));
                } else {
                    rtnMap.put(every_key, obj.toString());
                }
            }
            if (i != 0 && i % PAGE_LINE_COUNT.intValue() == 0) {
                PRINT_PAGE_END = PRINT_PAGE_END.add(BigDecimal.ONE);
            }
            rtnMap.put("MEMO_DATA", "DETAIL");
            rtnMap.put("PRINT_PAGE_END", PRINT_PAGE_END.toString());
        }

        //�]�w����
        if (!rtnList.isEmpty()) {
            Map lastMap = new HashMap();
            lastMap.put("MEMO_DATA", "last");
            if (listSize.remainder(PAGE_LINE_COUNT).compareTo(PAGE_MAX_LINE) > 0) {//�P�_�����O�_�ݭn����
                PRINT_PAGE_END.add(BigDecimal.ONE);
            }
            lastMap.put("PRINT_PAGE_END", PRINT_PAGE_END.toString());
            rtnList.add(lastMap);
        } else {
            Map emptyMap = new HashMap();
            emptyMap.put("PRINT_PAGE_END", PRINT_PAGE_END.toString());
            rtnList.add(emptyMap);
        }

        Map rtnMap = new HashMap();
        headMap.put("REPORT_ID", "EP_A30040_02");
        headMap.put("PRINT_DATE", locale.formatDate(DATE.today(), "/", ""));
        headMap.put("PRINT_PAGE_BEG", PRINT_PAGE_BEG);
        headMap.put("PAGE_LINE_COUNT", PAGE_LINE_COUNT);//�C���C�L����

        rtnMap.put("params", headMap);
        rtnMap.put("detail", rtnList);

        return rtnMap;

    }

    /**
     * �C�L�Ӽh�Y�ɧQ��
     * @param reqMap  Map 
     * @param req  RequestContext  
     * @param resp  ResponseContext     
     */
    public void printUse(Map reqMap, ResponseContext resp) {
        JasperReportUtils.addOutputRptDataToResp("EP_A30040_02", (Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), resp);
    }

    /**
     *  ��s�`���q�j�ӷJ���T
     * @param bldMap  Map �j�Өϥη��p
     * @param rtnList List<Map>   �ӯ����p����
     * @throws ErrorInputException
     */
    private void setA045Summary(Map bldMap, List<Map> rtnList) throws ErrorInputException {
        //��l�p�����
        //(B7) 1-13�j���`���n  
        BigDecimal BLD_SIZE_A = BigDecimal.ZERO;
        //(B8) 1-13�`�ۥέ��n
        BigDecimal SLF_SIZE_A = BigDecimal.ZERO;

        //(B10) 1-13�`�X�����n
        BigDecimal RNT_SIZE_A = BigDecimal.ZERO;
        //(B11) >15�j���`���n
        BigDecimal BLD_SIZE_B = BigDecimal.ZERO;
        //(B12) >15�`�ۥέ��n
        BigDecimal SLF_SIZE_B = BigDecimal.ZERO;

        //(B14) >15�`�X�����n
        BigDecimal RNT_SIZE_B = BigDecimal.ZERO;
        MultiKeyMap fldRoom = new MultiKeyMap();
        BigDecimal ROOM_SIZE_my = BigDecimal.ZERO;
        BigDecimal RNT_SIZE_my = BigDecimal.ZERO;
        //�v���B�z�ӯ����p���ӡA�p��J���T
        for (Map map : rtnList) {
            String FLD_NO = MapUtils.getString(map, "FLD_NO");
            String ROOM_NO = MapUtils.getString(map, "ROOM_NO");
            if (fldRoom.containsKey(FLD_NO, ROOM_NO)) {
                continue;
            }
            BigDecimal ROOM_SIZE = obj2Big(map, "ROOM_SIZE", BigDecimal.ZERO);
            BigDecimal RNT_SIZE = obj2Big(map, "RNT_SIZE", BigDecimal.ZERO);
            String USE_TYPE = MapUtils.getString(map, "USE_TYPE");
            ROOM_SIZE_my = ROOM_SIZE_my.add(ROOM_SIZE);
            RNT_SIZE_my = RNT_SIZE_my.add(RNT_SIZE);
            /*    if (FLD_NO.indexOf("B") != -1) {
                    BLD_SIZE_B = BLD_SIZE_B.add(ROOM_SIZE);
                    RNT_SIZE_B = RNT_SIZE_B.add(RNT_SIZE);
                    if ("2".equals(USE_TYPE) || "9".equals(USE_TYPE)) {
                        SLF_SIZE_B = SLF_SIZE_B.add(ROOM_SIZE);
                    }
                } else if (NumberUtils.isDigits(FLD_NO)) {
                    Integer FLD_NOint = Integer.valueOf(FLD_NO);

                    if (FLD_NOint >= 1 && FLD_NOint <= 13) {
                        BLD_SIZE_A = BLD_SIZE_A.add(ROOM_SIZE);
                        RNT_SIZE_A = RNT_SIZE_A.add(RNT_SIZE);

                        if ("2".equals(USE_TYPE) || "9".equals(USE_TYPE)) {
                            SLF_SIZE_A = SLF_SIZE_A.add(ROOM_SIZE);
                        }
                    } else if (FLD_NOint >= 15) {
                        BLD_SIZE_B = BLD_SIZE_B.add(ROOM_SIZE);
                        RNT_SIZE_B = RNT_SIZE_B.add(RNT_SIZE);
                        if ("2".equals(USE_TYPE) || "9".equals(USE_TYPE)) {
                            SLF_SIZE_B = SLF_SIZE_B.add(ROOM_SIZE);
                        }

                    }
                }*/
            if (FLD_NO.compareTo("001") >= 0 && FLD_NO.compareTo("013") <= 0) {
                BLD_SIZE_A = BLD_SIZE_A.add(ROOM_SIZE);
                RNT_SIZE_A = RNT_SIZE_A.add(RNT_SIZE);
                if ("2".equals(USE_TYPE) || "9".equals(USE_TYPE)) {
                    SLF_SIZE_A = SLF_SIZE_A.add(ROOM_SIZE);
                }
            } else if (FLD_NO.compareTo("015") >= 0) {
                BLD_SIZE_B = BLD_SIZE_B.add(ROOM_SIZE);
                RNT_SIZE_B = RNT_SIZE_B.add(RNT_SIZE);
                if ("2".equals(USE_TYPE) || "9".equals(USE_TYPE)) {
                    SLF_SIZE_B = SLF_SIZE_B.add(ROOM_SIZE);
                }
            }
            fldRoom.put(FLD_NO, ROOM_NO, map.get("BLD_CD"));

        }
        //�p��X���v
        Map tempMap = new HashMap();
        tempMap.put("BLD_SIZE", BLD_SIZE_A);
        tempMap.put("SLF_SIZE", SLF_SIZE_A);
        tempMap.put("RNT_SIZE", RNT_SIZE_A);
        //(B9) 1-13�X���v
        BigDecimal RNT_RT_A = this.getRentRate(tempMap, "2", 4).multiply(BD_100);//�p�ƨ��
        tempMap.put("BLD_SIZE", BLD_SIZE_B);
        tempMap.put("SLF_SIZE", SLF_SIZE_B);
        tempMap.put("RNT_SIZE", RNT_SIZE_B);
        //(B13) >15�X���v
        BigDecimal RNT_RT_B = this.getRentRate(tempMap, "2", 4).multiply(BD_100); //�p�ƨ��
        //�]�w1~13�� �X���J���T
        bldMap.put("BLD_SIZE_A", BLD_SIZE_A);
        bldMap.put("SLF_SIZE_A", SLF_SIZE_A);

        bldMap.put("RNT_RT_A", RNT_RT_A);
        bldMap.put("RNT_SIZE_A", RNT_SIZE_A);
        //�]�w15~28��(�t�a�U) �X���J���T
        bldMap.put("BLD_SIZE_B", BLD_SIZE_B);
        bldMap.put("SLF_SIZE_B", SLF_SIZE_B);

        bldMap.put("RNT_RT_B", RNT_RT_B);
        bldMap.put("RNT_SIZE_B", RNT_SIZE_B);

    }

    /**
     * Ū���j�ӼӼh�Ȥ�M��
     * @param reqMap Map 
     *                  <pre>
     *                  SUB_CPY_ID = �����q�O
     *                  BLD_CD  = �j�ӥN��
     *                  BLD_NAME = �j�ӦW��
     *                  CRT_NO = �����N��
     *                  RNT_KD = �ӯ�����
     *                  PRT_YR = �C�L�~��
     *                   </pre>
     * @param ds DataSet
     * @return rtnList List<Map>   �j�ӲM��
     * @throws DBException 
     */
    private List<Map> queryList1(Map reqMap, DataSet ds) throws ModuleException {
        ErrorInputException eie = null;
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A30040_MSG_005"));//�j�ӥN�����o���ŭ�!
        }
        ds.clear();

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        ds.clear();

        BatchQueryDataSet bqds = null;
        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            bqds.setField("BLD_CD", BLD_CD);
            setFieldIfMapExist(reqMap, "CRT_NO", bqds);
            setFieldIfMapExist(reqMap, "CUS_NO", bqds);

            bqds.searchAndRetrieve(SQL_queryList1_001);//DBUtil.searchAndRetrieve(ds, SQL_queryList1_001, false);

            int groupCount = 2000;//�C�妸�d��2000�����
            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            if (totalcount == 0) {
                return new ArrayList<Map>();
            }
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��

            List<Map> rtnList = new ArrayList<Map>();
            MultiKeyMap regMap = new MultiKeyMap();
            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map rtnMap = VOTool.dataSetToMap(bqds);

                    //�n�O�γ~
                    rtnMap.put("FLD_TYPE_NM", getNM("FLD_TYPE", rtnMap, "FLD_TYPE"));
                    //�ϥΪ��p
                    rtnMap.put("USE_TYPE_NM", getNM("USE_TYPE", rtnMap, "USE_TYPE"));
                    //���ϥΩʽ�
                    rtnMap.put("USE_KD_NM", getNM("USE_KD", rtnMap, "USE_KD"));

                    String reg = MapUtils.getString(rtnMap, "REG");
                    String rntStrDate = MapUtils.getString(rtnMap, "RNT_STR_DATE", "");
                    if ("Y".equals(reg) && StringUtils.isNotEmpty(rntStrDate)) {

                        regMap.put(MapUtils.getString(rtnMap, "BLD_CD"), MapUtils.getString(rtnMap, "FLD_NO"), MapUtils.getString(rtnMap,
                            "ROOM_NO"), MapUtils.getString(rtnMap, "REG"));
                    }
                    rtnList.add(rtnMap);
                }

                Iterator<Map> iList = rtnList.iterator();
                while (iList.hasNext()) {
                    Map data = iList.next();
                    String reg = MapUtils.getString(data, "REG");
                    String USE_TYPE = MapUtils.getString(data, "USE_TYPE");
                    // ��ǧO�Ÿm�ǧO�A�p�G���w����A�j�ӫȤᤣ��� �Ÿm�ǧO
                    if ("N".equals(reg) && "3".equals(USE_TYPE)) {
                        String regRoom = (String) regMap.get(MapUtils.getString(data, "BLD_CD"), MapUtils.getString(data, "FLD_NO"),
                            MapUtils.getString(data, "ROOM_NO"));
                        if (regRoom != null) {
                            iList.remove();
                        }
                    }
                }
            }
            return rtnList;
        } catch (DBException dbe) {
            log.error("�d�ߥ���", dbe);
            throw new ModuleException(dbe);
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            throw new ModuleException(e);
        } finally {
            try {
                if (bqds != null) {
                    bqds.close();//�����妸�d�߳s�u
                }
            } catch (DBException e) {
            }

        }
    }

    /**
     * Ū���j�Ө���Ȥ�M��
     * @param reqMap  Map 
     *                  <pre>
     *                  SUB_CPY_ID = �����q�O
     *                  BLD_CD  = �j�ӥN��
     *                  BLD_NAME = �j�ӦW��
     *                  CRT_NO = �����N��
     *                  RNT_KD = �ӯ�����
     *                  PRT_YR = �C�L�~��
     *                  </pre>
     * @param ds DataSet
     * @return rtnList List<Map>   �j�Ө���M��
     */
    private List<Map> queryList2(Map reqMap, DataSet ds) throws ModuleException {
        ErrorInputException eie = null;
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_005");//�j�ӥN�����o���ŭ�!
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }


        if (eie != null) {
            throw eie;
        }
        ds.clear();
        
        BatchQueryDataSet bqds = null;
        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            bqds.setField("BLD_CD", BLD_CD);
            
            String PRT_YR = MapUtils.getString(reqMap, "PRT_YR");
            if (StringUtils.isBlank(PRT_YR)) {
                PRT_YR = DATE.getDBDate().substring(0, 4);
            }
            bqds.setField("PRT_YR", PRT_YR);
            setFieldIfMapExist(reqMap, "CRT_NO", bqds);
            setFieldIfMapExist(reqMap, "CUS_NO", bqds);

            bqds.searchAndRetrieve(SQL_queryList2_001);

            int groupCount = 2000;//�C�妸�d��2000�����
            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            //if (totalcount == 0) {
            //    throw new DataNotFoundException("�d�L���");
            //}
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��

            List<Map> rtnList = new ArrayList<Map>();
            MultiKeyMap regMap = new MultiKeyMap();
            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map rtnMap = VOTool.dataSetToMap(bqds);

                    //�ϥΪ��p
                    rtnMap.put("USE_TYPE_NM", getNM("USE_TYPE", rtnMap, "USE_TYPE"));

                    String reg = MapUtils.getString(rtnMap, "REG");
                    String rntStrDate = MapUtils.getString(rtnMap, "RNT_STR_DATE", "");
                    if ("Y".equals(reg) && StringUtils.isNotEmpty(rntStrDate)) {
                        regMap.put(MapUtils.getString(rtnMap, "BLD_CD"), MapUtils.getString(rtnMap, "PRK_NO"), MapUtils.getString(rtnMap,
                            "REG"));
                    }

                    rtnList.add(rtnMap);
                }

                Iterator<Map> iList = rtnList.iterator();
                while (iList.hasNext()) {
                    Map data = iList.next();
                    String reg = MapUtils.getString(data, "REG");
                    String USE_TYPE = MapUtils.getString(data, "USE_TYPE");
                    // ��ǧO�Ÿm�ǧO�A�p�G���w����A�j�ӫȤᤣ��� �Ÿm�ǧO
                    if ("N".equals(reg) && "3".equals(USE_TYPE)) {
                        String regPark = (String) regMap.get(MapUtils.getString(data, "BLD_CD"), MapUtils.getString(data, "PRK_NO"));
                        if (regPark != null) {
                            iList.remove();
                        }
                    }
                }
            }
            return rtnList;
        } catch (DBException dbe) {
            log.error("�d�ߥ���", dbe);
            throw new ModuleException(dbe);
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            throw new ModuleException(e);
        } finally {
            try {
                if (bqds != null) {
                    bqds.close();//�����妸�d�߳s�u
                }
            } catch (DBException e) {
            }

        }

    }

    /**
     *  Ū���j�Ө���Ȥ�妸�C�L�M��
     * @param reqMap  Map 
     *                  <pre>
     *                  SUB_CPY_ID = �����q�O
     *                  BLD_CD  = �j�ӥN��(�i����J)
     *                  BLD_NAME = �j�ӦW��
     *                  CRT_NO = �����N��
     *                  RNT_KD = �ӯ�����
     *                  PRT_YR = �C�L�~��
     *                   </pre>
     * @param ds DataSet
     * @return  rtnList List<Map>   �j�Ө���M��
     */
    private List<Map> queryList3(Map reqMap, DataSet ds) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        String PRT_YR = MapUtils.getString(reqMap, "PRT_YR");
        if (StringUtils.isBlank(PRT_YR)) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_007");//�C�L�~�����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        ds.clear();
        
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("PRT_YR", PRT_YR);
        setFieldIfMapExist(reqMap, "BLD_CD", ds);
        DBUtil.searchAndRetrieve(ds, SQL_queryList3_001, false);
        List<Map> rtnList = new ArrayList<Map>();
        MultiKeyMap regMap = new MultiKeyMap();
        while (ds.next()) {
            //�v���B�z�d�ߵ��G
            Map data = VOTool.dataSetToMap(ds);
            //�ϥΪ��p
            data.put("USE_TYPE_NM", getNM("USE_TYPE", data, "USE_TYPE"));
            String reg = MapUtils.getString(data, "REG");
            String rntStrDate = MapUtils.getString(data, "RNT_STR_DATE", "");
            if ("Y".equals(reg) && StringUtils.isNotEmpty(rntStrDate)) {
                regMap.put(MapUtils.getString(data, "BLD_CD"), MapUtils.getString(data, "PRK_NO"), MapUtils.getString(data, "REG"));
            }

            rtnList.add(data);
        }
        Iterator<Map> iList = rtnList.iterator();
        while (iList.hasNext()) {
            Map data = iList.next();
            String reg = MapUtils.getString(data, "REG");
            String USE_TYPE = MapUtils.getString(data, "USE_TYPE");
            // ��ǧO�Ÿm�ǧO�A�p�G���w����A�j�ӫȤᤣ��� �Ÿm�ǧO
            if ("N".equals(reg) && "3".equals(USE_TYPE)) {
                String regPark = (String) regMap.get(MapUtils.getString(data, "BLD_CD"), MapUtils.getString(data, "PRK_NO"));
                if (regPark != null) {
                    iList.remove();
                }
            }
        }
        return rtnList;
    }

    /**
     * Ū���Ӽh�ӯ����p����
     * @param reqMap  Map 
     *              <pre>
     *              SUB_CPY_ID = �����q�O
     *              BLD_CD  = �j�ӥN��
     *              BLD_NAME = �j�ӦW��
     *              CRT_NO = �����N��
     *              RNT_KD = �ӯ�����
     *              </pre>
     * @param locale
     * @return   rtnList List<Map>   �j�өӯ����p
     * @throws ModuleException
     */
    private List<Map> queryList5(Map reqMap, LocaleDisplay locale) throws ModuleException {
        //�d�ߤj�өӯ����p�M��
        DataSet ds = Transaction.getDataSet();
        List<Map> rtnList = this.queryList1(reqMap, ds);
        StringBuffer sb = new StringBuffer();
        for (Map data : rtnList) {
            data.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(data, "TAX_TYPE")));
            String ADJ_TYPE = MapUtils.getString(data, "ADJ_TYPE");

            String ADJ_MEMO;
            if (StringUtils.isNotBlank(ADJ_TYPE)) {
                sb.append(ADJ_TYPE).append(FieldOptionList.getName("EP", "ADJ_TYPE", ADJ_TYPE));
                if ("1".equals(ADJ_TYPE)) {
                    String ADJ_UNIT = MapUtils.getString(data, "ADJ_UNIT");
                    String ADJ_UNIT_NUM = MapUtils.getString(data, "ADJ_UNIT_NUM", "");
                    if ("1".equals(ADJ_UNIT)) {
                        //1: ��
                        sb.append(locale.formatNumber(ADJ_UNIT_NUM, 0, "0"));
                    } else if ("2".equals(ADJ_UNIT)) {
                        //2: %
                        sb.append(locale.formatNumber(ADJ_UNIT_NUM, 1, "0.0")).append('%');
                    }
                }
                ADJ_MEMO = sb.toString();

                sb.setLength(0);
            } else {
                ADJ_MEMO = "";
            }
            data.put("ADJ_MEMO", ADJ_MEMO);//�L�ȵ��ť�
        }
        return rtnList;

    }

    /**
     * Ū���Ӽh��������
     * @param reqMap Map 
     *              <pre>
     *              SUB_CPY_ID = �����q�O
     *              BLD_CD  = �j�ӥN��
     *              BLD_NAME = �j�ӦW��
     *              CRT_NO = �����N��
     *              RNT_KD = �ӯ�����
     *              </pre>
     * @return  rtnList List<Map>   �j�ӲM��
     * @throws ModuleException
     */
    private List<Map> queryList6(Map reqMap, DataSet ds) throws ModuleException {
        ErrorInputException eie = null;
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A30040_MSG_005");//�j�ӥN�����o���ŭ�!
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }

        if (eie != null) {
            throw eie;
        }
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", BLD_CD);

        setFieldIfMapExist(reqMap, "CRT_NO", ds);
        setFieldIfMapExist(reqMap, "CUS_NO", ds);
        //�d�ߤj�ӫȤ�M��
        return VOTool.findToMaps(ds, SQL_queryList6_001, false);

    }

    /**
     * ���ͤj�Ӱ����ҦC�L����
     * @param data   Map �j�Ӱ�����
     * @param prtYear  String �C�L�~��
     * @param serNo  int �C�L����
     * @param SUB_CPY_ID   String  �����q
     * @param DATA_TYPE   String  �������
     * @param DivNo
     * @param EmpID
     * @param EmpName
     * @param currentTime
     * @param sb
     * @param ds
     * @param display
     * @return  EPA105vo  DTEPA105    �C�L���
     * @throws ModuleException
     */
    private Map printLog(Map data, String prtYear, int serNo, String SUB_CPY_ID, String DATA_TYPE, String DivNo, String EmpID,
            String EmpName, Timestamp currentTime, StringBuffer sb, DataSet ds, LocaleDisplay display) throws ModuleException {
        //���򤣶��B�z
        String PRK_PER = MapUtils.getString(data, "PRK_PER");
        if (!"Y".equals(PRK_PER)) {
            log.error(data);
            log.error("�A���i�C�L������!");
            return null;
        }

        String STR_DT = sb.append(prtYear).append("-01-01").toString();
        sb.setLength(0);
        //�D���u�P���İ�����A���C�L������
        String USR_NAME = MapUtils.getString(data, "USR_NAME");
        String CRT_NO = MapUtils.getString(data, "CRT_NO");
        String RNT_END_DATE = MapUtils.getString(data, "RNT_END_DATE");
        if (StringUtils.isBlank(USR_NAME)
                && (StringUtils.isBlank(CRT_NO) || (StringUtils.isNotBlank(RNT_END_DATE) && RNT_END_DATE.compareTo(STR_DT) < 0))) {
            log.error(data);
            log.error(sb.append("�A�D���u�P���İ�����A���C�L������!").append(RNT_END_DATE).append('<').append(STR_DT).toString());
            sb.setLength(0);
            return null;
        }
        //�`���q�u�C�L���ťD�ި���
        String BLD_CD = MapUtils.getString(data, "BLD_CD");
        String PRK_NO = MapUtils.getString(data, "PRK_NO", "");
        if ("A045".equals(BLD_CD) && PRK_NO.startsWith("P0")) {
            log.error(data);
            log.error("�A�D�`���q���ťD�ި���A���C�L������!");
            return null;
        }
        //���o�C�L�Ǹ�
        //String PRT_NO = STRING.fillZero(String.valueOf(serNo), 3);
        String PRT_NO = STRING.fillZero(String.valueOf(serNo), 3, null);
        if ("B".equals(DATA_TYPE)) {
            PRT_NO = sb.append("B-").append(PRT_NO).toString();
        } else {
            int prtCount = this.getPrintNo(data, SUB_CPY_ID, prtYear, "P");
            PRT_NO = sb.append(prtCount).append("-").append(PRT_NO).toString();
        }
        sb.setLength(0);
        // �]�w���Ĵ���
        String EFF_DATE = RNT_END_DATE;
        if (StringUtils.isNotBlank(RNT_END_DATE)) {
            String rntYear = DATE.getY2KYear(RNT_END_DATE);
            if (rntYear.compareTo(prtYear) > 0) {
                EFF_DATE = sb.append(prtYear).append("-12-31").toString();
                sb.setLength(0);
            }
        }

        //�s�W�����ҦC�L����
        ds.clear();
        ds.setField("PRT_YR", prtYear);
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("PRK_NO", PRK_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("PRT_NO", PRT_NO);
        ds.setField("DATA_TYPE", DATA_TYPE);
        ds.setField("USR_NAME", USR_NAME);
        ds.setField("EFF_DATE", EFF_DATE);
        ds.setField("CRT_NO", CRT_NO);
        String CUS_NO = MapUtils.getString(data, "CUS_NO");
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("PRK_STS", "1");
        ds.setField("CHG_DATE", currentTime);
        ds.setField("CHG_DIV_NO", DivNo);
        ds.setField("CHG_ID", EmpID);
        ds.setField("CHG_NAME", EmpName);

        DBUtil.executeUpdate(ds, SQL_printLog_001);
        Map rtnMap = new HashMap();
        String BLD_NAME = "A045".equals(MapUtils.getString(data, "BLD_CD")) ? MessageUtil.getMessage("EP_A30040_MSG_017") : MapUtils
                .getString(data, "BLD_NAME", "");
        rtnMap.put("BLD_NAME", BLD_NAME);//����H�ثO�I�ѥ��������q
        String CUS_NAME = MapUtils.getString(data, "CUS_NAME", "");
        String SET_CUS_NAME = FieldOptionList.getName("EP", "A30400_CUS_NAME", CUS_NAME);
        if (StringUtils.isNotEmpty(SET_CUS_NAME)) {
            CUS_NAME = SET_CUS_NAME;
        }

        //rtnMap.put("CUS_NAME", CUS_NAME);
        rtnMap.put("CUS_NAME", StringUtils.isBlank(CUS_NAME) ? USR_NAME : CUS_NAME); //�Y�Ȥ�m�W����  �H�ϥΪ̩m�W�C�L
        rtnMap.put("PRT_NO", PRT_NO);
        rtnMap.put("PRK_NO", PRK_NO);
        Date Date_EFF_DATE = DATE.isDate(EFF_DATE) ? (Date) Date.valueOf(EFF_DATE) : null;
        rtnMap.put("EFF_DATE", display != null ? display.formatDate(Date_EFF_DATE, "/", "") : Date_EFF_DATE);

        return rtnMap;

    }

    /**
     * Map ���Ȥ~�]
     * @param reqMap
     * @param key
     * @param ds
     */
    private void setFieldIfMapExist(Map reqMap, String key, DataSet ds) {
        String value = MapUtils.getString(reqMap, key);
        this.setFieldIfExist(key, value, ds);
    }

    /**
     * ���Ȥ~�]
     * @param reqMap
     * @param key
     * @param ds
     */
    private void setFieldIfExist(String key, String value, DataSet ds) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * �ھ�MAP key �å[�P�_�O�_�[�N�X�A�^�Ǩ��o����
     * @param Field_key
     * @param rtnMap
     * @param key
     * @return
     */
    private String getNM(String Field_key, Map rtnMap, String key) {
        return FieldOptionList.getName("EP", Field_key, MapUtils.getString(rtnMap, key, ""));
    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            } else {
                String str = o.toString();
                if (StringUtils.isNotBlank(str)) {
                    return new BigDecimal(str);
                } else {
                    return defaultValue;
                }
            }
        }
        return defaultValue;
    }

    /**
     * �ץX��Ƴ]�w
     * @param columns  ���key
     * @param firstRow   ���Y
     * @param firstRow_  ����
     */
    private void xlsSettingCol(String[] columns, List<ColumnSetting> firstRow, List<ColumnSetting> firstRow_) {
        for (String key : columns) {
            String columnNM = MessageUtil.getMessage("EPA3_0040_UI_" + key);
            XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, columnNM);
            if (key.indexOf("AMT") != -1 || key.indexOf("SIZE") != -1) {
                XlsUtils.addColumnAttrs(firstRow_, key, columnNM, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
            } else {
                XlsUtils.addColumnAttrs(firstRow_, key, columnNM, new ColumnOptions(1, 1, SORT_RULE.STRING));
            }
        }
    }
}
