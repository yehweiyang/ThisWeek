package com.cathay.ep.a3.module;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.z0.module.EP_Z0B301;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.rpt.RptUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 * DATE   Description Author
 * 2013/10/14  Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �j�Өϥη��p�Ҳ�
 * �Ҳ�ID    EP_A30050 
 * ���n����    �j�Ӧۥη��p�Ҳ�
 * 
 * </pre>
 * @author �¶��� 
 * @since 2014/1/10  
 */

@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_A30050 {

    private static final String EPA007 = "EPA007";

    private static final String SQL_queryList_001 = "com.cathay.ep.a3.module.EP_A30050.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.a3.module.EP_A30050.SQL_queryList_002";

    private static final String SQL_queryList_003 = "com.cathay.ep.a3.module.EP_A30050.SQL_queryList_003";

    /**
     * Ū���j�Өϥη��p�M��
     * @param SUB_CPY_ID
     * @param SORT_TYPE
     * @param QRY_TYPE
     * @return
     * @throws ModuleException 
     * @throws SQLException 
     */
    public List<Map> queryList(String SUB_CPY_ID, String SORT_TYPE, String QRY_TYPE) throws ModuleException, SQLException {
        return queryList(SUB_CPY_ID, SORT_TYPE, QRY_TYPE, null);
    }

    /**
     * [20190801][�X�R] Ū���j�Өϥη��p�M��
     * @param SUB_CPY_ID
     * @param SORT_TYPE
     * @param QRY_TYPE
     * @param bldList
     * @return
     * @throws ModuleException
     * @throws SQLException
     */
    public List<Map> queryList(String SUB_CPY_ID, String SORT_TYPE, String QRY_TYPE, List<String> bldList) throws ModuleException,
            SQLException {

        //�ˮֶǤJ�Ѽ�:
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30050_MSG_001"));//�����q�O���o���ŭ�
        }

        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if ("1".equals(QRY_TYPE) || "X".equals(QRY_TYPE)) {
            ds.setField("QRY_TYPE_1", "1");
        } else {
            ds.setField("QRY_TYPE_2", "1");
        }

        if (bldList != null && !bldList.isEmpty()) {
            ds.setFieldValues("bldList", bldList);
        }

        String SQL_KEY;

        if ("1".equals(SORT_TYPE)) {
            SQL_KEY = SQL_queryList_001;
        } else if ("2".equals(SORT_TYPE)) {
            SQL_KEY = SQL_queryList_002;
        } else {
            SQL_KEY = SQL_queryList_003;
        }

        DBUtil.searchAndRetrieve(ds, SQL_KEY);
        List<Map> rtnList;

        if (!"X".equals(QRY_TYPE)) {
            rtnList = new ArrayList();
            EP_A30040 theEP_A30040 = new EP_A30040();
            EP_A10010 theEP_A10010 = new EP_A10010();
            while (ds.next()) {
                Map data = VOTool.dataSetToMap(ds);
                //�]�w�j�Ӹ�T
                this.setInfo(data, theEP_A30040, theEP_A10010);
                rtnList.add(data);
            }
        } else {
            rtnList = VOTool.dataSetToMaps(ds);
        }

        return rtnList;

    }

    /**
     * ��s�j�Өϥη��p�M��
     * @param SUB_CPY_ID �����q�O
     * @param user �ϥΪ̸�T
    * @throws SQLException 
    * @throws ModuleException 
     */
    public void update(String SUB_CPY_ID, UserObject user) throws ModuleException, SQLException, DBException {
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�:
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            getErrorInputException(eie, MessageUtil.getMessage("EP_A30050_MSG_001"));//�����q�O���o���ŭ�
        }
        if (user == null) {
            getErrorInputException(eie, MessageUtil.getMessage("EP_A30050_MSG_003"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        Timestamp UPD_TIME = DATE.currentTime();// �@�~����ɶ�

        //���o�j�ӲM��
        List<Map> rtnList = this.queryList(SUB_CPY_ID, "1", "X");

        //���ͤj�Өϥη��p
        Map<String, Map> mapSum = new HashMap<String, Map>();
        Map<String, Map> mapA010 = new HashMap<String, Map>();
        for (Map data : rtnList) {
            String BLD_CD = MapUtils.getString(data, "BLD_CD");
            if (StringUtils.isBlank(BLD_CD)) {
                continue;
            }
            mapA010.put(BLD_CD, data);
            Map newA101 = new HashMap();
            newA101.putAll(data);

            newA101.put("RNT_AMT", BigDecimal.ZERO);
            newA101.put("SLF_SIZE", BigDecimal.ZERO);
            newA101.put("RNT_SIZE", BigDecimal.ZERO);
            newA101.put("ACT_SIZE", BigDecimal.ZERO);
            newA101.put("PART_CNT", BigDecimal.ZERO);
            newA101.put("BLD_PRK", BigDecimal.ZERO);
            newA101.put("SLF_PRK", BigDecimal.ZERO);
            newA101.put("RNT_PRK", BigDecimal.ZERO);
            newA101.put("CUS_CNT", BigDecimal.ZERO);
            newA101.put("DIV_CNT", BigDecimal.ZERO);
            newA101.put("RNT_AMT", BigDecimal.ZERO);
            mapSum.put(BLD_CD, newA101);
        }

        EP_A10010 theEP_A10010 = new EP_A10010();
        theEP_A10010.setSumInfo(null, SUB_CPY_ID, mapSum);

        List<Map> listA101 = new ArrayList<Map>();
        List<Map> listB308 = new ArrayList<Map>();
        List<Map> listB301 = new ArrayList<Map>();

        String divNo = user.getDivNo();
        String id = user.getEmpID();
        String name = user.getEmpName();
        String currentDate = DATE.toDate_yyyyMMdd(DATE.getDBDate());
        int[] aplySerNo = new EP_Z0Z001().createNextNumberforBatch("00", "006", currentDate, "APLY_NO", mapSum.size());

        //�v���B�z�j�ӲM��
        int idx = 0;
        for (String key : mapSum.keySet()) {
            String APLY_NO = new StringBuffer().append(currentDate).append(STRING.fillZero(String.valueOf(aplySerNo[idx]), 6)).toString();
            idx++;
            Map data = (Map) mapSum.get(key);
            String TRN_KIND = EPA007;
            Map caseMap = new HashMap();
            caseMap.put("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            caseMap.put("BLD_CD", data.get("BLD_CD"));//�j�ӥN��
            caseMap.put("UPD_TRN_KIND", EPA007);//�������
            caseMap.put("TRN_KIND", TRN_KIND);//�������
            caseMap.put("UPD_DATE", UPD_TIME);//�J�ɤ��
            caseMap.put("CHG_ID", id);//����ID
            caseMap.put("CHG_DIV_NO", divNo);//���ʳ��
            caseMap.put("CHG_NAME", name);//���ʩm�W
            caseMap.put("IS_PLENTY", "Y"); //�f����������� ID �m�W
            caseMap.put("APLY_NO", APLY_NO);//�ץ�s��
            listB301.add(caseMap);

            //��s�j�ӨϥΪ��p
            data.put("APLY_NO", APLY_NO);
            data.put("TRN_KIND", TRN_KIND);
            data.put("CHG_DATE", UPD_TIME);
            data.put("CHG_DIV_NO", divNo);
            data.put("CHG_ID", id);
            data.put("CHG_NAME", name);
            data.put("UPD_APLY_NO", APLY_NO);
            data.put("UPD_TRN_KIND", TRN_KIND);

            //��X�j�Ӳ��ʬ���
            listB308.add(data);

            //��s�j�ӥD�ɸ��

            listA101.add(data);

        }
        // ����X�߮׸��
        new EP_Z0B301().insertBatch(listB301);
        // ����X�j�Ӳ��ʬ���
        theEP_A10010.updateBatch(listB308, mapA010);
        //����s�j�Ӱ򥻸��
        theEP_A10010.updateDTEPA101Batch(listA101, UPD_TIME.toString(), mapA010);

    }

    /**
     * �ץXXLS�M��
     * @param locale
     * @param SORT_TYPE
     * @param EXP_ALL
     * @param rtnList
     * @param resp
     * @throws Exception
     */
    public void exportXLS(LocaleDisplay locale, String SORT_TYPE, String EXP_ALL, List<Map> rtnList, ResponseContext resp) throws Exception {
        FileOutputStream fileOutputString = null;
        try {
            //�ɦW: �ϥη��p_�ƧǤ覡_YYYMMDD.xls
            StringBuilder sb = new StringBuilder();
            sb.append(MessageUtil.getMessage("EP_A30050_MSG_004")).append("_");//�ϥη��p
            sb.append(MessageUtil.getMessage("EP_A30050_MSG_005")).append("_");//�ƧǤ覡
            sb.append(DATE.toDate_yyyyMMdd(DATE.getDBDate()));
            sb.append(".xls");
            String fileName = sb.toString();
            sb.setLength(0);

            HSSFWorkbook workbook = new HSSFWorkbook();// �u�@��
            HSSFSheet sheet = workbook.createSheet(fileName);
            sheet.setMargin(HSSFSheet.LeftMargin, 0);
            sheet.setMargin(HSSFSheet.RightMargin, 0);
            sheet.setMargin(HSSFSheet.TopMargin, 0);
            sheet.setMargin(HSSFSheet.BottomMargin, 0);
            boolean isNeedSub = "2".equals(SORT_TYPE);//���ƧǤ覡���ϥΩʽ�ݤp�p

            //�]�w���j�p
            getSheetColumnWidth(sheet, EXP_ALL, isNeedSub);

            //�]�w�C�L���Y
            workbook.setRepeatingRowsAndColumns(0, 0, 0, 0, 2);
            sheet.setHorizontallyCenter(true);//�C�L����m��

            //�g�J���Ӹ��
            createworkbook(locale, workbook, sheet, isNeedSub, rtnList, EXP_ALL);

            // ���ͼȦs��
            File downloadFile = RptUtils.createTempFile(fileName);

            // ��X excel �ɪ����|
            String path = downloadFile.getPath();
            fileOutputString = new FileOutputStream(path);
            workbook.write(fileOutputString);
            RptUtils.cryptoDownloadParameterToResp(fileName, downloadFile, resp);
        } finally {
            if (fileOutputString != null) {
                fileOutputString.close();
            }
        }

    }

    /**
     * [20190801] �t�X�q�l�a��  �L�o queryList
     * @param qryMap
     * @param bldList
     * @return
     * @throws ModuleException
     * @throws SQLException
     */
    public List<Map> qryBuildList(Map qryMap, List<String> BLD_LIST) throws ModuleException, SQLException {
        if (qryMap == null || qryMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30050_MSG_007"));//��J�d�߱���(qryMap)���i����
        }
        if (BLD_LIST == null || BLD_LIST.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30050_MSG_008"));//��J�j�ӲM��(bldList)���i����
        }
        String SUB_CPY_ID = MapUtils.getString(qryMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30050_MSG_001"));//�����q�O���o���ŭ�
        }

        List<Map> rtnList = this.queryList(SUB_CPY_ID, "1", "1", BLD_LIST);

        BigDecimal RNT_RT_LOW = STRING.objToBigDecimal(qryMap.get("RNT_RT_LOW"), null);
        boolean isRNT_RT_LOW = RNT_RT_LOW != null;
        BigDecimal RNT_RT_HIGH = STRING.objToBigDecimal(qryMap.get("RNT_RT_HIGH"), null);
        boolean isRNT_RT_HIGH = RNT_RT_HIGH != null;

        //�̰��γ̧C�X���v����J�~�ݭn�]�j��L�o
        if (isRNT_RT_LOW || isRNT_RT_HIGH) {
            Iterator<Map> iter = rtnList.iterator();
            while (iter.hasNext()) {
                Map rtnMap = iter.next();
                BigDecimal RNT_RT = STRING.objToBigDecimal(rtnMap.get("RNT_RT"), BigDecimal.ZERO);
                //�̧C�X���v�L�o
                if (isRNT_RT_LOW && (RNT_RT.compareTo(RNT_RT_LOW) < 0)) {
                    iter.remove();
                }
                //�̰��X���v�L�o
                if (isRNT_RT_HIGH && (RNT_RT.compareTo(RNT_RT_HIGH) > 0)) {
                    iter.remove();
                }
            }
        }
        return rtnList;

    }

    /**
     * �]�w�j�Ӹ�T
     * @param rtnMap
     * @param theEP_A30040
     * @param theEP_A10010
     * @throws SQLException
     * @throws ErrorInputException
     */
    private void setInfo(Map rtnMap, EP_A30040 theEP_A30040, EP_A10010 theEP_A10010) throws SQLException, ErrorInputException {

        //�j�өʽ�_�ϰ�γ~
        rtnMap.put("BLD_KD_1_NM", FieldOptionList.getName("EP", "BLD_KD_1", MapUtils.getString(rtnMap, "BLD_KD_1")));

        //�j�өʽ�_�ϥ�����
        rtnMap.put("BLD_KD_2_NM", FieldOptionList.getName("EP", "BLD_KD_2", MapUtils.getString(rtnMap, "BLD_KD_2")));

        //�j�өʽ�_�ӷ~����
        rtnMap.put("BLD_KD_3_NM", FieldOptionList.getName("EP", "BLD_KD_3", MapUtils.getString(rtnMap, "BLD_KD_3")));

        //�j�ӥγ~  
        rtnMap.put("BLD_USE_CD_NM", FieldOptionList.getName("EP", "BLD_USE_CD", MapUtils.getString(rtnMap, "BLD_USE_CD")));

        //�޲z���
        rtnMap.put("CLC_DIV_NO_NM",
            theEP_A10010.getDivName(MapUtils.getString(rtnMap, "CLC_DIV_NO"), MapUtils.getString(rtnMap, "SUB_CPY_ID")));

        //�p��Ÿm���� = �`���� - �X������ - �ۥΨ���
        rtnMap.put(
            "AVL_PRK",
            obj2Big(rtnMap, "BLD_PRK", BigDecimal.ZERO).subtract(obj2Big(rtnMap, "RNT_PRK", BigDecimal.ZERO)).subtract(
                obj2Big(rtnMap, "SLF_PRK", BigDecimal.ZERO)));

        //�p�⥼�X�����n = �`���n - �X�����n - �ۥέ��n
        rtnMap.put("UN_RNT_SIZE", obj2Big(rtnMap, "BLD_SIZE", BigDecimal.ZERO).subtract(obj2Big(rtnMap, "RNT_SIZE", BigDecimal.ZERO))
                .subtract(obj2Big(rtnMap, "SLF_SIZE", BigDecimal.ZERO)));

        //�p��X���v�A�����ۥΥX���v�� 0%
        rtnMap.put("RNT_RT", theEP_A30040.getRentRate(rtnMap, "2", 3));

    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param map
     * @param key
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            } else {
                String str = o.toString();
                if (StringUtils.isNotBlank(str)) {
                    return new BigDecimal(str);
                } else {
                    return defaultValue;
                }
            }
        }
        return defaultValue;
    }

    /**
     * ��wEIE���� 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �]�w���j�p
     * @param sheet
     * @param SORT_TYPE
     * @param isNeedSub
     * @param EXP_ALL
     */
    private void getSheetColumnWidth(HSSFSheet sheet, String EXP_ALL, boolean isNeedSub) {

        if ("Y".equals(EXP_ALL)) {
            sheet.setColumnWidth(0, 26 * 256);//�j�ӦW��
            sheet.setColumnWidth(1, 10 * 256);//�j�ӥγ~
            sheet.setColumnWidth(2, 17 * 256);//�`���n
            sheet.setColumnWidth(3, 17 * 256);//�w�X�����n
            sheet.setColumnWidth(4, 17 * 256);//���X�����n
            sheet.setColumnWidth(5, 17 * 256);//�ۥέ��n
            sheet.setColumnWidth(6, 10 * 256);//�X���v
            sheet.setColumnWidth(7, 12 * 256);//�`����
            sheet.setColumnWidth(8, 12 * 256);//�w�X������
            sheet.setColumnWidth(9, 12 * 256);//�Ÿm����
            sheet.setColumnWidth(10, 10 * 256);//�ۥΨ���
            sheet.setColumnWidth(11, 15 * 256);//�j�өʽ�_�ϰ�γ~
            sheet.setColumnWidth(12, 17 * 256);//�`����
            sheet.setColumnWidth(13, 10 * 256);//�Ȥ��
            sheet.setColumnWidth(14, 10 * 256);//����
            sheet.setColumnWidth(15, 15 * 256);//�Ÿm�j����
            sheet.setColumnWidth(16, 15 * 256);//�޲z���
            sheet.setColumnWidth(17, 10 * 256);//�j�Ӹg��W��
            sheet.setColumnWidth(18, 12 * 256);//�j�өʽ�ϥ�����
            sheet.setColumnWidth(19, 12 * 256);//�j�өʽ�ӷ~����
        } else {
            if (isNeedSub) {//�ϥΩʭ�
                sheet.setColumnWidth(0, 26 * 256);//�j�ӦW��
                sheet.setColumnWidth(1, 10 * 256);//�j�ӥγ~
                sheet.setColumnWidth(2, 17 * 256);//�`���n
                sheet.setColumnWidth(3, 17 * 256);//�w�X�����n
                sheet.setColumnWidth(4, 17 * 256);//���X�����n
                sheet.setColumnWidth(5, 17 * 256);//�ۥέ��n
                sheet.setColumnWidth(6, 10 * 256);//�X���v
                sheet.setColumnWidth(7, 12 * 256);//�`����
                sheet.setColumnWidth(8, 12 * 256);//�w�X������
                sheet.setColumnWidth(9, 15 * 256);//�j�өʽ�
                sheet.setColumnWidth(10, 17 * 256);//�`����

            } else {//�j�ӥN��
                sheet.setColumnWidth(0, 26 * 256);//�j�ӦW��
                sheet.setColumnWidth(1, 10 * 256);//�j�ӥγ~
                sheet.setColumnWidth(2, 17 * 256);//�`���n
                sheet.setColumnWidth(3, 17 * 256);//�w�X�����n
                sheet.setColumnWidth(4, 17 * 256);//���X�����n
                sheet.setColumnWidth(5, 17 * 256);//�ۥέ��n
                sheet.setColumnWidth(6, 10 * 256);//�X���v
                sheet.setColumnWidth(7, 12 * 256);//�`����
                sheet.setColumnWidth(8, 12 * 256);//�w�X������
                sheet.setColumnWidth(9, 12 * 256);//�Ÿm����
                sheet.setColumnWidth(10, 12 * 256);//�ۥΨ���
                sheet.setColumnWidth(11, 17 * 256);//�`����

            }

        }

    }

    /**
     * �]�w���
     * @param locale
     * @param workbook
     * @param sheet
     * @param isNeedSub
     * @param rtnList
     * @param EXP_ALL
     * @throws ModuleException
     */
    private void createworkbook(LocaleDisplay locale, HSSFWorkbook workbook, HSSFSheet sheet, boolean isNeedSub, List<Map> rtnList,
            String EXP_ALL) throws ModuleException {

        //�]�wSTYLE
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���");//���Y
        HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���");//�����Y
        HSSFCellStyle style7 = createStyle(workbook, 7, "�s�ө���");//���Ӥ�r�a�k

        HSSFRow row;
        int beginRow = 0;

        //�]�w����
        int totalColumns = 0;
        if ("Y".equals(EXP_ALL)) {
            totalColumns = 20;
        } else {
            if (isNeedSub) {
                totalColumns = 11;
            } else {
                totalColumns = 12;
            }
        }

        //���D
        //��1�� (�s�����:)
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style7, 0,
            MessageUtil.getMessage("EP_A30050_MSG_006", new Object[] { locale.formatDate(DATE.today(), "/", "") }), false, true, beginRow,
            beginRow, 0, totalColumns - 1);//�s�����:{0}
        beginRow++;
        //��2��(�j�ӨϥΪ��p�έp)
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style0, 0, MessageUtil.getMessage("EPA3_0050_UI_XLS_TITLE"), false, true, beginRow, beginRow, 0,
            totalColumns - 1);//�j�ӨϥΪ��p�έp
        beginRow++;

        //���Y
        row = sheet.createRow(beginRow);

        if ("Y".equals(EXP_ALL)) {
            setColumn(sheet, row, style1, 0, MessageUtil.getMessage("EPA3_0050_UI_BLD_NAME"), false, false, null, null, null, null);//�j�ӦW��
            setColumn(sheet, row, style1, 1, MessageUtil.getMessage("EPA3_0050_UI_BLD_USE_CD"), false, false, null, null, null, null);//�j�ӥγ~
            setColumn(sheet, row, style1, 2, MessageUtil.getMessage("EPA3_0050_UI_BLD_SIZE"), false, false, null, null, null, null);//�`���n
            setColumn(sheet, row, style1, 3, MessageUtil.getMessage("EPA3_0050_UI_RNT_SIZE"), false, false, null, null, null, null);//�w�X�����n
            setColumn(sheet, row, style1, 4, MessageUtil.getMessage("EPA3_0050_UI_UN_RNT_SIZE"), false, false, null, null, null, null);//���X�����n
            setColumn(sheet, row, style1, 5, MessageUtil.getMessage("EPA3_0050_UI_SLF_SIZE"), false, false, null, null, null, null);//�ۥέ��n
            setColumn(sheet, row, style1, 6, MessageUtil.getMessage("EPA3_0050_UI_RNT_RT"), false, false, null, null, null, null);//�X���v
            setColumn(sheet, row, style1, 7, MessageUtil.getMessage("EPA3_0050_UI_BLD_PRK"), false, false, null, null, null, null);//�`����
            setColumn(sheet, row, style1, 8, MessageUtil.getMessage("EPA3_0050_UI_RNT_PRK"), false, false, null, null, null, null);//�w�X������
            setColumn(sheet, row, style1, 9, MessageUtil.getMessage("EPA3_0050_UI_AVL_PRK"), false, false, null, null, null, null);//�Ÿm����
            setColumn(sheet, row, style1, 10, MessageUtil.getMessage("EPA3_0050_UI_SLF_PRK"), false, false, null, null, null, null);//�ۥΨ���
            setColumn(sheet, row, style1, 11, MessageUtil.getMessage("EPA3_0050_UI_BLD_KD_1_NM"), false, false, null, null, null, null);//�j�өʽ�_�ϰ�γ~
            setColumn(sheet, row, style1, 12, MessageUtil.getMessage("EPA3_0050_UI_RNT_AMT"), false, false, null, null, null, null);//�`����
            setColumn(sheet, row, style1, 13, MessageUtil.getMessage("EPA3_0050_UI_CUS_CNT"), false, false, null, null, null, null);//�Ȥ��
            setColumn(sheet, row, style1, 14, MessageUtil.getMessage("EPA3_0050_UI_DIV_CNT"), false, false, null, null, null, null);// ����
            setColumn(sheet, row, style1, 15, MessageUtil.getMessage("EPA3_0050_UI_PART_CNT"), false, false, null, null, null, null);//�Ÿm�j����
            setColumn(sheet, row, style1, 16, MessageUtil.getMessage("EPA3_0050_UI_CLC_DIV_NO_NM"), false, false, null, null, null, null);//�޲z���
            setColumn(sheet, row, style1, 17, MessageUtil.getMessage("EPA3_0050_UI_BLD_USR_NAME"), false, false, null, null, null, null);//�j�Ӹg��W��
            setColumn(sheet, row, style1, 18, MessageUtil.getMessage("EPA3_0050_UI_BLD_KD_2_NM"), false, false, null, null, null, null);//�j�өʽ�ϥ�����
            setColumn(sheet, row, style1, 19, MessageUtil.getMessage("EPA3_0050_UI_BLD_KD_3_NM"), false, false, null, null, null, null);//�j�өʽ�ӷ~����
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(MessageUtil.getMessage("EPA3_0050_UI_RNT_PRK_1")).append("\r\n")
                    .append(MessageUtil.getMessage("EPA3_0050_UI_RNT_PRK_2"));
            String tmpRNT_PRK = sb.toString();
            sb.setLength(0);
            if (isNeedSub) {//�ϥΩʭ�
                setColumn(sheet, row, style1, 0, MessageUtil.getMessage("EPA3_0050_UI_BLD_NAME"), false, false, null, null, null, null);//�j�ӦW��
                setColumn(sheet, row, style1, 1, MessageUtil.getMessage("EPA3_0050_UI_BLD_USE_CD_1"), false, false, null, null, null, null);//�γ~
                setColumn(sheet, row, style1, 2, MessageUtil.getMessage("EPA3_0050_UI_BLD_SIZE"), false, false, null, null, null, null);//�`���n
                setColumn(sheet, row, style1, 3, MessageUtil.getMessage("EPA3_0050_UI_RNT_SIZE"), false, false, null, null, null, null);//�w�X�����n
                setColumn(sheet, row, style1, 4, MessageUtil.getMessage("EPA3_0050_UI_UN_RNT_SIZE"), false, false, null, null, null, null);//���X�����n
                setColumn(sheet, row, style1, 5, MessageUtil.getMessage("EPA3_0050_UI_SLF_SIZE"), false, false, null, null, null, null);//�ۥέ��n
                setColumn(sheet, row, style1, 6, MessageUtil.getMessage("EPA3_0050_UI_RNT_RT"), false, false, null, null, null, null);//�X���v
                setColumn(sheet, row, style1, 7, MessageUtil.getMessage("EPA3_0050_UI_BLD_PRK"), false, false, null, null, null, null);//�`����
                setColumn(sheet, row, style1, 8, tmpRNT_PRK, false, false, null, null, null, null);//�w�X��(����)����
                setColumn(sheet, row, style1, 9, MessageUtil.getMessage("EPA3_0050_UI_BLD_KD_1_NM_1"), false, false, null, null, null, null);//�j�өʽ�
                setColumn(sheet, row, style1, 10, MessageUtil.getMessage("EPA3_0050_UI_RNT_AMT"), false, false, null, null, null, null);//�`����
            } else {//�j�ӥN��
                setColumn(sheet, row, style1, 0, MessageUtil.getMessage("EPA3_0050_UI_BLD_NAME"), false, false, null, null, null, null);//�j�ӦW��
                setColumn(sheet, row, style1, 1, MessageUtil.getMessage("EPA3_0050_UI_BLD_USE_CD_1"), false, false, null, null, null, null);//�γ~
                setColumn(sheet, row, style1, 2, MessageUtil.getMessage("EPA3_0050_UI_BLD_SIZE"), false, false, null, null, null, null);//�`���n
                setColumn(sheet, row, style1, 3, MessageUtil.getMessage("EPA3_0050_UI_RNT_SIZE"), false, false, null, null, null, null);//�w�X�����n
                setColumn(sheet, row, style1, 4, MessageUtil.getMessage("EPA3_0050_UI_UN_RNT_SIZE"), false, false, null, null, null, null);//���X�����n
                setColumn(sheet, row, style1, 5, MessageUtil.getMessage("EPA3_0050_UI_SLF_SIZE"), false, false, null, null, null, null);//�ۥέ��n
                setColumn(sheet, row, style1, 6, MessageUtil.getMessage("EPA3_0050_UI_RNT_RT"), false, false, null, null, null, null);//�X���v
                setColumn(sheet, row, style1, 7, MessageUtil.getMessage("EPA3_0050_UI_BLD_PRK"), false, false, null, null, null, null);//�`����
                setColumn(sheet, row, style1, 8, tmpRNT_PRK, false, false, null, null, null, null);//�w�X��(����)����
                setColumn(sheet, row, style1, 9, MessageUtil.getMessage("EPA3_0050_UI_AVL_PRK"), false, false, null, null, null, null);//�Ÿm����
                setColumn(sheet, row, style1, 10, MessageUtil.getMessage("EPA3_0050_UI_SLF_PRK"), false, false, null, null, null, null);//�ۥΨ���
                setColumn(sheet, row, style1, 11, MessageUtil.getMessage("EPA3_0050_UI_RNT_AMT"), false, false, null, null, null, null);//�`����    
            }
        }
        beginRow++;

        //���Ӹ��(�t�X�p,�s�դp�p)
        createDetail(workbook, beginRow, sheet, row, isNeedSub, rtnList, EXP_ALL);

    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @return
     */
    private HSSFCellStyle createStyle(HSSFWorkbook workbook, int type, String font_type) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();

        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 16); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);

        //�Ʀr�榡
        HSSFDataFormat format = workbook.createDataFormat();
        boolean needSameBorder = true;
        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�j���Y
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            font.setFontHeightInPoints((short) 22); // �j�p         
            needSameBorder = false;
        } else if (type == 1) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.BLACK.index);
            font.setColor(HSSFColor.BLACK.index);
            style.setWrapText(true);
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 3) {//��r�a�k
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        } else if (type == 5) {//���ӼƦr(�d����,�L�p�Ʀ�,�m�k)
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
            style.setDataFormat(format.getFormat("#,##0"));
        } else if (type == 6) {//���ӼƦr(�d����,��p�Ʀ��3��,�m�k)
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
            style.setDataFormat(format.getFormat("#,##0.000"));
        } else if (type == 7) {//��r�a�k
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
            needSameBorder = false;
        } else if (type == 8) {//���ӼƦr(�d����,�L�p�Ʀ�,�m��)
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setDataFormat(format.getFormat("#,##0"));
        } else if (type == 9) {//���ӼƦr(#,##0.0%)
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
            style.setDataFormat(format.getFormat("#,##0.0%"));
        }

        style.setFont(font);

        //�~��
        if (needSameBorder) {
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        }

        return style;
    }

    /**
     *  �]�w���
     * @param sheet
     * @param bodyRow
     * @param style ���A
     * @param columnNumber ���ͲĴX��cell
     * @param content  ���
     * @param isNumeric �O�_���Ʀr���
     * @param doCombine �O�_�ݦX���x�s��
     * @param firstRow
     * @param lastRow
     * @param firstCol
     * @param lastCol
     */
    private void setColumn(HSSFSheet sheet, HSSFRow bodyRow, HSSFCellStyle style, Integer columnNumber, String content, boolean isNumeric,
            boolean doCombine, Integer firstRow, Integer lastRow, Integer firstCol, Integer lastCol) {

        HSSFCell bodyCell;
        bodyCell = bodyRow.createCell(columnNumber);
        bodyCell.setCellStyle(style);

        if (doCombine) {
            for (int s = firstCol; s <= lastCol; s++) {
                bodyCell = bodyRow.createCell(s);
                bodyCell.setCellStyle(style);
            }

            //�X���x�s��
            CellRangeAddress range_inputCount = new CellRangeAddress(firstRow, lastRow, firstCol, lastCol);
            sheet.addMergedRegion(range_inputCount);

            bodyCell = bodyRow.getCell(firstCol);
        }

        if (isNumeric) {
            if (StringUtils.isNotBlank(content)) {
                bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                Double bodyText = new Double(content);
                bodyCell.setCellValue(bodyText);
            }
        } else {
            HSSFRichTextString text = new HSSFRichTextString(content);
            bodyCell.setCellValue(text);
        }
    }

    /**
     * �إߪ��椺�e
     * @param beginRow
     * @param sheet
     * @param row
     * @param style2
     * @param style3
     * @param isNeedSub �O�_�ݸs�դp�p
     * @param rtnList ���Ӹ��
     * @throws ModuleException
     */
    private void createDetail(HSSFWorkbook workbook, int beginRow, HSSFSheet sheet, HSSFRow row, boolean isNeedSub, List<Map> rtnList,
            String EXP_ALL) throws ModuleException {
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���");//���Ӥ�r(�m��)
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���");//���Ӥ�r(�m�k)
        HSSFCellStyle style4 = createStyle(workbook, 4, "�s�ө���");//���Ӥ�r(�m��)
        HSSFCellStyle style5 = createStyle(workbook, 5, "�s�ө���");//���ӼƦr(�d����,�L�p�Ʀ�)
        HSSFCellStyle style6 = createStyle(workbook, 6, "�s�ө���");//���ӼƦr(�d����,�p�Ʋ�3��)
        HSSFCellStyle style8 = createStyle(workbook, 8, "�s�ө���");//���ӼƦr
        HSSFCellStyle style9 = createStyle(workbook, 9, "�s�ө���");//���ӼƦr(#,##0.0%)

        //�X�p���
        Map<String, BigDecimal> totMap = new HashMap<String, BigDecimal>();
        String totColumns[] = { "BLD_SIZE", "RNT_SIZE", "UN_RNT_SIZE", "SLF_SIZE", "BLD_PRK", "RNT_PRK", "AVL_PRK", "SLF_PRK", "RNT_AMT",
                "CUS_CNT", "DIV_CNT", "PART_CNT" };
        for (String col : totColumns) {
            totMap.put(col, BigDecimal.ZERO);
        }
        Map<String, Map> groupMap1 = new HashMap<String, Map>();//�޲z���  
        Map<String, Map> groupMap2 = new HashMap<String, Map>();//�޲z���   + �j�ӨϥΩʽ�
        //�p�p���
        String[] sumColumns = { "BLD_SIZE", "RNT_SIZE", "UN_RNT_SIZE", "SLF_SIZE", "BLD_PRK", "RNT_PRK", "RNT_AMT", "AVL_PRK", "SLF_PRK",
                "CUS_CNT", "DIV_CNT", "PART_CNT" };
        EP_A30040 theEP_A30040 = new EP_A30040();
        //����
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);
            String CLC_DIV_NO_NM = MapUtils.getString(rtnMap, "CLC_DIV_NO_NM", MessageUtil.getMessage("EPA3_0050_UI_CLC_DIV_NO_OTHERS"));//�䥦��
            String groupKey1 = CLC_DIV_NO_NM;//�޲z���  
            Map<String, BigDecimal> subTotMap;
            String BLD_KD_1_NM = MapUtils.getString(rtnMap, "BLD_KD_1_NM");
            if (isNeedSub) {//�ϥΩʽ�
                String groupKey2 = sb.append(BLD_KD_1_NM).append('&').append(groupKey1).toString();//�j�ӨϥΩʽ� + '&' +�޲z���
                sb.setLength(0);
                if (!groupMap2.isEmpty() && !groupMap2.containsKey(groupKey2)) {
                    Iterator entries = groupMap2.entrySet().iterator();
                    entries.hasNext();
                    Entry thisEntry = (Entry) entries.next();
                    String groupkey = ((String) thisEntry.getKey()).split("&")[0];
                    subTotMap = (Map) thisEntry.getValue();
                    String SUB_RNT_RT = theEP_A30040.getRentRate(subTotMap, "2", 3).toPlainString();//�p��X���v
                    row = sheet.createRow(beginRow);
                    if ("Y".equals(EXP_ALL)) {
                        setColumn(sheet, row, style3, 0, groupkey + MessageUtil.getMessage("EPA3_0050_UI_TOT2"), false, false, null, null,
                            null, null);//�s�զW��+�X�p
                        setColumn(sheet, row, style2, 1, null, false, false, null, null, null, null);//�j�ӥγ~
                        setColumn(sheet, row, style6, 2, subTotMap.get("BLD_SIZE").toPlainString(), true, false, null, null, null, null);//�`���n
                        setColumn(sheet, row, style6, 3, subTotMap.get("RNT_SIZE").toPlainString(), true, false, null, null, null, null);//�w�X�����n
                        setColumn(sheet, row, style6, 4, subTotMap.get("UN_RNT_SIZE").toPlainString(), true, false, null, null, null, null);//���X�����n
                        setColumn(sheet, row, style6, 5, subTotMap.get("SLF_SIZE").toPlainString(), true, false, null, null, null, null);//�ۥέ��n
                        setColumn(sheet, row, style9, 6, SUB_RNT_RT, true, false, null, null, null, null);//�X���v
                        setColumn(sheet, row, style5, 7, subTotMap.get("BLD_PRK").toPlainString(), true, false, null, null, null, null);//�`����
                        setColumn(sheet, row, style5, 8, subTotMap.get("RNT_PRK").toPlainString(), true, false, null, null, null, null);//�w�X������
                        setColumn(sheet, row, style5, 9, subTotMap.get("AVL_PRK").toPlainString(), true, false, null, null, null, null);//�Ÿm����
                        setColumn(sheet, row, style5, 10, subTotMap.get("SLF_PRK").toPlainString(), true, false, null, null, null, null);//�ۥΨ���
                        setColumn(sheet, row, style4, 11, null, false, false, null, null, null, null);//�j�өʽ�_�ϰ�γ~
                        setColumn(sheet, row, style5, 12, subTotMap.get("RNT_AMT").toPlainString(), true, false, null, null, null, null);//�`����
                        setColumn(sheet, row, style5, 13, subTotMap.get("CUS_CNT").toPlainString(), true, false, null, null, null, null);//�Ȥ��
                        setColumn(sheet, row, style5, 14, subTotMap.get("DIV_CNT").toPlainString(), true, false, null, null, null, null);//����
                        setColumn(sheet, row, style5, 15, subTotMap.get("PART_CNT").toPlainString(), true, false, null, null, null, null);//�Ÿm�j����
                        setColumn(sheet, row, style2, 16, null, false, false, null, null, null, null);//�޲z���
                        setColumn(sheet, row, style2, 17, null, false, false, null, null, null, null);//�j�Ӹg��W��
                        setColumn(sheet, row, style2, 18, null, false, false, null, null, null, null);//�j�өʽ�ϥ�����
                        setColumn(sheet, row, style2, 19, null, false, false, null, null, null, null);//�j�өʽ�ӷ~����
                    } else {
                        setColumn(sheet, row, style3, 0, groupkey + MessageUtil.getMessage("EPA3_0050_UI_TOT2"), false, false, null, null,
                            null, null);//�s�զW��+�X�p
                        setColumn(sheet, row, style2, 1, null, false, false, null, null, null, null);//�j�ӥγ~
                        setColumn(sheet, row, style6, 2, subTotMap.get("BLD_SIZE").toPlainString(), true, false, null, null, null, null);//�`���n
                        setColumn(sheet, row, style6, 3, subTotMap.get("RNT_SIZE").toPlainString(), true, false, null, null, null, null);//�w�X�����n
                        setColumn(sheet, row, style6, 4, subTotMap.get("UN_RNT_SIZE").toPlainString(), true, false, null, null, null, null);//���X�����n
                        setColumn(sheet, row, style6, 5, subTotMap.get("SLF_SIZE").toPlainString(), true, false, null, null, null, null);//�ۥέ��n
                        setColumn(sheet, row, style9, 6, SUB_RNT_RT, true, false, null, null, null, null);//�X���v
                        setColumn(sheet, row, style5, 7, subTotMap.get("BLD_PRK").toPlainString(), true, false, null, null, null, null);//�`����
                        setColumn(sheet, row, style5, 8, subTotMap.get("RNT_PRK").toPlainString(), true, false, null, null, null, null);//�w�X������
                        setColumn(sheet, row, style5, 9, null, false, false, null, null, null, null);//�j�өʽ�
                        setColumn(sheet, row, style5, 10, subTotMap.get("RNT_AMT").toPlainString(), true, false, null, null, null, null);//�`����
                    }
                    beginRow++;
                    groupMap2.clear();
                }
                if (groupMap2.isEmpty()) {
                    subTotMap = new HashMap<String, BigDecimal>();
                    for (String col : sumColumns) {
                        subTotMap.put(col, BigDecimal.ZERO);
                    }
                    groupMap2.put(groupKey2, subTotMap);
                } else {
                    subTotMap = groupMap2.get(groupKey2);
                }

                //�s�դG�p�p�p��
                for (String col : sumColumns) {
                    BigDecimal total = subTotMap.get(col).add(obj2Big(rtnMap, col, BigDecimal.ZERO));
                    subTotMap.put(col, total);
                }
            }
            if (!groupMap1.isEmpty() && !groupMap1.containsKey(groupKey1)) {
                Iterator entries = groupMap1.entrySet().iterator();
                entries.hasNext();
                Entry thisEntry = (Entry) entries.next();
                String groupkey = (String) thisEntry.getKey();
                subTotMap = (Map) thisEntry.getValue();
                String SUB_RNT_RT = theEP_A30040.getRentRate(subTotMap, "2", 3).toPlainString();//�p��X���v
                row = sheet.createRow(beginRow);
                if ("Y".equals(EXP_ALL)) {
                    setColumn(sheet, row, style3, 0, groupkey + MessageUtil.getMessage("EPA3_0050_UI_TOT2"), false, false, null, null,
                        null, null);//�s�զW��+�X�p
                    setColumn(sheet, row, style2, 1, null, false, false, null, null, null, null);//�j�ӥγ~
                    setColumn(sheet, row, style6, 2, subTotMap.get("BLD_SIZE").toPlainString(), true, false, null, null, null, null);//�`���n
                    setColumn(sheet, row, style6, 3, subTotMap.get("RNT_SIZE").toPlainString(), true, false, null, null, null, null);//�w�X�����n
                    setColumn(sheet, row, style6, 4, subTotMap.get("UN_RNT_SIZE").toPlainString(), true, false, null, null, null, null);//���X�����n
                    setColumn(sheet, row, style6, 5, subTotMap.get("SLF_SIZE").toPlainString(), true, false, null, null, null, null);//�ۥέ��n
                    setColumn(sheet, row, style9, 6, SUB_RNT_RT, true, false, null, null, null, null);//�X���v
                    setColumn(sheet, row, style5, 7, subTotMap.get("BLD_PRK").toPlainString(), true, false, null, null, null, null);//�`����
                    setColumn(sheet, row, style5, 8, subTotMap.get("RNT_PRK").toPlainString(), true, false, null, null, null, null);//�w�X������
                    setColumn(sheet, row, style5, 9, subTotMap.get("AVL_PRK").toPlainString(), true, false, null, null, null, null);//�Ÿm����
                    setColumn(sheet, row, style5, 10, subTotMap.get("SLF_PRK").toPlainString(), true, false, null, null, null, null);//�ۥΨ���
                    setColumn(sheet, row, style4, 11, null, false, false, null, null, null, null);//�j�өʽ�_�ϰ�γ~
                    setColumn(sheet, row, style5, 12, subTotMap.get("RNT_AMT").toPlainString(), true, false, null, null, null, null);//�`����
                    setColumn(sheet, row, style5, 13, subTotMap.get("CUS_CNT").toPlainString(), true, false, null, null, null, null);//�Ȥ��
                    setColumn(sheet, row, style5, 14, subTotMap.get("DIV_CNT").toPlainString(), true, false, null, null, null, null);//����
                    setColumn(sheet, row, style5, 15, subTotMap.get("PART_CNT").toPlainString(), true, false, null, null, null, null);//�Ÿm�j����
                    setColumn(sheet, row, style2, 16, null, false, false, null, null, null, null);//�޲z���
                    setColumn(sheet, row, style2, 17, null, false, false, null, null, null, null);//�j�Ӹg��W��
                    setColumn(sheet, row, style2, 18, null, false, false, null, null, null, null);//�j�өʽ�ϥ�����
                    setColumn(sheet, row, style2, 19, null, false, false, null, null, null, null);//�j�өʽ�ӷ~����
                } else {
                    setColumn(sheet, row, style3, 0, groupkey + MessageUtil.getMessage("EPA3_0050_UI_TOT2"), false, false, null, null,
                        null, null);//�s�զW��+�X�p
                    setColumn(sheet, row, style2, 1, null, false, false, null, null, null, null);//�j�ӥγ~
                    setColumn(sheet, row, style6, 2, subTotMap.get("BLD_SIZE").toPlainString(), true, false, null, null, null, null);//�`���n
                    setColumn(sheet, row, style6, 3, subTotMap.get("RNT_SIZE").toPlainString(), true, false, null, null, null, null);//�w�X�����n
                    setColumn(sheet, row, style6, 4, subTotMap.get("UN_RNT_SIZE").toPlainString(), true, false, null, null, null, null);//���X�����n
                    setColumn(sheet, row, style6, 5, subTotMap.get("SLF_SIZE").toPlainString(), true, false, null, null, null, null);//�ۥέ��n
                    setColumn(sheet, row, style9, 6, SUB_RNT_RT, true, false, null, null, null, null);//�X���v
                    setColumn(sheet, row, style5, 7, subTotMap.get("BLD_PRK").toPlainString(), true, false, null, null, null, null);//�`����
                    setColumn(sheet, row, style5, 8, subTotMap.get("RNT_PRK").toPlainString(), true, false, null, null, null, null);//�w�X������
                    if (isNeedSub) {
                        setColumn(sheet, row, style5, 9, null, false, false, null, null, null, null);//�j�өʽ�
                        setColumn(sheet, row, style5, 10, subTotMap.get("RNT_AMT").toPlainString(), true, false, null, null, null, null);//�`����

                    } else {
                        setColumn(sheet, row, style5, 9, subTotMap.get("AVL_PRK").toPlainString(), true, false, null, null, null, null);//�Ÿm����
                        setColumn(sheet, row, style5, 10, subTotMap.get("SLF_PRK").toPlainString(), true, false, null, null, null, null);//�ۥΨ���
                        setColumn(sheet, row, style5, 11, subTotMap.get("RNT_AMT").toPlainString(), true, false, null, null, null, null);//�`����
                    }

                }
                beginRow++;
                groupMap1.clear();

            }

            if (groupMap1.isEmpty()) {
                subTotMap = new HashMap<String, BigDecimal>();
                for (String col : sumColumns) {
                    subTotMap.put(col, BigDecimal.ZERO);
                }
                groupMap1.put(groupKey1, subTotMap);
            } else {
                subTotMap = groupMap1.get(groupKey1);
            }
            //�s�դ@�p�p�p��
            for (String col : sumColumns) {
                BigDecimal total = subTotMap.get(col).add(obj2Big(rtnMap, col, BigDecimal.ZERO));
                subTotMap.put(col, total);
            }

            //���Ӹ��
            row = sheet.createRow(beginRow);
            if ("Y".equals(EXP_ALL)) {
                setColumn(sheet, row, style4, 0,
                    sb.append(MapUtils.getString(rtnMap, "BLD_CD", "")).append(" ").append(MapUtils.getString(rtnMap, "BLD_NAME", ""))
                            .toString(), false, false, null, null, null, null);//�j�ӦW��
                sb.setLength(0);
                setColumn(sheet, row, style2, 1, MapUtils.getString(rtnMap, "BLD_USE_CD_NM"), false, false, null, null, null, null);//�j�ӥγ~
                setColumn(sheet, row, style6, 2, MapUtils.getString(rtnMap, "BLD_SIZE"), true, false, null, null, null, null);//�`���n
                setColumn(sheet, row, style6, 3, MapUtils.getString(rtnMap, "RNT_SIZE"), true, false, null, null, null, null);//�w�X�����n
                setColumn(sheet, row, style6, 4, MapUtils.getString(rtnMap, "UN_RNT_SIZE"), true, false, null, null, null, null);//���X�����n
                setColumn(sheet, row, style6, 5, MapUtils.getString(rtnMap, "SLF_SIZE"), true, false, null, null, null, null);//�ۥέ��n
                setColumn(sheet, row, style9, 6, MapUtils.getString(rtnMap, "RNT_RT"), true, false, null, null, null, null);//�X���v
                setColumn(sheet, row, style5, 7, MapUtils.getString(rtnMap, "BLD_PRK"), true, false, null, null, null, null);//�`����
                setColumn(sheet, row, style5, 8, MapUtils.getString(rtnMap, "RNT_PRK"), true, false, null, null, null, null);//�w�X������
                setColumn(sheet, row, style5, 9, MapUtils.getString(rtnMap, "AVL_PRK"), true, false, null, null, null, null);//�Ÿm����
                setColumn(sheet, row, style5, 10, MapUtils.getString(rtnMap, "SLF_PRK"), true, false, null, null, null, null);//�ۥΨ���
                setColumn(sheet, row, style4, 11, MapUtils.getString(rtnMap, "BLD_KD_1_NM"), false, false, null, null, null, null);//�j�өʽ�_�ϰ�γ~
                setColumn(sheet, row, style5, 12, MapUtils.getString(rtnMap, "RNT_AMT"), true, false, null, null, null, null);//�`����
                setColumn(sheet, row, style5, 13, MapUtils.getString(rtnMap, "CUS_CNT"), true, false, null, null, null, null);//�Ȥ��
                setColumn(sheet, row, style5, 14, MapUtils.getString(rtnMap, "DIV_CNT"), true, false, null, null, null, null);// ����
                setColumn(sheet, row, style5, 15, MapUtils.getString(rtnMap, "PART_CNT"), true, false, null, null, null, null);//�Ÿm�j����
                setColumn(sheet, row, style2, 16, MapUtils.getString(rtnMap, "CLC_DIV_NO_NM"), false, false, null, null, null, null);//�޲z���
                setColumn(sheet, row, style2, 17, MapUtils.getString(rtnMap, "BLD_USR_NAME"), false, false, null, null, null, null);//�j�Ӹg��W��
                setColumn(sheet, row, style2, 18, MapUtils.getString(rtnMap, "BLD_KD_2_NM"), false, false, null, null, null, null);//�j�өʽ�ϥ�����
                setColumn(sheet, row, style2, 19, MapUtils.getString(rtnMap, "BLD_KD_3_NM"), false, false, null, null, null, null);//�j�өʽ�ӷ~����
            } else {
                String BLD_NM = MapUtils.getString(rtnMap, "BLD_NAME", "");
                if (BLD_NM.length() > 6) {
                    BLD_NM = BLD_NM.substring(0, 6);
                }
                sb.append(MapUtils.getString(rtnMap, "BLD_CD", "")).append(' ').append(BLD_NM);
                String BLD_CD_NAME = sb.toString();
                sb.setLength(0);
                if (isNeedSub) {//�ϥΩʭ�
                    setColumn(sheet, row, style4, 0, BLD_CD_NAME, false, false, null, null, null, null);//�j�ӦW��
                    setColumn(sheet, row, style2, 1, MapUtils.getString(rtnMap, "BLD_USE_CD_NM"), false, false, null, null, null, null);//�j�ӥγ~
                    setColumn(sheet, row, style6, 2, MapUtils.getString(rtnMap, "BLD_SIZE"), true, false, null, null, null, null);//�`���n
                    setColumn(sheet, row, style6, 3, MapUtils.getString(rtnMap, "RNT_SIZE"), true, false, null, null, null, null);//�w�X�����n
                    setColumn(sheet, row, style6, 4, MapUtils.getString(rtnMap, "UN_RNT_SIZE"), true, false, null, null, null, null);//���X�����n
                    setColumn(sheet, row, style6, 5, MapUtils.getString(rtnMap, "SLF_SIZE"), true, false, null, null, null, null);//�ۥέ��n
                    setColumn(sheet, row, style9, 6, MapUtils.getString(rtnMap, "RNT_RT"), true, false, null, null, null, null);//�X���v
                    setColumn(sheet, row, style5, 7, MapUtils.getString(rtnMap, "BLD_PRK"), true, false, null, null, null, null);//�`����
                    setColumn(sheet, row, style5, 8, MapUtils.getString(rtnMap, "RNT_PRK"), true, false, null, null, null, null);//�w�X������
                    setColumn(sheet, row, style4, 9, MapUtils.getString(rtnMap, "BLD_KD_1_NM"), false, false, null, null, null, null);//�j�өʽ�
                    setColumn(sheet, row, style5, 10, MapUtils.getString(rtnMap, "RNT_AMT"), true, false, null, null, null, null);//�`����
                } else {//�j�ӥN��
                    setColumn(sheet, row, style4, 0, BLD_CD_NAME, false, false, null, null, null, null);//�j�ӦW��
                    sb.setLength(0);
                    setColumn(sheet, row, style2, 1, MapUtils.getString(rtnMap, "BLD_USE_CD_NM"), false, false, null, null, null, null);//�j�ӥγ~
                    setColumn(sheet, row, style6, 2, MapUtils.getString(rtnMap, "BLD_SIZE"), true, false, null, null, null, null);//�`���n
                    setColumn(sheet, row, style6, 3, MapUtils.getString(rtnMap, "RNT_SIZE"), true, false, null, null, null, null);//�w�X�����n
                    setColumn(sheet, row, style6, 4, MapUtils.getString(rtnMap, "UN_RNT_SIZE"), true, false, null, null, null, null);//���X�����n
                    setColumn(sheet, row, style6, 5, MapUtils.getString(rtnMap, "SLF_SIZE"), true, false, null, null, null, null);//�ۥέ��n
                    setColumn(sheet, row, style9, 6, MapUtils.getString(rtnMap, "RNT_RT"), true, false, null, null, null, null);//�X���v
                    setColumn(sheet, row, style5, 7, MapUtils.getString(rtnMap, "BLD_PRK"), true, false, null, null, null, null);//�`����
                    setColumn(sheet, row, style5, 8, MapUtils.getString(rtnMap, "RNT_PRK"), true, false, null, null, null, null);//�w�X������
                    setColumn(sheet, row, style5, 9, MapUtils.getString(rtnMap, "AVL_PRK"), true, false, null, null, null, null);//�Ÿm����
                    setColumn(sheet, row, style5, 10, MapUtils.getString(rtnMap, "SLF_PRK"), true, false, null, null, null, null);//�ۥΨ���
                    setColumn(sheet, row, style5, 11, MapUtils.getString(rtnMap, "RNT_AMT"), true, false, null, null, null, null);//�`����
                }
            }
            beginRow++;

            //�X�p�p��
            for (String col : totColumns) {
                BigDecimal total = totMap.get(col).add(obj2Big(rtnMap, col, BigDecimal.ZERO));
                totMap.put(col, total);
            }

        }
        if (!groupMap2.isEmpty()) {
            Iterator entries = groupMap2.entrySet().iterator();
            entries.hasNext();
            Entry thisEntry = (Entry) entries.next();
            String groupkey = (String) thisEntry.getKey();
            Map<String, BigDecimal> subTotMap = (Map) thisEntry.getValue();
            String SUB_RNT_RT = theEP_A30040.getRentRate(subTotMap, "2", 3).toPlainString();//�p��X���v
            row = sheet.createRow(beginRow);
            if ("Y".equals(EXP_ALL)) {
                setColumn(sheet, row, style3, 0, groupkey.split("&")[0] + MessageUtil.getMessage("EPA3_0050_UI_TOT2"), false, false, null,
                    null, null, null);//�s�զW��+�X�p
                setColumn(sheet, row, style2, 1, null, false, false, null, null, null, null);//�j�ӥγ~
                setColumn(sheet, row, style6, 2, subTotMap.get("BLD_SIZE").toPlainString(), true, false, null, null, null, null);//�`���n
                setColumn(sheet, row, style6, 3, subTotMap.get("RNT_SIZE").toPlainString(), true, false, null, null, null, null);//�w�X�����n
                setColumn(sheet, row, style6, 4, subTotMap.get("UN_RNT_SIZE").toPlainString(), true, false, null, null, null, null);//���X�����n
                setColumn(sheet, row, style6, 5, subTotMap.get("SLF_SIZE").toPlainString(), true, false, null, null, null, null);//�ۥέ��n
                setColumn(sheet, row, style9, 6, SUB_RNT_RT, true, false, null, null, null, null);//�X���v
                setColumn(sheet, row, style5, 7, subTotMap.get("BLD_PRK").toPlainString(), true, false, null, null, null, null);//�`����
                setColumn(sheet, row, style5, 8, subTotMap.get("RNT_PRK").toPlainString(), true, false, null, null, null, null);//�w�X������
                setColumn(sheet, row, style5, 9, subTotMap.get("AVL_PRK").toPlainString(), true, false, null, null, null, null);//�Ÿm����
                setColumn(sheet, row, style5, 10, subTotMap.get("SLF_PRK").toPlainString(), true, false, null, null, null, null);//�ۥΨ���
                setColumn(sheet, row, style5, 11, null, false, false, null, null, null, null);//�j�өʽ�_�ϰ�γ~
                setColumn(sheet, row, style5, 12, subTotMap.get("RNT_AMT").toPlainString(), true, false, null, null, null, null);//�`����
                setColumn(sheet, row, style5, 13, subTotMap.get("CUS_CNT").toPlainString(), true, false, null, null, null, null);//�Ȥ��
                setColumn(sheet, row, style5, 14, subTotMap.get("DIV_CNT").toPlainString(), true, false, null, null, null, null);//����
                setColumn(sheet, row, style5, 15, subTotMap.get("PART_CNT").toPlainString(), true, false, null, null, null, null);//�Ÿm�j����
                setColumn(sheet, row, style2, 16, null, false, false, null, null, null, null);//�޲z���
                setColumn(sheet, row, style2, 17, null, false, false, null, null, null, null);//�j�Ӹg��W��
                setColumn(sheet, row, style2, 18, null, false, false, null, null, null, null);//�j�өʽ�ϥ�����
                setColumn(sheet, row, style2, 19, null, false, false, null, null, null, null);//�j�өʽ�ӷ~����
            } else {
                setColumn(sheet, row, style3, 0, groupkey.split("&")[0] + MessageUtil.getMessage("EPA3_0050_UI_TOT2"), false, false, null,
                    null, null, null);//�s�զW��+�X�p
                setColumn(sheet, row, style2, 1, null, false, false, null, null, null, null);//�j�ӥγ~
                setColumn(sheet, row, style6, 2, subTotMap.get("BLD_SIZE").toPlainString(), true, false, null, null, null, null);//�`���n
                setColumn(sheet, row, style6, 3, subTotMap.get("RNT_SIZE").toPlainString(), true, false, null, null, null, null);//�w�X�����n
                setColumn(sheet, row, style6, 4, subTotMap.get("UN_RNT_SIZE").toPlainString(), true, false, null, null, null, null);//���X�����n
                setColumn(sheet, row, style6, 5, subTotMap.get("SLF_SIZE").toPlainString(), true, false, null, null, null, null);//�ۥέ��n
                setColumn(sheet, row, style9, 6, SUB_RNT_RT, true, false, null, null, null, null);//�X���v
                setColumn(sheet, row, style5, 7, subTotMap.get("BLD_PRK").toPlainString(), true, false, null, null, null, null);//�`����
                setColumn(sheet, row, style5, 8, subTotMap.get("RNT_PRK").toPlainString(), true, false, null, null, null, null);//�w�X������
                setColumn(sheet, row, style5, 9, null, false, false, null, null, null, null);//�j�өʽ�
                setColumn(sheet, row, style5, 10, subTotMap.get("RNT_AMT").toPlainString(), true, false, null, null, null, null);//�`����
            }
            beginRow++;
            groupMap2.clear();

        }
        if (!groupMap1.isEmpty()) {

            Iterator entries = groupMap1.entrySet().iterator();
            entries.hasNext();
            Entry thisEntry = (Entry) entries.next();
            String groupkey = (String) thisEntry.getKey();
            Map<String, BigDecimal> subTotMap = (Map) thisEntry.getValue();
            String SUB_RNT_RT = theEP_A30040.getRentRate(subTotMap, "2", 3).toPlainString();//�p��X���v
            row = sheet.createRow(beginRow);
            if ("Y".equals(EXP_ALL)) {
                setColumn(sheet, row, style3, 0, groupkey + MessageUtil.getMessage("EPA3_0050_UI_TOT2"), false, false, null, null, null,
                    null);//�s�զW��+�X�p
                setColumn(sheet, row, style2, 1, null, false, false, null, null, null, null);//�j�ӥγ~
                setColumn(sheet, row, style6, 2, subTotMap.get("BLD_SIZE").toPlainString(), true, false, null, null, null, null);//�`���n
                setColumn(sheet, row, style6, 3, subTotMap.get("RNT_SIZE").toPlainString(), true, false, null, null, null, null);//�w�X�����n
                setColumn(sheet, row, style6, 4, subTotMap.get("UN_RNT_SIZE").toPlainString(), true, false, null, null, null, null);//���X�����n
                setColumn(sheet, row, style6, 5, subTotMap.get("SLF_SIZE").toPlainString(), true, false, null, null, null, null);//�ۥέ��n
                setColumn(sheet, row, style9, 6, SUB_RNT_RT, true, false, null, null, null, null);//�X���v
                setColumn(sheet, row, style5, 7, subTotMap.get("BLD_PRK").toPlainString(), true, false, null, null, null, null);//�`����
                setColumn(sheet, row, style5, 8, subTotMap.get("RNT_PRK").toPlainString(), true, false, null, null, null, null);//�w�X������
                setColumn(sheet, row, style5, 9, subTotMap.get("AVL_PRK").toPlainString(), true, false, null, null, null, null);//�Ÿm����
                setColumn(sheet, row, style5, 10, subTotMap.get("SLF_PRK").toPlainString(), true, false, null, null, null, null);//�ۥΨ���
                setColumn(sheet, row, style5, 11, null, false, false, null, null, null, null);//�j�өʽ�_�ϰ�γ~
                setColumn(sheet, row, style5, 12, subTotMap.get("RNT_AMT").toPlainString(), true, false, null, null, null, null);//�`����
                setColumn(sheet, row, style5, 13, subTotMap.get("CUS_CNT").toPlainString(), true, false, null, null, null, null);//�Ȥ��
                setColumn(sheet, row, style5, 14, subTotMap.get("DIV_CNT").toPlainString(), true, false, null, null, null, null);//����
                setColumn(sheet, row, style5, 15, subTotMap.get("PART_CNT").toPlainString(), true, false, null, null, null, null);//�Ÿm�j����
                setColumn(sheet, row, style2, 16, null, false, false, null, null, null, null);//�޲z���
                setColumn(sheet, row, style2, 17, null, false, false, null, null, null, null);//�j�Ӹg��W��
                setColumn(sheet, row, style2, 18, null, false, false, null, null, null, null);//�j�өʽ�ϥ�����
                setColumn(sheet, row, style2, 19, null, false, false, null, null, null, null);//�j�өʽ�ӷ~����
            } else {
                setColumn(sheet, row, style3, 0, groupkey + MessageUtil.getMessage("EPA3_0050_UI_TOT2"), false, false, null, null, null,
                    null);//�s�զW��+�X�p
                setColumn(sheet, row, style2, 1, null, false, false, null, null, null, null);//�j�ӥγ~
                setColumn(sheet, row, style6, 2, subTotMap.get("BLD_SIZE").toPlainString(), true, false, null, null, null, null);//�`���n
                setColumn(sheet, row, style6, 3, subTotMap.get("RNT_SIZE").toPlainString(), true, false, null, null, null, null);//�w�X�����n
                setColumn(sheet, row, style6, 4, subTotMap.get("UN_RNT_SIZE").toPlainString(), true, false, null, null, null, null);//���X�����n
                setColumn(sheet, row, style6, 5, subTotMap.get("SLF_SIZE").toPlainString(), true, false, null, null, null, null);//�ۥέ��n
                setColumn(sheet, row, style9, 6, SUB_RNT_RT, true, false, null, null, null, null);//�X���v
                setColumn(sheet, row, style5, 7, subTotMap.get("BLD_PRK").toPlainString(), true, false, null, null, null, null);//�`����
                setColumn(sheet, row, style5, 8, subTotMap.get("RNT_PRK").toPlainString(), true, false, null, null, null, null);//�w�X������
                if (isNeedSub) {
                    setColumn(sheet, row, style5, 9, null, false, false, null, null, null, null);//�j�өʽ�
                    setColumn(sheet, row, style5, 10, subTotMap.get("RNT_AMT").toPlainString(), true, false, null, null, null, null);//�`����
                } else {
                    setColumn(sheet, row, style5, 9, subTotMap.get("AVL_PRK").toPlainString(), false, false, null, null, null, null);//�Ÿm����
                    setColumn(sheet, row, style5, 10, subTotMap.get("SLF_PRK").toPlainString(), false, false, null, null, null, null);//�ۥΨ���
                    setColumn(sheet, row, style5, 11, subTotMap.get("RNT_AMT").toPlainString(), true, false, null, null, null, null);//�`����
                }

            }
            beginRow++;
            groupMap1.clear();

        }
        //�X�p
        String tot_RNT_RT = theEP_A30040.getRentRate(totMap, "2", 3).toPlainString();//�p��X���v
        row = sheet.createRow(beginRow);
        if ("Y".equals(EXP_ALL)) {
            setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EPA3_0050_UI_TOT"), false, false, null, null, null, null);//�X�p
            setColumn(sheet, row, style8, 1, String.valueOf(rtnList.size()), true, false, null, null, null, null);//����
            setColumn(sheet, row, style6, 2, MapUtils.getString(totMap, "BLD_SIZE"), true, false, null, null, null, null);//�`���n
            setColumn(sheet, row, style6, 3, MapUtils.getString(totMap, "RNT_SIZE"), true, false, null, null, null, null);//�w�X�����n
            setColumn(sheet, row, style6, 4, MapUtils.getString(totMap, "UN_RNT_SIZE"), true, false, null, null, null, null);//���X�����n
            setColumn(sheet, row, style6, 5, MapUtils.getString(totMap, "SLF_SIZE"), true, false, null, null, null, null);//�ۥέ��n
            setColumn(sheet, row, style9, 6, tot_RNT_RT, true, false, null, null, null, null);//�X���v
            setColumn(sheet, row, style5, 7, MapUtils.getString(totMap, "BLD_PRK"), true, false, null, null, null, null);//�`����
            setColumn(sheet, row, style5, 8, MapUtils.getString(totMap, "RNT_PRK"), true, false, null, null, null, null);//�w�X������
            setColumn(sheet, row, style5, 9, MapUtils.getString(totMap, "AVL_PRK"), true, false, null, null, null, null);//�Ÿm����
            setColumn(sheet, row, style5, 10, MapUtils.getString(totMap, "SLF_PRK"), true, false, null, null, null, null);//�ۥΨ���
            setColumn(sheet, row, style4, 11, null, false, false, null, null, null, null);//�j�өʽ�_�ϰ�γ~
            setColumn(sheet, row, style5, 12, MapUtils.getString(totMap, "RNT_AMT"), true, false, null, null, null, null);//�`����
            setColumn(sheet, row, style5, 13, MapUtils.getString(totMap, "CUS_CNT"), true, false, null, null, null, null);//�Ȥ��
            setColumn(sheet, row, style5, 14, MapUtils.getString(totMap, "DIV_CNT"), true, false, null, null, null, null);// ����
            setColumn(sheet, row, style5, 15, MapUtils.getString(totMap, "PART_CNT"), true, false, null, null, null, null);//�Ÿm�j����
            setColumn(sheet, row, style2, 16, null, false, false, null, null, null, null);//�޲z���
            setColumn(sheet, row, style2, 17, null, false, false, null, null, null, null);//�j�Ӹg��W��
            setColumn(sheet, row, style2, 18, null, false, false, null, null, null, null);//�j�өʽ�ϥ�����
            setColumn(sheet, row, style2, 19, null, false, false, null, null, null, null);//�j�өʽ�ӷ~����          
        } else {
            if (isNeedSub) {
                setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EPA3_0050_UI_TOT"), false, false, null, null, null, null);//�X�p
                setColumn(sheet, row, style8, 1, String.valueOf(rtnList.size()), true, false, null, null, null, null);//����
                setColumn(sheet, row, style6, 2, MapUtils.getString(totMap, "BLD_SIZE"), true, false, null, null, null, null);//�`���n
                setColumn(sheet, row, style6, 3, MapUtils.getString(totMap, "RNT_SIZE"), true, false, null, null, null, null);//�w�X�����n
                setColumn(sheet, row, style6, 4, MapUtils.getString(totMap, "UN_RNT_SIZE"), true, false, null, null, null, null);//���X�����n
                setColumn(sheet, row, style6, 5, MapUtils.getString(totMap, "SLF_SIZE"), true, false, null, null, null, null);//�ۥέ��n
                setColumn(sheet, row, style9, 6, tot_RNT_RT, true, false, null, null, null, null);//�X���v
                setColumn(sheet, row, style5, 7, MapUtils.getString(totMap, "BLD_PRK"), true, false, null, null, null, null);//�`����
                setColumn(sheet, row, style5, 8, MapUtils.getString(totMap, "RNT_PRK"), true, false, null, null, null, null);//�w�X������
                setColumn(sheet, row, style4, 9, null, false, false, null, null, null, null);//�j�өʽ�
                setColumn(sheet, row, style5, 10, MapUtils.getString(totMap, "RNT_AMT"), true, false, null, null, null, null);//�`����
            } else {
                setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EPA3_0050_UI_TOT"), false, false, null, null, null, null);//�X�p
                setColumn(sheet, row, style8, 1, String.valueOf(rtnList.size()), true, false, null, null, null, null);//����
                setColumn(sheet, row, style6, 2, MapUtils.getString(totMap, "BLD_SIZE"), true, false, null, null, null, null);//�`���n
                setColumn(sheet, row, style6, 3, MapUtils.getString(totMap, "RNT_SIZE"), true, false, null, null, null, null);//�w�X�����n
                setColumn(sheet, row, style6, 4, MapUtils.getString(totMap, "UN_RNT_SIZE"), true, false, null, null, null, null);//���X�����n
                setColumn(sheet, row, style6, 5, MapUtils.getString(totMap, "SLF_SIZE"), true, false, null, null, null, null);//�ۥέ��n
                setColumn(sheet, row, style9, 6, tot_RNT_RT, true, false, null, null, null, null);//�X���v
                setColumn(sheet, row, style5, 7, MapUtils.getString(totMap, "BLD_PRK"), true, false, null, null, null, null);//�`����
                setColumn(sheet, row, style5, 8, MapUtils.getString(totMap, "RNT_PRK"), true, false, null, null, null, null);//�w�X������
                setColumn(sheet, row, style5, 9, MapUtils.getString(totMap, "AVL_PRK"), true, false, null, null, null, null);//�Ÿm����
                setColumn(sheet, row, style5, 10, MapUtils.getString(totMap, "SLF_PRK"), true, false, null, null, null, null);//�ۥΨ���
                setColumn(sheet, row, style5, 11, MapUtils.getString(totMap, "RNT_AMT"), true, false, null, null, null, null);//�`����
            }
        }

    }
}
