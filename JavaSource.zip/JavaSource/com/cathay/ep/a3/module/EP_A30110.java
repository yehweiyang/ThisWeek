package com.cathay.ep.a3.module;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �ҲզW�� �j�ӥ�����ӼҲ�
 * �Ҳ�ID    EP_A30110
 * ���n����    �j�ӥ�����ӼҲ�
 * </pre>
 * @author �¶i��
 * @since  2013/12/19
 */
@SuppressWarnings("unchecked")
public class EP_A30110 {
    private static final Logger log = Logger.getLogger(EP_A30110.class);

    private static final String SQL_queryListA_001 = "com.cathay.ep.a3.module.EP_A30110.SQL_queryListA_001";

    private static final String SQL_queryListA_002 = "com.cathay.ep.a3.module.EP_A30110.SQL_queryListA_002";

    private static final String SQL_queryListA_003 = "com.cathay.ep.a3.module.EP_A30110.SQL_queryListA_003";

    private static final String SQL_queryListA_004 = "com.cathay.ep.a3.module.EP_A30110.SQL_queryListA_004";

    /**
     * Ū���j���ܧ�������
     * @param reqMap
     * @return
     * @throws ModuleException
     * @throws SQLException
     */
    public List<Map> queryListA(Map reqMap) throws ModuleException, SQLException {

        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30110_MSG_001")); // �ǤJ�ѼƤ��o����
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30110_MSG_002")); // �ǤJ�����q�O���o���ŭ�!
        }

        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30110_MSG_003")); // �ǤJ�ץ�s�����o���ŭ�!
        }

        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);

        setLikeFieldIfNotNull(ds, reqMap, "BLD_CD");

        DBUtil.searchAndRetrieve(ds, SQL_queryListA_001);

        List<Map> rtnList = new ArrayList<Map>();

        EP_A10010 theEP_A10010 = new EP_A10010();
        while (ds.next()) {

            Map rtnMap = VOTool.dataSetToMap(ds);

            //�������
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            //�������
            rtnMap.put("DATA_TYPE_NM", FieldOptionList.getName("EP", "DATA_TYPE", MapUtils.getString(rtnMap, "DATA_TYPE")));
            //���O
            rtnMap.put("CURR_NM", FieldOptionList.getName("EP", "CURR", MapUtils.getString(rtnMap, "CURR")));
            //�޲z���
            rtnMap.put("CLC_DIV_NO_NM", theEP_A10010.getDivName(MapUtils.getString(rtnMap, "CLC_DIV_NO"), MapUtils.getString(rtnMap,
                "SUB_CPY_ID")));
            //�p�q���
            rtnMap.put("UNIT_NM", FieldOptionList.getName("EP", "UNIT", MapUtils.getString(rtnMap, "UNIT")));
            //�γ~�N�X
            rtnMap.put("BLD_USE_CD_NM", FieldOptionList.getName("EP", "BLD_USE_CD", MapUtils.getString(rtnMap, "BLD_USE_CD")));
            //�j�өʽ�_�ϰ�γ~�N�� 
            rtnMap.put("BLD_KD_1_NM", FieldOptionList.getName("EP", "BLD_KD_1", MapUtils.getString(rtnMap, "BLD_KD_1")));
            //�j�өʽ�_�ϥ������N�� 
            rtnMap.put("BLD_KD_2_NM", FieldOptionList.getName("EP", "BLD_KD_2", MapUtils.getString(rtnMap, "BLD_KD_2")));
            //�j�өʽ�_�ӷ~�����N��
            rtnMap.put("BLD_KD_3_NM", FieldOptionList.getName("EP", "BLD_KD_3", MapUtils.getString(rtnMap, "BLD_KD_3")));

            rtnList.add(rtnMap);
        }

        return rtnList;
    }

    /**
     * Ū���Ӽh�ܧ�������
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryListB(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30110_MSG_001")); // �ǤJ�ѼƤ��o����
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30110_MSG_002")); // �ǤJ�����q�O���o���ŭ�!
        }

        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30110_MSG_003")); // �ǤJ�ץ�s�����o���ŭ�!
        }

        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);

        setLikeFieldIfNotNull(ds, reqMap, "BLD_CD");

        DBUtil.searchAndRetrieve(ds, SQL_queryListA_002);

        List<Map> rtnList = new ArrayList<Map>();

        while (ds.next()) {

            Map rtnMap = VOTool.dataSetToMap(ds);

            //�������
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            //�������
            rtnMap.put("DATA_TYPE_NM", FieldOptionList.getName("EP", "DATA_TYPE", MapUtils.getString(rtnMap, "DATA_TYPE")));
            //�n�O�γ~
            rtnMap.put("FLD_TYPE_NM", FieldOptionList.getName("EP", "FLD_TYPE", MapUtils.getString(rtnMap, "FLD_TYPE")));

            rtnList.add(rtnMap);
        }

        return rtnList;
    }

    /**
     * Ū���ǧO�ܧ�������
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryListC(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30110_MSG_001")); // �ǤJ�ѼƤ��o����
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30110_MSG_002")); // �ǤJ�����q�O���o���ŭ�!
        }

        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30110_MSG_003")); // �ǤJ�ץ�s�����o���ŭ�!
        }

        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);

        setLikeFieldIfNotNull(ds, reqMap, "BLD_CD");

        DBUtil.searchAndRetrieve(ds, SQL_queryListA_003);

        List<Map> rtnList = new ArrayList<Map>();

        while (ds.next()) {

            Map rtnMap = VOTool.dataSetToMap(ds);

            //�������
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            //�������
            rtnMap.put("DATA_TYPE_NM", FieldOptionList.getName("EP", "DATA_TYPE", MapUtils.getString(rtnMap, "DATA_TYPE")));
            //�s�W����^�ǨϥΪ��p��������, ���o�u�ϥΪ��p�����v����:
            rtnMap.put("USE_TYPE_NM", FieldOptionList.getName("EP", "USE_TYPE", MapUtils.getString(rtnMap, "USE_TYPE")));
            //�s�W����^�Ǩϥγ��ʽ褤��, ���o�u�ϥγ��ʽ�v����:
            rtnMap.put("USE_KD_NM", FieldOptionList.getName("EP", "USE_KD", MapUtils.getString(rtnMap, "USE_KD")));
            //�վ�覡
            rtnMap.put("FLD_ADJ_NM", FieldOptionList.getName("EP", "FLD_ADJ", MapUtils.getString(rtnMap, "FLD_ADJ")));

            rtnList.add(rtnMap);
        }

        return rtnList;
    }

    /**
     * Ū�������ܧ�������
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryListD(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30110_MSG_001")); // �ǤJ�ѼƤ��o����
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30110_MSG_002")); // �ǤJ�����q�O���o���ŭ�!
        }

        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30110_MSG_003")); // �ǤJ�ץ�s�����o���ŭ�!
        }

        if (eie != null) {
            throw eie;
        }

        BatchQueryDataSet bqds = null;
        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            bqds.setField("APLY_NO", APLY_NO);
            setLikeFieldIfNotNull(bqds, reqMap, "BLD_CD");

            bqds.searchAndRetrieve(SQL_queryListA_004);

            int groupCount = 2000;//�C�妸�d��2000�����
            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            if (totalcount == 0) {
                throw new DataNotFoundException("�d�L���");
            }
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��

            List<Map> rtnList = new ArrayList<Map>();
            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map rtnMap = VOTool.dataSetToMap(bqds);

                    //�������
                    rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
                    //�������
                    rtnMap.put("DATA_TYPE_NM", FieldOptionList.getName("EP", "DATA_TYPE", MapUtils.getString(rtnMap, "DATA_TYPE")));
                    //�s�W����^�ǥX����������, ���o�u�X�������v����:
                    rtnMap.put("RNT_KIND_NM", FieldOptionList.getName("EP", "RNT_KIND", MapUtils.getString(rtnMap, "RNT_KIND")));
                    //�s�W����^�ǨϥΪ��p����, ���o�u�ϥΪ��p�v����:
                    rtnMap.put("USE_TYPE_NM", FieldOptionList.getName("EP", "USE_TYPE", MapUtils.getString(rtnMap, "USE_TYPE")));

                    rtnList.add(rtnMap);
                }
            }
            return rtnList;
        } catch (DBException dbe) {
            log.error("�d�ߥ���", dbe);
            throw new ModuleException(dbe);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            throw dnfe;
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            throw new ModuleException(e);
        } finally {
            try {
                if (bqds != null) {
                    bqds.close();//�����妸�d�߳s�u
                }
            } catch (DBException e) {
            }

        }

    }

    /**
     * �걵 ErrorInputException �T��
     * @param eie
     * @param msg
     * @return
     */
    private ErrorInputException getEieInstance(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(msg);

        return eie;
    }

    /**
     * �����Ȯɤ~��J field �� (�ҽk�d��)
     * @param ds
     * @param map
     * @param key
     */
    private void setLikeFieldIfNotNull(DataSet ds, Map map, String key) {

        String value = MapUtils.getString(map, key);

        StringBuilder sb = new StringBuilder();

        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, sb.append('%').append(value).append('%').toString());
        }
    }

}
