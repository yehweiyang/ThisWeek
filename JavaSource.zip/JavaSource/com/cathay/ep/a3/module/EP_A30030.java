package com.cathay.ep.a3.module;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.EmployeeDetail;
import com.cathay.common.hr.Permission;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.CathayZipUtils;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.vo.DTEPA101;
import com.cathay.ep.vo.DTEPB308;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.RptUtils;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE     Description Author
 * 2013/10/08   Created ������
 * 2018/03/05    2.0 ���     ����[
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �j�ӲM����@�Ҳ�
 * �Ҳ�ID     EP_A30030
 * ���n����    �j�ӲM����@�Ҳ�
 *</pre>
 * @author ù�ΫT
 * @since 2013-11-27
 */
@SuppressWarnings("unchecked")
public class EP_A30030 {

    private static final String SQL_queryList_001 = "com.cathay.ep.a3.module.EP_A30030.SQL_queryList_001";

    private static final String SQL_formatRent_001 = "com.cathay.ep.a3.module.EP_A30030.SQL_formatRent_001";

    private static final String[] BLD_USE_CDs = new String[] { "01", "02", "03" };

    /**
     * Ū���j�ӲM��
     * @param reqMap
     * @return �j�ӲM��
     * @throws ModuleException
     * @throws SQLException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException, SQLException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30030_ERRMSG_001"));//�j�Ӹ�Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30030_ERRMSG_002"));//�����q�O���o����
        }

        String USE_DIV_NO = MapUtils.getString(reqMap, "USE_DIV_NO");
        String CUS_NAME = MapUtils.getString(reqMap, "CUS_NAME");
        String MA_ROLE = MapUtils.getString(reqMap, "MA_ROLE");
        String MA_ID = MapUtils.getString(reqMap, "MA_ID");

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        setFieldIfExsits(reqMap, ds, "ARA_CD");//�ϰ�O mofidlied by i9300606 2013/12/26
        StringBuilder sb = new StringBuilder();
        setLikeFieldsIfExsits(reqMap, ds, "BLD_CD", sb);//�j�ӥN��
        setLikeFieldsIfExsits(reqMap, ds, "BLD_NAME", sb);//�j�ӦW��
        setLikeFieldsIfExsits(reqMap, ds, "BLD_ADDR", sb);//���W
        setFieldIfExsits(reqMap, ds, "BLD_KD_1");//�ϰ�γ~
        setFieldIfExsits(reqMap, ds, "BLD_USE_CD"); //�γ~
        setFieldIfExsits(reqMap, ds, "CLC_DIV_NO"); //�޲z���

        if (StringUtils.isNotEmpty(MA_ID)) {
            if ("1".equals(MA_ROLE)) {//�j�Ӹg��
                ds.setField("BLD_USR_ID", MA_ID);
            } else if ("2".equals(MA_ROLE)) {//�j�ӥD��
                ds.setField("DIRECTOR_ID", MA_ID);
            }
        }
        //�̨ϥγ��d��
        if (StringUtils.isNotEmpty(USE_DIV_NO)) {
            setFieldIfExsits(reqMap, ds, "USE_DIV_NO");
        }
        //�̫Ȥ�m�W�d��
        if (StringUtils.isNotEmpty(CUS_NAME)) {

            setLikeFieldsIfExsits(reqMap, ds, "CUS_NAME", sb);
        }
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);

        EP_A10010 theEP_A10010 = new EP_A10010();
        for (Map<String, Object> rtnMap : rtnList) {
            //���o�u�ϥΪ��p�v����:          
            String BLD_USE_NM = FieldOptionList.getName("EP", "BLD_USE_CD", MapUtils.getString(rtnMap, "BLD_USE_CD"));
            rtnMap.put("BLD_USE_NM", BLD_USE_NM);
            //���o�޲z��줤��
            rtnMap.put("CLC_DIV_NM", theEP_A10010.getDivName(MapUtils.getString(rtnMap, "CLC_DIV_NO"), MapUtils.getString(rtnMap,
                "SUB_CPY_ID")));
        }

        return rtnList;
    }

    /**
     * ���o�ϥγ��Ĥ@�h�M��
     * @param SUB_CPY_ID �����q�O
     * @return �ϥγ��Ĥ@�h�M��
     * @throws ModuleException
     */
    public List<Map> getDIV_1_List(String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30030_ERRMSG_002"));//�����q�O���o����
        }

        //���X���Ĥ@�h�M��
        String DIV_CD = "DIV_1_" + SUB_CPY_ID;//������

        //getFieldOptions�^�ǬOMap, ��spec�w�q�^��List<Map>, �ҥH�h�إ�List����H���^�Ǥ���
        List<Map> DIV_1_LIST = new ArrayList<Map>();
        DIV_1_LIST.add(FieldOptionList.getFieldOptions("EP", DIV_CD));

        //���o�|ñ���Ĥ@�h�M��
        return DIV_1_LIST;
    }

    /**
     * ���o�ϥγ��ĤG�h�M��
     * @param SUB_CPY_ID �����q�O
     * @param USE_DIV_NO_1 �ϥγ��Ĥ@�h
     * @param userID �ϥΪ�ID
     * @return �ϥγ��ĤG�h�M��
     * @throws Exception 
     */
    //TODO SUB_CPY_ID �S���Ψ�, SA�^�Яd��
    public List<Map> getDIV_2_List(String SUB_CPY_ID, String USE_DIV_NO_1, String userID) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isEmpty(USE_DIV_NO_1)) {
            eie = getErrorInputException(eie, "EP_A30030_ERRMSG_003");//�ϥγ��Ĥ@�h���o����
        }
        if (StringUtils.isEmpty(userID)) {
            eie = getErrorInputException(eie, "EP_A30030_ERRMSG_004");//�ϥΪ�ID���o����
        }
        if (eie != null) {
            throw eie;
        }

        //���X���ĤG�h�M�� (����/�ϳ�)
        Vector DIV_2 = new Permission().getAllUnitComboData(USE_DIV_NO_1, null, null, userID);
        String html_txt = DIV_2.get(1).toString().replace("selected", "");//�]��SAXBuilder�u����<></>�զX, �ҥH���N��selected�r��
        return removeSelection(getDivList(html_txt, "N"));//mofidlied by i9300606 2013/12/26
    }

    /**
     * ���o�ϥγ��ĤT�h�M��
     * @param SUB_CPY_ID �����q�O
     * @param USE_DIV_NO_1 �|ñ���Ĥ@�h
     * @param USE_DIV_NO_2 �|ñ���ĤG�h
     * @param userID �ϥΪ�ID
     * @return �|ñ���ĤT�h�M��
     * @throws Exception
     */
    //TODO SUB_CPY_ID �S���Ψ�, SA�^�Яd��
    public List<Map> getDIV_3_List(String SUB_CPY_ID, String USE_DIV_NO_1, String USE_DIV_NO_2, String userID) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isEmpty(USE_DIV_NO_1)) {
            eie = getErrorInputException(eie, "EP_A30030_ERRMSG_005");//�|ñ���Ĥ@�h���o����
        }
        if (StringUtils.isEmpty(USE_DIV_NO_2)) {
            eie = getErrorInputException(eie, "EP_A30030_ERRMSG_006");//�|ñ���ĤG�h���o����
        }
        if (StringUtils.isEmpty(userID)) {
            eie = getErrorInputException(eie, "EP_A30030_ERRMSG_004");//�ϥΪ�ID���o����
        }
        if (eie != null) {
            throw eie;
        }

        //���o�ϥγ��ĤT�h�M��
        Vector DIV_3 = new Permission().getAllUnitComboData(USE_DIV_NO_1, USE_DIV_NO_2, null, userID);//mofidlied by i9300606 2013/12/26
        //mofidlied by i9300606 2013/12/26
        String html_txt = DIV_3.get(2).toString().replace("selected", "");//�]��SAXBuilder�u����<></>�զX, �ҥH���N��selected�r��
        //mofidlied by i9300606 2013/12/26
        return removeSelection(getDivList(html_txt, "Y"));//�NDIV_3���X���N���γ��W�١A�g�JList<Map>���� 
    }

    /**
     * �s�W
     * @param updList �j�ӲM��
     * @param MA_ROLE ���@����
     * @param MA_ID ���@�H��
     * @param user �@�~�H��
     * @throws ModuleException
     * @throws SQLException
     */
    public void update(List<Map> updList, String MA_ROLE, String MA_ID, UserObject user, String SUB_CPY_ID) throws ModuleException,
            SQLException {
        ErrorInputException eie = null;
        if (updList == null || updList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30030_ERRMSG_007"));//�j�ӲM�椣�o����
        }
        if (StringUtils.isEmpty(MA_ROLE)) {
            eie = getErrorInputException(eie, "EP_A30030_ERRMSG_008");//���@���⤣�o����
        }
        if (StringUtils.isEmpty(MA_ID)) {
            eie = getErrorInputException(eie, "EP_A30030_ERRMSG_009");//���@�H�����o����
        }
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_A30030_ERRMSG_002");//�����q�O���o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_A30030_ERRMSG_010");//�@�~�H�����o����
        }
        if (eie != null) {
            throw eie;
        }

        //�v���B�z���ʤj�ӲM��
        String UPD_TIME = DATE.getDBTimeStamp();
        Timestamp UPD_TIMESTAMP = DATE.toTimestamp(UPD_TIME);
        String APLY_NO;
        EP_Z00030 ep_z00030 = new EP_Z00030();
        EP_B30010 eP_B30010 = new EP_B30010();
        EP_A10010 eP_A10010 = new EP_A10010();
        PersonnelData personnelData = new PersonnelData();
        String TRN_KIND = "EPA002";
        String EmpID = user.getEmpID();
        String DivNo = user.getDivNo();
        String EmpName = user.getEmpName();

        for (Map map : updList) {
            Map<String, Object> caseMap = new HashMap<String, Object>();
            caseMap.put("SUB_CPY_ID", SUB_CPY_ID);
            caseMap.put("BLD_CD", map.get("BLD_CD"));//�j�ӥN��
            caseMap.put("UPD_TRN_KIND", TRN_KIND);//�������
            caseMap.put("UPD_DATE", UPD_TIME);//�J�ɤ��
            caseMap.put("CHG_ID", EmpID); //����ID
            caseMap.put("CHG_DIV_NO", DivNo); //���ʳ��
            caseMap.put("CHG_NAME", EmpName); //���ʩm�W

            //�s�W�߮ץ�
            APLY_NO = eP_B30010.insertForUpdMain(caseMap);
            DTEPA101 vo = VOTool.mapToVO(DTEPA101.class, map);

            vo.setCHG_DATE(UPD_TIMESTAMP);
            vo.setCHG_DIV_NO(DivNo);
            vo.setCHG_ID(EmpID);
            vo.setCHG_NAME(EmpName);
            vo.setAPLY_NO(APLY_NO);

            DTEPB308 voB308 = VOTool.mapToVO(DTEPB308.class, map);
            voB308.setDATA_TYPE("A");
            voB308.setAPLY_NO(APLY_NO);
            if ("1".equals(MA_ROLE)) {//�g��
                vo.setBLD_USR_ID(MA_ID);//�j�Ӹg��ID
                if (ep_z00030.isAccountSubCpy(SUB_CPY_ID)) {//���
                    EmployeeDetail emp = personnelData.getByEmployeeID2(MA_ID);
                    vo.setBLD_USR_NAME(emp.getName()); //�j�Ӹg��W��
                } else {//�D���
                    vo.setBLD_USR_NAME(FieldOptionList.getName("EP", "AGT_ID_" + SUB_CPY_ID, MA_ID));
                }
            } else if ("2".equals(MA_ROLE)) { //�j�ӥD��
                vo.setDIRECTOR_ID(MA_ID);//�j�ӥD��ID
            }
            //��X���ʬ���
            eP_A10010.update(voB308);

            //��s�j�Ӹ��
            eP_A10010.updateDTEPA101(vo, UPD_TIME, APLY_NO, TRN_KIND);

        }
    }

    /**
     * �ӯ����p�榡�B�z
     * @param reqMap Map    
     *                  <pre>
     *                  SUB_CPY_ID = �����q�O
     *                  ARA_CD  = �ϰ�O
     *                  BLD_CD  = �j�ӥN��
     *                  BLD_ADDR  = ���W
     *                  BLD_NAME = �j�ӦW��
     *                  CUS_NAME = �Ȥ�W��
     *                  MA_ROLE = ���@����
     *                  MA_ID = ���@�H��
     *                  USE_DIV_NO = �ϥγ��
     *                  BLD_USE_CD  �γ~�N�X
     *                  BLD_KD_1    �j�өʽ�_�ϰ�γ~�N��
     *                  CLC_DIV_NO  �޲z���(�ӿ��O)
     *                  </pre>
     * @param user
     * @return rtnMap   Map �����C�L�Ѽ�
     * @throws SQLException 
     * @throws ModuleException 
     */
    public Map formatRent(Map reqMap, UserObject user) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "EP_A30030_ERRMSG_014");//�ϥΪ̸�T���o����
        }
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_A30030_ERRMSG_001");//�j�Ӹ�Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            throw getErrorInputException(eie, "EP_A30030_ERRMSG_002");//�����q�O���o����
        }
        /* 1.  �ˮֿ�J�ѼơG�L�C
         2.  �ܼƪ�l�ơG�L�C
         3.  �I�s�Ҳը��o���
         4.  �Y�d�L��Ƶ������`�A����ܪų���
         5.  �YPRINT_PAGE_BEG �L�ȡA PRINT_PAGE_BEG = 1*/
        //���o�j�Ӱ򥻸��
        List<Map> bldList = this.queryList(reqMap);

        StringBuilder sb = new StringBuilder();
        LocaleDisplay locale = new LocaleDisplay("EP", user);

        String CLC_DIV_NO = MapUtils.getString(reqMap, "CLC_DIV_NO");

        String RPT_TITLE = MessageUtil.getMessage("EP_A30030_MSG_011");//�ӯ����p�@����
        String RPT_NAME;
        boolean isExistCLC_DIV_NO = StringUtils.isNotBlank(CLC_DIV_NO);
        String CLC_DIV_USE_TITLE = "";
        if (isExistCLC_DIV_NO) {
            String CLC_DIV_NO_NAME = new EP_A10010().getDivName(CLC_DIV_NO, SUB_CPY_ID);
            RPT_NAME = sb.append(CLC_DIV_NO_NAME).append(RPT_TITLE).toString();//�ӯ����p�@����
            sb.setLength(0);
            CLC_DIV_USE_TITLE = MessageUtil.getMessage("EP_A30030_MSG_014", new Object[] { CLC_DIV_NO_NAME });//�ҤU�j�ө���
        } else {
            RPT_NAME = RPT_TITLE;
        }
        Map coverMap = new HashMap();
        coverMap.put("RPT_NAME", RPT_NAME);
        //���:�D��ؤ���ܲ�����
        coverMap.put("RPT_DIV", new EP_Z00030().isAccountSubCpy(SUB_CPY_ID) ? MessageUtil.getMessage("EP_A30030_MSG_013") : "");//���ʲ��޲z���s
        coverMap.put("RPT_YM", locale.formatDateym(DATE.today(), ""));
        coverMap.put("CLC_DIV_USE_TITLE", CLC_DIV_USE_TITLE);//�ҤU�j�ө���
        coverMap.put("USE_TITLE", MessageUtil.getMessage("EP_A30030_MSG_015"));//���٦U�γ~�j�Ӽƶq
        //���o�j�ӥγ~�ƶq
        Map qryMap = new HashMap();
        qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> useList = this.queryUseList(qryMap, "USE", sb);

        List<Map> clcDivUseList = null;
        //���o�޲z����ҤU�j�ӥγ~�M��
        if (isExistCLC_DIV_NO) {
            qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
            clcDivUseList = queryUseList(reqMap, "CLC_DIV_USE", sb);
        }

        //�v���j�ӳB�z�A���ͤ������e�P�ؿ���T
        List<Map> printBldList = new ArrayList<Map>();//�j�ӦC�L���
        List<Map> dirList = new ArrayList<Map>();//�ؿ����
        EP_A30040 theEP_A30040 = new EP_A30040();

        BigDecimal PRINT_PAGE_END = BigDecimal.ZERO;

        for (Map bldMap : bldList) {
            if (ArrayUtils.contains(BLD_USE_CDs, MapUtils.getString(bldMap, "BLD_USE_CD"))) {
                bldMap.put("PRINT_PAGE_BEG", PRINT_PAGE_END.add(BigDecimal.ONE));
                Map printMap = theEP_A30040.formatRent(bldMap, user);
                Map printMap_param = (Map) printMap.get("params");

                PRINT_PAGE_END = STRING.objToBigDecimal(printMap_param.get("PRINT_PAGE_END"), BigDecimal.ONE);

                Map dirMap = new HashMap();
                dirMap.put("BLD_CD", bldMap.get("BLD_CD"));
                dirMap.put("BLD_NAME", bldMap.get("BLD_NAME"));
                dirMap.put("BLD_ADDR", bldMap.get("BLD_ADDR"));
                dirMap.put("BLD_USE_NM", bldMap.get("BLD_USE_NM"));//�γ~
                dirMap.put("DIR", "DIR");
                BigDecimal PRINT_PAGE_BEG = STRING.objToBigDecimal(printMap_param.get("PRINT_PAGE_BEG"), BigDecimal.ONE);

                String PAGE;
                if (PRINT_PAGE_END.compareTo(PRINT_PAGE_BEG) != 0) {
                    PAGE = sb.append(PRINT_PAGE_BEG).append("-").append(PRINT_PAGE_END).toString();
                    sb.setLength(0);
                } else {
                    PAGE = PRINT_PAGE_BEG.toString();
                }
                dirMap.put("PAGE", PAGE);
                dirList.add(dirMap);
                printBldList.add(printMap);
            }
        }
        //�榡��LIST
        formateList(useList, locale);

        if (clcDivUseList != null && !clcDivUseList.isEmpty()) {
            formateList(clcDivUseList, locale);
        }

        formateList(dirList, locale);

        //�]�w�^�ǭ�
        Map rtnMap = new HashMap();
        rtnMap.put("COVER", coverMap);
        rtnMap.put("USE_LIST", useList);
        rtnMap.put("CLC_DIV_USE_LIST", clcDivUseList);
        rtnMap.put("DIR_LIST", dirList);
        rtnMap.put("BLD_LIST", printBldList);
        return rtnMap;
    }

    /**
     * �C�L�ӯ����p
     * @param reqMap
     * @param req
     * @param resp
     * @throws Exception
     */
    public void printRent(Map reqMap, RequestContext req, ResponseContext resp) throws Exception {
        //�̷Ӷ��ǲ���PDF�����A�J�㦨 �ӯ����p�@����
        //EP_A30030_01
        List<Map> printBldList = (List<Map>) reqMap.get("BLD_LIST");
        //�ʭ�
        Map coverMap = (Map) reqMap.get("COVER");
        coverMap.put("REPORT_ID", "EP_A30030_01");
        List<Map> coverList = new ArrayList<Map>();

        //�j�ӨϥβM��
        List<Map> useList = (List<Map>) reqMap.get("USE_LIST");
        if (useList != null && !useList.isEmpty()) {
            coverList.addAll(useList);
        }

        //���o�޲z����ҤU�j�ӨϥβM��
        List<Map> clcDivUseList = (List<Map>) reqMap.get("CLC_DIV_USE_LIST");
        if (clcDivUseList != null && !clcDivUseList.isEmpty()) {
            coverList.addAll(clcDivUseList);
        }

        //�j�ӥؿ�
        List<Map> dirList = (List<Map>) reqMap.get("DIR_LIST");
        if (dirList != null && !dirList.isEmpty()) {
            coverList.addAll(dirList);
        }

        //�U�j�Ӹ��
        int printBldListSize = printBldList.size();
        String PDF_BLD_COUNTstr = FieldOptionList.getName("EP", "BLD_BOOKS", "PDF_BLD_COUNT");
        int Times = NumberUtils.isDigits(PDF_BLD_COUNTstr) ? Integer.valueOf(PDF_BLD_COUNTstr) : 1;

        String reportIds[] = new String[Times];
        Map inputParams[][] = new Map[Times][];
        List inputDetailLists[][] = new List[Times][];
        reportIds[0] = "EP_A30030_01";//reportId
        inputParams[0] = new Map[] { coverMap };//report Param
        inputDetailLists[0] = new List[] { coverList };//report Detail
        boolean isOutput = false;

        List<String> pathPDFList = new ArrayList<String>();
        RptUtils theRptUtils = new RptUtils();
        for (int i = 0; i < printBldListSize; i++) {
            isOutput = false;
            int index = (i + 1) % Times;
            reportIds[index] = "EP_A30040_01";
            Map bldMap = printBldList.get(i);
            inputParams[index] = new Map[] { (Map) bldMap.get("params") };
            inputDetailLists[index] = new List[] { (List<Map>) bldMap.get("detail") };

            if (index == (Times - 1)) {
                isOutput = true;

                String tempFileFullPath = RptUtils.markTempFileFullPath();

                theRptUtils.createPDFFile(inputParams, inputDetailLists, tempFileFullPath, req);

                pathPDFList.add(tempFileFullPath);

            }
        }
        //�Y��ƥ�����X�A�̫��X
        if (!isOutput) {
            int lastPDF = printBldListSize % Times + 1;
            String lastreportIds[] = new String[lastPDF];
            Map lastinputParams[][] = new Map[lastPDF][];
            List lastinputDetailLists[][] = new List[lastPDF][];
            for (int i = 0; i < lastPDF; i++) {
                lastreportIds[i] = "EP_A30040_01";
                lastinputParams[i] = inputParams[i];
                lastinputDetailLists[i] = inputDetailLists[i];
            }

            String tempFileFullPath = RptUtils.markTempFileFullPath();

            theRptUtils.createPDFFile(lastinputParams, lastinputDetailLists, tempFileFullPath, req);

            //�ھ� RESP getOutputData  encryptTempFileFullPath ���o�ɮ׸��|
            pathPDFList.add(tempFileFullPath);
        }
        String zipFileNM = MapUtils.getString(coverMap, "RPT_NAME") + ".zip";
        File zipFilePathFile = RptUtils.createTempFile(MapUtils.getString(coverMap, "RPT_NAME") + ".zip");
        String zipFilePath = zipFilePathFile.getPath();
        CathayZipUtils.zipFile(pathPDFList.toArray(new String[] {}), zipFilePath);
        //�N�ɮ׸ѱK�^��
        RptUtils.cryptoDownloadParameterToResp(zipFileNM, zipFilePath, resp);

    }

    /**
     * �d�߸�Ƥ覡 like'%key%'
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setLikeFieldsIfExsits(Map reqMap, DataSet ds, String key, StringBuilder sb) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            sb.append('%').append(value).append('%');
            ds.setField(key, sb.toString());
            sb.setLength(0);
        }
    }

    /**
     * �d�߸�ƫ��A�� 'key'
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setFieldIfExsits(Map reqMap, DataSet ds, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * To remove the selection 'all' or dash.
     * Modified by i9300606
     * @param fieldOption
     * @return
     */
    private List<Map> removeSelection(List<Map> fieldOption) {
        Iterator<Map> it = fieldOption.iterator();

        while (it.hasNext()) {
            Map map = it.next();
            String DIV_NM = MapUtils.getString(map, "DIV_NM");
            if (StringUtils.isBlank(DIV_NM)) {
                it.remove();
            } else {
                DIV_NM = DIV_NM.trim();
                DIV_NM = DIV_NM.replaceAll("�@", "");

                if ("����".equals(DIV_NM)) {// Hardcode is the worst way, and to build a new selection set is better way.  
                    it.remove();
                } else if (DIV_NM.startsWith("--")) {
                    it.remove();
                }
            }
        }

        return fieldOption;
    }

    /**
     * LIST �榡��
     * @param List
     * @param locale
     */
    private void formateList(List<Map> List, LocaleDisplay locale) {
        for (Map map : List) {
            for (Object everyKey : map.keySet()) {
                Object obj = map.get(everyKey);
                if (obj instanceof BigDecimal) {
                    map.put(everyKey, locale.formatNumber(obj, 0, "0"));
                } else {
                    map.put(everyKey, obj.toString());
                }
            }
        }
    }

    /**
     * ���o�j�ӥγ~�ƶq
     * @param reqMap
     * @param type
     * @param sb
     * @return
     * @throws ModuleException
     */
    private List<Map> queryUseList(Map reqMap, String type, StringBuilder sb) throws ModuleException {
        //���o�j�ӥγ~�ƶq
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", reqMap.get("SUB_CPY_ID"));//�����q�O
        setFieldIfExsits(reqMap, ds, "ARA_CD");//�ϰ�O
        setLikeFieldsIfExsits(reqMap, ds, "BLD_CD", sb);//�j�ӥN��
        setLikeFieldsIfExsits(reqMap, ds, "BLD_NAME", sb);//�j�ӦW��
        setLikeFieldsIfExsits(reqMap, ds, "BLD_ADDR", sb);//���W
        setFieldIfExsits(reqMap, ds, "BLD_KD_1");//�ϰ�γ~
        setFieldIfExsits(reqMap, ds, "BLD_USE_CD"); //�γ~
        setFieldIfExsits(reqMap, ds, "CLC_DIV_NO"); //�޲z���

        String USE_DIV_NO = MapUtils.getString(reqMap, "USE_DIV_NO");
        String CUS_NAME = MapUtils.getString(reqMap, "CUS_NAME");
        String MA_ROLE = MapUtils.getString(reqMap, "MA_ROLE");
        String MA_ID = MapUtils.getString(reqMap, "MA_ID");
        if (StringUtils.isNotEmpty(MA_ID)) {
            if ("1".equals(MA_ROLE)) {//�j�Ӹg��
                ds.setField("BLD_USR_ID", MA_ID);
            } else if ("2".equals(MA_ROLE)) {//�j�ӥD��
                ds.setField("DIRECTOR_ID", MA_ID);
            }
        }
        //�̨ϥγ��d��
        if (StringUtils.isNotEmpty(USE_DIV_NO)) {
            setFieldIfExsits(reqMap, ds, "USE_DIV_NO");
        }
        //�̫Ȥ�m�W�d��
        if (StringUtils.isNotEmpty(CUS_NAME)) {

            setLikeFieldsIfExsits(reqMap, ds, "CUS_NAME", sb);
        }
        DBUtil.searchAndRetrieve(ds, SQL_formatRent_001);

        BigDecimal SUM_RNT_CNT = BigDecimal.ZERO;
        BigDecimal SUM_SLF_CNT = BigDecimal.ZERO;
        BigDecimal SUM_PAR_CNT = BigDecimal.ZERO;
        BigDecimal SUM_TOT_CNT = BigDecimal.ZERO;
        List<Map> useList = new ArrayList<Map>();
        while (ds.next()) {

            BigDecimal RNT_CNT = STRING.objToBigDecimal(ds.getField("RNT_CNT"), BigDecimal.ZERO);
            BigDecimal SLF_CNT = STRING.objToBigDecimal(ds.getField("SLF_CNT"), BigDecimal.ZERO);
            BigDecimal PAR_CNT = STRING.objToBigDecimal(ds.getField("PAR_CNT"), BigDecimal.ZERO);
            BigDecimal TOT_CNT = STRING.objToBigDecimal(ds.getField("TOT_CNT"), BigDecimal.ZERO);
            Map useMap = new HashMap();
            useMap.put("ARA_CD_NM", FieldOptionList.getName("EP", "ARA_CD", (String) ds.getField("ARA_CD")));
            useMap.put("RNT_CNT", RNT_CNT);
            useMap.put("SLF_CNT", SLF_CNT);
            useMap.put("PAR_CNT", PAR_CNT);
            useMap.put("TOT_CNT", TOT_CNT);
            useMap.put("USE", type);
            useList.add(useMap);
            SUM_RNT_CNT = SUM_RNT_CNT.add(RNT_CNT);
            SUM_SLF_CNT = SUM_SLF_CNT.add(SLF_CNT);
            SUM_PAR_CNT = SUM_PAR_CNT.add(PAR_CNT);
            SUM_TOT_CNT = SUM_TOT_CNT.add(TOT_CNT);

        }

        //���ͦX�p��
        Map totMap = new HashMap();
        totMap.put("ARA_CD_NM", MessageUtil.getMessage("EP_A30030_MSG_012"));//�X�p
        totMap.put("RNT_CNT", SUM_RNT_CNT);
        totMap.put("SLF_CNT", SUM_SLF_CNT);
        totMap.put("PAR_CNT", SUM_PAR_CNT);
        totMap.put("TOT_CNT", SUM_TOT_CNT);
        totMap.put("USE", type);
        useList.add(totMap);
        return useList;
    }

    /**
     * ���X���ĤG�h�M�� (����/�ϳ�)
     * @param html �����q�O
     * @param befDot �u���r�I�e��T
     * @return ���M��
     * @throws ModuleException
     * @throws IOException 
     * @throws JDOMException 
     */
    private List<Map> getDivList(String html, String befDot) throws ModuleException, JDOMException, IOException {
        //�ΤH�ƼҲը�����
        StringBuilder sb = new StringBuilder().append("<root>").append(html).append("</root>");

        Document doc = new SAXBuilder().build(new StringReader(sb.toString()));
        Element root = doc.getRootElement();
        List children = root.getChildren();
        List<Map> DIV_2_List = new ArrayList<Map>();
        String childValue;
        int comma;

        for (int i = 0; i < children.size(); i++) {
            Map<String, Object> dmap = new HashMap<String, Object>();
            Element child = (Element) children.get(i);
            childValue = child.getAttributeValue("value");
            comma = childValue.indexOf(',');

            //�^����,�����e����r mofidlied by i9300606 2013/12/26
            dmap.put("DIV_NO", childValue);
            if ("Y".equals(befDot)) {
                if (!(comma < 0)) {
                    dmap.put("USE_DIV_NO", childValue.substring(0, childValue.indexOf(',')));
                } else {
                    dmap.put("USE_DIV_NO", "");
                }
            } else {
                dmap.put("USE_DIV_NO", childValue);
            }

            dmap.put("DIV_NM", child.getText());
            DIV_2_List.add(dmap);
        }

        return DIV_2_List;
    }
}
