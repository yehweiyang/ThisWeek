package com.cathay.ep.a3.module;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.rpt.RptUtils;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * �ҲզW�� �s���h���d�߼Ҳ�
 * �Ҳ�ID    EP_A30070
 * ���n����    �s���h���d�߼Ҳ�
 * </pre>
 * @author �¶i��
 * @since  2014/1/16
 */
@SuppressWarnings("unchecked")
public class EP_A30070 {

    private static final String SQL_queryList_001 = "com.cathay.ep.a3.module.EP_A30070.SQL_queryList_001";

    private static final String SQL_deleteRentType_001 = "com.cathay.ep.a3.module.EP_A30070.SQL_deleteRentType_001";

    /**
     * Ū���s���h������
     * @param QRY_TYPE
     * @param SUB_CPY_ID
     * @param QRY_YM
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;
        String QRY_TYPE = MapUtils.getString(reqMap, "QRY_TYPE");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage(""));//�d�߱��󤣥i����
        } else {
            if (StringUtils.isBlank(QRY_TYPE)) {
                eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30070_MSG_001")); // �d�ߺ������o���ŭ�
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30070_MSG_002")); // �����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();

        ds.setField("QRY_TYPE", QRY_TYPE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        String QRY_YM = MapUtils.getString(reqMap, "QRY_YM");
        if (StringUtils.isNotBlank(QRY_YM)) {

            // STR_DT = QRY_YM�e�|�X + ��-��  + QRY_YM��G�X + ��-01��
            String STR_DT = new StringBuilder().append(QRY_YM.substring(0, 4)).append('-').append(QRY_YM.substring(4, 6)).append("-01")
                    .toString();

            // END_DT  = DATE.getMonthLastDate(STR_DT)
            String END_DT = DATE.getMonthLastDate(STR_DT);

            String STR_TIME = STR_DT + " 00:00:00.000000";
            String END_TIME = END_DT + " 23:59:59.999999";

            ds.setField("STR_DT", STR_DT);
            ds.setField("END_DT", END_DT);

            ds.setField("STR_TIME", STR_TIME);
            ds.setField("END_TIME", END_TIME);
        }

        String INPUT_NAME = MapUtils.getString(reqMap, "INPUT_NAME");
        if (StringUtils.isNotBlank(INPUT_NAME)) {
            StringBuilder sb = new StringBuilder();
            ds.setField("INPUT_NAME", sb.append("%").append(INPUT_NAME).append("%").toString());
        }

        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);

        List<Map> rtnList = new ArrayList<Map>();

        while (ds.next()) {

            Map rtnMap = VOTool.dataSetToMap(ds);

            //�]�w���ʺ���
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));

            if ("1".equals(QRY_TYPE)) {
                String respName = MapUtils.getString(rtnMap, "CRT_RESP_NAME");
                if (StringUtils.isNotBlank(respName)) {
                    rtnMap.put("BLD_USR_NAME", respName);
                }
            }
            String UPD_DATE = MapUtils.getString(rtnMap, "UPD_DATE");
            if (StringUtils.isBlank(UPD_DATE)) {
                String INPUT_DATE = MapUtils.getString(rtnMap, "INPUT_DATE");
                rtnMap.put("CHG_DATE", StringUtils.isNotBlank(INPUT_DATE) ? INPUT_DATE.substring(0, 10) : "");
            } else {
                rtnMap.put("CHG_DATE", UPD_DATE.substring(0, 10));
            }

            rtnList.add(rtnMap);
        }

        return rtnList;
    }

    /**
     * �簣�ǧO���ʩ��ӷs�h���O�X
     * @param updList
     * @param user
     * @throws ModuleException
     */
    public void deleteRentType(List<Map> updList, UserObject user, String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;

        if (updList == null) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30070_MSG_003")); //�ǧO���ʲM�椣�o���ŭ�
        }

        if (user == null) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_A30070_MSG_004")); // �@�~�H�����o���ŭ�
        }

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("MEP00020")); // �����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String empID = user.getEmpID();
        Timestamp currTime = DATE.currentTime();

        DataSet ds = Transaction.getDataSet();

        for (Map updMap : updList) {

            ds.clear();

            ds.setField("RNT_CHG_ID", empID);
            ds.setField("RNT_CHG_DATE", currTime);
            ds.setField("APLY_NO", updMap.get("APLY_NO"));
            ds.setField("APLY_SER_NO", updMap.get("APLY_SER_NO"));
            ds.setField("DATA_TYPE", updMap.get("DATA_TYPE"));
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_deleteRentType_001);
        }
    }

    /**
     * �ץXXLS�M��
     * @param rtnList �ץX�M��
     * @param RNT_TP �d�ߺ���
     * @param resp
     * @return 
     * @throws Exception 
     */
    public void exportXLS(List<Map> rtnList, String RNT_TP, ResponseContext resp) throws Exception {
        FileOutputStream fileOutputString = null;
        try {
            //�ɦW: �s���h��_�d�ߺ���_YYYMMDD.xls
            StringBuilder sb = new StringBuilder();
            sb.append(MessageUtil.getMessage("EP_A30070_MSG_005")).append("_"); //�s���h��
            sb.append(MessageUtil.getMessage("EP_A30070_MSG_006")).append("_"); //�d�ߺ���
            sb.append(DATE.toDate_yyyyMMdd(DATE.getDBDate()));
            sb.append(".xls");
            String fileName = sb.toString();
            sb.setLength(0);

            HSSFWorkbook workbook = new HSSFWorkbook();// �u�@��
            HSSFSheet sheet = workbook.createSheet(fileName);

            // �]�w���j�p
            getSheetColumnWidth(sheet);

            //�g�J���Ӹ��
            createworkbook(workbook, sheet, rtnList, RNT_TP);

            // ���ͼȦs��
            File downloadFile = RptUtils.createTempFile(fileName);

            // ��X excel �ɪ����|
            String path = downloadFile.getPath();
            fileOutputString = new FileOutputStream(path);
            workbook.write(fileOutputString);
            RptUtils.cryptoDownloadParameterToResp(fileName, downloadFile, resp);
        } finally {
            if (fileOutputString != null) {
                fileOutputString.close();
            }
        }

    }

    /**
     * �걵 ErrorInputException �T��
     * @param eie
     * @param msg
     * @return
     */
    private ErrorInputException getEieInstance(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(msg);

        return eie;
    }

    /**
     * �]�w���j�p
     * @param sheet
     */
    private void getSheetColumnWidth(HSSFSheet sheet) {
        sheet.setColumnWidth(0, 30 * 256);//�Ȥ�W��
        sheet.setColumnWidth(1, 20 * 256);//�����N��
        sheet.setColumnWidth(2, 10 * 256);//�Ǹ�
        sheet.setColumnWidth(3, 15 * 256);//�j�ӥN��
        sheet.setColumnWidth(4, 20 * 256);//�j�ӦW��
        sheet.setColumnWidth(5, 15 * 256);//�Ӽh
        sheet.setColumnWidth(6, 15 * 256);//�ǧO
        sheet.setColumnWidth(7, 15 * 256);//�������ʤ��
        sheet.setColumnWidth(8, 15 * 256);//�ǧO���n
        sheet.setColumnWidth(9, 15 * 256);//�j�Ӹg��W��
        sheet.setColumnWidth(10, 15 * 256);//�_����� 
        sheet.setColumnWidth(11, 15 * 256);//������� 
        sheet.setColumnWidth(12, 15 * 256);//�`�믲�� 
        sheet.setColumnWidth(13, 15 * 256);//���(���|)
        sheet.setColumnWidth(14, 20 * 256);//�ץ�s�� 
        sheet.setColumnWidth(15, 15 * 256);//���ʭ�] 
        sheet.setColumnWidth(16, 15 * 256);//��J�H��
        sheet.setColumnWidth(17, 15 * 256);// ���ʤ��

    }

    /**
     * �]�w���
     * @param workbook
     * @param sheet
     * @param rtnList
     * @param RNT_TP
     * @throws ModuleException
     */
    private void createworkbook(HSSFWorkbook workbook, HSSFSheet sheet, List<Map> rtnList, String RNT_TP) throws ModuleException {

        //�]�wSTYLE
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���"); //���Y
        HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���"); //�����Y
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���"); //���Ӥ�r
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���"); //���ӼƦr

        HSSFRow row;
        int beginRow = 0;
        int totalColumns = 18;

        //���D
        String RNT_TP_NM = FieldOptionList.getName("EP", "RNT_TP", RNT_TP);

        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style0, 0, MessageUtil.getMessage("EPA3_0070_UI_XLS_TITLE", new Object[] { RNT_TP_NM }), false, true,
            beginRow, beginRow, 0, totalColumns - 1); //�j��{RNT_TP_NM}����
        beginRow++;

        //���Y
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style1, 0, MessageUtil.getMessage("EPA3_0070_UI_CUS_NAME"), false, false, null, null, null, null); //�Ȥ�W��
        setColumn(sheet, row, style1, 1, MessageUtil.getMessage("EPA3_0070_UI_CRT_NO"), false, false, null, null, null, null); //�����N��
        setColumn(sheet, row, style1, 2, MessageUtil.getMessage("EPA3_0070_UI_NO"), false, false, null, null, null, null); //�Ǹ�
        setColumn(sheet, row, style1, 3, MessageUtil.getMessage("EPA3_0070_UI_BLD_CD"), false, false, null, null, null, null); //�j�ӥN��
        setColumn(sheet, row, style1, 4, MessageUtil.getMessage("EPA3_0070_UI_BLD_NAME"), false, false, null, null, null, null); //�j�ӦW��
        setColumn(sheet, row, style1, 5, MessageUtil.getMessage("EPA3_0070_UI_FLD_NO"), false, false, null, null, null, null); //�Ӽh
        setColumn(sheet, row, style1, 6, MessageUtil.getMessage("EPA3_0070_UI_ROOM_NO"), false, false, null, null, null, null); //�ǧO
        setColumn(sheet, row, style1, 7, MessageUtil.getMessage("EPA3_0070_UI_RNT_STR_DATE"), false, false, null, null, null, null); //�������ʤ��
        setColumn(sheet, row, style1, 8, MessageUtil.getMessage("EPA3_0070_UI_ROOM_SIZE"), false, false, null, null, null, null); //�ǧO���n
        setColumn(sheet, row, style1, 9, MessageUtil.getMessage("EPA3_0070_UI_BLD_USR_NAME"), false, false, null, null, null, null); //�j�Ӹg��W�� 
        setColumn(sheet, row, style1, 10, MessageUtil.getMessage("EPA3_0070_UI_RNT_SDATE"), false, false, null, null, null, null); //�_����� 
        setColumn(sheet, row, style1, 11, MessageUtil.getMessage("EPA3_0070_UI_RNT_EDATE"), false, false, null, null, null, null); //������� 
        setColumn(sheet, row, style1, 12, MessageUtil.getMessage("EPA3_0070_UI_RNT_AMT"), false, false, null, null, null, null); //�`�믲�� 
        setColumn(sheet, row, style1, 13, MessageUtil.getMessage("EPA3_0070_UI_FNL_AMT"), false, false, null, null, null, null); //���(���|)
        setColumn(sheet, row, style1, 14, MessageUtil.getMessage("EPA3_0070_UI_APLY_NO"), false, false, null, null, null, null); //�ץ�s��
        setColumn(sheet, row, style1, 15, MessageUtil.getMessage("EPA3_0070_UI_TRN_KIND_NM"), false, false, null, null, null, null); //���ʭ�]
        setColumn(sheet, row, style1, 16, MessageUtil.getMessage("EPA3_0070_UI_INPUT_NAME"), false, false, null, null, null, null); //��J�H��
        setColumn(sheet, row, style1, 17, MessageUtil.getMessage("EPA3_0070_UI_CHG_DATE"), false, false, null, null, null, null); //���ʤ��

        beginRow++;

        //���Ӹ��(�t�X�p,�s�դp�p)
        createDetail(beginRow, sheet, row, style2, style3, rtnList, totalColumns);

    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @return
     */
    private HSSFCellStyle createStyle(HSSFWorkbook workbook, int type, String font_type) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();

        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);

        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�j���Y
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            font.setFontHeightInPoints((short) 22); // �j�p         

        } else if (type == 1) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.BLACK.index);
            font.setColor(HSSFColor.BLACK.index);
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 3) {//���ӼƦr
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        }

        style.setFont(font);

        //�~��
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);

        return style;
    }

    /**
     *  �]�w���
     * @param sheet
     * @param bodyRow
     * @param style ���A
     * @param columnNumber ���ͲĴX��cell
     * @param content  ���
     * @param doCombine �O�_�ݦX���x�s��
     * @param firstRow
     * @param lastRow
     * @param firstCol
     * @param lastCol
     */
    private void setColumn(HSSFSheet sheet, HSSFRow bodyRow, HSSFCellStyle style, Integer columnNumber, String content, boolean isNumeric,
            boolean doCombine, Integer firstRow, Integer lastRow, Integer firstCol, Integer lastCol) {

        HSSFCell bodyCell;
        bodyCell = bodyRow.createCell(columnNumber);
        bodyCell.setCellStyle(style);

        if (doCombine) {
            for (int s = firstCol; s <= lastCol; s++) {
                bodyCell = bodyRow.createCell(s);
                bodyCell.setCellStyle(style);
            }

            //�X���x�s��
            CellRangeAddress range_inputCount = new CellRangeAddress(firstRow, lastRow, firstCol, lastCol);
            sheet.addMergedRegion(range_inputCount);

            bodyCell = bodyRow.getCell(firstCol);
        }

        if (isNumeric) {
            if (StringUtils.isNotBlank(content)) {
                bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                Double bodyText = new Double(content);
                bodyCell.setCellValue(bodyText);
            }
        } else {
            HSSFRichTextString text = new HSSFRichTextString(content);
            bodyCell.setCellValue(text);
        }
    }

    /**
     * �إߪ��椺�e
     * @param beginRow
     * @param sheet
     * @param row
     * @param style2
     * @param style3
     * @param rtnList ���Ӹ��
     * @param totalColumns �C�C���
     * @throws ModuleException
     */
    private void createDetail(int beginRow, HSSFSheet sheet, HSSFRow row, HSSFCellStyle style2, HSSFCellStyle style3, List<Map> rtnList,
            int totalColumns) throws ModuleException {

        BigDecimal TOT_ROOM_SIZE = BigDecimal.ZERO;

        //����
        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);

            //���Ӹ��
            row = sheet.createRow(beginRow);
            setColumn(sheet, row, style2, 0, MapUtils.getString(rtnMap, "CUS_NAME"), false, false, null, null, null, null);//�Ȥ�W��
            setColumn(sheet, row, style2, 1, MapUtils.getString(rtnMap, "CRT_NO"), false, false, null, null, null, null); //�����N��
            setColumn(sheet, row, style2, 2, MapUtils.getString(rtnMap, "CUS_NO"), false, false, null, null, null, null); //�Ǹ�
            setColumn(sheet, row, style2, 3, MapUtils.getString(rtnMap, "BLD_CD"), false, false, null, null, null, null);//�j�ӥN��
            setColumn(sheet, row, style2, 4, MapUtils.getString(rtnMap, "BLD_NAME"), false, false, null, null, null, null);//�j�ӦW��
            setColumn(sheet, row, style2, 5, MapUtils.getString(rtnMap, "FLD_NO"), false, false, null, null, null, null);//�Ӽh
            setColumn(sheet, row, style2, 6, MapUtils.getString(rtnMap, "ROOM_NO"), false, false, null, null, null, null); //�ǧO
            setColumn(sheet, row, style2, 7, MapUtils.getString(rtnMap, "RNT_STR_DATE"), false, false, null, null, null, null);//�������ʤ��
            setColumn(sheet, row, style3, 8, MapUtils.getString(rtnMap, "ROOM_SIZE"), true, false, null, null, null, null); //�ǧO���n
            setColumn(sheet, row, style2, 9, MapUtils.getString(rtnMap, "BLD_USR_NAME"), false, false, null, null, null, null); //�j�Ӹg��W��
            setColumn(sheet, row, style2, 10, MapUtils.getString(rtnMap, "RNT_STR_DATE"), false, false, null, null, null, null);//�_�����
            setColumn(sheet, row, style2, 11, MapUtils.getString(rtnMap, "RNT_END_DATE"), false, false, null, null, null, null);//�������
            setColumn(sheet, row, style3, 12, MapUtils.getString(rtnMap, "RNT_AMT"), true, false, null, null, null, null); // �`�믲�� 
            setColumn(sheet, row, style3, 13, MapUtils.getString(rtnMap, "FNL_AMT"), true, false, null, null, null, null); //���(���|)
            setColumn(sheet, row, style2, 14, MapUtils.getString(rtnMap, "APLY_NO"), false, false, null, null, null, null);//�ץ�s�� 
            setColumn(sheet, row, style2, 15, MapUtils.getString(rtnMap, "TRN_KIND_NM"), false, false, null, null, null, null); //���ʭ�] 
            setColumn(sheet, row, style2, 16, MapUtils.getString(rtnMap, "INPUT_NAME"), false, false, null, null, null, null); //��J�H�� 
            setColumn(sheet, row, style2, 17, MapUtils.getString(rtnMap, "CHG_DATE"), false, false, null, null, null, null); //���ʤ��

            beginRow++;

            //�X�p�p��
            TOT_ROOM_SIZE = TOT_ROOM_SIZE.add(obj2Big(rtnMap, "ROOM_SIZE", BigDecimal.ZERO));

        }

        //�X�p
        row = sheet.createRow(beginRow);
        for (int j = 0; j < totalColumns; j++) {
            if (j == 0) {
                setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EPA3_0050_UI_TOT"), false, false, null, null, null, null);//�X�p
            } else if (j == 8) {
                setColumn(sheet, row, style3, 8, TOT_ROOM_SIZE.toPlainString(), true, false, null, null, null, null);//�`���n�X�p��
            } else {
                setColumn(sheet, row, style2, j, null, false, false, null, null, null, null);//�®تŮ�
            }
        }

    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param map
     * @param key
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            } else {
                String str = o.toString();
                if (StringUtils.isNotBlank(str)) {
                    return new BigDecimal(str);
                } else {
                    return defaultValue;
                }
            }
        }
        return defaultValue;
    }

}
