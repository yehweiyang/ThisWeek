package com.cathay.ep.a3.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.Log;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.db.impl.DynamicBatchQueryDataSet;
import com.cathay.ep.h2.trx.EPH2_1000;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * 2018/02/22 modified:��إ[�����q�O
 * 
 * �ҲզW�� �Ÿm�Ӽh�d�߼Ҳ�
 * �Ҳ�ID    EP_A30020 
 * ���n����    �Ÿm�Ӽh�d�߼Ҳ�
 * </pre>
 * @author �¶i��
 * @since  2013/12/19
 * 
 * 2019/07/09 �t�XAPI�ק�method
 * 
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_A30020 {
	/** log */
    private static final Logger log = Logger.getLogger(EP_A30020.class);
	
    private static final String SQL_queryList_001 = "com.cathay.ep.a3.module.EP_A30020.SQL_queryList_001";
    
    private static final String SQL_queryList_002 = "com.cathay.ep.a3.module.EP_A30020.SQL_queryList_002";

    private XlsUtils xlsUtils;

    private static final String[] totalColumns = { "ROOM_SIZE" };

    /**
     * [20190610] Ū���Ÿm�Ӽh�M��
     * [20190709] �t�X API �R�� isAccountSubCpy, isRSV�Ѽ�
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        return queryList(reqMap, null);
    }

    /**
     * [20190722] Ū���Ÿm�Ӽh�M��(�X�R)
     * �t�XAPI�NBLD_LIST��X
     * @param reqMap
     * @param BLD_LIST
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap, List<String> BLD_LIST) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A30020_MSG_001")); // �ǤJ�ѼƤ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException("�ǤJ�����q�O���i����");
        }
        log.debug("reqMap: "+reqMap);

        //[20190709] �t�XAPI�N�P�_�Զi�Ҳ�
        boolean isAccountSubCpy = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);
        //[20190709] �t�XAPI�N�P�_�Զi�Ҳ�
        String QRY_RSV_KD = MapUtils.getString(reqMap, "QRY_RSV_KD");

        DataSet ds = Transaction.getDataSet();

        //[20190709] �S��JQRY_RSV_KD �h��setField
        if ("Y".equals(QRY_RSV_KD)) {
            ds.setField("RSV_KD_Y", "Y");
        } else if ("N".equals(QRY_RSV_KD)) {
            ds.setField("RSV_KD_N", "N");
        }

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setFieldIfNotNull(ds, reqMap, "BLD_CD");
        setLikeFieldIfNotNull(ds, reqMap, "BLD_NAME");
        setFieldIfNotNull(ds, reqMap, "ARA_CD");
        setLikeFieldIfNotNull(ds, reqMap, "BLD_ADDR");
        setFieldIfNotNull(ds, reqMap, "FLD_SIZE_S");
        setFieldIfNotNull(ds, reqMap, "FLD_SIZE_L");
        //[20190709] �ק��ܼƦW��  ROOM_SIZE_S -> ROOM_SIZE_LOW
        setFieldIfNotNull(ds, reqMap, "ROOM_SIZE_LOW");
        //[20190709] �ק��ܼƦW��  ROOM_SIZE_L -> ROOM_SIZE_HIGH
        setFieldIfNotNull(ds, reqMap, "ROOM_SIZE_HIGH");
        //[20190719] �s�W�d�����
        setFieldIfNotNull(ds, reqMap, "NET_SIZE_LOW");
        setFieldIfNotNull(ds, reqMap, "NET_SIZE_HIGH");
        //[20190610] �s�W�d�����
        setFieldIfNotNull(ds, reqMap, "CLC_DIV_NO");
        setLikeFieldIfNotNull(ds, reqMap, "BLD_USR_NAME");
        //[20190709] �s�W�d�����
        setFieldIfNotNull(ds, reqMap, "NET_SIZE_LOW");//�b���n�̤p��
        setFieldIfNotNull(ds, reqMap, "NET_SIZE_HIGH");//�b���n�̤j��
        setFieldIfNotNull(ds, reqMap, "BLD_KD_2");//�j�өʽ�
        setFieldIfNotNull(ds, reqMap, "BLD_USR_ID");//�j�Ӹg��
        setFieldIfNotNull(ds, reqMap, "AVG_AMT_LOW");//�����}���̧C��
        setFieldIfNotNull(ds, reqMap, "AVG_AMT_HIGH");//�����}���̰���
        setFieldIfNotNull(ds, reqMap, "CLR_AMT_LOW");//���������̧C��
        setFieldIfNotNull(ds, reqMap, "CLR_AMT_HIGH");//���������̰���
        setFieldIfNotNull(ds, reqMap, "TOWN");//�ϰ��F��
        //[20190719] �s�W�d�����
        if (BLD_LIST != null && !BLD_LIST.isEmpty()) {
            ds.setFieldValues("BLD_LIST", BLD_LIST);
        }

        if (isAccountSubCpy) {
            DBUtil.searchAndRetrieve(ds, SQL_queryList_002);
        } else {
            DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        }

        List<Map> rtnList = new ArrayList<Map>();
        BigDecimal countROOM_SIZE = BigDecimal.ZERO;

        while (ds.next()) {

            Map rtnMap = VOTool.dataSetToMap(ds);

            countROOM_SIZE = countROOM_SIZE.add(obj2Big(rtnMap, "ROOM_SIZE", BigDecimal.ZERO));
            //�ϥΪ��p
            rtnMap.put("USE_TYPE_NM", FieldOptionList.getName("EP", "USE_TYPE", MapUtils.getString(rtnMap, "USE_TYPE")));

            //�X�p-ROOM_SIZE
            rtnMap.put("countROOM_SIZE", countROOM_SIZE);

            if (isAccountSubCpy) {
                //[20190610] �z�LA106���L��ƧP�_�O�d���p
                String A106_ROOM_NO = MapUtils.getString(rtnMap, "A106_ROOM_NO");
                if (StringUtils.isNotBlank(A106_ROOM_NO)) {
                    rtnMap.put("IS_RSV", FieldOptionList.getName("EP", "QRY_RSV_KD", "Y"));
                }

                //[20190610] �O�d���������ഫ
                String RSV_KD = MapUtils.getString(rtnMap, "RSV_KD");
                if (StringUtils.isNotBlank(RSV_KD)) {
                    rtnMap.put("RSV_KD_NM", FieldOptionList.getName("EP", "RSV_KD", MapUtils.getString(rtnMap, "RSV_KD")));
                }
            }
            rtnList.add(rtnMap);
        }

        if (rtnList.isEmpty()) {
            throw new DataNotFoundException();
        }

        return rtnList;
    }

    /**
     * [20190611] �ھڤ����q�O�_����ةM�O�_�d�ߤw�O�d���X�R
     * �ץXxls
     * @param reqMap
     * @param resp
     * @param user
     * @param isAccountSubCpy
     * @param isRsv
     * @throws Exception
     */
    public void exportXLS(Map reqMap, ResponseContext resp, UserObject user) throws Exception {
        //[20190709] �R���ǤJ�Ѽ�,��reqMap����
        List<Map> rtnList = this.queryList(reqMap);
        StringBuffer sb = getSqlStr(rtnList.size());

        xlsUtils = new XlsUtils(MapUtils.getString(reqMap, "fileName"), 100, 10, resp);
        // �Y�O�����ץX�ϥ� BatchQueryDataSet �H�קK�W�L2000��
        BatchQueryDataSet q = new BatchQueryDataSet();
        q.setDataSet(Transaction.getDataSet());
        DataSet ds = new DynamicBatchQueryDataSet(q);
        BatchQueryDataSet bqds = ((BatchQueryDataSet) ds);
        String gridJSON = MapUtils.getString(reqMap, "gridJSON");
        int i = 0;
        try {
            LocaleDisplay locale = new LocaleDisplay("EP", user);
            bqds.searchAndRetrieve(sb.toString());
            if (xlsUtils != null) {
                Map<String, Object> dataTotalMap = new HashMap<String, Object>();
                // �X�p�]�w(�W��)+(���) 
                dataTotalMap.put("totalTitle", "�X�p");
                dataTotalMap.put("totalColumns", totalColumns);
                xlsUtils.initBatchExportSetting(gridJSON, 1, dataTotalMap);
                while (xlsUtils.fetchData(bqds)) {
                    while (xlsUtils.next(bqds)) {
                        Map dataMap = xlsUtils.getCurrentMap();
                        Map rtnMap = (Map) rtnList.get(i);
                        String BLD_END_DATE = MapUtils.getString(rtnMap, "BLD_END_DATE");
                        rtnMap.put("BLD_END_DATE",
                            StringUtils.isNotBlank(BLD_END_DATE) ? locale.formatDate(Date.valueOf(BLD_END_DATE), "/", "") : "");
                        dataMap.putAll(rtnMap);
                        i++;
                        xlsUtils.batchCreateXls();
                    }
                }
            }
        } finally {
            if (bqds != null) {
                bqds.close();
            }
        }
    }

    /**
     * �ץX���Ŷ��]�w
     * @param count
     * @return
     */
    private StringBuffer getSqlStr(int count) {
        StringBuffer sb = new StringBuffer(
                "SELECT SUB_CPY_ID FROM (SELECT a.SUB_CPY_ID FROM DBEP.DTEPA101 a,DBEP.DTEPB102 b ) ORDER BY SUB_CPY_ID fetch first ");
        sb.append(String.valueOf(count)).append(" rows only with ur");

        return sb;
    }

    /**
     * map���XBigDecmial
     * @param map
     * @param key
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key);
        if (o instanceof BigDecimal) {
            return (BigDecimal) o;
        }
        String ostr = o.toString();
        if (NumberUtils.isNumber(ostr)) {
            return new BigDecimal(ostr);
        }

        return defaultValue;
    }

    /**
     * �����Ȯɤ~��J field ��
     * @param ds
     * @param map
     * @param key
     */
    private void setFieldIfNotNull(DataSet ds, Map map, String key) {

        String value = MapUtils.getString(map, key);

        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * �����Ȯɤ~��J field �� (�ҽk�d��)
     * @param ds
     * @param map
     * @param key
     */
    private void setLikeFieldIfNotNull(DataSet ds, Map map, String key) {

        String value = MapUtils.getString(map, key);

        StringBuilder sb = new StringBuilder();

        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, sb.append('%').append(value).append('%').toString());
        }
    }

    /**
     * [20190611] �B�zErrorInput�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getEie(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

}
