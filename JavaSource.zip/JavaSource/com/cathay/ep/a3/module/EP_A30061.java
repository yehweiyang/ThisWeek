package com.cathay.ep.a3.module;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.a1.module.EP_A10031;
import com.cathay.ep.a1.module.EP_A10041;
import com.cathay.ep.c1.module.EP_C1Z001;
import com.cathay.rpt.RptUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * DATE    Description Author
 * 2013/10/18  Created ������
 * 2018/03/01  ��ؽվ�   ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �j�ӫȤ᯲�����J�d�߼Ҳ�
 * �Ҳ�ID    EP_A30061
 * ���n����    �j�ӫȤ᯲�����J�d�߼Ҳ�
 * 
 * @author ����[
 * @since 2014-01-15
 */
@SuppressWarnings("unchecked")
public class EP_A30061 {
    private static final Logger log = Logger.getLogger(EP_A30061.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.a3.module.EP_A30061.SQL_queryList_001";

    /**
     * Ū���j�ӯ������J�M��
     * @param BLD_CD        �j�ӥN��
     * @param SUB_CPY_ID    �����q�O
     * @param RCV_YM        �����~��
     * @return  rtnList     �j�ӯ������J����
     * @throws Exception 
     */
    public List<Map> queryList(String BLD_CD, String SUB_CPY_ID, String RCV_YM) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A30061_MSG_001");// �j�ӥN�����������
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_A30061_MSG_002");// �����q�O���������
        }
        if (StringUtils.isBlank(RCV_YM)) {
            eie = getErrorInputException(eie, "EP_A30061_MSG_003");// �����~�묰�������
        }
        if (eie != null) {
            throw eie;
        }

        //�d�ߤj�ӯ������J
        Map<MultiKey, Map> rntMap = queryRentMap(BLD_CD, SUB_CPY_ID, RCV_YM);
        log.debug("RCV_YM:" + RCV_YM + ":" + rntMap);

        //�d�ߤj�ӫȤ�M��
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", BLD_CD);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);

        //�v���B�z�d�ߵ��G
        Iterator<Map> iList = rtnList.iterator();
        while (iList.hasNext()) {
            Map data = iList.next();

            //���o�j�ӫȤ᯲�����
            MultiKey key = new MultiKey(data.get("BLD_CD"), data.get("CRT_NO"), data.get("CUS_NO"));
            Map rentMap = rntMap.get(key);
            if (rentMap != null && !rentMap.isEmpty()) {
                data.putAll(rentMap);
                rntMap.remove(key);

                //�]�w�j�өʽ� �ϰ�γ~
                data.put("BLD_KD_1_NM", FieldOptionList.getName("EP", "BLD_KD_1", MapUtils.getString(data, "BLD_KD_1")));
                data.put("PAY_KIND_NM", FieldOptionList.getName("EP", "PAY_KIND", MapUtils.getString(data, "PAY_KIND")));
                data.put("RNT_TYPE_NM", FieldOptionList.getName("EP", "RNT_TYPE", MapUtils.getString(data, "RNT_TYPE")));

            } else {
                iList.remove();
            }
        }

        if (rntMap.size() > 0) {
            //�d�ߤj�ӦW��
            String[] RNT_TYPEs = new String[] { "1", "2", "6" };
            EP_A10031 theEP_A10031 = new EP_A10031();
            EP_A10041 theEP_A10041 = new EP_A10041();

            for (MultiKey key : rntMap.keySet()) {
                Map data = rntMap.get(key);
                data.put("SUB_CPY_ID", SUB_CPY_ID);
                //��X�ǧO�����w�g�U���v�ɪ��Ȥ᯲�����Ӹ��
                String RNT_TYPE = MapUtils.getString(data, "RNT_TYPE");
                if (ArrayUtils.contains(RNT_TYPEs, RNT_TYPE)) {//�Ӽh�ǧO
                    try {
                        Map logData = theEP_A10031.queryLogData(data);
                        data.put("FLD_NO", logData.get("FLD_NO"));
                        data.put("ROOM_NO", logData.get("ROOM_NO"));
                    } catch (DataNotFoundException dnfe) {
                        log.error("�d�L��Ƶ������`");
                    }
                } else if ("3".equals(RNT_TYPE) || "9".equals(RNT_TYPE)) {//����
                    try {
                        Map logList = theEP_A10041.queryLogData(data);
                        data.put("PRK_NO", logList.get("PRK_NO"));
                    } catch (DataNotFoundException e) {
                        log.error("�d�L��Ƶ������`");
                    }
                }
                rtnList.add(data);
            }
        }

        return rtnList;

    }

    /**
     * Ū���j�ӯ������J
     * @param BLD_CD        �j�ӥN��
     * @param SUB_CPY_ID    �����q�O
     * @param RCV_YM        �����~��
     * @param type          �d������(1:����;2:���~�֭p)
     * @return  rtnMap      �j�ӫȤ᯲�����J
     * @throws ModuleException
     */
    private Map<MultiKey, Map> queryRentMap(String BLD_CD, String SUB_CPY_ID, String RCV_YM) throws ModuleException {

        StringBuilder sb = new StringBuilder();
        String RCV_YM_S = sb.append(RCV_YM.substring(0, 4)).append("01").toString();
        sb.setLength(0);
        EP_C1Z001 theEP_C1Z001 = new EP_C1Z001();
        List<Map> rtnList = theEP_C1Z001.queryRNTAmt(RCV_YM_S, RCV_YM, BLD_CD, null, null, null, SUB_CPY_ID);

        Map<MultiKey, Map> rentMap = new HashMap<MultiKey, Map>();

        for (Map rtnMap : rtnList) {
            //�������J�b�B = �������J(�L�ȵ��s) - �w�����J(�L�ȵ��s) + ��b�`���B(�L�ȵ��s)
            BigDecimal NET_SAL_AMT = getBigDecimal(rtnMap.get("SAL_AMT"), BigDecimal.ZERO).subtract(
                getBigDecimal(rtnMap.get("PRP_AMT"), BigDecimal.ZERO)).add(getBigDecimal(rtnMap.get("TRA_PRP_AMT"), BigDecimal.ZERO))
                    .subtract(getBigDecimal(rtnMap.get("RJT_RNT_AMT"), BigDecimal.ZERO));

            //�ֿn�b�B = �ֿn�������J(�L�ȵ��s) �V �ֿn�w�����J(�L�ȵ��s) + �ֿn��b�`���B(�L�ȵ��s) �V �ֿn�P�f�h�^(�L�ȵ��s)
            BigDecimal SUM_NET_AMT = getBigDecimal(rtnMap.get("SUM_SAL_AMT"), BigDecimal.ZERO).subtract(
                getBigDecimal(rtnMap.get("SUM_PRP_AMT"), BigDecimal.ZERO)).add(
                getBigDecimal(rtnMap.get("SUM_TRA_PRP_AMT"), BigDecimal.ZERO)).subtract(
                getBigDecimal(rtnMap.get("SUM_RJT_RNT_AMT"), BigDecimal.ZERO));

            rtnMap.put("NET_SAL_AMT", NET_SAL_AMT);
            rtnMap.put("SUM_NET_AMT", SUM_NET_AMT);

            //�ӯ��O����
            rtnMap.put("RNT_TYPE_NM", FieldOptionList.getName("EP", "RNT_TYPE", MapUtils.getString(rtnMap, "RNT_TYPE")));
            //ú�ں���
            rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EP", "PAY_KIND", MapUtils.getString(rtnMap, "PAY_KIND")));
            MultiKey key = new MultiKey(rtnMap.get("BLD_CD"), rtnMap.get("CRT_NO"), rtnMap.get("CUS_NO"));
            rentMap.put(key, rtnMap);
        }

        return rentMap;
    }

    /**
     * �ץX
     * @param BLD_CD        �j�ӥN��
     * @param SUB_CPY_ID    �����q�O
     * @param RCV_YM        �����~��
     * @param reqMap        �ץX���
     * @param resp
     * @throws Exception
     */
    public List<Map> export(String BLD_CD, String SUB_CPY_ID, String RCV_YM, Map reqMap, ResponseContext resp) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A30061_MSG_001");// �j�ӥN�����������
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_A30061_MSG_002");// �����q�O���������
        }
        if (StringUtils.isBlank(RCV_YM)) {
            eie = getErrorInputException(eie, "EP_A30061_MSG_003");// �����~�묰�������
        }
        if (eie != null) {
            throw eie;
        }

        FileOutputStream fileOutputString = null;
        try {
            //���o�j�ӦW��
            Map temp = new HashMap();
            temp.put("SUB_CPY_ID", SUB_CPY_ID);
            temp.put("BLD_CD", BLD_CD);
            String BLD_NAME = MapUtils.getString(new EP_A10010().queryMap(temp), "BLD_NAME");

            String fileName = MapUtils.getString(reqMap, "fileName");

            List<Map> dataList = this.queryList(BLD_CD, SUB_CPY_ID, RCV_YM);

            HSSFWorkbook workbook = new HSSFWorkbook();// �u�@��
            HSSFSheet sheet = workbook.createSheet(fileName);

            // �]�w���j�p
            getSheetColumnWidth(sheet);

            //�g�J���Ӹ��
            createworkbook(workbook, sheet, dataList, BLD_NAME);

            // ���ͼȦs��
            File downloadFile = RptUtils.createTempFile(fileName);

            // ��X excel �ɪ����|
            String path = downloadFile.getPath();
            fileOutputString = new FileOutputStream(path);
            workbook.write(fileOutputString);
            RptUtils.cryptoDownloadParameterToResp(fileName, downloadFile, resp);
            return dataList;
        } finally {
            if (fileOutputString != null) {
                fileOutputString.close();
            }
        }

    }

    /**
     * �]�w���j�p
     * @param sheet
     */
    private void getSheetColumnWidth(HSSFSheet sheet) {
        sheet.setColumnWidth(0, 20 * 256);
        sheet.setColumnWidth(1, 12 * 256);
        sheet.setColumnWidth(2, 50 * 256);
        sheet.setColumnWidth(3, 12 * 256);
        sheet.setColumnWidth(4, 12 * 256);
        sheet.setColumnWidth(5, 12 * 256);
        sheet.setColumnWidth(6, 12 * 256);
        sheet.setColumnWidth(7, 12 * 256);
        sheet.setColumnWidth(8, 12 * 256);
        sheet.setColumnWidth(9, 15 * 256);
        sheet.setColumnWidth(10, 15 * 256);
        sheet.setColumnWidth(11, 15 * 256);
        sheet.setColumnWidth(12, 15 * 256);
        sheet.setColumnWidth(13, 15 * 256);
        sheet.setColumnWidth(14, 15 * 256);
    }

    /**
     * �]�w���
     * @param workbook
     * @param sheet
     * @param isNeedSub
     * @param rtnList
     * @throws ModuleException
     */
    private void createworkbook(HSSFWorkbook workbook, HSSFSheet sheet, List<Map> rtnList, String BLD_NAME) throws ModuleException {

        //�]�wSTYLE
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���");//���Y
        HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���");//�����Y
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���");//���Ӥ�r
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���");//���ӼƦr

        HSSFRow row;
        int beginRow = 0;
        int totalColumns = 15;

        //���D
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style0, 0, BLD_NAME + MessageUtil.getMessage("EP_A30061_MSG_004")/*�������J���Ӫ�*/, false, true, beginRow,
            beginRow, 0, totalColumns - 1);//�j�ӨϥΪ��p�έp
        beginRow++;

        //���Y
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style1, 0, MessageUtil.getMessage("EPA3_0061_UI_CRT_NO"), false, false, null, null, null, null);//�����N��
        setColumn(sheet, row, style1, 1, MessageUtil.getMessage("EPA3_0061_UI_CUS_NO"), false, false, null, null, null, null);//�Ȥ�Ǹ�
        setColumn(sheet, row, style1, 2, MessageUtil.getMessage("EPA3_0061_UI_CUS_NAME"), false, false, null, null, null, null);//�Ȥ�W��
        setColumn(sheet, row, style1, 3, MessageUtil.getMessage("EPA3_0061_UI_PAY_KIND_NM"), false, false, null, null, null, null);//ú�ں���
        setColumn(sheet, row, style1, 4, MessageUtil.getMessage("EPA3_0061_UI_RNT_TYPE"), false, false, null, null, null, null);//�ӯ��O
        setColumn(sheet, row, style1, 5, MessageUtil.getMessage("EPA3_0061_UI_RNT_TYPE_NM"), false, false, null, null, null, null);//�ӯ��O
        setColumn(sheet, row, style1, 6, MessageUtil.getMessage("EPA3_0061_UI_FLD_NO"), false, false, null, null, null, null);//�Ӽh
        setColumn(sheet, row, style1, 7, MessageUtil.getMessage("EPA3_0061_UI_ROOM_NO"), false, false, null, null, null, null);//�ǧO
        setColumn(sheet, row, style1, 8, MessageUtil.getMessage("EPA3_0061_UI_PRK_NO"), false, false, null, null, null, null);//����
        setColumn(sheet, row, style1, 9, MessageUtil.getMessage("EPA3_0061_UI_SAL_AMT"), false, false, null, null, null, null);//�������J
        setColumn(sheet, row, style1, 10, MessageUtil.getMessage("EPA3_0061_UI_PRP_AMT"), false, false, null, null, null, null);//�w�����J
        setColumn(sheet, row, style1, 11, MessageUtil.getMessage("EPA3_0061_UI_TRA_PRP_AMT"), false, false, null, null, null, null);//��b���B
        setColumn(sheet, row, style1, 12, MessageUtil.getMessage("EPA3_0061_UI_RJT_RNT_AMT"), false, false, null, null, null, null);//�P�f�h�^
        setColumn(sheet, row, style1, 13, MessageUtil.getMessage("EPA3_0061_UI_NET_SAL_AMT"), false, false, null, null, null, null);//�������J�b�B
        setColumn(sheet, row, style1, 14, MessageUtil.getMessage("EPA3_0061_UI_SUM_NET_AMT"), false, false, null, null, null, null);//�֭p�`�B

        beginRow++;

        //���Ӹ��(�t�X�p,�s�դp�p)
        createDetail(beginRow, sheet, row, style2, style3, rtnList, totalColumns);

    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @return
     */
    private HSSFCellStyle createStyle(HSSFWorkbook workbook, int type, String font_type) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();

        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);

        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�j���Y
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            font.setFontHeightInPoints((short) 22); // �j�p         
        } else if (type == 1) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.BLACK.index);
            font.setColor(HSSFColor.BLACK.index);
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 3) {//���ӼƦr
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        }

        style.setFont(font);

        //�~��
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);

        return style;
    }

    /**
     * �إߪ��椺�e
     * @param beginRow
     * @param sheet
     * @param row
     * @param style2
     * @param style3
     * @param isNeedSub �O�_�ݸs�դp�p
     * @param rtnList ���Ӹ��
     * @param totalColumns �C�C���
     * @throws ModuleException
     */
    private void createDetail(int beginRow, HSSFSheet sheet, HSSFRow row, HSSFCellStyle style2, HSSFCellStyle style3, List<Map> rtnList,
            int totalColumns) throws ModuleException {

        BigDecimal TOT_SAL_AMT = BigDecimal.ZERO;
        BigDecimal TOT_PRP_AMT = BigDecimal.ZERO;
        BigDecimal TOT_TRA_PRP_AMT = BigDecimal.ZERO;
        BigDecimal TOT_RJT_RNT_AMT = BigDecimal.ZERO;
        BigDecimal TOT_NET_SAL_AMT = BigDecimal.ZERO;
        BigDecimal TOT_SUM_NET_AMT = BigDecimal.ZERO;

        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);

            //���Ӹ��
            row = sheet.createRow(beginRow);
            setColumn(sheet, row, style2, 0, MapUtils.getString(rtnMap, "CRT_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 1, MapUtils.getString(rtnMap, "CUS_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 2, StringUtils.trim(MapUtils.getString(rtnMap, "CUS_NAME")), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 3, MapUtils.getString(rtnMap, "PAY_KIND_NM"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 4, MapUtils.getString(rtnMap, "RNT_TYPE"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 5, MapUtils.getString(rtnMap, "RNT_TYPE_NM"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 6, MapUtils.getString(rtnMap, "FLD_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 7, MapUtils.getString(rtnMap, "ROOM_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 8, MapUtils.getString(rtnMap, "PRK_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style3, 9, MapUtils.getString(rtnMap, "SAL_AMT"), true, false, null, null, null, null);
            setColumn(sheet, row, style3, 10, MapUtils.getString(rtnMap, "PRP_AMT"), true, false, null, null, null, null);
            setColumn(sheet, row, style3, 11, MapUtils.getString(rtnMap, "TRA_PRP_AMT"), true, false, null, null, null, null);
            setColumn(sheet, row, style3, 12, MapUtils.getString(rtnMap, "RJT_RNT_AMT"), true, false, null, null, null, null);
            setColumn(sheet, row, style3, 13, MapUtils.getString(rtnMap, "NET_SAL_AMT"), true, false, null, null, null, null);
            setColumn(sheet, row, style3, 14, MapUtils.getString(rtnMap, "SUM_NET_AMT"), true, false, null, null, null, null);
            beginRow++;

            //�X�p�p��
            TOT_SAL_AMT = TOT_SAL_AMT.add(getBigDecimal(rtnMap.get("SAL_AMT"), BigDecimal.ZERO));
            TOT_PRP_AMT = TOT_PRP_AMT.add(getBigDecimal(rtnMap.get("PRP_AMT"), BigDecimal.ZERO));
            TOT_TRA_PRP_AMT = TOT_TRA_PRP_AMT.add(getBigDecimal(rtnMap.get("TRA_PRP_AMT"), BigDecimal.ZERO));
            TOT_RJT_RNT_AMT = TOT_NET_SAL_AMT.add(getBigDecimal(rtnMap.get("RJT_RNT_AMT"), BigDecimal.ZERO));
            TOT_NET_SAL_AMT = TOT_NET_SAL_AMT.add(getBigDecimal(rtnMap.get("NET_SAL_AMT"), BigDecimal.ZERO));
            TOT_SUM_NET_AMT = TOT_SUM_NET_AMT.add(getBigDecimal(rtnMap.get("SUM_NET_AMT"), BigDecimal.ZERO));

        }

        //�X�p
        row = sheet.createRow(beginRow);
        for (int j = 0; j < totalColumns; j++) {
            if (j == 0) {
                setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EPA3_0050_UI_TOT"), false, false, null, null, null, null);//�X�p
            } else if (j == 9) {
                setColumn(sheet, row, style3, 9, TOT_SAL_AMT.toPlainString(), true, false, null, null, null, null);
            } else if (j == 10) {
                setColumn(sheet, row, style3, 10, TOT_PRP_AMT.toPlainString(), true, false, null, null, null, null);
            } else if (j == 11) {
                setColumn(sheet, row, style3, 11, TOT_TRA_PRP_AMT.toPlainString(), true, false, null, null, null, null);
            } else if (j == 12) {
                setColumn(sheet, row, style3, 12, TOT_RJT_RNT_AMT.toPlainString(), true, false, null, null, null, null);
            } else if (j == 13) {
                setColumn(sheet, row, style3, 13, TOT_NET_SAL_AMT.toPlainString(), true, false, null, null, null, null);
            } else if (j == 14) {
                setColumn(sheet, row, style3, 14, TOT_SUM_NET_AMT.toPlainString(), true, false, null, null, null, null);
            } else {
                setColumn(sheet, row, style2, j, null, false, false, null, null, null, null);//�®تŮ�
            }
        }

    }

    /**
     *  �]�w���
     * @param sheet
     * @param bodyRow
     * @param style ���A
     * @param columnNumber ���ͲĴX��cell
     * @param content  ���
     * @param isNumeric �O�_���Ʀr���
     * @param doCombine �O�_�ݦX���x�s��
     * @param firstRow
     * @param lastRow
     * @param firstCol
     * @param lastCol
     */
    private void setColumn(HSSFSheet sheet, HSSFRow bodyRow, HSSFCellStyle style, Integer columnNumber, String content, boolean isNumeric,
            boolean doCombine, Integer firstRow, Integer lastRow, Integer firstCol, Integer lastCol) {

        HSSFCell bodyCell;
        bodyCell = bodyRow.createCell(columnNumber);
        bodyCell.setCellStyle(style);

        if (doCombine) {
            for (int s = firstCol; s <= lastCol; s++) {
                bodyCell = bodyRow.createCell(s);
                bodyCell.setCellStyle(style);
            }

            //�X���x�s��
            CellRangeAddress range_inputCount = new CellRangeAddress(firstRow, lastRow, firstCol, lastCol);
            sheet.addMergedRegion(range_inputCount);

            bodyCell = bodyRow.getCell(firstCol);
        }

        if (isNumeric) {
            if (StringUtils.isNotBlank(content)) {
                bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                Double bodyText = new Double(content);
                bodyCell.setCellValue(bodyText);
            }
        } else {
            HSSFRichTextString text = new HSSFRichTextString(content);
            bodyCell.setCellValue(text);
        }
    }

    /**
     * ��wEIE����
     * 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * �૬�A�M���w�]
     * 
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

}
