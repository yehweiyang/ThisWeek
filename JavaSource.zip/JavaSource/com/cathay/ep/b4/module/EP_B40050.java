package com.cathay.ep.b4.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.db.impl.DynamicBatchQueryDataSet;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE Description Author
 * 2013/11/25  Created ���կ�
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �s���h�����Ӻ��@�Ҳ�
 * �Ҳ�ID    EP_B40050
 * ���n����    �s���h�����Ӻ��@�Ҳ�
 * </pre>
 * @author �x�Ԫ�
 * @since 2013/12/31
 */
@SuppressWarnings("unchecked")
public class EP_B40050 {
    private static final String SQL_queryList_001 = "com.cathay.ep.b4.module.EP_B40050.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.b4.module.EP_B40050.SQL_queryList_002";

    private static final String SQL_queryList_003 = "com.cathay.ep.b4.module.EP_B40050.SQL_queryList_003";

    /**
     * Ū���s���h������
     * @param SUB_CPY_ID  String  �����q�O
     * @param QRY_STR_DATE   DATE    �d�߰_��
     * @param QRY_END_DATE   DATE    �d�ߨ���
     * @return  rtnList List<Map>   �s���h������(�h��)
     */
    public List<Map> queryList(String SUB_CPY_ID, Date QRY_STR_DATE, Date QRY_END_DATE) throws ModuleException {
        //����
        //�s��: ��J��b�d�߰_���鶡
        //�h��: ��������b�d�߰_���鶡(�����]�t�t�q�s�����פ��)
        //�Ƨ�: �ѫe��TABLE UI�B�z
        //�ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_B40050_MSG_001");//�����q�O���o���ŭ�!
        }
        if (QRY_STR_DATE == null) {
            eie = getErrorInputException(eie, "EP_B40050_MSG_002");//�d�߰_�餣�o���ŭ�!
        }
        if (QRY_END_DATE == null) {
            eie = getErrorInputException(eie, "EP_B40050_MSG_003");//�d�ߨ��餣�o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("QRY_STR_DATE", QRY_STR_DATE);
        ds.setField("QRY_END_DATE", QRY_END_DATE);
        //���o�w�J�ɷs������
        List<Map> tmpList = new ArrayList<Map>();
        //�NtmpList1�[�J�^��tmpList��
        List<Map> tmpList1 = VOTool.findToMaps(ds, SQL_queryList_001, false);
        if (tmpList1 != null && !tmpList1.isEmpty()) {
            tmpList.addAll(tmpList1);
        }
        //���o�w���󥼤J�ɷs������
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("QRY_STR_DATE", QRY_STR_DATE);
        ds.setField("QRY_END_DATE", QRY_END_DATE);
        //�NtmpList2 �[�J�^��tmpList��
        List<Map> tmpList2 = VOTool.findToMaps(ds, SQL_queryList_002, false);
        if (tmpList2 != null && !tmpList2.isEmpty()) {
            tmpList.addAll(tmpList2);
        }
        //���o�h������(���ư��t�q�s��).
        //�ثe�Ȥ��Ҽ{�w���Ѭ�, �����B�z, ���e�פ����, �n�^LOG����(�Y�n�^��h�Ҽ{�妸��,���n�u�W�@�~)
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("QRY_STR_DATE", QRY_STR_DATE);
        ds.setField("QRY_END_DATE", QRY_END_DATE);
        List<Map> tmpList3 = VOTool.findToMaps(ds, SQL_queryList_003, false);
        if (tmpList3 != null && !tmpList3.isEmpty()) {
            tmpList.addAll(tmpList3);
        }
        if (tmpList.isEmpty()) {
            throw new ModuleException("EP_B40050_MSG_004");//�d�L����������
        }
        //�^�ǳB�z�ηs�W����^�ǲM�� 
        MultiKeyMap mKeyMap = new MultiKeyMap();
        List<Map> rtnList = new ArrayList<Map>();
        StringBuilder sb = new StringBuilder();        
        for (Map tmpMap : tmpList) {
            String KIND = MapUtils.getString(tmpMap, "KIND");
            String INPUT_DATE = MapUtils.getString(tmpMap, "INPUT_DATE");
            String CRT_NO = MapUtils.getString(tmpMap, "CRT_NO");
            String CUS_NO = MapUtils.getString(tmpMap, "CUS_NO");

            String ROOM_NO = MapUtils.getString(tmpMap, "ROOM_NO", "");
            String FLD_NO = this.removeLeftZero(MapUtils.getString(tmpMap, "FLD_NO", ""));

            String FNL_AMT = MapUtils.getString(tmpMap, "FNL_AMT", "");
            BigDecimal RNT_SIZE = (BigDecimal) MapUtils.getObject(tmpMap, "RNT_SIZE", BigDecimal.ZERO);
            
            boolean KIND_D;
            if (mKeyMap.containsKey(KIND, INPUT_DATE, CRT_NO, CUS_NO)) {
                Map group_map = (Map) mKeyMap.get(KIND, INPUT_DATE, CRT_NO, CUS_NO);
                //�̷ӬۦP��tmpMap.KIND�BtmpMap.INPUT_DATE�BtmpMap.CRT_NO�BtmpMap.CUS_NO���s��,
                // �v��tmpMap.RNT_SIZE �`�p
                BigDecimal SUB_TOTAL_RNT_SIZE = (BigDecimal) MapUtils.getObject(group_map, "SUB_TOTAL_RNT_SIZE", BigDecimal.ZERO);
                SUB_TOTAL_RNT_SIZE = SUB_TOTAL_RNT_SIZE.add(RNT_SIZE);
                group_map.put("SUB_TOTAL_RNT_SIZE", SUB_TOTAL_RNT_SIZE);                

                //EX: rtnMap.RM  = 14A,14B
                //rtnMap.FNL_TOT = rtnMap.FNL_AMT + ��,�� + �P�s�դU�@���}�l�v��tmpMap.FNL_AMT
                // �N���s��rtnMap�[�JrtnList��
                String FNL_TOT = MapUtils.getString(group_map, "FNL_TOT", "");
                group_map.put("FNL_TOT", sb.append(FNL_TOT).append(",").append(FNL_AMT).toString());
                sb.setLength(0);

                //rtnMap.RM = rtnMap.FLD_NO�h������ ��0�� + rtnMap.ROOM_NO + ��,�� + �P�s�դU�@���}�l�v  ��tmpMap.FLD_NO�h������ ��0�� + tmpMap.ROOM_NO     
                String RM = MapUtils.getString(group_map, "RM", "");
                group_map.put("RM", sb.append(RM).append(',').append(FLD_NO).append(ROOM_NO).toString());
                sb.setLength(0);
                //
                KIND_D = (Boolean) MapUtils.getObject(group_map, "KIND_D", false);
            } else {
                //�ۦP�s�դ��Ĥ@��tmpMap���
                //�ۦP��ƳB�z��u�ǥX�@��                
                String CASE_TYPE = MapUtils.getString(tmpMap, "CASE_TYPE", "");
                tmpMap.put("CASE_TYPE_NM", sb.append(CASE_TYPE).append(FieldOptionList.getName("EP", "CASE_TYPE", CASE_TYPE)).toString());
                sb.setLength(0);
                KIND_D = "D".equals(KIND);
                tmpMap.put("KIND_D", KIND_D);
                tmpMap.put("FNL_TOT", FNL_AMT);
                tmpMap.put("SUB_TOTAL_RNT_SIZE", RNT_SIZE);                
                tmpMap.put("RM", sb.append(FLD_NO).append(ROOM_NO).toString());
                sb.setLength(0);
                rtnList.add(tmpMap);
                mKeyMap.put(KIND, INPUT_DATE, CRT_NO, CUS_NO, tmpMap);
            }            
        }
        
        for (Map rtnMap : rtnList) {
            
            boolean KIND_D = (Boolean) MapUtils.getObject(rtnMap, "KIND_D", false);
            BigDecimal SUB_TOTAL_RNT_SIZE = (BigDecimal) MapUtils.getObject(rtnMap, "SUB_TOTAL_RNT_SIZE", BigDecimal.ZERO);
            if (KIND_D) {
                rtnMap.put("AREA", sb.append('(').append(SUB_TOTAL_RNT_SIZE).append(')').toString());// �NrtnMap.AREA�άA���A�_   EX: (60.4)
                sb.setLength(0);
            } else {
                rtnMap.put("AREA", SUB_TOTAL_RNT_SIZE);
            }            
        }
        
        return rtnList;

    }

    /**
     * �ץX�ɮ�
     * @param reqMap
     * @param resp
     * @throws Exception
     */
    public void export(Map reqMap, UserObject user, ResponseContext resp) throws Exception {
        List<Map> rtnList = this.queryList(MapUtils.getString(reqMap, "USER_CPY_ID"), Date.valueOf(MapUtils.getString(reqMap,
            "QRY_STR_DATE")), Date.valueOf(MapUtils.getString(reqMap, "QRY_END_DATE")));
        LocaleDisplay display = new LocaleDisplay("EP", user);
        StringBuffer sb = getSqlStr(rtnList.size());
        XlsUtils xlsUtils = new XlsUtils(MapUtils.getString(reqMap, "fileName"), 100, 10, resp);
        // �Y�O�����ץX�ϥ� BatchQueryDataSet �H�קK�W�L2000��
        BatchQueryDataSet q = new BatchQueryDataSet();
        q.setDataSet(Transaction.getDataSet());
        DataSet ds = new DynamicBatchQueryDataSet(q);
        BatchQueryDataSet bqds = ((BatchQueryDataSet) ds);
        String gridJSON = MapUtils.getString(reqMap, "gridJSON");
        int i = 0;

        try {
            bqds.searchAndRetrieve(sb.toString());
            if (xlsUtils != null) {

                xlsUtils.initBatchExportSetting(gridJSON, 1);
                while (xlsUtils.fetchData(bqds)) {
                    while (xlsUtils.next(bqds)) {
                        Map dataMap = xlsUtils.getCurrentMap();
                        Map map = (Map) rtnList.get(i);
                        map.put("INPUT_DATE", display.formatDate((Date) map.get("INPUT_DATE"), "", ""));
                        map.put("RNT_STR_DATE", display.formatDate((Date) map.get("RNT_STR_DATE"), "", ""));
                        map.put("RNT_END_DATE", display.formatDate((Date) map.get("RNT_END_DATE"), "", ""));
                        dataMap.putAll(map);
                        i++;
                        xlsUtils.batchCreateXls();
                    }
                }
            }
        } finally {
            if (bqds != null) {
                bqds.close();
            }
        }
    }

    /**
     * �ץX���Ŷ��]�w
     * @param count
     * @return
     */
    private StringBuffer getSqlStr(int count) {
        StringBuffer sb = new StringBuffer(
                "SELECT SUB_CPY_ID FROM (SELECT a.SUB_CPY_ID FROM DBEP.DTEPA101 a,DBEP.DTEPB102 b ) ORDER BY SUB_CPY_ID fetch first ");
        sb.append(String.valueOf(count)).append(" rows only with ur");

        return sb;
    }

    /**
     * �N�r�ꥪ�䪺0�h��
     * @param str
     * @return
     */
    private String removeLeftZero(String str) {
        if (StringUtils.isNotBlank(str)) {
            for (int i = 0; i < str.length(); i++) {
                if (!"0".equals(str.substring(i, i + 1))) {
                    return str.substring(i);
                }
            }
        }
        return "";
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

}
