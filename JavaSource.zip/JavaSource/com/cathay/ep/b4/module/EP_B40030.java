package com.cathay.ep.b4.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.STRING;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 *      DATE    Description Author
 *      2013/08/07  Created ���կ�
 *      
 *      �@�B  �{���\�෧�n�����G
 *      �ҲզW��    �ӯ�����޼Ҳ�
 *      �Ҳ�ID    EP_B40030
 *      ���n����    �ӯ�����޺��@�Ҳ�
 *      
 * </pre>
 * @author �x�Ԫ�
 * @since  2013-09-12
 */
@SuppressWarnings("unchecked")
public class EP_B40030 {
    //private static final String SQL_queryList_001 = "com.cathay.ep.b4.module.EP_B40030.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.b4.module.EP_B40030.SQL_queryList_002";

    private static final String SQL_queryList_003 = "com.cathay.ep.b4.module.EP_B40030.SQL_queryList_003";

    private static final String SQL_queryList_004 = "com.cathay.ep.b4.module.EP_B40030.SQL_queryList_004";

    /**
     * Ū���ӯ����ƲM��
     * @param SUB_CPY_ID String  �����q�O
     * @param ID         String  �ҥ󸹽X
     * @param CRT_STS    String  �������p
     * @param RENT_TYPE  String  �ӯ��O
     * @param CUS_NAME   String  �Ȥ�m�W
     * @param CRT_NO     String  �����N�� 
     * @param BLD_CD     String  �j�ӥN��
     * @return  rtnList List<Map>   �ӯ����ƲM��(�h��)
     */

    public List<Map> queryList(String SUB_CPY_ID, String ID, String CRT_STS, String RENT_TYPE, String CUS_NAME, String CRT_NO, String BLD_CD)
            throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        SUB_CPY_ID = STRING.fillZero(SUB_CPY_ID, 2);

        //�̶ǤJ����d�ߩӯ��ǧO�B����B�����Ωӯ�����
        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if (StringUtils.isNotBlank(ID)) {
            ds.setField("ID", ID);            
        } else if (StringUtils.isNotBlank(CUS_NAME)) {
            setFieldLike(ds, "CUS_NAME", CUS_NAME);
        } else if (StringUtils.isNotBlank(CRT_NO)) {
            setFieldLike(ds, "CRT_NO", CRT_NO);
        } else if (StringUtils.isNotBlank(BLD_CD)) {
            setFieldLike(ds, "BLD_CD", BLD_CD);
        }
        
        if ("1".equals(CRT_STS)) {
            //���ĥ�
            ds.setField("CRT_STS_1", 1);
        } else if ("2".equals(CRT_STS)) {
            //������
            ds.setField("CRT_STS_2", 4);
        }
        
        //�줽�ǤΦ��v
        if ("1".equals(RENT_TYPE)) {
            //�d�߫ǧOSQL
            return VOTool.findToMaps(ds, SQL_queryList_002);
        }
        if ("2".equals(RENT_TYPE)) {
            //�d�ߨ���SQL
            return VOTool.findToMaps(ds, SQL_queryList_003);
        }
        return VOTool.findToMaps(ds, SQL_queryList_004);

    }

    /**
     * Like �]�� 
     * @param ds
     * @param key
     * @param value
     */
    private void setFieldLike(DataSet ds, String key, String value) {
        ds.setField(key, new StringBuilder().append('%').append(value).append('%').toString());
    }
}
