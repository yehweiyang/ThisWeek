package com.cathay.ep.b4.module;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 *      DATE    Description Author
 *      2013/08/16  Created ���կ�
 *      
 *      �@�B  �{���\�෧�n�����G
 *      �ҲզW��    �ץ�߮׬d�ߺ��@�Ҳ�
 *      �Ҳ�ID    EP_B40010
 *      ���n����    �ץ�߮׬d�ߺ��@�Ҳ�
 *      
 * </pre>
 * @author �x�Ԫ�
 * @since  2013-09-12
 */
@SuppressWarnings("unchecked")
public class EP_B40010 {

    private static final String SQL_queryList_001 = "com.cathay.ep.b4.module.EP_B40010.SQL_queryList_001";

    /**
     * Ū���ץ�_�ܧ�����ɲM��
     * @param SUB_CPY_ID
     * @param reqMap Map
     *              <pre>
     *                  SUB_CPY_ID  String  �����q�O
     *                  APLY_STS = �ץ󪬪p
     *                  APLY_STR_DATE = �߮װ_��
     *                  APLY_END_DATE = �߮ר���
     *                  BLD_CD = �j�ӥN��
     *                  CRT_NO = �����N��
     *                  INPUT_DIV_NO = ��J���
     *                  INPUT_NAME = ��J�H��
     *                  REG_STR_DATE = �w���J�ɰ_��
     *                  REG_END_DATE = �w���J�ɨ���
     *                  TRN_KIND = �������
     *                  APLY_NO = �߮׽s��
     *              </pre> 
     * @return  rtnList List<Map>   �ץ�_�ܧ������DTEPB301 (�h��)
     */
    public List<Map> queryList(String SUB_CPY_ID, Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, "EP_B40010_MSG_001");//�ץ�_�ܧ�������o����
        }
        if (eie != null) {
            throw eie;
        }
        String OP_STATUS = MapUtils.getString(reqMap, "APLY_STS");

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //��ܹw���w�J�ɥH�~����L�ﶵ(06�w���w�J��)    
        if ("06".equals(OP_STATUS)) {
            ds.setField("OP_STATUS", "04");
            ds.setField("IS_REG", "Y");
        } else if (StringUtils.isNotBlank(OP_STATUS)) {
            ds.setField("OP_STATUS", OP_STATUS);
        }
        Set<String> expTrnKind = FieldOptionList.getName("EP", "APRV_NOT_QUERY_B401").keySet(); //103.5.20�d�߱ư�������N��(��USER�ݨD) �ثe���ư�EPA007�j�Өϥη��p��s

        if(expTrnKind != null){
            ds.setFieldValues("expTrnKind", expTrnKind.toArray());
        }
        
        setFieldDATEIfExist(ds, reqMap, "APLY_STR_DATE", "APLY_END_DATE");
        setFieldDATEIfExist(ds, reqMap, "REG_STR_DATE", "REG_END_DATE");

        setFieldIfExist(ds, reqMap, "BLD_CD");
        setFieldIfExist(ds, reqMap, "CRT_NO");
        setFieldIfExist(ds, reqMap, "INPUT_DIV_NO");
        setFieldIfExist(ds, reqMap, "INPUT_NAME");
        setFieldIfExist(ds, reqMap, "REG_STR_DATE");
        setFieldIfExist(ds, reqMap, "REG_END_DATE");
        setFieldIfExist(ds, reqMap, "TRN_KIND");
        setFieldIfExist(ds, reqMap, "APLY_NO");
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);
        //�s�W����^�ǲM�� 
        int i = 1;
        for (Map rtnMap : rtnList) {
            rtnMap.put("SER_NO", i++);
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "APLY_STS_B410", MapUtils.getString(rtnMap, "OP_STATUS", "").trim()));
        }
        return rtnList;

    }

    /**
     * ��� �]�w  �A���p�_�馳�� ����L�� �A�h ����==�_��
     * @param ds
     * @param reqMap
     * @param DATE_STR
     * @param DATE_END
     */
    private void setFieldDATEIfExist(DataSet ds, Map reqMap, String DATE_STR, String DATE_END) {
        String DATE_STR_value = MapUtils.getString(reqMap, DATE_STR);
        String DATE_END_value = MapUtils.getString(reqMap, DATE_END);
        if (StringUtils.isNotBlank(DATE_STR_value)) {
            ds.setField(DATE_STR, DATE_STR_value);
        }
        if (StringUtils.isNotBlank(DATE_END_value)) {
            ds.setField(DATE_END, DATE_END_value);
        }

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * ���Ȥ~�]��
     * @param ds
     * @param reqMap
     * @param string
     */
    private void setFieldIfExist(DataSet ds, Map reqMap, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

}
