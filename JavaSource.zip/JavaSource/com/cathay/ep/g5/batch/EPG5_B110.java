package com.cathay.ep.g5.batch;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.CathayAPI;
import com.cathay.common.util.CathayAPI.API_Platform;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.http.HttpClientHelper;
import com.cathay.common.util.http.HttpClientHelper.HttpResponseType;
import com.cathay.ep.g1.ws.DPLandHelper;
import com.cathay.ep.module.EP_BatchBean;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;

/**
 * <pre>
 * ���ʤ�� ����  ���ʻ���    ���ʤH��    �߮׳渹
 * 2019/10/22  1   Created ������ 191025000965
 * 
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �q�l�å��妸�ӽ�
 * �{���W��    EPG5_B110
 * �@�~�覡    BATCH
 * ���n����    �d�߰�a�å��վ\���ӫݥӽХ�A�I�s�A�ȥӽйq�l�å�
 * �w����ƶq   50 (�̤j��)
 * �@�~�W��    JAEPDG001
 * �~�ȧO EP
 * ���t�ΦW��   G5
 * �B�z�g��    ��
 * ����B�z���  �L
 * �ݨD���    ���ʲ���곡���ʲ�����
 * �@�~���    ����T����ڸ�T��

 * </pre>
 * @author ���ި|
 * @since 2019/11/6
 * 2019/11/11 AllenTsai �վ�I�sWeb Service����EP_SEQ
 * 2019/11/12 AllenTsai �վ����P�_�B�z�覡�A�קK�P�_����
 * 2019-11-14 AllenTsai �վ�API �ϥ� CathayAPI �I�s �֤߼Ҳ�
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class EPG5_B110 extends EP_BatchBean {
    /** log */
    private static final Logger log = Logger.getLogger(EPG5_B110.class);

    /** �@�~�W�� */
    private static final String JOB_NAME = "JAEPDG001";

    /** �{���W�� */
    private static final String PROGRAM = "EPG5_B110";

    /** ����g�� */
    private static final String PERIOD = "��";

    private static final String INPUT_COUNT = "��a�å��ݳB�z��";

    private static final String OUTPUT_G511_COUNT = "��a�å��վ\����";

    private static final String SEND_COUNT = "�q�l�å��e�󵧼�";

    private static final String API_ERROR_COUNT = "�q�l�å��e���ˮֿ��~";

    private static final String CHECK_ERROR_COUNT = "�e���ˮ֬d�߿��~����";

    private static final String OVERLOAD_COUNT = "�q�l�å��e��W�L�֭�";

    private static final String EPAPI_ERROR_COUNT = "�q�l�å��A�ȼҲտ��~���";

    private static final String G511_ERROR_COUNT = "��a�å��վ\���ӧ�s���~";

    private StringBuilder sb = new StringBuilder();

    private static final String SQL_query_001 = "com.cathay.ep.g5.batch.EPG5_B110.SQL_query_001";

    private static final String SQL_UPDATE_001 = "com.cathay.ep.g5.batch.EPG5_B110.SQL_UPDATE_001";
    
	private static final SimpleDateFormat YYYY_MM_DD_SDF = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    public void execute(String[] arg0) throws Exception {

        final BatchConstructor bc = new BatchConstructor(JOB_NAME, PROGRAM, PERIOD);

        try {

            bc.createCountType(INPUT_COUNT);
            bc.createCountType(OUTPUT_G511_COUNT);
            bc.createCountType(SEND_COUNT);
            bc.createCountType(API_ERROR_COUNT);
            bc.createCountType(CHECK_ERROR_COUNT);
            bc.createCountType(OVERLOAD_COUNT);
            bc.createCountType(EPAPI_ERROR_COUNT);
            bc.createCountType(G511_ERROR_COUNT);

            bc.execute(new BatchConstructor.DataBaseHandler() {
                BatchUpdateDataSet buds_g511_upd = bc
                        .getBatchUpdateDataSet(SQL_UPDATE_001, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                DPLandHelper dpLandHelper = new DPLandHelper();

                int resendErrCnt = 0;

                int sendCnt = 0;

                int CHK_SEND_COUNT = 0;

                //���~�۰ʭ��e����
                Map errResendCfg = null;

                @Override
                protected boolean firstProcess() throws Exception {
                    try {
                        //���o�q�l�å��e���ˮֳ]�w
                        Map loadCheckCfg = FieldOptionList.getName("EP", "DPLandServiceCheck");
                        String apiURL = MapUtils.getString(loadCheckCfg, "SEND_CHECK_API");
                        resendErrCnt = MapUtils.getInteger(loadCheckCfg, "RESEND_ERR_COUNT");//����
                        String apiResult = callCSRAPI(apiURL, null);
                        Map apiResultMap = VOTool.jsonToMap(apiResult);
                        if (!"0".equals(MapUtils.getString(apiResultMap, "returnCode"))) {
                            log.fatal("�I�s�q�l�å��e���ˮ�API ���~,API���~�T��:" + apiResultMap);
                            bc.addErrorLog("�I�s�q�l�å��e���ˮ�API ���~,API���~�T��:", apiResultMap);
                            bc.writeErrorLog();
                            bc.addCountNumber(API_ERROR_COUNT, 1);
                            return false;
                        }
                        Map mapStatus = VOTool.jsonToMap(MapUtils.getString(apiResultMap, "detail"));
                        String MSG_DESC = MapUtils.getString(mapStatus, "MSG_DESC");
                        if (!"0".equals(MapUtils.getString(mapStatus, "CODE"))) {
                            log.fatal("�q�l�å��e���ˮ֬d�߿��~:" + MSG_DESC);
                            bc.addErrorLog("�q�l�å��e���ˮ֬d�߿��~", MSG_DESC);
                            bc.writeErrorLog();
                            bc.addCountNumber(CHECK_ERROR_COUNT, 1);
                            return false;
                        }
                        //���~�۰ʭ��e����
                        errResendCfg = FieldOptionList.getName("EP", "RSC_CD");
                        //���o�q�l�å��e�󵧼ƻ֭�
                        CHK_SEND_COUNT = MapUtils.getIntValue(mapStatus, "ACCREQNUM");//�����
                        if (CHK_SEND_COUNT < 1) { //�i�e����
                            log.fatal("�q�l�å��e���ˮֶW�L�֭ȡA�Ȱ��e��:" + MSG_DESC);
                            bc.addErrorLog("�q�l�å��e���ˮֶW�L�֭ȡA�Ȱ��e��", MSG_DESC);
                            bc.writeErrorLog();
                            bc.addCountNumber(OVERLOAD_COUNT, 1);
                            return false;
                        }

                    } catch (Exception e) {
                        log.fatal("�I�s�q�l�å��e���ˮ�API ���~", e);
                        bc.addErrorLog("�I�s�q�l�å��e���ˮ�API ���~,API���~�T��", e);
                        bc.writeErrorLog();
                        bc.addCountNumber(API_ERROR_COUNT, 1);
                        return false;
                    }
                    return true;
                }

                @Override
                protected boolean searchProcess(BatchQueryDataSet bqds) throws Exception {
                    bqds.searchAndRetrieve(SQL_query_001);
                    int totalCount = bqds.getTotalCount();
                    if (totalCount == 0) {
                        log.fatal("�d�L�ݳB�z�����");
                        return false;
                    }
                    bc.addCountNumber(INPUT_COUNT, totalCount);
                    return true;
                }

                @Override
                protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {
                    //�v���B�z��a�å��ݰe�����
                    //���e�󵧼�(sendCnt)�W�L�]�w�֭�(CHK_SEND_COUNT)�A���XREAD �j��A�i��̫�@�媺��ƿ�X
                    if (sendCnt < CHK_SEND_COUNT) {
                        //�榡�ƼҲհѼ� paramMap
                        Map paramMap = new HashMap();
                        paramMap.put("APLY_ID", ObjectUtils.toString(bqds.getField("APLY_ID")));//�e��H��
                        paramMap.put("APLY_NM", ObjectUtils.toString(bqds.getField("APLY_NM")));//�e��H���W��
                        paramMap.put("EP_KIND", ObjectUtils.toString(bqds.getField("EP_KIND")));//�å����O
                        String EP_APLY_NO = ObjectUtils.toString(bqds.getField("EP_APLY_NO"));
                        paramMap.put("EP_APLY_NO", EP_APLY_NO);//�վ\�s��
                        sb.setLength(0);
                        String BASE_CD = ObjectUtils.toString(bqds.getField("BASE_CD"));
                        
                        paramMap.put("EP_SEQ", ObjectUtils.toString(bqds.getField("EP_SEQ")));//�վ\�Ǹ�
                        paramMap.put("OID", sb.append(BASE_CD).append('_').append(ObjectUtils.toString(bqds.getField("EP_SEQ"))).toString());//�վ\�Ǹ�
                        paramMap.put("BASE_CD", BASE_CD);//��a�N��
                        //�����N�X
                        String CITY_ID_G111 = ObjectUtils.toString(bqds.getField("CITY_ID_G111"));
                        paramMap.put("CITY_ID", StringUtils.isBlank(CITY_ID_G111) ? ObjectUtils.toString(bqds.getField("CITY_ID"))
                                : CITY_ID_G111);
                        //�����W��
                        String CITY_NM_G111 = ObjectUtils.toString(bqds.getField("CITY_NM_G111"));
                        paramMap.put("CITY_NM", StringUtils.isBlank(CITY_NM_G111) ? ObjectUtils.toString(bqds.getField("CITY_NM"))
                                : CITY_NM_G111);
                        //�ϰ�N�X
                        String AREA_ID_G111 = ObjectUtils.toString(bqds.getField("AREA_ID_G111"));
                        paramMap.put("AREA_ID", StringUtils.isBlank(AREA_ID_G111) ? ObjectUtils.toString(bqds.getField("AREA_ID"))
                                : AREA_ID_G111);
                        //�ϰ�W��
                        String AREA_NM_G111 = ObjectUtils.toString(bqds.getField("AREA_NM_G111"));
                        paramMap.put("AREA_NM", StringUtils.isBlank(AREA_NM_G111) ? ObjectUtils.toString(bqds.getField("AREA_NM"))
                                : AREA_NM_G111);
                        //�a�ҥN�X
                        String LN_G111 = ObjectUtils.toString(bqds.getField("LN_G111"));
                        paramMap.put("LN", StringUtils.isBlank(LN_G111) ? ObjectUtils.toString(bqds.getField("LN")) : LN_G111);
                        //�a�ҦW��
                        String LN_NM_G111 = ObjectUtils.toString(bqds.getField("LN_NM_G111"));
                        paramMap.put("LN_NM", StringUtils.isBlank(LN_NM_G111) ? ObjectUtils.toString(bqds.getField("LN_NM")) : LN_NM_G111);
                        //�q�p�q�N�X
                        String SESSION_ID_G111 = ObjectUtils.toString(bqds.getField("SESSION_ID_G111"));
                        paramMap.put("SESSION_ID", StringUtils.isBlank(SESSION_ID_G111) ? ObjectUtils.toString(bqds.getField("SESSION_ID"))
                                : SESSION_ID_G111);
                        //�q�p�q�W��
                        String SESSION_NM_G111 = ObjectUtils.toString(bqds.getField("SESSION_NM_G111"));
                        paramMap.put("SESSION_NM", StringUtils.isBlank(SESSION_NM_G111) ? ObjectUtils.toString(bqds.getField("SESSION_NM"))
                                : SESSION_NM_G111);
                        String bqdsIR49_NO = ObjectUtils.toString(bqds.getField("IR49_NO"));
                        paramMap.put("IR49_NO", bqdsIR49_NO.replace("-", ""));//�a�q��
                        paramMap.put("OWN_ID", ObjectUtils.toString(bqds.getField("OWN_ID")));//�Ҧ��v�Ҹ�

                        int bqdsTOT_ERR_CNT = Integer.parseInt(ObjectUtils.toString(bqds.getField("TOT_ERR_CNT"), "0"));
                        //�P�_���~��O�_�۰ʭ��e
                        boolean isSkipThis = false;
                        if (!"0".equals(ObjectUtils.toString(bqds.getField("EP_APLY_STS")))) {//�D���`��ݰe��
                            //���~���ƶW�L�֭ȳ]�w�A���۰ʭ��e
                            if (bqdsTOT_ERR_CNT > resendErrCnt) {
                                isSkipThis = true;
                            }
                            //���~��A�j�@�魫�e
                            boolean aplDateSameDate = isSameDateApply(bqds);
							if (aplDateSameDate) {//�P�_ bqds.EP_APL_DATE�ɶ������ == ����
                                isSkipThis = true;
                            }
                            //�P�_�O�_���۰ʭ��e���~����
                            String RSC_CD = ObjectUtils.toString(bqds.getField("RSC_CD"));
                            if (StringUtils.isBlank(RSC_CD) || !errResendCfg.containsKey(RSC_CD)) {
                                isSkipThis = true;
                            }
                        }
                        //�I�s�q�l�å��A�ȼҲ�
                        if (!isSkipThis) {
                            String APLY_STS = null;
                            String EP_APLY_MSG = null;
                            int EP_APLY_CNT = 0;
                            int EP_ERR_CNT = 0;
                            int TOT_ERR_CNT = 0;
                            try {
                                Map rtnMap = dpLandHelper.applyEDoc(paramMap);
                                if ("0".equals(MapUtils.getString(rtnMap, "CODE"))) {
                                    APLY_STS = "L"; //�e��
                                    EP_APLY_MSG = MapUtils.getString(rtnMap, "RESP_MSG");
                                    EP_APLY_CNT = 1;
                                    EP_ERR_CNT = 0;
                                    TOT_ERR_CNT = bqdsTOT_ERR_CNT;
                                    sendCnt++;//�֭p�e�󵧼�
                                    bc.addCountNumber(SEND_COUNT, 1);
                                } else {
                                    APLY_STS = "W"; //�I�s�e��A�ȥ���
                                    EP_APLY_MSG = "";
                                    EP_APLY_CNT = 0;
                                    EP_ERR_CNT = 1;
                                    TOT_ERR_CNT = bqdsTOT_ERR_CNT + 1;
                                }
                                //�z�L  buds_g511_upd ��s��a�å��վ\����
                                buds_g511_upd.setField("EP_APLY_NO", EP_APLY_NO);//�վ\�s��
                                buds_g511_upd.setField("EP_SEQ", bqds.getField("EP_SEQ"));//�վ\�Ǹ�
                                buds_g511_upd.setField("CITY_ID", paramMap.get("CITY_ID"));//�����N�X
                                buds_g511_upd.setField("CITY_NM", paramMap.get("CITY_NM"));//�����W��
                                buds_g511_upd.setField("AREA_ID", paramMap.get("AREA_ID"));//�ϰ�N�X
                                buds_g511_upd.setField("AREA_NM", paramMap.get("AREA_NM"));//�ϰ�W��
                                buds_g511_upd.setField("LN", paramMap.get("LN"));//�a�ҥN�X
                                buds_g511_upd.setField("LN_NM", paramMap.get("LN_NM"));//�a�ҦW��
                                buds_g511_upd.setField("SESSION_ID", paramMap.get("SESSION_ID"));//�q�p�q�N�X
                                buds_g511_upd.setField("SESSION_NM", paramMap.get("SESSION_NM"));//�q�p�q�W��
                                buds_g511_upd.setField("EP_KIND", paramMap.get("EP_KIND"));//�å�����
                                buds_g511_upd.setField("OWN_ID", paramMap.get("OWN_ID"));//�Ҧ��v�H�Ҹ�
                                buds_g511_upd.setField("IR49_NO", bqdsIR49_NO);//�a�ظ�
                                buds_g511_upd.setField("EP_APLY_STS", APLY_STS);//�å��ӽЪ��A 
                                buds_g511_upd.setField("EP_APLY_CNT", EP_APLY_CNT);//�վ\�e�󵧼�
                                buds_g511_upd.setField("EP_EXP_CNT", 0);//�վ\�U������
                                buds_g511_upd.setField("EP_ERR_CNT", EP_ERR_CNT);//�վ\���~����
                                buds_g511_upd.setField("EP_APLY_MSG", EP_APLY_MSG);//�ӽгB�z�T��
                                buds_g511_upd.setField("RSC_CD", "");//���~���e����
                                buds_g511_upd.setField("TOT_ERR_CNT", TOT_ERR_CNT);//�֭p���~����
                                buds_g511_upd.setField("CHG_DATE", DATE.getDBTimeStamp());//�B�z�ɶ�
                                addBatchAndJoinGroup(buds_g511_upd);
                                bc.addCountNumber(OUTPUT_G511_COUNT, 1);
                            } catch (Exception e) {
                                log.fatal("�I�s�q�l�å��A�ȼҲտ��~,�Ҳտ��~�T��:", e);
                                bc.addErrorLog("�I�s�q�l�å��A�ȼҲտ��~,�Ҳտ��~�T��:", e);
                                bc.writeErrorLog();
                                bc.addCountNumber(EPAPI_ERROR_COUNT, 1);
                            }
                        }
                    }
                }

				private boolean isSameDateApply(BatchQueryDataSet bqds) {
					Date EP_APL_DATE = (Date) bqds.getField("EP_APL_DATE");
					String today =DATE.getDBDate();
					String strEP_APL_DATE = (EP_APL_DATE==null ? today : YYYY_MM_DD_SDF.format(EP_APL_DATE));
					boolean aplDateSameDate = today.equals(strEP_APL_DATE);
					return aplDateSameDate;
				}

                @Override
                protected String formatErrorDetailMessage(Map errorDataMap) {
                    try {
                        bc.addCountNumber(G511_ERROR_COUNT, 1);
                    } catch (ModuleException e) {
                        log.fatal("�p���a�å��վ\���ӧ�s���~���Ƶo�Ϳ��~", e);
                    }
                    return "��a�å��վ\���ӧ�s���~:" + getSQLException(errorDataMap);
                }

                //2019-11-14 AllenTsai �վ�API �ϥ� CathayAPI �I�s �֤߼Ҳ� 
                private String callCSRAPI(String requestURL, Map param) {
                    log.debug("requestURL:"+ requestURL);

                    try {
                    	String csrResult = (String) CathayAPI.build(API_Platform.CSR).getService(requestURL).call(HttpResponseType.STRING);
                    	return csrResult;
                    } catch (Exception e) {
                        log.fatal("CathayAPI �o�Ϳ��~", e);
                        try{
                            HttpClientHelper hc = new HttpClientHelper();
                            Map requestHeader = new HashMap();
                            requestHeader.put("Accept", "application/json");
                            requestHeader.put("Accept-Charset", "UTF-8");
                            String apiHost = FieldOptionList.getName("EP", "DPLandServiceCheck", "FULL_API_PREFIX");

                            String fullRequestURL = apiHost+requestURL;
                            log.debug("fullRequestURL:"+ requestURL);
                            String jsonStr = "";
                            Object result = hc.getHttpResponseByJSON(fullRequestURL, requestHeader, jsonStr, HttpResponseType.STRING, "UTF-8");
                            String strResult = result != null ? result.toString() : "";
                            return strResult;
                        } catch(Exception ee) {
                        	log.fatal("CSRAPI �o�Ϳ��~", ee);
                        }

                    }
                    return null;
                }

            });
        } catch (Exception e) {
            setExitCode(ERROR);
            log.fatal("����ɵo�Ϳ��~", e);
        } finally {
            int batchConstructorExitCode = bc.getExitCode();
            if (batchConstructorExitCode != OK) {
                setExitCode(batchConstructorExitCode);
            }
            printExitCode(getExitCode());
        }

    }
}