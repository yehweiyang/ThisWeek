package com.cathay.ep.b2.module.test;


import org.apache.log4j.Logger;

import com.cathay.ep.b2.module.EPB2_0010_mod;
import com.cathay.ep.vo.DTEPB201;
import com.cathay.util.DBTestCase;

public class EPB2_0010_modTest2 extends DBTestCase {

    private static Logger log = Logger.getLogger(EPB2_0010_modTest2.class);
    
    EPB2_0010_mod theEPB2_0010_mod = new EPB2_0010_mod();

    public EPB2_0010_modTest2(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    } 

    public void testchkDTEPB201Ipt() {
        log.debug("==============================���� testchkDTEPB201Ipt �}�l==============================");
        try {
            theEPB2_0010_mod.chkDTEPB201Ipt(null, null, false);
            log.debug("------------------------------�t�V�ר�1���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�1���զ��\------------------------------");
            log.error("", e);
        }
        try {
            theEPB2_0010_mod.chkDTEPB201Ipt(new DTEPB201(), "K", false);
            log.debug("------------------------------�t�V�ר�2���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�2���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setCUS_NAME("test");
            B201Vo.setJOB_TYPE("bb");
            B201Vo.setCONT_MOBIL_NO("A");
            B201Vo.setTEL_AREA("A");
            B201Vo.setTEL("A");
            B201Vo.setTEL_EXT("A");
            B201Vo.setTAX_FREE_CD("!");
            B201Vo.setCUS_EMAIL("!");
            B201Vo.setCOMP_ZIP_CODE("A");
            B201Vo.setCONT_ZIP_CODE("A");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "K", false);
            log.debug("------------------------------�t�V�ר�3���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�3���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setJOB_TYPE("bb");
            B201Vo.setCONT_MOBIL_NO("A");
            B201Vo.setTEL_AREA("A");
            B201Vo.setTEL("A");
            B201Vo.setTEL_EXT("A");
            B201Vo.setTAX_FREE_CD("!");
            B201Vo.setCUS_EMAIL("!");
            B201Vo.setCOMP_ZIP_CODE("996");
            B201Vo.setCONT_ZIP_CODE("996");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "K", false);
            log.debug("------------------------------�t�V�ר�4���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�4���զ��\------------------------------");
            log.error("", e);
        }        
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("F18173251A");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCUS_EMAIL("xxx@cathaylife.com.tw");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("aaa");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "I", false);
            log.debug("------------------------------�t�V�ר�5���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�5���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("F18173251A");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCUS_EMAIL("xxx@cathaylife.com.tw");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("12340123456789");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "I", false);
            log.debug("------------------------------�t�V�ר�6���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�6���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("F18173251A");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCUS_EMAIL("xxx@cathaylife.com.tw");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("5288018730374B");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "U", true);
            log.debug("------------------------------�t�V�ר�7���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�7���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("F18173251A");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCUS_EMAIL("xxx@cathaylife.com.tw");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("5288018730374B");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "I", true);
            log.debug("------------------------------�t�V�ר�8���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�8���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("A18730374B");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("5288018730374B");
            B201Vo.setINV_TYPE("1");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "U", true);
            log.debug("------------------------------�t�V�ר�9���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�9���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("A18730374B");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("5288018730374B");
            B201Vo.setINV_TYPE("2");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "U", true);
            log.debug("------------------------------�t�V�ר�10���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�10���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("A18730374B");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("5288018730374B");
            B201Vo.setINV_TYPE("2");
            B201Vo.setINV_DEVICE_TYPE("A");
            B201Vo.setINV_DEVICE_NO("AA0123456789123");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "U", true);
            log.debug("------------------------------�t�V�ר�11���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�11���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("A18730374B");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("5288018730374B");
            B201Vo.setINV_TYPE("2");
            B201Vo.setINV_DEVICE_TYPE("B");
            B201Vo.setINV_DEVICE_NO("/234567");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "U", true);
            log.debug("------------------------------�t�V�ר�12���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�12���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();


            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "D", true);
            log.debug("------------------------------�t�V�ר�13���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�13���զ��\------------------------------");
            log.error("", e);
        } 
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_ID("0000006693");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "D", true);
            log.debug("------------------------------�t�V�ר�14���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�14���զ��\------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_ID("000000010");
            B201Vo.setCUS_NAME("�sO��Ǫѥ��������q");
            B201Vo.setID_TYPE("1");
            B201Vo.setID("99999999");
            B201Vo.setJOB_TYPE("20");
            B201Vo.setCOMP_ZIP_CODE("106");
            B201Vo.setCONT_ZIP_CODE("106");
            B201Vo.setVIR_ACC_ID("52889999999999");
            B201Vo.setINV_TYPE("A");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "U", true);
            log.debug("------------------------------�t�V�ר�15���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�15���զ��\------------------------------");
            log.error("", e);
        } 
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_ID("000000010");
            B201Vo.setCUS_NAME("�sO��Ǫѥ��������q");
            B201Vo.setID_TYPE("1");
            B201Vo.setID("99999999");
            B201Vo.setJOB_TYPE("20");
            B201Vo.setCOMP_ZIP_CODE("106");
            B201Vo.setCONT_ZIP_CODE("106");
            B201Vo.setVIR_ACC_ID("52889999999999");
            B201Vo.setINV_TYPE("A");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "I", false);
            log.debug("------------------------------�t�V�ר�16���ե���------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------�t�V�ר�16���զ��\------------------------------");
            log.error("", e);
        }          
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("F18173251A");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCUS_EMAIL("xxx@cathaylife.com.tw");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("52880123456789");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "U", true);
            log.debug("------------------------------���V�ר�1���զ��\------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------���V�ר�1���ե���------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("11");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("F18173251A");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCUS_EMAIL("xxx@cathaylife.com.tw");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("52880123456789");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "U", true);
            log.debug("------------------------------���V�ר�2���զ��\------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------���V�ר�2���ե���------------------------------");
            log.error("", e);
        }
        try {
            DTEPB201 B201Vo = new DTEPB201();
            B201Vo.setSUB_CPY_ID("00");
            B201Vo.setCUS_NAME("test");
            B201Vo.setID_TYPE("4");
            B201Vo.setCUS_ID("0000000129");
            B201Vo.setID("A18730374B");
            B201Vo.setJOB_TYPE("00");
            B201Vo.setCONT_MOBIL_NO("0911111111");
            B201Vo.setTEL_AREA("02");
            B201Vo.setTEL("28825252");
            B201Vo.setTEL_EXT("2511");
            B201Vo.setCUS_EMAIL("xxx@cathaylife.com.tw");
            B201Vo.setCOMP_ZIP_CODE("406");
            B201Vo.setCONT_ZIP_CODE("406");
            B201Vo.setVIR_ACC_ID("5288018730374B");
            theEPB2_0010_mod.chkDTEPB201Ipt(B201Vo, "I", true);
            log.debug("------------------------------���V�ר�3���զ��\------------------------------");
        } catch (Exception e) {
            log.debug("------------------------------���V�ר�3���ե���------------------------------");
            log.error("", e);
        }

        log.debug("==============================���� testchkDTEPB201Ipt ����==============================");
    }      
    
    

}
