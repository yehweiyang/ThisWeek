package com.cathay.ep.b2.module;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPB201;
import com.cathay.ep.vo.DTEPB201_LOG;
import com.cathay.ep.z0.module.EP_Z0B201;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 *      DATE    Description Author
 *      2013/11/5   Created ���կ�
 *      
 *      �@�B  �{���\�෧�n�����G
 *      �ҲզW��    �Ȥ��ƺ��@�Ҳ�
 *      �Ҳ�ID    EP_B20010
 *      ���n����    �Ȥ��ƺ��@�Ҳ�
 * </pre>
 * @author �x�Ԫ�
 * @since  2013-11-13
 */
@SuppressWarnings("unchecked")
public class EP_B20010 {
    private final static Logger log = Logger.getLogger(EP_B20010.class);

    //private static final String SQL_queryList_001 = "com.cathay.ep.b2.module.EP_B20010.SQL_queryList_001"; �Ҳդ�(EP_Z0B201)

    //private static final String SQL_queryList_002 = "com.cathay.ep.b2.module.EP_B20010.SQL_queryList_002"; �Ҳդ�(EP_Z0B201)

    private static final String SQL_queryMap_001 = "com.cathay.ep.b2.module.EP_B20010.SQL_queryMap_001";

    private static final String SQL_chkCrtCusID_001 = "com.cathay.ep.b2.module.EP_B20010.SQL_chkCrtCusID_001";

    private static final String SQL_chkCrtCusID_002 = "com.cathay.ep.b2.module.EP_B20010.SQL_chkCrtCusID_002";

    private static final String SQL_chkCrtCusID_003 = "com.cathay.ep.b2.module.EP_B20010.SQL_chkCrtCusID_003";

    /**
     * Ū���Ȥ�򥻸���ɲM��
     * @param reqMap Map
     *                  <pre>
     *                      SUB_CPY_ID = �����q�O
     *                      ID = �ҥ󸹽X
     *                      CUS_NAME = �Ȥ�m�W
     *                      CUS_ID = �Ȥ�s��
     *                      IS_EXACT = �O�_��T�d��(Y/N)
     *                  </pre>
     * @return  rtnList List<Map>   �Ȥ�_�򥻸��DTEPB201(�h��)
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B20010_MSG_001");//�Ȥ�򥻸�Ƥ��o����!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_002");//�����q�O���o���ŭ�!
        }
        String ID = MapUtils.getString(reqMap, "ID");
        String CUS_NAME = MapUtils.getString(reqMap, "CUS_NAME");
        String CUS_ID = MapUtils.getString(reqMap, "CUS_ID");
        String VIR_ACC_ID = MapUtils.getString(reqMap, "VIR_ACC_ID");
        if (StringUtils.isBlank(ID) && StringUtils.isBlank(CUS_NAME) && StringUtils.isBlank(CUS_ID) && StringUtils.isBlank(VIR_ACC_ID)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_003");//�ҥ󸹽X�B�Ȥ�m�W�B�Ȥ�s���B�����b�����o�Ҭ��ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        StringBuilder sb = new StringBuilder();
        /* �Ҳդ�(EP_Z0B201)
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        boolean IS_EXACT = !"Y".equals(MapUtils.getString(reqMap, "IS_EXACT"));
        StringBuilder sb = new StringBuilder();
        setIfExist(ds, reqMap, "ID", sb, IS_EXACT);
        setIfExist(ds, reqMap, "CUS_NAME", sb, IS_EXACT);
        setIfExist(ds, reqMap, "CUS_ID", sb, IS_EXACT);
        setIfExist(ds, reqMap, "VIR_ACC_ID", sb, IS_EXACT);
        String SQL = IS_EXACT ? SQL_queryList_001 : SQL_queryList_002; //IS_EXACT "Y" ��T�d��*/
        List<Map> rtnList = new EP_Z0B201().queryB201List(reqMap, SUB_CPY_ID);
        int SER_NO = 1;
        for (Map rtnMap : rtnList) {
            rtnMap.put("ID_TYPE_NM", FieldOptionList.getName("EP", "ID_TYPE", MapUtils.getString(rtnMap, "ID_TYPE")));
            rtnMap.put("JOB_TYPE_NM", FieldOptionList.getName("EP", "JOB_TYPE", MapUtils.getString(rtnMap, "JOB_TYPE")));
            String TEL = MapUtils.getString(rtnMap, "TEL");
            if (StringUtils.isNotBlank(TEL)) {
                String TEL_AREA = MapUtils.getString(rtnMap, "TEL_AREA");
                if (StringUtils.isNotBlank(TEL_AREA)) {
                    sb.append(TEL_AREA).append("-");
                }
                sb.append(TEL);
                String TEL_EXT = MapUtils.getString(rtnMap, "TEL_EXT");
                if (StringUtils.isNotBlank(TEL_EXT)) {
                    sb.append("-").append(TEL_EXT);
                }
                rtnMap.put("CONT_TEL", sb.toString());
                sb.setLength(0);
            }
            rtnMap.put("SER_NO", SER_NO++);
            
            //2020-02-10 ��عq�l�o���ɤJ�G�s�W�o����Τ覡���
            String INV_TRANS_TYPE = MapUtils.getString(rtnMap, "TRANS_TYPE");
            rtnMap.put("INV_TRANS_TYPE", INV_TRANS_TYPE);//�o����Τ覡
            rtnMap.put("INV_TRANS_TYPE_NM", FieldOptionList.getName("EP", "TRANS_TYPE", INV_TRANS_TYPE));//�o����Τ覡
        }
        return rtnList;
    }

    /**
     * �H�Ȥ�s�����o�Ȥ�򥻸��
     * @param SUB_CPY_ID  String  �����q�O
     * @param CUS_ID      String  �Ȥ�s��
     * @return   rtnMap  Map �Ȥ�_�򥻸��DTEPB201(�浧)
     */
    public Map queryMap(String SUB_CPY_ID, String CUS_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_002");//�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(CUS_ID)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_004");//�Ȥ�s�����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CUS_ID", CUS_ID);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001);
        rtnMap.put("ID_TYPE_NM", FieldOptionList.getName("EP", "ID_TYPE", MapUtils.getString(rtnMap, "ID_TYPE")));
        rtnMap.put("JOB_TYPE_NM", FieldOptionList.getName("EP", "ID_TYPE", MapUtils.getString(rtnMap, "JOB_TYPE")));
        String TEL = MapUtils.getString(rtnMap, "TEL");
        if (StringUtils.isNotBlank(TEL)) {
            String TEL_AREA = MapUtils.getString(rtnMap, "TEL_AREA");
            StringBuilder sb = new StringBuilder();
            if (StringUtils.isNotBlank(TEL_AREA)) {
                sb.append(TEL_AREA).append("-");
            }
            sb.append(TEL);
            String TEL_EXT = MapUtils.getString(rtnMap, "TEL_EXT");
            if (StringUtils.isNotBlank(TEL_EXT)) {
                sb.append("-").append(TEL_EXT);
            }
            rtnMap.put("CONT_TEL", sb.toString());
            sb.setLength(0);
        }
        return rtnMap;
    }

    /**
     * �ˮ֫����O�_�����Ȥ�s��
     * @param CUS_ID String  �Ȥ�s��
     * @return  hasCrt  boolean ������ƬO�_�����Ȥ�s��
     */
    public boolean chkCrtCusID(String CUS_ID, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(CUS_ID)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_004");//�Ȥ�s�����o���ŭ�!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_002");//�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("CUS_ID", CUS_ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //�d�߫���_�ӯ�����(DTEPB102)���Ȥ�s�����ơG
        DBUtil.searchAndRetrieve(ds, SQL_chkCrtCusID_001);
        ds.next();
        if ((Integer) ds.getField(0) > 0) {
            return true;
        }
        //�d�߼Ȧs����_�ӯ�����(DTEPB303)�ܧ�|�����׸�Ʀ��Ȥ�s�����ơG
        //�d���ܧ�ץ�|�����׸�� 04���� 05���P
        ds.clear();
        ds.setField("CUS_ID", CUS_ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_chkCrtCusID_002);
        ds.next();
        if ((Integer) ds.getField(0) > 0) {
            return true;
        }
        //�d�߫Ȥ�_�H�Υd���v�Ѹ��(DTEPB202)���Ȥ�s�����ơG
        ds.clear();
        ds.setField("CUS_ID", CUS_ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_chkCrtCusID_003);
        ds.next();
        if ((Integer) ds.getField(0) > 0) {
            return true;
        }
        return false;

    }

    /**
     * �s�W�Ȥ�򥻸��
     * @param B201Vo DTEPB201    �Ȥ�_�򥻸��
     * @param user   UserObject  �ϥΪ̸�T
     * @return  CUS_ID  String  �Ȥ�s��
     */
    public String insert(DTEPB201 B201Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_005");//�ϥΪ̸�T���o����!
        }
        if (B201Vo == null) {
            throw getErrorInputException(eie, "EP_B20010_MSG_006");//�Ȥ�_�򥻸�Ƥ��o����!
        }
        String SUB_CPY_ID = B201Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_002");//�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        Timestamp UPD_DATE = DATE.currentTime();
        //���o�Ȥ�s��
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        String CUS_ID = theEP_Z0Z001.createNextNo(SUB_CPY_ID, "003", "CUS_ID", "CUS_ID", SUB_CPY_ID, 8);
        //�g�J�Ȥ�򥻸��
        //160216 modified by i9301216 : �ˮ֫Ȥ�W�٤��i�t�b�μ��I�Ÿ�(')
        B201Vo.setCUS_NAME(STRING.replace(B201Vo.getCUS_NAME(), "'", "��"));
        B201Vo.setCUS_ID(String.valueOf(CUS_ID));
        B201Vo.setCHG_DATE(UPD_DATE);
        B201Vo.setCHG_DIV_NO(user.getOpUnit());
        B201Vo.setCHG_ID(user.getEmpID());
        B201Vo.setCHG_NAME(user.getEmpName());
        //�����b��
        String VIR_ACC_ID = B201Vo.getVIR_ACC_ID();
        if (("3".equals(B201Vo.getID_TYPE()) || "4".equals(B201Vo.getID_TYPE())) && StringUtils.isBlank(VIR_ACC_ID)) {//��L�s�X
            String VIR_ACC = FieldOptionList.getName("EP", "VIR_ACC", "VIR_ACC_ID");
            String ROCYYYMM = DATE.getROCYearAndMonth(DATE.toDate_yyyyMMdd(DATE.getDBDate()));
            VIR_ACC_ID = this.getVIR_ACC_IDbySerNo(VIR_ACC, ROCYYYMM, "99", theEP_Z0Z001, SUB_CPY_ID);
            B201Vo.setVIR_ACC_ID(VIR_ACC_ID);
        }

        VOTool.insert(B201Vo);
        //�g�@��LOG��
        this.insertLog(B201Vo, UPD_DATE, "I", user);
        return CUS_ID;

    }

    /**
     * �̬y�������o�����b��(ID_TYPE=3,4)
     * �]�y�����s�o�����b���i��|�Q�ק����,��������P�_�O�_�w�Q�ϥ�,�Y��:�b���U�@��!
     * @param VIR_ACC
     * @param ROCYYYMM
     * @param VIR_CODE
     * @param theEP_Z0Z001
     * @return
     * @throws ModuleException
     */
    private String getVIR_ACC_IDbySerNo(String VIR_ACC, String ROCYYYMM, String VIR_CODE, EP_Z0Z001 theEP_Z0Z001, String SUB_CPY_ID)
            throws ModuleException {

        String VIR_ACC_ID = theEP_Z0Z001.createNextNo(SUB_CPY_ID, "043", VIR_ACC, ROCYYYMM, new StringBuilder().append(VIR_ACC).append(
            VIR_CODE).append(ROCYYYMM).toString(), 3);
        try {
            Map B201Map = new EP_Z0B201().queryByVIR_ACC_ID(VIR_ACC_ID, SUB_CPY_ID);//(�d�L��Ƶ������`)
            if (B201Map != null && !B201Map.isEmpty()) {
                log.debug("�ӵ����b���w�������Ȥ���,�A���U�@��,VIR_ACC_ID:" + VIR_ACC_ID);
                VIR_ACC_ID = this.getVIR_ACC_IDbySerNo(VIR_ACC, ROCYYYMM, VIR_CODE, theEP_Z0Z001, SUB_CPY_ID);
            }
        } catch (DataNotFoundException dnfe) {
            log.debug("�ӵ����b���L�����Ȥ���,VIR_ACC_ID:" + VIR_ACC_ID);
        }
        return VIR_ACC_ID;
    }

    /**
     * ��s�Ȥ�򥻸��
     * @param B201Vo DTEPB201    �Ȥ�_�򥻸��
     * @param user UserObject  �ϥΪ̸�T
     */
    public void update(DTEPB201 B201Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_005");//�ϥΪ̸�T���o����!
        }
        if (B201Vo == null) {
            throw getErrorInputException(eie, "EP_B20010_MSG_006");//�Ȥ�_�򥻸�Ƥ��o����!
        }
        if (StringUtils.isBlank(B201Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_002");//�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        Timestamp UPD_DATE = DATE.currentTime();

        //�g�@��LOG��
        this.insertLog(B201Vo, UPD_DATE, "U", user);
        //��s�Ȥ�򥻸��
        //160216 modified by i9301216 : �ˮ֫Ȥ�W�٤��i�t�b�μ��I�Ÿ�(')
        B201Vo.setCUS_NAME(STRING.replace(B201Vo.getCUS_NAME(), "'", "��"));
        B201Vo.setCHG_DATE(UPD_DATE);
        B201Vo.setCHG_DIV_NO(user.getOpUnit());
        B201Vo.setCHG_ID(user.getEmpID());
        B201Vo.setCHG_NAME(user.getEmpName());
        VOTool.update(B201Vo);

    }

    /**
     * �R���Ȥ�򥻸��
     * @param B201VoList List<DTEPB201>  �Ȥ�_�򥻸��List
     * @param user  userObject  �ϥΪ̸�T
     */
    public void delete(List<DTEPB201> B201VoList, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_005");//�ϥΪ̸�T���o����!
        }
        if (B201VoList == null || B201VoList.isEmpty()) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_006");//�Ȥ�_�򥻸�Ƥ��o����!
        }
        if (eie != null) {
            throw eie;
        }
        Timestamp UPD_DATE = DATE.currentTime();
        for (DTEPB201 B201Vo : B201VoList) {
            //�g�@��LOG��
            this.insertLog(B201Vo, UPD_DATE, "D", user);
            //�R���Ȥ�򥻸���� DTEPB201�G
            VOTool.delByPK(B201Vo);
        }

    }

    /**
     * �s�W�Ȥ�򥻸��LOG��
     * @param B201Vo DTEPB201
     * @param UPD_DATE Timestamp
     * @param OPR_KIND String I�s�W D�R�� U�ץ�
     * @param user UserObject  �ϥΪ̸�T
     */
    public void insertLog(DTEPB201 B201Vo, Timestamp UPD_DATE, String OPR_KIND, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(OPR_KIND) || (!"I".equals(OPR_KIND) && !"D".equals(OPR_KIND) && !"U".equals(OPR_KIND))) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_007");//�ǤJ�@�~���ؿ��~!
        }
        if (UPD_DATE == null) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_008");//�J�ɤ���ɶ����o���ŭ�!
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_005");//�ϥΪ̸�T���o����!
        }
        if (B201Vo == null) {
            throw getErrorInputException(eie, "EP_B20010_MSG_006");//�Ȥ�_�򥻸�Ƥ��o����!
        }
        String SUB_CPY_ID = B201Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_002");//�����q�O���o���ŭ�!
        }
        String CUS_ID = B201Vo.getCUS_ID();
        if (StringUtils.isBlank(CUS_ID)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_004");//�Ȥ�s�����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�g�@��LOG��

        DTEPB201_LOG B201Vo_Log = VOTool.mapToVO(DTEPB201_LOG.class, this.queryMap(SUB_CPY_ID, CUS_ID));
        B201Vo_Log.setUPD_DATE(UPD_DATE);
        B201Vo_Log.setDATA_TYPE(OPR_KIND);
        B201Vo_Log.setUPD_ID(user.getEmpID());
        B201Vo_Log.setUPD_NAME(user.getEmpName());
        VOTool.insert(B201Vo_Log);
    }

    /**
     * �۰ʨ��o�����b��ID
     * @param ID_TYPE
     * @param ID
     * @return
     * @throws ModuleException 
     */
    public String getVIR_ACC_ID(String ID_TYPE, String ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(ID_TYPE)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_00");//�ǤJ�ҥ�������i����!
        }
        if (!"4".equals(ID_TYPE) && StringUtils.isBlank(ID)) {
            eie = getErrorInputException(eie, "EP_B20010_MSG_00");//�ǤJ�ҥ�ID���i����!
        }
        if (eie != null) {
            throw eie;
        }

        String VIR_ACC_ID = FieldOptionList.getName("EP", "VIR_ACC", "VIR_ACC_ID");//�e�|�X
        if ("1".equals(ID_TYPE)) {//�νs
            return new StringBuilder().append(VIR_ACC_ID).append("00").append(ID).toString();
        } else if ("2".equals(ID_TYPE)) { //ID
            return new StringBuilder().append(VIR_ACC_ID).append(this.convertID(ID)).append(ID.substring(2, 10)).toString();
        } //��L 
        //�T�w�|�X+00+����~�뤭�X(e.x.1050407)+3�X�y����(000~999)�@
        //new EP_Z0Z001().createNextNo("00", "043", VIR_ACC_ID, DATE.getROCDate(), new StringBuilder().append(VIR_ACC_ID).append("99").append(DATE.getROCDate()).toString(), 1
        return "";//��ѽT�w�s�W�ɤ~����

    }

    /**
     * �ഫID�e��X
     * @param input
     * @return
     */
    private String convertID(String input) {

        if (StringUtils.isBlank(input) || input.length() < 2) {
            return "";
        }

        char firstChar = input.charAt(0);
        Integer val = Integer.parseInt(input.substring(1, 2)) - 1;

        String rtnString = String.valueOf((val * 26) + (Character.getNumericValue(firstChar) - 9));

        return rtnString.length() < 2 ? "0" + rtnString : rtnString;

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}
