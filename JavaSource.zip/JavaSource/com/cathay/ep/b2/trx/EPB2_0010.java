package com.cathay.ep.b2.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ds.z0.module.DS_Z01000;
import com.cathay.ep.b2.module.EPB2_0010_mod;
import com.cathay.ep.b2.module.EP_B20010;
import com.cathay.ep.c2.module.EPC2_2010_mod;
import com.cathay.ep.vo.DTEPB201;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 *       Date   Version Description Author
 *       2013/11/4   1.0 Created ���կ�
 *       2017/12/15   2.0 �q�l�o�� ����[
 *       2018/03/19   3.0 ��ؾɤJ ����[
 *       
 *       UCEPB2_0010_�Ȥ��ƺ��@
 *       
 *       �@�B  �{���\�෧�n�����G
 *       �{���\��    �Ȥ��ƺ��@
 *       �{���W��    EPB2_0010
 *       �@�~�覡    ONLINE
 *       ���n����    (1) ��l
 *                  (2) �d�� �w �ϥΪ̫��U�d�߫��s��A���o�Ȥ�򥻸�ƲM���T�C
 *                  (3) �s�W�w ���ѨϥΪ̷s�W�Ȥ�򥻸�Ƹ�T�C
 *                  (4) �ץ� �w ���ѨϥΪ̭ק�Ȥ�򥻸�Ƹ�T�C
 *                  (5) �R���w ���ѨϥΪ̧R���Ȥ�򥻸�Ƹ�T�C=
 *                  (6) �M�� �V �M����J�ϸ��
 *       ���s���v    �M��
 *       �����q���
 *       �榡js    �M��
 *       �h��y�t    �M��
 *       �h���d��   ������         

 * </pre>
 * @author �x�Ԫ�
 * @since  2013-11-15
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPB2_0010 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPB2_0010.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);
        try {
            EP_Z00030 theEP_Z00030 = new EP_Z00030();
            String USER_CPY_ID = theEP_Z00030.getSUB_CPY_ID(user);
            resp.addOutputData("USER_CPY_ID", USER_CPY_ID);//�����q�O
            resp.addOutputData("isAccountSubCpy", theEP_Z00030.isAccountSubCpy(USER_CPY_ID));
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPB2_0010_ERRMSG_001");//���o�����q�O����
        }

        resp.addOutputData("LINK_FROM", req.getParameter("LINK_FROM")); //�W��e��
        resp.addOutputData("ID", req.getParameter("IN_ID")); //�ҥ󸹽X
        resp.addOutputData("CUS_NAME", req.getParameter("IN_CUS_NAME")); //�Ȥ�W��
        resp.addOutputData("CUS_ID", req.getParameter("IN_CUS_ID")); //�Ȥ�s��

        try {
            //�u�ҥ�����v�U�Կ��G
            resp.addOutputData("ID_TYPE_LIST", FieldOptionList.getName("EP", "ID_TYPE"));
            //�u�o���X�I�覡�v�U�Կ��G
            resp.addOutputData("TRANS_TYPE_LIST", FieldOptionList.getName("EP", "TRANS_TYPE"));
            //�u�o���ӤH���������v�U�Կ��G
            resp.addOutputData("INV_DEVICE_TP_LIST", FieldOptionList.getName("EP", "INV_DEVICE_TYPE"));
            //�u�R�߽X�v�w�]�G
            resp.addOutputData("LOVE_CODE", FieldOptionList.getName("EP", "ELE_INV", "LOVE_CODE"));

            //�u��~�O�v�M��G[20200511] ��ءG�e����ܦ�~�O�M��
            Map JOB_TYPE_LIST = FieldOptionList.getName("EP", "JOB_TYPE");
            StringBuilder jobTypeList = new StringBuilder();
            for (Object key : JOB_TYPE_LIST.keySet()) {
                if (jobTypeList.length() > 0) {
                    jobTypeList.append(" / ");
                }
                jobTypeList.append(key).append(" ").append(JOB_TYPE_LIST.get(key));
            }
            resp.addOutputData("JOB_TYPE_LIST", jobTypeList);
        } catch (Exception e) {
            log.error("��l����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00029");//��l����    
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            //���o�j�Ӱ򥻸��
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            this.query(reqMap, new EP_B20010());

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L�������
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB2_0010_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }
        return resp;
    }

    /**
     * �d��
     * @param theEP_B20010
     * @param reqMap
     */
    private void query(Map reqMap, EP_B20010 theEP_B20010) throws ModuleException {
        List<Map> rtnList = theEP_B20010.queryList(reqMap);
        // 20161212 LogSecurity
        try {
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map tmpRecord : rtnList) {
                Map logSecurityMap = new HashMap();
                // �ҥ󸹽X
                logSecurityMap.put("ID", MapUtils.getString(tmpRecord, "ID", ""));
                // �Ȥ�m�W
                logSecurityMap.put("CUS_NAME", MapUtils.getString(tmpRecord, "CUS_NAME", ""));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);
            logSecurityList.clear();
        } catch (Throwable e) {
            log.warn(e, e);
        }
        resp.addOutputData("rtnBList", rtnList);

    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            //�N�i�϶�C�j�e����Ʀs��DTEPB201_Vo
            DTEPB201 DTEPB201_Vo = VOTool.jsonToVO(DTEPB201.class, req.getParameter("B201VO"));

            boolean isFirst = Boolean.valueOf(req.getParameter("isFirst"));
            String valid_result = new EPB2_0010_mod().chkDTEPB201Ipt(DTEPB201_Vo, "I", isFirst);
            if (StringUtils.isNotBlank(valid_result)) {//�^jsp confirm
                resp.addOutputData("valid_result", valid_result);
                return resp;
            }

            //�ˮֲνs�s�X
            if (StringUtils.equals("1", DTEPB201_Vo.getID_TYPE())) {
                new EPC2_2010_mod().checkUniSN(DTEPB201_Vo.getID(), false);
            }
            EP_B20010 theEP_B20010 = new EP_B20010();

            String IN_CUS_ID;
            Transaction.begin();
            try {
                IN_CUS_ID = theEP_B20010.insert(DTEPB201_Vo, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00004");//�s�W����
            resp.addOutputData("CUS_ID", IN_CUS_ID);
            try {
                Map reqMap = new HashMap();
                reqMap.put("ID", DTEPB201_Vo.getID());
                reqMap.put("CUS_NAME", DTEPB201_Vo.getCUS_NAME());
                reqMap.put("CUS_ID", IN_CUS_ID);
                reqMap.put("SUB_CPY_ID", DTEPB201_Vo.getSUB_CPY_ID());
                this.query(reqMap, theEP_B20010);
            } catch (DataNotFoundException e) {
                log.error("�s�W�����A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB2_0010_MSG_002");//�s�W�����A�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataDuplicateException dde) {
            log.error("�s�W���ѡA��Ƥw�s�b", dde);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_DUP, "MEP00006");//�s�W���ѡA��Ƥw�s�b
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00005");//�s�W����
        }

        return resp;
    }

    /**
     * �ץ�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {
            //�N�i�϶�C�j�e����Ʀs��DTEPB201_Vo
            DTEPB201 DTEPB201_Vo = VOTool.jsonToVO(DTEPB201.class, req.getParameter("B201VO"));
            boolean isFirst = Boolean.valueOf(req.getParameter("isFirst"));
            String valid_result = new EPB2_0010_mod().chkDTEPB201Ipt(DTEPB201_Vo, "U", isFirst);
            if (StringUtils.isNotBlank(valid_result)) {//�^jsp confirm
                resp.addOutputData("valid_result", valid_result);
                return resp;
            }
            //�ˮֲνs�s�X
            if ("Y".equals(FieldOptionList.getName("EP", "ELE_INV", "C101_PASS_VAILD")) && StringUtils.equals("1", DTEPB201_Vo.getID_TYPE())) {
                new EPC2_2010_mod().checkUniSN(DTEPB201_Vo.getID(), false);
            }
            EP_B20010 theEP_B20010 = new EP_B20010();
            Transaction.begin();
            try {
                theEP_B20010.update(DTEPB201_Vo, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB2_0010_MSG_003");//�ץ�����
            try {
                this.query(VOTool.jsonToMap(req.getParameter("reqMap")), theEP_B20010);
            } catch (DataNotFoundException e) {
                log.error("�ץ������A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB2_0010_MSG_004");//�ץ������A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB2_0010_ERRMSG_006");// �ץ����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB2_0010_ERRMSG_005");//�ץ�����
            }
        } catch (Exception e) {
            log.error("�ק�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB2_0010_ERRMSG_005");//�ץ�����
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            List<DTEPB201> DTEPB201_voList = VOTool.jsonAryToVOs(DTEPB201.class, req.getParameter("delList"));
            EPB2_0010_mod theEPB2_0010_mod = new EPB2_0010_mod();
            for (DTEPB201 EPB201Vo : DTEPB201_voList) {
                theEPB2_0010_mod.chkDTEPB201Ipt(EPB201Vo, "D", true);
            }
            EP_B20010 theEP_B20010 = new EP_B20010();
            Transaction.begin();
            try {
                theEP_B20010.delete(DTEPB201_voList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00010");//�R������
            try {
                this.query(VOTool.jsonToMap(req.getParameter("reqMap")), theEP_B20010);
            } catch (DataNotFoundException e) {
                log.error("�d�L���", e);
                MessageUtil.setMsg(msg, "EPB1_0070_MSG_006");//�R�������A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB2_0010_ERRMSG_007");//�R�����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00011");//�R������
            }
        } catch (Exception e) {
            log.error("�R���@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00011");//�R������
        }

        return resp;
    }

    /**
     * ���q�l���ϸ����o���q�ϰ�O
     * @param req
     * @return
     */
    public ResponseContext doCOMPCityName(RequestContext req) {
        try {
            String CityName = this.getCityName(req.getParameter("ZIP_CODE"), new DS_Z01000());
            resp.addOutputData("CityName", CityName);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�ߵL���q�ϰ�O", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB2_0010_ERRMSG_008");//���q�l���ϸ���J���~!
        } catch (Exception e) {
            log.error("�d�ߤ��q�ϰ�O����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB2_0010_ERRMSG_008");//���q�l���ϸ���J���~!
        }

        return resp;
    }

    /**
     * �q�T�l���ϸ����o�q�T�a�}�ϰ�O
     * @param req
     * @return
     */
    public ResponseContext doCONTCityName(RequestContext req) {
        try {
            String CityName = this.getCityName(req.getParameter("ZIP_CODE"), new DS_Z01000());
            resp.addOutputData("CityName", CityName);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�ߵL�q�T�a�}�ϰ�O", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB2_0010_ERRMSG_009");//�q�T�l���ϸ���J���~!
        } catch (Exception e) {
            log.error("�d�߳q�T�a�}�ϰ�O����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB2_0010_ERRMSG_009");//�q�T�l���ϸ���J���~!
        }
        return resp;
    }

    /**
     * �d�ߦa�}�ϰ�O
     * @param ZIP_CODE
     */
    private String getCityName(String ZIP_CODE, DS_Z01000 theDS_Z01000) throws ModuleException {
        String CityName = theDS_Z01000.getCityTown(ZIP_CODE);
        if (StringUtils.isBlank(CityName)) {
            throw new ErrorInputException();
        }
        return CityName;
    }

    /**
     * �s�ʦ�~�O
     * @param req
     * @return
     */
    public ResponseContext doChangeJOB_TYPE(RequestContext req) {
        try {
            resp.addOutputData("JOB_TYPE_NM", FieldOptionList.getName("EP", "JOB_TYPE", req.getParameter("JOB_TYPE")));
        } catch (Exception e) {
            log.debug("�d�ߦ�~�O����", e);
        }
        return resp;
    }

    /**
     * �s�ʵ����b��
     * @param req
     * @return
     */
    public ResponseContext doGetVIR_ACC_ID(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String ID_TYPE = MapUtils.getString(reqMap, "ID_TYPE");
            String ID = MapUtils.getString(reqMap, "ID");
            EP_B20010 theEP_B20010 = new EP_B20010();
            String VirAccId = theEP_B20010.getVIR_ACC_ID(ID_TYPE, ID);
            resp.addOutputData("VirAccId", VirAccId);
        } catch (Exception e) {
            log.debug("�����b��s�ʥ���", e);
        }
        return resp;
    }
}
