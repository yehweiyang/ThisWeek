package com.cathay.ep.b2.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.b2.module.EP_B20020;
import com.cathay.ep.vo.DTEPB202;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 *      Date    Version Description Author
 *      2013/8/9    1.0 Created ���կ�
 *      
 *      UCEPB2_0020_�d�����v��ƫ���
 *      
 *      �@�B  �{���\�෧�n�����G
 *      �{���\��    �d�����v��ƫ���
 *      �{���W��    EPB2_0020
 *      �@�~�覡    ONLINE
 *      ���n����    (1) ��l=
 *                  (2) �d�� �w ���ѨϥΪ̬d�߫H�Υd���v��ơC
 *                  (3) �s�W �w ���ѨϥΪ̷s�W�H�Υd���v��ơC
 *                  (4) �ק� �V ���ѨϥΪ̭ק�H�Υd���v��ơC
 *                  (5) �o�� �w ���ѨϥΪ̰��Φ��H�Υd���v��ơC
 *      ���s���v    �M��
 *      �����q���
 *      �榡���js  �M��
 *      �h��y�t    �M��
 *      �h���d��    ������                               
 * </pre>
 * @author �x�Ԫ�
 * @since  2013-11-21
 */
@SuppressWarnings("unchecked")
public class EPB2_0020 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPB2_0020.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            resp.addOutputData("USER_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPB2_0020_ERRMSG_001");//���o�����q�O����
        }
        //���o�H�Υd�O
        resp.addOutputData("CARD_TYPE_LIST", FieldOptionList.getName("EP", "CARD_TYPE"));
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            this.query(req.getParameter("SUB_CPY_ID"), req.getParameter("ID"), req.getParameter("SER_NO"), req.getParameter("AUTH_SER_NO"),
                new EP_B20020());

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB2_0020_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }
        return resp;
    }

    /**
     * �@�άd��
     * @param SUB_CPY_ID
     * @param ID
     * @param SER_NO
     * @param AUTH_SER_NO
     * @param theEP_B20020
     */
    private void query(String SUB_CPY_ID, String ID, String SER_NO, String AUTH_SER_NO, EP_B20020 theEP_B20020) throws ModuleException {
        //�d�߫H�Υd���v�Ѹ�ƲM��
        Map rtnMap = theEP_B20020.queryList(SUB_CPY_ID, ID, SER_NO, AUTH_SER_NO);
        
        //�YrtnMap.rtnB102List�D��
        Map rtnB202Map = (Map) MapUtils.getObject(rtnMap, "rtnB202Map");

        // 20161212 LogSecurity ���v        
        try{
            Map logOneSecurityMap = new HashMap();
            logOneSecurityMap.put("ID", MapUtils.getString(rtnB202Map, "ID", "")) ;
            logOneSecurityMap.put("CUS_NAME", MapUtils.getString(rtnB202Map, "CUS_NAME", "") );
            logOneSecurityMap.put("AUTH_ID",  MapUtils.getString(rtnB202Map, "AUTH_ID", "")  );
            logOneSecurityMap.put("AUTH_NAME",  MapUtils.getString(rtnB202Map, "AUTH_NAME", ""));
            logOneSecurityMap.put("CARD_NO",  MapUtils.getString(rtnB202Map, "CARD_NO", ""));
            logSecurity(logOneSecurityMap);
        } catch(Exception e) {
        	
        }
        
        resp.addOutputData("rtnB202Map", rtnB202Map);
        List<Map> rtnB102List = (List<Map>) MapUtils.getObject(rtnMap, "rtnB102List");
        
        // 20161212 LogSecurity
        try{
        	if(rtnB102List!= null && rtnB102List.size() > 0) {
          		List<Map> logSecurityList = new ArrayList<Map>();
          		for (Map tmpRecord : rtnB102List) {
          			Map logSecurityMap = new HashMap();
          			// �ҥ󸹽X
          			logSecurityMap.put("ID", MapUtils.getString(tmpRecord, "ID", ""));
          			// �Ȥ�m�W
          			logSecurityMap.put("CUS_NAME", 
          					MapUtils.getString(tmpRecord,"CUS_NAME", ""));
          			logSecurityList.add(logSecurityMap);
          		}
          		logSecurity(logSecurityList);
          		logSecurityList.clear();        		
        	}

        } catch(Throwable e) {
        	log.warn(e, e);
        }        
        if (rtnB102List != null) {
            resp.addOutputData("CARD_CUS_NAME", MapUtils.getString(rtnB102List.get(0), "CUS_NAME"));//�Ĥ@�����Ȥ�m�W
            resp.addOutputData("rtnB102List", rtnB102List);

        }

    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            DTEPB202 B202VO = VOTool.jsonToVO(DTEPB202.class, req.getParameter("B202VO"));
            EP_B20020 theEP_B20020 = new EP_B20020();
            Transaction.begin();
            try {
                theEP_B20020.insert(B202VO, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00004");//�s�W����

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataDuplicateException dde) {
            log.error("�s�W���ѡA��Ƥw�s�b", dde);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_DUP, "MEP00006");//�s�W���ѡA��Ƥw�s�b
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00005");//�s�W����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {
            DTEPB202 B202VO = VOTool.jsonToVO(DTEPB202.class, req.getParameter("B202VO"));
            EP_B20020 theEP_B20020 = new EP_B20020();
            Transaction.begin();
            try {
                theEP_B20020.update(B202VO, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB2_0020_MSG_003");//�ץ�����
            try {
                String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
                String ID = req.getParameter("ID");
                String SER_NO = req.getParameter("SER_NO");
                String AUTH_SER_NO = req.getParameter("AUTH_SER_NO");
                this.query(SUB_CPY_ID, ID, SER_NO, AUTH_SER_NO, theEP_B20020);
            } catch (DataNotFoundException e) {
                log.error("�ץ������A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB2_0020_MSG_004");//�ץ������A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB2_0020_ERRMSG_006");//�ץ����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB2_0020_ERRMSG_005");//�ץ�����
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB2_0020_ERRMSG_005");//�ץ�����
        }

        return resp;
    }

    /**
     * �o��
     * @param req
     * @return
     */
    public ResponseContext doCancel(RequestContext req) {
        try {
            DTEPB202 B202VO = VOTool.jsonToVO(DTEPB202.class, req.getParameter("B202VO"));
            EP_B20020 theEP_B20020 = new EP_B20020();

            Transaction.begin();
            try {
                theEP_B20020.cancel(B202VO, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPB2_0020_MSG_007");//�o������
            try {
                String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
                String ID = req.getParameter("ID");
                String SER_NO = req.getParameter("SER_NO");
                String AUTH_SER_NO = req.getParameter("AUTH_SER_NO");
                this.query(SUB_CPY_ID, ID, SER_NO, AUTH_SER_NO, theEP_B20020);
            } catch (DataNotFoundException e) {
                log.error("�o�������A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB2_0020_MSG_008");//�o�������A�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB2_0020_ERRMSG_010");//�o�����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB2_0020_ERRMSG_009");//�o������
            }
        } catch (Exception e) {
            log.error("�o���@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB2_0020_ERRMSG_009");//�o������
        }

        return resp;
    }
}
