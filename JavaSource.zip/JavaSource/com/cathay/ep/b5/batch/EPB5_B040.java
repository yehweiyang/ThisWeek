package com.cathay.ep.b5.batch;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.batch.CountManager;
import com.cathay.common.util.batch.ErrorLog;
import com.cathay.common.util.mail.MailSender;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.rz.s0.module.RZ_S00300;
import com.igsapp.db.BatchQueryDataSet;

/**
 * <pre>
 * Date        Version Description Author
 * 2013/08/06  1.0     Created     ���կ�
 * 
 * �@�B   �{���\�෧�n�����G
 * �{���\��    �Ƶ��ݿ�ƶ��q��
 * �{���W��    EPB5_B040.java
 * �@�~�覡    BATCH
 * ���n����    �C�ѱN�������q�����Ƶ��ƶ��۰ʱH�e�oEMAIL�q��
 * �w����ƶq   
 * �@�~�W��    �Ƶ��ݿ�ƶ��q��
 * �~�ȧO EP
 * ���t�ΦW��   B5
 * �B�z�g��    ��07:00AM
 * ����B�z���  �w�]��
 * 
 * [20181102] Modified �H�H���~�B�z
 * </pre>
 * @author ���_��
 * @since 2013/12/31
 */
@SuppressWarnings("unchecked")
public class EPB5_B040 extends EP_BatchBean {
    /** log */
    private static final Logger log = Logger.getLogger(EPB5_B040.class);

    /**  �@�~�W�� */
    private static final String JOB_NAME = "EPB5_B040";

    /** �{���W�� */
    private static final String PROGRAM = "EPB5_B040";

    /** �~�ȧO */
    private static final String BUSINESS = "EP";

    /** ���t�ΦW�� */
    private static final String SUBSYSTEM = "B5";

    /** ����g�� */
    private static final String PERIOD = "��";

    /** �]�� true �Ѥ����O�p�Ƥμg���~�T��, false �Шϥ� ErrorLog ��CountManager �ۦ�g���~�T���έp�� */
    private static final boolean isAUTO_WRITELOG = false;

    private static final String INPUT_COUNT = "����q����Ƽ�";

    private static final String EMAIL_COUNT = "�o�H�ʼ�";

    private static final String ERROR_COUNT = "���~���";

    /** �d�ߪ����� */
    private BatchQueryDataSet bqds;

    /** �M�����O�@�Τ����~�T���O������ */
    private ErrorLog errorLog;

    /** �p�ƾ� */
    private CountManager countManager;

    private StringBuffer sbf;

    private static final String SQL_QUERYDTEPB103_001 = "com.cathay.ep.b5.batch.EPB5_B040.SQL_QUERYDTEPB103_001";

    private Date today;

    private String today_str;

    /** �o�e�������@�Ҳ� */
    private RZ_S00300 theRZ_S00300;

    public EPB5_B040() throws Exception {

        //�]�w�����O���غc�l,�ǤJ true �Ѥ����O�p�Ƥμg���~�T��
        super(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isAUTO_WRITELOG);

        //���~�T���O������
        countManager = new CountManager(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD);

        errorLog = new ErrorLog(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM);

        sbf = new StringBuffer();

        bqds = getBatchQueryDataSet();

        initCountManager();

        today = DATE.today();
        today_str = new SimpleDateFormat("yyyy-MM-dd").format(today);

        theRZ_S00300 = new RZ_S00300();

    }

    public void execute(String args[]) throws Exception {

        try {

            String SYS_BGN_DATE;
            String SYS_END_DATE;
            String SUB_CPY_ID_q;
            try {

                //������G�Y�L�ǤJ�ѼơA�h���t�Τ�@�������
                if (args != null && args.length > 0) {

                    SUB_CPY_ID_q = args[0];

                    if (args.length > 1) {
                        SYS_BGN_DATE = args[1];

                        if (StringUtils.isBlank(SYS_BGN_DATE)) {
                            SYS_BGN_DATE = today_str;

                        } else if (!DATE.isDate(SYS_BGN_DATE)) {
                            throw new ErrorInputException("�ǤJ�_�馳�~");
                        }

                        if (args.length > 2) {
                            SYS_END_DATE = args[2];
                            if (StringUtils.isBlank(SYS_END_DATE)) {
                                SYS_END_DATE = SYS_BGN_DATE;

                            } else if (!DATE.isDate(SYS_END_DATE)) {
                                throw new ErrorInputException("�ǤJ���馳�~");
                            } else if (SYS_END_DATE.compareTo(SYS_BGN_DATE) < 0) {
                                throw new ErrorInputException("�ǤJ����p��_��");
                            }

                        } else {
                            SYS_END_DATE = SYS_BGN_DATE;
                        }

                        sbf.append("���ǤJ������_��: ").append(SYS_BGN_DATE).append(";").append(SYS_END_DATE);
                        log.fatal(sbf.toString());
                        sbf.setLength(0);
                    } else {
                        SYS_BGN_DATE = today_str;
                        SYS_END_DATE = today_str;
                        log.fatal("���ǤJ������A�u�B�z�����:" + SYS_BGN_DATE);

                    }

                } else {
                    SUB_CPY_ID_q = "00";
                    SYS_BGN_DATE = today_str;
                    SYS_END_DATE = today_str;
                    log.fatal("���ǤJ������A�u�B�z���(00)�����:" + SYS_BGN_DATE);
                }

            } catch (Exception e) {
                setExitCode(ERROR);
                log.fatal("�Ѽƿ��~", e);
                return;
            }

            //�����
            bqds.setField("SYS_BGN_DATE", SYS_BGN_DATE);
            bqds.setField("SYS_END_DATE", SYS_END_DATE);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID_q);//�����q�O

            searchAndRetrieve(bqds, SQL_QUERYDTEPB103_001);

            int inputCount = getInputCount();
            if (inputCount == 0) {
                return;
            }

            countManager.addCountNumber(INPUT_COUNT, inputCount); //�]�w��X���

            List<Map> titleList = new ArrayList<Map>();
            Map titleMap1 = new HashMap();
            titleMap1.put("FIELD", "CRT_NO");
            titleMap1.put("FIELD_NM", "�����N��");
            titleMap1.put("FIELD_SIZE", "14");
            titleList.add(titleMap1);
            Map titleMap2 = new HashMap();
            titleMap2.put("FIELD", "CUS_NO");
            titleMap2.put("FIELD_NM", "�Ȥ�Ǹ�");
            titleMap2.put("FIELD_SIZE", "3");
            titleList.add(titleMap2);
            Map titleMap3 = new HashMap();
            titleMap3.put("FIELD", "SER_NO");
            titleMap3.put("FIELD_NM", "�y����");
            titleMap3.put("FIELD_SIZE", "3");
            titleList.add(titleMap3);
            Map titleMap4 = new HashMap();
            titleMap4.put("FIELD", "YEAR");
            titleMap4.put("FIELD_NM", "�~��");
            titleMap4.put("FIELD_SIZE", "4");
            titleList.add(titleMap4);
            Map titleMap5 = new HashMap();
            titleMap5.put("FIELD", "CLC_DIV_NO");
            titleMap5.put("FIELD_NM", "�ӿ��O");
            titleMap5.put("FIELD_SIZE", "7");
            titleList.add(titleMap5);
            Map titleMap6 = new HashMap();
            titleMap6.put("FIELD", "PROC_STS");
            titleMap6.put("FIELD_NM", "�B�z���A");
            titleMap6.put("FIELD_SIZE", "10");
            titleList.add(titleMap6);
            Map titleMap7 = new HashMap();
            titleMap7.put("FIELD", "MEMO");
            titleMap7.put("FIELD_NM", "�Ƶ�");
            titleMap7.put("FIELD_SIZE", "300");
            titleList.add(titleMap7);

            Map<String, Map<String, Object>> groupDataByKey = new HashMap<String, Map<String, Object>>();

            for (prepareFetch(); fetchData(bqds); goNext()) { //�������

                int mailcount = 0;
                try {
                    // �v���B�z
                    /*�N���q������ƨ�INFM_EMAIL(�q��EMAIL)���s�N��ƥ[�JcrtInfoList��H�oEMAIL�AEMAIL�ۦP��(�ۦPINFM_EMAIL)�u�H�X�@��*/
                    while (bqds.next()) {
                        Map mailMap = new HashMap();

                        String INFM_EMAIL = (String) bqds.getField("INFM_EMAIL");
                        if (StringUtils.isBlank(INFM_EMAIL)) {
                            setExitCode(ERROR);
                            sbf.setLength(0);
                            sbf.append("�@�~���~(e-mail�H�c����): �����N��:").append(ObjectUtils.toString(bqds.getField("CRT_NO"), ""));
                            sbf.append(", �Ȥ�Ǹ�").append(ObjectUtils.toString(bqds.getField("CUS_NO"), ""));
                            sbf.append(", �y����").append(ObjectUtils.toString(bqds.getField("SER_NO"), ""));
                            log.fatal(sbf.toString());
                            errorLog.addErrorLog("", sbf.toString());
                            sbf.setLength(0);
                            continue;
                        }

                        if (!groupDataByKey.isEmpty() && !groupDataByKey.containsKey(INFM_EMAIL)) {

                            try {

                                boolean isSendSuccess = sendMail(SUB_CPY_ID_q, groupDataByKey, titleList);
                                if (!isSendSuccess) {
                                    return;
                                }
                                mailcount++;
                            } finally {
                                groupDataByKey.clear();
                            }
                        }

                        Map groupData;
                        List<Map> crtInfoList;
                        if (groupDataByKey.isEmpty()) {
                            groupData = new HashMap<String, Map<String, Object>>();
                            groupDataByKey.put(INFM_EMAIL, groupData);

                            groupData.put("INFM_ID", ObjectUtils.toString(bqds.getField("INFM_ID"), " "));
                            groupData.put("CHG_DIV_NO", ObjectUtils.toString(bqds.getField("CHG_DIV_NO"), " "));
                            crtInfoList = new ArrayList<Map>();
                            groupData.put("crtInfoList", crtInfoList);

                        } else {
                            groupData = groupDataByKey.get(INFM_EMAIL);

                            crtInfoList = (List<Map>) groupData.get("crtInfoList");
                        }

                        mailMap.put("CRT_NO", ObjectUtils.toString(bqds.getField("CRT_NO"), ""));
                        mailMap.put("CUS_NO", ObjectUtils.toString(bqds.getField("CUS_NO"), ""));
                        mailMap.put("SER_NO", ObjectUtils.toString(bqds.getField("SER_NO"), ""));
                        mailMap.put("YEAR", ObjectUtils.toString(bqds.getField("YEAR"), ""));
                        mailMap.put("CLC_DIV_NO", ObjectUtils.toString(bqds.getField("CLC_DIV_NO"), ""));
                        mailMap.put("PROC_STS", FieldOptionList.getName("EP", "PROC_STS", (String) bqds.getField("PROC_STS")));
                        mailMap.put("MEMO", ObjectUtils.toString(bqds.getField("MEMO"), ""));

                        crtInfoList.add(mailMap);

                    }// while loop end

                } finally {

                    countManager.addCountNumber(EMAIL_COUNT, mailcount);

                    //�g�X���~��ưO���� , �C�@�����@��         
                    int count = errorLog.getErrorCountAndWriteErrorMessage();
                    countManager.addCountNumber(ERROR_COUNT, count);
                }

            } //for loop end

            if (!groupDataByKey.isEmpty()) {
                try {
                    //�̫�@�������H�H

                    boolean isSendSuccess = sendMail(SUB_CPY_ID_q, groupDataByKey, titleList);
                    if (!isSendSuccess) {
                        return;
                    }
                    countManager.addCountNumber(EMAIL_COUNT, 1);

                } finally {

                    groupDataByKey.clear();

                    //�g�X���~��ưO���� , �C�@�����@��         
                    int count = errorLog.getErrorCountAndWriteErrorMessage();
                    countManager.addCountNumber(ERROR_COUNT, count);
                }

            }

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("����ɵo�Ϳ��~", e);
        } finally {

            log.fatal(countManager);

            if (countManager != null) {
                countManager.writeLog(); //�g�J��ưO����  
            }
            // �����Ҧ����s�u
            if (bqds != null) {
                bqds.close();
            }

            printExitCode(getExitCode()); //�^�ǵ� Control_M ���T���N�X , �{���פ�
        }

    }

    //  *********************************************** Private Method  ************************************************/

    /**
     * ��l�p��
     * @throws ModuleException
     */
    private void initCountManager() throws ModuleException {
        countManager.createCountType("START");
        countManager.writeLog();
        countManager.clearCountTypeAndNumber();
        countManager.createCountType(INPUT_COUNT);
        countManager.createCountType(EMAIL_COUNT);
        countManager.createCountType(ERROR_COUNT);
    }

    /**
     * �H�eMAIL
     * @param CHG_DIV_NO
     * @param INFM_ID
     * @param INFM_EMAIL
     * @param mailList
     * @param titleList
     * @param crtInfoList
     * @param theRZ_S00300
     * @throws Exception
     */
    private boolean sendMail(String SUB_CPY_ID, Map<String, Map<String, Object>> groupDataByKey, List<Map> titleList) throws Exception {

        String INFM_EMAIL = groupDataByKey.keySet().iterator().next();

        Map<String, Object> groupData = groupDataByKey.get(INFM_EMAIL);
        List crtInfoList = (List) groupData.get("crtInfoList");

        Map infmMap = new HashMap();

        infmMap.put("USER_EMAIL", INFM_EMAIL);
        infmMap.put("DEFAULT_MAIL", MailSender.DEFAULT_MAIL);
        infmMap.put("USER_NAME", INFM_EMAIL);
        infmMap.put("USER_ID", groupData.get("INFM_ID"));
        infmMap.put("USER_DIVNO", groupData.get("CHG_DIV_NO"));
        infmMap.put("USER_DIVNM", "���ʲ��Ƶ��q��");

        List mailList = new ArrayList();
        mailList.add(infmMap);
        //[20181102] Modified �H�H���~�B�z
        try {
            String COMP_ID = new EP_B30010().getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);
            String ERR_MSG = theRZ_S00300.createRecordByDIV("EP_IB002", "EP", today, mailList, titleList, crtInfoList, COMP_ID); //EP_IB002�����Ƶ��q��
            if (StringUtils.isNotBlank(ERR_MSG)) {
                throw new ModuleException(ERR_MSG);
            }
            return true;
        } catch (Exception e) {
            if (getExitCode() == OK) {
                setExitCode(101); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�                                    
            }
            sbf.setLength(0);
            sbf.append("�H�e�H��ɵo�Ϳ��~, �����EMIL:").append(INFM_EMAIL).append(" ���e:").append(crtInfoList);
            log.fatal(sbf.toString(), e);
            sbf.setLength(0);
            sbf.append("�H�e�H��ɵo�Ϳ��~, �����EMIL:").append(INFM_EMAIL);
            errorLog.addErrorLog(sbf.toString(), e);
            sbf.setLength(0);
            return false;
        }

    }

}
