package com.cathay.ep.b5.batch;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.batch.CountManager;
import com.cathay.common.util.batch.ErrorLog;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.b1.module.EP_B10010;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.b3.module.EP_B30030;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPB102;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPB303;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.rz.s0.module.RZ_S00300;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchQueryDataSet;

/**
 * 
 * <pre>
 * Date    Version Description Author
 * 2013/11/19  1.0 Created ���կ�
 * 2018/02/01  �t�X��ؽվ� ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ���e�פ������s
 * �{���W��    EPB5_B010.java
 * �@�~�覡    BATCH
 * ���n����    �����L���e�פ����, �w��e�@�Ѩ������������, �M�Ũ�j�ӫǧO�����T
 * (��s ������ + 1 = ���餧�ץ�)
 * �w����ƶq   
 * �@�~�W��    ���e�פ������s�j�ӫǧO������
 * �~�ȧO EP
 * ���t�ΦW��   B5
 * �B�z�g��    ��06:00AM
 * ����B�z���  �w�]��
 * 
 * [20181102] �ק�� Modified �H�H���~�B�z
 * </pre>
 * @author �¶��� 
 * @since 2014/1/8
 */
@SuppressWarnings("unchecked")
public class EPB5_B010 extends EP_BatchBean { //�~��BatchBean

    private static final Logger log = Logger.getLogger(EPB5_B010.class); //log

    private static final String JOB_NAME = "EPB5_B010"; //�@�~�W��

    private static final String PROGRAM = "EPB5_B010"; //�{���W��

    private static final String BUSINESS = "EP"; //�~�ȧO

    private static final String SUBSYSTEM = "B5"; //���t�ΦW��

    private static final String PERIOD = "��"; //����g��

    //�]�� true �Ѥ����O�p�Ƥμg���~�T��, false �Шϥ� ErrorLog ��CountManager �ۦ�g���~�T���έp��
    private static final boolean isAUTO_WRITELOG = false;

    private static final String INPUT_COUNT = "��J���";

    private static final String UPD_COUNT = "��s�ӯ�����";

    private static final String OUTPUT_COUNT = "EMAIL����";

    private static final String ERROR_COUNT = "���~���";

    private static final String MAILERR_COUNT = "EMAIL���~���";

    private static final String CHG_ID = "EPB5_B010";

    private static final String CHG_NAME = "���e�פ�";

    private static final String NEW_TRN_KIND = "EPB006"; //�����פ�

    private static final String SQL_query_001 = "com.cathay.ep.b5.batch.EPB5_B010.SQL_query_001";

    /**�d�ߪ�����*/
    private BatchQueryDataSet bqds;

    /** �M�����O�@�Τ����~�T���O������ */
    private ErrorLog errorLog;

    /**�p�ƾ�*/
    private CountManager countManager;

    private StringBuilder sb;

    /**�߮׿�J���@�Ҳ�*/
    private EP_B30010 theEP_B30010;

    /**�򥻸�ƺ��@�Ҳ�*/
    private EP_A10010 theEP_A10010;

    /**�ӯ���O�����@�Ҳ�*/
    private EP_B10020 theEP_B10020;

    /** ������ƺ��@�Ҳ�*/
    private EP_B10010 theEP_B10010;

    /** �����״��ܧ���@�Ҳ�*/
    private EP_B30030 theEP_B30030;

    /**EMAIL�H�o�]�w���@�Ҳ�*/
    private EP_Z10030 theEP_Z10030;

    /**�o�e�������@�Ҳ�*/
    private RZ_S00300 theRZ_S00300;

    private Date today;

    private Timestamp UPD_TIME;

    private String strUPD_TIME;

    private List<Map> crtInfoList;

    private List<Map> mailList;

    public EPB5_B010() throws Exception {

        //�]�w�����O���غc�l,�ǤJ true �Ѥ����O�p�Ƥμg���~�T��
        super(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isAUTO_WRITELOG);

        //���~�T���O������
        countManager = new CountManager(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD);

        errorLog = new ErrorLog(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM);

        sb = new StringBuilder();

        theEP_B30010 = new EP_B30010();
        theEP_A10010 = new EP_A10010();
        theEP_B10020 = new EP_B10020();
        theEP_B10010 = new EP_B10010();
        theEP_B30030 = new EP_B30030();
        theEP_Z10030 = new EP_Z10030();
        theRZ_S00300 = new RZ_S00300();

        initCountManager();

        today = DATE.today();

        UPD_TIME = DATE.currentTime();

        strUPD_TIME = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS").format(UPD_TIME);

        crtInfoList = new ArrayList();

        mailList = new ArrayList();
    }

    public void execute(String args[]) throws Exception { //����妸�@�~      

        try {

            String SUB_CPY_ID_q; //�����q�O
            String PROC_STR_DATE; //�B�z����_��
            String PROC_END_DATE;//�B�z�������

            try {

                if (args == null || args.length == 0 || StringUtils.isBlank(args[0])) {
                    String CURRENT_DATE = new SimpleDateFormat("yyyy-MM-dd").format(today);
                    PROC_STR_DATE = CURRENT_DATE;
                    PROC_END_DATE = CURRENT_DATE;
                    SUB_CPY_ID_q = "00";
                    sb.append("���ǤJ�ѼơA�u�B�z���(00)�����:").append(PROC_STR_DATE);
                    String memo = sb.toString();
                    sb.setLength(0);
                    log.fatal(memo);

                } else {
                    SUB_CPY_ID_q = args[0];
                    if (StringUtils.isBlank(SUB_CPY_ID_q)) {
                        SUB_CPY_ID_q = "00";
                        log.fatal("�L�ǤJ�����q�O,�u�B�z���(00)��");
                    }
                    if (args.length > 1) {
                        PROC_STR_DATE = args.length > 1 ? args[1] : null;
                        PROC_END_DATE = args.length > 2 ? args[2] : null;

                        if (!DATE.isDate(PROC_STR_DATE)) {
                            sb.append("PROC_STR_DATE = ").append(PROC_STR_DATE).append("; ");
                        }
                        if (StringUtils.isBlank(PROC_END_DATE)) {
                            PROC_END_DATE = PROC_STR_DATE;

                        } else {
                            if (!DATE.isDate(PROC_END_DATE)) {
                                sb.append("PROC_END_DATE = ").append(PROC_END_DATE).append("; ");
                            }

                            if (sb.length() == 0 && DATE.diffDay(PROC_END_DATE, PROC_STR_DATE) > 0) {
                                sb.append("�B�z����_��ݤp�󵥩󨴤�");
                            }
                        }

                        if (sb.length() > 0) {
                            String chkMsg = sb.toString();
                            sb.setLength(0);
                            throw new ErrorInputException(chkMsg);
                        }

                        sb.append("���ǤJ�B�z����_��: ");
                        sb.append(PROC_STR_DATE).append("; ");
                        sb.append(PROC_END_DATE);
                        String memo = sb.toString();
                        sb.setLength(0);
                        log.fatal(memo);
                    } else {
                        String CURRENT_DATE = new SimpleDateFormat("yyyy-MM-dd").format(today);
                        PROC_STR_DATE = CURRENT_DATE;
                        PROC_END_DATE = CURRENT_DATE;
                        sb.append("���ǤJ�B�z����A�u�B�z�����:").append(PROC_STR_DATE);
                        String memo = sb.toString();
                        sb.setLength(0);
                        log.fatal(memo);
                    }
                }

            } catch (Exception e) {
                String memo = "�ǤJ�ѼƦ��~";
                log.fatal(memo, e);
                errorLog.addErrorLog(memo, e);
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                countManager.addCountNumber(ERROR_COUNT, errorCount);
                throw e;
            }

            try {

                bqds = getBatchQueryDataSet(); //���ͬd�ߪ�����
                bqds.setField("PROC_STR_DATE", PROC_STR_DATE);
                bqds.setField("PROC_END_DATE", PROC_END_DATE);
                bqds.setField("SUB_CPY_ID", SUB_CPY_ID_q);
                searchAndRetrieve(bqds, SQL_query_001);

            } catch (Exception e) {
                setExitCode(ERROR);
                String memo = "Ū�����`";
                log.fatal(memo, e);
                errorLog.addErrorLog(memo, e);
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                countManager.addCountNumber(ERROR_COUNT, errorCount);
                return;
            }

            int inputCount = getInputCount();

            if (inputCount == 0) {
                log.fatal("�d�L���");
                return;
            }

            countManager.addCountNumber(INPUT_COUNT, inputCount); //�]�w��X���

            //�������TITLE: 
            List<Map> titleList = new ArrayList<Map>();
            setTitleList(titleList, "CRT_NO", "�����N��", 14);
            setTitleList(titleList, "CUS_NO", "�Ȥ�Ǹ�", 3);
            setTitleList(titleList, "CLC_DIV_NO", "��J���", 7);
            setTitleList(titleList, "INPUT_NAME", "��J�H��", 10);
            setTitleList(titleList, "PROC_STS", "�B�z���A", 20);
            Map<String, Map<String, Map<String, List<Map>>>> groupMap = new HashMap<String, Map<String, Map<String, List<Map>>>>();

            for (prepareFetch(); fetchData(bqds); goNext()) { //�������

                try {

                    // �v���B�z
                    while (bqds.next()) {
                        String SUB_CPY_ID = (String) bqds.getField("SUB_CPY_ID");
                        String CRT_NO = (String) bqds.getField("CRT_NO");
                        String BLD_CD = (String) bqds.getField("BLD_CD");

                        //�̤����q�O���������s��
                        if (!groupMap.isEmpty() && !groupMap.containsKey(SUB_CPY_ID)) {
                            try {
                                this.transactionByGroup(groupMap, titleList);
                            } finally {
                                groupMap.clear();
                                crtInfoList.clear();
                                mailList.clear();
                            }
                        }
                        Map<String, Map<String, List<Map>>> BLD_CDsMap;
                        if (groupMap.isEmpty()) {
                            BLD_CDsMap = new HashMap<String, Map<String, List<Map>>>();
                            groupMap.put(SUB_CPY_ID, BLD_CDsMap);
                        } else {
                            BLD_CDsMap = groupMap.get(SUB_CPY_ID);
                        }

                        Map<String, List<Map>> CRT_NOsMap;
                        if (BLD_CDsMap.isEmpty() || !BLD_CDsMap.containsKey(BLD_CD)) {
                            CRT_NOsMap = new HashMap<String, List<Map>>();
                            BLD_CDsMap.put(BLD_CD, CRT_NOsMap);
                        } else {
                            CRT_NOsMap = BLD_CDsMap.get(BLD_CD);
                        }

                        List<Map> rtnList;
                        if (CRT_NOsMap.isEmpty() || !CRT_NOsMap.containsKey(CRT_NO)) {
                            rtnList = new ArrayList();
                            CRT_NOsMap.put(CRT_NO, rtnList);
                        } else {
                            rtnList = CRT_NOsMap.get(CRT_NO);
                        }
                        rtnList.add(VOTool.dataSetToMap(bqds));

                    }// while loop end

                } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                    errorLog.addErrorLog("���榳�~", e);
                    throw e; //�Y�o�Ϳ��~�h�{���X�פ�

                } finally {
                    int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                    countManager.addCountNumber(ERROR_COUNT, errorCount);//�������~���
                }

            } //for loop end

            //�̫�@�s
            try {
                if (!groupMap.isEmpty()) {
                    try {
                        this.transactionByGroup(groupMap, titleList);
                    } finally {
                        groupMap.clear();
                        crtInfoList.clear();
                        mailList.clear();
                    }
                }
            } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                errorLog.addErrorLog("���榳�~", e);
                throw e; //�Y�o�Ϳ��~�h�{���X�פ�

            } finally {
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                countManager.addCountNumber(ERROR_COUNT, errorCount);//�������~���

            }

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("����ɵo�Ϳ��~", e);

        } finally {

            log.fatal(countManager); //����

            if (countManager != null) {
                countManager.writeLog(); //�g�J��ưO����  
            }

            // �����Ҧ����s�u
            if (bqds != null) {
                bqds.close();
            }

            printExitCode(getExitCode()); //�^�ǵ� Control_M ���T���N�X , �{���פ�
        }
    }

    //  *********************************************** Private Method  ************************************************/
    /**
     * ��l�p��
     * @throws ModuleException
     */
    private void initCountManager() throws ModuleException {

        countManager.createCountType("START");
        countManager.writeLog();
        countManager.clearCountTypeAndNumber();
        countManager.createCountType(INPUT_COUNT);
        countManager.createCountType(ERROR_COUNT);
        countManager.createCountType(UPD_COUNT);
        countManager.createCountType(OUTPUT_COUNT);
        countManager.createCountType(MAILERR_COUNT);

    }

    /**
     * �]�w�ץ�_�����ӯ����ܧ����(DTEPB303)���� 
     * @param EPB303Vo
     */
    private void setDTEPB303Vo_Fields(DTEPB303 EPB303Vo, Map rtnMap) {

        EPB303Vo.setCRT_NO((String) rtnMap.get("CRT_NO"));//�����N�� 
        EPB303Vo.setCUS_NO((Integer) rtnMap.get("CUS_NO"));//�Ȥ�Ǹ� 
        EPB303Vo.setCUS_NAME((String) rtnMap.get("CUS_NAME"));//�Ȥ�m�W 
        EPB303Vo.setID((String) rtnMap.get("ID"));//�ҥ󸹽X 
        EPB303Vo.setJOB_TYPE((String) rtnMap.get("JOB_TYPE"));//��~�O 
        EPB303Vo.setRNT_TYPE((String) rtnMap.get("RNT_TYPE"));//�ӯ��O 
        EPB303Vo.setRNT_STR_DATE((Date) rtnMap.get("RNT_STR_DATE"));//�_����� 
        EPB303Vo.setRNT_END_DATE((Date) rtnMap.get("RNT_END_DATE"));//������� 
        EPB303Vo.setPMS_TYPE((String) rtnMap.get("PMS_TYPE"));//�㯲�覡 
        EPB303Vo.setRNT_SIZE((BigDecimal) rtnMap.get("RNT_SIZE"));//�ӯ��W�� 
        EPB303Vo.setRNT_AMT((BigDecimal) rtnMap.get("RNT_AMT"));//�믲�� 
        EPB303Vo.setPMS_AMT((BigDecimal) rtnMap.get("PMS_AMT"));//��� 
        EPB303Vo.setNEXT_PAY_DATE((Date) rtnMap.get("NEXT_PAY_DATE"));//�U����ú�� 
        EPB303Vo.setDCT_TYPE((String) rtnMap.get("DCT_TYPE"));//���ڤ覡 
        EPB303Vo.setSLRY_ID((String) rtnMap.get("SLRY_ID"));//���~ID 
        EPB303Vo.setADJ_KIND((String) rtnMap.get("ADJ_KIND"));//�կ����O 
        EPB303Vo.setMON_BRK((String) rtnMap.get("MON_BRK"));//�O�_���뵲�� 
        EPB303Vo.setMON_BRK_EDATE((Date) rtnMap.get("MON_BRK_EDATE"));//�}�먴�� 
        EPB303Vo.setORG_RNT_AMT((BigDecimal) rtnMap.get("ORG_RNT_AMT"));//��l���� 
        EPB303Vo.setACPT_BANK_NO((String) rtnMap.get("ACPT_BANK_NO"));//���ڦ�w 
        EPB303Vo.setACPT_ACNT_NO((String) rtnMap.get("ACPT_ACNT_NO"));//���ڱb�� 
        EPB303Vo.setCUS_ID((String) rtnMap.get("CUS_ID"));//�Ȥ�s�� 
        EPB303Vo.setBOSS_NAME((String) rtnMap.get("BOSS_NAME"));//�t�d�H 
        EPB303Vo.setCOMP_ZIP_CODE((String) rtnMap.get("COMP_ZIP_CODE"));//���q�l���ϸ� 
        EPB303Vo.setCOMP_ADDR((String) rtnMap.get("COMP_ADDR"));//���q�n�O�a�} 
        EPB303Vo.setCONT_NAME((String) rtnMap.get("CONT_NAME"));//�p���H 
        EPB303Vo.setCONT_MOBIL_NO((String) rtnMap.get("CONT_MOBIL_NO"));//�p���H��� 
        EPB303Vo.setTEL_AREA((String) rtnMap.get("TEL_AREA"));//�q�ܰϽX 
        EPB303Vo.setTEL((String) rtnMap.get("TEL"));//�q�� 
        EPB303Vo.setTEL_EXT((String) rtnMap.get("TEL_EXT"));//�q�ܤ��� 
        EPB303Vo.setCONT_ZIP_CODE((String) rtnMap.get("CONT_ZIP_CODE"));//�q�T�a�l���ϸ� 
        EPB303Vo.setCONT_ADDR((String) rtnMap.get("CONT_ADDR"));//�q�T�a�} 
        EPB303Vo.setCUS_EMAIL((String) rtnMap.get("CUS_EMAIL"));//�Ȥ�EMAIL 
        EPB303Vo.setFILE_NO((String) rtnMap.get("FILE_NO"));//�ɮ׽s�� 
        EPB303Vo.setMEMO((String) rtnMap.get("MEMO"));//�Ƶ� 
        EPB303Vo.setSUB_CPY_ID((String) rtnMap.get("SUB_CPY_ID"));//�����q�O 
        EPB303Vo.setDATA_TYPE("A");//������� 
        EPB303Vo.setCUS_STS("3");//�Ȥ᪬�p 

    }

    /**
     * �]�w����_�ӯ�����(DTEPB102)���� 
     * @param EPB102Vo
     */
    private void setDTEPB102Vo_Fields(DTEPB102 EPB102Vo, Map rtnMap) {
        EPB102Vo.setCRT_NO((String) rtnMap.get("CRT_NO"));//�����N�� 
        EPB102Vo.setCUS_NO((Integer) rtnMap.get("CUS_NO"));//�Ȥ�Ǹ� 
        EPB102Vo.setCUS_NAME((String) rtnMap.get("CUS_NAME"));//�Ȥ�m�W 
        EPB102Vo.setID((String) rtnMap.get("ID"));//�ҥ󸹽X 
        EPB102Vo.setJOB_TYPE((String) rtnMap.get("JOB_TYPE"));//��~�O 
        EPB102Vo.setRNT_TYPE((String) rtnMap.get("RNT_TYPE"));//�ӯ��O 
        EPB102Vo.setRNT_STR_DATE((Date) rtnMap.get("RNT_STR_DATE"));//�_����� 
        EPB102Vo.setRNT_END_DATE((Date) rtnMap.get("RNT_END_DATE"));//������� 
        EPB102Vo.setPMS_TYPE((String) rtnMap.get("PMS_TYPE"));//�㯲�覡 
        EPB102Vo.setRNT_SIZE((BigDecimal) rtnMap.get("RNT_SIZE"));//�ӯ��W�� 
        EPB102Vo.setRNT_AMT((BigDecimal) rtnMap.get("RNT_AMT"));//�믲�� 
        EPB102Vo.setPMS_AMT((BigDecimal) rtnMap.get("PMS_AMT"));//��� 
        EPB102Vo.setNEXT_PAY_DATE((Date) rtnMap.get("NEXT_PAY_DATE"));//�U����ú�� 
        EPB102Vo.setCUS_STS("3");//�Ȥ᪬�p 
        EPB102Vo.setDCT_TYPE((String) rtnMap.get("DCT_TYPE"));//���ڤ覡 
        EPB102Vo.setSLRY_ID((String) rtnMap.get("SLRY_ID"));//���~ID 
        EPB102Vo.setADJ_KIND((String) rtnMap.get("ADJ_KIND"));//�կ����O 
        EPB102Vo.setMON_BRK((String) rtnMap.get("MON_BRK"));//�O�_���뵲�� 
        EPB102Vo.setMON_BRK_EDATE((Date) rtnMap.get("MON_BRK_EDATE"));//�}�먴�� 
        EPB102Vo.setORG_RNT_AMT((BigDecimal) rtnMap.get("ORG_RNT_AMT"));//��l���� 
        EPB102Vo.setACPT_BANK_NO((String) rtnMap.get("ACPT_BANK_NO"));//���ڦ�w 
        EPB102Vo.setACPT_ACNT_NO((String) rtnMap.get("ACPT_ACNT_NO"));//���ڱb�� 
        EPB102Vo.setCUS_ID((String) rtnMap.get("CUS_ID"));//�Ȥ�s�� 
        EPB102Vo.setBOSS_NAME((String) rtnMap.get("BOSS_NAME"));//�t�d�H 
        EPB102Vo.setCOMP_ZIP_CODE((String) rtnMap.get("COMP_ZIP_CODE"));//���q�l���ϸ� 
        EPB102Vo.setCOMP_ADDR((String) rtnMap.get("COMP_ADDR"));//���q�n�O�a�} 
        EPB102Vo.setCONT_NAME((String) rtnMap.get("CONT_NAME"));//�p���H 
        EPB102Vo.setCONT_MOBIL_NO((String) rtnMap.get("CONT_MOBIL_NO"));//�p���H��� 
        EPB102Vo.setTEL_AREA((String) rtnMap.get("TEL_AREA"));//�q�ܰϽX 
        EPB102Vo.setTEL((String) rtnMap.get("TEL"));//�q�� 
        EPB102Vo.setTEL_EXT((String) rtnMap.get("TEL_EXT"));//�q�ܤ��� 
        EPB102Vo.setCONT_ZIP_CODE((String) rtnMap.get("CONT_ZIP_CODE"));//�q�T�a�l���ϸ� 
        EPB102Vo.setCONT_ADDR((String) rtnMap.get("CONT_ADDR"));//�q�T�a�} 
        EPB102Vo.setCUS_EMAIL((String) rtnMap.get("CUS_EMAIL"));//�Ȥ�EMAIL 
        EPB102Vo.setFILE_NO((String) rtnMap.get("FILE_NO"));//�ɮ׽s�� 
        EPB102Vo.setMEMO((String) rtnMap.get("MEMO"));//�Ƶ� 
        EPB102Vo.setCONT_CHG_ID((String) rtnMap.get("CONT_CHG_ID"));//�q�T���ʤH�� 
        EPB102Vo.setCONT_CHG_NAME((String) rtnMap.get("CONT_CHG_NAME"));//�q�T���ʩm�W 
        EPB102Vo.setCONT_CHG_DATE((Timestamp) rtnMap.get("CONT_CHG_DATE"));//�q�T���ʤ�� 
        EPB102Vo.setCONT_CHG_APLYNO((String) rtnMap.get("CONT_CHG_APLYNO"));//�q�T���ʨ��s 
        EPB102Vo.setSUB_CPY_ID((String) rtnMap.get("SUB_CPY_ID"));//�����q�O 

    }

    /**
     *  ��s�j�Ӹ��
     * @param BLD_CD
     * @param UPD_TIME
     * @param NEW_APLY_NO
     * @throws ModuleException
     * @throws SQLException
     */
    private void updateBLD_CD(String BLD_CD, String UPD_TIME, String NEW_APLY_NO) throws ModuleException, SQLException {

        DTEPB301 B301Vo = VOTool.mapToVO(DTEPB301.class, theEP_B30010.queryMap(NEW_APLY_NO));
        //��s�j�Ӹ�T
        theEP_A10010.updateSum(BLD_CD, B301Vo, UPD_TIME);
    }

    /**
     *  ��s�������p
     * @param CRTMap
     * @param NEW_APLY_NO
     * @throws ModuleException
     * @throws SQLException
     */
    private void updateCRT_NO(Map CRTMap, String NEW_APLY_NO) throws ModuleException, SQLException {
        String keyCRT_NO = MapUtils.getString(CRTMap, "CRT_NO");
        String keySUB_CPY_ID = MapUtils.getString(CRTMap, "SUB_CPY_ID");

        Map rtnMapNew = theEP_B10020.getCrtSum(keySUB_CPY_ID, keyCRT_NO, null, "1", false);
        //���o���īȤ��
        Map<String, String> B102Map = new HashMap<String, String>();
        B102Map.put("SUB_CPY_ID", keySUB_CPY_ID);
        B102Map.put("CRT_NO", keyCRT_NO);
        B102Map.put("QuerySts", "1");
        Map B101Map = new HashMap();
        boolean hasB102 = false;
        try {
            theEP_B10020.queryList(B102Map);
            hasB102 = true;
        } catch (DataNotFoundException dnfe) {
            log.fatal(dnfe);
            B101Map.put("CRT_STS", "4");//����פ�
        }

        B101Map.put("SUB_CPY_ID", keySUB_CPY_ID);
        B101Map.put("BLD_CD", MapUtils.getString(CRTMap, "BLD_CD"));
        B101Map.put("CRT_NO", keyCRT_NO);
        B101Map.put("UPD_TRN_KIND", NEW_TRN_KIND);
        B101Map.put("UPD_DATE", MapUtils.getString(CRTMap, "UPD_TIME"));
        B101Map.put("UPD_APLY_NO", NEW_APLY_NO);
        B101Map.put("CHG_DIV_NO", MapUtils.getString(CRTMap, "INPUT_DIV_NO"));
        B101Map.put("CHG_ID", CHG_ID);
        B101Map.put("CHG_NAME", CHG_NAME);
        //103.05.14�P�z�p�T�{,�ȩ����״�(����)����s�����`�W��, �`����, �`�����T, ��L�ܧ�O�d�����¸�T�H�Ѭd�� 103.05.19 �Y�������ĩӯ���h����s�����W�Ƥ��`���B
        if (hasB102) {
            B101Map.put("RNT_TOT_SIZE", rtnMapNew.get("SUM_RNT_SIZE"));
            B101Map.put("RNT_TOT_AMT", rtnMapNew.get("SUM_RNT_AMT"));
            B101Map.put("PMS_TOT_AMT", rtnMapNew.get("SUM_PMS_AMT"));
        }
        theEP_B10010.updatePartCrtInfo(B101Map);
    }

    /**
     * EMAIL����]�w
     * @param titleList
     * @param FIELD
     * @param FIELD_NM
     * @param FIELD_SIZE
     */
    private void setTitleList(List<Map> titleList, String FIELD, String FIELD_NM, int FIELD_SIZE) {
        Map<String, Object> styleMap = new HashMap<String, Object>();
        styleMap.put("FIELD", FIELD);
        styleMap.put("FIELD_NM", FIELD_NM);
        styleMap.put("FIELD_SIZE", FIELD_SIZE);
        titleList.add(styleMap);
    }

    /**
     * �H�eEmail
     * @param keySUB_CPY_ID
     * @param crtInfoList
     * @param mailList
     * @param titleList
     * @return
     * @throws ModuleException
     */
    private boolean sendMail(String keySUB_CPY_ID, List<Map> crtInfoList, List<Map> mailList, List<Map> titleList) throws ModuleException {

        //�H�H
        //���o�������q�q��MAIL LIST�ñH�o�e�������q��email�q��
        try {
            List<DTEPZ103> rtnMailList = theEP_Z10030.getMailList(keySUB_CPY_ID, "EP_IB004").get(keySUB_CPY_ID);//EP_IB004: ���e�פ������s�q��

            for (DTEPZ103 Z103Vo : rtnMailList) {
                Map mailMap = new HashMap();
                mailMap.put("USER_ID", Z103Vo.getID());
                mailMap.put("USER_DIVNO", Z103Vo.getCHG_DIV_NO());
                mailMap.put("USER_DIVNM", "���ʲ����e�פ������s");
                mailMap.put("USER_EMAIL", Z103Vo.getEMAIL());
                mailMap.put("USER_NAME", Z103Vo.getNAME());
                mailList.add(mailMap);
            }
        } catch (DataNotFoundException dnfe) {
            if (new EP_Z00030().isAccountSubCpy(keySUB_CPY_ID) && getExitCode() == OK) {//�D��جd�Lmail�������`
                setExitCode(101); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�                                    
            }
            sb.setLength(0);
            sb.append("�]�w�ɬd�L���e�פ������s�q��EMAIL, �����q�O: ").append(keySUB_CPY_ID).append(", ���e:").append(crtInfoList);
            log.fatal(sb.toString(), dnfe);
            sb.setLength(0);
            sb.append("�]�w�ɬd�L���e�פ������s�q��EMAIL, �����q�O: ").append(keySUB_CPY_ID);
            errorLog.addErrorLog("", sb.toString());
            sb.setLength(0);
            return false;
        }

        String COMP_ID = new EP_B30010().getCOMP_IDfrSUB_CPY_ID(keySUB_CPY_ID);
        log.fatal("@@@@ COMP_ID::" + COMP_ID);
        //�H�oEMAIL
        //[20181102] Modified �H�H���~�B�z
        try {
            String ERR_MSG = theRZ_S00300.createRecordByDIV("EP_IB004", "EP", today, mailList, titleList, crtInfoList, COMP_ID);
            if (StringUtils.isNotBlank(ERR_MSG)) {
                throw new ModuleException(ERR_MSG);
            }

        } catch (Exception e) {
            if (getExitCode() == OK) {
                setExitCode(101); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            }
            log.fatal("�H�e�H��ɵo�Ϳ��~", e);
        }

        return true;

    }

    /**
     * �������By�s��
     * @param groupMap
     * @param titleList
     * @param today
     * @throws Exception
     */
    private void transactionByGroup(Map<String, Map<String, Map<String, List<Map>>>> groupMap, List<Map> titleList) throws Exception {

        int UPD_COUNT_NUM = 0;
        int OUT_COUNT_NUM = 0;
        int mailErrCount = 0;

        Iterator entries = groupMap.entrySet().iterator();
        entries.hasNext();//�u���@��
        Entry<String, Map<String, Map<String, List<Map>>>> thisEntry = (Entry<String, Map<String, Map<String, List<Map>>>>) entries.next();
        String keySUB_CPY_ID = thisEntry.getKey();

        Map<String, Map<String, List<Map>>> BLD_CDsMap = thisEntry.getValue();
        Iterator entries2 = BLD_CDsMap.entrySet().iterator();
        Integer logCUS_NO = null;
        String logCRT_NO = null;
        String logBLD_CD = null;

        try {

            try {

                Transaction.begin();

                try {

                    while (entries2.hasNext()) {//�v���j�ӥN���B�z
                        Entry<String, Map<String, List<Map>>> thisEntry2 = (Entry<String, Map<String, List<Map>>>) entries2.next();
                        String keyBLD_CD = thisEntry2.getKey();
                        Map<String, List<Map>> CRT_NsOMap = thisEntry2.getValue();
                        Iterator entries3 = CRT_NsOMap.entrySet().iterator();
                        String NEW_APLY_NO_byBLD_CD = null;
                        logBLD_CD = keyBLD_CD;
                        while (entries3.hasNext()) {//�v�������N���B�z
                            Entry<String, List<Map>> thisEntry3 = (Entry<String, List<Map>>) entries3.next();
                            String keyCRT_NO = thisEntry3.getKey();
                            List<Map> CRT_NOList = thisEntry3.getValue();
                            String NEW_APLY_NO = null;
                            logCRT_NO = keyCRT_NO;
                            // //�P�@�����N������
                            for (Map rtnMap : CRT_NOList) {
                                Integer CUS_NO = (Integer) rtnMap.get("CUS_NO");
                                String INPUT_DIV_NO = (String) rtnMap.get("INPUT_DIV_NO");
                                String INPUT_NAME = (String) rtnMap.get("INPUT_NAME");
                                String INPUT_ID = (String) rtnMap.get("INPUT_ID");
                                boolean IS_UPD_RM = false;
                                boolean IS_UPD_CAR = false;
                                boolean rmHasData = false;
                                boolean carHasData = false;
                                logCUS_NO = CUS_NO;

                                //���o�ǧO�ݳB�z���, ����ݳB�z���
                                Map reqMap = new HashMap();
                                reqMap.put("SUB_CPY_ID", keySUB_CPY_ID);
                                reqMap.put("CRT_NO", keyCRT_NO);
                                reqMap.put("CUS_NO", CUS_NO);
                                try {
                                    theEP_B10020.queryRm(reqMap);
                                    rmHasData = true;
                                } catch (DataNotFoundException dnfe) {
                                    log.fatal(dnfe);
                                }
                                try {
                                    theEP_B10020.queryCar(reqMap);
                                    carHasData = true;
                                } catch (DataNotFoundException dnfe) {
                                    log.fatal(dnfe);
                                }

                                //�s�W�ץ��� 
                                reqMap.clear();
                                reqMap.put("SUB_CPY_ID", keySUB_CPY_ID);
                                reqMap.put("BLD_CD", keyBLD_CD);
                                reqMap.put("CRT_NO", keyCRT_NO);
                                reqMap.put("UPD_TRN_KIND", NEW_TRN_KIND);
                                reqMap.put("UPD_DATE", UPD_TIME);
                                reqMap.put("CHG_ID", INPUT_ID);
                                reqMap.put("CHG_DIV_NO", INPUT_DIV_NO);
                                reqMap.put("CHG_NAME", CHG_NAME);
                                if (NEW_APLY_NO == null) {//�P�@�����N���u���@��
                                    NEW_APLY_NO = theEP_B30010.insertForUpdMain(reqMap);
                                }

                                reqMap.put("APLY_NO", NEW_APLY_NO);
                                reqMap.put("CUS_NO", CUS_NO);
                                reqMap.put("INPUT_NAME_EPB301", CHG_NAME);
                                reqMap.put("INPUT_ID_EPB301", CHG_ID);
                                reqMap.put("INPUT_DIV_NO_EPB301", INPUT_DIV_NO);

                                if (rmHasData) {
                                    //��s�ǧO������D��
                                    theEP_B30030.updRmProc(reqMap, NEW_TRN_KIND, UPD_TIME);
                                    IS_UPD_RM = true;
                                }

                                if (carHasData) {
                                    //�M�Ũ���B�z
                                    theEP_B30030.updCarProc(reqMap, NEW_TRN_KIND, UPD_TIME);
                                    IS_UPD_CAR = true;
                                }

                                //��s�ӵ��ӯ��᪬�A
                                DTEPB303 EPB303Vo = new DTEPB303();
                                this.setDTEPB303Vo_Fields(EPB303Vo, rtnMap);
                                EPB303Vo.setAPLY_NO(NEW_APLY_NO);

                                //�s�W�ץ�ӯ�������
                                theEP_B10020.insertDTEPB303(EPB303Vo, "U", null); //�@�~���� U �ק�

                                DTEPB102 EPB102Vo = new DTEPB102();
                                this.setDTEPB102Vo_Fields(EPB102Vo, rtnMap);
                                EPB102Vo.setCHG_DATE(UPD_TIME);
                                EPB102Vo.setCHG_DIV_NO(INPUT_DIV_NO);
                                EPB102Vo.setCHG_ID(CHG_ID);
                                EPB102Vo.setCHG_NAME(CHG_NAME);
                                EPB102Vo.setAPLY_NO(NEW_APLY_NO);
                                EPB102Vo.setTRN_KIND(NEW_TRN_KIND);
                                EPB102Vo.setRNT_CHG_ID(CHG_ID);
                                EPB102Vo.setRNT_CHG_NAME(CHG_NAME);
                                EPB102Vo.setRNT_CHG_DATE(UPD_TIME);
                                EPB102Vo.setRNT_CHG_APLYNO(NEW_APLY_NO);
                                EPB102Vo.setRNT_CHG_TRNKD(NEW_TRN_KIND);

                                theEP_B10020.updateDTEPB102(EPB102Vo, strUPD_TIME, NEW_APLY_NO, NEW_TRN_KIND);
                                UPD_COUNT_NUM++;

                                //�B�z�H�H���
                                try {
                                    Map textMap = new HashMap();
                                    textMap.put("CRT_NO", keyCRT_NO);
                                    textMap.put("CUS_NO", CUS_NO);
                                    textMap.put("CLC_DIV_NO", INPUT_DIV_NO);
                                    textMap.put("INPUT_NAME", INPUT_NAME);
                                    String PROC_STS;
                                    if (IS_UPD_RM && IS_UPD_CAR) {
                                        PROC_STS = "�ǧO�Ψ���w�M��";
                                    } else if (IS_UPD_RM) {
                                        PROC_STS = "�ǧO�w�M��";
                                    } else if (IS_UPD_CAR) {
                                        PROC_STS = "����w�M��";
                                    } else {
                                        PROC_STS = "�ӯ����Ƥw��s";
                                    }

                                    textMap.put("PROC_STS", PROC_STS);
                                    crtInfoList.add(textMap);

                                    List<Map> mailInfos = theEP_Z10030.getMailByID(keySUB_CPY_ID, INPUT_DIV_NO, INPUT_ID, "1");

                                    if (mailInfos == null || mailInfos.size() <= 0) {
                                        log.fatal("�d�L�ӤHmail,�������`");
                                    } else {
                                        //���o����J��EMAIL
                                        Map iptMailListOne = mailInfos.get(0);

                                        // EMAIL����:1�ӤH2���3�ӤH�γ��(����쪺EMAIL�w�]�b����w��)
                                        Map mailMap = new HashMap();
                                        mailMap.put("USER_ID", MapUtils.getString(iptMailListOne, "ID"));
                                        mailMap.put("USER_DIVNO", MapUtils.getString(iptMailListOne, "CHG_DIV_NO"));
                                        mailMap.put("USER_DIVNM", "���ʲ����e�פ������s");
                                        mailMap.put("USER_EMAIL", MapUtils.getString(iptMailListOne, "EMAIL"));
                                        mailMap.put("USER_NAME", MapUtils.getString(iptMailListOne, "NAME"));
                                        mailList.add(mailMap);
                                    }

                                } catch (Exception e) {
                                    mailErrCount++;
                                    if (new EP_Z00030().isAccountSubCpy(keySUB_CPY_ID) && getExitCode() == OK) {//�D��جd�Lmail�������`
                                        setExitCode(101);
                                    }
                                    log.fatal("EMAIL�B�z���~", e);
                                    errorLog.addErrorLog("EMAIL�B�z���~", e);

                                }

                            }//���ӵ���

                            Map CRTMap = new HashMap();
                            CRTMap.put("BLD_CD", keyBLD_CD);
                            CRTMap.put("CRT_NO", keyCRT_NO);
                            CRTMap.put("SUB_CPY_ID", keySUB_CPY_ID);
                            CRTMap.put("UPD_TIME", UPD_TIME);
                            CRTMap.put("INPUT_DIV_NO", MapUtils.getString(CRT_NOList.get(0), "INPUT_DIV_NO"));

                            //��s�������pby�P�@�����N��
                            this.updateCRT_NO(CRTMap, NEW_APLY_NO);
                            NEW_APLY_NO_byBLD_CD = NEW_APLY_NO;

                        }

                        //��s�j�Ӹ��
                        this.updateBLD_CD(keyBLD_CD, strUPD_TIME, NEW_APLY_NO_byBLD_CD);
                    }

                    Transaction.commit();
                } catch (Exception e) {
                    Transaction.rollback();
                    throw e;
                }
            } catch (Exception e) {
                setExitCode(ERROR);
                sb.append("���ʧ@�~���~");
                sb.append("�F�����q�O(SUB_CPY_ID) = ").append(keySUB_CPY_ID);
                sb.append("�B�j�ӥN��(BLD_CD) = ").append(logBLD_CD);
                sb.append("�B�����N��(CRT_NO) = ").append(logCRT_NO);
                sb.append("�B�Ȥ�Ǹ�(CUS_NO) = ").append(logCUS_NO);

                String message = sb.toString();
                sb.setLength(0);
                log.fatal(message, e);
                errorLog.addErrorLog(message, e);

                return;//��srollback ���@�H�H

            }

            //�H��H�X
            if (crtInfoList.size() == 0) {//�L���Ӹ��
                return;
            }

            try {
                if (this.sendMail(keySUB_CPY_ID, crtInfoList, mailList, titleList)) {
                    OUT_COUNT_NUM++;
                }
            } catch (Exception e) {
                mailErrCount++;
                if (getExitCode() == OK) {
                    setExitCode(101);
                }
                log.fatal("�H�e�H��ɵo�Ϳ��~", e);
                errorLog.addErrorLog("�H�e�H��ɵo�Ϳ��~", e);
            }
        } finally {
            countManager.addCountNumber(MAILERR_COUNT, mailErrCount);//EMAIL���~���
            countManager.addCountNumber(UPD_COUNT, UPD_COUNT_NUM); //�]�w��s�ӯ�����
            countManager.addCountNumber(OUTPUT_COUNT, OUT_COUNT_NUM); //�]�w��X���
        }

    }
}
