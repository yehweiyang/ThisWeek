package com.cathay.ep.b5.batch;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.transaction.Status;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.DATE;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.CountManager;
import com.cathay.common.util.batch.ErrorLog;
import com.cathay.common.util.mail.MailSender;
import com.cathay.ep.a1.module.EP_A10030;
import com.cathay.ep.a1.module.EP_A10040;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.b3.module.EP_B30020;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.rz.s0.module.RZ_S00300;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchQueryDataSet;

/**
 * Date        Version Description Author
 * 2013/11/08  1.0     Created     ���կ�
 * 2018/02/01  �t�X��ؽվ� ����[
 * 2018/07/02   �M��sb,�קKlog�g�Jmail���e ����[
 * 
 * �@�B   �{���\�෧�n�����G
 * �{���\��    �_�����s�j�ӫǧO������
 * �{���W��    EPB5_B020.java
 * �@�~�覡    BATCH
 * ���n����    �C�ѱN����_����Ƨ�s�j�ӫǧO������(�Y�_����<=����󥼧�s�̫h�@�֧�s)
 * �w����ƶq   
 * �@�~�W��    �_�����s�j�ӫǧO������
 * �~�ȧO EP
 * ���t�ΦW��   B5
 * �B�z�g��    ��07:00AM
 * ����B�z���  �w�]��
 * 
 * [20181102] �ק�� Modified �H�H���~�B�z
 * @author ���_��
 * @since 2014/1/9
 */
@SuppressWarnings("unchecked")
public class EPB5_B020 extends EP_BatchBean {

    /** log */
    private static final Logger log = Logger.getLogger(EPB5_B020.class);

    /** �@�~�W�� */
    private static final String JOB_NAME = "EPB5_B020";

    /** �{���W�� */
    private static final String PROGRAM = "EPB5_B020";

    /** �~�ȧO */
    private static final String BUSINESS = "EP";

    /** ���t�ΦW�� */
    private static final String SUBSYSTEM = "B5";

    /** ����g�� */
    private static final String PERIOD = "��";

    /** �]�� true �Ѥ����O�p�Ƥμg���~�T��, false �Шϥ� ErrorLog ��CountManager �ۦ�g���~�T���έp�� */
    private static final boolean isAUTO_WRITELOG = false;

    private static final String INPUT_COUNT = "��J���";

    private static final String ENDCASE_COUNT = "�ץ󵲮ץ��";

    private static final String UPDCASE_COUNT = "��s�ץ���";

    private static final String ERROR_COUNT = "���~���";

    private static final String MAILERR_COUNT = "EMAIL���~���";

    private static final String OUTPUT_COUNT = "EMAIL����";

    /** �d�ߪ����� */
    private BatchQueryDataSet bqds;

    /** �M�����O�@�Τ����~�T���O������ */
    private ErrorLog errorLog;

    /** �p�ƾ� */
    private CountManager countManager;

    private StringBuffer sbf;

    /** �o�e�������@�Ҳ� */
    private RZ_S00300 theRZ_S00300;

    /** �Ӽh�O�����@�Ҳ� */
    private EP_A10030 theEP_A10030;

    /** �W��O�����@�Ҳ� */
    private EP_B30020 theEP_B30020;

    /** ����Ψ�L�O�����@�Ҳ� */
    private EP_A10040 theEP_A10040;

    /** �߮׿�J���@�Ҳ� */
    private EP_B30010 theEP_B30010;

    /** EMAIL�H�o�]�w���@�Ҳ� */
    private EP_Z10030 theEP_Z10030;

    private static final String QUERYDTEPB301_001 = "com.cathay.ep.b5.batch.EPB5_B020.QUERYDTEPB301_001";

    public EPB5_B020() throws Exception {

        //�]�w�����O���غc�l,�ǤJ true �Ѥ����O�p�Ƥμg���~�T��
        super(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isAUTO_WRITELOG);

        //���~�T���O������
        countManager = new CountManager(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD);

        errorLog = new ErrorLog(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM);

        sbf = new StringBuffer();

        bqds = getBatchQueryDataSet();

        initCountManager();

        theRZ_S00300 = new RZ_S00300();

        theEP_A10030 = new EP_A10030();

        theEP_B30020 = new EP_B30020();

        theEP_A10040 = new EP_A10040();

        theEP_B30010 = new EP_B30010();

        theEP_Z10030 = new EP_Z10030();
    }

    public void execute(String args[]) throws Exception {

        try {

            String SYS_DATE;
            String SUB_CPY_ID_q;
            try {

                //������G�Y�L�ǤJ�ѼơA�h���t�Τ�@�������
                if (args != null && args.length > 0) {
                    //�����q�O
                    SUB_CPY_ID_q = args[0];
                    if (StringUtils.isBlank(SUB_CPY_ID_q)) {
                        SUB_CPY_ID_q = "00";
                        sbf.append("�L�ǤJ�����q�O,�w�]00���");
                        log.fatal(sbf.toString());
                    }
                    //�����
                    if (args.length > 1) {
                        SYS_DATE = args[1];

                        if (StringUtils.isBlank(SYS_DATE)) {
                            SYS_DATE = DATE.getDBDate();
                        } else if (!DATE.isDate(SYS_DATE)) {
                            throw new ErrorInputException("�ǤJ����ѼƦ��~");
                        } else if (SYS_DATE.compareTo(DATE.getDBDate()) > 0) {
                            throw new ErrorInputException("�ǤJ���餣�o�j�󤵤�!");
                        }

                        sbf.append("���ǤJ������A�����: ").append(SYS_DATE);
                        log.fatal(sbf.toString());
                        sbf.setLength(0);
                    } else {
                        SYS_DATE = DATE.getDBDate();
                        sbf.append("���ǤJ������A�u�B�z�����: ").append(SYS_DATE);
                        log.fatal(sbf.toString());
                        sbf.setLength(0);
                    }
                } else {
                    SYS_DATE = DATE.getDBDate();
                    SUB_CPY_ID_q = "00";
                    sbf.append("���ǤJ������A�u�B�z�����: ").append(SYS_DATE).append(STRING.lineSeparator);
                    sbf.append("�L�ǤJ�����q�O,�w�]00���");
                    log.fatal(sbf.toString());
                    //180702:�M��sb,�קKlog�g�Jmail���e
                    sbf.setLength(0);
                }

            } catch (Exception e) {
                setExitCode(ERROR);
                log.fatal("�ǤJ�ѼƦ��~", e);
                return;
            }

            String[] TRN_KIND1 = { "EPA001", "EPA002", "EPB015", "EPB001", "EPB008", "EPB011", "EPB009", "EPB010", "EPB002", "EPB003" };
            bqds.setFieldValues("TRN_KIND", TRN_KIND1);
            //�����
            bqds.setField("SYS_DATE", SYS_DATE);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID_q);//�����q�O

            /*���o�w���ܧ�ץ�ݧ�s���(���ư��t�q�s��, ���e�פ���(�Ѩ�L�妸��s))
            1.  �B�z���:EPA001�j�Ӧ��ߡBEPA002�j�Ӹ�ƭץ��BEPB015�w����ץ��BEPB001�������ߡB
                EPB008�����ץ��BEPB011�W��BEPB009�ӯ�����ɡBEPB010�ӯ���ץ��BEPB002�W���BEPB003�
            2.  �Y�Ӯץ󤧹w���ǧO����w��s����, �N�Ӯץ󵲮�
            3.  �̷Ӥ����q�O�H�oEMAIL(�H����J�̥H�γ]�w�ɩҳ]�w��EMAIL), �@�Ӥ����q�u�H�o�@�����Ҧ������
            */

            searchAndRetrieve(bqds, QUERYDTEPB301_001);

            int inputCount = getInputCount();
            if (inputCount == 0) {//�Y�d�L��ơA�������`�A�{������
                return;
            }

            countManager.addCountNumber(INPUT_COUNT, inputCount); //�]�w��X���

            //�������TITLE: 
            List<Map> titleList = new ArrayList<Map>();
            titleList(titleList, "CRT_NO", "�����N��", 14);
            titleList(titleList, "CLC_DIV_NO", "��J���", 7);
            titleList(titleList, "INPUT_NAME", "��J�H��", 10);
            titleList(titleList, "PROC_STS", "�B�z���A", 20);

            //�]�w�ϥΪ̸�TuserMap
            Map<String, String> userMap = new HashMap<String, String>();
            userMap.put("CHG_ID", "SYSTEM");//�f��i���妸���gSYSTEM, �_�h�|�L�k�������H�ƦW��
            userMap.put("CHG_NAME", "�w�����s");

            Map<String, Map<String, Object>> groupDataByKey = new HashMap<String, Map<String, Object>>();
            /*�B�z�w����ǧO�Ψ����s*/
            Date today = DATE.today();
            String UPD_TIME = DATE.getDBTimeStamp();
            Timestamp UPD_TIMESTAMP = DATE.toTimestamp(UPD_TIME);

            DTEPB301 B301vo = new DTEPB301();
            String[] EPString = new String[] { "EPB011", "EPB002", "EPB003" };

            boolean occurError = false;
            try {
                for (prepareFetch(); fetchData(bqds); goNext()) { //�������

                    int mailcount = 0;
                    int updcasecount = 0;

                    try {
                        // �v���B�z
                        while (bqds.next()) {

                            boolean IS_UPD_RM = false;
                            boolean IS_UPD_CAR = false;
                            boolean IS_END_CASE = false;
                            String MSG = "";

                            String SUB_CPY_ID = (String) bqds.getField("SUB_CPY_ID");

                            if (!groupDataByKey.isEmpty() && !groupDataByKey.containsKey(SUB_CPY_ID)) {

                                try {

                                    if (occurError) {
                                        if (Transaction.getStatus() == Status.STATUS_ACTIVE) {
                                            Transaction.rollback();
                                        }

                                    } else {

                                        try {

                                            if (Transaction.getStatus() == Status.STATUS_ACTIVE) {
                                                Transaction.commit();
                                            }

                                            sendMail(groupDataByKey, titleList, today);
                                            mailcount++;

                                        } catch (Exception e) {
                                            if (getExitCode() == OK) {
                                                setExitCode(101); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�                                    
                                            }
                                            log.fatal("EMAIL�B�z���~", e);
                                            errorLog.addErrorLog("EMAIL�B�z���~", e);
                                            countManager.addCountNumber(MAILERR_COUNT, 1);
                                        }

                                    }

                                } finally {
                                    groupDataByKey.clear();
                                    occurError = false;
                                }
                            }

                            if (occurError) {
                                continue;
                            }

                            if (Transaction.getStatus() != Status.STATUS_ACTIVE) {
                                Transaction.begin();
                            }

                            String APLY_NO = (String) bqds.getField("APLY_NO");
                            String CRT_NO = (String) bqds.getField("CRT_NO");

                            try {

                                Integer carCount = (Integer) bqds.getField("CAR_COUNT");
                                Integer rmCount = (Integer) bqds.getField("RM_COUNT");

                                //���o�ǧO�ݳB�z���, ����ݳB�z���

                                //��s�ǧO������D��
                                String BLD_CD = (String) bqds.getField("BLD_CD");
                                String TRN_KIND = (String) bqds.getField("TRN_KIND");
                                String INPUT_DIV_NO = (String) bqds.getField("INPUT_DIV_NO");
                                String INPUT_ID = (String) bqds.getField("INPUT_ID");
                                String INPUT_NAME = (String) bqds.getField("INPUT_NAME");
                                String IS_REG = (String) bqds.getField("IS_REG");

                                B301vo.setSUB_CPY_ID(SUB_CPY_ID);
                                B301vo.setAPLY_NO(APLY_NO);
                                B301vo.setTRN_KIND(TRN_KIND);
                                B301vo.setINPUT_DIV_NO(INPUT_DIV_NO);
                                B301vo.setINPUT_ID(INPUT_ID);
                                B301vo.setINPUT_NAME(INPUT_NAME);
                                B301vo.setIS_REG(IS_REG);
                                B301vo.setCRT_NO(CRT_NO);
                                B301vo.setBLD_CD(BLD_CD);
                                B301vo.setFLOW_NO((String) bqds.getField("FLOW_NO"));
                                B301vo.setINPUT_DATE((Timestamp) bqds.getField("INPUT_DATE"));
                                B301vo.setLST_PROC_DATE((Timestamp) bqds.getField("LST_PROC_DATE"));
                                B301vo.setLST_PROC_DIV((String) bqds.getField("LST_PROC_DIV"));
                                B301vo.setLST_PROC_ID((String) bqds.getField("LST_PROC_ID"));
                                B301vo.setLST_PROC_NAME((String) bqds.getField("LST_PROC_NAME"));
                                B301vo.setOP_STATUS((String) bqds.getField("OP_STATUS"));
                                B301vo.setPRE_CRT_NO((String) bqds.getField("PRE_CRT_NO"));
                                B301vo.setREG_APLY_NO((String) bqds.getField("REG_APLY_NO"));
                                B301vo.setREG_END_DATE((Date) bqds.getField("REG_END_DATE"));
                                B301vo.setREG_STR_DATE((Date) bqds.getField("REG_STR_DATE"));

                                if (rmCount != null) {
                                    theEP_A10030.approve(BLD_CD, B301vo, UPD_TIME);
                                    IS_UPD_RM = true;
                                }

                                if (carCount != null) {

                                    if (ArrayUtils.contains(EPString, TRN_KIND)) {
                                        // EPB011�W��BEPB002�W���BEPB003�
                                        theEP_B30020.approve(B301vo, UPD_TIMESTAMP, false);
                                        MSG = "�W�";
                                    } else {
                                        theEP_A10040.approve(BLD_CD, B301vo, UPD_TIME);
                                    }
                                    IS_UPD_CAR = true;
                                }

                                if (IS_UPD_RM || IS_UPD_CAR) {
                                    //��s�ӵ��ץ��ܧ�������A
                                    String REG_END_DATE = ObjectUtils.toString(bqds.getField("REG_END_DATE"), "");
                                    if (SYS_DATE.compareTo(REG_END_DATE) >= 0) {
                                        IS_END_CASE = true;
                                        countManager.addCountNumber(ENDCASE_COUNT, 1);
                                    }
                                    theEP_B30010.regEndCase(B301vo, userMap, IS_END_CASE, UPD_TIME);
                                    updcasecount++;

                                    //����EMAIL���e�GcrtInfoList
                                    Map groupData;//�PSUB_CPY_ID��Ʀs��(List<Map>)
                                    List<Map<String, String>> crtInfoList;
                                    if (groupDataByKey.isEmpty()) {
                                        groupData = new HashMap<String, Map<String, Object>>();
                                        groupDataByKey.put(SUB_CPY_ID, groupData);

                                        crtInfoList = new ArrayList<Map<String, String>>();
                                        groupData.put("crtInfoList", crtInfoList);
                                    } else {
                                        groupData = groupDataByKey.get(SUB_CPY_ID);

                                        crtInfoList = (List<Map<String, String>>) groupData.get("crtInfoList");
                                    }

                                    Map<String, String> mailMap = new HashMap<String, String>();
                                    mailMap.put("CRT_NO", ObjectUtils.toString(CRT_NO, ""));
                                    mailMap.put("CLC_DIV_NO", ObjectUtils.toString(INPUT_DIV_NO, ""));
                                    mailMap.put("INPUT_NAME", ObjectUtils.toString(INPUT_NAME, ""));
                                    mailMap.put("INPUT_ID", ObjectUtils.toString(INPUT_ID, ""));
                                    if (IS_UPD_RM && IS_UPD_CAR) {
                                        sbf.append(MSG).append("�ǧO�Ψ����s");
                                    } else if (IS_UPD_RM) {
                                        sbf.append(MSG).append("�ǧO��s");
                                    } else {
                                        sbf.append(MSG).append("�����s");
                                    }
                                    mailMap.put("PROC_STS", sbf.toString());
                                    sbf.setLength(0);
                                    crtInfoList.add(mailMap);

                                }

                            } catch (Exception e) {
                                occurError = true;
                                setExitCode(ERROR);

                                sbf.append("�@�~���~�F");
                                sbf.append("APLY_NO=").append(APLY_NO);
                                sbf.append("�BCRT_NO=").append(CRT_NO);
                                sbf.append("�BSUB_CPY_ID=").append(SUB_CPY_ID);
                                String msg = sbf.toString();
                                sbf.setLength(0);
                                log.fatal(msg, e);
                                errorLog.addErrorLog(msg, e);
                            }

                        }// while loop end

                        if (!groupDataByKey.isEmpty()) {

                            try {

                                if (occurError) {
                                    if (Transaction.getStatus() == Status.STATUS_ACTIVE) {
                                        Transaction.rollback();
                                    }
                                } else {

                                    try {

                                        if (Transaction.getStatus() == Status.STATUS_ACTIVE) {
                                            Transaction.commit();
                                        }

                                        //�̫�@�������H�H
                                        sendMail(groupDataByKey, titleList, today);
                                        countManager.addCountNumber(OUTPUT_COUNT, 1);

                                    } catch (Exception e) {
                                        if (getExitCode() == OK) {
                                            setExitCode(101); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�                                    
                                        }
                                        log.fatal("EMAIL�B�z���~", e);
                                        errorLog.addErrorLog("EMAIL�B�z���~", e);
                                        countManager.addCountNumber(MAILERR_COUNT, 1);
                                    }
                                }

                            } finally {
                                groupDataByKey.clear();
                                occurError = false;
                            }

                        } else if (Transaction.getStatus() == Status.STATUS_ACTIVE) {
                            Transaction.rollback();
                        }

                    } finally {
                        countManager.addCountNumber(OUTPUT_COUNT, mailcount);
                        countManager.addCountNumber(UPDCASE_COUNT, updcasecount);
                    }

                } //for loop end

            } finally {
                int count = errorLog.getErrorCountAndWriteErrorMessage();
                countManager.addCountNumber(ERROR_COUNT, count);
            }

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("����ɵo�Ϳ��~", e);
        } finally {

            log.fatal(countManager);

            if (countManager != null) {
                countManager.writeLog(); //�g�J��ưO����  
            }
            // �����Ҧ����s�u
            if (bqds != null) {
                bqds.close();
            }

            printExitCode(getExitCode()); //�^�ǵ� Control_M ���T���N�X , �{���פ�
        }

    }

    //  *********************************************** Private Method  ************************************************/

    /**
     * ��l�p��
     * @throws ModuleException
     */
    private void initCountManager() throws ModuleException {
        countManager.createCountType("START");
        countManager.writeLog();
        countManager.clearCountTypeAndNumber();
        countManager.createCountType(INPUT_COUNT);
        countManager.createCountType(ENDCASE_COUNT);
        countManager.createCountType(UPDCASE_COUNT);
        countManager.createCountType(ERROR_COUNT);
        countManager.createCountType(MAILERR_COUNT);
        countManager.createCountType(OUTPUT_COUNT);
    }

    /**
     * �H�eMAIL
     * @param CHG_DIV_NO
     * @param INFM_ID
     * @param INFM_EMAIL
     * @param mailList
     * @param titleList
     * @param crtInfoList
     * @param theRZ_S00300
     * @throws Exception
     */
    private void sendMail(Map<String, Map<String, Object>> groupDataByKey, List<Map> titleList, Date today) throws Exception {

        String SUB_CPY_ID = groupDataByKey.keySet().iterator().next();

        Map<String, Object> groupData = groupDataByKey.get(SUB_CPY_ID);
        List<Map> crtInfoList = (List<Map>) groupData.get("crtInfoList");

        if (crtInfoList.size() == 0) {
            log.fatal("�w����ǧO�����s�q��: �����L��s���");
            return;
        }

        List mailList = new ArrayList();

        Iterator<Map> iter = crtInfoList.iterator();
        String USER_DIVNM = "�w����ǧO�����s�q��";
        try {
            while (iter.hasNext()) {
                Map<String, String> nowMap = iter.next();
                String INPUT_DIV_NO = nowMap.get("CLC_DIV_NO"); //���D��s�� 20181001-0013:�]�w�����J�H���w��¾�A�|��H��J��줧�H�c�A���{���ѼƳ]�w���~�A�ɭP�d�L������MAIL�H�e�C
                String INPUT_ID = nowMap.get("INPUT_ID");

                List<Map> iptMailList = theEP_Z10030.getMailByID(SUB_CPY_ID, INPUT_DIV_NO, INPUT_ID, "1");// EMAIL����:1�ӤH2���3�ӤH�γ��(����쪺EMAIL�w�]�b����w��)
                if (iptMailList == null || iptMailList.size() <= 0) {
                    log.fatal("�d�L�ӤHmail,�������`");
                } else {
                    Map Mailmap = iptMailList.get(0);
                    Mailmap.put("USER_EMAIL", Mailmap.get("EMAIL"));
                    Mailmap.put("DEFAULT_MAIL", MailSender.DEFAULT_MAIL);
                    Mailmap.put("USER_NAME", Mailmap.get("NAME"));
                    Mailmap.put("USER_ID", Mailmap.get("ID"));
                    Mailmap.put("USER_DIVNO", Mailmap.get("CHG_DIV_NO"));
                    Mailmap.put("USER_DIVNM", USER_DIVNM);
                    mailList.add(Mailmap);
                }

            }
        } catch (Exception e) {
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID) && getExitCode() == OK) {//�D��جd�Lmail�������`
                setExitCode(101);
            }
            sbf.setLength(0);
            sbf.append("���o�ӤHEMAIL���~, �����q�O: ").append(SUB_CPY_ID).append(", ���e:").append(crtInfoList);
            log.fatal(sbf.toString(), e);
            sbf.setLength(0);
            sbf.append("���o�ӤHEMAIL���~, �����q�O: ").append(SUB_CPY_ID);
            errorLog.addErrorLog(sbf.toString(), e);
            sbf.setLength(0);
            countManager.addCountNumber(MAILERR_COUNT, 1);
        }

        //���o�e�������q�q��MAIL LIST�ñH�o�q��
        try {
            Map rtnMap = theEP_Z10030.getMailList(SUB_CPY_ID, "EP_IB003");

            List<DTEPZ103> rtnMailList = (List<DTEPZ103>) rtnMap.get(SUB_CPY_ID);

            for (DTEPZ103 Z103vo : rtnMailList) {
                Map infmMap = new HashMap();
                infmMap.put("USER_EMAIL", Z103vo.getEMAIL());
                infmMap.put("DEFAULT_MAIL", MailSender.DEFAULT_MAIL);
                infmMap.put("USER_NAME", Z103vo.getNAME());
                infmMap.put("USER_ID", Z103vo.getID());
                infmMap.put("USER_DIVNO", ObjectUtils.toString(Z103vo.getCHG_DIV_NO(), " "));
                infmMap.put("USER_DIVNM", USER_DIVNM);
                mailList.add(infmMap);
            }
        } catch (DataNotFoundException dnfe) {
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID) && getExitCode() == OK) {//�D��جd�Lmail�������`
                setExitCode(101); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�                                    
            }
            sbf.setLength(0);
            sbf.append("�]�w�ɬd�L�w�����s�q��EMAIL, �����q�O: ").append(SUB_CPY_ID).append(", ���e:").append(crtInfoList);
            log.fatal(sbf.toString(), dnfe);
            sbf.setLength(0);
            sbf.append("�]�w�ɬd�L�w�����s�q��EMAIL, �����q�O: ").append(SUB_CPY_ID);
            errorLog.addErrorLog("", sbf.toString());
            sbf.setLength(0);
            countManager.addCountNumber(MAILERR_COUNT, 1);
        }

        if (mailList.size() == 0) {
            log.fatal("�w����ǧO�����s�q��: �L����̸�Ƥ��H�e");
            return;
        }
        //[20181102] Modified �H�H���~�B�z
        try {
            String COMP_ID = new EP_B30010().getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);
            String ERR_MSG = theRZ_S00300.createRecordByDIV("EP_IB003", "EP", today, mailList, titleList, crtInfoList, COMP_ID);
            if (StringUtils.isNotBlank(ERR_MSG)) {
                throw new ModuleException(ERR_MSG);
            }
        } catch (Exception e) {
            if (getExitCode() == OK) {
                setExitCode(101); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            }
            log.fatal("�H�e�H��ɵo�Ϳ��~", e);
            errorLog.addErrorLog("�H�e�H��ɵo�Ϳ��~", "�H�e�H��ɵo�Ϳ��~");
            countManager.addCountNumber(MAILERR_COUNT, 1);
        }

    }

    /**
     * EMAIL����]�w
     * @param titleList
     * @param FIELD
     * @param FIELD_NM
     * @param FIELD_SIZE
     */
    private void titleList(List<Map> titleList, String FIELD, String FIELD_NM, int FIELD_SIZE) {
        Map<String, Object> styleMap = new HashMap<String, Object>();
        styleMap.put("FIELD", FIELD);
        styleMap.put("FIELD_NM", FIELD_NM);
        styleMap.put("FIELD_SIZE", FIELD_SIZE);
        titleList.add(styleMap);
    }

}
