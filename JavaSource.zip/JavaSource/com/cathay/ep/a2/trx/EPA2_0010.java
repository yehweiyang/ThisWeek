package com.cathay.ep.a2.trx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.a2.module.EPA2_0010_mod;
import com.cathay.ep.a2.module.EP_A20010;
import com.cathay.ep.b3.module.EPB3_0010_mod;
import com.cathay.ep.vo.DTEPB309;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2013/9/3    1.0 Created ����i
 * 
 * UCEPA2_0010_�X��B�z
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �X��B�z
 * �{���W��    EPA2_0010
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 *             (2) �d�� �w �ϥΪ̫��U�d�߫��s��A�I�sEP_A20010�Ҳը��o�j�Ӹ�ơC
 *             (3) ��J �w �s�W�@���s�W�ץ󲧰ʶ���
 * ���s���v    �M��FUNC_ID = EPA20010
 *</pre>
 * @author ����[
 * @since 2013-10-25
 */
@SuppressWarnings("unchecked")
public class EPA2_0010 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPA2_0010.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            VOTool.setParamsFromLP_JSON(req);
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
            resp.addOutputData("CHG_DATE", DATE.getDBDate());
            resp.addOutputData("TRN_KIND", req.getParameter("TRN_KIND"));
            resp.addOutputData("APLY_NO", req.getParameter("APLY_NO"));
            resp.addOutputData("DATA_TYPE", req.getParameter("DATA_TYPE"));
            resp.addOutputData("BLD_CD", req.getParameter("BLD_CD"));
            resp.addOutputData("FLD_NO", req.getParameter("FLD_NO"));

            resp.addOutputData("INPUT_ID", user.getEmpID());
            resp.addOutputData("INPUT_NAME", user.getEmpName());
            resp.addOutputData("INPUT_DIV", user.getOpUnit());

            //�u�ϥΪ��p�v�U�Կ��
            resp.addOutputData("USE_TYPEList", FieldOptionList.getName("EP", "USE_TYPE"));
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (Exception e) {
            log.error("��l����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00029");//��l����
        }
        return resp;

    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            EP_A20010 theEP_A20010 = new EP_A20010();

            Map rtnAMap = null;
            List<Map> rtnBList = null;
            try {
                rtnAMap = theEP_A20010.queryMap(reqMap);
            } catch (DataNotFoundException dnfe) {
                log.debug("�d�L��Ƶ������`", dnfe);
            }
            try {
                rtnBList = theEP_A20010.queryList(reqMap);
            } catch (DataNotFoundException dnfe) {
                log.debug("�d�L��Ƶ������`", dnfe);
            }
            if (rtnAMap == null && rtnBList == null) {
                throw new DataNotFoundException(MessageUtil.getMessage("EPA2_0010_UI_002"));//rtnAMap��rtnBList�Ҭd�L���
            }
            resp.addOutputData("rtnAMap", rtnAMap);
            resp.addOutputData("rtnBList", rtnBList);

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߦ��\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPA2_0010_UI_001"));//���ƶW�L
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * ��J
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            DTEPB309 B309vo = VOTool.jsonToVO(DTEPB309.class, req.getParameter("dataMap"));

            String USE_TYPE = req.getParameter("USE_TYPE");
            //�ˮ֬O�_�i�s�W�A���i�h��X���~
            new EPA2_0010_mod().chkInsert(B309vo, USE_TYPE);
            //�ˮ֪��A�O�_�i���ʡA���i�h��X���~
            new EPB3_0010_mod().isChangeable(B309vo.getAPLY_NO());

            EP_A20010 theEP_A20010 = new EP_A20010();
            Transaction.begin();
            try {
                theEP_A20010.insert(B309vo, USE_TYPE);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00004"));//�s�W����

            //�s�W�������d
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", B309vo.getSUB_CPY_ID());
            reqMap.put("APLY_NO", B309vo.getAPLY_NO());
            reqMap.put("BLD_CD", B309vo.getBLD_CD());
            reqMap.put("FLD_NO", B309vo.getFLD_NO());
            Map rtnAMap = null;
            List<Map> rtnBList = null;
            try {
                rtnAMap = theEP_A20010.queryMap(reqMap);
            } catch (DataNotFoundException dnfe) {
                log.debug("�d�L��Ƶ������`", dnfe);
            }
            try {
                rtnBList = theEP_A20010.queryList(reqMap);
            } catch (DataNotFoundException dnfe) {
                log.debug("�d�L��Ƶ������`", dnfe);
            }
            if (rtnAMap == null && rtnBList == null) {
                throw new DataNotFoundException(MessageUtil.getMessage("EPA2_0010_UI_002"));//rtnAMap��rtnBList�Ҭd�L���
            }
            resp.addOutputData("rtnAMap", rtnAMap);
            resp.addOutputData("rtnBList", rtnBList);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00005"));//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00005"));//�s�W����
        }

        return resp;
    }

    /**
     * �簣
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            DTEPB309 B309Vo = VOTool.jsonToVO(DTEPB309.class, req.getParameter("dataMap"));

            new EPB3_0010_mod().isChangeable(B309Vo.getAPLY_NO());

            EP_A20010 theEP_A20010 = new EP_A20010();

            Transaction.begin();
            try {
                theEP_A20010.delete(B309Vo);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "MEP00010");//�R������ 

            //�簣�������d
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", B309Vo.getSUB_CPY_ID());
            reqMap.put("APLY_NO", B309Vo.getAPLY_NO());
            reqMap.put("BLD_CD", B309Vo.getBLD_CD());
            reqMap.put("FLD_NO", B309Vo.getFLD_NO());
            Map rtnAMap = null;
            List<Map> rtnBList = null;
            try {
                rtnAMap = theEP_A20010.queryMap(reqMap);
            } catch (DataNotFoundException dnfe) {
                log.debug("�d�L��Ƶ������`", dnfe);
            }
            try {
                rtnBList = theEP_A20010.queryList(reqMap);
            } catch (DataNotFoundException dnfe) {
                log.debug("�d�L��Ƶ������`", dnfe);
            }
            if (rtnAMap == null && rtnBList == null) {
                throw new DataNotFoundException(MessageUtil.getMessage("EPA2_0010_UI_002"));//rtnAMap��rtnBList�Ҭd�L���
            }
            resp.addOutputData("rtnAMap", rtnAMap);
            resp.addOutputData("rtnBList", rtnBList);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00012"));//�R�����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00011"));//�R������ 
            }
        } catch (Exception e) {
            log.error("�簣����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00011"));//�R������ 
        }
        return resp;
    }

}
