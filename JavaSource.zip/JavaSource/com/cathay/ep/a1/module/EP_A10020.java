package com.cathay.ep.a1.module;

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.db.impl.DynamicBatchQueryDataSet;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.vo.DTEPA102;
import com.cathay.ep.vo.DTEPA102_LOG;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPB308;
import com.cathay.ep.vo.DTEPB309;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE Description Author
 * 2013/08/16  Created ����i
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �Ӽh�O�����@�Ҳ�
 * �Ҳ�ID    EP_A10020
 * ���n����    �Ӽh�O�����@�Ҳ�
 * </pre>
 * @author ���_��
 * @since 2013/9/12
 */
@SuppressWarnings("unchecked")
public class EP_A10020 {
    private static final Logger log = Logger.getLogger(EP_A10020.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.a1.module.EP_A10020.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.a1.module.EP_A10020.SQL_queryList_002";

    private static final String SQL_queryMap_001 = "com.cathay.ep.a1.module.EP_A10020.SQL_queryMap_001";

    private static final String SQL_queryMap_002 = "com.cathay.ep.a1.module.EP_A10020.SQL_queryMap_002";

    private static final String SQL_queryMap_003 = "com.cathay.ep.a1.module.EP_A10020.SQL_queryMap_003";

    private static final String SQL_deleteDTEPB309DelAll_001 = "com.cathay.ep.a1.module.EP_A10020.SQL_deleteDTEPB309DelAll_001";

    private XlsUtils xlsUtils;

    private boolean isExport = false;

    private static final String[] totalColumns = { "FLD_SIZE", "PBL_RATE", "AVG_AMT", "CLR_AMT" };

    /**
     * Ū���j�ӼӼh�O���ɲM��
     * <pre>
     * @param reqMap{
     * SUB_CPY_ID = �����q�O
     * APLY_NO = �ץ�s��
     * BLD_CD = �j�ӥN��
     * FLD_NO = �Ӽh�O
     * }
     * </pre>
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }

        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", BLD_CD);
        setFieldsIfExsits(reqMap, ds, "FLD_NO");
        if (StringUtils.isNotBlank(APLY_NO)) {
            //�H�ǤJ�ץ�s���d�߮ץ�_�j�ӼӼh�O���ܧ����(DTEPB309)�G

            ds.setField("APLY_NO", APLY_NO);
            DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        } else {
            //�H�ǤJ�j�ӥN���d�ߤj�ӼӼh�O����(DTEPA102)�G
            String FZY_FLD_NO = MapUtils.getString(reqMap, "FZY_FLD_NO");
            if (StringUtils.isNotBlank(FZY_FLD_NO)) {
                StringBuilder sb = new StringBuilder();
                ds.setField("FZY_FLD_NO", sb.append("%").append(FZY_FLD_NO).append("%").toString());
            }
            DBUtil.searchAndRetrieve(ds, SQL_queryList_002);
        }

        List<Map> rtnList = new ArrayList<Map>();

        //�v���B�z�^�ǲM��G
        //�s�W����^�ǵn�O�γ~����, ���o�u�n�O�γ~�v����:
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            rtnMap.put("FLD_TYPE_NM", FieldOptionList.getName("EP", "FLD_TYPE", MapUtils.getString(rtnMap, "FLD_TYPE")));
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            rtnList.add(rtnMap);
        }

        return rtnList;
    }

    /**
     * Ū���j�ӼӼh�O����
     * <pre>
     * @param reqMap{
     * SUB_CPY_ID = �����q�O
     * BLD_CD = �j�ӥN��
     * FLD_NO = �Ӽh�O
     * APLY_NO = �ץ�s��
     * APLY_SER_NO = �ץ�Ǹ�
     * DATA_TYPE = �������
     * QRY_TYPE = 1:�D�ɡB2:������}
     * </pre>
     * @return
     * @throws ModuleException
     */
    private DataSet query(Map reqMap) throws ModuleException {
        return this.query(reqMap, true);
    }

    private DataSet query(Map reqMap, boolean dataNotFoundIsError) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }

        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        String FLD_NO = MapUtils.getString(reqMap, "FLD_NO");
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_004"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("FLD_NO", FLD_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (StringUtils.isNotBlank(APLY_NO)) {
            //�H�ǤJ�����q�O�d�߮ץ�_�j�ӼӼh�O���ܧ����(DTEPB309)�G
            ds.setField("APLY_NO", APLY_NO);
            setFieldsIfExsits(reqMap, ds, "APLY_SER_NO");
            setFieldsIfExsits(reqMap, ds, "DATA_TYPE");
            DBUtil.searchAndRetrieve(ds, SQL_queryMap_001, dataNotFoundIsError);
        } else if ("2".equals(MapUtils.getString(reqMap, "QRY_TYPE"))) {
            DBUtil.searchAndRetrieve(ds, SQL_queryMap_003, dataNotFoundIsError);
        } else {
            //�H�ǤJ�����q�O�Τj�ӥN���d�ߤj�ӼӼh�O����(DTEPA102)�G
            DBUtil.searchAndRetrieve(ds, SQL_queryMap_002, dataNotFoundIsError);
        }

        //�s�W����^�ǵn�O�γ~����, ���o�u�n�O�γ~�v����:

        return ds;
    }

    /**
     * Ū���j�ӼӼh�O����
     * <pre>
     * @param reqMap{
     * SUB_CPY_ID = �����q�O
     * BLD_CD = �j�ӥN��
     * FLD_NO = �Ӽh�O
     * APLY_NO = �ץ�s��
     * APLY_SER_NO = �ץ�Ǹ�
     * DATA_TYPE = �������}
     * </pre>
     * @return
     * @throws ModuleException
     */
    public Map queryMap(Map reqMap, boolean dataNotFoundIsError) throws ModuleException {

        DataSet ds = this.query(reqMap, dataNotFoundIsError);
        if (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //�s�W����^�ǵn�O�γ~����, ���o�u�n�O�γ~�v����:
            rtnMap.put("FLD_TYPE_NM", FieldOptionList.getName("EP", "FLD_TYPE", MapUtils.getString(rtnMap, "FLD_TYPE")));
            //String CHG_DATE = MapUtils.getString(rtnMap, "CHG_DATE");
            //if (StringUtils.isNotBlank(CHG_DATE)) {
            //    rtnMap.put("CHG_DATE", CHG_DATE.split(" ")[0]);
            //}
            return rtnMap;
        }

        return null;
    }

    public Map queryMap(Map reqMap) throws ModuleException {
        return this.queryMap(reqMap, true);
    }

    /**
     * Ū���j�ӼӼh�O����
     * <pre>
     * SUB_CPY_ID = �����q�O
     * BLD_CD = �j�ӥN��
     * FLD_NO = �Ӽh�O
     * APLY_NO = �ץ�s��
     * APLY_SER_NO = �ץ�Ǹ�
     * DATA_TYPE = �������
     * </pre>
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    public DTEPA102_LOG queryDTEPA102(Map reqMap) throws ModuleException {
        DataSet ds = this.query(reqMap);
        ds.next();
        return VOTool.dataSetToVO(DTEPA102_LOG.class, ds);
    }

    /**
     * �s�W�j�ӼӼh�O����
     * @param A102Vo  �j��_�Ӽh�O����
     * @param UPD_DATE  �J�ɤ���ɶ�
     * @param UPD_APLY_NO      �J�ɮץ�s��
     * @param UPD_TRN_KIND    �J�ɥ������
     * @throws ModuleException
     */
    public void insertDTEPA102(DTEPA102 A102Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {

        if (A102Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�:
        String BLD_CD = A102Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String FLD_NO = A102Vo.getFLD_NO();
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_004"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        String SUB_CPY_ID = A102Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�s�W�j�ӼӼh�O���� DTEPA102�G
        VOTool.insert(A102Vo);

    }

    /**
     * �R���j�ӼӼh�O����
     * @param A102Vo    �j��_�Ӽh�O����
     * @param UPD_DATE   �J�ɤ���ɶ�
     * @param UPD_APLY_NO     �J�ɮץ�s��
     * @param UPD_TRN_KIND    �J�ɥ������
     * @throws ModuleException
     */
    public void deleteDTEPA102(DTEPA102 A102Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {

        if (A102Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�:
        String BLD_CD = A102Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String FLD_NO = A102Vo.getFLD_NO();
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_004"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        String SUB_CPY_ID = A102Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�g�@��LOG��
        this.insertLog(A102Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND, true);
        //�R���j�ӼӼh�O���� DTEPA102�G
        VOTool.delByPK(A102Vo);
    }

    /**
     * �ק�j�ӼӼh�O����
     * @param A102Vo    �j��_�Ӽh�O����
     * @param UPD_DATE    �J�ɤ���ɶ�
     * @param UPD_APLY_NO     �J�ɮץ�s��
     * @param UPD_TRN_KIND    �J�ɥ������
     * @throws ModuleException
     */
    public void updateDTEPA102(DTEPA102 A102Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {

        if (A102Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�:
        String BLD_CD = A102Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String FLD_NO = A102Vo.getFLD_NO();
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_004"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        String SUB_CPY_ID = A102Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        //�g�@��LOG��
        this.insertLog(A102Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND, false);
        //�ק�j�ӼӼh�O���� DTEPA102�G
        VOTool.update(A102Vo);

    }

    /**
     * �s�W�j�ӼӼh�O��LOG��
     * @param A102Vo     �j��_�Ӽh�O����
     * @param UPD_DATE     �J�ɤ���ɶ�
     * @param UPD_APLY_NO     �J�ɮץ�s��
     * @param UPD_TRN_KIND     �J�ɮץ�s��
     * @param isDelete    �O�_�R��
     * @throws ModuleException 
     */
    public void insertLog(DTEPA102 A102Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND, boolean isDelete)
            throws ModuleException {

        if (A102Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = A102Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        String BLD_CD = A102Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String FLD_NO = A102Vo.getFLD_NO();
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_004"));//�ǤJ�Ӽh�O���o���ŭ�!
        }

        if (StringUtils.isBlank(UPD_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_005"));//�ǤJ�J�ɤ���ɶ����o���ŭ�!
        }

        if (StringUtils.isBlank(UPD_APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_006"));//�ǤJ�J�ɮץ�s�����o���ŭ�!
        }

        if (StringUtils.isBlank(UPD_TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_007"));//�ǤJ�J�ɥ���������o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        Map reqMap = new HashMap();

        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BLD_CD", BLD_CD);
        reqMap.put("FLD_NO", FLD_NO);

        DTEPA102_LOG A102Vo_Log = this.queryDTEPA102(reqMap);
        try {
            A102Vo_Log.setUPD_DATE(DATE.toTimestamp(UPD_DATE));
        } catch (Exception e) {
            A102Vo_Log.setUPD_DATE(Timestamp.valueOf(UPD_DATE));
        }
        A102Vo_Log.setUPD_APLY_NO(UPD_APLY_NO);
        A102Vo_Log.setUPD_TRN_KIND(UPD_TRN_KIND);
        A102Vo_Log.setSUB_CPY_ID(SUB_CPY_ID);
        VOTool.insert(A102Vo_Log);

    }

    /**
     * �s�W�ץ�j�ӼӼh�O����
     * @param B309Vo  DTEPB309   �ץ�_�j�ӼӼh�O����
     * @throws ModuleException
     */
    public void insertDTEPB309(DTEPB309 B309Vo) throws ModuleException {

        if (B309Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }

        ErrorInputException eie = null;
        String SUB_CPY_ID = B309Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        String APLY_NO = B309Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_008"));//�ǤJ�ץ�s�����o���ŭ�!
        }
        String BLD_CD = B309Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String FLD_NO = B309Vo.getFLD_NO();
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_004"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        //�s�W�ץ�j�ӼӼh�O���� DTEPB309�G
        String APLY_SER_NO1 = B309Vo.getAPLY_SER_NO();
        if (StringUtils.isBlank(APLY_SER_NO1) || APLY_SER_NO1 == null) {
            Integer APLY_SER_NO = new EP_Z0Z001().createNextNumber(B309Vo.getSUB_CPY_ID(), "014", B309Vo.getAPLY_NO(), B309Vo.getBLD_CD());

            B309Vo.setAPLY_SER_NO(APLY_SER_NO.toString());
        }

        VOTool.insert(B309Vo);

    }

    /**
     * �R���ץ�j�ӼӼh�O����
     * @param B309Vo   �ץ�_�j�ӼӼh�O����
     * @throws ModuleException
     */
    public void deleteDTEPB309(DTEPB309 B309Vo) throws ModuleException {

        if (B309Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = B309Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        String APLY_NO = B309Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_008"));//�ǤJ�ץ�s�����o���ŭ�!
        }
        String BLD_CD = B309Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String FLD_NO = B309Vo.getFLD_NO();
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_004"));//�ǤJ�Ӽh�O���o���ŭ�!
        }

        if (eie != null) {
            throw eie;
        }

        //�R���ץ�j�ӼӼh�O���� DTEPB309�G
        VOTool.delByPK(B309Vo);
        //�Y�������A�ɶ��NB�]�@�֧R�� 
        String DATA_TYPE = B309Vo.getDATA_TYPE();
        if ("A".equals(DATA_TYPE)) {
            B309Vo.setDATA_TYPE("B");
            VOTool.delByPK(B309Vo);
        } else if ("D".equals(DATA_TYPE)) {
            new EP_A10030().deleteDTEPB310DelAll(APLY_NO, SUB_CPY_ID, BLD_CD, FLD_NO);
        }
    }

    /**
     * �ק�ץ�j�ӼӼh�O����
     * @param B309Vo   �ץ�_�j�ӼӼh�O����
     * @throws ModuleException
     */
    public void updateDTEPB309(DTEPB309 B309Vo) throws ModuleException {

        if (B309Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = B309Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        String APLY_NO = B309Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_008"));//�ǤJ�ץ�s�����o���ŭ�!
        }
        String BLD_CD = B309Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String FLD_NO = B309Vo.getFLD_NO();
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_004"));//�ǤJ�Ӽh�O���o���ŭ�!
        }

        if (eie != null) {
            throw eie;
        }

        //�ק�ץ�j�ӼӼh�O���� DTEPB309�G
        VOTool.update(B309Vo);
    }

    /**
     * �s�W�ץ�j�ӼӼh�O����
     * @param B308Vo   �ץ�_�j�Ӱ򥻸����
     * @throws ModuleException
     */
    public void insertDTEPB309DelAll(DTEPB308 B308Vo) throws ModuleException {

        if (B308Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = B308Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        String APLY_NO = B308Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_008"));//�ǤJ�ץ�s�����o���ŭ�!
        }
        String BLD_CD = B308Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String DATA_TYPE = B308Vo.getDATA_TYPE();
        if (!"D".equals(DATA_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_009"));//����R���@�~���~!
        }
        if (eie != null) {
            throw eie;
        }

        //�s�W�ץ�j�ӼӼh�O���� DTEPB309�G
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BLD_CD", BLD_CD);

        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        List<Map> rtnList;
        try {
            rtnList = this.queryList(reqMap);
            for (Map rtnMap : rtnList) {
                DTEPB309 B309Vo = VOTool.mapToVO(DTEPB309.class, rtnMap);
                Integer APLY_SER_NO = theEP_Z0Z001.createNextNumber(B309Vo.getSUB_CPY_ID(), "014", APLY_NO, B309Vo.getBLD_CD());
                B309Vo.setAPLY_SER_NO(APLY_SER_NO.toString());
                B309Vo.setAPLY_NO(APLY_NO);
                B309Vo.setDATA_TYPE(DATA_TYPE);
                B309Vo.setSUB_CPY_ID(SUB_CPY_ID);
                VOTool.insert(B309Vo);
            }
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
        }

    }

    /**
     * �ק�
     * @param B309Vo    �ץ�_�Ӽh�O����
     * @throws ModuleException
     */
    public void update(DTEPB309 B309Vo) throws ModuleException {

        if (B309Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }

        //����s�W�{��(�ק�ɼW�[2����ơA�@�����ʫe�A�@�����ʫ�)
        Integer APLY_SER_NO = new EP_Z0Z001().createNextNumber(B309Vo.getSUB_CPY_ID(), "014", B309Vo.getAPLY_NO(), B309Vo.getBLD_CD());

        B309Vo.setAPLY_SER_NO(APLY_SER_NO.toString());
        //���ʫ�
        B309Vo.setDATA_TYPE("A");
        this.insertDTEPB309(B309Vo);

        //���ʫe
        //�d�ߥD�ɸ��
        String BLD_CD = B309Vo.getBLD_CD();
        String FLD_NO = B309Vo.getFLD_NO();
        String SUB_CPY_ID = B309Vo.getSUB_CPY_ID();
        Map reqMap = new HashMap();

        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BLD_CD", BLD_CD);
        reqMap.put("FLD_NO", FLD_NO);
        reqMap.put("APLY_SER_NO", B309Vo.getAPLY_SER_NO());

        Map rtnMap = this.queryMap(reqMap);

        DTEPB309 newB309Vo = VOTool.mapToVO(DTEPB309.class, rtnMap);
        newB309Vo.setDATA_TYPE("B");
        newB309Vo.setAPLY_NO(B309Vo.getAPLY_NO());
        newB309Vo.setAPLY_SER_NO(B309Vo.getAPLY_SER_NO());

        this.insertDTEPB309(newB309Vo);

        //�ק�ץ��ܧ������T
        DTEPB301 DTEPB301 = new DTEPB301();
        DTEPB301.setAPLY_NO(B309Vo.getAPLY_NO());
        DTEPB301.setBLD_CD(BLD_CD);
        DTEPB301.setSUB_CPY_ID(SUB_CPY_ID);
        new EP_B30010().updateDTEPB301MainInfo(DTEPB301);

    }

    /**
     * �s�W
     * @param B309Vo  �ץ�_�Ӽh�O����
     * @throws ModuleException
     */
    public void insert(DTEPB309 B309Vo) throws ModuleException {
        if (B309Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        B309Vo.setAPLY_SER_NO(null);
        this.insertDTEPB309(B309Vo);

        //�ק�ץ��ܧ������T
        DTEPB301 DTEPB301 = new DTEPB301();
        DTEPB301.setAPLY_NO(B309Vo.getAPLY_NO());
        DTEPB301.setBLD_CD(B309Vo.getBLD_CD());
        DTEPB301.setSUB_CPY_ID(B309Vo.getSUB_CPY_ID());
        new EP_B30010().updateDTEPB301MainInfo(DTEPB301);

    }

    /**
     * �R��
     * @param B309Vo   �ץ�_�Ӽh�O����
     * @throws ModuleException
     */
    public void delete(DTEPB309 B309Vo) throws ModuleException {
        if (B309Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        this.insertDTEPB309(B309Vo);

        DTEPB308 DTEPB308 = new DTEPB308();
        VOTool.copyVOFromTo(B309Vo, DTEPB308);
        try {
            new EP_A10030().insertDTEPB310DelAll(B309Vo);
        } catch (DataNotFoundException dnfe) {
            log.error("�R���ǧO�d�L��Ƶ������`");
        }

        //�ק�ץ��ܧ������T
        DTEPB301 DTEPB301 = new DTEPB301();
        DTEPB301.setAPLY_NO(B309Vo.getAPLY_NO());
        DTEPB301.setBLD_CD(B309Vo.getBLD_CD());
        DTEPB301.setSUB_CPY_ID(B309Vo.getSUB_CPY_ID());
        new EP_B30010().updateDTEPB301MainInfo(DTEPB301);

    }

    /**
     * �վ�
     * @param B309Vo   �ץ�_�Ӽh�O����
     * @throws ModuleException
     */
    public void change(DTEPB309 B309Vo) throws ModuleException {
        if (B309Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }

        this.updateDTEPB309(B309Vo);

        //�ק�ץ��ܧ������T

        DTEPB301 DTEPB301 = new DTEPB301();
        DTEPB301.setAPLY_NO(B309Vo.getAPLY_NO());
        DTEPB301.setBLD_CD(B309Vo.getBLD_CD());
        DTEPB301.setSUB_CPY_ID(B309Vo.getSUB_CPY_ID());
        new EP_B30010().updateDTEPB301MainInfo(DTEPB301);

    }

    public void approve(String BLC_CD, DTEPB301 DTEPB301vo, String UPD_TIME) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLC_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (DTEPB301vo == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_010"));//�߮׮ץ󤣱o���ŭ�!
        }
        if (StringUtils.isBlank(UPD_TIME)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_011"));//���ʤ���ɶ����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", DTEPB301vo.getSUB_CPY_ID()); //�����q�O
        reqMap.put("BLD_CD", BLC_CD);
        reqMap.put("APLY_NO", DTEPB301vo.getAPLY_NO()); //�ץ�s��
        //�d�߲��ʩ���
        List<Map> updList = queryList(reqMap);
        String APLY_NO = DTEPB301vo.getAPLY_NO();
        String TRN_KIND = DTEPB301vo.getTRN_KIND();
        Timestamp UPD_TIME_stmp = DATE.toTimestamp(UPD_TIME);
        String INPUT_DIV_NO = DTEPB301vo.getINPUT_DIV_NO();
        String INPUT_ID = DTEPB301vo.getINPUT_ID();
        //�v���B�z���ʩ���
        for (Map upd : updList) {
            DTEPA102 voA102 = VOTool.mapToVO(DTEPA102.class, upd);
            voA102.setAPLY_NO(APLY_NO);
            voA102.setTRN_KIND(TRN_KIND);
            voA102.setCHG_DATE(UPD_TIME_stmp);
            voA102.setCHG_DIV_NO(INPUT_DIV_NO);
            voA102.setCHG_ID(INPUT_ID);
            voA102.setCHG_NAME(DTEPB301vo.getINPUT_NAME());

            String DATA_TYPE = MapUtils.getString(upd, "DATA_TYPE");
            if ("I".equals(DATA_TYPE)) {
                insertDTEPA102(voA102, UPD_TIME, APLY_NO, TRN_KIND);
            } else if ("D".equals(DATA_TYPE)) {
                deleteDTEPA102(voA102, UPD_TIME, APLY_NO, TRN_KIND);
            } else if ("A".equals(DATA_TYPE)) {
                updateDTEPA102(voA102, UPD_TIME, APLY_NO, TRN_KIND);
            }
        }

    }

    /**
     * �簣�R���ץ�j�ӼӼh�O����
     * @param B308Vo DTEPB308    �ץ�_�j�Ӱ򥻸����
     */
    public void deleteDTEPB309DelAll(DTEPB308 B308Vo) throws ModuleException {
        ErrorInputException eie = null;
        if (B308Vo == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        String APLY_NO = B308Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_008"));//�ǤJ�ץ�s�����o���ŭ�!
        }
        String BLD_CD = B308Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String SUB_CPY_ID = B308Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (!"D".equals(B308Vo.getDATA_TYPE())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10020_MSG_009"));//����R���@�~���~!
        }
        if (eie != null) {
            throw eie;
        }
        //�s�W�ץ�ǧO�O���� DTEPB310�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //�R�������Ƶ������`
        DBUtil.executeUpdate(ds, SQL_deleteDTEPB309DelAll_001, false);
    }

    /**
     * �ץX
     * @param reqMap
     * @param resp
     * @throws Exception
     */
    public void queryForExport(Map reqMap, UserObject user, ResponseContext resp) throws Exception {
        List<Map> rtnList = this.queryList(reqMap);
        StringBuffer sb = getSqlStr(rtnList.size());
        DataSet ds = getDataSetByExport(reqMap, resp);
        BatchQueryDataSet bqds = ((BatchQueryDataSet) ds);
        String gridJSON = MapUtils.getString(reqMap, "gridJSON");
        LocaleDisplay display = new LocaleDisplay("EP", user);
        Map<String, Object> dataTotalMap = new HashMap<String, Object>();
        // �X�p�]�w(�W��)+(���) 
        dataTotalMap.put("totalTitle", "�X�p");
        dataTotalMap.put("totalColumns", totalColumns);

        int i = 0;
        try {
            BatchQueryDataSet dynaDS = new DynamicBatchQueryDataSet(bqds);

            dynaDS.searchAndRetrieve(sb.toString());
            if (xlsUtils != null) {

                xlsUtils.initBatchExportSetting(gridJSON, 1, dataTotalMap);
                while (xlsUtils.fetchData(dynaDS)) {
                    while (xlsUtils.next(dynaDS)) {
                        Map dataMap = xlsUtils.getCurrentMap();
                        Map map = (Map) rtnList.get(i);
                        map.put("CHG_DATE", display.formatTimestamp((Timestamp) map.get("CHG_DATE"), "-", ""));
                        dataMap.putAll(map);
                        i++;
                        xlsUtils.batchCreateXls();
                    }
                }

            }

        } finally {
            if (bqds != null) {
                bqds.close();
            }
        }

    }

    /**
     * ���o�ץX���Ƴ]�w
     * @param count
     * @return
     */
    private StringBuffer getSqlStr(int count) {
        StringBuffer sb = new StringBuffer(
                "SELECT SUB_CPY_ID FROM (SELECT a.SUB_CPY_ID FROM DBEP.DTEPA101 a,DBEP.DTEPB102 b ) ORDER BY SUB_CPY_ID fetch first ");
        sb.append(String.valueOf(count)).append(" rows only with ur");

        return sb;
    }

    /**
     * �̥\��M�w DataSet ����
     * @param reqMap
     * @param resp
     * @return
     * @throws IOException
     */
    private DataSet getDataSetByExport(Map reqMap, ResponseContext resp) throws IOException {

        String fileName = MapUtils.getString(reqMap, "fileName");
        xlsUtils = new XlsUtils(URLEncoder.encode(fileName, "UTF-8"), resp);

        isExport = xlsUtils != null;
        DataSet ds = null;
        if (isExport) {
            BatchQueryDataSet q = new BatchQueryDataSet();
            q.setConnName(Transaction.getDataSet().getConnName());
            ds = q;
        } else {

            ds = Transaction.getDataSet();
        }
        return ds;
    }

    /**
     * �]�w�d�߸��
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setFieldsIfExsits(Map reqMap, DataSet ds, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {

            ds.setField(key, value);

        }
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

}
