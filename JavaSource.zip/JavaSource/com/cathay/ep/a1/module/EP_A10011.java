package com.cathay.ep.a1.module;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.db.impl.DynamicBatchQueryDataSet;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE        Description Author
 * 2013/11/12  Created     ������
 *
 * �@�B    �{���\�෧�n�����G
 * �ҲզW��    �򥻸�ƥ�����ӼҲ�
 * �Ҳ�ID     EP_A10011
 * ���n����    �򥻸�ƺ��@�Ҳ�
 *</pre>
 * @author ���_��
 * @since 2013/11/20
 */
@SuppressWarnings("unchecked")
public class EP_A10011 {
    private XlsUtils xlsUtils;

    private boolean isExport = false;

    private static final String SQL_queryList_001 = "com.cathay.ep.a1.module.EP_A10011.SQL_queryList_001";

    /**
     * Ū���j�Ӱ򥻸�ƥ������
     * @param reqMap = {SUB_CPY_ID = �����q�O ; BLD_CD = �j�ӥN��}
     * @param resp �u�����ϥ�,�N�`���ƶǦ^
     * @param isFirstQuery �u�����ϥ�,�O�_���Ĥ@���j�M
     * @param startWith �u�����ϥ�,�_�l�d��
     * @param endWith �u�����ϥ�,�����d��
     * @return
     * @throws Exception
     */
    public List<Map> queryList(Map reqMap, ResponseContext resp, boolean isFirstQuery, Integer startWith, Integer endWith) throws Exception {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10011_MSG_001"));//�ǤJ�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A10011_MSG_002");//�j�ӥN�����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�N�d�ߤ���ন�d�߮ɶ�
        String DATE_STR = MapUtils.getString(reqMap, "DATE_STR");
        if (StringUtils.isNotBlank(DATE_STR)) {
            DATE_STR = DATE_STR + " 00:00:00.000000";
        }
        String DATE_END = MapUtils.getString(reqMap, "DATE_END");
        if (StringUtils.isNotBlank(DATE_END)) {
            DATE_END = DATE_END + " 23:59:59.999999";
        }

        //�H�ǤJ�����q�O�d�ߤj�Ӱ򥻸����LOG(DTEPA101_LOG)�A�̲��ʤ���ϦV�Ƨ�
        StringBuilder sb = new StringBuilder();
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", sb.append('%').append(BLD_CD).append('%').toString());
        setLikeFieldsIfExsits(ds, "DATE_STR", DATE_STR);
        setLikeFieldsIfExsits(ds, "DATE_END", DATE_END);
        sb.setLength(0);

        Map rtnMapA = new EP_A10010().queryMap(reqMap);
        String CHG_DATE = MapUtils.getString(rtnMapA, "CHG_DATE");

        if (!isExport) {
            //�P�_�D�ɲ��ʮɶ� ���� �d�߰϶� �~�N��� �[�J�d�ߵ��G
            if (CHG_DATE.compareTo(DATE_STR) >= 0 && CHG_DATE.compareTo(DATE_END) <= 0) {
                if (startWith != 1) {
                    startWith = startWith - 1;
                }
                ds.setFetchRange(startWith, endWith - 1);//�u�����\�� �_����ƦC �]�w
            } else {
                ds.setFetchRange(startWith, endWith);//�u�����\�� �_����ƦC �]�w
            }

        }

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);

        //�d���`����
        if (isFirstQuery) {
            //�P�_�D�ɲ��ʮɶ� ���� �d�߰϶� �~�N��� �[�J�d�ߵ��G
            if (CHG_DATE.compareTo(DATE_STR) >= 0 && CHG_DATE.compareTo(DATE_END) <= 0) {
                resp.addOutputData("totalOfRecords", ds.getQueryTotalCount() + 1); // ���o-�`����,�u�����\��T�w�ѼƦW��
            } else {
                resp.addOutputData("totalOfRecords", ds.getQueryTotalCount()); // ���o-�`����,�u�����\��T�w�ѼƦW��
            }

        }

        //�v���B�z�^�ǲM��A���o����W��
        if (rtnList == null) {
            rtnList = new ArrayList<Map>();
        }
        EP_A10010 theEP_A10010 = new EP_A10010();
        for (Map rtnMap : rtnList) {
            rtnMap.put("CURR_NM", FieldOptionList.getName("EP", "CURR", MapUtils.getString(rtnMap, "CURR")));

            rtnMap.put("UPD_TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "UPD_TRN_KIND")));
            rtnMap.put("CLC_DIV_NO_NM", theEP_A10010.getDivName(MapUtils.getString(rtnMap, "CLC_DIV_NO"),SUB_CPY_ID));
            rtnMap.put("TOT_FLG_RD", getDecimal(rtnMap.get("FLG_RD")).add(getDecimal(rtnMap.get("UD_FLG_RD"))));
        }

        //���o�j�Ӱ򥻸��
        //�s�W�̷s��ƨ�Ĥ@��
        //�P�_�D�ɲ��ʮɶ� ���� �d�߰϶� �~�N��� �[�J�d�ߵ��G
        if (CHG_DATE.compareTo(DATE_STR) >= 0 && CHG_DATE.compareTo(DATE_END) <= 0) {
            if (startWith == 1) {

                String TRN_KIND = MapUtils.getString(rtnMapA, "TRN_KIND");
                rtnMapA.put("UPD_TRN_KIND", TRN_KIND);
                rtnMapA.put("UPD_DATE", rtnMapA.get("CHG_DATE"));
                rtnMapA.put("UPD_TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", TRN_KIND));

                rtnList.add(0, rtnMapA);
            }
        }

        for (Map rtnMap1 : rtnList) {
            rtnMap1.put("UNIT_NM", FieldOptionList.getName("EP", "UNIT", MapUtils.getString(rtnMap1, "UNIT")));
            rtnMap1.put("BLD_USE_CD_NM", FieldOptionList.getName("EP", "BLD_USE_CD", MapUtils.getString(rtnMap1, "BLD_USE_CD")));
            rtnMap1.put("BLD_KD_1_NM", FieldOptionList.getName("EP", "BLD_KD_1", MapUtils.getString(rtnMap1, "BLD_KD_1")));
            rtnMap1.put("BLD_KD_2_NM", FieldOptionList.getName("EP", "BLD_KD_2", MapUtils.getString(rtnMap1, "BLD_KD_2")));
            rtnMap1.put("BLD_KD_3_NM", FieldOptionList.getName("EP", "BLD_KD_3", MapUtils.getString(rtnMap1, "BLD_KD_3")));

        }
        return rtnList;
    }

    /**
     * Ū���j�Ӱ򥻸�ƥ������
     * @param reqMap = {SUB_CPY_ID = �����q�O ; BLD_CD = �j�ӥN��}
     * @return �j�Ӱ򥻸�ƥ��������(�h��)
     * @throws Exception 
     */
    public List<Map> queryListForExport(Map reqMap, ResponseContext resp) throws Exception {
        isExport = true;//�ץX�d��
        List<Map> rtnList = this.queryList(reqMap, resp, false, 1, null);
        StringBuffer sb = getSqlStr(rtnList.size());
        DataSet ds = getDataSetByExport(reqMap, resp);
        BatchQueryDataSet bqds = ((BatchQueryDataSet) ds);
        String gridJSON = MapUtils.getString(reqMap, "gridJSON");

        int i = 0;
        try {
            BatchQueryDataSet dynaDS = new DynamicBatchQueryDataSet(bqds);

            dynaDS.searchAndRetrieve(sb.toString());
            if (xlsUtils != null) {

                xlsUtils.initBatchExportSetting(gridJSON, 1);
                while (xlsUtils.fetchData(dynaDS)) {
                    while (xlsUtils.next(dynaDS)) {
                        Map dataMap = xlsUtils.getCurrentMap();
                        dataMap.putAll((Map) rtnList.get(i));
                        i++;
                        xlsUtils.batchCreateXls();
                    }
                }

            }

        } finally {
            if (bqds != null) {
                bqds.close();
            }
        }

        return null;

    }

    private StringBuffer getSqlStr(int count) {

        StringBuffer sb = new StringBuffer("SELECT * FROM DBEP.DTEPA101_LOG fetch first ");
        sb.append(String.valueOf(count)).append(" rows only with ur");

        return sb;
    }

    /**
     * �̥\��M�w DataSet ����
     * @param reqMap
     * @param resp
     * @return
     * @throws IOException
     */
    private DataSet getDataSetByExport(Map reqMap, ResponseContext resp) throws IOException {

        String fileName = MapUtils.getString(reqMap, "fileName");
        xlsUtils = new XlsUtils(URLEncoder.encode(fileName, "UTF-8"), resp);

        isExport = xlsUtils != null;
        DataSet ds = null;
        if (isExport) {
            BatchQueryDataSet q = new BatchQueryDataSet();
            q.setConnName(Transaction.getDataSet().getConnName());
            ds = q;
        } else {

            ds = Transaction.getDataSet();
        }
        return ds;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * �d�߸�Ƥ覡 like'%key%'
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setLikeFieldsIfExsits(DataSet ds, String key, String value) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }
        return (BigDecimal) obj;
    }

}
