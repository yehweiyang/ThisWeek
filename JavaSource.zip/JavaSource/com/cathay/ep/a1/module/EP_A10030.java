package com.cathay.ep.a1.module;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.vo.DTEPA103;
import com.cathay.ep.vo.DTEPA103_LOG;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPB308;
import com.cathay.ep.vo.DTEPB309;
import com.cathay.ep.vo.DTEPB310;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE        Description  Author
 * 2013/08/29  Created      ������
 * 
 * �@�B    �{���\�෧�n�����G
 * �ҲզW��    �Ӽh�O�����@�Ҳ�
 * �Ҳ�ID     EP_A10030
 * ���n����    �Ӽh�O�����@�Ҳ�
 *</pre>
 * @author ���_��
 * @since 2013/10/8
 */
@SuppressWarnings("unchecked")
public class EP_A10030 {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EP_A10030.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.a1.module.EP_A10030.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.a1.module.EP_A10030.SQL_queryList_002";

    private static final String SQL_queryList_003 = "com.cathay.ep.a1.module.EP_A10030.SQL_queryList_003";

    private static final String SQL_queryMap_001 = "com.cathay.ep.a1.module.EP_A10030.SQL_queryMap_001";

    private static final String SQL_queryMap_002 = "com.cathay.ep.a1.module.EP_A10030.SQL_queryMap_002";

    private static final String SQL_queryMap_003 = "com.cathay.ep.a1.module.EP_A10030.SQL_queryMap_003";

    private static final String SQL_deleteDTEPB310_AdjB_001 = "com.cathay.ep.a1.module.EP_A10030.SQL_deleteDTEPB310_AdjB_001";

    private static final String SQL_deleteDTEPB310DelAll_001 = "com.cathay.ep.a1.module.EP_A10030.SQL_deleteDTEPB310DelAll_001";

    private static final String SQL_updateDTEPB310_001 = "com.cathay.ep.a1.module.EP_A10030.SQL_updateDTEPB310_001";

    private static final String SQL_updateDTEPB310_002 = "com.cathay.ep.a1.module.EP_A10030.SQL_updateDTEPB310_002";

    private static final String SQL_getDivList_001 = "com.cathay.ep.a1.module.EP_A10030.SQL_getDivList_001";

    /**
     * Ū���j�ӫǧO�O����
     * <pre>
     * @param reqMap{
     * SUB_CPY_ID = �����q�O
     * APLY_NO = �ץ�s��
     * BLD_CD = �j�ӥN��
     * FLD_NO = �Ӽh�O
     * ROOM_NO = �ǧO
     * QRY_TYPE = �d�ߺ���(1:�D��;2:������;)
     * FLD_ADJ = �վ�覡
     * }
     * </pre>
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }

        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�ץ�s���d�߮ץ�_�ǧO�O���ܧ����(DTEPB310)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", BLD_CD);
        setFieldsIfExsits(reqMap, ds, "FLD_NO");
        setFieldsIfExsits(reqMap, ds, "ROOM_NO");

        String FLD_ADJ = MapUtils.getString(reqMap, "FLD_ADJ");

        if ("1".equals(FLD_ADJ) || "2".equals(FLD_ADJ)) {
            ds.setFieldValues("FLD_ADJ", new String[] { "1", "2" });
        }

        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isNotBlank(APLY_NO)) {

            ds.setField("APLY_NO", APLY_NO);
            DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        } else if ("2".equals(MapUtils.getString(reqMap, "QRY_TYPE"))) {
            DBUtil.searchAndRetrieve(ds, SQL_queryList_002);
        } else {
            DBUtil.searchAndRetrieve(ds, SQL_queryList_003);
        }

        List<Map> rtnList = new ArrayList<Map>();
        //�v���B�z�^�ǲM��G
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //�s�W����^�ǨϥΪ��p��������, ���o�u�ϥΪ��p�����v����:
            rtnMap.put("USE_TYPE_NM", FieldOptionList.getName("EP", "USE_TYPE", MapUtils.getString(rtnMap, "USE_TYPE")));
            //�s�W����^�Ǩϥγ��ʽ褤��, ���o�u�ϥγ��ʽ�v����:
            rtnMap.put("USE_KD_NM", FieldOptionList.getName("EP", "USE_KD", MapUtils.getString(rtnMap, "USE_KD")));
            //�s�W����^�ǵ|�O����, ���o�u�|�O�v����:
            rtnMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE")));
            //�������
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            rtnList.add(rtnMap);
        }

        return rtnList;

    }

    /**
     * Ū���j�ӫǧO�O����
     * <pre>
     * @param reqMap{
     * SUB_CPY_ID = �����q�O
     * BLD_CD = �j�ӥN��
     * FLD_NO = �Ӽh�O
     * ROOM_NO = �ǧO
     * APLY_NO = �ץ�s��
     * APLY_SER_NO = �ץ�Ǹ�
     * DATA_TYPE = �������
     * QRY_TYPE = �d�ߺ��� (1:�D��;2:������)
     *}
     *</pre>
     * @return
     * @throws ModuleException
     */
    public Map queryMap(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");

        //�ˮֶǤJ�Ѽ�:
        new EPA1_0030_mod().checkMapValue(reqMap, "3");

        //�H�ǤJ�j�ӥN���B�Ӽh�O�ΫǧO�d�߮ץ�_�ǧO�ܧ����(DTEPB310)�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        ds.setField("BLD_CD", MapUtils.getString(reqMap, "BLD_CD"));
        ds.setField("FLD_NO", MapUtils.getString(reqMap, "FLD_NO"));
        ds.setField("ROOM_NO", MapUtils.getString(reqMap, "ROOM_NO"));
        if (StringUtils.isNotBlank(APLY_NO)) {
            ds.setField("APLY_NO", APLY_NO);
            setFieldsIfExsits(reqMap, ds, "APLY_SER_NO");
            setFieldsIfExsits(reqMap, ds, "DATA_TYPE");
            DBUtil.searchAndRetrieve(ds, SQL_queryMap_001);
        } else if ("2".equals(MapUtils.getString(reqMap, "QRY_TYPE"))) {
            DBUtil.searchAndRetrieve(ds, SQL_queryMap_002);
        } else {
            DBUtil.searchAndRetrieve(ds, SQL_queryMap_003);
        }

        Map rtnMap = null;
        if (ds.next()) {
            rtnMap = VOTool.dataSetToMap(ds);
            //�s�W����^�ǨϥΪ��p��������, ���o�u�ϥΪ��p�����v����:
            rtnMap.put("USE_TYPE_NM", FieldOptionList.getName("EP", "USE_TYPE", MapUtils.getString(rtnMap, "USE_TYPE")));
            //�s�W����^�Ǩϥγ��ʽ褤��, ���o�u�ϥγ��ʽ�v����:
            rtnMap.put("USE_KD_NM", FieldOptionList.getName("EP", "USE_KD", MapUtils.getString(rtnMap, "USE_KD")));
            //�s�W����^�ǵ|�O����, ���o�u�|�O�v����:
            rtnMap.put("TAX_TYPE_NM", FieldOptionList.getName("EP", "TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE")));

        }
        return rtnMap;
    }

    /**
     * �s�W�j�ӫǧO�O����
     * @param A103Vo �j��_�ǧO�O����
     * @param UPD_DATE �J�ɤ���ɶ�
     * @param UPD_APLY_NO �J�ɮץ�s��
     * @param UPD_TRN_KIND �J�ɥ������
     * @throws ModuleException 
     */
    public void insertDTEPA103(DTEPA103 A103Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {
        if (A103Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�:

        if (StringUtils.isBlank(A103Vo.getBLD_CD())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (StringUtils.isBlank(A103Vo.getFLD_NO())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_006"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        if (StringUtils.isBlank(A103Vo.getROOM_NO())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_007"));//�ǤJ�ǧO���o���ŭ�!
        }
        if (StringUtils.isBlank(A103Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�s�W�j�ӫǧO�O���� DTEPA103�G
        VOTool.insert(A103Vo);
        //�g�@��LOG��
        // this.insertLog(A103Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND);

    }

    /**
     * �R���j�ӫǧO�O����
     * @param A103Vo �j��_�ǧO�O����
     * @param UPD_DATE �J�ɤ���ɶ�
     * @param UPD_APLY_NO �J�ɮץ�s��
     * @param UPD_TRN_KIND �J�ɥ������
     * @throws ModuleException 
     */
    public void deleteDTEPA103(DTEPA103 A103Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {
        if (A103Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�:

        if (StringUtils.isBlank(A103Vo.getBLD_CD())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (StringUtils.isBlank(A103Vo.getFLD_NO())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_006"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        if (StringUtils.isBlank(A103Vo.getROOM_NO())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_007"));//�ǤJ�ǧO���o���ŭ�!
        }
        if (StringUtils.isBlank(A103Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        //�g�@��LOG��
        this.insertLog(A103Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND);
        //�R���j�ӫǧO�O���� DTEPA103�G
        VOTool.delByPK(A103Vo);

    }

    /**
     * �ק�j�ӫǧO�O����
     * @param A103Vo �j��_�ǧO�O����
     * @param UPD_DATE �J�ɤ���ɶ�
     * @param UPD_APLY_NO �J�ɤ���ɶ�
     * @param UPD_TRN_KIND �J�ɥ������
     * @throws ModuleException 
     */
    public void updateDTEPA103(DTEPA103 A103Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {
        if (A103Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�:

        if (StringUtils.isBlank(A103Vo.getBLD_CD())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (StringUtils.isBlank(A103Vo.getFLD_NO())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_006"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        if (StringUtils.isBlank(A103Vo.getROOM_NO())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_007"));//�ǤJ�ǧO���o���ŭ�!
        }
        if (StringUtils.isBlank(A103Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�g�@��LOG��
        this.insertLog(A103Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND);
        //�ק�j�ӫǧO�O���� DTEPA103�G
        VOTool.update(A103Vo);

    }

    /**
     * �ק�j�ӫǧO�O����
     * @param A103Vo �j��_�ǧO�O����
     * @param UPD_DATE �J�ɤ���ɶ�
     * @param caseMap �J�ɮץ�
     * @param UPD_TYPE ��s���
     * @throws ModuleException 
     * @throws IllegalAccessException 
     */
    public void updateDTEPA103ByInput(DTEPA103 A103Vo, String UPD_DATE, Map caseMap, String[] UPD_TYPE) throws ModuleException,
            IllegalAccessException {
        if (A103Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        if (caseMap == null || caseMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_013"));//�J�ɮץ󤣱o����
        }
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�:
        String BLD_CD = A103Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String FLD_NO = A103Vo.getFLD_NO();
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_006"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        String ROOM_NO = A103Vo.getROOM_NO();
        if (StringUtils.isBlank(ROOM_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_007"));//�ǤJ�ǧO���o���ŭ�!
        }
        String SUB_CPY_ID = A103Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�!
        }
        String APLY_NO = MapUtils.getString(caseMap, "APLY_NO");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_014"));//�ǤJ���z�s�����o���ŭ�!
        }
        String TRN_KIND = MapUtils.getString(caseMap, "TRN_KIND");
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_015"));//�ǤJ����������o���ŭ�!
        }
        String INPUT_DIV_NO = MapUtils.getString(caseMap, "INPUT_DIV_NO");
        if (StringUtils.isBlank(INPUT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_016"));//�ǤJ��J��줣�o���ŭ�!
        }
        String INPUT_ID = MapUtils.getString(caseMap, "INPUT_ID");
        if (StringUtils.isBlank(INPUT_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_017"));//�ǤJ��J�H�����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        //���o�s�h���O�����
        Map rtnMap = this.getTrnRntMap();

        if (UPD_TYPE.length > 0) {

            //�ק�ץ�_�j�ӫǧO�O���� DTEPB310�G

            Map A103Map = VOTool.voToMap(A103Vo);
            Map map = new HashMap();
            //�d�߫ǧO�D�ɸ��
            Map reqMap = new HashMap();
            reqMap.put("BLD_CD", BLD_CD);
            reqMap.put("FLD_NO", FLD_NO);
            reqMap.put("ROOM_NO", ROOM_NO);
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            Map oldMap = this.queryMap(reqMap);
            map.putAll(oldMap);
            for (String UPD_NAME : UPD_TYPE) {
                map.put(UPD_NAME, A103Map.get(UPD_NAME));
            }
            DTEPB310 newB310Vo = VOTool.mapToVO(DTEPB310.class, map);
            //�H�����ʪ�����sTABLE
            newB310Vo.setBLD_CD(BLD_CD);
            newB310Vo.setFLD_NO(FLD_NO);
            newB310Vo.setROOM_NO(ROOM_NO);
            newB310Vo.setSUB_CPY_ID(SUB_CPY_ID);
            newB310Vo.setAPLY_NO(APLY_NO);
            newB310Vo.setUPD_DATE(DATE.toTimestamp(UPD_DATE)); //�קK��s�ǧO�P�_�̤j�ͮĤ�ɧ�w��s����Ƥ]���ӧP�_

            this.update(newB310Vo, false, rtnMap, oldMap);

            //�ק�j�ӫǧO�O���� DTEPA103�G

            DTEPA103 newA103Vo = VOTool.mapToVO(DTEPA103.class, map);
            newA103Vo.setBLD_CD(BLD_CD);
            newA103Vo.setFLD_NO(FLD_NO);
            newA103Vo.setROOM_NO(ROOM_NO);
            newA103Vo.setAPLY_NO(APLY_NO);
            newA103Vo.setTRN_KIND(TRN_KIND);
            newA103Vo.setCHG_DATE(DATE.toTimestamp(UPD_DATE));
            newA103Vo.setCHG_DIV_NO(INPUT_DIV_NO);
            newA103Vo.setCHG_ID(INPUT_ID);
            newA103Vo.setCHG_NAME(MapUtils.getString(caseMap, "INPUT_NAME"));
            newA103Vo.setSUB_CPY_ID(SUB_CPY_ID);

            this.updateDTEPA103(newA103Vo, UPD_DATE, newA103Vo.getAPLY_NO(), newA103Vo.getTRN_KIND());
        }
    }

    /**
     * �s�W�ǧO�O��LOG��
     * @param A103Vo �j��_�ǧO�O����
     * @param UPD_DATE �J�ɤ���ɶ�
     * @param UPD_APLY_NO �J�ɮץ�s��
     * @param UPD_TRN_KIND �J�ɥ������
     * @throws ModuleException
     */
    public void insertLog(DTEPA103 A103Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {
        if (A103Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = A103Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        String BLD_CD = A103Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String FLD_NO = A103Vo.getFLD_NO();
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_006"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        String ROOM_NO = A103Vo.getROOM_NO();
        if (StringUtils.isBlank(ROOM_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_007"));//�ǤJ�ǧO���o���ŭ�!
        }
        if (StringUtils.isBlank(UPD_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_008"));//�ǤJ�J�ɤ���ɶ����o���ŭ�!
        }
        if (StringUtils.isBlank(UPD_APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_009"));//�ǤJ�J�ɮץ�s�����o���ŭ�!
        }
        if (StringUtils.isBlank(UPD_TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_005"));//�ǤJ�J�ɥ���������o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�g�@��LOG��

        Map reqMap = new HashMap();
        reqMap.put("BLD_CD", BLD_CD);
        reqMap.put("FLD_NO", FLD_NO);
        reqMap.put("ROOM_NO", ROOM_NO);
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        DTEPA103_LOG A103Vo_Log = VOTool.mapToVO(DTEPA103_LOG.class, this.queryMap(reqMap));
        A103Vo_Log.setUPD_DATE(DATE.toTimestamp(UPD_DATE));
        A103Vo_Log.setUPD_APLY_NO(UPD_APLY_NO);
        A103Vo_Log.setUPD_TRN_KIND(UPD_TRN_KIND);

        VOTool.insert(A103Vo_Log);

    }

    /**
     * �s�W�ץ�ǧO�O����
     * @param B310Vo �ץ�_�j�ӫǧO�O����
     * @throws ModuleException 
     */
    public void insertDTEPB310(DTEPB310 B310Vo) throws ModuleException {
        if (B310Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        //�ˮֶǤJ�Ѽ�:
        new EPA1_0030_mod().checkValue(B310Vo);
        //�s�W�ץ�ǧO�O���� DTEPB310�G
        if (B310Vo.getAPLY_SER_NO() == null) {
            B310Vo.setAPLY_SER_NO(new EP_Z0Z001().createNextNumber(B310Vo.getSUB_CPY_ID(), "015", B310Vo.getAPLY_NO(), B310Vo.getBLD_CD()
                    .toString()));
        }

        VOTool.insert(B310Vo);

    }

    /**
     * �R���ץ�ǧO�O����
     * @param B310Vo �ץ�_�j�ӫǧO�O����
     * @throws ModuleException 
     */
    public void deleteDTEPB310(DTEPB310 B310Vo) throws ModuleException {
        if (B310Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        //�ˮֶǤJ�Ѽ�:
        new EPA1_0030_mod().checkValue(B310Vo);
        //�Y�������A�ɶ��NB�]�@�֧R��
        if ("A".equals(B310Vo.getDATA_TYPE())) {
            if ("1".equals(B310Vo.getFLD_ADJ()) || "2".equals(B310Vo.getFLD_ADJ())) {
                Map reqMap = new HashMap();
                reqMap.put("APLY_NO", B310Vo.getAPLY_NO());
                reqMap.put("SUB_CPY_ID", B310Vo.getSUB_CPY_ID());
                reqMap.put("BLD_CD", B310Vo.getBLD_CD());
                reqMap.put("FLD_NO", B310Vo.getFLD_NO());
                reqMap.put("FLD_ADJ", "1");
                List<Map> rtnCList = this.queryList(reqMap);
                int fldAdjCnt = 0;
                for (Map data : rtnCList) {
                    String fldAdj = MapUtils.getString(data, "FLD_ADJ");
                    if ("A".equals(MapUtils.getString(data, "DATA_TYPE")) && ("1".equals(fldAdj) || "2".equals(fldAdj))) {
                        fldAdjCnt++;
                    }
                }

                //�R���̫�@������վ���ӡA�N���ʫe���Ӥ@�_�R��
                if (fldAdjCnt == 1) {
                    this.deleteDTEPB310_AdjB(B310Vo);
                }
            } else {
                B310Vo.setDATA_TYPE("B");
                VOTool.delByPK(B310Vo);
                B310Vo.setDATA_TYPE("A");
            }
        }
        //�R���ץ�ǧO�O���� DTEPB310�G
        VOTool.delByPK(B310Vo);

    }

    /**
     * �R���ץ�j�ӼӼh���ΦX�ְO����
     * @param B310Vo �ץ�_�j�ӼӼh�ǧO�O����
     * @throws ModuleException
     */
    public void deleteDTEPB310_AdjB(DTEPB310 B310Vo) throws ModuleException {
        if (B310Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }

        String SUB_CPY_ID = B310Vo.getSUB_CPY_ID();
        String APLY_NO = B310Vo.getAPLY_NO();
        String BLD_CD = B310Vo.getBLD_CD();
        String FLD_NO = B310Vo.getFLD_NO();

        ErrorInputException eie = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_010"));//�ǤJ�ץ�s�����o���ŭ�!
        }
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_006"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("FLD_NO", FLD_NO);

        DBUtil.executeUpdate(ds, SQL_deleteDTEPB310_AdjB_001);

    }

    /**
     * �ק�ץ�ǧO�O����
     * @param B310Vo �ץ�_�j�ӫǧO�O����
     * @throws ModuleException 
     */
    public void updateDTEPB310(DTEPB310 B310Vo) throws ModuleException {
        if (B310Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }

        //�ˮֶǤJ�Ѽ�:
        new EPA1_0030_mod().checkValue(B310Vo);

        String strRNT_TP = B310Vo.getRNT_TP();

        B310Vo.setRNT_TP(this.getRNT_TP(B310Vo.getDATA_TYPE(), strRNT_TP, B310Vo.getFLD_ADJ(), B310Vo.getCRT_NO()));
        if ("A".equals(B310Vo.getDATA_TYPE())) {

            Map reqMap = new HashMap();
            reqMap.put("APLY_NO", B310Vo.getAPLY_NO());
            reqMap.put("BLD_CD", B310Vo.getBLD_CD());
            reqMap.put("FLD_NO", B310Vo.getFLD_NO());
            reqMap.put("ROOM_NO", B310Vo.getROOM_NO());
            reqMap.put("SUB_CPY_ID", B310Vo.getSUB_CPY_ID());
            reqMap.put("DATA_TYPE", "B");
            if (!"1".equals(B310Vo.getFLD_ADJ()) && !"2".equals(B310Vo.getFLD_ADJ())) {
                Map oldMap = this.queryMap(reqMap);
                String B_RNT_TP = getRNT_TP("B", strRNT_TP, MapUtils.getString(oldMap, "FLD_ADJ"), MapUtils.getString(oldMap, "CRT_NO"));

                if (!B_RNT_TP.equals(MapUtils.getString(oldMap, "RNT_TP"))) {
                    DataSet ds = Transaction.getDataSet();
                    ds.setField("RNT_TP", MapUtils.getString(oldMap, "RNT_TP"));
                    ds.setField("APLY_NO", MapUtils.getString(oldMap, "APLY_NO"));
                    ds.setField("APLY_SER_NO", MapUtils.getString(oldMap, "APLY_SER_NO"));
                    ds.setField("DATA_TYPE", MapUtils.getString(oldMap, "DATA_TYPE"));
                    ds.setField("SUB_CPY_ID", MapUtils.getString(oldMap, "SUB_CPY_ID"));
                    DBUtil.executeUpdate(ds, SQL_updateDTEPB310_001);
                }
            }

        }

        //�ק�ץ�ǧO�O���� DTEPB310�G
        VOTool.update(B310Vo);

    }

    /**
     * �s�W�ץ�ǧO�O����
     * @param B309Vo �ץ�_�j�Ӱ򥻸����
     * @throws ModuleException
     */
    public void insertDTEPB310DelAll(DTEPB309 B309Vo) throws ModuleException {
        if (B309Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = B309Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        String APLY_NO = B309Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_010"));//�ǤJ�ץ�s�����o���ŭ�!
        }
        String BLD_CD = B309Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String DATA_TYPE = B309Vo.getDATA_TYPE();
        if (StringUtils.isBlank(DATA_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_012"));//�ǤJ����������o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        DTEPB308 B308Vo = new DTEPB308();
        B308Vo.setSUB_CPY_ID(SUB_CPY_ID);
        B308Vo.setAPLY_NO(APLY_NO);
        B308Vo.setBLD_CD(BLD_CD);
        B308Vo.setDATA_TYPE(DATA_TYPE);

        this.insertDTEPB310DelAll(B308Vo, B309Vo.getFLD_NO());

    }

    /**
     * �s�W�ץ�ǧO�O����
     * @param B308Vo �ץ�_�j�Ӱ򥻸����
     * @param FLD_NO �Ӽh
     * @throws ModuleException
     */
    public void insertDTEPB310DelAll(DTEPB308 B308Vo, String FLD_NO) throws ModuleException {
        if (B308Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = B308Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        String APLY_NO = B308Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_010"));//�ǤJ�ץ�s�����o���ŭ�!
        }
        String BLD_CD = B308Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        String DATA_TYPE = B308Vo.getDATA_TYPE();

        if (!"D".equals(DATA_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_011"));//����R���@�~���~!
        }
        if (StringUtils.isBlank(DATA_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_012"));//�ǤJ����������o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�s�W�ץ�ǧO�O���� DTEPB310�G
        Map reqMap = new HashMap();
        reqMap.put("BLD_CD", BLD_CD);
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);

        if (StringUtils.isNotBlank(FLD_NO)) {
            reqMap.put("FLD_NO", FLD_NO);
        } else {
            FLD_NO = "";
        }
        List<Map> rtnList = this.queryList(reqMap);
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        for (Map rtnMap : rtnList) {

            DTEPB310 B310Vo = VOTool.mapToVO(DTEPB310.class, rtnMap);
            B310Vo.setAPLY_NO(APLY_NO);
            B310Vo.setDATA_TYPE(DATA_TYPE);
            B310Vo.setAPLY_SER_NO(theEP_Z0Z001.createNextNumber(B310Vo.getSUB_CPY_ID().toString(), "015", B310Vo.getAPLY_NO().toString(),
                B310Vo.getBLD_CD().toString()));
            B310Vo.setDATA_TYPE("D");
            B310Vo.setRNT_TP("0");
            VOTool.insert(B310Vo);
        }

    }

    /**
     * �ק�
     * <pre>
     * @param B310Vo �ץ�_�ǧO�O����
     * @param isUpB301 True:��s
     *            False:����s      
     *</pre>
     * @throws ModuleException 
     * @throws ModuleException
     */
    public void update(DTEPB310 B310Vo, boolean isUpB301) throws ModuleException {
        update(B310Vo, isUpB301, null, null);
    }

    /**
     * �ק�
     * <pre>
     * @param B310Vo �ץ�_�ǧO�O����
     * @param isUpB301 True:��s
     *            False:����s
     * @param rtnMap �s�h���O��Ӫ�   
     * @param oldMap Map �ǧO���ʫe�D�ɸ��
     *</pre>
     * @throws ModuleException
     */
    public void update(DTEPB310 B310Vo, boolean isUpB301, Map aMap, Map oldMap) throws ModuleException {
        if (B310Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        ErrorInputException eie = null;
        String FLD_NO = B310Vo.getFLD_NO();
        String ROOM_NO = B310Vo.getROOM_NO();
        String SUB_CPY_ID = B310Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(ROOM_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_007"));//�ǤJ�ǧO���o���ŭ�!
        }
        if (StringUtils.isBlank(FLD_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_006"));//�ǤJ�Ӽh�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        String BLD_CD = B310Vo.getBLD_CD();
        //����s�W�{��(�ק�ɼW�[2����ơA�@�����ʫe�A�@�����ʫ�)

        //���ʫ�
        //���o�B�z�Ǹ�
        B310Vo.setAPLY_SER_NO(new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "015", B310Vo.getAPLY_NO(), BLD_CD));

        B310Vo.setDATA_TYPE("A");
        Map rtnMap;
        String APLY_NO = B310Vo.getAPLY_NO();
        //���ʫe
        if (oldMap == null || oldMap.isEmpty()) {
            //�d�ߥD�ɸ��

            Map reqMap = new HashMap();
            reqMap.put("BLD_CD", BLD_CD);
            reqMap.put("FLD_NO", FLD_NO);
            reqMap.put("ROOM_NO", ROOM_NO);
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            rtnMap = this.queryMap(reqMap);
        } else {
            rtnMap = oldMap;
        }

        DTEPB310 oldB310Vo = VOTool.mapToVO(DTEPB310.class, rtnMap);
        oldB310Vo.setDATA_TYPE("B");
        oldB310Vo.setAPLY_NO(APLY_NO);
        oldB310Vo.setAPLY_SER_NO(B310Vo.getAPLY_SER_NO());
        oldB310Vo.setUPD_DATE(B310Vo.getUPD_DATE()); //����ܧ�᪺UPD_DATE
        oldB310Vo.setFLD_ADJ(B310Vo.getFLD_ADJ());

        //�P�_�s�h���O
        this.setRntType(B310Vo, oldB310Vo, aMap, null);

        //�s�W���ʫe����
        this.insertDTEPB310(B310Vo);

        //�s�W���ʫ����
        this.insertDTEPB310(oldB310Vo);

        if (isUpB301) {
            //�ק�ץ��ܧ������T
            DTEPB301 DTEPB301 = new DTEPB301();
            DTEPB301.setAPLY_NO(APLY_NO);
            DTEPB301.setBLD_CD(BLD_CD);
            DTEPB301.setSUB_CPY_ID(SUB_CPY_ID);
            new EP_B30010().updateDTEPB301MainInfo(DTEPB301);
        }
    }

    /**
     * �s�W 
     * @param B310Vo �ץ�_�ǧO�O����
     * @param FLD_ADJ �ǧO�վ�覡
     * @param RNT_TYPE �s���h���O(0:�L;1:�s��;2:�h��;3:��)
     * @param rtnCList �D�ɦX�֤��βM��
     * @throws ModuleException
     */
    public void insert(DTEPB310 B310Vo, String FLD_ADJ, String RNT_TYPE, List<Map> rtnCList) throws ModuleException {
        if (B310Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }

        String strRNT_TP = B310Vo.getRNT_TP();
        String APLY_NO = B310Vo.getAPLY_NO();
        if ("1".equals(FLD_ADJ) || "2".equals(FLD_ADJ)) {
            //�R�����ΦX�ֽվ�e����
            try {
                this.deleteDTEPB310_AdjB(B310Vo);
            } catch (DataNotFoundException dnfe) {
                log.error("�R�L��Ʀ��������`", dnfe);//�R�L��Ƶ������`�A����X���~
            }

            //�v���B�z�D�ɦX�֤��βM��
            for (Map rtnMap : rtnCList) {
                DTEPB310 vo = VOTool.mapToVO(DTEPB310.class, rtnMap);
                vo.setDATA_TYPE("B");
                vo.setFLD_ADJ(FLD_ADJ);
                vo.setAPLY_NO(APLY_NO);
                vo.setAPLY_SER_NO(null);
                vo.setRNT_TP(getRNT_TP(vo.getDATA_TYPE(), strRNT_TP, vo.getFLD_ADJ(), vo.getCRT_NO()));
                this.insertDTEPB310(vo);
            }
            //�p�G���ΦX�֡A�վ㲧�ʺ����� �ק��
            B310Vo.setDATA_TYPE("A");
            B310Vo.setRNT_TP(getRNT_TP(B310Vo.getDATA_TYPE(), strRNT_TP, FLD_ADJ, B310Vo.getCRT_NO()));

        } else {
            B310Vo.setRNT_TP(getRNT_TP(B310Vo.getDATA_TYPE(), strRNT_TP, FLD_ADJ, B310Vo.getCRT_NO()));
        }
        B310Vo.setAPLY_SER_NO(null);
        this.insertDTEPB310(B310Vo);

        //�ק�ץ��ܧ������T
        DTEPB301 DTEPB301 = new DTEPB301();
        DTEPB301.setAPLY_NO(APLY_NO);
        DTEPB301.setBLD_CD(B310Vo.getBLD_CD());
        DTEPB301.setSUB_CPY_ID(B310Vo.getSUB_CPY_ID());
        new EP_B30010().updateDTEPB301MainInfo(DTEPB301);

    }

    /**
     * �R��
     * @param B310Vo �ץ�_�ǧO�O����
     * @throws ModuleException 
     */
    public void delete(DTEPB310 B310Vo) throws ModuleException {
        if (B310Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }
        B310Vo.setRNT_TP("0");
        this.insertDTEPB310(B310Vo);
        updateDTEPB301MainInfo(B310Vo);

    }

    private void updateDTEPB301MainInfo(DTEPB310 B310Vo) throws ModuleException {
        //�ק�ץ��ܧ������T
        DTEPB301 DTEPB301 = new DTEPB301();
        DTEPB301.setAPLY_NO(B310Vo.getAPLY_NO());
        DTEPB301.setBLD_CD(B310Vo.getBLD_CD());
        DTEPB301.setSUB_CPY_ID(B310Vo.getSUB_CPY_ID());
        new EP_B30010().updateDTEPB301MainInfo(DTEPB301);
    }

    /**
     * �վ�
     * @param B310Vo �ץ�_�ǧO�O����
     * @throws ModuleException 
     */
    public void change(DTEPB310 B310Vo) throws ModuleException {
        this.updateDTEPB310(B310Vo);
        updateDTEPB301MainInfo(B310Vo);

    }

    /**
     * �f��ץ��s�ǧO�D�ɸ��
     * @param BLD_CD �j�ӥN��
     * @param voB301 �߮׮ץ�
     * @param UPD_TIME ���ʤ���ɶ�
     * @throws ModuleException
     */
    public void approve(String BLD_CD, DTEPB301 voB301, String UPD_TIME) throws ModuleException {
        if (voB301 == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10030_MSG_001"));//�ɮװ򥻸���ɤ��o����
        }

        String APLY_NO = voB301.getAPLY_NO();
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", voB301.getSUB_CPY_ID()); //�����q�O
        reqMap.put("BLD_CD", BLD_CD);
        reqMap.put("APLY_NO", APLY_NO); //�ץ�s��

        //�d�߲��ʩ���
        try {
            List<Map> updList = queryList(reqMap);
            //�B�z���

            //���o�̤j�_����
            String MAX_STR_DT = "1911-01-01";
            for (Map upd : updList) {

                String date = MapUtils.getString(upd, "RNT_STR_DATE");
                if (StringUtils.isNotBlank(date) && DATE.isDate(date)) {
                    if (DATE.diffDay(MAX_STR_DT, date) > 0) {
                        MAX_STR_DT = date;
                    }
                }
            }

            Timestamp PCD_DT = DATE.toTimestamp(UPD_TIME);
            //�v���B�z���ʩ���
            for (Map upd : updList) {
                DTEPA103 voA103 = VOTool.mapToVO(DTEPA103.class, upd);
                voA103.setAPLY_NO(APLY_NO);
                voA103.setTRN_KIND(voB301.getTRN_KIND());
                voA103.setCHG_DATE(PCD_DT);
                voA103.setCHG_DIV_NO(voB301.getINPUT_DIV_NO());
                voA103.setCHG_ID(voB301.getINPUT_ID());
                voA103.setCHG_NAME(voB301.getINPUT_NAME());
                voA103.setSUB_CPY_ID(voB301.getSUB_CPY_ID());
                //�w����A�_���������A����s���ʸ�ƨ�D��(���P�_�O�_�w��s, �H�K�P�_��ӯ��鬰�ŭȪ����p)
                String FLD_ADJ = MapUtils.getString(upd, "FLD_ADJ");
                String RNT_STR_DATE = MapUtils.getString(upd, "RNT_STR_DATE");
                boolean isRentStart = (Date.valueOf(MAX_STR_DT).compareTo(DATE.timestampToDate(PCD_DT)) <= 0)
                        || (StringUtils.isNotBlank(RNT_STR_DATE) && Date.valueOf(RNT_STR_DATE).compareTo(DATE.timestampToDate(PCD_DT)) <= 0);

                if (!"Y".equals(voB301.getIS_REG())
                        || ("Y".equals(voB301.getIS_REG()) && StringUtils.isBlank(MapUtils.getString(upd, "UPD_DATE")) && (isRentStart || StringUtils
                                .isBlank(RNT_STR_DATE)))) {
                    if ("I".equals(upd.get("DATA_TYPE"))) {

                        insertDTEPA103(voA103, UPD_TIME, APLY_NO, voB301.getTRN_KIND());

                    } else if ("D".equals(upd.get("DATA_TYPE"))) {

                        deleteDTEPA103(voA103, UPD_TIME, APLY_NO, voB301.getTRN_KIND());

                    } else if ("A".equals(upd.get("DATA_TYPE"))) {

                        if ("1".equals(FLD_ADJ) || "2".equals(FLD_ADJ)) {

                            insertDTEPA103(voA103, UPD_TIME, APLY_NO, voB301.getTRN_KIND());

                        } else {

                            updateDTEPA103(voA103, UPD_TIME, APLY_NO, voB301.getTRN_KIND());

                        }
                    } else if ("B".equals(upd.get("DATA_TYPE"))) {
                        //���ݲ��ʳB�z
                        if ("1".equals(FLD_ADJ) || "2".equals(FLD_ADJ)) {

                            deleteDTEPA103(voA103, UPD_TIME, APLY_NO, voB301.getTRN_KIND());

                        }
                    }

                    if ("Y".equals(voB301.getIS_REG())) {
                        if ("B".equals(upd.get("DATA_TYPE"))) {
                            continue;
                        }
                        DataSet ds = Transaction.getDataSet();
                        ds.setField("UPD_DATE", PCD_DT);
                        ds.setField("APLY_NO", MapUtils.getString(upd, "APLY_NO"));
                        ds.setField("APLY_SER_NO", MapUtils.getString(upd, "APLY_SER_NO"));
                        ds.setField("SUB_CPY_ID", MapUtils.getString(upd, "SUB_CPY_ID"));
                        if ("1".equals(FLD_ADJ) || "2".equals(FLD_ADJ)) {
                            ds.setField("DATA_TYPE", MapUtils.getString(upd, "DATA_TYPE"));
                        }

                        DBUtil.executeUpdate(ds, SQL_updateDTEPB310_002);
                    }

                }
            }
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L�������`", dnfe);//�d�L�������`
        }

    }

    /**
     * �簣�R���ץ�ǧO�O����
     * @param APLY_NO  String  ���z�s��
     * @param SUB_CPY_ID  String  �����q
     * @param BLD_CD String  �j�ӥN��
     * @param FLD_NO  String  �Ӽh
     */
    public void deleteDTEPB310DelAll(String APLY_NO, String SUB_CPY_ID, String BLD_CD, String FLD_NO) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_010"));//�ǤJ�ץ�s�����o���ŭ�!
        }
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_003"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_A10030_MSG_002"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�s�W�ץ�ǧO�O���� DTEPB310�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (StringUtils.isNotBlank(FLD_NO)) {
            ds.setField("FLD_NO", FLD_NO);
        }
        //�R�������Ƶ������`
        DBUtil.executeUpdate(ds, SQL_deleteDTEPB310DelAll_001, false);
    }

    /**
     * ���o�ϥγ���ĳ�M��
     * [20190724] �R�������n�Ѽƨýվ��k
     * @param SUB_CPY_ID �����q�O
     * @param USE_DIV_NAME ���W��
     * @return �ϥγ���ĳ�M��
     * @throws ModuleException
     */
    public List<Map> getDivList(String USE_DIV_NAME) throws ModuleException {
        if (StringUtils.isBlank(USE_DIV_NAME)) {
            return Collections.EMPTY_LIST;
        }
        DataSet ds = Transaction.getDataSet();
        StringBuilder sb = new StringBuilder();
        ds.setField("USE_DIV_NAME", sb.append('%').append(USE_DIV_NAME).append('%').toString());
        return VOTool.findToMaps(ds, SQL_getDivList_001);
    }

    /**
     *  ���o������O�s�h��������
     * @return ������O�s�h��������
     * @throws ModuleException
     */
    public Map getTrnRntMap() throws ModuleException {
        Map rntMap = FieldOptionList.getName("EP", "TRN_RNT_TP");
        return rntMap;
    }

    /**
     * ���o������O�s�h��������
     * @param newB310 ���ʫ�ǧO����
     * @param oldB310 ���ʫe�ǧO����
     * @param rntMap ������O�s�h��������
     * @param vo301 �߮׳�
     * @throws ModuleException 
     */
    public boolean setRntType(DTEPB310 newB310, DTEPB310 oldB310, Map rtnMap, DTEPB301 vo301) throws ModuleException {
        //���o�߮׳�
        if (vo301 == null) {
            vo301 = new DTEPB301();
            vo301.setAPLY_NO(newB310.getAPLY_NO());
            vo301.setSUB_CPY_ID(newB310.getSUB_CPY_ID());
            vo301 = VOTool.findByPK(vo301);
        }
        boolean updateOld = false;

        //���o������O�P�s�h���O�h�Ӫ�
        if (rtnMap == null || rtnMap.isEmpty()) {
            rtnMap = getTrnRntMap();
        }

        String DATA_TYPE = newB310.getDATA_TYPE();
        if ("I".equals(DATA_TYPE)) {

            //�̫ǧO���ʧP�_
            newB310.setRNT_TP("1");

        } else if ("A".equals(DATA_TYPE)) {
            String TRN_KIND = vo301.getTRN_KIND();
            String RNT_TP = MapUtils.getString(rtnMap, TRN_KIND, "T"); //�L�ȵ���T��
            if ("2".equals(RNT_TP) && StringUtils.isEmpty(newB310.getCRT_NO())) {
                newB310.setRNT_TP("0");
                if (StringUtils.isNotEmpty(oldB310.getCRT_NO())) {
                    updateOld = setOldRntType(oldB310, "2");
                } else {
                    updateOld = setOldRntType(oldB310, "0");
                }

            } else if (("1".equals(RNT_TP) || "3".equals(RNT_TP)) && StringUtils.isNotEmpty(newB310.getCRT_NO())) {

                newB310.setRNT_TP(RNT_TP);
                if (StringUtils.isNotEmpty(oldB310.getCRT_NO()) && !"3".equals(RNT_TP) && !newB310.getCRT_NO().equals(oldB310.getCRT_NO())) {
                    updateOld = setOldRntType(oldB310, "2");
                } else {
                    updateOld = setOldRntType(oldB310, "0");
                }

                oldB310.setRNT_TP("0");

            } else if ("T".equals(RNT_TP) || "1".equals(RNT_TP) || "2".equals(RNT_TP) || "3".equals(RNT_TP)) {
                if (newB310 != null && oldB310 != null) {

                    if (StringUtils.isNotBlank(oldB310.getCRT_NO())) {
                        //OLD�X��, NEW ���X��
                        if (StringUtils.isBlank(newB310.getCRT_NO())) {
                            updateOld = setOldRntType(oldB310, "2");

                            newB310.setRNT_TP("0");
                        } else {

                            //�ӯ��Ȥ�ۦP
                            updateOld = setOldRntType(oldB310, "0");
                            newB310.setRNT_TP("0");
                        }
                    } else if (StringUtils.isNotBlank(newB310.getCRT_NO())) {

                        //OLD ���X��, NEW �X��
                        if ("T".equals(RNT_TP)) {
                            newB310.setRNT_TP("1");
                        } else {
                            newB310.setRNT_TP(RNT_TP);
                        }
                        updateOld = setOldRntType(oldB310, "0");
                    } else {
                        updateOld = setOldRntType(oldB310, "0");
                        newB310.setRNT_TP("0");

                    }
                }
            } else {

                newB310.setRNT_TP("0");

                if (oldB310 != null) {
                    updateOld = setOldRntType(oldB310, "0");

                }
            }
        }
        return updateOld;

    }

    /**
     *  �]�w�ӯ�����
     * @param DATA_TYPE ���ʺ���
     * @param RNT_TP �ӯ��O (0:�L;1:�s��;2:�h��;3:��)
     * @param FLD_ADJ ���ΦX��
     * @param CRT_NO
     * @return
     */
    public String getRNT_TP(String DATA_TYPE, String RNT_TP, String FLD_ADJ, String CRT_NO) {

        String strRNT_TP = "0";
        if ("1".equals(RNT_TP) || "3".equals(RNT_TP)) {//1:�s��
            if ("A".equals(DATA_TYPE) || "I".equals(DATA_TYPE)) {
                strRNT_TP = RNT_TP;
            } else if (StringUtils.isNotBlank(CRT_NO) && "B".equals(DATA_TYPE) && ("1".equals(FLD_ADJ) || "2".equals(FLD_ADJ))) {
                strRNT_TP = "2";
            }
        } else if ("2".equals(RNT_TP)) { //2:�h��
            if (StringUtils.isNotBlank(CRT_NO) && "B".equals(DATA_TYPE)) {
                strRNT_TP = "2";
            }
        }

        return strRNT_TP;

    }

    private boolean setOldRntType(DTEPB310 oldB310, String RNT_TP) {
        boolean flag = false;
        if (oldB310.getRNT_TP() != null && !oldB310.getRNT_TP().equals(RNT_TP)) {
            flag = true;
        }
        oldB310.setRNT_TP(RNT_TP);
        return flag;
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

    /**
     * �d�߸�Ƥ覡 like'%key%'
     * @param reqMap
     * @param ds
     * @param key
     */
    /*
    private void setLikeFieldsIfExsits(String value, DataSet ds, String key, StringBuilder sb) {
        if (StringUtils.isNotBlank(value)) {
            sb.append('%').append(value).append('%');
            ds.setField(key, sb.toString());
            sb.setLength(0);
        }
    }
    */
    /**
     * �]�w�d�߸��
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setFieldsIfExsits(Map reqMap, DataSet ds, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {

            ds.setField(key, value);

        }
    }

}
