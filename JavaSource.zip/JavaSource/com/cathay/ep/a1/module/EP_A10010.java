package com.cathay.ep.a1.module;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.LRUMap;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.hr.Employee;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.cache.CacheManager;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.a3.module.EP_A30040;
import com.cathay.ep.a3.module.EP_A30050;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.vo.DTEPA101;
import com.cathay.ep.vo.DTEPA101_LOG;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPB308;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0F170;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 *   DATE       Description  Author
 *   2013/07/01  Created     ����i
 *   2018/02/23  �s�W�d�߼Ҳ�for�겣�޲z�t��     ����[
 *   2018/03/05  ���     ����[
 *   
 *   �@�B  �{���\�෧�n�����G
 *         �ҲզW��    �򥻸�ƺ��@�Ҳ�
 *         �Ҳ�ID    EP_A10010
 *         ���n����    �򥻸�ƺ��@�Ҳ�
 * 
 * </pre>
 * 
 * @author �x�Ԫ�
 * @since 2013-08-13
 * 
 * @version 2018/01/26 ���~��:�s��µ�t�γB�z�[�J���P��/��H��
 * 
 * 2019/06/27 �©s��  �s�W�޲z���ӿ�d��API
 * 
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_A10010 {
    private static final Logger log = Logger.getLogger(EP_A10010.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.a1.module.EP_A10010.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.a1.module.EP_A10010.SQL_queryList_002";

    private static final String SQL_queryMap_001 = "com.cathay.ep.a1.module.EP_A10010.SQL_queryMap_001";

    private static final String SQL_queryMap_002 = "com.cathay.ep.a1.module.EP_A10010.SQL_queryMap_002";

    private static final String SQL_updateSum_001 = "com.cathay.ep.a1.module.EP_A10010.SQL_updateSum_001";

    private static final String SQL_updateSum_002 = "com.cathay.ep.a1.module.EP_A10010.SQL_updateSum_002";

    private static final String SQL_updateSum_003 = "com.cathay.ep.a1.module.EP_A10010.SQL_updateSum_003";

    private static final String SQL_updateSum_004 = "com.cathay.ep.a1.module.EP_A10010.SQL_updateSum_004";

    private static final String SQL_queryMap_003 = "com.cathay.ep.a1.module.EP_A10010.SQL_queryMap_003";

    private static final String SQL_updateBatch_001 = "com.cathay.ep.a1.module.EP_A10010.SQL_updateBatch_001";

    private static final String SQL_updateDTEPA101Batch_001 = "com.cathay.ep.a1.module.EP_A10010.SQL_updateDTEPA101Batch_001";

    private static final String SQL_updateDTEPA101Batch_002 = "com.cathay.ep.a1.module.EP_A10010.SQL_updateDTEPA101Batch_002";

    private static Map cacheMap;

    private static Map cacheMap_getDivMemberList;

    private static EP_Z00030 theEP_Z00030 = new EP_Z00030();

    private static DivData dd = new DivData();

    private static final String SQL_setSumInfo_001 = "com.cathay.ep.a1.module.EP_A10010.SQL_setSumInfo_001";

    private static final String SQL_setSumInfo_002 = "com.cathay.ep.a1.module.EP_A10010.SQL_setSumInfo_002";

    private static final String SQL_setSumInfo_003 = "com.cathay.ep.a1.module.EP_A10010.SQL_setSumInfo_003";

    private static final String SQL_setSumInfo_004 = "com.cathay.ep.a1.module.EP_A10010.SQL_setSumInfo_004";

    private static final String SQL_setSumInfo_007 = "com.cathay.ep.a1.module.EP_A10010.SQL_setSumInfo_007";

    private static final String SQL_queryForDVEPA900_001 = "com.cathay.ep.a1.module.EP_A10010.SQL_queryForDVEPA900_001";

    private static final String SQL_queryForEHD_001 = "com.cathay.ep.a1.module.EP_A10010.SQL_queryForEHD_001";

    private static final String SQL_qryDivAgentList_001 = "com.cathay.ep.a1.module.EP_A10010.SQL_qryDivAgentList_001";

    private static final String SQL_qryBuild_001 = "com.cathay.ep.a1.module.EP_A10010.SQL_qryBuild_001";

    static {
        cacheMap = CacheManager.register("EP_A10010_getDivName_���W��", new LRUMap(20));

        cacheMap_getDivMemberList = CacheManager.register("EP_A10010_DivData.getDivMember", new LRUMap(10));
    }

    /**
     * Ū���j�Ӱ򥻸���ɲM��
     * 
     * @param reqMap
     *            <pre>
     *              SUB_CPY_ID = �����q�O
     *              APLY_NO = �ץ�s��
     *              BLD_CD = �j�ӥN��
     *              BLD_NAME = �j�ӦW��
     *              BLD_ADDR = �a�}
     * </pre>
     * @return List<Map> �j�Ӱ򥻸����DTEPA101(�h��)
     */
    public List<Map> queryList(Map reqMap) throws ModuleException, SQLException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10010_MSG_001"));// �j�Ӱ򥻸�Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));// �����q�O���o���ŭ�
        }

        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        DataSet ds = Transaction.getDataSet();
        StringBuilder sb = new StringBuilder();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList;
        if (StringUtils.isNotBlank(APLY_NO)) {
            // �H�ǤJ�����q�O�d�߮ץ�_�j�Ӱ򥻸���ܧ����(DTEPB308)�G
            ds.setField("APLY_NO", APLY_NO);
            setLikeFieldsIfExsits(reqMap, ds, "BLD_CD", sb);
            setLikeFieldsIfExsits(reqMap, ds, "BLD_NAME", sb);
            setLikeFieldsIfExsits(reqMap, ds, "BLD_ADDR", sb);
            setFieldIfExsits(reqMap, ds, "CLC_DIV_NO");

            rtnList = VOTool.findToMaps(ds, SQL_queryList_001);
        } else {
            // �H�ǤJ�����q�O�d�ߤj�Ӱ򥻸����(DTEPA101)�G
            setLikeFieldsIfExsits(reqMap, ds, "BLD_CD", sb);
            setLikeFieldsIfExsits(reqMap, ds, "BLD_NAME", sb);
            setLikeFieldsIfExsits(reqMap, ds, "BLD_ADDR", sb);
            rtnList = VOTool.findToMaps(ds, SQL_queryList_002);
        }
        // �v���B�z�^�ǲM��G
        // �s�W����^�ǲM��
        for (Map rtnMap : rtnList) {
            String CURR = MapUtils.getString(rtnMap, "CURR");
            String TRN_KIND = MapUtils.getString(rtnMap, "TRN_KIND");
            String CLC_DIV_NO = MapUtils.getString(rtnMap, "CLC_DIV_NO");
            if (StringUtils.isNotBlank(CURR)) {
                rtnMap.put("CURR_NM", FieldOptionList.getName("EP", "CURR", CURR));
            }
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", TRN_KIND));
            if (StringUtils.isNotBlank(CLC_DIV_NO)) {

                rtnMap.put("CLC_DIV_NO_NM", this.getDivName(CLC_DIV_NO, SUB_CPY_ID));

            }
        }

        return rtnList;
    }

    /**
     * Ū���j�Ӱ򥻸����
     * 
     * @param reqMap
     *            <pre>
     *          SUB_CPY_ID = �����q�O
     *          BLD_CD = �j�ӥN��
     *          APLY_NO = �ץ�s��
     *          DATA_TYPE = �������
     * </pre>
     * @return rtnMap Map �j�Ӱ򥻸����
     */
    public Map queryMap(Map reqMap) throws SQLException, ModuleException {
        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_A10010_MSG_001");// �j�Ӱ򥻸�Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", BLD_CD);

        Map rtnMap = null;
        if (StringUtils.isNotBlank(APLY_NO)) {
            ds.setField("APLY_NO", APLY_NO);
            setFieldIfExsits(reqMap, ds, "DATA_TYPE");
            List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryMap_001, false);
            if (rtnList != null) {
                for (Map map : rtnList) {
                    String DATA_TYPE = MapUtils.getString(map, "DATA_TYPE");
                    if ("I".equals(DATA_TYPE) || "A".equals(DATA_TYPE) || "D".equals(DATA_TYPE)) {
                        rtnMap = map;
                        rtnMap.put("SOURCE", "B");
                        break;
                    }
                }
            }
        }
        // �d�L����~��B�z
        if (rtnMap == null) {
            ds.clear();
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("BLD_CD", BLD_CD);
            if ("2".equals(MapUtils.getString(reqMap, "QRY_TYPE"))) {
                rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_003);
            } else {
                rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_002);
                rtnMap.put("SOURCE", "A");

            }

        }
        // �s�W����^�ǹ��O����, ���o�u���O�v����:

        String TRN_KIND = MapUtils.getString(rtnMap, "TRN_KIND");
        String CLC_DIV_NO = MapUtils.getString(rtnMap, "CLC_DIV_NO");
        String CURR = MapUtils.getString(rtnMap, "CURR");
        if (StringUtils.isNotBlank(CURR)) {
            // rtnMap.put("CURR_NM", new
            // RZ_D00203().queryKey(CURR).getCHI_NM());
            rtnMap.put("CURR_NM", FieldOptionList.getName("EP", "CURR", CURR));
        }
        rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", TRN_KIND));
        if (StringUtils.isNotBlank(CURR)) {
            //rtnMap.put("CLC_DIV_NO_NM", new DivData().getUnit4ShortName(CLC_DIV_NO));
            //2018-03-13 �վ���W�٧���Ҳ�
            rtnMap.put("CLC_DIV_NO_NM", this.getDivName(CLC_DIV_NO, SUB_CPY_ID));
        }
        rtnMap.put("TOT_FLG_RD", getDecimal(MapUtils.getObject(rtnMap, "FLG_RD")).add(getDecimal(MapUtils.getObject(rtnMap, "UD_FLG_RD"))));

        String DIRECTOR_ID = MapUtils.getString(rtnMap, "DIRECTOR_ID");
        if (StringUtils.isNotBlank(DIRECTOR_ID)) {
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//���
                rtnMap.put("DIRECTOR_NM", new PersonnelData().getByEmployeeID2(DIRECTOR_ID).getName());
            } else {
                rtnMap.put("DIRECTOR_NM", FieldOptionList.getName("EP", "DRT_ID_" + SUB_CPY_ID, DIRECTOR_ID));
            }
        }
        return rtnMap;
    }

    /**
     * �s�W�j�Ӱ򥻸����
     * 
     * @param A101Vo
     *            DTEPA101 �j�Ӱ򥻸����
     * @param UPD_DATE
     *            String �J�ɤ���ɶ�
     * @param UPD_APLY_NO
     *            String �J�ɮץ�s��
     * @param UPD_TRN_KIND
     *            String �J�ɥ������
     */
    public void insertDTEPA101(DTEPA101 A101Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {
        ErrorInputException eie = null;

        if (A101Vo == null) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_002"); // �j�Ӱ򥻸���ɤ��o����
        } else {
            if (StringUtils.isBlank(A101Vo.getSUB_CPY_ID())) {
                eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
            }
            if (StringUtils.isBlank(A101Vo.getBLD_CD())) {
                eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
            }
        }
        if (StringUtils.isBlank(UPD_DATE)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_004");// �J�ɤ���ɶ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        // �s�W�j�Ӱ򥻸���� DTEPA101�G
        VOTool.insert(A101Vo);

    }

    /**
     * �R���j�Ӱ򥻸����
     * 
     * @param A101Vo
     *            DTEPA101 �j�Ӱ򥻸����
     * @param UPD_DATE
     *            String �J�ɤ���ɶ�
     * @param UPD_APLY_NO
     *            String �J�ɮץ�s��
     * @param UPD_TRN_KIND
     *            String �J�ɥ������
     */
    public void deleteDTEPA101(DTEPA101 A101Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException,
            SQLException {
        ErrorInputException eie = null;
        if (A101Vo == null) {
            throw getErrorInputException(eie, "EP_A10010_MSG_002"); // �j�Ӱ򥻸���ɤ��o����
        }
        if (StringUtils.isBlank(A101Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(A101Vo.getBLD_CD())) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }
        // �g�@��LOG��
        this.insertLog(A101Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND);
        // �R���j�Ӱ򥻸���� DTEPA101�G
        VOTool.delByPK(A101Vo);

    }

    /**
     * �ק�j�Ӱ򥻸����
     * 
     * @param A101Vo
     *            DTEPA101 �j�Ӱ򥻸����
     * @param UPD_DATE
     *            String �J�ɤ���ɶ�
     * @param UPD_APLY_NO
     *            String �J�ɮץ�s��
     * @param UPD_TRN_KIND
     *            String �J�ɥ������
     */
    public void updateDTEPA101(DTEPA101 A101Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException,
            SQLException {
        ErrorInputException eie = null;
        if (A101Vo == null) {
            throw getErrorInputException(eie, "EP_A10010_MSG_002");// �j�Ӱ򥻸���ɤ��o����
        }
        if (StringUtils.isBlank(A101Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(A101Vo.getBLD_CD())) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �ǤJ�j�ӥN�����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }
        // �g�@��LOG��
        this.insertLog(A101Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND);
        // �ק�j�Ӱ򥻸���� DTEPA101�G
        VOTool.update(A101Vo);

    }

    /**
     * �ק�j�Ӱ򥻸����
     * 
     * @param listA101
     *            List<Map> �j�Ӱ򥻸�Ƨ�s���e
     * @param UPD_DATE
     *            String �J�ɤ���ɶ�
     * @param mapA101
     *            Map<String, Map> �j�Ӱ򥻸�Ʋ��ʫe���e
     * @throws ModuleException
     * @throws DBException
     */
    public void updateDTEPA101Batch(List<Map> listA101, String UPD_DATE, Map<String, Map> mapA101) throws ModuleException, DBException {
        // �ˮֶǤJ�Ѽ�:
        ErrorInputException eie = null;
        if (listA101 == null || listA101.isEmpty()) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_027");// �ǤJ�j�Ӱ򥻸�Ƨ�s���e���o���ŭ�!
        }
        if (mapA101 == null || mapA101.isEmpty()) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_028");// �ǤJ�j�Ӱ򥻸�Ʋ��ʫe���e���o���ŭ�!
        }

        if (StringUtils.isBlank(UPD_DATE)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_004");// �J�ɤ���ɶ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        BatchUpdateDataSet budsA101LOG = Transaction.getBatchUpdateDataSet();
        BatchUpdateDataSet budsA101 = Transaction.getBatchUpdateDataSet();

        budsA101LOG.preparedBatch(SQL_updateDTEPA101Batch_001);
        budsA101.preparedBatch(SQL_updateDTEPA101Batch_002);
        int commit_size = 100; // �@��200���i�H�ݨD���ܵ���
        int batchCount = (listA101.size() / commit_size) + 1;
        try {
            for (int i = 1; i <= batchCount; i++) {
                try {

                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? listA101.size() : i * commit_size;
                    // �J�`�Q��w�s�H�Τ������զ�����w�s
                    for (int j = initS; j < initE; j++) {
                        Map list_mapA101 = (Map) listA101.get(j);
                        Map mapOld = (Map) mapA101.get(list_mapA101.get("BLD_CD"));
                        if (mapOld == null) {
                            continue;
                        }
                        budsA101LOG.setField("SUB_CPY_ID", mapOld.get("SUB_CPY_ID"));
                        budsA101LOG.setField("BLD_CD", mapOld.get("BLD_CD"));
                        budsA101LOG.setField("BLD_NAME", mapOld.get("BLD_NAME"));
                        budsA101LOG.setField("BLD_USR_ID", mapOld.get("BLD_USR_ID"));
                        budsA101LOG.setField("BLD_USR_NAME", mapOld.get("BLD_USR_NAME"));
                        budsA101LOG.setField("ZIP_CODE", mapOld.get("ZIP_CODE"));
                        budsA101LOG.setField("ZIP_NAME", mapOld.get("ZIP_NAME"));
                        budsA101LOG.setField("BLD_ADDR", mapOld.get("BLD_ADDR"));
                        budsA101LOG.setField("CURR", mapOld.get("CURR"));
                        budsA101LOG.setField("UNIT", mapOld.get("UNIT"));
                        budsA101LOG.setField("BLD_SIZE", mapOld.get("BLD_SIZE"));
                        budsA101LOG.setField("RNT_AMT", mapOld.get("RNT_AMT"));
                        budsA101LOG.setField("SLF_SIZE", mapOld.get("SLF_SIZE"));
                        budsA101LOG.setField("RNT_SIZE", mapOld.get("RNT_SIZE"));
                        budsA101LOG.setField("ACT_SIZE", mapOld.get("ACT_SIZE"));
                        budsA101LOG.setField("BUS_SIZE", mapOld.get("BUS_SIZE"));
                        budsA101LOG.setField("BLD_PRK", mapOld.get("BLD_PRK"));
                        budsA101LOG.setField("SLF_PRK", mapOld.get("SLF_PRK"));
                        budsA101LOG.setField("RNT_PRK", mapOld.get("RNT_PRK"));
                        budsA101LOG.setField("FLG_RD", mapOld.get("FLG_RD"));
                        budsA101LOG.setField("UD_FLG_RD", mapOld.get("UD_FLG_RD"));
                        budsA101LOG.setField("CUS_CNT", mapOld.get("CUS_CNT"));
                        budsA101LOG.setField("DIV_CNT", mapOld.get("DIV_CNT"));
                        budsA101LOG.setField("PART_CNT", mapOld.get("PART_CNT"));
                        budsA101LOG.setField("COST_AMT", mapOld.get("COST_AMT"));
                        budsA101LOG.setField("ARA_CD", mapOld.get("ARA_CD"));
                        budsA101LOG.setField("BLD_USE_CD", mapOld.get("BLD_USE_CD"));
                        budsA101LOG.setField("BLD_STR_DATE", mapOld.get("BLD_STR_DATE"));
                        budsA101LOG.setField("BLD_END_DATE", mapOld.get("BLD_END_DATE"));
                        budsA101LOG.setField("TEL_ARA_NO", mapOld.get("TEL_ARA_NO"));
                        budsA101LOG.setField("TEL_NO", mapOld.get("TEL_NO"));
                        budsA101LOG.setField("TEL_EXT_NO", mapOld.get("TEL_EXT_NO"));
                        budsA101LOG.setField("FAX_ARA_NO", mapOld.get("FAX_ARA_NO"));
                        budsA101LOG.setField("FAX_NO", mapOld.get("FAX_NO"));
                        budsA101LOG.setField("DIRECTOR_ID", mapOld.get("DIRECTOR_ID"));
                        budsA101LOG.setField("CLC_DIV_NO", mapOld.get("CLC_DIV_NO"));
                        budsA101LOG.setField("MNG_AMT", mapOld.get("MNG_AMT"));
                        budsA101LOG.setField("BLD_KD_1", mapOld.get("BLD_KD_1"));
                        budsA101LOG.setField("BLD_KD_2", mapOld.get("BLD_KD_2"));
                        budsA101LOG.setField("BLD_KD_3", mapOld.get("BLD_KD_3"));
                        budsA101LOG.setField("CHG_DATE", mapOld.get("CHG_DATE"));
                        budsA101LOG.setField("CHG_DIV_NO", mapOld.get("CHG_DIV_NO"));
                        budsA101LOG.setField("CHG_ID", mapOld.get("CHG_ID"));
                        budsA101LOG.setField("CHG_NAME", mapOld.get("CHG_NAME"));
                        budsA101LOG.setField("APLY_NO", mapOld.get("APLY_NO"));
                        budsA101LOG.setField("TRN_KIND", mapOld.get("TRN_KIND"));

                        budsA101LOG.setField("UPD_DATE", UPD_DATE);
                        budsA101LOG.setField("UPD_APLY_NO", list_mapA101.get("APLY_NO"));
                        budsA101LOG.setField("UPD_TRN_KIND", list_mapA101.get("TRN_KIND"));
                        budsA101LOG.addBatch();
                        budsA101.setField("SUB_CPY_ID", list_mapA101.get("SUB_CPY_ID"));
                        budsA101.setField("BLD_CD", list_mapA101.get("BLD_CD"));
                        budsA101.setField("BLD_NAME", list_mapA101.get("BLD_NAME"));
                        budsA101.setField("BLD_USR_ID", list_mapA101.get("BLD_USR_ID"));
                        budsA101.setField("BLD_USR_NAME", list_mapA101.get("BLD_USR_NAME"));
                        budsA101.setField("ZIP_CODE", list_mapA101.get("ZIP_CODE"));
                        budsA101.setField("ZIP_NAME", list_mapA101.get("ZIP_NAME"));
                        budsA101.setField("BLD_ADDR", list_mapA101.get("BLD_ADDR"));
                        budsA101.setField("CURR", list_mapA101.get("CURR"));
                        budsA101.setField("UNIT", list_mapA101.get("UNIT"));
                        budsA101.setField("BLD_SIZE", list_mapA101.get("BLD_SIZE"));
                        budsA101.setField("RNT_AMT", list_mapA101.get("RNT_AMT"));
                        budsA101.setField("SLF_SIZE", list_mapA101.get("SLF_SIZE"));
                        budsA101.setField("RNT_SIZE", list_mapA101.get("RNT_SIZE"));

                        budsA101.setField("ACT_SIZE", list_mapA101.get("ACT_SIZE"));
                        budsA101.setField("BUS_SIZE", list_mapA101.get("BUS_SIZE"));
                        budsA101.setField("BLD_PRK", list_mapA101.get("BLD_PRK"));
                        budsA101.setField("SLF_PRK", list_mapA101.get("SLF_PRK"));
                        budsA101.setField("RNT_PRK", list_mapA101.get("RNT_PRK"));
                        budsA101.setField("FLG_RD", list_mapA101.get("FLG_RD"));
                        budsA101.setField("UD_FLG_RD", list_mapA101.get("UD_FLG_RD"));
                        budsA101.setField("CUS_CNT", list_mapA101.get("CUS_CNT"));
                        budsA101.setField("DIV_CNT", list_mapA101.get("DIV_CNT"));
                        budsA101.setField("PART_CNT", list_mapA101.get("PART_CNT"));
                        budsA101.setField("COST_AMT", list_mapA101.get("COST_AMT"));
                        budsA101.setField("ARA_CD", list_mapA101.get("ARA_CD"));
                        budsA101.setField("BLD_USE_CD", list_mapA101.get("BLD_USE_CD"));
                        budsA101.setField("BLD_STR_DATE", list_mapA101.get("BLD_STR_DATE"));
                        budsA101.setField("BLD_END_DATE", list_mapA101.get("BLD_END_DATE"));
                        budsA101.setField("TEL_ARA_NO", list_mapA101.get("TEL_ARA_NO"));
                        budsA101.setField("TEL_NO", list_mapA101.get("TEL_NO"));
                        budsA101.setField("TEL_EXT_NO", list_mapA101.get("TEL_EXT_NO"));
                        budsA101.setField("FAX_ARA_NO", list_mapA101.get("FAX_ARA_NO"));
                        budsA101.setField("FAX_NO", list_mapA101.get("FAX_NO"));
                        budsA101.setField("DIRECTOR_ID", list_mapA101.get("DIRECTOR_ID"));
                        budsA101.setField("CLC_DIV_NO", list_mapA101.get("CLC_DIV_NO"));
                        budsA101.setField("MNG_AMT", list_mapA101.get("MNG_AMT"));
                        budsA101.setField("BLD_KD_1", list_mapA101.get("BLD_KD_1"));
                        budsA101.setField("BLD_KD_2", list_mapA101.get("BLD_KD_2"));
                        budsA101.setField("BLD_KD_3", list_mapA101.get("BLD_KD_3"));
                        budsA101.setField("CHG_DATE", list_mapA101.get("CHG_DATE"));
                        budsA101.setField("CHG_DIV_NO", list_mapA101.get("CHG_DIV_NO"));
                        budsA101.setField("CHG_ID", list_mapA101.get("CHG_ID"));
                        budsA101.setField("CHG_NAME", list_mapA101.get("CHG_NAME"));
                        budsA101.setField("APLY_NO", list_mapA101.get("APLY_NO"));
                        budsA101.setField("TRN_KIND", list_mapA101.get("TRN_KIND"));
                        budsA101.addBatch();

                    }
                    // ���s�W�j�Ӳ���LOG
                    budsA101LOG.executeBatch();
                    // ����s�j�Ӹ��
                    budsA101.executeBatch();
                    Object theErrorA101LOGObject[][] = budsA101LOG.getBatchUpdateErrorArray();
                    if (theErrorA101LOGObject.length > 0) {
                        for (int k = 0; k < theErrorA101LOGObject.length; k++) {
                            Map errorDataMap = (Map) theErrorA101LOGObject[k][1];
                            log.error(
                                "�s�W��" + (Exception) theErrorA101LOGObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap.toString(),
                                (Exception) theErrorA101LOGObject[k][2]);
                        }
                        throw new ModuleException(MessageUtil.getMessage("EP_A10010_MSG_024"));// �s�W��Ʀ��~
                    }
                    Object theErrorA101Object[][] = budsA101.getBatchUpdateErrorArray();
                    if (theErrorA101Object.length > 0) {
                        for (int k = 0; k < theErrorA101Object.length; k++) {
                            Map errorDataMap = (Map) theErrorA101Object[k][1];
                            log.error("��s��" + theErrorA101Object[k][0] + "����Ʀ��~ update setField = " + errorDataMap.toString(),
                                (Exception) theErrorA101Object[k][2]);
                        }
                        // �s�W��Ʀ��~
                        throw new ModuleException(MessageUtil.getMessage("EP_A10010_MSG_026"));// ��s��Ʀ��~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException(MessageUtil.getMessage("EP_A10010_MSG_025"));// �妸�s�W����
                }
            }
        } finally {
            if (budsA101LOG != null) {
                budsA101LOG.close();
            }
            if (budsA101 != null) {
                budsA101.close();
            }
        }

    }

    /**
     * �s�W�ץ�j�Ӱ򥻸����
     * 
     * @param B308Vo
     *            DTEPB308 �ץ�_�j�Ӱ򥻸����
     */
    public void insertDTEPB308(DTEPB308 B308Vo) throws ModuleException {

        ErrorInputException eie = null;
        if (B308Vo == null) {
            throw getErrorInputException(eie, "EP_A10010_MSG_011");// �ץ�_�j�Ӱ򥻸���ɤ��o����
        }
        if (StringUtils.isBlank(B308Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(B308Vo.getAPLY_NO())) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_007");// �ץ�s�����o���ŭ�
        }
        if (StringUtils.isBlank(B308Vo.getBLD_CD())) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
        }
        if (StringUtils.isBlank(B308Vo.getDATA_TYPE())) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_009");// ����������o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }
        B308Vo.setARA_CD(STRING.fillZero(B308Vo.getARA_CD(), 3));
        // �s�W�j�Ӱ򥻸���� DTEPB308�G
        VOTool.insert(B308Vo);

    }

    /**
     * �R���ץ�j�Ӱ򥻸����
     * 
     * @param B308Vo
     *            DTEPB308 �ץ�_�j�Ӱ򥻸����
     */
    public void deleteDTEPB308(DTEPB308 B308Vo) throws ModuleException {

        ErrorInputException eie = null;
        if (B308Vo == null) {
            throw getErrorInputException(eie, "EP_A10010_MSG_011");// �ץ�_�j�Ӱ򥻸���ɤ��o����
        }
        if (StringUtils.isBlank(B308Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        String APLY_NO = B308Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_007");// �ץ�s�����o���ŭ�
        }
        String DATA_TYPE = B308Vo.getDATA_TYPE();
        if (StringUtils.isBlank(DATA_TYPE)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_009");// ����������o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        // �s�W�j�Ӱ򥻸���� DTEPB308�G
        VOTool.delByPK(B308Vo);
        // �Y�������A�ɶ��NB�]�@�֧R��
        if ("A".equals(DATA_TYPE)) {
            B308Vo.setDATA_TYPE("B");
            VOTool.delByPK(B308Vo);
        } else if ("D".equals(DATA_TYPE)) {
            new EP_A10020().deleteDTEPB309DelAll(B308Vo);
            new EP_A10030().deleteDTEPB310DelAll(APLY_NO, B308Vo.getSUB_CPY_ID(), B308Vo.getBLD_CD(), null);
            new EP_A10040().deleteDTEPB311DelAll(B308Vo);
        }

    }

    /**
     * �ק�ץ�j�Ӱ򥻸����
     * 
     * @param B308Vo
     *            DTEPB308 �ץ�_�j�Ӱ򥻸����
     */
    public void updateDTEPB308(DTEPB308 B308Vo) throws ModuleException {

        ErrorInputException eie = null;
        if (B308Vo == null) {
            throw getErrorInputException(eie, "EP_A10010_MSG_011");// �ץ�_�j�Ӱ򥻸���ɤ��o����
        }
        if (StringUtils.isBlank(B308Vo.getAPLY_NO())) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_007");// �ץ�s�����o���ŭ�
        }
        if (StringUtils.isBlank(B308Vo.getDATA_TYPE())) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_009");// ����������o���ŭ�
        }
        if (StringUtils.isBlank(B308Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        // �s�W�j�Ӱ򥻸���� DTEPB308�G
        VOTool.update(B308Vo);

    }

    /**
     * �ק�
     * 
     * @param B308Vo
     *            DTEPB308 �ץ�_�j�Ӱ򥻸����
     */
    public void update(DTEPB308 B308Vo) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (B308Vo == null) {
            throw getErrorInputException(eie, "EP_A10010_MSG_011");// �ץ�_�j�Ӱ򥻸���ɤ��o����
        }
        String SUB_CPY_ID = B308Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        String APLY_NO = B308Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_007");// �ץ�s�����o���ŭ�
        }
        String BLD_CD = B308Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        // ����s�W�{��(�ק�ɼW�[2����ơA�@�����ʫe�A�@�����ʫ�)
        // ���ʫ�
        B308Vo.setDATA_TYPE("A");
        this.insertDTEPB308(B308Vo);
        // ���ʫe
        // �d�ߥD�ɸ��
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BLD_CD", BLD_CD);
        Map rtnMap = this.queryMap(reqMap);
        DTEPB308 newB308Vo = VOTool.mapToVO(DTEPB308.class, rtnMap);
        newB308Vo.setDATA_TYPE("B");
        newB308Vo.setAPLY_NO(APLY_NO);
        this.insertDTEPB308(newB308Vo);
        // �ק�ץ��ܧ������T
        DTEPB301 B301Vo = new DTEPB301();
        B301Vo.setAPLY_NO(APLY_NO);
        B301Vo.setBLD_CD(BLD_CD);
        B301Vo.setSUB_CPY_ID(SUB_CPY_ID);
        new EP_B30010().updateDTEPB301MainInfo(B301Vo);

    }

    /**
     * ���ק�
     * 
     * @param listB308
     *            List<Map>
     * @param mapA010
     *            Map<String,Map>
     * @throws DBException
     * @throws ModuleException
     */
    public void updateBatch(List<Map> listB308, Map<String, Map> mapA010) throws DBException, ModuleException {

        ErrorInputException eie = null;
        if (listB308 == null || listB308.isEmpty()) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_011");// �ץ�_�j�Ӱ򥻸���ɤ��o���ŭ�!
        }
        if (mapA010 == null || mapA010.isEmpty()) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_025");// �j�ӭ�l�򥻸�Ƥ��o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        BatchUpdateDataSet bqds = Transaction.getBatchUpdateDataSet();
        // �v���z�L�妸�N��Ƽg�JDTEPB308 INSERT INTO DBEP.DTEPB308
        bqds.preparedBatch(SQL_updateBatch_001);

        // �p����妸��
        int commit_size = 100; // �@��200���i�H�ݨD���ܵ���
        int batchCount = (listB308.size() / commit_size) + 1;
        try {
            for (int i = 1; i <= batchCount; i++) {
                try {
                    int initS = (i - 1) * commit_size;
                    int initE = (i == batchCount) ? listB308.size() : i * commit_size;
                    // �J�`�Q��w�s�H�Τ������զ�����w�s
                    for (int j = initS; j < initE; j++) {
                        Map map308 = (Map) listB308.get(j);
                        String BLD_CD = MapUtils.getString(map308, "BLD_CD");
                        String APLY_NO = MapUtils.getString(map308, "APLY_NO");
                        if (StringUtils.isBlank(BLD_CD)) {
                            continue;
                        }
                        Map A010_map308 = mapA010.get(BLD_CD);
                        if (A010_map308 == null) {
                            continue;
                        }

                        bqds.setField("APLY_NO", APLY_NO);
                        bqds.setField("BLD_CD", BLD_CD);
                        bqds.setField("BLD_NAME", map308.get("BLD_NAME"));
                        bqds.setField("BLD_USR_ID", map308.get("BLD_USR_ID"));
                        bqds.setField("BLD_USR_NAME", map308.get("BLD_USR_NAME"));
                        bqds.setField("ZIP_CODE", map308.get("ZIP_CODE"));
                        bqds.setField("ZIP_NAME", map308.get("ZIP_NAME"));
                        bqds.setField("BLD_ADDR", map308.get("BLD_ADDR"));
                        bqds.setField("CURR", map308.get("CURR"));
                        bqds.setField("UNIT", map308.get("UNIT"));
                        bqds.setField("BLD_SIZE", map308.get("BLD_SIZE"));
                        bqds.setField("RNT_AMT", map308.get("RNT_AMT"));
                        bqds.setField("SLF_SIZE", map308.get("SLF_SIZE"));
                        bqds.setField("RNT_SIZE", map308.get("RNT_SIZE"));
                        bqds.setField("ACT_SIZE", map308.get("ACT_SIZE"));
                        bqds.setField("BUS_SIZE", map308.get("BUS_SIZE"));
                        bqds.setField("BLD_PRK", map308.get("BLD_PRK"));
                        bqds.setField("SLF_PRK", map308.get("SLF_PRK"));
                        bqds.setField("RNT_PRK", map308.get("RNT_PRK"));
                        bqds.setField("FLG_RD", map308.get("FLG_RD"));
                        bqds.setField("UD_FLG_RD", map308.get("UD_FLG_RD"));
                        bqds.setField("CUS_CNT", map308.get("CUS_CNT"));
                        bqds.setField("DIV_CNT", map308.get("DIV_CNT"));
                        bqds.setField("PART_CNT", map308.get("PART_CNT"));
                        bqds.setField("COST_AMT", map308.get("COST_AMT"));
                        bqds.setField("ARA_CD", map308.get("ARA_CD"));
                        bqds.setField("BLD_USE_CD", map308.get("BLD_USE_CD"));
                        bqds.setField("BLD_STR_DATE", map308.get("BLD_STR_DATE"));
                        bqds.setField("BLD_END_DATE", map308.get("BLD_END_DATE"));
                        bqds.setField("TEL_ARA_NO", map308.get("TEL_ARA_NO"));
                        bqds.setField("TEL_NO", map308.get("TEL_NO"));
                        bqds.setField("TEL_EXT_NO", map308.get("TEL_EXT_NO"));
                        bqds.setField("FAX_ARA_NO", map308.get("FAX_ARA_NO"));
                        bqds.setField("FAX_NO", map308.get("FAX_NO"));
                        bqds.setField("DIRECTOR_ID", map308.get("DIRECTOR_ID"));
                        bqds.setField("CLC_DIV_NO", map308.get("CLC_DIV_NO"));
                        bqds.setField("MNG_AMT", map308.get("MNG_AMT"));
                        bqds.setField("BLD_KD_1", map308.get("BLD_KD_1"));
                        bqds.setField("BLD_KD_2", map308.get("BLD_KD_2"));
                        bqds.setField("BLD_KD_3", map308.get("BLD_KD_3"));
                        bqds.setField("SUB_CPY_ID", map308.get("SUB_CPY_ID"));
                        bqds.setField("DATA_TYPE", "A");
                        bqds.addBatch();

                        bqds.setField("APLY_NO", APLY_NO);
                        bqds.setField("BLD_CD", BLD_CD);
                        bqds.setField("BLD_NAME", A010_map308.get("BLD_NAME"));
                        bqds.setField("BLD_USR_ID", A010_map308.get("BLD_USR_ID"));
                        bqds.setField("BLD_USR_NAME", A010_map308.get("BLD_USR_NAME"));
                        bqds.setField("ZIP_CODE", A010_map308.get("ZIP_CODE"));
                        bqds.setField("ZIP_NAME", A010_map308.get("ZIP_NAME"));
                        bqds.setField("BLD_ADDR", A010_map308.get("BLD_ADDR"));
                        bqds.setField("CURR", A010_map308.get("CURR"));
                        bqds.setField("UNIT", A010_map308.get("UNIT"));
                        bqds.setField("BLD_SIZE", A010_map308.get("BLD_SIZE"));
                        bqds.setField("RNT_AMT", A010_map308.get("RNT_AMT"));
                        bqds.setField("SLF_SIZE", A010_map308.get("SLF_SIZE"));
                        bqds.setField("RNT_SIZE", A010_map308.get("RNT_SIZE"));
                        bqds.setField("ACT_SIZE", A010_map308.get("ACT_SIZE"));
                        bqds.setField("BUS_SIZE", A010_map308.get("BUS_SIZE"));
                        bqds.setField("BLD_PRK", A010_map308.get("BLD_PRK"));
                        bqds.setField("SLF_PRK", A010_map308.get("SLF_PRK"));
                        bqds.setField("RNT_PRK", A010_map308.get("RNT_PRK"));
                        bqds.setField("FLG_RD", A010_map308.get("FLG_RD"));
                        bqds.setField("UD_FLG_RD", A010_map308.get("UD_FLG_RD"));
                        bqds.setField("CUS_CNT", A010_map308.get("CUS_CNT"));
                        bqds.setField("DIV_CNT", A010_map308.get("DIV_CNT"));
                        bqds.setField("PART_CNT", A010_map308.get("PART_CNT"));
                        bqds.setField("COST_AMT", A010_map308.get("COST_AMT"));
                        bqds.setField("ARA_CD", A010_map308.get("ARA_CD"));
                        bqds.setField("BLD_USE_CD", A010_map308.get("BLD_USE_CD"));
                        bqds.setField("BLD_STR_DATE", A010_map308.get("BLD_STR_DATE"));
                        bqds.setField("BLD_END_DATE", A010_map308.get("BLD_END_DATE"));
                        bqds.setField("TEL_ARA_NO", A010_map308.get("TEL_ARA_NO"));
                        bqds.setField("TEL_NO", A010_map308.get("TEL_NO"));
                        bqds.setField("TEL_EXT_NO", A010_map308.get("TEL_EXT_NO"));
                        bqds.setField("FAX_ARA_NO", A010_map308.get("FAX_ARA_NO"));
                        bqds.setField("FAX_NO", A010_map308.get("FAX_NO"));
                        bqds.setField("DIRECTOR_ID", A010_map308.get("DIRECTOR_ID"));
                        bqds.setField("CLC_DIV_NO", A010_map308.get("CLC_DIV_NO"));
                        bqds.setField("MNG_AMT", A010_map308.get("MNG_AMT"));
                        bqds.setField("BLD_KD_1", A010_map308.get("BLD_KD_1"));
                        bqds.setField("BLD_KD_2", A010_map308.get("BLD_KD_2"));
                        bqds.setField("BLD_KD_3", A010_map308.get("BLD_KD_3"));
                        bqds.setField("SUB_CPY_ID", A010_map308.get("SUB_CPY_ID"));
                        bqds.setField("DATA_TYPE", "B");
                        bqds.addBatch();
                    }
                    bqds.executeBatch();
                    Object theErrorObject[][] = bqds.getBatchUpdateErrorArray();
                    if (theErrorObject.length > 0) {
                        for (int k = 0; k < theErrorObject.length; k++) {
                            Map errorDataMap = (Map) theErrorObject[k][1];
                            log.error("�s�W��" + theErrorObject[k][0] + "����Ʀ��~ Insert setField = " + errorDataMap,
                                (Exception) theErrorObject[k][2]);
                        }
                        // �s�W��Ʀ��~
                        throw new ModuleException(MessageUtil.getMessage("EP_A10010_MSG_024"));// �s�W��Ʀ��~
                    }
                } catch (Exception e) {
                    log.error(e, e);
                    throw new ModuleException(MessageUtil.getMessage("EP_A10010_MSG_025"));// �妸�s�W����
                }
            }
        } finally {
            if (bqds != null) {
                bqds.close();
            }
        }
    }

    /**
     * �s�W
     * 
     * @param B308Vo
     *            DTEPB308 �ץ�_�j�Ӱ򥻸����
     */
    public void insert(DTEPB308 B308Vo) throws ModuleException {
        ErrorInputException eie = null;
        if (B308Vo == null) {
            throw getErrorInputException(eie, "EP_A10010_MSG_011");// �ץ�_�j�Ӱ򥻸���ɤ��o����
        }
        String APLY_NO = B308Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_007");// �ץ�s�����o���ŭ�
        }
        String BLD_CD = B308Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
        }
        String SUB_CPY_ID = B308Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        this.insertDTEPB308(B308Vo);
        // �ק�ץ��ܧ������T
        DTEPB301 B301Vo = new DTEPB301();
        B301Vo.setAPLY_NO(APLY_NO);
        B301Vo.setBLD_CD(BLD_CD);
        B301Vo.setSUB_CPY_ID(SUB_CPY_ID);
        new EP_B30010().updateDTEPB301MainInfo(B301Vo);

    }

    /**
     * �R��
     * 
     * @param B308Vo
     *            DTEPB308 �ץ�_�j�Ӱ򥻸����
     */
    public void delete(DTEPB308 B308Vo) throws ModuleException {
        ErrorInputException eie = null;
        if (B308Vo == null) {
            throw getErrorInputException(eie, "EP_A10010_MSG_011");// �ץ�_�j�Ӱ򥻸���ɤ��o����
        }
        String APLY_NO = B308Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_007");// �ץ�s�����o���ŭ�
        }
        String BLD_CD = B308Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
        }
        String SUB_CPY_ID = B308Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        this.insertDTEPB308(B308Vo);
        try {
            new EP_A10020().insertDTEPB309DelAll(B308Vo);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L��ơA�������`", dnfe);
        }
        try {
            new EP_A10030().insertDTEPB310DelAll(B308Vo, null);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L��ơA�������`", dnfe);
        }
        try {
            new EP_A10040().insertDTEPB311DelAll(B308Vo);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L��ơA�������`", dnfe);
        }
        // �ק�ץ��ܧ������T
        DTEPB301 B301Vo = new DTEPB301();
        B301Vo.setAPLY_NO(APLY_NO);
        B301Vo.setBLD_CD(BLD_CD);
        B301Vo.setSUB_CPY_ID(SUB_CPY_ID);
        new EP_B30010().updateDTEPB301MainInfo(B301Vo);

    }

    /**
     * �վ�
     * 
     * @param B308Vo
     *            B308Vo DTEPB308 �ץ�_�j�Ӱ򥻸����
     */
    public void change(DTEPB308 B308Vo) throws ModuleException {
        ErrorInputException eie = null;
        if (B308Vo == null) {
            throw getErrorInputException(eie, "EP_A10010_MSG_011");// �ץ�_�j�Ӱ򥻸���ɤ��o����
        }
        String APLY_NO = B308Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_007");// �ץ�s�����o���ŭ�
        }
        String BLD_CD = B308Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
        }
        String SUB_CPY_ID = B308Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        this.updateDTEPB308(B308Vo);
        // �ק�ץ��ܧ������T
        DTEPB301 B301Vo = new DTEPB301();
        B301Vo.setAPLY_NO(APLY_NO);
        B301Vo.setBLD_CD(BLD_CD);
        B301Vo.setSUB_CPY_ID(SUB_CPY_ID);
        new EP_B30010().updateDTEPB301MainInfo(B301Vo);

    }

    /**
     * �O�_���\�ק�
     * 
     * @param APLY_NO
     *            String �߮׽s��
     * @param INPUT_ID
     *            String �߮פH��
     * @param OP_STATUS
     *            String �߮ת��A
     * @param user
     *            UserObject �n�J�H��
     * @param OP_Type
     *            String �@�~�O Q:�d��;P:�ץ�B�z
     * @param SUB_CPY_ID           
     *            String �����q�O
     * @return isEdit boolean �O�_���\�ק�
     */
    public boolean canEdit(String APLY_NO, String INPUT_ID, String OP_STATUS, UserObject user, String OP_TYPE, String SUB_CPY_ID)
            throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            throw getErrorInputException(eie, "EP_A10010_MSG_014");// �n�J�H�����o���ŭ�
        }
        if (StringUtils.isBlank(APLY_NO)) {
            return false;
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            return false;
        }
        DTEPB301 voDTEPB301 = new DTEPB301();
        voDTEPB301.setAPLY_NO(APLY_NO);
        voDTEPB301.setSUB_CPY_ID(SUB_CPY_ID);
        voDTEPB301 = VOTool.findByPKWithUR(voDTEPB301);
        String OP_STATUS_B301 = voDTEPB301.getOP_STATUS();

        if (StringUtils.isNotBlank(OP_STATUS_B301)) {
            OP_STATUS_B301 = OP_STATUS_B301.trim();
        }
        if (!user.getEmpID().equals(voDTEPB301.getINPUT_ID()) || "Q".equals(OP_TYPE)) {

            return false;
        } else if ("01".equals(OP_STATUS_B301)) {
            // �߮ת��A�~�i�ק�A�e��ᤣ���\�ק�
            return true;
        }
        return false;

    }

    /**
     * ��s�j�Ӹ�T
     * 
     * @param BLD_CD
     *            String �j�ӥN��
     * @param DTEPB301
     *            B301VO �߮׮ץ�
     * @param UPD_TIME
     *            String ���ʤ���ɶ�
     */
    public void updateSum(String BLD_CD, DTEPB301 B301VO, String UPD_TIME) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
        }
        if (StringUtils.isBlank(UPD_TIME)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_016");// ���ʤ���ɶ����o���ŭ�
        }
        if (B301VO == null) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_017");// �߮׮ץ󤣱o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        String SUB_CPY_ID = B301VO.getSUB_CPY_ID();
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BLD_CD", BLD_CD);
        Map rtnMap = new EP_A10010().queryMap(reqMap);
        String APLY_NO = B301VO.getAPLY_NO();
        String TRN_KIND = B301VO.getTRN_KIND();
        rtnMap.put("APLY_NO", APLY_NO);
        rtnMap.put("TRN_KIND", TRN_KIND);
        rtnMap.put("CHG_DATE", DATE.toTimestamp(UPD_TIME));
        rtnMap.put("CHG_DIV_NO", B301VO.getINPUT_DIV_NO());
        rtnMap.put("CHG_ID", B301VO.getINPUT_ID());
        rtnMap.put("CHG_NAME", B301VO.getINPUT_NAME());
        rtnMap.put("RNT_AMT", BigDecimal.ZERO);
        rtnMap.put("SLF_SIZE", BigDecimal.ZERO);
        rtnMap.put("RNT_SIZE", BigDecimal.ZERO);
        rtnMap.put("ACT_SIZE", BigDecimal.ZERO);
        rtnMap.put("PART_CNT", BigDecimal.ZERO);
        rtnMap.put("BLD_PRK", BigDecimal.ZERO);
        rtnMap.put("SLF_PRK", BigDecimal.ZERO);
        rtnMap.put("RNT_PRK", BigDecimal.ZERO);
        rtnMap.put("CUS_CNT", BigDecimal.ZERO);
        rtnMap.put("DIV_CNT", BigDecimal.ZERO);
        rtnMap.put("RNT_AMT", BigDecimal.ZERO);

        Map<String, Map> sumInfo = new HashMap<String, Map>();
        sumInfo.put(BLD_CD, rtnMap);
        setSumInfo(BLD_CD, SUB_CPY_ID, sumInfo);
        rtnMap = sumInfo.get(BLD_CD);

        DTEPB308 voB308 = VOTool.mapToVO(DTEPB308.class, rtnMap);
        // ��X���ʬ���
        this.update(voB308);

        // ��s�j�Ӹ��
        DTEPA101 vo = VOTool.mapToVO(DTEPA101.class, rtnMap);
        this.updateDTEPA101(vo, UPD_TIME, APLY_NO, TRN_KIND);

    }

    /**
     * ���o�U�j�Өϥη��p
     * 
     * @param BLD_CD
     *            �j�ӥN�� (�i���ǤJ�A���ǤJ���d�߱���)
     * @param SUB_CPY_ID
     *            �����q�O
     * @param sumMap
     *            �U�j�ӷ��p�J��
     */
    public void setSumInfo(String BLD_CD, String SUB_CPY_ID, Map<String, Map> sumMap) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ�
        }
        if (sumMap == null || sumMap.isEmpty()) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_023");// �U�j�ӷ��p�J���Ƥ��o����
        }
        if (eie != null) {
            throw eie;
        }

        // �p���`�믲��CERNTAM �`�믲��

        try {
            List<Map> listRnt = new EP_B10020().getBldRntByTax(BLD_CD, SUB_CPY_ID);
            BigDecimal TAX_TYPE_1_divparam = new BigDecimal("1.05");
            // �d�L��ơA SUM_AMT = 0 �A������~

            for (Map rnt : listRnt) {
                String rntBLD_CD = MapUtils.getString(rnt, "BLD_CD");
                if (StringUtils.isBlank(rntBLD_CD)) {
                    continue;
                }
                Map voSum = sumMap.get(rntBLD_CD);
                if (voSum == null || voSum.isEmpty()) {
                    continue;
                }
                BigDecimal SUM_AMT = getDecimal(voSum.get("RNT_AMT"));
                BigDecimal RNT_AMT = getDecimal(rnt.get("RNT_AMT"));
                String TAX_TYPE = MapUtils.getString(rnt, "TAX_TYPE");
                if ("1".equals(TAX_TYPE)) { // ���t
                    SUM_AMT = SUM_AMT.add(RNT_AMT.divide(TAX_TYPE_1_divparam, 0, BigDecimal.ROUND_HALF_UP));// �믲��
                } else {
                    SUM_AMT = SUM_AMT.add(RNT_AMT); // �믲��
                }
                voSum.put("RNT_AMT", SUM_AMT);
            }
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L�̵|�O�Τj�Ө��o�D�ɦ��ī����ӯ����B�`�p���", dnfe);
        }

        // �p��ۥέ��n�B�X�����n�B��ڥX�����n�B�Ŷ��j����
        DataSet ds = Transaction.getDataSet();
        setFieldIfExsits(BLD_CD, ds, "BLD_CD");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_updateSum_001, false);
        while (ds.next()) {
            Map voSum = sumMap.get(ds.getField("BLD_CD"));
            if (voSum == null || voSum.isEmpty()) {
                continue;
            }
            voSum.put("SLF_SIZE", getDecimal(ds.getField("SLF_SIZE")));
            voSum.put("RNT_SIZE", getDecimal(ds.getField("RNT_SIZE")));
            voSum.put("ACT_SIZE", getDecimal(ds.getField("ACT_SIZE")));
            voSum.put("PART_CNT", getDecimal(ds.getField("PART_CNT")));

        }

        // �p��X�����n�B��ڥX�����n�B�Ŷ��j���� ==�p��w���󦩰� , �p��ۥέ��n ==�p��w���󦩰�
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_setSumInfo_001, false);
        while (ds.next()) {
            Map voSum = sumMap.get(ds.getField("BLD_CD"));
            if (voSum == null || voSum.isEmpty()) {
                continue;
            }
            voSum.put("SLF_SIZE", getDecimal(voSum.get("SLF_SIZE")).subtract(getDecimal(ds.getField("SLF_SIZE"))));
            voSum.put("RNT_SIZE", getDecimal(ds.getField("RNT_SIZE")).add(getDecimal(voSum.get("RNT_SIZE"))));
            voSum.put("ACT_SIZE", getDecimal(ds.getField("ACT_SIZE")).add(getDecimal(voSum.get("ACT_SIZE"))));
            voSum.put("PART_CNT", getDecimal(voSum.get("PART_CNT")).subtract(getDecimal(ds.getField("RSV_PART_CNT"))));
        }
        // �p��w���� ��֥X��   �W�[�ۥέ��n
        ds.clear();
        setFieldIfExsits(BLD_CD, ds, "BLD_CD");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_setSumInfo_007, false);
        while (ds.next()) {
            Map voSum = sumMap.get(ds.getField("BLD_CD"));
            if (voSum == null || voSum.isEmpty()) {
                continue;
            }
            voSum.put("RNT_SIZE", getDecimal(voSum.get("RNT_SIZE")).subtract(getDecimal(ds.getField("SUB_RNT_SIZE"))));
            voSum.put("ACT_SIZE", getDecimal(voSum.get("ACT_SIZE")).subtract(getDecimal(ds.getField("SUB_ACT_SIZE"))));
            voSum.put("PART_CNT", getDecimal(voSum.get("PART_CNT")).add(getDecimal(ds.getField("ADD_PART_CNT"))));
            voSum.put("SLF_SIZE", getDecimal(voSum.get("SLF_SIZE")).add(getDecimal(ds.getField("ADD_SLF_SIZE"))));

        }
        // �p���`����� �B�ۥΨ���B�X������
        ds.clear();
        setFieldIfExsits(BLD_CD, ds, "BLD_CD");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_updateSum_002, false);
        while (ds.next()) {
            Map voSum = sumMap.get(ds.getField("BLD_CD"));
            if (voSum == null || voSum.isEmpty()) {
                continue;
            }
            voSum.put("BLD_PRK", getDecimal(ds.getField("BLD_PRK", 0)));
            voSum.put("SLF_PRK", getDecimal(ds.getField("SLF_PRK", 0)));
            voSum.put("RNT_PRK", getDecimal(ds.getField("RNT_PRK", 0)));
        }

        // �p�� �X������ ==�p��w����, �ۥΨ��� ==�p��w���� ��֨���
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_setSumInfo_002, false);
        while (ds.next()) {
            Map voSum = sumMap.get(ds.getField("BLD_CD"));
            if (voSum == null || voSum.isEmpty()) {
                continue;
            }
            voSum.put("SLF_PRK", getDecimal(voSum.get("SLF_PRK")).subtract(getDecimal(ds.getField("SLF_PRK"))));
            voSum.put("RNT_PRK", getDecimal(voSum.get("RNT_PRK")).add(getDecimal(ds.getField("RNT_PRK"))));
        }

        // �p��Ȥ��
        ds.clear();
        setFieldIfExsits(BLD_CD, ds, "BLD_CD");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_updateSum_003, false);
        while (ds.next()) {
            Map voSum = sumMap.get(ds.getField("BLD_CD"));
            if (voSum == null || voSum.isEmpty()) {
                continue;
            }
            voSum.put("CUS_CNT", getDecimal(ds.getField("CUS_CNT", 0)));
        }

        // �p��Ȥ�� ==�p��w����
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_setSumInfo_003, false);
        while (ds.next()) {
            Map voSum = sumMap.get(ds.getField("BLD_CD"));
            if (voSum == null || voSum.isEmpty()) {
                continue;
            }
            voSum.put("CUS_CNT", getDecimal(ds.getField("CUS_CNT")).add(getDecimal(voSum.get("CUS_CNT"))));
        }

        // �p�����
        ds.clear();
        setFieldIfExsits(BLD_CD, ds, "BLD_CD");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_updateSum_004, false);
        while (ds.next()) {
            Map voSum = sumMap.get(ds.getField("BLD_CD"));
            if (voSum == null || voSum.isEmpty()) {
                continue;
            }
            voSum.put("DIV_CNT", getDecimal(ds.getField("DIV_CNT", 0)));
        }

        // �p����� ==�����ۥγ�� ���w����
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_setSumInfo_004, false);
        while (ds.next()) {
            Map voSum = sumMap.get(ds.getField("BLD_CD"));
            if (voSum == null || voSum.isEmpty()) {
                continue;
            }
            voSum.put("DIV_CNT", getDecimal(voSum.get("DIV_CNT")).subtract(getDecimal(ds.getField("DIV_CNT"))));
        }

    }

    /**
     * �f��ץ��s�j�ӥD�ɸ��
     * 
     * @param BLD_CD
     *            String �j�ӥN��
     * @param DTEPB301
     *            B301VO �߮׮ץ�
     * @param UPD_TIME
     *            String ���ʤ���ɶ�
     */
    public void approve(String BLD_CD, DTEPB301 B301VO, String UPD_TIME) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
        }
        if (B301VO == null) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_017");// �߮׮ץ󤣱o���ŭ�
        }
        if (StringUtils.isBlank(UPD_TIME)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_016");// ���ʤ���ɶ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        Map reqMap = new HashMap();
        String APLY_NO = B301VO.getAPLY_NO();
        String SUB_CPY_ID = B301VO.getSUB_CPY_ID();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);// �����q�O
        reqMap.put("APLY_NO", APLY_NO); // �ץ�s��
        String TRN_KIND = B301VO.getTRN_KIND();
        String INPUT_DIV_NO = B301VO.getINPUT_DIV_NO();
        String INPUT_ID = B301VO.getINPUT_ID();
        String INPUT_NAME = B301VO.getINPUT_NAME();
        // �d�߲��ʩ���
        List<Map> updList = queryList(reqMap);
        // �v���B�z���ʩ���
        Timestamp time = DATE.toTimestamp(UPD_TIME);
        for (Map upd : updList) {
            // ��upd�� KEY, VALUE �N�ȳ]�w�� voA101
            DTEPA101 voA101 = VOTool.mapToVO(DTEPA101.class, upd);
            voA101.setAPLY_NO(APLY_NO);
            voA101.setTRN_KIND(TRN_KIND);
            voA101.setCHG_DATE(time);
            voA101.setCHG_DIV_NO(INPUT_DIV_NO);
            voA101.setCHG_ID(INPUT_ID);
            voA101.setCHG_NAME(INPUT_NAME);
            voA101.setSUB_CPY_ID(SUB_CPY_ID);

            String DATA_TYPE = MapUtils.getString(upd, "DATA_TYPE");
            if ("I".equals(DATA_TYPE)) {
                this.insertDTEPA101(voA101, UPD_TIME, APLY_NO, TRN_KIND);
            } else if ("D".equals(DATA_TYPE)) {
                this.deleteDTEPA101(voA101, UPD_TIME, APLY_NO, TRN_KIND);
            } else if ("A".equals(DATA_TYPE)) {
                this.updateDTEPA101(voA101, UPD_TIME, APLY_NO, TRN_KIND);
            }
            // "B".equals(DATA_TYPE))
            // ���ݲ��ʳB�z

        }

    }

    /**
     * Ū���j�Ӹg��M��
     * 
     * @param reqMap
     * @return
     */
    public List<Map> queryAgentList(Map reqMap) throws SQLException, ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10010_MSG_018"));// �ǤJ��Ƥ��o����!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));// �����q�O���o���ŭ�!
        }
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//���
            StringBuffer sb = new StringBuffer();
            // ���o���M��
            List<String> CLC_DIVList = FieldOptionList.getAllOption("EP", sb.append("AGT_DIV_").append(SUB_CPY_ID).toString());
            // ���o���u��ĳ�M��
            return getEmpList(CLC_DIVList, MapUtils.getString(reqMap, "BLD_USR_NAME"));
        } else {
            Map AGT_ID_List = FieldOptionList.getFieldOptions("EP", "AGT_ID_" + SUB_CPY_ID);
            List<Map> rtnList = new ArrayList<Map>();
            for (Object key : AGT_ID_List.keySet()) {
                Map rtnMap = new HashMap();
                rtnMap.put("EMP_ID", key);
                rtnMap.put("EMP_NAME", AGT_ID_List.get(key));
                rtnList.add(rtnMap);
            }
            return rtnList;
        }

    }

    /**
     * Ū���j�ӥD���M��
     * 
     * @param reqMap
     *            Map
     * 
     *            <pre>
     *                  SUB_CPY_ID = �����q�O
     *                  DIRECTOR_NM �D���m�W
     * </pre>
     * @return rtnList List<Map> �j�ӥD����ĳ�M��
     */
    public List<Map> queryDirectorList(Map reqMap) throws SQLException, ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10010_MSG_018"));// �ǤJ��Ƥ��o����!
        }
        String OP_UNIT = MapUtils.getString(reqMap, "OP_UNIT");
        if (StringUtils.isBlank(OP_UNIT)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10010_MSG_022"));// �@�~��줣�o���ŭ�!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));// �����q�O���o���ŭ�!
        }

        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//���
            StringBuffer sb = new StringBuffer();
            // ���o���M��
            List<String> DIR_DIVList = FieldOptionList.getAllOption("EP", sb.append("DRT_DIV_").append(OP_UNIT).toString());
            // ���o���u��ĳ�M��
            return getEmpList(DIR_DIVList, MapUtils.getString(reqMap, "DIRECTOR_NM"));
        } else {//�D���
            Map DRT_ID_List = FieldOptionList.getFieldOptions("EP", "DRT_ID_" + SUB_CPY_ID);
            List<Map> rtnList = new ArrayList<Map>();
            for (Object key : DRT_ID_List.keySet()) {
                Map rtnMap = new HashMap();
                rtnMap.put("EMP_ID", key);
                rtnMap.put("EMP_NAME", DRT_ID_List.get(key));
                rtnList.add(rtnMap);
            }
            return rtnList;
        }

    }

    /**
     * ���o��줤��
     * 
     * @param DIV_NO
     *            String ���N��
     * @return DIV_NAME String ���W��
     * @throws ErrorInputException 
     */
    public String getDivName(String DIV_NO, String SUB_CPY_ID) throws SQLException, ErrorInputException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));// �����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(DIV_NO)) {
            return "";
        }
        String DIV_NAME = null;
        // ��� RZ_Z0Z002���覡�z�LCACHED MAP�B�z�A�קK���Ƭd�߳�줤��
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
            if (!cacheMap.containsKey(DIV_NO)) {
                DIV_NAME = dd.getUnit4ShortName(DIV_NO);
                cacheMap.put(DIV_NO, DIV_NAME);
            } else {
                DIV_NAME = (String) cacheMap.get(DIV_NO);
            }
            return DIV_NAME;
        } else {
            if (!cacheMap.containsKey(DIV_NO)) {
                DIV_NAME = FieldOptionList.getName("EP", "DIVNO_" + SUB_CPY_ID, DIV_NO);
                cacheMap.put(DIV_NO, DIV_NAME);
            } else {
                DIV_NAME = (String) cacheMap.get(DIV_NO);
            }
            return DIV_NAME;
        }
    }

    /**
     * �d�߳��N��
     * 
     * @param theDivData
     * @param DIV_NO
     * @return
     * @throws SQLException
     */
    public List<Map> getDivMember(DivData theDivData, String DIV_NO) throws SQLException {

        List<Map> memList;

        synchronized (EP_A10010.class) {
            Employee[] empList;

            StringBuffer sb = new StringBuffer();
            if (!cacheMap_getDivMemberList.containsKey(DIV_NO)) {
                // ���o���M��
                empList = theDivData.getDivMember(DIV_NO, false, true);
                memList = new ArrayList<Map>();

                for (Employee emp : empList) {
                    Map rtnMap = new HashMap();
                    rtnMap.put("EMP_ID", emp.getEmployeeId());
                    rtnMap.put("EMP_NAME", emp.getName());
                    memList.add(rtnMap);
                }

                cacheMap_getDivMemberList.put(DIV_NO, memList);
                log.debug(sb.append("DivData.getDivMember:").append(DIV_NO).append(memList).toString());
                // �Ycache���w���������
            } else {
                memList = (List<Map>) cacheMap_getDivMemberList.get(DIV_NO);
                log.debug(sb.append("cached div member:").append(DIV_NO).append(memList).toString());
            }
        }
        return memList;
    }

    /**
     * ���o��µ�H���U�Կ��
     * @return
     * @throws SQLException
     */
    public List getDivMember() throws SQLException {
        EP_A10010 mod = new EP_A10010();
        //��µ�H���M��
        List<Map> divMember = new ArrayList<Map>();
        //�H�N�X���o��µ�����ҤU�H��
        List<Map> fixDivIdList = mod.getDivMember(new DivData(), FieldOptionList.getName("EP", "DIV_F106", "FIX_DIV"));
        //�[�J��µ�H���M��
        divMember.addAll(fixDivIdList);
        //�H�N�X���o�䴩�����H��
        Map supportFixDivIdMap = FieldOptionList.getFieldOptions("EP", "SUPPORT_FIX_DIV_ID");
        //�H�N�X���o��µ��H�~���\�@�~�����(�䴩)
        String[] fixDivArray = FieldOptionList.getName("EP", "DIV_F106", "FIX_DIV_SUPPORT").split(",");
        for (String fixDiv : fixDivArray) {
            //�H�䴩�����o����ҤU�H��
            List<Map> divMemberList = mod.getDivMember(new DivData(), fixDiv);
            //�H�䴩���H���P�_�O�_�ŦX�䴩�H���M��A�Y�s�b�h�[�J��µ��H���M��
            for (Map map : divMemberList) {
                //�䴩����ҤU�H��
                String empId = MapUtils.getString(map, "EMP_ID");
                //����ҤU�H���O�_�b�䴩�H���M�椤                    
                if (supportFixDivIdMap.get(empId) != null) {
                    //�[�J��µ�H���M��
                    divMember.add(map);
                }
            }
        }
        //�^�ǭ�µ�H���M��
        return divMember;
    }

    /**
     * Ū���j�Ӱ򥻸����
     * 
     * @param reqMap
     *            <pre>
     *          SUB_CPY_ID = �����q�O
     *          BLD_CD = �j�ӥN��
     *          APLY_NO = �ץ�s��
     *          DATA_TYPE = �������
     * </pre>
     * @return rtnMap Map �j�Ӱ򥻸����
     */
    public String getBldName(String BLD_CD) throws SQLException, ModuleException {

        ErrorInputException eie = null;

        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_003");// �j�ӥN�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String BLD_NAME;
        try {
            // �d�ߤj�Ӱ򥻸����(DTEPA101)�G
            DataSet ds = Transaction.getDataSet();
            ds.setField("SUB_CPY_ID", "00");// ���
            ds.setField("BLD_CD", BLD_CD);
            DBUtil.searchAndRetrieve(ds, SQL_queryList_002);

            ds.next();
            BLD_NAME = ObjectUtils.toString(ds.getField("BLD_NAME"));

        } catch (DataNotFoundException dnfe) {
            try {
                // �d�L��Ʈɧ�� ��µ��ۦ���@�j�ӥN���M��(�N�X�]�w)
                BLD_NAME = FieldOptionList.getName("EP", "BLD_CD_REPAIR", BLD_CD);
            } catch (Exception e) {
                throw new DataNotFoundException("�d�L�j�ӥN����ơF�j�ӥN���J" + BLD_CD);
            }
        }

        return BLD_NAME;
    }

    /**
     * �s�W�j�Ӱ򥻸��LOG��
     * 
     * @param A101Vo
     *            DTEPA101 �j�Ӱ򥻸����
     * @param UPD_DATE
     *            String �J�ɤ���ɶ�
     * @param UPD_APLY_NO
     *            String �J�ɮץ�s��
     * @param UPD_TRN_KIND
     *            String �J�ɥ������
     * @param isDelete
     *            boolean �O�_�R��
     */
    private void insertLog(DTEPA101 A101Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(UPD_DATE)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_004");// �J�ɤ���ɶ����o���ŭ�
        }

        if (StringUtils.isBlank(UPD_APLY_NO)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_005");// �J�ɮץ�s�����o���ŭ�
        }

        if (StringUtils.isBlank(UPD_TRN_KIND)) {
            eie = getErrorInputException(eie, "EP_A10010_MSG_006");// �J�ɥ���������o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }
        // �g�@��LOG��
        Map reqMap = new HashMap();
        String SUB_CPY_ID = A101Vo.getSUB_CPY_ID();
        String BLD_CD = A101Vo.getBLD_CD();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BLD_CD", BLD_CD);
        DTEPA101_LOG A101Vo_Log = VOTool.mapToVO(DTEPA101_LOG.class, queryMap(reqMap));
        A101Vo_Log.setUPD_DATE(DATE.toTimestamp(UPD_DATE));
        A101Vo_Log.setUPD_APLY_NO(UPD_APLY_NO);
        A101Vo_Log.setUPD_TRN_KIND(UPD_TRN_KIND);

        VOTool.insert(A101Vo_Log);
    }

    /**
     * Ū�������u�M��
     * 
     * @param DIVList
     *            List<Map> ���M��
     * @param EMP_NAME
     *            String �m�W
     * @return rtnList List<Map> �����u�M��
     */
    private List<Map> getEmpList(List<String> CLC_DIVList, String EMP_NAME) throws ModuleException, SQLException {
        // �v���B�z�^�ǳ��M��G
        // �s�W����^�ǲM��
        List<Map> rtnList = new ArrayList<Map>();
        DivData theDivData = new DivData();
        for (String DIV_NO : CLC_DIVList) {
            // DivData.getDivMembe-�d�߳��N�� *�O�_�t�ҤU�Atrue���t�ҤU�Afalse�����t�ҤU
            // *�O�_�t���Y���~�Atrue���t���Y���~�Afalse�����t���Y���~
            if (StringUtils.isEmpty(EMP_NAME)) {
                rtnList.addAll(getDivMember(theDivData, DIV_NO));
            } else {
                List<Map> empList = getDivMember(theDivData, DIV_NO);

                for (Map emp : empList) {
                    String Name = MapUtils.getString(emp, "EMP_NAME");
                    if (Name != null && EMP_NAME != null && Name.indexOf(EMP_NAME) >= 0) {
                        rtnList.add(emp);
                    }
                }
            }

        }
        return rtnList;
    }

    /**
     * ��wEIE����
     * 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * �d�߸�Ƥ覡 like'%key%'
     * 
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setLikeFieldsIfExsits(Map reqMap, DataSet ds, String key, StringBuilder sb) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            sb.append('%').append(value).append('%');
            ds.setField(key, sb.toString());
            sb.setLength(0);
        }
    }

    /**
     * �d�߸�ƫ��A�� 'key'
     * 
     * @param reqMap
     *            Map
     * @param ds
     * @param key
     */
    private void setFieldIfExsits(Map reqMap, DataSet ds, String key) {
        String value = MapUtils.getString(reqMap, key);
        this.setFieldIfExsits(value, ds, key);

    }

    /**
     * �d�߸�ƫ��A�� 'key'
     * 
     * @param value
     *            String
     * @param ds
     * @param key
     */
    private void setFieldIfExsits(String value, DataSet ds, String key) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * �ഫBigDecimal�榡
     * 
     * @param obj
     *            �ǤJ����
     * @return
     */
    private BigDecimal getDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }
        if (BigDecimal.class.isInstance(obj)) {
            return (BigDecimal) obj;
        }
        return new BigDecimal(String.valueOf(obj));
    }

    /**
     * ��DBEP.DVEPA900
     * @param BLD_CD (not null)
     * @return 
     * @throws ModuleException
     */
    public List<Map> queryForDVEPA900(String BLD_CD) throws ModuleException {
        if (StringUtils.isBlank(BLD_CD)) {
            throw new ErrorInputException("�ǤJ�ѼƤ��i����");
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("BLD_CD", BLD_CD);
        return VOTool.findToMaps(ds, SQL_queryForDVEPA900_001);
    }

    /**
     * ��DBEP.DVEPA900
     * @param Map={BLD_CD,USE_DIV_NO,inputBldgArea}//�ҥi����(=���d)
     * @return
     * @throws ModuleException
     */
    public List<Map> queryForDVEPA900(Map reqMap) throws ModuleException {

        DataSet ds = Transaction.getDataSet();
        setFieldIfExsits(MapUtils.getString(reqMap, "BLD_CD"), ds, "BLD_CD");
        setFieldIfExsits(MapUtils.getString(reqMap, "USE_DIV_NO"), ds, "USE_DIV_NO");
        setFieldIfExsits(MapUtils.getString(reqMap, "inputBldgArea"), ds, "inputBldgArea");
        return VOTool.findToMaps(ds, SQL_queryForDVEPA900_001);
    }

    /**
     * �d�ߤj��for�겣�޲z�t��
     * @param Map={SUB_CPY_ID �����q�O,BLD_CD �j�ӥN��(�i����)}//�����q�O���i����
     * @return A101List {BLD_CD,BLD_NAME,BLD_USR_ID,BLD_USR_NAME,CLC_DIV_NO}
     * @throws ModuleException
     */
    public List<Map> queryForEHD(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10010_MSG_001"));// �j�Ӱ򥻸�Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));// �����q�O���o���ŭ�
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setFieldIfExsits(MapUtils.getString(reqMap, "BLD_CD"), ds, "BLD_CD");
        return VOTool.findToMaps(ds, SQL_queryForEHD_001);

    }

    /**
     * [20190627] �޲z���ӿ�d��API
     * @param SUB_CPY_ID �����q�O(�w��'00')
     * @return
     * @throws ModuleException
     */
    public List<Map> qryDivAgentList(String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID) || !"00".equals(SUB_CPY_ID)) {
            throw new ErrorInputException("��J�����q�O(SUB_CPY_ID)���i���ũάO�D'00'��");
        }

        DataSet ds = Transaction.getDataSet();
        DBUtil.searchAndRetrieve(ds, SQL_qryDivAgentList_001);

        List<Map> divAgentList = new ArrayList<Map>();
        Map<String, Map> divAgentMap = new HashMap<String, Map>();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            String CLC_DIV_NO = MapUtils.getString(rtnMap, "CLC_DIV_NO");//�޲z���(�ӿ��O)
            Map mapDivAgent = MapUtils.getMap(divAgentMap, CLC_DIV_NO);
            List<Map> agentList;
            if (mapDivAgent == null) {
                mapDivAgent = new HashMap();
                mapDivAgent.put("CLC_DIV_NO", CLC_DIV_NO);
                mapDivAgent.put("DIV_SHORT_NAME", rtnMap.get("DIV_SHORT_NAME"));//�޲z���(�ӿ��O)
                agentList = new ArrayList<Map>();
                mapDivAgent.put("BLD_USR_LIST", agentList);//�j�Ӹg��M��(�]�t�j�Ӹg��ID,�j�Ӹg��W��)
            } else {
                agentList = (List<Map>) mapDivAgent.get("BLD_USR_LIST");
            }
            Map<String, String> agentMap = new HashMap<String, String>();
            agentMap.put("BLD_USR_ID", MapUtils.getString(rtnMap, "BLD_USR_ID"));//�j�Ӹg��ID
            agentMap.put("BLD_USR_NAME", MapUtils.getString(rtnMap, "BLD_USR_NAME"));//�j�Ӹg��W��
            agentList.add(agentMap);
            divAgentMap.put(CLC_DIV_NO, mapDivAgent);
        }

        //��divAgentMap�নList<Map>
        for (String key : divAgentMap.keySet()) {
            divAgentList.add(divAgentMap.get(key));
        }

        return divAgentList;
    }

    /**
     * [20190801] ��ؤj�Ӱ򥻸�Ƭd��API
     * @param reqMap
     * @return
     * @throws ModuleException
     * @throws SQLException 
     */
    public Map qryBuild(Map reqMap) throws ModuleException, SQLException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_A10010_MSG_001"));// �j�Ӱ򥻸�Ƥ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        if (StringUtils.isBlank(BLD_CD)) {
            eie = this.getErrorInputException(eie, "EP_A10010_MSG_003");//�j�ӥN�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", BLD_CD);

        Map rtnMap = VOTool.findOneToMap(ds, SQL_qryBuild_001);
        Map mapF170 = new HashMap();

        boolean isAccountSubCpy = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);
        //�p�G�O��ؤH��,�h�dF170�ݦ��L���
        if (isAccountSubCpy) {
        	//�]�w�N�X����P�X���v
        	setInfo(rtnMap);        	

            try {
                mapF170 = new EP_Z0F170().queryMap(reqMap);
                rtnMap.put("REQ_ID", mapF170.get("REQ_ID"));
                rtnMap.put("REQ_USR_NM", mapF170.get("REQ_USR_NM"));
                String mapF170_REQ_DIV = MapUtils.getString(mapF170, "REQ_DIV");
                //�j�ӥγ~���ۥ� ���o�{���޲z�H�������q��
                if ("02".equals(MapUtils.getString(rtnMap, "BLD_USE_CD")) && StringUtils.isNotBlank(mapF170_REQ_DIV)) {
                    /*TODO ��SA�T�{��Table�ʤֳ����A���},���W��
                    UnitAddress unitAdd = new DivData().getUnitAddress(mapF170_REQ_DIV);
                    rtnMap.put("INSTITUTION_PHONE", unitAdd.getDivTel1());
                    */
                } else {
                    //�D�ۥΩάOF170�S��REQ_DIV�h�έ쥻F170�����
                    rtnMap.put("INSTITUTION_PHONE", mapF170.get("INSTITUTION_PHONE"));
                }
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L��Ƶ������`", dnfe);
            }
        }

        return rtnMap;
    }
    
    private void setInfo(Map rtnMap) throws SQLException, ErrorInputException {

        //�j�өʽ�_�ϰ�γ~
        rtnMap.put("BLD_KD_1_NM", FieldOptionList.getName("EP", "BLD_KD_1", MapUtils.getString(rtnMap, "BLD_KD_1")));

        //�j�өʽ�_�ϥ�����
        rtnMap.put("BLD_KD_2_NM", FieldOptionList.getName("EP", "BLD_KD_2", MapUtils.getString(rtnMap, "BLD_KD_2")));

        //�j�өʽ�_�ӷ~����
        rtnMap.put("BLD_KD_3_NM", FieldOptionList.getName("EP", "BLD_KD_3", MapUtils.getString(rtnMap, "BLD_KD_3")));

        //�j�ӥγ~  
        rtnMap.put("BLD_USE_CD_NM", FieldOptionList.getName("EP", "BLD_USE_CD", MapUtils.getString(rtnMap, "BLD_USE_CD")));

        //�p��X���v�A�����ۥΥX���v�� 0%
        rtnMap.put("RNT_RT", new EP_A30040().getRentRate(rtnMap, "2", 3));

    }  
    
}
