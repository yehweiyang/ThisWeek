package com.cathay.ep.a1.module;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.ep.vo.DTEPB308;
import com.cathay.util.MessageUtil;

/**
 * <pre>
 * Date Version Description Author
 * 2013/8/15   1.0 Created ����i
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �ɮ׸���ˮּҲ�
 * �{���W��    EPA1_0010_mod.java
 * �@�~�覡    MODULE
 * ���n����    
 * </pre>
 * @author ���_��
 * @since 2013/9/11
 */
@SuppressWarnings("unchecked")
public class EPA1_0010_mod {
    private static final Logger log = Logger.getLogger(EPA1_0010_mod.class);

    /**
     * �ˮ֬O�_�i�s�W
     * @param EPB308Vo
     * @throws ModuleException
     * @throws SQLException
     */
    public void checkIsCanInsert(DTEPB308 EPB308Vo) throws ModuleException, SQLException {
        this.checkDTEPA101BLD_CD(EPB308Vo);
        this.checkDTEPB308BLD_CD(EPB308Vo);
    }

    /**
     * �ˮ֬O�_�i�ק�
     * @param EPB308Vo
     * @throws ModuleException
     * @throws SQLException
     */
    public void checkIsCanUpdate(DTEPB308 EPB308Vo) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        try {
            this.checkDTEPB308BLD_CD(EPB308Vo);
        } catch (ErrorInputException e) {
            eie = getErrorInputException(eie, e.getMessage());
        }
        try {
            this.checkisNullBLD_CD(EPB308Vo);
        } catch (ErrorInputException e) {
            eie = getErrorInputException(eie, e.getMessage());
        }
        if (eie != null) {
            throw eie;
        }

    }

    /**
     * �ˮ֤j�Ӱ򥻸���ɬO�_�w�s�b
     * @param EPB308Vo
     * @throws ModuleException
     * @throws SQLException
     */

    public void checkDTEPA101BLD_CD(DTEPB308 EPB308Vo) throws ModuleException, SQLException {
        if (EPB308Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EPA1_0010_mod_MSG_001"));//�ץ�_�j�Ӱ򥻸���ܧ�������o����
        }

        String SUB_CPY_ID = EPB308Vo.getSUB_CPY_ID();
        String BLD_CD = EPB308Vo.getBLD_CD();

        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPA1_0010_mod_MSG_003"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPA1_0010_mod_MSG_004"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("BLD_CD", BLD_CD);

        try {
            new EP_A10010().queryMap(reqMap);
            throw new ErrorInputException(MessageUtil.getMessage("EPA1_0010_mod_MSG_006"));//�j��_�򥻸���ɤw�s�b!
        } catch (DataNotFoundException dnfe) {
            log.debug("�d�L��ƬO�����`");
        }
    }

    /**
     * �ˮ֮ץ�_�j�Ӱ򥻸���ܧ�����O�_�w�s�b
     * @param EPB308Vo
     * @throws ModuleException
     * @throws SQLException
     */
    public void checkDTEPB308BLD_CD(DTEPB308 EPB308Vo) throws ModuleException, SQLException {
        if (EPB308Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EPA1_0010_mod_MSG_001"));//�ץ�_�j�Ӱ򥻸���ܧ�������o����
        }

        String SUB_CPY_ID = EPB308Vo.getSUB_CPY_ID();
        String BLD_CD = EPB308Vo.getBLD_CD();

        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPA1_0010_mod_MSG_003"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPA1_0010_mod_MSG_004"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        try {
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            reqMap.put("BLD_CD", BLD_CD);
            reqMap.put("DATA_TYPE", EPB308Vo.getDATA_TYPE());
            reqMap.put("QRY_TYPE", "2");//���ʶ���
            new EP_A10010().queryMap(reqMap);
            throw new ErrorInputException(MessageUtil.getMessage("EPA1_0010_mod_MSG_005"));//�ץ�j�Ӱ򥻸�Ƥw�s�b�ݼf���ʬ���!
        } catch (DataNotFoundException dnfe) {
            log.debug("�d�L��ƬO�����`");
        }

    }

    /**
     * �ˮ֤j�Ӱ򥻸���ɬO�_���s�b
     * @param EPB308Vo
     * @throws ModuleException
     * @throws SQLException
     */
    public void checkisNullBLD_CD(DTEPB308 EPB308Vo) throws ModuleException, SQLException {
        if (EPB308Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EPA1_0010_mod_MSG_001"));//�ץ�_�j�Ӱ򥻸���ܧ�������o����
        }

        String SUB_CPY_ID = EPB308Vo.getSUB_CPY_ID();
        String BLD_CD = EPB308Vo.getBLD_CD();

        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPA1_0010_mod_MSG_003"));//�ǤJ�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPA1_0010_mod_MSG_004"));//�ǤJ�j�ӥN�����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        try {
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            reqMap.put("BLD_CD", BLD_CD);
            new EP_A10010().queryMap(reqMap);
        } catch (DataNotFoundException dnfe) {
            throw new ErrorInputException(MessageUtil.getMessage("EPA1_0010_mod_MSG_002", new Object[] { EPB308Vo.getBLD_CD()
                    + EPB308Vo.getBLD_NAME() }), dnfe);
            //"�L���ɤj��(" + EPB308Vo.getBLD_CD() + EPB308Vo.getBLD_NAME() + ")���!"
        }

    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

}
