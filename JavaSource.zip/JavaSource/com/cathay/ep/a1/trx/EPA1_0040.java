package com.cathay.ep.a1.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.a1.module.EPA1_0040_mod;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.a1.module.EP_A10040;
import com.cathay.ep.b3.module.EPB3_0010_mod;
import com.cathay.ep.vo.DTEPB311;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Version  Description  Author
 * 2013/9/2    1.0      Created      ����i
 * 2018/3/19   2.0      �t�X��ؾɤJ�վ� ����[
 * 
 * �@�B   �{���\�෧�n�����G
 * �{���\��    ����Ψ�L����
 * �{���W��    EPA1_0040
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 *             (2) �d�� �w �ϥΪ̫��U�d�߫��s��A�I�sEP_A10040�Ҳը��o�M���ơC
 *             (3) ����Ψ�L �w �N�ӵ��D�ɸ�Ʊa�JD��
 *             (4) �s�W �w �s�W�@���s�W�ץ󲧰ʶ���
 *             (5) �ק� �w �s�W�@���ק�ץ󲧰ʶ���
 *             (6) �R�� �w �s�W�@���R���ץ󲧰ʶ���
 *             (7) �վ� �w ��s�ץ󲧰ʶ��ؤ��e
 *             (8) �簣 �w �R���ץ󲧰ʶ���
 *             (9) �վ�ץ� �w �N�ӵ��ץ󲧰ʶ��ظ�Ʊa�JD��
 *             (10) �h������ �w �P�ɽվ�h���ץ󫴬��N���B�Ȥ�Ǹ��B�_������B�ϥΪ̡B�����ҦC�L
 * ���s���v    �M��FUNC_ID = EPA10040
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 *</pre>
 * @author ���_��
 * @since 2013/9/30
 */
@SuppressWarnings("unchecked")
public class EPA1_0040 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPA1_0040.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     * @throws Exception 
     * @throws ErrorInputException 
     */
    public ResponseContext doPrompt(RequestContext req) throws Exception {
        //����
        VOTool.setParamsFromLP_JSON(req);
        String SUB_CPY_ID = null;
        String APLY_NO = req.getParameter("APLY_NO");//�ץ�s��
        String BLD_CD = req.getParameter("BLD_CD");//�j�ӥN��
        String PRK_NO = req.getParameter("PRK_NO");//����Ψ�L�N��
        String TRN_KIND = req.getParameter("TRN_KIND");//���ʺ���
        String OP_STATUS = req.getParameter("OP_STATUS");//�@�~�i��
        String INPUT_ID = req.getParameter("INPUT_ID");//��J�H��ID
        String OP_TYPE = req.getParameter("OP_TYPE");

        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);//�����q�O
        } catch (Exception e) {
            log.error("��l���ȥ���", e);
        }

        resp.addOutputData("APLY_NO", APLY_NO);
        resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        resp.addOutputData("OP_STATUS", OP_STATUS);
        resp.addOutputData("TRN_KIND", TRN_KIND);
        resp.addOutputData("PRK_NO", PRK_NO);
        resp.addOutputData("BLD_CD", BLD_CD);
        
        
        if(StringUtils.isNotBlank(TRN_KIND)&&"EPA002".equals(TRN_KIND)){
            if(StringUtils.isNotBlank(FieldOptionList.getName("EP", "EPA002_CRT_NO", BLD_CD))){
                resp.addOutputData("CRT_NO_enable", "Y");
            }
        }

        EP_A10040 theEP_A10040 = new EP_A10040();
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        reqMap.put("BLD_CD", BLD_CD);//�j�ӥN��
        try {
            //���o�j�Ө���D�ɬ���

            List<Map> rtnBList = theEP_A10040.queryList(reqMap);
            BigDecimal TCAR_RNT_AMT = BigDecimal.ZERO;

            for (Map map : rtnBList) {
                String CAR_RNT_AMTB = MapUtils.getString(map, "CAR_RNT_AMT");
                if (StringUtils.isNotBlank(CAR_RNT_AMTB)) {
                    TCAR_RNT_AMT = TCAR_RNT_AMT.add(new BigDecimal(CAR_RNT_AMTB));
                }
            }
            resp.addOutputData("TCAR_RNT_AMT", TCAR_RNT_AMT);
            resp.addOutputData("rtnBList", VOTool.toJSON(rtnBList));

        } catch (Exception e) {
            log.error("rtnBList�d�L��ƪ�l����", e);
            resp.addOutputData("rtnBList", "");
        }

        if (StringUtils.isNotBlank(APLY_NO)) {
            reqMap.put("APLY_NO", APLY_NO);//�ץ�s��

            try {
                BigDecimal TCAR_RNT_AMT2 = BigDecimal.ZERO;
                List<Map> rtnCList = theEP_A10040.queryList(reqMap);
                for (Map map : rtnCList) {
                    String CAR_RNT_AMTC = MapUtils.getString(map, "CAR_RNT_AMT");
                    if (StringUtils.isNotBlank(CAR_RNT_AMTC)) {
                        TCAR_RNT_AMT2 = TCAR_RNT_AMT2.add(new BigDecimal(CAR_RNT_AMTC));
                    }
                }
                resp.addOutputData("rtnCList", VOTool.toJSON(rtnCList));
                resp.addOutputData("TCAR_RNT_AMT2", TCAR_RNT_AMT2);
            } catch (Exception dnfe) {
                log.error("rtnCList�d�L���", dnfe);
                resp.addOutputData("rtnCList", "");
            }

        }

        if (StringUtils.isNotBlank(PRK_NO)) {
            Map rtnMap = null;
            try {
                reqMap.put("PRK_NO", PRK_NO);
                rtnMap = theEP_A10040.queryMap(reqMap);
                resp.addOutputData("rtnMap", VOTool.toJSON(rtnMap));
            } catch (DataNotFoundException dnfe) {
                log.error("rtnMap�d�L���", dnfe);
                resp.addOutputData("rtnMap", "");
            }
            if (rtnMap == null && StringUtils.isNotBlank(APLY_NO)) {
                reqMap.put("APLY_NO", null);
                try {
                    rtnMap = theEP_A10040.queryMap(reqMap);
                    resp.addOutputData("rtnMap", VOTool.toJSON(rtnMap));
                } catch (DataNotFoundException dnfe) {
                    log.error("rtnMap�d�L���", dnfe);
                    resp.addOutputData("rtnMap", "");
                }
            }
        }

        try {

            //���s����
            if (StringUtils.isNotBlank(APLY_NO)) {
                boolean canEdit = new EP_A10010().canEdit(APLY_NO, INPUT_ID, OP_STATUS, user, OP_TYPE, SUB_CPY_ID);
                resp.addOutputData("canEdit", canEdit);
            } else {
                resp.addOutputData("canEdit", false);
            }

        } catch (Exception e) {
            log.error("��l���s�����", e);
            resp.addOutputData("canEdit", false);
        }

        try {
            if ("01".equals(OP_STATUS) && user.getEmpID().equals(INPUT_ID)) {
                resp.addOutputData("candelet", 0); //��ܭ簣�s ,�����A�P�_rtnCMap.DATA_TYPE!=B

            } else {
                resp.addOutputData("candelet", 1); //���í簣�s//���ýվ�s
            }
        } catch (Exception e) {
            log.error("��l���s�����", e);
        }

        try {
            //���o�X�������U�Կ��
            resp.addOutputData("RNT_KINDList", FieldOptionList.getName("EP", "RNT_KIND"));
            //���o�ϥΪ��p�U�Կ��
            resp.addOutputData("USE_TYPEList", FieldOptionList.getName("EP", "USE_TYPE"));
        } catch (Exception e) {
            log.error("�U�Կ����o����", e);
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMap"));
            EP_A10040 theEP_A10040 = new EP_A10040();
            boolean isShowMsg = this.queryL(reqMap, theEP_A10040);
            String alertMsg;
            if (isShowMsg) {
                alertMsg = MessageUtil.getMessage("EPA1_0040_MSG_011");//�d�L������

            } else {
                alertMsg = MessageUtil.getMessage("EPA1_0040_MSG_001");//�d�ߧ���
            }
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, alertMsg);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0040_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPA1_0040_MSG_003"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPA1_0040_MSG_004"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPA1_0040_MSG_004"), e);//�d�ߥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0040_MSG_004"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �s�W 
     * @param req
     * @return
     */
    public ResponseContext doAdd(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB311 theDTEPB311 = VOTool.mapToVO(DTEPB311.class, reqMap);
            theDTEPB311.setDATA_TYPE("I");
            new EPA1_0040_mod().checkIsCanInsert(theDTEPB311);
            new EPB3_0010_mod().isChangeable(theDTEPB311.getAPLY_NO());
            EP_A10040 theEP_A10040 = new EP_A10040();
            Transaction.begin();
            try {
                theEP_A10040.insert(theDTEPB311);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0040_MSG_005"));//�s�W����

            //�d��
            try {
                this.queryL(reqMap, theEP_A10040);
            } catch (Exception e) {
                log.error("�s�W���������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0040_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0040_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0040_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �ק� 
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB311 theDTEPB311 = VOTool.mapToVO(DTEPB311.class, reqMap);
            theDTEPB311.setDATA_TYPE("A");
            new EPA1_0040_mod().checkIsCanUpdate(theDTEPB311, "U");
            new EPB3_0010_mod().isChangeable(theDTEPB311.getAPLY_NO());
            EP_A10040 theEP_A10040 = new EP_A10040();
            Transaction.begin();
            try {
                theEP_A10040.update(theDTEPB311);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0040_MSG_007"));//�ק粒��

            //�d��
            try {
                this.queryL(reqMap, theEP_A10040);
            } catch (Exception e) {
                log.error("�ק粒�������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0040_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0040_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0040_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �R�� 
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB311 theDTEPB311 = VOTool.mapToVO(DTEPB311.class, reqMap);
            theDTEPB311.setDATA_TYPE("D");
            new EPA1_0040_mod().checkIsCanUpdate(theDTEPB311, "D");
            new EPB3_0010_mod().isChangeable(theDTEPB311.getAPLY_NO());
            EP_A10040 theEP_A10040 = new EP_A10040();
            Transaction.begin();
            try {
                theEP_A10040.delete(theDTEPB311);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0040_MSG_008"));//�R������

            //�d��
            try {
                this.queryL(reqMap, theEP_A10040);
            } catch (Exception e) {
                log.error("�R�����������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0040_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0040_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0040_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �簣 
     * @param req
     * @return
     */
    public ResponseContext doDeleteB(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB311 theDTEPB311 = VOTool.mapToVO(DTEPB311.class, reqMap);
            new EPB3_0010_mod().isChangeable(theDTEPB311.getAPLY_NO());
            EP_A10040 theEP_A10040 = new EP_A10040();
            Transaction.begin();
            try {
                theEP_A10040.deleteDTEPB311(theDTEPB311);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0040_MSG_009"));//�簣����

            //�d��
            try {
                this.queryL(reqMap, theEP_A10040);
            } catch (Exception e) {
                log.error("�d�L��Ƶ������`", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0040_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0040_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�簣����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0040_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �վ� 
     * @param req
     * @return
     */
    public ResponseContext doChange(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB311 theDTEPB311 = VOTool.mapToVO(DTEPB311.class, reqMap);
            //�ˮ֬O�_�i�ק�A���i�h��X���~
            new EPA1_0040_mod().checkIsCanUpdate(theDTEPB311, "C");
            new EPB3_0010_mod().isChangeable(theDTEPB311.getAPLY_NO());
            EP_A10040 theEP_A10040 = new EP_A10040();
            Transaction.begin();
            try {
                theEP_A10040.change(theDTEPB311);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0040_MSG_010"));//�վ�ץ󧹦�

            //�d��
            try {
                this.queryL(reqMap, theEP_A10040);
            } catch (Exception e) {
                log.error("�վ�ץ󧹦����d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0040_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0040_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�վ㥢��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0040_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �h������ 
     * @param req
     * @return
     */
    public ResponseContext doChangeMulti(RequestContext req) {
        try {

            List<DTEPB311> chkList = VOTool.jsonAryToVOs(DTEPB311.class, req.getParameter("storeMapInsert"));

            EPA1_0040_mod EPA1_0040_mod = new EPA1_0040_mod();
            for (DTEPB311 B311vo : chkList) {
                EPA1_0040_mod.checkIsCanUpdate(B311vo, "U");
            }

            new EPB3_0010_mod().isChangeable(chkList.get(0).getAPLY_NO());
            Transaction.begin();
            try {
                for (DTEPB311 B311vo : chkList) {
                    new EP_A10040().update(B311vo);
                }
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0040_MSG_010"));//�վ�ץ󧹦�

            //�d��
            try {
                EP_A10040 theEP_A10040 = new EP_A10040();
                Map reqMap = VOTool.voToMap(chkList.get(0));
                reqMap.put("PRK_NO", null);
                String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
                reqMap.put("SUB_CPY_ID", SUB_CPY_ID);

                this.queryL(reqMap, theEP_A10040);
            } catch (Exception e) {
                log.error("�վ�ץ󧹦����d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0040_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0040_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�վ㥢��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0040_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �d��
     * @param reqMap
     * @throws ModuleException 
     * @throws Exception 
     */
    private boolean queryL(Map reqMap, EP_A10040 theEP_A10040) throws ModuleException {

        Map tmp_reqMap = new HashMap();
        tmp_reqMap.put("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        tmp_reqMap.put("BLD_CD", MapUtils.getString(reqMap, "BLD_CD"));
        tmp_reqMap.put("PRK_NO", MapUtils.getString(reqMap, "PRK_NO"));
        List<Map> rtnBList = null;
        try {
            rtnBList = theEP_A10040.queryList(tmp_reqMap);
            // 20161219 LogSecurity
            try{
            	
          		List<Map> logSecurityList = new ArrayList<Map>();
          		for (Map tmpRecord : rtnBList) {
          			Map logSecurityMap = new HashMap();
          			// �ϥΪ̦W��
          			logSecurityMap.put("USR_NAME", 
          					MapUtils.getString(tmpRecord,"USR_NAME", ""));
          			logSecurityList.add(logSecurityMap);
          		}
          		logSecurity(logSecurityList);
          		logSecurityList.clear();
            } catch(Throwable e) {
            	log.warn(e, e);
            }   
            
            BigDecimal TCAR_RNT_AMT = BigDecimal.ZERO;

            for (Map map : rtnBList) {
                String CAR_RNT_AMTB = MapUtils.getString(map, "CAR_RNT_AMT");
                if (StringUtils.isNotBlank(CAR_RNT_AMTB)) {
                    TCAR_RNT_AMT = TCAR_RNT_AMT.add(new BigDecimal(CAR_RNT_AMTB));
                }
            }
            resp.addOutputData("TCAR_RNT_AMT", TCAR_RNT_AMT);
            resp.addOutputData("rtnBList", rtnBList);

        } catch (DataNotFoundException dnfe) {
            log.error("rtnBList�d�L���", dnfe);
            resp.addOutputData("rtnBList", "");
        }

        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        List<Map> rtnCList = null;
        try {

            if (StringUtils.isNotBlank(APLY_NO)) {
                Map C_reqMap = new HashMap();//�d�ߩҦ����ʶ���
                C_reqMap.put("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
                C_reqMap.put("BLD_CD", MapUtils.getString(reqMap, "BLD_CD"));
                C_reqMap.put("APLY_NO", APLY_NO);
                rtnCList = theEP_A10040.queryList(C_reqMap);
                BigDecimal TCAR_RNT_AMT2 = BigDecimal.ZERO;
                for (Map map : rtnCList) {
                    String CAR_RNT_AMTC = MapUtils.getString(map, "CAR_RNT_AMT");
                    if (StringUtils.isNotBlank(CAR_RNT_AMTC)) {
                        TCAR_RNT_AMT2 = TCAR_RNT_AMT2.add(new BigDecimal(CAR_RNT_AMTC));
                    }
                }
                resp.addOutputData("TCAR_RNT_AMT2", TCAR_RNT_AMT2);
                resp.addOutputData("rtnCList", rtnCList);
            }
        } catch (DataNotFoundException dnfe) {
            log.error("rtnCLis�d�L���", dnfe);
            resp.addOutputData("rtnCList", "");
        }

        boolean isShowMsg = false;
        String PRK_NO = MapUtils.getString(reqMap, "PRK_NO");
        if (StringUtils.isNotBlank(PRK_NO)) {
            isShowMsg = true;
            Map rtnMap = null;
            tmp_reqMap.put("PRK_NO", PRK_NO);
            try {
                rtnMap = theEP_A10040.queryMap(tmp_reqMap);
                resp.addOutputData("rtnMap", rtnMap);
            } catch (DataNotFoundException dnfe) {
                log.error("rtnMap�d�L���", dnfe);
                resp.addOutputData("rtnMap", "");
            }

            if (rtnMap == null && StringUtils.isNotBlank(APLY_NO)) {
                tmp_reqMap.put("APLY_NO", null);
                try {
                    rtnMap = theEP_A10040.queryMap(tmp_reqMap);
                    resp.addOutputData("rtnMap", rtnMap);
                } catch (DataNotFoundException dnfe) {
                    log.error("rtnMap�d�L���", dnfe);
                    resp.addOutputData("rtnMap", "");
                }
            }

            if (rtnMap != null) {
                isShowMsg = false;
            }

        }

        if (rtnCList == null && rtnBList == null) {
            throw new DataNotFoundException();
        }

        return isShowMsg;

    }

    /**
     * �j�M����-�Ȥ��ĳ�M��
     * @param req
     * @return
     */
    public ResponseContext doGetCusName(RequestContext req) {
        try {

            Map trnMap = new EP_A10040().getCustSuggestList(req.getParameter("SUB_CPY_ID"), req.getParameter("CRT_NO"), req
                    .getParameter("APLY_NO"), req.getParameter("CUS_NO"));

            // 20161219 LogSecurity ���v        
            Map logOneSecurityMap = new HashMap();
            logOneSecurityMap.put("USR_NAME", MapUtils.getString(trnMap, "USR_NAME", "") );
            logOneSecurityMap.put("CUS_NAME", MapUtils.getString(trnMap, "CUS_NAME", "") );
            logSecurity(logOneSecurityMap);
            
            resp.addOutputData("trnMap", trnMap);
        } catch (Exception e) {
            log.error("�Ȥ�j�M�d�ߥ���", e);
            resp.addOutputData("trnMap", "");
        }
        return resp;
    }
}