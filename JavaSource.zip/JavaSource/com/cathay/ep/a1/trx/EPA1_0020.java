package com.cathay.ep.a1.trx;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.a1.module.EPA1_0020_mod;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.a1.module.EP_A10020;
import com.cathay.ep.b3.module.EPB3_0010_mod;
import com.cathay.ep.vo.DTEPB309;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Version  Description            Author
 * 2013/8/6    1.0      Created                ����i
 * 2013/9/26   1.1      Modified�̻ݨD�վ㤺�e  ������
 * 
 * �@�B   �{���\�෧�n�����G
 * �{���\��    �Ӽh����
 * �{���W��    EPA1_0020
 * �@�~�覡    ONLINE
 * ���n����      (1) ��l
 *              (2) �d�� �w �ϥΪ̫��U�d�߫��s��A�I�sEP_A10020�Ҳը��o�j�ӲM���ơC
 *              (3) �Ӽh�O �w �N�ӵ��D�ɸ�Ʊa�JD��
 *              (4) �s�W �w �s�W�@���s�W�ץ󲧰ʶ���
 *              (5) �ק� �w �s�W�@���ק�ץ󲧰ʶ���
 *              (6) �R�� �w �s�W�@���R���ץ󲧰ʶ���
 *              (7) �վ� �w ��s�ץ󲧰ʶ��ؤ��e
 *              (8) �簣 �w �R���ץ󲧰ʶ���
 *              (9) �վ�ץ� �w �N�ӵ��ץ󲧰ʶ��ظ�Ʊa�JD��
 * ���s���v    �M��FUNC_ID = EPA10020
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 *</pre>
 * @author ���_��
 * @since 2013/10/30
 */
@SuppressWarnings("unchecked")
public class EPA1_0020 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPA1_0020.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     * @throws Exception 
     * @throws ErrorInputException 
     */
    public ResponseContext doPrompt(RequestContext req) throws Exception {
        //����
        VOTool.setParamsFromLP_JSON(req);

        String SUB_CPY_ID;
        String APLY_NO = req.getParameter("APLY_NO");//�ץ�s��
        String BLD_CD = req.getParameter("BLD_CD");//�j�ӥN��
        String FLD_NO = req.getParameter("FLD_NO");//�Ӽh�O
        String OP_STATUS = req.getParameter("OP_STATUS");//�@�~�i��
        String INPUT_ID = req.getParameter("INPUT_ID");//��J�H��ID
        String OP_TYPE = req.getParameter("OP_TYPE");//�@�~�O
        if (StringUtils.isBlank(OP_TYPE)) {
            OP_TYPE = "P";
        }

        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);//�����q�O          
        } catch (Exception e) {
            SUB_CPY_ID = null;
            log.error("���ȥ���", e);
        }

        resp.addOutputData("APLY_NO", APLY_NO);
        resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        resp.addOutputData("BLD_CD", BLD_CD);
        resp.addOutputData("FLD_NO", FLD_NO);
        try {

            EP_A10020 theEP_A10020 = new EP_A10020();
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            reqMap.put("BLD_CD", BLD_CD);//�j�ӥN��
            if (StringUtils.isNotBlank(APLY_NO)) {
                reqMap.put("APLY_NO", APLY_NO);//�ץ�s��
            }
            if (StringUtils.isNotBlank(FLD_NO)) {
                reqMap.put("FLD_NO", FLD_NO);
            }
            this.queryL(reqMap, theEP_A10020, true);
            //�d�ߤj�ӼӼh

        } catch (Exception e) {
            log.error("��l����", e);
        }

        try {

            //���s����
            boolean canEdit = new EP_A10010().canEdit(APLY_NO, INPUT_ID, OP_STATUS, user, OP_TYPE, SUB_CPY_ID);
            resp.addOutputData("canEdit", canEdit);

            if ("01".equals(OP_STATUS) && user.getEmpID().equals(INPUT_ID)) {
                resp.addOutputData("candelet", 0); //��ܭ簣�s ,�����A�P�_rtnCMap.DATA_TYPE!=B

            } else {
                resp.addOutputData("candelet", 1); //���í簣�s//���ýվ�s
            }
        } catch (Exception e) {
            log.error("��l���s�����", e);
        }

        try {
            //���o�n�O�γ~�U�Կ��
            resp.addOutputData("FLD_TYPEList", FieldOptionList.getName("EP", "FLD_TYPE"));
        } catch (Exception e) {
            log.error("�U�Կ����o����", e);
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMap"));
            EP_A10020 theEP_A10020 = new EP_A10020();
            this.queryL(reqMap, theEP_A10020, false);

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0020_MSG_001"));//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0020_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPA1_0020_MSG_003"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPA1_0020_MSG_004"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPA1_0020_MSG_004"), e);//�d�ߥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0020_MSG_004"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �s�W 
     * @param req
     * @return
     */
    public ResponseContext doAdd(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));
            DTEPB309 theDTEPB309 = VOTool.mapToVO(DTEPB309.class, reqMap);
            theDTEPB309.setDATA_TYPE("I");
            new EPA1_0020_mod().checkIsCanInsert(theDTEPB309);
            new EPB3_0010_mod().isChangeable(theDTEPB309.getAPLY_NO());

            EP_A10020 theEP_A10020 = new EP_A10020();
            Transaction.begin();
            try {
                theEP_A10020.insert(theDTEPB309);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0020_MSG_005"));//�s�W����

            //�d��
            try {
                this.queryL(reqMap, theEP_A10020, false);
            } catch (Exception e) {
                log.error("�s�W���������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0020_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0020_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0020_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �ק� 
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));
            DTEPB309 theDTEPB309 = VOTool.mapToVO(DTEPB309.class, reqMap);
            theDTEPB309.setDATA_TYPE("A");
            new EPA1_0020_mod().checkIsCanUpdate(theDTEPB309, "U");
            new EPB3_0010_mod().isChangeable(theDTEPB309.getAPLY_NO());
            EP_A10020 theEP_A10020 = new EP_A10020();
            Transaction.begin();
            try {
                theEP_A10020.update(theDTEPB309);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0020_MSG_007"));//�ק粒��

            //�d��
            try {
                this.queryL(reqMap, theEP_A10020, false);
            } catch (Exception e) {
                log.error("�ק粒�������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0020_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0020_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0020_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �R�� 
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB309 theDTEPB309 = VOTool.mapToVO(DTEPB309.class, reqMap);
            theDTEPB309.setDATA_TYPE("D");
            new EPA1_0020_mod().checkIsCanUpdate(theDTEPB309, "D");
            new EPB3_0010_mod().isChangeable(theDTEPB309.getAPLY_NO());
            EP_A10020 theEP_A10020 = new EP_A10020();
            Transaction.begin();
            try {
                theEP_A10020.delete(theDTEPB309);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0020_MSG_008"));//�R������

            //�d��
            try {
                this.queryL(reqMap, theEP_A10020, false);
            } catch (Exception e) {
                log.error("�R�����������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0020_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0020_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0020_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �簣 
     * @param req
     * @return
     */
    public ResponseContext doDeleteB(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB309 theDTEPB309 = VOTool.mapToVO(DTEPB309.class, reqMap);
            new EPB3_0010_mod().isChangeable(theDTEPB309.getAPLY_NO());
            EP_A10020 theEP_A10020 = new EP_A10020();
            Transaction.begin();
            try {
                theEP_A10020.deleteDTEPB309(theDTEPB309);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0020_MSG_009"));//�簣����

            //�d��
            try {
                this.queryL(reqMap, theEP_A10020, false);
            } catch (Exception e) {
                log.error("�簣�����d�L��Ƶ������`", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0020_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0020_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�簣����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0020_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �վ� 
     * @param req
     * @return
     */
    public ResponseContext doChange(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB309 theDTEPB309 = VOTool.mapToVO(DTEPB309.class, reqMap);
            //�ˮ֬O�_�i�վ�A���i�h��X���~
            new EPA1_0020_mod().checkIsCanUpdate(theDTEPB309, "C");
            new EPB3_0010_mod().isChangeable(theDTEPB309.getAPLY_NO());
            EP_A10020 theEP_A10020 = new EP_A10020();
            Transaction.begin();
            try {
                theEP_A10020.change(theDTEPB309);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0020_MSG_010"));//�վ�ץ󧹦�

            //�d��
            try {
                this.queryL(reqMap, theEP_A10020, false);
            } catch (Exception e) {
                log.error("�վ�ץ󧹦����d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPA1_0020_MSG_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0020_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�վ�ץ󥢱�", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0020_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �ץX
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {
        try {

            // Ū���e�����
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String OP_DATE = DATE.toDate_yyyyMMdd(DATE.getDBDate());//�@�~��� 
            StringBuffer sbf = new StringBuffer();
            sbf.append(MessageUtil.getMessage("EPA1_0020_UI_TITLE")).append('_').append(OP_DATE); // �Ӽh����_YYYMMDD

            reqMap.put("fileName", sbf.toString()); // ��J xls �ɦW

            reqMap.put("gridJSON", req.getParameter("gridJSON"));

            // �̬d�߱��󭫷s�d�߸�ƫ�N��ƶץX��excel��
            new EP_A10020().queryForExport(reqMap, user, resp);

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPA1_0020_MSG_EXPORT_DENF"); // �d�L��ƾɭP�ץX����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028"); //�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0020_MSG_EXPORT_FAIL"); //�ץX����
                }
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPA1_0020_MSG_EXPORT_FAIL"); //�ץX����
        }

        return resp;
    }

    /**
     * �d��
     * @param reqMap
     * @throws Exception 
     * @throws Exception 
     */
    private void queryL(Map reqMap, EP_A10020 theEP_A10020, boolean isPrompt) throws Exception {
        Map tmp_reqMap = new HashMap();
        tmp_reqMap.put("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        tmp_reqMap.put("BLD_CD", MapUtils.getString(reqMap, "BLD_CD"));

        //���o�j�Ӱ򥻸��
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        reqMap.put("APLY_NO", APLY_NO);//�ץ�s��
        Map rtnMapA = new EP_A10010().queryMap(reqMap);
        if (isPrompt) {
            resp.addOutputData("rtnMapA", VOTool.toJSON(rtnMapA));
        } else {
            resp.addOutputData("rtnMapA", rtnMapA);
        }

        try {
            List<Map> rtnBList = theEP_A10020.queryList(tmp_reqMap);
            if (isPrompt) {
                resp.addOutputData("rtnBList", VOTool.toJSON(rtnBList));
            } else {
                resp.addOutputData("rtnBList", rtnBList);
            }

            BigDecimal TFLD_SIZE = BigDecimal.ZERO;
            BigDecimal TPBL_RATE = BigDecimal.ZERO;
            BigDecimal TAVG_AMT = BigDecimal.ZERO;
            BigDecimal TCLR_AMT = BigDecimal.ZERO;
            for (Map map : rtnBList) {
                BigDecimal FLD_SIZE = (BigDecimal) MapUtils.getObject(map, "FLD_SIZE", BigDecimal.ZERO);
                BigDecimal PBL_RATE = (BigDecimal) MapUtils.getObject(map, "PBL_RATE", BigDecimal.ZERO);
                BigDecimal AVG_AMT = (BigDecimal) MapUtils.getObject(map, "AVG_AMT", BigDecimal.ZERO);
                BigDecimal CLR_AMT = (BigDecimal) MapUtils.getObject(map, "CLR_AMT", BigDecimal.ZERO);
                TFLD_SIZE = TFLD_SIZE.add(FLD_SIZE);
                TPBL_RATE = TPBL_RATE.add(PBL_RATE);
                TAVG_AMT = TAVG_AMT.add(AVG_AMT);
                TCLR_AMT = TCLR_AMT.add(CLR_AMT);

            }
            resp.addOutputData("TFLD_SIZE", TFLD_SIZE);
            resp.addOutputData("TPBL_RATE", TPBL_RATE);
            resp.addOutputData("TAVG_AMT", TAVG_AMT);
            resp.addOutputData("TCLR_AMT", TCLR_AMT);

        } catch (DataNotFoundException dnfe) {
            log.error("rtnBList�d�L���", dnfe);
            resp.addOutputData("rtnBList", "");
        }

        if (StringUtils.isNotBlank(APLY_NO)) {

            try {

                tmp_reqMap.put("APLY_NO", APLY_NO);
                List<Map> rtnCList = theEP_A10020.queryList(tmp_reqMap);

                BigDecimal TFLD_SIZE2 = BigDecimal.ZERO;
                BigDecimal TPBL_RATE2 = BigDecimal.ZERO;
                BigDecimal TAVG_AMT2 = BigDecimal.ZERO;
                BigDecimal TCLR_AMT2 = BigDecimal.ZERO;

                for (Map map : rtnCList) {
                    BigDecimal FLD_SIZE = (BigDecimal) MapUtils.getObject(map, "FLD_SIZE", BigDecimal.ZERO);
                    BigDecimal PBL_RATE = (BigDecimal) MapUtils.getObject(map, "PBL_RATE", BigDecimal.ZERO);
                    BigDecimal AVG_AMT = (BigDecimal) MapUtils.getObject(map, "AVG_AMT", BigDecimal.ZERO);
                    BigDecimal CLR_AMT = (BigDecimal) MapUtils.getObject(map, "CLR_AMT", BigDecimal.ZERO);
                    TFLD_SIZE2 = TFLD_SIZE2.add(FLD_SIZE);
                    TPBL_RATE2 = TPBL_RATE2.add(PBL_RATE);
                    TAVG_AMT2 = TAVG_AMT2.add(AVG_AMT);
                    TCLR_AMT2 = TCLR_AMT2.add(CLR_AMT);

                }
                resp.addOutputData("TFLD_SIZE2", TFLD_SIZE2);
                resp.addOutputData("TPBL_RATE2", TPBL_RATE2);
                resp.addOutputData("TAVG_AMT2", TAVG_AMT2);
                resp.addOutputData("TCLR_AMT2", TCLR_AMT2);

                if (isPrompt) {
                    resp.addOutputData("rtnCList", VOTool.toJSON(rtnCList));
                } else {
                    resp.addOutputData("rtnCList", rtnCList);
                }

            } catch (DataNotFoundException dnfe) {
                log.error("rtnCList�d�L���", dnfe);
                resp.addOutputData("rtnCList", "");
            }

        }

        //�Y�Ӽh����
        String FLD_NO = MapUtils.getString(reqMap, "FLD_NO");
        if (StringUtils.isNotBlank(FLD_NO)) {
            reqMap.put("FLD_NO", FLD_NO);
            reqMap.put("DATA_TYPE", "A");
            try {
                Map rtnMap = theEP_A10020.queryMap(reqMap);
                if (isPrompt) {
                    resp.addOutputData("rtnMap", VOTool.toJSON(rtnMap));
                } else {
                    resp.addOutputData("rtnMap", rtnMap);
                }
            } catch (DataNotFoundException dnfe) {
                try {
                    reqMap.remove("DATA_TYPE");
                    reqMap.remove("APLY_NO");
                    Map rtnMap = theEP_A10020.queryMap(reqMap);

                    if (isPrompt) {
                        resp.addOutputData("rtnMap", VOTool.toJSON(rtnMap));
                    } else {
                        resp.addOutputData("rtnMap", rtnMap);
                    }

                } catch (DataNotFoundException dne) {
                    log.error("rtnMap�d�L���", dne);
                    resp.addOutputData("rtnMap", "");
                }
            }
        }
    }
}
