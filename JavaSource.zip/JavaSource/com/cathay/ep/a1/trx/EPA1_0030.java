package com.cathay.ep.a1.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.a1.module.EPA1_0030_mod;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.a1.module.EP_A10020;
import com.cathay.ep.a1.module.EP_A10030;
import com.cathay.ep.a1.module.EP_A10040;
import com.cathay.ep.a3.module.EP_A30030;
import com.cathay.ep.b3.module.EPB3_0010_mod;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPB310;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Version  Description                                 Author
 * 2013/8/29   1.0      Created                                     ����i
 * 2013/10/3   1.1      Modified�վ�ǧO�����A��X�Ӽh���ΡB�X�֧@�~  ������
 * 2018/03/3   2.0      �t�X��ؾɤJ�վ�  ����[
 * 
 * �@�B    �{���\�෧�n�����G
 * �{���\��    �ǧO����
 * �{���W��    EPA1_0030
 * �@�~�覡    ONLINE
 * ���n����      (1) ��l
 *              (2) �d�� �w �ϥΪ̫��U�d�߫��s��A�I�sEP_A10030�Ҳը��o�ǧO�M���ơC
 *              (3) �ǧO �w �N�ӵ��D�ɸ�Ʊa�JD��
 *              (4) �s�W �w �s�W�@���s�W�ץ󲧰ʶ���
 *              (5) �ק� �w �s�W�@���ק�ץ󲧰ʶ���
 *              (6) �R�� �w �s�W�@���R���ץ󲧰ʶ���
 *              (7) �վ� �w ��s�ץ󲧰ʶ��ؤ��e
 *              (8) �簣 �w �R���ץ󲧰ʶ���
 *              (9) �վ�ץ� �w �N�ӵ��ץ󲧰ʶ��ظ�Ʊa�JD��
 * ���s���v    �M��FUNC_ID = EPA10030
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 *</pre>
 * @author ���_��
 * @since 2013/10/30
 */
@SuppressWarnings("unchecked")
public class EPA1_0030 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPA1_0030.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     * @throws Exception 
     * @throws ErrorInputException 
     */
    public ResponseContext doPrompt(RequestContext req) throws Exception {
        //����
        VOTool.setParamsFromLP_JSON(req);
        String SUB_CPY_ID;
        String APLY_NO = req.getParameter("APLY_NO");//�ץ�s��
        String BLD_CD = req.getParameter("BLD_CD");//�j�ӥN��
        String FLD_NO = req.getParameter("FLD_NO");//�Ӽh�O
        String ROOM_NO = req.getParameter("ROOM_NO");//�ǧO
        String OP_STATUS = req.getParameter("OP_STATUS");//�@�~�i��
        String INPUT_ID = req.getParameter("INPUT_ID");//��J�H��ID
        String OP_TYPE = req.getParameter("OP_TYPE");//�@�~�O
        if (StringUtils.isBlank(OP_TYPE)) {
            OP_TYPE = "P";
        }

        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);//�����q�O
        } catch (Exception e) {
            log.error("���ȥ���", e);
            SUB_CPY_ID = null;
        }

        resp.addOutputData("APLY_NO", APLY_NO);
        resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        resp.addOutputData("BLD_CD", BLD_CD);
        resp.addOutputData("FLD_NO", FLD_NO);
        resp.addOutputData("ROOM_NO", ROOM_NO);
        try {

            //���o�j�Ө���D�ɬ���
            Map reqMap = new HashMap();

            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            reqMap.put("BLD_CD", BLD_CD);//�j�ӥN��
            if (StringUtils.isNotBlank(APLY_NO)) {
                reqMap.put("APLY_NO", APLY_NO);//�ץ�s��
            }
            if (StringUtils.isNotBlank(FLD_NO) && StringUtils.isNotBlank(ROOM_NO)) {
                reqMap.put("FLD_NO", FLD_NO);
                reqMap.put("ROOM_NO", ROOM_NO);
            }
            EP_A10030 theEP_A10030 = new EP_A10030();

            this.queryL(reqMap, theEP_A10030, true);

        } catch (Exception e) {
            log.error("��l����", e);
        }

        try {

            //���s����
            boolean canEdit = new EP_A10010().canEdit(APLY_NO, INPUT_ID, OP_STATUS, user, OP_TYPE, SUB_CPY_ID);
            resp.addOutputData("canEdit", canEdit);

        } catch (Exception e) {
            log.error("��l���s�����", e);
        }

        try {
            //���o�Ӽh�վ�覡�U�Կ��
            resp.addOutputData("FLD_ADJList", FieldOptionList.getName("EP", "FLD_ADJ"));
            //���o���ϥΩʽ�U�Կ��
            resp.addOutputData("USE_KDList", FieldOptionList.getName("EP", "USE_KD"));
            //���o�ϥΪ��p�U�Կ��
            resp.addOutputData("USE_TYPEList", FieldOptionList.getName("EP", "USE_TYPE"));
            //�s���h���O�U�Կ��
            resp.addOutputData("RNT_TPList", FieldOptionList.getName("EP", "RNT_TP"));

        } catch (Exception e) {
            log.error("�U�Կ����o����", e);
        }

        try {
            //���o�ϥγ��M��(�Ĥ@�h)�G 
            resp.addOutputData("DIV_1_LIST", new EP_A30030().getDIV_1_List(SUB_CPY_ID).get(0));//�]���Ҳզ^�ǬO�Ȧ��@��Map��List, �ҥH�o����Ĥ@��
        } catch (Exception e) {
            log.error("���o�ϥγ��M��(�Ĥ@�h)����", e);

        }

        resp.addOutputData("TRN_KIND", req.getParameter("TRN_KIND"));
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMap"));
            EP_A10030 theEP_A10030 = new EP_A10030();
            this.queryL(reqMap, theEP_A10030, false);

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("MEP00002"));//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPA1_0030_MSG_003"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("MEP00003"), e);//�d�ߥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    private void doCountDiff1(List<Map> rtnCList, List<Map> rtnBList, boolean isQuery) throws ModuleException {
        BigDecimal TROOM_SIZE2 = BigDecimal.ZERO;
        BigDecimal TRNT_SIZE2 = BigDecimal.ZERO;
        BigDecimal TMGT_SIZE2 = BigDecimal.ZERO;
        BigDecimal TNET_SIZE2 = BigDecimal.ZERO;

        BigDecimal TROOM_SIZE = BigDecimal.ZERO;
        BigDecimal TRNT_SIZE = BigDecimal.ZERO;
        BigDecimal TMGT_SIZE = BigDecimal.ZERO;
        BigDecimal TNET_SIZE = BigDecimal.ZERO;

        if (isQuery) {
            for (Map map : rtnCList) {
                String FLD_ADJ = MapUtils.getString(map, "FLD_ADJ");
                if ("1".equals(FLD_ADJ) || "2".equals(FLD_ADJ)) {
                    TROOM_SIZE2 = TROOM_SIZE2.add(getDecimal(map.get("ROOM_SIZE")));
                    TRNT_SIZE2 = TRNT_SIZE2.add(getDecimal(map.get("RNT_SIZE")));
                    TMGT_SIZE2 = TMGT_SIZE2.add(getDecimal(map.get("MGT_SIZE")));
                    TNET_SIZE2 = TNET_SIZE2.add(getDecimal(map.get("NET_SIZE")));
                }
            }

            for (Map map : rtnBList) {
                if ("Y".equals(MapUtils.getString(map, "IS_CHECKED"))) {
                    TROOM_SIZE = TROOM_SIZE.add(getDecimal(map.get("ROOM_SIZE")));
                    TRNT_SIZE = TRNT_SIZE.add(getDecimal(map.get("RNT_SIZE")));
                    TMGT_SIZE = TMGT_SIZE.add(getDecimal(map.get("MGT_SIZE")));
                    TNET_SIZE = TNET_SIZE.add(getDecimal(map.get("NET_SIZE")));
                }
            }
        } else {
            for (Map map : rtnCList) {
                String FLD_ADJ = MapUtils.getString(map, "FLD_ADJ");
                if ("1".equals(FLD_ADJ) || "2".equals(FLD_ADJ)) {
                    TROOM_SIZE2 = TROOM_SIZE2.add(getDecimal(map.get("ROOM_SIZE")));
                    TRNT_SIZE2 = TRNT_SIZE2.add(getDecimal(map.get("RNT_SIZE")));
                    TMGT_SIZE2 = TMGT_SIZE2.add(getDecimal(map.get("MGT_SIZE")));
                    TNET_SIZE2 = TNET_SIZE2.add(getDecimal(map.get("NET_SIZE")));
                }
            }

            for (Map map : rtnBList) {

                TROOM_SIZE = TROOM_SIZE.add(getDecimal(map.get("ROOM_SIZE")));
                TRNT_SIZE = TRNT_SIZE.add(getDecimal(map.get("RNT_SIZE")));
                TMGT_SIZE = TMGT_SIZE.add(getDecimal(map.get("MGT_SIZE")));
                TNET_SIZE = TNET_SIZE.add(getDecimal(map.get("NET_SIZE")));
            }
        }
        resp.addOutputData("TROOM_SIZE1", TROOM_SIZE);
        resp.addOutputData("TRNT_SIZE1", TRNT_SIZE);
        resp.addOutputData("TMGT_SIZE1", TMGT_SIZE);
        resp.addOutputData("TNET_SIZE1", TNET_SIZE);

        resp.addOutputData("TROOM_SIZE2", TROOM_SIZE.subtract(TROOM_SIZE2));
        resp.addOutputData("TRNT_SIZE2", TRNT_SIZE.subtract(TRNT_SIZE2));
        resp.addOutputData("TMGT_SIZE2", TMGT_SIZE.subtract(TMGT_SIZE2));
        resp.addOutputData("TNET_SIZE2", TNET_SIZE.subtract(TNET_SIZE2));

    }

    /**
     * �p��t�ȻP�Ŀ�X�p
     * @param req
     * @return
     * @throws ModuleException 
     */
    public ResponseContext doCountDiff(RequestContext req) throws ModuleException {

        List<Map> selectedBox = VOTool.jsonAryToMaps(req.getParameter("selectedBox"));
        List<Map> rtnCList = VOTool.jsonAryToMaps((req.getParameter("rtnCList")));
        doCountDiff1(rtnCList, selectedBox, false);
        return resp;
    }

    /**
     * �s�W 
     * @param req
     * @return
     */
    public ResponseContext doAdd(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            List<Map> chkBList = VOTool.jsonAryToMaps(req.getParameter("selectedBox"));
            DTEPB310 theDTEPB310 = VOTool.mapToVO(DTEPB310.class, reqMap);
            theDTEPB310.setDATA_TYPE("I");
            EPA1_0030_mod theEPA1_0030_mod = new EPA1_0030_mod();
            theEPA1_0030_mod.checkInsert(theDTEPB310, chkBList);
            new EPB3_0010_mod().isChangeable(theDTEPB310.getAPLY_NO());
            String FLD_ADJ = MapUtils.getString(reqMap, "FLD_ADJ");
            theEPA1_0030_mod.checkADJ(FLD_ADJ, chkBList);

            EP_A10030 theEP_A10030 = new EP_A10030();
            Transaction.begin();
            try {
                theEP_A10030.insert(theDTEPB310, FLD_ADJ, MapUtils.getString(reqMap, "RNT_TP"), chkBList);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("MEP00004"));//�s�W����

            //�d��
            try {
                this.queryL(reqMap, theEP_A10030, false);
            } catch (Exception e) {
                log.error("�s�W���������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00005"));//�s�W����
        }

        return resp;
    }

    /**
     * �ק� 
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB310 theDTEPB310 = VOTool.mapToVO(DTEPB310.class, reqMap);
            theDTEPB310.setDATA_TYPE("A");
            theDTEPB310.setFLD_ADJ("0");

            new EPA1_0030_mod().checkUpdate(theDTEPB310, "1", "1");

            new EPB3_0010_mod().isChangeable(theDTEPB310.getAPLY_NO());
            EP_A10030 theEP_A10030 = new EP_A10030();
            Transaction.begin();
            try {
                theEP_A10030.update(theDTEPB310, true);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0030_MSG_007"));//�ק粒��

            //�d��
            try {
                Map storeMap = VOTool.jsonToMap(req.getParameter("storeMap"));
                this.queryL(storeMap, theEP_A10030, false);
            } catch (Exception e) {
                log.error("�ק粒�������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0030_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0030_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �R�� 
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB310 theDTEPB310 = VOTool.mapToVO(DTEPB310.class, reqMap);
            theDTEPB310.setDATA_TYPE("D");
            new EPA1_0030_mod().checkDelete(theDTEPB310);
            new EPB3_0010_mod().isChangeable(theDTEPB310.getAPLY_NO());
            EP_A10030 theEP_A10030 = new EP_A10030();
            Transaction.begin();
            try {
                theEP_A10030.delete(theDTEPB310);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("MEP00010"));//�R������

            //�d��
            try {
                Map storeMap = VOTool.jsonToMap(req.getParameter("storeMap"));
                this.queryL(storeMap, theEP_A10030, false);
            } catch (Exception e) {
                log.error("�R�����������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00011");//�R������
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00011"));//�R������
        }

        return resp;
    }

    /**
     * �簣 
     * @param req
     * @return
     */
    public ResponseContext doDeleteB(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB310 theDTEPB310 = VOTool.mapToVO(DTEPB310.class, reqMap);
            new EPB3_0010_mod().isChangeable(theDTEPB310.getAPLY_NO());
            EP_A10030 theEP_A10030 = new EP_A10030();
            Transaction.begin();
            try {
                theEP_A10030.deleteDTEPB310(theDTEPB310);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0030_MSG_009"));//�簣����

            //�d��
            try {
                Map storeMap = VOTool.jsonToMap(req.getParameter("storeMap"));
                this.queryL(storeMap, theEP_A10030, false);
            } catch (Exception e) {
                log.error("�簣�����d�L��Ƶ������`", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0030_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�簣����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0030_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �վ� 
     * @param req
     * @return
     */
    public ResponseContext doChange(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            DTEPB310 theDTEPB310 = VOTool.mapToVO(DTEPB310.class, reqMap);
            //�ˮ֪��A�O�_�i���ʡA���i�h��X���~
            new EPB3_0010_mod().isChangeable(theDTEPB310.getAPLY_NO());
            new EPA1_0030_mod().checkUpdate(theDTEPB310, "1", "2");

            EP_A10030 theEP_A10030 = new EP_A10030();
            Transaction.begin();
            try {
                theEP_A10030.change(theDTEPB310);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPA1_0030_MSG_010"));//�վ�ץ󧹦�

            //�d��
            try {
                Map storeMap = VOTool.jsonToMap(req.getParameter("storeMap"));
                this.queryL(storeMap, theEP_A10030, false);
            } catch (Exception e) {
                log.error("�վ�ץ󧹦����d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPA1_0030_MSG_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�վ�ץ󥢱�", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0030_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �j�M����-�Ȥ��ĳ�M��
     * @param req
     * @return
     */
    public ResponseContext doGetCusName(RequestContext req) {
        this
                .getCusName(req.getParameter("SUB_CPY_ID"), req.getParameter("CRT_NO"), req.getParameter("APLY_NO"), req
                        .getParameter("CUS_NO"));

        return resp;
    }

    /**
     * ���o�Ӽh���
     * @param req
     * @return
     */
    public ResponseContext doGetFldSize(RequestContext req) {
        this
                .getFldSize(req.getParameter("SUB_CPY_ID"), req.getParameter("BLD_CD"), req.getParameter("FLD_NO"), req
                        .getParameter("APLY_NO"));

        return resp;
    }

    /**
     * �d���I����
     * @param req
     * @return
     */
    public ResponseContext doGetQueryData(RequestContext req) {
        try {
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            String APLY_NO = req.getParameter("APLY_NO");
            String CRT_NO = req.getParameter("CRT_NO");
            String CUS_NO = req.getParameter("CUS_NO");

            //���o�Ӽh���
            if ("Y".equals(req.getParameter("qryFldSize"))) {
                String FLD_NO = req.getParameter("FLD_NO");
                String BLD_CD = req.getParameter("BLD_CD");
                this.getFldSize(SUB_CPY_ID, BLD_CD, FLD_NO, APLY_NO);
            }
            //�Ȥ�W��
            this.getCusName(SUB_CPY_ID, CRT_NO, APLY_NO, CUS_NO);

            //���o�u�s���h���w�]�ȡv���
            if ("Y".equals(req.getParameter("qryRNT_TP"))) {
                this.getTRN_TP(APLY_NO, SUB_CPY_ID);
            }
        } catch (Exception e) {
            log.error("�d���I���Ƨ@�~����", e);
        }
        return resp;
    }

    /**
     * �̷ӿ��1�d�߿��2
     * @param req
     * @return
     */
    public ResponseContext doQueryDivUserNo2(RequestContext req) {
        try {
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            String USE_DIV_NO_1 = req.getParameter("USE_DIV_NO_1");

            List<Map> userNoDiv2List = new EP_A30030().getDIV_2_List(SUB_CPY_ID, USE_DIV_NO_1, user.getEmpID());
            resp.addOutputData("DIV_2_LIST", userNoDiv2List);
        } catch (Exception e) {
            log.error("�d�ߥ���", e);

        }

        return resp;
    }

    /**
     * �̷ӿ��2�d�߿��3
     * @param req
     * @return
     */
    public ResponseContext doQueryDivUserNo3(RequestContext req) {
        try {
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            String USE_DIV_NO_1 = req.getParameter("USE_DIV_NO_1");
            String USE_DIV_NO_2 = req.getParameter("USE_DIV_NO_2");

            List<Map> userNoDiv3List = new EP_A30030().getDIV_3_List(SUB_CPY_ID, USE_DIV_NO_1, USE_DIV_NO_2, user.getEmpID());
            resp.addOutputData("DIV_3_LIST", userNoDiv3List);
        } catch (Exception e) {
            log.error("�d�ߥ���", e);

        }

        return resp;
    }

    /**
     * �d��
     * @param reqMap
     * @throws Exception 
     * @throws Exception 
     */
    private void queryL(Map reqMap, EP_A10030 theEP_A10030, boolean isPrompt) throws Exception {
        Map tmp_reqMap = new HashMap();
        tmp_reqMap.put("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        tmp_reqMap.put("BLD_CD", MapUtils.getString(reqMap, "BLD_CD"));
        tmp_reqMap.put("FLD_NO", MapUtils.getString(reqMap, "FLD_NO"));
        List<Map> rtnBList = new ArrayList();

        try {
            rtnBList = theEP_A10030.queryList(tmp_reqMap);
            BigDecimal TROOM_SIZE = BigDecimal.ZERO;
            BigDecimal TRNT_SIZE = BigDecimal.ZERO;
            BigDecimal TMGT_SIZE = BigDecimal.ZERO;
            BigDecimal TNET_SIZE = BigDecimal.ZERO;
            for (Map map : rtnBList) {
                TROOM_SIZE = TROOM_SIZE.add(getDecimal(map.get("ROOM_SIZE")));
                TRNT_SIZE = TRNT_SIZE.add(getDecimal(map.get("RNT_SIZE")));
                TMGT_SIZE = TMGT_SIZE.add(getDecimal(map.get("MGT_SIZE")));
                TNET_SIZE = TNET_SIZE.add(getDecimal(map.get("NET_SIZE")));
            }
            resp.addOutputData("TROOM_SIZE", TROOM_SIZE);
            resp.addOutputData("TRNT_SIZE", TRNT_SIZE);
            resp.addOutputData("TMGT_SIZE", TMGT_SIZE);
            resp.addOutputData("TNET_SIZE", TNET_SIZE);

            if (isPrompt) {
                resp.addOutputData("rtnBList", VOTool.toJSON(rtnBList));
            } else {
                resp.addOutputData("rtnBList", rtnBList);
            }

        } catch (DataNotFoundException dnfe) {
            log.debug("rtnBList�d�L���", dnfe);
            resp.addOutputData("rtnBList", "");
        }

        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        List<Map> rtnCList = new ArrayList();
        if (StringUtils.isNotBlank(APLY_NO)) {
            try {
                Map C_reqMap = new HashMap();//�d�ߩҦ����ʶ���
                C_reqMap.put("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
                C_reqMap.put("BLD_CD", MapUtils.getString(reqMap, "BLD_CD"));
                C_reqMap.put("APLY_NO", APLY_NO);
                rtnCList = theEP_A10030.queryList(C_reqMap);

                if (rtnCList.size() > 0) {
                    //�̲��ʩ��ӡA���O�D�ɬO�_�����ΦX�ֲ���
                    new EPA1_0030_mod().processList(rtnBList, rtnCList);

                    doCountDiff1(rtnCList, rtnBList, true);
                }
                if (isPrompt) {
                    resp.addOutputData("rtnCList", VOTool.toJSON(rtnCList));
                    resp.addOutputData("rtnBList", VOTool.toJSON(rtnBList));
                } else {
                    resp.addOutputData("rtnCList", rtnCList);
                    resp.addOutputData("rtnBList", rtnBList);
                }

            } catch (DataNotFoundException dnfe) {
                log.error("rtnCList�d�L���", dnfe);
                resp.addOutputData("rtnCList", "");
            }
        }

        //�d�߫ǧO����
        String FLD_NO = MapUtils.getString(reqMap, "FLD_NO");
        String ROOM_NO = MapUtils.getString(reqMap, "ROOM_NO");
        Map rtnMap = new HashMap();
        if (StringUtils.isNotBlank(FLD_NO) && StringUtils.isNotBlank(ROOM_NO)) {
            try {
                tmp_reqMap.put("FLD_NO", FLD_NO);
                tmp_reqMap.put("ROOM_NO", ROOM_NO);
                rtnMap = theEP_A10030.queryMap(tmp_reqMap);
                if (isPrompt) {
                    resp.addOutputData("rtnMap", VOTool.toJSON(rtnMap));
                } else {
                    resp.addOutputData("rtnMap", rtnMap);
                }

            } catch (DataNotFoundException dnfe) {
                log.error("rtnMap�d�L���", dnfe);
                resp.addOutputData("rtnMap", "");
            }
        }

        if (rtnBList.isEmpty() && rtnCList.isEmpty()) {
            throw new DataNotFoundException();
        }
    }

    /**
     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }

        if (BigDecimal.class.isInstance(obj)) {
            return (BigDecimal) obj;
        }

        String str = String.valueOf(obj);

        if (StringUtils.isBlank(str)) {
            return BigDecimal.ZERO;
        }

        return new BigDecimal(str);
    }

    /**
     * ���o�u�Ȥ�v���
     * @param SUB_CPY_ID
     * @param CRT_NO
     * @param APLY_NO
     * @param CUS_NO
     */
    private void getCusName(String SUB_CPY_ID, String CRT_NO, String APLY_NO, String CUS_NO) {
        try {

            Map trnMap = new EP_A10040().getCustSuggestList(SUB_CPY_ID, CRT_NO, APLY_NO, CUS_NO);

            // 20161219 LogSecurity ���v        
            Map logOneSecurityMap = new HashMap();
            logOneSecurityMap.put("CUS_NAME", MapUtils.getString(trnMap, "CUS_NAME", ""));
            logSecurity(logOneSecurityMap);

            resp.addOutputData("trnMap", trnMap);
        } catch (Exception e) {
            log.error("�Ȥ�j�M�d�ߥ���", e);
            resp.addOutputData("trnMap", "");
        }

    }

    /**
     * ���o�u�Ӽh�v���
     * @param SUB_CPY_ID
     * @param BLD_CD
     * @param FLD_NO
     * @param APLY_NO
     */
    private void getFldSize(String SUB_CPY_ID, String BLD_CD, String FLD_NO, String APLY_NO) {
        try {

            Map reqMap = new HashMap();

            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            reqMap.put("BLD_CD", BLD_CD);
            reqMap.put("FLD_NO", FLD_NO);

            Map aMap;
            EP_A10020 theEP_A10020 = new EP_A10020();

            if (StringUtils.isNotBlank(APLY_NO)) {
                reqMap.put("APLY_NO", APLY_NO);

                try {
                    aMap = theEP_A10020.queryMap(reqMap);
                } catch (DataNotFoundException dnfe) {
                    log.debug("��APLY_NO�d�L���", dnfe);
                    reqMap.remove("APLY_NO");

                    try {
                        aMap = theEP_A10020.queryMap(reqMap);
                    } catch (DataNotFoundException dnfe1) {
                        log.debug("�LAPLY_NO�d�L���", dnfe1);
                        aMap = null;
                    }
                }

            } else {
                try {
                    aMap = theEP_A10020.queryMap(reqMap);
                } catch (DataNotFoundException dnfe) {
                    log.debug("�LAPLY_NO�d�L���", dnfe);
                    reqMap.remove("APLY_NO");
                    aMap = null;
                }
            }

            resp.addOutputData("aMap", aMap);

        } catch (Exception e) {
            log.error("���o�Ӽh��ƥ���", e);
            resp.addOutputData("aMap", "");
        }

    }

    /**
     * ���o�u�s���h���w�]�ȡv���
     * @param APLY_NO
     */
    private void getTRN_TP(String APLY_NO, String SUB_CPY_ID) {

        try {
            DTEPB301 vo301 = new DTEPB301();
            vo301.setAPLY_NO(APLY_NO);
            vo301.setSUB_CPY_ID(SUB_CPY_ID);
            vo301 = VOTool.findByPK(vo301, false);
            String TRN_TP = vo301 != null ? FieldOptionList.getName("EP", "TRN_RNT_TP", vo301.getTRN_KIND()) : "";
            resp.addOutputData("TRN_TP", TRN_TP);
        } catch (Exception e) {
            log.error("���o�s���h���w�]�ȥ���", e);
            resp.addOutputData("TRN_TP", "");
        }
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doSuggestFLD_NO(RequestContext req) {
        try {

            String BLD_CD = req.getParameter("BLD_CD");
            if (StringUtils.isNotBlank(BLD_CD)) {
                Map reqMap = new HashMap();
                reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
                reqMap.put("BLD_CD", BLD_CD);
                reqMap.put("FZY_FLD_NO", req.getParameter("suggestValue"));

                List<Map> rtnList = new EP_A10020().queryList(reqMap);
                List<Map> FLD_NOList = new ArrayList<Map>();
                Map trnMap;
                for (Map map : rtnList) {
                    trnMap = new HashMap();
                    trnMap.put("FLD_NO", MapUtils.getString(map, "FLD_NO"));
                    FLD_NOList.add(trnMap);
                }
                resp.addOutputData("suggestResult", FLD_NOList);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPA1_0030_MSG_003"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("MEP00003"), e);//�d�ߥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }
}
