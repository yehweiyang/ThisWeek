package com.cathay.ep.c3.trx;

import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.c3.module.EPC3_0020_mod;
import com.cathay.ep.c3.module.EPC3_0040_mod;
import com.cathay.ep.c3.module.EP_C30010;
import com.cathay.ep.c3.module.EP_C30020;
import com.cathay.ep.c3.module.EP_C30050;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Version Description Author
 * 2013/10/15  1.0     Created     ������
 *
 * �{���\�෧�n�����G
 * �{���\��    ú�O���p�B�z
 * �{���W��    EPC3_0020
 * �@�~�覡    ONLINE
 * ���n����    1.�d�ߡG�ھ�ú�O�s���A�d��ú�O���p�Pú�ڬ���
 *             2.���p�T�{�G�Nú�ڬ������pú�O����
 *             3.���p�����G�Nú�ڬ������p�쪺ú�O���ӲM��
 * ���s���v    �M��
 * �����q����榡���js  �M��
 * �h��y�t    �M��
 * �h���d��    ������
 *</pre>
 * @author ���_��
 * @since 2013/12/10
 */
@SuppressWarnings("unchecked")
public class EPC3_0020 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0020.class);

    /**isDebug*/
    private boolean isDebug = log.isDebugEnabled();

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     * @throws Exception 
     */
    public ResponseContext doPrompt(RequestContext req) {
        //����
        VOTool.setParamsFromLP_JSON(req);

        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPC3_0020_MSG_002");//���o�����q�O����
        }

        //�ӷ�����
        String SOURCE = req.getParameter("SOURCE");
        //ú�ڤ覡
        String PAY_TYPE = req.getParameter("PAY_TYPE");
        //ú�O�M��
        String PAY_MAP = req.getParameter("PAY_MAP");
        //ú�O�s��
        String PAY_NO = req.getParameter("PAY_NO");
        //ú�ڲM��
        String PAY_LIST = req.getParameter("PAY_LIST");
        resp.addOutputData("DTMP_NO", req.getParameter("DTMP_NO"));
        List<Map> list = new ArrayList();
        try {
            if (PAY_LIST != null || StringUtils.isNotBlank(PAY_LIST)) {
                list = VOTool.jsonAryToMaps(PAY_LIST);
            }
        } catch (ModuleException me) {
            log.error("", me);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPC3_0020_MSG_001");//�ǤJú�ڲM����~
        }

        if ("EPC3_0010".equals(SOURCE)) {
            BigDecimal SUM_PAY_AMT = BigDecimal.ZERO;
            for (Map map : list) {
                SUM_PAY_AMT = SUM_PAY_AMT.add(getDecimal(map.get("PAY_AMT")));
            }
            resp.addOutputData("SUM_PAY_AMT", SUM_PAY_AMT);
            resp.addOutputData("SUM_PRE_AMT", "0");
        } else if ("EPC3_0050".equals(SOURCE)) {
            BigDecimal SUM_ACNT_AMT = BigDecimal.ZERO;
            for (Map map : list) {
                SUM_ACNT_AMT = SUM_ACNT_AMT.add(getDecimal(map.get("ACNT_AMT")));
            }
            resp.addOutputData("SUM_PRE_AMT", SUM_ACNT_AMT);
            resp.addOutputData("SUM_PAY_AMT", "0");
        } else {
            resp.addOutputData("SUM_PRE_AMT", "0");
            resp.addOutputData("SUM_PAY_AMT", "0");
        }
        String LINK_FROM = req.getParameter("LINK_FROM");
        if (StringUtils.isNotBlank(LINK_FROM)) {
            resp.addOutputData("LINK_FROM", new StringBuffer().append(LINK_FROM.substring(0, 4)).append('_').append(
                LINK_FROM.substring(4, 8)).toString());
        } else {
            resp.addOutputData("LINK_FROM", SOURCE);
        }
        resp.addOutputData("QUERY_TYPE", req.getParameter("QUERY_TYPE"));
        resp.addOutputData("SOURCE", SOURCE);
        resp.addOutputData("PAY_TYPE", PAY_TYPE);
        resp.addOutputData("PAY_NO", PAY_NO);
        resp.addOutputData("OpUnit", user.getOpUnit());
        //resp.addOutputData("OpStNm", user.getOpUnitShortName());
        resp.addOutputData("EmpNm", user.getEmpName());

        try {
            if (StringUtils.isNotBlank(PAY_MAP)) {
                resp.addOutputData("MAL_AMT", VOTool.jsonToMap(PAY_MAP).get("MAL_AMT"));
                resp.addOutputData("CSH_AMT", VOTool.jsonToMap(PAY_MAP).get("CSH_AMT"));
                resp.addOutputData("PAY_MAP", URLDecoder.decode(PAY_MAP, "big5")); //POPWIN����s�X���D
                //2018-03-13 �վ���W�٧���Ҳ�
                resp.addOutputData("OpStNm", new EP_A10010().getDivName(user.getOpUnit(), SUB_CPY_ID));
            } else {
                resp.addOutputData("PAY_MAP", "");
            }
            if (StringUtils.isNotBlank(PAY_LIST)) {
                resp.addOutputData("PAY_LIST", URLDecoder.decode(PAY_LIST, "big5")); //POPWIN����s�X���D
            } else {
                resp.addOutputData("PAY_LIST", "");
            }
        } catch (Exception e) {
            resp.addOutputData("PAY_MAP", "");
            resp.addOutputData("PAY_LIST", "");
        }

        return resp;

    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {

            this.queryM(req.getParameter("PAY_NO"), req.getParameter("QUERY_TYPE"), req.getParameter("SUB_CPY_ID"));
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("MEP00002"));//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else if (me.getRootException() instanceof DataNotFoundException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00001");//�d�L���
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00780");//�@�~����
                }
            }
        } catch (Exception e) {
            log.error("�@�~����", e);//�@�~����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00780");//�@�~����
        }

        return resp;
    }

    /**
     * �p���`�X
     * @param req
     * @return
     */
    public ResponseContext doCount(RequestContext req) {

        try {
            List<Map> TMP_INFO_LIST = VOTool.jsonAryToMaps(req.getParameter("TMP_INFO_LIST"));

            BigDecimal TACNT_AMT = BigDecimal.ZERO;
            for (Map map : TMP_INFO_LIST) {
                TACNT_AMT = TACNT_AMT.add(getDecimal(map.get("ACNT_AMT")));
            }
            resp.addOutputData("TACNT_AMT", TACNT_AMT);

        } catch (Exception e) {
            log.error("�@�~����", e);//�@�~����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00780");//�@�~����
        }

        return resp;
    }

    /**
     * �d�߫Ȥ�W��
     * @param req
     * @return
     */
    public ResponseContext doGetCusName(RequestContext req) {

        try {
            //����줤��²��
            String POLICY_NO = req.getParameter("POLICY_NO");
            String CST_NM;
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            if (StringUtils.isNotBlank(POLICY_NO) && "I".equals(POLICY_NO.substring(1, 2))) {
                //CST_NM = new DivData().getUnit4ShortName(POLICY_NO.substring(2, 9));
                //2018-03-13 �վ���W�٧���Ҳ�
                CST_NM = new EP_A10010().getDivName(POLICY_NO.substring(2, 9), SUB_CPY_ID);
            } else {
                Map reqMap = new HashMap();
                reqMap.put("CRT_NO", POLICY_NO);
                reqMap.put("CUS_NO", req.getParameter("PAY_TIMES"));
                reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
                CST_NM = (String) new EP_B10020().queryTenentList(reqMap).get(0).get("CUS_NAME");
            }

            resp.addOutputData("CST_NAME", CST_NM);

        } catch (Exception e) {
            log.error("�@�~����", e);//�@�~����
            resp.addOutputData("CST_NAME", "");
        }

        return resp;
    }

    /**
     * ���p�T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMap"));
            List<Map> RMT_LIST = VOTool.jsonAryToMaps(req.getParameter("RMT_LIST"));
            List<Map> CHK_LIST = VOTool.jsonAryToMaps(req.getParameter("CHK_LIST"));
            List<Map> TKD_LIST = VOTool.jsonAryToMaps(req.getParameter("TKD_LIST"));
            List<Map> ACNT_LIST = VOTool.jsonAryToMaps(req.getParameter("ACNT_LIST"));
            List<Map> TMP_LIST = VOTool.jsonAryToMaps(req.getParameter("TMP_LIST"));
            List<Map> insertList = VOTool.jsonAryToMaps(req.getParameter("insertList"));
            Map reqMapD = VOTool.jsonToMap(req.getParameter("reqMapD"));
            log.debug("SUM_CSH_AMT>>>>>" + reqMapD.get("SUM_CSH_AMT"));
            BigDecimal amt1 = getDecimal(reqMapD.get("SUM_CHK_AMT")).add(getDecimal(reqMapD.get("SUM_RMT_AMT"))).add(
                getDecimal(reqMapD.get("SUM_TKD_AMT"))).add(getDecimal(reqMapD.get("SUM_ACNT_AMT"))).add(
                getDecimal(reqMapD.get("SUM_MAL_AMT"))).add(getDecimal(reqMapD.get("SUM_CSH_AMT")));

            BigDecimal amt2;
            String QUERY_TYPE = req.getParameter("QUERY_TYPE");
            if ("DTDKG002".equals(QUERY_TYPE)) {
                amt2 = getDecimal(reqMapD.get("SUM_PRE_AMT"));
            } else {
                amt2 = getDecimal(reqMapD.get("SUM_PAY_AMT")).add(getDecimal(reqMapD.get("SUM_TMP_AMT")));
            }

            if (amt1.compareTo(amt2) != 0) {
                resp.addOutputData("NOTEQL", "YES");
                return resp;
            }

            List<Map> PAY_LIST = (List<Map>) MapUtils.getObject(reqMap, "PAY_LIST");
            
            /**
             * �ˬd�O�_�bFLASH COPY���ɬq
             * ���D��s�� 20190418-0093  
             * �����R�Ȧ���ú�O�d�L�����b�Ȩt��(DK)�R�Ȧ���ơA�o�{�ӵ�ú�O��4/17 16:10:47�R�Ȧ��ɡA
             * XA����I�W��ƮwFLASH COPY�ɶ��A�o��Transaction.commit occur error - javax.transaction.HeuristicMixedException�����~
             * �A�ɭPEP�t�θ��commit�BDK�t�θ�ƥ����\commit
             * �{���վ�A�W�[����ɶ����ˮ֡A�קK���J�ӱ��p 4/19�W�u
             */
            new EPC3_0040_mod().checkFlashCopyTime(MapUtils.getString(PAY_LIST.get(0), "SUB_CPY_ID"));
            
            EPC3_0020_mod theEPC3_0020_mod = new EPC3_0020_mod();

            //�ˮ֬O�_�Vú
            theEPC3_0020_mod.chkBAL_TYPE(PAY_LIST, TMP_LIST);

            //�ˮ֪��B
            //Callú�O���p�B�z�ˮּҲ�.���B�ˬd��k
            log.debug("compareTo>>SUM_CSH_AMT");
            log.debug(getDecimal(reqMapD.get("SUM_CSH_AMT")).compareTo(BigDecimal.ZERO) == 0);
            if (getDecimal(reqMapD.get("SUM_CSH_AMT")).compareTo(BigDecimal.ZERO) == 0) {
                theEPC3_0020_mod.checkAMT(QUERY_TYPE, (Map) reqMap.get("PAY_MAP"), PAY_LIST, RMT_LIST, CHK_LIST, TKD_LIST, ACNT_LIST,
                    TMP_LIST);
            }

            //3.3.2 �ˮ������l�B�O�_���Q���ʹL
            theEPC3_0020_mod.checkSPR_AMT(QUERY_TYPE, PAY_LIST);

            //�B�zú�ڬ���
            //Callú�ڬ������@�Ҳ�.�s�Wú�ڬ�����T��k
            Transaction.setXAMode();
            Transaction.begin();
            //�}XAmode,�Ҳդ����ϥΨ�buds,�ѥD�{���ǤJ,transaction.commit��A����
            //budsArray = [C101,C301,C302,C303,C307]
            BatchUpdateDataSet budsC101 = Transaction.getBatchUpdateDataSet();
            BatchUpdateDataSet budsC301 = new com.cathay.db.impl.BatchUpdateDataSet();
            BatchUpdateDataSet budsC302 = new com.cathay.db.impl.BatchUpdateDataSet();
            BatchUpdateDataSet budsC303 = new com.cathay.db.impl.BatchUpdateDataSet();
            BatchUpdateDataSet budsC307 = new com.cathay.db.impl.BatchUpdateDataSet();
            budsC301.setDataSet(budsC101);
            budsC302.setDataSet(budsC101);
            budsC303.setDataSet(budsC101);
            budsC307.setDataSet(budsC101);
            BatchUpdateDataSet[] budsArray = new BatchUpdateDataSet[] { budsC101, budsC301, budsC302, budsC303, budsC307 };
            String PAY_NO = null;
            try {
                Map PAY_MAP = (Map) MapUtils.getObject(reqMap, "PAY_MAP", new HashMap());
                if (isDebug) {
                    log.debug("reqMap��PAY_TYPE====> " + (String) reqMap.get("PAY_TYPE"));
                    log.debug("PAY_MAP====> " + PAY_MAP);
                    log.debug("PAY_MAP��PAY_TYPE ====> " + (String) PAY_MAP.get("PAY_TYPE"));
                    log.debug("%%%%% EP_C30020.insertPayInfo:start==>" + DATE.currentTime());
                }
                //buds 4�� : C301,C302,C303,C307,C101
                PAY_NO = new EP_C30020().insertPayInfo(QUERY_TYPE, PAY_MAP, PAY_LIST, RMT_LIST, CHK_LIST, TKD_LIST, ACNT_LIST, TMP_LIST,
                    insertList, user, budsArray);
                if (isDebug) {
                    log.debug("%%%%% EP_C30020.insertPayInfo:end==>" + DATE.currentTime());
                }

                Transaction.commit();
            } catch (Exception e) {
                log.debug("Error Log:" + e, e);
                Transaction.rollback();
                throw e;
            } finally {
                if (budsC101 != null) {
                    try {
                        budsC101.close();
                    } catch (Exception e) {
                        log.fatal("budsC101.close ", e);
                        log.fatal("budsC101.isAutoTransaction " + budsC101.isAutoTransaction());
                        log.fatal("budsC101.isOnTranscation " + budsC101.isOnTranscation());
                    }
                }

                if (budsC301 != null) {
                    try {
                        budsC301.close();
                    } catch (Exception e) {
                    }
                }
                if (budsC302 != null) {
                    try {
                        budsC302.close();
                    } catch (Exception e) {
                    }
                }
                if (budsC303 != null) {
                    try {
                        budsC303.close();
                    } catch (Exception e) {
                    }
                }
                if (budsC307 != null) {
                    try {
                        budsC307.close();
                    } catch (Exception e) {
                    }
                }
            }
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC3_0020_MSG_01"));//�T�{����

            //�d��
            try {
                this.queryM(PAY_NO, QUERY_TYPE, MapUtils.getString(PAY_LIST.get(0), "SUB_CPY_ID"));
            } catch (Exception e) {
                log.error("���p�T�{���������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00780");//�@�~����
                }
            }
        } catch (Exception e) {
            log.error("�@�~����", e);//�@�~����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00780");//�@�~����
        }

        return resp;
    }

    /**
     * ���p����
     * @param req
     * @return
     */
    public ResponseContext doCancelConfirm(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            String PAY_NO = MapUtils.getString(reqMap, "PAY_NO");
            String QUERY_TYPE = MapUtils.getString(reqMap, "QUERY_TYPE");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            /**
             * �ˬd�O�_�bFLASH COPY���ɬq
             * ���D��s�� 20190418-0093  
             * �����R�Ȧ���ú�O�d�L�����b�Ȩt��(DK)�R�Ȧ���ơA�o�{�ӵ�ú�O��4/17 16:10:47�R�Ȧ��ɡA
             * XA����I�W��ƮwFLASH COPY�ɶ��A�o��Transaction.commit occur error - javax.transaction.HeuristicMixedException�����~
             * �A�ɭPEP�t�θ��commit�BDK�t�θ�ƥ����\commit
             * �{���վ�A�W�[����ɶ����ˮ֡A�קK���J�ӱ��p 4/19�W�u
             */
            new EPC3_0040_mod().checkFlashCopyTime(SUB_CPY_ID);
            
            
            EPC3_0020_mod theEPC3_0020_mod = new EPC3_0020_mod();

            //�ˮ֬O�_���@�b����
            //Callú�O���p�B�z�ˮּҲ�.ú�O�s���ˬd��k
            new EPC3_0020_mod().checkPayNo(PAY_NO, user, SUB_CPY_ID);

            //���oú�ڬ���
            //Callú�ڳB�z�@�~���@�Ҳ�.���oú�ڬ�����T��k
            Map payInfoMap = new EP_C30010().queryPayInfoMap(PAY_NO, SUB_CPY_ID);

            //4.3.2 �ˮ������l�B�O�_���Q����
            List<Map> PAY_LIST = (List<Map>) MapUtils.getObject(reqMap, "PAY_LIST");
            theEPC3_0020_mod.checkSPR_AMT(QUERY_TYPE, PAY_LIST);

            //����ú�ڬ���
            //Callú�ڬ������@�Ҳ�.����ú�ڬ�����T��k
            Transaction.setXAMode();
            Transaction.begin();
            //�}XAmode,�Ҳդ����ϥΨ�buds,�ѥD�{���ǤJ,transaction.commit��A����
            BatchUpdateDataSet budsC101 = Transaction.getBatchUpdateDataSet();
            try {
                log.debug("%%%%% EPC3_0020.doCancelConfirm:start==>" + DATE.currentTime());
                new EP_C30020().cancelPayInfo(payInfoMap, budsC101);
                if ("DTDKG002".equals(QUERY_TYPE)) {
                    String[] TMP_NOs = MapUtils.getString(payInfoMap, "TMP_NO", "").split(",");
                    for (int i = 0; i < TMP_NOs.length; i++) {
                        new EP_C30050().deleteTmpInfo(TMP_NOs[i], SUB_CPY_ID);
                    }
                }
                log.debug("%%%%% EPC3_0020.doCancelConfirm:end==>" + DATE.currentTime());
                Transaction.commit();
            } catch (Exception e) {
                log.debug("Error Log:" + e, e);
                Transaction.rollback();
                throw e;
            } finally {
                if (budsC101 != null) {
                    try {
                        budsC101.close();
                    } catch (Exception e) {
                        log.fatal("budsC101.close ", e);
                        log.fatal("budsC101.isAutoTransaction " + budsC101.isAutoTransaction());
                        log.fatal("budsC101.isOnTranscation " + budsC101.isOnTranscation());
                    }
                }
            }
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC3_0020_MSG_02"));//��������
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00780");//�@�~����
                }
            }
        } catch (Exception e) {
            log.error("�@�~����", e);//�@�~����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00780");//�@�~����
        }

        return resp;
    }

    /**
     * �d��
     * @param PAY_NO
     * @param SOURCE
     * @throws ModuleException 
     */
    private void queryM(String PAY_NO, String QUERY_TYPE, String SUB_CPY_ID) throws ModuleException {
        //���oú�ڬ����ɸ��
        Map payMap = new EP_C30010().queryPayInfoMap(PAY_NO, SUB_CPY_ID);
        logSecurity(payMap);
        resp.addOutputData("payMap", payMap);

        //���oú�O���p��T�M���ú�O�Ȧ���T�M��
        List<Map> rtnList = new ArrayList();
        EP_C30020 theEP_C30020 = new EP_C30020();
        if ("DTEPC301".equals(QUERY_TYPE)) {//("EPC3_0010".equals(SOURCE) || "EPC3_0040".equals(SOURCE)) {
            //Callú�O���p�B�z���@�Ҳ�.���oú�O���p��T�M���k
            rtnList = theEP_C30020.queryRtlInfoList(PAY_NO, SUB_CPY_ID);
        } else if ("DTDKG002".equals(QUERY_TYPE)) {
            //Callú�O���p�B�z���@�Ҳ�.���oú�O�Ȧ���T�M���k
            rtnList = theEP_C30020.queryTmpInfoList(PAY_NO, SUB_CPY_ID);
        }

        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map map : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", map.get("ID"));
            logSecurityMap.put("CUS_NAME", map.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);
        }
        logSecurity(logSecurityList);

        resp.addOutputData("rtnList", rtnList);
    }

    /**
     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }

        if (BigDecimal.class.isInstance(obj)) {
            return (BigDecimal) obj;
        }

        String str = String.valueOf(obj);

        if (StringUtils.isBlank(str)) {
            return BigDecimal.ZERO;
        }

        return new BigDecimal(str);
    }

}