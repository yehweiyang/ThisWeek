package com.cathay.ep.c3.trx;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.hr.WorkDate;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.dk.a0.module.DK_A0Z002;
import com.cathay.ep.c3.module.EP_C30130;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * 
<pre>
Date    Version Description Author
2013/10/17  1.0 Created ����ʹ

UCEPC3_0130_�M����ӽT�{

�{���\�෧�n�����G
    �{���\��    �M����ӽT�{
    �{���W��    EPC3_0130
    �@�~�覡    ONLINE
    ���n����    
        1.  �d�ߡG�d�߱M����Ӹ��
        2.  �T�{�G�T�{�M����Ӹ��
        3.  �����T�{�G�����T�{�M����Ӹ��
    ���s���v    �M��
    �����q���
    �榡���js  �M��
    �h��y�t    �M��
    �h���d��    ������ 
</pre>
 * @author ���t�s
 * @since 2013/12/19
 */

@SuppressWarnings("unchecked")
public class EPC3_0130 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0130.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            String SUB_CPY_ID = "";
            try {
                SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
                resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            } catch (Exception e) {
                log.error("���o�����q�O����", e);
                MessageUtil.setErrorMsg(msg, "EPC3_0130_MSG_013");//���o�����q�O����
            }
            resp.addOutputData("userID", user.getEmpID());
            resp.addOutputData("userName", user.getEmpName());
            resp.addOutputData("CFM_TYPE", FieldOptionList.getFieldOptions("EPC3", "CFM_TYPE_EPC30130"));
            //���o�e�@�u�@��
            String PREV_WORK_DATE = DATE.addDate(DATE.getDBDate(), 0, 0, -1);
            while (!WorkDate.isWorkingDay(Date.valueOf(PREV_WORK_DATE))) {
                PREV_WORK_DATE = DATE.addDate(PREV_WORK_DATE, 0, 0, -1);
            }
            resp.addOutputData("PREV_WORK_DATE", DATE.toROCDate(PREV_WORK_DATE));

            //���o�b��²�٤U�Կ��]�w��
            resp.addOutputData("ACNT_INFO_LIST", new DK_A0Z002().getAcntCodeList2("DCB", "98", "", new ReturnMessage()));
            //�O�_���|�p�P�b
            resp.addOutputData("ACC_CHECK_LIST", FieldOptionList.getFieldOptions("EP", "ACC_CHECK"));
        } catch (Exception e) {
            log.error("", e);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPC3_0130_MSG_001"); //���o�U�Կ�楢��
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            //����פJ�Y�ɤJ�����s�O�_�i�H�I��
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            Date RMT_DATE_S = Date.valueOf(MapUtils.getString(reqMap, "RMT_DATE_S"));
            Date RMT_DATE_E = Date.valueOf(MapUtils.getString(reqMap, "RMT_DATE_E"));

            //���o����̫�@�u�@��
            String LEST_WORK_DATE = DATE.getMonthLastDate(); //�H���Ѫ��������Ǧ^�Ƿ���̫�@�� 
            while (!WorkDate.isWorkingDay(Date.valueOf(LEST_WORK_DATE))) {
                LEST_WORK_DATE = DATE.addDate(LEST_WORK_DATE, 0, 0, -1);
            }

            //�C��̫�@�u�@��, �~�i�פJ�Y�ɤJ��
            Date WORK_DATE = Date.valueOf(LEST_WORK_DATE);
            String IMPORT_BANK_DATE = FieldOptionList.getName("EPC3", "IMPORT_BANK_DATE", DATE.getDBDate());

            if ((DATE.isSameDate(WORK_DATE, DATE.today()) || StringUtils.isNotBlank(IMPORT_BANK_DATE))
                    && (DATE.isSameDate(WORK_DATE, RMT_DATE_S) || StringUtils.contains(IMPORT_BANK_DATE, MapUtils.getString(reqMap,
                        "RMT_DATE_S"))) && DATE.isSameDate(RMT_DATE_S, RMT_DATE_E)) {
                resp.addOutputData("isImportBankData", "Y");
            } else {
                resp.addOutputData("isImportBankData", "N");
            }

            query(reqMap, new EP_C30130());

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �����T�{
     * @param req
     * @return
     */
    public ResponseContext doCancel(RequestContext req) {
        try {
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            //�ˮ֬O�_�w����ú���αb�ȽT�{
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
             
            EP_C30130 theEP_C30130 = new EP_C30130();
            Transaction.begin();
            try {
                new EP_C30130().doCancelConfirm(reqList, MapUtils.getString(reqMap, "SUB_CPY_ID"));
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0130_MSG_002"); //�����T�{����

            try {
                query(reqMap, theEP_C30130);
            } catch (DataNotFoundException e) {
                log.error("�����T�{���������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0130_MSG_003"); //�����T�{����
            }
        } catch (Exception e) {
            log.error("�����T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0130_MSG_003");//�����T�{����
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {

        try {
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            EP_C30130 theEP_C30130 = new EP_C30130();
            Transaction.begin();
            try {
                theEP_C30130.doConfirm(reqList, dataMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0130_MSG_004"); //�T�{����

            try {
                query(VOTool.jsonToMap(req.getParameter("reqMap")), theEP_C30130);
            } catch (DataNotFoundException e) {
                log.error("�T�{���������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0130_MSG_005"); //�T�{����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0130_MSG_005"); //�T�{����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {

        try {
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            //�ˮ֬O�_�w����ú���αb�ȽT�{
            Map reqMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            EP_C30130 theEP_C30130 = new EP_C30130();

            Transaction.begin();
            try {
                new EP_C30130().doConfirm(reqList, reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0130_MSG_006"); //�ק粒��

            try {
                query(VOTool.jsonToMap(req.getParameter("reqMap")), theEP_C30130);
            } catch (DataNotFoundException e) {
                log.error("�T�{���������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0130_MSG_007"); //�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0130_MSG_007"); //�ק異��
        }

        return resp;
    }

    /**
     * �פJ�M��Y�ɤJ�����
     * @param req
     * @return
     */
    public ResponseContext doImport(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String ACNT_INFO = MapUtils.getString(reqMap, "ACNT_INFO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            String[] strs = ACNT_INFO.split(",");
            String BANK_NO = strs[0];
            String ACNT_NO = strs[1];

            EP_C30130 theEP_C30130 = new EP_C30130();

            Transaction.setXAMode();
            Transaction.begin();
            try {
                theEP_C30130.inserDTEPC307(BANK_NO, ACNT_NO, SUB_CPY_ID); //�ӷ���DTDCB063�Ȧ榬��Y�ɤJ���ɸ��
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPC3_0130_MSG_011"); //�פJ�Y�ɤJ������

            try {
                query(reqMap, theEP_C30130);
            } catch (DataNotFoundException e) {
                log.error("�פJ�Y�ɤJ�����������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0130_MSG_012"); //�פJ�Y�ɤJ������
            }
        } catch (Exception e) {
            log.error("�פJ�Y�ɤJ������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0130_MSG_012"); //�פJ�Y�ɤJ������
        }

        return resp;
    }

    /**
     * �ֿn�s�J���B
     * @param req
     * @return
     */
    public ResponseContext doSumAMOUNT(RequestContext req) {
        try {
            List<Map> rtnList = VOTool.jsonAryToMaps(req.getParameter("rtnList"));

            BigDecimal AMOUNT = BigDecimal.ZERO;
            for (Map map : rtnList) {
                AMOUNT = AMOUNT.add(getDecimal(map.get("AMOUNT")));
            }
            resp.addOutputData("SUM_AMOUNT", AMOUNT);

        } catch (Exception e) {
            log.error("�p���`�X����", e);
            resp.addOutputData("SUM_AMOUNT", "");
        }

        return resp;

    }

    /**
     * ��@�d��
     * @param reqMap
     * @param theEP_C30130
     * @throws Exception
     */
    private void query(Map reqMap, EP_C30130 theEP_C30130) throws Exception {

        List<Map> rtnList = theEP_C30130.doQuery(reqMap);

        //logSecurity
        logSecurity(rtnList);

        BigDecimal TOT_AMOUNT = BigDecimal.ZERO;
        for (Map rtnMap : rtnList) {
            TOT_AMOUNT = TOT_AMOUNT.add(getDecimal(rtnMap.get("AMOUNT")));
        }

        Map TOT_MAP = new HashMap();
        TOT_MAP.put("MEMO1", MessageUtil.getMessage("EPC3_0130_MSG_008"));//"�X�p����:"
        TOT_MAP.put("MEMO2", rtnList.size() + MessageUtil.getMessage("EPC3_0130_MSG_009"));//��
        TOT_MAP.put("TX_TIME", MessageUtil.getMessage("EPC3_0130_MSG_010"));//"�X�p���B:"
        TOT_MAP.put("AMOUNT", TOT_AMOUNT);

        resp.addOutputData("rtnList", rtnList);
        resp.addOutputData("TOT_MAP", TOT_MAP);
    }

    /**
     * �ഫBigDecimal�榡
     * 
     * @param obj
     *            �ǤJ����
     * @return
     */
    private BigDecimal getDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }
        if (BigDecimal.class.isInstance(obj)) {
            return (BigDecimal) obj;
        }
        return new BigDecimal(String.valueOf(obj));
    }

}
