package com.cathay.ep.c3.trx;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.c3.module.EP_C30010;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Version Description Author
 * 2013/08/12  1.0     Created     ������
 * 
 * �{���\�෧�n�����G
 * �{���\��    ú�ڳB�z�@�~
 * �{���W��    EPC3_0010
 * �@�~�覡    ONLINE
 * ���n����    1.  �d�ߡG�d�ߥ�ú�ڰO���A�Τwú�ڸ��
 *             2.  ú�O���p�G�e���ɦ�ú�O���p�B�z�@�~
 * ���s���v    �M��
 * �����q����榡���js  �M��
 * �h��y�t    �M��
 * �h���d��    ������
 *</pre>
 * @author ���_��
 * @since 2013/12/24
 */
@SuppressWarnings("unchecked")
public class EPC3_0010 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0010.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     * @throws Exception 
     * @throws UnsupportedEncodingException 
     */
    public ResponseContext doPrompt(RequestContext req) {

        //����
        VOTool.setParamsFromLP_JSON(req);
        //�ӷ�����
        resp.addOutputData("LINK_FROM", req.getParameter("LINK_FROM"));
        resp.addOutputData("ACTION_TYPE", req.getParameter("ACTION_TYPE"));
        resp.addOutputData("SOURCE", req.getParameter("SOURCE"));
        //ú�O�s��
        resp.addOutputData("PAY_NO", req.getParameter("PAY_NO"));
        //ú�ڲM��
        resp.addOutputData("PAY_LIST", req.getParameter("PAY_LIST"));
        resp.addOutputData("NOWym", DATE.getTodayYearAndMonth());
        resp.addOutputData("SYS_DATE", DATE.getDBDate());
        resp.addOutputData("CURRENT_YM", DATE.getTodayYearAndMonth());
        
        try {

            //���o�d�ߺ����U�Կ��
            resp.addOutputData("QUERY_KINDList", FieldOptionList.getName("EPC3", "QUERY_KIND"));
            //���oú�ڤ覡�U�Կ��
            resp.addOutputData("PAY_TYPEList", FieldOptionList.getName("EPC3", "PAY_TYPE"));
            //ú�ڤ覡
            resp.addOutputData("PAY_KINDList", FieldOptionList.getName("EPC", "PAY_KIND_EPC30010"));
        } catch (Exception e) {
            log.error("�U�Կ����o����", e);
        }

        String SUB_CPY_ID = "";
        try {
            EP_Z00030 theEP_Z00030 = new EP_Z00030();
            SUB_CPY_ID = theEP_Z00030.getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            resp.addOutputData("isAccountSubCpy", theEP_Z00030.isAccountSubCpy(SUB_CPY_ID));
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPC3_0010_ERRMSG_001");//���o�����q�O����
        }
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {

            this.queryM(VOTool.jsonToMap(req.getParameter("reqMap")));
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("MEP00002"));//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            Throwable re = me.getRootException();
            if (re == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (re instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else if (re instanceof DataNotFoundException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, me.getMessage());//�d�L���
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00780");//�@�~����
                }
            }
        } catch (Exception e) {
            log.error("�@�~����", e);//�@�~����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00780");//�@�~����
        }

        return resp;
    }

    /**
     * ú�O���p
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            resp.addOutputData("PAY_MAP", reqMap);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00780");//�@�~����
                }
            }
        } catch (Exception e) {
            log.error("�@�~����", e);//�@�~����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00780");//�@�~����
        }

        return resp;
    }

    /**
     * ���o�j�ӦW��
     * @param req
     * @return
     */
    public ResponseContext doGetBldName(RequestContext req) {
        try {

            Map reqMap = new HashMap();

            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_CD", req.getParameter("BLD_CD"));

            String BLD_NAME = (String) new EP_A10010().queryMap(reqMap).get("BLD_NAME");

            resp.addOutputData("BLD_NAME", BLD_NAME);

        } catch (Exception e) {
            log.error("���o���o�j�ӦW�٥���", e);
            resp.addOutputData("BLD_NAME", "");
        }
        return resp;
    }

    /**
     * ���o�Ȥ�W��
     * @param req
     * @return
     */
    public ResponseContext doGetCusName(RequestContext req) {
        try {

            Map reqMap = new HashMap();

            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("CUS_NO", req.getParameter("CUS_NO"));
            reqMap.put("CRT_NO", req.getParameter("CRT_NO"));
            String CUS_NAME = (String) new EP_B10020().queryTenentList(reqMap).get(0).get("CUS_NAME");

            resp.addOutputData("CUS_NAME", CUS_NAME);

        } catch (Exception e) {
            log.error("���o�Ȥ�W�٥���", e);
            resp.addOutputData("CUS_NAME", "");
        }
        return resp;
    }

    /**
     * �d��
     * @param PAY_NO
     * @throws ModuleException 
     * @throws SQLException 
     */
    private void queryM(Map reqMap) throws ModuleException, SQLException {

        List<Map> rtnList = null;

        if ("0".equals(MapUtils.getString(reqMap, "QUERY_KIND"))) {

            //Callú�ڳB�z�@�~���@�Ҳ�.���o���������M���k
            rtnList = new EP_C30010().queryRcvInfoList(reqMap);
        } else {
            //ú�ڳB�z�@�~���@�Ҳ�.���oú�ڬ����M���k
            rtnList = new EP_C30010().queryPayInfoList(reqMap);

        }

        BigDecimal TSPR_AMT = BigDecimal.ZERO;
        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map map : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", map.get("ID"));
            logSecurityMap.put("CUS_NAME", map.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);

            TSPR_AMT = TSPR_AMT.add(getDecimal(map.get("SPR_AMT")));
        }
        logSecurity(logSecurityList);

        resp.addOutputData("TSPR_AMT", TSPR_AMT);

        resp.addOutputData("rtnList", rtnList);
    }

    /**
     * �p���ú���B�`�M
     * @param req
     * @return
     */
    public ResponseContext doSumPAY_AMT(RequestContext req) {
        try {
            List<Map> rtnList = VOTool.jsonAryToMaps(req.getParameter("rtnList"));

            BigDecimal PAY_AMT = BigDecimal.ZERO;
            for (Map map : rtnList) {
                PAY_AMT = PAY_AMT.add(getDecimal(map.get("PAY_AMT")));
            }
            resp.addOutputData("SUM_PAY_AMT", PAY_AMT);

        } catch (Exception e) {
            log.error("�p���`�X����", e);
            resp.addOutputData("SUM_PAY_AMT", "");
        }

        return resp;

    }

    /**
     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }

        if (BigDecimal.class.isInstance(obj)) {
            return (BigDecimal) obj;
        }

        String str = String.valueOf(obj);

        if (StringUtils.isBlank(str)) {
            return BigDecimal.ZERO;
        }

        return new BigDecimal(str);
    }

}