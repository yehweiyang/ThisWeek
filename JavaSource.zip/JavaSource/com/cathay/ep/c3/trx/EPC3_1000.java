package com.cathay.ep.c3.trx;

import java.io.IOException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.hr.WorkDate;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.c3.module.EP_C31000;
import com.cathay.util.ControlMCaller;
import com.cathay.util.FileStoreUtil;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.cathay.zz.x0.module.ZZ_X0Z004;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.common.util.annotation.CallMethod;
import com.igsapp.common.util.annotation.TxBean;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 *  Date         Description Author  �߮׳�
 *  2019/04/24   �s�W     ������   190418000735
 *
 *�{���\��    ���~����@�~
 *�{���W��    EPC3_1000
 *�@�~�覡    ONLINE
 *���n����     (1) ��l �w �̾ڶǤJ�Ѽ���ܧ@�~�e��
 *       (2) �s�W �w ���s�W���~�էO����]�w
 *       (3) �T�{ �w ���T�{���~�էO����]�w
 *       (4) �ק� �w �浧�ק囹�~�էO����]�w
 *       (5) �d�� �w �d�ߦ��~�էO����]�w
 *       (6) �W�� �w �W�Ǧ��~�Ƶ{���A���ͦ��~�էO����]�w
 *       (7) ���~�ɩ� �w���~���A�ݬ����B�z�A�~��u�W����妸�A�i�榩�~���@�~
 *�ݨD���    ���ʲ���곡���ʲ��޲z�G��
 *�@�~���    ����T����ڸ�T��
 *�@�~���x    ���@��  �����O�q��  �����
 *�Ӹ�B��    �e��       ���L ���B�� ��securitylog
 *           �����C�L    ���L ���B�� ��securitylog
 *           �ɮפU��    ���L ���B�� ��securitylog
 *�����B�z   ���L ���u�������������A�����C��___���iDefaul 20�j
 *�H�H�B�z    �H�H��H    ���L ���Ȥ�@�����I���u�@�����Y���~���u�@���X�@�t��
 *���s���v   �L
 * </pre>
 *
 * @author ��üy
 * @since 2019-05-07
 */
@TxBean
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC3_1000 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_1000.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);
        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);
        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode(CallMethod.CODE_SUCCESS);
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    @CallMethod(action = "prompt", url = "/EP/C3/EPC3_1000/EPC31000.jsp")
    public ResponseContext doPrompt(RequestContext req) {
        try {
            //�u���~�էO�v�U�Կ��
            Map PAY_GRPList = FieldOptionList.getName("EP", "PAY_GRP");
            resp.addOutputData("PAY_GRPList", PAY_GRPList);
            DateFormat sdf = new SimpleDateFormat("yyyy");
            String DATA_YEAR = sdf.format(DATE.today());
            resp.addOutputData("DATA_YEAR", DATA_YEAR);

            resp.addOutputData("userDivNo", user.getDivNo());
        } catch (Exception e) {
            log.error("�d�ߤU�Կ�楢��", e);
            MessageUtil.getMessage("EPC3_1000_ERRMSG_001");//�d�ߤU�Կ�楢�� 
        }
        return resp;
    }

    /**
     * doQuery �d��
     * @param req
     * @return
     */
    @CallMethod(action = "query", type = CallMethod.TYPE_AJAX)
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            this.query(reqMap, "MEP00002", true); //�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001"); //�d�L���            
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�d�ߥ���", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028"); //�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003"); //�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003"); //�d�ߥ���
        }
        return resp;
    }

    /**
     * �פJ
     * @param req
     * @return
     */
    @CallMethod(action = "import", type = CallMethod.TYPE_NA)
    public ResponseContext doImport(RequestContext req) {
        try {

            //���o�W���ɮ�
            FileItem fileItem = FileStoreUtil.parseUploadStream(req); // �פJ�ɮ�
            Map reqMap = new HashMap();
            reqMap.put("PAY_GRP", req.getParameter("PAY_GRP"));
            reqMap.put("DATA_YEAR", Integer.parseInt(req.getParameter("DATA_YEAR")) + 1911);
            reqMap.put("DATA_YEAR_ROC", req.getParameter("DATA_YEAR"));
            boolean isPass = this.chkXLSX(reqMap, fileItem);
            if (isPass) {
                List<Map> rtnList = new EP_C31000().parseUploadXlsx(reqMap, fileItem);
                resp.addOutputData("rtnList", rtnList);
                MessageUtil.setMsg(msg, "EPC3_1000_ERRMSG_002");//�W�ǧ���,�нT�{
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�W�ǥ���", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_1000_ERRMSG_003");//�W�ǥ���
            }
        } catch (Exception e) {
            log.error("�W�ǥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_1000_ERRMSG_003");//�W�ǥ���
        } finally {
            this.send2iframe(req);
        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    @CallMethod(action = "insert", type = CallMethod.TYPE_AJAX)
    public ResponseContext doInsert(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> dataList = VOTool.jsonAryToMaps(req.getParameter("dataList"));
            String PAY_GRP = MapUtils.getString(reqMap, "PAY_GRP");

            int iMonCnt = Integer.parseInt(FieldOptionList.getName("EP", "PAY_GRP_MM", PAY_GRP));
            if (iMonCnt != dataList.size()) {
                throw new ModuleException(MessageUtil.getMessage("EPC3_1000_ERRMSG_008", new Object[] { iMonCnt }));//�ӲէO�����~��Ƴ]�w���~�A����{0}��
            }
            StringBuilder errMsg = new StringBuilder();

            for (Map dataMap : dataList) {
                String strDATA_DATE = MapUtils.getString(dataMap, "DATA_DATE");
                if (!DATE.isDate(strDATA_DATE)) {
                    throw new ModuleException("EPC3_1000_UI_DATA_DATE_MUSTDATE");
                }
                Date DATA_DATE = Date.valueOf(strDATA_DATE);

                if (!WorkDate.isWorkingDay(DATA_DATE)) {
                    errMsg.append(MessageUtil.getMessage("EPC3_1000_ERRMSG_009", new Object[] { dataMap.get("SLRY_YYMM_ROC") }));//���~�~��{0}����D�u�@��
                }
            }
            String ERR_MSG = errMsg.toString();
            if (StringUtils.isNotBlank(ERR_MSG)) {
                throw new ModuleException(ERR_MSG);
            }
            EP_C31000 theEP_C31000 = new EP_C31000();
            try {
                List<Map> rtnList = theEP_C31000.queryList(reqMap);
                if (rtnList.size() > 0) {
                    throw new ModuleException("EPC3_1000_ERRMSG_011");//�ӲէO���~�~�׸�Ƥw�s�b�A���i�s�W
                }
            } catch (DataNotFoundException dnfe) {
                log.debug("�d�L��Ƶ������`", dnfe);
            }

            Transaction.begin();
            try {
                theEP_C31000.insert(reqMap, dataList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            this.query(reqMap, "EPC3_1000_ERRMSG_012", false);//�s�W����
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�s�W����", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_1000_ERRMSG_013");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_1000_ERRMSG_013");//�s�W����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    @CallMethod(action = "update", type = CallMethod.TYPE_AJAX)
    public ResponseContext doUpdate(RequestContext req) {

        try {
            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            EP_C31000 theEP_C31000 = new EP_C31000();
            Map qryMap = theEP_C31000.queryMap(dataMap);

            if (!"1".equals(MapUtils.getString(qryMap, "SLRY_CTL_STS"))) {
                throw new ModuleException(MessageUtil.getMessage("EPC3_1000_ERRMSG_014"));//���~����A�D�s�W�]�w�A���i�ק�
            }
            String strDATA_DATE = MapUtils.getString(dataMap, "DATA_DATE");

            if (!DATE.isDate(strDATA_DATE)) {
                throw new ModuleException("EPC3_1000_UI_DATA_DATE_MUSTDATE");
            }
            Date DATA_DATE = Date.valueOf(strDATA_DATE);
            //�ˮ֩���O�_���u�@��
            if (!WorkDate.isWorkingDay(DATA_DATE)) {
                throw new ModuleException(MessageUtil.getMessage("EPC3_1000_ERRMSG_010"));//����D�u�@��    
            }

            Transaction.begin();
            try {
                theEP_C31000.update(dataMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            this.query(reqMap, "EPC3_1000_ERRMSG_015", false);//�ק粒��
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�ק異��", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_1000_ERRMSG_016");//�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_1000_ERRMSG_016");//�ק異��
        }

        return resp;
    }

    /**
     * ���~�ɩ�
     * @param req
     * @return
     */
    @CallMethod(action = "select", type = CallMethod.TYPE_AJAX)
    public ResponseContext doSelect(RequestContext req) {

        try {
            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));

            boolean isrunning = new ZZ_X0Z004("EPC3_B110").isRunning(new ReturnMessage());

            if (isrunning) {
                throw new ModuleException("EPC3_1000_ERRMSG_018");//�妸���b���椤�A���i���ƴ���!     
            }
            EP_C31000 theEP_C31000 = new EP_C31000();
            Map qryMap = theEP_C31000.queryMap(dataMap);

            if (!"3".equals(MapUtils.getString(qryMap, "SLRY_CTL_STS"))) {
                throw new ModuleException("EPC3_1000_ERRMSG_019");//���~����A�D���B�z�A���i���~�ɩ�
            }
            //�u�W����妸���~���Ƶ{
            ControlMCaller aControlMCaller = new ControlMCaller(true);
            String[] batchArgs = new String[] { MapUtils.getString(dataMap, "PAY_GRP"), MapUtils.getString(dataMap, "SLRY_YYMM") };
            aControlMCaller.runBatch("EPC3_B110", null, batchArgs, true);

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            this.query(reqMap, "EPC3_1000_ERRMSG_017", false);//�妸���槹��
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("���~�ɩ⥢��", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_1000_ERRMSG_020");//�妸���楢��
            }
        } catch (Exception e) {
            log.error("���~�ɩ⥢��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_1000_ERRMSG_020");//�妸���楢��
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    @CallMethod(action = "confirm", type = CallMethod.TYPE_AJAX)
    public ResponseContext doConfirm(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> dataList = VOTool.jsonAryToMaps(req.getParameter("dataList"));

            EP_C31000 theEP_C31000 = new EP_C31000();
            List<Map> rtnList = theEP_C31000.queryList(reqMap);
            for (Map rtnMap : rtnList) {
                if (!"1".equals(MapUtils.getString(rtnMap, "SLRY_CTL_STS"))) {
                    throw new ModuleException("EPC3_1000_ERRMSG_023");//���~�����ƫD�s�W�]�w�A���i�T�{ 
                }
            }
            Transaction.begin();
            try {
                theEP_C31000.confirm(dataList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            this.query(reqMap, "EPC3_1000_ERRMSG_021", false);//�T�{����
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�T�{����", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_1000_ERRMSG_022");//�T�{����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_1000_ERRMSG_022");//�T�{����
        }

        return resp;
    }

    /**
     * �d��
     * @param reqMap
     * @throws ModuleException
     */
    private void query(Map reqMap, String actionSuccessMsg, boolean isDoQuery) throws ModuleException {

        try {
            List<Map> rtnList = new EP_C31000().queryList(reqMap);
            resp.addOutputData("rtnList", rtnList);
            MessageUtil.setMsg(msg, actionSuccessMsg);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            Map mapConfig = FieldOptionList.getName("EP", "SLRY_XLSX_" + MapUtils.getString(reqMap, "PAY_GRP"));
            int FILE_MB_SIZE = MapUtils.getIntValue(mapConfig, "FILE_MB_SIZE", 1);
            resp.addOutputData("FILE_MB_SIZE", FILE_MB_SIZE);
            resp.addOutputData("erMsg", MessageUtil.getMessage("EPC3_1000_ERRMSG_024", new Object[] { FILE_MB_SIZE }));
            if (isDoQuery) {
                MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001"); //�d�L���
            } else {
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "MEP00001"); //�d�L���
            }

        }

    }

    /**
     * chkXLSX ����ˮ�
     * @param reqMap
     * @param fileItem
     * @return �� CHK_MSG �ˮ֤��q�L�^��  false
     * @throws ModuleException
     * @throws IOException
     */
    private boolean chkXLSX(Map reqMap, FileItem fileItem) throws ModuleException, IOException {

        Map mapConfig = FieldOptionList.getName("EP", "SLRY_XLSX_" + MapUtils.getString(reqMap, "PAY_GRP"));

        long FILE_SIZE = fileItem.getSize();
        int FILE_MB_SIZE = MapUtils.getIntValue(mapConfig, "FILE_MB_SIZE", 1);

        if (FILE_SIZE > FILE_MB_SIZE * 1048576) {
            throw new ModuleException(MessageUtil.getMessage("EPC3_1000_ERRMSG_024", new Object[] { FILE_MB_SIZE }));//�W���ɮפ��i�W�L{0}MB
        }

        //Ū���Ƶ{���u�@��
        Workbook wb = new XSSFWorkbook(fileItem.getInputStream());
        Sheet sheet = wb.getSheetAt(MapUtils.getIntValue(mapConfig, "SHEET"));
        Row headRow0 = sheet.getRow(0);
        Row headRow = sheet.getRow(MapUtils.getIntValue(mapConfig, "HEAD_ROW"));

        String HEAD_ROW = headRow0.getCell(0).getStringCellValue();
        String DATA_YEAR_ROC = MapUtils.getString(reqMap, "DATA_YEAR_ROC");
        StringBuilder sb = new StringBuilder();

        if (!HEAD_ROW.startsWith(DATA_YEAR_ROC)) {
            sb.append(MessageUtil.getMessage("EPC3_1000_ERRMSG_004"));//A1���}�Y�D���~�~��
        }
        String SLRYM_COL = headRow.getCell(MapUtils.getIntValue(mapConfig, "SLRYM_COL")).getStringCellValue();
        String SLRYM_HEAD = MapUtils.getString(mapConfig, "SLRYM_HEAD");
        if (!SLRYM_COL.startsWith(SLRYM_HEAD)) {
            sb.append(MessageUtil.getMessage("EPC3_1000_ERRMSG_005"));//���}�Y�D�~�Եo�~
        }
        String PASS_COL = headRow.getCell(MapUtils.getIntValue(mapConfig, "PASS_COL")).getStringCellValue();
        String PASS_HEAD = MapUtils.getString(mapConfig, "PASS_HEAD");
        if (!PASS_COL.startsWith(PASS_HEAD)) {
            sb.append(MessageUtil.getMessage("EPC3_1000_ERRMSG_006"));//���}�Y�D���~��
        }
        String PAY_COL = headRow.getCell(MapUtils.getIntValue(mapConfig, "PAY_COL")).getStringCellValue();
        String PAY_HEAD = MapUtils.getString(mapConfig, "PAY_HEAD");
        if (!PAY_COL.startsWith(PAY_HEAD)) {
            sb.append(MessageUtil.getMessage("EPC3_1000_ERRMSG_007"));//���}�Y�D�o�~��
        }
        String CHK_MSG = sb.toString();
        if (StringUtils.isNotBlank(CHK_MSG)) {
            resp.addOutputData("CHK_MSG", CHK_MSG);
            return false;
        }
        return true;

    }

    /**
     * �N����নhtml�榡�^�Ǧܵe���W��iframe
     * @param req
     * @throws Exception
     */
    private void send2iframe(RequestContext req) {
        try {
            //---------- �n�^�Ǫ����(start) ----------
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("rtnList", resp.getOutputData("rtnList"));
            if (resp.getOutputData("CHK_MSG") != null) {
                map.put("CHK_MSG", resp.getOutputData("CHK_MSG"));
            }
            map.put(IConstantMap.ErrMsg, msg);

            //---------- �n�^�Ǫ����(end) ----------

            // ��html
            EncodingHelper.send2iframe(req, map, msg);

        } catch (Exception e) {
            log.error(e, e);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, e.getMessage());
        }
    }
}
