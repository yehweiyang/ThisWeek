package com.cathay.ep.c3.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.c3.module.EP_C30140;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * 
<pre>
Date    Version Description Author
2013/11/12  1.0 Created ������

UCEPC3_0140_�wú�䲼�I�{�T�{

�{���\�෧�n�����G
    �{���\��    �wú�䲼�I�{�T�{
    �{���W��    EPC3_0140
    �@�~�覡    ONLINE
    ���n����    
        1.  �d�ߡG�d�ߥ��T�{�Ȧ��O���A�Τw�T�{�Ȧ���ơC
        2.  �T�{�G�N�w�I�{���䲼�Ȧ��A�P����������p�C
        3.  �����T�{�G�N�w�I�{���䲼�Ȧ��A�P������ƨ������p�C
���s���v    �M��
�����q���
�榡���js  �M��
�h��y�t    �M��
�h���d��    ������                                
</pre>
 * @author ���t�s
 * @since 2013/12/24
 */

@SuppressWarnings("unchecked")
public class EPC3_0140 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0140.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC3_0140_MSG_004");//���o�����q�O����
        }
        try {
            resp.addOutputData("CFM_TYPE", FieldOptionList.getFieldOptions("EPC3", "CFM_TYPE"));
        } catch (Exception e) {
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPC3_0140_MSG_001"); //���o�U�Կ�楢��
        }

        resp.addOutputData("CURRENT_YM", DATE.getTodayYearAndMonth()); //2019-01-30�W�[�D�����~����뤣�o�T�{���ˮ�
        
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            List<Map> rtnList = new EP_C30140().queryMatchList(req.getParameter("COA_DATE_S"), req.getParameter("COA_DATE_E"), req
                    .getParameter("CFM_DATE"), user.getOpUnit(), req.getParameter("SUB_CPY_ID"));
            countAMT(rtnList);
            resp.addOutputData("rtnList", rtnList);

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {
        try {
            Transaction.setXAMode();
            Transaction.begin();
            //�}XAmode,�Ҳդ����ϥΨ�buds,�ѥD�{���ǤJ,transaction.commit��A����
            //budsArray = [C101,C301,C302,C303,C307]
            BatchUpdateDataSet budsC101 = Transaction.getBatchUpdateDataSet();
            BatchUpdateDataSet budsC301 = new com.cathay.db.impl.BatchUpdateDataSet();
            budsC301.setDataSet(budsC101);
            BatchUpdateDataSet[] budsArray = new BatchUpdateDataSet[] { budsC101, budsC301, null, null, null };
            try {
                //����k�u�|�ϥΨ�C101�PC301
                new EP_C30140().doConfirm(VOTool.jsonAryToMaps(req.getParameter("MATCH_LIST")), user, budsArray, req
                        .getParameter("SUB_CPY_ID"));
                Transaction.commit();
            } catch (Exception e) {
                log.error("�T�{����", e);
                Transaction.rollback();
                throw e;
            } finally {
                if (budsC101 != null) {
                    try {
                        budsC101.close();
                    } catch (Exception e) {
                        log.fatal("budsC101.close ", e);
                        log.fatal("budsC101.isAutoTransaction " + budsC101.isAutoTransaction());
                        log.fatal("budsC101.isOnTranscation " + budsC101.isOnTranscation());
                    }
                }
                if (budsC301 != null) {
                    try {
                        budsC301.close();
                    } catch (Exception e) {
                    }
                }
            }

            MessageUtil.setMsg(msg, "EPC3_0140_MSG_002"); // �T�{����
            String CFM_DATE = DATE.getDBDate();
            resp.addOutputData("CFM_DATE", CFM_DATE);
            List<Map> rtnList = null;
            try {
                rtnList = new EP_C30140().queryMatchList(null, null, CFM_DATE, user.getOpUnit(), req.getParameter("SUB_CPY_ID"));
                countAMT(rtnList);
                resp.addOutputData("rtnList", rtnList);

            } catch (DataNotFoundException e) {
                log.error("�T�{�������d�L���", e);
            }

            countAMT(rtnList);

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0140_MSG_003"); //�T�{����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0140_MSG_003"); //�T�{����
        }

        return resp;
    }

    /**
     * Map���XBigDecimal
     * @param map
     * @param key
     * @param defaultValue
     * @return
     */
    private BigDecimal objToBig(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }

    /**
     * ���B�[�`
     * @param rtnList
     */
    private void countAMT(List<Map> rtnList) {
        BigDecimal Count_ACNT_AMT = BigDecimal.ZERO;
        BigDecimal Count_SPR_AMT = BigDecimal.ZERO;
        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map map : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("CST_NAME", map.get("CST_NAME"));
            logSecurityMap.put("ID", map.get("ID"));
            logSecurityList.add(logSecurityMap);

            Count_ACNT_AMT = Count_ACNT_AMT.add(objToBig(map, "ACNT_AMT", BigDecimal.ZERO));
            Count_SPR_AMT = Count_SPR_AMT.add(objToBig(map, "SPR_AMT", BigDecimal.ZERO));
        }
        logSecurity(logSecurityList);
        resp.addOutputData("Count_ACNT_AMT", Count_ACNT_AMT);
        resp.addOutputData("Count_SPR_AMT", Count_SPR_AMT);
    }
}
