package com.cathay.ep.c3.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.c3.module.EP_C32020;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * 
<pre>
Date    Version Description Author
2013/08/30  1.0 Created ����ʹ

�{���\�෧�n�����G
    �{���\��    ú�ڬ����d��
    �{���W��    EPC3_2020.java
    �@�~�覡    ONLINE
    ���n����    (1) �d��ú�ڬ���
    ���s���v    
</pre>
 * @author ���t�s
 * @since 2014/1/3
 */
@SuppressWarnings("unchecked")
public class EPC3_2020 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_2020.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        VOTool.setParamsFromLP_JSON(req);
        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC3_2020_ERRMSG_001");//���o�����q�O����
        }
        String INPUT_ID = req.getParameter("INPUT_ID");
        resp.addOutputData("QUERY_KIND", req.getParameter("QUERY_KIND"));
        resp.addOutputData("ACNT_DIV_NO", req.getParameter("ACNT_DIV_NO"));
        resp.addOutputData("INPUT_ID", INPUT_ID);
        if (StringUtils.isNotBlank(INPUT_ID)) {
            try {
                resp.addOutputData("INPUT_NAME", new PersonnelData().getByEmployeeID4Name(INPUT_ID, true));
            } catch (Exception e) {
                log.error("���o�m�W����", e);
            }
        }
        resp.addOutputData("ACNT_DATE", req.getParameter("ACNT_DATE"));
        resp.addOutputData("PAY_NOs", req.getParameter("PAY_NOs"));
        resp.addOutputData("CHK_SET_NOs", req.getParameter("CHK_SET_NOs"));
        resp.addOutputData("RMT_SET_NOs", req.getParameter("RMT_SET_NOs"));
        resp.addOutputData("TMP_NOs", req.getParameter("TMP_NOs"));
        resp.addOutputData("DTMP_NOs", req.getParameter("DTMP_NOs"));
        resp.addOutputData("ACNT_SET_NOs", req.getParameter("ACNT_SET_NOs"));

        //���o�U�Կ��
        resp.addOutputData("QUERY_KIND_List", FieldOptionList.getName("EPC", "QUERY_KIND"));
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
            List<Map> rtnList = new EP_C32020().doQuery(reqMap, null, null);
            String[] totColumns;
            if ("0".equals(QUERY_KIND)) {//��������
                totColumns = new String[] { "CHK_AMT" };
            } else if ("1".equals(QUERY_KIND)) {//�״ڳ�
                totColumns = new String[] { "RMT_AMT" };
            } else if ("2".equals(QUERY_KIND)) {//�Ȧ��J�b
                totColumns = new String[] { "ACNT_AMT", "BAL_AMT" };
            } else if ("3".equals(QUERY_KIND)) {//�Ȧ��R�b
                totColumns = new String[] { "DACNT_AMT" };
            } else {//�M��
                totColumns = new String[] { "AMOUNT" };
            }

            //logSecurity
            if ("2".equals(QUERY_KIND) || "3".equals(QUERY_KIND) || "4".equals(QUERY_KIND)) {//�Ȧ��B�M��
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map rtnMap : rtnList) {
                    Map logSecurityMap = new HashMap();
                    if ("2".equals(QUERY_KIND)) {
                        logSecurityMap.put("CST_NAME", rtnMap.get("CST_NAME"));
                    } else if ("3".equals(QUERY_KIND)) {
                        logSecurityMap.put("DACPT_ACNT_NAME", rtnMap.get("DACPT_ACNT_NAME"));
                    } else {
                        logSecurityMap.put("MEMO1", rtnMap.get("MEMO1"));
                    }
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);
            }

            Map<String, BigDecimal> totMap = new HashMap<String, BigDecimal>();
            for (String key : totColumns) {
                totMap.put(key, BigDecimal.ZERO);
            }
            for (Map rtnMap : rtnList) {
                for (String key : totColumns) {
                    totMap.put(key, totMap.get(key).add(objToDec(rtnMap.get(key), BigDecimal.ZERO)));
                }
            }
            for (String key : totColumns) {
                resp.addOutputData("TOT_" + key, totMap.get(key));
            }
            resp.addOutputData("rtnList", rtnList);
            MessageUtil.setMsg(msg, "MI00020");//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            EP_C32020 theEP_C32020 = new EP_C32020();
            List<Map> rtnList = theEP_C32020.doQuery(reqMap, null, null);

            String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
            //logSecurity
            if ("2".equals(QUERY_KIND) || "3".equals(QUERY_KIND)) {//�Ȧ��B�M��
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map rtnMap : rtnList) {
                    Map logSecurityMap = new HashMap();
                    if ("2".equals(QUERY_KIND)) {
                        logSecurityMap.put("CST_NAME", rtnMap.get("CST_NAME"));
                    } else {
                        logSecurityMap.put("DACPT_ACNT_NAME", rtnMap.get("DACPT_ACNT_NAME"));
                    }
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);
            }

            theEP_C32020.print(reqMap, rtnList, user, resp);

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC3_2020_UI_MSG_001"));//�C�L����

            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC3_2020_UI_MSG_001"));//�C�L����
        }

        return resp;
    }

    /**
     * �U��
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("IS_EXPORT_XLS", "Y");
            String exportName = req.getParameter("exportName");
            //�����ɦW :{$exportName}_YYYYMMDD.xls
            reqMap.put("fileName", new StringBuilder(exportName).append("_").append(DATE.toDate_yyyyMMdd(DATE.getDBDate())).toString());
            List<Map> rtnList = new EP_C32020().doQuery(reqMap, user, resp);

            String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
            //logSecurity
            if ("2".equals(QUERY_KIND) || "3".equals(QUERY_KIND) || "4".equals(QUERY_KIND)) {//�Ȧ��B�M��
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map rtnMap : rtnList) {
                    Map logSecurityMap = new HashMap();
                    if ("2".equals(QUERY_KIND)) {
                        logSecurityMap.put("CST_NAME", rtnMap.get("CST_NAME"));
                    } else {
                        logSecurityMap.put("DACPT_ACNT_NAME", rtnMap.get("DACPT_ACNT_NAME"));
                    }
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�U������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC3_2020_UI_054"));//�U������
        }

        return resp;
    }

    /**
     * ��BigDecimal
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal objToDec(Object o, BigDecimal defaultValue) {

        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }

}
