package com.cathay.ep.c3.trx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.c3.module.EPC3_0070_mod;
import com.cathay.ep.c3.module.EP_C30070;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * 
<pre> 
Date    Version Description Author
2013/10/01  1.0 Created ���i��

UCEPC3_0070_ú�O��X�@�~

�@�B  �{���\�෧�n�����G
�{���\��    ú�O��X�@�~
�{���W��    EPC3_0070
�@�~�覡    ONLINE
���n����    
    (1) �d�ߡG �d��ú�O��������X�����C
    (2) �T�{�G �Nú�O��������X�A�ÿ����X�����C
    (3) �����T�{�G�N�w����X��ú�O�����٭즨����X�����A�C
    (4) ��ܡG��ܻݭn�����ʪ���ơA�ñN�ԲӸ�Ʊa�JB����ܡC
    (5) ��X����-�J�Ȧ��G�Ȥ�쥻�o����ú�O�覡�β{���A��ӤϷ|���o����ú����ú�F�A�n��Τ䲼�C
    (6) ��X����-�h�O�G�Ȥ�쥻�w�gú�F�����O�ΡA��ӷQ�h�O�C
    (7) ��X����-�~�b�J�Ȧ��G�Ȥ�ú�F�����O�ΡA�g��o�J�������N���C
�h���d��    ������
</pre>
 * @author ���t�s
 * @since 2013/12/30
 */
@SuppressWarnings("unchecked")
public class EPC3_0070 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0070.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     * @throws ModuleException 
     */
    public ResponseContext doPrompt(RequestContext req) {

        Map QUERY_TYPE = new HashMap();
        QUERY_TYPE.put("0", MessageUtil.getMessage("EPC3_0070_MSG_001")); //ú�O����
        QUERY_TYPE.put("1", MessageUtil.getMessage("EPC3_0070_MSG_002")); //��X����

        Map D_PAY_TYPE = new HashMap();
        D_PAY_TYPE.put("0", MessageUtil.getMessage("EPC3_0070_MSG_003")); //�п��
        D_PAY_TYPE.put("3", MessageUtil.getMessage("EPC3_0070_MSG_004")); //�״�
        D_PAY_TYPE.put("1", MessageUtil.getMessage("EPC3_0070_MSG_005")); //�{��
        D_PAY_TYPE.put("2", MessageUtil.getMessage("EPC3_0070_MSG_006")); //�䲼

        Map PAY_KIND = FieldOptionList.getFieldOptions("EP", "PAY_KIND");
        if (PAY_KIND == null || PAY_KIND.isEmpty()) {
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPC3_0070_MSG_007"); //���oú�ں����U�Կ�楢��
        }
        Map SWP_KIND = FieldOptionList.getFieldOptions("EP", "SWP_KIND2");
        if (SWP_KIND == null || SWP_KIND.isEmpty()) {
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPC3_0070_MSG_008"); //���o��X�����U�Կ�楢��
        }
        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC3_0070_MSG_013");//���o�����q�O����
        }
        resp.addOutputData("QUERY_TYPE", QUERY_TYPE);
        resp.addOutputData("D_PAY_TYPE", D_PAY_TYPE);
        resp.addOutputData("PAY_KIND", PAY_KIND);
        resp.addOutputData("SWP_KIND", SWP_KIND);
        resp.addOutputData("TODAY_ROC", DATE.getDBDate());

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     * @throws ModuleException 
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            EP_C30070 theEP_C30070 = new EP_C30070();
            String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
            String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
            String RCV_YM_S = MapUtils.getString(reqMap, "RCV_YM_S");
            String RCV_YM_E = MapUtils.getString(reqMap, "RCV_YM_E");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            RCV_YM_S = StringUtils.isNotBlank(RCV_YM_S) ? DATE.getY2KYearAndMonth(RCV_YM_S) : "";
            RCV_YM_E = StringUtils.isNotBlank(RCV_YM_E) ? DATE.getY2KYearAndMonth(RCV_YM_E) : "";

            List<Map> dataList = theEP_C30070.query(MapUtils.getString(reqMap, "QUERY_TYPE"), MapUtils.getString(reqMap, "PAY_KIND"),
                CRT_NO, CUS_NO, RCV_YM_S, RCV_YM_E, SUB_CPY_ID);

            logSecurity(dataList);
            resp.addOutputData("dataList", dataList);

            Map dataMap = theEP_C30070.query3(CRT_NO, CUS_NO, SUB_CPY_ID);
            Map dataMap2 = theEP_C30070.query4(CRT_NO, CUS_NO, SUB_CPY_ID);
            if (dataMap != null) {
                resp.addOutputData("IS_NEED_CHECK", "Y"); //�����|����L�����ڶ����M��
            } else {
                resp.addOutputData("IS_NEED_CHECK", "N");
            }
            if (dataMap2 != null) {
                resp.addOutputData("IS_NEED_CHECK2", "Y"); //�����Ȧ��ڶ����h�١A�Ф@�ְh��!!
            } else {
                resp.addOutputData("IS_NEED_CHECK2", "N");
            }
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �d��2
     * @param req
     * @return
     */
    public ResponseContext doQuery2(RequestContext req) {
        try {
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            Map CUST_MAP = new EP_C30070().query2(req.getParameter("CRT_NO"), req.getParameter("CUS_NO"), SUB_CPY_ID);
            logSecurity(CUST_MAP);
            resp.addOutputData("CUST_MAP", CUST_MAP);
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);

            new EPC3_0070_mod().checkInsert(reqMap);
            reqMap.put("USER_ID", user.getEmpID());
            reqMap.put("USER_NAME", user.getUserName());
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            reqMap.put("PAY_AMT", STRING.replace(MapUtils.getString(reqMap, "PAY_AMT"), ",", ""));
            reqMap.put("D_PAY_AMT", STRING.replace(MapUtils.getString(reqMap, "D_PAY_AMT"), ",", ""));
            reqMap.put("D_SWP_AMT", STRING.replace(MapUtils.getString(reqMap, "D_SWP_AMT"), ",", ""));
            Transaction.setXAMode();
            Transaction.begin();
            try {
                new EP_C30070().insert(reqMap);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPC3_0070_MSG_009"); //�T�{����

            try {
                String RCV_YM_S = MapUtils.getString(reqMap, "RCV_YM_S");
                String RCV_YM_E = MapUtils.getString(reqMap, "RCV_YM_E");
                RCV_YM_S = StringUtils.isNotBlank(RCV_YM_S) ? DATE.getY2KYearAndMonth(RCV_YM_S) : "";
                RCV_YM_E = StringUtils.isNotBlank(RCV_YM_E) ? DATE.getY2KYearAndMonth(RCV_YM_E) : "";

                List<Map> dataList = new EP_C30070().query(MapUtils.getString(reqMap, "QUERY_TYPE"),
                    MapUtils.getString(reqMap, "PAY_KIND"), MapUtils.getString(reqMap, "CRT_NO"), MapUtils.getString(reqMap, "CUS_NO"),
                    RCV_YM_S, RCV_YM_E, SUB_CPY_ID);

                logSecurity(dataList);
                resp.addOutputData("dataList", dataList);
            } catch (DataNotFoundException e) {
                log.error("�T�{�������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0070_MSG_010");//�T�{����
                }
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0070_MSG_010");//�T�{����
        }

        return resp;
    }

    /**
     * �����T�{
     * @param req
     * @return
     */
    public ResponseContext doCancel(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            reqMap.put("USER_ID", user.getEmpID());
            reqMap.put("USER_NAME", user.getUserName());
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            Transaction.setXAMode();
            Transaction.begin();
            try {
                new EP_C30070().delete(reqMap);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0070_MSG_011"); //�����T�{����

            try {
                String RCV_YM_S = MapUtils.getString(reqMap, "RCV_YM_S");
                String RCV_YM_E = MapUtils.getString(reqMap, "RCV_YM_E");
                RCV_YM_S = StringUtils.isNotBlank(RCV_YM_S) ? DATE.getY2KYearAndMonth(RCV_YM_S) : "";
                RCV_YM_E = StringUtils.isNotBlank(RCV_YM_E) ? DATE.getY2KYearAndMonth(RCV_YM_E) : "";
                List<Map> dataList = new EP_C30070().query(MapUtils.getString(reqMap, "QUERY_TYPE"),
                    MapUtils.getString(reqMap, "PAY_KIND"), MapUtils.getString(reqMap, "CRT_NO"), MapUtils.getString(reqMap, "CUS_NO"),
                    RCV_YM_S, RCV_YM_E, SUB_CPY_ID);

                logSecurity(dataList);
                resp.addOutputData("dataList", dataList);
            } catch (DataNotFoundException e) {
                log.error("�����T�{�������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0070_MSG_012");//�����T�{����
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0070_MSG_012");//�����T�{����
        }

        return resp;
    }
}
