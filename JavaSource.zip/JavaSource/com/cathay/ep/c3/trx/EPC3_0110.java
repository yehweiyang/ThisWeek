package com.cathay.ep.c3.trx;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.tools.ant.util.FileUtils;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.c3.module.EP_C30110;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.RptUtils;
import com.cathay.util.FileStoreUtil;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Description Author
 * 2013/9/6    Created �\�a�s
 * 
 * UCEPC3_0110_�H�Υd�P�b�W�ǧ@�~
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �H�Υd�P�b�W�ǧ@�~
 * �{���W��    EPC3_0110
 * �@�~�覡    ONLINE]
 * ���n����    (1) �d�ߡG�d�߫H�Υd�дھP�b���
 *             (2) �W�ǡG�N�Ȧ�^�Ǫ���ƤW��, ��X��e���W
 *             (3) �P�b�G�N�W�Ǫ���ƾP�b
 *             (4) �����P�b�G�N�d�X����ƨ����P�b
 * �h���d��     ������                                      
 * </pre>
 * @author �x�Ԫ�
 * @since 2013/12/25
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC3_0110 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0110.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC3_0110_ERRMSG_007");//���o�����q�O����
        }

        resp.addOutputData("ACNT_DIV_NO", user.getDivNo());
        resp.addOutputData("ACNT_DATE", DATE.getROCDate());
        resp.addOutputData("DACNT_TYPEList", FieldOptionList.getFieldOptions("EP", "DACNT_TYPE"));

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String strACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
            Date ACNT_DATE = null;
            if (StringUtils.isNotBlank(strACNT_DATE)) {
                ACNT_DATE = Date.valueOf(strACNT_DATE);
            }
            List<Map> rtnList = new EP_C30110().queryList(ACNT_DATE, user.getDivNo(), MapUtils.getString(reqMap, "SLIP_SET_NO"), MapUtils.getString(reqMap, "SUB_CPY_ID"));
            resp.addOutputData("rtnList", rtnList);

            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            //���B�X�p
            BigDecimal PAY_AMT = BigDecimal.ZERO;
            for (Map rtnMap : rtnList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("ID", rtnMap.get("ID"));
                logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                logSecurityList.add(logSecurityMap);

                PAY_AMT = PAY_AMT.add(this.obj2Big(rtnMap.get("PAY_AMT")));
            }
            logSecurity(logSecurityList);
            resp.addOutputData("PAY_AMT", PAY_AMT);

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }
        return resp;
    }

    /**
     * �ɮפW��
     * @param req
     * @return
     */
    public ResponseContext doUpload(RequestContext req) {
        List<Map> rtnList = null;
        String DACNT_TYPE = null;
        String filePath = ""; // [20200415]�s�W�{���X
        String fileName = ""; // [20200415]�s�W�{���X
        File zipfile = null; // [20200415]�s�W�{���X
        try {
            //���o�e���W�W�Ǫ�����
            FileItem fi = FileStoreUtil.parseUploadStream(req);

            // [20200210]�s�W�{���X
            // ���o�W�Ǹ��|�������Ƥj�p
            long fileMaxSize = 10 * 1024 * 1024; // 10MB
            if (fi.getSize() > fileMaxSize) {
                throw new ModuleException(MessageUtil.getMessage("EPC3_0110_ERRMSG_008")); // �W���ɮפӤj
            }

            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            DACNT_TYPE = req.getParameter("DACNT_TYPE");
            log.debug("yenho=DACNT_TYPE=>" + DACNT_TYPE);
            Transaction.begin();
            try {
                // [20200415]�Ȧ���W�ǧ��zip��
                if ("1".equals(DACNT_TYPE)) {//�Ȧ���W��
                    fileName = fi.getName();
                    filePath = RptUtils.createTempFile(fileName).getAbsolutePath();
                    zipfile = new File(filePath);
                    fi.write(zipfile);
                    rtnList = new EP_C30110().rptStr2List1(filePath, DACNT_TYPE, SUB_CPY_ID);
                    Transaction.commit();
                } else {//��@�Ȥ�W��
                    rtnList = new EP_C30110().rptStr2List2(fi.getInputStream(), DACNT_TYPE, SUB_CPY_ID);
                }
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0110_MSG_001");//�W�ǧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0110_ERRMSG_002");//�W�ǥ���
            }
        } catch (Exception e) {
            log.error("�W�ǥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0110_ERRMSG_002");//�W�ǥ���
        } finally {
            try {
                // [20200415]�s�W�{���X�A�L�צ��\�P�_�A�ҧR���Ȧs��
                if ("1".equals(DACNT_TYPE)) {//�Ȧ���W��
                    if (zipfile != null && zipfile.exists()) { // �Ȧs��zip�ɮ�
                        FileUtils.delete(zipfile);
                    }
                    StringBuilder sb = new StringBuilder();
                    String newFolderName = FilenameUtils.getFullPath(filePath) + FilenameUtils.getBaseName(filePath);
                    File txtPath = new File(newFolderName); // �s��txt����Ƨ�
                    if (txtPath.exists()) {
                        String[] txtNames = txtPath.list();
                        if (txtNames.length != 0) {
                            File txtfile = new File(sb.append(newFolderName).append('/').append(txtNames[0]).toString()); // �Ȧs��txt
                            if (txtfile.exists()) {
                                FileUtils.delete(txtfile);
                            }
                        }
                        FileUtils.delete(txtPath);
                    }
                }

                //�^�Ǫ����
                Map<String, Object> map = new HashMap<String, Object>();
                map.put(IConstantMap.ErrMsg, msg);
                map.put("rtnList", rtnList);
                logSecurity(rtnList);
                //���B�X�p
                if (rtnList != null && !rtnList.isEmpty()) {
                    if ("1".equals(DACNT_TYPE)) {
                        BigDecimal SPR_AMT = BigDecimal.ZERO;
                        for (Map rtnMap : rtnList) {
                            SPR_AMT = SPR_AMT.add(this.obj2Big(rtnMap.get("SPR_AMT")));
                        }
                        map.put("SPR_AMT", SPR_AMT);
                    }
                }
                EncodingHelper.send2iframe(req, map, msg);
            } catch (Exception e) {
                log.error("�W�ǵ��G����", e);
            }
        }

        return resp;
    }

    /**
     * �P�b
     * @param req
     * @return
     */
    public ResponseContext doSB(RequestContext req) {
        try {
            List<Map> recordList = VOTool.jsonAryToMaps(req.getParameter("records"));
            String ACNT_DATE = req.getParameter("ACNT_DATE");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            String SLIP_SET_NO = "";
            String DACNT_TYPE = null;
            DACNT_TYPE = req.getParameter("DACNT_TYPE");
            log.debug("yenho=DACNT_TYPE=>" + DACNT_TYPE);

            Transaction.setXAMode();
            Transaction.begin();
            try {
                SLIP_SET_NO = new EP_C30110().doSB(recordList, StringUtils.isNotBlank(ACNT_DATE) ? Date.valueOf(ACNT_DATE) : null, user.getDivNo(), user, DACNT_TYPE, SUB_CPY_ID);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0110_MSG_003");//�P�b����
            resp.addOutputData("SLIP_SET_NO", SLIP_SET_NO);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0110_ERRMSG_004");//�P�b����
            }
        } catch (Exception e) {
            log.error("�P�b�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0110_ERRMSG_004");//�P�b����
        }

        return resp;
    }

    /**
     * �����P�b
     * @param req
     * @return
     */
    public ResponseContext doCancelSB(RequestContext req) {
        try {
            String ACNT_DATE = req.getParameter("ACNT_DATE");
            String SLIP_SET_NO = req.getParameter("SLIP_SET_NO");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            Transaction.setXAMode();
            Transaction.begin();
            try {
                new EP_C30110().doCancelSB(StringUtils.isNotBlank(ACNT_DATE) ? Date.valueOf(ACNT_DATE) : null, user.getDivNo(), SLIP_SET_NO, user, SUB_CPY_ID);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0110_MSG_005");//�����P�b����
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0110_ERRMSG_006");//�����P�b����
            }
        } catch (Exception e) {
            log.error("�����P�b�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0110_ERRMSG_006");//�����P�b����
        }

        return resp;
    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal obj2Big(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }

        String str = String.valueOf(obj);

        if (StringUtils.isBlank(str)) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal(str);
    }

}
