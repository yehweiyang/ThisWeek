package com.cathay.ep.c3.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.c0.module.EP_C0Z002;
import com.cathay.ep.c0.module.EP_C0Z003;
import com.cathay.ep.c0.module.EP_C0Z004;
import com.cathay.ep.c3.module.EP_C30090;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Version Description Author
 * 2013/11/11   1.0 Created     ���i��
 *
 * UCEPC3_0090_�h�O�P�������b�ȽT�{
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �h�O�P�������b�ȽT�{
 * �{���W��    EPC3_0090
 * �@�~�覡    ONLINE
 * ���n����    1. �d�ߡG�d�߫ݽT�{�Τw�T�{���Ȧ�/��X��ơC
 *             2. �T�{�G����Ȧ�/��X���X�b�@�~�C
 *             3. �����T�{�G�����Ȧ�/��X���X�b�@�~�C
 * �h���d��     �L         v������          �u����
 * </pre>
 * @author ����[
 * @since 2013-12-31
 */
@SuppressWarnings("unchecked")
public class EPC3_0090 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0090.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        String SUB_CPY_ID = null;

        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC3_0090_ERRMSG_011");//���o�����q�O����
        }

        resp.addOutputData("today", DATE.getDBDate());
        //�b�Ⱥ����vACNT_TYPE_List
        resp.addOutputData("ACNT_TYPE_List", FieldOptionList.getFieldOptions("EP", "ACNT_TYPE"));
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("USER_ID", user.getEmpID());
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            reqMap.put("USER_NAME", user.getEmpName());

            query(reqMap, new EP_C30090());

            MessageUtil.setMsg(msg, "MI00020");//�d�ߥ����\
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0090_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00630");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("USER_ID", user.getEmpID());
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            reqMap.put("USER_NAME", user.getEmpName());

            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));

            EP_C30090 theEP_C30090 = new EP_C30090();
            Map<String, String> SLIP_MAP = new HashMap<String, String>();

            Transaction.setXAMode();
            Transaction.begin();
            try {
                SLIP_MAP = theEP_C30090.confirm(reqMap, reqList, user);
                String SLIP_SET_NO = MapUtils.getString(SLIP_MAP, "SLIP_SET_NO");
                reqMap.put("SLIP_SET_NO", SLIP_SET_NO);
                resp.addOutputData("ACNT_DATE", DATE.toROCDate(MapUtils.getString(SLIP_MAP, "ACNT_DATE")));
                resp.addOutputData("SLIP_SET_NO", SLIP_SET_NO);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            try {
                reqMap.put("QUERY_TYPE", "Y");
                query(reqMap, theEP_C30090);
            } catch (DataNotFoundException e) {
                log.error("�T�{�����A�d�L���", e);
            }

            MessageUtil.setMsg(msg, "EPC3_0090_ERRMSG_001");//�ʦ��T�{
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0090_ERRMSG_002");//�T�{����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0090_ERRMSG_002");//�T�{����
        }

        return resp;
    }

    /**
     * �����T�{
     * @param req
     * @return
     */
    public ResponseContext doUnConfirm(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("USER_ID", user.getEmpID());
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            reqMap.put("USER_NAME", user.getEmpName());
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));

            EP_C30090 theEP_C30090 = new EP_C30090();

            Transaction.setXAMode();
            Transaction.begin();
            try {
                theEP_C30090.cancel(reqMap, reqList);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            try {
                reqMap.put("QUERY_TYPE", "N");
                query(reqMap, theEP_C30090);
            } catch (DataNotFoundException e) {
                log.error("�����T�{�����A�d�L���", e);
            }
            MessageUtil.setMsg(msg, "EPC3_0090_ERRMSG_003");//�����T�{���\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0090_ERRMSG_004");//�����T�{����
            }
        } catch (Exception e) {
            log.error("�����T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0090_ERRMSG_004");//�����T�{����
        }

        return resp;
    }

    /**
     * �@�άd��
     * @param reqMap
     * @param theEP_C30090
     * @throws ModuleException
     */
    public void query(Map reqMap, EP_C30090 theEP_C30090) throws ModuleException {

        List<Map> dataList = new ArrayList<Map>();
        try {
            dataList = theEP_C30090.query(reqMap);

            String QUERY_TYPE = MapUtils.getString(reqMap, "QUERY_TYPE");

            if ("Y".equals(QUERY_TYPE)) {
                //�Y�d�ߪ��w�T�{��Ƹ̭��A���@����ƪ��X�b�H���D�ثe�e���ާ@�H���A�h�i�����T�{�j�B�i�����C�L���s�j�ҳ]��DISABLE                
                for (Map dataMap : dataList) {
                    String INPUT_ID = MapUtils.getString(dataMap, "INPUT_ID");

                    if (!user.getEmpID().equals(INPUT_ID)) {
                        resp.addOutputData("QueryOnly", "Y");
                        break;
                    }
                }
            }
        } catch (DataNotFoundException ex) {
            log.error("", ex);
            //It's OK
        }

        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        int i = 1;
        for (Map rtnMap : dataList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
            logSecurityMap.put("ID", rtnMap.get("ID"));
            logSecurityMap.put("ACPT_ID", rtnMap.get("ACPT_ID"));
            logSecurityMap.put("ACPT_ACNT_NAME", rtnMap.get("ACPT_ACNT_NAME"));
            logSecurityMap.put("INPUT_ID", rtnMap.get("INPUT_ID"));
            logSecurityMap.put("INPUT_NAME", rtnMap.get("INPUT_NAME"));
            logSecurityList.add(logSecurityMap);

            rtnMap.put("NO", i++);
        }
        logSecurity(logSecurityList);

        resp.addOutputData("dataList", dataList);
    }

    /**
     * �����C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));

            //5.4.1 �]�wUSER���
            reqMap.put("USER_ID", user.getEmpID());
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            reqMap.put("USER_NAME", user.getEmpName());
            String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
            String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
            //�զ��������ͼҲնǤJ�Ѽ�
            String key1 = MapUtils.getString(reqMap, "SLIP_DATE");
            String key2 = new EP_C30090().getSLIP_LOT_NO(QUERY_KIND, ACNT_TYPE);
            String key3 = MapUtils.getString(reqMap, "USER_DIV_NO");
            String key4 = MapUtils.getString(reqMap, "SLIP_SET_NO");
            ErrorInputException eie = null;
            if (StringUtils.isBlank(key1)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPC3_0090_MSG_007"));//�ǲ�������o���ŭ�
            }
            if (StringUtils.isBlank(key2)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPC3_0090_MSG_008"));//�ǲ��帹���o���ŭ�
            }
            if (StringUtils.isBlank(key3)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPC3_0090_MSG_009"));//�s����줣�o���ŭ�
            }
            if (StringUtils.isBlank(key4)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPC3_0090_MSG_010"));//�ǲ��ո����o���ŭ�
            }
            if (eie != null) {
                throw eie;
            }

            //�v���B�zreqList
            List<Map> dataList1 = new ArrayList<Map>(); //�Ȧ��h�O�Bú�O��X�h�O�������
            List<Map> dataList2 = new ArrayList<Map>(); //ú�O��X�J�Ȧ��Bú�O��X�~�b�J�Ȧ����
            List<Map> dataList3 = new ArrayList<Map>();

            for (Map map : reqList) {
                Map dataMap = new HashMap();
                if ("1".equals(QUERY_KIND)) {//�Ȧ��h�O
                    dataMap.putAll(map);
                    dataMap.put("PAY_TYPE", MapUtils.getString(map, "RTN_KIND"));
                    dataMap.put("CRT_NO", MapUtils.getString(map, "POLICY_NO"));
                    dataMap.put("CUS_NO", MapUtils.getString(map, "PAY_TIMES"));
                    dataMap.put("AMT", MapUtils.getObject(map, "DACNT_AMT"));

                    String ACPT_ACNT_NAME = MapUtils.getString(map, "ACPT_ACNT_NAME");
                    String ACPT_BANK_NO = MapUtils.getString(map, "ACPT_BANK_NO");
                    String ACPT_ACNT_NO = MapUtils.getString(map, "ACPT_ACNT_NO");
                    if (StringUtils.isNotBlank(ACPT_BANK_NO)) {
                        ACPT_ACNT_NAME = ACPT_ACNT_NAME + "�A��w�N��:" + ACPT_BANK_NO;
                    }
                    if (StringUtils.isNotBlank(ACPT_ACNT_NO)) {
                        ACPT_ACNT_NAME = ACPT_ACNT_NAME + "�A�Ȧ�b��:" + ACPT_ACNT_NO;
                    }
                    dataMap.put("ACPT_ACNT_NAME", ACPT_ACNT_NAME);
                    dataList1.add(dataMap);
                } else if ("2".equals(QUERY_KIND)) {//ú�O��X
                    String PAY_TYPE = MapUtils.getString(map, "PAY_TYPE");
                    String SWP_KIND = MapUtils.getString(map, "SWP_KIND");
                    dataMap.putAll(map);
                    if ("1".equals(SWP_KIND)) { //ú�O��X�h�O
                        if ("1".equals(PAY_TYPE)) {
                            dataMap.put("PAY_TYPE", "2"); //�{��
                        } else if ("2".equals(PAY_TYPE)) {
                            dataMap.put("PAY_TYPE", "3"); //�䲼
                        } else if ("3".equals(PAY_TYPE)) {
                            dataMap.put("PAY_TYPE", "1"); //�״�
                            String ACPT_ACNT_NAME = MapUtils.getString(map, "ACPT_ACNT_NAME");
                            String ACPT_BANK_NO = MapUtils.getString(map, "ACPT_BANK_NO");
                            String ACPT_ACNT_NO = MapUtils.getString(map, "ACPT_ACNT_NO");
                            if (StringUtils.isNotBlank(ACPT_BANK_NO)) {
                                ACPT_ACNT_NAME = ACPT_ACNT_NAME + "�A" + MessageUtil.getMessage("EPC3_0090_UI_BANK_NO") + ":" + ACPT_BANK_NO;
                            }
                            if (StringUtils.isNotBlank(ACPT_ACNT_NO)) {
                                ACPT_ACNT_NAME = ACPT_ACNT_NAME + "�A" + MessageUtil.getMessage("EPC3_0090_UI_ACNT_NO") + ":" + ACPT_ACNT_NO;
                            }
                            dataMap.put("ACPT_ACNT_NAME", ACPT_ACNT_NAME);
                        }
                        dataMap.put("AMT", MapUtils.getObject(map, "SWP_AMT"));
                        dataList1.add(dataMap);
                    } else if ("0".equals(SWP_KIND) || "2".equals(SWP_KIND)) { //��X�J�Ȧ��B��X�~�b�J�Ȧ�
                        dataMap.put("ACNT_AMT", MapUtils.getObject(map, "SWP_AMT"));
                        dataList2.add(dataMap);
                    }
                    String CHK_CD = MapUtils.getString(map, "CHK_CD");
                    dataMap.put("CHK_CD_NM", StringUtils.isNotBlank(CHK_CD) ? FieldOptionList.getName("EP", "CHK_CD", CHK_CD) : "");
                    String PAY_KIND = MapUtils.getString(map, "PAY_KIND");
                    dataMap
                            .put("PAY_KIND_NM", StringUtils.isNotBlank(PAY_KIND) ? FieldOptionList.getName("EPC", "PAY_KIND", PAY_KIND)
                                    : "");
                }
            }
            //����:�ǲ����,�ǲ��帹,�s�����,�ǲ��ո�
            StringBuilder sb = new StringBuilder();
            sb.append(key1).append(",");
            sb.append(key2).append(",");
            sb.append(key3).append(",");
            sb.append(key4);
            String key = sb.toString();
            sb.setLength(0);

            Map<String, List<Map>> SlipMap1 = null;
            Map<String, List<Map>> SlipMap2 = null;

            //�榡�Ƴ����Ѽ�MAP
            if (dataList1.size() > 0) {
                SlipMap1 = new HashMap<String, List<Map>>();
                SlipMap1.put(key, dataList1);
            }

            if (dataList2.size() > 0) {
                SlipMap2 = new HashMap<String, List<Map>>();
                SlipMap2.put(key, dataList2);
            }
            Map<String, List<Map>> SlipMap3 = new HashMap();
            dataList3.addAll(dataList1);
            dataList3.addAll(dataList2);
            logSecurity(dataList3);
            SlipMap3.put(key, dataList3);
            //���������Ʈ榡��
            if ("1".equals(QUERY_KIND)) { //�Ȧ��h�O 
                EP_C0Z002 theEP_C0Z002 = new EP_C0Z002();
                Map paramMap1 = theEP_C0Z002.doFormat(SlipMap1, user);
                theEP_C0Z002.doPrint(paramMap1, resp);
            } else {
                //��X�h�O�����Ҳ�
                EP_C0Z002 theEP_C0Z002 = new EP_C0Z002();
                //��X�J�Ȧ������Ҳ�
                EP_C0Z003 theEP_C0Z003 = new EP_C0Z003();

                EP_C0Z004 theEP_C0Z004 = new EP_C0Z004();
                List<Map[]> RPT_PARAMList = new ArrayList<Map[]>();
                List<List[]> RPT_DETAILList_F = new ArrayList<List[]>();
                if (SlipMap1 != null && !SlipMap1.isEmpty()) {

                    Map paramMap1 = theEP_C0Z002.doFormat(SlipMap1, user);
                    RPT_PARAMList.add(new Map[] { (Map) paramMap1.get("params") });
                    RPT_DETAILList_F.add(new List[] { (List<Map>) paramMap1.get("detail") });
                    //theEP_C0Z002.doPrint(paramMap1, resp);
                }
                if (SlipMap2 != null && !SlipMap2.isEmpty()) {

                    Map paramMap2 = theEP_C0Z003.doFormat(SlipMap2, user);
                    //theEP_C0Z003.doPrint(paramMap2, resp);

                    RPT_PARAMList.add(new Map[] { (Map) paramMap2.get("params") });
                    RPT_DETAILList_F.add(new List[] { (List<Map>) paramMap2.get("detail") });
                }
                Map paramMap3 = theEP_C0Z004.doFormat(SlipMap3, user);
                RPT_PARAMList.add(new Map[] { (Map) paramMap3.get("params") });
                RPT_DETAILList_F.add(new List[] { (List<Map>) paramMap3.get("detail") });
                // theEP_C0Z004.doPrint(paramMap3, resp);
                int paramsSize = RPT_PARAMList.size();
                Map[][] inputParams = RPT_PARAMList.toArray(new Map[paramsSize][]);

                List[][] inputDetailLists = RPT_DETAILList_F.toArray(new List[RPT_DETAILList_F.size()][]);
                String[] reportIds = new String[paramsSize];
                for (int i = 0; i < paramsSize; i++) {
                    reportIds[i] = "EPC30090";
                }
                JasperReportUtils.addOutputRptDataToResp(reportIds, inputParams, inputDetailLists, req, resp);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0090_ERRMSG_005");//�����C�L����
            }
        } catch (Exception e) {
            log.error("�����C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0090_ERRMSG_005");//�����C�L����
        }

        return resp;
    }

    /**
     * �s����ܶǲ��帹
     * @param req
     * @return
     */
    public ResponseContext doChangeACNT_TYPE(RequestContext req) {
        try {

            resp
                    .addOutputData("SLIP_LOT_NO", new EP_C30090().getSLIP_LOT_NO(req.getParameter("QUERY_KIND"), req
                            .getParameter("ACNT_TYPE")));
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630");//�d�ߥ���
        }

        return resp;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
