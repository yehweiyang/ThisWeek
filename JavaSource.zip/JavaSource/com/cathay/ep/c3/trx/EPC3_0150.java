package com.cathay.ep.c3.trx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.c3.module.EP_C30150;
import com.cathay.ep.c3.module.EP_C32020;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * 
<pre> 
Date    Version Description Author
2013/12/26  1.0 Created ������

UCEPC3_0150_�h���B�z��X�@�~

�{���\�෧�n�����G
    �{���\��    �h���B�z��X�@�~
    �{���W��    EPC3_0150
    �@�~�覡    ONLINE
    ���n����
        1.  �d�ߡG�d�߲��ڥd���I�{�ɤ����h����ơC
        2.  �T�{�G�N���ڥd���I�{�ɤ����Ȧ��s���������s���A�T�{��X�åX�b�C
        3.  �����T�{�G�N���ڥd���I�{�ɤ����Ȧ��s���������s���A�����T�{��X�çR���b�ȸ�ơC
        4.  ��X���J�B�z�G�ɦ��������ڰh���޲z�@�~
    ���s���v    �M��
    �����q���
    �榡���js  �M��
    �h��y�t    �M��
    �h���d��    ������
</pre>
 * @author ���t�s
 * @since 2014/1/22
 */
@SuppressWarnings("unchecked")
public class EPC3_0150 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0150.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        String OpUnit = user.getOpUnit();
        resp.addOutputData("CFM_TYPE", FieldOptionList.getFieldOptions("EPC3", "CFM_TYPE"));
        resp.addOutputData("ACNT_DIV_NO", new StringBuilder(OpUnit).append(" ").append(user.getDivShortName()));
        resp.addOutputData("ACNT_NAME", user.getEmpName());

        //�b�Ⱥ����vACNT_TYPE_List
        resp.addOutputData("ACNT_TYPE_List", FieldOptionList.getFieldOptions("EP", "ACNT_TYPE"));

        String SLIP_LOT_NO = "EP9";
        resp.addOutputData("SLIP_LOT_NO", SLIP_LOT_NO);
        resp.addOutputData("ACNT_DATE", DATE.getDBDate());
        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC3_0150_MSG_006");//���o�����q�O����
        }
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> rtnList = new EP_C30150().queryNonCashChkList(reqMap, user);

            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map rtnMap : rtnList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("ID", rtnMap.get("ID"));
                logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);

            resp.addOutputData("rtnList", rtnList);
            MessageUtil.setMsg(msg, "MI00020"); //�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632"); //�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028"); ////�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00630"); //�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630"); //�d�ߥ���
        }

        return resp;
    }

    /**
     * �d�ߤj�ӦW��
     * @param req
     * @return
     */
    public ResponseContext doQueryBLDName(RequestContext req) {
        try {
            Map reqMap = new HashMap();
            reqMap.put("BLD_CD", req.getParameter("BLD_CD"));
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            resp.addOutputData("BLD_NAME", (new EP_A10010()).queryMap(reqMap).get("BLD_NAME"));
        } catch (ErrorInputException eie) {
            log.error(eie);
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
            } else {
                log.error(me.getMessage(), me.getRootException());
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            log.error("EPC3_0150 doConfirm reqMap:" + reqMap);//TODO
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            Transaction.setXAMode();
            Transaction.begin();
            try {
                new EP_C30150().doConfirm(reqMap, reqList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            resp.addOutputData("SLIP_SET_NO", reqMap.get("SLIP_SET_NO"));
            reqMap.put("CFM_TYPE", "Y");
            MessageUtil.setMsg(msg, "EPC3_0150_MSG_001"); //�T�{����
            try {
                List<Map> rtnList = new EP_C30150().queryNonCashChkList(reqMap, user);

                //logSecurity
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map rtnMap : rtnList) {
                    Map logSecurityMap = new HashMap();
                    logSecurityMap.put("ID", rtnMap.get("ID"));
                    logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);

                resp.addOutputData("rtnList", rtnList);
            } catch (DataNotFoundException e) {
                resp.addOutputData("rtnList", Collections.EMPTY_LIST);
                log.error("�T�{�������d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632"); //�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0150_MSG_002"); //�T�{����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0150_MSG_002"); //�T�{����
        }

        return resp;
    }

    /**
     * �����T�{
     * @param req
     * @return
     */
    public ResponseContext doCancel(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));

            Transaction.setXAMode();
            Transaction.begin();
            try {
                new EP_C30150().doCancel(reqMap, reqList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            try {
                reqMap.put("CFM_TYPE", "N");
                List<Map> rtnList = new EP_C30150().queryNonCashChkList(reqMap, user);

                //logSecurity
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map rtnMap : rtnList) {
                    Map logSecurityMap = new HashMap();
                    logSecurityMap.put("ID", rtnMap.get("ID"));
                    logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);

                resp.addOutputData("rtnList", rtnList);
            } catch (DataNotFoundException e) {
                resp.addOutputData("rtnList", Collections.EMPTY_LIST);
                log.error("�����T�{���\���d�L���", e);
            }

            MessageUtil.setMsg(msg, "EPC3_0150_MSG_003"); //�����T�{����
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632"); //�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0150_MSG_004"); //�����T�{����
            }
        } catch (Exception e) {
            log.error("�����T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0150_MSG_004"); //�����T�{����
        }

        return resp;
    }

    /**
     * �C�L���ک���
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            EP_C32020 theEP_C32020 = new EP_C32020();
            //�H���ڲո��d�߲��ک���
            reqMap.put("QUERY_KIND", "0");
            List<Map> dataList = theEP_C32020.doQueryC302(reqMap);

            //�C�L�ǲ�����
            theEP_C32020.print(reqMap, dataList, user, resp);
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0150_MSG_005");//�C�L����
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0150_MSG_005");//�C�L����
        }

        return resp;
    }

}
