package com.cathay.ep.c3.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.c3.module.EP_C30080;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C301;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * 
<pre> 
UCEPC3_0080_����ഫ�@�~

1.  �{���\�෧�n�����G
        �{���\��    ����ഫ�@�~
        �{���W��    EPC3_0080
        �@�~�覡    ONLINE
        ���n����    
            1.  �d�ߡG�d��ú�ڬ������
            2.  �T�{�G���ͷs��ú�ڬ���
        ���s���v    �M��
        �����q���
        �榡���js  �M��
        �h��y�t    �M��
        �h���d��    ������       

</pre>
 * @author ���t�s
 * @since 2013/12/17
 */
@SuppressWarnings("unchecked")
public class EPC3_0080 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0080.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        StringBuilder sb = new StringBuilder();
        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            sb.append(MessageUtil.getMessage("EPC3_0080_MSG_005"));//���o�����q�O����
            STRING.newLine(sb);
        }

        resp.addOutputData("PMI_S_DATE", DATE.getMonthFirstDate());//�㮧�_��  �w�] ����1��
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            List<Map> rtnList = new EP_Z0C301().doQuery(req.getParameter("CRT_NO"), req.getParameter("CUS_NO"));

            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map rtnMap : rtnList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("ID", rtnMap.get("ID"));
                logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);

            resp.addOutputData("rtnList", rtnList);

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �p���`�B
     * @param req
     * @return
     */
    public ResponseContext doCompute(RequestContext req) {

        try {
            Map payMap = VOTool.jsonToMap(req.getParameter("payAmtMap"));
            BigDecimal bPAYAMT = BigDecimal.ZERO;
            for (Object key : payMap.keySet()) {
                bPAYAMT = bPAYAMT.add(getBigDecimal(payMap.get(key)));
            }
            resp.addOutputData("PAYAMT", bPAYAMT);
        } catch (Exception e) {
            log.error("�p�⥢��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC3_0080_MSG_002")); //�p�⥢��
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {
        try {
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            EP_C30080 theEP_C30080 = new EP_C30080();
            EP_Z0C301 theEP_Z0C301 = new EP_Z0C301();

            Transaction.begin();
            try {
                theEP_C30080.doComfirm(reqList, reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC3_0080_MSG_001")); //�T�{����

            try {
                List<Map> rtnList = theEP_Z0C301.doQuery(MapUtils.getString(reqMap, "CRT_NO"), MapUtils.getString(reqMap, "CUS_NO"));

                //logSecurity
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map rtnMap : rtnList) {
                    Map logSecurityMap = new HashMap();
                    logSecurityMap.put("ID", rtnMap.get("ID"));
                    logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);

                resp.addOutputData("rtnList", rtnList);
            } catch (DataNotFoundException dnfe) {
                log.error(dnfe);
            } catch (Exception e) {
                MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC3_0080_MSG_003")); //�T�{���������d����
                log.error("", e);
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC3_0080_MSG_004")); //�T�{����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC3_0080_MSG_004")); //�T�{����
        }

        return resp;
    }

    /**
     * ���oBigDecimal
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj) {
        if (obj != null) {
            if (obj instanceof BigDecimal) {
                return (BigDecimal) obj;
            }
            String value = obj.toString();
            if (NumberUtils.isNumber(value)) {
                return new BigDecimal(value);
            }
        }
        return BigDecimal.ZERO;

    }

    /**
     * �s�ʬd��(�Ȥ��T)
     * @param req
     * @return
     */
    public ResponseContext doGetCusName(RequestContext req) {
        try {
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
            reqMap.put("CUS_NO", req.getParameter("CUS_NO"));
            reqMap.put("CRT_NO", req.getParameter("CRT_NO"));
            Map rtnMap = new EP_B10020().queryMap(reqMap);
            resp.addOutputData("CUS_NAME", rtnMap.get("CUS_NAME"));
            resp.addOutputData("ID", rtnMap.get("ID"));

        } catch (Exception e) {
            log.error("���o�Ȥ��T����", e);
            resp.addOutputData("CUS_NAME", "");
        }
        return resp;
    }

}
