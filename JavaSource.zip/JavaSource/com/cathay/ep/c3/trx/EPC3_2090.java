package com.cathay.ep.c3.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.c3.module.EP_C32090;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * 
<pre>
Date    Version Description Author
2013/11/13  1.0 Created ���i��

UCEPC3_2090_����d��

�{���\�෧�n�����G
    �{���\��    ����d��
    �{���W��    EPC3_2090
    �@�~�覡    ONLINE
    ���n����    �d�ߤj�ө����Ʃ��ӡC
    �h���d��    ������
</pre>
 * @author ���t�s
 * @since 2014/1/2
 */
@SuppressWarnings("unchecked")
public class EPC3_2090 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_2090.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    //private UserObject user;
    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */

    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = new HashMap();
            reqMap.put("BLD_CD", req.getParameter("BLD_CD"));
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);

            EP_C32090 theEP_C32090 = new EP_C32090();

            resp.addOutputData("BLD_NAME", theEP_C32090.query3(reqMap));

            boolean qryIsDnfe = true;
            List<Map> logSecurityList = new ArrayList<Map>();
            try {
                List<Map> bGrid = theEP_C32090.query1(reqMap);
                Map bLogSecurityMap = new HashMap();
                for (int i = 0; i < bGrid.size(); i++) {
                    bLogSecurityMap.put("bGrid[" + i + "].CUS_NAME", bGrid.get(i).get("CUS_NAME"));
                }
                logSecurityList.add(bLogSecurityMap);
                resp.addOutputData("bGrid", bGrid);
                qryIsDnfe = false;
            } catch (DataNotFoundException dnfe) {
                log.error("", dnfe);
            }
            try {
                List<Map> cGrid = theEP_C32090.query2(reqMap);
                Map bLogSecurityMap = new HashMap();
                for (int i = 0; i < cGrid.size(); i++) {
                    bLogSecurityMap.put("cGrid[" + i + "].CUS_NAME", cGrid.get(i).get("CUS_NAME"));
                }
                logSecurityList.add(bLogSecurityMap);
                resp.addOutputData("cGrid", cGrid);
                qryIsDnfe = false;
            } catch (DataNotFoundException dnfe) {
                log.error("", dnfe);
            }
            logSecurity(logSecurityList);
            if (qryIsDnfe) {
                throw new DataNotFoundException();
            }

            MessageUtil.setMsg(msg, "MI00020");//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

}
