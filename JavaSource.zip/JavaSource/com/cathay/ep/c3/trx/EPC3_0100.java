package com.cathay.ep.c3.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.c1.module.EP_C14010;
import com.cathay.ep.c3.module.EP_C30100;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2013/10/31  1.0 Created ���i��
 * 
 * UCEPC3_0100_�ʦ��P�b�b�@�~
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �ʦ��P�b�b�@�~
 * �{���W��    EPC3_0100\
 * �@�~�覡    ONLINE
 * ���n����    (1) �d�ߡG �d�������ڡB�w�C�ʦ��B�w�C�b�b��ơC
 *             (2) �T�{�G ���������ڡB�w�C�ʦ��B�w�C�b�b���b�ȸ�ơC
 *             (3) �����T�{�G�R�������ڡB�w�C�ʦ��B�w�C�b�b���b�ȸ�ơC
 *             (4) �e���C�L�G�C�L�ثe�e������ơC
 * �h���d��   ������
 * </pre>
 * @author �x�Ԫ�
 * @since 2013/12/23
 */
@SuppressWarnings("unchecked")
public class EPC3_0100 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0100.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));//�����q�O
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC3_0100_ERRMSG_001");//���o�����q�O����
        }
        resp.addOutputData("ACNT_DIV_NO", user.getOpUnit());
        //�b�Ⱥ����vACNT_TYPE_List
        resp.addOutputData("ACNT_TYPE_List", FieldOptionList.getFieldOptions("EP", "ACNT_TYPE"));
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            EP_C30100 theEP_C30100 = new EP_C30100();
            this.query(reqMap, theEP_C30100);
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }
        return resp;
    }

    /**
     * �ʦ��T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm1(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("USER_ID", user.getEmpID());
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            reqMap.put("USER_NAME", user.getEmpName());
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            EP_C30100 theEP_C30100 = new EP_C30100();
            Transaction.setXAMode();
            Transaction.begin();
            try {
                //����ʦ��T�{
                Map<String, String> rtnMap = theEP_C30100.confirm1(reqMap, reqList);
                resp.addOutputData("ACNT_DATE", DATE.toROCDate(MapUtils.getString(rtnMap, "ACNT_DATE")));
                resp.addOutputData("SLIP_SET_NO", MapUtils.getString(rtnMap, "SLIP_SET_NO"));
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0100_MSG_003");//�ʦ��T�{���\
            try {
                reqMap.put("QUERY_TYPE", "2");
                this.query(reqMap, theEP_C30100);
            } catch (DataNotFoundException e) {
                log.error("�ʦ��T�{�����A�d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0100_ERRMSG_002");//�ʦ��T�{����
            }
        } catch (Exception e) {
            log.error("�ʦ��T�{�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0100_ERRMSG_002");//�ʦ��T�{����
        }

        return resp;
    }

    /**
     * �����ʦ�
     * @param req
     * @return
     */
    public ResponseContext doCancel1(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("USER_ID", user.getEmpID());
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            reqMap.put("USER_NAME", user.getEmpName());
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            EP_C30100 theEP_C30100 = new EP_C30100();
            Transaction.setXAMode();
            Transaction.begin();
            try {
                //��������ʦ��@�~
                theEP_C30100.cancel1(reqMap, reqList);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0100_MSG_005");//�����ʦ����\
            try {
                reqMap.put("QUERY_TYPE", "1");
                this.query(reqMap, theEP_C30100);
            } catch (DataNotFoundException e) {
                log.error("�����ʦ������A�d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0100_ERRMSG_004");//�����ʦ�����
            }
        } catch (Exception e) {
            log.error("�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0100_ERRMSG_004");//�����ʦ�����
        }

        return resp;
    }

    /**
     * �b�b�T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm2(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("USER_ID", user.getEmpID());
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            reqMap.put("USER_NAME", user.getEmpName());
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            EP_C30100 theEP_C30100 = new EP_C30100();
            Transaction.setXAMode();
            Transaction.begin();
            try {
                //����b�b�T�{�@�~
                theEP_C30100.confirm2(reqMap, reqList);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0100_MSG_007");//�b�b�T�{���\
            try {
                reqMap.put("QUERY_TYPE", "3");
                this.query(reqMap, theEP_C30100);
            } catch (DataNotFoundException e) {
                log.error("�b�b�T�{�����A�d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0100_ERRMSG_006");//�b�b�T�{����
            }
        } catch (Exception e) {
            log.error("�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0100_ERRMSG_006");//�b�b�T�{����
        }

        return resp;
    }

    /**
     * �����b�b
     * @param req
     * @return
     */
    public ResponseContext doCancel2(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("USER_ID", user.getEmpID());
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            reqMap.put("USER_NAME", user.getEmpName());
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            EP_C30100 theEP_C30100 = new EP_C30100();
            Transaction.setXAMode();
            Transaction.begin();
            try {
                //��������b�b�@�~
                theEP_C30100.cancel2(reqMap, reqList);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC3_0100_MSG_009");//�����b�b���\
            try {
                reqMap.put("QUERY_TYPE", "2");
                this.query(reqMap, theEP_C30100);
            } catch (DataNotFoundException e) {
                log.error("�����b�b�����A�d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0100_ERRMSG_008");//�����b�b����
            }
        } catch (Exception e) {
            log.error("�����b�b�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0100_ERRMSG_008");//�����b�b����
        }

        return resp;
    }

    /**
     * �C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            EP_C14010 theEP_C14010 = new EP_C14010();
            reqMap.put("USER_DIV_NO", user.getOpUnit());
            List<Map> reqList = new EP_C30100().query(reqMap);
            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map rtnMap : reqList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);

            Map rptMap = theEP_C14010.doFmtRpt2(MapUtils.getString(reqMap, "QUERY_TYPE"), reqList, "", user, false);
            theEP_C14010.prtRpt2(rptMap, resp, req);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0100_ERRMSG_010");//�C�L����
            }
        } catch (Exception e) {
            log.error("�C�L����", e);//�C�L����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0100_ERRMSG_010");//�C�L����
        }

        return resp;
    }

    /**
     * �@�άd��
     * @param reqMap
     * @param theEP_C30100
     * @throws Exception
     */
    private void query(Map reqMap, EP_C30100 theEP_C30100) throws Exception {
        List<Map> rtnList = theEP_C30100.query(reqMap);

        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map rtnMap : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);
        }
        logSecurity(logSecurityList);

        resp.addOutputData("rtnList", rtnList);

    }
}
