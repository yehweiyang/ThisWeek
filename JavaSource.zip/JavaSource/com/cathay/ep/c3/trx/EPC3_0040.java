package com.cathay.ep.c3.trx;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.c3.module.EPC3_0040_mod;
import com.cathay.ep.c3.module.EP_C30040;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date        Version Description Author
 * 2013/08/29  1.0     Created     ������
 *
 * �{���\�෧�n�����G
 * �{���\��    ú�ڳB�z�@�~
 * �{���W��    EPC3_0040
 * �@�~�覡    ONLINE
 * ���n����    1.  �d�ߡG�d�ߤwú�ڸ��
 *             2.  �T�{�G����P�b�A�æP�ɥX�b
 *             3.  �����T�{�G�����P�b�A�çR���b�ȸ��
 * ���s���v    �M��
 * �����q����榡���js  �M��
 * �h��y�t    �M��
 * @author ���_��
 * @since 2013/12/27
 */
@SuppressWarnings("unchecked")
public class EPC3_0040 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0040.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     * @throws Exception 
     */
    public ResponseContext doPrompt(RequestContext req) {

        String SUB_CPY_ID = "";
        String OpUnit = user.getOpUnit();
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            //2018-03-13 �վ���W�٧���Ҳ�
            resp.addOutputData("ACNT_DIV", OpUnit + new EP_A10010().getDivName(OpUnit, SUB_CPY_ID));

        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC3_0040_MSG_006");//���o�����q�O����
        }

        //�@�b���
        //resp.addOutputData("ACNT_DIV", OpUnit + user.getOpUnitShortName());
        //�@�b�H��
        resp.addOutputData("ACNT_NAME", user.getEmpName());
        resp.addOutputData("OpUnit", OpUnit);//�ӿ��O
        resp.addOutputData("EmpID", user.getEmpID());//�ӿ�ID
        String today = DATE.getDBDate();
        resp.addOutputData("SYS_DATE", today);

        //�b�Ⱥ����vACNT_TYPE_List
        resp.addOutputData("ACNT_TYPE_List", FieldOptionList.getFieldOptions("EP", "ACNT_TYPE"));

        try {
            //���o�T�{���A�U�Կ��
            resp.addOutputData("CFM_TYPEList", FieldOptionList.getName("EPC3", "CFM_TYPE"));

        } catch (Exception e) {
            log.error("�U�Կ����o����", e);
        }

        return resp;

    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            this.queryM(MapUtils.getString(reqMap, "ACNT_DATE"), MapUtils.getString(reqMap, "ACNT_TYPE"), MapUtils.getString(reqMap,
                "SLIP_LOT_NO"), MapUtils.getString(reqMap, "SUB_CPY_ID"));

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("MEP00002"));//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else if (me.getRootException() instanceof DataNotFoundException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, me.getMessage());
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00780");//�@�~����
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0040_MSG_003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �����T�{
     * @param req
     * @return
     */
    public ResponseContext doCancelConfirm(RequestContext req) {

        try {
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("getCheck"));
            String ACNT_DATE = req.getParameter("ACNT_DATE");
            String SLIP_LOT_NO = req.getParameter("SLIP_LOT_NO");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            //Callú�ڱb�ȽT�{���@�Ҳ�.�����T�{�@�~��k �ˮ� �b�Ȥ���O�_����
            new EPC3_0040_mod().checkACNT_DATE(reqList, "1", SUB_CPY_ID);

            Transaction.setXAMode();
            Transaction.begin();
            //�}XAmode,�Ҳդ����ϥΨ�buds,�ѥD�{���ǤJ,transaction.commit��A����
            //budsArray = [C301,C306,C307]
            BatchUpdateDataSet budsC301 = Transaction.getBatchUpdateDataSet();
            BatchUpdateDataSet budsC306 = new com.cathay.db.impl.BatchUpdateDataSet();
            BatchUpdateDataSet budsC307 = new com.cathay.db.impl.BatchUpdateDataSet();

            budsC306.setDataSet(budsC301);
            budsC307.setDataSet(budsC301);
            BatchUpdateDataSet[] budsArray = new BatchUpdateDataSet[] { budsC301, budsC306, budsC307 };
            try {
                new EP_C30040().doCancelConfirm(ACNT_DATE, SLIP_LOT_NO, reqList, user, SUB_CPY_ID, budsArray);
                Transaction.commit();
            } catch (Exception e) {
                log.debug("Error Log:" + e, e);
                Transaction.rollback();
                throw e;
            } finally {
                if (budsC301 != null) {
                    try {
                        budsC301.close();
                    } catch (Exception e) {
                        log.fatal("budsC301.close ", e);
                        log.fatal("budsC301.isAutoTransaction " + budsC301.isAutoTransaction());
                        log.fatal("budsC301.isOnTranscation " + budsC301.isOnTranscation());
                    }
                }
                if (budsC306 != null) {
                    try {
                        budsC306.close();
                    } catch (Exception e) {
                    }
                }
                if (budsC307 != null) {
                    try {
                        budsC307.close();
                    } catch (Exception e) {
                    }
                }
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC3_0040_MSG_001"));//�����T�{����

            try {
                this.queryM("", req.getParameter("ACNT_TYPE"), SLIP_LOT_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�����T�{�������d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00780");//�@�~����
                }
            }
        } catch (Exception e) {
            log.error("�����T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0040_MSG_004");//�����T�{����
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {

        try {
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("getCheck"));
            String SLIP_LOT_NO = req.getParameter("SLIP_LOT_NO");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            //Callú�ڱb�ȽT�{�ˮּҲ�.�b�Ȥ��
            //new EPC3_0040_mod().checkAMT(reqList);
            EPC3_0040_mod theEPC3_0040_mod = new EPC3_0040_mod();
            //�ˮ֬O�_�Vú
            theEPC3_0040_mod.checkACNT_DATE(reqList, "0", SUB_CPY_ID);

            //Callú�ڱb�ȽT�{���@�Ҳ�.�T�{�@�~��k
            Transaction.setXAMode();
            Transaction.begin();
            //�}XAmode,�Ҳդ����ϥΨ�buds,�ѥD�{���ǤJ,transaction.commit��A����
            //budsArray = [C301,C306,C307]
            BatchUpdateDataSet budsC301 = Transaction.getBatchUpdateDataSet();
            BatchUpdateDataSet budsC306 = Transaction.getBatchUpdateDataSet();
            BatchUpdateDataSet budsC307 = Transaction.getBatchUpdateDataSet();
            budsC306.setDataSet(budsC301);
            budsC307.setDataSet(budsC301);
            BatchUpdateDataSet[] budsArray = new BatchUpdateDataSet[] { budsC301, budsC306, budsC307 };
            try {
                new EP_C30040().doConfirm(reqList, user, req.getParameter("ACNT_TYPE"), SLIP_LOT_NO, SUB_CPY_ID, budsArray);
                Transaction.commit();
            } catch (Exception e) {
                log.debug("Error Log:" + e, e);
                Transaction.rollback();
                throw e;
            } finally {
                if (budsC301 != null) {
                    try {
                        budsC301.close();
                    } catch (Exception e) {
                        log.fatal("budsC301.close ", e);
                        log.fatal("budsC301.isAutoTransaction " + budsC301.isAutoTransaction());
                        log.fatal("budsC301.isOnTranscation " + budsC301.isOnTranscation());
                        try {
                            budsC301.endTransaction();
                        } catch (Exception e1) {
                            log.fatal("budsC301.endTransaction ", e);
                        }

                    }
                }
            }
            String date = DATE.getDBDate();
            resp.addOutputData("SYS_DATE", date);
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC3_0040_MSG_002"));//�T�{����

            try {
                this.queryM(date, req.getParameter("ACNT_TYPE"), SLIP_LOT_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�T�{�������d�L���", e);
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00780");//�@�~����
                }
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC3_0040_MSG_005");//�T�{����
        }

        return resp;
    }

    /**
     * �p��[�`
     * @param req
     * @return
     * @throws ModuleException 
     * @throws ModuleException
     */
    public ResponseContext doCount(RequestContext req) throws ModuleException {

        List<Map> selectedBox = VOTool.jsonAryToMaps(req.getParameter("selectedBox"));
        BigDecimal SUM_CSH_AMT = BigDecimal.ZERO;
        BigDecimal SUM_MAL_AMT = BigDecimal.ZERO;
        BigDecimal SUM_RMT_AMT = BigDecimal.ZERO;
        BigDecimal SUM_CHK_AMT = BigDecimal.ZERO;
        BigDecimal SUM_TKD_AMT = BigDecimal.ZERO;
        BigDecimal SUM_ACNT_AMT = BigDecimal.ZERO;
        BigDecimal SUM_KIND_1_AMT = BigDecimal.ZERO;
        BigDecimal SUM_KIND_2_AMT = BigDecimal.ZERO;
        BigDecimal SUM_KIND_3_AMT = BigDecimal.ZERO;
        BigDecimal SUM_TMP_AMT = BigDecimal.ZERO;
        BigDecimal SUM_TMP_AMT_FORG002 = BigDecimal.ZERO;//�wú�J�Ȧ�
        Set<String> PAY_NO_Set = new HashSet<String>();

        for (Map map : selectedBox) {
            String PAY_NO = MapUtils.getString(map, "PAY_NO");
            String ISFROM = MapUtils.getString(map, "ISFROM");
            String PAY_KIND = MapUtils.getString(map, "PAY_KIND");
            BigDecimal PAY_AMT1 = getDecimal(map.get("PAY_AMT1"));
            if ("C301".equals(ISFROM)) {
                if ("1".equals(PAY_KIND)) {
                    SUM_KIND_1_AMT = SUM_KIND_1_AMT.add(PAY_AMT1);
                } else if ("2".equals(PAY_KIND)) {
                    SUM_KIND_2_AMT = SUM_KIND_2_AMT.add(PAY_AMT1);
                } else if ("3".equals(PAY_KIND)) {
                    SUM_KIND_3_AMT = SUM_KIND_3_AMT.add(PAY_AMT1);
                } else {
                    SUM_KIND_1_AMT = SUM_KIND_1_AMT.add(PAY_AMT1);
                }
            } else if ("G002".equals(ISFROM)) {
                SUM_TMP_AMT_FORG002 = SUM_TMP_AMT_FORG002.add(PAY_AMT1);
            }
            if (PAY_NO_Set.contains(PAY_NO)) {
                continue;
            }

            SUM_CSH_AMT = SUM_CSH_AMT.add(getDecimal(map.get("CSH_AMT")));
            SUM_MAL_AMT = SUM_MAL_AMT.add(getDecimal(map.get("MAL_AMT")));
            SUM_RMT_AMT = SUM_RMT_AMT.add(getDecimal(map.get("RMT_AMT")));
            SUM_CHK_AMT = SUM_CHK_AMT.add(getDecimal(map.get("CHK_AMT")));
            SUM_TKD_AMT = SUM_TKD_AMT.add(getDecimal(map.get("TKD_AMT")));
            SUM_ACNT_AMT = SUM_ACNT_AMT.add(getDecimal(map.get("ACNT_AMT")));
            SUM_TMP_AMT = SUM_TMP_AMT.add(getDecimal(map.get("TMP_AMT")));

            PAY_NO_Set.add(PAY_NO);

        }
        resp.addOutputData("SUM_CSH_AMT", SUM_CSH_AMT);
        resp.addOutputData("SUM_MAL_AMT", SUM_MAL_AMT);
        resp.addOutputData("SUM_RMT_AMT", SUM_RMT_AMT);
        resp.addOutputData("SUM_CHK_AMT", SUM_CHK_AMT);
        resp.addOutputData("SUM_TKD_AMT", SUM_TKD_AMT);
        resp.addOutputData("SUM_ACNT_AMT", SUM_ACNT_AMT);
        resp.addOutputData("SUM_TMP_AMT", SUM_TMP_AMT);
        resp.addOutputData("SUM_KIND_1_AMT", SUM_KIND_1_AMT);
        resp.addOutputData("SUM_KIND_2_AMT", SUM_KIND_2_AMT);
        resp.addOutputData("SUM_KIND_3_AMT", SUM_KIND_3_AMT);
        resp.addOutputData("SUM_TMP_AMT_FORG002", SUM_TMP_AMT_FORG002);
        return resp;
    }

    /**
     * �d��
     * @param PAY_NO
     * @throws ModuleException 
     * @throws SQLException 
     */
    private void queryM(String ACNT_DATE, String ACNT_TYPE, String SLIP_LOT_NO, String SUB_CPY_ID) throws ModuleException, SQLException {

        //Callú�ڱb�ȽT�{���@�Ҳ�.���oú�O���p�����M���k
        //log.fatal("QUERY START=====>"+DATE.currentTime());
        List<Map> rtnList = new EP_C30040().queryPayRltInfoList(user.getOpUnit(), SLIP_LOT_NO, user.getEmpID(), ACNT_DATE, ACNT_TYPE,
            SUB_CPY_ID);
        //log.fatal("QUERY END=====>"+DATE.currentTime());
        int i;
        List<Map> rtnListAll = new ArrayList();

        List<Map> logSecurityList = new ArrayList();
        for (Map map : rtnList) {
            List<Map> PAY_RLT_LIST = (List<Map>) map.get("RLT_INFO_LIST");
            i = 1;
            for (Map PAY_RLT_map : PAY_RLT_LIST) {
                Map mapNEW = new HashMap();
                mapNEW.put("ACNT_INFO", map.get("ACNT_INFO"));
                mapNEW.put("PAY_NO", map.get("PAY_NO"));
                mapNEW.put("PAY_AMT", map.get("PAY_AMT"));
                mapNEW.put("CSH_AMT", map.get("CSH_AMT"));
                mapNEW.put("CHK_AMT", map.get("CHK_AMT"));
                mapNEW.put("RMT_AMT", map.get("RMT_AMT"));
                mapNEW.put("MAL_AMT", map.get("MAL_AMT"));
                mapNEW.put("ACNT_AMT", map.get("ACNT_AMT"));
                mapNEW.put("TKD_AMT", map.get("TKD_AMT"));
                mapNEW.put("TMP_AMT", map.get("TMP_AMT"));
                mapNEW.put("CHG_DATE", map.get("CHG_DATE"));
                mapNEW.put("TMP_NO", map.get("TMP_NO"));
                mapNEW.put("CHK_SET_NO", map.get("CHK_SET_NO"));
                mapNEW.put("RMT_SET_NO", map.get("RMT_SET_NO"));
                mapNEW.put("ACNT_SET_NO", map.get("ACNT_SET_NO"));
                mapNEW.put("DTMP_NO", map.get("DTMP_NO"));
                mapNEW.put("ACNT_SET_NO", map.get("ACNT_SET_NO"));

                mapNEW.put("PAY_KIND", PAY_RLT_map.get("PAY_KIND"));
                mapNEW.put("RCV_YM", "00000".equals(PAY_RLT_map.get("RCV_YM").toString()) ? "" : PAY_RLT_map.get("RCV_YM"));
                mapNEW.put("RCV_NO", PAY_RLT_map.get("RCV_NO"));
                mapNEW.put("CRT_NO", PAY_RLT_map.get("CRT_NO"));
                mapNEW.put("CUS_NO", PAY_RLT_map.get("CUS_NO"));
                mapNEW.put("CUS_NAME", PAY_RLT_map.get("CUS_NAME"));
                mapNEW.put("PAY_KIND_NM", PAY_RLT_map.get("PAY_KIND_NM"));
                mapNEW.put("PAY_AMT1", PAY_RLT_map.get("PAY_AMT"));
                mapNEW.put("ISFROM", PAY_RLT_map.get("ISFROM"));
                mapNEW.put("BLD_CD", PAY_RLT_map.get("BLD_CD"));
                mapNEW.put("SUB_CPY_ID", PAY_RLT_map.get("SUB_CPY_ID"));
                mapNEW.put("SEQ_NO", i++);

                rtnListAll.add(mapNEW);

                Map logSecurityMap = new HashMap();
                logSecurityMap.put("CUS_NAME", PAY_RLT_map.get("CUS_NAME"));
                logSecurityList.add(logSecurityMap);

            }

        }
        logSecurity(logSecurityList);
        resp.addOutputData("rtnList", rtnListAll);
    }

    /**
     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }

        if (BigDecimal.class.isInstance(obj)) {
            return (BigDecimal) obj;
        }

        String str = String.valueOf(obj);

        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }

        return BigDecimal.ZERO;
    }

}