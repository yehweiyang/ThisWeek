package com.cathay.ep.c3.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.c3.module.EPC3_0060_mod;
import com.cathay.ep.c3.module.EP_C30060;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Version  Description  Author
 * 2013/08/27  1.0      Created      ���i��
 * 
 * UCEPC3_0060_�Ȧ��h�O�@�~
 * 
 * �@�B   �{���\�෧�n�����G
 * �{���\��    �Ȧ��h�O�@�~
 * �{���W��    EPC3_0600
 * �@�~�覡    ONLINE
 * ���n����    (1) �d�ߡG�d�ߤ��ʲ��Ȧ���ơC
 *             (2) ��J�G��J�R�Ȧ���ơC
 *             (3) �簣�G�R���R�Ȧ���ơC
 * 
 *</pre>
 *
 * [20180221] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * 
 * @author ���_��
 * @since 2013/11/18
 */
@SuppressWarnings("unchecked")
public class EPC3_0060 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC3_0060.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC2_2040_ERRMSG_001");//���o�����q�O����
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMap"));

            this.queryM(reqMap);

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC3_0060_UI_001"));//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPC3_0060_UI_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC3_0060_UI_003"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC3_0060_UI_004"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPC3_0060_UI_004"), e);//�d�ߥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC3_0060_UI_004"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * ��J
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));

            new EPC3_0060_mod().checkInsert(reqMap);
            Transaction.setXAMode();
            Transaction.begin();
            try {
                reqMap.put("USER_ID", user.getEmpID());
                reqMap.put("USER_NAME", user.getEmpName());
                reqMap.put("USER_DIV_NO", user.getOpUnit());
                reqMap.put("USER_DIV_NAME", user.getDivShortName());

                new EP_C30060().insert(reqMap);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC3_0060_UI_005"));//��J����

            //�d��
            try {
                this.queryM(reqMap);
            } catch (ModuleException me) {
                log.error("��J���\�A�����d�L���", me);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPC3_0060_UI_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0060_UI_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("��J����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC3_0060_UI_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �簣
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapInsert"));
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            Transaction.setXAMode();
            Transaction.begin();
            try {
                /* [20180221] ��I�sEP_C30060 */
                new EP_C30060().delete(reqMap);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC3_0060_UI_008"));//�簣����

            //�d��
            try {
                this.queryM(reqMap);
            } catch (ModuleException me) {
                log.error("�簣���\�A�����d�L���", me);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPC3_0060_UI_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC3_0060_UI_006");//�@�~����
            }
        } catch (Exception e) {
            log.error("�簣����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC3_0060_UI_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �d��
     * @param reqMap
     * @throws ModuleException
     */
    private void queryM(Map reqMap) throws ModuleException {
        EP_C30060 EP_C30060 = new EP_C30060();
        //�d�߼Ȧ��h�O���.
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
        String QUERY_TYPE = MapUtils.getString(reqMap, "QUERY_TYPE");
        List<Map> dataList = EP_C30060.query(CRT_NO, CUS_NO, QUERY_TYPE, SUB_CPY_ID, MapUtils.getString(reqMap, "DACNT_DATE_S"), MapUtils
                .getString(reqMap, "DACNT_DATE_E"));
        String CUST_NAME = EP_C30060.queryCustName(CRT_NO, CUS_NO, SUB_CPY_ID);
        int SER_NO = 0;//�y����
        StringBuilder sb = new StringBuilder();
        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map map : dataList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("CUS_NAME", map.get("CUS_NAME"));
            logSecurityMap.put("ID", map.get("ID"));
            logSecurityList.add(logSecurityMap);

            String POLICY_NO = MapUtils.getString(map, "POLICY_NO");
            String PAY_TIMES = MapUtils.getString(map, "PAY_TIMES");
            map.put("SER_NO", ++SER_NO);
            map.put("POLICY_NO", sb.append(POLICY_NO).append("-").append(PAY_TIMES).toString());
            map.put("CRT_NO", CRT_NO);
            sb.setLength(0);
        }
        logSecurity(logSecurityList);
        resp.addOutputData("rtnList", dataList);
        resp.addOutputData("CUST_NAME", CUST_NAME);

    }
}