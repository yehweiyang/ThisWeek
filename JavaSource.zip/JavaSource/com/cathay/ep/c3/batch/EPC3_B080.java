package com.cathay.ep.c3.batch;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.BatchConstructor.Options;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.dd.b0.module.DD_B0Z018;
import com.cathay.dd.e0.module.DD_E0Z003;
import com.cathay.ep.c0.module.EP_C0Z001;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.util.DateUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/** 
 * <pre>
 * Date    Version Description Author
 * 2017/10/27  1.0 Created ����[
 * 2018/01/29   1.1      �վ�o���~�W�榡         ����[
 * 2018/12/26   �ק�H��PMD�W�h
 * 2020/03/27   �q�l�o��������T(email/���㸹�X)
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �q�l�o����Ʃ��ɧ@�~
 * �{���W��    EPC3_B080.java
 * �@�~�覡    BATCH
 * ���n����    ����q�l�o���ɦ�DTDDE003�C
 * �w����ƶq  3000
 * �@�~�W��    JAEPDC308
 * �~�ȧO EP
 * ���t�ΦW��   C3
 * �B�z�g��    �C��
 * ����B�z���  �w�]��
 * 
 * </pre>
 * @author �_�§� 
 * @since 2017/11/23  
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC3_B080 extends EP_BatchBean {

    private static final Logger log = Logger.getLogger(EPC3_B080.class);

    private static final String SQL_query_001 = "com.cathay.ep.c3.batch.EPC3_B080.SQL_query_001";

    private static final String SQL_update_001 = "com.cathay.ep.c3.batch.EPC3_B080.SQL_update_001";

    public void execute(String[] args) throws Exception {

        final BatchConstructor bc = new BatchConstructor("JAEPDC308", "EPC3_B080", "��");

        try {
            final String SUB_CPY_ID; //�����q�O
            final String INV_DATE; //�o���}�ߤ�
            final String INVOICE_NO;//�o�����X
            final Timestamp current_time = DATE.currentTime();

            try {
                StringBuilder sb = new StringBuilder();
                //�Ѽ��ˮ�
                if (args == null || args.length == 0) {
                    throw new ErrorInputException("���ǤJ�����q�O���");
                } else {

                    SUB_CPY_ID = args[0];
                    sb.append("�ǤJ�����q�O�G").append(SUB_CPY_ID);

                    if (args.length > 1) {
                        String param2 = args[1];
                        if (!DATE.isDate(param2) && param2 != null) {
                            throw new ErrorInputException("�B�z����榡���~�]INV_DATE�^��" + param2);
                        } else {
                            sb.append("�F�ǤJ�B�z����G").append(param2);
                            INV_DATE = param2;
                        }
                    } else {
                        INV_DATE = DateUtil.getSystemDate();
                        sb.append("�F���ǤJ�B�z����A�w�]�B�z��G").append(INV_DATE);
                    }

                    if (args.length > 2) {
                        String param3 = args[2];
                        INVOICE_NO = param3;
                        sb.append("�F�ǤJ�o�����X�G").append(INVOICE_NO);
                    } else {
                        INVOICE_NO = null;
                        sb.append("�F���ǤJ�o�����X");
                    }
                }

                log.fatal(sb.toString());
                sb.setLength(0);

            } catch (Exception e) {
                setExitCode(ERROR);
                log.fatal("�Ѽƿ��~", e);
                return;

            }

            Options options = bc.getOptions();
            options.setTerminated(true);
            bc.execute(new BatchConstructor.DataBaseHandler() {

                private List<Map> E003List = new ArrayList<Map>();

                private String TrnDate = DateUtil.getSystemDate();

                private String INV_NO = INVOICE_NO;

                BatchUpdateDataSet buds_update = bc.getBatchUpdateDataSet(SQL_update_001, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                DD_E0Z003 theDD_E0Z003 = new DD_E0Z003();

                EP_C0Z001 theEP_C0Z001 = new EP_C0Z001();

                Map PIN_NAMEmap = new HashMap();

                StringBuilder sb = new StringBuilder();

                @Override
                protected boolean searchProcess(BatchQueryDataSet bqds) throws DBException {

                    bqds.setField("START_YM", FieldOptionList.getName("EP", "ELE_INV", "START_YM"));
                    bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    bqds.setField("INV_DATE", INV_DATE);
                    if (StringUtils.isNotBlank(INV_NO)) {
                        bqds.setField("INV_NO", INV_NO);
                    }
                    bqds.searchAndRetrieve(SQL_query_001);
                    int totalQueryCount = bqds.getTotalCount();
                    if (totalQueryCount == 0) {
                        log.fatal("�d�L���ʲ��q�l�o������");
                        return false;
                    }

                    //�~�W�M��
                    List<Map> PIN_CODE_LIST = null;
                    try {
                        PIN_CODE_LIST = new DD_B0Z018().queryDtddb070("");
                    } catch (ModuleException e) {
                        log.fatal("���o�~�W�M�榳�~,�������`");
                        //e.printStackTrace();//181226:�ק�H��PMD�W�h
                    }
                    //�~�W�N�X/����
                    if (PIN_CODE_LIST != null) {
                        for (Map mp : PIN_CODE_LIST) {
                            PIN_NAMEmap.put(MapUtils.getString(mp, "PIN_CODE", ""), MapUtils.getString(mp, "PIN_NAME", ""));
                        }
                    }

                    return true;
                }

                @Override
                protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {

                    Map TMP_Map = new HashMap();
                    //�ץ�����
                    TMP_Map.put("CASE_TYPE", "A");
                    //�ץ�i��
                    TMP_Map.put("CASE_STATUS", "A");

                    //�~�W,����
                    //�~�W�����榡�վ�
                    theEP_C0Z001.getPIN_NAMEForPrint(VOTool.dataSetToMap(bqds), TMP_Map, sb, PIN_NAMEmap);

                    //�γ~�O
                    TMP_Map.put("USE_TYPE", "EP1");
                    //�o���B�z�覡
                    String TRANS_TYPE = ObjectUtils.toString(bqds.getField("TRANS_TYPE"));
                    if (StringUtils.isNotBlank(TRANS_TYPE)) {
                        TMP_Map.put("TRANS_TYPE", TRANS_TYPE);
                    } else {
                        TMP_Map.put("TRANS_TYPE", "A");
                    }
                    //�o���B�z�i��(Y = �w�C�L�A�H�e)
                    if (bqds.getField("PRT_DATE") != null) {
                        TMP_Map.put("TRANS_STATUS", "Y");
                    } else {
                        TMP_Map.put("TRANS_STATUS", "N");
                    }
                    //�q�l�H�c
                    if ("B".equals(TRANS_TYPE)) {
                        //[20200327] �q�l�o��������T(email/���㸹�X)
                        TMP_Map.put("EMAIL", bqds.getField("DEVICE_NO"));
                        TMP_Map.put("DEVICE_TYPE", null);
                        TMP_Map.put("DEVICE_NO", null);
                        TMP_Map.put("DEVICE_CODE", null);
                    }
                    //���㸹�X
                    else if ("C".equals(TRANS_TYPE) || "D".equals(TRANS_TYPE)) {//�ӤH:����/����
                        //[20200327] �q�l�o��������T(email/���㸹�X)
                        String DEVICE_NO = ObjectUtils.toString(bqds.getField("DEVICE_NO"));
                        if (StringUtils.isBlank(DEVICE_NO)) {
                            throw new ModuleException("�ӤH�o��:����s�����i����");
                        }
                        //��������
                        String INV_DEVICE_TYPE = DEVICE_NO.substring(0, DEVICE_NO.indexOf(":"));
                        //����N��
                        if("C".equals(TRANS_TYPE)) {
                            String INV_DEVICE_NO = DEVICE_NO.substring(DEVICE_NO.indexOf(":") + 1);
                            TMP_Map.put("DEVICE_TYPE", INV_DEVICE_TYPE);
                            TMP_Map.put("DEVICE_NO", INV_DEVICE_NO);
                        }else {
                            TMP_Map.put("DEVICE_NO", DEVICE_NO);
                        }
                        //�������O���X
                        if ("B".equals(INV_DEVICE_TYPE)) {
                            TMP_Map.put("DEVICE_CODE", "3J0002");//���
                        } else {
                            TMP_Map.put("DEVICE_CODE", "CQ0001");//�۵M�H
                        }
                        TMP_Map.put("EMAIL", null);
                    } else {
                        TMP_Map.put("EMAIL", null);
                        TMP_Map.put("DEVICE_TYPE", null);
                        TMP_Map.put("DEVICE_NO", null);
                        TMP_Map.put("DEVICE_CODE", null);
                    }

                    //�o�����B
                    TMP_Map.put("AMT", bqds.getField("INV_AMT"));
                    //�o���|�B
                    TMP_Map.put("TAX_AMT", bqds.getField("TAX_AMT"));
                    //�ӫ~���|���B
                    TMP_Map.put("PROD_AMT", bqds.getField("SAL_AMT"));
                    //�o���l�B
                    TMP_Map.put("BAL_AMT", bqds.getField("INV_AMT"));
                    //�o�����O
                    TMP_Map.put("INV_YM", bqds.getField("RCV_YM"));
                    //�o�����X
                    String INV_NO = ObjectUtils.toString(bqds.getField("INV_NO"));
                    TMP_Map.put("INV_NO", INV_NO);
                    //�o���ɶ�
                    TMP_Map.put("INV_TS", ObjectUtils.toString(bqds.getField("INV_DATE")) + " 00:00:00.000000");
                    //�o�����O�C��
                    TMP_Map.put("RANDOM_NO", bqds.getField("CHK_NO"));
                    //�o�����O�C��
                    TMP_Map.put("INV_TP", "07");
                    //�ҵ|�O�C��
                    String TAX_TYPE = ObjectUtils.toString(bqds.getField("TAX_TYPE"));
                    if ("1".equals(TAX_TYPE) || "2".equals(TAX_TYPE)) {
                        TMP_Map.put("TAX_TP", "1");//���|
                    } else if ("3".equals(TAX_TYPE)) {
                        TMP_Map.put("TAX_TP", "2");//�s�|�v
                    } else if ("4".equals(TAX_TYPE)) {
                        TMP_Map.put("TAX_TP", "3");//�K�|
                    }
                    //�|�v
                    if ("1".equals(TAX_TYPE) || "2".equals(TAX_TYPE)) {
                        TMP_Map.put("TAX_RATE", "5");//���|
                    } else {
                        TMP_Map.put("TAX_RATE", "0");//�s�|�v�A�K�|
                    }
                    //���W��
                    TMP_Map.put("SELLER_NM", "����H��");
                    //���νs
                    TMP_Map.put("SELLER_BAN", "03374707");
                    //�R��W��
                    TMP_Map.put("BUYER_NM", bqds.getField("CUS_NAME"));
                    //�R��νs
                    String INV_TYPE = ObjectUtils.toString(bqds.getField("INV_TYPE"));
                    if ("A".equals(INV_TYPE)) {
                        TMP_Map.put("BUYER_BAN", ObjectUtils.toString(bqds.getField("ID")));//B2B
                    } else {
                        TMP_Map.put("BUYER_BAN", "");//B2C
                    }
                    //�b�Ȥ��/�ǲ����
                    TMP_Map.put("ACNT_DATE", bqds.getField("ACNT_DATE"));
                    //�帹
                    TMP_Map.put("SLIP_LOT_NO", bqds.getField("SLIP_LOT_NO"));
                    //�ո�
                    TMP_Map.put("SLIP_SET_NO", bqds.getField("SLIP_SET_NO"));
                    //�g�����Ǹ�
                    TMP_Map.put("TRN_SER_NO", bqds.getField("TRN_SER_NO"));
                    //���O
                    TMP_Map.put("CE_CURR_TYPE", "NTD");
                    //����
                    TMP_Map.put("CE_DIV_NO", STRING.objToStr(bqds.getField("SLIP_DIV_NO")).substring(0, 5));
                    //�ǲ��Ǹ�
                    TMP_Map.put("CE_SLPSEQ_NO", bqds.getField("SLIP_SEQ_NO"));
                    //�ӷ��s��(�ӷ�PK)
                    TMP_Map.put("EPKEY", bqds.getField("PRE_KEY"));
                    //�@�~�H��ID
                    TMP_Map.put("OPR_ID", bqds.getField("CHG_ID"));
                    //�@�~�H���m�W
                    TMP_Map.put("OPR_NAME", bqds.getField("CHG_NAME"));
                    //�@�~�ӽг��
                    TMP_Map.put("OPR_DIV_NO", bqds.getField("CHG_DIV_NO"));
                    //�@�~�ɶ�
                    TMP_Map.put("OPR_TS", current_time);
                    //�b�ȽT�{�H��ID
                    TMP_Map.put("ACNT_CFM_ID", bqds.getField("ACNT_ID"));
                    //�b�ȽT�{�H���m�W
                    TMP_Map.put("ACNT_CFM_NAME", bqds.getField("ACNT_NAME"));
                    //�b�ȽT�{���
                    TMP_Map.put("ACNT_CFM_DIV_NO", bqds.getField("ACNT_DIV_NO"));
                    //�b�ȽT�{�ɶ�
                    TMP_Map.put("ACNT_CFM_TS", bqds.getField("ACNT_DATE"));

                    E003List.add(TMP_Map);
                    buds_update.setField("APLY_DATE", TrnDate);
                    buds_update.setField("INV_NO", INV_NO);
                    addBatchAndJoinGroup(buds_update);
                }

                @Override
                protected void executeBatchProcess() throws Exception {

                    //�}�_�������
                    buds_update.beginTransaction();

                    DataSet ds = Transaction.getDataSet();
                    ds.setConnName("DS_DD");
                    ds.beginTransaction();

                    try {
                        //��sDTEPC202.APLY_DATE
                        try {
                            buds_update.executeBatch();
                        } catch (Exception e) {
                            log.fatal("#### ��s�o���ɴC�������~:" + e);
                            throw e;
                        }
                        //�g�JDTDDE003
                        try {
                            theDD_E0Z003.insertEP_INV(E003List, ds);
                        } catch (Exception e) {
                            log.fatal("#### �g�JDTDDE003�o���ɿ��~:" + e);
                            throw e;
                        }

                        buds_update.endTransaction();
                        ds.endTransaction();
                    } catch (Exception e) {

                        buds_update.rollbackTransaction();
                        ds.rollbackTransaction();

                        setExitCode(ERROR);
                        throw e;

                    } finally {
                        E003List.clear();
                    }

                }
            });

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("����ɵo�Ϳ��~", e);

        } finally {
            int batchConstructorExitCode = bc.getExitCode();
            if (batchConstructorExitCode != OK) {
                setExitCode(batchConstructorExitCode);
            }
            printExitCode(getExitCode()); //�^�ǵ� Control_M ���T���N�X , �{���פ�
        }

    }
}