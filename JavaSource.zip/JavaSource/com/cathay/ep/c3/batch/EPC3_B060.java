package com.cathay.ep.c3.batch;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.DATE;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchProcesser;
import com.cathay.common.util.batch.CountManager;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.batch.ErrorLog;
import com.cathay.common.util.batch.GroupHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.common.util.validate.ValidateUtil;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.util.Transaction;
import com.cathay.util.TransactionHelper.Platform;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/** 
 * <pre>
 * Date    Version Description Author
 * 2014/1/13   1.0 CREATE  ���|��
 * 2014/2/27   1.1 �W�[���ʲ��C��P���o��PASS��~�|DBDD.DTDDB150 ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �o����Ʃ��ɧ@�~
 * �{���W��    EPC3_B060.java
 * �@�~�覡    BATCH
 * ���n����    1.  ���IFRS���u�k�������o����Ʀ�DTEPC205IFRS�o���ɡC
 * 2.  ����o����Ʀ���~�|�t��
 * �w����ƶq   3000
 * �@�~�W��    JAEPDC306
 * �~�ȧO EP
 * ���t�ΦW��   C3
 * �B�z�g��    �C�Ӥ�1��
 * ����B�z���  �w�]��
 * 
 * </pre>
 * @author �¶��� 
 * @since 2014/3/18  
 */
@SuppressWarnings("unchecked")
public class EPC3_B060 extends EP_BatchBean { //�~��BatchBean

    private static final Logger log = Logger.getLogger(EPC3_B060.class); //log

    private static final String JOB_NAME = "JAEPDC306"; //�@�~�W��

    private static final String PROGRAM = "EPC3_B060"; //�{���W��

    private static final String BUSINESS = "EP"; //�~�ȧO

    private static final String SUBSYSTEM = "C3"; //���t�ΦW��

    private static final String PERIOD = "��"; //����g��

    //�]�� true �Ѥ����O�p�Ƥμg���~�T��, false �Шϥ� ErrorLog ��CountManager �ۦ�g���~�T���έp��
    private static final boolean isAUTO_WRITELOG = false;

    private static final String INPUT_COUNT1 = "IFRS�o���B�z���";

    private static final String OUTPUT_COUNT1 = "IFRS�o����s���";

    private static final String ERROR_COUNT1 = "IFRS�o�����~���";

    private static final String INPUT_COUNT2 = "DTEPC202Ū�����";

    private static final String OUTPUT_COUNT2 = "DTDDB150�s�W���";

    private static final String ERROR_COUNT2 = "DTDDB150�s�W���ѥ��";

    private static final String ERROR_COUNT = "���~���";

    /**�d�ߪ�����*/
    private BatchQueryDataSet bqds;

    private BatchUpdateDataSet buds_INSERT_DTEPC205;

    private BatchUpdateDataSet buds_INSERT_DTDDB150;

    /** �M�����O�@�Τ����~�T���O������ */
    private ErrorLog errorLog;

    /**�p�ƾ�*/
    private CountManager countManager;

    /**�̿��~���h�Ũ��o���~�����*/
    private ErrorHandler errorHandler;

    /**�P�@�妸�h�� table ���� , �������~����� , �ñN���T����Ƽg�J*/
    private GroupHandler groupHandler;

    /**���s����*/
    private BatchProcesser batchProcesser;

    private StringBuilder sb;

    private Timestamp CURRENT_TIME;

    private static final String tableNameDTEPC205 = "IFRS�o���ɡ]DTEPC205�^";

    private static final String tableNameDTDDB150 = "���ʲ��P�����ӼȦs�� �]DTDDB150�^";

    private static final String actionNameByInsert = "�s�W";

    private static final String SQL_query_001 = "com.cathay.ep.c3.batch.EPC3_B060.SQL_query_001";

    private static final String SQL_query_002 = "com.cathay.ep.c3.batch.EPC3_B060.SQL_query_002";

    private static final String SQL_insert_001 = "com.cathay.ep.c3.batch.EPC3_B060.SQL_insert_001";

    private static final String SQL_insert_002 = "com.cathay.ep.c3.batch.EPC3_B060.SQL_insert_002";

    private static final String SQL_delete_001 = "com.cathay.ep.c3.batch.EPC3_B060.SQL_delete_001";

    public EPC3_B060() throws Exception {

        //�]�w�����O���غc�l,�ǤJ true �Ѥ����O�p�Ƥμg���~�T��
        super(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isAUTO_WRITELOG);

        //���~�T���O������
        countManager = new CountManager(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD);

        errorLog = new ErrorLog(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM);

        errorHandler = new ErrorHandler();

        sb = new StringBuilder();
        CURRENT_TIME = DATE.currentTime();

        groupHandler = new GroupHandler();
        batchProcesser = new BatchProcesser();

        initCountManager();

        bqds = getBatchQueryDataSet();

    }

    public void execute(String args[]) throws Exception { //����妸�@�~      

        try {

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMM");
            String STR_ACNT_DATE; //�b�Ȱ_��
            String END_ACNT_DATE; //�b�Ȩ���
            String RCV_YM;//�����~��
            String ACT_TYPE;//�������O
            String INVOICE_NO;//�o�����X

            try {
                String ACNT_YYYYMM;//�b�Ȧ~��
                //�Ѽ��ˮ�
                if (args != null && args.length > 0) {

                    ErrorInputException eie = null;
                    if (StringUtils.isNotBlank(args[0])) {
                        ACT_TYPE = args[0];
                        if (!("1".equals(ACT_TYPE) || "2".equals(ACT_TYPE))) {
                            sb.append("�������O���~�]ACT_TYPE�^��").append(ACT_TYPE).append("�A���ǤJ1��2");
                            eie = this.getErrorInputException(eie, sb.toString());
                            sb.setLength(0);
                        }
                    } else {
                        ACT_TYPE = null;
                    }

                    if (args.length > 1 && StringUtils.isNotBlank(args[1])) {
                        ACNT_YYYYMM = args[1];
                        if (!checkYM(ACNT_YYYYMM)) {
                            sb.append("�b�Ȧ~�릳�~�]ACNT_YYYYMM�^��").append(ACNT_YYYYMM).append("�A�DyyyyMM�榡");
                            eie = this.getErrorInputException(eie, sb.toString());
                            sb.setLength(0);
                        }
                    } else {
                        ACNT_YYYYMM = null;
                    }

                    if (args.length > 2 && StringUtils.isNotBlank(args[2])) {
                        INVOICE_NO = args[2];
                    } else {
                        INVOICE_NO = null;
                    }

                    if (eie != null) {
                        throw eie;
                    }

                } else {
                    ACT_TYPE = null;
                    ACNT_YYYYMM = null;
                    INVOICE_NO = null;
                }

                Calendar cal = Calendar.getInstance();
                if (StringUtils.isNotBlank(ACNT_YYYYMM)) {
                    cal.setTime(sdf2.parse(ACNT_YYYYMM));
                } else {
                    cal.add(Calendar.MONTH, -1);//���W�Ӥ�
                }

                cal.set(Calendar.DATE, cal.getActualMinimum(Calendar.DATE));//����Ĥ@��
                STR_ACNT_DATE = sdf.format(cal.getTime());
                RCV_YM = sdf2.format(cal.getTime());
                cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));//����̫�@��
                END_ACNT_DATE = sdf.format(cal.getTime());

            } catch (Exception e) {
                String memo = "�Ѽƿ��~";
                log.fatal(memo, e);
                errorLog.addErrorLog(memo, e);
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                countManager.addCountNumber(ERROR_COUNT, errorCount);
                throw e;
            }

            //���IFRS�o�����
            if (StringUtils.isBlank(ACT_TYPE) || "1".equals(ACT_TYPE)) {
                buds_INSERT_DTEPC205 = getBatchUpdateDataSet();
                buds_INSERT_DTEPC205.preparedBatch(SQL_insert_001);

                try {

                    bqds.setField("RNT_END_DATE", "2011-12-31");//IFRS�{�C�l�鬰2012-01-01
                    bqds.setField("STR_ACNT_DATE", STR_ACNT_DATE);
                    bqds.setField("END_ACNT_DATE", END_ACNT_DATE);
                    bqds.setField("RCV_YM", RCV_YM);
                    if (StringUtils.isNotEmpty(INVOICE_NO)) {
                        bqds.setField("INV_NO", INVOICE_NO);
                    } else {
                        bqds.setField("NO_INV_NO", "1");
                    }

                    searchAndRetrieve(bqds, SQL_query_001);

                } catch (Exception e) {
                    String memo = "���IFRS�o����Ʋ��`";
                    log.fatal(memo, e);
                    errorLog.addErrorLog(memo, e);
                    int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                    countManager.addCountNumber(ERROR_COUNT, errorCount);
                    throw e;
                }

                int inputCount = getInputCount();

                if (inputCount == 0) {
                    log.fatal("���IFRS�o����Ƭd�L���");
                    return;
                }

                countManager.addCountNumber(INPUT_COUNT1, inputCount); //�]�w��X���

                for (prepareFetch(); fetchData(bqds); goNext()) { //�������

                    buds_INSERT_DTEPC205.beginTransaction(); //�������}�l

                    try {

                        // �v���B�z
                        while (bqds.next()) {
                            //�N��Ƽg�JDTEPC205 IFRS�o����
                            groupHandler.begin();

                            setBuds_INSERT_DTEPC205_Fields(STR_ACNT_DATE, RCV_YM);
                            buds_INSERT_DTEPC205.addBatch();
                            groupHandler.joinGroup(SQL_insert_001);

                            groupHandler.end();

                        }// while loop end

                        int countByInsertDTEPC205 = executeBatchByBatchUpdateDataSet(actionNameByInsert, buds_INSERT_DTEPC205,
                            SQL_insert_001, tableNameDTEPC205, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                        groupHandler.displayRevomeIndex();

                        //�Y�S�����~�� index �s�b
                        if (groupHandler.isSuccess()) {

                            buds_INSERT_DTEPC205.endTransaction();

                            countManager.addCountNumber(OUTPUT_COUNT1, countByInsertDTEPC205);

                            //�Y�����~�� index �s�b
                        } else {

                            setExitCode(ERROR);

                            buds_INSERT_DTEPC205.rollbackTransaction();

                            buds_INSERT_DTEPC205.beginTransaction();

                            int reDocountByInsertDTEPC205 = reDoBatchByBatchUpdateDataSet(buds_INSERT_DTEPC205, SQL_insert_001);

                            buds_INSERT_DTEPC205.endTransaction();

                            countManager.addCountNumber(OUTPUT_COUNT1, reDocountByInsertDTEPC205);

                        }

                    } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                        buds_INSERT_DTEPC205.rollbackTransaction(); //�^�_��媺�@�~
                        setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
                        log.fatal("�g�JIFRS�o���ɿ��~", e);
                        errorLog.addErrorLog("�g�JIFRS�o���ɿ��~", e);
                        throw e; //�Y�o�Ϳ��~�h�{���X�פ�

                    } finally {

                        groupHandler.clear();
                        //�g�X���~��ưO���� , �C�@�����@��               
                        int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                        //�������~���
                        countManager.addCountNumber(ERROR_COUNT1, errorCount);

                    }

                } //for loop end                

            }

            //����P���o�����PASS��~�|DBDD.DTDDB150
            if (StringUtils.isBlank(ACT_TYPE) || "2".equals(ACT_TYPE)) {

                buds_INSERT_DTDDB150 = getBatchUpdateDataSet(Transaction.getDataSet(Platform.CSR));
                buds_INSERT_DTDDB150.preparedBatch(SQL_insert_002);
                if (StringUtils.isNotEmpty(INVOICE_NO)) {

                    try {
                        DataSet ds = Transaction.getDataSet(Platform.CSR);
                        try {
                            ds.beginTransaction();
                            try {
                                ds.setField("INVOICE_NO", INVOICE_NO);
                                DBUtil.executeUpdate(ds, SQL_delete_001);
                            } catch (DataNotFoundException dnfe) {
                                log.fatal("�R�����T�{��~�|��Ƭd�L��ơA�������`", dnfe);
                            }
                            ds.endTransaction();
                        } catch (Exception e) {
                            ds.rollbackTransaction();
                            throw e;
                        }
                    } catch (Exception e) {
                        setExitCode(ERROR);
                        sb.append("�R�����T�{��~�|��Ƶo�Ϳ��~");
                        sb.append("�F�o�����X(INVOICE_NO) = ").append(INVOICE_NO);
                        String message = sb.toString();
                        sb.setLength(0);
                        log.fatal(message, e);
                        errorLog.addErrorLog(message, e);
                        int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                        countManager.addCountNumber(ERROR_COUNT, errorCount);

                        return;//����
                    }

                }

                try {
                    bqds.clear();
                    bqds.setField("RCV_YM", RCV_YM);
                    if (StringUtils.isNotEmpty(INVOICE_NO)) {
                        bqds.setField("INV_NO", INVOICE_NO);
                    }

                    searchAndRetrieve(bqds, SQL_query_002);

                } catch (Exception e) {
                    String memo = "����P���o����Ʋ��`";
                    log.fatal(memo, e);
                    errorLog.addErrorLog(memo, e);
                    int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                    countManager.addCountNumber(ERROR_COUNT, errorCount);
                    throw e;
                }

                int inputCount = getInputCount();

                if (inputCount == 0) {
                    log.fatal("����P���o���d�L���");
                    return;
                }

                countManager.addCountNumber(INPUT_COUNT2, inputCount); //�]�w��X���

                for (prepareFetch(); fetchData(bqds); goNext()) { //�������

                    buds_INSERT_DTDDB150.beginTransaction(); //�������}�l

                    try {

                        // �v���B�z
                        while (bqds.next()) {

                            groupHandler.begin();

                            setBuds_INSERT_DTDDB150_Fields();
                            buds_INSERT_DTDDB150.addBatch();
                            groupHandler.joinGroup(SQL_insert_002);

                            groupHandler.end();

                        }// while loop end

                        int countByInsertDTDDB150 = executeBatchByBatchUpdateDataSet(actionNameByInsert, buds_INSERT_DTDDB150,
                            SQL_insert_002, tableNameDTDDB150, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                        groupHandler.displayRevomeIndex();

                        //�Y�S�����~�� index �s�b
                        if (groupHandler.isSuccess()) {

                            buds_INSERT_DTDDB150.endTransaction();

                            countManager.addCountNumber(OUTPUT_COUNT2, countByInsertDTDDB150);

                            //�Y�����~�� index �s�b
                        } else {

                            setExitCode(ERROR);

                            buds_INSERT_DTDDB150.rollbackTransaction();

                            buds_INSERT_DTDDB150.beginTransaction();

                            int reDocountByInsertDTDDB150 = reDoBatchByBatchUpdateDataSet(buds_INSERT_DTDDB150, SQL_insert_002);

                            buds_INSERT_DTDDB150.endTransaction();

                            countManager.addCountNumber(OUTPUT_COUNT2, reDocountByInsertDTDDB150);

                        }

                    } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                        buds_INSERT_DTDDB150.rollbackTransaction(); //�^�_��媺�@�~
                        setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
                        log.fatal("���榳�~", e);
                        errorLog.addErrorLog("���榳�~", e);
                        throw e; //�Y�o�Ϳ��~�h�{���X�פ�

                    } finally {

                        groupHandler.clear();
                        //�g�X���~��ưO���� , �C�@�����@��               
                        int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                        //�������~���
                        countManager.addCountNumber(ERROR_COUNT2, errorCount);

                    }

                } //for loop end
            }

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("����ɵo�Ϳ��~", e);

        } finally {

            log.fatal(countManager); //����

            if (countManager != null) {
                countManager.writeLog(); //�g�J��ưO����  
            }

            // �����Ҧ����s�u
            if (bqds != null) {
                bqds.close();
            }
            if (buds_INSERT_DTEPC205 != null) {
                buds_INSERT_DTEPC205.close();
            }

            if (buds_INSERT_DTDDB150 != null) {
                buds_INSERT_DTDDB150.close();
            }

            printExitCode(getExitCode()); //�^�ǵ� Control_M ���T���N�X , �{���פ�
        }
    }

    //  *********************************************** Private Method  ************************************************/
    /**
     * ��l�p��
     * @throws ModuleException
     */
    private void initCountManager() throws ModuleException {

        countManager.createCountType("START");
        countManager.writeLog();
        countManager.clearCountTypeAndNumber();
        countManager.createCountType(INPUT_COUNT1);
        countManager.createCountType(ERROR_COUNT1);
        countManager.createCountType(OUTPUT_COUNT1);
        countManager.createCountType(INPUT_COUNT2);
        countManager.createCountType(ERROR_COUNT2);
        countManager.createCountType(OUTPUT_COUNT2);
        countManager.createCountType(ERROR_COUNT);

    }

    /**
     * �]�w�ǤJ�s�WIFRS�o���ɡ]DTEPC205�^���Ѽ�
     */
    private void setBuds_INSERT_DTEPC205_Fields(String ACTN_STR_DATE, String RCV_YYMM) {

        buds_INSERT_DTEPC205.setField("SUB_CPY_ID", bqds.getField("SUB_CPY_ID"));
        buds_INSERT_DTEPC205.setField("CRT_NO", bqds.getField("CRT_NO"));
        buds_INSERT_DTEPC205.setField("CUS_NO", bqds.getField("CUS_NO"));
        buds_INSERT_DTEPC205.setField("PAY_KIND", bqds.getField("PAY_KIND"));
        buds_INSERT_DTEPC205.setField("INV_NO", bqds.getField("INV_NO"));
        buds_INSERT_DTEPC205.setField("INV_CD", bqds.getField("INV_CD"));
        buds_INSERT_DTEPC205.setField("PAY_S_DATE", bqds.getField("PAY_S_DATE"));
        buds_INSERT_DTEPC205.setField("PAY_E_DATE", bqds.getField("PAY_E_DATE"));
        buds_INSERT_DTEPC205.setField("DIV_NO", bqds.getField("DIV_NO"));
        String slipDate = STRING.objToStr(bqds.getField("SLIP_DATE"));
        buds_INSERT_DTEPC205.setField("SLIP_DATE", bqds.getField("SLIP_DATE", ACTN_STR_DATE));
        if (StringUtils.isEmpty(slipDate)) {
            buds_INSERT_DTEPC205.setField("RCV_YM", RCV_YYMM);
        } else {
            String rcvYM = STRING.objToStr(bqds.getField("RCV_YM"));
            buds_INSERT_DTEPC205.setField("RCV_YM", rcvYM);
        }
        buds_INSERT_DTEPC205.setField("INV_AMT", bqds.getField("INV_AMT"));
        buds_INSERT_DTEPC205.setField("SAL_AMT", bqds.getField("SAL_AMT"));
        buds_INSERT_DTEPC205.setField("TAX_AMT", bqds.getField("TAX_AMT"));
        buds_INSERT_DTEPC205.setField("TAX_TYPE", bqds.getField("TAX_TYPE"));
        buds_INSERT_DTEPC205.setField("RJT_AMT", bqds.getField("RJT_AMT"));
        buds_INSERT_DTEPC205.setField("PRE_PAY_AMT", bqds.getField("PRP_SP_AMT"));
        buds_INSERT_DTEPC205.setField("CHK_TYPE", "");
        buds_INSERT_DTEPC205.setField("RSN_CODE", "");
        buds_INSERT_DTEPC205.setField("INPUT_DATE", CURRENT_TIME);

    }

    /**
     * �]�w�ǤJ��~�|�P���o���Ȧs�ɡ]DTDDB150�^���Ѽ�
     */
    private void setBuds_INSERT_DTDDB150_Fields() {

        String BUILD_ID = ObjectUtils.toString(bqds.getField("BUILD_ID")).trim();
        String OPERATE_TIME = ObjectUtils.toString(bqds.getField("OPERATE_TIME"));
        String SLIP_SEQ_NO = ObjectUtils.toString(bqds.getField("SLIP_SEQ_NO"));
        String PAY_KIND = ObjectUtils.toString(bqds.getField("PAY_KIND"));
        buds_INSERT_DTDDB150.setField("TYPE_CODE", bqds.getField("TYPE_CODE"));
        buds_INSERT_DTDDB150.setField("YEAR_MONTH", bqds.getField("YEAR_MONTH"));

        //1600719 modified by i9301216 : ��ӤG�T�p���P�_�覡,�ȤT�p��(���q�渹)�ݿ�JBUILD_ID
        String ID_TYPE = ObjectUtils.toString(bqds.getField("ID_TYPE"));
        if (BUILD_ID.length() == 8 && ((StringUtils.isNotBlank(ID_TYPE) && "1".equals(ID_TYPE)) || ValidateUtil.checkCOID(BUILD_ID))) {//�ҥ�������νs>���q�渹
            buds_INSERT_DTDDB150.setField("BUILD_ID", BUILD_ID);//�νs
        } else {
            buds_INSERT_DTDDB150.setField("BUILD_ID", "");//�ӤHID��10�X,�h���
        }
        buds_INSERT_DTDDB150.setField("INVOICE_NO", bqds.getField("INVOICE_NO"));
        buds_INSERT_DTDDB150.setField("INVOICE_AMOUNT", bqds.getField("INVOICE_AMOUNT"));
        buds_INSERT_DTDDB150.setField("LEVY_CODE", bqds.getField("LEVY_CODE"));
        buds_INSERT_DTDDB150.setField("INVOICE_TAX", bqds.getField("INVOICE_TAX"));
        buds_INSERT_DTDDB150.setField("OPERATE_ID", bqds.getField("OPERATE_ID"));
        buds_INSERT_DTDDB150.setField("OPERATE_NAME", bqds.getField("OPERATE_NAME"));
        buds_INSERT_DTDDB150.setField("OPERATE_TIME", StringUtils.isNotBlank(OPERATE_TIME) ? OPERATE_TIME : null);
        Date dSlip_Date;
        if ("6".equals(PAY_KIND)) {
            dSlip_Date = (Date) bqds.getField("SLIP_DATE");
        } else {
            Date INV_DATE = (Date) bqds.getField("INV_DATE");
            if (INV_DATE != null) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(INV_DATE);
                cal.set(Calendar.DATE, cal.getActualMinimum(Calendar.DATE));//����Ĥ@��
                dSlip_Date = new Date(cal.getTimeInMillis());
            } else {
                dSlip_Date = null;
            }
        }
        buds_INSERT_DTDDB150.setField("SLIP_DATE", dSlip_Date);

        buds_INSERT_DTDDB150.setField("SLIP_DIV_NO", bqds.getField("SLIP_DIV_NO"));
        buds_INSERT_DTDDB150.setField("SLIP_SEQ_NO", StringUtils.isNotBlank(SLIP_SEQ_NO) ? SLIP_SEQ_NO : null);
        buds_INSERT_DTDDB150.setField("CONFIRM_TYPE", bqds.getField("CONFIRM_TYPE"));
        buds_INSERT_DTDDB150.setField("PIN_CODE", bqds.getField("PIN_CODE"));

    }

    /**
     * ����妸�ðO����X��ƥB�B�z���~��
     * @param action
     * @param buds
     * @param sql
     * @param tableName
     * @param executeStatusType
     * @return
     * @throws DBException
     */
    private int executeBatchByBatchUpdateDataSet(String action, BatchUpdateDataSet buds, String sql, String tableName, int executeStatusType)
            throws DBException {

        //�^�ǰ��檺���G , �i�Ѧҳ̤U�����N�X��
        int buds_Ret[] = buds.executeBatch();

        //���]���~���}�C
        Object errObject[][] = errorHandler.getErrorArray(buds.getBatchUpdateErrorArray(), buds_Ret, buds.getBatchMapsArray(),
            executeStatusType);

        //executebatch���~�B�z
        //�^�Ǫ����� �� Object[i][3] , 
        //Object[i][0] �N���ĴX�����~ , index �� 0 �}�l ,
        //Object[i][1] �� Map , ���ܿ��~�� key �� value
        //Object[i][2] ��SQLException , �i�� SQLSTATE �� CODE �P�_��ؿ��~
        if (errObject != null && errObject.length > 0) {

            for (int i = 0; i < errObject.length; i++) {

                Map errorDataMap = (Map) errObject[i][1];
                sb.append(action).append(tableName).append("���`");
                if (tableNameDTEPC205.equals(tableName)) {
                    sb.append("�F�����q�O(SUB_CPY_ID) = ").append(errorDataMap.get("SUB_CPY_ID"));
                    sb.append("�B�o�����X(INV_NO) = ").append(errorDataMap.get("INV_NO"));
                    sb.append("�B�J�ɮɶ�(INPUT_DATE) = ").append(errorDataMap.get("INPUT_DATE"));
                } else {
                    sb.append("�o�����X(INVOICE_NO) = ").append(errorDataMap.get("INVOICE_NO"));
                }

                String message = sb.toString();
                sb.setLength(0);

                errorLog.addErrorLog(message, errObject[i][2]);

            }
        }

        //���XaddBatch�������
        int outputCount = buds_Ret.length;

        //�N��X��Ʀ�����Insert�ɵo�ͪ����~
        outputCount -= errObject.length;

        groupHandler.removeIndex(errObject, sql);

        return outputCount;

    }

    /**
     * 
     * @param buds
     * @param sql
     * @return
     * @throws DBException
     */
    private int reDoBatchByBatchUpdateDataSet(BatchUpdateDataSet buds, String sql) throws DBException {

        //���o���T�����
        List redoList = groupHandler.filterExecuteList(buds.getBatchMapsArray(), sql);

        //�]�w redo ���Ѽ�
        batchProcesser.setFields(redoList, buds);

        //���s����
        int output[] = buds.executeBatch();

        return output.length;

    }

    /**
     * ��wEIE���� 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     *  ���Ħ~���ˮ�
     * @param YYYYMM
     * @return
     */
    private boolean checkYM(String YYYYMM) {
        int len = YYYYMM.length();
        if (len < 6) {
            return false;
        }
        StringBuilder sbf = new StringBuilder();
        sbf.append(YYYYMM.substring(0, len - 2)).append("-");
        sbf.append(YYYYMM.substring(len - 2, len)).append("-01");
        String chkDate = sbf.toString();
        sbf.setLength(0);
        return DATE.isDate(chkDate);

    }

}
