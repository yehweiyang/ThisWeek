package com.cathay.ep.c3.batch;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.DATE;
import com.cathay.common.util.batch.CountManager;
import com.cathay.common.util.batch.ErrorLog;
import com.cathay.dg.a0.module.DG_A0Z002;
import com.cathay.dg.vo.DTDGA002;
import com.cathay.dk.f0.bo.DK_F0Z003_bo;
import com.cathay.dk.f0.module.DK_F0Z003;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.util.ReturnCode;
import com.igsapp.db.BatchQueryDataSet;

/**
 * <pre>
 * Date        Version Description                           Author
 * 2013/11/14  1.0     Created                               ���i��
 * 2014/1/17   1.1     ��H�ǻ���r�ɤ覡pass��ƨ�P�@���Y�H�t��  ���i��
 *
 * �@�B    �{���\�෧�n�����G
 * �{���\��    PASS�P�@���Y�H�t��
 * �{���W��    EPC3_B050.java
 * �@�~�覡    BATCH
 * ���n����    �N�C��b���ʲ��t�Φ��������B���ú�O��������PASS���P�@���Y�H�t�ΡC
 * �w����ƶq   500
 * �@�~�W��    JAEPDC305
 * �~�ȧO EP
 * ���t�ΦW��   C3
 * �B�z�g��    �C�u�@��  21�G00
 * ����B�z���  �w�]��
 * </pre>
 * @author ���_��
 * @since 2014/1/20
 */
public class EPC3_B050 extends EP_BatchBean {

    /** log */
    private static final Logger log = Logger.getLogger(EPC3_B050.class);

    /** �@�~�W�� */
    private static final String JOB_NAME = "JAEPDC305";

    /** �{���W�� */
    private static final String PROGRAM = "EPC3_B050";

    /** �~�ȧO */
    private static final String BUSINESS = "EP";

    /** ���t�ΦW�� */
    private static final String SUBSYSTEM = "C3";

    /** ����g�� */
    private static final String PERIOD = "��";

    /** �]�� true �Ѥ����O�p�Ƥμg���~�T��, false �Шϥ� ErrorLog ��CountManager �ۦ�g���~�T���έp�� */
    private static final boolean isAUTO_WRITELOG = false;

    private static final String INPUT_COUNT = "�B�z���";

    private static final String OUTPUT_COUNT = "�s�W���";

    private static final String ERROR_COUNT = "���~���";

    /** �d�ߪ����� */
    private BatchQueryDataSet bqds;

    /** �M�����O�@�Τ����~�T���O������ */
    private ErrorLog errorLog;

    /** �p�ƾ� */
    private CountManager countManager;

    private StringBuffer sbf;

    private static final String QUERYDTEPC301_001 = "com.cathay.ep.c3.batch.EPC3_B050.QUERYDTEPC301_001";

    public EPC3_B050() throws Exception {

        //�]�w�����O���غc�l,�ǤJ true �Ѥ����O�p�Ƥμg���~�T��
        super(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isAUTO_WRITELOG);

        //���~�T���O������
        countManager = new CountManager(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD);

        errorLog = new ErrorLog(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM);

        sbf = new StringBuffer();

        bqds = getBatchQueryDataSet();

        initCountManager();

    }

    public void execute(String args[]) throws Exception {

        //        File file = new File(FileStoreUtil.getFTPU2HRoot() + "/DBEP", "EP_pass_DG_NEW.TXT");
        //        if (!file.isFile()) {
        //            file.createNewFile();
        //        }
        //        String fileName = file.getAbsolutePath();

        //        FileService fs = new FileService();

        try {
            MultiKeyMap mkm = new MultiKeyMap();
            String ACNT_DATE;
            String SUB_CPY_ID = null;
            try {

                //������G�Y�L�ǤJ�ѼơA�h���t�Τ�@�������
                if (args != null && args.length > 0) {

                    ACNT_DATE = args[0];

                    if (StringUtils.isBlank(ACNT_DATE)) {
                        ACNT_DATE = DATE.getDBDate();
                    } else if (!DATE.isDate(ACNT_DATE)) {
                        throw new ErrorInputException("�ǤJ�ѼƦ��~");
                    }

                    if (args.length > 1) {
                        SUB_CPY_ID = args[1];
                        if (StringUtils.isBlank(SUB_CPY_ID)) {
                            SUB_CPY_ID = "00";
                        }
                    } else {
                        SUB_CPY_ID = "00";
                    }

                } else {
                    ACNT_DATE = DATE.getDBDate();
                    SUB_CPY_ID = "00";
                }

            } catch (Exception e) {
                setExitCode(ERROR);
                log.fatal("�ǤJ�Ѽƿ��~", e);
                return;
            }

            //�b�Ȥ��
            bqds.setField("ACNT_DATE", ACNT_DATE);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            //�d�߯����ú�O���
            searchAndRetrieve(bqds, QUERYDTEPC301_001);

            int inputCount = getInputCount();
            if (inputCount == 0) {
                //���ͪ���
                //                setExitCode(ERROR);
                log.fatal("�d�L���");
                return;
            }

            countManager.addCountNumber(INPUT_COUNT, inputCount); //�]�w��X���

            //            boolean firstRowData = true;

            List<DTDGA002> DGA002List = new ArrayList<DTDGA002>();
            DK_F0Z003 theDK_F0Z003 = new DK_F0Z003();

            for (prepareFetch(); fetchData(bqds); goNext()) { //�������
                int outcount = 0;
                try {
                    // �v���B�z

                    while (bqds.next()) {

                        // �]�w����H�W��
                        String CUS_NAME_B102 = (String) bqds.getField("CUS_NAME_B102");
                        String CUS_NAME_C301 = (String) bqds.getField("CUS_NAME_C301");

                        String TRANS_NAME;
                        if (StringUtils.isNotEmpty(CUS_NAME_B102)) {
                            TRANS_NAME = CUS_NAME_B102;
                        } else if (StringUtils.isNotEmpty(CUS_NAME_C301)) {
                            TRANS_NAME = CUS_NAME_C301;
                        } else {
                            TRANS_NAME = "";
                        }

                        //�զ��P�@���Y�H���ʲ�������ӼȦs�ɴC��(�r�����j��)

                        //                        if (firstRowData) {
                        //                            firstRowData = false;
                        //                        } else {
                        //                            STRING.newLine(sbf);
                        //                        }

                        String SLIP_DATE = ObjectUtils.toString(bqds.getField("ACNT_DATE"));
                        String SLIP_LOT_NO = ObjectUtils.toString(bqds.getField("SLIP_LOT_NO"));
                        String SLIP_SET_NO = ObjectUtils.toString(bqds.getField("SLIP_SET_NO"));
                        String ACNT_DIV_NO = ObjectUtils.toString(bqds.getField("ACNT_DIV_NO"));
                        String SLIP_SEQ_NO = "0";
                        //181226:�վ�Y�L�b�餣�d�ǲ���T,�קK���T�{�ɤ@��CALL DK
                        if (StringUtils.isNotBlank(SLIP_DATE)) {
                            //2015/04/10 �W�[cached�A��֭���IO���D
                            if (mkm.containsKey("1", SLIP_DATE, SLIP_LOT_NO, SLIP_SET_NO, ACNT_DIV_NO)) {
                                SLIP_SEQ_NO = (String) mkm.get("1", SLIP_DATE, SLIP_LOT_NO, SLIP_SET_NO, ACNT_DIV_NO);
                            } else {
                                ReturnMessage rm = new ReturnMessage();
                                DK_F0Z003_bo Z003_bo = theDK_F0Z003.doSwitch("1", SLIP_DATE, SLIP_LOT_NO, SLIP_SET_NO, ACNT_DIV_NO, rm);
                                if (rm.getReturnCode() == ReturnCode.OK) {
                                    SLIP_SEQ_NO = Z003_bo.getSLIP_NO();
                                    mkm.put("1", SLIP_DATE, SLIP_LOT_NO, SLIP_SET_NO, ACNT_DIV_NO, SLIP_SEQ_NO);
                                } else {
                                    log.fatal("�ഫ�ǲ��Ǹ�����," + rm.getMsgDesc());
                                    mkm.put("1", SLIP_DATE, SLIP_LOT_NO, SLIP_SET_NO, ACNT_DIV_NO, SLIP_SEQ_NO);
                                }
                            }
                        }
                        DTDGA002 BO = new DTDGA002();
                        BO.setTRANS_ID(StringUtils.trim(ObjectUtils.toString(bqds.getField("TRANS_ID"))));
                        BO.setTRANS_NAME(TRANS_NAME);
                        BO.setTRANS_NO(ObjectUtils.toString(bqds.getField("TRANS_NO")));
                        BO.setSLIP_DATE(Date.valueOf(SLIP_DATE));
                        BO.setSLIP_DIV_NO(ACNT_DIV_NO);
                        BO.setSLIP_SEQ_NO(Integer.parseInt(SLIP_SEQ_NO));
                        BO.setREMARK("");
                        BO.setTRANS_AMT(new BigDecimal(ObjectUtils.toString(bqds.getField("TRANS_AMT"))));
                        BO.setSRC("2");
                        BO.setPRE_KEY("");
                        BO.setINPUT_DATE(Date.valueOf(ObjectUtils.toString(bqds.getField("INPUT_DATE"))));
                        BO.setINPUT_DIV_NO(ObjectUtils.toString(bqds.getField("INPUT_DIV_NO")));
                        BO.setINPUT_ID(null);
                        BO.setINPUT_NAME("EPC3_B050");
                        BO.setTRANS_DATE(null); //��SRC='1'���t�ήɦ���
                        BO.setSTOCK_NO(null); //��SRC='1'���t�ήɦ���                     

                        DGA002List.add(BO);

                        //                        sbf.append(ObjectUtils.toString(bqds.getField("TRANS_ID"))).append(",").append(TRANS_NAME).append(",").append(
                        //                            ObjectUtils.toString(bqds.getField("TRANS_NO"))).append(",").append(
                        //                            ObjectUtils.toString(bqds.getField("ACNT_DATE"))).append(",").append(
                        //                            ObjectUtils.toString(bqds.getField("ACNT_DIV_NO"))).append(",").append(
                        //                            ObjectUtils.toString(bqds.getField("TRANS_AMT"))).append(",").append(
                        //                            ObjectUtils.toString(bqds.getField("INPUT_DATE"))).append(",").append(
                        //                            ObjectUtils.toString(bqds.getField("INPUT_DIV_NO"))).append(",").append(
                        //                            ObjectUtils.toString(bqds.getField("OPR_TIME"))).append(",").append(
                        //                            ObjectUtils.toString(bqds.getField("SLIP_LOT_NO"))).append(",").append(
                        //                            ObjectUtils.toString(bqds.getField("SLIP_SET_NO")));

                        outcount++;
                    }// while loop end

                    //                    fs.StringToFile(sbf.toString(), fileName, true);

                } finally {

                    sbf.setLength(0);
                    //�g�X���~��ưO���� , �C�@�����@��         
                    int count = errorLog.getErrorCountAndWriteErrorMessage();
                    countManager.addCountNumber(ERROR_COUNT, count);
                    countManager.addCountNumber(OUTPUT_COUNT, outcount);
                }

            } //for loop end

            new DG_A0Z002().insertDTDGA002List(DGA002List);

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("�g�J�P�@���Y�H������ӼȦs�ɥ���", e);
        } finally {

            log.fatal(countManager);

            if (countManager != null) {
                countManager.writeLog(); //�g�J��ưO����  
            }
            // �����Ҧ����s�u
            if (bqds != null) {
                bqds.close();
            }

            printExitCode(getExitCode()); //�^�ǵ� Control_M ���T���N�X , �{���פ�
        }

    }

    //  *********************************************** Private Method  ************************************************/

    /**
     * ��l�p��
     * @throws ModuleException
     */
    private void initCountManager() throws ModuleException {
        countManager.createCountType("START");
        countManager.writeLog();
        countManager.clearCountTypeAndNumber();
        countManager.createCountType(INPUT_COUNT);
        countManager.createCountType(OUTPUT_COUNT);
        countManager.createCountType(ERROR_COUNT);
    }

}
