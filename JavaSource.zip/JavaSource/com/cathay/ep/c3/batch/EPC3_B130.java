package com.cathay.ep.c3.batch;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.hr.Employee;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.util.CathayDate;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.c3.module.EP_C30020;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.rz.s0.module.RZ_S00300;
import com.cathay.util.Transaction;
import com.cathay.zz.bo.DTZZM010;
import com.cathay.zz.m0.module.ZZ_M0Z020;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;


/**
 * <pre>
 * Date        Version Description                           Author
 * 2019/04/22  1.0     Created                               ������
 * 2019/05/02  1.1     Modified DTEPC306 �̷ӳ��P�b�U�O���͸��            ������
 *
 * �@�B�{���\�෧�n�����G
 * �{���\��      ���ʲ����u���~�P�b
 * �{���W��      EPC3_B130.java
 * �@�~�覡      BATCH
 * ���n����      �C��d�߫ݮ��~�էO�����~�^���ɡA�̾ڦ^�Ǹ�ƶi��妸�P�b
 * �w����ƶq    5000(�̤j��)
 * �@�~�W��      JAEPDC004
 * �~�ȧO        EP
 * ���t�ΦW��    C3
 * �B�z�g��      ��
 * ����B�z���  �L
 * </pre>
 * @author ������
 * @since 2019/05/06
 * 2019/06/03 AllenTsai �վ�H�H�q���A���~��ƼW�[���~�էO
 * 2019/06/10 AllenTsai �վ� JOB_NAME�A��K�]�w�Ƶ{
 * 2019/09/20 AllenTsai �վ�@�~�W�ٻPControM�@�P
 */
public class EPC3_B130 extends EP_BatchBean {

	/** logger */
	private static final Logger log = Logger.getLogger(EPC3_B130.class);	
	
	/** �@�~�W�� */
    private static final String JOB_NAME = "JAEPDC004";

    /** �{���W�� */
    private static final String PROGRAM = "EPC3_B130";

    /** �B�z�g�� */
    private static final String PERIOD = "��";      
    	
	/** ���~�էO */
	private String PAY_GRP;
    
    /** �����q�O */
    private String SUB_CPY_ID = "00";
    
    /** �ƥ�N��(���ʲ����~�P�b�q��) */
    private String EVENT_ID = "EP_RA008";
    
    /** �ƥ�N��(���ʲ����~�����q��) */
    private String FAIL_EVENT_ID = "EP_RA009";        
    
	/** �@�~���(�t�Τ��) */
	private Date SYS_DT = DATE.today();	
	
	/** �妸�P�b�B�z�ɶ� */
	private Timestamp pcsDACNT_DATE = DATE.currentTime();	
	
	/** �ӿ��O�P�b�B�z�έp��T */
	private Map<String, Map> mapSumData = new TreeMap<String, Map>();
	
	/** ���~�~��P�b�B�z�έp��T */
	private Map<String, Map> mapYMSumData = new HashMap<String, Map>();
	
	/** �b�U�O�ӿ��O�έp��T */
	private Map<String, Map> mapSumC306 = new HashMap<String, Map>();
	
	/** ���ڤ����q�����e��T */
	private Map<String, List> mapFailNotify = new HashMap<String, List>();
	
	/** ���~���� */
    private int salaryCount = 0;
    
    /** ���~���\���� */
    private int salaryOKCount = 0;
        
    /** ���~���\���B */
    private int salaryOKAmt = 0;
    
    /** ���~������� */
    private int salaryFailCnt = 0;
    
    /** ���~�P�b���~��� */
    private int acntErrorCount = 0;
	
	/** �P�b���~��] */
	private String DACNT_ERR_CODE = null;
	
	/** �P�b���A */
	private String DACNT_STS = null;
	
	/** ���~��� */
	private int ERROR_COUNT = 0;
	
	/** �B�z���� table */
	private String tableLoc = null;
	
	StringBuilder sb = new StringBuilder();

	
	/** �ŧi�ϥΪ� SQL��k */	    
    /**
     * <pre>
     * select a.*, b.SLY_CNT, c.RCV_NO, c.SUB_CPY_ID, c.CLC_DIV_NO, d.RCV_YM, d.PAY_KIND, 
     *        d.CRT_NO, d.CUS_NO, d.INV_NO, d.ID, d.CUS_NAME, d.BLD_CD, d.PAY_S_DATE, 
     *        d.PAY_E_DATE, d.DIV_NO, d.SPR_AMT, d.OP_STATUS, d.RJT_CD, e.BLD_NAME 
     *   from DBEP.DTEPC322 as a 
     *   left join DBEP.DTEPC320 b 
     *     on b.PAY_GRP = a.PAY_GRP 
     *    and b.SLRY_YYMM = a.SLRY_YYMM
     *   left join DBEP.DTEPC321 c 
     *     on c.TRN_DATE = a.TRN_DATE
     *    and c.SRC_CODE = a.SRC_CODE
     *    and c.SER_NO = a.SER_NO
     *   left join DBEP.DTEPC101 d 
     *     on d.RCV_NO = c.RCV_NO 
     *    and d.SUB_CPY_ID = c.SUB_CPY_ID  
     *   left join DBEP.DTEPA101 e 
     *     on e.BLD_CD = c.BLD_CD 
     *    and e.SUB_CPY_ID = c.SUB_CPY_ID  
     *  where b.PAY_GRP = ':PAY_GRP'
     *    and b.SLRY_CTL_STS = '4'  -- ���~����A = 4:�ݮ��~
     *    and c.SLRY_STS	=  '0'  -- ���~��󪬺A	= 0.���`��
     *   with ur
     *   </pre>
     */
    private static final String SQL_QUERY_001 = "com.cathay.ep.c3.batch.EPC3_B130.SQL_QUERY_001";
	    
    /**
     * <pre>
     * update DBEP.DTEPC321
     *    set DCT_RSLT = ':DCT_RSLT',
     *        DACNT_STS = ':DACNT_STS',
     *        DACNT_ERR_CODE = ':DACNT_ERR_CODE',
     *        PAY_NO = ':PAY_NO'
     *  where PAY_GRP = ':PAY_GRP'
     *    and SLRY_YYMM = ':SLRY_YYMM'
     *    and RCV_NO = ':RCV_NO'
     *    and SUB_CPY_ID = ':SUB_CPY_ID'
     * </pre>
     */
	private static final String SQL_UPDATE_DTEPC321 = "com.cathay.ep.c3.batch.EPC3_B130.SQL_UPDATE_DTEPC321";
	
	/**
	 * <pre>
	 * INSERT INTO DBEP.DTEPC301(PAY_NO,
     *                           RCV_NO,
     *                           SUB_CPY_ID, 
     *                           RCV_YM, 
     *                           PAY_KIND, 
     *                           CRT_NO, 
     *                           CUS_NO, 
     *                           PAY_TYPE, 
     *                           PAY_AMT, 
     *                           CHK_CD, 
     *                           COA_DATE, 
     *                           PMI_S_DATE, 
     *                           PMI_E_DATE, 
     *                           INV_NO, 
     *                           ID, 
     *                           CUS_NAME, 
     *                           BLD_CD, 
     *                           PAY_S_DATE, 
     *                           PAY_E_DATE, 
     *                           INPUT_ID, 
     *                           INPUT_NAME, 
     *                           SLIP_SET_NO, 
     *                           TRN_KIND, 
     *                           CHG_DATE, 
     *                           CHG_DIV_NO, 
     *                           CHG_ID, 
     *                           CHG_NAME, 
     *                           OP_STATUS_C101, 
     *                           ORN_AMT) 
     * VALUES (':PAY_NO', 
     *         ':RCV_NO', 
     *         ':SUB_CPY_ID', 
     *         ':RCV_YM',
     *         ':PAY_KIND', 
     *         ':CRT_NO', 
     *         ':CUS_NO', 
     *         ':PAY_TYPE', 
     *         ':PAY_AMT', 
     *         ':CHK_CD', 
     *         ':COA_DATE', 
     *         ':PMI_S_DATE', 
     *         ':PMI_E_DATE', 
     *         ':INV_NO', 
     *         ':ID', 
     *         ':CUS_NAME', 
     *         ':BLD_CD', 
     *         ':PAY_S_DATE', 
     *         ':PAY_E_DATE', 
     *         ':INPUT_ID', 
     *         ':INPUT_NAME', 
     *         ':SLIP_SET_NO',
     *         ':TRN_KIND',
     *         ':CHG_DATE', 
     *         ':CHG_DIV_NO', 
     *         ':CHG_ID', 
     *         ':CHG_NAME', 
     *        ':OP_STATUS_C101',
     *         ':ORN_AMT')
     * </pre>
	 */
	private static final String SQL_INSERT_DTEPC301 = "com.cathay.ep.c3.batch.EPC3_B130.SQL_INSERT_DTEPC301";
	
	/**
     * <pre>
     * update DBEP.DTEPC101
     *    set SPR_AMT = ':SPR_AMT'
     *  where RCV_NO = ':RCV_NO'
     *    and SUB_CPY_ID = ':SUB_CPY_ID'
     * </pre>
     */
	private static final String SQL_UPDATE_DTEPC101 = "com.cathay.ep.c3.batch.EPC3_B130.SQL_UPDATE_DTEPC101";

	/**
	 * <pre>
	 * INSERT INTO DBEP.DTEPC324 (TRN_DATE,
     *                            SRC_CODE,
     *                            SER_NO, 
     *                            COMP_ID, 
     *                            AREA_CODE, 
     *                            EMPLOYEE_ID, 
     *                            SLRY_KIND, 
     *                            SLRY_YYMM, 
     *                            PAY_GRP, 
     *                            SLRY_CODE, 
     *                            TOT_AMT, 
     *                            CURR_CODE, 
     *                            DIV_NO, 
     *                            POSITION, 
     *                            PROC_CODE,
     *                            DCT_CTGY, 
     *                            DCT_FAIL_PROC, 
     *                            DCT_RSLT, 
     *                            DACNT_DATE) 
     * VALUES (':TRN_DATE', 
     *         ':SRC_CODE', 
     *         ':SER_NO', 
     *         ':COMP_ID', 
     *         ':AREA_CODE', 
     *         ':EMPLOYEE_ID', 
     *         ':SLRY_KIND', 
     *         ':SLRY_YYMM', 
     *         ':PAY_GRP', 
     *         ':SLRY_CODE', 
     *         ':TOT_AMT', 
     *         ':CURR_CODE', 
     *         ':DIV_NO', 
     *         ':POSITION', 
     *         ':PROC_CODE', 
     *         ':DCT_CTGY', 
     *         ':DCT_FAIL_PROC', 
     *         ':DCT_RSLT', 
     *         ':DACNT_DATE')
	 * </pre>
	 */
	private static final String SQL_INSERT_DTEPC324 = "com.cathay.ep.c3.batch.EPC3_B130.SQL_INSERT_DTEPC324";

	/**
	 * <pre>
	 * DELETE FROM DBEP.DTEPC322
     *  WHERE TRN_DATE = ':TRN_DATE'
     *    AND SRC_CODE = ':SRC_CODE'
     *    AND SER_NO = ':SER_NO'
     * </pre>
	 */
	private static final String SQL_DELETE_DTEPC322 = "com.cathay.ep.c3.batch.EPC3_B130.SQL_DELETE_DTEPC322";

	/**
	 * <pre>
	 * INSERT INTO DBEP.DTEPC306 (SUB_CPY_ID, 
     *                            PAY_NO, 
     *                            CSH_AMT, 
     *                            CHK_AMT, 
     *                            RMT_AMT, 
     *                            TKD_AMT, 
     *                            ACNT_AMT, 
     *                            MAL_AMT, 
     *                            PAY_AMT, 
     *                            DACNT_AMT, 
     *                            TMP_AMT, 
     *                            CHK_SET_NO, 
     *                            RMT_SET_NO, 
     *                            ACNT_SET_NO, 
     *                            INPUT_ID, 
     *                            INPUT_NAME, 
     *                            SLIP_SET_NO, 
     *                            TRN_KIND, 
     *                            CHG_DATE, 
     *                            CHG_DIV_NO, 
     *                            CHG_ID, 
     *                            CHG_NAME, 
     *                            CARD_D_NO, 
     *                            CARD_D_AMT, 
     *                            SAL_D_AMT, 
     *                            TMP_NO, 
     *                            DTMP_NO) 
     * VALUES (':SUB_CPY_ID',
     *         ':PAY_NO', 
     *         ':CSH_AMT', 
     *         ':CHK_AMT', 
     *         ':RMT_AMT', 
     *         ':TKD_AMT', 
     *         ':ACNT_AMT', 
     *         ':MAL_AMT', 
     *         ':PAY_AMT', 
     *         ':DACNT_AMT', 
     *         ':TMP_AMT', 
     *         ':CHK_SET_NO', 
     *         ':RMT_SET_NO', 
     *         ':ACNT_SET_NO', 
     *         ':INPUT_ID', 
     *         ':INPUT_NAME',      
     *         ':SLIP_SET_NO',
     *         ':TRN_KIND',
     *         ':CHG_DATE',
     *         ':CHG_DIV_NO',
     *         ':CHG_ID',
     *         ':CHG_NAME',
     *         ':CARD_D_NO',
     *         ':CARD_D_AMT',
     *         ':SAL_D_AMT',
     *         ':TMP_NO',
     *         ':DTMP_NO')
	 * </pre>
	 */
	private static final String SQL_INSERT_DTEPC306 = "com.cathay.ep.c3.batch.EPC3_B130.SQL_INSERT_DTEPC306";
	
	/**
	 * <pre>
	 * update DBEP.DTEPC320
     *    set SLRY_CTL_STS = ':SLRY_CTL_STS',
     *        DACNT_DATE = ':DACNT_DATE',
     *        SLY_OK_CNT = ':SLY_OK_CNT',
     *        SLY_FAIL_CNT = ':SLY_FAIL_CNT',
     *        DACNT_CNT = ':DACNT_CNT',
     *        DACNT_ERR_CNT = ':DACNT_ERR_CNT',
     *        DACNT_AMT = ':DACNT_AMT'
     *  where PAY_GRP = ':PAY_GRP'
     *    and SLRY_YYMM = ':SLRY_YYMM'
	 * </pre>
	 */
	private static final String SQL_UPDATE_DTEPC320 = "com.cathay.ep.c3.batch.EPC3_B130.SQL_UPDATE_DTEPC320";

	
	
	
	/** ����妸�@�~ */
	/**
	 * method 1: execute (�D�{��)	
	 * @param String args[]
	 * @return
	 * @throws Exception
	 */
	public void execute(String[] args) throws Exception {
	    
		//�]�w BatchConstructor (�ѼƤ��O��"�@�~�W�١B�{���W�١B����g��")
		final BatchConstructor bc = new BatchConstructor(JOB_NAME, PROGRAM, PERIOD);				
		
		try {	
			//�@�B�{���D��G
			//�ˮְѼ�
			PAY_GRP = chkArgs(args);	
			
			bc.execute(new BatchConstructor.DataBaseHandler() {			    
			    
			    //�� SPEC �@�~�y�{�Ƨ�
			    int updC321Count = 0;    //��s���ʲ����u���~�����ɥ�� (upd - DTEPC321) - PG�ۤv�[��
			    int insC301Count = 0;    //�s�Wú�O���p�ɥ�� (ins - DTEPC301)			    
			    int updC101Count = 0;    //��s�����ɥ�� (upd - DTEPC101)
			    int insC324Count = 0;    //�s�W���ʲ����u���~�B�z�O�� (ins - DTEPC324)
			    int delC322Count = 0;    //�R�����~���G��� (del - DTEPC322)			    
			    int insC306Count = 0;    //�s�Wú�O�O���ɥ�� (ins - DTEPC306)
			    int updC320Count = 0;    //��s���s�����ɥ�� (upd - DTEPC320)
			    
			    //�� SPEC �@�~�y�{�Ƨ�
			    String C321_UPD_COUNT = "��s���ʲ����u���~������";  //buds_upd_c321��X���� - PG�ۤv�[��
			    String REC_PAY_COUNT = "ú�O���p";//buds_ins_c301��X����
			    String REC_UPD_COUNT = "������s����";//buds_ins_c101��X����
			    String OUTPUT_COUNT = "���~���G�O����X����";//buds_ins_c324��X����
			    String DEL_COUNT = "���~���G�R������";//buds_del_c322��X����
			    String PAY_INS_COUNT = "ú�O�O����X����";//buds_ins_c306��X����			    
			    String CTRL_UPD_COUNT = "���~�����ɧ�s����";//buds_upd_c320��X����
			    
			    
			    String ACNT_ERR_COUNT = "���~�P�b���~����";//acntErrorCount
			    String SLRY_OK_COUNT = "���~���\����";
			    String SLRY_FAIL_COUNT = "���~��������";
			    
			    BatchUpdateDataSet buds_upd_C321 = bc.getBatchUpdateDataSet(SQL_UPDATE_DTEPC321, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);
				BatchUpdateDataSet buds_ins_C301 = bc.getBatchUpdateDataSet(SQL_INSERT_DTEPC301, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);
				BatchUpdateDataSet buds_upd_C101 = bc.getBatchUpdateDataSet(SQL_UPDATE_DTEPC101, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);				
				BatchUpdateDataSet buds_ins_C324 = bc.getBatchUpdateDataSet(SQL_INSERT_DTEPC324, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);
				BatchUpdateDataSet buds_del_C322 = bc.getBatchUpdateDataSet(SQL_DELETE_DTEPC322, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);
				
				
				//�έp��ơA�W�[�B�~���p��
				@Override
				protected boolean firstProcess() throws Exception {
	                //�� SPEC �@�~�y�{�Ƨ�
				    bc.createCountType(C321_UPD_COUNT);
				    bc.createCountType(REC_PAY_COUNT);
				    bc.createCountType(REC_UPD_COUNT);
				    bc.createCountType(OUTPUT_COUNT);
					bc.createCountType(DEL_COUNT);
					bc.createCountType(PAY_INS_COUNT);					
					bc.createCountType(CTRL_UPD_COUNT);
										
					bc.createCountType(ACNT_ERR_COUNT);
					bc.createCountType(SLRY_OK_COUNT);
					bc.createCountType(SLRY_FAIL_COUNT);					
					return true;
				}
				
				@Override
				protected boolean searchProcess(BatchQueryDataSet bqds) throws DBException {

					//�d�ߦ��~�������Ӹ��
					bqds.setField("PAY_GRP", PAY_GRP);					
					bqds.searchAndRetrieve(SQL_QUERY_001);
					//�p�G bqds �d�L���  return false => �i�J finallyProcess�y�{
					if(bqds.getTotalCount() == 0) {
					    sb.append("���~�էO ");
					    sb.append(PAY_GRP);
					    sb.append(" �d�L���~�������Ӹ�ơA�������`�����A�������X�C");					    
						log.fatal(sb.toString());
						sb.setLength(0);
						return false;
					}
					return true;
				}
				
				EP_Z0G103 ep_z0g103 = new EP_Z0G103();
				EP_C30020 ep_c30020 = new EP_C30020();
				DivData dd = new DivData();
				int SLRY_AMT = 0;
				@Override
				protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {
					
					//�v���B�z���~���G���ӡG
					try {
						
						//�B�z�Ĥ@���G��囹�~���ӵ��ƻP���~���G�d�ߵ��ƬO�_�@�P�A�p�G���@�P�A��X���~�O��A�A�{�����_
						if(salaryCount == 0) {
							int SLRY_CNT = Integer.parseInt(ObjectUtils.toString(bqds.getField("SLY_CNT")));
							
							if(SLRY_CNT != bqds.getTotalCount()) {
								sb.append("���~����");
								sb.append(SLRY_CNT);
								sb.append("�P���~���G����");
								sb.append(bqds.getTotalCount());
								sb.append("���P");								
								bc.addErrorLog("���~���ƻP�^���ɵ��Ƥ��P", sb.toString());	
								bc.writeErrorLog();
								sb.setLength(0);
								setExitCode(ERROR);
								ERROR_COUNT++;
								throw new ModuleException("���~���ƻP�^���ɵ��Ƥ��P");
							}
						}
						
						
						//���o���~�~��έp���
						Map ymSumData = mapYMSumData.get(ObjectUtils.toString(bqds.getField("SLRY_YYMM")));					
						
						String subCpyId = ObjectUtils.toString(bqds.getField("SUB_CPY_ID"));//bqds.SUB_CPY_ID	
						String SLRY_YYMM = ObjectUtils.toString(bqds.getField("SLRY_YYMM"));
						//�Y ymSumData �L��
						if(ymSumData == null) {
							ymSumData = new HashMap<String, Object>();
							ymSumData.put("SUB_CPY_ID", subCpyId);
							ymSumData.put("SLRY_YYMM", SLRY_YYMM);							
							ymSumData.put("SLY_CNT", 0);
							ymSumData.put("SLY_OK_CNT", 0);
							ymSumData.put("SLY_FAIL_CNT", 0);
							ymSumData.put("SLY_OK_AMT", 0);
							ymSumData.put("ACNT_ERR_CNT", 0);
							
							mapYMSumData.put(SLRY_YYMM, ymSumData);
						}
						
						//���o�ӿ��O�έp���
						Map sumData = mapSumData.get(bqds.getField("CLC_DIV_NO"));                 
						
						String CLC_DIV_NO = ObjectUtils.toString(bqds.getField("CLC_DIV_NO"));
						String clcDivNoShort = dd.getUnit4ShortName(CLC_DIV_NO);
						//�Y sumData �L��
						if(sumData == null) {
							sumData = new HashMap<String, Object>();							
							sumData.put("SUB_CPY_ID", subCpyId);
							sumData.put("DIV_NAME", clcDivNoShort);
							sumData.put("CLC_DIV_NO", CLC_DIV_NO);
							sumData.put("SLY_CNT", 0);//���~���
							sumData.put("SLY_OK_CNT", 0);//���~���\���
							sumData.put("SLY_FAIL_CNT", 0);//���~�������							
							sumData.put("SLY_OK_AMT", 0);//���~���B
							sumData.put("ACNT_ERR_CNT", 0);//�P�b���~���		
							
							mapSumData.put(CLC_DIV_NO, sumData);							
						}
						
						String balType;
						//���o�b�U�O�ӿ��O�έp��� 
						try{
							String BLD_CD = ObjectUtils.toString(bqds.getField("BLD_CD"));
							balType = ep_z0g103.getBAL_TYPE(subCpyId, BLD_CD);//���o�b�U�O
						} catch(Exception e) {
							//�Y�����D
							balType = "CA";
						}
						
						sb.append(CLC_DIV_NO);
						sb.append("_");
						sb.append(balType);
						String clcDivNoBalType = sb.toString();
						sb.setLength(0);
						
						Map mapC306 = mapSumC306.get(clcDivNoBalType);				
												
						String RCV_YM = ObjectUtils.toString(bqds.getField("RCV_YM"));

						//�Y mapC306 �L��
						if(mapC306 == null) {
							mapC306 = new HashMap<String, Object>();
							String strPayNo = ep_c30020.getPayNo(subCpyId, RCV_YM, "8");
							mapC306.put("PAY_NO", strPayNo);
							mapC306.put("SUB_CPY_ID", subCpyId);
							mapC306.put("DIV_NAME", clcDivNoShort);
							mapC306.put("CLC_DIV_NO", CLC_DIV_NO);
							mapC306.put("SLY_CNT", 0);//���~���
							mapC306.put("SLY_OK_CNT", 0);//���~���\���							
							mapC306.put("SLY_FAIL_CNT", 0);//���~�������
							mapC306.put("SLY_OK_AMT", 0);//���~���B
							mapC306.put("ACNT_OK_AMT", 0);//���~���\�J�b���B							
							mapC306.put("ACNT_ERR_CNT", 0);//�P�b���~���
							mapC306.put("BAL_TYPE", balType);//�b�U�O
							
							mapSumC306.put(clcDivNoBalType, mapC306);
						}
						
						//���o���~���B
						BigDecimal totAmt =  STRING.objToBigDecimal(bqds.getField("TOT_AMT"), BigDecimal.ZERO);
						//BigDecimal �ন int
						SLRY_AMT = totAmt.intValue();
						
						//�P�_�P�b���A
						String DCT_RSLT = ObjectUtils.toString(bqds.getField("DCT_RSLT"));//���~���G
						String OP_STATUS = ObjectUtils.toString(bqds.getField("OP_STATUS"));
					    String RJT_CD = ObjectUtils.toString(bqds.getField("RJT_CD"));
						String SPR_AMT = ObjectUtils.toString(bqds.getField("SPR_AMT"));
						String TOT_AMT = ObjectUtils.toString(bqds.getField("TOT_AMT"));						
						String BLD_NAME = ObjectUtils.toString(bqds.getField("BLD_NAME"));
						String CRT_NO = ObjectUtils.toString(bqds.getField("CRT_NO"));
						String CUS_NAME = ObjectUtils.toString(bqds.getField("CUS_NAME"));
						String EMPLOYEE_ID = ObjectUtils.toString(bqds.getField("EMPLOYEE_ID"));
											
						if("0".equals(DCT_RSLT)) {//���~���\
							if("99".equals(OP_STATUS)) {//�����@�o (2019.05.20 update : �����ꦨ�@�� if/else if....)
								DACNT_ERR_CODE = "2";
							} else if ("".equals(OP_STATUS)) {//2019.05.20 update : �Y OP_STATUS ���ŭȡA�h DACNT_ERR_CODE = 4							   
							    DACNT_ERR_CODE = "4";
							} else if("Y".equals(RJT_CD)) {
								DACNT_ERR_CODE = "3";
							} else if(!SPR_AMT.equals(TOT_AMT)) {
								DACNT_ERR_CODE = "1";
							} else {
								DACNT_ERR_CODE = "";
							}		
							
							//�P�b���A
							if(!"".equals(DACNT_ERR_CODE)) {
								DACNT_STS = "2";//�P�b���`
								acntErrorCount++;//���~�P�b���~���
								
								//���έp���																
								sumData.put("ACNT_ERR_CNT", Integer.parseInt(ObjectUtils.toString(sumData.get("ACNT_ERR_CNT"), "0")) + 1);								
								
								//���b�U�O�έp���																
								mapC306.put("ACNT_ERR_CNT", Integer.parseInt(ObjectUtils.toString(mapC306.get("ACNT_ERR_CNT"), "0")) + 1);
								
								//���~�~��έp���																
								ymSumData.put("ACNT_ERR_CNT", Integer.parseInt(ObjectUtils.toString(ymSumData.get("ACNT_ERR_CNT"), "0")) + 1);
								
							} else {
								DACNT_STS = "1";//�P�b���`
								
								//���b�U�O�p�p���~���\�B�J�b���\���B
								mapC306.put("ACNT_OK_AMT", Integer.parseInt(ObjectUtils.toString(mapC306.get("ACNT_OK_AMT"), "0")) + SLRY_AMT);
							}
							
							salaryOKCount++;//���~���\����					
							salaryOKAmt += SLRY_AMT;//���~���\���B
							
							//���έp��� (���~���\��ơB���~���\���B)
							sumData.put("SLY_OK_CNT", Integer.parseInt(ObjectUtils.toString(sumData.get("SLY_OK_CNT"), "0")) + 1);
							sumData.put("SLY_OK_AMT", Integer.parseInt(ObjectUtils.toString(sumData.get("SLY_OK_AMT"), "0")) + SLRY_AMT);
														
							//���b�U�O�έp��T (���~���\��ơB���~���\���B)
							mapC306.put("SLY_OK_CNT", Integer.parseInt(ObjectUtils.toString(mapC306.get("SLY_OK_CNT"), "0")) + 1);
							mapC306.put("SLY_OK_AMT", Integer.parseInt(ObjectUtils.toString(mapC306.get("SLY_OK_AMT"), "0")) + SLRY_AMT);
														
							//���~�~��έp��T (���~���\��ơB���~���\���B)
							ymSumData.put("SLY_OK_CNT", Integer.parseInt(ObjectUtils.toString(ymSumData.get("SLY_OK_CNT"), "0")) + 1);
							ymSumData.put("SLY_OK_AMT", Integer.parseInt(ObjectUtils.toString(ymSumData.get("SLY_OK_AMT"), "0")) + SLRY_AMT);							
														
						} else {//���~����
							DACNT_ERR_CODE = "";
							DACNT_STS = "";
							
							//��즩�~�������
							sumData.put("SLY_FAIL_CNT", Integer.parseInt(ObjectUtils.toString(sumData.get("SLY_FAIL_CNT"), "0")) + 1);
							
							//���b�U�O�έp��T���~�������
							mapC306.put("SLY_FAIL_CNT", Integer.parseInt(ObjectUtils.toString(mapC306.get("SLY_FAIL_CNT"), "0")) + 1);
							
							//���~�~��έp��T���~�������
							ymSumData.put("SLY_FAIL_CNT", Integer.parseInt(ObjectUtils.toString(ymSumData.get("SLY_FAIL_CNT"), "0")) + 1);
							
							//���~�������
							salaryFailCnt++;
							
							//�]�w���~�����q�����ؤ��e
							Map notifyMap = new HashMap();
							notifyMap.put("BLD_NAME", BLD_NAME);
							notifyMap.put("CRT_NO", CRT_NO);
							notifyMap.put("CUS_NAME", CUS_NAME);
							notifyMap.put("TOT_AMT", TOT_AMT);
							String DCT_RSLT_NM = FieldOptionList.getName("EP", "DCT_RSLT", DCT_RSLT);
							notifyMap.put("DCT_RSLT_NM", DCT_RSLT_NM);
							
							List<Map> notifyList = new ArrayList<Map>();
							if(mapFailNotify.containsKey(EMPLOYEE_ID)) {
								notifyList = mapFailNotify.get(EMPLOYEE_ID);
								notifyList.add(notifyMap);
							} else {								
								notifyList.add(notifyMap);
								mapFailNotify.put(EMPLOYEE_ID, notifyList);			
							}
						}
						
						//�p�p���~���
						//���έp���
						sumData.put("SLY_CNT", (Integer)sumData.get("SLY_CNT") + 1);
						
						//���~�~��έp���
						ymSumData.put("SLY_CNT", (Integer)ymSumData.get("SLY_CNT") + 1);
						
						//���b�U�O�έp���
						mapC306.put("SLY_CNT", (Integer)mapC306.get("SLY_CNT") + 1);
						
						salaryCount++;
						
						
						//��s���~���� (BY DTEPC321's PK)
						tableLoc = "DTEPC321";
						String payGrp = ObjectUtils.toString(bqds.getField("PAY_GRP"));
						String RCV_NO = ObjectUtils.toString(bqds.getField("RCV_NO"));						

						buds_upd_C321.setField("DCT_RSLT", DCT_RSLT);
						buds_upd_C321.setField("DACNT_STS", DACNT_STS);
						buds_upd_C321.setField("DACNT_ERR_CODE", DACNT_ERR_CODE);						
						//where����(table SQL_KEY)
						buds_upd_C321.setField("PAY_GRP", payGrp);//���~�էO
						buds_upd_C321.setField("SLRY_YYMM", SLRY_YYMM);//�o�~�u�@�~��
						buds_upd_C321.setField("RCV_NO", RCV_NO);//�����s��
						buds_upd_C321.setField("SUB_CPY_ID", subCpyId);//�����q�O
						buds_upd_C321.setField("TABLE_LOC", tableLoc);//2019.05.20 update : for errorDataMap�ϥ�
						
						if("1".equals(DACNT_STS)) {
							buds_upd_C321.setField("PAY_NO", mapC306.get("PAY_NO"));//2019.05.10 �PSA�T�{�AsumData�L����ơA�� mapC306���o�Y�i�C							
						} else {
							buds_upd_C321.setField("PAY_NO", "");
						}
						updC321Count++;
						
						//�㵧��ƥ[�J�妸
						addBatchAndJoinGroup(buds_upd_C321);
						
						
						
						
						String PAY_KIND = ObjectUtils.toString(bqds.getField("PAY_KIND"));						
						String CUS_NO = ObjectUtils.toString(bqds.getField("CUS_NO"));
						String INV_NO = ObjectUtils.toString(bqds.getField("INV_NO"));
						String ID = ObjectUtils.toString(bqds.getField("ID"));
						String BLD_CD = ObjectUtils.toString(bqds.getField("BLD_CD"));
						String PAY_S_DATE = ObjectUtils.toString(bqds.getField("PAY_S_DATE"));
						String PAY_E_DATE = ObjectUtils.toString(bqds.getField("PAY_E_DATE"));
						String CHG_DIV_NO = ObjectUtils.toString(bqds.getField("CLC_DIV_NO"));
						
						//�s�W���~���\ú�O���p�O�� (�P�b���\�~�B�z)
						if("1".equals(DACNT_STS)) {
						    tableLoc = "DTEPC301";
							String PAY_NO = (String) mapC306.get("PAY_NO");							
							buds_ins_C301.setField("PAY_NO", PAY_NO);
							buds_ins_C301.setField("RCV_NO", RCV_NO);
							buds_ins_C301.setField("SUB_CPY_ID", subCpyId);
							buds_ins_C301.setField("RCV_YM", RCV_YM);
							buds_ins_C301.setField("PAY_KIND", PAY_KIND);
							buds_ins_C301.setField("CRT_NO", CRT_NO);
							buds_ins_C301.setField("CUS_NO", CUS_NO);							
							buds_ins_C301.setField("PAY_TYPE", "8");
							buds_ins_C301.setField("PAY_AMT", TOT_AMT);
							buds_ins_C301.setField("CHK_CD", "");							
							buds_ins_C301.setField("COA_DATE", null);
							buds_ins_C301.setField("PMI_S_DATE", null);
							buds_ins_C301.setField("PMI_E_DATE", null);
							buds_ins_C301.setField("INV_NO", INV_NO);
							buds_ins_C301.setField("ID", ID);							
							buds_ins_C301.setField("CUS_NAME", CUS_NAME);							
							buds_ins_C301.setField("BLD_CD", BLD_CD);
							buds_ins_C301.setField("PAY_S_DATE", PAY_S_DATE);
							buds_ins_C301.setField("PAY_E_DATE", PAY_E_DATE);
							buds_ins_C301.setField("INPUT_ID", PROGRAM);							
							buds_ins_C301.setField("INPUT_NAME", "���~�P�b");
							buds_ins_C301.setField("SLIP_SET_NO", 0);
							buds_ins_C301.setField("TRN_KIND", "01");
							buds_ins_C301.setField("CHG_DATE", pcsDACNT_DATE);//�t�Τ���ɶ�
							buds_ins_C301.setField("CHG_DIV_NO", CHG_DIV_NO);
							buds_ins_C301.setField("CHG_ID", PROGRAM);
							buds_ins_C301.setField("CHG_NAME", "���~�P�b");					
							buds_ins_C301.setField("OP_STATUS_C101", OP_STATUS);//�����@�~�i��
							buds_ins_C301.setField("ORN_AMT", TOT_AMT);//��ú���B		
							buds_ins_C301.setField("TABLE_LOC", tableLoc);//2019.05.20 update : for errorDataMap�ϥ�
							insC301Count++;
							
							//�㵧��ƥ[�J�妸
							addBatchAndJoinGroup(buds_ins_C301);
							
							
							
							//��s������ (�P�b���\�~�B�z)
							tableLoc = "DTEPC101";							
							buds_upd_C101.setField("SPR_AMT", BigDecimal.ZERO);//�����l�B(��쫬�O�GDecimal(12,2)
							//where����(table SQL_KEY)
							buds_upd_C101.setField("RCV_NO", RCV_NO);//�����s��
							buds_upd_C101.setField("SUB_CPY_ID", subCpyId);//�����q�O
							buds_upd_C101.setField("TABLE_LOC", tableLoc);//2019.05.20 update : for errorDataMap�ϥ�
							updC101Count++;
							
							//�㵧��ƥ[�J�妸
							addBatchAndJoinGroup(buds_upd_C101);
							
						}//End if
						
						
						
						String TRN_DATE = ObjectUtils.toString(bqds.getField("TRN_DATE"));
						String SRC_CODE = ObjectUtils.toString(bqds.getField("SRC_CODE"));
						String SER_NO = ObjectUtils.toString(bqds.getField("SER_NO"));
						String COMP_ID = ObjectUtils.toString(bqds.getField("COMP_ID"));
						String AREA_CODE = ObjectUtils.toString(bqds.getField("AREA_CODE"));
						String SLRY_KIND = ObjectUtils.toString(bqds.getField("SLRY_KIND"));
						String SLRY_CODE = ObjectUtils.toString(bqds.getField("SLRY_CODE"));
						String CURR_CODE = ObjectUtils.toString(bqds.getField("CURR_CODE"));
						String DIV_NO = ObjectUtils.toString(bqds.getField("DIV_NO"));
						String POSITION = ObjectUtils.toString(bqds.getField("POSITION"));
						String PROC_CODE = ObjectUtils.toString(bqds.getField("PROC_CODE"));
						String DCT_CTGY = ObjectUtils.toString(bqds.getField("DCT_CTGY"));
						String DCT_FAIL_PROC = ObjectUtils.toString(bqds.getField("DCT_FAIL_PROC"));
						
						
						//�s�W���~�B�z�O��
						tableLoc = "DTEPC324";
						buds_ins_C324.setField("TRN_DATE", TRN_DATE);
						buds_ins_C324.setField("SRC_CODE", SRC_CODE);
						buds_ins_C324.setField("SER_NO", SER_NO);
						buds_ins_C324.setField("COMP_ID", COMP_ID);
						buds_ins_C324.setField("AREA_CODE", AREA_CODE);
						buds_ins_C324.setField("EMPLOYEE_ID", EMPLOYEE_ID);						
						buds_ins_C324.setField("SLRY_KIND", SLRY_KIND);
						buds_ins_C324.setField("SLRY_YYMM", SLRY_YYMM);
						buds_ins_C324.setField("PAY_GRP", payGrp);
						buds_ins_C324.setField("SLRY_CODE", SLRY_CODE);						
						buds_ins_C324.setField("TOT_AMT", TOT_AMT);
						buds_ins_C324.setField("CURR_CODE", CURR_CODE);
						buds_ins_C324.setField("DIV_NO", DIV_NO);
						buds_ins_C324.setField("POSITION", POSITION);
						buds_ins_C324.setField("PROC_CODE", PROC_CODE);
						buds_ins_C324.setField("DCT_CTGY", DCT_CTGY);
						buds_ins_C324.setField("DCT_FAIL_PROC", DCT_FAIL_PROC);
						buds_ins_C324.setField("DCT_RSLT", DCT_RSLT);
						buds_ins_C324.setField("DACNT_DATE", pcsDACNT_DATE);
						buds_ins_C324.setField("TABLE_LOC", tableLoc);//2019.05.20 update : for errorDataMap�ϥ�
						insC324Count++;
						
						//�㵧��ƥ[�J�妸
						addBatchAndJoinGroup(buds_ins_C324);
						
						
						
						//�R�����~���G (BY DTEPC322's PK)
						tableLoc = "DTEPC322";
						buds_del_C322.setField("TRN_DATE", TRN_DATE);
						buds_del_C322.setField("SRC_CODE", SRC_CODE);
						buds_del_C322.setField("SER_NO", SER_NO);
						buds_del_C322.setField("TABLE_LOC", tableLoc);//2019.05.20 update : for errorDataMap�ϥ�
						delC322Count++;
						
						//�㵧��ƥ[�J�妸
						addBatchAndJoinGroup(buds_del_C322);


					} catch(Exception e) {						
						log.fatal("�B�z���~���G���ӵo�Ϳ��~�G" + e.getMessage(), e);
					    throw e;
					}
					
					
				}
				
				
				@Override
				protected String formatErrorDetailMessage(Map errorDataMap) {
				    String memo = null;	
				    sb.setLength(0);
				    
				    String tableLoc = ObjectUtils.toString(errorDataMap.get("TABLE_LOC"));
				    
				    //�̩Ҧb table �i����~�B�z�G
				    if("DTEPC321".equals(tableLoc)) {
				      //��s��󱱨��ɵo�Ϳ��~�G				        	                    
	                    sb.append("��s���~�����ɿ��~�Atable�G ");
	                    sb.append(tableLoc);
	                    
	                    String errPAY_RGP = ObjectUtils.toString(errorDataMap.get("PAY_RGP"));
	                    String errSLRY_YYMM = ObjectUtils.toString(errorDataMap.get("SLRY_YYMM"));
	                    String errRCV_NO = ObjectUtils.toString(errorDataMap.get("RCV_NO"));
	                    String errSUB_CPY_ID = ObjectUtils.toString(errorDataMap.get("SUB_CPY_ID"));
	                    
	                    sb.append(". PAY_RGP = ");
	                    sb.append(errPAY_RGP);
	                    sb.append(", SLRY_YYMM = ");
                        sb.append(errSLRY_YYMM);
                        sb.append(", RCV_NO = ");
                        sb.append(errRCV_NO);
                        sb.append(", SUB_CPY_ID = ");
                        sb.append(errSUB_CPY_ID);
                        sb.append("\n");
                        
				    } else if("DTEPC301".equals(tableLoc)) {
                        sb.append("�s�Wú�O���p�ɿ��~�Atable�G ");
                        sb.append(tableLoc);
                        
                        String errPAY_NO = ObjectUtils.toString(errorDataMap.get("PAY_NO"));
                        String errRCV_NO = ObjectUtils.toString(errorDataMap.get("RCV_NO"));
                        String errSUB_CPY_ID = ObjectUtils.toString(errorDataMap.get("SUB_CPY_ID"));
                        sb.append(". PAY_NO = ");
                        sb.append(errPAY_NO);
                        sb.append(", RCV_NO = ");
                        sb.append(errRCV_NO);
                        sb.append(", SUB_CPY_ID = ");
                        sb.append(errSUB_CPY_ID);
                        sb.append("\n");
                        
				    } else if("DTEPC101".equals(tableLoc)) {
                        sb.append("��s�����ɿ��~�Atable�G ");
                        sb.append(tableLoc);
                                                
                        String errRCV_NO = ObjectUtils.toString(errorDataMap.get("RCV_NO"));
                        String errSUB_CPY_ID = ObjectUtils.toString(errorDataMap.get("SUB_CPY_ID"));
                        
                        sb.append(". RCV_NO = ");
                        sb.append(errRCV_NO);
                        sb.append(", SUB_CPY_ID = ");
                        sb.append(errSUB_CPY_ID);
                        sb.append("\n");                        
                        
				    } else if("DTEPC324".equals(tableLoc)) {
                        sb.append("�s�W���ʲ����u���~�B�z�O���ɿ��~�Atable�G ");
                        sb.append(tableLoc);
                        
                        String errTRN_DATE = ObjectUtils.toString(errorDataMap.get("TRN_DATE"));
                        String errSRC_CODE = ObjectUtils.toString(errorDataMap.get("SRC_CODE"));
                        String errSER_NO = ObjectUtils.toString(errorDataMap.get("SER_NO"));
                        
                        sb.append(". TRN_DATE = ");
                        sb.append(errTRN_DATE);
                        sb.append(", SRC_CODE = ");
                        sb.append(errSRC_CODE);
                        sb.append(", SER_NO = ");
                        sb.append(errSER_NO);
                        sb.append("\n");
                        
				    } else if("DTEPC322".equals(tableLoc)) {
                        sb.append("�R�����ʲ����u���~���G�ɿ��~�Atable�G ");
                        sb.append(tableLoc);
                        
                        String errTRN_DATE = ObjectUtils.toString(errorDataMap.get("TRN_DATE"));
                        String errSRC_CODE = ObjectUtils.toString(errorDataMap.get("SRC_CODE"));
                        String errSER_NO = ObjectUtils.toString(errorDataMap.get("SER_NO"));
                        
                        sb.append(". TRN_DATE = ");
                        sb.append(errTRN_DATE);
                        sb.append(", SRC_CODE = ");
                        sb.append(errSRC_CODE);
                        sb.append(", SER_NO = ");
                        sb.append(errSER_NO);
                        sb.append("\n");                        
				    }
					
					memo = sb.toString();
                    sb.setLength(0);
                                     
					setExitCode(ERROR);    
					ERROR_COUNT += 1;
       
					return memo;
				}
			
				
				@Override
				protected void executeBatchProcess() throws Exception {	
					
	                //�� SPEC �@�~�y�{�Ƨ�
				    bc.addCountNumber(C321_UPD_COUNT, updC321Count);				    
					bc.addCountNumber(REC_PAY_COUNT, insC301Count);
                    bc.addCountNumber(REC_UPD_COUNT, updC101Count);
                    bc.addCountNumber(OUTPUT_COUNT, insC324Count);
                    bc.addCountNumber(DEL_COUNT, delC322Count);
					
		            bc.addCountNumber(ACNT_ERR_COUNT, acntErrorCount);
		            bc.addCountNumber(SLRY_OK_COUNT, salaryOKCount);
		            bc.addCountNumber(SLRY_FAIL_COUNT, salaryFailCnt);
									
					//�k�s�O�קK�U�@�����j��A���ƥ[�O��e���p��
		            //�� SPEC �@�~�y�{�Ƨ�
		            updC321Count = 0;
		            insC301Count = 0;					
					updC101Count = 0;
					insC324Count = 0;
					delC322Count = 0;					
					
					acntErrorCount = 0;
					salaryOKCount = 0;
					salaryFailCnt = 0;					
				}
			
				@Override
				protected void lastProcess() throws Exception {
				    
                    DataSet ds_ins_C306 = Transaction.getDataSet();
				    
                    tableLoc = "DTEPC306";                    
				    for(Map.Entry<String, Map> entry : mapSumC306.entrySet()) {
				        
				        Transaction.begin();
				        Map mapC306 = entry.getValue();//�C�@�� key �����@��: CLC_DIV_NO + "_" + balType
				        
				        try{				            
	                        ds_ins_C306.setField("SUB_CPY_ID", mapC306.get("SUB_CPY_ID"));                      
	                        ds_ins_C306.setField("PAY_NO", mapC306.get("PAY_NO"));
	                        ds_ins_C306.setField("CSH_AMT", BigDecimal.ZERO);//���O�O Decimal(12, 2)
	                        ds_ins_C306.setField("CHK_AMT", BigDecimal.ZERO);//���O�O Decimal(12, 2)
	                        ds_ins_C306.setField("RMT_AMT", BigDecimal.ZERO);//���O�O Decimal(12, 2)
	                        ds_ins_C306.setField("TKD_AMT", BigDecimal.ZERO);//���O�O Decimal(12, 2)
	                        ds_ins_C306.setField("ACNT_AMT", BigDecimal.ZERO);//���O�O Decimal(12, 2)
	                        ds_ins_C306.setField("MAL_AMT", BigDecimal.ZERO);//���O�O Decimal(12, 2)
	                        ds_ins_C306.setField("PAY_AMT", new BigDecimal(ObjectUtils.toString(mapC306.get("ACNT_OK_AMT"))));//���O�O Decimal(12, 2)
	                        ds_ins_C306.setField("DACNT_AMT", BigDecimal.ZERO);//���O�O Decimal(12, 2)
	                        ds_ins_C306.setField("TMP_AMT", BigDecimal.ZERO);//���O�O Decimal(12, 2)
	                        ds_ins_C306.setField("CHK_SET_NO", "");
	                        ds_ins_C306.setField("RMT_SET_NO", "");
	                        ds_ins_C306.setField("ACNT_SET_NO", "");
	                        ds_ins_C306.setField("INPUT_ID", PROGRAM);
	                        ds_ins_C306.setField("INPUT_NAME", "���~�P�b");
	                        ds_ins_C306.setField("SLIP_SET_NO", 0);//���O�O INTEGER
	                        ds_ins_C306.setField("TRN_KIND", "01");                     
	                        ds_ins_C306.setField("CHG_DATE", pcsDACNT_DATE);//�t�Τ���ɶ�
	                        ds_ins_C306.setField("CHG_DIV_NO", mapC306.get("CLC_DIV_NO"));
	                        ds_ins_C306.setField("CHG_ID", mapC306.get("BAL_TYPE"));
	                        ds_ins_C306.setField("CHG_NAME", "���~�P�b�b�U�O");
	                        ds_ins_C306.setField("CARD_D_NO", "");
	                        ds_ins_C306.setField("CARD_D_AMT", BigDecimal.ZERO);//���O�O Decimal(12, 2)	                        
	                        ds_ins_C306.setField("SAL_D_AMT", new BigDecimal(ObjectUtils.toString(mapC306.get("ACNT_OK_AMT"))));//���O�O Decimal(12, 2)
	                        ds_ins_C306.setField("TMP_NO", "");
	                        ds_ins_C306.setField("DTMP_NO", "");
	                        insC306Count++;
	                        
	                        //�s�W��ú�ڰO���� DTEPC306
	                        DBUtil.executeUpdate(ds_ins_C306, SQL_INSERT_DTEPC306);
	                        
	                        Transaction.commit();
				        } catch(Exception e) {
			                //�Y�g�J���~�Grollback �^�{����l���A���
			                Transaction.rollback();
			                setExitCode(ERROR);
			                log.fatal(e.getMessage(), e);
			                //���~�B�z�G�֭p���ѥ��
			                ERROR_COUNT += 1;
			                sb.setLength(0);
			                sb.append(tableLoc);
			                sb.append(". SUB_CPY_ID = ");
			                sb.append(mapC306.get("SUB_CPY_ID"));
			                sb.append(", PAY_NO = ");
			                sb.append(mapC306.get("PAY_NO"));
			                bc.addErrorLog("����table���`", sb.toString());
			                bc.writeErrorLog();
			                sb.setLength(0);
			                //�����{���B�{�����浲�G���`
			                throw new Exception("ú�ڬ����ɸ�Ƽg�J���~" + e.getMessage(), e);
			            }
				        						
					}
				    bc.addCountNumber(PAY_INS_COUNT, insC306Count);
					
				    
					
                    
                    DataSet ds_upd_C320 = Transaction.getDataSet();
                    tableLoc = "DTEPC320";
				    //�v���B�z
				    for(Map.Entry<String, Map> entry : mapYMSumData.entrySet()) {

				        Transaction.begin();
				        Map ymSumData = entry.getValue();    

				        try {
	                        ds_upd_C320.setField("PAY_GRP", PAY_GRP);
	                        ds_upd_C320.setField("SLRY_YYMM", new BigDecimal(ObjectUtils.toString(ymSumData.get("SLRY_YYMM"))));//DECIMAL(6) ���O
	                        ds_upd_C320.setField("SLRY_CTL_STS", "5");//�P�b����
	                        ds_upd_C320.setField("DACNT_DATE", pcsDACNT_DATE);              
	                        ds_upd_C320.setField("SLY_OK_CNT", ymSumData.get("SLY_OK_CNT"));//INTEGER
	                        ds_upd_C320.setField("SLY_FAIL_CNT", ymSumData.get("SLY_FAIL_CNT"));//INTEGER
	                        ds_upd_C320.setField("DACNT_CNT", ymSumData.get("SLY_CNT"));//INTEGER
	                        ds_upd_C320.setField("DACNT_ERR_CNT", ymSumData.get("ACNT_ERR_CNT"));//INTEGER
	                        ds_upd_C320.setField("DACNT_AMT", new BigDecimal(ObjectUtils.toString(ymSumData.get("SLY_OK_AMT"))));//DECIMAL(12) ���O
	                        updC320Count++;

	                        //��s�ܤ��ʲ����u���~�էO����]�w DTEPC320
	                        DBUtil.executeUpdate(ds_upd_C320, SQL_UPDATE_DTEPC320); 
	                        
	                        Transaction.commit();
				        } catch(Exception e) {
                            //�Y��s���~�Grollback �^�{����l���A���
                            Transaction.rollback();
                            setExitCode(ERROR);
                            log.fatal(e.getMessage(), e);
                            //���~�B�z�G�֭p���ѥ��
                            ERROR_COUNT += 1;
                            sb.setLength(0);
                            sb.append(tableLoc);
                            sb.append(". PAY_GRP = ");                            
                            sb.append(PAY_GRP);
                            sb.append(", SLRY_YYMM = ");
                            sb.append(ymSumData.get("SLRY_YYMM"));
                            bc.addErrorLog("����table���`", sb.toString());
                            bc.writeErrorLog();
                            sb.setLength(0);
                            //�����{���B�{�����浲�G���`
                            throw new Exception("���ʲ����u���~�էO����]�w�ɸ�Ƨ�s���~" + e.getMessage(), e);
                        }				        
					}
				    bc.addCountNumber(CTRL_UPD_COUNT, updC320Count);     
				    					
					
					
					//�H�e�P�b�B�z�q��
				    //1. ���o�T���q�������q�O
					EP_B30010 ep_b30010 = new EP_B30010();
					EP_Z10030 ep_z10030 = new EP_Z10030();
					RZ_S00300 rz_s00300 = new RZ_S00300();
					String COMP_ID = null;
					try {
                        COMP_ID = ep_b30010.getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);
                    } catch (Exception me) {
                        sb.setLength(0);
                        sb.append("���o�T���q�������q�O�o�Ϳ��~�A�����q�O�G");
                        sb.append(SUB_CPY_ID);
                        sb.append(", ");
                        sb.append(me.getMessage());
                        log.fatal(sb.toString(), me);
                        sb.setLength(0);
                    }
					
					//2. �]�w�q����H�M��
					List<Map> recList = new ArrayList<Map>();
					try {
                        Map<String, List<DTEPZ103>> nMap = ep_z10030.getMailList(SUB_CPY_ID, EVENT_ID);
                        if(nMap.size() == 0) {
                            //�Y�d�L��ơA ��X���~���� B�A�{�����_
                            try {
                                bc.addErrorLog("�q����H�]�w���~", "���ʲ����~�P�b���q��");
                                bc.writeErrorLog();
                                setExitCode(ERROR);
                                ERROR_COUNT++;                                
                            } catch (Exception e) {
                                log.fatal(e.getMessage(), e);                                
                            }
                            return;
                        }
                        
                        List<DTEPZ103> mailList = nMap.get(SUB_CPY_ID);                                                
                        for(DTEPZ103 z103: mailList) {
                            Map receipt = new HashMap();
                            receipt.put("EVENT_ID", EVENT_ID);
                            receipt.put("USER_ID", z103.getID());
                            receipt.put("USER_EMAIL", z103.getEMAIL());
                            recList.add(receipt);
                        }
                    } catch (ModuleException me) {
                        sb.setLength(0);
                        sb.append("�]�w�q����H�M��o�Ϳ��~�A�����q�O�G");
                        sb.append(SUB_CPY_ID);
                        sb.append(", ");
                        sb.append(me.getMessage());
                        log.fatal(sb.toString(), me);
                        sb.setLength(0);
                    }
					
					//3. �B�zEMAIL����������]�w
					List<Map> titleList = new ArrayList<Map>();
					//���o���~�էO����
					String PAY_GRP_NM = FieldOptionList.getName("EP", "PAY_GRP", PAY_GRP);
					mailColAndCont(titleList, "DIV_NAME", "�޲z���", 10);
					mailColAndCont(titleList, "SLY_CNT", PAY_GRP_NM+"���~���", 5);
					mailColAndCont(titleList, "SLY_OK_CNT", "���~���\���", 5);
					mailColAndCont(titleList, "SLY_FAIL_CNT", "���~�������", 5);
					mailColAndCont(titleList, "SLY_OK_AMT", "���~���\���B", 5);
					mailColAndCont(titleList, "ACNT_ERR_CNT", "�P�b���~���", 5);		
                    
					//4. �H�e�q�����e
					//�N Map <String, Map> mapSumData ��value ��J List<Map> dataList
					List<Map> dataList = new ArrayList<Map>();
					
	                for(Map.Entry<String, Map> entry : mapSumData.entrySet()) {
	                    Map sumData = entry.getValue();
					    dataList.add(sumData);
					}
	                
	                String ERR_MSG = null;
	                try {
	                    ERR_MSG = rz_s00300.createRecordByDIV(EVENT_ID, "EP", (java.sql.Date) SYS_DT, recList, titleList, dataList, COMP_ID);
	                    
	                    //�p�GERRMSG���ȡG��X���~�O��C�A�{�����_
	                    if(StringUtils.isNotBlank(ERR_MSG)) {
	                        bc.addErrorLog("�H�e�q�����~", ERR_MSG);
	                        bc.writeErrorLog();
	                        setExitCode(ERROR);
	                        ERROR_COUNT++;
	                        return;
	                    }
	                    
	                } catch(Exception e) {
	                    log.fatal(e.getMessage(), e);
	                    throw new Exception(e.getMessage(), e);
	                }

					//�H�e���ڤ����B�z�q��
                    //1. ���o�T���q�������q�O (�M�H�e�P�b�B�z�q���ۦP�A�G������)
					//2. �B�zEMAIL����������]�w
					List<Map> failTitleList = new ArrayList<Map>();
                    mailColAndCont(failTitleList, "BLD_NAME", "�j�ӦW��", 15);
                    mailColAndCont(failTitleList, "CRT_NO", "�����N��", 10);
                    mailColAndCont(failTitleList, "CUS_NAME", "�Ȥ�W��", 10);
                    mailColAndCont(failTitleList, "TOT_AMT", "�������B", 5);
                    mailColAndCont(failTitleList, "DCT_RSLT_NM", "���~���G", 15);
                   
                    //3. �v�@�B�z���ڤ����q��
                    PersonnelData pd = new PersonnelData();
                    
                    for(String failID : mapFailNotify.keySet()) {
                        
                        //���o�H�ư򥻸��                        
                        Employee empData = pd.getByEmployeeID(failID);
                        
                        //�YempData ���ȡG�]�w���ڤ����q����H�M��  & �H�e���ڤ����q��
                        if(empData != null) {
                            
                            List failDataList = mapFailNotify.get(failID); 
                            
                            //�]�w���ڤ����q����H�M��
                            List<Map> failRecList = new ArrayList<Map>();
                            Map receipt = new HashMap();
                            receipt.put("EVENT_ID", FAIL_EVENT_ID);
                            receipt.put("USER_ID", failID);
                            receipt.put("USER_EMAIL", empData.getEmail());
                            failRecList.add(receipt);

                            //�H�e���ڤ����q��
                            try{
                                rz_s00300.createRecordByDIV(FAIL_EVENT_ID, "EP", (java.sql.Date) SYS_DT, failRecList, failTitleList, failDataList, COMP_ID);
                            } catch(Exception e) {
                                log.fatal(e.getMessage(), e);
                                throw new Exception(e.getMessage(), e);
                            }
                            
                        }                        
                    }					
                    
                    //2019.05.20 update : �~�Ȩ��˧��b�H�e�Ҧ� mail ����
                    //��s��󱱨���
                    //�]�w�~�Ȩ���
                    DTZZM010 dtzzm010 = new DTZZM010();
                    ZZ_M0Z020 zz_m0z020 = new ZZ_M0Z020();
                    String SHUT_DATE = new CathayDate().getShutdownDay();
                    dtzzm010.setSHUT_DT(SHUT_DATE);
                    dtzzm010.setSYS_CODE("EP");
                    dtzzm010.setJOB_NAME(JOB_NAME);
                    dtzzm010.setPROGRAM(PROGRAM);
                    
                    String CNT_ITEM = null;
                    //�v���B�z
                    for(Map.Entry<String, Map> entry : mapYMSumData.entrySet()) {
                        
                        Map ymSumData = entry.getValue();    

                        //��X���~���\��Ʒ~�Ȩ��˶���
                        CNT_ITEM = FieldOptionList.getName("EP", "SLRY_ACNT_ITEM", PAY_GRP + "_SLY_OK_CNT");
                        dtzzm010.setCNT_ITEM(CNT_ITEM);
                        dtzzm010.setCNT_VALUE(ObjectUtils.toString(ymSumData.get("SLY_OK_CNT")));
                        zz_m0z020.doInsertDTZZM010(dtzzm010, true);//2019.05.20 update : �Ѽƥ[�W�ĤG�� = true
                        
                        //��X���~���ѥ�Ʒ~�Ȩ��˶���
                        CNT_ITEM = FieldOptionList.getName("EP", "SLRY_ACNT_ITEM", PAY_GRP + "_SLY_FAIL_CNT");
                        dtzzm010.setCNT_ITEM(CNT_ITEM);
                        dtzzm010.setCNT_VALUE(ObjectUtils.toString(ymSumData.get("SLY_FAIL_CNT")));
                        zz_m0z020.doInsertDTZZM010(dtzzm010, true);//2019.05.20 update : �Ѽƥ[�W�ĤG�� = true
                        
                        //��X���~���\���B�~�Ȩ��˶���
                        CNT_ITEM = FieldOptionList.getName("EP", "SLRY_ACNT_ITEM", PAY_GRP + "_SLY_OK_AMT");
                        dtzzm010.setCNT_ITEM(CNT_ITEM);
                        BigDecimal SLY_OK_AMT = STRING.objToBigDecimal(ymSumData.get("SLY_OK_AMT"), BigDecimal.ZERO);
                        String slyOkAmt = SLY_OK_AMT.toPlainString();
                        dtzzm010.setCNT_VALUE(slyOkAmt);
                        zz_m0z020.doInsertDTZZM010(dtzzm010, true);//2019.05.20 update : �Ѽƥ[�W�ĤG�� = true
                        
                        //��X�P�b��Ʒ~�Ȩ��˶���
                        CNT_ITEM = FieldOptionList.getName("EP", "SLRY_ACNT_ITEM", PAY_GRP + "_SLY_CNT");
                        dtzzm010.setCNT_ITEM(CNT_ITEM);
                        dtzzm010.setCNT_VALUE(ObjectUtils.toString(ymSumData.get("SLY_CNT")));
                        zz_m0z020.doInsertDTZZM010(dtzzm010, true);//2019.05.20 update : �Ѽƥ[�W�ĤG�� = true
                        
                    }                      
                    
				}
				

				
				
			});						

						
		} catch(DataNotFoundException dnfe) {
			setExitCode(OK);
			bc.addErrorLog("�d�L���~�էO", PAY_GRP);
			bc.writeErrorLog();
			//�{���פ�
		} catch(Exception e) {
			//�G�B���~�B�z
			//�]�w�w�w�^�Ǫ��T�� (���A�T�{���e�O�_���T)
			log.fatal("����妸�ɵo�Ϳ��~�G" + e.getMessage(), e);
			setExitCode(ERROR);			
			throw e;
		} finally {
		    
		    bc.writeErrorLog();
			//�ϥ� BatchConstructor ���Φۤv�����s�u�C���n���o bc �� ExitCode �A set �^�h
			int batchConstructorExitCode = bc.getExitCode();
			if(batchConstructorExitCode != OK) {
				setExitCode(batchConstructorExitCode);
			}
			printExitCode(batchConstructorExitCode);
		}
	}
	
	
    /**
     * �Ѽ��ˮ� (PAY_GRP�����ǤJ)
     * @param  args
     * @return PAY_GRP
     * @throws ErrorInputException
     */
	private String chkArgs(String[] args) throws ErrorInputException {
	    try {
            if (args == null || args.length == 0) {
                throw new ErrorInputException("���ǤJ���~�էO");
            }
            PAY_GRP = args[0];//PAY_GRP �T�w�T�X
            sb.append("�ǤJ���~�էO�G").append(PAY_GRP);
            log.fatal(sb.toString());
            sb.setLength(0);
            
            return PAY_GRP;
            
        } catch (Exception e) {
            setExitCode(ERROR);
            log.fatal("�ǤJ�Ѽƿ��~�G" + e.getMessage(), e);
            throw new ErrorInputException("�ǤJ�Ѽƿ��~�G" + e.getMessage(), e);
        }
	}	   	
	
    /**
     * EMAIL����]�w (�H�e�P�b�B�z�q���B�H�e���ڤ����B�z�q���A�i�@��)
     * @param titleList
     * @param FIELD
     * @param FIELD_NM
     * @param FIELD_SIZE
     */
    private void mailColAndCont(List<Map> titleList, String FIELD, String FIELD_NM, int FIELD_SIZE) {
        Map<String, Object> styleMap = new HashMap<String, Object>();
        styleMap.put("FIELD", FIELD);
        styleMap.put("FIELD_NM", FIELD_NM);
        styleMap.put("FIELD_SIZE", FIELD_SIZE);
        titleList.add(styleMap);
    }
	
	
}
