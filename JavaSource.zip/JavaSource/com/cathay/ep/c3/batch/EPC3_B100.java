package com.cathay.ep.c3.batch;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.rz.s0.module.RZ_S00300;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.DBException;

/** 
 * <pre>
 * �@�B	�{���\�෧�n�����G
 * �{���\��	���~����]�w�妸���˳q��
 * �{���W��	EPC3_B100
 * �@�~�覡	BATCH
 * ���n����	�C�~�~���۰ʨ��ˤU�Ӧ~�ת����~�էO�Ƶ{�O�_�����]�w�P�T�{
 * �w����ƶq	5000 (�̤j��)
 * �@�~�W��	JAEPYC001
 * �~�ȧO	EP
 * ���t�ΦW��	C3
 * �B�z�g��	�~
 * ����B�z���	�L
 * �ݨD���	���ʲ��޲z�����ʲ��޲z�G��
 * �@�~���	����T����ڸ�T��
 * </pre>
 * @author ���W�_
 * @since 2019/05/16  
 */
@SuppressWarnings("unchecked")
public class EPC3_B100 extends EP_BatchBean {
    private static final Logger log = Logger.getLogger(EPC3_B100.class);

    /** �@�~�W�� */
    private static final String JOB_NAME = "JAEPYC001";

    /** �{���W�� */
    private static final String PROGRAM = "EPC3_B100";

    /** ����g�� */
    private static final String PERIOD = "�~";

    private String EVENT_ID = "EP_RA006"; //  �ƥ�N�� 

    private String SUB_CPY_ID = "00"; //  �����q�O

    private Date SYS_DT;

    private int iDataYear; //  ���~�~��

    private boolean needNotify = false; //  �ˮֵ��G

    private List<Map> dataList = new ArrayList<Map>(); //  �q�����������

    private List<Map> recList = new ArrayList<Map>(); //  �q����H

    private List<Map> titleList = new ArrayList<Map>(); //  �q������������

    private EP_B30010 theEP_B30010 = new EP_B30010(); // �߮׿�J���@�Ҳ�

    private EP_Z10030 theEP_Z10030 = new EP_Z10030(); // �����q�����@�Ҳ�

    private RZ_S00300 theRZ_S00300 = new RZ_S00300(); // �T���q���B�z�Ҳ�

    private String COMP_ID;

    private String ERROR_COUNT = "���~���";

    /**
     * <pre>
     * select a.OPTION,
     * a.NAME,
     *       b.PAY_GRP,
     *       count(*) INPUT_CNT,
     *       sum (case when b.SLRY_CTL_STS >= '2' then 1 else 0 end) CFM_CNT
     *  from DBCM.DVCM0006 a
     *  left join DBEP.DTEPC320 b
     *    on b.PAY_GRP = a.OPTION and b.DATA_YEAR = ':iDataYear'
     * where a.SYSID = 'EP' and a.FIELD_NAME = 'PAY_GRP'
     * group by a.OPTION, a.NAME, b.PAY_GRP
     * with ur
     * </pre>
     */
    private static final String SQL_QUERY_001 = "com.cathay.ep.c3.batch.EPC3_B100.SQL_QUERY_001";

    @Override
    public void execute(String[] args) throws Exception {
        final BatchConstructor bc = new BatchConstructor(JOB_NAME, PROGRAM, PERIOD);
        try {
            SYS_DT = DATE.today();
            //�Ѽ��ˮ�
            if (args != null && args.length > 0) {
                String DATA_YEAR = args[0];
                try {
                    iDataYear = Integer.parseInt(DATA_YEAR);
                } catch (NumberFormatException nfe) {
                    //���~�B�zA�o�͡A�ithrow new NumberFormatException();
                    ErrorHandler(bc, "�ǤJ���~�~�׿��~", new StringBuilder("���~�~��{").append(DATA_YEAR).append("}���~").toString());
                }
            } else {
                iDataYear = Integer.parseInt(DATE.addDate(DATE.getDBDate(), 1, 0, 0).split("-")[0]);
            }
            //�{����
            bc.execute(new BatchConstructor.DataBaseHandler() {
                String INPUT_COUNT = "���~�էO����";//bqds �d�ߵ���

                String CONFIG_COUNT = "�]�w����";//configCount

                String CONFIRM_COUNT = "�T�{����";//confirmCount

                int configCount = 0; //  �]�w����

                int confirmCount = 0; //  �T�{����

                @Override
                protected boolean firstProcess() throws Exception {
                    bc.createCountType(INPUT_COUNT);
                    bc.createCountType(CONFIG_COUNT);
                    bc.createCountType(CONFIRM_COUNT);
                    return true;
                }

                @Override
                protected void executeBatchProcess() throws Exception {
                    bc.addCountNumber(CONFIG_COUNT, configCount);
                    bc.addCountNumber(CONFIRM_COUNT, confirmCount);
                    configCount = 0;
                    confirmCount = 0;
                }

                @Override
                protected boolean searchProcess(BatchQueryDataSet bqds) throws DBException, ModuleException {
                    bqds.setField("iDataYear", iDataYear);
                    bqds.searchAndRetrieve(SQL_QUERY_001);
                    if (bqds.getTotalCount() == 0) {
                        log.fatal("�d�L���");
                        return false;
                    } else {
                        bc.addCountNumber(INPUT_COUNT, bqds.getTotalCount());
                    }
                    return true;
                }

                @Override
                protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {
                    Map dataMap = VOTool.dataSetToMap(bqds);
                    int iMMCnt = Integer.parseInt(FieldOptionList.getName("EP", "PAY_GRP_MM", ObjectUtils.toString(dataMap.get("PAY_GRP")))); //�ন���
                    int iInputCnt = Integer.parseInt(ObjectUtils.toString(dataMap.get("INPUT_CNT"),"0")); //�ন���
                    int iConfirmCnt = Integer.parseInt(ObjectUtils.toString(dataMap.get("CFM_CNT"),"0")); //�ন���
                    configCount += iInputCnt; //�X�p�]�w����
                    confirmCount += iConfirmCnt; //�X�p�T�{����

                    StringBuilder sbCHK_MEMO = new StringBuilder();
                    if (iInputCnt < iMMCnt) {
                        sbCHK_MEMO.append("�ݳ]�w").append(iMMCnt - iInputCnt).append("��");
                        dataMap.put("CHK_MEMO", sbCHK_MEMO.toString());
                        needNotify = true;
                    } else if (iConfirmCnt < iMMCnt) {
                        sbCHK_MEMO.append("�ݽT�{").append(iMMCnt - iConfirmCnt).append("��");
                        dataMap.put("CHK_MEMO", sbCHK_MEMO.toString());
                        needNotify = true;
                    } else {
                    	dataMap.put("CHK_MEMO", "�����]�w�T�{");
                    }
                    dataList.add(dataMap);
                    if (needNotify) {}
                }

                @Override
                protected void lastProcess() {
                    try {
                    	if(needNotify) {
                            COMP_ID = theEP_B30010.getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);
                            Map<String, List<DTEPZ103>> nMap = theEP_Z10030.getMailList(SUB_CPY_ID, EVENT_ID);
                            //���~�B�zB�o�͡A�i�אּ!=
                            if (nMap.size() == 0) {
                                ErrorHandler(bc, "�q����H�]�w���~", "���~�էO����q����H");
                            }

                            List<DTEPZ103> mailList = nMap.get(SUB_CPY_ID);
                            for (DTEPZ103 z103 : mailList) {
                                Map recepit = new HashMap();
                                recepit.put("EVENT_ID", EVENT_ID);
                                recepit.put("USER_ID", z103.getID());
                                recepit.put("USER_EMAIL", z103.getEMAIL());

                                recList.add(recepit);
                            }

                            String[][] titleArray = { { "NAME", "���~�էO", "10" }, { "INPUT_CNT", "�]�w���", "5" }, { "CFM_CNT", "�T�{���", "5" },
                                    { "CHK_MEMO", "�ˮֻ���", "15" } };
                            for (String[] title : titleArray) {
                                Map titleMap = new HashMap();
                                titleMap.put("FIELD", title[0]);
                                titleMap.put("FIELD_NM", title[1]);
                                titleMap.put("FIELD_SIZE", title[2]);
                                if (titleList.size() < titleArray.length) {
                                    titleList.add(titleMap);
                                } else {
                                    continue;//�����Ʀs��H�󤺤����
                                }
                            }
                                            	

                            String ERR_MSG = theRZ_S00300.createRecordByDIV(EVENT_ID, "EP", SYS_DT, recList, titleList, dataList, COMP_ID);

                            //���~�B�zC�o�͡A�i�אּ==
                            if (ERR_MSG.length() != 0) {
                                ErrorHandler(bc, "�H�e�q�����~", ERR_MSG);
                            }
                    	}

                    } catch (Exception e) {
                        setExitCode(ERROR);
                        log.fatal(e.getMessage(), e);
                    }
                }

            });

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.getMessage(), e);
        } finally {
            bc.writeCounter();
            bc.writeErrorLog();

            int batchConstructorExitCode = bc.getExitCode();
            if (batchConstructorExitCode != OK) {
                setExitCode(batchConstructorExitCode);
            }

            printExitCode(getExitCode()); //�^�ǵ� Control_M ���T���N�X , �{���פ�
        }

    }

    /**
     * ���~�B�z
     * @param bc BatchConstructor
     * @param message �T������(MESSAGE)
     * @param memo �K�n(MEMO)
     * @throws Exception �ҥ~
     */
    private void ErrorHandler(BatchConstructor bc, String message, String memo) throws Exception {
        bc.addErrorLog(message, memo);
        setExitCode(ERROR);
        if (bc.getAllCountTypeAndNumber().get(ERROR_COUNT) == null) {
            bc.createCountType(ERROR_COUNT);
        }
        bc.addCountNumber(ERROR_COUNT, 1);
        throw new Exception();
    }
}