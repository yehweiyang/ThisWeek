package com.cathay.ep.c3.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.CathayDate;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.util.FileStoreUtil;
import com.cathay.util.Transaction;
import com.cathay.zz.bo.DTZZM010;
import com.cathay.zz.m0.module.ZZ_M0Z020;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * Date        Version Description                           Author
 * 2019/04/22  1.0     Created                               ������
 * 
 * �@�B�{���\�෧�n�����G
 * �{���\��      ���u���~���Ӹ�ƶ���
 * �{���W��      EPC3_B120.java
 * �@�~�覡      BATCH
 * ���n����      �C��d�ߦ��~�էO����]�w�A�̾ڳ]�w����i�榩�~��������
 * �w����ƶq    5000(�̤j��)
 * �@�~�W��      JAEPDC003
 * �~�ȧO        EP
 * ���t�ΦW��    C3
 * �B�z�g��      ��
 * ����B�z���  �L
 * </pre>
 * 
 * @author ������
 * @since 2019/04/30
 * 2019/06/10 AllenTsai �վ� JOB_NAME�A��K�]�w�Ƶ{
 * 2019/06/18 AllenTsai �վ��ɮ׿�X���|
 * 2019/09/20 AllenTsai �վ�@�~�W�ٻPControM�@�P
 * 2019/09/25 AllenTsai �վ�p�p�ɿ�X�A�W�[�~�z�N�����p�p�A��ƻP���B
 */
public class EPC3_B120 extends EP_BatchBean {

    /** logger */
    private static final Logger log = Logger.getLogger(EPC3_B120.class);

    /** �@�~�W�� */
    private static final String JOB_NAME = "JAEPDC003";

    /** �{���W�� */
    private static final String PROGRAM = "EPC3_B120";

    /** �B�z�g�� */
    private static final String PERIOD = "��";

    /** �ŧi�ϥΪ� SQL��k */
    /**
     * <pre>
     * select * from DBEP.DTEPC320  
     *  where PAY_GRP = ':PAY_GRP'
     *    and SLRY_DATE = ':SYS_DATE'
     *    and SLRY_CTL_STS	= '3'
     *   with ur
     * </pre>
     */
    private static final String SQL_QUERY_DTEPC320_001 = "com.cathay.ep.c3.batch.EPC3_B120.SQL_QUERY_DTEPC320_001";

    /**
     * <pre>
     * select a.TRN_DATE, a.SRC_CODE, a.SER_NO, a.COMP_ID, a.AREA_CODE, a.EMPLOYEE_ID,
     *        a.SLRY_KIND, a.SLRY_YYMM, a.PAY_GRP, a.SLRY_CODE, a.TOT_AMT, a.CURR_CODE,
     *        a.DIV_NO, a.POSITION, a.PROC_CODE, a.DCT_CTGY, a.DCT_FAIL_PROC
     *   from DBEP.DTEPC321 as a
     *   join DBEP.DTEPC320 b
     *     on b.PAY_GRP = a.PAY_GRP
     *    and b.SLRY_YYMM = a.SLRY_YYMM
     *  where b.PAY_GRP = ':PAY_GRP'
     *    and b.SLRY_YYMM = ':SLRY_YYMM'
     *    and b.SLRY_CTL_STS = '3'
     *    and a.SLRY_STS = '0'
     *   with ur
     * </pre>
     */
    private static final String SQL_QUERY_001 = "com.cathay.ep.c3.batch.EPC3_B120.SQL_QUERY_001";

    /**
     * <pre>
     * update DBEP.DTEPC320
     *    set SLRY_CTL_STS = '4',
     *        SLRY_PASS_DATE = ':SLRY_PASS_DATE'
     *  where PAY_GRP = ':PAY_GRP'
     *    and SLRY_YYMM = ':SLRY_YYMM'
     * </pre>
     */
    private static final String SQL_UPDATE_DTEPC320_001 = "com.cathay.ep.c3.batch.EPC3_B120.SQL_UPDATE_DTEPC320_001";

    /** �@�~���/����� */
    private Date SYS_DT = DATE.today();

    /** �妸���ɳB�z�ɶ� */
    private Timestamp pcsPass_DATE = DATE.currentTime();                                                         

    /** ���~��� */
    private int iTOT_CNT = 0;

    /** ���~�էO */
    private String PAY_GRP;

    /** �ɮ׿�X��y */
    BufferedWriter bwDTL = null;

    BufferedWriter bwDTLOK = null;

    BufferedWriter bwSUM = null;

    BufferedWriter bwSUMOK = null;

    /** �ɮצW�� */
    File detailFileNM = null;

    File detailOKNM = null;

    File sumFileNM = null;

    File sumOKNM = null;

    /** ���~�էO����]�w�Ѽ� */
    Map mapC320 = null;
    
    //2019/09/25 AllenTsai �W�[�~�z�N���p�p��T 
    Map<String, Map<String, Integer>> mapSumData = new TreeMap<String, Map<String, Integer>>();

    /** ���o���~����ӳ]�w */
    Map<String, String> mapSLRY_CFG = new HashMap<String, String>();
    /** ���o���~���ɮ׸��|�]�w */
    Map<String, String> mapSLRY_FILE = new HashMap<String, String>();    

    /** ���~��� */
    int errorCount = 0;

    StringBuilder sb = new StringBuilder();

    /** ����妸�@�~ */
    /**
     * method 1: execute (�D�{��)
     * 
     * @param args[]
     * @return
     * @throws Exception
     */
    public void execute(String[] args) throws Exception {

        // �]�w BatchConstructor (�ѼƤ��O��"�@�~�W�١B�{���W�١B����g��")
        final BatchConstructor bc = new BatchConstructor(JOB_NAME, PROGRAM, PERIOD);

        try {
            // �@�B�{���D��G
            // �ˮְѼ�
            PAY_GRP = chkArgs(args);

            mapC320 = getSalaryConfig(PAY_GRP, SYS_DT);

            if (mapC320 == null) {
                bc.addErrorLog("�d�L���~�էO", PAY_GRP);
                bc.writeErrorLog();
                setExitCode(OK); 
                return;//�d�L��ƥ��`���� 
            }

            // ���o���~����ӳ]�w (�ϥΥN�X�����Ӹ��)
            mapSLRY_CFG = FieldOptionList.getName("EP", "SLRY_CFG");

            // ���o�ɮץؿ�
            sb.setLength(0);
            File file = new File(sb.append(FileStoreUtil.getFTPH2URoot()).append(File.separator).append("DBEP").toString());
            if (!file.exists()) {
                file.mkdirs();
            }
            
            File sumfile = file;
            File dtlfile = file;

            try{
                mapSLRY_FILE =  FieldOptionList.getName("EP", "SLRY_FILE_PATH");
                String sysID= MapUtils.getString(mapSLRY_FILE, "SYS_ID");
                String subDir= MapUtils.getString(mapSLRY_FILE, "SUB_DIR");
                String sumDir= MapUtils.getString(mapSLRY_FILE, "SUM");
                String dtlDir= MapUtils.getString(mapSLRY_FILE, "DTL");
                //�Y���]�w���~�ɮ׸��| �ϥΦ��~���|���� ���ӻP�K�n�ɮ׸��|
                //�έp��  /home/ftpusr/host_to_unix/DBFK/T2/sum
                //������   /home/ftpusr/host_to_unix/DBFK/T2/DTL
				if (StringUtils.isNotEmpty(sysID)
						&& StringUtils.isNotEmpty(subDir)
						&& StringUtils.isNotEmpty(sumDir)
						&& StringUtils.isNotEmpty(dtlDir)) {
					sb.setLength(0);
					sb.append(FileStoreUtil.getFTPH2URoot())
							.append(File.separator).append(sysID)
							.append(File.separator).append(subDir);
					String fkFileDir = sb.toString();
					sb.setLength(0);
					sb.append(fkFileDir).append(File.separator).append(sumDir);
					sumfile = new File(sb.toString());
					log.debug("SUM FilePath:"+ sumfile.getAbsolutePath());
					
					sb.setLength(0);
					sb.append(fkFileDir).append(File.separator).append(dtlDir);
					dtlfile = new File(sb.toString());
                    log.debug("DTL FilePath:"+ dtlfile.getAbsolutePath());
				}
            }catch(Exception e) {
                sumfile = file;
                dtlfile = file;            	
            }
            

            // ���o�ɮצW��
            sb.setLength(0);
            String fileFirstName = "DTEPC321_";
            sb.append(fileFirstName);// ���� = 9
            sb.append(PAY_GRP);// ���~�էO��ƪ��� = 3
            sb.append("_DTL.txt");
            String tmpDetailFileNM = sb.toString();
            detailFileNM = new File(dtlfile, tmpDetailFileNM);
            if (!detailFileNM.exists()) {
                detailFileNM.createNewFile();
            }

            int newLen = fileFirstName.length() + PAY_GRP.length();
            sb.setLength(newLen);
            sb.append("_DTL.ok");
            String tmpDetailOKNM = sb.toString();
            detailOKNM = new File(dtlfile, tmpDetailOKNM);
            if (!detailOKNM.exists()) {
                detailOKNM.createNewFile();
            }

            sb.setLength(newLen);
            sb.append("_SUM.txt");
            String tmpSumFileNM = sb.toString();
            sumFileNM = new File(sumfile, tmpSumFileNM);
            if (!sumFileNM.exists()) {
                sumFileNM.createNewFile();
            }

            sb.setLength(newLen);
            sb.append("_SUM.ok");
            String tmpSumOKNM = sb.toString();
            sumOKNM = new File(sumfile, tmpSumOKNM);
            if (!sumOKNM.exists()) {
                sumOKNM.createNewFile();
            }
            sb.setLength(0);

            try {
                bwDTL = EncodingHelper.getBufferedWriter(detailFileNM);//�g�ɤ覡�Ѧ�ABA0_B016
                                                                      
            } catch (Exception e) {
                log.fatal("�}���ɮצ�y���~, �ɮצW�١G" + detailFileNM);
                bc.addErrorLog("�}���ɮצ�y���~", "�ɮצW�١G" + detailFileNM);
                bc.writeErrorLog();
                setExitCode(OK);                
            }

            bc.execute(new BatchConstructor.DataBaseHandler() {

                BatchUpdateDataSet buds = bc
                        .getBatchUpdateDataSet(SQL_UPDATE_DTEPC320_001, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                BigDecimal bdTOT_AMT = BigDecimal.ZERO;
                String totAmt = null;

                @Override
                protected boolean searchProcess(BatchQueryDataSet bqds) throws DBException {
                    // �d�ߦ��~�������Ӹ��
                    bqds.setField("PAY_GRP", mapC320.get("PAY_GRP"));
                    bqds.setField("SLRY_YYMM", mapC320.get("SLRY_YYMM"));
                    bqds.searchAndRetrieve(SQL_QUERY_001);
                    // �p�G bqds �d�L��� return false => �i�J finallyProcess�y�{
                    if (bqds.getTotalCount() == 0) {
                        log.fatal("�d�L���~�������Ӹ��");
                        return false;
                    }
                    return true;
                }

                @Override
                protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {

                    // �v���B�z���~�������ӡG��X�� bwDTL
                    try {
                        // �N�d�߸�ƨ�"," ���j�A��X�� bwDTL (��ƨӷ� table �w�] unique key, ���|����ƭ��ƪ����D)
                        sb.append(bqds.getField("TRN_DATE"));
                        sb.append(",");
                        sb.append(bqds.getField("SRC_CODE"));
                        sb.append(",");
                        sb.append(bqds.getField("SER_NO"));
                        sb.append(",");
                        sb.append(bqds.getField("COMP_ID"));
                        sb.append(",");
                        sb.append(bqds.getField("AREA_CODE"));
                        sb.append(",");
                        sb.append(bqds.getField("EMPLOYEE_ID"));// ���~ID
                                                                // EMPLOYEE_ID
                        sb.append(",");
                        sb.append(bqds.getField("SLRY_KIND"));
                        sb.append(",");
                        sb.append(bqds.getField("SLRY_YYMM"));
                        sb.append(",");
                        sb.append(bqds.getField("PAY_GRP"));
                        sb.append(",");
                        //
                        String slry_code = bqds.getField("SLRY_CODE").toString();
                        sb.append(slry_code);
                        sb.append(",");
                        sb.append(bqds.getField("TOT_AMT"));
                        sb.append(",");
                        sb.append(bqds.getField("CURR_CODE"));
                        sb.append(",");
                        sb.append(bqds.getField("DIV_NO"));
                        sb.append(",");
                        sb.append(bqds.getField("POSITION"));
                        sb.append(",");
                        sb.append(bqds.getField("PROC_CODE"));
                        sb.append(",");
                        sb.append(bqds.getField("DCT_CTGY"));
                        sb.append(",");
                        sb.append(bqds.getField("DCT_FAIL_PROC"));
                        // ��X����Ÿ�
                        sb.append("\n");

                        //2019/09/25 AllenTsai �p���~�z�N�� ����ƻP���B�A�Y sumData �L��  ���/���B �w�]�ȵ��s,
                        Map<String, Integer> sumData = mapSumData.get(slry_code);                            
                        if(sumData == null) {
                            sumData = new HashMap<String, Integer>();                            
                            sumData.put("SLY_CNT", 0);
                            sumData.put("SLY_AMT", 0);
                            mapSumData.put(slry_code, sumData);                            
                        }


                        // �p��X�p��T(���~���+1)
                        iTOT_CNT++;
                        BigDecimal caseTotAmt = STRING.objToBigDecimal(bqds.getField("TOT_AMT"), BigDecimal.ZERO);

                        int slryCodeCnt = sumData.get("SLY_CNT") +1;
                        int slryCodeAmt = sumData.get("SLY_AMT") +caseTotAmt.intValue();
                        sumData.put("SLY_CNT", slryCodeCnt);
                        sumData.put("SLY_AMT", slryCodeAmt);
                        
                        // �֥[���~�`���B
                        bdTOT_AMT = bdTOT_AMT.add(caseTotAmt);

                    } catch (Exception e) {
                        // �g�i bwDTL �o�Ϳ��~ => 2019.05.06 �PSA�Q�� => ���~���� D :
                        // ��X��y���~+�ɮצW��
                        log.fatal("��X��y���~�A�ɮצW�١G" + detailFileNM);
                        bc.addErrorLog("��X��y���~", "�ɮצW�١G" + detailFileNM);
                        bc.writeErrorLog();
                    }

                    // ��s��󱱨���
                    buds.setField("SLRY_CTL_STS", "4");
                    buds.setField("SLRY_PASS_DATE", pcsPass_DATE);
                    buds.setField("PAY_GRP", mapC320.get("PAY_GRP"));
                    buds.setField("SLRY_YYMM", mapC320.get("SLRY_YYMM"));

                    // �㵧��ƥ[�J�妸
                    addBatchAndJoinGroup(buds);
                }

                @Override
                protected String formatErrorDetailMessage(Map errorDataMap) {
                    // ��s��󱱨��ɵo�Ϳ��~�GsetExitCode = -1, ERROR_COUNT++, �{������
                    sb.setLength(0);
                    sb.append("��s��󱱨��ɿ��~�A���~�էO�G ");
                    sb.append(errorDataMap.get("PAY_GRP"));
                    sb.append("�A���~�~��G ");
                    sb.append(errorDataMap.get("SLRY_YYMM"));
                    String memo = sb.toString();
                    sb.setLength(0);
                    setExitCode(ERROR);
                    errorCount += 1;
                    return memo;
                }
                
                @Override
                protected void executeBatchProcess() throws Exception { 
                    // �[�i��X�� bwDTL(�妸����)
                    bwDTL.write(sb.toString());
                    bwDTL.flush();
                    sb.setLength(0);
                }

                @Override
                protected void lastProcess() throws Exception {               
                    
                    // ��X���� OK��(���}���ɮ׿�X��y)
                    try {
                        bwDTLOK = EncodingHelper.getBufferedWriter(detailOKNM);
                    } catch (Exception e1) {
                        log.fatal("�}���ɮצ�y���~, �ɮצW�١G" + detailOKNM);
                        try {
                            bc.addErrorLog("�}���ɮצ�y���~", "�ɮצW�١G" + detailOKNM);
                            bc.writeErrorLog();
                            setExitCode(OK);
                        } catch (Exception e2) {
                            log.fatal(e2.getMessage(), e2);
                            throw e2;
                        }
                    }

                    // ��X���� OK��(�g�J���� OK��)
                    try {
                        bwDTLOK.write(String.valueOf(iTOT_CNT));
                        bwDTLOK.flush();
                    } catch (Exception e) {
                        log.fatal("��X��y���~�A�ɮצW�١G" + detailOKNM);
                        try {
                            bc.addErrorLog("��X��y���~", "�ɮצW�١G" + detailOKNM);
                            bc.writeErrorLog();
                            setExitCode(OK);
                        } catch (Exception e2) {
                            log.fatal(e2.getMessage(), e2);
                            throw e2;
                        }
                    }

                    // ��X �p�p��(���}���ɮ׿�X��y)
                    try {
                        bwSUM = EncodingHelper.getBufferedWriter(sumFileNM);
                    } catch (Exception e1) {
                        log.fatal("�}���ɮצ�y���~, �ɮצW�١G" + sumFileNM);                        
                        try {
                            bc.addErrorLog("�}���ɮצ�y���~", "�ɮצW�١G" + sumFileNM);
                            bc.writeErrorLog();
                            setExitCode(OK);
                        } catch (Exception e2) {
                            log.fatal(e2.getMessage(), e2);
                            throw e2;                            
                        }
                    }

                    // ��X �p�p��(�g�J�ɮ�)
                    try {
                        String compId = FieldOptionList.getName("EP", "SLRY_COMP_ID", PAY_GRP);// �ǤJ��PAY_GRP
                        //2019/09/25 AllenTsai �վ��X�~�z�����A�X�p�P�p�p�����P��
                        sb.setLength(0);
                        for(String slryCode : mapSumData.keySet()) {
                        	Map<String, Integer> sumData = mapSumData.get(slryCode);                           
                            appendSummaryData(compId, mapSLRY_CFG.get("SLRY_KIND"), slryCode, sumData.get("SLY_CNT"), sumData.get("SLY_AMT"));
                            sb.append("\n");
                        }
                        appendSummaryData(compId, mapSLRY_CFG.get("SUM_SLRY_KIND"), "TOTAL", iTOT_CNT, bdTOT_AMT.intValue());
                        log.debug("---------------- SUM ----------------------");
                        log.debug(sb);
                        bwSUM.write(sb.toString());
                        bwSUM.flush();
                        sb.setLength(0);
                    } catch (Exception e) {
                    	//2019/09/25 ��X���~����T���A��K���R���~��]
                        log.fatal("��X��y���~�A�ɮצW�١G" + sumFileNM, e);
                        try {
                            bc.addErrorLog("��X��y���~", "�ɮצW�١G" + sumFileNM);
                            bc.writeErrorLog();
                            setExitCode(OK);
                        } catch (Exception e2) {
                            log.fatal(e2.getMessage(), e2);
                            throw e2;
                        }
                    }

                    // ��X �p�p OK��(���}���ɮ׿�X��y)
                    try {
                        bwSUMOK = EncodingHelper.getBufferedWriter(sumOKNM);
                    } catch (Exception e1) {
                        log.fatal("�}���ɮצ�y���~, �ɮצW�١G" + sumOKNM);
                        try {
                            bc.addErrorLog("�}���ɮצ�y���~", "�ɮצW�١G" + sumOKNM);
                            bc.writeErrorLog();
                            setExitCode(OK);
                        } catch (Exception e2) {
                            log.fatal(e2.getMessage(), e2);
                            throw e2;
                        }
                    }

                    // ��X �p�p OK��(�g�J�ɮ�)
                    try {
                        bwSUMOK.write("1");
                        bwSUMOK.flush();
                    } catch (Exception e) {
                        log.fatal("��X��y���~�A�ɮצW�١G" + sumOKNM);
                        try {
                            bc.addErrorLog("��X��y���~", "�ɮצW�١G" + sumOKNM);
                            bc.writeErrorLog();
                            setExitCode(OK);
                        } catch (Exception e2) {
                            log.fatal(e2.getMessage(), e2);
                            throw e2;
                        }
                    }

                    // ��X���~���
                    DTZZM010 dtzzm010 = new DTZZM010();
                    String SHUT_DATE = new CathayDate().getShutdownDay();
                    dtzzm010.setSHUT_DT(SHUT_DATE);
                    dtzzm010.setSYS_CODE("EP");
                    dtzzm010.setJOB_NAME(JOB_NAME);
                    dtzzm010.setPROGRAM(PROGRAM);
                    String CNT_ITEM = FieldOptionList.getName("EP", "SLRY_ITEM", PAY_GRP + "_CNT");
                    dtzzm010.setCNT_ITEM(CNT_ITEM);
                    dtzzm010.setCNT_VALUE(ObjectUtils.toString(iTOT_CNT));
                    try {
                        new ZZ_M0Z020().doInsertDTZZM010(dtzzm010,true);
                    } catch (ModuleException me) {
                        log.fatal("�s�W DTZZM010 ���~�G" + me.getMessage(), me);
                    }

                    // ��X���~���(�e�� 4�ӰѼƸ�ƬۦP�A�u�]�w 2�Ӥ��P�Ȫ�����)
                    CNT_ITEM = FieldOptionList.getName("EP", "SLRY_ITEM", PAY_GRP + "_AMT");
                                                                                          
                    dtzzm010.setCNT_ITEM(CNT_ITEM);
                    dtzzm010.setCNT_VALUE(bdTOT_AMT.toPlainString());
                    try {
                        new ZZ_M0Z020().doInsertDTZZM010(dtzzm010,true);
                    } catch (ModuleException me) {
                        log.fatal("�s�W DTZZM010 ���~�G" + me.getMessage(), me);
                    }
                }

            });
            
        } catch (Exception e) {
            // �G�B���~�B�z
            // �]�w�w�w�^�Ǫ��T�� (���A�T�{���e�O�_���T)
            log.fatal("����妸�ɵo�Ϳ��~�G" + e.getMessage(), e);
            setExitCode(ERROR);
            throw e;
        } finally {

            //�{�������A�����Ҧ��ɮ� BufferWriter
            if (bwDTL != null) {
                try {
                    bwDTL.close();
                } catch (IOException e) {
                    sb.setLength(0);
                    sb.append("�����ɮצ�y���~, �ɮצW�١G");
                    sb.append(detailFileNM);
                    sb.append(", ");
                    sb.append(e.getMessage());                                       
                    log.fatal(sb.toString(), e);
                    sb.setLength(0);
                }
            }
            if (bwDTLOK != null) {
                try {
                    bwDTLOK.close();
                } catch (IOException e) {
                    sb.setLength(0);
                    sb.append("�����ɮצ�y���~, �ɮצW�١G");
                    sb.append(detailOKNM);
                    sb.append(", ");
                    sb.append(e.getMessage());                                       
                    log.fatal(sb.toString(), e);
                    sb.setLength(0);
                }
            }
            if (bwSUM != null) {
                try {
                    bwSUM.close();
                } catch (IOException e) {
                    sb.setLength(0);
                    sb.append("�����ɮצ�y���~, �ɮצW�١G");
                    sb.append(sumFileNM);
                    sb.append(", ");
                    sb.append(e.getMessage());                                       
                    log.fatal(sb.toString(), e);
                    sb.setLength(0);
                }
            }
            if (bwSUMOK != null) {
                try {
                    bwSUMOK.close();
                } catch (IOException e) {
                    sb.setLength(0);
                    sb.append("�����ɮצ�y���~, �ɮצW�١G");
                    sb.append(sumOKNM);
                    sb.append(", ");
                    sb.append(e.getMessage());                                       
                    log.fatal(sb.toString(), e);
                    sb.setLength(0);
                }
            }
            
            bc.writeErrorLog();
            // �ϥ� BatchConstructor ���Φۤv�����s�u�C���n���o bc �� ExitCode �A set �^�h
            int batchConstructorExitCode = bc.getExitCode();
            if (batchConstructorExitCode != OK) {
                setExitCode(batchConstructorExitCode);
            }
            printExitCode(batchConstructorExitCode);
        }
    }

    /**
     * �Ѽ��ˮ� 
     * @param args
     * @return PAY_GRP
     * @throws ErrorInputException
     */
    private String chkArgs(String[] args) throws ErrorInputException {
        try {
            if (args == null || args.length == 0) {
                throw new ErrorInputException("���ǤJ���~�էO");
            }
            PAY_GRP = args[0];// 2019.05.06 �߰� SA, �T�w PAY_GRP �T�w�T�X
            sb.append("�ǤJ���~�էO�G").append(PAY_GRP);
            log.fatal(sb.toString());
            
            return PAY_GRP;
            
        } catch (Exception e) {
            setExitCode(ERROR);
            log.fatal("�ǤJ�Ѽƿ��~�G" + e.getMessage(), e);
            throw new ErrorInputException("�ǤJ�Ѽƿ��~�G" + e.getMessage(), e);
        }
    }

    /**
     * getSalaryConfig
     * 
     * @param PAY_GRP
     * @param SYS_DT
     * @return mapC320
     * @throws ModuleException
     */
    private Map getSalaryConfig(String PAY_GRP, Date SYS_DT) throws ModuleException {

        Map mapC320 = null;
        try {
            DataSet ds = Transaction.getDataSet();
            ds.setField("PAY_GRP", PAY_GRP);
            ds.setField("SYS_DATE", SYS_DT);
            
            List<Map> resultList = VOTool.findToMaps(ds, SQL_QUERY_DTEPC320_001);

            if (resultList.size() > 0) {
                mapC320 = resultList.get(0);
            }

        } catch (DataNotFoundException dnfe) {
            sb.setLength(0);
            sb.append("�d�L���~�էO ");
            sb.append(PAY_GRP);
            sb.append(" �A�������`�����A�������X�C");
            log.fatal(sb.toString());
            return mapC320;

        } catch (Exception e) {
            setExitCode(ERROR);
            log.fatal("���ʲ����u���~�էO����]�w��Ū�����`�G�G" + e.getMessage(), e);
            throw new ModuleException("���ʲ����u���~�էO����]�w��Ū�����`�G" + e.getMessage(), e);
        }
        return mapC320;
    }
    
    //2019/09/25 AllenTsai ��X�~�z�N�� ���p�p��ƻP���B
    private void appendSummaryData(String compId, String slryKind, String slryCode, int slryCnt, int slryAmt) {
    	sb.append(compId);// ���q�O COMP_ID
        sb.append(",");
        sb.append(mapSLRY_CFG.get("AREA_CODE"));// �a�ϧO AREA_CODE
        sb.append(",");
        sb.append(mapC320.get("SLRY_YYMM"));// �o�~�~�� SLRY_YYMM
        sb.append(",");
        sb.append(mapC320.get("PAY_GRP"));// �o�~�էO PAY_GRP
        sb.append(",");
        sb.append(slryKind);// �z������
                                                // SLRY_KIND
        sb.append(",");
        sb.append(slryCode);// �~�z�N�� SLRY_CODE
        sb.append(",");
        sb.append(slryCnt);// �`��� TOT_CNT
        sb.append(",");                                              
        sb.append(slryAmt);// �`���B TOT_AMT    	
    }

}
