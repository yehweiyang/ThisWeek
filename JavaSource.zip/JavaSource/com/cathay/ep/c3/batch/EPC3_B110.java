package com.cathay.ep.c3.batch;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.hr.Employee;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.c3.module.EP_C31100;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.fm.z0.module.FM_Z0Z004;
import com.cathay.rz.s0.module.RZ_S00300;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.cathay.zz.x0.module.ZZ_X0Z004;
import com.cathay.zz.x0.module.ZZ_X0Z007;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * Date        Version  Description      Author
 * 2019/04/18  1.0      Created          ������
 * 
 * �@�B�{���\�෧�n�����G
 * �{���\��     ���u���~�妸���
 * �{���W��      EPC3_B110.java
 * �@�~�覡      BATCH
 * ���n����      �C��d�ߦ��~�էO����]�w�A�̾ڳ]�w����i�榩�~���ө��
 * �w����ƶq    5000(�̤j��)
 * �@�~�W��      JAEPDC003
 * �~�ȧO        EP
 * ���t�ΦW��    C3
 * �B�z�g��      ��
 * ����B�z���  �L
 * </pre>
 * 
 * @author i9200847 ������
 * @since 2019/05/21
 * 2019/06/01 AllenTsai �H�H�q���@�߶ǤJ titleList/dataList  
 * 2019/09/20 AllenTsai ���~��������l�B��󦩴ڡA�קK�o�����B�w�g�������P�b�A�վ�@�~�W�ٻPControM�@�P
 */
public class EPC3_B110 extends EP_BatchBean {
    
    /** logger */
    private static final Logger log = Logger.getLogger(EPC3_B110.class);
    
    private boolean isDebug = log.isDebugEnabled();

    /** �@�~�W�� */
    private static final String JOB_NAME = "JAEPDC003";

    /** �{���W�� */
    private static final String PROGRAM = "EPC3_B110";

    /** �B�z�g�� */
    private static final String PERIOD = "��";
    
    /** �ƥ�N��(���ʲ����~���q��) */
    private String EVENT_ID = "EP_RA007";
    
    /** �����q�O */
    private String SUB_CPY_ID = "00";    
        
    /** �@�~���(�t�Τ��) */
    private java.sql.Date SYS_DATE = DATE.today();

    /** �妸�B�z�ɶ�(�t�ήɶ�) */
    private Timestamp pcsTRN_DATE = DATE.currentTime();                                                         

    /** �����ӧǸ� */
    private int iSER_NO = 1;

    /** �u�W����妸�Ѽ� */
    private String[] onlineArgs = new String[0];

    /** ���B�z�έp��T */
    Map<String, Map> mapSumData = new TreeMap<String, Map>();
    
    /** ���覡 */
    private String EXE_TYPE;
    
    /** ���~�էO */
    private String PAY_GRP;
    
    /** ���~�էO���� */
    private String PAY_GRP_NM;
    
    /** ���~�էO����]�w�Ѽ� */
    Map mapC320 = null; 
    
    /** ���o���~����ӳ]�w */
    Map<String, String> mapSLRY_CFG = null;
    
    /** ���~��� */
    private int ERROR_COUNT = 0;
    
    StringBuilder sb = new StringBuilder();
    

    /** �ŧi�ϥΪ� SQL��k */
    /**
     * <pre>
     * select *
     *   from DBEP.DTEPC320  
     *  where PAY_GRP = ':PAY_GRP'
     *    and DATA_DATE = ':SYS_DATE'
     *    and SLRY_CTL_STS = '2'
     *   with ur
     * </pre>
     */
    private static final String SQL_QUERY_DTEPC320_001 = "com.cathay.ep.c3.batch.EPC3_B110.SQL_QUERY_DTEPC320_001";

    /**
     * <pre>
     *   select A.*,
     *  (select MAX(SER_NO) from DBEP.DTEPC321 B 
     *    where B.PAY_GRP = A. PAY_GRP 
     *      and B.SLRY_YYMM = A.SLRY_YYMM) as MAX_SER_NO
     *     from DBEP.DTEPC320 as A
     *    where A.PAY_GRP = ':PAY_GRP'
     *      and A.SLRY_YYMM = ':SLRY_YYMM'
     *     with ur
     * </pre>
     */
    private static final String SQL_QUERY_001 = "com.cathay.ep.c3.batch.EPC3_B110.SQL_QUERY_001";
    
    /**
     * <pre>
     * select C101.RCV_NO, C101.SUB_CPY_ID, C101.RCV_YM, C101.PAY_S_DATE, C101.PAY_E_DATE,
     *        C101.CRT_NO, C101.CUS_NO, C101.ID, C101.CUS_NAME, C101.BLD_CD, A101.BLD_NAME,
     *        C101.PRK_NO, C101.INV_NO, C101.INV_AMT, C101.SPR_AMT, C101.DIV_NO as CLC_DIV_NO, 
     *        B102.SLRY_ID, B102.DCT_TYPE, EMP.DIV_NO, EMP.POSITION, C321.PAY_GRP, C321.SLRY_YYMM,
     *        C321.TRN_DATE, C321.SLRY_STS
     *   from DBEP.DTEPC101 C101 
     *   join DBEP.DTEPB102 B102 
     *     on C101.CRT_NO = B102.CRT_NO 
     *    and C101.CUS_NO = B102.CUS_NO 
     *    and B102.SUB_CPY_ID = C101.SUB_CPY_ID
     *   join DBEP.DTEPA101 A101
     *     on C101.BLD_CD = A101.BLD_CD
     *    and A101.SUB_CPY_ID = C101.SUB_CPY_ID     
     *   left join DBEP.DTEPC321 C321 
     *     on C321.PAY_GRP = ':PAY_GRP'
     *    and C321.SLRY_YYMM = ':SLRY_YYMM'
     *    and C321.RCV_NO = C101.RCV_NO     
     *    and C321.SUB_CPY_ID = C101.SUB_CPY_ID  
     *   left join CXLHR.DTA0_EMPLOYEE_WORK EMP
     *     on EMP.EMPLOYEE_ID = B102.SLRY_ID
     *  where B102.RNT_TYPE IN ( '3' , '9' ) 
     *    and B102.DCT_TYPE = '2'
     *    and C101.RCV_YM = ':RCV_YM'
     *    and C101.SPR_AMT > 0
     *    and C101.OP_STATUS <> 99
     *    and C101.INV_NO <> ''
     *   with ur
     * </pre>
     */
    private static final String SQL_QUERY_002 = "com.cathay.ep.c3.batch.EPC3_B110.SQL_QUERY_002";
    
    /**
     * <pre>
     * update DBEP.DTEPC320 
     *    set SLRY_CTL_STS = '3',
     *        TRN_DATE = ':TRN_DATE',
     *        SLY_CNT = ':SLY_CNT',
     *        SLY_AMT = ':SLY_AMT',
     *        SLY_ERR_CNT = ':SLY_ERR_CNT'
     *  where PAY_GRP = ':PAY_GRP'
     *    and SLRY_YYMM = ':SLRY_YYMM'
     * </pre>
     */
    private static final String SQL_UPDATE_DTEPC320 = "com.cathay.ep.c3.batch.EPC3_B110.SQL_UPDATE_DTEPC320";

    /**
     * <pre>
     * update DBEP.DTEPC321 
     *    set TRN_DATE = ':TRN_DATE'
     *  where PAY_GRP = ':PAY_GRP'
     *    and SLRY_YYMM = ':SLRY_YYMM'
     *    and RCV_NO = ':RCV_NO'
     *    and SUB_CPY_ID = ':SUB_CPY_ID'
     * </pre>
     */    
    private static final String SQL_UPDATE_DTEPC321 = "com.cathay.ep.c3.batch.EPC3_B110.SQL_UPDATE_DTEPC321";

    /**
     * <pre>
     * INSERT INTO DBEP.DTEPC321(PAY_GRP, 
     *                           SLRY_YYMM, 
     *                           RCV_NO, 
     *                           SUB_CPY_ID, 
     *                           RCV_YM, 
     *                           CRT_NO, 
     *                           CUS_NO, 
     *                           PAY_S_DATE, 
     *                           PAY_E_DATE, 
     *                           ID, 
     *                           CUS_NAME, 
     *                           CLC_DIV_NO, 
     *                           BLD_CD, 
     *                           INV_NO, 
     *                           TOT_AMT, 
     *                           PRK_NO, 
     *                           DCT_TYPE, 
     *                           EMPLOYEE_ID, 
     *                           SLRY_STS, 
     *                           TRN_DATE, 
     *                           SRC_CODE, 
     *                           SER_NO, 
     *                           COMP_ID, 
     *                           AREA_CODE, 
     *                           SLRY_KIND, 
     *                           SLRY_CODE, 
     *                           CURR_CODE, 
     *                           DIV_NO, 
     *                           POSITION, 
     *                           PROC_CODE, 
     *                           DCT_CTGY, 
     *                           DCT_FAIL_PROC)                                                  
     * VALUES (':PAY_GRP', 
     *         ':SLRY_YYMM', 
     *         ':RCV_NO', 
     *         ':SUB_CPY_ID', 
     *         ':RCV_YM', 
     *         ':CRT_NO', 
     *         ':CUS_NO', 
     *         ':PAY_S_DATE', 
     *         ':PAY_E_DATE', 
     *         ':ID', 
     *         ':CUS_NAME', 
     *         ':CLC_DIV_NO', 
     *         ':BLD_CD', 
     *         ':INV_NO', 
     *         ':TOT_AMT', 
     *         ':PRK_NO', 
     *         ':DCT_TYPE', 
     *         ':EMPLOYEE_ID', 
     *         ':SLRY_STS', 
     *         ':TRN_DATE', 
     *         ':SRC_CODE', 
     *         ':SER_NO', 
     *         ':COMP_ID', 
     *         ':AREA_CODE', 
     *         ':SLRY_KIND', 
     *         ':SLRY_CODE', 
     *         ':CURR_CODE', 
     *         ':DIV_NO', 
     *         ':POSITION', 
     *         ':PROC_CODE', 
     *         ':DCT_CTGY',
     *         ':DCT_FAIL_PROC')
     * </pre>
     */
    private static final String SQL_INSERT_DTEPC321 = "com.cathay.ep.c3.batch.EPC3_B110.SQL_INSERT_DTEPC321";

    /** ����妸�@�~ */
    /**
     * method 1: execute (�D�{��)
     * 
     * @param args[]
     * @return
     * @throws Exception
     */
    public void execute(String[] args) throws Exception {

        // �]�w BatchConstructor (�ѼƤ��O��"�@�~�W�١B�{���W�١B����g��")
        final BatchConstructor bc = new BatchConstructor(JOB_NAME, PROGRAM, PERIOD);
        ZZ_X0Z004 theZZ_X0Z004 = new ZZ_X0Z004(PROGRAM);
        ReturnMessage rm = new ReturnMessage();
        
        try {
            // �@�B�{���D��G
            // ���o���~�էO�]�w
            chkArgs(args, bc, theZZ_X0Z004, rm);

            //���o���~�էO����]�w�Ѽ�
            mapC320 = getSalaryConfig(EXE_TYPE, PAY_GRP, SYS_DATE, onlineArgs);

            if("O".equals(EXE_TYPE)) {
                //�p�G�d�L��ơA��X���~�O�� C�A�{�����_
                if (mapC320 == null) {
                    sb.setLength(0);
                    sb.append("���~�էO ");
                    sb.append(onlineArgs[0]);
                    sb.append(" ���~�~�� ");
                    sb.append(onlineArgs[1]);                    
                    bc.addErrorLog("�u�W����妸�d�L���~�էO", sb.toString());
                    bc.writeErrorLog();
                    sb.setLength(0);
                    setExitCode(ERROR);
                    ERROR_COUNT++;
                    throw new ModuleException("�u�W����妸�d�L���~�էO"); 
                }
                
                String SLRY_CTL_STS = ObjectUtils.toString(mapC320.get("SLRY_CTL_STS"));
                
                if(!"3".equals(SLRY_CTL_STS)) {//���~���A�������B�z�A�����歫��
                    //��X���~�O�� D�A�{���������`����
                    sb.setLength(0);
                    sb.append("���~�էO ");
                    sb.append(onlineArgs[0]);
                    sb.append(" ���~�~�� ");
                    sb.append(onlineArgs[1]);
                    bc.addErrorLog("�u�W����妸���~���A���~", sb.toString());
                    bc.writeErrorLog();
                    sb.setLength(0);
                    setExitCode(OK); 
                    return; 
                }      
                
                //�Y mapC320.MAX_SER_NO �L�� ��0
                String MAX_SER_NO = ObjectUtils.toString(mapC320.get("MAX_SER_NO"), "0");                
                iSER_NO = Integer.parseInt(MAX_SER_NO) + 1;
                                           
            } else {//�妸�C�����
                //�p�G�d�L��ơA�{���������`�����A�������X
                if (mapC320 == null) {
                    iSER_NO = 1;
                    log.fatal("���~�էO����]�w�ѼƬd�L��ơA�{���������`�����A�������X�C");                     
                    return;//�d�L��ƥ��`���� 
                }
            }
                        
            // ���o���~����ӳ]�w (�ϥΥN�X�����Ӹ��)
            mapSLRY_CFG = FieldOptionList.getName("EP", "SLRY_CFG");            

            bc.execute(new BatchConstructor.DataBaseHandler() {

                int outputCount = 0;        //���~��X����
                int outputErrCount = 0;     //���~��X���~����(PG�ۤv�ɤW)
                int updateCount = 0;        //���~��s����
                int updateErrCount = 0;     //���~��s���~����(PG�ۤv�ɤW)
                int salaryErrorCount = 0;   //���~�����~����
                int passCount = 0;          //���s���ӫD���յ���                                                                                     
                                                
                String INPUT_COUNT = "���~�����d�ߵ���";
                String OUTPUT_COUNT = "���~���ӿ�X����";
                String OUTPUT_ERROR_COUNT = "���~���ӿ�X���~����";//PG�ۤv�ɤW
                String UPDATE_COUNT = "���~���ӧ�s����";
                String UPDATE_ERROR_COUNT = "���~���ӧ�s���~����";//PG�ۤv�ɤW
                String SLRY_ERR_COUNT = "���~�����~����";
                String SLRY_PASS_COUNT = "���~���ӫD���յ���";
                
                BatchUpdateDataSet buds_upd = bc.getBatchUpdateDataSet(SQL_UPDATE_DTEPC321, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);
                BatchUpdateDataSet buds_ins = bc.getBatchUpdateDataSet(SQL_INSERT_DTEPC321, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);
                
                //�έp��ơA�W�[�B�~���p��
                @Override
                protected boolean firstProcess() throws Exception {
                    //�� SPEC �@�~�y�{�Ƨ�
                    bc.createCountType(INPUT_COUNT);
                    bc.createCountType(OUTPUT_COUNT);
                    bc.createCountType(OUTPUT_ERROR_COUNT);
                    bc.createCountType(UPDATE_COUNT);
                    bc.createCountType(UPDATE_ERROR_COUNT);
                    bc.createCountType(SLRY_ERR_COUNT);
                    bc.createCountType(SLRY_PASS_COUNT);
                                       
                    return true;
                }
                

                @Override
                protected boolean searchProcess(BatchQueryDataSet bqds) throws Exception {
                    // �d�ߦ��~�������Ӹ��
                    String payGrp = ObjectUtils.toString(mapC320.get("PAY_GRP"));
                    String slryYymm = ObjectUtils.toString(mapC320.get("SLRY_YYMM"));
                    String rcvYm = ObjectUtils.toString(mapC320.get("RCV_YM"));
                    
                    bqds.setField("PAY_GRP", payGrp);
                    bqds.setField("SLRY_YYMM", slryYymm);
                    bqds.setField("RCV_YM", rcvYm);
                    bqds.searchAndRetrieve(SQL_QUERY_002);
                    
                    // �p�G bqds �d�L��� return false => �i�J finallyProcess�y�{
                    if (bqds.getTotalCount() == 0) {
                        
                        //����u�H�e���q���v�B�J
                        sb.setLength(0);
                        sb.append("���~�էO ");
                        sb.append(payGrp);
                        sb.append(", �o�~�u�@�~�� ");
                        sb.append(slryYymm);
                        sb.append(", �����~�� ");
                        sb.append(rcvYm);
                        sb.append("�A�d�L���~�������Ӹ�ơA�H�e����q���C");
                        log.fatal(sb.toString());
                        sb.setLength(0);
                        return false;
                    }
                    bc.addCountNumber(INPUT_COUNT, bqds.getTotalCount());  
                    return true;
                }

                DivData dd = new DivData();
                @Override
                protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {

                    // �v���B�z���~�������ӡG
                    try {                  
                        
                        String TRN_DATE = ObjectUtils.toString(bqds.getField("TRN_DATE"));
                        String rcv_no = ObjectUtils.toString(bqds.getField("RCV_NO"));
                        String sub_cpy_id = ObjectUtils.toString(bqds.getField("SUB_CPY_ID"));                        
                        
                        if(StringUtils.isNotBlank(TRN_DATE)) {
                            //�Y���~���Ӥw�g�s�b�A�z�L buds_upd ��DTEPC321 PK��s�ӵ���ƪ�TRN_DATE
                            String pay_grp = ObjectUtils.toString(bqds.getField("PAY_GRP"));
                            String slry_yymm = ObjectUtils.toString(bqds.getField("SLRY_YYMM"));                            
                            
                            buds_upd.setField("TRN_DATE", pcsTRN_DATE);
                            //where ���� (table SQL_KEY)
                            buds_upd.setField("PAY_GRP", pay_grp);
                            buds_upd.setField("SLRY_YYMM", slry_yymm);
                            buds_upd.setField("RCV_NO", rcv_no);
                            buds_upd.setField("SUB_CPY_ID", sub_cpy_id);
                            buds_upd.setField("WORK_PROCESS", "UPDATE_DTEPC321");//for errorDataMap�ϥ�
                            updateCount++;
                            
                            //�㵧��ƥ[�J�妸
                            addBatchAndJoinGroup(buds_upd);
                            
                        } else {
                            //�Y���~���Ӥ��s�b�A�z�L buds_ins �s�W���~����
                            
                            //�̦��~�էO���o���q�O
                            String mapC320_PAY_GRP = ObjectUtils.toString(mapC320.get("PAY_GRP"));                            
                            String comID = FieldOptionList.getName("EP", "SLRY_COMP_ID", mapC320_PAY_GRP);                            
                            
                            //�P�_���~�էO
                            String div_no = ObjectUtils.toString(bqds.getField("DIV_NO"));
                            String position = ObjectUtils.toString(bqds.getField("POSITION"));
                            String slry_id = ObjectUtils.toString(bqds.getField("SLRY_ID"));
                            
                            Map mapGroup = checkSalaryGroup(div_no, position, comID, slry_id);
                                                        
                            String salaryGroup = ObjectUtils.toString(mapGroup.get("CHK_PAY_GRP"));
                            
                            if(!salaryGroup.equals(mapC320_PAY_GRP) && !salaryGroup.startsWith("XX")) {//�էO�P�_���~�٬O��X
                                
                                passCount++;                    
                                
                                return;//�D�Ӧ��~�էO�A�~��B�z�U�@�����
                            }
                            
                            //�P�_�~�z�N��
                            String clc_div_no = ObjectUtils.toString(bqds.getField("CLC_DIV_NO"));
                            String salaryCode= FieldOptionList.getName("EP", "SLRY_CODE", clc_div_no);
                            
                            //���o�ӿ��O�έp���
                            Map sumData = mapSumData.get(clc_div_no);                            
                            
                            String clcDivNoShort = dd.getUnit4ShortName(clc_div_no);                            
                            
                            //�Y sumData �L��
                            if(sumData == null) {
                                sumData = new HashMap<String, Object>();                            
                                sumData.put("DIV_NAME", clcDivNoShort);
                                sumData.put("SLY_CNT", 0);
                                sumData.put("SLY_AMT", 0);
                                sumData.put("SLY_ERR_CNT", 0);     
                                
                                mapSumData.put(clc_div_no, sumData);                            
                            }
                            
                            String salaryStatus = null;
                            //�P�_���~��󪬺A
                            if(salaryGroup.startsWith("XX")) {
                                salaryStatus = Character.toString(salaryGroup.charAt(2));//salaryGroup �ĤT�X
                                salaryErrorCount++;//���~�����~���+1
                                String sly_err_cnt = ObjectUtils.toString(sumData.get("SLY_ERR_CNT"));                                                                
                                
                                if(StringUtils.isBlank(sly_err_cnt)) {
                                    sly_err_cnt = "0";//�Y�L��  ��0
                                }                                
                                
                                sumData.put("SLY_ERR_CNT", Integer.parseInt(sly_err_cnt) + 1);
                            } else {
                                salaryStatus = "0";//���`��
                                sumData.put("SLY_CNT", Integer.parseInt(ObjectUtils.toString(sumData.get("SLY_CNT"))) + 1);
                                String sprAmt = ObjectUtils.toString(bqds.getField("SPR_AMT"));                                
                                
                                //�����p���I����
                                String[] tmpStrs = sprAmt.split("\\.");                                
                                sprAmt = tmpStrs[0];
                                                                
                                int iSPR_AMT = Integer.parseInt(sprAmt);                                                                
                                
                                sumData.put("SLY_AMT", Integer.parseInt(ObjectUtils.toString(sumData.get("SLY_AMT"))) + iSPR_AMT);                                
                            }                            
                            
                            String mapC320_SLRY_YYMM = ObjectUtils.toString(mapC320.get("SLRY_YYMM"));
                            String rcv_ym = ObjectUtils.toString(bqds.getField("RCV_YM"));
                            String crt_no = ObjectUtils.toString(bqds.getField("CRT_NO"));
                            String cus_no = ObjectUtils.toString(bqds.getField("CUS_NO"));  
                            String pay_s_date = ObjectUtils.toString(bqds.getField("PAY_S_DATE"));
                            String pay_e_date = ObjectUtils.toString(bqds.getField("PAY_E_DATE"));
                            String id = ObjectUtils.toString(bqds.getField("ID"));
                            String cus_name = ObjectUtils.toString(bqds.getField("CUS_NAME"));                            
                            String bld_cd = ObjectUtils.toString(bqds.getField("BLD_CD"));
                            String inv_no = ObjectUtils.toString(bqds.getField("INV_NO"));
                            String spr_amt = ObjectUtils.toString(bqds.getField("SPR_AMT"));
                            String prk_no = ObjectUtils.toString(bqds.getField("PRK_NO"));                            
                            String dct_type = ObjectUtils.toString(bqds.getField("DCT_TYPE"));
                            String employee_id = ObjectUtils.toString(bqds.getField("SLRY_ID"));
                            String src_code = ObjectUtils.toString(mapSLRY_CFG.get("SRC_CODE"));                           
                            String area_code = ObjectUtils.toString(mapSLRY_CFG.get("AREA_CODE"));
                            String slry_kind = ObjectUtils.toString(mapSLRY_CFG.get("SLRY_KIND"));
                            String curr_code = ObjectUtils.toString(mapSLRY_CFG.get("CURR_CODE"));
                            String proc_code = ObjectUtils.toString(mapSLRY_CFG.get("PROC_CODE"));
                            String dct_ctgy = ObjectUtils.toString(mapSLRY_CFG.get("DCT_CTGY"));
                            String dct_fail_proc = ObjectUtils.toString(mapSLRY_CFG.get("DCT_FAIL_PROC"));                                                        
                            
                            
                            //�s�W��X���Ȼ��� buds_ins
                            buds_ins.setField("PAY_GRP", mapC320_PAY_GRP);//KEYSEQ - NOT NULL                         
                            buds_ins.setField("SLRY_YYMM", new BigDecimal(mapC320_SLRY_YYMM));//KEYSEQ - NOT NULL     //���O�O Decimal(6)
                            buds_ins.setField("RCV_NO", rcv_no);//KEYSEQ - NOT NULL
                            buds_ins.setField("SUB_CPY_ID", sub_cpy_id);//KEYSEQ - NOT NULL                            
                            buds_ins.setField("RCV_YM", Integer.parseInt(rcv_ym));//���O�O Decimal(6)
                            buds_ins.setField("CRT_NO", crt_no);                            
                            buds_ins.setField("CUS_NO", Integer.parseInt(cus_no));//���O�O INTEGER
                            buds_ins.setField("PAY_S_DATE", pay_s_date);//���O�O DATE
                            buds_ins.setField("PAY_E_DATE", pay_e_date);//���O�O DATE                            
                            buds_ins.setField("ID", id);
                            buds_ins.setField("CUS_NAME", cus_name);
                            buds_ins.setField("CLC_DIV_NO", clc_div_no);
                            buds_ins.setField("BLD_CD", bld_cd);                            
                            buds_ins.setField("INV_NO", inv_no);
                            buds_ins.setField("TOT_AMT", new BigDecimal(spr_amt));//���O�O Decimal(12,2)
                            buds_ins.setField("PRK_NO", prk_no);
                            buds_ins.setField("DCT_TYPE", dct_type);                            
                            buds_ins.setField("EMPLOYEE_ID", employee_id);
                            buds_ins.setField("SLRY_STS", salaryStatus);
                            buds_ins.setField("TRN_DATE", pcsTRN_DATE);//KEYSEQ - NOT NULL      //���O�OTIMESTAMP
                            buds_ins.setField("SRC_CODE", src_code);//KEYSEQ - NOT NULL                            
                            buds_ins.setField("SER_NO", iSER_NO++);//KEYSEQ - NOT NULL        //���O�O INTEGER                            
                            buds_ins.setField("COMP_ID", comID);//comID ���~�էO�d�ߥN�X SLRY_COMP_ID                            
                            buds_ins.setField("AREA_CODE", area_code);
                            buds_ins.setField("SLRY_KIND", slry_kind);
                            buds_ins.setField("SLRY_CODE", salaryCode);
                            buds_ins.setField("CURR_CODE", curr_code);
                            buds_ins.setField("DIV_NO", div_no);
                            buds_ins.setField("POSITION", position);                            
                            buds_ins.setField("PROC_CODE", proc_code);
                            buds_ins.setField("DCT_CTGY", dct_ctgy);
                            buds_ins.setField("DCT_FAIL_PROC", dct_fail_proc);                            
                            buds_ins.setField("WORK_PROCESS", "INSERT_DTEPC321");//for errorDataMap�ϥ�
                            outputCount++;
                            
                            //�㵧��ƥ[�J�妸
                            addBatchAndJoinGroup(buds_ins);                                                        
                        }
                        
                    } catch (Exception e) {
                        log.fatal("�B�z���~���G���ӵo�Ϳ��~�G" + e.getMessage(), e);
                        throw e;
                    }
                    
                }

                @Override
                protected String formatErrorDetailMessage(Map errorDataMap) {
                    
                    String memo = null;                                       
                    sb.setLength(0);
                    
                    String WORK_PROCESS = ObjectUtils.toString(errorDataMap.get("WORK_PROCESS"));                    

                    //�� DTEPC321 ����ʧ@�A�i����~�B�z�G
                    if("UPDATE_DTEPC321".equals(WORK_PROCESS)) {
                        //��s���ʲ����u���~�����ɵo�Ϳ��~�G                                                
                        sb.append("��s���ʲ����u���~�����ɿ��~�G ");   
                        outputErrCount += 1;//�s�W���~��� +1
                        
                                                
                    } else if("INSERT_DTEPC321".equals(WORK_PROCESS)) {
                        //�s�W���ʲ����u���~�����ɵo�Ϳ��~�G     
                        sb.append("�s�W���ʲ����u���~�����ɿ��~�G ");
                        updateErrCount += 1;//��s���~��� +1
                        
                    }
                    
                    String errPAY_RGP = ObjectUtils.toString(errorDataMap.get("PAY_RGP"));
                    String errSLRY_YYMM = ObjectUtils.toString(errorDataMap.get("SLRY_YYMM"));
                    String errRCV_NO = ObjectUtils.toString(errorDataMap.get("RCV_NO"));
                    String errSUB_CPY_ID = ObjectUtils.toString(errorDataMap.get("SUB_CPY_ID"));
                    
                    sb.append(". PAY_RGP = ");
                    sb.append(errPAY_RGP);
                    sb.append(", SLRY_YYMM = ");
                    sb.append(errSLRY_YYMM);
                    sb.append(", RCV_NO = ");
                    sb.append(errRCV_NO);
                    sb.append(", SUB_CPY_ID = ");
                    sb.append(errSUB_CPY_ID);
                    sb.append("\n");
                    
                    memo = sb.toString();                    
                    
                    sb.setLength(0);                                       
                                     
                    setExitCode(ERROR);    
                    ERROR_COUNT++;
                    
                    return memo;
                }
                
                @Override
                protected void executeBatchProcess() throws Exception {
                    
                    outputCount = outputCount - outputErrCount - updateErrCount;                    
                    //�� SPEC �@�~�y�{�Ƨ�
                    bc.addCountNumber(OUTPUT_COUNT, outputCount);//���~���ӿ�X����
                    bc.addCountNumber(OUTPUT_ERROR_COUNT, outputErrCount);//���~���ӿ�X���~����          //PG�ۤv�ɤW
                    bc.addCountNumber(UPDATE_COUNT, updateCount);//���~���ӧ�s����
                    bc.addCountNumber(UPDATE_ERROR_COUNT, updateErrCount);//���~���ӧ�s���~����          //PG�ۤv�ɤW
                    bc.addCountNumber(SLRY_ERR_COUNT, salaryErrorCount);//���~�����~����
                    bc.addCountNumber(SLRY_PASS_COUNT, passCount);//���~���ӫD���յ���
                    
                                    
                    //�k�s�O�קK�U�@�����j��A���ƥ[�O��e���p��
                    //�� SPEC �@�~�y�{�Ƨ�
                    outputCount = 0;
                    outputErrCount = 0;
                    updateCount = 0;   
                    updateErrCount = 0;
                    salaryErrorCount = 0;
                    passCount = 0;
                      
                }

                @Override
                protected void lastProcess() throws Exception {               
                    
                    // ��s��󱱨���
                    try {                        
                        updateC320(mapC320, pcsTRN_DATE);
                        
                    } catch (Exception e1) {
                        //�Y�B�z�Ҳտ��~�A��X���~�O�� E                        
                        try {
                            sb.setLength(0);
                            sb.append("���~�էO ");
                            sb.append(mapC320.get("PAY_GRP"));
                            sb.append(", ���~�~�� ");
                            sb.append(mapC320.get("SLRY_YYMM"));                            
                            bc.addErrorLog("��s��󱱨��ɿ��~", sb.toString());
                            bc.writeErrorLog();
                            sb.setLength(0);
                            setExitCode(ERROR);
                            ERROR_COUNT++;
                            throw e1;
                        } catch (Exception e2) {
                            log.fatal(e2.getMessage(), e2);
                            throw e2;
                        }
                    }
                }
                
                
                @Override
                protected void finallyProcess() {
                    
                    //�H�e���q��
                    EP_B30010 ep_b30010 = new EP_B30010();
                    EP_Z10030 ep_z10030 = new EP_Z10030();
                    RZ_S00300 rz_s00300 = new RZ_S00300();
                    
                    //1. ���o�T���q�������q�O                    
                    String COMP_ID = null;
                    
                    try {
                        COMP_ID = ep_b30010.getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);                        
                        
                    } catch (Exception me) {
                        sb.setLength(0);
                        sb.append("���o�T���q�������q�O�o�Ϳ��~�A�����q�O�G");
                        sb.append(SUB_CPY_ID);
                        sb.append(", ");
                        sb.append(me.getMessage());
                        log.fatal(sb.toString(), me);
                        sb.setLength(0);
                    }

                    
                    //2. �]�w�q����H�M��
                    List<Map> recList = new ArrayList<Map>();
                    try {
                        Map<String, List<DTEPZ103>> nMap = ep_z10030.getMailList(SUB_CPY_ID, EVENT_ID);                        
                        
                        if(nMap.size() == 0) {
                            //�Y�d�L��ơA ��X���~���� F�A�{�����_
                            try {
                                bc.addErrorLog("�q����H�]�w���~", "���ʲ����~���q��");
                                bc.writeErrorLog();
                                setExitCode(ERROR);
                                ERROR_COUNT++;                                                                
                            } catch (Exception e) {
                                log.fatal(e.getMessage(), e);                                 
                            }
                            return;
                        }
                        
                        List<DTEPZ103> mailList = nMap.get(SUB_CPY_ID);                        
                        
                        for(DTEPZ103 z103: mailList) {
                            Map receipt = new HashMap();
                            receipt.put("EVENT_ID", EVENT_ID);
                            receipt.put("USER_ID", z103.getID());
                            receipt.put("USER_EMAIL", z103.getEMAIL());
                            recList.add(receipt);
                        }                                                
                        
                    } catch (ModuleException me) {
                        sb.setLength(0);
                        sb.append("�]�w�q����H�M��o�Ϳ��~�A�����q�O�G");
                        sb.append(SUB_CPY_ID);
                        sb.append(", ");
                        sb.append(me.getMessage());
                        log.fatal(sb.toString(), me);
                        sb.setLength(0);
                    }
                             
                    
                    //3. �B�zEMAIL����������]�w
                    List<Map> titleList = new ArrayList<Map>();                                        
                    mailColAndCont(titleList, "DIV_NAME", "�޲z���", 10);
                    mailColAndCont(titleList, "SLY_CNT", PAY_GRP_NM +"���~���", 10);
                    mailColAndCont(titleList, "SLY_AMT", "���~���B", 5);
                    mailColAndCont(titleList, "SLY_ERR_CNT", "���~���", 5);                    
                    
                    //4. �H�e�q�����e
                    //�N Map <String, Map> mapSumData ��value ��J List<Map> dataList
                    List<Map> dataList = new ArrayList<Map>();
                    
                    for(Map.Entry<String, Map> entry : mapSumData.entrySet()) {
                        Map sumData = entry.getValue();
                        dataList.add(sumData);
                    }
                                        
                    String ERR_MSG = null;
                    try {
                        ERR_MSG = rz_s00300.createRecordByDIV(EVENT_ID, "EP", SYS_DATE, recList, titleList, dataList, COMP_ID);                                         
                        
                        //�p�GERR_MSG���ȡG��X���~�O�� G�A�{�����_
                        if(StringUtils.isNotBlank(ERR_MSG)) {
                            bc.addErrorLog("�H�e�q�����~", ERR_MSG);
                            bc.writeErrorLog();
                            setExitCode(ERROR);
                            ERROR_COUNT++;
                            return;
                        }
                        
                    } catch(Exception e) {
                        setExitCode(ERROR);
                        log.fatal(e.getMessage(), e);                        
                    }                                        
                }

            });
            
        } catch (Exception e) {
            // �G�B���~�B�z
            // �]�w�w�w�^�Ǫ��T�� (���A�T�{���e�O�_���T)
            log.fatal("����妸�ɵo�Ϳ��~�G" + e.getMessage(), e);
            setExitCode(ERROR);
            throw e;
            
        } finally {

            //�{������
            if("O".equals(EXE_TYPE)) {
              try {                                                        
                    theZZ_X0Z004.endBatch(rm);
                } catch (Exception e) {
                    log.fatal("�u�W�妸�������~ " + e.getMessage(), e);
                    return;
                }

                if(rm.getReturnCode() != ReturnCode.OK) {
                    //��X���~�O�� H�A�{�����_
                    bc.addErrorLog("�R���妸�ʱ��ɵo�Ϳ��~", "�R���妸�ʱ��ɵo�Ϳ��~");
                    bc.writeErrorLog();
                    setExitCode(ERROR);
                    ERROR_COUNT++;
                    return;
                }
            }
            
            
            bc.writeErrorLog();
            
            // �ϥ� BatchConstructor ���Φۤv�����s�u�C���n���o bc �� ExitCode �A set �^�h
            int batchConstructorExitCode = bc.getExitCode();
            if (batchConstructorExitCode != OK) {
                setExitCode(batchConstructorExitCode);
            }
            printExitCode(batchConstructorExitCode);
        }
    }

    /**
     * �Ѽ��ˮ� 
     * @param args
     * @parma bc
     * @param theZZ_X0Z004
     * @param rm
     * @return 
     * @throws ErrorInputException
     */
    private void chkArgs(String[] args, BatchConstructor bc, ZZ_X0Z004 theZZ_X0Z004, ReturnMessage rm) throws ErrorInputException {
        try {
            
            if (args == null || args.length == 0) {
                throw new ErrorInputException("���ǤJ���覡");
            }
            
            EXE_TYPE = args[0];
            sb.append("�ǤJ���覡�G").append(EXE_TYPE);
            if(isDebug) {
                log.debug(sb.toString());                
            }
            sb.setLength(0);            
            
            if("O".equals(EXE_TYPE)) {
                try {
                    theZZ_X0Z004.startBatch(rm);
                } catch(Exception e) {
                    if(isDebug) {
                        log.debug("�u�W�妸�Ұʿ��~�G" + e.getMessage(), e);
                    }
                    throw e;
                }
                
                if(rm.getReturnCode() != ReturnCode.OK) {
                    //��X���~�O��A, �{�����_
                    bc.addErrorLog("�s�W�妸�ʱ��ɵo�Ϳ��~", "�s�W�妸�ʱ��ɵo�Ϳ��~");                    
                    bc.writeErrorLog();
                    setExitCode(ERROR);
                    ERROR_COUNT++;
                    throw new ModuleException("�s�W�妸�ʱ��ɵo�Ϳ��~");
                }
                
                //���o�妸����Ѽ�
                ZZ_X0Z007 theZZ_X0Z007 = new ZZ_X0Z007(PROGRAM);
                onlineArgs = theZZ_X0Z007.retrieveParam(null, 2);//�ĤG�ӰѼơG�ǻ��Ѽƪ��ƶq
                if(onlineArgs == null || onlineArgs.length == 0) {
                    //��X���~�O��B, �{�����_
                    bc.addErrorLog("���o�u�W�ǻ��妸�Ѽƿ��~", "���o�u�W�ǻ��妸�Ѽƿ��~");
                    bc.writeErrorLog();
                    setExitCode(ERROR);
                    ERROR_COUNT++;
                    throw new ModuleException("���o�u�W�ǻ��妸�Ѽƿ��~");
                }                                
            } else if("B".equals(EXE_TYPE)) {
                if(args.length == 1) {//�u�ǤJ�@�ӰѼ�
                    throw new ErrorInputException("���覡�� B �妸�A���ǤJ���~�էO");
                }
                PAY_GRP = args[1];                
            } else {
                throw new ErrorInputException("�п�J���T�����覡(B:�妸�FO:�u�W����妸)");
            }            
            
        } catch (Exception e) {
            setExitCode(ERROR);
            log.fatal("�ǤJ�Ѽƿ��~�G" + e.getMessage(), e);
            throw new ErrorInputException("�ǤJ�Ѽƿ��~�G" + e.getMessage(), e);
        }
    }

    /**
     * getSalaryConfig    ���o���~����]�w
     * @param EXE_TYPE    ����覡(�ˮ�(�@�}�l�w����)�ݬ� B:�妸 / O:�u�W����妸)
     * @param PAY_GRP     ���~�էO
     * @param SYS_DATE    �t�Τ��
     * @param onlineArgs  �u�W����妸�ǤJ�Ѽ�(�̧Ǭ� ���~�էO / ���~�~��)
     * @return mapC320    ���~�էO����]�w
     * @throws ModuleException
     */
    private Map getSalaryConfig(String EXE_TYPE, String PAY_GRP, Date SYS_DATE, String[] onlineArgs) throws ModuleException {
        
        List<Map> resultList = null;
        try {
            DataSet ds = Transaction.getDataSet();
            
            if("B".equals(EXE_TYPE)) {
                ds.setField("PAY_GRP", PAY_GRP);
                ds.setField("SYS_DATE", SYS_DATE);
                resultList = VOTool.findToMaps(ds, SQL_QUERY_DTEPC320_001);
                
                
            } else {
                ds.setField("PAY_GRP", onlineArgs[0]);
                ds.setField("SLRY_YYMM", onlineArgs[1]);
                resultList = VOTool.findToMaps(ds, SQL_QUERY_001);
            }
            
            if (resultList.size() > 0) {
                mapC320 = resultList.get(0);
            }
            
            //PAY_GRP_NM ���~�էO����            
            PAY_GRP_NM = FieldOptionList.getName("EP", "PAY_GRP", ObjectUtils.toString(mapC320.get("PAY_GRP")));
                        
            mapC320.put("PAY_GRP_NM", PAY_GRP_NM);            

        } catch (DataNotFoundException dnfe) {          
            return mapC320;//null

        } catch (Exception e) {
            setExitCode(ERROR);
            log.fatal("���ʲ����u���~�էO����]�w��Ū�����`�G�G" + e.getMessage(), e);
            throw new ModuleException("���ʲ����u���~�էO����]�w��Ū�����`�G" + e.getMessage(), e);
        }
        return mapC320;
    }

    
    /**
     * updateC320           ��s���~�էO��󱱨���
     * @param mapC320       ���~�էO����]�w
     * @param pcsTRN_DATE   �B�z�ɶ�
     * @return 
     * @throws ModuleException
     */
    private void updateC320(Map mapC320, Timestamp pcsTRN_DATE) throws ModuleException {
        
        //EP_C31100 ep_c31100 = new EP_C31100();
        EP_C31100 ep_c31100 = new EP_C31100();
        
        Map mapSum = null;        
        DataSet ds = Transaction.getDataSet();
        
        //�d�ߩ����Ӳέp��T        
        try {           
            mapSum = ep_c31100.queryC321Sum(mapC320);            
        } catch (Exception e) {            
            setExitCode(ERROR);
            log.fatal("���ʲ����u���~������Ū�����`�G�G" + e.getMessage(), e);
            throw new ModuleException("���ʲ����u���~������Ū�����`�G" + e.getMessage(), e);
        }        
        
        //��s��󱱨��ɥ�Ƹ�T
        Transaction.begin();
        try {
            ds.setField("TRN_DATE", pcsTRN_DATE);
            
            String SLY_CNT = ObjectUtils.toString(mapSum.get("SLY_CNT"));
            
            if(StringUtils.isBlank(SLY_CNT)) {
                ds.setField("SLY_CNT", 0);//�L�� ��0
            } else {
                ds.setField("SLY_CNT", Integer.parseInt(SLY_CNT));//�b DTEPC320 �O INTEGER ���O
            }                        
            
            if(StringUtils.isBlank(ObjectUtils.toString(mapSum.get("SLY_AMT")))) {
                ds.setField("SLY_AMT", BigDecimal.ZERO);//�L��  ��0
            } else {
                ds.setField("SLY_AMT", mapSum.get("SLY_AMT"));//�b DTEPC320 �O DECIMAL(12) ���O
            }
            
            String SLY_ERR_CNT = ObjectUtils.toString(mapSum.get("SLY_ERR_CNT"));            
            
            if(StringUtils.isBlank(SLY_ERR_CNT)) {
                ds.setField("SLY_ERR_CNT", 0);//�L��  ��0
            } else {
                ds.setField("SLY_ERR_CNT", Integer.parseInt(SLY_ERR_CNT));//�b DTEPC320 �O INTEGER ���O
            }
            
            ds.setField("PAY_GRP", mapC320.get("PAY_GRP"));
            ds.setField("SLRY_YYMM", mapC320.get("SLRY_YYMM"));
            
            //��s DTEPC320 ���ʲ����u���~�էO����]�w��
            DBUtil.executeUpdate(ds, SQL_UPDATE_DTEPC320);
            
            Transaction.commit();
        } catch (Exception e) {
            Transaction.rollback();
            setExitCode(ERROR);
            log.fatal("��s���ʲ����u���~�էO����]�w�ɲ��`�G�G" + e.getMessage(), e);
            throw new ModuleException("��s���ʲ����u���~�էO����]�w�ɲ��`�G" + e.getMessage(), e);
        }        
    }
    
    
    /**
     * checkSalaryGroup     �P�_���~�էO
     * @param DIV_NO        ���~���u���
     * @param POSITION      ���~���u¾��
     * @param comID         ���~���q�O
     * @param SLRY_ID       ���~���u�N��
     * @return mapGroup     ���~�էO�P�_
     * @throws ModuleException
     */
    private Map checkSalaryGroup(String DIV_NO, String POSITION, String comID, String SLRY_ID) throws ModuleException {
        
        Map mapGroup = new HashMap();
        String strDIV_NO = null;
        String strPOSITION = null;
        
        if(!"A0".equals(comID)){    //�D A0 ��إ�A�Ȥ��B�z
            mapGroup.put("CHK_PAY_GRP", "NNN");            
        } else {
            Employee empData;
            PersonnelData personnelData = new PersonnelData();           
            
            //�p�G���u����¾�ŵL�ȡA�I�s�H�ƼҲը��o���
            if(StringUtils.isBlank(DIV_NO) || StringUtils.isBlank(POSITION)) {
                try {
                    empData = personnelData.getByEmployeeID(SLRY_ID);                                        
                    
                    if(empData == null) {
                        
                        //�Y���o�H�Ƹ�ƿ��~ (�d�L��� �� empData = null)
                        mapGroup.put("CHK_PAY_GRP", "XX1");                        
                        return mapGroup;                       
                    }                         
                } catch(Exception e) {
                    //�Y���o�H�Ƹ�ƿ��~ (�Ҳտ��~)
                    mapGroup.put("CHK_PAY_GRP", "XX1");                    
                    return mapGroup;
                }
                
                
                strDIV_NO = empData.getDivNo();
                strPOSITION = empData.getPosition();

                //�D�b¾�B�B�D�~�M�B��M��
                if(!empData.isStatusOnDuty() && !empData.isStatusT() && !empData.isStatusX()) {
                    mapGroup.put("CHK_PAY_GRP", "XX1");
                    return mapGroup;
                }
                
            } else {
                strDIV_NO = DIV_NO;
                strPOSITION = POSITION;
            }
            
            //�]�w���N���P¾��
            mapGroup.put("DIV_NO", strDIV_NO);
            mapGroup.put("POSITION", strPOSITION);                      
            
            //���o���u����
            String staffClass = null;
            try {
                staffClass = new FM_Z0Z004().getUserStaffClass(strDIV_NO, strPOSITION);                                
            } catch (Exception e) {
                //�Y�Ҳտ��~
                mapGroup.put("CHK_PAY_GRP", "XX2");                                
                
                return mapGroup;
            }
            
            //�����u�����P�_���G���Źw��
            String letter2 = Character.toString(staffClass.charAt(1));                        
            
            if(StringUtils.isBlank(staffClass) || staffClass.length() != 2) {//staffClass �L�� �άO ���� ����2
                mapGroup.put("CHK_PAY_GRP", "XX2");
            } else if("Y".equals(letter2)) {//staffClass �ĤG�X =��Y�� 
                mapGroup.put("CHK_PAY_GRP", "A02");//��إ~��
            } else {
                mapGroup.put("CHK_PAY_GRP", "A01");//��ؤ���
            }                        
        }
        return mapGroup;
    }

    
    /**
     * mailColAndCont    EMAIL����]�w (�H�e���q��)
     * @param titleList
     * @param FIELD
     * @param FIELD_NM
     * @param FIELD_SIZE
     */
    private void mailColAndCont(List<Map> titleList, String FIELD, String FIELD_NM, int FIELD_SIZE) {
        Map<String, Object> styleMap = new HashMap<String, Object>();
        styleMap.put("FIELD", FIELD);
        styleMap.put("FIELD_NM", FIELD_NM);
        styleMap.put("FIELD_SIZE", FIELD_SIZE);
        titleList.add(styleMap);
    }
    
}
