package com.cathay.ep.c3.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * 
<pre>
DATE    Description Author
2013/10/30  Created ����ʹ

�@�B  �{���\�෧�n�����G
�ҲզW��    �M����Ӭd�߼Ҳ�
�Ҳ�ID    EP_C30120
���n����    �B�z�M����Ӭd�ߧ@�~
</pre>
 * @author ���t�s
 * @since 2013/11/29
 */
@SuppressWarnings("unchecked")
public class EP_C30120 {

    private static final String SQL_doQuery_001 = "com.cathay.ep.c3.module.EP_C30120.SQL_doQuery_001";

    /**
     * ���o�Ȧ�M����ӲM��
     * @param reqMap �d�߻Ȧ�M����ӲM�椧���
     * @return �Ȧ�M����ӲM��
     * @throws ModuleException
     */
    public List<Map> doQuery(Map reqMap) throws ModuleException {

        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30120_MSG_001")); //�d�߻Ȧ�M����ӲM�椧��Ƥ��o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }

        String ID = MapUtils.getString(reqMap, "ID");
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");

        DataSet ds = Transaction.getDataSet();
        if (StringUtils.isNotBlank(ID)) {
            ds.setFieldValues("ID", ID.split(","));
        }
        if (StringUtils.isNotBlank(BLD_CD)) {
            ds.setFieldValues("BLD_CD", BLD_CD.split(","));
        }
        if (StringUtils.isNotBlank(CRT_NO)) {
            ds.setFieldValues("CRT_NO", CRT_NO.split(","));
        }
        if (StringUtils.isNotBlank(CUS_NO)) {
            ds.setFieldValues("CUS_NO", CUS_NO.split(","));
        }
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        return VOTool.findToMaps(ds, SQL_doQuery_001);
    }
}
