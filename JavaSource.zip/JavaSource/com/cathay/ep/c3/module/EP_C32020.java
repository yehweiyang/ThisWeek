package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.AuthUtil;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * 
<pre>
Date    Version Description Author
2013/09/03  1.0 Created ����ʹ

�{���\�෧�n�����G
    �ҲզW��    ú�ڬ������@�Ҳ�
    �Ҳ�ID    EP_C32020
    ���n����    ú�ڬ������@
</pre>

 * [20180301] �ק��
 * ���:�Ȧ�
 * 
 * @author ���t�s
 * @since 2013/12/31
 */

@SuppressWarnings("unchecked")
public class EP_C32020 {

    private static final String SQL_doQueryC302_001 = "com.cathay.ep.c3.module.EP_C32020.SQL_doQueryC302_001";

    private static final String SQL_doQueryC303_001 = "com.cathay.ep.c3.module.EP_C32020.SQL_doQueryC303_001";

    private static final String SQL_doQueryG002_001 = "com.cathay.ep.c3.module.EP_C32020.SQL_doQueryG002_001";

    private static final String SQL_doQueryG002_002 = "com.cathay.ep.c3.module.EP_C32020.SQL_doQueryG002_002";

    private static final String SQL_doQueryG003_001 = "com.cathay.ep.c3.module.EP_C32020.SQL_doQueryG003_001";

    private static final String SQL_doQueryG003_002 = "com.cathay.ep.c3.module.EP_C32020.SQL_doQueryG003_002";

    private static final String SQL_doQueryC307_001 = "com.cathay.ep.c3.module.EP_C32020.SQL_doQueryC307_001";

    private static final String SQL_doQueryC302AndC305_001 = "com.cathay.ep.c3.module.EP_C32020.SQL_doQueryC302AndC305_001";

    /**
     * �dú�ڬ������
     * @param reqMap
     * @param user
     * @param resp
     * @return
     * @throws Exception 
     * @throws ParseException 
     */
    public List<Map> doQuery(Map reqMap, UserObject user, ResponseContext resp) throws ParseException, Exception {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32020_MSG_001")); //�dú�ڬ�����Ƥ��o����
        }

        String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
        List<Map> rtnList;
        if ("0".equals(QUERY_KIND)) {
            rtnList = this.doQueryC302(reqMap);
        } else if ("1".equals(QUERY_KIND)) {
            rtnList = this.doQueryC303(reqMap);
        } else if ("2".equals(QUERY_KIND)) {//�Ȧ��J�b
            rtnList = this.doQueryG002(reqMap, user, resp);
        } else if ("3".equals(QUERY_KIND)) {//�Ȧ��R�b
            rtnList = this.doQueryG003(reqMap, user, resp);
        } else if ("4".equals(QUERY_KIND)) {
            //�M�������
            rtnList = this.doQueryC307(reqMap);
        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32020_MSG_002")); //�d�ߺ����榡���~
        }
        return rtnList;
    }

    /**
     * �d���ک����ɸ��
     * @param reqMap
     * @return
     * @throws ModuleException 
     */
    public List<Map> doQueryC302(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32020_MSG_001")); //�dú�ڬ�����Ƥ��o����
        } else {
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "SUB_CPY_ID"))) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
        }
        //�]EPC3_0150 �]��call doQueryC302(),INPUT_ID �n�d��
        DataSet ds = Transaction.getDataSet();
        this.setDS(reqMap, ds);
        return VOTool.findToMaps(ds, SQL_doQueryC302_001);
    }

    /**
     * �d���ڤβ��էI�{�����ɸ��
     * @param reqMap
     * @return
     * @throws ModuleException 
     */
    public List<Map> doQueryC302AndC305(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32020_MSG_001")); //�dú�ڬ�����Ƥ��o����
        } else {
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "SUB_CPY_ID"))) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
        }
        //�]EPC3_0150 �]��call doQueryC302(),INPUT_ID �n�d��
        DataSet ds = Transaction.getDataSet();
        this.setDS(reqMap, ds);
        return VOTool.findToMaps(ds, SQL_doQueryC302AndC305_001);
    }

    /**
     * �d�״ڳ�����ɸ��
     * @param reqMap
     * @return
     * @throws ModuleException 
     */
    public List<Map> doQueryC303(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32020_MSG_001")); //�dú�ڬ�����Ƥ��o����
        } else {
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "SUB_CPY_ID"))) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
        }

        DataSet ds = Transaction.getDataSet();
        this.setDS(reqMap, ds);
        return VOTool.findToMaps(ds, SQL_doQueryC303_001);
    }

    /**
     * �d�������J�b�ɸ��
     * @param reqMap
     * @param user
     * @param resp
     * @return
     * @throws Exception 
     * @throws ParseException 
     */
    public List<Map> doQueryG002(Map reqMap, UserObject user, ResponseContext resp) throws ParseException, Exception {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32020_MSG_001")); //�dú�ڬ�����Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        String sql = "";
        /* [20180301] �[�P�_��  */
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            sql = SQL_doQueryG002_001;
        } else {
            sql = SQL_doQueryG002_002;
        }
        if ("Y".equals(MapUtils.getString(reqMap, "IS_EXPORT_XLS"))) {//�ץX xls

            BatchQueryDataSet bqds = null;
            try {
                String fileName = MapUtils.getString(reqMap, "fileName");
                XlsUtils xlsUtils = new XlsUtils(URLEncoder.encode(fileName, "UTF-8"), resp);

                bqds = Transaction.getBatchQueryDataSet();
                this.setDS(reqMap, bqds);

                LocaleDisplay locale = new LocaleDisplay("EP", user);
                String gridJSON = MapUtils.getString(reqMap, "gridJSON");

                Map<String, Object> dataTotalMap = new HashMap<String, Object>();
                String[] totalColumns = { "ACNT_AMT", "BAL_AMT" };
                dataTotalMap.put("totalTitle", MessageUtil.getMessage("TOTAL"));//�X�p
                dataTotalMap.put("totalColumns", totalColumns);

                bqds.searchAndRetrieve(sql);
                AuthUtil auth = new AuthUtil();
                List<Map> rtnList = new ArrayList();
                if (xlsUtils != null) {

                    xlsUtils.initBatchExportSetting(gridJSON, 1, dataTotalMap);

                    while (xlsUtils.fetchData(bqds)) {

                        while (xlsUtils.next(bqds)) {
                            Map rtnMap = xlsUtils.getCurrentMap();
                            rtnList.add(rtnMap);
                            this.formatQueryG002(rtnMap, auth);

                            //����B�z
                            Date COA_DATE = (Date) bqds.getField("COA_DATE");
                            rtnMap.put("COA_DATE", COA_DATE != null ? locale.formatDate(COA_DATE, "/", "") : "");//�Ȧ�P�b��

                            xlsUtils.batchCreateXls();
                        }
                    }
                }

                return rtnList;
            } finally {
                if (bqds != null) {
                    bqds.close();
                }
            }

        } else {
            DataSet ds = Transaction.getDataSet();
            this.setDS(reqMap, ds);
            DBUtil.searchAndRetrieve(ds, sql);
            AuthUtil auth = new AuthUtil();
            List<Map> rtnList = new ArrayList<Map>();
            while (ds.next()) {
                Map rtnMap = VOTool.dataSetToMap(ds);
                this.formatQueryG002(rtnMap, auth);
                rtnList.add(rtnMap);
            }

            return rtnList;
        }

    }

    /**
     * �d�������R�b�ɸ��
     * @param reqMap
     * @param user
     * @param resp
     * @return
     * @throws ModuleException 
     */
    public List<Map> doQueryG003(Map reqMap, UserObject user, ResponseContext resp) throws ParseException, Exception {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32020_MSG_001")); //�dú�ڬ�����Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        String sql = "";
        /* [20180301] �[�P�_��  */
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            sql = SQL_doQueryG003_001;
        } else {
            sql = SQL_doQueryG003_002;
        }
        if ("Y".equals(MapUtils.getString(reqMap, "IS_EXPORT_XLS"))) {//�ץX xls
            BatchQueryDataSet bqds = null;
            try {
                String fileName = MapUtils.getString(reqMap, "fileName");
                XlsUtils xlsUtils = new XlsUtils(URLEncoder.encode(fileName, "UTF-8"), resp);

                bqds = Transaction.getBatchQueryDataSet();
                this.setDS(reqMap, bqds);

                LocaleDisplay locale = new LocaleDisplay("EP", user);
                String gridJSON = MapUtils.getString(reqMap, "gridJSON");

                Map<String, Object> dataTotalMap = new HashMap<String, Object>();
                String[] totalColumns = { "DACNT_AMT" };
                dataTotalMap.put("totalTitle", MessageUtil.getMessage("TOTAL"));//�X�p
                dataTotalMap.put("totalColumns", totalColumns);

                bqds.searchAndRetrieve(sql);

                List<Map> rtnList = new ArrayList<Map>();
                if (xlsUtils != null) {

                    xlsUtils.initBatchExportSetting(gridJSON, 1, dataTotalMap);

                    while (xlsUtils.fetchData(bqds)) {

                        while (xlsUtils.next(bqds)) {
                            Map rtnMap = xlsUtils.getCurrentMap();
                            rtnList.add(rtnMap);
                            this.formatQueryG003(rtnMap);

                            //����B�z
                            Timestamp DACNT_IN_DATE = (Timestamp) bqds.getField("DACNT_IN_DATE");

                            rtnMap.put("DACNT_IN_DATE", DACNT_IN_DATE != null ? locale.formatDate(DATE.timestampToDate(DACNT_IN_DATE), "/",
                                "") : "");//���ʤ��

                            xlsUtils.batchCreateXls();
                        }
                    }
                }

                return rtnList;
            } finally {
                if (bqds != null) {
                    bqds.close();
                }
            }
        } else {
            DataSet ds = Transaction.getDataSet();
            this.setDS(reqMap, ds);
            DBUtil.searchAndRetrieve(ds, sql);
            List<Map> rtnList = new ArrayList<Map>();
            while (ds.next()) {
                Map rtnMap = VOTool.dataSetToMap(ds);

                this.formatQueryG003(rtnMap);

                rtnList.add(rtnMap);
            }

            return rtnList;
        }

    }

    /**
     * �d�ȱM���ɸ��
     * @param reqMap
     *       <pre>
     *       ACNT_DIV_NO�ӿ��O
     *       INPUT_ID�ӿ�ID
     *       ACNT_DATE�ǲ����
     *       ACNT_SET_NO_LIST�M��ո�
     *       </pre>  
     * @return
     */
    public List<Map> doQueryC307(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32020_MSG_001")); //�dú�ڬ�����Ƥ��o����
        } else {
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "SUB_CPY_ID"))) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
            }
        }
        DataSet ds = Transaction.getDataSet();
        this.setDS(reqMap, ds);
        return VOTool.findToMaps(ds, SQL_doQueryC307_001);
    }

    /**
     * �����C�L
     * @param reqMap
     * @param rtnList
     * @param user
     * @param resp
     * @throws ErrorInputException
     * @throws ParseException
     */
    public void print(Map reqMap, List<Map> rtnList, UserObject user, ResponseContext resp) throws ErrorInputException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32020_MSG_001")); //�dú�ڬ�����Ƥ��o����
        }

        String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");

        List<Map> newList = new ArrayList();

        LocaleDisplay locale = new LocaleDisplay("EP", user);
        String reportId;
        Map params = new HashMap();
        Map<String, BigDecimal> totMap = null;
        if ("0".equals(QUERY_KIND)) {
            reportId = "EP_C32020_1";
            String[] totColumns = new String[] { "CHK_AMT" };
            totMap = initTotMap(totColumns);
            for (Map rtnMap : rtnList) {
                Map<String, String> newMap = new HashMap<String, String>();
                newMap.put("BANK_NO", MapUtils.getString(rtnMap, "BANK_NO", ""));
                newMap.put("CHK_NO", MapUtils.getString(rtnMap, "CHK_NO", ""));
                newMap.put("ACNT_NO", MapUtils.getString(rtnMap, "ACNT_NO", ""));
                newMap.put("CHK_SET_NO", MapUtils.getString(rtnMap, "CHK_SET_NO", ""));
                newMap.put("CHK_DATE", locale.formatDate(obj2Date(rtnMap, "CHK_DATE", null), "/", ""));
                newMap.put("CHK_AMT", locale.formatNumber(MapUtils.getString(rtnMap, "CHK_AMT", ""), 0, ""));
                newMap.put("INPUT_NAME", MapUtils.getString(rtnMap, "INPUT_NAME", ""));
                newMap.put("TRN_DATE", this.timeToDate(rtnMap, "TRN_DATE", locale));
                newMap.put("IS_SUMMARY", "N");
                newList.add(newMap);
                this.totCount(rtnMap, totMap, totColumns);
            }

        } else if ("1".equals(QUERY_KIND)) {
            reportId = "EP_C32020_2";
            String[] totColumns = new String[] { "RMT_AMT" };
            totMap = initTotMap(totColumns);
            for (Map rtnMap : rtnList) {
                Map<String, String> newMap = new HashMap<String, String>();
                newMap.put("RMT_DATE", locale.formatDate(obj2Date(rtnMap, "RMT_DATE", null), "/", ""));
                newMap.put("RMT_SET_NO", MapUtils.getString(rtnMap, "RMT_SET_NO", ""));
                newMap.put("ACNT_NO", MapUtils.getString(rtnMap, "ACNT_NO", ""));
                newMap.put("RMT_AMT", locale.formatNumber(MapUtils.getString(rtnMap, "RMT_AMT", ""), 0, ""));
                newMap.put("CEPSTCD", MapUtils.getString(rtnMap, "CEPSTCD", ""));
                newMap.put("CEMALAM", locale.formatNumber(MapUtils.getString(rtnMap, "CEMALAM", ""), 0, ""));
                newMap.put("INPUT_NAME", MapUtils.getString(rtnMap, "INPUT_NAME", ""));
                newMap.put("ACNT_DIV_NO", MapUtils.getString(rtnMap, "ACNT_DIV_NO", ""));
                newMap.put("SLIP_LOT_NO", MapUtils.getString(rtnMap, "SLIP_LOT_NO", ""));
                newMap.put("SLIP_SET_NO", MapUtils.getString(rtnMap, "SLIP_SET_NO", ""));
                newMap.put("IS_SUMMARY", "N");
                newList.add(newMap);
                this.totCount(rtnMap, totMap, totColumns);
            }

        } else if ("2".equals(QUERY_KIND)) {
            reportId = "EP_C32020_3";
            String[] totColumns = new String[] { "ACNT_AMT", "BAL_AMT" };
            totMap = initTotMap(totColumns);
            for (Map rtnMap : rtnList) {
                Map<String, String> newMap = new HashMap<String, String>();
                newMap.put("POLICY_NO", MapUtils.getString(rtnMap, "POLICY_NO", ""));
                newMap.put("PAY_TIMES", MapUtils.getString(rtnMap, "PAY_TIMES", ""));
                newMap.put("TMP_IN_CD_NM", MapUtils.getString(rtnMap, "TMP_IN_CD_NM", ""));
                newMap.put("ACNT_AMT", locale.formatNumber(MapUtils.getString(rtnMap, "ACNT_AMT", ""), 0, ""));
                newMap.put("CHK_STS_CODE_NM", MapUtils.getString(rtnMap, "CHK_STS_CODE_NM", ""));
                newMap.put("CHK_SET_NO", MapUtils.getString(rtnMap, "CHK_SET_NO", ""));
                newMap.put("CAT_PREM_NM", MapUtils.getString(rtnMap, "CAT_PREM_NM", ""));
                newMap.put("ACNT_NAME", MapUtils.getString(rtnMap, "ACNT_NAME", ""));
                newMap.put("APLY_NO", MapUtils.getString(rtnMap, "APLY_NO", ""));
                newMap.put("SLIP_LOT_NO", MapUtils.getString(rtnMap, "SLIP_LOT_NO", ""));
                newMap.put("ID", MapUtils.getString(rtnMap, "ID", ""));
                newMap.put("CST_NAME", MapUtils.getString(rtnMap, "CST_NAME", ""));
                newMap.put("BAL_AMT", locale.formatNumber(MapUtils.getString(rtnMap, "BAL_AMT", ""), 0, ""));
                newMap.put("COA_DATE", locale.formatDate(obj2Date(rtnMap, "COA_DATE", null), "/", ""));
                newMap.put("SUB_ACNT_CODE", MapUtils.getString(rtnMap, "SUB_ACNT_CODE", ""));
                newMap.put("TMP_NO", MapUtils.getString(rtnMap, "TMP_NO", ""));
                newMap.put("MEMO", MapUtils.getString(rtnMap, "MEMO", ""));
                newMap.put("SLIP_SET_NO", MapUtils.getString(rtnMap, "SLIP_SET_NO", ""));
                newMap.put("IS_SUMMARY", "N");
                newList.add(newMap);
                this.totCount(rtnMap, totMap, totColumns);
            }

        } else if ("3".equals(QUERY_KIND)) {
            reportId = "EP_C32020_4";
            String[] totColumns = new String[] { "DACNT_AMT" };
            totMap = initTotMap(totColumns);
            for (Map rtnMap : rtnList) {
                Map<String, String> newMap = new HashMap<String, String>();
                newMap.put("POLICY_NO", MapUtils.getString(rtnMap, "POLICY_NO", ""));
                newMap.put("PAY_TIMES", MapUtils.getString(rtnMap, "PAY_TIMES", ""));
                newMap.put("TMP_NO", MapUtils.getString(rtnMap, "TMP_NO", ""));
                newMap.put("DTMP_D_KIND_NM", MapUtils.getString(rtnMap, "DTMP_D_KIND_NM", ""));
                newMap.put("DRTN_KIND_NM", MapUtils.getString(rtnMap, "DRTN_KIND_NM", ""));
                newMap.put("APLY_NO", MapUtils.getString(rtnMap, "APLY_NO", ""));
                newMap.put("DACNT_NAME", MapUtils.getString(rtnMap, "DACNT_NAME", ""));
                newMap.put("DACNT_IN_DATE", this.timeToDate(rtnMap, "DACNT_IN_DATE", locale));
                newMap.put("SLIP_LOT_NO", MapUtils.getString(rtnMap, "DSLIP_LOT_NO", ""));
                newMap.put("ID", MapUtils.getString(rtnMap, "ID", ""));
                newMap.put("DACPT_ACNT_NAME", MapUtils.getString(rtnMap, "DACPT_ACNT_NAME", ""));
                newMap.put("DACNT_AMT", locale.formatNumber(MapUtils.getString(rtnMap, "DACNT_AMT", ""), 0, ""));
                newMap.put("DSUB_ACNT_CODE", MapUtils.getString(rtnMap, "DSUB_ACNT_CODE", ""));
                newMap.put("MEMO", MapUtils.getString(rtnMap, "MEMO", ""));
                newMap.put("DSLIP_SET_NO", MapUtils.getString(rtnMap, "DSLIP_SET_NO", ""));
                newMap.put("IS_SUMMARY", "N");
                newList.add(newMap);
                this.totCount(rtnMap, totMap, totColumns);
            }

        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32020_MSG_002")); //�d�ߺ����榡���~
        }

        params.put("REPORT_ID", reportId);
        params.put("SLIP_DATE", locale.formatDate(obj2Date(reqMap, "ACNT_DATE", null), "/", ""));
        params.put("CURRENT_DATE", locale.formatDate(DATE.today(), "/", ""));
        params.put("SIZE", locale.formatNumber(newList.size(), 0, "0"));

        //�B�z�X�p�ȰѼ�
        Iterator entries = totMap.entrySet().iterator();
        while (entries.hasNext()) {
            Entry<String, BigDecimal> thisEntry = (Entry<String, BigDecimal>) entries.next();
            String countKey = thisEntry.getKey();
            BigDecimal value = thisEntry.getValue();
            params.put("TOT_" + countKey, locale.formatNumber(value, 0, "0"));
        }

        //�̫�@���X�p�C�L(����smmary���detail)
        Map summaryMap = new HashMap();
        summaryMap.put("IS_SUMMARY", "Y");
        newList.add(summaryMap);

        JasperReportUtils.addOutputRptDataToResp(reportId, params, newList, resp);

    }

    /**
     * �Nmap���o����নDate
     * @param map
     * @param key
     * @param defaultKey
     * @return
     */
    private Date obj2Date(Map map, String key, Date defaultKey) {
        Object o = MapUtils.getObject(map, key);
        if (o != null) {
            if (o instanceof Date) {
                return (Date) o;
            }
            String ostr = o.toString();
            if (DATE.isDate(ostr)) {
                return Date.valueOf(ostr);
            }
        }
        return defaultKey;
    }

    /**
     * �]�wds���d�߰Ѽ�
     * @param reqMap
     * @return
     */
    private void setDS(Map reqMap, DataSet ds) {

        String ACNT_DIV_NO = MapUtils.getString(reqMap, "ACNT_DIV_NO");
        String INPUT_ID = MapUtils.getString(reqMap, "INPUT_ID");
        String INPUT_NAME = MapUtils.getString(reqMap, "INPUT_NAME");
        Date ACNT_DATE = obj2Date(reqMap, "ACNT_DATE", null);
        String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
        String CHK_SET_NOs = MapUtils.getString(reqMap, "CHK_SET_NO");
        String RMT_SET_NOs = MapUtils.getString(reqMap, "RMT_SET_NO");
        String ACNT_SET_NOs = MapUtils.getString(reqMap, "ACNT_SET_NO");
        String TMP_NOs = MapUtils.getString(reqMap, "TMP_NO");
        String DTMP_NOs = MapUtils.getString(reqMap, "DTMP_NO");
        String CHK_NO = MapUtils.getString(reqMap, "CHK_NO");
        String BANK_NO = MapUtils.getString(reqMap, "BANK_NO");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);//�W�[�����q�O
        if ("0".equals(QUERY_KIND) && StringUtils.isNotBlank(CHK_SET_NOs)) {
            String[] CHK_SET_NO_arr = CHK_SET_NOs.split(",");
            ds.setFieldValues("CHK_SET_NO", CHK_SET_NO_arr);
        } else if ("1".equals(QUERY_KIND) && StringUtils.isNotBlank(RMT_SET_NOs)) {
            String[] RMT_SET_NO_arr = RMT_SET_NOs.split(",");
            ds.setFieldValues("RMT_SET_NO", RMT_SET_NO_arr);
        } else if ("4".equals(QUERY_KIND) && StringUtils.isNotBlank(ACNT_SET_NOs)) {
            String[] ACNT_SET_NO_arr = ACNT_SET_NOs.split(",");
            ds.setFieldValues("ACNT_SET_NO", ACNT_SET_NO_arr);
        } else if ("2".equals(QUERY_KIND) && StringUtils.isNotBlank(TMP_NOs)) {
            String[] TMP_NO_arr = TMP_NOs.split(",");
            ds.setFieldValues("TMP_NO", TMP_NO_arr);
        } else if ("3".equals(QUERY_KIND) && StringUtils.isNotBlank(DTMP_NOs)) {
            String[] DTMP_NO_arr = DTMP_NOs.split(",");
            ds.setFieldValues("DTMP_NO", DTMP_NO_arr);
        } else {
            if (StringUtils.isNotBlank(ACNT_DIV_NO)) {
                ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
            }
            //�]EPC3_0150 �]��call doQueryC302(),INPUT_ID �n�d��
            if (StringUtils.isNotBlank(INPUT_ID)) {
                ds.setField("INPUT_ID", INPUT_ID);
            }
            if (StringUtils.isNotBlank(INPUT_NAME)) {
                ds.setField("INPUT_NAME", INPUT_NAME);
            }
            if (ACNT_DATE != null) {
                ds.setField("ACNT_DATE", ACNT_DATE);
            }
            String PAY_NOs = MapUtils.getString(reqMap, "PAY_NOs");
            if (StringUtils.isNotBlank(PAY_NOs)) {
                String[] PAY_NO_arr = PAY_NOs.split(",");
                ds.setFieldValues("PAY_NOS", PAY_NO_arr);
            }
            if (StringUtils.isNotBlank(CHK_NO)) {
                ds.setField("CHK_NO", CHK_NO);
            }
            if (StringUtils.isNotBlank(BANK_NO)) {
                ds.setField("BANK_NO", BANK_NO);
            }
        }

    }

    /**
     *  �d�������J�b�ɸ�Ƭd�ߵ��Gformat
     * @param rtnMap
     * @param auth
     */
    private void formatQueryG002(Map rtnMap, AuthUtil auth) {
        //���o���p����P�Ȧ��ӷ�����
        String CHK_STS_CODE = MapUtils.getString(rtnMap, "CHK_STS_CODE");
        String CHK_STS_CODE_NM = FieldOptionList.getName("EPC", "CHK_STS_CODE", CHK_STS_CODE);
        String TMP_IN_CD = MapUtils.getString(rtnMap, "TMP_IN_CD");
        String TMP_IN_CD_NM = FieldOptionList.getName("EPC3", "TMP_IN_CD", TMP_IN_CD);
        String CAT_PREM = MapUtils.getString(rtnMap, "CAT_PREM");
        String CAT_PREM_NM = FieldOptionList.getName("EP", "PAY_KIND", CAT_PREM);
        rtnMap.put("CHK_STS_CODE_NM", StringUtils.isNotBlank(CHK_STS_CODE_NM) ? CHK_STS_CODE_NM : CHK_STS_CODE);
        rtnMap.put("TMP_IN_CD_NM", StringUtils.isNotBlank(TMP_IN_CD_NM) ? TMP_IN_CD_NM : TMP_IN_CD);
        rtnMap.put("CAT_PREM_NM", StringUtils.isNotBlank(CAT_PREM_NM) ? CAT_PREM_NM : CAT_PREM);
        String LST_CHG_ID = MapUtils.getString(rtnMap, "LST_CHG_ID");
        if (StringUtils.isNotBlank(LST_CHG_ID)) {
            UserObject uesr = auth.getUserObjByID(LST_CHG_ID);
            if (uesr != null) {
                rtnMap.put("LST_CHG_NAME", uesr.getEmpName());
            }

        }
    }

    /**
     * �d�������R�b�ɵ��Gformat
     * @param rtnMap
     */
    private void formatQueryG003(Map rtnMap) {
        //���o�R�b���ܻP�h�O���ܤ���            
        String TMP_D_KIND = MapUtils.getString(rtnMap, "DTMP_D_KIND");
        String DTMP_D_KIND_NM = FieldOptionList.getName("EPC3", "TMP_D_KIND", TMP_D_KIND);
        String RTN_KIND = MapUtils.getString(rtnMap, "DRTN_KIND");
        String DRTN_KIND_NM = FieldOptionList.getName("EPC3", "RTN_KIND", RTN_KIND);

        rtnMap.put("DTMP_D_KIND_NM", StringUtils.isNotBlank(DTMP_D_KIND_NM) ? DTMP_D_KIND_NM : TMP_D_KIND);
        rtnMap.put("DRTN_KIND_NM", StringUtils.isNotBlank(DRTN_KIND_NM) ? DRTN_KIND_NM : RTN_KIND);

    }

    /**
     * �Ntimestamp �নlocaleDasplay formate ������榡
     * @param map
     * @param key
     * @param locale
     * @return
     */
    private String timeToDate(Map map, String key, LocaleDisplay locale) {
        String time = MapUtils.getString(map, key);
        return StringUtils.isNotBlank(time) ? locale.formatDate(DATE.timestampToDate(time), "/", "") : "";
    }

    /**
     * �p�p�p��
     * @param rtnMap
     * @param totMap
     * @param totColumns
     * @return
     */
    private void totCount(Map rtnMap, Map<String, BigDecimal> totMap, String[] totColumns) {
        for (String key : totColumns) {
            totMap.put(key, totMap.get(key).add(objToDec(rtnMap.get(key), BigDecimal.ZERO)));
        }

    }

    /**
     * �p�p��l
     * @param totColumns
     * @return
     */
    private Map<String, BigDecimal> initTotMap(String[] totColumns) {
        Map<String, BigDecimal> totMap = new HashMap<String, BigDecimal>();
        for (String key : totColumns) {
            totMap.put(key, BigDecimal.ZERO);
        }

        return totMap;
    }

    /**
     * ��BigDecimal
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal objToDec(Object o, BigDecimal defaultValue) {

        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }

}
