package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.ep.vo.DTEPC306;
import com.cathay.ep.z0.module.EP_Z0C101;
import com.cathay.ep.z0.module.EP_Z0C307;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/** 
 * <pre>
DATE Description Author
2016/03/18  Created �L����

�{���\�෧�n�����G
    �ҲզW��    �����b��۰ʾP�b�@�~���@�Ҳ�
    �Ҳ�ID     EP_C30160
    ���n����    �۰ʤ��M���������
 
 * </pre>
 */
@SuppressWarnings("unchecked")
public class EP_C30160 {

    private static final Logger log = Logger.getLogger(EP_C30160.class);

    private static final String SQL_doQuery_001 = "com.cathay.ep.c3.module.EP_C30160.SQL_doQuery_001";

    private static final String SQL_doQuery_002 = "com.cathay.ep.c3.module.EP_C30160.SQL_doQuery_002";

    /**
     * ���o���T�{ú�O���p����ﵲ�G
     * @param reqMap �d�߱���
     * @return ���I�{�䲼�����M��
     * @throws ModuleException 
     */
    public List<Map> query(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30160_MSG_001"));//�ǤJ�ѼƬd�߱��󤣱o����
        }

        ErrorInputException eie = null;

        String RMT_DATE_S = MapUtils.getString(reqMap, "RMT_DATE_S");
        String RMT_DATE_E = MapUtils.getString(reqMap, "RMT_DATE_E");
        if (StringUtils.isBlank(RMT_DATE_S)) {
            eie = getEieInstance(eie, "EP_C30160_MSG_002");//�ǤJ�Ѽƶ״ڤ��(�_)���o����
        } else if (!DATE.isDate(RMT_DATE_S)) {
            eie = getEieInstance(eie, "EP_C30160_MSG_005");//�ǤJ�Ѽƶ״ڤ��(�_)�榡����
        }
        if (StringUtils.isBlank(RMT_DATE_E)) {
            eie = getEieInstance(eie, "EP_C30160_MSG_003");//�ǤJ�Ѽƶ״ڤ��(��)���o����
        } else if (!DATE.isDate(RMT_DATE_E)) {
            eie = getEieInstance(eie, "EP_C30160_MSG_006");//�ǤJ�Ѽƶ״ڤ��(��)�榡����
        }

        if (eie != null) {
            throw eie;
        }

        String CURRENT_YM = DATE.getTodayYearAndMonth();
        //sum(�h��$)>�浧�M��
        //20200528�]�Q��X�̪�����A�G�ݭn�u�� BY�E�Ͷv
        //��쥻SQL��C307�BSUM C307�B�HC307 ID��C101��SUM C101��������}�A
        //���O�d��C307�BC101��A�A�HJAVA�����B
        //C307�浧�|��C101�h���A���BMATCH�~�q���e���@�~�A��l�ҤH�u�@�~
        DataSet ds = Transaction.getDataSet();
        ds.setField("RMT_DATE_S", RMT_DATE_S);
        ds.setField("RMT_DATE_E", RMT_DATE_E);
        String ID = MapUtils.getString(reqMap, "ID");
        if (StringUtils.isNotEmpty(ID)) {
            ds.setField("ID", ID);
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CFM_TYPE_5", "5");
    	List<Map> tmpListC307 = new ArrayList<Map>();
    	List<Map> tmpList1 = new ArrayList<Map>();
    	List<String> C307IDList = new ArrayList<String>();
        List<Map> tmp2ListC307 = new ArrayList<Map>();
      	Map<String, List<Map>> C101IDMap = new HashMap();
        log.debug("query.SQL_doQuery_001.start");
        try{
        	List<Map> C307List = new EP_Z0C307().queryC307(ds);
        	log.debug("query.SQL_doQuery_001.process1");
        	//���έp�UID���ơA�浧�M�᪺�~��۰ʾP�b
        	Map<String, BigDecimal> cntMap = new HashMap();
        	for (Map C307Map: C307List){
        		String C307ID = MapUtils.getString(C307Map, "ID");
        		if(cntMap.isEmpty()){
        			cntMap.put(C307ID, BigDecimal.ONE);
        		} else if (cntMap.containsKey(C307ID)){
        			cntMap.put(C307ID, STRING.objToBigDecimal(cntMap.get(C307ID),BigDecimal.ZERO).add(BigDecimal.ONE));
        		} else {
        			cntMap.put(C307ID, BigDecimal.ONE);
        		}
        	}

        	//�Ȧ��@�����[�JtmpListC307
        	for (Map C307Map: C307List){
        		String C307ID = MapUtils.getString(C307Map, "ID");
        		BigDecimal C307CNT = STRING.objToBigDecimal(cntMap.get(C307ID),BigDecimal.ZERO);
        		if (C307CNT.compareTo(BigDecimal.ONE)==0){
        			tmpListC307.add(C307Map);
        			if(C307IDList.size()==0 || !C307IDList.contains(C307ID)){
        				C307IDList.add(C307ID);
        			}        			
        		}
        	}
            log.debug("query.SQL_doQuery_001.process2");
        	//�d�߱M��ID�����|���P�b������C101
        	List<Map> C101List = new EP_Z0C101().queryC101forC307(C307IDList, CURRENT_YM, SUB_CPY_ID);
            log.debug("query.SQL_doQuery_001.process3");
          	Map<String, BigDecimal> AmtMap = new HashMap();
        	for(Map C101Map : C101List){
        		//�N�PID�������l�B�ۥ[
        		String C101ID = MapUtils.getString(C101Map, "ID");
        		BigDecimal SPR_AMT = STRING.objToBigDecimal(C101Map.get("SPR_AMT"),BigDecimal.ZERO);
        		if(AmtMap.isEmpty()){
        			AmtMap.put(C101ID, SPR_AMT);
        		} else if (AmtMap.containsKey(C101ID)){
        			AmtMap.put(C101ID, STRING.objToBigDecimal(AmtMap.get(C101ID),BigDecimal.ZERO).add(SPR_AMT));
        		} else {
        			AmtMap.put(C101ID, SPR_AMT);
        		}
        		
        		//��z�UID����������
        		if(C101IDMap.isEmpty()){
        			List<Map> c101tmpList= new ArrayList<Map>();
        			c101tmpList.add(C101Map);
        			C101IDMap.put(C101ID, c101tmpList);
        		} else if (C101IDMap.containsKey(C101ID)){
        			List<Map> c101tmpList = (List<Map>)C101IDMap.get(C101ID);
        			c101tmpList.add(C101Map);
        			C101IDMap.put(C101ID, c101tmpList);
        		} else {
        			List<Map> c101tmpList= new ArrayList<Map>();
        			c101tmpList.add(C101Map);
        			C101IDMap.put(C101ID, c101tmpList);
        		}        		
        	}
            log.debug("query.SQL_doQuery_001.process4");
        	//���i�H�P�b���M��
        	for (Map tmpC307 : tmpListC307){
        		
        		String C307ID = MapUtils.getString(tmpC307, "ID"); //ID        		
        		BigDecimal AMOUNT = STRING.objToBigDecimal(tmpC307.get("AMOUNT"),BigDecimal.ZERO); //�M��P�b���B
        		BigDecimal SUM_SPR_AMT = STRING.objToBigDecimal(AmtMap.get(C307ID),BigDecimal.ZERO); //�����l�B
        		if(AMOUNT.compareTo(SUM_SPR_AMT) == 0){ //�ۦP���B�i�H�P�b
        			List<Map> c101tmpList = (List<Map>)C101IDMap.get(C307ID);
        			for (Map tmpC101 : c101tmpList){
        				Map tmpMap1 = new HashMap();
        				
        				//�Ӧ�C307
        				tmpMap1.put("BANK_SER_NO", tmpC307.get("BANK_SER_NO"));
        				tmpMap1.put("ID", C307ID);
        				tmpMap1.put("AMOUNT", AMOUNT);
        				tmpMap1.put("RMT_DATE", tmpC307.get("RMT_DATE"));
        				tmpMap1.put("MEMO1", tmpC307.get("MEMO1"));
        				tmpMap1.put("MEMO2", tmpC307.get("MEMO2"));
        				tmpMap1.put("ACCNAME", tmpC307.get("ACCNAME"));
        				tmpMap1.put("BANKID", tmpC307.get("BANKID"));
        				tmpMap1.put("TX_SPEC", tmpC307.get("TX_SPEC"));
        				
        				//�Ӧ�C101
        				tmpMap1.put("RCV_NO", tmpC101.get("RCV_NO"));
        				tmpMap1.put("SUB_CPY_ID", tmpC101.get("SUB_CPY_ID"));
        				tmpMap1.put("RCV_YM", tmpC101.get("RCV_YM"));
        				tmpMap1.put("PAY_KIND", tmpC101.get("PAY_KIND"));
        				tmpMap1.put("CRT_NO", tmpC101.get("CRT_NO"));
        				tmpMap1.put("CUS_NO", tmpC101.get("CUS_NO"));
        				tmpMap1.put("ID_C101", tmpC101.get("ID"));
        				tmpMap1.put("PAY_S_DATE", tmpC101.get("PAY_S_DATE"));
        				tmpMap1.put("PAY_E_DATE", tmpC101.get("PAY_E_DATE"));
        				tmpMap1.put("CUS_NAME", tmpC101.get("CUS_NAME"));
        				tmpMap1.put("BLD_CD", tmpC101.get("BLD_CD"));
        				tmpMap1.put("INV_NO", tmpC101.get("INV_NO"));
        				tmpMap1.put("INV_AMT", tmpC101.get("INV_AMT"));
        				tmpMap1.put("SAL_AMT", tmpC101.get("SAL_AMT"));
        				tmpMap1.put("TAX_AMT", tmpC101.get("TAX_AMT"));
        				tmpMap1.put("SPR_AMT", tmpC101.get("SPR_AMT"));
        				tmpMap1.put("OP_STATUS", tmpC101.get("OP_STATUS"));
        				
        				tmpList1.add(tmpMap1);
        			}        			
        		} else{
        			tmp2ListC307.add(tmpC307); //���ĤG�q���ӥ�
        		}
        	} 
            log.debug("query.SQL_doQuery_001.process5");
        	
            //�Ƨ�BY TEL_KIND,SEQ_NO
            Collections.sort(tmpList1, new Comparator<Map>() {
                public int compare(Map obj1, Map obj2) {
                    String o1 = MapUtils.getString(obj1, "BANK_SER_NO");
                    String o2 = MapUtils.getString(obj2, "BANK_SER_NO");

                    int r = o1.compareTo(o2);
                    if (r != 0) {
                        return r;
                    }
                    o1 = MapUtils.getString(obj1, "ID");
                    o2 = MapUtils.getString(obj2, "ID");

                    r = o1.compareTo(o2);
                    if (r != 0) {
                        return r;
                    }
                    
                    o1 = MapUtils.getString(obj1, "CRT_NO");
                    o2 = MapUtils.getString(obj2, "CRT_NO");

                    r = o1.compareTo(o2);

                    return r;
                }
            });                   	        	
        } catch (DataNotFoundException dnfe) {
        	log.debug("�d�L���");
        }        
        log.debug("query.SQL_doQuery_001.end");
        
        List<String> tmpIdList = new ArrayList<String>();
        if (tmpList1 != null) {
            for (Map tmpMap : tmpList1) {
                String tmpMapID = MapUtils.getString(tmpMap, "ID");
                if (!tmpIdList.contains(tmpMapID)) {
                    tmpIdList.add(tmpMapID);
                }
            }
        }       
        
        //�浧$>�浧�M��
        //�浧$(s)>�浧�M�� && ���P������
        //�W�z�|�ư�C307�@����C101�h��������n�@�����B���P��C307����A���q�ݼ��X
        /*ds.clear();
        ds.setField("RMT_DATE_S", reqMap.get("RMT_DATE_S"));
        ds.setField("RMT_DATE_E", reqMap.get("RMT_DATE_E"));
        if (!tmpIdList.isEmpty()) {
            ds.setFieldValues("IDS", tmpIdList);
        }
        if (StringUtils.isNotEmpty(ID)) {
            ds.setField("ID", ID);
        }

        ds.setField("CURRENT_YM",  CURRENT_YM);
        log.debug("query.SQL_doQuery_002.start");
        List<Map> tmpList2 = VOTool.findToMaps(ds, SQL_doQuery_002, false);
        log.debug("query.SQL_doQuery_002.end");*/
        
        log.debug("query.SQL_doQuery_002.start");
        List<Map> tmpList2 = new ArrayList<Map>();
        if(tmp2ListC307 != null && tmp2ListC307.size()>0){
	        for (Map tmp2Map: tmp2ListC307){
	        	String C307ID = MapUtils.getString(tmp2Map, "ID"); //ID        		
        		BigDecimal AMOUNT = STRING.objToBigDecimal(tmp2Map.get("AMOUNT"),BigDecimal.ZERO); //�M��P�b���B
				List<Map> c101tmpList = (List<Map>)C101IDMap.get(C307ID);
				if (c101tmpList != null && c101tmpList.size()>0){
					for (Map tmpC101 : c101tmpList){						
		        		BigDecimal SPR_AMT = STRING.objToBigDecimal(tmpC101.get("SPR_AMT"),BigDecimal.ZERO); //�����l�B
		        		if(AMOUNT.compareTo(SPR_AMT)==0){ //�Y�P�b���B�P�����l�B�A�ӵ��]�ݧ�X��
							Map tmpMap2 = new HashMap();
							
							//�Ӧ�C307
							tmpMap2.put("BANK_SER_NO", tmp2Map.get("BANK_SER_NO"));
							tmpMap2.put("ID", C307ID);
							tmpMap2.put("AMOUNT", AMOUNT);
							tmpMap2.put("RMT_DATE", tmp2Map.get("RMT_DATE"));
							tmpMap2.put("MEMO1", tmp2Map.get("MEMO1"));
							tmpMap2.put("MEMO2", tmp2Map.get("MEMO2"));
							tmpMap2.put("ACCNAME", tmp2Map.get("ACCNAME"));
							tmpMap2.put("BANKID", tmp2Map.get("BANKID"));
							tmpMap2.put("TX_SPEC", tmp2Map.get("TX_SPEC"));
							
							//�Ӧ�C101
							tmpMap2.put("RCV_NO", tmpC101.get("RCV_NO"));
							tmpMap2.put("SUB_CPY_ID", tmpC101.get("SUB_CPY_ID"));
							tmpMap2.put("RCV_YM", tmpC101.get("RCV_YM"));
							tmpMap2.put("PAY_KIND", tmpC101.get("PAY_KIND"));
							tmpMap2.put("CRT_NO", tmpC101.get("CRT_NO"));
							tmpMap2.put("CUS_NO", tmpC101.get("CUS_NO"));
							tmpMap2.put("ID_C101", tmpC101.get("ID"));
							tmpMap2.put("PAY_S_DATE", tmpC101.get("PAY_S_DATE"));
							tmpMap2.put("PAY_E_DATE", tmpC101.get("PAY_E_DATE"));
							tmpMap2.put("CUS_NAME", tmpC101.get("CUS_NAME"));
							tmpMap2.put("BLD_CD", tmpC101.get("BLD_CD"));
							tmpMap2.put("INV_NO", tmpC101.get("INV_NO"));
							tmpMap2.put("INV_AMT", tmpC101.get("INV_AMT"));
							tmpMap2.put("SAL_AMT", tmpC101.get("SAL_AMT"));
							tmpMap2.put("TAX_AMT", tmpC101.get("TAX_AMT"));
							tmpMap2.put("SPR_AMT", tmpC101.get("SPR_AMT"));
							tmpMap2.put("OP_STATUS", tmpC101.get("OP_STATUS"));
							
							tmpList2.add(tmpMap2);
							
							//����쪺�ܴN�ӵ�C307�w�QC101���A�G���U��C307�h���
							break;
		        		}
					}   
				}
	        }
        }
        
        log.debug("query.SQL_doQuery_002.end");

        List<Map> rtnList = new ArrayList<Map>();
        if (tmpList1 != null) {
            rtnList.addAll(tmpList1);
        }
        if (tmpList2 != null) {
            rtnList.addAll(tmpList2);
        }
        
        if (rtnList.isEmpty()) {
            throw new DataNotFoundException(MessageUtil.getMessage("EP_C30160_MSG_004"));//�d�L���
        }

        for (Map rtnMap : rtnList) {
            rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND_ONE", MapUtils.getString(rtnMap, "PAY_KIND")));
        }
        return rtnList;
    }

    /**
     * �T�{ú�O���p
     * @param reqList �T�{��T
     * @param user
     * @throws ModuleException 
     * @throws Exception 
     */
    public void confirm(List<Map> reqList, UserObject user, String SUB_CPY_ID) throws ModuleException {

        if (reqList == null || reqList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30160_MSG_001"));//�ǤJ�ѼƬd�߱��󤣱o����
        }
        //���oú�O�~��
        String RCV_YM = DATE.getYearAndMonth(DATE.getY2KDate());
        Map<String, List<Map>> keep = new HashMap<String, List<Map>>();
        for (Map reqMap : reqList) {
            String BANK_SER_NO = MapUtils.getString(reqMap, "BANK_SER_NO");
            List<Map> tmpList;
            if (keep.containsKey(BANK_SER_NO)) {
                tmpList = keep.get(BANK_SER_NO);
            } else {
                if (!keep.isEmpty()) {
                    this.insertPayInfo(keep, SUB_CPY_ID, RCV_YM, user);//�s�W�W�sú�O����
                    keep.clear();
                }
                tmpList = new ArrayList<Map>();
                keep.put(BANK_SER_NO, tmpList);
            }
            tmpList.add(reqMap);
        }

        this.insertPayInfo(keep, SUB_CPY_ID, RCV_YM, user);//�s�W�̫�@�sú�O����

    }

    /**
     * �s�Wú�O����
     * @param keep
     * @param SUB_CPY_ID
     * @param RCV_YM
     * @param user
     * @throws ModuleException
     */
    public void insertPayInfo(Map<String, List<Map>> keep, String SUB_CPY_ID, String RCV_YM, UserObject user) throws ModuleException {

        ErrorInputException eie = null;

        if (keep == null || keep.isEmpty()) {
            eie = getEieInstance(eie, "EP_C30160_MSG_007");//�ǤJ�ѼƻȦ�b�Ǹ����o����
        }
        if (user == null) {
            eie = getEieInstance(eie, "EP_C30160_MSG_008");//�ǤJ�ѼƨϥΪ̸�T���o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEieInstance(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String key = keep.keySet().iterator().next();
        List<Map> tmpList = keep.get(key);
        //���oú�O�s��
        EP_C30020 theEP_C30020 = new EP_C30020();
        String PAY_NO = theEP_C30020.getPayNo(SUB_CPY_ID, RCV_YM, "9"); //9:�M��   
        //���o�M��ո� 
        Map fstMap = tmpList.get(0);
        String ACNT_SET_NO = new EP_Z0C307().updateAcntInfo(fstMap, user, SUB_CPY_ID);//update C307. ACNT_SET_NO       
        BigDecimal ACNT_AMT = STRING.objToBigDecimal(fstMap.get("AMOUNT"), BigDecimal.ZERO);//�M����B 
        //insert C301 + update C101
        EP_Z0C101 theEP_Z0C101 = new EP_Z0C101();
        for (Map tmpMap : tmpList) {
            tmpMap.put("PAY_NO", PAY_NO);
            tmpMap.put("PAY_TYPE", "9");//�M��
            tmpMap.put("SUB_CPY_ID", SUB_CPY_ID);
            String PAY_KIND = MapUtils.getString(tmpMap, "PAY_KIND");
            if ("2".equals(PAY_KIND)) {//���:�p���_�� = �״ڤ��
                tmpMap.put("PMI_S_DATE", MapUtils.getString(tmpMap, "RMT_DATE"));
            }
            tmpMap.put("PAY_AMT", tmpMap.get("SPR_AMT"));
            theEP_C30020.insertRtlInfo(tmpMap, user, theEP_Z0C101);
        }
        String userEmpID = user.getEmpID();
        String userEmpName = user.getEmpName();
        DTEPC306 DTEPC306_vo = new DTEPC306();
        DTEPC306_vo.setPAY_NO(PAY_NO);
        DTEPC306_vo.setACNT_AMT(ACNT_AMT);
        DTEPC306_vo.setPAY_AMT(ACNT_AMT);
        DTEPC306_vo.setDACNT_AMT(ACNT_AMT);
        DTEPC306_vo.setSUB_CPY_ID(SUB_CPY_ID);
        DTEPC306_vo.setACNT_SET_NO(ACNT_SET_NO);
        DTEPC306_vo.setINPUT_ID(userEmpID);
        DTEPC306_vo.setINPUT_NAME(userEmpName);
        DTEPC306_vo.setSLIP_SET_NO(0);
        DTEPC306_vo.setTRN_KIND("09");//�۰ʾP�b
        DTEPC306_vo.setCHG_DATE(DATE.currentTime());
        DTEPC306_vo.setCHG_DIV_NO(user.getOpUnit());
        DTEPC306_vo.setCHG_ID(userEmpID);
        DTEPC306_vo.setCHG_NAME(userEmpName);
        DTEPC306_vo.setCSH_AMT(BigDecimal.ZERO);
        DTEPC306_vo.setCHK_AMT(BigDecimal.ZERO);
        DTEPC306_vo.setRMT_AMT(BigDecimal.ZERO);
        DTEPC306_vo.setTKD_AMT(BigDecimal.ZERO);
        DTEPC306_vo.setMAL_AMT(BigDecimal.ZERO);
        DTEPC306_vo.setTMP_AMT(BigDecimal.ZERO);
        DTEPC306_vo.setCARD_D_AMT(BigDecimal.ZERO);
        VOTool.insert(DTEPC306_vo);
    }

    /**
     * ���o���~�T��
     * 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getEieInstance(ErrorInputException eie, String errMsg) {

        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}
