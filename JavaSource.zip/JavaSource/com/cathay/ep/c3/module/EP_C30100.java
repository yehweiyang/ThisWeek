package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.WorkDate;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dk.a0.bo.DK_AAZ011_bo;
import com.cathay.dk.a0.module.DK_A0Z003;
import com.cathay.dk.bo.DTDKF001;
import com.cathay.dk.f0.bo.DK_F0Z003_bo;
import com.cathay.dk.f0.module.DK_F0Z003;
import com.cathay.dk.f0.module.DK_F0Z017;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2013/10/31  Created ���i��
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �ʦ��P�b�b�@�~���@�Ҳ�
 * �Ҳ�ID    EP_C30100
 * ���n����    �ʦ��P�b�b�@�~���@�Ҳ�
 * </pre>
 * 
 * [20180208] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * 
 * @author �x�Ԫ�
 * @since 2013/12/20
 */
@SuppressWarnings("unchecked")
public class EP_C30100 {
    //private static final Logger log = Logger.getLogger(EP_C30100.class);

    private static final String SQL_query_001 = "com.cathay.ep.c3.module.EP_C30100.SQL_query_001";

    private static final String SQL_confirm1_001 = "com.cathay.ep.c3.module.EP_C30100.SQL_confirm1_001";

    private static final String SQL_cancel1_001 = "com.cathay.ep.c3.module.EP_C30100.SQL_cancel1_001";

    private static final String SQL_confirm2_001 = "com.cathay.ep.c3.module.EP_C30100.SQL_confirm2_001";

    private static final String SQL_cancel2_001 = "com.cathay.ep.c3.module.EP_C30100.SQL_cancel2_001";

    /**
     * �d�������ɸ��
     * @param reqMap  Map �e���d�����
     *                <pre>
     *                QUERY_TYPE�d�߶���
     *                RCV_YM�����~��
     *                QUERY_KIND�d�ߺ���
     *                SLIP_DATE�ǲ����
     *                SLIP_SET_NO�ǲ��ո�
     *                </pre>
     * @return  rtnList List<Map>   �����ɸ��
     */
    public List<Map> query(Map reqMap) throws Exception {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_C30100_MSG_001");//�d�߸�Ƥ��o����!
        }
        String DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");
        if (StringUtils.isBlank(DIV_NO)) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_002");//�ӿ��줣�o����!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
        if (StringUtils.isBlank(RCV_YM)) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_003");//�����~�뤣�o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        String SLIP_LOT_NO = null;
        //�]�w�ǲ��帹
        String QUERY_TYPE = MapUtils.getString(reqMap, "QUERY_TYPE");
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        if ("2".equals(QUERY_TYPE)) {
            SLIP_LOT_NO = this.getSLIP_LOT_NO("1", ACNT_TYPE);
        } else if ("3".equals(QUERY_TYPE)) {
            SLIP_LOT_NO = this.getSLIP_LOT_NO("2", ACNT_TYPE);
        }
        String SLIP_SEQ_NO = MapUtils.getString(reqMap, "SLIP_SEQ_NO");
        String SLIP_DATE = MapUtils.getString(reqMap, "SLIP_DATE");
        String ACNT_DIV_NO = MapUtils.getString(reqMap, "ACNT_DIV_NO");
        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");

        EP_Z00030 theEP_Z00030 = new EP_Z00030();

        //�d�߶ǲ��ո�
        /* [20180208] �s�W�P�_�I�sEP_Z00030  */
        //181226:�վ�Y�L�b�餣�d�ǲ���T,�קK���T�{�ɤ@��CALL DK
        if (StringUtils.isNotBlank(SLIP_DATE) && StringUtils.isNotBlank(SLIP_SEQ_NO) && theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
            ReturnMessage rm = new ReturnMessage();
            DK_F0Z003_bo DK_F0Z003_bo = new DK_F0Z003().doSwitch("2", SLIP_DATE, SLIP_LOT_NO, SLIP_SEQ_NO, ACNT_DIV_NO, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(rm.getMsgDesc());
            }
            SLIP_SET_NO = DK_F0Z003_bo.getSLIP_NO();
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("DIV_NO", DIV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("RCV_YM", RCV_YM);
        if (StringUtils.isNotBlank(SLIP_DATE)) {
            setFieldIfExist("ACNT_DIV_NO", ACNT_DIV_NO, ds);//�b�ȳ��
        }
        if ("1".equals(QUERY_TYPE)) {
            //�d��������
            ds.setField("COND1", "1");
        } else if ("2".equals(QUERY_TYPE)) {
            //�d�ߤw�J�ʦ�
            ds.setField("COND2", "1");
            if (StringUtils.isNotBlank(SLIP_DATE)) {
                ds.setField("SLIP_DATE", SLIP_DATE);//TURN_ACNT_DATE   �ʦ��b�Ȥ�   
                setFieldIfExist("TURN_SLPLOT_NO", SLIP_LOT_NO, ds);//TURN_SLPLOT_NO  �ʦ��ǲ��帹
                setFieldIfExist("SLIP_SET_NO", SLIP_SET_NO, ds);//�ʦ��ǲ��ո�
            }
        } else if ("3".equals(QUERY_TYPE)) {
            //�d�ߤw�J�b�b
            ds.setField("COND3", "1");
            if (StringUtils.isNotBlank(SLIP_DATE)) {
                ds.setField("SLIP_DATE", SLIP_DATE);//BDEBT_ACNT_DATE  �b�b�b�Ȥ�
                setFieldIfExist("BDEBT_SLPLOT_NO", SLIP_LOT_NO, ds);//BDEBT_SLPLOT_NO �b�b�ǲ��帹
                setFieldIfExist("SLIP_SET_NO", SLIP_SET_NO, ds);//�b�b�ǲ��ո�
            }
        }

        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else {
            ds.setField("ACNT_TYPE2", "2");
        }
        //�d��ú�O�������

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_query_001);
        int i = 1;
        for (Map map : rtnList) {
            //�d��ú�ں�������
            map.put("SER_NO", i++);
            map.put("PAY_KIND_NM", FieldOptionList.getName("EP", "PAY_KIND", MapUtils.getString(map, "PAY_KIND")));
            String RCV_YM_C101 = MapUtils.getString(map, "RCV_YM");
            if (!"000000".equals(RCV_YM_C101)) {
                int RCV_YM_C101_INT = Integer.parseInt(RCV_YM_C101) - 191100;
                map.put("RCV_YM", String.valueOf(RCV_YM_C101_INT));
            }
        }
        return rtnList;
    }

    /**
     * �ʦ��T�{
     * @param reqMap Map �e���d�����
     * @param reqList List<Map>  �e���Ŀ���
     */
    public Map<String, String> confirm1(Map reqMap, List<Map> reqList) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_001");//�d�߸�Ƥ��o����!
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
            }
        }
        if (reqList == null || reqList.isEmpty()) {
            throw getErrorInputException(eie, "EP_C30100_MSG_005");//�Ŀ��Ƥ��o����!
        }
        if (eie != null) {
            throw eie;
        }
        Timestamp currentTime = DATE.currentTime();
        //�]�w�b�Ȥ���A�Y�ާ@�ɶ��W�L16:30�A�h�b����U�@�u�@��C
        String ACNT_DATE;
        if (DATE.getTime24().compareTo("16:30:59") <= 0) {
            ACNT_DATE = DATE.getDBDate();
        } else {
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            ACNT_DATE = df.format(WorkDate.getNextXWorkingDate(DATE.today(), 1));//�U�@�u�@��
        }
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");

        //�]�w�ʦ��ǲ��帹
        String SLIP_LOT_NO = this.getSLIP_LOT_NO("1", ACNT_TYPE);

        //���o�g�����Ǹ�
        String USER_ID = MapUtils.getString(reqMap, "USER_ID");
        ReturnMessage rm = new ReturnMessage();
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();

        /* [20180208] ��ѩI�sEP_Z0Z001���oTRN_SER_NO  */
        String TRN_SER_NO = theEP_Z0Z001.getTRN_SER_NO(SUB_CPY_ID, USER_ID, ACNT_DATE, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(rm.getMsgDesc());
        }

        //���o�ǲ��ո�
        String USER_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");

        /* [20180208] ��ѩI�sEP_Z0Z001���oSLIP_SET_NO  */
        String SLIP_SET_NO = theEP_Z0Z001.getSLIP_SET_NO(SUB_CPY_ID, "1", USER_DIV_NO, USER_ID, SLIP_LOT_NO, ACNT_DATE, rm);

        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(rm.getMsgDesc());
        }
        Map<String, String> rtnMap = new HashMap<String, String>();
        rtnMap.put("ACNT_DATE", ACNT_DATE);
        rtnMap.put("SLIP_LOT_NO", SLIP_LOT_NO);
        rtnMap.put("SLIP_SET_NO", SLIP_SET_NO);

        String USER_NAME = MapUtils.getString(reqMap, "USER_NAME");

        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        /* [20180208] �s�W�P�_���I�sEP_Z00030  */
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b

            //�p��ʦ����B�`�M
            //        BigDecimal TOTAL_AMT1 = BigDecimal.ZERO;//���(1)�B�H����(4)�B�X�����a(5)�B��L(7)���B�`�M
            //        BigDecimal TOTAL_AMT2 = BigDecimal.ZERO;//�޲z�O(3)���B�`�M
            //        BigDecimal TOTAL_AMT3 = BigDecimal.ZERO;//�ʦ����B�`�B
            //150513 modified SG�X�� 
            Map<MultiKey, Map<String, BigDecimal>> acntInfo = new HashMap<MultiKey, Map<String, BigDecimal>>();// KEY �b�U�O, Map �έp���G
            //�v���B�zreqList
            EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
            for (Map map : reqList) {
                String DIV_NO = MapUtils.getString(map, "DIV_NO", USER_DIV_NO);
                String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(SUB_CPY_ID, MapUtils.getString(map, "BLD_CD"));
                MultiKey mkey = new MultiKey(DIV_NO, BAL_TYPE);

                Map<String, BigDecimal> sumMap = (Map<String, BigDecimal>) acntInfo.get(mkey);
                //�S�� CREATE �s Map �έp�Ȫ�l�� 0
                if (sumMap == null) {
                    sumMap = new HashMap<String, BigDecimal>();
                }

                String PAY_KIND = MapUtils.getString(map, "PAY_KIND");
                BigDecimal SPR_AMT = obj2Big(map, "SPR_AMT", BigDecimal.ZERO);
                if ("1".equals(PAY_KIND) || "4".equals(PAY_KIND) || "5".equals(PAY_KIND) || "7".equals(PAY_KIND) || "8".equals(PAY_KIND)) {
                    sumMap.put("TOTAL_AMT1", STRING.objToBigDecimal(sumMap.get("TOTAL_AMT1"), BigDecimal.ZERO).add(SPR_AMT));
                    sumMap.put("TOTAL_CNT1", STRING.objToBigDecimal(sumMap.get("TOTAL_CNT1"), BigDecimal.ZERO).add(BigDecimal.ONE));
                } else if ("3".equals(PAY_KIND)) {
                    sumMap.put("TOTAL_AMT2", STRING.objToBigDecimal(sumMap.get("TOTAL_AMT2"), BigDecimal.ZERO).add(SPR_AMT));
                    sumMap.put("TOTAL_CNT2", STRING.objToBigDecimal(sumMap.get("TOTAL_CNT2"), BigDecimal.ZERO).add(BigDecimal.ONE));
                }
                sumMap.put("TOTAL_AMT3", STRING.objToBigDecimal(sumMap.get("TOTAL_AMT3"), BigDecimal.ZERO).add(SPR_AMT));
                sumMap.put("TOTAL_CNT3", STRING.objToBigDecimal(sumMap.get("TOTAL_CNT3"), BigDecimal.ZERO).add(BigDecimal.ONE));
                acntInfo.put(mkey, sumMap);
            }

            //String size = String.valueOf(reqList.size());
            String TRN_DATE = currentTime.toString();
            //�Y#TOTAL_AMT1!=0�A�h�զ�����X�b�Ҳ�BO�A#DK_AAZ011_BO =
            List DK_AAZ011_BO_LIST = new ArrayList();
            Set<MultiKey> BAL_TYPEs = acntInfo.keySet();
            for (MultiKey mkey : BAL_TYPEs) {
                String DIV_NO = (String) mkey.getKey(0);
                String balType = (String) mkey.getKey(1);

                Map<String, BigDecimal> sumMap = acntInfo.get(mkey);
                BigDecimal TOTAL_AMT1 = STRING.objToBigDecimal(sumMap.get("TOTAL_AMT1"), BigDecimal.ZERO);
                String TOTAL_CNT1 = MapUtils.getString(sumMap, "TOTAL_CNT1", "0");
                if (BigDecimal.ZERO.compareTo(TOTAL_AMT1) != 0) {
                    DK_AAZ011_bo theDK_AAZ011_bo = new DK_AAZ011_bo();
                    theDK_AAZ011_bo.setINPUT_ID(USER_ID);//�g��ID
                    theDK_AAZ011_bo.setINPUT_NAME(USER_NAME);//�g��m�W
                    theDK_AAZ011_bo.setTRN_DATE(TRN_DATE);//�������ɶ�
                    theDK_AAZ011_bo.setTRN_SER_NO(TRN_SER_NO);//����Ǹ�
                    theDK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);//�ǲ��帹
                    theDK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);//�ǲ��ո�
                    theDK_AAZ011_bo.setREL_FILE_NO("DTEPC101");//�����ɥN��
                    theDK_AAZ011_bo.setACNT_DATE(ACNT_DATE);//�b�Ȥ��
                    theDK_AAZ011_bo.setTRN_KIND("EPC301");//�������
                    theDK_AAZ011_bo.setMEMO("");//�K�n
                    theDK_AAZ011_bo.setACNT_DIV_NO(USER_DIV_NO);//���b���
                    theDK_AAZ011_bo.setKIND_CODE(null);//���O�N��
                    theDK_AAZ011_bo.setBUS_CODE("EP");//�~�ȥN�X
                    theDK_AAZ011_bo.setBUS_TRAN_CODE("1");//�~�ȥ���N�X
                    theDK_AAZ011_bo.setCURR("NTD");//���O
                    theDK_AAZ011_bo.setCNT(TOTAL_CNT1);//���
                    theDK_AAZ011_bo.setITEM("10");//����
                    theDK_AAZ011_bo.setTYPE("2");//����             2�G����             3�G�޲z�O
                    theDK_AAZ011_bo.setBANK_NO(""); //�פJ�X�渹
                    theDK_AAZ011_bo.setACNT_NO("");//�פJ�X�b��
                    theDK_AAZ011_bo.setAMT(TOTAL_AMT1.toString());//���B
                    theDK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);//�b�Ⱥ���
                    theDK_AAZ011_bo.setBAL_TYPE(balType);//�b�U�O
                    theDK_AAZ011_bo.setDIV_NO_C101(DIV_NO);
                    DK_AAZ011_BO_LIST.add(theDK_AAZ011_bo);
                }
                BigDecimal TOTAL_AMT2 = STRING.objToBigDecimal(sumMap.get("TOTAL_AMT2"), BigDecimal.ZERO);
                String TOTAL_CNT2 = MapUtils.getString(sumMap, "TOTAL_CNT2", "0");
                if (BigDecimal.ZERO.compareTo(TOTAL_AMT2) != 0) {
                    DK_AAZ011_bo theDK_AAZ011_bo = new DK_AAZ011_bo();
                    theDK_AAZ011_bo.setINPUT_ID(USER_ID);//�g��ID
                    theDK_AAZ011_bo.setINPUT_NAME(USER_NAME);//�g��m�W
                    theDK_AAZ011_bo.setTRN_DATE(TRN_DATE);//�������ɶ�
                    theDK_AAZ011_bo.setTRN_SER_NO(TRN_SER_NO);//����Ǹ�
                    theDK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);//�ǲ��帹
                    theDK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);//�ǲ��ո�
                    theDK_AAZ011_bo.setREL_FILE_NO("DTEPC101");//�����ɥN��
                    theDK_AAZ011_bo.setACNT_DATE(ACNT_DATE);//�b�Ȥ��
                    theDK_AAZ011_bo.setTRN_KIND("EPC301");//�������
                    theDK_AAZ011_bo.setMEMO("");//�K�n
                    theDK_AAZ011_bo.setACNT_DIV_NO(USER_DIV_NO);//���b���
                    theDK_AAZ011_bo.setKIND_CODE(null);//���O�N��
                    theDK_AAZ011_bo.setBUS_CODE("EP");//�~�ȥN�X
                    theDK_AAZ011_bo.setBUS_TRAN_CODE("1");//�~�ȥ���N�X
                    theDK_AAZ011_bo.setCURR("NTD");//���O
                    theDK_AAZ011_bo.setCNT(TOTAL_CNT2);//���
                    theDK_AAZ011_bo.setITEM("10");//����
                    theDK_AAZ011_bo.setTYPE("3");//���� 2�G����    3�G�޲z�O
                    theDK_AAZ011_bo.setBANK_NO("");//�פJ�X�渹
                    theDK_AAZ011_bo.setACNT_NO("");//�פJ�X�b��
                    theDK_AAZ011_bo.setAMT(TOTAL_AMT2.toString());//���B
                    theDK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);//�b�Ⱥ���
                    theDK_AAZ011_bo.setBAL_TYPE(balType);//�b�U�O
                    theDK_AAZ011_bo.setDIV_NO_C101(DIV_NO);
                    DK_AAZ011_BO_LIST.add(theDK_AAZ011_bo);
                }

                //�ʦ����B�X�b�Ҳ�BO
                BigDecimal TOTAL_AMT3 = STRING.objToBigDecimal(sumMap.get("TOTAL_AMT3"), BigDecimal.ZERO);
                String TOTAL_CNT3 = MapUtils.getString(sumMap, "TOTAL_CNT3", "0");
                DK_AAZ011_bo theDK_AAZ011_bo = new DK_AAZ011_bo();
                theDK_AAZ011_bo.setINPUT_ID(USER_ID);//�g��ID
                theDK_AAZ011_bo.setINPUT_NAME(USER_NAME);//�g��m�W
                theDK_AAZ011_bo.setTRN_DATE(TRN_DATE);//�������ɶ�
                theDK_AAZ011_bo.setTRN_SER_NO(TRN_SER_NO);//����Ǹ�
                theDK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);//�ǲ��帹
                theDK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);//�ǲ��ո�
                theDK_AAZ011_bo.setREL_FILE_NO("DTEPC101");//�����ɥN��
                theDK_AAZ011_bo.setACNT_DATE(ACNT_DATE);//�b�Ȥ��
                theDK_AAZ011_bo.setTRN_KIND("EPC301");//�������
                theDK_AAZ011_bo.setMEMO("");//�K�n
                theDK_AAZ011_bo.setACNT_DIV_NO(USER_DIV_NO);//���b���
                theDK_AAZ011_bo.setKIND_CODE(null);//���O�N��
                theDK_AAZ011_bo.setBUS_CODE("EP");//�~�ȥN�X
                theDK_AAZ011_bo.setBUS_TRAN_CODE("1");//�~�ȥ���N�X
                theDK_AAZ011_bo.setCURR("NTD");//���O
                theDK_AAZ011_bo.setCNT(TOTAL_CNT3);//���
                theDK_AAZ011_bo.setITEM("10");//����
                theDK_AAZ011_bo.setTYPE("1");//����             2�G����             3�G�޲z�O
                theDK_AAZ011_bo.setBANK_NO(""); //�פJ�X�渹
                theDK_AAZ011_bo.setACNT_NO("");//�פJ�X�b��
                theDK_AAZ011_bo.setAMT(TOTAL_AMT3.toString());//���B
                theDK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);//�b�Ⱥ��� 
                theDK_AAZ011_bo.setBAL_TYPE(balType);//�b�U�O
                theDK_AAZ011_bo.setDIV_NO_C101(DIV_NO);
                DK_AAZ011_BO_LIST.add(theDK_AAZ011_bo);
            }
            //�I�s�X�b�Ҳ� 
            new DK_A0Z003().doInsert(DK_AAZ011_BO_LIST, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(rm.getMsgDesc());
            }
        }
        //�v���B�zreqList�A�^���ǲ���T��������(DTEPC101)
        DataSet ds = Transaction.getDataSet();
        for (Map map : reqList) {
            ds.clear();
            ds.setField("TURN_ACNT_DATE", ACNT_DATE);
            ds.setField("TURN_ID", USER_ID);
            ds.setField("TURN_NAME", USER_NAME);
            ds.setField("TURN_SLPLOT_NO", SLIP_LOT_NO);
            ds.setField("TURN_SLPSET_NO", SLIP_SET_NO);
            ds.setField("OP_STATUS", "4");//�ʦ�
            ds.setField("LST_PROC_DATE", currentTime);
            ds.setField("LST_PROC_ID", USER_ID);
            ds.setField("LST_PROC_DIV", USER_DIV_NO);
            ds.setField("LST_PROC_NAME", USER_NAME);
            ds.setField("RCV_NO", MapUtils.getString(map, "RCV_NO"));
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_confirm1_001);
        }

        return rtnMap;
    }

    /**
     * �����ʦ��T�{
     * @param reqMap Map �e���d�����
     * @param reqList  List<Map>  �e���d�ߥX�Ӥw�C�ʦ������
     */
    public void cancel1(Map reqMap, List<Map> reqList) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_001");//�d�߸�Ƥ��o����!
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
            }
        }
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_011");//�ʦ�����Ƥ��o����!
        }
        if (eie != null) {
            throw eie;
        }
        String USER_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");
        /* [20180208] �s�W�P�_���I�sEP_Z00030  */
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            //�զ��|�p�������������BO
            DTDKF001 theDTDKF001 = new DTDKF001();
            theDTDKF001.setACNT_DIV_NO(USER_DIV_NO);
            theDTDKF001.setACNT_DATE(MapUtils.getString(reqMap, "SLIP_DATE"));
            theDTDKF001.setSLIP_LOT_NO("EPA");
            theDTDKF001.setSLIP_SET_NO(MapUtils.getString(reqMap, "SLIP_SET_NO"));
            //�R���|�p������������� 
            ReturnMessage rm = new ReturnMessage();
            new DK_F0Z017().deleteByACNT_DIV_NO(theDTDKF001, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(rm.getMsgDesc());
            }
        }
        //�v���B�zreqList�A���������ɶʦ��T�{���
        Timestamp currentTime = DATE.currentTime();
        String USER_ID = MapUtils.getString(reqMap, "USER_ID");
        String USER_NAME = MapUtils.getString(reqMap, "USER_NAME");
        DataSet ds = Transaction.getDataSet();
        for (Map map : reqList) {
            ds.clear();
            ds.setField("OP_STATUS", "3"); //�w�X�b
            ds.setField("LST_PROC_DATE", currentTime);
            ds.setField("LST_PROC_ID", USER_ID);
            ds.setField("LST_PROC_DIV", USER_DIV_NO);
            ds.setField("LST_PROC_NAME", USER_NAME);
            ds.setField("RCV_NO", MapUtils.getString(map, "RCV_NO"));
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_cancel1_001);
        }

    }

    /**
     * �b�b�T�{
     * @param reqMap Map �e���d�����
     * @param reqList List<Map>   �e���Ŀ諸���
     */
    public void confirm2(Map reqMap, List<Map> reqList) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_001");//�d�߸�Ƥ��o����!
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
            }
        }
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_013");//�Ŀ諸��Ƥ��o����!
        }
        if (eie != null) {
            throw eie;
        }
        Timestamp currentTime = DATE.currentTime();
        //�]�w�b�Ȥ���A�Y�ާ@�ɶ��W�L16:30�A�h�b����U�@�u�@��C
        String ACNT_DATE;
        if (DATE.getTime24().compareTo("16:30:59") <= 0) {
            ACNT_DATE = DATE.getDBDate();
        } else {
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            ACNT_DATE = df.format(WorkDate.getNextXWorkingDate(DATE.today(), 1));//�U�@�u�@��
        }
        //�]�w�b�b�ǲ��帹
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        String SLIP_LOT_NO = getSLIP_LOT_NO("2", ACNT_TYPE);
        String USER_ID = MapUtils.getString(reqMap, "USER_ID");
        //���o�g�����Ǹ�
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        ReturnMessage rm = new ReturnMessage();
        /* [20180208] ��ѩI�sEP_Z0Z001���oTRN_SER_NO  */
        String TRN_SER_NO = theEP_Z0Z001.getTRN_SER_NO(SUB_CPY_ID, USER_ID, ACNT_DATE, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(rm.getMsgDesc());
        }
        //���o�ǲ��ո�
        String USER_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");
        //        /* [20180208] ��ѩI�sEP_Z0Z001���oTRN_SER_NO  */
        String SLIP_SET_NO = theEP_Z0Z001.getSLIP_SET_NO(SUB_CPY_ID, "2", USER_DIV_NO, USER_ID, SLIP_LOT_NO, ACNT_DATE, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(rm.getMsgDesc());
        }
        Map<String, String> rtnMap = new HashMap<String, String>();
        rtnMap.put("ACNT_DATE", ACNT_DATE);
        rtnMap.put("SLIP_LOT_NO", SLIP_LOT_NO);
        rtnMap.put("SLIP_SET_NO", SLIP_SET_NO);

        //�p��b�b���B�`�M
        //150513 modified SG�X�� 
        Map<String, Map<String, BigDecimal>> acntInfo = new HashMap<String, Map<String, BigDecimal>>();// KEY �b�U�O, Map �έp���G
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        //BigDecimal TOTAL_AMT = BigDecimal.ZERO;
        for (Map map : reqList) {
            String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(MapUtils.getString(map, "SUB_CPY_ID"), MapUtils.getString(map, "BLD_CD"));
            Map<String, BigDecimal> sumMap = (Map<String, BigDecimal>) MapUtils.getObject(acntInfo, BAL_TYPE,
                new HashMap<String, BigDecimal>()); //�S�� CREATE �s Map �έp�Ȫ�l�� 0 

            BigDecimal SPR_AMT = obj2Big(map, "SPR_AMT", BigDecimal.ZERO);
            sumMap.put("TOTAL_AMT", STRING.objToBigDecimal(sumMap.get("TOTAL_AMT"), BigDecimal.ZERO).add(SPR_AMT));
            acntInfo.put(BAL_TYPE, sumMap);
        }
        String USER_NAME = MapUtils.getString(reqMap, "USER_NAME");
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        //        /* [20180208] �s�W�P�_���I�sEP_Z00030  */
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            List DK_AAZ011_BO_LIST = new ArrayList();
            //�h�զ��b�b�X�b�Ҳ�
            Set<String> BAL_TYPEs = acntInfo.keySet();
            for (String BAL_TYPE : BAL_TYPEs) {
                Map<String, BigDecimal> sumMap = acntInfo.get(BAL_TYPE);
                BigDecimal TOTAL_AMT = STRING.objToBigDecimal(sumMap.get("TOTAL_AMT"), BigDecimal.ZERO);
                DK_AAZ011_bo theDK_AAZ011_bo = new DK_AAZ011_bo();
                theDK_AAZ011_bo.setINPUT_ID(USER_ID);//�g��ID
                theDK_AAZ011_bo.setINPUT_NAME(USER_NAME);//�g��m�W
                theDK_AAZ011_bo.setTRN_DATE(currentTime.toString());//�������ɶ�
                theDK_AAZ011_bo.setTRN_SER_NO(TRN_SER_NO);//����Ǹ�
                theDK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);//�ǲ��帹
                theDK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);//�ǲ��ո�
                theDK_AAZ011_bo.setREL_FILE_NO("DTEPC101");//�����ɥN��
                theDK_AAZ011_bo.setACNT_DATE(ACNT_DATE);//�b�Ȥ��
                theDK_AAZ011_bo.setTRN_KIND("EPC301");//�������
                theDK_AAZ011_bo.setMEMO("");//�K�n
                theDK_AAZ011_bo.setACNT_DIV_NO(USER_DIV_NO);//���b���
                theDK_AAZ011_bo.setKIND_CODE(null);//���O�N��
                theDK_AAZ011_bo.setBUS_CODE("EP");//�~�ȥN�X
                theDK_AAZ011_bo.setBUS_TRAN_CODE("1");//�~�ȥ���N�X
                theDK_AAZ011_bo.setCURR("NTD");//���O
                theDK_AAZ011_bo.setCNT(String.valueOf(reqList.size()));//���
                theDK_AAZ011_bo.setITEM("11");//����        11�G�b�b
                theDK_AAZ011_bo.setTYPE("");
                theDK_AAZ011_bo.setBANK_NO("");//�פJ�X�渹
                theDK_AAZ011_bo.setACNT_NO("");//�פJ�X�b��
                theDK_AAZ011_bo.setAMT(TOTAL_AMT.toString());//���B
                theDK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);//�b�Ⱥ���
                theDK_AAZ011_bo.setBAL_TYPE(BAL_TYPE);//�b�U�O
                DK_AAZ011_BO_LIST.add(theDK_AAZ011_bo);
            }
            //�I�s�X�b�Ҳ�
            new DK_A0Z003().doInsert(DK_AAZ011_BO_LIST, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(rm.getMsgDesc());
            }
        }
        //�v���B�zreqList�A�^���ǲ���T��������(DTEPC101)
        DataSet ds = Transaction.getDataSet();
        for (Map map : reqList) {
            ds.clear();
            ds.setField("BDEBT_ACNT_DATE", null);
            ds.setField("BDEBT_ID", USER_ID);
            ds.setField("BDEBT_NAME", USER_NAME);
            ds.setField("BDEBT_SLPLOT_NO", null);
            ds.setField("BDEBT_SLPSET_NO", null);
            ds.setField("OP_STATUS", "5");//�b�b
            ds.setField("LST_PROC_DATE", currentTime);
            ds.setField("LST_PROC_ID", USER_ID);
            ds.setField("LST_PROC_DIV", USER_DIV_NO);
            ds.setField("LST_PROC_NAME", USER_NAME);
            ds.setField("RCV_NO", MapUtils.getString(map, "RCV_NO"));
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_confirm2_001);
        }
        //        return;
    }

    /**
     * �����b�b
     * @param reqMap Map �e���d�����
     * @param reqList List<Map>   �e���d�ߥX�Ӥw�C�b�b�����
     */
    public void cancel2(Map reqMap, List<Map> reqList) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_004");//�e���d�ߥX�Ӥw�C�b�b����Ƥ��o����!
        }
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_001");//�d�߸�Ƥ��o����!
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        String USER_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");

        /* [20180208] �s�W�P�_���I�sEP_Z00030  */
        //        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        //        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
        //        //�զ��|�p�������������BO
        //        DTDKF001 theDTDKF001 = new DTDKF001();
        //        String SLIP_DATE = MapUtils.getString(reqMap, "SLIP_DATE");
        //        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");       
        //        theDTDKF001.setACNT_DIV_NO(USER_DIV_NO);
        //        theDTDKF001.setACNT_DATE(SLIP_DATE);
        //        theDTDKF001.setSLIP_LOT_NO("EPB");
        //        theDTDKF001.setSLIP_SET_NO(SLIP_SET_NO);
        //        //�R���|�p�������������
        //        ReturnMessage rm = new ReturnMessage();
        //        new DK_F0Z017().deleteByACNT_DIV_NO(theDTDKF001, rm);
        //        if (rm.getReturnCode() != ReturnCode.OK) {
        //            throw new ModuleException(rm.getMsgDesc());
        //        }
        //        }
        //�v���B�zreqList�A���������ɶʦ��T�{���
        Timestamp currentTime = DATE.currentTime();
        DataSet ds = Transaction.getDataSet();
        String USER_ID = MapUtils.getString(reqMap, "USER_ID");
        String USER_NAME = MapUtils.getString(reqMap, "USER_NAME");

        for (Map map : reqList) {
            ds.clear();
            ds.setField("OP_STATUS", "4");//�ʦ�
            ds.setField("LST_PROC_DATE", currentTime);
            ds.setField("LST_PROC_ID", USER_ID);
            ds.setField("LST_PROC_DIV", USER_DIV_NO);
            ds.setField("LST_PROC_NAME", USER_NAME);
            ds.setField("RCV_NO", MapUtils.getString(map, "RCV_NO"));
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_cancel2_001);
        }
    }

    public String getSLIP_LOT_NO(String QUERY_TYPE, String ACNT_TYPE) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(QUERY_TYPE)) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_017");//�d�ߺ������o����!
        }
        if (StringUtils.isBlank(ACNT_TYPE)) {
            eie = getErrorInputException(eie, "EP_C30100_MSG_018");//�b�Ⱥ������o����!
        }
        if (eie != null) {
            throw eie;
        }
        String SLIP_LOT_NO = null;
        if ("1".equals(QUERY_TYPE)) {
            if ("1".equals(ACNT_TYPE)) {
                SLIP_LOT_NO = "EPA"; //���ʲ��ʦ�
            } else {
                SLIP_LOT_NO = "EPM"; ////���ʲ��ʦ�-�粣
            }
        } else if ("2".equals(QUERY_TYPE)) {
            if ("1".equals(ACNT_TYPE)) {
                SLIP_LOT_NO = "EPB"; //���ʲ���b�b
            } else {
                SLIP_LOT_NO = "EPN";//���ʲ���b�b-�粣
            }
        } else {
            throw new ModuleException(MessageUtil.getMessage("EP_C30100_MSG_016") + QUERY_TYPE);//���o�ǲ��帹���~�A�d�ߺ���
        }
        return SLIP_LOT_NO;
    }

    /**
     * ���Ȥ~�]
     * @param key
     * @param value
     * @param ds
     */
    private void setFieldIfExist(String key, String value, DataSet ds) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }

}
