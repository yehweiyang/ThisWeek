package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dc.b0.module.DC_B0Z003;
import com.cathay.dc.b0.module.DC_B0Z028;
import com.cathay.dk.f0.bo.DK_F0Z003_bo;
import com.cathay.dk.f0.module.DK_F0Z003;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C307;
import com.cathay.util.MessageUtil;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * 
<pre>
DATE    Description Author
2013/10/17  Created ����ʹ

�@�B  �{���\�෧�n�����G
�ҲզW��    �M����ӽT�{���@�Ҳ�
�Ҳ�ID    EP_C30130
���n����    �B�z�M����ӽT�{�@�~
</pre>

[20180208] �ק��
��ؾɤJ:�Ϥ�call DK�Ҳ�
 * 
 * @author ���t�s
 * @since 2013/12/2
 */

@SuppressWarnings("unchecked")
public class EP_C30130 {
    private static final Logger log = Logger.getLogger(EP_C30130.class);

    //private static final String SQL_doQuery_001 = "com.cathay.ep.c3.module.EP_C30130.SQL_doQuery_001";

    //private static final String SQL_doConfirm_001 = "com.cathay.ep.c3.module.EP_C30130.SQL_doConfirm_001";

    //private static final String SQL_doCancelConfirm_001 = "com.cathay.ep.c3.module.EP_C30130.SQL_doCancelConfirm_001";

    private static final String SQL_checkData_001 = "com.cathay.ep.c3.module.EP_C30130.SQL_checkData_001";

    //private static final String SQL_insertDTEPC307_001 = "com.cathay.ep.c3.module.EP_C30130.SQL_insertDTEPC307_001"; �Ҳդ�

    private static final String SQL_deleteDTEPC307_001 = "com.cathay.ep.c3.module.EP_C30130.SQL_deleteDTEPC307_001";

    private static final String SQL_insertDTEPC307_002 = "com.cathay.ep.c3.module.EP_C30130.SQL_insertDTEPC307_002";

    /**
     * ���o�Ȧ�M����ӲM��
     * @param reqMap �d�߸�ƲM��
     * @return
     * @throws ModuleException
     */
    public List<Map> doQuery(Map reqMap) throws Exception {
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30130_MSG_001")); //�d�߻Ȧ�M����ӲM�檺��Ƥ��o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        String ACNT_INFO = MapUtils.getString(reqMap, "ACNT_INFO");
        String[] strs = ACNT_INFO.split(",");
        String BANK_NO = strs[0];
        String ACNT_NO = strs[1];
        String CFM_TYPE = MapUtils.getString(reqMap, "CFM_TYPE");
        String CFM_NAME = MapUtils.getString(reqMap, "CFM_NAME");//�T�{�H��
        Date RMT_DATE_S = obj2Date(reqMap, "RMT_DATE_S", null);
        Date RMT_DATE_E = obj2Date(reqMap, "RMT_DATE_E", null);
        BigDecimal AMOUNT = obj2Big(reqMap, "AMOUNT", null);
        String KEY_WORD = MapUtils.getString(reqMap, "KEY_WORD");
        StringBuilder sb = new StringBuilder();

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if ("0".equals(CFM_TYPE)) {
            ds.setField("CFM_TYPE_0", "0"); //���T�{
        } else if ("1".equals(CFM_TYPE)) {
            ds.setField("CFM_TYPE_1", "1"); //�w�T�{
        } else if ("2".equals(CFM_TYPE)) {
            ds.setField("CFM_TYPE_2", "2"); //�~�b
        } else if ("3".equals(CFM_TYPE)) {
            ds.setField("CFM_TYPE_3", "3");//�|�p�P�b       
        } else if ("4".equals(CFM_TYPE)) {
            ds.setField("CFM_TYPE_4", "4");//�T�{���A���w�T�{���д�        
        }

        if (StringUtils.isNotBlank(BANK_NO)) {
            ds.setField("BANK_NO", BANK_NO);
        }
        if (StringUtils.isNotBlank(ACNT_NO)) {
            ds.setField("ACNT_NO", ACNT_NO);
        }
        if (RMT_DATE_S != null) {
            ds.setField("RMT_DATE_S", RMT_DATE_S);
        }
        if (RMT_DATE_E != null) {
            ds.setField("RMT_DATE_E", RMT_DATE_E);
        }
        if (AMOUNT != null) {
            ds.setField("AMOUNT", AMOUNT);
        }
        if (StringUtils.isNotBlank(KEY_WORD)) {
            sb.append("%").append(KEY_WORD).append("%");
            ds.setField("KEY_WORD", sb.toString());
            sb.setLength(0);
        }
        if (StringUtils.isNotBlank(CFM_NAME)) {
            ds.setField("CFM_NAME", CFM_NAME);
        }
        List<Map> rtnList = new EP_Z0C307().queryC307(ds);//SQL�Ҳդ�@EP_Z0C307:VOTool.findToMaps(ds, SQL_doQuery_001);
        ReturnMessage message = new ReturnMessage();
        ReturnMessage RM = new ReturnMessage();
        DC_B0Z028 theDC_B0Z028 = new DC_B0Z028();
        DK_F0Z003 theDK_F0Z003 = new DK_F0Z003();
        DivData dd = new DivData();
        String CFM_DIV_NO;
        String BANKID;
        String BANK_CHN;
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        for (Map map : rtnList) {

            /* [20180208] �s�W�P�_���I�sEP_Z00030  */
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                //���o�ǲ��Ǹ�
                //181226:�վ�Y�L�b�餣�d�ǲ���T,�קK���T�{�ɤ@��CALL DK
                String ACNT_DATE = MapUtils.getString(map, "ACNT_DATE");
                if (StringUtils.isNotBlank(ACNT_DATE)) {
                    DK_F0Z003_bo Z003BO = theDK_F0Z003.doSwitch("1", ACNT_DATE, MapUtils.getString(map, "SLIP_LOT_NO"), MapUtils.getString(
                        map, "SLIP_SET_NO"), MapUtils.getString(map, "ACNT_DIV_NO"), RM);
                    if (RM.getReturnCode() == ReturnCode.OK) {
                        map.put("SLIP_SEQ_NO", Z003BO.getSLIP_NO());
                    } else {
                        map.put("SLIP_SEQ_NO", "");
                    }
                } else {
                    map.put("SLIP_SEQ_NO", "");
                }

                BANKID = MapUtils.getString(map, "BANKID", ""); //���� 
                BANK_CHN = (StringUtils.isBlank(BANKID) || BANKID.trim().length() != 7) ? BANKID : theDC_B0Z028
                        .getBankInfo(BANKID, message).getBANK_SNAME();

                if (message.getReturnCode() != ReturnCode.OK) {
                    BANK_CHN = BANKID;
                }
                map.put("BANK_CHN", BANK_CHN);

                CFM_DIV_NO = MapUtils.getString(map, "CFM_DIV_NO");
                map.put("CFM_DIV_NO_CHN", StringUtils.isNotBlank(CFM_DIV_NO) ? dd.getUnit4ShortName(CFM_DIV_NO) : "");
            } else {
                CFM_DIV_NO = MapUtils.getString(map, "CFM_DIV_NO");
                map.put("CFM_DIV_NO_CHN", StringUtils.isNotBlank(CFM_DIV_NO) ? FieldOptionList.getName("EP", "AGT_DIV_" + SUB_CPY_ID,
                    CFM_DIV_NO) : "");
            }
        }

        return rtnList;
    }

    /**
     * �T�{�@�~
     * @param reqList List<Map> Map
     *                       <pre> BANK_SER_NO   �Ȧ�b�Ǹ� </pre>
     * @param reqMap �T�{�@�~�M��
     * @param user �n�J��
     * @throws ModuleException
     */
    public void doConfirm(List<Map> reqList, Map reqMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;

        if (reqMap == null || reqMap.isEmpty()) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30130_MSG_011")); //��s��T���o����
        } else {
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "SUB_CPY_ID"))) {
                eie = getEieInstance(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30130_MSG_004")); //�n�J�̤��o����
        }
        if (reqList == null || reqList.isEmpty()) {
            throw getEieInstance(eie, MessageUtil.getMessage("EP_C30130_MSG_003")); //��s��Ƥ��o����  
        }
        List<String> BANK_SER_NOs = new ArrayList<String>();
        for (Map map : reqList) {
            String BANK_SER_NO = MapUtils.getString(map, "BANK_SER_NO");
            if (StringUtils.isBlank(BANK_SER_NO)) {
                throw getEieInstance(eie, MessageUtil.getMessage("EP_C30130_MSG_005"));//�Ȧ�b�Ǹ����o����            
            }
            BANK_SER_NOs.add(BANK_SER_NO);
        }
        if (eie != null) {
            throw eie;
        }

        new EP_Z0C307().confirm(reqMap, user, BANK_SER_NOs);
        /*SQL�Ҳդ�@EP_Z0C307
        String ACC_CHECK = MapUtils.getString(reqMap, "ACC_CHECK");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String ID = MapUtils.getString(reqMap, "ID");
        DataSet ds = Transaction.getDataSet();

        if ("Y".equals(ACC_CHECK)) {
            CUS_NO = null;
            BLD_CD = null;
            CRT_NO = null;
            ID = null;
            ds.setField("ACC_MEMO", reqMap.get("ACC_MEMO"));
            ds.setField("ACNT_DATE", reqMap.get("ACNT_DATE"));
            ds.setField("ACNT_DIV_NO", reqMap.get("ACNT_DIV_NO"));
            ds.setField("SLIP_SET_NO", reqMap.get("SLIP_SET_NO"));
        } else {
            if (StringUtils.isBlank(CUS_NO)) {
                CUS_NO = null;
            }

        }
        ds.setField("ID", ID);
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("CFM_ID", user.getEmpID());
        ds.setField("CFM_NAME", user.getEmpName());
        ds.setField("CFM_DIV_NO", user.getOpUnit());
        ds.setField("CFM_DATE", DATE.getDBDate());
        ds.setFieldValues("BANK_SER_NO", BANK_SER_NOs);
        DBUtil.executeUpdate(ds, SQL_doConfirm_001);*/

    }

    /**
     * �����T�{�@�~
     * @param reqList List<Map> Map
     *                       <pre> BANK_SER_NO   �Ȧ�b�Ǹ� </pre>
     * @throws ModuleException
     */
    public void doCancelConfirm(List<Map> reqList, String SUB_CPY_ID) throws ModuleException {
        if (reqList == null || reqList.isEmpty()) {
            new ErrorInputException(MessageUtil.getMessage("EP_C30130_MSG_003")); //��s��Ƥ��o����  
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        List<String> BANK_SER_NOs = new ArrayList<String>();
        for (Map map : reqList) {
            String BANK_SER_NO = MapUtils.getString(map, "BANK_SER_NO");
            if (StringUtils.isBlank(BANK_SER_NO)) {
                new ErrorInputException(MessageUtil.getMessage("EP_C30130_MSG_005"));//�Ȧ�b�Ǹ����o����            
            }
            BANK_SER_NOs.add(BANK_SER_NO);
        }
        DataSet ds = Transaction.getDataSet();
        this.checkData(BANK_SER_NOs, SUB_CPY_ID, ds);

        new EP_Z0C307().cancelConfirm(BANK_SER_NOs, SUB_CPY_ID);
        /*SQL�Ҳդ�@EP_Z0C307
        ds.clear();
        ds.setFieldValues("BANK_SER_NO", BANK_SER_NOs);
        DBUtil.executeUpdate(ds, SQL_doCancelConfirm_001);*/

    }

    /**
     * �s�W�Ȧ�M������ɸ��
     * @param EPC307List
     * @throws ModuleException
     */
    public void insertDTEPC307(List<Map> EPC307List) throws ModuleException {
        //��DC�l�t�ΩI�s
        this.insertDTEPC307(EPC307List, "00");
    }

    public void insertDTEPC307(List<Map> EPC307List, String SUB_CPY_ID) throws ModuleException {

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (EPC307List == null || EPC307List.isEmpty()) {
            throw new ErrorInputException("�L�ݼg�J���M����");//�L�ݼg�J���M����
        }
        //�q���~�b�B�z
        List<Map> updateEPC307List = processAcntError(EPC307List, SUB_CPY_ID);

        new EP_Z0C307().insertDTEPC307(EPC307List, SUB_CPY_ID);

        DataSet ds = Transaction.getDataSet();
        //�Y�e�@�Ѥw����Ʊq���ʲ��פJ, �B�Q�Ȧ�~�b��R, �h��s�Ȧ�M������ɸ��
        for (Map map : updateEPC307List) {
            ds.clear();
            ds.setField("BANK_SER_NO", MapUtils.getString(map, "BANK_SER_NO")); //�Ȧ�b�Ǹ�
            ds.setField("ERR_CODE", MapUtils.getString(map, "ERR_CODE")); //�~�b����
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_insertDTEPC307_002);
            log.debug("��sDTEPC307���\>>>" + updateEPC307List.size() + "��");
        }
    }

    /**
     * �R���Ȧ�M������ɸ��
     * @param BANK_NO ��w�N��
     * @param ACNT_NO �Ȧ�b��
     * @param RMT_DATE �״ڤ��
     * @throws ModuleException
     */
    public void deleteDTEPC307(String BANK_NO, String ACNT_NO, String RMT_DATE) throws ModuleException {
        //��DC�l�t�ΩI�s
        this.deleteDTEPC307(BANK_NO, ACNT_NO, RMT_DATE, "00");
    }

    public void deleteDTEPC307(String BANK_NO, String ACNT_NO, String RMT_DATE, String SUB_CPY_ID) throws ModuleException {
        //�R���Ȧ�M������ɸ��
        DataSet ds = Transaction.getDataSet();

        //�ˬd�Ȧ�M������ɸ�ƬO�_���w�T�{��
        ds.setField("CFM_TYPE_1", "1");
        ds.setField("RMT_DATE_S", RMT_DATE);
        ds.setField("RMT_DATE_E", RMT_DATE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList = null;
        try {
            rtnList = new EP_Z0C307().queryC307(ds);
            //SQL�Ҳդ�@EP_Z0C307:VOTool.findToMaps(ds, SQL_doQuery_001, false);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L��Ƶ������`");
        }
        if (rtnList != null && rtnList.size() > 0) {
            throw new ModuleException("�w���Ȧ��Ƨ����T�{�A�G���i�i������T�{�@�~");
        }

        ds.clear();
        ds.setField("BANK_NO", BANK_NO);
        ds.setField("ACNT_NO", ACNT_NO);
        ds.setField("RMT_DATE", RMT_DATE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_deleteDTEPC307_001);
    }

    /**
     * �ѧY�ɤJ��PASS��ƦܻȦ�M�������
     * @throws ModuleException
     */
    public void inserDTEPC307(String BANK_NO, String ACNT_NO, String SUB_CPY_ID) throws ModuleException {
        /* [20180208] �s�W�P�_���I�sEP_Z00030  */
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            DC_B0Z003 theDC_B0Z003 = new DC_B0Z003();
            String RMT_DATE = DATE.getDBDate();
            List<Map> EPC307List = theDC_B0Z003.queryDTDCB063(BANK_NO, ACNT_NO, RMT_DATE, "NTD");
            log.debug(DATE.currentTime() + "�ѧY�ɤJ�����o����>>>" + EPC307List.size());
            insertDTEPC307(EPC307List, SUB_CPY_ID);
        } else {
            throw new ModuleException(MessageUtil.getMessage("EP_C30130_MSG_012"));//�D��ؤH���A�L�M����Ӹ��
        }
    }

    /**
     * �q���~�b�B�z
     * @param EPC307List
     * @throws ModuleException 
     */
    public List<Map> processAcntError(List<Map> EPC307List, String SUB_CPY_ID) throws ModuleException {

        //��R����ư��B�z(DR+�PDR-��R, CR+�PCR-��R)
        MultiKeyMap errMultiKeyMap = new MultiKeyMap(); //�s��i��ݭn��R�����(DR-��CR+)
        List<Map> notErrEPC307List = new ArrayList<Map>(); //�s��DR+��CR-���

        Map map = EPC307List.get(0);
        boolean isLinkBankData = StringUtils.isBlank(MapUtils.getString(map, "TX_SEQNO", "")) ? false : true; //�ӷ��O�_���Y�ɤJ��
        log.debug("isLinkBankData>>>" + isLinkBankData);

        //���o�Ȧ�M������ɸ��
        DataSet ds = Transaction.getDataSet();
        String RMT_DATE = MapUtils.getString(map, "RMT_DATE");
        ds.setField("RMT_DATE_S", RMT_DATE);
        ds.setField("RMT_DATE_E", RMT_DATE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnEPC307List = null;
        try {
            rtnEPC307List = new EP_Z0C307().queryC307(ds);
            //SQL�Ҳդ�@EP_Z0C307:VOTool.findToMaps(ds, SQL_doQuery_001, false);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L��Ƶ������`");
        }
        boolean isrtnEPC307List = (rtnEPC307List != null && rtnEPC307List.size() > 0) ? true : false;
        log.debug("isrtnEPC307List>>>" + isrtnEPC307List);

        for (Map EPC307Map : EPC307List) {
            String DC = isLinkBankData ? MapUtils.getString(EPC307Map, "DC")
                    : ("DR".equals(MapUtils.getString(EPC307Map, "PAY_RCV_CODE")) ? "2" : "1"); //1����CR, 2����DR
            String RMT_ID;
            if (isLinkBankData) {
                RMT_ID = trimSpace(EPC307Map, "MEMO1");
                RMT_ID = StringUtils.isBlank(RMT_ID) ? trimSpace(EPC307Map, "ACCNAME") : RMT_ID;
            } else {
                RMT_ID = trimSpace(EPC307Map, "RMT_ID");
            }
            String PN_CODE = MapUtils.getString(EPC307Map, "PN_CODE");
            String TRN_AMT = MapUtils.getString(EPC307Map, "TRN_AMT");
            EPC307Map.put("DC", DC); //�ɶU�O
            EPC307Map.put("RMT_ID", RMT_ID);

            //DR-��CR+
            if (("2".equals(DC) && "-".equals(PN_CODE)) || ("1".equals(DC) && "+".equals(PN_CODE))) {

                //���ʻ~�b����
                EPC307Map.put("ERR_CODE", "Y"); //�~�b����, Y���~�b

                if (errMultiKeyMap.containsKey(DC, PN_CODE, RMT_ID, TRN_AMT)) {
                    List<Map> errEPC307List = (List<Map>) errMultiKeyMap.get(DC, PN_CODE, RMT_ID, TRN_AMT); //�ۦPkey���U��DR-��CR+�M��
                    errEPC307List.add(EPC307Map);
                } else {
                    //errMultiKeyMap��key�� DC�ɶU�O , SIGN������B���t��, ID�״ڤH, TRN_AMT������B 
                    List<Map> errEPC307List = new ArrayList<Map>();
                    errEPC307List.add(EPC307Map);
                    errMultiKeyMap.put(DC, PN_CODE, RMT_ID, TRN_AMT, errEPC307List);
                }
            } else {
                //DR+��CR-
                notErrEPC307List.add(EPC307Map);
            }
        }

        //�qDR+��CR-����Ƥ���RDR-��CR+
        for (Map EPC307Map : notErrEPC307List) {
            String DC = MapUtils.getString(EPC307Map, "DC");
            String RMT_ID = MapUtils.getString(EPC307Map, "RMT_ID");
            String PN_CODE = MapUtils.getString(EPC307Map, "PN_CODE");
            String NPN_CODE = StringUtils.equals(PN_CODE, "+") ? "-" : "+";
            String TRN_AMT = MapUtils.getString(EPC307Map, "TRN_AMT");

            if (errMultiKeyMap.containsKey(DC, NPN_CODE, RMT_ID, TRN_AMT)) {

                //���ʳQ��R���(DR+��CR-) 
                EPC307Map.put("ERR_CODE", "Y"); //�~�b����, Y���~�b
                List<Map> errEPC307List = (List<Map>) errMultiKeyMap.get(DC, NPN_CODE, RMT_ID, TRN_AMT);//��key���U����R�M��
                if (errEPC307List.size() == 1) {
                    errMultiKeyMap.remove(DC, NPN_CODE, RMT_ID, TRN_AMT);//�q��R�M�椤����
                } else {
                    errEPC307List.remove(0);//�q�ۦPkey�U��R�M�椤����
                }
            }
        }

        MultiKeyMap multiKeyMap = new MultiKeyMap(); //�s��Ҧ��M������ɸ��
        List<Map> updateEPC307List = new ArrayList<Map>(); //�s��ݲ��ʪ��M������ɸ��

        //�Y�����, ���ܤw�q���ʲ��פJ�Y�ɤJ�����(�C��̫�@�u�@��)
        if (isrtnEPC307List) {
            log.debug("rtnEPC307List SIZE>>>" + rtnEPC307List.size());

            for (Map EPC307Map : EPC307List) {
                if (isLinkBankData) {
                    //errMultiKeyMap��key��TX_DATE������, TX_SEQNO����Ǹ� , TX_MACH�������, TX_TIME����ɶ�
                    multiKeyMap.put(MapUtils.getString(EPC307Map, "TX_DATE"), MapUtils.getString(EPC307Map, "TX_SEQNO"), MapUtils
                            .getString(EPC307Map, "TX_MACH"), MapUtils.getString(EPC307Map, "TX_TIME"), EPC307Map);
                    log.debug("multiKeyMap.put��TX_DATE>>>" + MapUtils.getString(EPC307Map, "TX_DATE") + ",TX_SEQNO>>>"
                            + MapUtils.getString(EPC307Map, "TX_SEQNO") + ",TX_MACH>>>" + MapUtils.getString(EPC307Map, "TX_MACH")
                            + ",TX_TIME>>>" + MapUtils.getString(EPC307Map, "TX_TIME"));
                } else {
                    //errMultiKeyMap��key��PAY_RCV_CODE�ɶU�O, PN_CODE���t�� , TRN_AMT������B, RMT_ID�״�ID
                    multiKeyMap.put(MapUtils.getString(EPC307Map, "PAY_RCV_CODE"), MapUtils.getString(EPC307Map, "PN_CODE"), MapUtils
                            .getString(EPC307Map, "TRN_AMT"), trimSpace(EPC307Map, "RMT_ID"), MapUtils.getString(EPC307Map, "RMT_DATE"),
                        EPC307Map);
                    log.debug("multiKeyMap.put��PAY_RCV_CODE>>>" + MapUtils.getString(EPC307Map, "PAY_RCV_CODE") + ",PN_CODE>>>"
                            + MapUtils.getString(EPC307Map, "PN_CODE") + ",TRN_AMT>>>" + MapUtils.getString(EPC307Map, "TRN_AMT")
                            + ",RMT_ID>>>" + trimSpace(EPC307Map, "RMT_ID") + ",RMT_DATE>>>" + MapUtils.getString(EPC307Map, "RMT_DATE"));
                }
            }

            for (Map rtnEPC307Map : rtnEPC307List) {
                Map epc307Map;
                if (isLinkBankData) {
                    epc307Map = (Map) multiKeyMap.get(DATE.toDate_yyyyMMdd(MapUtils.getString(rtnEPC307Map, "RMT_DATE")), MapUtils
                            .getString(rtnEPC307Map, "TX_SEQNO"), MapUtils.getString(rtnEPC307Map, "TX_MACH"), MapUtils.getString(
                        rtnEPC307Map, "TX_TIME"));
                    log.debug("multiKeyMap.set��TX_DATE>>>" + DATE.toDate_yyyyMMdd(MapUtils.getString(rtnEPC307Map, "RMT_DATE"))
                            + ",TX_SEQNO>>>" + MapUtils.getString(rtnEPC307Map, "TX_SEQNO") + ",TX_MACH>>>"
                            + MapUtils.getString(rtnEPC307Map, "TX_MACH") + ",TX_TIME>>>" + MapUtils.getString(rtnEPC307Map, "TX_TIME"));
                } else {
                    String PAY_RCV_CODE = "2".equals(MapUtils.getString(rtnEPC307Map, "DC")) ? "DR" : "CR";
                    String RMT_ID = trimSpace(rtnEPC307Map, "MEMO1");
                    RMT_ID = StringUtils.isBlank(RMT_ID) ? trimSpace(rtnEPC307Map, "ACCNAME") : RMT_ID;
                    RMT_ID = trimSpace(null, substring(RMT_ID, 0, 10)); //�C��i�Ӫ�RMT_ID�̦h10�줸
                    epc307Map = (Map) multiKeyMap.get(PAY_RCV_CODE, MapUtils.getString(rtnEPC307Map, "SIGN"), MapUtils.getString(
                        rtnEPC307Map, "AMOUNT"), RMT_ID, MapUtils.getString(rtnEPC307Map, "RMT_DATE"));
                    log.debug("multiKeyMap.set��PAY_RCV_CODE>>>" + PAY_RCV_CODE + ",PN_CODE>>>" + MapUtils.getString(rtnEPC307Map, "SIGN")
                            + ",TRN_AMT>>>" + MapUtils.getString(rtnEPC307Map, "AMOUNT") + ",RMT_ID>>>" + RMT_ID + ",RMT_DATE>>>"
                            + MapUtils.getString(rtnEPC307Map, "RMT_DATE"));
                }

                //�Y�ӧ��Ƥ�, ���~�b���ܬ�Y, ���s�b�쥻EPC307�~�b���ܬ�N��, ���ܸӸ�ƫ�ӳQ�Ȧ氵�~�b�R�b
                if (epc307Map != null) {
                    if ("Y".equals(MapUtils.getString(epc307Map, "ERR_CODE")) && "N".equals(MapUtils.getString(rtnEPC307Map, "ERR_CODE"))) {
                        rtnEPC307Map.put("ERR_CODE", "Y");
                        updateEPC307List.add(rtnEPC307Map);
                    }
                    //�����w�g�s�b�����
                    EPC307List.remove(epc307Map);
                }
            }
        }

        log.debug("updateEPC307List SIZE>>>" + updateEPC307List.size());
        return updateEPC307List;
    }

    /**
     * �ˮֻȦ�M������ɸ�ƬO�_�i����
     * @param BANK_SER_NOs
     * @throws ModuleException
     */
    private void checkData(List<String> BANK_SER_NOs, String SUB_CPY_ID, DataSet ds) throws ModuleException {
        ds.clear();
        ds.setFieldValues("BANK_SER_NO", BANK_SER_NOs);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_checkData_001, false);
        if (rtnList != null && rtnList.size() > 0) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30130_MSG_009")); //�ӵ���Ƥw����ú���αb�ȽT�{�A�G���i�i�沧��
        }
    }

    /**
     * ���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getEieInstance(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * ����榡�ഫ
     * @param map
     * @param key
     * @param defaultValue
     * @return
     * @throws ModuleException
     */
    private Date obj2Date(Map map, String key, Date defaultValue) throws ModuleException {
        Object o = MapUtils.getObject(map, key);
        if (o != null) {
            if (o instanceof Date) {
                return (Date) o;
            }
            String ostr = o.toString();
            if (DATE.isDate(ostr)) {
                return Date.valueOf(ostr);
            }
        }
        return defaultValue;
    }

    /**
     * �Ʀr�榡�ഫ
     * @param map
     * @param key
     * @param defaultValue
     * @return
     * @throws ModuleException
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) throws ModuleException {
        Object o = MapUtils.getObject(map, key);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }

        return defaultValue;
    }

    /**
     * �N�r���^��start��end�r��
     * @param src
     * @param start
     * @param end
     * @return
     */
    private String substring(String src, int start, int end) {
        byte[] b = src.getBytes();
        return substring(b, start, end);
    }

    /**
     * �N�r���}�C�^��start��end�r��
     * @param src
     * @param start
     * @param end
     * @return
     */
    private String substring(byte[] src, int start, int end) {
        if (src.length < 10) {
            return new String(src);
        }

        byte[] tmp = new byte[end - start];
        System.arraycopy(src, start, tmp, 0, tmp.length);
        return new String(tmp);
    }

    /**
     * �N���Υb�Ϊťեh��
     * @param map
     * @param key
     * @return
     */
    private String trimSpace(Map map, String key) {
        //�h�b�Ϊť�
        String str = map == null ? key : MapUtils.getString(map, key, "").trim();

        //�h���Ϊť�
        str = STRING.trimFullSpace(str);
        return str;
    }
}
