package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.Id;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dk.bo.DTDKG002;
import com.cathay.dk.bo.DTDKG003;
import com.cathay.dk.g0.module.DK_G0Z002;
import com.cathay.dk.g0.module.DK_G0Z011;
import com.cathay.ep.vo.DTEPC301;
import com.cathay.ep.vo.DTEPC306;
import com.cathay.ep.vo.DTEPC309;
import com.cathay.ep.vo.DTEPC310;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C101;
import com.cathay.ep.z0.module.EP_Z0C301;
import com.cathay.ep.z0.module.EP_Z0C302;
import com.cathay.ep.z0.module.EP_Z0C303;
import com.cathay.ep.z0.module.EP_Z0C306;
import com.cathay.ep.z0.module.EP_Z0C307;
import com.cathay.ep.z0.module.EP_Z0C309;
import com.cathay.ep.z0.module.EP_Z0C310;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2013/09/03  Created ������
 *
 * �@�B    �{���\�෧�n�����G
 * �ҲզW��    ú�O���p�B�z���@�Ҳ�
 * �Ҳ�ID    EP_C30020
 * ���n����    �B�zú�ڱb�ȽT�{�@�~
 * 
 * [20180208] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * 
 * [20180227]�ק��
 * ���:�D���
 * 
 *</pre>
 * @author ���_��
 * @since 2013/11/1
 */

@SuppressWarnings("unchecked")
public class EP_C30020 {
    /**logger*/
    private static final Logger log = Logger.getLogger(EP_C30020.class);

    /**isDebug*/
    private boolean isDebug = log.isDebugEnabled();

    private static final String SQL_queryRtlInfoList_001 = "com.cathay.ep.c3.module.EP_C30020.SQL_queryRtlInfoList_001";

    private static final String SQL_queryTmpInfoList_001 = "com.cathay.ep.c3.module.EP_C30020.SQL_queryTmpInfoList_001";

    private static final String SQL_cancelPayInfo_004 = "com.cathay.ep.c3.module.EP_C30020.SQL_cancelPayInfo_004";

    private static final String SQL_cancelPayInfo_005 = "com.cathay.ep.c3.module.EP_C30020.SQL_cancelPayInfo_005";

    //    private static final String SQL_cancelPayInfo_001 = "com.cathay.ep.c3.module.EP_C30020.SQL_cancelPayInfo_001";

    //    private static final String SQL_cancelPayInfo_002 = "com.cathay.ep.c3.module.EP_C30020.SQL_cancelPayInfo_002";

    //    private static final String SQL_cancelPayInfo_003 = "com.cathay.ep.c3.module.EP_C30020.SQL_cancelPayInfo_003";

    //    private static final String SQL_updateAcntInfo_001 = "com.cathay.ep.c3.module.EP_C30020.SQL_updateAcntInfo_001";

    //    private static final String SQL_cancelPayInfo_006 = "com.cathay.ep.c3.module.EP_C30020.SQL_cancelPayInfo_006";

    //    private static final String SQL_cancelPayInfo_007 = "com.cathay.ep.c3.module.EP_C30020.SQL_cancelPayInfo_007";

    //    private static final String SQL_cancelPayInfo_008 = "com.cathay.ep.c3.module.EP_C30020.SQL_cancelPayInfo_008";

    //    private static final String SQL_updateRcvSprAmt_001 = "com.cathay.ep.c3.module.EP_C30020.SQL_updateRcvSprAmt_001";

    //    private static final String SQL_queryRtlInfoList_002 = "com.cathay.ep.c3.module.EP_C30020.SQL_queryRtlInfoList_002";

    //    private static final String SQL_insertTmpInfo_001 = "com.cathay.ep.c3.module.EP_C30020.SQL_insertTmpInfo_001";

    /**
     * ���oú�O�s��
     * @param SUB_CPY_ID �����q�O
     * @param RCV_YM �����~��
     * @param PAY_TYPE ú�ڤ覡
     * @return ú�O�s��
     * @throws ModuleException
     */
    public String getPayNo(String SUB_CPY_ID, String RCV_YM, String PAY_TYPE) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o����
        }
        if (StringUtils.isBlank(RCV_YM)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_001"));//�����~�뤣�o����
        }
        if (StringUtils.isBlank(PAY_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_002"));//ú�ڤ覡���o����
        }
        if (eie != null) {
            throw eie;
        }

        //���o�y���Ǹ�
        int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "021", RCV_YM, PAY_TYPE);

        //�榡��ú�O�s��
        //SER_NO�e��0��4�X
        String SER_NO_S = STRING.fillZero(Integer.toString(SER_NO), 4, EncodingHelper.DefaultCharset);

        return new StringBuilder().append(SUB_CPY_ID).append(RCV_YM).append(PAY_TYPE).append(SER_NO_S).toString();

    }

    /**
     * ���o�״ڽs��
     * @param SUB_CPY_ID �����q�O
     * @param RMT_DATE �״ڤ��
     * @return �״ڽs��
     * @throws ModuleException
     */
    public String getRmtNo(String SUB_CPY_ID, String RMT_DATE) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o����
        }
        if (StringUtils.isBlank(RMT_DATE) || !DATE.isDate(RMT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_003"));//�״ڤ�����o���ũΤ��Ť���榡
        }
        if (eie != null) {
            throw eie;
        }

        //���o�y���Ǹ�
        String sRMT_DATE = RMT_DATE.replaceAll("-", "");
        int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "025", sRMT_DATE, "1");
        //�榡�ƶ״ڽs�� ,SER_NO�e��0��4�X
        String SER_NO_S = STRING.fillZero(Integer.toString(SER_NO), 4, EncodingHelper.DefaultCharset);

        return new StringBuilder().append(SUB_CPY_ID).append(sRMT_DATE).append(SER_NO_S).toString();
    }

    /**
     * ���o�M��ո�
     * @param SUB_CPY_ID �����q�O
     * @return �M��ո�
     * @throws ModuleException
     */
    public String getAcntSetNo(String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }

        //���o�y���Ǹ�
        int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "027", "1", "1");

        return new StringBuilder().append(SUB_CPY_ID).append(STRING.fillZero(Integer.toString(SER_NO), 8, EncodingHelper.DefaultCharset))
                .toString();

    }

    /**
     * ���oú�O���p��T�M��
     * @param PAY_NO ú�O�s��
     * @return ú�O���p��T�M��
     * @throws ModuleException
     */
    public List<Map> queryRtlInfoList(String PAY_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(PAY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30020_MSG_004"));//ú�O�s�����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30020_MSG_004"));//ú�O�s�����o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> RTL_INFO_LIST;
        try {
            RTL_INFO_LIST = VOTool.findToMaps(ds, SQL_queryRtlInfoList_001);

            //ú�ں���
            for (Map RTL_INFO_MAP : RTL_INFO_LIST) {

                String PAY_KIND = MapUtils.getString(RTL_INFO_MAP, "PAY_KIND");
                RTL_INFO_MAP.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND", PAY_KIND));

                //�]�w�������B
                if ("3".equals(PAY_KIND)) { //�޲z�O
                    RTL_INFO_MAP.put("REC_AMT", RTL_INFO_MAP.get("RCV_AMT"));
                } else if ("2".equals(PAY_KIND)) {//���
                    RTL_INFO_MAP.put("REC_AMT", RTL_INFO_MAP.get("SAL_AMT"));
                } else { //��L �����B���a�O�B�H����
                    RTL_INFO_MAP.put("REC_AMT", RTL_INFO_MAP.get("INV_AMT"));
                }
            }
        } catch (DataNotFoundException dnfe) {
            throw dnfe;
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_005"));//���oú�O���p�o�Ϳ��~
        }
        return RTL_INFO_LIST;
    }

    /**
     * ���oú�O�Ȧ���T�M��
     * @param PAY_NO ú�O�s��
     * @param SUB_CPY_ID �����q�O
     * 
     * @return ú�O�Ȧ���T�M��
     * @throws ModuleException
     */
    public List<Map> queryTmpInfoList(String PAY_NO, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_006"));//ú�O�s�����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        try {
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                DataSet ds = Transaction.getDataSet();
                ds.setField("PAY_NO", PAY_NO);
                //�]�u����ؼȦ��sDK,�G�����q�O�T�w��"00"
                DBUtil.searchAndRetrieve(ds, SQL_queryTmpInfoList_001);
                List<Map> rtnList = new ArrayList<Map>();
                while (ds.next()) {
                    Map rtnMap = VOTool.dataSetToMap(ds);
                    rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EPC3", "TMP_IN_CD", MapUtils.getString(rtnMap, "PAY_KIND")));
                    rtnList.add(rtnMap);
                }
                return rtnList;
            } else {
                // [20180227]�D��ا�gEP.�Ȧ���
                return new EP_Z0C309().queryDTEPC309ByPAY_NO(SUB_CPY_ID, PAY_NO);
            }
        } catch (DataNotFoundException dnfe) {
            throw dnfe;
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_007"));//���oú�O�Ȧ��o�Ϳ��~
        }

    }

    /**
     * �s�Wú�ڬ�����T
     * @param SOURCE �ӷ�����
     * @param PAY_MAP ú�ڬ�����T
     * @param PAY_LIST ú�ڲM��
     * @param RMT_LIST �״ڳ���Ӹ�T�M��
     * @param CHK_LIST ���ک��Ӹ�T�M��
     * @param TKD_LIST �Ȧ��R�b��J�M��
     * @param ACNT_LIST �M����Ӹ�T�M��
     * @param TMP_LIST �Ȧ��J�b��J�M��
     * @param insertList �Ȧ���T
     * @param user �ϥΪ̸�T
     * @return ú�O�s��
     * @throws Exception
     */
    public String insertPayInfo(String QUERY_TYPE, Map PAY_MAP, List<Map> PAY_LIST, List<Map> RMT_LIST, List<Map> CHK_LIST,
            List<Map> TKD_LIST, List<Map> ACNT_LIST, List<Map> TMP_LIST, List<Map> insertList, UserObject user,
            BatchUpdateDataSet[] budsArray) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (PAY_MAP == null || PAY_MAP.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_018"));//ú�ڬ�����T���o����
        }
        if (PAY_LIST == null || PAY_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_019"));//ú�ڲM�椣�o����
        } else {
            SUB_CPY_ID = MapUtils.getString(PAY_LIST.get(0), "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (StringUtils.isBlank(QUERY_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_041"));//�@�~�������o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_009"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        //budsArray = [C101,C301,C302,C303,C307]
        boolean isBatch = false;
        //�Y�S����buds�i��>>���ª���k�]||��buds>>�妸��k
        if (budsArray != null && budsArray.length > 0) {
            isBatch = true;
        }
        //���o�����~��
        String RCV_YM = DATE.getYearAndMonth(DATE.getY2KDate());
        //���oú�O�s��
        String PAY_NO = this.getPayNo(SUB_CPY_ID, RCV_YM, MapUtils.getString(PAY_MAP, "PAY_TYPE"));

        //���o�״ڲո�
        String RMT_SET_NO = "";
        if (RMT_LIST != null && !RMT_LIST.isEmpty()) {
            //budsArray = [C101,C301,C302,C303,C307]
            BatchUpdateDataSet budsC303 = isBatch ? budsArray[3] : null;
            EP_Z0C303 theEP_Z0C303 = new EP_Z0C303();
            RMT_SET_NO = (isBatch && budsC303 != null) ? theEP_Z0C303.insertRmtInfo(RMT_LIST, user, budsC303) : theEP_Z0C303.insertRmtInfo(
                RMT_LIST, user);
        }

        //���o���ڲո�
        String CHK_SET_NO = "";
        if (CHK_LIST != null && !CHK_LIST.isEmpty()) {
            //budsArray = [C101,C301,C302,C303,C307]
            BatchUpdateDataSet budsC302 = isBatch ? budsArray[2] : null;
            EP_Z0C302 theEP_Z0C302 = new EP_Z0C302();
            CHK_SET_NO = (isBatch && budsC302 != null) ? theEP_Z0C302.insertChkInfo(CHK_LIST, user, budsC302) : theEP_Z0C302.insertChkInfo(
                CHK_LIST, user);
        }

        //���o�M��ո�
        String ACNT_SET_NO = "";
        if (ACNT_LIST != null && !ACNT_LIST.isEmpty()) {
            //budsArray = [C101,C301,C302,C303,C307]
            BatchUpdateDataSet budsC307 = isBatch ? budsArray[4] : null;
            EP_Z0C307 theEP_Z0C307 = new EP_Z0C307();
            ACNT_SET_NO = (isBatch && budsC307 != null) ? theEP_Z0C307.updateAcntInfo(ACNT_LIST, user, budsC307) : theEP_Z0C307
                    .updateAcntInfo(ACNT_LIST, user);
        }
        //�B�z�Ȧ��R�b��T
        String DTMP_NO = "";
        if (TKD_LIST != null && !TKD_LIST.isEmpty()) {
            Map rtnMap = this.insertDtmpInfo(PAY_NO, TKD_LIST, user, SUB_CPY_ID);
            DTMP_NO = MapUtils.getString(rtnMap, "DTMP_NO");//�h��
        }

        //���o�������B
        BigDecimal OVR_AMT = BigDecimal.ZERO;
        String TMP_NO = "";
        if (TMP_LIST != null && !TMP_LIST.isEmpty()) {
            //String BAL_TYPE = new EP_Z0G103().getBalTypeByList(PAY_LIST);
            Map rtnMap = this.insertTmpInfo(PAY_NO, TMP_LIST, CHK_SET_NO, CHK_LIST, user, SUB_CPY_ID);
            OVR_AMT = getBigDecimal(rtnMap.get("OVR_AMT"), BigDecimal.ZERO);//�����ɼȦ�
            TMP_NO = MapUtils.getString(rtnMap, "TMP_NO");//�h��
        }

        //�B�zú�ڲM��A���oú�ڲM����B
        //Call�B�zú�ڸ�T��k
        if (isDebug) {
            log.debug("PAY_MAP====>" + PAY_MAP);
        }
        //�wú
        BigDecimal TMP_AMT = BigDecimal.ZERO;
        if ("DTDKG002".equals(QUERY_TYPE)) {
            //Call��s�w���J�Ȧ����Ӹ�T��k
            StringBuffer TMP_NOs = new StringBuffer();
            for (Map PAY_LIST_Map : PAY_LIST) {
                TMP_NOs.append(',').append(new EP_C30050().insertTmpInfo(PAY_LIST_Map, CHK_LIST, CHK_SET_NO, user, SUB_CPY_ID));//�Ȧ��s��
                TMP_AMT = TMP_AMT.add(getBigDecimal(PAY_LIST_Map.get("TMP_AMT"), BigDecimal.ZERO));
            }
            if (TMP_NOs.length() > 0) {
                TMP_NO = TMP_NOs.substring(1).toString();//�h���Ȧ��s��
            }
            //[20180208]��ؾɤJ:�Ϥ�call DK�Ҳ�
            Map inMap = new HashMap();
            inMap.put("SUB_CPY_ID", SUB_CPY_ID);
            inMap.put("RTN_RCPT_NO", PAY_NO);
            inMap.put("LST_CHG_ID", user.getEmpID());
            inMap.put("TMP_NO", TMP_NO);
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {
                new DK_G0Z002().updateDTDKG002RTN_RCPT_NO(inMap);
            } else {
                new EP_Z0C309().update309RTN_RCPT_NO(inMap);
            }
        } else {

            BatchUpdateDataSet budsC101 = isBatch ? budsArray[0] : null;
            BatchUpdateDataSet budsC301 = isBatch ? budsArray[1] : null;
            EP_Z0C101 theEP_Z0C101 = new EP_Z0C101();
            for (Map PAY_INFO_MAP : PAY_LIST) {
                PAY_INFO_MAP.put("TMP_NO", TMP_NO);
                PAY_INFO_MAP.put("PAY_TYPE", MapUtils.getString(PAY_MAP, "PAY_TYPE"));
                PAY_INFO_MAP.put("PMI_S_DATE", MapUtils.getString(PAY_MAP, "PMI_S_DATE"));
                PAY_INFO_MAP.put("PAY_NO", PAY_NO);
                PAY_INFO_MAP.put("SUB_CPY_ID", SUB_CPY_ID);
                if (!isBatch || budsC101 == null || budsC301 == null) {
                    this.insertRtlInfo(PAY_INFO_MAP, user, theEP_Z0C101);//��ξ��B�z
                }
            }

            if (isBatch && budsC101 != null && budsC301 != null) {
                //budsArray = [C101,C301,C302,C303,C307]
                //���s�Wú�O���p
                new EP_Z0C301().insertBatch(PAY_LIST, user, budsC301);
                //����sDBEP.DTEPC101�����ɪ������l�B
                theEP_Z0C101.updateRcvSprAmtBatch("I", PAY_LIST, budsC101);
            }
        }

        DTEPC306 DTEPC306_vo = new DTEPC306();
        DTEPC306_vo.setPAY_NO(PAY_NO);
        //DTEPC306_vo.setCSH_AMT(BigDecimal.ZERO);

        BigDecimal CSH_AMT = getBigDecimal(PAY_MAP.get("CSH_AMT"), BigDecimal.ZERO);
        DTEPC306_vo.setCSH_AMT(CSH_AMT);

        BigDecimal CHK_AMT = getBigDecimal(PAY_MAP.get("CHK_AMT"), BigDecimal.ZERO);
        DTEPC306_vo.setCHK_AMT(CHK_AMT);

        BigDecimal RMT_AMT = getBigDecimal(PAY_MAP.get("RMT_AMT"), BigDecimal.ZERO);
        DTEPC306_vo.setRMT_AMT(RMT_AMT);

        BigDecimal TKD_AMT = getBigDecimal(PAY_MAP.get("TKD_AMT"), BigDecimal.ZERO);
        DTEPC306_vo.setTKD_AMT(TKD_AMT);

        BigDecimal ACNT_AMT = getBigDecimal(PAY_MAP.get("ACNT_AMT"), BigDecimal.ZERO);
        DTEPC306_vo.setACNT_AMT(ACNT_AMT);

        BigDecimal MAL_AMT = getBigDecimal(PAY_MAP.get("MAL_AMT"), BigDecimal.ZERO);
        DTEPC306_vo.setMAL_AMT(MAL_AMT);

        BigDecimal CARD_D_AMT = getBigDecimal(PAY_MAP.get("CARD_D_AMT"), BigDecimal.ZERO);
        DTEPC306_vo.setCARD_D_AMT(CARD_D_AMT);

        BigDecimal PAY_AMT = CHK_AMT.add(RMT_AMT).add(TKD_AMT).add(ACNT_AMT).add(CSH_AMT).add(MAL_AMT).add(CARD_D_AMT);
        DTEPC306_vo.setPAY_AMT(PAY_AMT);

        if (TMP_AMT.compareTo(BigDecimal.ZERO) != 0) {
            TMP_AMT = TMP_AMT.add(OVR_AMT);
        } else {
            TMP_AMT = OVR_AMT;
        }
        DTEPC306_vo.setTMP_AMT(TMP_AMT);

        BigDecimal DACNT_AMT = BigDecimal.ZERO;
        if (!"DTDKG002".equals(QUERY_TYPE)) {
            DACNT_AMT = PAY_AMT.subtract(TMP_AMT);
        }
        DTEPC306_vo.setDACNT_AMT(DACNT_AMT);
        DTEPC306_vo.setCHK_SET_NO(CHK_SET_NO);
        DTEPC306_vo.setRMT_SET_NO(RMT_SET_NO);
        DTEPC306_vo.setACNT_SET_NO(ACNT_SET_NO);
        DTEPC306_vo.setINPUT_ID(user.getEmpID());
        DTEPC306_vo.setINPUT_NAME(user.getEmpName());
        DTEPC306_vo.setSLIP_SET_NO(0);
        DTEPC306_vo.setTRN_KIND("01");
        DTEPC306_vo.setCHG_DATE(DATE.currentTime());
        DTEPC306_vo.setCHG_DIV_NO(user.getOpUnit());
        DTEPC306_vo.setCHG_ID(user.getEmpID());
        DTEPC306_vo.setCHG_NAME(user.getEmpName());
        DTEPC306_vo.setTMP_NO(TMP_NO);
        DTEPC306_vo.setDTMP_NO(DTMP_NO);
        DTEPC306_vo.setCARD_D_NO(MapUtils.getString(PAY_MAP, "CARD_D_NO"));//1030606 yenho �W�[�H�Υd�P�b�s�����O
        DTEPC306_vo.setSUB_CPY_ID(SUB_CPY_ID);
        //�s�WDBEP.DTEPC306ú�ڬ�����
        try {
            VOTool.insert(DTEPC306_vo);
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_021"));//�g�Jú�ڬ����ɦ��~
        }

        return PAY_NO;
    }

    /**
     * ����ú�ڬ�����T
     * @param PAY_MAP ú�ڬ�����T
     * @throws Exception
     */
    public void cancelPayInfo(Map PAY_MAP, BatchUpdateDataSet budsC101) throws Exception {
        if (PAY_MAP == null || PAY_MAP.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30020_MSG_018"));//ú�ڬ�����T���o����
        }

        DataSet ds = Transaction.getDataSet();
        ReturnMessage msg = new ReturnMessage();
        String ACNT_SET_NO = MapUtils.getString(PAY_MAP, "ACNT_SET_NO");
        String SUB_CPY_ID = MapUtils.getString(PAY_MAP, "SUB_CPY_ID");
        if (StringUtils.isNotBlank(ACNT_SET_NO)) {
            //��sDTEPC307�Ȧ�M������ɡA�N���ʲ���EP_Z0C307
            new EP_Z0C307().clearAcntSetNo(ACNT_SET_NO, SUB_CPY_ID);
            /*ds.setField("ACNT_SET_NO", ACNT_SET_NO);
            try {
                DBUtil.executeUpdate(ds, SQL_cancelPayInfo_001);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_026", new Object[] { ACNT_SET_NO }));//�M�ŻȦ�M������ɪ��M��ո����~,�M��ո�={(0)}
            }*/
        }
        String RMT_SET_NO = MapUtils.getString(PAY_MAP, "RMT_SET_NO");
        if (StringUtils.isNotBlank(RMT_SET_NO)) {
            //�R��DTEPC303�״ڳ�����ɡA�N���ʲ���EP_Z0C303
            new EP_Z0C303().deleteByRmtSetNo(RMT_SET_NO, SUB_CPY_ID);
            /*ds.clear();
            ds.setField("RMT_SET_NO", RMT_SET_NO);
            try {
                DBUtil.executeUpdate(ds, SQL_cancelPayInfo_002);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_027", new Object[] { RMT_SET_NO }));//�R���״ڳ������BY�״ڲո����~,�״ڲո�={(0)}
            }*/
        }
        String CHK_SET_NO = MapUtils.getString(PAY_MAP, "CHK_SET_NO");
        if (StringUtils.isNotBlank(CHK_SET_NO)) {
            //�R��DTEPC302���ک����ɡA�N���ʲ���EP_Z0C302
            new EP_Z0C302().deleteByChkSetNo(CHK_SET_NO, SUB_CPY_ID);
            /*ds.clear();
            ds.setField("CHK_SET_NO", CHK_SET_NO);
            try {
                DBUtil.executeUpdate(ds, SQL_cancelPayInfo_003);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_028", new Object[] { CHK_SET_NO }));//�R�����ک�����BY���ڲո����~,���ڲո�={(0)}
            }*/
        }
        BigDecimal TKD_AMT = getBigDecimal(MapUtils.getString(PAY_MAP, "TKD_AMT"), BigDecimal.ZERO);
        String PAY_NO = MapUtils.getString(PAY_MAP, "PAY_NO");
        DK_G0Z002 theDK_G0Z002 = new DK_G0Z002();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        EP_Z0C310 theEP_Z0C310 = new EP_Z0C310();
        EP_Z0C309 theEP_Z0C309 = new EP_Z0C309();
        if (TKD_AMT.compareTo(BigDecimal.ZERO) != 0) {

            //[20180208]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                //�����R�Ȧ����� 
                //�d�ߨR�Ȧ�����
                ds.setField("PAY_NO", PAY_NO);
                List<Map> dtmpNoList = VOTool.findToMaps(ds, SQL_cancelPayInfo_004);
                //�v���B�zdtmpNoList
                //Call�Ȧ��R�b��J�[�R���Ҳ�.�R���Ȧ��R�b��k

                String DTMP_NO;
                for (Map map : dtmpNoList) {
                    DTMP_NO = MapUtils.getString(map, "DTMP_NO");
                    msg.setReturnCode(0);
                    new DK_G0Z011().deleteDTDKG003onlyForXA(DTMP_NO, msg);
                    if (msg.getReturnCode() != 0) {
                        throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_029", new Object[] { DTMP_NO }) + msg.getMsgDesc());//�����R�Ȧ�����BY�Ȧ��R�b�s�����~,�Ȧ��R�b�s��={(0)}
                    }
                }
            } else {
                // [20180227]�D��ا�gEP.�Ȧ���
                List<DTEPC310> C310List = theEP_Z0C310.queryDTEPC310ByPAY_NO(SUB_CPY_ID, PAY_NO);
                //�v���B�zC310List
                for (DTEPC310 C310 : C310List) {
                    theEP_Z0C310.deleteDTEPC310(SUB_CPY_ID, C310.getDTMP_NO());
                }
            }

        }
        BigDecimal DACNT_AMT = getBigDecimal(MapUtils.getString(PAY_MAP, "DACNT_AMT"), BigDecimal.ZERO);

        BigDecimal TMP_AMT = getBigDecimal(MapUtils.getString(PAY_MAP, "TMP_AMT"), BigDecimal.ZERO);

        if (DACNT_AMT.compareTo(BigDecimal.ZERO) != 0 && TMP_AMT.compareTo(BigDecimal.ZERO) != 0) {

            //[20180208]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                //���o�������
                ds.clear();
                ds.setField("PAY_NO", PAY_NO);
                List<Map> dkg002List = VOTool.findToMaps(ds, SQL_cancelPayInfo_005);
                //�v���B�zdkg002List 
                //�����J�Ȧ������ACall�Ȧ��J�b��J�B�R���Ҳ�.�R���������J�b�ɤ�k
                String TMP_NO;
                for (Map map : dkg002List) {
                    TMP_NO = MapUtils.getString(map, "TMP_NO");
                    msg.setReturnCode(0);
                    theDK_G0Z002.deleteDTDKG002ByTMP_NOForXA(TMP_NO, msg);
                    if (msg.getReturnCode() != 0) {
                        throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_030", new Object[] { TMP_NO }) + msg.getMsgDesc());//������������BY�Ȧ��J�b�s�����~,�Ȧ��J�b�s��={(0)}
                    }
                }
            } else {
                //[20180227]�D��ا�gEP.�Ȧ���
                List<Map> C309List = theEP_Z0C309.queryDTEPC309ByPAY_NO(SUB_CPY_ID, PAY_NO);

                //�v���B�zdkg002List 
                for (Map C309 : C309List) {
                    //�����J�Ȧ������ACall�Ȧ��J�b��J�B�R���Ҳ�.�R���������J�b�ɤ�k
                    theEP_Z0C309.deleteDTEPC309ByTMP_NO(MapUtils.getString(C309, "SUB_CPY_ID"), MapUtils.getString(C309, "TMP_NO"));
                }

            }

        }

        /*if (DACNT_AMT.compareTo(BigDecimal.ZERO) == 0 && TMP_AMT.compareTo(BigDecimal.ZERO) != 0) {
            //[20180208]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                //�����w������
                //�d�߹w������
                ds.clear();
                ds.setField("PAY_NO", PAY_NO);
                List<Map> tmpNoList = VOTool.findToMaps(ds, SQL_cancelPayInfo_006);

                //�v���B�ztmpNoList
                // �]�w�Ȧ���s�Ѽ�inMap
                Map inMap = new HashMap();
                for (Map map : tmpNoList) {

                    String TMP_NO = MapUtils.getString(map, "TMP_NO");
                    inMap.put("RTN_RCPT_NO", "");
                    inMap.put("LST_CHG_ID", "");
                    inMap.put("TMP_NO", TMP_NO);

                    //Call�Ȧ��J�b��J�B�R���Ҳ�.�̼Ȧ��s����s�h�����I���ڸ��X��k
                    try {
                        theDK_G0Z002.updateDTDKG002RTN_RCPT_NO(inMap);
                    } catch (ModuleException me) {
                        log.error("", me);
                        throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_034", new Object[] { TMP_NO }));//��s�w���J�Ȧ����Ӹ�Ʀ��~,�Ȧ��s��={0}
                    }
                }
            } else {
                //:�D��ا�gEP.�Ȧ���
                tmpNoList = EP_Z0C309.queryDTEPC309ByPAY_NO(SUB_CPY_ID, PAY_NO);
                //�v���B�ztmpNoList�A�]�w�Ȧ���s�Ѽ�inMap
                for (Map inMap : tmpNoList) {
                    Map inMap = new HashMap();
                    String TMP_NO = MapUtils.getString(map, "TMP_NO");
                    inMap.put("RTN_RCPT_NO", "");
                    inMap.put("LST_CHG_ID", "");
                    inMap.put("TMP_NO", TMP_NO); 
                    inMap.put("SUB_CPY_ID", SUB_CPY_ID);
                    
                    //Call�Ȧ��J�b��J�B�R���Ҳ�.�̼Ȧ��s����s�h�����I���ڸ��X��k
                    EP_Z0C309. update309RTN_RCPT_NO(inMap);
                }

            }

        }*/

        if (DACNT_AMT.compareTo(BigDecimal.ZERO) != 0) {
            //�^�_�����ɾl�B

            try {
                List<Map> RTL_INFO_LIST = this.queryRtlInfoList(PAY_NO, SUB_CPY_ID);
                //VOTool.findToMaps(ds, SQL_queryRtlInfoList_002);
                EP_Z0C101 theEP_Z0C101 = new EP_Z0C101();
                if (budsC101 != null) {//����buds�i�Ӥ~�Χ妸update
                    theEP_Z0C101.updateRcvSprAmtBatch("D", RTL_INFO_LIST, budsC101);
                } else {
                    for (Map rtlInfoMap : RTL_INFO_LIST) {
                        theEP_Z0C101.updateRcvSprAmt("D", MapUtils.getString(rtlInfoMap, "PAY_NO"), getBigDecimal(
                            rtlInfoMap.get("PAY_AMT"), BigDecimal.ZERO), (String) rtlInfoMap.get("RCV_NO"), getBigDecimal(rtlInfoMap
                                .get("SPR_AMT"), BigDecimal.ZERO), rtlInfoMap, theEP_Z0C101);
                    }
                }
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_040"));//���oú�O���p�P�����l�B�o�Ϳ��~
            }
            //����DTEPC301ú�O���p��
            try {
                new EP_Z0C301().deleteByPayNo(PAY_NO, SUB_CPY_ID);
                /*ds.clear();
                ds.setField("PAY_NO", PAY_NO);
                DBUtil.executeUpdate(ds, SQL_cancelPayInfo_007);*/
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_032", new Object[] { PAY_NO }));//�R��ú�O���p��BYú�O�s�����~,ú�O�s��={(0)}
            }

        }

        //�R��DTEPC306ú�ڬ�����
        try {
            new EP_Z0C306().deleteByPayNo(PAY_NO, SUB_CPY_ID);
            /*ds.clear();
            ds.setField("PAY_NO", PAY_NO);
            DBUtil.executeUpdate(ds, SQL_cancelPayInfo_008);*/
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_033", new Object[] { PAY_NO }));//�R��ú�ڬ�����BYú�O�s�����~,ú�O�s��={(0)}
        }

    }

    /**
     * �s�W�Ȧ��R�b���Ӹ�T
     * @param PAY_NO ú�O�s��
     * @param TKD_INFO_LIST �Ȧ��R�b���Ӹ�T�M��
     * @param user �ϥΪ̸�T
     * @param SUB_CPY_ID �����q�O
     * @throws Exception 
     * @throws DBException 
     */
    public Map insertDtmpInfo(String PAY_NO, List<Map> TKD_INFO_LIST, UserObject user, String SUB_CPY_ID) throws DBException, Exception {
        ErrorInputException eie = null;

        if (TKD_INFO_LIST == null || TKD_INFO_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_014"));//�Ȧ��R�b���Ӹ�T�M�椣�o����
        }
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_006"));//ú�O�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_009"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        // �v���B�z�ǤJ.TKD_INFO_LIST

        ReturnMessage msg = new ReturnMessage();
        Map rtnMap = new HashMap();

        //����DBDK.DTDKG003�������R�b�ɮ榡
        DK_G0Z011 theDK_G0Z011 = new DK_G0Z011();
        EP_Z0C310 theEP_Z0C310 = new EP_Z0C310();
        //String OpUnit = user.getOpUnit();
        String EmpID = user.getEmpID();
        String EmpName = user.getEmpName();
        String date = DATE.getDBDate();
        StringBuffer DTMP_NOs = new StringBuffer();
        for (Map map : TKD_INFO_LIST) {
            DTDKG003 DTDKG003_vo = new DTDKG003();

            DTDKG003_vo.setTMP_NO(MapUtils.getString(map, "TMP_NO"));//�������J�b�s��
            DTDKG003_vo.setTRN_KIND("EPC302");//�������
            DTDKG003_vo.setTMP_CD("A");//�������O
            DTDKG003_vo.setINPUT_CD("2");//��J�覡
            DTDKG003_vo.setDACNT_ID(EmpID);
            DTDKG003_vo.setDACNT_NAME(EmpName);
            DTDKG003_vo.setDACNT_IN_DATE(date);
            DTDKG003_vo.setDACNT_AMT(MapUtils.getString(map, "DACNT_AMT"));//�R�b���B
            DTDKG003_vo.setTMP_D_KIND("9");//�Ȧ��R�b�覡
            DTDKG003_vo.setACPT_ID(MapUtils.getString(map, "ID"));//���ڤH�ҥ󸹽X
            DTDKG003_vo.setACPT_ACNT_NAME(MapUtils.getString(map, "CST_NAME"));//���ڱb��W��
            DTDKG003_vo.setRTN_RCPT_NO(PAY_NO);//�h�O���I���ڸ��X
            //[20180208]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {
                //Call�Ȧ��R�b��J�B�R���Ҳ�.�s�W�Ȧ��R�b��k 
                String DTMP_NO = theDK_G0Z011.insertDTDKG003ForXA(DTDKG003_vo, msg);
                if (msg.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_015") + msg.getMsgDesc());//�s�W�Ȧ��R�b��Ʀ��~,
                }
                //�p���`�������B
                DTMP_NOs.append(',').append(DTMP_NO);
            } else {
                //[20180227] �D��ا�gEP.�Ȧ���
                DTEPC310 C310 = new DTEPC310();
                DTDKG003_vo.setDACNT_IN_DATE(DATE.getDBTimeStamp());
                VOTool.copyVOFromTo(DTDKG003_vo, C310);
                C310.setSUB_CPY_ID(SUB_CPY_ID);
                String DTMP_NO = theEP_Z0C310.insertDTEPC310(C310);
                DTMP_NOs.append(',').append(DTMP_NO);
            }
        }

        if (DTMP_NOs.length() > 0) {
            rtnMap.put("DTMP_NO", DTMP_NOs.substring(1).toString());
        }

        return rtnMap;

    }

    /**
     * �s�W�Ȧ��J�b���Ӹ�T
     * @param PAY_NO ú�O�s��
     * @param TMP_INFO_LIST �Ȧ��J�b���Ӹ�T�M��
     * @param user �ϥΪ̸�T
     * @param SUB_CPY_ID �����q�O
     * @return Map  <pre>
     *               OVR_AMT = �������B
     *               TMP_NO = �Ȧ��s��
     *              </pre>
     * @throws Exception
     */
    public Map insertTmpInfo(String PAY_NO, List<Map> TMP_INFO_LIST, String CHK_SET_NO, List CHK_LIST, UserObject user, String SUB_CPY_ID)
            throws Exception {
        ErrorInputException eie = null;
        if (TMP_INFO_LIST == null || TMP_INFO_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_016"));//�Ȧ��J�b���Ӹ�T�M�椣�o����
        }
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_006"));//ú�O�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_009"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        DK_G0Z002 theDK_G0Z002 = new DK_G0Z002();
        EP_Z0C309 theEP_Z0C309 = new EP_Z0C309();
        ReturnMessage msg = new ReturnMessage();
        Id id = new Id();
        BigDecimal OVR_AMT = BigDecimal.ZERO;
        String OpUnit = user.getOpUnit();
        String EmpID = user.getEmpID();
        String EmpName = user.getEmpName();
        String date = DATE.getDBDate();
        StringBuffer TMP_NOs = new StringBuffer();
        String POLICY_NO = "";
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        //�v���B�z�ǤJ.TMP_INFO_LIST
        for (Map map : TMP_INFO_LIST) {
            BigDecimal ACNT_AMT = BigDecimal.ZERO;
            String TMP_NO = null;

            //����DBDK.DTDKG003�������R�b�ɮ榡
            DTDKG002 DTDKG002_vo = new DTDKG002();
            POLICY_NO = MapUtils.getString(map, "POLICY_NO", "").trim();
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) { //���:�̳��P�_
                if ("I8300100".equals(POLICY_NO)) {
                    DTDKG002_vo.setTMP_KIND("965");//����������
                } else if ("I8300200".equals(POLICY_NO)) {
                    DTDKG002_vo.setTMP_KIND("966");//����������
                } else if ("I8200100".equals(POLICY_NO)) {
                    DTDKG002_vo.setTMP_KIND("975");//����������  //���ʲ����� ��鲣�M��
                } else {
                    if ("8300100".equals(OpUnit)) {
                        DTDKG002_vo.setTMP_KIND("965");//����������
                    } else {
                        DTDKG002_vo.setTMP_KIND("966");
                    }
                }
            } else {//�D���:����N��
                DTDKG002_vo.setTMP_KIND(user.getDivNo());
            }

            String ID = MapUtils.getString(map, "ID");
            if (StringUtils.isNotBlank(ID)) {
                //Call�����Ҧr���ˮּҲ�
                if (ID.length() == 10 && id.checkID1(ID)) {//150515 modified 
                    DTDKG002_vo.setID_KIND("1");
                } else if (id.checkUniSN(ID)) {
                    DTDKG002_vo.setID_KIND("3");//��~�H�Τ@�s���ˮ�
                } else {
                    DTDKG002_vo.setID_KIND("2");
                }
            } else {
                DTDKG002_vo.setID_KIND("");
            }

            ACNT_AMT = getBigDecimal(map.get("ACNT_AMT"), BigDecimal.ZERO);

            DTDKG002_vo.setSYS_NO("EP");
            DTDKG002_vo.setTRN_KIND("EPC301");
            DTDKG002_vo.setTMP_CD("A");
            DTDKG002_vo.setINPUT_CD("2");
            DTDKG002_vo.setACNT_ID(EmpID);
            DTDKG002_vo.setACNT_NAME(EmpName);
            DTDKG002_vo.setACNT_IN_DATE(date);
            DTDKG002_vo.setACNT_AMT(ACNT_AMT.toString());//�J�b���B
            DTDKG002_vo.setBAL_AMT(ACNT_AMT.toString());//�R�b�l�B
            DTDKG002_vo.setTMP_IN_CD(MapUtils.getString(map, "TMP_IN_CD"));
            DTDKG002_vo.setRESN_NO("01");
            DTDKG002_vo.setLST_CHG_DIV(OpUnit);
            DTDKG002_vo.setLST_CHG_ID(EmpID);
            DTDKG002_vo.setLST_CHG_DATE(date);
            if (isDebug) {
                log.debug("POLICY_NO ====> " + POLICY_NO);
            }
            DTDKG002_vo.setPOLICY_NO(POLICY_NO);
            if (isDebug) {
                log.debug("PAY_TIMES ====> " + MapUtils.getString(map, "PAY_TIMES"));
            }
            DTDKG002_vo.setPAY_TIMES(MapUtils.getString(map, "PAY_TIMES"));
            String BLD_CD = MapUtils.getString(map, "BLD_CD");
            DTDKG002_vo.setAPLY_NO(BLD_CD);
            DTDKG002_vo.setRTN_RCPT_NO(PAY_NO);
            DTDKG002_vo.setID(MapUtils.getString(map, "ID"));
            DTDKG002_vo.setCST_NAME(MapUtils.getString(map, "CST_NAME"));
            DTDKG002_vo.setCAT_PREM(MapUtils.getString(map, "PAY_KIND"));
            if (CHK_LIST != null && !CHK_LIST.isEmpty()) {
                DTDKG002_vo.setCHK_SET_NO(CHK_SET_NO);
                DTDKG002_vo.setBANK_NO(STRING.fillZero(MapUtils.getString((Map) CHK_LIST.get(0), "BANK_NO"), 7,
                    EncodingHelper.DefaultCharset));
                DTDKG002_vo.setACNT_NO(STRING.fillZero(MapUtils.getString((Map) CHK_LIST.get(0), "ACNT_NO"), 16,
                    EncodingHelper.DefaultCharset));
                DTDKG002_vo.setCHK_NO(STRING
                        .fillZero(MapUtils.getString((Map) CHK_LIST.get(0), "CHK_NO"), 7, EncodingHelper.DefaultCharset));
                DTDKG002_vo.setCHK_DATE(MapUtils.getString((Map) CHK_LIST.get(0), "CHK_DATE"));
            }
            DTDKG002_vo.setMEMO(MapUtils.getString(map, "BLD_NAME"));
            DTDKG002_vo.setCURR("NTD");

            //�]�w�Ȧ��b�U�O
            String BAL_TYPE = new EP_Z0G103().getBAL_TYPE(MapUtils.getString(map, "SUB_CPY_ID"), BLD_CD, map, POLICY_NO);
            this.setBAL_TYPEforDKG002(DTDKG002_vo, BAL_TYPE);
            //[20180208]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                //Call�Ȧ��J�b��J�B�R���Ҳ�.�s�W�������J�b�ɤ�k
                TMP_NO = theDK_G0Z002.insertDTDKG002ForXA(DTDKG002_vo, msg);
                if (msg.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_017") + msg.getMsgDesc());//�s�W�Ȧ��J�b��Ʀ��~,
                }
            } else {
                //[20180227]�D��ا�gEP.�Ȧ���  
                DTEPC309 C309 = new DTEPC309();
                DTDKG002_vo.setLST_CHG_DATE(null);
                DTDKG002_vo.setACNT_IN_DATE(null);
                VOTool.copyVOFromTo(DTDKG002_vo, C309);
                date = DATE.getDBTimeStamp();
                C309.setLST_CHG_DATE(DATE.currentTime());
                C309.setACNT_IN_DATE(DATE.currentTime());
                C309.setSUB_CPY_ID(SUB_CPY_ID);
                TMP_NO = theEP_Z0C309.insertDTEPC309(C309);
            }
            //�p���`�������B
            OVR_AMT = OVR_AMT.add(ACNT_AMT);
            if (StringUtils.isNotBlank(TMP_NO)) {
                TMP_NOs.append(',').append(TMP_NO);
            }
        }
        Map rtnMap = new HashMap();
        rtnMap.put("OVR_AMT", OVR_AMT);
        if (TMP_NOs.length() > 0) {
            rtnMap.put("TMP_NO", TMP_NOs.substring(1).toString());
        }
        return rtnMap;

    }

    /**
     * �榡�ƼȦ��b�U�O
     * @param DTDKG002_VO
     * @param BAL_TYPE
     */
    public void setBAL_TYPEforDKG002(DTDKG002 DTDKG002_VO, String BAL_TYPE) {
        //�榡�ƼȦ��b�U�O�A����{������
        DTDKG002_VO.setBAL_TYPE(BAL_TYPE); //TODO ��DK�W����
    }

    /**
     * ��s�w���J�Ȧ����Ӹ�T
     * @param PAY_NO ú�O�s��
     * @param PAY_LIST ú�ڲM��
     * @param user �ϥΪ̸�T
     * @param SUB_CPY_ID �����q�O
     * @return �w�����B
     * @throws ModuleException 
     */
    public BigDecimal updateTmpInfo(String PAY_NO, List<Map> PAY_LIST, UserObject user, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (PAY_LIST == null || PAY_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_019"));//ú�ڲM�椣�o����
        }
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_006"));//ú�O�s�����o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_009"));//�ϥΪ̸�T���o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�v���B�z�ǤJ.PAY_LIST�A
        //�]�w�Ȧ���s�Ѽ�inMap
        Map inMap = new HashMap();
        DK_G0Z002 theDK_G0Z002 = new DK_G0Z002();
        BigDecimal TMP_AMT = BigDecimal.ZERO;
        String EmpID = user.getEmpID();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        EP_Z0C309 theEP_Z0C309 = new EP_Z0C309();
        for (Map PAY_LIST_Map : PAY_LIST) {
            String TMP_NO = MapUtils.getString(PAY_LIST_Map, "TMP_NO");
            inMap.put("RTN_RCPT_NO", PAY_NO);
            inMap.put("LST_CHG_ID", EmpID);
            inMap.put("TMP_NO", TMP_NO);
            inMap.put("SUB_CPY_ID", SUB_CPY_ID);
            //[20180208]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                //Call�Ȧ��J�b��J�B�R���Ҳ�.�̼Ȧ��s����s�h�����I���ڸ��X��k
                try {
                    theDK_G0Z002.updateDTDKG002RTN_RCPT_NO(inMap);
                } catch (ModuleException me) {
                    log.error("��s�w���J�Ȧ����Ӹ�Ʀ��~", me);
                    throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_034", new Object[] { TMP_NO }));//��s�w���J�Ȧ����Ӹ�Ʀ��~,�Ȧ��s��={0},
                }
            } else {
                //[20180227]�D��ا�gEP.�Ȧ���
                theEP_Z0C309.update309RTN_RCPT_NO(inMap);
            }

            //�p���`�w�����B
            TMP_AMT = TMP_AMT.add(getBigDecimal(PAY_LIST_Map.get("TMP_AMT"), BigDecimal.ZERO));
        }
        return TMP_AMT;

    }

    /**
     * �s�Wú�O���p��T
     * @param RTL_MAP
     * <pre>
     * {
     * PAY_NO�Gú�O�s��
     * RCV_NO�G�����s��
     * SUB_CPY_ID�G�����q�O
     * RCV_YM�G�����~��
     * PAY_KIND�Gú�ں���
     * CRT_NO�G�����N��
     * CUS_NO�G�Ȥ�Ǹ�
     * PAY_TYPE�Gú�ڤ覡
     * PAY_AMT�G��ú���B
     * COA_DATE�G�Ȧ�P�b��
     * INV_NO�G�o�����X
     * ID�G�ҥ󸹽X
     * CUS_NAME�G�Ȥ�W��
     * BLD_CD�G�j�ӥN��
     * PAY_S_DATE�Gú�کl��
     * PAY_E_DATE�Gú�ڲ״�
     * OP_STATUS_C101�G�����@�~�i��
     *}
     *</pre>
     * @param user �ϥΪ̸�T
     * @throws ModuleException
     */
    /* �妸��k:
     * EP_Z0C301.insertBatch()
       EP_Z0C101.updateRcvSprAmt*/
    public void insertRtlInfo(Map RTL_MAP, UserObject user, EP_Z0C101 theEP_Z0C101) throws ModuleException {
        ErrorInputException eie = null;
        if (RTL_MAP == null || RTL_MAP.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_023"));//�ɮװ򥻸���ɤ��o����
        }
        String RCV_NO = MapUtils.getString(RTL_MAP, "RCV_NO");
        if (StringUtils.isBlank(RCV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_024"));//�����s�����o���ŭ�
        }
        String SUB_CPY_ID = MapUtils.getString(RTL_MAP, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30020_MSG_009"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        String PAY_NO = MapUtils.getString(RTL_MAP, "PAY_NO");
        String RCV_YM = MapUtils.getString(RTL_MAP, "RCV_YM");
        String PAY_KIND = MapUtils.getString(RTL_MAP, "PAY_KIND");
        if (StringUtils.isBlank(PAY_NO)) {
            PAY_NO = this.getPayNo(SUB_CPY_ID, RCV_YM, PAY_KIND);
            RTL_MAP.put("PAY_NO", PAY_NO);
        }

        //��sDBEP.DTEPC101�����ɪ������l�B
        //Call ��s�����������l�B��k
        BigDecimal PAY_AMT = getBigDecimal(RTL_MAP.get("PAY_AMT"), BigDecimal.ZERO);
        theEP_Z0C101.updateRcvSprAmt("I", PAY_NO, PAY_AMT, RCV_NO, getBigDecimal(RTL_MAP.get("SPR_AMT"), BigDecimal.ZERO), RTL_MAP,
            theEP_Z0C101);

        //����DBEP.DTEPC301ú�O���p�ɮ榡
        String PAY_TYPE = MapUtils.getString(RTL_MAP, "PAY_TYPE");
        if (isDebug) {
            log.debug("PAY_TYPE===>" + PAY_TYPE);
            log.debug("RTL_MAP===>" + RTL_MAP);
        }

        DTEPC301 DTEPC301_vo = new DTEPC301();

        if ("5".equals(PAY_TYPE)) {
            DTEPC301_vo.setCHK_CD("0");
        } else {
            DTEPC301_vo.setCHK_CD("");
        }

        DTEPC301_vo.setPAY_NO(PAY_NO);
        DTEPC301_vo.setRCV_NO(RCV_NO);
        DTEPC301_vo.setSUB_CPY_ID(SUB_CPY_ID);
        DTEPC301_vo.setRCV_YM(getBigDecimal(RCV_YM, null));
        DTEPC301_vo.setPAY_KIND(PAY_KIND);
        DTEPC301_vo.setCRT_NO(MapUtils.getString(RTL_MAP, "CRT_NO"));
        DTEPC301_vo.setCUS_NO(Integer.valueOf(MapUtils.getString(RTL_MAP, "CUS_NO")));
        DTEPC301_vo.setPAY_TYPE(PAY_TYPE);
        DTEPC301_vo.setPAY_AMT(PAY_AMT);
        DTEPC301_vo.setORN_AMT(PAY_AMT);
        String COA_DATE = MapUtils.getString(RTL_MAP, "COA_DATE");
        DTEPC301_vo.setCOA_DATE(StringUtils.isNotBlank(COA_DATE) ? Date.valueOf(COA_DATE) : null);
        String PMI_S_DATE = MapUtils.getString(RTL_MAP, "PMI_S_DATE");
        String PMI_E_DATE = MapUtils.getString(RTL_MAP, "PMI_E_DATE");
        DTEPC301_vo.setPMI_S_DATE(StringUtils.isNotBlank(PMI_S_DATE) ? Date.valueOf(PMI_S_DATE) : null);
        DTEPC301_vo.setPMI_E_DATE(StringUtils.isNotBlank(PMI_E_DATE) ? Date.valueOf(PMI_E_DATE) : null);
        DTEPC301_vo.setINV_NO(MapUtils.getString(RTL_MAP, "INV_NO"));
        DTEPC301_vo.setID(MapUtils.getString(RTL_MAP, "ID", "").trim());
        DTEPC301_vo.setCUS_NAME(MapUtils.getString(RTL_MAP, "CUS_NAME"));
        DTEPC301_vo.setBLD_CD(MapUtils.getString(RTL_MAP, "BLD_CD"));
        String PAY_S_DATE = MapUtils.getString(RTL_MAP, "PAY_S_DATE");
        String PAY_E_DATE = MapUtils.getString(RTL_MAP, "PAY_E_DATE");
        DTEPC301_vo.setPAY_S_DATE(StringUtils.isNotBlank(PAY_S_DATE) ? Date.valueOf(PAY_S_DATE) : null);
        DTEPC301_vo.setPAY_E_DATE(StringUtils.isNotBlank(PAY_E_DATE) ? Date.valueOf(PAY_E_DATE) : null);
        String ID = user.getEmpID();
        String NAME = user.getEmpName();
        DTEPC301_vo.setINPUT_ID(ID);
        DTEPC301_vo.setINPUT_NAME(NAME);
        DTEPC301_vo.setSLIP_SET_NO(0);
        DTEPC301_vo.setTRN_KIND("01");
        DTEPC301_vo.setCHG_DATE(DATE.currentTime());
        DTEPC301_vo.setCHG_DIV_NO(user.getOpUnit());
        DTEPC301_vo.setCHG_ID(ID);
        DTEPC301_vo.setCHG_NAME(NAME);
        String OP_STATUS_C101 = MapUtils.getString(RTL_MAP, "OP_STATUS");
        DTEPC301_vo.setOP_STATUS_C101(STRING.isInteger(OP_STATUS_C101) ? Integer.valueOf(OP_STATUS_C101) : null);

        //�s�WDBEP.DTEPC301ú�O���p��
        try {
            VOTool.insert(DTEPC301_vo);
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30020_MSG_025"));//�g�Jú�O���p�ɦ��~
        }
    }

    /**
     * ���oBigDecimal
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaluValue) {
        if (obj == null) {
            return defaluValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String value = obj.toString();
        if (NumberUtils.isNumber(value)) {
            return new BigDecimal(value);
        }
        return defaluValue;
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

}
