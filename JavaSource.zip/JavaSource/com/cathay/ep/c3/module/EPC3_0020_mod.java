package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.ep.z0.module.EP_Z0C101;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE        Description  Author
 * 2013/10/18  Created      ������
 *
 * �@�B    �{���\�෧�n�����G
 * �ҲզW��    ú�O���p�B�z�ˮּҲ�
 * �Ҳ�ID    EPC3_0020_mod
 * ���n����    �ˮֹ�ú���B�Pú�O���p���B
 *</pre>
 * @author ���_��
 * @since 2013/11/6
 */
@SuppressWarnings("unchecked")
public class EPC3_0020_mod {

    private static final String SQL_checkPayNo_001 = "com.cathay.ep.c3.module.EPC3_0020_mod.SQL_checkPayNo_001";

    /**
     * ���B�ˬd
     * @param QUERY_TYPE �@�~����
     * @param PAY_MAP ú�O�M��
     * @param PAY_LIST ú�ڲM��
     * @param RMT_LIST �״ڳ��J�M��
     * @param CHK_LIST ���ڿ�J�M��
     * @param TKD_LIST �Ȧ��R�b��J�M��
     * @param ACNT_LIST �M����b��J�M��
     * @param TMP_LIST �Ȧ��J�b��J�M��
     * @throws ErrorInputException
     */
    public void checkAMT(String QUERY_TYPE, Map PAY_MAP, List<Map> PAY_LIST, List<Map> RMT_LIST, List<Map> CHK_LIST, List<Map> TKD_LIST,
            List<Map> ACNT_LIST, List<Map> TMP_LIST) throws ErrorInputException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(QUERY_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0020_mod_MSG_008"));//�@�~�������o����
        }
        if (eie != null) {
            throw eie;
        }

        //���o�Ȧ��J�b���B
        BigDecimal OVR_AMT = BigDecimal.ZERO;
        for (Map TMP_LIST_map : TMP_LIST) {
            OVR_AMT = OVR_AMT.add(getBigDecimal(TMP_LIST_map.get("ACNT_AMT"), BigDecimal.ZERO));
        }

        BigDecimal CHK_AMT = BigDecimal.ZERO;
        BigDecimal PAY_MAP_CHK_AMT = getBigDecimal(PAY_MAP.get("CHK_AMT"), BigDecimal.ZERO);
        if (CHK_LIST != null && !CHK_LIST.isEmpty()) {

            //���o�䲼���B
            for (Map CHK_LIST_map : CHK_LIST) {
                CHK_AMT = CHK_AMT.add(getBigDecimal(CHK_LIST_map.get("CHK_AMT"), BigDecimal.ZERO));

            }

            //            if (CHK_AMT.add(OVR_AMT).compareTo(PAY_MAP_CHK_AMT) != 0) {
            if (CHK_AMT.compareTo(PAY_MAP_CHK_AMT) != 0) {
                throw new ErrorInputException(MessageUtil.getMessage("EPC3_0020_mod_MSG_009", new Object[] { CHK_AMT, PAY_MAP_CHK_AMT }));//�䲼���B�X�p���~�A���ڿ�J���B:{0}+�Ȧ��J�b���B:{1}<> ú�ڿ�J�䲼���B:{2}
            }
        }

        BigDecimal RMT_AMT = BigDecimal.ZERO;
        BigDecimal PAY_MAP_RMT_AMT = getBigDecimal(PAY_MAP.get("RMT_AMT"), BigDecimal.ZERO);
        BigDecimal PAY_MAP_MAL_AMT = getBigDecimal(PAY_MAP.get("MAL_AMT"), BigDecimal.ZERO);
        if (RMT_LIST != null && !RMT_LIST.isEmpty()) {

            //���o�״ڪ��B
            for (Map RMT_LIST_map : RMT_LIST) {
                RMT_AMT = RMT_AMT.add(getBigDecimal(RMT_LIST_map.get("TRN_AMT"), BigDecimal.ZERO));
            }

            //            if (RMT_AMT.add(OVR_AMT).compareTo(PAY_MAP_RMT_AMT.subtract(PAY_MAP_MAL_AMT)) != 0) {
            if (RMT_AMT.compareTo(PAY_MAP_RMT_AMT) != 0) {
                throw new ErrorInputException(MessageUtil.getMessage("EPC3_0020_mod_MSG_010", new Object[] { RMT_AMT, PAY_MAP_RMT_AMT }));//�״ڪ��B�X�p���~�A�״ڳ��J���B:{0}<>ú�ڿ�J�״ڳ���B:{1}
            }
        }

        BigDecimal TKD_AMT = BigDecimal.ZERO;
        BigDecimal PAY_MAP_TKD_AMT = getBigDecimal(PAY_MAP.get("TKD_AMT"), BigDecimal.ZERO);
        if (TKD_LIST != null && !TKD_LIST.isEmpty()) {

            //���o�R�Ȧ����B
            for (Map TKD_LIST_map : TKD_LIST) {
                TKD_AMT = TKD_AMT.add(getBigDecimal(TKD_LIST_map.get("DACNT_AMT"), BigDecimal.ZERO));
            }

            if (TKD_AMT.compareTo(PAY_MAP_TKD_AMT) != 0) {
                throw new ErrorInputException(MessageUtil.getMessage("EPC3_0020_mod_MSG_011", new Object[] { TKD_AMT, PAY_MAP_TKD_AMT }));//�R�Ȧ����B�X�p���~�A�R�Ȧ���J���B:{0}<>ú�ڿ�J�R�Ȧ����B:{1}
            }
        }

        BigDecimal ACNT_AMT = BigDecimal.ZERO;
        BigDecimal PAY_MAP_ACNT_AMT = getBigDecimal(PAY_MAP.get("ACNT_AMT"), BigDecimal.ZERO);
        if (ACNT_LIST != null && !ACNT_LIST.isEmpty()) {

            //���o�M��P�b���B

            for (Map ACNT_LIST_map : ACNT_LIST) {
                ACNT_AMT = ACNT_AMT.add(getBigDecimal(ACNT_LIST_map.get("AMOUNT"), BigDecimal.ZERO));
            }

            if (ACNT_AMT.compareTo(PAY_MAP_ACNT_AMT) != 0) {
                throw new ErrorInputException(MessageUtil.getMessage("EPC3_0020_mod_MSG_012", new Object[] { ACNT_AMT, OVR_AMT,
                        PAY_MAP_ACNT_AMT }));//�M��P�b���B�X�p���~�A�M��P�b��J���B:{0}+�Ȧ��J�b���B:{1}<>ú�ڿ�J�M��P�b���B:{2}
            }
        }

        BigDecimal DACNT_AMT = BigDecimal.ZERO;
        BigDecimal TMP_AMT = BigDecimal.ZERO;
        //���o�P�b���B
        if ("DTEPC301".equals(QUERY_TYPE)) {
            for (Map PAY_LIST_map : PAY_LIST) {
                DACNT_AMT = DACNT_AMT.add(getBigDecimal(PAY_LIST_map.get("PAY_AMT"), BigDecimal.ZERO));
            }
        } else if ("DTDKG002".equals(QUERY_TYPE)) {
            //���o�Ȧ����B
            for (Map PAY_LIST_map : PAY_LIST) {
                TMP_AMT = TMP_AMT.add(getBigDecimal(PAY_LIST_map.get("ACNT_AMT"), BigDecimal.ZERO));
            }
        }

        //���o��ú���B
        BigDecimal PAY_AMT = PAY_MAP_CHK_AMT.add(PAY_MAP_RMT_AMT).add(PAY_MAP_TKD_AMT).add(PAY_MAP_ACNT_AMT);

        //�ˮ֪��B�X�p
        if (PAY_AMT.add(PAY_MAP_MAL_AMT).compareTo(DACNT_AMT.add(TMP_AMT).add(OVR_AMT)) != 0) {
            throw new ErrorInputException(MessageUtil.getMessage("EPC3_0020_mod_MSG_013", new Object[] { PAY_AMT, PAY_MAP_MAL_AMT,
                    DACNT_AMT, TMP_AMT.add(OVR_AMT) }));//�ˮ֪��B�X�p���~�A��ú���B:{0}+�l�O���B:{1}<>�P�b���B:{2}+�Ȧ����B:{3}
        }

    }

    /**
     * ú�O�s���ˬd
     * @param PAY_NO ú�O�s��
     * @param user �ϥΪ̸�T
     * @throws ModuleException
     */
    public void checkPayNo(String PAY_NO, UserObject user, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0020_mod_MSG_014"));//ú�O�s�����o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0020_mod_MSG_015"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        //�d��DTEPC306ú�ڬ�����
        Map DTEPC306_VO;
        try {
            DataSet ds = Transaction.getDataSet();
            ds.setField("PAY_NO", PAY_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DTEPC306_VO = VOTool.findOneToMap(ds, SQL_checkPayNo_001);
        } catch (ModuleException me) {
            throw new ModuleException(MessageUtil.getMessage("EPC3_0020_mod_MSG_016", new Object[] { PAY_NO }));//�d�Lú�O�s��:{0}ú�ڬ����C
        }

        //�ˬd�b�ȸ�T
        if (!"0".equals(MapUtils.getString(DTEPC306_VO, "SLIP_SET_NO"))) {
            throw new ModuleException(MessageUtil.getMessage("EPC3_0020_mod_MSG_017", new Object[] { PAY_NO }));//ú�O�s��:{0}�w����ú�ڱb�ȽT�{�A���o���p�����C
        }
        //�ˬd��J�H����T
        if (!user.getEmpID().equals(MapUtils.getString(DTEPC306_VO, "INPUT_ID"))) {
            throw new ModuleException(MessageUtil.getMessage("EPC3_0020_mod_MSG_018", new Object[] { PAY_NO }));//ú�O�s��:{0}�D�Ѿާ@�H����J�A���o���p�����C
        }

    }

    /**
     * �ˬd�����l�B�O�_�ۦP
     * @param QRY_TYPE
     * @param PAY_LIST
     * @throws ModuleException 
     */
    public void checkSPR_AMT(String QRY_TYPE, List<Map> PAY_LIST) throws ModuleException {

        //�wú���ˮ������l�B�O�_�ۦP
        if (!"DTDKG002".equals(QRY_TYPE)) {

            //���o��O�M�椧�������
            Map c101MAP = new EP_Z0C101().queryRcvMap(PAY_LIST);

            //�v�����ú�O�M�������l�B�O�_�ۦP
            StringBuilder ERR_RCV_NO = new StringBuilder();
            int index = 0;
            for (Map payMap : PAY_LIST) {
                String RCV_NO = MapUtils.getString(payMap, "RCV_NO");
                Map rcvMap = (Map) c101MAP.get(RCV_NO);
                if (STRING.objToBigDecimal(rcvMap.get("SPR_AMT"), BigDecimal.ZERO).compareTo(
                    STRING.objToBigDecimal(payMap.get("SPR_AMT"), BigDecimal.ZERO)) != 0) {
                    index++;
                    if (index > 10) {
                        ERR_RCV_NO.append(STRING.lineSeparator);
                        index = 0;
                    }
                    ERR_RCV_NO.append(MapUtils.getString(rcvMap, "RCV_NO")).append(",");
                }
            }
            if (ERR_RCV_NO.length() != 0) {
                throw new ModuleException(MessageUtil.getMessage("EPC3_0020_mod_MSG_020")/*�����l�B�w�g�Q��L�@�~���ʡA�����s��:*/
                        + ERR_RCV_NO.substring(0, ERR_RCV_NO.length() - 1).toString());
            }
        }
    }

    /**
     * �ˮ֬O�_�Vú
     * @param PAY_LIST
     * @throws ModuleException
     */
    public void chkBAL_TYPE(List<Map> PAY_LIST, List<Map> TMP_LIST) throws ModuleException {
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        String TMP_BAL_TYPE = null;
        for (Map PAY_MAP : PAY_LIST) {
            String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(MapUtils.getString(PAY_MAP, "SUB_CPY_ID"), MapUtils.getString(PAY_MAP, "BLD_CD"),
                PAY_MAP, MapUtils.getString(PAY_MAP, "CRT_NO", "").trim());
            if (StringUtils.isBlank(TMP_BAL_TYPE)) {
                TMP_BAL_TYPE = BAL_TYPE;
            } else if (!TMP_BAL_TYPE.equals(BAL_TYPE)) {
                throw new ModuleException("�b�U�O���@�P�A���i�Vú");
            }
        }

        //��ú
        for (Map map : TMP_LIST) {
            String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(MapUtils.getString(map, "SUB_CPY_ID"), MapUtils.getString(map, "BLD_CD"), map,
                MapUtils.getString(map, "POLICY_NO", "").trim());
            if (StringUtils.isBlank(TMP_BAL_TYPE)) {
                TMP_BAL_TYPE = BAL_TYPE;
            } else if (!TMP_BAL_TYPE.equals(BAL_TYPE)) {
                throw new ModuleException("�b�U�O���@�P�A���i�Vú");
            }
        }
    }

    /**
     * ���oBigDecimal
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaluValue) {
        if (obj == null) {
            return defaluValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String value = obj.toString();
        if (NumberUtils.isNumber(value)) {
            return new BigDecimal(value);
        }
        return defaluValue;
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

}
