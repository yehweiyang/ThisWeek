package com.cathay.ep.c3.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2013/08/12  Created ������
 *
 * �@�B   �{���\�෧�n�����G
 * �ҲզW��    �״ڳ��J���@�Ҳ�
 * �Ҳ�ID    EP_C30021
 * ���n����    ���o�״ڳ�����ɸ�Ƨ@�~
 *</pre>
 * @author ���_��
 * @since 2013/11/4
 */
@SuppressWarnings("unchecked")
public class EP_C30021 {

    private static final String SQL_queryRmtInfoList_001 = "com.cathay.ep.c3.module.EP_C30021.SQL_queryRmtInfoList_001";

    private static final String SQL_queryDTEPC306_001 = "com.cathay.ep.c3.module.EP_C30021.SQL_queryDTEPC306_001";

    /**
     * ���o�״ڳ���ӲM�� 
     * @param PAY_NO ú�O�s��
     * @return �״ڳ���ӲM��
     * @throws ModuleException
     */
    public List<Map> queryRmtInfoList(String PAY_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(PAY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30021_MSG_001"));//�����s�����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("PAY_NO", PAY_NO);
        try {
            return VOTool.findToMaps(ds, SQL_queryRmtInfoList_001, false);
        } catch (ModuleException me) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30021_MSG_002"), me);//���o�״ڳ���ӲM��o�Ϳ��~,
        }
    }

    /**
     * 
     * @param reqMap
     * @throws ModuleException 
     */
    public List<Map> queryDTEPC306(Map reqMap) throws ModuleException {
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30021_MSG_003"));//�d�߸�Ƥ��o���ŭ�
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("RMT_SET_NO", reqMap.get("RMT_SET_NO"));
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_queryDTEPC306_001);
    }
}
