package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.util.NumberUtils;

/**
 * <pre>
 * DATE        Description Author
 * 2013/08/16  Created     ������
 *
 * �@�B    �{���\�෧�n�����G
 * �ҲզW��    ú�ڳB�z�@�~�ˮּҲ�
 * �Ҳ�ID    EPC3_0010_mod
 * ���n����    �ˮֹ�ú���B
 *</pre>
 * @author ���_��
 * @since 2013/11/5
 */
@SuppressWarnings("unchecked")
public class EPC3_0010_mod {

    /**
     * ���B�ˬd
     * @param ACNT_AMT �{�����B
     * @param CHK_AMT �䲼���B
     * @param RMT_AMT �״ڪ��B
     * @param TKD_AMT �R�Ȧ����B
     * @param MAL_AMT �l�O
     * @param PAY_LIST ��ú�M��
     * @throws ModuleException
     */
    public void checkAMT(BigDecimal ACNT_AMT, BigDecimal CHK_AMT, BigDecimal RMT_AMT, BigDecimal TKD_AMT, BigDecimal MAL_AMT,
            List<Map> PAY_LIST) throws ModuleException {
        ErrorInputException eie = null;
        if (PAY_LIST == null || PAY_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_001"));//ú�ڲM�椣�o����
        }
        if (ACNT_AMT == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_002"));//�M����b���B���o���ŭ�
        }
        if (CHK_AMT == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_003"));//�䲼���B���o���ŭ�
        }
        if (RMT_AMT == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_004"));//�״ڪ��B���o���ŭ�
        }
        if (TKD_AMT == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_005"));//�R�Ȧ����B���o���ŭ�
        }
        if (MAL_AMT == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_006"));//�l�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        BigDecimal PAY_SUM_AMT = BigDecimal.ZERO;
        /* BigDecimal PAY_CSH_AMT = BigDecimal.ZERO;//��ú�{�����B
         BigDecimal PAY_RMT_AMT = BigDecimal.ZERO;//��ú�״ڪ��B
         BigDecimal PAY_CHK_AMT = BigDecimal.ZERO;//��ú�䲼���B
         BigDecimal PAY_TKD_AMT = BigDecimal.ZERO;//��ú�R�Ȧ����B*/
        for (Map map : PAY_LIST) {
            //�v���B�z��ú�M��PAY_LIST
            PAY_SUM_AMT = PAY_SUM_AMT.add(getDecimal(map.get("PAY_AMT")));
            /*
            if ("1".equals(MapUtils.getString(map, "PAY_TYPE"))) {

                PAY_CSH_AMT = PAY_CSH_AMT.add(getDecimal(map.get("PAY_AMT")));

            } else if ("4".equals(MapUtils.getString(map, "PAY_TYPE"))) {

                PAY_RMT_AMT = PAY_RMT_AMT.add(getDecimal(map.get("PAY_AMT")));

            } else if ("5".equals(MapUtils.getString(map, "PAY_TYPE"))) {

                PAY_CHK_AMT = PAY_CHK_AMT.add(getDecimal(map.get("PAY_AMT")));

            } else if ("6".equals(MapUtils.getString(map, "PAY_TYPE"))) {

                PAY_TKD_AMT = PAY_TKD_AMT.add(getDecimal(map.get("PAY_AMT")));
            }*/

        }

        //�p����B
        eie = null;
        if (PAY_SUM_AMT.compareTo(ACNT_AMT.add(CHK_AMT).add(RMT_AMT).add(TKD_AMT).add(MAL_AMT)) != 0) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_007"));//���B�X�p���~
        } /*else if (PAY_CSH_AMT.compareTo(ACNT_AMT) != 0) {
                                 eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_008"));//�{�����B�X�p���~
                             } else if (PAY_CSH_AMT.compareTo(RMT_AMT) != 0) {
                                 eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_009"));//�״ڪ��B�X�p���~
                             } else if (PAY_CHK_AMT.compareTo(CHK_AMT) != 0) {
                                 eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_010"));//�䲼���B�X�p���~
                             } else if (PAY_TKD_AMT.compareTo(TKD_AMT) != 0) {
                                 eie = getErrorInputException(eie, MessageUtil.getMessage("EPC3_0010_mod_MSG_011"));//�R�Ȧ����B�X�p���~
                             }*/
        if (eie != null) {
            throw eie;
        }
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

    /**
     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getDecimal(Object obj) {

        if (BigDecimal.class.isInstance(obj)) {
            return (BigDecimal) obj;
        }

        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return BigDecimal.ZERO;
    }

}
