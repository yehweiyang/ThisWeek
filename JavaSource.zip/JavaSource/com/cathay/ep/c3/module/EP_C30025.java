package com.cathay.ep.c3.module;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE        Description Author
 * 2013/011/11 Created     ������
 *
 * �@�B    �{���\�෧�n�����G
 * �ҲզW��    �Ȧ��J�b��J���@�Ҳ�
 * �Ҳ�ID    EP_C30025
 * ���n����    ���oDBDK.DVDKG002_FOR_EP���ʲ����������Ӹ�Ƨ@�~
 *</pre>
 *
 * [20180227] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * 
 * @author ���_��
 * @since 2013/11/27
 */
@SuppressWarnings("unchecked")
public class EP_C30025 {

    private static final String SQL_queryTmpInfoList_001 = "com.cathay.ep.c3.module.EP_C30025.SQL_queryTmpInfoList_001";

    private static final String SQL_queryTmpInfoList_002 = "com.cathay.ep.c3.module.EP_C30025.SQL_queryTmpInfoList_002";

    /**
     * ���o�Ȧ��J�b���ӲM��
     * @param PAY_NO ú�O�s��
     * @param SUB_CPY_ID �����q�O
     * @return �Ȧ��J�b���ӲM��
     * @throws ModuleException
     */
    public List<Map> queryTmpInfoList(String PAY_NO, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30025_MSG_001"));//ú�O�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);

        List<Map> TMP_INFO_LIST;
        try {
            /* [20180227] �[�P�_��  */
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                TMP_INFO_LIST = VOTool.findToMaps(ds, SQL_queryTmpInfoList_001, false);
            } else {
                /* [20180227]�D��ا�gEP.�Ȧ���  */
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                TMP_INFO_LIST = VOTool.findToMaps(ds, SQL_queryTmpInfoList_002, false);
            }
        } catch (ModuleException me) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30024_MSG_002"), me);//���o�Ȧ��J�b���ӲM��o�Ϳ��~ 
        }

        //�榡��TMP_INFO_LIST�A��TMP_MAP�զ�
        if (TMP_INFO_LIST != null) {
            for (Map TMP_MAP : TMP_INFO_LIST) {
                String POLICY_NO = MapUtils.getString(TMP_MAP, "POLICY_NO");
                if ("I".equals(POLICY_NO.substring(0, 1))) {
                    //�Ȧ��ϧOTMP_TYPE
                    TMP_MAP.put("TMP_TYPE", FieldOptionList.getName("EPC3", "TMP_TYPE", "2"));
                    //���Ǭ�OTMP_DIV_NO
                    TMP_MAP.put("TMP_DIV_NO", FieldOptionList.getName("EPC3", "TMP_TYPE", POLICY_NO.substring(1, 8)));//���N��
                } else {
                    TMP_MAP.put("TMP_TYPE", FieldOptionList.getName("EPC3", "TMP_TYPE", "1"));
                    TMP_MAP.put("TMP_DIV_NO", "");
                }

                //�Ȧ��ӷ��W��TMP_IN_NM
                TMP_MAP.put("TMP_IN_NM", FieldOptionList.getName("EPC3", "TMP_IN_CD", MapUtils.getString(TMP_MAP, "TMP_IN_CD")));
            }
        }

        return TMP_INFO_LIST;

    }

    /**
     * �榡�ƼȦ��J�b���Ӹ�T
     * @param TMP_MAP �Ȧ��J�b����
     * @return �Ȧ��J�b���Ӹ�T
     * @throws ErrorInputException
     */
    public Map formatTmpInfo(Map TMP_MAP) throws ErrorInputException {
        if (TMP_MAP == null || TMP_MAP.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30025_MSG_001"));//ú�O�s�����o����
        }

        Map TMP_INFO_MAP = new HashMap();
        TMP_INFO_MAP.putAll(TMP_MAP);

        //�Ȧ��ϧOTMP_TYPE
        TMP_INFO_MAP.put("TMP_TYPE", FieldOptionList.getName("EPC3", "TMP_TYPE", MapUtils.getString(TMP_INFO_MAP, "TMP_TYPE")));
        //���Ǭ�OTMP_DIV_NO
        TMP_INFO_MAP.put("TMP_DIV_NO", FieldOptionList.getName("EPC3", "TMP_DIV_NO", MapUtils.getString(TMP_INFO_MAP, "TMP_DIV_NO")));
        //�Ȧ��ӷ��W��TMP_IN_NM
        TMP_INFO_MAP.put("TMP_IN_NM", FieldOptionList.getName("EPC3", "TMP_IN_CD", MapUtils.getString(TMP_INFO_MAP, "TMP_IN_CD")));

        return TMP_INFO_MAP;
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }
}
