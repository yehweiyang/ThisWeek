package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.Id;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dj.a0.bo.DJ_A0Z016_vo;
import com.cathay.dj.a0.module.DJ_A0Z016;
import com.cathay.dj.b0.module.DJ_B0Z010;
import com.cathay.dj.bo.DTDJB006;
import com.cathay.dj.c0.module.DJ_C0Z012;
import com.cathay.dj.c0.module.DJ_C0Z032;
import com.cathay.dk.a0.bo.DK_AAZ011_bo;
import com.cathay.dk.a0.module.DK_A0Z003;
import com.cathay.dk.bo.DTDKF001;
import com.cathay.dk.bo.DTDKG002;
import com.cathay.dk.bo.DTDKG003;
import com.cathay.dk.f0.module.DK_F0Z011;
import com.cathay.dk.f0.module.DK_F0Z017;
import com.cathay.dk.g0.module.DK_G0Z002;
import com.cathay.dk.g0.module.DK_G0Z007;
import com.cathay.dk.g0.module.DK_G0Z011;
import com.cathay.ep.vo.DTEPC309;
import com.cathay.ep.vo.DTEPC310;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C309;
import com.cathay.ep.z0.module.EP_Z0C310;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE     Description     Author
 * 2013/11/11   Created     ���i��
 * PS�G���������|���ݷ|�p�Ҳն}�o�A�ݶ}�o��������|�ɻ�SPEC�C    
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �h�O�P�������b�ȽT�{���@�Ҳ�
 * �Ҳ�ID    EP_C30090
 * ���n����    �h�O�P�������b�ȽT�{�@�Ҳ�
 * 
 *  [20180207]�ק��
 *  ��ؾɤJ:�Ϥ�call DK�Ҳ�
 *  �g�����Ǹ�/�ǲ��ո���I�sEP_Z0Z001
 *  
 *  [20180301]�ק��
 *  �D���
 * </pre>
 * @author ����[
 * @since 2013-12-27
 */
@SuppressWarnings("unchecked")
public class EP_C30090 {

    private static final Logger log = Logger.getLogger(EP_C30090.class);

    private static final String SQL_query1_001 = "com.cathay.ep.c3.module.EP_C30090.SQL_query1_001";

    private static final String SQL_query1_002 = "com.cathay.ep.c3.module.EP_C30090.SQL_query1_002";

    private static final String SQL_query2_001 = "com.cathay.ep.c3.module.EP_C30090.SQL_query2_001";

    private static final String SQL_query2_002 = "com.cathay.ep.c3.module.EP_C30090.SQL_query2_002";

    private static final String SQL_confirm2_001 = "com.cathay.ep.c3.module.EP_C30090.SQL_confirm2_001";

    private static final String SQL_cancel2_001 = "com.cathay.ep.c3.module.EP_C30090.SQL_cancel2_001";

    /**
     * �d�߱b�ȳB�z���
     * @param reqMap    �e���d�����
     * @return
     * @throws ModuleException
     */
    public List<Map> query(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;
        String QUERY_KIND = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
            if (StringUtils.isBlank(QUERY_KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_002"));//�d�߶��ج��������
            }
        }
        if (eie != null) {
            throw eie;
        }

        //�̷Ӥ��P�d�߶��ءA�I�s���P��k
        if ("1".equals(QUERY_KIND)) {//�Ȧ��h�O
            return query1(reqMap);
        }

        if ("2".equals(QUERY_KIND) || "3".equals(QUERY_KIND) || "4".equals(QUERY_KIND)) {//ú�O��X�J�Ȧ��Bú�O��X�h�O�Bú�O��X�~�b�J�Ȧ�
            return query2(reqMap);
        }
        return null;
    }

    /**
     * �d�߼Ȧ��h�O���
     * @param reqMap    �e���d�����
     * @return
     * @throws ModuleException
     */
    public List<Map> query1(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;
        String QUERY_TYPE = null;
        String QUERY_KIND = null;
        String SLIP_DATE = null;
        String SLIP_SET_NO = null;
        String SUB_CPY_ID = null;
        String USER_ID = MapUtils.getString(reqMap, "USER_ID");
        String USER_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            QUERY_TYPE = MapUtils.getString(reqMap, "QUERY_TYPE");
            QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
            SLIP_DATE = MapUtils.getString(reqMap, "SLIP_DATE");
            SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(QUERY_TYPE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_002"));//�d�ߺ������������
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");

        DataSet ds = Transaction.getDataSet();
        if ("N".equals(QUERY_TYPE)) {//�d�ߥ��T�{���
            ds.setField("COND1", "1");
            ds.setField("USER_ID", USER_ID);
            ds.setField("DACNT_DATE", SLIP_DATE);
        } else if ("Y".equals(QUERY_TYPE)) {//�d�ߤw�T�{���
            ds.setField("COND2", "1");
            ds.setField("DSLIP_DATE", SLIP_DATE);
            ds.setField("DACNT_DIV_NO", USER_DIV_NO);
            ds.setField("DSLIP_LOT_NO", getSLIP_LOT_NO(QUERY_KIND, ACNT_TYPE));
            if (StringUtils.isNotBlank(SLIP_SET_NO)) {
                ds.setField("DSLIP_SET_NO", SLIP_SET_NO);
            }
        }
        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else {
            ds.setField("ACNT_TYPE2", "2");
        }
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
        //��ؤ~�|�X�b
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {
            DBUtil.searchAndRetrieve(ds, SQL_query1_001);
        } else {
            //[20180301]�D��ا�gEP.�Ȧ���
            DBUtil.searchAndRetrieve(ds, SQL_query1_002);

        }
        List<Map> rtnList = new ArrayList();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            rtnMap.put("RTN_KIND_NM", FieldOptionList.getName("EPC3", "RTN_KIND", MapUtils.getString(rtnMap, "RTN_KIND")));
            rtnList.add(rtnMap);
        }

        return rtnList;

    }

    /**
     * �d��ú�O��X�J�Ȧ����
     * @param reqMap    �e���d�����
     * @return
     * @throws ModuleException
     */
    public List<Map> query2(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;
        String QUERY_TYPE = null;
        String QUERY_KIND = null;
        String SLIP_DATE = null;
        String SLIP_SET_NO = null;
        String SUB_CPY_ID = null;
        String USER_ID = MapUtils.getString(reqMap, "USER_ID");
        String USER_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            QUERY_TYPE = MapUtils.getString(reqMap, "QUERY_TYPE");
            QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
            SLIP_DATE = MapUtils.getString(reqMap, "SLIP_DATE");
            SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(QUERY_TYPE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_002"));//�d�ߺ������������
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();

        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if ("N".equals(QUERY_TYPE)) {//�d�ߥ��T�{���
            ds.setField("COND1", "1");
            ds.setField("SWP_DATE", SLIP_DATE);
            ds.setField("INPUT_ID", USER_ID);
        } else if ("Y".equals(QUERY_TYPE)) {//�d�ߤw�T�{���
            ds.setField("COND2", "1");
            ds.setField("S_ACNT_DATE", SLIP_DATE);
            ds.setField("S_DIV_NO", USER_DIV_NO);
            ds.setField("S_SLPLOT_NO", getSLIP_LOT_NO(QUERY_KIND, ACNT_TYPE));
            if (StringUtils.isNotBlank(SLIP_SET_NO)) {
                ds.setField("S_SLPSET_NO", SLIP_SET_NO);
            }
        }
        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else {
            ds.setField("ACNT_TYPE2", "2");
        }
        List<Map> rtnList = new ArrayList();
        /* [20180301]�[�P�_��  */
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            DBUtil.searchAndRetrieve(ds, SQL_query2_001);
        } else {
            /* [20180301]�D��ا�gEP.�Ȧ���  */
            DBUtil.searchAndRetrieve(ds, SQL_query2_002);
        }
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            rtnMap.put("SWP_KIND_NM", FieldOptionList.getName("EP", "SWP_KIND2", MapUtils.getString(rtnMap, "SWP_KIND")));
            String PAY_TYPE_C301 = MapUtils.getString(rtnMap, "PAY_TYPE_C301");
            String PAY_TYPE_C304 = MapUtils.getString(rtnMap, "PAY_TYPE");
            if (StringUtils.isNotBlank(PAY_TYPE_C301)) {
                rtnMap.put("PAY_TYPE_C301_NM", FieldOptionList.getName("EP", "PAY_TYPE", PAY_TYPE_C301));
            }
            if (StringUtils.isNotBlank(PAY_TYPE_C304)) {
                rtnMap.put("PAY_TYPE_NM", FieldOptionList.getName("EP", "PAY_TYPE_C204", PAY_TYPE_C304));
            }
            rtnMap.put("CHK_CD_NM", FieldOptionList.getName("EP", "CHK_CD", MapUtils.getString(rtnMap, "CHK_CD")));
            rtnList.add(rtnMap);
        }

        return rtnList;

    }

    /**
     * �b�ȽT�{�@�~
     * @param reqMap    �e���d�����
     * @param reqList   �e���Ŀ���
     * @throws Exception
     */
    public Map<String, String> confirm(Map reqMap, List<Map> reqList, UserObject user) throws Exception {

        ErrorInputException eie = null;
        String QUERY_KIND = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
            if (StringUtils.isBlank(QUERY_KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_002"));//�d�߶��ج��������
            }
        }
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        Map<String, String> rtnMap = new HashMap<String, String>();
        //�̷Ӥ��P�d�߶��ءA�I�s���P��k
        if ("1".equals(QUERY_KIND)) {//�Ȧ��h�O
            rtnMap = confirm1(reqMap, reqList);
        } else if ("2".equals(QUERY_KIND)) {//ú�O��X
            rtnMap = confirm2(reqMap, reqList, user);
        }
        return rtnMap;
    }

    /**
     * ����Ȧ��h�O�b�ȽT�{�@�~
     * @param reqMap    �e���d�����
     * @param reqList   �e���Ŀ諸���
     * @throws Exception
     */
    public Map<String, String> confirm1(Map reqMap, List<Map> reqList) throws Exception {

        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        //�]�w�b�Ȥ��
        String ACNT_DATE = MapUtils.getString(reqMap, "SLIP_DATE");
        //�]�w�ǲ��帹
        String SLIP_LOT_NO = getSLIP_LOT_NO(QUERY_KIND, ACNT_TYPE);
        //���o�g�����Ǹ�
        ReturnMessage rm = new ReturnMessage();
        String user_id = MapUtils.getString(reqMap, "USER_ID");
        String user_div_no = MapUtils.getString(reqMap, "USER_DIV_NO");
        String user_name = MapUtils.getString(reqMap, "USER_NAME");
        //[20180207]�g�����Ǹ���I�sEP_Z0Z001
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        String TRN_SER_NO = theEP_Z0Z001.getTRN_SER_NO(SUB_CPY_ID, user_id, ACNT_DATE, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_003", new Object[] { rm.getMsgDesc() }));//���o�g�����Ǹ�����,+ rm.getMsgDesc()
        }
        //���o�ǲ��ո�
        //[20180207]�ǲ��ո���I�sEP_Z0Z001
        String SLIP_SET_NO = theEP_Z0Z001.getSLIP_SET_NO(SUB_CPY_ID, "2", user_div_no, null, SLIP_LOT_NO, ACNT_DATE, rm);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_004", new Object[] { rm.getMsgDesc() }));//���o�ǲ��ո�����,+ rm.getMsgDesc()
        }

        Map<String, String> rtnMap = new HashMap<String, String>();
        rtnMap.put("ACNT_DATE", ACNT_DATE);
        rtnMap.put("SLIP_SET_NO", SLIP_SET_NO);

        Map<MultiKey, BigDecimal> RMT_AMT_MAP = new HashMap<MultiKey, BigDecimal>(); //�Ȧ��h�O�覡���״ڤ����B�X�p�]by�ץX��w�^
        Map<MultiKey, BigDecimal> BAL_AMT_MAP = new HashMap<MultiKey, BigDecimal>();
        Map<MultiKey, BigDecimal> BAL_CNT_MAP = new HashMap<MultiKey, BigDecimal>();
        BigDecimal TOTAL_AMT2 = BigDecimal.ZERO; //�Ȧ��h�O�覡���{�������B�X�p
        BigDecimal TOTAL_AMT3 = BigDecimal.ZERO; //�Ȧ��h�O�覡���䲼�����B�X�p
        Map<MultiKey, BigDecimal> RMT_CNT_MAP = new HashMap<MultiKey, BigDecimal>(); //�Ȧ��h�O�覡���״ڤ���ƦX�p�]by�ץX��w�^
        BigDecimal TOTAL_CNT2 = BigDecimal.ZERO; //�Ȧ��h�O�覡���{������ƦX�p
        BigDecimal TOTAL_CNT3 = BigDecimal.ZERO; //�Ȧ��h�O�覡���䲼����ƦX�p
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        StringBuilder sb = new StringBuilder();
        DK_G0Z011 theDK_G0Z011 = new DK_G0Z011();
        EP_Z0C310 theEP_Z0C310 = new EP_Z0C310();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        boolean isAccountSubCpy = theEP_Z00030.isAccountSubCpy(SUB_CPY_ID);
        log.fatal("reqList:" + reqList);
        for (Map tempMap : reqList) {
            tempMap.put("SUB_CPY_ID", SUB_CPY_ID);
            String bldCD = MapUtils.getString(tempMap, "APLY_NO", "");
            tempMap.put("BLD_CD", bldCD);//�Ȧ��j�ӥN�� ��b APLY_NO
            String balType = theEP_Z0G103.getBAL_TYPE(SUB_CPY_ID, bldCD);
            tempMap.put("BAL_TYPE", balType);

            String RTN_KIND = MapUtils.getString(tempMap, "RTN_KIND");
            if ("1".equals(RTN_KIND)) {//�Ȧ��h�O�覡���״�
                DJ_A0Z016_vo DJ_A0Z016_vo = DJ_A0Z016.getRmtBankInfoByAcptBankNo(MapUtils.getString(tempMap, "ACPT_BANK_NO"), "NTD", true);
                sb.setLength(0);
                String rmtkey = sb.append(DJ_A0Z016_vo.getRMT_BANK_NO()).append("-").append(DJ_A0Z016_vo.getRMT_ACNT_NO()).toString();
                MultiKey mkey = new MultiKey(rmtkey, balType);
                RMT_AMT_MAP.put(mkey, getBigDecimal(RMT_AMT_MAP.get(mkey), BigDecimal.ZERO).add(
                    getBigDecimal(tempMap.get("DACNT_AMT"), BigDecimal.ZERO)));
                RMT_CNT_MAP.put(mkey, getBigDecimal(RMT_CNT_MAP.get(mkey), BigDecimal.ZERO).add(BigDecimal.ONE));
            } else if ("2".equals(RTN_KIND)) { //�Ȧ��h�O�覡���{��
                MultiKey mkey = new MultiKey("2", balType);
                BAL_AMT_MAP.put(mkey, getBigDecimal(BAL_AMT_MAP.get(mkey), BigDecimal.ZERO).add(
                    getBigDecimal(tempMap.get("DACNT_AMT"), BigDecimal.ZERO)));
                BAL_CNT_MAP.put(mkey, getBigDecimal(BAL_CNT_MAP.get(mkey), BigDecimal.ZERO).add(BigDecimal.ONE));
                TOTAL_AMT2 = TOTAL_AMT2.add(getBigDecimal(tempMap.get("DACNT_AMT"), BigDecimal.ZERO));
                TOTAL_CNT2 = TOTAL_CNT2.add(BigDecimal.ONE);
            } else if ("3".equals(RTN_KIND)) { //�Ȧ��h�O�覡���䲼
                MultiKey mkey = new MultiKey("3", balType);
                BAL_AMT_MAP.put(mkey, getBigDecimal(BAL_AMT_MAP.get(mkey), BigDecimal.ZERO).add(
                    getBigDecimal(tempMap.get("DACNT_AMT"), BigDecimal.ZERO)));
                BAL_CNT_MAP.put(mkey, getBigDecimal(BAL_CNT_MAP.get(mkey), BigDecimal.ZERO).add(BigDecimal.ONE));
                TOTAL_AMT3 = TOTAL_AMT3.add(getBigDecimal(tempMap.get("DACNT_AMT"), BigDecimal.ZERO));
                TOTAL_CNT3 = TOTAL_CNT3.add(BigDecimal.ONE);
            }

            //��sDTDKG003�b�ȸ��
            DTDKG003 DTDKG003_VO = new DTDKG003();
            DTDKG003_VO.setTMP_NO(MapUtils.getString(tempMap, "TMP_NO"));
            DTDKG003_VO.setDTMP_NO(MapUtils.getString(tempMap, "DTMP_NO"));
            DTDKG003_VO.setDACNT_DATE(ACNT_DATE);
            DTDKG003_VO.setDACNT_SER_NO(TRN_SER_NO);
            DTDKG003_VO.setSLIP_DATE(ACNT_DATE);
            DTDKG003_VO.setSLIP_LOT_NO(SLIP_LOT_NO);
            DTDKG003_VO.setSLIP_SET_NO(SLIP_SET_NO);
            DTDKG003_VO.setDACNT_ID(user_id);
            DTDKG003_VO.setDACNT_NAME(user_name);
            DTDKG003_VO.setDACNT_IN_DATE(DATE.getDBTimeStamp());
            DTDKG003_VO.setDACNT_DIV_NO(user_div_no);
            DTDKG003_VO.setTRN_KIND("EPC390");
            DTDKG003_VO.setDACNT_AMT(MapUtils.getString(tempMap, "DACNT_AMT"));
            //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�           
            if (isAccountSubCpy) { //��ؤ~�|�X�b
                //theDK_G0Z011.updateG003ForXA(DTDKG003_VO, rm);
                theDK_G0Z011.insertDTDKF001fromG003ForXA(DTDKG003_VO, rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException("��sDTDKG003�b�ȸ�Ƶo�Ϳ��~�G" + rm.getMsgDesc());
                }
            } else {
                //[20180301]:�D��ا�gEP.�Ȧ���
                DTEPC310 C310 = new DTEPC310();
                VOTool.copyVOFromTo(DTDKG003_VO, C310);
                C310.setSUB_CPY_ID(SUB_CPY_ID);
                theEP_Z0C310.updateC310ForACNT(C310);
                //��s�R�Ȧ��ɱb�ȸ��(DTDKG003)
                /*DK_G0Z011 theDK_G0Z011 = new DK_G0Z011();
                for (Map map : reqList) {
                    DTDKG003 DTDKG003_VO = new DTDKG003();
                    DTDKG003_VO.setTMP_NO(MapUtils.getString(map, "TMP_NO"));
                    DTDKG003_VO.setDTMP_NO(MapUtils.getString(map, "DTMP_NO"));
                    DTDKG003_VO.setSLIP_DATE(MapUtils.getString(map, "SLIP_DATE"));
                    DTDKG003_VO.setSLIP_LOT_NO(MapUtils.getString(map, "SLIP_LOT_NO"));
                    DTDKG003_VO.setSLIP_SET_NO(MapUtils.getString(map, "SLIP_SET_NO"));
                    theDK_G0Z011.updateG003ForXA(DTDKG003_VO, rm);
                    if (rm.getReturnCode() != ReturnCode.OK) {
                        throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_010", new Object[] { rm.getMsgDesc() })); //��sDTDKG003�b�ȸ�Ƶo�Ϳ��~�G{0}
                    }

                }*/
            }//end if ��ؤ~�X�b
        }//end for
        if (isAccountSubCpy) { //��ؤ~�|�X�b
            //      String BAL_TYPE = theEP_Z0G103.getBalTypeByList(reqList);
            //�Y#RMT_AMT_MAP.keyset.size()>0�A�h�v���B�z#RMT_AMT_MAP.keyset�A�զ��״ڥX�b�Ҳ�BO�A
            List<DK_AAZ011_bo> DK_AAZ011_BO_LIST = new ArrayList<DK_AAZ011_bo>();
            Set<MultiKey> keyset = RMT_AMT_MAP.keySet();
            String current_time = DATE.getDBTimeStamp();
            if (keyset.size() > 0) {
                log.debug("RMT_AMT_MAP.keyset:" + keyset);
                for (MultiKey mkey : keyset) {
                    String rmtAcntkey = (String) mkey.getKey(0);
                    String balType = (String) mkey.getKey(1);
                    DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
                    DK_AAZ011_BO.setINPUT_ID(user_id);
                    DK_AAZ011_BO.setINPUT_NAME(user_name);
                    DK_AAZ011_BO.setTRN_DATE(current_time);
                    DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
                    DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
                    DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
                    DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
                    DK_AAZ011_BO.setTRN_KIND("EPC390");
                    DK_AAZ011_BO.setMEMO("");
                    DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
                    DK_AAZ011_BO.setKIND_CODE(null);
                    DK_AAZ011_BO.setBUS_CODE("EP");
                    DK_AAZ011_BO.setBUS_TRAN_CODE("1");
                    DK_AAZ011_BO.setCURR("NTD");
                    DK_AAZ011_BO.setCNT(MapUtils.getString(RMT_CNT_MAP, mkey));
                    DK_AAZ011_BO.setITEM("8");
                    DK_AAZ011_BO.setTYPE("3");
                    DK_AAZ011_BO.setBANK_NO(rmtAcntkey.split("-")[0]);
                    DK_AAZ011_BO.setACNT_NO(rmtAcntkey.split("-")[1]);
                    DK_AAZ011_BO.setAMT(MapUtils.getString(RMT_AMT_MAP, mkey));
                    DK_AAZ011_BO.setACNT_TYPE(ACNT_TYPE);
                    DK_AAZ011_BO.setBAL_TYPE(balType);

                    DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);
                }
            }
            Set<MultiKey> balkeyset = BAL_AMT_MAP.keySet();
            log.debug("BAL_AMT_MAP.keyset:" + keyset);
            if (balkeyset.size() > 0) {
                for (MultiKey mkey : balkeyset) {
                    String type = (String) mkey.getKey(0);
                    String balType = (String) mkey.getKey(1);
                    // "2" �Ȧ��h�O�覡���{��
                    if ("2".equals(type)) {
                        DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
                        DK_AAZ011_BO.setINPUT_ID(user_id);
                        DK_AAZ011_BO.setINPUT_NAME(user_name);
                        DK_AAZ011_BO.setTRN_DATE(current_time);
                        DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
                        DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
                        DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
                        DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
                        DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
                        DK_AAZ011_BO.setTRN_KIND("EPC390");
                        DK_AAZ011_BO.setMEMO("");
                        DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
                        DK_AAZ011_BO.setKIND_CODE(null);
                        DK_AAZ011_BO.setBUS_CODE("EP");
                        DK_AAZ011_BO.setBUS_TRAN_CODE("1");
                        DK_AAZ011_BO.setCURR("NTD");
                        DK_AAZ011_BO.setCNT(MapUtils.getString(BAL_CNT_MAP, mkey));
                        DK_AAZ011_BO.setITEM("8");
                        DK_AAZ011_BO.setTYPE("2");
                        DK_AAZ011_BO.setBANK_NO("");
                        DK_AAZ011_BO.setACNT_NO("");
                        DK_AAZ011_BO.setAMT(MapUtils.getString(BAL_AMT_MAP, mkey));
                        DK_AAZ011_BO.setACNT_TYPE(ACNT_TYPE);
                        DK_AAZ011_BO.setBAL_TYPE(balType);

                        DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);

                    } else if ("3".endsWith(type)) {
                        //�Ȧ��h�O�覡���䲼
                        //���o��s�b��
                        Map ACNT_MAP = new DJ_C0Z032().getChkAcntInfo(user_div_no, rm);

                        DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
                        DK_AAZ011_BO.setINPUT_ID(user_id);
                        DK_AAZ011_BO.setINPUT_NAME(user_name);
                        DK_AAZ011_BO.setTRN_DATE(current_time);
                        DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
                        DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
                        DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
                        DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
                        DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
                        DK_AAZ011_BO.setTRN_KIND("EPC390");
                        DK_AAZ011_BO.setMEMO("");
                        DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
                        DK_AAZ011_BO.setKIND_CODE(null);
                        DK_AAZ011_BO.setBUS_CODE("EP");
                        DK_AAZ011_BO.setBUS_TRAN_CODE("1");
                        DK_AAZ011_BO.setCURR("NTD");
                        DK_AAZ011_BO.setCNT(MapUtils.getString(BAL_CNT_MAP, mkey));
                        DK_AAZ011_BO.setITEM("8");
                        DK_AAZ011_BO.setTYPE("3");
                        DK_AAZ011_BO.setBANK_NO(MapUtils.getString(ACNT_MAP, "BANK_NO"));
                        DK_AAZ011_BO.setACNT_NO(MapUtils.getString(ACNT_MAP, "ACNT_NO"));
                        DK_AAZ011_BO.setAMT(MapUtils.getString(BAL_AMT_MAP, mkey));
                        DK_AAZ011_BO.setACNT_TYPE(ACNT_TYPE);
                        DK_AAZ011_BO.setBAL_TYPE(balType);

                        DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);

                    }

                }
            }
            //
            //        //�Y#TOTAL_CNT2>0�A�h�զ��{���X�b�Ҳ�BO�A
            //        if (TOTAL_CNT2.compareTo(BigDecimal.ZERO) > 0) {}
            //        //�Y#TOTAL_CNT3>0�A�h�զ��䲼�X�b�Ҳ�BO�A
            //        if (TOTAL_CNT3.compareTo(BigDecimal.ZERO) > 0) {}

            //�I�s�X�b�Ҳ�
            log.debug("DK_AAZ011_BO_LIST:" + DK_AAZ011_BO_LIST);
            new DK_A0Z003().doInsert(DK_AAZ011_BO_LIST, rm);

            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_005", new Object[] { rm.getMsgDesc() }));//�I�s�X�b�Ҳե���,+ rm.getMsgDesc()
            }

            //�ˮֱb�ȬO�_����
            new DK_F0Z011().isBalance2(user_div_no, user_id, ACNT_DATE, SLIP_LOT_NO, SLIP_SET_NO, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_006") + rm.getMsgDesc());//�ˮֱb�ȬO�_���ŵo�Ϳ��~
            }

            //�YreqList[i].RTN_KIND=��1�� OR ��3���A�զ��ݵ��I��BO�A�üg�J�ݵ��I��(DTDJB006)
            String today = DATE.getDBDate();
            DJ_B0Z010 theDJ_B0Z010 = new DJ_B0Z010();

            DTDJB006 DTDJB006_bo = new DTDJB006();
            for (Map tempMap : reqList) {
                String BAL_TYPE = MapUtils.getString(tempMap, "BAL_TYPE");
                String RTN_KIND = MapUtils.getString(tempMap, "RTN_KIND");
                if ("1".equals(RTN_KIND) || "2".equals(RTN_KIND) || "3".equals(RTN_KIND)) {
                    String RMT_BANK_NO;
                    String RMT_ACNT_NO;
                    if ("1".equals(RTN_KIND)) {
                        DJ_A0Z016_vo DJ_A0Z016_vo = DJ_A0Z016.getRmtBankInfoByAcptBankNo(MapUtils.getString(tempMap, "ACPT_BANK_NO"),
                            "NTD", true);
                        RMT_BANK_NO = DJ_A0Z016_vo.getRMT_BANK_NO();
                        RMT_ACNT_NO = DJ_A0Z016_vo.getRMT_ACNT_NO();
                    } else {
                        RMT_BANK_NO = "";
                        RMT_ACNT_NO = "";
                    }
                    DTDJB006_bo.setCASE_NO(null);
                    DTDJB006_bo.setPAY_TYPE(RTN_KIND);
                    DTDJB006_bo.setCHK_KIND("1");
                    DTDJB006_bo.setPAY_DIV_NO(user_div_no);
                    DTDJB006_bo.setPAY_DATE(ACNT_DATE);
                    DTDJB006_bo.setPAY_KIND("01");
                    DTDJB006_bo.setAPLY_NO("");
                    DTDJB006_bo.setPOLICY_NO(MapUtils.getString(tempMap, "POLICY_NO"));
                    DTDJB006_bo.setSYS_NO("P");
                    DTDJB006_bo.setPAY_AMT(MapUtils.getString(tempMap, "DACNT_AMT"));
                    DTDJB006_bo.setNET_PAY_AMT(MapUtils.getString(tempMap, "DACNT_AMT"));
                    DTDJB006_bo.setTAX_AMT("0");
                    DTDJB006_bo.setCLC_NO("");
                    DTDJB006_bo.setAGNT_ID("");
                    DTDJB006_bo.setAGNT_NAME("");
                    DTDJB006_bo.setACPT_DIV_NO(user_div_no);
                    DTDJB006_bo.setRMT_BANK_NO(RMT_BANK_NO);
                    DTDJB006_bo.setRMT_ACNT_NO(RMT_ACNT_NO);
                    DTDJB006_bo.setACPT_BANK_NO(MapUtils.getString(tempMap, "ACPT_BANK_NO"));
                    DTDJB006_bo.setACPT_ACNT_NO(MapUtils.getString(tempMap, "ACPT_ACNT_NO"));
                    DTDJB006_bo.setACPT_ACNT_NAME(MapUtils.getString(tempMap, "ACPT_ACNT_NAME"));

                    boolean isExtChar = DJ_C0Z012.isExtChar(MapUtils.getString(tempMap, "ACPT_ACNT_NAME"));
                    if (isExtChar) {
                        DTDJB006_bo.setACPT_ACNT_NPRT("A");
                        DTDJB006_bo.setACPT_NPRT("A");
                    } else {
                        DTDJB006_bo.setACPT_ACNT_NPRT("");
                        DTDJB006_bo.setACPT_NPRT("");
                    }

                    DTDJB006_bo.setACPT_NAME(MapUtils.getString(tempMap, "ACPT_ACNT_NAME"));
                    DTDJB006_bo.setACPT_KIND(MapUtils.getString(tempMap, "ACPT_KIND"));
                    DTDJB006_bo.setID_KIND(MapUtils.getString(tempMap, "ACPT_ID_KIND"));
                    DTDJB006_bo.setID(MapUtils.getString(tempMap, "ACPT_ID"));
                    DTDJB006_bo.setMEMO("");
                    DTDJB006_bo.setAPLY_DIV_NO(user_div_no);
                    DTDJB006_bo.setINPUT_DATE(current_time);
                    DTDJB006_bo.setINPUT_ID(user_id);
                    DTDJB006_bo.setINPUT_NAME(user_name);
                    DTDJB006_bo.setUSER_TRN_SERNO(TRN_SER_NO);
                    DTDJB006_bo.setEXTR_DATE(today);
                    DTDJB006_bo.setYEAR(DATE.getROCYear(ACNT_DATE));
                    DTDJB006_bo.setFILE_NO("000000");
                    DTDJB006_bo.setSER_NO("0");
                    DTDJB006_bo.setACPT_SER_NO("0");
                    DTDJB006_bo.setSLIP_DATE(ACNT_DATE);
                    DTDJB006_bo.setSLIP_DIV_NO("");
                    DTDJB006_bo.setSLIP_SEQ_NO("0");
                    DTDJB006_bo.setCFM_DATE(null);
                    DTDJB006_bo.setCFM_DIV_NO("");
                    DTDJB006_bo.setCFM_ID("");
                    DTDJB006_bo.setCFM_NAME("");
                    DTDJB006_bo.setDLT_CODE("");
                    DTDJB006_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DTDJB006_bo.setSLIP_SET_NO(SLIP_SET_NO);
                    DTDJB006_bo.setPRE_KEY(MapUtils.getString(tempMap, "DTMP_NO"));
                    DTDJB006_bo.setCURR("NTD");
                    DTDJB006_bo.setSWIFT_CODE("");
                    DTDJB006_bo.setCHECK_CODE("1");
                    DTDJB006_bo.setTRN_KIND("");
                    DTDJB006_bo.setBAL_TYPE(BAL_TYPE);
                    theDJ_B0Z010.insertDTDJB006(DTDJB006_bo);
                }
            }//end for
        }//end if ��ؤ~�X�b
        return rtnMap;
    }

    /**
     * ����ú�O��X�J�Ȧ��b�ȽT�{
     * @param reqMap    �e���d�����
     * @param reqList   �e���Ŀ諸���
     * @throws Exception
     */
    public Map<String, String> confirm2(Map reqMap, List<Map> reqList, UserObject user) throws Exception {

        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        }
        if (eie != null) {
            throw eie;
        }
        String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        //�]�w�b�Ȥ��
        String ACNT_DATE = MapUtils.getString(reqMap, "SLIP_DATE");
        //�]�w�ǲ��帹
        String SLIP_LOT_NO = getSLIP_LOT_NO(QUERY_KIND, ACNT_TYPE);
        reqMap.put("SLIP_LOT_NO", SLIP_LOT_NO);
        //���o�g�����Ǹ�
        ReturnMessage rm = new ReturnMessage();
        String user_id = MapUtils.getString(reqMap, "USER_ID");
        String user_div_no = MapUtils.getString(reqMap, "USER_DIV_NO");
        String user_name = MapUtils.getString(reqMap, "USER_NAME");
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        //[20180207] �g�����Ǹ���I�sEP_Z0Z001
        String TRN_SER_NO = theEP_Z0Z001.getTRN_SER_NO(SUB_CPY_ID, user_id, ACNT_DATE, rm);
        reqMap.put("TRN_SER_NO", TRN_SER_NO);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_003", new Object[] { rm.getMsgDesc() }));//���o�g�����Ǹ�����,+ rm.getMsgDesc()
        }
        //���o�ǲ��ո�
        //[20180207] �ǲ��ո���I�sEP_Z0Z001
        String SLIP_SET_NO = theEP_Z0Z001.getSLIP_SET_NO(SUB_CPY_ID, "2", user_div_no, null, SLIP_LOT_NO, ACNT_DATE, rm);
        reqMap.put("SLIP_SET_NO", SLIP_SET_NO);
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_004", new Object[] { rm.getMsgDesc() }));//���o�ǲ��ո�����,+ rm.getMsgDesc()
        }

        List<Map> dataList1 = new ArrayList<Map>(); //�Ȧ��h�O�Bú�O��X�h�O�������
        List<Map> dataList2 = new ArrayList<Map>(); //ú�O��X�J�Ȧ��Bú�O��X�~�b�J�Ȧ����

        //�v���B�zreqList
        for (Map map : reqList) {
            String SWP_KIND = MapUtils.getString(map, "SWP_KIND");
            if ("0".equals(SWP_KIND) || "2".equals(SWP_KIND)) {
                dataList1.add(map); //��X�J�Ȧ��B��X�~�b�J�Ȧ����
            } else if ("1".equals(SWP_KIND)) {
                dataList2.add(map); //��X�h�O���
            }
        }

        Map<String, String> rtnMap = new HashMap<String, String>();
        rtnMap.put("ACNT_DATE", ACNT_DATE);
        rtnMap.put("SLIP_SET_NO", SLIP_SET_NO);

        //        BigDecimal TOTAL_AMT1 = BigDecimal.ZERO; //��X�J�Ȧ����B�`�M{����(1)�B�H����(4)�B�X�����a(5)�B��L(7)}
        //        BigDecimal TOTAL_CNT1 = BigDecimal.ZERO; //��X�J�Ȧ�����`�M{����(1)�B�H����(4)�B�X�����a(5)�B��L(7)}
        //        BigDecimal TOTAL_AMT2 = BigDecimal.ZERO; //��X�J�Ȧ����B�`�M{�޲z�O(3)}
        //        BigDecimal TOTAL_CNT2 = BigDecimal.ZERO; //��X�J�Ȧ�����`�M{�޲z�O(3)}
        //        BigDecimal TOTAL_AMT3 = BigDecimal.ZERO; //��X�J�Ȧ����B�`�M{���(2)}
        //        BigDecimal TOTAL_CNT3 = BigDecimal.ZERO; //��X�J�Ȧ�����`�M{���(2)}
        Map<MultiKey, BigDecimal> ACNT_AMT_MAP = new HashMap<MultiKey, BigDecimal>();
        Map<MultiKey, BigDecimal> ACNT_CNT_MAP = new HashMap<MultiKey, BigDecimal>();

        DataSet ds = Transaction.getDataSet();
        //20190703���D��s�� 20190703-0092  
        //��ر��v���ʲ��޲z�t�ξɤJ�ɡA�s�Wú�ں���"8�X�����a"�C�b�j�Ӧ����v�@�~(�p��w�P����)�ι�b���Ӫ��ɥ��Nú�ں���"8�X�����a"�����B��i�h�C
        String[] PAY_KIND_array = { "1", "4", "5", "7", "8" };
        String ACNT_TYPE1 = "1"; //�����b��
        String ACNT_TYPE2 = "2"; //�޲z�O�b��
        String ACNT_TYPE3 = "3"; //����b��
        String current_time = DATE.getDBTimeStamp();
        DK_G0Z002 theDK_G0Z002 = new DK_G0Z002();
        EP_C30020 theEP_C30020 = new EP_C30020();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        EP_Z0C309 theEP_Z0C309 = new EP_Z0C309();
        boolean isAccountSubCpy = theEP_Z00030.isAccountSubCpy(SUB_CPY_ID);
        log.debug("confirm2.reqList:" + reqList);
        for (Map tempMap : reqList) {
            String BLD_CD = MapUtils.getString(tempMap, "BLD_CD");
            String BAL_TYPE = new EP_Z0G103().getBAL_TYPE(SUB_CPY_ID, BLD_CD);
            String SWP_KIND = MapUtils.getString(tempMap, "SWP_KIND");
            String DIV_NO_C101 = MapUtils.getString(tempMap, "DIV_NO_C101");
            String PAY_KIND = MapUtils.getString(tempMap, "PAY_KIND");
            BigDecimal SWP_AMT = getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO);
            if (ArrayUtils.contains(PAY_KIND_array, PAY_KIND)) {
                calAcntMap(ACNT_TYPE1, DIV_NO_C101, ACNT_AMT_MAP, ACNT_CNT_MAP, SWP_AMT, BAL_TYPE);
                //                TOTAL_AMT1 = TOTAL_AMT1.add(getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO));
                //                TOTAL_CNT1 = TOTAL_CNT1.add(BigDecimal.ONE);
            } else if ("3".equals(PAY_KIND)) {
                calAcntMap(ACNT_TYPE2, DIV_NO_C101, ACNT_AMT_MAP, ACNT_CNT_MAP, SWP_AMT, BAL_TYPE);
                //              TOTAL_AMT2 = TOTAL_AMT2.add(getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO));
                //              TOTAL_CNT2 = TOTAL_CNT2.add(BigDecimal.ONE);
            } else if ("2".equals(PAY_KIND)) {
                calAcntMap(ACNT_TYPE3, DIV_NO_C101, ACNT_AMT_MAP, ACNT_CNT_MAP, SWP_AMT, BAL_TYPE);
                //                TOTAL_AMT3 = TOTAL_AMT3.add(getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO));
                //                TOTAL_CNT3 = TOTAL_CNT3.add(BigDecimal.ONE);
            }
            log.debug("ACNT_AMT_MAP:" + ACNT_AMT_MAP);

            ds.clear();
            ds.setField("TRN_DATE", current_time);
            ds.setField("TRN_SER_NO", TRN_SER_NO);
            ds.setField("S_ACNT_DATE", ACNT_DATE);
            ds.setField("S_ACNT_ID", user_id);
            ds.setField("S_DIV_NO", user_div_no);
            ds.setField("S_SLPLOT_NO", SLIP_LOT_NO);
            ds.setField("S_SLPSET_NO", SLIP_SET_NO);
            ds.setField("EXT_NO", MapUtils.getString(tempMap, "EXT_NO"));
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_confirm2_001);

            //��sDKG�Ȧ��ɱb�ȸ�T
            //            DTDKG002 G002_VO = new DTDKG002();
            //            G002_VO.setTMP_NO(MapUtils.getString(tempMap, "TMP_NO"));
            //            G002_VO.setSLIP_DATE(ACNT_DATE);
            //            G002_VO.setACNT_DATE(ACNT_DATE);
            //            G002_VO.setSLIP_LOT_NO(SLIP_LOT_NO);
            //            G002_VO.setSLIP_SET_NO(SLIP_SET_NO);
            //            G002_VO.setACNT_SER_NO(TRN_SER_NO);
            //            theDK_G0Z002.updateG002ForXA(G002_VO, rm);

            if ("0".equals(SWP_KIND) || "2".equals(SWP_KIND)) {

                DTDKG002 DTDKG002_Bo = new DTDKG002();
                String TMP_NO = MapUtils.getString(tempMap, "TMP_NO");
                DTDKG002_Bo = new DK_G0Z007().queryByPKForXA(TMP_NO, rm);

                DTDKG002_Bo.setSLIP_DATE(ACNT_DATE);
                DTDKG002_Bo.setACNT_DATE(ACNT_DATE);
                DTDKG002_Bo.setACNT_DIV_NO(user_div_no);
                DTDKG002_Bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                DTDKG002_Bo.setSLIP_SET_NO(SLIP_SET_NO);
                DTDKG002_Bo.setACNT_SER_NO(TRN_SER_NO);
                //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
                ////��ؤ~�|�X�b
                if (isAccountSubCpy) {
                    //�]�w�Ȧ��b�U�O
                    theEP_C30020.setBAL_TYPEforDKG002(DTDKG002_Bo, BAL_TYPE);

                    //��sú�O���p�b�ȸ�T(��sG002�M�s�WF001)
                    theDK_G0Z002.insertDTDKG002ByHandForXA_2(DTDKG002_Bo, rm, user);

                    if (rm.getReturnCode() != ReturnCode.OK) {
                        throw new ModuleException("��sDKG�Ȧ��ɱb�ȸ�T����:" + rm.getMsgDesc());
                    }
                } else {
                    // [20180301]�D��ا�gEP.�Ȧ���
                    DTEPC309 C309 = new DTEPC309();
                    VOTool.copyVOFromTo(DTDKG002_Bo, C309);
                    C309.setSUB_CPY_ID(SUB_CPY_ID);
                    theEP_Z0C309.updateC309ForACNT(C309);
                }
            }
        }
        List<DK_AAZ011_bo> DK_AAZ011_BO_LIST = new ArrayList<DK_AAZ011_bo>();
        //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
        //��ؤ~�|�X�b
        if (isAccountSubCpy) {
            log.debug("ACNT_AMT_MAP:" + ACNT_AMT_MAP);
            for (MultiKey mkey : ACNT_AMT_MAP.keySet()) {
                String acntKey = (String) mkey.getKey(0);
                String balType = (String) mkey.getKey(1);
                String[] key_split = STRING.split(acntKey, "-");
                String div_no_c101 = key_split[0];
                String acnt_type = key_split[1];

                BigDecimal amt = (BigDecimal) ACNT_AMT_MAP.get(mkey);
                BigDecimal cnt = (BigDecimal) ACNT_CNT_MAP.get(mkey);

                DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
                DK_AAZ011_BO.setINPUT_ID(user_id);
                DK_AAZ011_BO.setINPUT_NAME(user_name);
                DK_AAZ011_BO.setTRN_DATE(current_time);
                DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
                DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
                DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
                DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
                DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
                DK_AAZ011_BO.setTRN_KIND("EPC390");
                DK_AAZ011_BO.setMEMO("");
                DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
                DK_AAZ011_BO.setKIND_CODE(null);
                DK_AAZ011_BO.setBUS_CODE("EP");
                DK_AAZ011_BO.setBUS_TRAN_CODE("1");
                DK_AAZ011_BO.setCURR("NTD");
                DK_AAZ011_BO.setCNT(cnt.toPlainString());
                DK_AAZ011_BO.setITEM("9");
                DK_AAZ011_BO.setTYPE(acnt_type);
                DK_AAZ011_BO.setBANK_NO("");
                DK_AAZ011_BO.setACNT_NO("");
                DK_AAZ011_BO.setAMT(amt.toPlainString());
                DK_AAZ011_BO.setDIV_NO_C101(div_no_c101);
                DK_AAZ011_BO.setACNT_TYPE(ACNT_TYPE);
                DK_AAZ011_BO.setBAL_TYPE(balType);

                DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);
            }
            //        if (TOTAL_AMT1.compareTo(BigDecimal.ZERO) != 0) {
            //            DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
            //            DK_AAZ011_BO.setINPUT_ID(user_id);
            //            DK_AAZ011_BO.setINPUT_NAME(user_name);
            //            DK_AAZ011_BO.setTRN_DATE(current_time);
            //            DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
            //            DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
            //            DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
            //            DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
            //            DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
            //            DK_AAZ011_BO.setTRN_KIND("EPC390");
            //            DK_AAZ011_BO.setMEMO("");
            //            DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
            //            DK_AAZ011_BO.setKIND_CODE(null);
            //            DK_AAZ011_BO.setBUS_CODE("EP");
            //            DK_AAZ011_BO.setBUS_TRAN_CODE("1");
            //            DK_AAZ011_BO.setCURR("NTD");
            //            DK_AAZ011_BO.setCNT(TOTAL_CNT1.toPlainString());
            //            DK_AAZ011_BO.setITEM("9");
            //            DK_AAZ011_BO.setTYPE("1");
            //            DK_AAZ011_BO.setBANK_NO("");
            //            DK_AAZ011_BO.setACNT_NO("");
            //            DK_AAZ011_BO.setAMT(TOTAL_AMT1.toPlainString());
            //            DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);
            //        }
            //        if (TOTAL_AMT2.compareTo(BigDecimal.ZERO) != 0) {
            //            DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
            //            DK_AAZ011_BO.setINPUT_ID(user_id);
            //            DK_AAZ011_BO.setINPUT_NAME(user_name);
            //            DK_AAZ011_BO.setTRN_DATE(current_time);
            //            DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
            //            DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
            //            DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
            //            DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
            //            DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
            //            DK_AAZ011_BO.setTRN_KIND("EPC390");
            //            DK_AAZ011_BO.setMEMO("");
            //            DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
            //            DK_AAZ011_BO.setKIND_CODE(null);
            //            DK_AAZ011_BO.setBUS_CODE("EP");
            //            DK_AAZ011_BO.setBUS_TRAN_CODE("1");
            //            DK_AAZ011_BO.setCURR("NTD");
            //            DK_AAZ011_BO.setCNT(TOTAL_CNT2.toPlainString());
            //            DK_AAZ011_BO.setITEM("9");
            //            DK_AAZ011_BO.setTYPE("2");
            //            DK_AAZ011_BO.setBANK_NO("");
            //            DK_AAZ011_BO.setACNT_NO("");
            //            DK_AAZ011_BO.setAMT(TOTAL_AMT2.toPlainString());
            //            DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);
            //        }
            //        if (TOTAL_AMT3.compareTo(BigDecimal.ZERO) != 0) {
            //            DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
            //            DK_AAZ011_BO.setINPUT_ID(user_id);
            //            DK_AAZ011_BO.setINPUT_NAME(user_name);
            //            DK_AAZ011_BO.setTRN_DATE(current_time);
            //            DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
            //            DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
            //            DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
            //            DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
            //            DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
            //            DK_AAZ011_BO.setTRN_KIND("EPC390");
            //            DK_AAZ011_BO.setMEMO("");
            //            DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
            //            DK_AAZ011_BO.setKIND_CODE(null);
            //            DK_AAZ011_BO.setBUS_CODE("EP");
            //            DK_AAZ011_BO.setBUS_TRAN_CODE("1");
            //            DK_AAZ011_BO.setCURR("NTD");
            //            DK_AAZ011_BO.setCNT(TOTAL_CNT3.toPlainString());
            //            DK_AAZ011_BO.setITEM("9");
            //            DK_AAZ011_BO.setTYPE("3");
            //            DK_AAZ011_BO.setBANK_NO("");
            //            DK_AAZ011_BO.setACNT_NO("");
            //            DK_AAZ011_BO.setAMT(TOTAL_AMT3.toPlainString());
            //            DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);
            //        }
            //�զ��Ȧ��X�b�Ҳ�BO
            //        DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
            //        DK_AAZ011_BO.setINPUT_ID(user_id);
            //        DK_AAZ011_BO.setINPUT_NAME(user_name);
            //        DK_AAZ011_BO.setTRN_DATE(current_time);
            //        DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
            //        DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
            //        DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
            //        DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
            //        DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
            //        DK_AAZ011_BO.setTRN_KIND("EPC390");
            //        DK_AAZ011_BO.setMEMO("");
            //        DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
            //        DK_AAZ011_BO.setKIND_CODE(null);
            //        DK_AAZ011_BO.setBUS_CODE("EP");
            //        DK_AAZ011_BO.setBUS_TRAN_CODE("1");
            //        DK_AAZ011_BO.setCURR("NTD");
            //        DK_AAZ011_BO.setCNT(TOTAL_CNT1.add(TOTAL_CNT2).add(TOTAL_CNT3).toPlainString());
            //        DK_AAZ011_BO.setITEM("9");
            //        DK_AAZ011_BO.setTYPE("4");
            //        DK_AAZ011_BO.setBANK_NO("");
            //        DK_AAZ011_BO.setACNT_NO("");
            //        DK_AAZ011_BO.setAMT(TOTAL_AMT1.add(TOTAL_AMT2).add(TOTAL_AMT3).toPlainString());
            //        DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);

        }

        if (dataList2.size() > 0) {
            confirm3(reqMap, dataList2, DK_AAZ011_BO_LIST);
        }

        //��ؤ~�|�X�b
        if (isAccountSubCpy) {
            //�I�s�X�b�Ҳ�
            new DK_A0Z003().doInsert(DK_AAZ011_BO_LIST, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_005", new Object[] { rm.getMsgDesc() }));//�I�s�X�b�Ҳե���,+ rm.getMsgDesc()
            }

            //�ˮֱb�ȬO�_����
            new DK_F0Z011().isBalance2(user_div_no, user_id, ACNT_DATE, SLIP_LOT_NO, SLIP_SET_NO, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_006") + rm.getMsgDesc()); //�ˮֱb�ȬO�_����
            }
        }

        return rtnMap;
    }

    /**
     * ����ú�O��X�h�O�X�b�@�~
     * @param reqMap    �e���d�����
     * @param reqList   �e���Ŀ諸���
     * @throws Exception
     */
    public void confirm3(Map reqMap, List<Map> reqList, List<DK_AAZ011_bo> DK_AAZ011_BO_LIST) throws Exception {

        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        String ACNT_DATE = MapUtils.getString(reqMap, "SLIP_DATE");
        String user_id = MapUtils.getString(reqMap, "USER_ID");
        String user_div_no = MapUtils.getString(reqMap, "USER_DIV_NO");
        String TRN_SER_NO = MapUtils.getString(reqMap, "TRN_SER_NO");
        String SLIP_LOT_NO = MapUtils.getString(reqMap, "SLIP_LOT_NO");
        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        Map<MultiKey, BigDecimal> RMT_AMT_MAP = new HashMap<MultiKey, BigDecimal>(); //��X�h�O�覡���״ڡA�U�h�O��w���B�`�M
        Map<MultiKey, BigDecimal> BAL_AMT_MAP = new HashMap<MultiKey, BigDecimal>();
        BigDecimal TOTAL_AMT2 = BigDecimal.ZERO; //��X�h�O�覡���{�������B�X�p
        BigDecimal TOTAL_AMT3 = BigDecimal.ZERO; //��X�h�O�覡���䲼�����B�X�p
        Map<MultiKey, BigDecimal> RMT_CNT_MAP = new HashMap<MultiKey, BigDecimal>(); //��X�h�O�覡���״ڡA�U�h�O��w����`�M
        Map<MultiKey, BigDecimal> BAL_CNT_MAP = new HashMap<MultiKey, BigDecimal>();
        BigDecimal TOTAL_CNT2 = BigDecimal.ZERO; //��X�h�O�覡���{������ƦX�p
        BigDecimal TOTAL_CNT3 = BigDecimal.ZERO; //��X�h�O�覡���䲼����ƦX�p

        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        //String BAL_TYPE = theEP_Z0G103.getBalTypeByList(reqList);
        //        BigDecimal TOTAL_AMT_DR1 = BigDecimal.ZERO; //ú�ں��������������B�X�p
        //        BigDecimal TOTAL_CNT_DR1 = BigDecimal.ZERO; //ú�ں�������������ƦX�p
        //        BigDecimal TOTAL_AMT_DR2 = BigDecimal.ZERO; //ú�ں�������������B�X�p
        //        BigDecimal TOTAL_CNT_DR2 = BigDecimal.ZERO; //ú�ں������������ƦX�p
        //        BigDecimal TOTAL_AMT_DR3 = BigDecimal.ZERO; //ú�ں������޲z�O�����B�X�p
        //        BigDecimal TOTAL_CNT_DR3 = BigDecimal.ZERO; //ú�ں������޲z�O����ƦX�p

        //DataSet ds = Transaction.getDataSet();
        String current_time = DATE.getDBTimeStamp();
        StringBuilder sb = new StringBuilder();
        //String[] PAY_KIND_array = { "1", "4", "5", "7" };
        log.debug("confirm3.reqList:" + reqList);
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        for (Map tempMap : reqList) {
            String BLD_CD = MapUtils.getString(tempMap, "BLD_CD", "");

            String balType = theEP_Z0G103.getBAL_TYPE(SUB_CPY_ID, BLD_CD);
            //balType
            tempMap.put("BAL_TYPE", balType);
            //String PAY_KIND = MapUtils.getString(tempMap, "PAY_KIND");
            String PAY_TYPE = MapUtils.getString(tempMap, "PAY_TYPE");
            //            if (ArrayUtils.contains(PAY_KIND_array, PAY_KIND)) {
            //                TOTAL_AMT_DR1 = TOTAL_AMT_DR1.add(getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO));
            //                TOTAL_CNT_DR1 = TOTAL_CNT_DR1.add(BigDecimal.ONE);
            //            } else if ("2".equals(PAY_KIND)) {
            //                TOTAL_AMT_DR2 = TOTAL_AMT_DR2.add(getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO));
            //                TOTAL_CNT_DR2 = TOTAL_CNT_DR2.add(BigDecimal.ONE);
            //            } else if ("3".equals(PAY_KIND)) {
            //                TOTAL_AMT_DR3 = TOTAL_AMT_DR3.add(getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO));
            //                TOTAL_CNT_DR3 = TOTAL_CNT_DR3.add(BigDecimal.ONE);
            //            }

            //            ds.clear();
            //            ds.setField("TRN_DATE", current_time);
            //            ds.setField("TRN_SER_NO", TRN_SER_NO);
            //            ds.setField("S_ACNT_DATE", ACNT_DATE);
            //            ds.setField("S_ACNT_ID", user_id);
            //            ds.setField("S_DIV_NO", user_div_no);
            //            ds.setField("S_SLPLOT_NO", SLIP_LOT_NO);
            //            ds.setField("S_SLPSET_NO", SLIP_SET_NO);
            //            ds.setField("EXT_NO", MapUtils.getString(tempMap, "EXT_NO"));
            //            DBUtil.executeUpdate(ds, SQL_confirm2_001);

            //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                if ("3".equals(PAY_TYPE)) { //��X�h�O�覡���״�
                    DJ_A0Z016_vo DJ_A0Z016_vo = DJ_A0Z016.getRmtBankInfoByAcptBankNo(MapUtils.getString(tempMap, "ACPT_BANK_NO"), "NTD",
                        true);
                    sb.setLength(0);
                    String rmtkey = sb.append(DJ_A0Z016_vo.getRMT_BANK_NO()).append("-").append(DJ_A0Z016_vo.getRMT_ACNT_NO()).toString();
                    MultiKey mkey = new MultiKey(rmtkey, balType);
                    RMT_AMT_MAP.put(mkey, getBigDecimal(RMT_AMT_MAP.get(mkey), BigDecimal.ZERO).add(
                        getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO)));
                    RMT_CNT_MAP.put(mkey, getBigDecimal(RMT_CNT_MAP.get(mkey), BigDecimal.ZERO).add(BigDecimal.ONE));
                } else if ("1".equals(PAY_TYPE)) { //��X�h�O�覡���{��
                    MultiKey mkey = new MultiKey("1", balType);
                    BAL_AMT_MAP.put(mkey, getBigDecimal(BAL_AMT_MAP.get(mkey), BigDecimal.ZERO).add(
                        getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO)));
                    BAL_CNT_MAP.put(mkey, getBigDecimal(BAL_CNT_MAP.get(mkey), BigDecimal.ZERO).add(BigDecimal.ONE));

                    TOTAL_AMT2 = TOTAL_AMT2.add(getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO));
                    TOTAL_CNT2 = TOTAL_CNT2.add(BigDecimal.ONE);
                } else if ("2".equals(PAY_TYPE)) { //��X�h�O�覡���䲼
                    MultiKey mkey = new MultiKey("2", balType);
                    BAL_AMT_MAP.put(mkey, getBigDecimal(BAL_AMT_MAP.get(mkey), BigDecimal.ZERO).add(
                        getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO)));
                    BAL_CNT_MAP.put(mkey, getBigDecimal(BAL_CNT_MAP.get(mkey), BigDecimal.ZERO).add(BigDecimal.ONE));

                    TOTAL_AMT3 = TOTAL_AMT3.add(getBigDecimal(tempMap.get("SWP_AMT"), BigDecimal.ZERO));
                    TOTAL_CNT3 = TOTAL_CNT3.add(BigDecimal.ONE);
                }
            }
        }
        log.debug("confirm3.BAL_AMT_MAP:" + BAL_AMT_MAP);
        log.debug("confirm3.BAL_CNT_MAP:" + BAL_CNT_MAP);

        //�Y#RMT_AMT_MAP.keyset.size()>0�A�h�v���B�z#RMT_AMT_MAP.keyset�A�զ��״ڥX�b�Ҳ�BO�A
        //List<DK_AAZ011_bo> DK_AAZ011_BO_LIST = new ArrayList<DK_AAZ011_bo>();
        Set<MultiKey> keyset = RMT_AMT_MAP.keySet();
        String user_name = MapUtils.getString(reqMap, "USER_NAME");
        if (keyset.size() > 0) {
            for (MultiKey mkey : keyset) {
                String acntkey = (String) mkey.getKey(0);
                String balType = (String) mkey.getKey(1);
                DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
                DK_AAZ011_BO.setINPUT_ID(user_id);
                DK_AAZ011_BO.setINPUT_NAME(user_name);
                DK_AAZ011_BO.setTRN_DATE(current_time);
                DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
                DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
                DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
                DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
                DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
                DK_AAZ011_BO.setTRN_KIND("EPC390");
                DK_AAZ011_BO.setMEMO("");
                DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
                DK_AAZ011_BO.setKIND_CODE(null);
                DK_AAZ011_BO.setBUS_CODE("EP");
                DK_AAZ011_BO.setBUS_TRAN_CODE("1");
                DK_AAZ011_BO.setCURR("NTD");
                DK_AAZ011_BO.setCNT(MapUtils.getString(RMT_CNT_MAP, mkey));
                DK_AAZ011_BO.setITEM("9");
                DK_AAZ011_BO.setTYPE("6");
                DK_AAZ011_BO.setBANK_NO(acntkey.split("-")[0]);
                DK_AAZ011_BO.setACNT_NO(acntkey.split("-")[1]);
                DK_AAZ011_BO.setAMT(MapUtils.getString(RMT_AMT_MAP, mkey));
                DK_AAZ011_BO.setACNT_TYPE(ACNT_TYPE);
                DK_AAZ011_BO.setBAL_TYPE(balType);

                DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);
            }
        }

        Set<MultiKey> balkeyset = BAL_AMT_MAP.keySet();
        log.debug("BAL_AMT_MAP.keyset:" + balkeyset);
        if (balkeyset.size() > 0) {
            for (MultiKey mkey : balkeyset) {
                String PAY_TYPE = (String) mkey.getKey(0);
                String balType = (String) mkey.getKey(1);
                if ("1".equals(PAY_TYPE)) {
                    //��X�h�O�覡���{��

                    DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
                    DK_AAZ011_BO.setINPUT_ID(user_id);
                    DK_AAZ011_BO.setINPUT_NAME(user_name);
                    DK_AAZ011_BO.setTRN_DATE(current_time);
                    DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
                    DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
                    DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
                    DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
                    DK_AAZ011_BO.setTRN_KIND("EPC390");
                    DK_AAZ011_BO.setMEMO("");
                    DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
                    DK_AAZ011_BO.setKIND_CODE(null);
                    DK_AAZ011_BO.setBUS_CODE("EP");
                    DK_AAZ011_BO.setBUS_TRAN_CODE("1");
                    DK_AAZ011_BO.setCURR("NTD");
                    DK_AAZ011_BO.setCNT(MapUtils.getString(BAL_CNT_MAP, mkey));
                    DK_AAZ011_BO.setITEM("9");
                    DK_AAZ011_BO.setTYPE("5");
                    DK_AAZ011_BO.setBANK_NO("");
                    DK_AAZ011_BO.setACNT_NO("");
                    DK_AAZ011_BO.setAMT(MapUtils.getString(BAL_AMT_MAP, mkey));
                    DK_AAZ011_BO.setACNT_TYPE(ACNT_TYPE);
                    DK_AAZ011_BO.setBAL_TYPE(balType);

                    DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);

                } else if ("2".equals(PAY_TYPE)) {
                    //��X�h�O�覡���䲼

                    //���o��s�b��
                    ReturnMessage rm = new ReturnMessage();
                    Map ACNT_MAP = new DJ_C0Z032().getChkAcntInfo(user_div_no, rm);

                    DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
                    DK_AAZ011_BO.setINPUT_ID(user_id);
                    DK_AAZ011_BO.setINPUT_NAME(user_name);
                    DK_AAZ011_BO.setTRN_DATE(current_time);
                    DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
                    DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
                    DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
                    DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
                    DK_AAZ011_BO.setTRN_KIND("EPC390");
                    DK_AAZ011_BO.setMEMO("");
                    DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
                    DK_AAZ011_BO.setKIND_CODE(null);
                    DK_AAZ011_BO.setBUS_CODE("EP");
                    DK_AAZ011_BO.setBUS_TRAN_CODE("1");
                    DK_AAZ011_BO.setCURR("NTD");
                    DK_AAZ011_BO.setCNT(MapUtils.getString(BAL_CNT_MAP, mkey));
                    DK_AAZ011_BO.setITEM("9");
                    DK_AAZ011_BO.setTYPE("6");
                    DK_AAZ011_BO.setBANK_NO(MapUtils.getString(ACNT_MAP, "BANK_NO"));
                    DK_AAZ011_BO.setACNT_NO(MapUtils.getString(ACNT_MAP, "ACNT_NO"));
                    DK_AAZ011_BO.setAMT(MapUtils.getString(BAL_AMT_MAP, mkey));
                    DK_AAZ011_BO.setACNT_TYPE(ACNT_TYPE);
                    DK_AAZ011_BO.setBAL_TYPE(balType);

                    DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);

                }
            }

        }

        //�Y#TOTAL_CNT2>0�A�h�զ��{���X�b�Ҳ�BO�A
        //        if (TOTAL_CNT2.compareTo(BigDecimal.ZERO) > 0) {}

        //�Y#TOTAL_CNT3>0�A�h�զ��䲼�X�b�Ҳ�BO�A
        //        if (TOTAL_CNT3.compareTo(BigDecimal.ZERO) > 0) {}

        //        if (TOTAL_CNT_DR1.compareTo(BigDecimal.ZERO) != 0) {
        //            DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
        //            DK_AAZ011_BO.setINPUT_ID(user_id);
        //            DK_AAZ011_BO.setINPUT_NAME(user_name);
        //            DK_AAZ011_BO.setTRN_DATE(current_time);
        //            DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
        //            DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
        //            DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
        //            DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
        //            DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
        //            DK_AAZ011_BO.setTRN_KIND("EPC390");
        //            DK_AAZ011_BO.setMEMO("");
        //            DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
        //            DK_AAZ011_BO.setKIND_CODE(null);
        //            DK_AAZ011_BO.setBUS_CODE("EP");
        //            DK_AAZ011_BO.setBUS_TRAN_CODE("1");
        //            DK_AAZ011_BO.setCURR("NTD");
        //            DK_AAZ011_BO.setCNT(TOTAL_CNT_DR1.toPlainString());
        //            DK_AAZ011_BO.setITEM("9");
        //            DK_AAZ011_BO.setTYPE("1");
        //            DK_AAZ011_BO.setBANK_NO("");
        //            DK_AAZ011_BO.setACNT_NO("");
        //            DK_AAZ011_BO.setAMT(TOTAL_AMT_DR1.toPlainString());
        //            DK_AAZ011_BO.setACNT_TYPE(ACNT_TYPE);
        //  
        //            DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);
        //        }
        //
        //        if (TOTAL_CNT_DR2.compareTo(BigDecimal.ZERO) != 0) {
        //            DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
        //            DK_AAZ011_BO.setINPUT_ID(user_id);
        //            DK_AAZ011_BO.setINPUT_NAME(user_name);
        //            DK_AAZ011_BO.setTRN_DATE(current_time);
        //            DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
        //            DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
        //            DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
        //            DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
        //            DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
        //            DK_AAZ011_BO.setTRN_KIND("EPC390");
        //            DK_AAZ011_BO.setMEMO("");
        //            DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
        //            DK_AAZ011_BO.setKIND_CODE(null);
        //            DK_AAZ011_BO.setBUS_CODE("EP");
        //            DK_AAZ011_BO.setBUS_TRAN_CODE("1");
        //            DK_AAZ011_BO.setCURR("NTD");
        //            DK_AAZ011_BO.setCNT(TOTAL_CNT_DR2.toPlainString());
        //            DK_AAZ011_BO.setITEM("9");
        //            DK_AAZ011_BO.setTYPE("3");
        //            DK_AAZ011_BO.setBANK_NO("");
        //            DK_AAZ011_BO.setACNT_NO("");
        //            DK_AAZ011_BO.setAMT(TOTAL_AMT_DR2.toPlainString());
        //            DK_AAZ011_BO.setACNT_TYPE(ACNT_TYPE);
        //
        //            DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);
        //        }
        //
        //        if (TOTAL_CNT_DR3.compareTo(BigDecimal.ZERO) != 0) {
        //            DK_AAZ011_bo DK_AAZ011_BO = new DK_AAZ011_bo();
        //            DK_AAZ011_BO.setINPUT_ID(user_id);
        //            DK_AAZ011_BO.setINPUT_NAME(user_name);
        //            DK_AAZ011_BO.setTRN_DATE(current_time);
        //            DK_AAZ011_BO.setTRN_SER_NO(TRN_SER_NO);
        //            DK_AAZ011_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
        //            DK_AAZ011_BO.setSLIP_SET_NO(SLIP_SET_NO);
        //            DK_AAZ011_BO.setREL_FILE_NO("EPC30090");
        //            DK_AAZ011_BO.setACNT_DATE(ACNT_DATE);
        //            DK_AAZ011_BO.setTRN_KIND("EPC390");
        //            DK_AAZ011_BO.setMEMO("");
        //            DK_AAZ011_BO.setACNT_DIV_NO(user_div_no);
        //            DK_AAZ011_BO.setKIND_CODE(null);
        //            DK_AAZ011_BO.setBUS_CODE("EP");
        //            DK_AAZ011_BO.setBUS_TRAN_CODE("1");
        //            DK_AAZ011_BO.setCURR("NTD");
        //            DK_AAZ011_BO.setCNT(TOTAL_CNT3.toPlainString());
        //            DK_AAZ011_BO.setITEM("9");
        //            DK_AAZ011_BO.setTYPE("2");
        //            DK_AAZ011_BO.setBANK_NO("");
        //            DK_AAZ011_BO.setACNT_NO("");
        //            DK_AAZ011_BO.setAMT(TOTAL_AMT_DR3.toPlainString());
        //            DK_AAZ011_BO.setACNT_TYPE(ACNT_TYPE);
        //
        //            DK_AAZ011_BO_LIST.add(DK_AAZ011_BO);
        //        }

        //�YreqList[i].RTN_KIND=��2�� OR ��3���A�զ��ݵ��I��BO�A�üg�J�ݵ��I��(DTDJB006)
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�g���I��
            String today = DATE.getDBDate();
            DJ_B0Z010 theDJ_B0Z010 = new DJ_B0Z010();
            Id id = new Id();
            String RMT_BANK_NO = "";
            String RMT_ACNT_NO = "";
            for (Map tempMap : reqList) {
                String balType = MapUtils.getString(tempMap, "BAL_TYPE");
                String PAY_TYPE = MapUtils.getString(tempMap, "PAY_TYPE");
                DTDJB006 DTDJB006_bo = new DTDJB006();
                if ("3".equals(PAY_TYPE)) {//�״�
                    DTDJB006_bo.setPAY_TYPE("1");
                    DJ_A0Z016_vo DJ_A0Z016_vo = DJ_A0Z016.getRmtBankInfoByAcptBankNo(MapUtils.getString(tempMap, "ACPT_BANK_NO"), "NTD",
                        true);
                    RMT_BANK_NO = DJ_A0Z016_vo.getRMT_BANK_NO();
                    RMT_ACNT_NO = DJ_A0Z016_vo.getRMT_ACNT_NO();
                } else if ("2".equals(PAY_TYPE)) {//�䲼
                    DTDJB006_bo.setPAY_TYPE("3");
                    RMT_BANK_NO = "";
                    RMT_ACNT_NO = "";
                } else if ("1".equals(PAY_TYPE)) {//�{��
                    DTDJB006_bo.setPAY_TYPE("2");
                    RMT_BANK_NO = "";
                    RMT_ACNT_NO = "";
                }

                //�]�w���ڤH�����O#ACPT_KIND�B���ڤH�ҥ����#ACPT_ID_KIND
                String ACPT_ID = MapUtils.getString(tempMap, "ACPT_ID");
                String ACPT_KIND;
                String ACPT_ID_KIND;
                if (id.checkID1(ACPT_ID)) {
                    ACPT_KIND = "2";
                    ACPT_ID_KIND = "1";
                } else if (id.checkID2(ACPT_ID)) {
                    ACPT_KIND = "X";
                    ACPT_ID_KIND = "2";
                } else if (id.checkUniSN(ACPT_ID)) {
                    ACPT_KIND = "1";
                    ACPT_ID_KIND = "3";
                } else {
                    ACPT_KIND = "X";
                    ACPT_ID_KIND = "4";
                }
                if ("2".equals(PAY_TYPE)) { //��X�h�O�覡���䲼
                    ACPT_KIND = "C";
                }

                DTDJB006_bo.setCASE_NO(null);
                DTDJB006_bo.setCHK_KIND("1");
                DTDJB006_bo.setPAY_DIV_NO(user_div_no);
                DTDJB006_bo.setPAY_DATE(ACNT_DATE);
                DTDJB006_bo.setPAY_KIND("02");
                DTDJB006_bo.setAPLY_NO("");
                DTDJB006_bo.setPOLICY_NO(MapUtils.getString(tempMap, "CRT_NO"));
                DTDJB006_bo.setSYS_NO("P");
                DTDJB006_bo.setPAY_AMT(MapUtils.getString(tempMap, "SWP_AMT"));
                DTDJB006_bo.setNET_PAY_AMT(MapUtils.getString(tempMap, "SWP_AMT"));
                DTDJB006_bo.setTAX_AMT("0");
                DTDJB006_bo.setCLC_NO("");
                DTDJB006_bo.setAGNT_ID("");
                DTDJB006_bo.setAGNT_NAME("");
                DTDJB006_bo.setACPT_DIV_NO(user_div_no);
                DTDJB006_bo.setRMT_BANK_NO(RMT_BANK_NO);
                DTDJB006_bo.setRMT_ACNT_NO(RMT_ACNT_NO);
                DTDJB006_bo.setACPT_BANK_NO(MapUtils.getString(tempMap, "ACPT_BANK_NO"));
                DTDJB006_bo.setACPT_ACNT_NO(MapUtils.getString(tempMap, "ACPT_ACNT_NO"));
                DTDJB006_bo.setACPT_ACNT_NAME(MapUtils.getString(tempMap, "ACPT_ACNT_NAME"));
                DTDJB006_bo.setACPT_NAME(MapUtils.getString(tempMap, "ACPT_ACNT_NAME"));

                boolean isExtChar = DJ_C0Z012.isExtChar(MapUtils.getString(tempMap, "ACPT_ACNT_NAME"));
                if (isExtChar) {
                    DTDJB006_bo.setACPT_ACNT_NPRT("A");
                    DTDJB006_bo.setACPT_NPRT("A");
                } else {
                    DTDJB006_bo.setACPT_ACNT_NPRT("");
                    DTDJB006_bo.setACPT_NPRT("");
                }
                DTDJB006_bo.setACPT_KIND(ACPT_KIND);
                DTDJB006_bo.setID_KIND(ACPT_ID_KIND);
                DTDJB006_bo.setID(ACPT_ID);
                DTDJB006_bo.setMEMO("");
                DTDJB006_bo.setAPLY_DIV_NO(user_div_no);
                DTDJB006_bo.setINPUT_DATE(current_time);
                DTDJB006_bo.setINPUT_ID(user_id);
                DTDJB006_bo.setINPUT_NAME(user_name);
                DTDJB006_bo.setUSER_TRN_SERNO(TRN_SER_NO);
                DTDJB006_bo.setEXTR_DATE(today);
                DTDJB006_bo.setYEAR(DATE.getROCYear(ACNT_DATE));
                DTDJB006_bo.setFILE_NO("000000");
                DTDJB006_bo.setSER_NO("0");
                DTDJB006_bo.setACPT_SER_NO("0");
                DTDJB006_bo.setSLIP_DATE(ACNT_DATE);
                DTDJB006_bo.setSLIP_DIV_NO("");
                DTDJB006_bo.setSLIP_SEQ_NO("0");
                DTDJB006_bo.setCFM_DATE(null);
                DTDJB006_bo.setCFM_DIV_NO("");
                DTDJB006_bo.setCFM_ID("");
                DTDJB006_bo.setCFM_NAME("");
                DTDJB006_bo.setDLT_CODE("");
                DTDJB006_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                DTDJB006_bo.setSLIP_SET_NO(SLIP_SET_NO);
                DTDJB006_bo.setPRE_KEY(MapUtils.getString(tempMap, "EXT_NO"));
                DTDJB006_bo.setCURR("NTD");
                DTDJB006_bo.setSWIFT_CODE("");
                DTDJB006_bo.setCHECK_CODE("1");
                DTDJB006_bo.setTRN_KIND("");
                DTDJB006_bo.setBAL_TYPE(balType);

                theDJ_B0Z010.insertDTDJB006(DTDJB006_bo);
            }//end for
        }

    }

    /**
     * �b�Ȩ����@�~
     * @param reqMap    �e���d����� 
     * @param reqList   �e���Ŀ���
     * @throws Exception
     */
    public void cancel(Map reqMap, List<Map> reqList) throws Exception {

        ErrorInputException eie = null;
        String QUERY_KIND = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
            if (StringUtils.isBlank(QUERY_KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_002"));//�d�߶��ج��������
            }
        }
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        //�̷Ӥ��P�d�߶��ءA�I�s���P��k
        if ("1".equals(QUERY_KIND)) {//�Ȧ��h�O
            cancel1(reqMap, reqList);
        } else if ("2".equals(QUERY_KIND)) {//ú�O��X
            cancel2(reqMap, reqList);
        }
    }

    /**
     * ����Ȧ��h�O�b�Ȩ����@�~
     * @param reqMap    �e���d�����
     * @param reqList   �e���Ŀ���
     * @throws Exception
     */
    public void cancel1(Map reqMap, List<Map> reqList) throws Exception {

        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        //�]�w�b�Ȥ��
        String ACNT_DATE = MapUtils.getString(reqMap, "SLIP_DATE");
        //�]�w�ǲ��帹
        String SLIP_LOT_NO = getSLIP_LOT_NO(QUERY_KIND, ACNT_TYPE);
        //�]�w�ǲ��ո�
        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
        //�]�w�ǲ����
        String ACNT_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");
        ReturnMessage rm = new ReturnMessage();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();

        //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
        //��ؤ~�|�X�b
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
            //�զ��|�p�������������BO
            DTDKF001 DTDKF001_Bo = new DTDKF001();
            DTDKF001_Bo.setACNT_DIV_NO(ACNT_DIV_NO);
            DTDKF001_Bo.setACNT_DATE(ACNT_DATE);
            DTDKF001_Bo.setSLIP_LOT_NO(SLIP_LOT_NO);
            DTDKF001_Bo.setSLIP_SET_NO(SLIP_SET_NO);

            //�R���|�p�������������
            new DK_F0Z017().deleteByACNT_DIV_NO(DTDKF001_Bo, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_007", new Object[] { rm.getMsgDesc() }));//�R���|�p������������ɥ���, + rm.getMsgDesc()
            }
        }

        DK_G0Z011 theDK_G0Z011 = new DK_G0Z011();
        EP_Z0C310 theEP_Z0C310 = new EP_Z0C310();
        for (Map dataMap : reqList) {

            //��sDTDKG003�b�ȸ��
            DTDKG003 DTDKG003_VO = new DTDKG003();
            DTDKG003_VO.setTMP_NO(MapUtils.getString(dataMap, "TMP_NO"));
            DTDKG003_VO.setDTMP_NO(MapUtils.getString(dataMap, "DTMP_NO"));
            DTDKG003_VO.setDACNT_DATE(null);
            DTDKG003_VO.setDACNT_SER_NO("0");
            DTDKG003_VO.setSLIP_DATE(null);
            DTDKG003_VO.setSLIP_LOT_NO("");
            DTDKG003_VO.setSLIP_SET_NO("0");
            //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                theDK_G0Z011.updateG003ForXA_2(DTDKG003_VO, rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException("�����R�Ȧ��ɱb�ȸ�T�o�Ϳ��~�G" + rm.getMsgDesc());
                }
            } else {
                //[20180301] �D��ا�gEP.�Ȧ���
                DTEPC310 C310 = new DTEPC310();
                VOTool.copyVOFromTo(DTDKG003_VO, C310);
                C310.setSUB_CPY_ID(SUB_CPY_ID);
                theEP_Z0C310.updC310ForCancelACNT(C310);

            }
        }

        //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
        //��ؤ~�|�X�b
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
            //�R���I�ڨt�Ϋݵ��I��(DTDJB006)
            new DJ_B0Z010().deleteForNewPlatform_EP(ACNT_DATE, SLIP_LOT_NO, SLIP_SET_NO, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_008", new Object[] { rm.getMsgDesc() }));//�R���I�ڨt�Ϋݵ��I�ɥ���, + rm.getMsgDesc()
            }
        }
    }

    /**
     * ����ú�O��X�J�Ȧ��b�Ȩ����@�~
     * @param reqMap    �e���d�����
     * @param reqList   �e���Ŀ���
     * @throws Exception
     */
    public void cancel2(Map reqMap, List<Map> reqList) throws Exception {

        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        //�]�w�b�Ȥ��
        String ACNT_DATE = MapUtils.getString(reqMap, "SLIP_DATE");
        //�]�w�ǲ��帹
        String SLIP_LOT_NO = getSLIP_LOT_NO(QUERY_KIND, ACNT_TYPE);
        //�]�w�ǲ��ո�
        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
        //�]�w�ǲ����
        String ACNT_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");

        List<Map> dataList1 = new ArrayList<Map>(); //�Ȧ��h�O�Bú�O��X�h�O�������
        List<Map> dataList2 = new ArrayList<Map>(); //ú�O��X�J�Ȧ��Bú�O��X�~�b�J�Ȧ����

        for (Map map : reqList) {
            String SWP_KIND = MapUtils.getString(map, "SWP_KIND");
            String PAY_TYPE = MapUtils.getString(map, "PAY_TYPE");
            if ("0".equals(SWP_KIND) || "2".equals(SWP_KIND)) {
                dataList1.add(map); //��X�J�Ȧ��B��X�~�b�J�Ȧ����
            } else if ("1".equals(SWP_KIND) && ("1".equals(PAY_TYPE) || "2".equals(PAY_TYPE) || "3".equals(PAY_TYPE))) {
                dataList2.add(map); //��X�h�O���
            }
        }

        DataSet ds = Transaction.getDataSet();

        for (Map tempMap : reqList) {
            ds.clear();
            ds.setField("TRN_DATE", null);
            ds.setField("TRN_SER_NO", null);
            ds.setField("S_ACNT_DATE", null);
            ds.setField("S_ACNT_ID", null);
            ds.setField("S_DIV_NO", null);
            ds.setField("S_SLPLOT_NO", null);
            ds.setField("S_SLPSET_NO", null);
            ds.setField("EXT_NO", MapUtils.getString(tempMap, "EXT_NO"));
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_cancel2_001);
        }

        //DK_G0Z002 theDK_G0Z002 = new DK_G0Z002();
        ReturnMessage rm = new ReturnMessage();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        EP_Z0C309 theEP_Z0C309 = new EP_Z0C309();
        for (Map tempMap : dataList1) {

            //��sDKG�Ȧ��ɱb�ȸ�T
            //            DTDKG002 G002_VO = new DTDKG002();
            //            G002_VO.setTMP_NO(MapUtils.getString(tempMap, "TMP_NO"));
            //            G002_VO.setSLIP_DATE(null);
            //            G002_VO.setACNT_DATE(null);
            //            G002_VO.setSLIP_LOT_NO("");
            //            G002_VO.setSLIP_SET_NO("0");
            //            G002_VO.setACNT_SER_NO("0");
            //            theDK_G0Z002.updateG002ForXA(G002_VO, rm);
            DTDKG002 G002_VO = new DTDKG002();
            String TMP_NO = MapUtils.getString(tempMap, "TMP_NO");
            G002_VO = new DK_G0Z007().queryByPKForXA(TMP_NO, rm);
            //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                new DK_G0Z002().checkAndUpdateG002ForXA(G002_VO, rm);

                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException("��sDKG�Ȧ��ɱb�ȸ�T����:" + rm.getMsgDesc());
                }
            } else {
                // [20180301]�D��ا�gEP.�Ȧ���
                DTEPC309 C309 = new DTEPC309();
                VOTool.copyVOFromTo(G002_VO, C309);
                C309.setSUB_CPY_ID(SUB_CPY_ID);
                theEP_Z0C309.checkAndUpdateC309(C309);
            }
        }

        //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
        //��ؤ~�|�X�b
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
            //�զ��|�p�������������BO
            DTDKF001 DTDKF001_Bo = new DTDKF001();
            DTDKF001_Bo.setACNT_DIV_NO(ACNT_DIV_NO);
            DTDKF001_Bo.setACNT_DATE(ACNT_DATE);
            DTDKF001_Bo.setSLIP_LOT_NO(SLIP_LOT_NO);
            DTDKF001_Bo.setSLIP_SET_NO(SLIP_SET_NO);

            //�R���|�p�������������        
            new DK_F0Z017().deleteByACNT_DIV_NO(DTDKF001_Bo, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_007", new Object[] { rm.getMsgDesc() }));//�R���|�p������������ɥ���, + rm.getMsgDesc()
            }

            //�R���I�ڨt�Ϋݵ��I��(DTDJB006)
            if (dataList2.size() > 0) {
                new DJ_B0Z010().deleteForNewPlatform_EP(ACNT_DATE, SLIP_LOT_NO, SLIP_SET_NO, rm);
            }
        }
    }

    /**
     * ����ú�O��X�h�O�b�Ȩ����@�~
     * @param reqMap    �e���d�����
     * @param reqList   �e���Ŀ���
     * @throws Exception
     */
    /*public void cancel3(Map reqMap, List<Map> reqList) throws Exception {

        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        }
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30090_MSG_001"));//�ǤJ��Ƥ��i����
        }
        if (eie != null) {
            throw eie;
        }

        String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
        //�]�w�b�Ȥ��
        String ACNT_DATE = MapUtils.getString(reqMap, "SLIP_DATE");
        //�]�w�ǲ��帹
        String SLIP_LOT_NO = getSLIP_LOT_NO(QUERY_KIND);
        //�]�w�ǲ��ո�
        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
        //�]�w�ǲ����
        String ACNT_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");

        DataSet ds = Transaction.getDataSet();
        for (Map tempMap : reqList) {
            ds.clear();
            ds.setField("TRN_DATE", null);
            ds.setField("TRN_SER_NO", null);
            ds.setField("S_ACNT_DATE", null);
            ds.setField("S_ACNT_ID", null);
            ds.setField("S_DIV_NO", null);
            ds.setField("S_SLPLOT_NO", null);
            ds.setField("S_SLPSET_NO", null);
            ds.setField("EXT_NO", MapUtils.getString(tempMap, "EXT_NO"));
            DBUtil.executeUpdate(ds, SQL_cancel2_001);
        }

        //�զ��|�p�������������BO
        DTDKF001 DTDKF001_Bo = new DTDKF001();
        DTDKF001_Bo.setACNT_DIV_NO(ACNT_DIV_NO);
        DTDKF001_Bo.setACNT_DATE(ACNT_DATE);
        DTDKF001_Bo.setSLIP_LOT_NO(SLIP_LOT_NO);
        DTDKF001_Bo.setSLIP_SET_NO(SLIP_SET_NO);

        //�R���|�p�������������
        ReturnMessage rm = new ReturnMessage();
        new DK_F0Z017().deleteByACNT_DIV_NO(DTDKF001_Bo, rm);
        if (rm.getReturnCode() != 0) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_007", new Object[] { rm.getMsgDesc() }));//�R���|�p������������ɥ���, + rm.getMsgDesc()
        }

        //�R���I�ڨt�Ϋݵ��I��(DTDJB006)
        new DJ_B0Z010().deleteForNewPlatform_EP(ACNT_DATE, SLIP_LOT_NO, SLIP_SET_NO, rm);
        if (rm.getReturnCode() != 0) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_008", new Object[] { rm.getMsgDesc() }));//�R���I�ڨt�Ϋݵ��I�ɥ���, + rm.getMsgDesc()
        }
    }*/

    /**
     * @param QUERY_KIND
     * @return
     * @throws ModuleException
     */
    public String getSLIP_LOT_NO(String QUERY_KIND, String ACNT_TYPE) throws ModuleException {
        if ("1".equals(QUERY_KIND)) {
            if ("1".equals(ACNT_TYPE)) {
                return "EP8";
            } else {
                return "EPK"; //���ʲ��Ȧ��h�O-�粣
            }

        } else if ("2".equals(QUERY_KIND) || "3".equals(QUERY_KIND) || "4".equals(QUERY_KIND)) {
            if ("1".equals(ACNT_TYPE)) {
                return "EP9";
            } else {
                return "EPL"; //���ʲ��Ȧ��h�O-�粣
            }

        } else {
            throw new ModuleException(MessageUtil.getMessage("EP_C30090_MSG_009", new Object[] { QUERY_KIND }));//���o�ǲ��帹���~�A�d�ߺ���=[{0}]
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

    private void calAcntMap(String ACNT_TYPE, String DIV_NO_C101, Map<MultiKey, BigDecimal> ACNT_AMT_MAP,
            Map<MultiKey, BigDecimal> ACNT_CNT_MAP, BigDecimal ACNT_AMT, String BAL_TYPE) throws ModuleException {
        String acntkey = DIV_NO_C101 + "-" + ACNT_TYPE;
        MultiKey mkey = new MultiKey(acntkey, BAL_TYPE);
        BigDecimal AMT = BigDecimal.ZERO;
        if (!ACNT_AMT_MAP.containsKey(mkey)) {
            AMT = BigDecimal.ZERO;
        } else {
            AMT = (BigDecimal) MapUtils.getObject(ACNT_AMT_MAP, mkey);
        }
        ACNT_AMT_MAP.put(mkey, AMT.add(ACNT_AMT));

        BigDecimal CNT = BigDecimal.ZERO;
        if (!ACNT_CNT_MAP.containsKey(mkey)) {
            CNT = BigDecimal.ONE;
        } else {
            CNT = (BigDecimal) MapUtils.getObject(ACNT_CNT_MAP, mkey);
            CNT = CNT.add(BigDecimal.ONE);
        }
        ACNT_CNT_MAP.put(mkey, CNT);
    }
}
