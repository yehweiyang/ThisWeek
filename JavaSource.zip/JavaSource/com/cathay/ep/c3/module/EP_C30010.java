package com.cathay.ep.c3.module;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE Description Author
 * 2013/08/12  Created ������
 * �@�B   �{���\�෧�n�����G
 * �ҲզW��    ú�ڳB�z�@�~���@�Ҳ�
 * �Ҳ�ID    EP_C30010
 * ���n����    ���oú�ڬ����M��@�~
 *</pre>
 * @author ���_��
 * @since 2013/11/1
 */

@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C30010 {

    private static final Logger log = Logger.getLogger(EP_C30010.class);

    private static final String SQL_queryRcvInfoList_001 = "com.cathay.ep.c3.module.EP_C30010.SQL_queryRcvInfoList_001";

    private static final String SQL_queryPayInfoMap_001 = "com.cathay.ep.c3.module.EP_C30010.SQL_queryPayInfoMap_001";

    private static final String SQL_queryPayInfoList_001 = "com.cathay.ep.c3.module.EP_C30010.SQL_queryPayInfoList_001";

    /**
     * ���o���������M��
     * @param reqMap <pre>
     *                  SUB_CPY_ID �����q�O
     *                  RCV_YM �����~��
     *                  BLD_CD �j�ӥN��
     *                  CRT_NO �����N��
     *                  CUS_NO �Ȥ�Ǹ�
     *                  ID �Τ@�s��
     *                </pre>
     * @return ���������M��
     * @throws ModuleException
     * @throws SQLException
     */
    public List<Map> queryRcvInfoList(Map reqMap) throws ModuleException, SQLException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30010_MSG_005"));//�d��ú�O������Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
        if ("9".equals(PAY_KIND)) {
            ds.setField("PAY_KIND_9", PAY_KIND);
        } else if ("1".equals(PAY_KIND) || "2".equals(PAY_KIND) || "3".equals(PAY_KIND)) {
            ds.setField("PAY_KIND", PAY_KIND);
        } else if ("7".equals(PAY_KIND)) {
            ds.setField("PAY_KIND_7", "7");
        }
        setFieldsIfExsits(reqMap, ds, "RCV_YM");
        setFieldValuesIfExsits(reqMap, ds, "BLD_CD");
        setFieldValuesIfExsits(reqMap, ds, "CRT_NO");
        setFieldValuesIfExsits(reqMap, ds, "CUS_NO");
        setFieldValuesIfExsits(reqMap, ds, "ID");
        List<Map> RCV_INFO_LIST;
        try {
            RCV_INFO_LIST = VOTool.findToMaps(ds, SQL_queryRcvInfoList_001);
            //�v���B�zRCV_INFO_LIST�A��RCV_INFO_MAP�զ�
            EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
            for (Map RCV_INFO_MAP : RCV_INFO_LIST) {

                String BLD_CD = MapUtils.getString(RCV_INFO_MAP, "BLD_CD");

                //ú�ں���
                RCV_INFO_MAP.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND_ONE", MapUtils.getString(RCV_INFO_MAP, "PAY_KIND")));

                RCV_INFO_MAP.put("BAL_TYPE", theEP_Z0G103.getBAL_TYPE(SUB_CPY_ID, BLD_CD));

            }
        } catch (DataNotFoundException dnfe) {
            throw dnfe;
        } catch (Exception e) {
            log.error("���o���������M��o�Ϳ��~", e);
            throw new ModuleException(MessageUtil.getMessage("EP_C30010_MSG_001"));//���o���������M��o�Ϳ��~
        }

        return RCV_INFO_LIST;
    }

    /**
     * ���oú�O������T
     * @param reqMap <pre>
     *              SUB_CPY_ID �����q�O
     *              RCV_YM �����~��
     *              BLD_CD �j�ӥN��
     *              CRT_NO �����N��
     *              CUS_NO �Ȥ�Ǹ�
     *              ID �Τ@�s��
     *              </pre>
     * @return PAY_INFO_LIST ú�O�����M��
     * @throws ModuleException
     */
    public List<Map> queryPayInfoList(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30010_MSG_005"));//�d��ú�O������Ƭ���
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30010_MSG_002"));//�����q�O���o���ŭ�
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
        if ("9".equals(PAY_KIND)) {
            ds.setField("PAY_KIND_9", PAY_KIND);
        } else if ("1".equals(PAY_KIND) || "2".equals(PAY_KIND) || "3".equals(PAY_KIND)) {
            ds.setField("PAY_KIND", PAY_KIND);
        } else if ("7".equals(PAY_KIND)) {
            ds.setField("PAY_KIND_7", "7");
        }
        setFieldsIfExsits(reqMap, ds, "RCV_YM");
        setFieldValuesIfExsits(reqMap, ds, "BLD_CD");
        setFieldValuesIfExsits(reqMap, ds, "CRT_NO");
        setFieldValuesIfExsits(reqMap, ds, "CUS_NO");
        setFieldValuesIfExsits(reqMap, ds, "ID");
        try {
            DBUtil.searchAndRetrieve(ds, SQL_queryPayInfoList_001);
            List<Map> rtnList = new ArrayList<Map>();
            while (ds.next()) {
                Map rtnMap = VOTool.dataSetToMap(ds);
                rtnMap.put("CHK_CD_NM", FieldOptionList.getName("EP", "CHK_CD", MapUtils.getString(rtnMap, "CHK_CD")));
                //ú�ں���
                rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EP", "PAY_KIND", MapUtils.getString(rtnMap, "PAY_KIND")));
                rtnMap.put("PAY_TYPE_NM", FieldOptionList.getName("EPC", "PAY_TYPE", MapUtils.getString(rtnMap, "PAY_TYPE")));

                rtnList.add(rtnMap);
            }
            return rtnList;
        } catch (DataNotFoundException dnfe) {
            throw dnfe;
        } catch (Exception e) {
            log.error("���oú�ڬ�����T�o�Ϳ��~", e);
            throw new ModuleException(MessageUtil.getMessage("EP_C30010_MSG_003"));//���oú�ڬ�����T�o�Ϳ��~
        }
    }

    /**
     * ���oú�ڬ�����T
     * @param PAY_NO ú�O�s��
     * @return ú�ڬ�����T
     * @throws ModuleException
     */
    public Map queryPayInfoMap(String PAY_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(PAY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30010_MSG_004"));//ú�O�s�����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30010_MSG_002"));//�����q�O���o���ŭ�
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        try {
            return VOTool.findOneToMap(ds, SQL_queryPayInfoMap_001);
        } catch (DataNotFoundException dnfe) {
            throw dnfe;
        } catch (Exception e) {
            log.error("���oú�ڬ�����T�o�Ϳ��~", e);
            throw new ModuleException(MessageUtil.getMessage("EP_C30010_MSG_003"));//���oú�ڬ�����T�o�Ϳ��~
        }
    }

    /**
     * �]�w�d�߸��
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setFieldsIfExsits(Map reqMap, DataSet ds, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * �]�w�d�߸��
     * @param reqMap
     * @param ds
     * @param key
     */
    private void setFieldValuesIfExsits(Map reqMap, DataSet ds, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setFieldValues(key, value.split(","));
        }

    }

}
