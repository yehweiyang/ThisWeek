package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * 
<pre> 
Date    Version Description Author
2013/08/28  1.0 Created ����ʹ

�{���\�෧�n�����G
    �ҲզW��    ú�ڬ������@�Ҳ�
    �Ҳ�ID    EP_C32010
    ���n����    ú�ڬ������@
</pre>
 * @author ���t�s
 * @since 2014/1/2
 */

@SuppressWarnings("unchecked")
public class EP_C32010 {

    private static final String SQL_doQuery_001 = "com.cathay.ep.c3.module.EP_C32010.SQL_doQuery_001";

    /** ú�ں���PAY_KIND��1�A�d��ú�ں���1,4,5,7,8 */
    private static final String[] QUERY_PAY_KIND_1 = { "1", "4", "5", "7", "8" };//�s�W�{��

    /**
     * �dú�ڬ������
     * @param reqMap
     * @return
     * @throws Exception 
     */
    public List<Map> doQuery(Map reqMap, UserObject user, ResponseContext resp) throws Exception {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32010_MSG_001")); //�d��ú�ڸ�Ƥ��o���ŭ� 
        }
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        String ID = MapUtils.getString(reqMap, "ID");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
        String PAY_NOs = MapUtils.getString(reqMap, "PAY_NOs");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(BLD_CD) && StringUtils.isBlank(ID) && StringUtils.isBlank(CRT_NO) && StringUtils.isBlank(ACNT_DATE)
                && StringUtils.isBlank(PAY_NOs)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32010_MSG_005")); //�j�ӥN���B�Τ@�s���B�����N���B�ǲ�������ܤ@��J
        }
        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");

        if ((StringUtils.isNotBlank(BLD_CD) || StringUtils.isNotBlank(ID)) && !"2".equals(MapUtils.getString(reqMap, "PAY_KIND"))
                && StringUtils.isBlank(RCV_YM)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32010_MSG_006")); //�Y��J�j�ӥN���βΤ@�s���A�h�����~�륲��
        }

        if ("Y".equals(MapUtils.getString(reqMap, "IS_EXPORT_XLS"))) {//�ץX xls

            BatchQueryDataSet bqds = null;
            try {
                String fileName = MapUtils.getString(reqMap, "fileName");
                XlsUtils xlsUtils = new XlsUtils(URLEncoder.encode(fileName, "UTF-8"), resp);

                bqds = Transaction.getBatchQueryDataSet();
                this.setFieldByQueryMap(reqMap, bqds);

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
                LocaleDisplay locale = new LocaleDisplay("EP", user);
                String gridJSON = MapUtils.getString(reqMap, "gridJSON");

                Map<String, Object> dataTotalMap = new HashMap<String, Object>();

                bqds.searchAndRetrieve(SQL_doQuery_001);

                List<Map> rtnList = new ArrayList();
                if (xlsUtils != null) {

                    xlsUtils.initBatchExportSetting(gridJSON, 1, dataTotalMap);

                    while (xlsUtils.fetchData(bqds)) {

                        while (xlsUtils.next(bqds)) {
                            Map rtnMap = xlsUtils.getCurrentMap();
                            rtnList.add(rtnMap);
                            String tmpCHK_CD = MapUtils.getString(rtnMap, "CHK_CD", "");
                            String tmpPAY_KIND = MapUtils.getString(rtnMap, "PAY_KIND", "");
                            String tmpPAY_TYPE = MapUtils.getString(rtnMap, "PAY_TYPE", "");
                            String tmpSWP_KIND = MapUtils.getString(rtnMap, "SWP_KIND", "");

                            String theCHK_CD = FieldOptionList.getName("EP", "CHK_CD", tmpCHK_CD);
                            String thePAY_KIND = FieldOptionList.getName("EPC", "PAY_KIND", tmpPAY_KIND);
                            String thePAY_TYPE = FieldOptionList.getName("EPC", "PAY_TYPE", tmpPAY_TYPE);
                            String theSWP_KIND = FieldOptionList.getName("EP", "SWP_KIND", tmpSWP_KIND);

                            rtnMap.put("CHK_CD_NM", StringUtils.isNotBlank(theCHK_CD) ? theCHK_CD : tmpCHK_CD);
                            rtnMap.put("PAY_KIND_NM", StringUtils.isNotBlank(thePAY_KIND) ? thePAY_KIND : tmpPAY_KIND);
                            rtnMap.put("PAY_TYPE_NM", StringUtils.isNotBlank(thePAY_TYPE) ? thePAY_TYPE : tmpPAY_TYPE);
                            rtnMap.put("SWP_KIND_NM", StringUtils.isNotBlank(theSWP_KIND) ? theSWP_KIND : tmpSWP_KIND);

                            //�~��B�z
                            rtnMap.put("RCV_YM", locale.formatDateym(MapUtils.getString(rtnMap, "RCV_YM"), ""));

                            //����B�z
                            String tmpRMT_DATE = MapUtils.getString(rtnMap, "RMT_DATE");
                            String tmpCHK_DATE = MapUtils.getString(rtnMap, "CHK_DATE");
                            String tmpCOA_DATE = MapUtils.getString(rtnMap, "COA_DATE");
                            String tmpACNT_DATE = MapUtils.getString(rtnMap, "ACNT_DATE");
                            String tmpSWP_DATE = MapUtils.getString(rtnMap, "SWP_DATE");
                            rtnMap.put("RMT_DATE", StringUtils.isNotBlank(tmpRMT_DATE) ? locale.formatDate(new Date(sdf.parse(tmpRMT_DATE)
                                    .getTime()), "/", "") : "");//�״ڤ�
                            rtnMap.put("CHK_DATE", StringUtils.isNotBlank(tmpCHK_DATE) ? locale.formatDate(new Date(sdf.parse(tmpCHK_DATE)
                                    .getTime()), "/", "") : "");//�䲼��
                            rtnMap.put("COA_DATE", StringUtils.isNotBlank(tmpCOA_DATE) ? locale.formatDate(new Date(sdf.parse(tmpCOA_DATE)
                                    .getTime()), "/", "") : "");//�Ȧ�P�b��
                            rtnMap.put("ACNT_DATE", StringUtils.isNotBlank(tmpACNT_DATE) ? locale.formatDate(new Date(sdf.parse(
                                tmpACNT_DATE).getTime()), "/", "") : "");//�Ȧ�P�b��

                            rtnMap.put("SWP_DATE", StringUtils.isNotBlank(tmpSWP_DATE) ? locale.formatDate(new Date(sdf.parse(tmpSWP_DATE)
                                    .getTime()), "/", "") : "");//��X���

                            xlsUtils.batchCreateXls();
                        }
                    }
                }

                return rtnList;
            } finally {
                if (bqds != null) {
                    bqds.close();
                }
            }
        } else {
            DataSet ds = Transaction.getDataSet();
            this.setFieldByQueryMap(reqMap, ds);
            List<Map> rtnList = VOTool.findToMaps(ds, SQL_doQuery_001);
            for (Map rtnMap : rtnList) {

                String tmpCHK_CD = MapUtils.getString(rtnMap, "CHK_CD", "");
                String tmpPAY_KIND = MapUtils.getString(rtnMap, "PAY_KIND", "");
                String tmpPAY_TYPE = MapUtils.getString(rtnMap, "PAY_TYPE", "");
                String tmpSWP_KIND = MapUtils.getString(rtnMap, "SWP_KIND", "");

                String theCHK_CD = FieldOptionList.getName("EP", "CHK_CD", tmpCHK_CD);
                String thePAY_KIND = FieldOptionList.getName("EPC", "PAY_KIND", tmpPAY_KIND);
                String thePAY_TYPE = FieldOptionList.getName("EPC", "PAY_TYPE", tmpPAY_TYPE);
                String theSWP_KIND = FieldOptionList.getName("EP", "SWP_KIND", tmpSWP_KIND);

                rtnMap.put("CHK_CD_NM", StringUtils.isNotBlank(theCHK_CD) ? theCHK_CD : tmpCHK_CD);
                rtnMap.put("PAY_KIND_NM", StringUtils.isNotBlank(thePAY_KIND) ? thePAY_KIND : tmpPAY_KIND);
                rtnMap.put("PAY_TYPE_NM", StringUtils.isNotBlank(thePAY_TYPE) ? thePAY_TYPE : tmpPAY_TYPE);
                rtnMap.put("SWP_KIND_NM", StringUtils.isNotBlank(theSWP_KIND) ? theSWP_KIND : tmpSWP_KIND);

            }
            return rtnList;
        }

    }

    /**
     * �C�L�榡�]�w
     * @param reqMap
     * @param rtnList
     * @param user
     * @param resp
     * @return
     */
    public Map doFmtRpt(Map reqMap, List<Map> rtnList, UserObject user, ResponseContext resp) throws ErrorInputException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C32010_MSG_001")); //�d��ú�ڸ�Ƥ��o���ŭ� 
        }
        LocaleDisplay locale = new LocaleDisplay("EP", user);
        Map<String, BigDecimal> totalMap = new HashMap<String, BigDecimal>();
        String[] totColumns = new String[] { "PAY_AMT" };
        for (Map rtnMap : rtnList) {
            for (Object every_key : rtnMap.keySet()) {
                Object obj = MapUtils.getObject(rtnMap, every_key, "");
                if ("RCV_YM".equals(every_key)) {
                    rtnMap.put(every_key, locale.formatDateym(obj, ""));
                } else if (BigDecimal.class.isInstance(obj)) {
                    if (ArrayUtils.contains(totColumns, every_key)) {
                        totalMap.put(every_key.toString(), STRING.objToBigDecimal(totalMap.get(every_key), BigDecimal.ZERO).add(
                            STRING.objToBigDecimal(obj, BigDecimal.ZERO)));
                    }
                    rtnMap.put(every_key, locale.formatNumber(obj, 0, "0"));
                } else if (Date.class.isInstance(obj)) {
                    rtnMap.put(every_key, locale.formatDate((Date) obj, "/", ""));
                } else {
                    rtnMap.put(every_key, obj.toString());
                }
            }
        }

        int rtnSize = 0;
        if (rtnList != null && !rtnList.isEmpty()) {
            rtnSize = rtnList.size();
            rtnList.get(rtnSize - 1).put("IS_SUMMARY", "Y");
        }
        Map params = new HashMap();
        params.put("REPORT_ID", "EP_C32010");
        params.put("CURRENT_DATE", locale.formatDate(DATE.today(), "/", ""));
        params.put("SIZE", locale.formatNumber(rtnSize, 0, "0"));
        for (String every_key : totalMap.keySet()) {
            params.put("TOT_" + every_key, locale.formatNumber(totalMap.get(every_key), 0, "0"));
        }
        Map rtnMap = new HashMap();
        rtnMap.put("params", params);
        rtnMap.put("detail", rtnList);
        return rtnMap;
    }

    /**
     * �C�L
     * @param reqMap
     */
    public void print(Map reqMap, ResponseContext resp) {

        JasperReportUtils.addOutputRptDataToResp("EP_C32010", (Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), resp);
    }

    /**
     * �Nmap���o����নDate
     * @param map
     * @param key
     * @param defaultKey
     * @return
     */
    private Date obj2Date(Map map, String key, Date defaultKey) {
        Object o = MapUtils.getObject(map, key);
        if (o != null) {
            if (o instanceof Date) {
                return (Date) o;
            }
            String ostr = o.toString();
            if (DATE.isDate(ostr)) {
                return Date.valueOf(ostr);
            }
        }
        return defaultKey;
    }

    /**
     * set�d�߰Ѽ�
     * @param reqMap
     * @param ds
     */
    private void setFieldByQueryMap(Map reqMap, DataSet ds) {

        //ú�ں���
        String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
        if (StringUtils.isNotBlank(PAY_KIND)) {
            if ("1".equals(PAY_KIND)) {
                ds.setFieldValues("PAY_KIND_1", QUERY_PAY_KIND_1);
            } else {
                ds.setField("PAY_KIND_2", PAY_KIND);
            }
        }
        ds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        String PAY_NOs = MapUtils.getString(reqMap, "PAY_NOs");
        if (StringUtils.isNotBlank(PAY_NOs)) {
            String[] PAY_NO_arr = PAY_NOs.split(",");
            ds.setFieldValues("PAY_NOS", PAY_NO_arr);
        } else {
            setFieldIfMapExist(reqMap, "ACNT_DIV_NO", ds);
            setFieldIfMapExist(reqMap, "INPUT_NAME", ds);
            setFieldIfMapExist(reqMap, "CRT_NO", ds); //�����N��
            setFieldIfMapExist(reqMap, "CUS_NO", ds);
            setFieldIfMapExist(reqMap, "BLD_CD", ds);
            setFieldIfMapExist(reqMap, "ID", ds);
            setFieldIfMapExist(reqMap, "RCV_YM", ds);
            Date ACNT_DATE = obj2Date(reqMap, "ACNT_DATE", null);
            if (ACNT_DATE != null) {
                ds.setField("ACNT_DATE", ACNT_DATE);
            }
        }
    }

    /**
     * Map ���Ȥ~�]
     * @param reqMap
     * @param key
     * @param ds
     */
    private void setFieldIfMapExist(Map reqMap, String key, DataSet ds) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

}
