package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.Id;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dj.a0.bo.DJ_A0Z016_vo;
import com.cathay.dj.a0.module.DJ_A0Z016;
import com.cathay.dk.bo.DTDKG002;
import com.cathay.dk.f0.bo.DK_F0Z006_bo;
import com.cathay.dk.f0.module.DK_F0Z006;
import com.cathay.dk.g0.module.DK_G0Z002;
import com.cathay.ep.vo.DTEPC309;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C101;
import com.cathay.ep.z0.module.EP_Z0C304;
import com.cathay.ep.z0.module.EP_Z0C309;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.MessageUtil;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * 
 <pre>
 * DATE Description Author
 * 2013/10/01   Created ���i��
 * �@�B   �{���\�෧�n�����G
 * �ҲզW�� ú�O��X�@�~���@�Ҳ�
 * �Ҳ�ID EP_C30070
 * ���n���� ú�O��X�@�~���@�Ҳ�
 * [20180207] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * </pre>
 * 
 * @author ���t�s
 * @since 2013/11/27
 */

@SuppressWarnings("unchecked")
public class EP_C30070 {
    private static final Logger log = Logger.getLogger(EP_C30070.class);

    private static final String SQL_query_001 = "com.cathay.ep.c3.module.EP_C30070.SQL_query_001";

    private static final String SQL_query_002 = "com.cathay.ep.c3.module.EP_C30070.SQL_query_002";

    private static final String SQL_query_003 = "com.cathay.ep.c3.module.EP_C30070.SQL_query_003";

    private static final String SQL_query2_001 = "com.cathay.ep.c3.module.EP_C30070.SQL_query2_001";

    private static final String SQL_query3_001 = "com.cathay.ep.c3.module.EP_C30070.SQL_query3_001";

    private static final String SQL_query4_001 = "com.cathay.ep.c3.module.EP_C30070.SQL_query4_001";

    //private static final String SQL_query5_001 = "com.cathay.ep.c3.module.EP_C30070.SQL_query5_001";

    //private static final String SQL_delete_001 = "com.cathay.ep.c3.module.EP_C30070.SQL_delete_001";

    //private static final String SQL_delete_002 = "com.cathay.ep.c3.module.EP_C30070.SQL_delete_002";

    private static final String SQL_delete_003 = "com.cathay.ep.c3.module.EP_C30070.SQL_delete_003";

    private static final String SQL_delete_004 = "com.cathay.ep.c3.module.EP_C30070.SQL_delete_004";

    private static final String SQL_delete_005 = "com.cathay.ep.c3.module.EP_C30070.SQL_delete_005";

    private static final String SQL_delete_006 = "com.cathay.ep.c3.module.EP_C30070.SQL_delete_006";

    private static final String SQL_delete_007 = "com.cathay.ep.c3.module.EP_C30070.SQL_delete_007";

    private static final String SQL_insert_001 = "com.cathay.ep.c3.module.EP_C30070.SQL_insert_001";

    //private static final String SQL_insert_002 = "com.cathay.ep.c3.module.EP_C30070.SQL_insert_002";

    //private static final String SQL_insert_003 = "com.cathay.ep.c3.module.EP_C30070.SQL_insert_003";

    //private static final String SQL_insert_004 = "com.cathay.ep.c3.module.EP_C30070.SQL_insert_004";

    private static final String SQL_insert_005 = "com.cathay.ep.c3.module.EP_C30070.SQL_insert_005";

    //private static final String SQL_insert_006 = "com.cathay.ep.c3.module.EP_C30070.SQL_insert_006";

    //private static final String SQL_insert_007 = "com.cathay.ep.c3.module.EP_C30070.SQL_insert_007";

    private boolean isDebug = log.isDebugEnabled();

    /**
     * �d��ú�O����X���
     * @param QUERY_TYPE �d�ߺ���
     * @param PAY_KIND ú�ں���
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param SUB_CPY_ID �����q�O
     * @return ú�O����X���
     * @throws ModuleException
     */
    public List<Map> query(String QUERY_TYPE, String PAY_KIND, String CRT_NO, String CUS_NO, String RCV_YM_S, String RCV_YM_E,
            String SUB_CPY_ID) throws ModuleException {

        // ��J�Ѽ��ˮ�
        ErrorInputException eie = null;
        if (StringUtils.isBlank(QUERY_TYPE)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_001")); //�d�ߺ������i���ť�
        }
        if (StringUtils.isBlank(PAY_KIND)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_002")); //ú�ں������i���ť�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_003")); //�����N�����i���ť�
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_004")); //�Ȥ�Ǹ����i���ť�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        List<Map> rtnList;
        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_KIND", PAY_KIND);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if (StringUtils.isNotBlank(RCV_YM_S)) {
            ds.setField("RCV_YM_S", RCV_YM_S);
        }
        if (StringUtils.isNotBlank(RCV_YM_E)) {
            ds.setField("RCV_YM_E", RCV_YM_E);
        }
        if ("0".equals(QUERY_TYPE)) {
            //�d��ú�O���� [20180301]  �ק�sql
            rtnList = VOTool.findToMaps(ds, SQL_query_001);
        } else if ("1".equals(QUERY_TYPE)) {
            //�d����X����     
            /* [20180301] �[�P�_��  */
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                rtnList = VOTool.findToMaps(ds, SQL_query_002);
            } else {
                /* [20180301]�D���*/
                rtnList = VOTool.findToMaps(ds, SQL_query_003);
            }
        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30070_MSG_005")); //�d�ߺ�����Ʈ榡���~
        }

        //DK_F0Z006 dK_F0Z006 = new DK_F0Z006();
        //ReturnMessage rm = new ReturnMessage();
        int i = 1;
        //        DK_F0Z006 theDK_F0Z006 = new DK_F0Z006();
        //        ReturnMessage rm = new ReturnMessage();
        for (Map map : rtnList) {
            ds.clear();
            String PAY_TYPE = MapUtils.getString(map, "PAY_TYPE");
            String CHK_CD = MapUtils.getString(map, "CHK_CD");

            // �d����X��������
            map.put("SWP_KIND_NM", FieldOptionList.getName("EP", "SWP_KIND", MapUtils.getString(map, "SWP_KIND")));

            // �d��ú�O�覡����
            map.put("PAY_TYPE_NM", FieldOptionList.getName("EP", "PAY_TYPE", PAY_TYPE));

            // �d�߲��p����
            map.put("CHK_CD_NM", FieldOptionList.getName("EP", "CHK_CD", CHK_CD));

            map.put("Order", i++);

            if ("0".equals(QUERY_TYPE)) {
                //20150312 AllenTsai 20150312 �d�ߵ��G�S���ϥ�
                //                String ACNT_DATE = MapUtils.getString(map, "ACNT_DATE", "");
                //                String ACNT_DIV_NO = MapUtils.getString(map, "ACNT_DIV_NO", "");
                //                String SLIP_LOT_NO = MapUtils.getString(map, "SLIP_LOT_NO", "");
                //                String SLIP_SET_NO = MapUtils.getString(map, "SLIP_SET_NO", "");
                //DK_F0Z006_bo bo = theDK_F0Z006.getStatusBySLIP_SET_NO(ACNT_DIV_NO, ACNT_DATE, SLIP_LOT_NO, SLIP_SET_NO, rm);
                //                if (rm.getReturnCode() != ReturnCode.OK) {
                //                    throw new ModuleException("�d��ú�O�b�Ȫ��A���~�A" + rm.getMsgDesc());
                //                }

                if ("5".equals(PAY_TYPE) && !"1".equals(CHK_CD)) {
                    map.put("ENABLE_WASH", "N"); //�Y���ڥ��I�{�A�h���i����ú�O��X                
                    //                } else if(!"1".equals(bo.getDAY_BALANCE_IND()) || !"2".equals(bo.getACNT_STS())) {
                    //                    map.put("ENABLE_WASH", "N");  //�Y�ǲ����X�b�γQ�h��A�h���i����ú�O��X
                } else {
                    map.put("ENABLE_WASH", "Y");
                }

            } else {
                String S_ACNT_DATE = MapUtils.getString(map, "S_ACNT_DATE", "");
                if (StringUtils.isNotBlank(S_ACNT_DATE) && !"null".equals(S_ACNT_DATE)) { //�Yú�O��X�w�X�b�A�h���i�����C
                    map.put("ENABLE_WASH", "N");
                } else {
                    map.put("ENABLE_WASH", "Y");
                }
            }

        }

        return rtnList;
    }

    /**
     * �d�߫Ȥ���
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @return �Ȥ���
     * @throws ModuleException
     */
    public Map query2(String CRT_NO, String CUS_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        // ���o�Ȥ��ƨæ^��
        return selectMap(CRT_NO, CUS_NO, SQL_query2_001, true, SUB_CPY_ID);
    }

    /**
     * �d�������l�B���
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @return �����l�B���
     * @throws ModuleException
     */
    public Map query3(String CRT_NO, String CUS_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        // ���o�����l�B��ƨæ^��
        return selectMap(CRT_NO, CUS_NO, SQL_query3_001, false, SUB_CPY_ID);
    }

    /**
     * �d�߼Ȧ��l�B���
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param SUB_CPY_ID �����q�O
     * @return �Ȧ��l�B���
     * @throws ModuleException
     */
    public Map query4(String CRT_NO, String CUS_NO, String SUB_CPY_ID) throws ModuleException {
        Map G002_MAP = null;
        //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
        //��ؤ~�|�X�b
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {
            //���o�Ȧ��l�B��ƨæ^��
            G002_MAP = selectMap(CRT_NO, CUS_NO, SQL_query4_001, false, "");
        } else {
            // [20180301]�D��ا�gEP.�Ȧ���
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            reqMap.put("CRT_NO", CRT_NO);
            reqMap.put("CUS_NO", CUS_NO);
            try {
                List<Map> C309List = new EP_Z0C309().queryC309hasBALAMT(reqMap);// �Y�d�L��ƫh�������`�C
                G002_MAP = C309List.get(0);
            } catch (DataNotFoundException dnfe) {
                // �Y�d�L��ƫh�������`�C
                log.error("�d�L�Ȧ��l�B���");
            }
        }
        return G002_MAP;
    }

    /** ����EP_Z0C304:SQL�Ҳդ�
     * �d����Xú�ڬ���
     * @param RCV_YM �����~��
     * @param PAY_NO ú�O�s��
     * @param SWP_DATE ��X���
     * @return ��Xú�ڬ������
     * @throws ModuleException
     */
    /*
    public Map query5(String RCV_YM, String PAY_NO, String SWP_DATE) throws ModuleException {
        // ��J�Ѽ��ˮ�
        ErrorInputException eie = null;
        if (StringUtils.isBlank(RCV_YM)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_006")); //�����~�뤣�i���ť�
        }
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_007")); //ú�O�s�����i���ť�
        }
        if (StringUtils.isBlank(SWP_DATE) || !DATE.isDate(SWP_DATE)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_008")); //��X������i���ťեB�ݬ����T����榡
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("SWP_DATE", SWP_DATE);

        return VOTool.findOneToMap(ds, SQL_query5_001, false);
    }*/

    /**
     * �s�W��Xú�ڬ���
     * @param reqMap ��Xú�ڬ������
     * @throws Exception
     */
    public void insert(Map reqMap) throws Exception {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30070_MSG_009")); //��J��Ƥ��o����
        }

        //20150312 AllenTsai 20150312 �d�ߵ��G�S���ϥ�
        String ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE", "");
        String ACNT_DIV_NO = MapUtils.getString(reqMap, "ACNT_DIV_NO", "");
        String SLIP_LOT_NO = MapUtils.getString(reqMap, "SLIP_LOT_NO", "");
        String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO", "");
        log.debug("## ACNT_DATE:" + ACNT_DATE);
        log.debug("## ACNT_DIV_NO:" + ACNT_DIV_NO);
        log.debug("## SLIP_LOT_NO:" + SLIP_LOT_NO);
        log.debug("## SLIP_SET_NO:" + SLIP_SET_NO);

        DK_F0Z006 theDK_F0Z006 = new DK_F0Z006();
        ReturnMessage rm = new ReturnMessage();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

        //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
        //��ؤ~�|�X�b
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
            DK_F0Z006_bo bo = theDK_F0Z006.getStatusBySLIP_SET_NO(ACNT_DIV_NO, ACNT_DATE, SLIP_LOT_NO, SLIP_SET_NO, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException("�d��ú�O�b�Ȫ��A���~�A" + rm.getMsgDesc());
            }
        }

        String RCV_NO = MapUtils.getString(reqMap, "RCV_NO");
        BigDecimal RCV_YM = obj2Big(reqMap, "RCV_YM", null);
        String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        Integer CUS_NO = obj2Int(reqMap, "CUS_NO", null);
        String C_CRT_NO = MapUtils.getString(reqMap, "C_CRT_NO");
        String C_CUS_NO = MapUtils.getString(reqMap, "C_CUS_NO");

        Date SWP_DATE = obj2Date(reqMap, "SWP_DATE", null);

        StringBuilder sb = new StringBuilder();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_010")); //�����q�O��Ƥ��o����
        }
        if (StringUtils.isBlank(RCV_NO)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_011")); //�����s�����o����
        }
        if (RCV_YM == null) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_012")); //��ú�~��s�����o����
        }
        if (StringUtils.isBlank(PAY_KIND)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_013")); //ú�ں������o����
        }
        if (StringUtils.isBlank(CRT_NO)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_003")); //�����N�����o����
        }
        if (CUS_NO == null) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_004")); //�Ȥ�Ǹ����o����
        }
        if ("2".equals(PAY_KIND) && SWP_DATE == null) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_015")); //��X������o���ŭ�            
        }

        if (sb.length() != 0) {
            throw new ErrorInputException(sb.insert(0, MessageUtil.getMessage("EP_C30070_MSG_014")).toString()); //��Xú�ڬ�����Ʀ��~:
        }

        String thisYear = DATE.getY2KYear(DATE.getDBDate());
        int tmpSER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "023", thisYear, "1");

        //���o��X�s��
        String EXT_NO = sb.append(SUB_CPY_ID).append(thisYear).append(
            STRING.fillZero(String.valueOf(tmpSER_NO), 4, EncodingHelper.DefaultCharset)).toString();
        String PAY_NO = MapUtils.getString(reqMap, "PAY_NO");

        //���o��X��w�P��X�b��
        String D_ACPT_BANK_NO = MapUtils.getString(reqMap, "D_ACPT_BANK_NO");
        String D_ACPT_ACNT_NO = MapUtils.getString(reqMap, "D_ACPT_ACNT_NO");
        String RMT_BANK_NO = null;
        String RMT_ACNT_NO = null;
        if (StringUtils.isNotBlank(D_ACPT_BANK_NO) && StringUtils.isNotBlank(D_ACPT_ACNT_NO)) {
            //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                DJ_A0Z016_vo dJ_A0Z016_vo = DJ_A0Z016.getRmtBankInfoByAcptBankNo(D_ACPT_BANK_NO, "NTD",
                    DJ_A0Z016.IF_NOT_FOUND_THEN_USE_DEFAULT);
                RMT_BANK_NO = dJ_A0Z016_vo.getRMT_BANK_NO();
                RMT_ACNT_NO = dJ_A0Z016_vo.getRMT_ACNT_NO();
            } else {
                //�D��إΥN�X����
                RMT_BANK_NO = FieldOptionList.getName("EP", "RMT_ACNT_NO_BY_" + SUB_CPY_ID, "RMT_BANK_NO");
                RMT_ACNT_NO = FieldOptionList.getName("EP", "RMT_ACNT_NO_BY_" + SUB_CPY_ID, "RMT_ACNT_NO");
            }
        }

        //�s�W��X����� 
        Timestamp currentTime = DATE.currentTime();
        String USER_ID = MapUtils.getString(reqMap, "USER_ID");
        String USER_NAME = MapUtils.getString(reqMap, "USER_NAME");
        String SWP_KIND = MapUtils.getString(reqMap, "SWP_KIND");
        String USER_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");
        BigDecimal PAY_AMT = obj2Big(reqMap, "PAY_AMT", BigDecimal.ZERO);
        String ID = MapUtils.getString(reqMap, "ID");

        //�]�w��X���ú���B      
        BigDecimal C301_PAY_AMT = null;
        BigDecimal SWP_AMT = BigDecimal.ZERO;
        BigDecimal D_PAY_AMT = obj2Big(reqMap, "D_PAY_AMT", BigDecimal.ZERO);
        if ("2".equals(SWP_KIND)) {
            C301_PAY_AMT = BigDecimal.ZERO;
            SWP_AMT = PAY_AMT;
        } else if ("1".equals(SWP_KIND)) {
            C301_PAY_AMT = PAY_AMT.subtract(D_PAY_AMT);
            SWP_AMT = D_PAY_AMT;
        } else if ("0".equals(SWP_KIND)) {//��X�J�Ȧ�
            if (!"2".equals(PAY_KIND)) {
                C301_PAY_AMT = BigDecimal.ZERO;
                SWP_AMT = PAY_AMT;
            } else {
                BigDecimal D_SWP_AMT = obj2Big(reqMap, "D_SWP_AMT", BigDecimal.ZERO);
                C301_PAY_AMT = PAY_AMT.subtract(D_SWP_AMT);
                SWP_AMT = D_SWP_AMT;
            }

        }
        if (isDebug) {
            log.debug("======C301_PAY_AMT=======" + C301_PAY_AMT);
            log.debug("======SWP_AMT=======" + SWP_AMT);
        }

        if (C301_PAY_AMT.compareTo(BigDecimal.ZERO) < 0) {
            throw new ModuleException("ú�O��X����ú�O���s�ɹ�ú���B���i�p��0�A�{���ú���B=" + PAY_AMT + ", ��X���B=" + SWP_AMT);
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("EXT_NO", EXT_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("PAY_KIND", PAY_KIND);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("ID", ID);
        ds.setField("CUS_NAME", MapUtils.getString(reqMap, "CUS_NAME"));
        ds.setField("BLD_CD", MapUtils.getString(reqMap, "BLD_CD"));
        ds.setField("PAY_TYPE", MapUtils.getString(reqMap, "D_PAY_TYPE"));
        ds.setField("SWP_KD", SWP_KIND);
        ds.setField("SWP_DATE", SWP_DATE);
        ds.setField("SWP_AMT", SWP_AMT);
        ds.setField("ACPT_BANK_NO", D_ACPT_BANK_NO);
        ds.setField("ACPT_ACNT_NO", MapUtils.getString(reqMap, "D_ACPT_ACNT_NO"));
        ds.setField("ACPT_ACNT_NAME", MapUtils.getString(reqMap, "D_ACPT_ACNT_NAME"));
        ds.setField("ACPT_ID", MapUtils.getString(reqMap, "D_ACPT_ID"));
        ds.setField("RMT_BANK_NO", RMT_BANK_NO);
        ds.setField("RMT_ACNT_NO", RMT_ACNT_NO);
        ds.setField("INPUT_ID", USER_ID);
        ds.setField("INPUT_NAME", USER_NAME);
        ds.setField("TRN_SER_NO", BigDecimal.ZERO);
        ds.setField("S_SLPSET_NO", "0");
        ds.setField("CHG_DATE", currentTime);
        ds.setField("CHG_DIV_NO", USER_DIV_NO);
        ds.setField("CHG_ID", USER_ID);
        ds.setField("CHG_NAME", USER_NAME);

        DBUtil.executeUpdate(ds, SQL_insert_005);

        //��sú�ڬ�����X�����X�����Ω㮧�פ�
        ds.clear();
        ds.setField("PAY_AMT", C301_PAY_AMT);
        ds.setField("ORN_AMT", PAY_AMT);
        ds.setField("SWP_KIND", SWP_KIND);
        ds.setField("SWP_DATE", SWP_DATE);
        ds.setField("CHG_DATE", currentTime);
        ds.setField("CHG_DIV_NO", USER_DIV_NO);
        ds.setField("CHG_ID", USER_ID);
        ds.setField("CHG_NAME", USER_NAME);
        if ("2".equals(PAY_KIND)) {
            ds.setField("PMI_E_DATE", DATE.addDate(SWP_DATE.toString(), 0, 0, -1));
        }

        ds.setField("RCV_NO", RCV_NO);
        ds.setField("PAY_NO", reqMap.get("PAY_NO"));
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("PAY_KIND", PAY_KIND);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_insert_001);

        //��sDTEPC306.PAY_AMT
        //        ds.clear();
        //        ds.setField("PAY_NO", PAY_NO);
        //        ds.setField("PAY_AMT1", SWP_AMT);
        //        DBUtil.executeUpdate(ds, SQL_insert_007);

        //update DTEPC101:�^�_�����l�B
        if (!"2".equals(PAY_KIND)) {//160126 modified by i9301216 : ��������s����������
            /*ds.clear();
            ds.setField("RCV_YM", RCV_YM);
            ds.setField("PAY_KIND", PAY_KIND);
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("CUS_NO", CUS_NO);
            ds.setField("RCV_NO", RCV_NO);
            Map C101_MAP = VOTool.findOneToMap(ds, SQL_insert_002);*/
            EP_Z0C101 theEP_Z0C101 = new EP_Z0C101();
            Map C101_MAP = theEP_Z0C101.queryByRcvNo(reqMap);

            BigDecimal SPR_AMT = null;
            BigDecimal C101_MAP_SPR_AMT = obj2Big(C101_MAP, "SPR_AMT", BigDecimal.ZERO);
            if ("0".equals(SWP_KIND) || "2".equals(SWP_KIND)) {
                SPR_AMT = C101_MAP_SPR_AMT.add(PAY_AMT);
            } else if ("1".equals(SWP_KIND)) {
                SPR_AMT = C101_MAP_SPR_AMT.add(D_PAY_AMT);
            }

            /*ds.clear();
            ds.setField("SPR_AMT", SPR_AMT);
            ds.setField("LST_PROC_DATE", currentTime);
            ds.setField("LST_PROC_ID", USER_ID);
            ds.setField("LST_PROC_DIV", USER_DIV_NO);
            ds.setField("LST_PROC_NAME", USER_NAME);
            ds.setField("RCV_NO", RCV_NO);
            DBUtil.executeUpdate(ds, SQL_insert_003);*/

            Map tmpMap = new HashMap();
            tmpMap.put("SPR_AMT", SPR_AMT);
            tmpMap.put("LST_PROC_DATE", currentTime);
            tmpMap.put("LST_PROC_ID", USER_ID);
            tmpMap.put("LST_PROC_DIV", USER_DIV_NO);
            tmpMap.put("LST_PROC_NAME", USER_NAME);
            tmpMap.put("RCV_NO", RCV_NO);
            tmpMap.put("SUB_CPY_ID", SUB_CPY_ID);
            theEP_Z0C101.updateSPR_AMTbyC304(tmpMap);
        }

        if ("0".equals(SWP_KIND) || "2".equals(SWP_KIND)) {
            String ID_KIND = "4";
            Id IDobj = new Id();
            if (StringUtils.isBlank(ID)) {
                ID_KIND = "4";
            } else if (ID.trim().length() == 8) {//�Τ@�s��
                if (IDobj.checkUniSN(ID)) {
                    ID_KIND = "3";
                }
            } else if (ID.trim().length() == 10) {
                if (IDobj.checkID1(ID)) {//�����Ҧr��
                    ID_KIND = "1";
                }
            } else {
                if (IDobj.checkID2(ID)) {//�@��
                    ID_KIND = "2";
                }
            }

            //            if ("6".equals(PAY_TYPE)) {
            //                //�]ú�O�覡=�R�Ȧ��^�A�h�d�߷���J�Ȧ����Ȧ��J�b�覡
            //                ds.clear();
            //                ds.setField("PAY_NO", MapUtils.getString(reqMap, "PAY_NO"));
            //                DBUtil.searchAndRetrieve(ds, SQL_insert_004);
            //            }

            //150513 modified SG�X��  
            String BAL_TYPE = new EP_Z0G103().getBAL_TYPE(SUB_CPY_ID, MapUtils.getString(reqMap, "BLD_CD"));
            //�]�wDTDKG002�n����POLICY_NO�MPAY_TIMES�ȡC
            String G002_POLICY_NO = "";
            String G002_PAY_TIMES = "";
            if ("0".equals(SWP_KIND)) {
                G002_POLICY_NO = CRT_NO;
                G002_PAY_TIMES = ObjectUtils.toString(CUS_NO);
                if ("2".equals(PAY_KIND)) {//��� ������X
                    BigDecimal D_SWP_AMT = obj2Big(reqMap, "D_SWP_AMT", BigDecimal.ZERO);//��X�J�Ȧ�  
                    PAY_AMT = D_SWP_AMT;//�Ȧ����B �P�Ȧ��l�B=��X���B
                }

            } else if ("2".equals(SWP_KIND)) {
                G002_POLICY_NO = C_CRT_NO;
                G002_PAY_TIMES = ObjectUtils.toString(C_CUS_NO);
            } else {
                throw new ModuleException("���~����X����=" + SWP_KIND);
            }

            DTDKG002 DTDKG002_BO = new DTDKG002();
            DTDKG002_BO.setSYS_NO("EP");
            DTDKG002_BO.setTRN_KIND("EPC370");
            DTDKG002_BO.setTMP_CD("A");
            if ("8300100".equals(USER_DIV_NO)) {
                DTDKG002_BO.setTMP_KIND("965");
            } else {
                DTDKG002_BO.setTMP_KIND("966");
            }

            DTDKG002_BO.setINPUT_CD("2");
            DTDKG002_BO.setACNT_AMT(PAY_AMT.toPlainString());
            DTDKG002_BO.setBAL_AMT(PAY_AMT.toPlainString());
            //            if ("1".equals(PAY_TYPE)) {
            //                DTDKG002_BO.setTMP_IN_CD("1");
            //            } else if ("4".equals(PAY_TYPE)) {
            //                DTDKG002_BO.setTMP_IN_CD("3");
            //            } else if ("6".equals(PAY_TYPE)) {
            ////                ds.next();
            ////                DTDKG002_BO.setTMP_IN_CD(ds.getField("TMP_IN_CD").toString());
            //                DTDKG002_BO.setTMP_IN_CD("1"); //�Y����ú�O�覡���R�Ȧ����ܡA�h��X�J�Ȧ��覡���{��
            //            } else if ("7".equals(PAY_TYPE)) {
            //                DTDKG002_BO.setTMP_IN_CD("4");
            //            } else if ("9".equals(PAY_TYPE)) {
            //                DTDKG002_BO.setTMP_IN_CD("B");
            //            }

            DTDKG002_BO.setTMP_IN_CD("D"); //�Ȧ��J�b�覡�@�ߩ���X

            DTDKG002_BO.setRESN_NO("27");
            DTDKG002_BO.setACPT_DIV_NO(USER_DIV_NO);
            DTDKG002_BO.setACPT_BANK_NO(MapUtils.getString(reqMap, "ACPT_BANK_NO"));
            DTDKG002_BO.setACPT_ACNT_NO(MapUtils.getString(reqMap, "ACPT_ACNT_NO"));
            DTDKG002_BO.setRCPT_NO(EXT_NO);
            DTDKG002_BO.setPOLICY_NO(G002_POLICY_NO);
            DTDKG002_BO.setPAY_TIMES(G002_PAY_TIMES);
            DTDKG002_BO.setCAT_PREM(PAY_KIND);
            DTDKG002_BO.setID_KIND(ID_KIND);
            DTDKG002_BO.setID(ID);
            DTDKG002_BO.setCST_NAME(MapUtils.getString(reqMap, "CUS_NAME"));
            DTDKG002_BO.setRETURN_IND("0");
            DTDKG002_BO.setCURR("NTD");
            DTDKG002_BO.setACNT_ID(USER_ID);
            DTDKG002_BO.setACNT_NAME(USER_NAME);
            DTDKG002_BO.setACNT_IN_DATE(DATE.getDBDate());
            DTDKG002_BO.setRTN_RCPT_NO(PAY_NO);
            //�]�w�Ȧ��b�U�O 
            new EP_C30020().setBAL_TYPEforDKG002(DTDKG002_BO, BAL_TYPE);
            //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                rm = new ReturnMessage();
                String TMP_NO = new DK_G0Z002().insertDTDKG002ForXA(DTDKG002_BO, rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(new StringBuilder(MessageUtil.getMessage("EP_C30070_MSG_017")).append(rm.getMsgDesc())
                            .toString()); //�s�W�Ȧ��J�b�ɥ���,
                }
                //�^��DTEPC306.TMP_NO
                //            ds.clear();
                //            ds.setField("TMP_NO", TMP_NO);
                //            ds.setField("PAY_NO", PAY_NO);
                //            DBUtil.executeUpdate(ds, SQL_insert_006);
            } else {
                // [20180301]�D��ا�gEP.�Ȧ���
                DTEPC309 C309VO = new DTEPC309();
                DTDKG002_BO.setACNT_IN_DATE(DATE.getDBTimeStamp());
                VOTool.copyVOFromTo(DTDKG002_BO, C309VO);
                C309VO.setLST_CHG_DATE(DATE.currentTime());
                C309VO.setACNT_IN_DATE(DATE.currentTime());
                C309VO.setSUB_CPY_ID(SUB_CPY_ID);
                new EP_Z0C309().insertDTEPC309(C309VO);
            }
        }

    }

    /**
     * �R��ú�O��X�������
     * @param reqMap ú�O��X�������
     * @throws Exception
     */
    public void delete(Map reqMap) throws Exception {

        // ��J�ˮ�
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30070_MSG_009")); //��J��Ƥ��o����
        }

        // �j�M����ˮ�
        String RCV_NO = MapUtils.getString(reqMap, "RCV_NO");
        String PAY_NO = MapUtils.getString(reqMap, "PAY_NO");
        String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
        String SWP_DATE = MapUtils.getString(reqMap, "SWP_DATE");
        String EXT_NO = MapUtils.getString(reqMap, "EXT_NO");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isBlank(RCV_NO)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_011")); //�����s����Ƥ��o����
        }
        if (StringUtils.isBlank(PAY_KIND)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_013")); //ú�ں�����Ƥ��o����
        }
        if (StringUtils.isBlank(CRT_NO)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_003")); //�����N����Ƥ��o����
        }
        if (StringUtils.isBlank(CUS_NO)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_004")); //�Ȥ�Ǹ���Ƥ��o����
        }
        if (StringUtils.isBlank(RCV_YM)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_006")); //�����~���Ƥ��o����
        }
        if (StringUtils.isBlank(SWP_DATE) || !DATE.isDate(SWP_DATE)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("EP_C30070_MSG_008")); //��X�����Ƥ��o���ũΤ���榡�����T
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            STRING.newLine(sb);
            sb.append(MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (sb.length() != 0) {
            throw new ErrorInputException(sb.toString());
        }

        EP_Z0C304 theEP_Z0C304 = new EP_Z0C304();
        DataSet ds = Transaction.getDataSet();
        // �d����X����ɸ��        
        Map C304_MAP = theEP_Z0C304.qryC304forDel(RCV_NO, PAY_KIND, CRT_NO, CUS_NO, RCV_YM, SWP_DATE, EXT_NO, SUB_CPY_ID, ds);
        if (C304_MAP == null || C304_MAP.isEmpty()) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30070_MSG_018")); //�d�L��X����
        }
        if (obj2Date(C304_MAP, "S_ACNT_DATE", null) != null) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30070_MSG_019")); //ú�O��X�w�g���b���o�����T�{!!
        }

        // �R����X����ɸ��
        theEP_Z0C304.deleteC304(RCV_NO, PAY_KIND, CRT_NO, CUS_NO, RCV_YM, SWP_DATE, EXT_NO, SUB_CPY_ID, ds);

        // �d��ú�O���p��� //150505 modify select by PK 
        ds.clear();
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("PAY_KIND", PAY_KIND);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        Map C301_MAP = VOTool.findOneToMap(ds, SQL_delete_003, false);
        if (C301_MAP == null || C301_MAP.isEmpty()) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30070_MSG_020")); //�d�Lú�O���p�ɸ��
        }

        // ��sú�O���p���
        ds.clear();
        String timestamp = DATE.getDBTimeStamp();
        BigDecimal c304SWP_AMT = obj2Big(C304_MAP, "SWP_AMT", BigDecimal.ZERO);
        BigDecimal temp_AMT = obj2Big(C301_MAP, "PAY_AMT", BigDecimal.ZERO).add(c304SWP_AMT);
        String USER_ID = MapUtils.getString(reqMap, "USER_ID");
        String USER_DIV_NO = MapUtils.getString(reqMap, "USER_DIV_NO");
        String USER_NAME = MapUtils.getString(reqMap, "USER_NAME");

        ds.setField("PAY_AMT", temp_AMT);
        ds.setField("TRN_DATE", timestamp);
        ds.setField("CHG_DATE", timestamp);
        ds.setField("CHG_DIV_NO", USER_DIV_NO);
        ds.setField("CHG_ID", USER_ID);
        ds.setField("CHG_NAME", USER_NAME);
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("PAY_KIND", PAY_KIND);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_delete_004);

        //��sDTEPC306.PAY_AMT
        //        ds.clear();
        //        ds.setField("PAY_NO", PAY_NO);
        //        ds.setField("PAY_AMT2", c304SWP_AMT);
        //        DBUtil.executeUpdate(ds, SQL_insert_007);

        // �d�������ɸ��
        if (!"2".equals(PAY_KIND)) {
            ds.clear();
            ds.setField("PAY_KIND", PAY_KIND);
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("CUS_NO", CUS_NO);
            ds.setField("RCV_YM", RCV_YM);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            paySEdateSet(ds, C301_MAP);

            Map C101_MAP = VOTool.findOneToMap(ds, SQL_delete_005, false);
            if (C101_MAP == null || C101_MAP.isEmpty()) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30070_MSG_021")); //�d�L�����ɸ��
            }

            temp_AMT = obj2Big(C101_MAP, "SPR_AMT", BigDecimal.ZERO).subtract(c304SWP_AMT);

            //��s�����ɪ��p 
            ds.clear();
            ds.setField("SPR_AMT", temp_AMT);
            ds.setField("LST_PROC_DATE", timestamp);
            ds.setField("LST_PROC_ID", USER_ID);
            ds.setField("LST_PROC_DIV", USER_DIV_NO);
            ds.setField("LST_PROC_NAME", USER_NAME);
            ds.setField("PAY_KIND", PAY_KIND);
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("CUS_NO", CUS_NO);
            ds.setField("RCV_YM", RCV_YM);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            paySEdateSet(ds, C301_MAP);

            int items = DBUtil.executeUpdate(ds, SQL_delete_006);
            if (items > 1) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30070_MSG_022")); //��s�۹��������ɦ��~�]�@���H�W�^
            }
        }

        // �d�߼������s��
        String SWP_KIND = MapUtils.getString(reqMap, "SWP_KIND");

        if ("0".equals(SWP_KIND) || "2".equals(SWP_KIND)) {
            //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {
                ds.clear();
                ds.setField("RCPT_NO", MapUtils.getString(C304_MAP, "EXT_NO"));
                DBUtil.searchAndRetrieve(ds, SQL_delete_007);
                ReturnMessage rm = new ReturnMessage();
                ds.next();
                new DK_G0Z002().deleteDTDKG002ByTMP_NOForXA(ds.getField("TMP_NO").toString(), rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(new StringBuilder(MessageUtil.getMessage("EP_C30070_MSG_023")).append(rm.getMsgDesc())
                            .toString()); //�R���Ȧ��J�b�ɥ���,
                }
            } else {
                //[20180301]�D��ا�gEP.�Ȧ��� 
                EP_Z0C309 theEP_Z0C309 = new EP_Z0C309();
                DTEPC309 C309 = theEP_Z0C309.queryDTEPC309ByEXT_NO(SUB_CPY_ID, MapUtils.getString(C304_MAP, "EXT_NO"));
                theEP_Z0C309.deleteDTEPC309ByTMP_NO(SUB_CPY_ID, C309.getTMP_NO());
            }
        }

    }

    /**
     * @param ds
     * @param reqMap
     * @throws ModuleException
     */
    private void paySEdateSet(DataSet ds, Map reqMap) throws ModuleException {
        Date PAY_S_DATE = obj2Date(reqMap, "PAY_S_DATE", null);
        Date PAY_E_DATE = obj2Date(reqMap, "PAY_E_DATE", null);
        if (PAY_S_DATE == null) {
            ds.setField("PAY_S_DATE_NULL", "1");
        } else {
            ds.setField("PAY_S_DATE", PAY_S_DATE);
        }
        if (PAY_E_DATE == null) {
            ds.setField("PAY_E_DATE_NULL", "1");
        } else {
            ds.setField("PAY_E_DATE", PAY_E_DATE);
        }

    }

    /**
     * ��J�ˮ�
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getEieInstance(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �d��
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param selectSql SQL
     * @param dnfIsErr �d�L��ƬO�_�߿�
     * @return �d�ߵ��G
     * @throws ModuleException
     */
    private Map selectMap(String CRT_NO, String CUS_NO, String selectSql, boolean dnfIsErr, String SUB_CPY_ID) throws ModuleException {
        // ��J�Ѽ��ˮ�
        ErrorInputException eie = null;
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_003")); //�����N�����i���ť�
        }
        if (StringUtils.isBlank(CUS_NO) && NumberUtils.isNumber(CUS_NO)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30070_MSG_004")); //�Ȥ�Ǹ����i���ťեB�ݬ��Ʀr�榡
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        if (StringUtils.isNotBlank(SUB_CPY_ID)) {
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        }
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);

        return VOTool.findOneToMap(ds, selectSql, dnfIsErr);

    }

    /**
     * �Nmap������নBigDecimal
     * @param map
     * @param key
     * @param defaultValue
     * @return
     * @throws ModuleException
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) throws ModuleException {
        Object o = MapUtils.getObject(map, key);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }

    /**
     *  �Nmap������নInteger
     * @param map
     * @param key
     * @param defaultValue
     * @return
     * @throws ModuleException
     */
    private Integer obj2Int(Map map, String key, Integer defaultValue) throws ModuleException {
        Object o = MapUtils.getObject(map, key);
        if (o != null) {
            if (o instanceof Integer) {
                return (Integer) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new Integer(ostr);
            }
        }

        return defaultValue;
    }

    /**
     *  �Nmap������নDate
     * @param map
     * @param key
     * @param defaultValue
     * @return
     * @throws ModuleException
     */
    private Date obj2Date(Map map, String key, Date defaultValue) throws ModuleException {
        Object o = MapUtils.getObject(map, key);
        if (o != null) {
            if (o instanceof Date) {
                return (Date) o;
            }
            String ostr = o.toString();
            if (DATE.isDate(ostr)) {
                return Date.valueOf(ostr);
            }
        }
        return defaultValue;
    }

}
