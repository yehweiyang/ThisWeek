package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dk.a0.bo.DK_AAZ011_bo;
import com.cathay.dk.a0.module.DK_A0Z003;
import com.cathay.dk.b0.module.DK_B0Z003;
import com.cathay.dk.bo.DTDKF001;
import com.cathay.dk.bo.DTDKG003;
import com.cathay.dk.f0.module.DK_F0Z011;
import com.cathay.dk.f0.module.DK_F0Z017;
import com.cathay.dk.g0.module.DK_G0Z011;
import com.cathay.ep.vo.DTEPC310;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C310;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.MessageUtil;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/** 
 * <pre>
DATE Description Author
2013/12/27  Created ������

�{���\�෧�n�����G
    �ҲզW��    �h���B�z��X�@�~���@�Ҳ�
    �Ҳ�ID    EP_C30150
    ���n����    ���oDTEPC305���ڥd���I�{�ɬ����A�i��h����X�b�ȧ@�~
 [20180207]�ק��
 ��ؾɤJ:�Ϥ�call DK�Ҳ�
 �g�����Ǹ�/�ǲ��ո���I�sEP_Z0Z001
 * </pre>
 * @author ���t�s
 * @since 2014/1/13
 */
@SuppressWarnings("unchecked")
public class EP_C30150 {
    private static final String SQL_doCancel_001 = "com.cathay.ep.c3.module.EP_C30150.SQL_doCancel_001";

    private static final String SQL_doCancel_002 = "com.cathay.ep.c3.module.EP_C30150.SQL_doCancel_002";

    private static final String SQL_doConfirm_001 = "com.cathay.ep.c3.module.EP_C30150.SQL_doConfirm_001";

    private static final String SQL_doConfirm_002 = "com.cathay.ep.c3.module.EP_C30150.SQL_doConfirm_002";

    private static final String SQL_queryNonCashChkList_001 = "com.cathay.ep.c3.module.EP_C30150.SQL_queryNonCashChkList_001";

    private static final String SQL_queryNonCashChkList_002 = "com.cathay.ep.c3.module.EP_C30150.SQL_queryNonCashChkList_002";

    private static final String SQL_queryNonCashChkList_003 = "com.cathay.ep.c3.module.EP_C30150.SQL_queryNonCashChkList_003";

    private static final String SQL_queryNonCashChkList_004 = "com.cathay.ep.c3.module.EP_C30150.SQL_queryNonCashChkList_004";

    private static final Logger log = Logger.getLogger(EP_C30150.class);

    private static final String SQL_doConfirm_003 = "com.cathay.ep.c3.module.EP_C30150.SQL_doConfirm_003";

    //private static final String SQL_doCancel_003 = "com.cathay.ep.c3.module.EP_C30150.SQL_doCancel_003";

    private static final String SQL_doCancel_004 = "com.cathay.ep.c3.module.EP_C30150.SQL_doCancel_004";

    //private static final String SQL_doConfirm_004 = "com.cathay.ep.c3.module.EP_C30150.SQL_doConfirm_004";

    //private static final String SQL_doConfirm_005 = "com.cathay.ep.c3.module.EP_C30150.SQL_doConfirm_005";

    /**
     * ���o���I�{�h�������M��
     * @param reqMap �d�߸�T
     * @param user �n�J�̸�T
     * @return ���I�{�䲼�����M��
     * @throws Exception 
     */
    public List<Map> queryNonCashChkList(Map reqMap, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = this.getEieInstance(eie, MessageUtil.getMessage("EP_C30150_MSG_001"));//�����T�{��T���o����            
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getEieInstance(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getEieInstance(eie, MessageUtil.getMessage("EP_C30150_MSG_002")); //�n�J�̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        List<Map> CHK_LIST = new ArrayList<Map>();
        String CFM_TYPE = MapUtils.getString(reqMap, "CFM_TYPE");

        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        String CHK_SET_NO = MapUtils.getString(reqMap, "CHK_SET_NO");
        String ID = MapUtils.getString(reqMap, "ID");
        String ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE");
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        if (StringUtils.isNotEmpty(CRT_NO) && StringUtils.isNotEmpty(CUS_NO)) {
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("CUS_NO", CUS_NO);
        }
        if (StringUtils.isNotEmpty(RCV_YM)) {
            ds.setField("RCV_YM", RCV_YM);
        }
        if (StringUtils.isNotEmpty(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }
        if (StringUtils.isNotEmpty(ID)) {
            ds.setField("ID", ID);
        }
        if (StringUtils.isNotEmpty(CHK_SET_NO)) {
            ds.setField("CHK_SET_NO", CHK_SET_NO);
        }
        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else {
            ds.setField("ACNT_TYPE2", "2");
        }
        ds.setField("DIV_NO", user.getOpUnit());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        try {
            if ("N".equals(CFM_TYPE)) {
                //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
                //��ؤ~�|�X�b
                if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                    DBUtil.searchAndRetrieve(ds, SQL_queryNonCashChkList_001);
                } else {
                    //[20180301] �D��ا�gEP.�Ȧ���
                    DBUtil.searchAndRetrieve(ds, SQL_queryNonCashChkList_003);
                }
            } else {
                //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�                
                if (StringUtils.isNotBlank(ACNT_DATE)) {
                    ds.setField("ACNT_DATE", ACNT_DATE);
                }
                String SLIP_SET_NO = MapUtils.getString(reqMap, "SLIP_SET_NO");
                if ("Y".equals(CFM_TYPE) && StringUtils.isNotBlank(SLIP_SET_NO)) {
                    ds.setField("SLIP_SET_NO", SLIP_SET_NO);
                    ds.setField("EmpID", user.getEmpID());
                }
                if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                    DBUtil.searchAndRetrieve(ds, SQL_queryNonCashChkList_002);
                } else {
                    //[20180301] �D��ا�gEP.�Ȧ���  
                    DBUtil.searchAndRetrieve(ds, SQL_queryNonCashChkList_004);
                }
            }
        } catch (DataNotFoundException dnfe) {
            log.error(MessageUtil.getMessage("EP_C30150_MSG_003"), dnfe);
            throw new DataNotFoundException(MessageUtil.getMessage("EP_C30150_MSG_003")); //���o�h���O���d�L���
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EP_C30150_MSG_004") + e.getMessage(), e);
            throw new ModuleException(MessageUtil.getMessage("EP_C30150_MSG_004") + e.getMessage()); //�o�h���O���M��o�Ϳ��~,
        }

        while (ds.next()) {
            Map dataMap = VOTool.dataSetToMap(ds);
            if ("N".equals(CFM_TYPE)) {
                dataMap.put("SLIP_SEQ_NO", "0");
            } else {
                //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
                //��ؤ~�|�X�b
                if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                    try {
                        String SLIP_LOT_NO = MapUtils.getString(dataMap, "SLIP_LOT_NO");
                        if (StringUtils.isNotBlank(SLIP_LOT_NO)) {
                            dataMap.put("SLIP_SEQ_NO", new DK_B0Z003().doSwitchNo("1", ACNT_DATE, SLIP_LOT_NO,
                                MapUtils.getString(dataMap, "SLIP_SET_NO")).get("CE_SLPSET_NO"));
                        }
                    } catch (DataNotFoundException e) {
                        dataMap.put("SLIP_SEQ_NO", "���X�b");
                    } catch (Exception e) {
                        log.error(MessageUtil.getMessage("EP_C30150_MSG_005") + e.getMessage(), e); //���o�ǲ��Ǹ��o�Ϳ��~,
                        throw new ModuleException(MessageUtil.getMessage("EP_C30150_MSG_005") + e.getMessage()); //���o�ǲ��Ǹ��o�Ϳ��~,
                    }
                }
            }
            dataMap.put("CARD_NO_NM", FieldOptionList.getName("EPC3", "CARD_NO", MapUtils.getString(dataMap, "CARD_NO")));
            CHK_LIST.add(dataMap);
        }

        return CHK_LIST;
    }

    /**
     * �T�{
     * @param reqMap �T�{��T
     * @param user �n�J�̸�T
     * @throws Exception 
     */
    public void doConfirm(Map reqMap, List<Map> reqList, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = this.getEieInstance(eie, MessageUtil.getMessage("EP_C30150_MSG_001"));//�����T�{��T���o����            
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getEieInstance(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getEieInstance(eie, MessageUtil.getMessage("EP_C30150_MSG_002")); //�n�J�̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        ReturnMessage msg = new ReturnMessage();

        String EmpID = user.getEmpID();
        String OpUnit = user.getOpUnit();
        //���o�b�ȸ��      
        String SLIP_LOT_NO = MapUtils.getString(reqMap, "SLIP_LOT_NO");

        String currentDate = DATE.getDBDate();
        String ACNT_DATE = currentDate;

        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        //[20180207]�g�����Ǹ���I�sEP_Z0Z001
        //Call���o�g�����Ǹ��Ҳ�.���o�g�����Ǹ���k
        String TRN_SER_NO = theEP_Z0Z001.getTRN_SER_NO(SUB_CPY_ID, EmpID, ACNT_DATE, msg);
        if (msg.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30150_MSG_008") + msg.getMsgDesc()); //�g�����Ǹ����o���~,
        }
        //[20180207]�ǲ��ո���I�sEP_Z0Z001
        //���o�ǲ��ո�
        String SLIP_SET_NO = theEP_Z0Z001.getSLIP_SET_NO(SUB_CPY_ID, "2", OpUnit, null, SLIP_LOT_NO, ACNT_DATE, msg);
        if (msg.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30150_MSG_018") + msg.getMsgDesc()); //���o�ǲ��ո����ѡA
        }

        //���ƨϥΪ��ܼ�        
        String currentTime = DATE.getDBTimeStamp();
        String EmpName = user.getEmpName();

        //String RCV_NO = MapUtils.getString(reqMap, "NO");
        String ACNT_TYPE = MapUtils.getString(reqMap, "ACNT_TYPE");
        DataSet ds = Transaction.getDataSet();
        List<DK_AAZ011_bo> DK_AAZ011_bo_List = new ArrayList<DK_AAZ011_bo>();
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        EP_Z0C310 theEP_Z0C310 = new EP_Z0C310();
        for (Map map : reqList) {
            String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(SUB_CPY_ID, MapUtils.getString(map, "BLD_CD"));

            //���o��X�s��
            String thisYear = DATE.getY2KYear(DATE.getDBDate());
            int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "023", thisYear, "1");
            String EXT_NO = new StringBuilder(SUB_CPY_ID).append(thisYear).append(
                STRING.fillZero(String.valueOf(SER_NO), 4, EncodingHelper.DefaultCharset)).toString();

            String RCV_NO = MapUtils.getString(map, "NO");
            String PAY_NO = MapUtils.getString(map, "PAY_NO");
            String PAY_KIND = MapUtils.getString(map, "PAY_KIND");
            String ID = MapUtils.getString(map, "ID");
            String PAY_AMT = MapUtils.getString(map, "PAY_AMT");
            if (StringUtils.isBlank(PAY_AMT) || !NumberUtils.isNumber(PAY_AMT)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_C30150_MSG_006")); //��X���B��Ʀ��~
            }

            //��sú�ڰO���μȦ��O��
            if ("1".equals(MapUtils.getString(map, "SRC_NO"))) {

                //�s�W��X�����(DTEPC304)            
                ds.setField("EXT_NO", EXT_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                ds.setField("RCV_NO", RCV_NO);
                ds.setField("PAY_NO", PAY_NO);
                ds.setField("RCV_YM", MapUtils.getString(map, "RCV_YM"));
                ds.setField("PAY_KIND", PAY_KIND);
                ds.setField("CRT_NO", MapUtils.getString(map, "CRT_NO"));
                ds.setField("CUS_NO", MapUtils.getString(map, "CUS_NO"));
                ds.setField("ID", ID);
                ds.setField("CUS_NAME", MapUtils.getString(map, "CUS_NAME"));
                ds.setField("BLD_CD", MapUtils.getString(map, "BLD_CD"));
                ds.setField("PAY_TYPE", MapUtils.getString(map, "PAY_TYPE"));
                ds.setField("SWP_KD", "3");
                ds.setField("SWP_DATE", currentDate);
                ds.setField("SWP_AMT", PAY_AMT);
                ds.setField("INPUT_ID", EmpID);
                ds.setField("INPUT_NAME", EmpName);
                ds.setField("TRN_DATE", currentTime);
                ds.setField("TRN_SER_NO", new BigDecimal(TRN_SER_NO));
                ds.setField("S_ACNT_DATE", ACNT_DATE);
                ds.setField("S_ACNT_ID", EmpID);
                ds.setField("S_DIV_NO", OpUnit);
                ds.setField("S_SLPLOT_NO", SLIP_LOT_NO);
                ds.setField("S_SLPSET_NO", SLIP_SET_NO);
                ds.setField("CHG_DATE", currentTime);
                ds.setField("CHG_DIV_NO", OpUnit);
                ds.setField("CHG_ID", EmpID);
                ds.setField("CHG_NAME", EmpName);
                DBUtil.executeUpdate(ds, SQL_doConfirm_001);

                //��sDTEPC301ú�O���p��
                ds.clear();
                ds.setField("SWP_DATE", currentDate);
                ds.setField("CHG_DATE", currentTime);
                ds.setField("CHG_DIV_NO", OpUnit);
                ds.setField("CHG_ID", EmpID);
                ds.setField("CHG_NAME", EmpName);
                ds.setField("PAY_NO", PAY_NO);
                ds.setField("RCV_NO", RCV_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.executeUpdate(ds, SQL_doConfirm_002);

                if (!"2".equals(PAY_KIND)) {
                    //��sDTEPC101�����ɾl�B
                    ds.clear();
                    ds.setField("SPR_AMT", PAY_AMT);
                    ds.setField("TRN_KIND", "EPC009");
                    ds.setField("LST_PROC_DATE", currentTime);
                    ds.setField("LST_PROC_DIV", OpUnit);
                    ds.setField("LST_PROC_ID", EmpID);
                    ds.setField("LST_PROC_NAME", EmpName);
                    ds.setField("RCV_NO", RCV_NO);
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    DBUtil.executeUpdate(ds, SQL_doConfirm_003);
                }
                //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
                //��ؤ~�|�X�b
                if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                    //����b�ȧ@�~
                    //�ɤ�
                    DK_AAZ011_bo DK_AAZ011_BO_B = new DK_AAZ011_bo();
                    DK_AAZ011_BO_B.setINPUT_ID(EmpID);
                    DK_AAZ011_BO_B.setINPUT_NAME(EmpName);
                    DK_AAZ011_BO_B.setTRN_DATE(currentTime);
                    DK_AAZ011_BO_B.setTRN_SER_NO(TRN_SER_NO);
                    DK_AAZ011_BO_B.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DK_AAZ011_BO_B.setSLIP_SET_NO(SLIP_SET_NO);
                    DK_AAZ011_BO_B.setREL_FILE_NO("DTEPC304");
                    DK_AAZ011_BO_B.setACNT_DATE(ACNT_DATE);
                    DK_AAZ011_BO_B.setTRN_KIND("EPC150");
                    DK_AAZ011_BO_B.setMEMO(MessageUtil.getMessage("EP_C30150_MSG_010")); //�h����X
                    DK_AAZ011_BO_B.setACNT_DIV_NO(OpUnit);
                    DK_AAZ011_BO_B.setBUS_CODE("EP");
                    DK_AAZ011_BO_B.setBUS_TRAN_CODE("1");
                    DK_AAZ011_BO_B.setCURR("NTD");
                    DK_AAZ011_BO_B.setCNT("1");
                    DK_AAZ011_BO_B.setITEM("9");
                    DK_AAZ011_BO_B.setAMT(PAY_AMT);
                    DK_AAZ011_BO_B.setDIV_NO_C101(MapUtils.getString(map, "DIV_NO_C101"));
                    DK_AAZ011_BO_B.setACNT_TYPE(ACNT_TYPE);//���@��P���M 
                    DK_AAZ011_BO_B.setBAL_TYPE(BAL_TYPE);
                    if ("2".equals(PAY_KIND)) {
                        DK_AAZ011_BO_B.setTYPE("3");
                    } else if ("3".equals(PAY_KIND)) {
                        DK_AAZ011_BO_B.setTYPE("2");
                    } else {
                        DK_AAZ011_BO_B.setTYPE("1");
                    }
                    DK_AAZ011_bo_List.add(DK_AAZ011_BO_B);//�ɤ�
                }

            } else {

                DK_G0Z011 theDK_G0Z011 = new DK_G0Z011();

                //�Ȧ��J�b
                DTDKG003 DTDKG003_VO = new DTDKG003();
                DTDKG003_VO.setTMP_NO(MapUtils.getString(map, "NO"));
                DTDKG003_VO.setTRN_KIND("EPC315");
                DTDKG003_VO.setTMP_CD("A");
                DTDKG003_VO.setINPUT_CD("1");

                if ("8300100".equals(OpUnit)) {
                    DTDKG003_VO.setTMP_KIND("965");
                } else {
                    DTDKG003_VO.setTMP_KIND("966");
                }
                DTDKG003_VO.setDACNT_DIV_NO(OpUnit);
                DTDKG003_VO.setDACNT_ID(EmpID);
                DTDKG003_VO.setDACNT_NAME(EmpName);
                DTDKG003_VO.setDACNT_IN_DATE(currentTime);
                DTDKG003_VO.setDACNT_AMT(PAY_AMT);
                DTDKG003_VO.setDACNT_DATE(ACNT_DATE);
                //DTDKG003_VO.setDACNT_SER_NO(TRN_SER_NO);
                DTDKG003_VO.setSLIP_LOT_NO(SLIP_LOT_NO);
                DTDKG003_VO.setSLIP_DATE(ACNT_DATE);
                // DTDKG003_VO.setSLIP_SET_NO(SLIP_SET_NO);
                DTDKG003_VO.setTMP_D_KIND("5");
                DTDKG003_VO.setACPT_ID(ID);
                DTDKG003_VO.setACPT_ACNT_NAME(MapUtils.getString(reqMap, "CUS_NAME"));
                DTDKG003_VO.setRCPT_NO(EXT_NO);
                DTDKG003_VO.setRTN_RCPT_NO(PAY_NO);

                if ("8300100".equals(OpUnit)) {
                    DTDKG003_VO.setTMP_KIND("965");
                } else {
                    DTDKG003_VO.setTMP_KIND("966");
                }

                //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�               
                String DTMP_NO = "";
                if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) { //��ؤ~�|�X�b
                    DTMP_NO = theDK_G0Z011.insertDTDKG003ForXA(DTDKG003_VO, msg);
                    if (msg.getReturnCode() != ReturnCode.OK) {
                        throw new ModuleException(MessageUtil.getMessage("EP_C30150_MSG_012") + msg.getMsgDesc()); //"�Ȧ��R�b���~,
                    }
                } else {
                    //[20180301]:�D��ا�gEP.�Ȧ���
                    DTEPC310 C310 = new DTEPC310();
                    VOTool.copyVOFromTo(DTDKG003_VO, C310);
                    C310.setSUB_CPY_ID(SUB_CPY_ID);
                    DTMP_NO = theEP_Z0C310.insertDTEPC310(C310);
                }
                DTDKG003_VO = new DTDKG003();
                DTDKG003_VO.setTMP_NO(MapUtils.getString(map, "NO"));
                DTDKG003_VO.setDTMP_NO(DTMP_NO);
                DTDKG003_VO.setDACNT_DATE(ACNT_DATE);
                DTDKG003_VO.setDACNT_SER_NO(TRN_SER_NO);
                DTDKG003_VO.setSLIP_DATE(ACNT_DATE);
                DTDKG003_VO.setSLIP_LOT_NO(SLIP_LOT_NO);
                DTDKG003_VO.setSLIP_SET_NO(SLIP_SET_NO);
                DTDKG003_VO.setDACNT_ID(EmpID);
                DTDKG003_VO.setDACNT_NAME(EmpName);
                DTDKG003_VO.setDACNT_IN_DATE(currentTime);
                DTDKG003_VO.setDACNT_DIV_NO(OpUnit);
                DTDKG003_VO.setTRN_KIND("EPC390");
                DTDKG003_VO.setDACNT_AMT(PAY_AMT);
                if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                    theDK_G0Z011.insertDTDKF001fromG003ForXA(DTDKG003_VO, msg);
                    if (msg.getReturnCode() != ReturnCode.OK) {
                        throw new ModuleException("��sDTDKG003�b�ȸ�Ƶo�Ϳ��~�G" + msg.getMsgDesc());
                    }
                } else {
                    //[20180301]:�D��ا�gEP.�Ȧ���
                    DTEPC310 C310 = new DTEPC310();
                    VOTool.copyVOFromTo(DTDKG003_VO, C310);
                    C310.setSUB_CPY_ID(SUB_CPY_ID);
                    theEP_Z0C310.updateC310ForACNT(C310);
                }
            }
            //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
            //��ؤ~�|�X�b
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                //�U��
                DK_AAZ011_bo DK_AAZ011_BO_D = new DK_AAZ011_bo();
                DK_AAZ011_BO_D = new DK_AAZ011_bo();
                DK_AAZ011_BO_D.setINPUT_ID(EmpID);
                DK_AAZ011_BO_D.setINPUT_NAME(EmpName);
                DK_AAZ011_BO_D.setTRN_DATE(currentTime);
                DK_AAZ011_BO_D.setTRN_SER_NO(TRN_SER_NO);
                DK_AAZ011_BO_D.setSLIP_LOT_NO(SLIP_LOT_NO);
                DK_AAZ011_BO_D.setSLIP_SET_NO(SLIP_SET_NO);
                DK_AAZ011_BO_D.setREL_FILE_NO("DTEPC304");
                DK_AAZ011_BO_D.setACNT_DATE(ACNT_DATE);
                DK_AAZ011_BO_D.setTRN_KIND("EPC150");
                DK_AAZ011_BO_D.setMEMO(MessageUtil.getMessage("EP_C30150_MSG_010")); //�h����X
                DK_AAZ011_BO_D.setACNT_DIV_NO(OpUnit);
                DK_AAZ011_BO_D.setBUS_CODE("EP");
                DK_AAZ011_BO_D.setBUS_TRAN_CODE("1");
                DK_AAZ011_BO_D.setCURR("NTD");
                DK_AAZ011_BO_D.setCNT("1");
                DK_AAZ011_BO_D.setITEM("9");
                DK_AAZ011_BO_D.setTYPE("8");
                DK_AAZ011_BO_D.setAMT(PAY_AMT);
                DK_AAZ011_BO_D.setACNT_TYPE(ACNT_TYPE);//�@��P���M
                DK_AAZ011_BO_D.setBAL_TYPE(BAL_TYPE);
                DK_AAZ011_bo_List.add(DK_AAZ011_BO_D);//�U��
            }
        }
        //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
        //��ؤ~�|�X�b
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
            new DK_A0Z003().doInsert(DK_AAZ011_bo_List, msg);
            if (msg.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30150_MSG_011") + msg.getMsgDesc()); //�g�J�b�ȸ�T���~,
            }

            //�ˮֱb�ȬO�_����
            new DK_F0Z011().isBalance2(OpUnit, EmpID, ACNT_DATE, SLIP_LOT_NO, SLIP_SET_NO, msg);
            if (msg.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30150_MSG_019") + msg.getMsgDesc()); //�ˮֱb�ȬO�_���ŵo�Ϳ��~�A
            }
        }

        reqMap.put("SLIP_SET_NO", SLIP_SET_NO); //�N�ǲ��ո���ܦb�e���W

    }

    /**
     * �����T�{
     * @param reqMap �����T�{��T
     * @param user �n�J�̸�T
     * @throws Exception 
     */
    public void doCancel(Map reqMap, List<Map> reqList, UserObject user) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = this.getEieInstance(eie, MessageUtil.getMessage("EP_C30150_MSG_001"));//�����T�{��T���o����            
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getEieInstance(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = this.getEieInstance(eie, MessageUtil.getMessage("EP_C30150_MSG_002")); //�n�J�̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        ReturnMessage msg = new ReturnMessage();

        String EmpID = user.getEmpID();
        DataSet ds = Transaction.getDataSet();
        BigDecimal SWP_AMT = BigDecimal.ZERO;
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        EP_Z0C310 theEP_Z0C310 = new EP_Z0C310();
        for (Map map : reqList) {
            //String PAY_NO = MapUtils.getString(map, "PAY_NO");
            //��sú�ڰO���μȦ��O��
            if ("1".equals(MapUtils.getString(map, "SRC_NO"))) {
                String EXT_NO = MapUtils.getString(map, "EXT_NO");
                String RCV_NO = MapUtils.getString(map, "NO");
                String PAY_KIND = MapUtils.getString(map, "PAY_KIND");
                if (StringUtils.isBlank(EXT_NO)) {
                    throw new ErrorInputException(MessageUtil.getMessage("EP_C30150_MSG_013")); //��X�s�����o����
                }

                //�d����X�����(DTEPC304)
                ds.setField("EXT_NO", EXT_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.searchAndRetrieve(ds, SQL_doCancel_004);
                while (ds.next()) {
                    SWP_AMT = (BigDecimal) ds.getField("SWP_AMT", BigDecimal.ZERO);
                }

                //�R����X�����(DTEPC304)
                ds.clear();
                ds.setField("EXT_NO", EXT_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                try {
                    DBUtil.executeUpdate(ds, SQL_doCancel_001, true);
                } catch (ModuleException me) {
                    throw new ModuleException(MessageUtil.getMessage("EP_C30150_MSG_015") + EXT_NO); //�R����X����O�����~,��X�s��=
                }

                if (!"2".equals(PAY_KIND)) {
                    //��sDTEPC101������
                    ds.clear();
                    ds.setField("SPR_AMT2", SWP_AMT);
                    ds.setField("TRN_KIND", "EPC010");
                    ds.setField("LST_PROC_DATE", DATE.getDBTimeStamp());
                    ds.setField("LST_PROC_DIV", user.getOpUnit());
                    ds.setField("LST_PROC_ID", user.getEmpID());
                    ds.setField("LST_PROC_NAME", user.getEmpName());
                    ds.setField("RCV_NO", RCV_NO);
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    DBUtil.executeUpdate(ds, SQL_doConfirm_003);
                }

                //��sDTEPC301ú�O���p��
                ds.clear();
                ds.setField("PAY_AMT", SWP_AMT);
                ds.setField("CHG_DATE", DATE.getDBTimeStamp());
                ds.setField("CHG_DIV_NO", user.getOpUnit());
                ds.setField("CHG_ID", EmpID);
                ds.setField("CHG_NAME", user.getEmpName());
                ds.setField("PAY_NO", map.get("PAY_NO"));
                ds.setField("RCV_NO", RCV_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.executeUpdate(ds, SQL_doCancel_002);

            } else {
                //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�
                //��ؤ~�|�X�b
                if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                    DK_G0Z011 theDK_G0Z011 = new DK_G0Z011();
                    //�Ȧ��R�b��J�B�R���Ҳ�.�R���Ȧ��R�b��k
                    theDK_G0Z011.doDeleteForXA(EmpID, MapUtils.getString(map, "DACNT_IN_DATE"), MapUtils.getString(map, "TRN_SER_NO"), msg);
                    if (msg.getReturnCode() != ReturnCode.OK) {
                        throw new ModuleException(MessageUtil.getMessage("EP_C30150_MSG_017") + msg.getMsgDesc()); //�����Ȧ��R�b���~,
                    }
                } else {
                    //[20180301]�D��ا�gEP.�Ȧ���
                    theEP_Z0C310.doDelete(SUB_CPY_ID, EmpID, MapUtils.getString(map, "DACNT_IN_DATE"), MapUtils
                            .getString(map, "TRN_SER_NO"));
                }
            }
        }
        //[20180207]��ؾɤJ:�Ϥ�call DK�Ҳ�       
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) { //��ؤ~�|�X�b
            //�R���|�p����
            if ("00".equals(SUB_CPY_ID)) {
                Map tmpMap = reqList.get(0);
                log.debug("====tmpMap====" + tmpMap);
                DTDKF001 DTDKF001_BO = new DTDKF001();
                DTDKF001_BO.setINPUT_ID(EmpID);
                DTDKF001_BO.setTRN_SER_NO(MapUtils.getString(tmpMap, "TRN_SER_NO"));
                DTDKF001_BO.setACNT_DATE(MapUtils.getString(reqMap, "ACNT_DATE"));

                DTDKF001_BO.setSLIP_LOT_NO(MapUtils.getString(tmpMap, "SLIP_LOT_NO"));
                DTDKF001_BO.setACNT_DIV_NO(MapUtils.getString(tmpMap, "ACNT_DIV_NO"));
                DTDKF001_BO.setSLIP_SET_NO(MapUtils.getString(tmpMap, "SLIP_SET_NO"));

                //Call�U����|�p���������ɿ�J�N�R���Ҳ�.Delete����|�p���������ɤ�k
                new DK_F0Z017().delete4(DTDKF001_BO, msg);
                if (msg.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(MessageUtil.getMessage("EP_C30150_MSG_014") + msg.getMsgDesc()); //�I�s�U����|�p���������ɿ�J,�R���Ҳ�DK_A0Z003����:
                }
            }
        }

    }

    /**
     *  ��J�ˮ�
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getEieInstance(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
