package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.STRING;
import com.cathay.ep.z0.module.EP_Z0C101;
import com.cathay.ep.z0.module.EP_Z0C307;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��  �����b��۰ʾP�b�ˮּҲ�
 * �Ҳ�ID  EPC3_0160_mod
 * ���n����  �����b��۰ʾP�b�ˮּҲ�
 * </pre>
 * 
 * @author ���Q
 * @since 2016/03/18
 */
@SuppressWarnings("unchecked")
public class EPC3_0160_mod {

    /**
     * �ˮ� 
     * @param reqList 
     * @throws ModuleException
     */
    public void chkConfirm(List<Map> reqList, String SUB_CPY_ID) throws ModuleException {
        //����ˮ�
        if (reqList == null || reqList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EPC3_0160_mod_MSG_001"));//�ˮָ�Ƥ��i����
        }

        List<String> BANK_SER_NOs = new ArrayList<String>();
        Map<String, List<String>> C101Map = new HashMap<String, List<String>>();

        for (int i = 0; i < reqList.size(); i++) {
            Map reqMap = reqList.get(i);

            String reqBANK_SER_NO = MapUtils.getString(reqMap, "BANK_SER_NO");
            String reqRCV_NO = MapUtils.getString(reqMap, "RCV_NO");
            if (!BANK_SER_NOs.contains(reqBANK_SER_NO)) {
                BANK_SER_NOs.add(reqBANK_SER_NO);
            }

            List<String> tmpC101;
            if (C101Map.containsKey(reqBANK_SER_NO)) {
                tmpC101 = C101Map.get(reqBANK_SER_NO);
            } else {
                tmpC101 = new ArrayList<String>();
                C101Map.put(reqBANK_SER_NO, tmpC101);
            }
            tmpC101.add(reqRCV_NO);

        }

        //�d��C307�M��
        DataSet ds = Transaction.getDataSet();
        ds.setFieldValues("BANK_SER_NOs", BANK_SER_NOs);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        EP_Z0C307 theEP_Z0C307 = new EP_Z0C307();
        EP_Z0C101 theEP_Z0C101 = new EP_Z0C101();
        List<Map> C307List = theEP_Z0C307.queryC307(ds);

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < C307List.size(); i++) {
            Map C307Map = C307List.get(i);
            String C307BANK_SER_NO = MapUtils.getString(C307Map, "BANK_SER_NO");
            //�d��C101������
            List<Map> C101List = theEP_Z0C101.queryRcvList(C101Map.get(C307BANK_SER_NO), SUB_CPY_ID);
            //�ˮֱM����ӬO�_�T�{�B���P�b
            Date C307CFM_DATE = (Date) C307Map.get("CFM_DATE");
            String C307ACNT_SET_NO = MapUtils.getString(C307Map, "ACNT_SET_NO");
            if (C307CFM_DATE == null) {
                //�M�᥼�T�{,�Ȧ�b�Ǹ�:{0}
                appendMsg(sb, "EPC3_0160_mod_MSG_002", new Object[] { C307BANK_SER_NO });
            }
            if (StringUtils.isNotBlank(C307ACNT_SET_NO)) {
                //�M��w�P�b,�Ȧ�b�Ǹ�:{0}
                appendMsg(sb, "EPC3_0160_mod_MSG_004", new Object[] { C307BANK_SER_NO });
            }

            String C307ID = MapUtils.getString(C307Map, "ID").trim();
            BigDecimal TOT_AMT = BigDecimal.ZERO;
            for (int j = 0; j < C101List.size(); j++) {
                Map C101MapJ = (Map<String, List>) C101List.get(j);
                String C101ID = MapUtils.getString(C101MapJ, "ID").trim();

                String C101RCV_NO = MapUtils.getString(C101MapJ, "RCV_NO");
                BigDecimal C101SPR_AMT = STRING.objToBigDecimal(C101MapJ.get("SPR_AMT"), BigDecimal.ZERO);
                //�ˮ������O�_��ú�ڥBID�@�P
                if (!C307ID.equals(C101ID)) {
                    //�����P�M��Ȥ�ID���@�P,�����s��:{0},�Ȧ�b�Ǹ�:{1}
                    appendMsg(sb, "EPC3_0160_mod_MSG_005", new Object[] { C101RCV_NO, C307BANK_SER_NO });
                }
                if (BigDecimal.ZERO.compareTo(C101SPR_AMT) == 0) {
                    //�����w�P�b,�����s��:{0}
                    appendMsg(sb, "EPC3_0160_mod_MSG_007", new Object[] { C101RCV_NO });
                }

                TOT_AMT = TOT_AMT.add(C101SPR_AMT);
            }

            //�ˮ־P�b���B�@�P
            BigDecimal C307AMOUNT = STRING.objToBigDecimal(C307Map.get("AMOUNT"), BigDecimal.ZERO);
            if (C307AMOUNT.compareTo(TOT_AMT) != 0) {
                //�������B�P�M����B����, �Ȧ�b�Ǹ�:{0}
                appendMsg(sb, "EPC3_0160_mod_MSG_008", new Object[] { C307BANK_SER_NO });
            }

            if (sb.length() > 0) {
                throw new ModuleException(sb.toString());
            }

        }

    }

    private void appendMsg(StringBuilder sb, String msg, Object[] objs) {
        if (sb.length() != 0) {
            STRING.newLine(sb);
        }
        if (objs != null) {
            sb.append(MessageUtil.getMessage(msg, objs));
        } else {
            sb.append(MessageUtil.getMessage(msg));
        }

    }

}
