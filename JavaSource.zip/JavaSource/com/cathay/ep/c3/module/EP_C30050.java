package com.cathay.ep.c3.module;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.Id;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dj.c0.module.DJ_C0Z025;
import com.cathay.dk.bo.DTDKG002;
import com.cathay.dk.g0.module.DK_G0Z002;
import com.cathay.ep.vo.DTEPC309;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C309;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 *<pre>
 * DATE Description Author
 * 2013/10/09  Created ������
 *
 * �@�B    �{���\�෧�n�����G
 * �ҲզW��    �wú�B�z�@�~���@�Ҳ�
 * �Ҳ�ID     EP_C30050
 * ���n����    ���o�Ȧ��J�b�M��@�~
 *</pre>
 *
 * [20180208] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * 
 * [20180227] �ק��
 * �D���
 * 
 * @author ���_��
 * @since 2013/11/14
 */
@SuppressWarnings("unchecked")
public class EP_C30050 {

    //private static final String SQL_queryTmpInfoList_001 = "com.cathay.ep.c3.module.EP_C30050.SQL_queryTmpInfoList_001";

    private static final String SQL_queryTmpInfoList_002 = "com.cathay.ep.c3.module.EP_C30050.SQL_queryTmpInfoList_002";

    private static final String SQL_queryTmpInfoList_003 = "com.cathay.ep.c3.module.EP_C30050.SQL_queryTmpInfoList_003";

    private static final Logger log = Logger.getLogger(EP_C30050.class);

    private boolean isDebug = log.isDebugEnabled();

    private static final String SQL_insertTmpInfo_001 = "com.cathay.ep.c3.module.EP_C30050.SQL_insertTmpInfo_001";

    /**
     * ���o�Ȧ������M��
     * @param reqMap
     *           <pre>       
     *           QUERY_KIND �d�ߺ���
     *           SUB_CPY_ID �����q�O
     *           CRT_NO �����N��
     *           CUS_NO �Ȥ�Ǹ�
     *           ACNT_STR_DATE �J�b���(�_)
     *           ACNT_END_DATE �J�b���(��)
     *           </pre>
     * @return �Ȧ������M��
     * @throws ModuleException
     * @throws SQLException
     */
    public List<Map> queryTmpInfoList(Map reqMap) throws ModuleException, SQLException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30050_MSG_009"));//�ǤJ�d�߼Ȧ���T���o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30050_MSG_001"));//�ǤJ�����q�O���o����
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setfieldIfExist(ds, reqMap, "CRT_NO");
        setfieldIfExist(ds, reqMap, "CUS_NO");
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            setfieldIfExist(ds, reqMap, "ACNT_STR_DATE");
            setfieldIfExist(ds, reqMap, "ACNT_END_DATE");
            DBUtil.searchAndRetrieve(ds, SQL_queryTmpInfoList_002);
        } else {
            /* [20180227]�D��جdEP  */
            String QUERY_KIND = MapUtils.getString(reqMap, "QUERY_KIND");
            if ("0".equals(QUERY_KIND)) {
                ds.setField("QUERY_KIND_0", QUERY_KIND);
            } else if ("1".equals(QUERY_KIND)) {
                ds.setField("QUERY_KIND_1", QUERY_KIND);
            }
            DBUtil.searchAndRetrieve(ds, SQL_queryTmpInfoList_003);
        }
        List<Map> TMP_INFO_LIST = new ArrayList();
        while (ds.next()) {
            Map TMP_INFO_MAP = VOTool.dataSetToMap(ds);
            TMP_INFO_MAP.put("BLD_CD", TMP_INFO_MAP.get("APLY_NO"));
            TMP_INFO_MAP.put("CRT_NO", TMP_INFO_MAP.get("POLICY_NO"));
            TMP_INFO_MAP.put("CUS_NO", TMP_INFO_MAP.get("PAY_TIMES"));
            TMP_INFO_MAP.put("MEMO", TMP_INFO_MAP.get("BLD_NAME"));
            //�Ȧ��ӷ�
            TMP_INFO_MAP.put("TMP_IN_NM", FieldOptionList.getName("EPC3", "TMP_IN_CD", MapUtils.getString(TMP_INFO_MAP, "TMP_IN_CD")));
            //ú�ں���
            String CAT_PREM = MapUtils.getString(TMP_INFO_MAP, "CAT_PREM");
            TMP_INFO_MAP.put("PAY_KIND", CAT_PREM);
            TMP_INFO_MAP.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND", CAT_PREM));
            TMP_INFO_LIST.add(TMP_INFO_MAP);
        }

        return TMP_INFO_LIST;

    }

    /**
     * �g�J�Ȧ��J�b��T
     * @param tmpInfoMap �Ȧ���T
     * @param CHK_LIST ���ک��Ӹ�T�M��
     * @param user �ϥΪ̸�T
     * @param SUB_CPY_ID �����q�O
     * @return
     * @throws Exception
     */
    public String insertTmpInfo(Map tmpInfoMap, List<Map> CHK_LIST, String CHK_SET_NO, UserObject user, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (tmpInfoMap == null || tmpInfoMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30050_MSG_003"));//�ǤJ�Ȧ���T���o����
        }
        /* [20180208] ���������n���P�_ tmpInfoMap.SUB_CPY_ID
                            �s�W�ǤJ�Ѽ� SUB_CPY_ID  */
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30050_MSG_001"));//�ǤJ�����q�O���o����
        }
        if (CHK_LIST != null && CHK_LIST.size() > 1) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30050_MSG_008"));//�ǤJ���ک��Ӹ�T�M�榳�~
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30050_MSG_004"));//�ǤJ�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        String OpUnit = user.getOpUnit();
        String userId = user.getEmpID();
        String time = DATE.getDBTimeStamp();
        String ACNT_AMT = MapUtils.getString(tmpInfoMap, "ACNT_AMT");
        String CRT_NO = MapUtils.getString(tmpInfoMap, "CRT_NO");
        String CRT_NO_1 = CRT_NO.substring(0, 1);
        String TMP_NO = "";

        //����DBDK.DTDKG002�������J�b�ɮ榡
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        DTDKG002 DTDKG002_BO = new DTDKG002();
        DTDKG002_BO.setSYS_NO("EP");
        DTDKG002_BO.setTRN_KIND("EPC305");
        DTDKG002_BO.setTMP_CD("A");

        //DTDKG002.TMP_KIND=965 ���ʲ��޲z�@��Ȧ�
        //DTDKG002.TMP_KIND=966 ���ʲ��޲z�G��Ȧ�

        if ("I".equals(CRT_NO_1)) {
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) { //���:�̳��P�_
                if ("I8300100".equals(CRT_NO)) {
                    DTDKG002_BO.setTMP_KIND("965");
                } else if ("I8300200".equals(CRT_NO)) {
                    DTDKG002_BO.setTMP_KIND("966");
                } else if ("I8200100".equals(CRT_NO)) {
                    DTDKG002_BO.setTMP_KIND("975");//����������  //���ʲ����� ��鲣�M��
                } else {
                    if ("8300100".equals(OpUnit)) {
                        DTDKG002_BO.setTMP_KIND("965");
                    } else {
                        DTDKG002_BO.setTMP_KIND("966");
                    }
                }
            } else {//�D���:����N��
                DTDKG002_BO.setTMP_KIND(user.getDivNo());
            }

        } else {
            if (isDebug) {
                log.debug("@@@�ˬd�����O�_����鲣�M��=" + CRT_NO);
            }
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) { //���:�̳��P�_
                DataSet ds = Transaction.getDataSet();
                ds.setField("CRT_NO", CRT_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.searchAndRetrieve(ds, SQL_insertTmpInfo_001);
                ds.next();
                if ("9".equals(ObjectUtils.toString(ds.getField(0)))) {
                    DTDKG002_BO.setTMP_KIND("975");// ��鲣�M��
                } else {
                    //�����N���Ĥ@�X('A','B','C','D','E','T')==>�޲z�@��
                    if (ArrayUtils.contains(new String[] { "A", "B", "C", "D", "E", "T" }, CRT_NO_1)) {
                        DTDKG002_BO.setTMP_KIND("965");
                    } else {
                        DTDKG002_BO.setTMP_KIND("966");
                    }
                }
            } else {//�D���:����N��
                DTDKG002_BO.setTMP_KIND(user.getDivNo());
            }

        }
        if (isDebug) {
            log.debug("@@@CRT_NO=" + CRT_NO);
            log.debug("@@@DTDKG002_BO.getTMP_KIND=" + DTDKG002_BO.getTMP_KIND());
        }

        DTDKG002_BO.setINPUT_CD("2");
        DTDKG002_BO.setACNT_ID(userId);
        DTDKG002_BO.setACNT_NAME(user.getEmpName());
        DTDKG002_BO.setACNT_IN_DATE(time);
        DTDKG002_BO.setACNT_AMT(ACNT_AMT);
        DTDKG002_BO.setBAL_AMT(ACNT_AMT);
        DTDKG002_BO.setTMP_IN_CD(MapUtils.getString(tmpInfoMap, "TMP_IN_CD"));
        DTDKG002_BO.setRESN_NO("01");
        DTDKG002_BO.setLST_CHG_DIV(OpUnit);
        DTDKG002_BO.setLST_CHG_ID(userId);
        DTDKG002_BO.setLST_CHG_DATE(time);
        DTDKG002_BO.setPOLICY_NO(CRT_NO);//�O�渹�X
        DTDKG002_BO.setPAY_TIMES(MapUtils.getString(tmpInfoMap, "CUS_NO"));//ú��
        DTDKG002_BO.setCAT_PREM(MapUtils.getString(tmpInfoMap, "PAY_KIND"));//���O����
        String APLY_NO = MapUtils.getString(tmpInfoMap, "BLD_CD");
        DTDKG002_BO.setAPLY_NO(APLY_NO);//���z�s��
        if (CHK_LIST != null && CHK_LIST.size() > 0) {
            Map CHK_INFO_MAP = CHK_LIST.get(0);
            String ACNT_NO = MapUtils.getString(CHK_INFO_MAP, "ACNT_NO");
            String CHK_NO = MapUtils.getString(CHK_INFO_MAP, "CHK_NO");//�q��2�X�����5�X
            DTDKG002_BO.setCHK_SET_NO(CHK_SET_NO);// ���ڲո�
            DTDKG002_BO.setBANK_NO(MapUtils.getString(CHK_INFO_MAP, "BANK_NO"));// ��w�N�� �䲼�Ȧ��ɻݿ�J
            DTDKG002_BO.setACNT_NO(ACNT_NO);// �Ȧ�b�� �䲼�Ȧ��ɻݿ�J
            DTDKG002_BO.setCHK_NO(CHK_NO);//���ڸ��X �䲼�Ȧ��ɻݿ�J
            DTDKG002_BO.setCHK_DATE(MapUtils.getString(CHK_INFO_MAP, "CHK_DATE"));//���ڤ�� �䲼�Ȧ��ɻݿ�J
            DTDKG002_BO.setCHK_STS_CODE("0");//���p 0�ݧI�{
            String CO_CHK_TYPE; //0 �^�y�� 0�D�^�y��
            if (StringUtils.isNotBlank(ACNT_NO) && ACNT_NO.length() > 5) {
                ReturnMessage msg = new ReturnMessage();
                new DJ_C0Z025().getCheckDetail_BO(ACNT_NO.substring(1, 6), CHK_NO, msg);
                CO_CHK_TYPE = (msg.getReturnCode() != ReturnCode.OK) ? "0" : "1";

            } else {
                CO_CHK_TYPE = "1";
            }
            DTDKG002_BO.setRETURN_IND(CO_CHK_TYPE);
        }
        //Call�����Ҧr���ˮּҲ�
        Id id = new Id();
        String tmpID = MapUtils.getString(tmpInfoMap, "ID", "");
        int Lenth = tmpID.length();
        if (StringUtils.isNotEmpty(tmpID) && (Lenth == 8 || Lenth == 10)) {
            if (Lenth == 10 && id.checkID1(tmpID)) {
                DTDKG002_BO.setID_KIND("1");
            } else if (Lenth == 8 && id.checkUniSN(tmpID)) {
                DTDKG002_BO.setID_KIND("3");
            } else {
                DTDKG002_BO.setID_KIND("2");
            }
        }
        DTDKG002_BO.setID(tmpID);
        DTDKG002_BO.setCST_NAME(MapUtils.getString(tmpInfoMap, "CUS_NAME"));
        DTDKG002_BO.setMEMO(MapUtils.getString(tmpInfoMap, "BLD_NAME"));
        DTDKG002_BO.setCURR("NTD");

        String BAL_TYPE = new EP_Z0G103().getBAL_TYPE(SUB_CPY_ID, APLY_NO, tmpInfoMap, CRT_NO);
        new EP_C30020().setBAL_TYPEforDKG002(DTDKG002_BO, BAL_TYPE);

        //Call�Ȧ��J�b��J�B�R���Ҳ�.�s�W�������J�b�ɤ�k 
        ReturnMessage rm = new ReturnMessage();
        /* [20180227] �s�W�P�_���I�sEP_Z00030  */
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            TMP_NO = new DK_G0Z002().insertDTDKG002ForXA(DTDKG002_BO, rm);
            if (rm.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30050_MSG_005") + rm.getMsgDesc());//�g�J�Ȧ����ӵo�Ϳ��~,
            }
        } else {
            //[20180227]�D��ا�gEP.�Ȧ��� 
            DTEPC309 C309VO = new DTEPC309();
            VOTool.copyVOFromTo(DTDKG002_BO, C309VO);
            C309VO.setLST_CHG_DATE(DATE.currentTime());
            C309VO.setACNT_IN_DATE(DATE.currentTime());
            C309VO.setSUB_CPY_ID(SUB_CPY_ID);
            TMP_NO = new EP_Z0C309().insertDTEPC309(C309VO);
        }

        return TMP_NO;
    }

    /**
     * �R���Ȧ��J�b��T
     * @param TMP_NO �Ȧ��J�b�s��
     * @param SUB_CPY_ID �����q�O
     * @throws Exception
     */
    public void deleteTmpInfo(String TMP_NO, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(TMP_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30050_MSG_006"));//�ǼȦ��J�b�s�����o����
        }
        /* [20180208] �s�W�ǤJ�Ѽ� SUB_CPY_ID  */
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30050_MSG_001"));//�ǤJ�����q�O���o����
        }
        if (eie != null) {
            throw eie;
        }
        EP_Z00030 theEP_Z00030 = new EP_Z00030();

        //Call�Ȧ��J�b��J�B�R���Ҳ�.�H�u��J�����Ю֫�R���|�p������k
        ReturnMessage rm = new ReturnMessage();
        /* [20180208] �s�W�P�_���I�sEP_Z00030  */
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
            new DK_G0Z002().deleteDTDKG002ByTMP_NOForXA(TMP_NO, rm);
            if (rm.getReturnCode() != 0) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30050_MSG_007") + rm.getMsgDesc());//�R���Ȧ����ӵo�Ϳ��~,
            }
        } else {
            //[20180227]�D��ا�gEP.�Ȧ���
            new EP_Z0C309().deleteDTEPC309ByTMP_NO(SUB_CPY_ID, TMP_NO);
        }
    }

    /**
     * ���Ȥ~�]�ܼ�
     * @param ds
     * @param key
     * @param value
     */
    private void setfieldIfExist(DataSet ds, Map reqMap, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

}
