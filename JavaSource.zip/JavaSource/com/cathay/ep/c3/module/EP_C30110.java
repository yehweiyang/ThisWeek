package com.cathay.ep.c3.module;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.CathayZipUtils;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.FileService;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dk.a0.bo.DK_AAZ011_bo;
import com.cathay.dk.a0.module.DK_A0Z003;
import com.cathay.dk.bo.DTDKF001;
import com.cathay.dk.f0.module.DK_F0Z017;
import com.cathay.dk.f0.module.DK_F0Z025;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C301;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * Date Version Description Author
 * 2013/9/6    1.0 �s�W  �\�a�s
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �H�Υd�дھP�b�Ҳ�
 * �{���W��    EP_C30110 
 * ���n����    �qDTEPB102_����_�ӯ�����, DTEPB202_�Ȥ�_�H�Υd���v�Ѹ��, DTEPC101_������
 * </pre>
 * 
 * [20180208] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * 
 * [20200413]�ק��
 * 
 * @author �x�Ԫ�
 * @since 2013/12/25
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C30110 {
    private static final Logger log = Logger.getLogger(EP_C30110.class);

    /** �P�b���� 1.�Ȧ��� , 2.��@�Ȥ� */
    private static final String[] DACNT_TYPEs = { "1", "2" };

    private static final String SQL_queryList_001 = "com.cathay.ep.c3.module.EP_C30110.SQL_queryList_001";

    //private static final String SQL_checkRptMap_001 = "com.cathay.ep.c3.module.EP_C30110.SQL_checkRptMap_001";

    private static final String SQL_getC101Map_001 = "com.cathay.ep.c3.module.EP_C30110.SQL_getC101Map_001";

    private static final String SQL_deleteDTEPC308_001 = "com.cathay.ep.c3.module.EP_C30110.SQL_deleteDTEPC308_001";

    private static final String SQL_insertDTEPC308_001 = "com.cathay.ep.c3.module.EP_C30110.SQL_insertDTEPC308_001";

    /**
     * �d��ú�ڸ��
     * @param ACNT_DATE  Date    �ǲ����
     * @param ACNT_DIV_NO  String  �b�ȳ�� 
     * @param SLIP_SET_NO  String  �ǲ��ո�
     * @param SUB_CPY_ID �����q�O  
     * @return rtnList List<Map>   ú�ڸ��List
     */
    public List<Map> queryList(Date ACNT_DATE, String ACNT_DIV_NO, String SLIP_SET_NO, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_001");//�ǲ�������o���ŭ�
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_002");//�b�ȳ�줣�o���ŭ�
        }
        if (StringUtils.isBlank(SLIP_SET_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_003");//�ǲ��ո����o���ŭ�
        }
        /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_022");//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_queryList_001);
    }

    /**
     * �����r������List (�Ȧ���W��)
     * @param filePATH String �ɮ׸��|
     * @param DACNT_TYPE String �P�b����
     * @param SUB_CPY_ID String �����q�O  
     * @return  rtnList List<Map>   ���List
     */
    public List<Map> rptStr2List1(String filePATH, String DACNT_TYPE, String SUB_CPY_ID) throws ModuleException, IOException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(filePATH)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_004"); // �ɮ׸��|���o����!
        }
        if (StringUtils.isBlank(DACNT_TYPE) || !ArrayUtils.contains(DACNT_TYPEs, DACNT_TYPE)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_017");//�P�b�������~!
        }
        /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_022");//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        StringBuilder sb = new StringBuilder();
        // [20200413]�ק�{���X: �ק令Ū�����Y��
        File zipfile = new File(filePATH);
        if (!zipfile.exists()) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_025")); // �W���ɮפ��o����
        }
        if (!"zip".equals(FilenameUtils.getExtension(filePATH).toLowerCase())) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_027")); // �W���ɮװ��ɦW����zip
        }

        String zipFullPath = FilenameUtils.getFullPath(filePATH); // �s��zip����Ƨ�
        String newFolderName = zipFullPath + FilenameUtils.getBaseName(filePATH); // �s��txt����Ƨ�
        File txtPath = new File(newFolderName);
        if (!txtPath.exists()) {
            txtPath.mkdirs();
        }

        String filePassword = FieldOptionList.getName("EP", "EP_RA016_ZIP", "UNZIP_WORD");
        try {
            CathayZipUtils.unZipFile(zipfile, txtPath, filePassword); // �����Y
        } catch (Exception e) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_028", new String[] { e.getMessage() }));//�����Y����
        }

        List<Map> rtnList = new ArrayList<Map>();
        String[] txtNames = txtPath.list();
        if (txtNames.length != 0) {
            String txtName = txtNames[0]; // �����Y�X�Ӫ�txt�ɦW
            if (!"txt".equals(FilenameUtils.getExtension(txtName).toLowerCase())) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_026")); // �����Y�᪺�ɮװ��ɦW����txt
            }

            FileService theFileService = new FileService(sb.append(newFolderName).append('/') + txtName);
            sb.setLength(0);
            DataSet ds = Transaction.getDataSet();
            while (theFileService.hasNextLine()) {
                String str = theFileService.nextLine();
                /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
                Map tempMap = this.rptStr2Map(str, ds, sb, SUB_CPY_ID);
                if (tempMap != null && !tempMap.isEmpty()) {
                    rtnList.add(tempMap);
                }
            }
        }
        if (rtnList.isEmpty()) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_016"));//�W���ɮ׸�Ƥ��o����
        }
        return rtnList;
    }

    /**
     * �����r������List (��@�Ȥ�W��)
     * @param filePATH String �ɮ׸��|
     * @param DACNT_TYPE String �P�b����
     * @param SUB_CPY_ID String �����q�O  
     * @return  rtnList List<Map>   ���List
     */
    public List<Map> rptStr2List2(InputStream is, String DACNT_TYPE, String SUB_CPY_ID) throws ModuleException, IOException {
        ErrorInputException eie = null;
        if (is == null) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_004");//�ɮ׸�Ƥ��o����!
        }
        if (StringUtils.isBlank(DACNT_TYPE) || !ArrayUtils.contains(DACNT_TYPEs, DACNT_TYPE)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_017");//�P�b�������~!
        }
        /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_022");//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        List<Map> rtnList = new ArrayList<Map>();
        StringBuilder sb = new StringBuilder();
        BufferedReader br = EncodingHelper.getBufferedReader(is);
        DataSet ds = Transaction.getDataSet();
        try {
            String str = br.readLine();
            while (StringUtils.isNotBlank(str)) {
                //��@�Ȥ�H�Υd�P�b
                /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
                Map tempMap = this.rptStr2Map_2(str, ds, sb, SUB_CPY_ID);
                if (tempMap != null && !tempMap.isEmpty()) {
                    rtnList.add(tempMap);
                }
                str = br.readLine();
            }
        } finally {
            if (is != null) {
                is.close();
            }
            if (br != null) {
                br.close();
            }
        }
        if (rtnList.isEmpty()) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_016"));//�W���ɮ׸�Ƥ��o����
        }
        return rtnList;
    }

    /**
     * �H�e�����List�i��P�b
     * @param rtnList List<Map> ���List
     * @param ACNT_DATE  Date    �ǲ����
     * @param ACNT_DIV_NO  String  �b�ȳ��
     * @param USER   UserObject  �ϥΪ̸�T
     * @param SUB_CPY_ID �����q�O
     */
    public String doSB(List<Map> rtnList, Date ACNT_DATE, String ACNT_DIV_NO, UserObject USER, String DACNT_TYPE, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (rtnList == null || rtnList.isEmpty()) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_008");//�ǤJ��Ƥ��o����!
        }
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_001");//�ǲ�������o����!
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_002");//�b�ȳ�줣�o����!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (USER == null) {
            throw eie;
        }
        //���X��ƫ�I�s�ҲվP�b
        String SLIP_LOT_NO = null;
        for (Map map : rtnList) {
            if (StringUtils.isNotBlank(MapUtils.getString(map, "ERRMSG"))) {
                throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_009"));//�W�Ǹ�ƥ����Ƴq�L�ˮ֡A�нT�{��A�P�b!
            }
            String ACNT_TYPE = MapUtils.getString(map, "ACNT_TYPE");
            SLIP_LOT_NO = "1".equals(ACNT_TYPE) ? "EPC" : "EPO";
        }
        DataSet ds = Transaction.getDataSet();
        //String SLIP_LOT_NO = "EPC"; //�H�Υd�帹
        ReturnMessage msg = new ReturnMessage();
        /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
        String TRN_SER_NO = this.getTRN_SER_NO(ACNT_DATE, USER, SUB_CPY_ID, msg);
        BigDecimal bigTRN_SER_NO = getDecimal(TRN_SER_NO);

        ds.clear();
        /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
        String SLIP_SET_NO = this.getSLIP_SET_NO(ACNT_DATE, SLIP_LOT_NO, USER, SUB_CPY_ID, msg);
        Integer intSLIP_SET_NO = NumberUtils.isDigits(SLIP_SET_NO) ? Integer.valueOf(SLIP_SET_NO) : 0;

        List<DK_AAZ011_bo> DK_A0Z011boList = new ArrayList<DK_AAZ011_bo>();
        EP_C30020 theEP_C30020 = new EP_C30020();
        EP_C30040 theEP_C30040 = new EP_C30040();
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        String EmpID = USER.getEmpID();
        String EmpName = USER.getEmpName();
        String currentTime = DATE.getDBTimeStamp();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();

        for (Map tempMap : rtnList) {
            BigDecimal SPR_AMT = obj2Big(tempMap, "SPR_AMT", null);
            String PAY_KIND = MapUtils.getString(tempMap, "PAY_KIND");
            String RCV_NO = MapUtils.getString(tempMap, "RCV_NO");
            String RCV_YM = MapUtils.getString(tempMap, "RCV_YM");
            String ACNT_TYPE = MapUtils.getString(tempMap, "ACNT_TYPE");

            BigDecimal ALPY_AMT = obj2Big(tempMap, "ALPY_AMT", null);//�дڪ��B
            BigDecimal FEE_AMT = obj2Big(tempMap, "FEE_AMT", null);//����O
            BigDecimal NET_AMT = obj2Big(tempMap, "PAY_AMT", null);//���ڲb�B

            Map dataMap = new HashMap();
            dataMap.put("RCV_NO", RCV_NO);
            dataMap.put("SUB_CPY_ID", SUB_CPY_ID);
            dataMap.put("RCV_YM", RCV_YM);
            dataMap.put("PAY_KIND", PAY_KIND);
            dataMap.put("CRT_NO", tempMap.get("CRT_NO"));
            dataMap.put("CUS_NO", tempMap.get("CUS_NO"));
            dataMap.put("PAY_TYPE", "7");//�H�Υd
            log.debug("yenhoDACNT_TYPE=>" + DACNT_TYPE + "@" + NET_AMT);
            if ("1".equals(DACNT_TYPE)) {//�Ȧ���
                dataMap.put("PAY_AMT", SPR_AMT);
                dataMap.put("ALPY_AMT", SPR_AMT);//�дڪ��B
                dataMap.put("FEE_AMT", "0"); //����O
                dataMap.put("NET_AMT", SPR_AMT); //���ڲb�B
            } else if ("2".equals(DACNT_TYPE)) { //��@�Ȥ�H�Υd�P�b
                //dataMap.put("PAY_AMT", PAY_AMT);  //���ڲb�B
                dataMap.put("PAY_AMT", ALPY_AMT); //�дڪ��B 1030606 YENHO �վ㬰�дڪ��B
                dataMap.put("ALPY_AMT", ALPY_AMT);//�дڪ��B
                dataMap.put("FEE_AMT", FEE_AMT); //����O
                dataMap.put("NET_AMT", NET_AMT); //���ڲb�B
            }
            dataMap.put("SPR_AMT", tempMap.get("SPR_AMT_ORI"));
            dataMap.put("INV_NO", tempMap.get("INV_NO"));
            dataMap.put("ID", tempMap.get("ID"));
            dataMap.put("CUS_NAME", tempMap.get("CUS_NAME"));
            dataMap.put("BLD_CD", tempMap.get("BLD_CD"));
            dataMap.put("PAY_S_DATE", tempMap.get("PAY_S_DATE"));
            dataMap.put("PAY_E_DATE", tempMap.get("PAY_E_DATE"));

            dataMap.put("CARD_NO", tempMap.get("CARD_NO"));//�H�Υd��
            dataMap.put("STORE_ID", tempMap.get("STORE_ID"));//�ө��N��
            dataMap.put("STORE_NAME", tempMap.get("STORE_NAME"));//�ө��W��
            dataMap.put("PAY_DATE", tempMap.get("PAY_S_DATE"));//���ڤ��

            List PAY_LIST = new ArrayList();
            PAY_LIST.add(dataMap);
            //theEP_C30020.insertRtlInfo(dataMap, USER);
            Map PAY_MAP = new HashMap();
            PAY_MAP.put("CARD_D_AMT", SPR_AMT);
            PAY_MAP.put("PAY_AMT", SPR_AMT);
            PAY_MAP.put("DACNT_AMT", SPR_AMT);
            PAY_MAP.put("PAY_TYPE", "7");//�H�Υd

            //�s�W�H�Υd�P�b������(DTEPC308)
            String CARD_D_NO = this.insertDTEPC308(dataMap, ACNT_DATE.toString(), ACNT_DIV_NO, SLIP_LOT_NO, SLIP_SET_NO, TRN_SER_NO, USER);
            PAY_MAP.put("CARD_D_NO", CARD_D_NO);//�H�Υd�P�b�s��
            //����ú�O���p //�]�bfor loop��  �G����buds update
            theEP_C30020.insertPayInfo("EPC3_0110", PAY_MAP, PAY_LIST, null, null, null, null, null, null, USER, null);
            String PAY_NO = MapUtils.getString(dataMap, "PAY_NO");

            String BAL_TYPE = theEP_Z0G103.getBAL_TYPE(MapUtils.getString(tempMap, "SUB_CPY_ID"), MapUtils.getString(tempMap, "BLD_CD"));

            //�b�ȽT�{ update C306 C301
            theEP_C30040.updateCloseAcntInfo(RCV_YM, PAY_NO, RCV_NO, "06", ACNT_DATE, ACNT_DIV_NO, SLIP_LOT_NO, intSLIP_SET_NO, bigTRN_SER_NO, USER, BAL_TYPE, false, SUB_CPY_ID);//06->�H�Υd

            //            Map tempC101Map = this.getC101Map(PAY_KIND, MapUtils.getString(tempMap,"CRT_NO"), MapUtils.getString(tempMap,"CUS_NO")
            //                , (Date) MapUtils.getObject(dataMap, "PAY_S_DATE"), (Date) MapUtils
            //                .getObject(dataMap, "PAY_E_DATE"), MapUtils.getString(tempMap,"INV_NO"), ds);
            /* [20180208] �s�W�P�_���I�sEP_Z00030  */
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                if ("1".equals(DACNT_TYPE)) {
                    this.setDK_A0Z011(DK_A0Z011boList, SPR_AMT, PAY_KIND, ACNT_DATE, ACNT_DIV_NO, SLIP_LOT_NO, SLIP_SET_NO, TRN_SER_NO, EmpID, EmpName, currentTime, MapUtils.getString(tempMap, "DIV_NO"), ACNT_TYPE, BAL_TYPE);
                } else if ("2".equals(DACNT_TYPE)) {
                    //��@�Ȥ�H�Υd�P�b
                    log.debug("yenho259=>" + ALPY_AMT + "@" + FEE_AMT + "@" + NET_AMT);
                    this.setDK_A0Z011_2(DK_A0Z011boList, ALPY_AMT, FEE_AMT, NET_AMT, PAY_KIND, ACNT_DATE, ACNT_DIV_NO, SLIP_LOT_NO, SLIP_SET_NO, TRN_SER_NO, EmpID, EmpName, currentTime, MapUtils.getString(tempMap, "DIV_NO"), ACNT_TYPE, BAL_TYPE);
                }
            } // end if theEP_Z00030.isAccountSubCpy
        } //end for

        new DK_A0Z003().doInsert(DK_A0Z011boList, msg);
        if (msg.getReturnCode() != ReturnCode.OK) {
            StringBuilder sb = new StringBuilder();
            throw new ModuleException(sb.append(MessageUtil.getMessage("EP_C30110_MSG_010")).append(msg.getMsgDesc()).toString());//�H�Υd�X�b���`:
        }
        return SLIP_SET_NO;
    }

    /**
     * �H�e�����List�i������P�b
     * @param ACNT_DATE  Date    �ǲ����
     * @param ACNT_DIV_NO  String  �b�ȳ��
     * @param SLIP_SET_NO  String  �ǲ��ո�
     * @param USER  UserObject  �ϥΪ̸�T
     */
    public void doCancelSB(Date ACNT_DATE, String ACNT_DIV_NO, String SLIP_SET_NO, UserObject USER, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_001");//�ǲ�������o����!
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_002");//�b�ȳ�줣�o����!
        }
        if (StringUtils.isBlank(SLIP_SET_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_003");//�ǲ��ո����o����!
        }
        if (USER == null) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_013");//�ϥΪ̸�T���o����!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //��ƭ��d
        /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
        List<Map> rtnList = this.queryList(ACNT_DATE, ACNT_DIV_NO, SLIP_SET_NO, SUB_CPY_ID);

        String TRN_SER_NO = "";
        String SLIP_LOT_NO = "EPC";

        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        /* [20180208] �s�W�P�_���I�sEP_Z00030  */
        if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) { //��ؤ~�|�X�b
            //�R���e�����X����Ǹ�
            ReturnMessage msg = new ReturnMessage();
            String strACNT_DATE = ACNT_DATE.toString();
            List<DTDKF001> f001List = new DK_F0Z025().selectDTDKF001_2(ACNT_DIV_NO, strACNT_DATE, "EPC", SLIP_SET_NO, msg);
            if (msg.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(msg.getMsgDesc());
            }

            TRN_SER_NO = f001List.get(0).getTRN_SER_NO();
            //�R������
            DTDKF001 delDTDKF001 = new DTDKF001();
            delDTDKF001.setACNT_DATE(strACNT_DATE);//�b�Ȥ��
            delDTDKF001.setACNT_DIV_NO(ACNT_DIV_NO);//�b�ȳ��
            delDTDKF001.setSLIP_LOT_NO(SLIP_LOT_NO);//�ǲ��帹 
            delDTDKF001.setSLIP_SET_NO(SLIP_SET_NO);//�ǲ��ո�

            new DK_F0Z017().deleteByACNT_DIV_NO(delDTDKF001, msg);
            if (msg.getReturnCode() != ReturnCode.OK) {
                throw getModuleException("EP_C30110_MSG_014", msg.getMsgDesc());//�H�Υd�X�b���`:
            }
        }
        //�R���H�Υd�P�b������ 
        this.deleteDTEPC308(ACNT_DATE, ACNT_DIV_NO, SLIP_LOT_NO, SLIP_SET_NO, SUB_CPY_ID);

        //��s/�R�� -> ú�ڬ����ɮ�
        EP_Z0C301 theEP_Z0C301 = new EP_Z0C301();
        EP_C30020 theEP_C30020 = new EP_C30020();
        Integer intSLIP_SET_NO = NumberUtils.isDigits(SLIP_SET_NO) ? Integer.valueOf(SLIP_SET_NO) : 0;
        BigDecimal bigTRN_SER_NO = getDecimal(TRN_SER_NO);
        for (Map tempMap : rtnList) {
            String PAY_NO = MapUtils.getString(tempMap, "PAY_NO");
            //delete C301 
            theEP_Z0C301.updateRltAcntInfo(PAY_NO, "01", ACNT_DATE, ACNT_DIV_NO, "EPC", intSLIP_SET_NO, bigTRN_SER_NO, USER, SUB_CPY_ID);
            Map payNoMap = new HashMap();
            payNoMap.put("PAY_NO", PAY_NO);
            payNoMap.put("DACNT_AMT", MapUtils.getString(tempMap, "PAY_AMT"));
            payNoMap.put("SUB_CPY_ID", MapUtils.getString(tempMap, "SUB_CPY_ID"));
            //�]�bfor loop��  �G����buds update
            //delete C306 update C101 
            theEP_C30020.cancelPayInfo(payNoMap, null);
        }
    }

    /**
     * �R���H�Υd�P�b������
    * @param ACNT_DATE  Date    �ǲ����
    * @param ACNT_DIV_NO String  �b�ȳ��
    * @param SLIP_LOT_NO String  �ǲ��帹
    * @param SLIP_SET_NO String  �ǲ��ո�
    * @throws ModuleException
    */
    public void deleteDTEPC308(Date ACNT_DATE, String ACNT_DIV_NO, String SLIP_LOT_NO, String SLIP_SET_NO, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_001");//�ǲ�������o����!
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_002");//�b�ȳ�줣�o����!
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_018");//�ǲ��帹���o����!
        }
        if (StringUtils.isBlank(SLIP_SET_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_003");//�ǲ��ո����o����!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�R���H�Υd�P�b������
        DataSet ds = Transaction.getDataSet();
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
        ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_deleteDTEPC308_001);
    }

    /**
     * �s�W�H�Υd�P�b������
     * @param dataMap Map �P�b���
     * @param ACNT_DATE  String  �b��
     * @param ACNT_DIV_NO String  �b�ȳ��
     * @param SLIP_LOT_NO String  �帹
     * @param SLIP_SET_NO String  �ǲ��ո�
     * @param TRN_SER_NO String  �g�����Ǹ�
     * @param user UserObject  �ϥΪ̸�T
     * @throws ModuleException
     */
    public String insertDTEPC308(Map dataMap, String ACNT_DATE, String ACNT_DIV_NO, String SLIP_LOT_NO, String SLIP_SET_NO, String TRN_SER_NO, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (dataMap == null || dataMap.isEmpty()) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_019");//�P�b��Ƥ��o����!
        }
        if (StringUtils.isBlank(ACNT_DATE)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_001");//�ǲ�������o����!
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_002");//�b�ȳ�줣�o����!
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_018");//�ǲ��帹���o����!
        }
        if (StringUtils.isBlank(SLIP_SET_NO)) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_003");//�ǲ��ո����o����!
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_C30110_MSG_013");//�ϥΪ̸�T���o����!
        }
        if (eie != null) {
            throw eie;
        }
        //�H�Υd�P�b�s��
        //Call�Ǹ����o�@�μҲ�.���o�y������k
        String yyyyMMdd = DATE.toDate_yyyyMMdd(DATE.getDBDate());
        String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID", "");
        int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "032", "001", yyyyMMdd);
        //�榡�ƫH�Υd�P�b�s��(14�X)  (ex:00201404300001) SUB_CPY_ID + yyyyMMdd + SER_NO�e��0��4�X
        StringBuffer sb = new StringBuffer();
        String CARD_D_NO = sb.append(SUB_CPY_ID).append(yyyyMMdd).append(STRING.fillZero(String.valueOf(SER_NO), 4, EncodingHelper.DefaultCharset)).toString();
        //�s�W�H�Υd�P�b������
        DataSet ds = Transaction.getDataSet();
        ds.setField("CARD_D_NO", CARD_D_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("STORE_ID", dataMap.get("STORE_ID"));
        ds.setField("PAY_DATE", dataMap.get("PAY_DATE"));
        ds.setField("CARD_NO", dataMap.get("CARD_NO"));
        ds.setField("STORE_NAME", dataMap.get("STORE_NAME"));
        ds.setField("ALPY_AMT", dataMap.get("ALPY_AMT"));
        ds.setField("FEE_AMT", dataMap.get("FEE_AMT"));
        ds.setField("NET_AMT", dataMap.get("NET_AMT"));
        ds.setField("EmpID", user.getEmpID());
        ds.setField("EmpName", user.getEmpName());
        ds.setField("currentTime", DATE.currentTime());
        ds.setField("TRN_SER_NO", TRN_SER_NO);
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
        ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        DBUtil.executeUpdate(ds, SQL_insertDTEPC308_001);

        return CARD_D_NO;

    }

    /**
     * �����r������Map(�Ȧ���W��)
     * @param rtnStr �����Ϊ��r��
     * @param ds DataSet
     * @param sb StringBuilder
     * @param SUB_CPY_ID �����q�O
     * @return dataMap Map ���Map
     * @throws ModuleException
     */
    private Map rptStr2Map(String rtnStr, DataSet ds, StringBuilder sb, String SUB_CPY_ID) throws ModuleException {
        Map dataMap = new HashMap();
        //CA11�}�Y = �̫�@��
        int rtnStrlen = this.impStrLen(rtnStr);

        if (rtnStrlen < 4) {
            dataMap.put("ERRMSG", MessageUtil.getMessage("EP_C30110_MSG_015"));//�ӵ���Ʀ����D  �нT�{ 
            return dataMap;
        }
        if ("CA11".equals(this.impSubStr(rtnStr, 0, 4))) {
            return null;
        }
        if (rtnStrlen < 116) {
            dataMap.put("ERRMSG", MessageUtil.getMessage("EP_C30110_MSG_015"));//�ӵ���Ʀ����D  �нT�{
            return dataMap;
        }
        if (!"000".equals(this.impSubStr(rtnStr, 113, 116))) {
            return null;
        }
        if (rtnStrlen < 147) {
            dataMap.put("ERRMSG", MessageUtil.getMessage("EP_C30110_MSG_015"));//�ӵ���Ʀ����D  �нT�{
            return dataMap;
        }
        dataMap.put("CARD_NO", this.impSubStr(rtnStr, 10, 26));
        dataMap.put("CRT_NO", this.impSubStr(rtnStr, 93, 103));
        dataMap.put("PAY_KIND", this.impSubStr(rtnStr, 111, 112));
        dataMap.put("INV_NO", this.impSubStr(rtnStr, 104, 111));//��7�X
        dataMap.put("CUS_NO", Integer.parseInt(this.impSubStr(rtnStr, 103, 104)));
        dataMap.put("SPR_AMT", new BigDecimal(this.impSubStr(rtnStr, 82, 91)));
        //6�X����~�몺��1�X=8��9 -> 08x/09x�~, ��L 1xx�~
        String tempPaySDate = this.impSubStr(rtnStr, 135, 141);
        String tempPayEDate = this.impSubStr(rtnStr, 141, 147);
        tempPaySDate = ((tempPaySDate.startsWith("8") || tempPaySDate.startsWith("9")) ? sb.append("0") : sb.append("1")).append(tempPaySDate).toString();
        sb.setLength(0);
        tempPayEDate = ((tempPayEDate.startsWith("8") || tempPayEDate.startsWith("9")) ? sb.append("0") : sb.append("1")).append(tempPayEDate).toString();
        sb.setLength(0);
        dataMap.put("PAY_S_DATE", DATE.parseROCDate(tempPaySDate));
        dataMap.put("PAY_E_DATE", DATE.parseROCDate(tempPayEDate));
        dataMap.put("STORE_ID", "200113000 "); //�ө��N��(�w��)
        dataMap.put("STORE_NAME", "200113000 "); //�ө��W��(�w��)
        dataMap.put("FEE_AMT", "0");//����O(�w��)

        //�q������, ú�O���p���ˮָ��
        /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
        this.checkRptMap(dataMap, ds, sb, SUB_CPY_ID);
        return dataMap;

    }

    /**
     * �W�ǳ�@�Ȥ�H�Υd�P�b�����r������Map
     * @param rtnStr  String  �����Ϊ��r��
     * @param ds DataSet
     * @param sb StringBuilder
     * @param SUB_CPY_ID �����q�O
     * @return dataMap Map ���Map
     * @throws ModuleException
     */
    private Map rptStr2Map_2(String rtnStr, DataSet ds, StringBuilder sb, String SUB_CPY_ID) throws ModuleException {
        Map dataMap = new HashMap();
        if (StringUtils.isBlank(rtnStr)) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_020"));//��Ʀ����D  �нT�{ 
        }
        String[] rtnStrs = rtnStr.split(",");
        if (rtnStrs.length < 13) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_020"));//��Ʀ����D  �нT�{  
        }
        //�̳r�����j�v�@��rtnStr���
        rtnStr.split(",");
        dataMap.put("STORE_ID", rtnStrs[0]); //�ө��N��
        String PAY_DATE = rtnStrs[1];
        if (!DATE.isROCDate(PAY_DATE, false)) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_020"));//��Ʀ����D  �нT�{  
        }
        dataMap.put("PAY_DATE", DATE.toY2KDate(PAY_DATE)); //���ڤ��
        dataMap.put("CARD_NO", rtnStrs[2]); //�d��
        dataMap.put("STORE_NAME", rtnStrs[3]); //�ө��W��
        dataMap.put("ALPY_AMT", rtnStrs[4]); //�дڪ��B

        String FEE_AMT = rtnStrs[5];
        if (!NumberUtils.isNumber(FEE_AMT)) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_020"));//��Ʀ����D  �нT�{  
        }
        dataMap.put("FEE_AMT", rtnStrs[5]); //����O
        dataMap.put("PAY_AMT", rtnStrs[6]); //���ڲb�B
        dataMap.put("CRT_NO", rtnStrs[7]); //�����N��
        String CUS_NO = rtnStrs[8];
        if (!NumberUtils.isDigits(CUS_NO)) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_020"));//��Ʀ����D  �нT�{  
        }
        dataMap.put("CUS_NO", CUS_NO); //�Ȥ�Ǹ�
        String RCV_YM = rtnStrs[9];
        if (!NumberUtils.isDigits(RCV_YM)) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30110_MSG_020"));//��Ʀ����D  �нT�{  
        }
        dataMap.put("RCV_YM", RCV_YM);//�����~��
        dataMap.put("RCV_NO", rtnStrs[10]);//�o�����X-----> �����2015/01/08 ��� �����s��  (�ɮצ����אּ�����s��)
        dataMap.put("PAY_KIND", "");//ú�ڤ覡
        dataMap.put("SPR_AMT", rtnStrs[4]);
        dataMap.put("PAY_S_DATE", DATE.parseROCDate(rtnStrs[11]));//����~���
        dataMap.put("PAY_E_DATE", DATE.parseROCDate(rtnStrs[12]));//����~���
        //�q������, ú�O���p���ˮָ��
        /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
        this.checkRptMap(dataMap, ds, sb, SUB_CPY_ID);
        return dataMap;
    }

    /**
     * substring ������קP�_�᭫�s���o���
     * @param str
     * @param start
     * @param end
     * @return
     */
    private String impSubStr(String str, int start, int end) {
        int newStart = 0;
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            count += STRING.doubleByteLength(str.substring(i, i + 1), EncodingHelper.DefaultCharset);
            if (count > start) {
                newStart = i;
                break;
            }
        }
        count = 0;
        int newEnd = 0;
        for (int i = 0; i < str.length(); i++) {
            count += STRING.doubleByteLength(str.substring(i, i + 1), EncodingHelper.DefaultCharset);
            if (count > end) {
                newEnd = i;
                break;
            }
        }
        return str.substring(newStart, newEnd);
    }

    /**
     * ���o�r����� (�t����)
     * @param str
     * @return
     */
    private int impStrLen(String str) {
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            count += STRING.doubleByteLength(str.substring(i, i + 1), EncodingHelper.DefaultCharset);
        }
        return count;
    }

    /**
     * �ˮֳ����r�ꪺ���Map
     * @param dataMap Map ���Map
     * @param ds DataSet
     * @param SUB_CPY_ID 
     * @param sb StringBuilder
     */
    private void checkRptMap(Map dataMap, DataSet ds, StringBuilder errsb, String SUB_CPY_ID) throws ModuleException {
        //�q�������ˮָ��
        String PAY_KIND = MapUtils.getString(dataMap, "PAY_KIND");
        String CRT_NO = MapUtils.getString(dataMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(dataMap, "CUS_NO");
        String INV_NO = MapUtils.getString(dataMap, "INV_NO");
        String dataRCV_NO = MapUtils.getString(dataMap, "RCV_NO");//��@�Ȥ�

        /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
        Map tempC101Map = this.getC101Map(PAY_KIND, CRT_NO, CUS_NO, (Date) MapUtils.getObject(dataMap, "PAY_S_DATE"), (Date) MapUtils.getObject(dataMap, "PAY_E_DATE"), INV_NO, dataRCV_NO, SUB_CPY_ID, ds);
        if (tempC101Map == null || tempC101Map.isEmpty()) {
            errsb.append(MessageUtil.getMessage("EP_C30110_MSG_005"));//�����ɸ�Ƥw���s�b,�G����P�b!
        } else {
            BigDecimal tempC101SPR_AMT = (BigDecimal) MapUtils.getObject(tempC101Map, "SPR_AMT", BigDecimal.ZERO);
            BigDecimal dataSPR_AMT = getDecimal(dataMap.get("SPR_AMT"));
            String ACNT_DATE = MapUtils.getObject(tempC101Map, "ACNT_DATE", "").toString();
            //�ˮ������b�O�_�w�X�~�i�P�b
            if (StringUtils.isBlank(PAY_KIND)) {
                PAY_KIND = MapUtils.getString(tempC101Map, "PAY_KIND");
            }
            if (!"3".equals(PAY_KIND)) {
                if (StringUtils.isBlank(ACNT_DATE)) {
                    errsb.append(MessageUtil.getMessage("EP_C30110_MSG_021"));//�����b�ȥ��T�{,�G����P�b!
                }
            }
            if (tempC101SPR_AMT.compareTo(dataSPR_AMT) != 0) {
                errsb.append(MessageUtil.getMessage("EP_C30110_MSG_006"));//ú�O���B����,�G����P�b!
            }
            SUB_CPY_ID = MapUtils.getString(tempC101Map, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                errsb.append(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
            String BLD_KD_1 = MapUtils.getString(tempC101Map, "BLD_KD_1");
            dataMap.put("PAY_KIND", PAY_KIND);
            dataMap.put("BLD_KD_1", BLD_KD_1);//�ϧO���M 
            dataMap.put("ACNT_TYPE", "9".equals(BLD_KD_1) ? "2" : "1");//9����鲣�M  ��L���@��
            dataMap.put("BLD_CD", tempC101Map.get("BLD_CD"));
            dataMap.put("INV_NO", tempC101Map.get("INV_NO"));
            dataMap.put("ID", tempC101Map.get("ID"));
            dataMap.put("CUS_NAME", tempC101Map.get("CUS_NAME"));
            dataMap.put("BLD_NAME", tempC101Map.get("BLD_NAME"));
            String RCV_YM = MapUtils.getString(tempC101Map, "RCV_YM");
            dataMap.put("RCV_YM", RCV_YM);
            String RCV_NO = MapUtils.getString(tempC101Map, "RCV_NO");
            dataMap.put("RCV_NO", RCV_NO);
            dataMap.put("PAY_NO", tempC101Map.get("PAY_NO"));
            dataMap.put("SUB_CPY_ID", SUB_CPY_ID);
            dataMap.put("SPR_AMT_ORI", tempC101Map.get("SPR_AMT"));
            dataMap.put("BLD_NAME", tempC101Map.get("BLD_NAME"));
            dataMap.put("DIV_NO", tempC101Map.get("DIV_NO"));
            //2020-02-06���D��s�� 20200205-0146 BY�E�Ͷv
            //�H�Υd�P�b�W�ǡA����A108100979��ܡGú�O���Ӹ�Ƥw�s�b�A�G���s�W!
            //�]�ӥ�즳�Ȧ��A�G���������Ȥ�n�D���R���Ȧ��A�ѤU�l�B�ΫH�Υd�P�b�A
            //���H�Υd�P�b�W�ǮɤS�|�ˮָӵ������w��ú�ڬ����N����A�@�~�A�ɭPUSER�L�k�P�b�C
            //--
            //��USER�T�{�P�b�W�ǥ��ӴN���ˮ������l�B=�H�Υdú�ڪ��B�@�P�~��P�b�A���ݭn�h�ˮ֤w��ú�ڬ����������A�G�{���ݽվ�A�����ˮ֡C
            //--
            //�qú�O���p���ˮָ��
            /*ds.clear();
            ds.setField("RCV_YM", RCV_YM);
            ds.setField("RCV_NO", RCV_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            if (DBUtil.searchAndRetrieve(ds, SQL_checkRptMap_001, false) != 0) {
                errsb.append(MessageUtil.getMessage("EP_C30110_MSG_007"));//ú�O���Ӹ�Ƥw�s�b�A�G���s�W!
            }*/
        }
        dataMap.put("ERRMSG", errsb.toString());
        errsb.setLength(0);
    }

    /**
     * ���o������Map
     * @param PAY_KIND   String  ú�ں���
     * @param CRT_NO   String  �����N��
     * @param CUS_NO   String  �Ȥ�Ǹ�
     * @param PAY_S_DATE  Date    ú�ڰ_��
     * @param PAY_E_DATE  Date    ú�ڲ״�
     * @param INV_NO  String  �o�����X
     * @param SUB_CPY_ID �����q�O
     * @param ds DataSet
     * @return  C101MAP Map ������
     */
    private Map getC101Map(String PAY_KIND, String CRT_NO, String CUS_NO, Date PAY_S_DATE, Date PAY_E_DATE, String INV_NO, String RCV_NO, String SUB_CPY_ID, DataSet ds) throws ModuleException {
        ds.clear();
        if (StringUtils.isNotBlank(PAY_KIND)) {
            ds.setField("PAY_KIND", PAY_KIND);
        }
        if (StringUtils.isNotBlank(RCV_NO)) {
            ds.setField("RCV_NO", RCV_NO);
        } else {
            if (StringUtils.isNotBlank(INV_NO)) {
                StringBuilder sb = new StringBuilder();
                ds.setField("INV_NO_LIKE", sb.append('%').append(INV_NO.trim()).toString());
            } else {
                ds.setField("INO_NO_1", "1");
            }
        }
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("PAY_S_DATE", PAY_S_DATE);
        ds.setField("PAY_E_DATE", PAY_E_DATE);
        /* [20180208] �s�W�ǤJ�Ѽ�   SUB_CPY_ID */
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            return VOTool.findOneToMap(ds, SQL_getC101Map_001);
        } catch (DataNotFoundException e) {
            return null;
        }
    }

    /**
     * ���o�P�b����Ǹ�
     * @param ACNT_DATE  Date    �ǲ����
     * @param USER  UserObject  �ϥΪ̸�T
     * @param SUB_CPY_ID �����q�O
     * @param ReturnMessage msg
     * @return  TRN_SER_NO  String  ����Ǹ�
     */
    private String getTRN_SER_NO(Date ACNT_DATE, UserObject USER, String SUB_CPY_ID, ReturnMessage msg) throws ModuleException {

        String TRN_SER_NO = null;
        try {
            /* [20180208] ��ѩI�sEP_Z0Z001���oTRN_SER_NO */
            TRN_SER_NO = new EP_Z0Z001().getTRN_SER_NO(SUB_CPY_ID, USER.getEmpID(), String.valueOf(ACNT_DATE), msg);

            if (msg.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(msg.getMsgDesc());
            }
        } catch (Exception e) {
            log.error("���o�g�����Ǹ����~�A", e);
            throw getModuleException("EP_C30110_MSG_023", e.getMessage());//���o�g�����Ǹ����~
        }

        return TRN_SER_NO;
    }

    /**
     * ���o�ǲ��ո�
     * @param ACNT_DATE   Date    �ǲ����
     * @param SLIP_LOT_NO  String  �ǲ��帹
     * @param USER   UserObject  �ϥΪ̸�T
     * @param SUB_CPY_ID �����q�O
     * @param ReturnMessage msg
     * @return SLIP_SET_NO String  �ǲ��ո�
     */
    private String getSLIP_SET_NO(Date ACNT_DATE, String SLIP_LOT_NO, UserObject USER, String SUB_CPY_ID, ReturnMessage msg) throws Exception {
        String SLIP_SET_NO = null;
        try {
            /* [20180208] ��ѩI�sEP_Z0Z001���oSLIP_SET_NO */
            SLIP_SET_NO = new EP_Z0Z001().getSLIP_SET_NO(SUB_CPY_ID, "2", USER.getEmpID(), null, SLIP_LOT_NO, String.valueOf(ACNT_DATE), msg);

            if (msg.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(msg.getMsgDesc());
            }
        } catch (Exception e) {
            log.error("���o�ǲ��ո����~�A", e);
            throw getModuleException("EP_C30110_MSG_024", e.getMessage());//���o�ǲ��ո����~
        }
        return SLIP_SET_NO;

    }

    /**
     * �ഫ�X�bbo
     * @param DK_A0Z011boList DK_A0Z011boList    ���ʲ��X�bbo
     * @param AMT  BigDecimal  ���B
     * @param PAY_KIND  String  �I�ں���
     * @param ACNT_DATE  Date    �ǲ����
     * @param ACNT_DIV_NO  String  �s�����
     * @param SLIP_LOT_NO  String  �ǲ��帹
     * @param SLIP_SET_NO  String  �ǲ��ո�
     * @param TRN_SER_NO  String  ����Ǹ�
     * @param String  EmpID  
     * @param String  EmpName
     * @param String  currentTime
     */
    private void setDK_A0Z011(List<DK_AAZ011_bo> DK_A0Z011boList, BigDecimal AMT, String PAY_KIND, Date ACNT_DATE, String ACNT_DIV_NO, String SLIP_LOT_NO, String SLIP_SET_NO, String TRN_SER_NO, String EmpID, String EmpName, String currentTime,
            String ACNT_DIV_NO_C101, String ACNT_TYPE, String BAL_TYPE) {
        String strACNT_DATE = ACNT_DATE.toString();
        String strAMT = AMT.toString();

        DK_AAZ011_bo bo = new DK_AAZ011_bo();
        bo.setINPUT_ID(EmpID);
        bo.setINPUT_NAME(EmpName);
        bo.setTRN_DATE(currentTime);
        bo.setTRN_SER_NO(TRN_SER_NO);
        bo.setSLIP_LOT_NO(SLIP_LOT_NO);
        bo.setSLIP_SET_NO(SLIP_SET_NO);
        bo.setACNT_DATE(strACNT_DATE);
        bo.setACNT_DIV_NO(ACNT_DIV_NO);//1030606 yenho�վ�
        bo.setBUS_CODE("EP");
        bo.setBUS_TRAN_CODE("1");
        bo.setAMT(strAMT);
        bo.setITEM("12");//�H�Υd�P�b
        bo.setTYPE("1");//�H�Υd�N���N�I
        bo.setREL_FILE_NO("EPC30110");
        bo.setTRN_KIND("EPC301");
        bo.setACNT_TYPE(ACNT_TYPE);
        bo.setBAL_TYPE(BAL_TYPE);
        DK_A0Z011boList.add(bo);

        bo = new DK_AAZ011_bo();
        bo.setINPUT_ID(EmpID);
        bo.setINPUT_NAME(EmpName);
        bo.setTRN_DATE(currentTime);
        bo.setTRN_SER_NO(TRN_SER_NO);
        bo.setSLIP_LOT_NO(SLIP_LOT_NO);
        bo.setSLIP_SET_NO(SLIP_SET_NO);
        bo.setACNT_DATE(strACNT_DATE);
        bo.setACNT_DIV_NO(ACNT_DIV_NO);//1030606 yenho�վ㬰
        bo.setBUS_CODE("EP");
        bo.setBUS_TRAN_CODE("1");
        bo.setAMT(AMT.toString());
        bo.setITEM("12"); //�H�Υd�P�b
        bo.setTYPE(("3".equals(PAY_KIND)) ? "2" : "3"); //3:�޲z�O->TYPE:2 ; ��L:����->TYPE:3.
        bo.setDIV_NO_C101(ACNT_DIV_NO_C101);
        bo.setREL_FILE_NO("EPC30110");
        bo.setTRN_KIND("EPC301");
        bo.setACNT_TYPE(ACNT_TYPE);
        bo.setBAL_TYPE(BAL_TYPE);
        DK_A0Z011boList.add(bo);

    }

    /**
     * �ഫ�X�bbo
     * @param DK_A0Z011boList DK_A0Z011boList    ���ʲ��X�bbo
     * @param AMT  BigDecimal  ���B
     * @param PAY_KIND  String  �I�ں���
     * @param ACNT_DATE  Date    �ǲ����
     * @param ACNT_DIV_NO  String  �s�����
     * @param SLIP_LOT_NO  String  �ǲ��帹
     * @param SLIP_SET_NO  String  �ǲ��ո�
     * @param TRN_SER_NO  String  ����Ǹ�
     * @param String  EmpID  
     * @param String  EmpName
     * @param String  currentTime
     */
    private void setDK_A0Z011_2(List<DK_AAZ011_bo> DK_A0Z011boList, BigDecimal ALPY_AMT, BigDecimal FEE_AMT, BigDecimal NET_AMT, String PAY_KIND, Date ACNT_DATE, String ACNT_DIV_NO, String SLIP_LOT_NO, String SLIP_SET_NO, String TRN_SER_NO,
            String EmpID, String EmpName, String currentTime, String ACNT_DIV_NO_C101, String ACNT_TYPE, String BAL_TYPE) {
        String strACNT_DATE = ACNT_DATE.toString();
        String strALPY_AMT = ALPY_AMT.toString();//�дڪ��B
        String strFEE_AMT = FEE_AMT.toString();//����O
        String strNET_AMT = NET_AMT.toString();//���ڲb�B

        DK_AAZ011_bo bo = new DK_AAZ011_bo();
        bo.setINPUT_ID(EmpID);
        bo.setINPUT_NAME(EmpName);
        bo.setTRN_DATE(currentTime);
        bo.setTRN_SER_NO(TRN_SER_NO);
        bo.setSLIP_LOT_NO(SLIP_LOT_NO);
        bo.setSLIP_SET_NO(SLIP_SET_NO);
        bo.setACNT_DATE(strACNT_DATE);
        bo.setACNT_DIV_NO(ACNT_DIV_NO);//1030606 yenho�վ�
        bo.setBUS_CODE("EP");
        bo.setBUS_TRAN_CODE("1");
        bo.setAMT(strALPY_AMT);////�дڪ��B
        bo.setITEM("12");//�H�Υd�P�b
        bo.setTYPE(("3".equals(PAY_KIND)) ? "2" : "3");//3:�޲z�O->TYPE:2 ; ��L:����->TYPE:3
        bo.setREL_FILE_NO("EPC30110");
        bo.setTRN_KIND("EPC301");
        bo.setDIV_NO_C101(ACNT_DIV_NO_C101);//1030611 yenho ������C101�����ɳ��P�_�l��
        bo.setACNT_TYPE(ACNT_TYPE);
        bo.setBAL_TYPE(BAL_TYPE);
        DK_A0Z011boList.add(bo);

        bo = new DK_AAZ011_bo();
        bo.setINPUT_ID(EmpID);
        bo.setINPUT_NAME(EmpName);
        bo.setTRN_DATE(currentTime);
        bo.setTRN_SER_NO(TRN_SER_NO);
        bo.setSLIP_LOT_NO(SLIP_LOT_NO);
        bo.setSLIP_SET_NO(SLIP_SET_NO);
        bo.setACNT_DATE(strACNT_DATE);
        bo.setACNT_DIV_NO(ACNT_DIV_NO);
        bo.setBUS_CODE("EP");
        bo.setBUS_TRAN_CODE("1");
        bo.setAMT(strFEE_AMT);
        bo.setITEM("12"); //�H�Υd�P�b
        bo.setTYPE("4"); //4:����O
        bo.setDIV_NO_C101(ACNT_DIV_NO_C101);//1030606 yenho�վ�
        bo.setREL_FILE_NO("EPC30110");
        bo.setTRN_KIND("EPC301");
        bo.setACNT_TYPE(ACNT_TYPE);
        bo.setBAL_TYPE(BAL_TYPE);
        DK_A0Z011boList.add(bo);

        bo = new DK_AAZ011_bo();
        bo.setINPUT_ID(EmpID);
        bo.setINPUT_NAME(EmpName);
        bo.setTRN_DATE(currentTime);
        bo.setTRN_SER_NO(TRN_SER_NO);
        bo.setSLIP_LOT_NO(SLIP_LOT_NO);
        bo.setSLIP_SET_NO(SLIP_SET_NO);
        bo.setACNT_DATE(strACNT_DATE);
        bo.setACNT_DIV_NO(ACNT_DIV_NO);
        bo.setBUS_CODE("EP");
        bo.setBUS_TRAN_CODE("1");
        bo.setAMT(strNET_AMT);//���ڲb�B
        bo.setITEM("12"); //�H�Υd�P�b
        bo.setTYPE("5"); //5:��s
        bo.setDIV_NO_C101(ACNT_DIV_NO_C101);//1030606 yenho�վ�
        bo.setREL_FILE_NO("EPC30110");
        bo.setTRN_KIND("EPC301");
        bo.setACNT_TYPE(ACNT_TYPE);
        bo.setBAL_TYPE(BAL_TYPE);
        DK_A0Z011boList.add(bo);
        log.debug("yenho=bolist=>" + DK_A0Z011boList);
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * ��wME����
     * @param errMsg
     * @param msgDesc
     * @return
     */
    private ModuleException getModuleException(String errMsg, String msgDesc) {
        StringBuilder sb = new StringBuilder();
        return new ModuleException(sb.append(MessageUtil.getMessage(errMsg)).append(msgDesc).toString());
    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }

    /**     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }
        if (BigDecimal.class.isInstance(obj)) {
            return (BigDecimal) obj;
        }
        return new BigDecimal(String.valueOf(obj));
    }

}
