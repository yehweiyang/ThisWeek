package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.dc.b0.module.DC_B0Z002;
import com.cathay.dc.bo.DTDCH004;
import com.cathay.dc.g0.module.DC_G0Z002;
import com.cathay.dc.h0.module.DC_H0Z001;
import com.cathay.dc.vo.DTDCG002;
import com.cathay.de.a0.module.DE_A0Z220;
import com.cathay.de.a0.module.DE_A0Z230;
import com.cathay.de.a0.module.DE_A0Z360;
import com.cathay.de.bo.DTDEA120;
import com.cathay.de.bo.DTDEA310;
import com.cathay.dj.c0.module.DJ_C0Z025;
import com.cathay.dk.a0.bo.DK_AAZ011_bo;
import com.cathay.dk.a0.module.DK_A0Z003;
import com.cathay.dk.bo.DTDKF001;
import com.cathay.dk.bo.DTDKG002;
import com.cathay.dk.bo.DTDKG003;
import com.cathay.dk.f0.module.DK_F0Z001;
import com.cathay.dk.f0.module.DK_F0Z002;
import com.cathay.dk.f0.module.DK_F0Z011;
import com.cathay.dk.f0.module.DK_F0Z017;
import com.cathay.dk.g0.module.DK_G0Z002;
import com.cathay.dk.g0.module.DK_G0Z007;
import com.cathay.dk.g0.module.DK_G0Z011;
import com.cathay.ep.vo.DTEPC307;
import com.cathay.ep.vo.DTEPC309;
import com.cathay.ep.vo.DTEPC310;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C301;
import com.cathay.ep.z0.module.EP_Z0C302;
import com.cathay.ep.z0.module.EP_Z0C306;
import com.cathay.ep.z0.module.EP_Z0C307;
import com.cathay.ep.z0.module.EP_Z0C309;
import com.cathay.ep.z0.module.EP_Z0C310;
import com.cathay.ep.z0.module.EP_Z0G103;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE        Description Author
 * 2013/08/29  Created     ������
 *
 * �@�B    �{���\�෧�n�����G
 * �ҲզW��    ú�ڱb�ȽT�{���@�Ҳ�
 * �Ҳ�ID    EP_C30040
 * ���n����    �B�zú�ڱb�ȽT�{�@�~
 * 
 * [20180207] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * [20180411] �ק��
 * ���D��:20180411-0075 
 * 
 *</pre>
 * @author ���_�� 
 * @since 2013/11/7
 */
@SuppressWarnings("unchecked")
public class EP_C30040 {

    private static final Logger log = Logger.getLogger(EP_C30040.class);

    /**isDebug*/
    private boolean isDebug = log.isDebugEnabled();

    private static final String SQL_queryRtlInfoList_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryRtlInfoList_001";

    private static final String SQL_queryRtlInfoList_002 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryRtlInfoList_002";

    private static final String SQL_queryPayInfoList_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryPayInfoList_001";

    private static final String SQL_queryPayInfoListByAcnt_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryPayInfoListByAcnt_001";

    private static final String SQL_queryPayRltInfoList_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryPayRltInfoList_001";

    private static final String SQL_queryPayRltInfoList_002 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryPayRltInfoList_002";

    private static final String SQL_queryPayRltInfoList_003 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryPayRltInfoList_003";

    private static final String SQL_updateChkInfo_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateChkInfo_001";

    private static final String SQL_updateChkInfo_002 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateChkInfo_002";

    private static final String SQL_updateChkInfo_003 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateChkInfo_003";

    private static final String SQL_updateChkInfo_005 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateChkInfo_005";

    private static final String SQL_updateRmtInfo_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateRmtInfo_001";

    private static final String SQL_updateRmtInfo_002 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateRmtInfo_002";

    private static final String SQL_updateRmtInfo_003 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateRmtInfo_003";

    private static final String SQL_updateRmtInfo_004 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateRmtInfo_004";

    private static final String SQL_updateRmtInfo_005 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateRmtInfo_005";

    private static final String SQL_updateRmtInfo_006 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateRmtInfo_006";

    //private static final String SQL_updatePayInfo_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_updatePayInfo_001";

    //private static final String SQL_updatePayInfo_002 = "com.cathay.ep.c3.module.EP_C30040.SQL_updatePayInfo_002";

    private static final String SQL_updateChkInfo_004 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateChkInfo_004";

    private static final String SQL_updateAcntInfo_002 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateAcntInfo_002";

    private static final String SQL_updateAcntInfo_003 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateAcntInfo_003";

    //private static final String SQL_updateAcntInfo_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_updateAcntInfo_001";

    private static final String SQL_queryAcntInfo_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryAcntInfo_001";

    //private static final String SQL_queryChkInfo_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryChkInfo_001";

    private static final String SQL_queryTmpInfo_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryTmpInfo_001";

    // private static final String SQL_queryRmtInfo_001 = "com.cathay.ep.c3.module.EP_C30040.SQL_queryRmtInfo_001";

    /**
     * ���oú�O���p�����M��
     * @param ACNT_DIV_NO �b�ȳ��
     * @param SLIP_LOT_NO �ǲ��帹
     * @param EMP_ID �ާ@�H��ID
     * @param ACNT_DATE �b�Ȥ��
     * @param SUB_CPY_ID �����q�O
     * @return ú�O���p�����M��
     * @throws ModuleException 
     */
    public List<Map> queryPayRltInfoList(String ACNT_DIV_NO, String SLIP_LOT_NO, String EMP_ID, String ACNT_DATE, String ACNT_TYPE,
            String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_001"));//�b�ȳ�줣�o����
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_002"));//�ǲ��帹���o����
        }
        if (StringUtils.isBlank(EMP_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_003"));//�ާ@�H��ID���o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("EMP_ID", EMP_ID);
        try {
            List<Map> PAY_RLT_LIST;
            if (StringUtils.isBlank(ACNT_DATE)) {
                if ("1".equals(ACNT_TYPE)) {
                    ds.setField("ACNT_TYPE1", "1");
                } else {
                    ds.setField("ACNT_TYPE2", "2");
                }
                /* [20180227] �[�P�_��  */
                if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//���                    
                    PAY_RLT_LIST = VOTool.findToMaps(ds, SQL_queryPayRltInfoList_001);
                } else {
                    PAY_RLT_LIST = VOTool.findToMaps(ds, SQL_queryPayRltInfoList_003);
                }

            } else {
                ds.setField("ACNT_DATE", ACNT_DATE);
                ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
                ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
                PAY_RLT_LIST = VOTool.findToMaps(ds, SQL_queryPayRltInfoList_002);
            }

            //Callú�ڱb�ȽT�{���@�Ҳ�.���oú�O���p�M���k
            Map<String, List<Map>> TOTAL_RLT_INFO_Map = this.queryRtlInfoList(PAY_RLT_LIST, SUB_CPY_ID);
            //�v���B�zPAY_RLT_LIST�A��PAY_RLT_MAP�զ�
            //Call���oú�O���p�M���k
            for (Map PAY_RLT_MAP : PAY_RLT_LIST) {

                String PAY_NO = MapUtils.getString(PAY_RLT_MAP, "PAY_NO");
                if (TOTAL_RLT_INFO_Map.get(PAY_NO) == null) {//�Y��306 PAY_NO ������301  �h�߿�
                    throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_004"));//���oú�ڬ����M��o�Ϳ��~,
                }
                List<Map> PAY_RLT_LIST1 = TOTAL_RLT_INFO_Map.get(PAY_NO);
                //                for (Map RLT_INFO_MAP : PAY_RLT_LIST1) {
                //                    if (MapUtils.getString(RLT_INFO_MAP, "CRT_NO", "").indexOf("OR") == 0) {
                //                        PAY_RLT_MAP.put("MAL_AMT", "0");
                //                    }
                //                }

                PAY_RLT_MAP.put("RLT_INFO_LIST", PAY_RLT_LIST1);

            }

            return PAY_RLT_LIST;
        } catch (DataNotFoundException dnfe) {
            throw dnfe;
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_004"));//���oú�ڬ����M��o�Ϳ��~,
        }

    }

    /**
     * ���oú�O���p�M��
     * @param PAY_NO ú�O�s��
     * @param SUB_CPY_ID �����q�O
     * 
     * @return ú�O���p�M��
     * @throws ModuleException
     */
    public Map<String, List<Map>> queryRtlInfoList(List<Map> PAY_RLT_LIST, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;

        if (PAY_RLT_LIST == null || PAY_RLT_LIST.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_005"));//ú�O�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        List<String> PAY_NO_LIST = new ArrayList();
        for (Map PAY_RLT_MAP : PAY_RLT_LIST) {
            String PAY_NO = MapUtils.getString(PAY_RLT_MAP, "PAY_NO");
            if (!PAY_NO_LIST.contains(PAY_NO)) {
                PAY_NO_LIST.add(PAY_NO);
            }
        }
        try {
            DataSet ds = Transaction.getDataSet();
            int i = 1;
            List<String> tmpPAY_NOList = new ArrayList();
            List<Map> tmp_LIST = new ArrayList();
            int PAY_NO_SIZE = PAY_NO_LIST.size();
            boolean isAccountSubCpy = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);
            for (String PAY_NO : PAY_NO_LIST) {
                tmpPAY_NOList.add(PAY_NO);
                if (i % 100 == 0) {
                    ds.clear();
                    ds.setFieldValues("PAY_NO", tmpPAY_NOList);
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    /* [20180227] �[�P�_��  */
                    if (isAccountSubCpy) {//���          
                        tmp_LIST.addAll(VOTool.findToMaps(ds, SQL_queryRtlInfoList_001));
                    } else {
                        tmp_LIST.addAll(VOTool.findToMaps(ds, SQL_queryRtlInfoList_002));
                    }
                    tmpPAY_NOList = new ArrayList();
                }
                if (i == PAY_NO_SIZE && i % 100 != 0) {
                    ds.clear();
                    ds.setFieldValues("PAY_NO", tmpPAY_NOList);
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    /* [20180227] �[�P�_��  */
                    if (isAccountSubCpy) {//���       
                        tmp_LIST.addAll(VOTool.findToMaps(ds, SQL_queryRtlInfoList_001));
                    } else {
                        tmp_LIST.addAll(VOTool.findToMaps(ds, SQL_queryRtlInfoList_002));
                    }
                }
                i++;

            }
            Map<String, List<Map>> tmpMap = new HashMap();
            List<Map> RLT_INFO_LIST;
            //�v���B�zRLT_INFO_LIST�A��RLT_INFO_MAP�զ�
            for (Map RLT_INFO_MAP : tmp_LIST) {
                String PAY_NO = MapUtils.getString(RLT_INFO_MAP, "PAY_NO");
                if (!tmpMap.containsKey(PAY_NO)) {
                    RLT_INFO_LIST = new ArrayList();
                    RLT_INFO_LIST.add(RLT_INFO_MAP);
                    tmpMap.put(PAY_NO, RLT_INFO_LIST);
                } else {
                    RLT_INFO_LIST = tmpMap.get(PAY_NO);
                    RLT_INFO_LIST.add(RLT_INFO_MAP);

                }
                //ú�ں���
                RLT_INFO_MAP.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND", MapUtils.getString(RLT_INFO_MAP, "PAY_KIND")));

            }

            return tmpMap;
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_006"));//���oú�O���p�M��o�Ϳ��~,
        }

    }

    /**
     * ���oú�ڰO���M��
     * @param PAY_NO ú�O�s��
     * @return ú�ڰO���M��
     * @throws ModuleException
     */
    public List<Map> queryPayInfoList(String PAY_NO, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(PAY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30040_MSG_005"));//ú�O�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            return VOTool.findToMaps(ds, SQL_queryPayInfoList_001);
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_004"));//���oú�ڬ����M��o�Ϳ��~,
        }

    }

    /**
     * ���oú�ڰO���M��By�b�ȸ�T
     * @param ACNT_DATE �b�Ȥ��
     * @param ACNT_DIV_NO �b�ȳ��
     * @param SLIP_LOT_NO �ǲ��帹
     * @param TRN_SER_NO �g�����Ǹ�
     * @param user �ϥΪ̸�T
     * @return ú�ڰO���M��
     * @throws ModuleException
     */
    public List<Map> queryPayInfoListByAcnt(Date ACNT_DATE, String ACNT_DIV_NO, String SLIP_LOT_NO, Integer SLIP_SET_NO, UserObject user)
            throws ModuleException {

        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_007"));//�b�Ȥ�����o����
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_001"));//�b�ȳ�줣�o����
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_002"));//�ǲ��帹���o����
        }
        if (SLIP_SET_NO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_008"));//�ǲ��ո����o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_010"));//�ϥΪ̸�T���o����
        } else {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
        ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
        ds.setField("SLIP_SET_NO", SLIP_SET_NO);
        ds.setField("ID", user.getEmpID());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            return VOTool.findToMaps(ds, SQL_queryPayInfoListByAcnt_001);
        } catch (ModuleException me) {
            log.error("", me);
            throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_004"));//���oú�ڬ����M��o�Ϳ��~,
        }

    }

    /**
     * �T�{�@�~
     * @param reqList �Ŀ�M��
     * @param user �ϥΪ̸�T
     * @throws Exception 
     */
    public void doConfirm(List<Map> reqList, UserObject user, String ACNT_TYPE, String SLIP_LOT_NO, String SUB_CPY_ID,
            BatchUpdateDataSet[] budsArray) throws Exception {

        ErrorInputException eie = null;
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_011"));//�Ŀ�M�椣�o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_010"));//�ϥΪ̸�T���o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(ACNT_TYPE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_044"));//�b�Ⱥ������o����
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_002"));//�ǲ��帹���o����
        }
        if (eie != null) {
            throw eie;
        }

        //budsArray != null >> �ϥ�buds //150410 insert
        boolean isBatch = false;
        BatchUpdateDataSet budsC301 = null;
        BatchUpdateDataSet budsC306 = null;
        BatchUpdateDataSet budsC307 = null;
        if (budsArray != null && budsArray.length == 3) {
            isBatch = true;
            budsC301 = budsArray[0];
            budsC306 = budsArray[1];
            budsC307 = budsArray[2];
            if (budsC301 == null || budsC306 == null || budsC307 == null) {
                throw new ErrorInputException("buds�ǤJ�ƶq���~");
            }
        }

        if (isDebug)
            log.debug(">>>>>isBatch:" + isBatch);

        DataSet ds = Transaction.getDataSet();
        String Id = user.getEmpID();
        String Op = user.getOpUnit();
        String Name = user.getEmpName();
        String date = DATE.getDBDate();
        String currentTime = DATE.getDBTimeStamp();
        //�]�w�鵲�帹
        //String SLIP_LOT_NO = "";
        //���o�b�Ȥ��
        String ACNT_DATE = "";
        //���o����Ǹ�
        String SER_NO = "0";
        ReturnMessage msg = new ReturnMessage();
        DK_G0Z002 theDK_G0Z002 = new DK_G0Z002();

        EP_Z00030 theEP_Z00030 = new EP_Z00030();

        boolean isAccountSubCpy = theEP_Z00030.isAccountSubCpy(SUB_CPY_ID);
        /* [20180207] �P�_����I�sEP_Z00030  */
        if (isAccountSubCpy) {
            //�]�w�鵲�帹
            //SLIP_LOT_NO = "EP7";
            //Call���o�b�Ȥ���Ҳ�.���o���b�Ȥ����k 
            ACNT_DATE = date;
            try {
                ACNT_DATE = new DK_F0Z001().getDateByAcc(Op, Id, SLIP_LOT_NO, msg).getACNT_DATE();
            } catch (Exception me) {
                log.debug("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_012", new Object[] { Op, SLIP_LOT_NO }));//Ū�����o�b�Ȥ���Ҳ�DK_F0Z001.����, ���N��={0}, �ǲ��帹={1}
            }
        } else {
            ACNT_DATE = date;
        }

        //���o�ǲ��ո� 
        String SLIP_SET_NO = "1";

        Date ACNT_DATE_d = Date.valueOf(ACNT_DATE);
        Integer SLIP_SET_NO_i = Integer.valueOf(SLIP_SET_NO);

        //����P�b�@�~
        //�v���B�zreqList
        List<DK_AAZ011_bo> DK_AAZ011_boList = new ArrayList();
        String strPayNo = "";
        int count = 0;

        /* [20180207] �{�����X if ("00".equals(SUB_CPY_ID)) start   */
        DK_A0Z003 theDK_A0Z003 = new DK_A0Z003();
        DK_F0Z011 theDK_F0Z011 = new DK_F0Z011();
        DK_G0Z007 theDK_G0Z007 = new DK_G0Z007();
        EP_Z0C302 theEP_Z0C302 = new EP_Z0C302();
        EP_Z0C306 theEP_Z0C306 = new EP_Z0C306();
        EP_Z0C307 theEP_Z0C307 = new EP_Z0C307();
        EP_Z0C301 theEP_Z0C301 = new EP_Z0C301();
        DK_F0Z002 theDK_F0Z002 = new DK_F0Z002();
        EP_Z0C310 theEP_Z0C310 = new EP_Z0C310();
        EP_Z0C309 theEP_Z0C309 = new EP_Z0C309();

        boolean isCash = false;

        //Callú�ڱb�ȽT�{���@�Ҳ�.���oú�O���p�M���k
        Map<String, List<Map>> TOTAL_RLT_INFO_Map = this.queryRtlInfoList(reqList, SUB_CPY_ID);

        //�����oú�O���� //150410 insert
        List<Map> C306PayList = theEP_Z0C306.queryPayList(reqList, SUB_CPY_ID);
        Map<String, Map> Map_C306_PAY = new HashMap<String, Map>();
        for (Map c306 : C306PayList) {
            Map_C306_PAY.put(MapUtils.getString(c306, "PAY_NO"), c306);
        }

        //�����o�M������AKEY = ACNT_SET_NO //150410 insert
        Map<String, List<DTEPC307>> MAP_ACNT_LIST = theEP_Z0C307.queryAcntPayListMap(C306PayList, SUB_CPY_ID);
        //�����o���ڬ����AKEY = CHK_SET_NO //150410 insert
        Map<String, List<Map>> MAP_CHK_LIST = theEP_Z0C302.queryChkPayListMap(C306PayList, SUB_CPY_ID);
        //����P�b�@�~
        Map<String, Map> Map_TRN_RCVYM = new HashMap<String, Map>(); //150410 insert

        String DACNT_DIV_NAME = user.getDivShortName();

        //�W�[�O�_��s�j�B�q���P�_
        List<String> OVERList = new ArrayList<String>();
        DTDCH004 DTDCH004_BO = new DTDCH004();
        DC_H0Z001 theDC_H0Z001 = new DC_H0Z001();
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
        ReturnMessage rm = new ReturnMessage();
        boolean isPrePay = false;
        int i = 1;
        /* [20180207] �{�����X if ("00".equals(SUB_CPY_ID)) end   */

        //�v���B�zreqList
        for (Map reqMap : reqList) {
            //�X�|�p����           
            //���oú�O���p�M��
            //Callú�ڱb�ȽT�{���@�Ҳ�.���oú�O���p�M���k
            //�v���B�zRLT_INFO_LIST�A��RLT_INFO_MAP�զ�
            //�զ�DK_AAZ011_bo�榡
            String PAY_NO = MapUtils.getString(reqMap, "PAY_NO");
            String TMP_NO = MapUtils.getString(reqMap, "TMP_NO", "");
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
            DK_AAZ011_boList = new ArrayList();
            if (isDebug)
                log.debug("RCV_YM>>>" + RCV_YM);
            if (strPayNo.equals(PAY_NO)) {
                continue;
            } else {
                strPayNo = PAY_NO;
                count = 0;
            }
            String RTL_BAL_TYPE = "EP";

            //��sC301�ݭnRCV_YM,��ؤ��|�i�U���϶�,�G�Ԩ�W��
            Map payInfo = new HashMap();
            payInfo.put("RCV_YM", RCV_YM);
            Map_TRN_RCVYM.put(PAY_NO, payInfo);

            /* [20180207] �[�P�_���I�sEP_Z00030  */
            if (isAccountSubCpy) {//��ؤ~�|�X�b 
                //Call�g�����Ǹ��Ҳ�.���o�g�����Ǹ���k
                SER_NO = theDK_F0Z002.getSER_NO(Id, date, msg);
                if (msg.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_013") + msg.getMsgDesc());//Ū���g�����Ǹ��Ҳ�DK_F0Z002����:
                }
                if (isDebug)
                    log.debug("�X�Ǹ�>>>" + SER_NO);

                //�]�wú�O���������A�g�����Ǹ� //150410 insert
                payInfo = Map_TRN_RCVYM.get(PAY_NO);
                payInfo.put("TRN_SER_NO", SER_NO);
                Map_TRN_RCVYM.put(PAY_NO, payInfo);

                if (isDebug)
                    log.debug("�}�l>>>");
                String[] TMP_NOs = TMP_NO.split(",");
                if ("0".equals(RCV_YM)) {//�wú�Ȧ�
                    if (isDebug)
                        log.debug("��sG002�M�s�WF001�}�l");

                    String BAL_TYPE = null;
                    for (String TMPNO : TMP_NOs) {
                        DTDKG002 DTDKG002_Bo;

                        try {
                            DTDKG002_Bo = theDK_G0Z007.queryByPKForXA(TMPNO, msg);
                        } catch (Exception e) {
                            log.error("", e);
                            throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_036") + e);//�I�s�|�p�Ҳ�DK_G0Z007��Ʀ��~
                        }

                        String TMP_IN_CD = DTDKG002_Bo.getTMP_IN_CD();
                        if (isDebug) {
                            log.debug("�P�_�O�_���{����");
                            log.debug("1".equals(TMP_IN_CD));
                        }
                        DTDKG002_Bo.setSLIP_DATE(ACNT_DATE);
                        DTDKG002_Bo.setACNT_DATE(ACNT_DATE);
                        DTDKG002_Bo.setACNT_DIV_NO(Op);
                        BAL_TYPE = DTDKG002_Bo.getBAL_TYPE();

                        if (!"1".equals(TMP_IN_CD)) {
                            //�״�/�M��:�g�J�j�B�q��
                            if ("3".equals(TMP_IN_CD) || "B".equals(TMP_IN_CD)) {
                                isPrePay = true;
                                BigDecimal PAY_AMT = STRING.objToBigDecimal(DTDKG002_Bo.getACNT_AMT(), BigDecimal.ZERO);
                                String G002_ID = DTDKG002_Bo.getID();
                                int G002_CRT_NO_length = DTDKG002_Bo.getPOLICY_NO().length();
                                if ((StringUtils.isNotBlank(G002_ID) || G002_CRT_NO_length == 10) && PAY_AMT.compareTo(BigDecimal.ZERO) > 0) {
                                    Map C306 = Map_C306_PAY.get(PAY_NO);
                                    DTDCH004_BO = new DTDCH004();
                                    DTDCH004_BO.setACC_DATE(ACNT_DATE);
                                    DTDCH004_BO.setACC_DIV_NO(Op);
                                    DTDCH004_BO.setPOLICY_NO(DTDKG002_Bo.getPOLICY_NO());
                                    DTDCH004_BO.setACC_KIND("99");
                                    DTDCH004_BO.setACC_AMT(PAY_AMT.toPlainString());
                                    DTDCH004_BO.setSER_NO(Integer.toString(i));
                                    DTDCH004_BO.setPAY_RCV_CODE("DR");
                                    DTDCH004_BO.setDACNT_CODE("Y");
                                    DTDCH004_BO.setCPTL_KIND("1");
                                    DTDCH004_BO.setSYS_NO("EP");
                                    DTDCH004_BO.setTRN_KIND("EPC304");
                                    DTDCH004_BO.setAPLY_NO(PAY_NO);
                                    DTDCH004_BO.setINPUT_DIV_NO(Op);
                                    DTDCH004_BO.setINPUT_ID(Id);
                                    DTDCH004_BO.setINPUT_NAME(Name);
                                    DTDCH004_BO.setINPUT_DATE(currentTime);
                                    DTDCH004_BO.setPRE_KEY(PAY_NO + "_" + DTDKG002_Bo.getTMP_NO());
                                    DTDCH004_BO.setSLIP_SET_NO(SLIP_SET_NO);
                                    DTDCH004_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
                                    DTDCH004_BO.setUSER_TRN_SERNO(SER_NO);
                                    DTDCH004_BO.setUSER_ID(Id);
                                    DTDCH004_BO.setCUST_ID(G002_ID);
                                    DTDCH004_BO.setCUST_NAME(DTDKG002_Bo.getCST_NAME());
                                    DTDCH004_BO.setRMT_SET_NO(MapUtils.getString(C306, "RMT_SET_NO"));
                                    i++;

                                    theDC_H0Z001.insert(DTDCH004_BO, null, rm);

                                    if (rm.getReturnCode() != ReturnCode.OK) {
                                        throw new ModuleException(rm.getMsgDesc());
                                    }
                                }
                            }

                            if (isDebug)
                                log.debug("�}�l��sG002�M�s�WF001");
                            try {
                                //DTDKG002_Bo.setSLIP_DATE(ACNT_DATE);
                                //DTDKG002_Bo.setACNT_DATE(ACNT_DATE);
                                //DTDKG002_Bo.setACNT_DIV_NO(Op);
                                DTDKG002_Bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                                DTDKG002_Bo.setSLIP_SET_NO(SLIP_SET_NO);
                                DTDKG002_Bo.setACNT_SER_NO(SER_NO);
                                if (isDebug)
                                    log.debug("DTDKG002_BO>>>" + DTDKG002_Bo);

                                //��sú�O���p�b�ȸ�T(��sG002�M�s�WF001)
                                theDK_G0Z002.insertDTDKG002ByHandForXA_2(DTDKG002_Bo, msg, user);

                                if (msg.getReturnCode() != ReturnCode.OK) {
                                    throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_035") + msg.getMsgDesc());//�I�s�|�p�Ҳ�DK_G0Z002.insertDTDKG002ByHandForXA_2���~
                                }
                                if (isDebug)
                                    log.debug("��sG002�M�s�WF001����");
                            } catch (Exception e) {
                                log.error("", e);
                                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_037") + e.getMessage());//�I�s�|�p�Ҳ�DK_G0Z002�٭�G003���~�A
                            }
                        }

                    }

                    //�P�_�wú���b�U�O
                    RTL_BAL_TYPE = BAL_TYPE;

                } else {//�D�wú
                    List<Map> payList = TOTAL_RLT_INFO_Map.get(PAY_NO);
                    // �P�@�� PAY_NO �|�P�h�������A�קK���Ƶ�DK���
                    List<String> dkList = new ArrayList<String>();
                    if (dkList.contains(PAY_NO)) {
                        continue;
                    }
                    //�P�_����ú�O���b�U�O
                    RTL_BAL_TYPE = theEP_Z0G103.getBalTypeByList(payList);

                    for (Map RLT_INFO_MAP : payList) {
                        if (isDebug) {
                            log.debug("RLT_INFO_MAP>>>" + RLT_INFO_MAP);
                            log.debug(" count ====>" + count++);
                        }
                        DK_AAZ011_bo DK_AAZ011_bo = new DK_AAZ011_bo();
                        String PAY_KIND = MapUtils.getString(RLT_INFO_MAP, "PAY_KIND");
                        if (isDebug)
                            log.debug("ISFROM>>>>" + MapUtils.getString(RLT_INFO_MAP, "ISFROM"));
                        if (!"G002".equals(MapUtils.getString(RLT_INFO_MAP, "ISFROM"))) {
                            if (isDebug)
                                log.debug("���Χ�ITEM�MTYPE");
                            DK_AAZ011_bo.setITEM("7");
                            String OP_STATUS_C101 = MapUtils.getString(RLT_INFO_MAP, "OP_STATUS_C101");

                            if ("2".equals(PAY_KIND)) {
                                DK_AAZ011_bo.setTYPE("7");
                            } else if ("3".equals(PAY_KIND)) {
                                DK_AAZ011_bo.setTYPE("8");
                            } else if ("1".equals(PAY_KIND) || "4".equals(PAY_KIND) || "5".equals(PAY_KIND) || "7".equals(PAY_KIND)
                                    || "8".equals(PAY_KIND)) {
                                if ("30".equals(OP_STATUS_C101) || "35".equals(OP_STATUS_C101)) {//�q�l�o���h�@��,35�|�p�w�Ю�
                                    DK_AAZ011_bo.setTYPE("6");
                                } else if ("40".equals(OP_STATUS_C101)) {
                                    DK_AAZ011_bo.setTYPE("12");//�ʦ��ڶ�
                                } else if ("50".equals(OP_STATUS_C101)) {
                                    DK_AAZ011_bo.setTYPE("13");//�Ʃ�b�b
                                } else {
                                    DK_AAZ011_bo.setTYPE("13");//�Ʃ�b�b
                                }
                            } else {
                                log.error("�ǤJOP_STATUS_C101:" + OP_STATUS_C101 + "�MPAY_KIND:" + PAY_KIND + "���~");
                                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_034"));//�ǤJOP_STATUS_C101�MPAY_KIND���~:
                            }
                        }

                        DK_AAZ011_bo.setINPUT_ID(Id);
                        DK_AAZ011_bo.setINPUT_NAME(Name);
                        DK_AAZ011_bo.setTRN_DATE(currentTime);
                        DK_AAZ011_bo.setTRN_SER_NO(SER_NO);
                        DK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                        DK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);
                        DK_AAZ011_bo.setREL_FILE_NO("DTEPC306");
                        DK_AAZ011_bo.setACNT_DATE(ACNT_DATE);
                        DK_AAZ011_bo.setTRN_KIND("EPC304");
                        DK_AAZ011_bo.setMEMO(MapUtils.getString(RLT_INFO_MAP, "PAY_NO") + ',' + MapUtils.getString(RLT_INFO_MAP, "RCV_NO"));
                        DK_AAZ011_bo.setACNT_DIV_NO(Op);
                        DK_AAZ011_bo.setKIND_CODE("");
                        DK_AAZ011_bo.setCURR("NTD");
                        DK_AAZ011_bo.setCNT("1");
                        DK_AAZ011_bo.setBUS_CODE("EP");
                        DK_AAZ011_bo.setBUS_TRAN_CODE("1");
                        DK_AAZ011_bo.setAMT(MapUtils.getString(RLT_INFO_MAP, "PAY_AMT"));
                        DK_AAZ011_bo.setBANK_NO("");
                        DK_AAZ011_bo.setACNT_NO("");
                        DK_AAZ011_bo.setDB_CR("CR");
                        String DIV_NO_C101 = MapUtils.getString(RLT_INFO_MAP, "DIV_NO_C101");
                        if (isDebug) {
                            log.debug("@@@DIV_NO_C101=" + DIV_NO_C101);
                        }
                        if (StringUtils.isBlank(DIV_NO_C101)) {
                            DIV_NO_C101 = Op;
                        }
                        DK_AAZ011_bo.setDIV_NO_C101(DIV_NO_C101);
                        DK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);//�b�Ⱥ���
                        DK_AAZ011_bo.setBAL_TYPE(theEP_Z0G103.getBAL_TYPE(SUB_CPY_ID, MapUtils.getString(RLT_INFO_MAP, "BLD_CD")));//�b�U�O

                        DK_AAZ011_boList.add(DK_AAZ011_bo);

                        if (isDebug)
                            log.debug("�s�W��ú���B>>>" + DK_AAZ011_boList);
                    }
                    dkList.add(PAY_NO);
                }//�����B�z �U��ڶ�

                //���oú�ڰO���M��
                //Callú�ڱb�ȽT�{���@�Ҳ�.���oú�ڰO���M���k
                //�v���B�zPAY_INFO_LIST�A��PAY_INFO_MAP�զ�
                //for (Map PAY_INFO_MAP : this.queryPayInfoList(PAY_NO)) {

                //PAY_NO��PK�A�������oPAY_INFO_MAP�B�z //150410 insert 
                Map PAY_INFO_MAP = Map_C306_PAY.get(PAY_NO);
                /*if (getBigDecimal(PAY_INFO_MAP.get("CSH_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {//�{��
                    isCash = true;
                    continue;
                    //�{�������s�W�ǲ�
                    DK_AAZ011_bo DK_AAZ011_bo = new DK_AAZ011_bo();
                    DK_AAZ011_bo.setINPUT_ID(Id);
                    DK_AAZ011_bo.setINPUT_NAME(Name);
                    DK_AAZ011_bo.setTRN_DATE(currentTime);
                    DK_AAZ011_bo.setTRN_SER_NO(SER_NO);
                    DK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);
                    DK_AAZ011_bo.setREL_FILE_NO("DTEPC306");
                    DK_AAZ011_bo.setACNT_DATE(ACNT_DATE);
                    DK_AAZ011_bo.setTRN_KIND("EPC304");
                    DK_AAZ011_bo.setMEMO(MapUtils.getString(PAY_INFO_MAP, "PAY_NO"));
                    DK_AAZ011_bo.setACNT_DIV_NO(Op);
                    DK_AAZ011_bo.setKIND_CODE("");
                    DK_AAZ011_bo.setCURR("NTD");
                    DK_AAZ011_bo.setCNT("1");
                    DK_AAZ011_bo.setBUS_CODE("EP");
                    DK_AAZ011_bo.setBUS_TRAN_CODE("1");
                    DK_AAZ011_bo.setITEM("7");
                    DK_AAZ011_bo.setTYPE("1");
                    DK_AAZ011_bo.setAMT(MapUtils.getString(PAY_INFO_MAP, "CSH_AMT"));
                    DK_AAZ011_bo.setBANK_NO("");
                    DK_AAZ011_bo.setACNT_NO("");
                    DK_AAZ011_bo.setDB_CR("DR");
                    DK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);//�b�Ⱥ���
                    DK_AAZ011_boList.add(DK_AAZ011_bo);
                    log.debug("�s�W�{��>>>" + DK_AAZ011_boList);
                } */

                if (getBigDecimal(PAY_INFO_MAP.get("RMT_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {//�״�
                    if (!isPrePay) {
                        OVERList.add(MapUtils.getString(PAY_INFO_MAP, "PAY_NO")); //��s�j�B�q��
                    }

                    DK_AAZ011_bo DK_AAZ011_bo = new DK_AAZ011_bo();

                    DK_AAZ011_bo.setINPUT_ID(Id);
                    DK_AAZ011_bo.setINPUT_NAME(Name);
                    DK_AAZ011_bo.setTRN_DATE(currentTime);
                    DK_AAZ011_bo.setTRN_SER_NO(SER_NO);
                    DK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);
                    DK_AAZ011_bo.setREL_FILE_NO("DTEPC306");
                    DK_AAZ011_bo.setACNT_DATE(ACNT_DATE);
                    DK_AAZ011_bo.setTRN_KIND("EPC304");
                    DK_AAZ011_bo.setMEMO(MapUtils.getString(PAY_INFO_MAP, "PAY_NO") + ',' + MapUtils.getString(PAY_INFO_MAP, "RMT_SET_NO"));

                    DK_AAZ011_bo.setACNT_DIV_NO(Op);
                    DK_AAZ011_bo.setKIND_CODE("");
                    DK_AAZ011_bo.setCURR("NTD");
                    DK_AAZ011_bo.setCNT("1");
                    DK_AAZ011_bo.setBUS_CODE("EP");
                    DK_AAZ011_bo.setBUS_TRAN_CODE("1");
                    DK_AAZ011_bo.setITEM("7");
                    DK_AAZ011_bo.setTYPE("3");
                    DK_AAZ011_bo.setAMT(MapUtils.getString(PAY_INFO_MAP, "RMT_AMT"));
                    DK_AAZ011_bo.setBANK_NO("");
                    DK_AAZ011_bo.setACNT_NO("");
                    DK_AAZ011_bo.setDB_CR("DR");
                    DK_AAZ011_bo.setDIV_NO_C101(Op);
                    DK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);//�b�Ⱥ���
                    DK_AAZ011_bo.setBAL_TYPE(RTL_BAL_TYPE);//�b�U�O

                    DK_AAZ011_boList.add(DK_AAZ011_bo);
                    if (isDebug)
                        log.debug("�s�W�״�>>>" + DK_AAZ011_boList);

                }

                if (getBigDecimal(PAY_INFO_MAP.get("MAL_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {//�l�O
                    DK_AAZ011_bo DK_AAZ011_bo = new DK_AAZ011_bo();

                    DK_AAZ011_bo.setINPUT_ID(Id);
                    DK_AAZ011_bo.setINPUT_NAME(Name);
                    DK_AAZ011_bo.setTRN_DATE(currentTime);
                    DK_AAZ011_bo.setTRN_SER_NO(SER_NO);
                    DK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);
                    DK_AAZ011_bo.setREL_FILE_NO("DTEPC306");
                    DK_AAZ011_bo.setACNT_DATE(ACNT_DATE);
                    DK_AAZ011_bo.setTRN_KIND("EPC304");
                    DK_AAZ011_bo.setMEMO(MapUtils.getString(PAY_INFO_MAP, "PAY_NO"));
                    DK_AAZ011_bo.setACNT_DIV_NO(Op);
                    DK_AAZ011_bo.setKIND_CODE("");
                    DK_AAZ011_bo.setCURR("NTD");
                    DK_AAZ011_bo.setCNT("1");
                    DK_AAZ011_bo.setBUS_CODE("EP");
                    DK_AAZ011_bo.setBUS_TRAN_CODE("1");
                    DK_AAZ011_bo.setITEM("7");
                    DK_AAZ011_bo.setTYPE("2");// [20180411]���D��:20180411-0075  
                    DK_AAZ011_bo.setAMT(MapUtils.getString(PAY_INFO_MAP, "MAL_AMT"));
                    DK_AAZ011_bo.setBANK_NO("");
                    DK_AAZ011_bo.setACNT_NO("");
                    DK_AAZ011_bo.setDB_CR("DR");
                    DK_AAZ011_bo.setDIV_NO_C101(Op);
                    DK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);//�b�Ⱥ���
                    DK_AAZ011_bo.setBAL_TYPE(RTL_BAL_TYPE);//�b�U�O

                    DK_AAZ011_boList.add(DK_AAZ011_bo);
                    if (isDebug)
                        log.debug("�s�W�l�O>>>" + DK_AAZ011_boList);

                }

                if (getBigDecimal(PAY_INFO_MAP.get("CHK_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0 && MAP_CHK_LIST != null) {//�䲼
                    //Ū���䲼�M��
                    List<Map> CHK_INFO_LIST = MAP_CHK_LIST.get(MapUtils.getString(PAY_INFO_MAP, "CHK_SET_NO"));
                    for (Map CHK_INFO_MAP : CHK_INFO_LIST) {

                        DK_AAZ011_bo DK_AAZ011_bo = new DK_AAZ011_bo();

                        DK_AAZ011_bo.setINPUT_ID(Id);
                        DK_AAZ011_bo.setINPUT_NAME(Name);
                        DK_AAZ011_bo.setTRN_DATE(currentTime);
                        DK_AAZ011_bo.setTRN_SER_NO(SER_NO);
                        DK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                        DK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);
                        DK_AAZ011_bo.setREL_FILE_NO("DTEPC306");
                        DK_AAZ011_bo.setACNT_DATE(ACNT_DATE);
                        DK_AAZ011_bo.setTRN_KIND("EPC304");
                        DK_AAZ011_bo.setMEMO(MapUtils.getString(PAY_INFO_MAP, "PAY_NO") + ','
                                + MapUtils.getString(PAY_INFO_MAP, "CHK_SET_NO"));

                        DK_AAZ011_bo.setACNT_DIV_NO(Op);
                        DK_AAZ011_bo.setKIND_CODE("");
                        DK_AAZ011_bo.setCURR("NTD");
                        DK_AAZ011_bo.setCNT("1");
                        DK_AAZ011_bo.setBUS_CODE("EP");
                        DK_AAZ011_bo.setBUS_TRAN_CODE("1");
                        DK_AAZ011_bo.setITEM("7");
                        DK_AAZ011_bo.setTYPE("4");
                        DK_AAZ011_bo.setAMT(MapUtils.getString(CHK_INFO_MAP, "CHK_AMT"));
                        DK_AAZ011_bo.setBANK_NO("");
                        DK_AAZ011_bo.setACNT_NO("");
                        DK_AAZ011_bo.setDB_CR("DR");
                        DK_AAZ011_bo.setDIV_NO_C101(Op);
                        DK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);//�b�Ⱥ���
                        DK_AAZ011_bo.setBAL_TYPE(RTL_BAL_TYPE);//�b�U�O

                        DK_AAZ011_boList.add(DK_AAZ011_bo);
                        if (isDebug)
                            log.debug("�s�W������>>>" + DK_AAZ011_boList);
                    }
                }

                if (getBigDecimal(PAY_INFO_MAP.get("ACNT_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0 && MAP_ACNT_LIST != null) {//�M��P�b
                    if (!isPrePay) {
                        OVERList.add(MapUtils.getString(PAY_INFO_MAP, "PAY_NO")); //��s�j�B�q��
                    }
                    //Ū���M��M��
                    List<DTEPC307> ACNT_INFO_LIST = MAP_ACNT_LIST.get(MapUtils.getString(PAY_INFO_MAP, "ACNT_SET_NO"));

                    for (DTEPC307 ACNT_INFO_MAP : ACNT_INFO_LIST) {

                        DK_AAZ011_bo DK_AAZ011_bo = new DK_AAZ011_bo();

                        DK_AAZ011_bo.setINPUT_ID(Id);
                        DK_AAZ011_bo.setINPUT_NAME(Name);
                        DK_AAZ011_bo.setTRN_DATE(currentTime);
                        DK_AAZ011_bo.setTRN_SER_NO(SER_NO);
                        DK_AAZ011_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                        DK_AAZ011_bo.setSLIP_SET_NO(SLIP_SET_NO);
                        DK_AAZ011_bo.setREL_FILE_NO("DTEPC306");
                        DK_AAZ011_bo.setACNT_DATE(ACNT_DATE);
                        DK_AAZ011_bo.setTRN_KIND("EPC304");
                        DK_AAZ011_bo.setMEMO(MapUtils.getString(PAY_INFO_MAP, "PAY_NO") + ','
                                + MapUtils.getString(PAY_INFO_MAP, "ACNT_SET_NO"));

                        DK_AAZ011_bo.setACNT_DIV_NO(Op);
                        DK_AAZ011_bo.setKIND_CODE("");
                        DK_AAZ011_bo.setCURR("NTD");
                        DK_AAZ011_bo.setCNT("1");
                        DK_AAZ011_bo.setBUS_CODE("EP");
                        DK_AAZ011_bo.setBUS_TRAN_CODE("1");
                        DK_AAZ011_bo.setITEM("7");
                        DK_AAZ011_bo.setTYPE("11");
                        DK_AAZ011_bo.setAMT(ACNT_INFO_MAP.getAMOUNT().toString());
                        DK_AAZ011_bo.setBANK_NO(ACNT_INFO_MAP.getBANK_NO());
                        DK_AAZ011_bo.setACNT_NO(ACNT_INFO_MAP.getACNT_NO());
                        DK_AAZ011_bo.setDB_CR("DR");
                        DK_AAZ011_bo.setDIV_NO_C101(Op);
                        DK_AAZ011_bo.setACNT_TYPE(ACNT_TYPE);//�b�Ⱥ���
                        DK_AAZ011_bo.setBAL_TYPE(RTL_BAL_TYPE);//�b�U�O

                        DK_AAZ011_boList.add(DK_AAZ011_bo);
                        if (isDebug) {
                            log.debug("�s�W�M��>>>" + DK_AAZ011_boList);
                        }
                    }

                    Map slipMap = new HashMap();
                    slipMap.put("SLIP_DIV_NO", Op); //�s�����
                    slipMap.put("SLIP_SET_NO", SLIP_SET_NO); //�ǲ��ո�
                    slipMap.put("SLIP_LOT_NO", SLIP_LOT_NO); //�ǲ��帹
                    slipMap.put("SLIP_DATE", ACNT_DATE); //�ǲ����
                    slipMap.put("USER_TRN_SERNO", SER_NO); //�g�����Ǹ�
                    if (isDebug) {
                        log.debug("slipMap>>>" + slipMap);
                        log.debug("ACNT_INFO_LIST>>>" + ACNT_INFO_LIST);
                        log.debug("insertDTDCB007>>>�}�l");
                    }
                    //new DC_B0Z009().insertDTDCB007(slipMap);
                    if (isDebug) {
                        log.debug("insertDTDCB007>>>�}�l");
                        log.debug("insertDTDCB004>>>�}�l");
                    }
                    new DC_B0Z002().insertDTDCB004(ACNT_INFO_LIST, slipMap, user);
                    if (isDebug) {
                        log.debug("insertDTDCB004>>>�}�l");
                    }

                }

                if (getBigDecimal(PAY_INFO_MAP.get("TKD_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {//�R�Ȧ�
                    //Ū���R�Ȧ��M��
                    ds.clear();
                    ds.setFieldValues("DTMP_NO", MapUtils.getString(PAY_INFO_MAP, "DTMP_NO").split(","));
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    List<Map> TKD_INFO_LIST = VOTool.findToMaps(ds, SQL_queryTmpInfo_001);
                    for (Map TKD_INFO_MAP : TKD_INFO_LIST) {
                        DTDKG003 DTDKG003_bo = new DTDKG003();
                        DTDKG003_bo.setDTMP_NO(MapUtils.getString(TKD_INFO_MAP, "DTMP_NO"));
                        DTDKG003_bo.setTMP_NO(MapUtils.getString(TKD_INFO_MAP, "TMP_NO"));
                        DTDKG003_bo.setTRN_KIND(MapUtils.getString(TKD_INFO_MAP, "TRN_KIND"));
                        DTDKG003_bo.setTMP_CD(MapUtils.getString(TKD_INFO_MAP, "TMP_CD"));
                        DTDKG003_bo.setTMP_KIND(MapUtils.getString(TKD_INFO_MAP, "TMP_KIND"));
                        DTDKG003_bo.setINPUT_CD(MapUtils.getString(TKD_INFO_MAP, "INPUT_CD"));
                        DTDKG003_bo.setDACNT_ID(Id);
                        DTDKG003_bo.setDACNT_NAME(Name);
                        DTDKG003_bo.setDACNT_IN_DATE(currentTime);
                        DTDKG003_bo.setDACNT_SER_NO(SER_NO);
                        DTDKG003_bo.setDACNT_DIV_NO(Op);
                        DTDKG003_bo.setDACNT_DIV_NAME(DACNT_DIV_NAME);
                        DTDKG003_bo.setDACNT_DATE(ACNT_DATE);
                        DTDKG003_bo.setSLIP_DATE(ACNT_DATE);
                        DTDKG003_bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                        DTDKG003_bo.setSLIP_SET_NO("1");
                        DTDKG003_bo.setDACNT_AMT(MapUtils.getString(TKD_INFO_MAP, "DACNT_AMT"));
                        DTDKG003_bo.setSUB_ACNT_CODE(MapUtils.getString(TKD_INFO_MAP, "DSUB_ACNT_CODE"));
                        DTDKG003_bo.setDTL_ACNT_CODE(MapUtils.getString(TKD_INFO_MAP, "DDTL_ACNT_CODE"));
                        DTDKG003_bo.setTMP_D_KIND(MapUtils.getString(TKD_INFO_MAP, "DTMP_D_KIND"));
                        DTDKG003_bo.setRTN_KIND(MapUtils.getString(TKD_INFO_MAP, "DRTN_KIND"));
                        DTDKG003_bo.setPREM_RCV_KIND(MapUtils.getString(TKD_INFO_MAP, "DPREM_RCV_KIND"));
                        DTDKG003_bo.setACPT_DIV_NO(MapUtils.getString(TKD_INFO_MAP, "DACPT_DIV_NO"));
                        DTDKG003_bo.setACPT_DIV_NAME(MapUtils.getString(TKD_INFO_MAP, "DACPT_DIV_NAME"));
                        DTDKG003_bo.setACPT_KIND(MapUtils.getString(TKD_INFO_MAP, "DACPT_KIND"));
                        DTDKG003_bo.setACPT_ID_KIND(MapUtils.getString(TKD_INFO_MAP, "DACPT_ID_KIND"));
                        DTDKG003_bo.setACPT_ID(MapUtils.getString(TKD_INFO_MAP, "DACPT_ID"));
                        DTDKG003_bo.setACPT_ACNT_NAME(MapUtils.getString(TKD_INFO_MAP, "DACPT_ACNT_NAME"));
                        DTDKG003_bo.setACPT_BANK_NO(MapUtils.getString(TKD_INFO_MAP, "DACPT_BANK_NO"));
                        DTDKG003_bo.setACPT_ACNT_NO(MapUtils.getString(TKD_INFO_MAP, "DACPT_ACNT_NO"));
                        DTDKG003_bo.setTMP_NO_D(MapUtils.getString(TKD_INFO_MAP, "DTMP_NO_D"));
                        DTDKG003_bo.setRCPT_NO(MapUtils.getString(TKD_INFO_MAP, "DRCPT_NO"));
                        DTDKG003_bo.setRTN_RCPT_NO(MapUtils.getString(TKD_INFO_MAP, "DRTN_RCPT_NO"));
                        if (isDebug) {
                            log.debug("DTDKG003_bo>>>" + DTDKG003_bo);
                        }
                        new DK_G0Z011().insertDTDKF001fromG003ForXA(DTDKG003_bo, msg);
                        if (isDebug) {
                            log.debug("�s�W�R�Ȧ�>>>" + DK_AAZ011_boList);
                        }
                    }
                }

                if (getBigDecimal(PAY_INFO_MAP.get("TMP_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {//�Ȧ�
                    DTDKG002 DTDKG002_Bo = new DTDKG002();
                    for (String TMPNO : TMP_NOs) {
                        try {
                            //Ū���Ȧ��M��                                
                            if (isDebug) {
                                log.debug("Ū���Ȧ�DK_G0Z007>>>");
                                log.debug("TMP_NO>>>" + TMPNO);
                                log.debug("�}�lDK_G0Z007>>>");
                            }
                            DTDKG002_Bo = new DK_G0Z007().queryByPKForXA(TMPNO, rm);
                            if (isDebug) {
                                log.debug("����DK_G0Z007>>>");
                                log.debug("DTDKG002_Bo>>>" + DTDKG002_Bo);
                            }
                        } catch (Exception e) {
                            log.error("", e);
                            throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_038") + e);//�I�s�|�p�Ҳ�DK_G0Z007�d�߸�Ʀ��~�A
                        }

                        try {
                            DTDKG002_Bo.setSLIP_DATE(ACNT_DATE);
                            DTDKG002_Bo.setACNT_DATE(ACNT_DATE);
                            DTDKG002_Bo.setACNT_DIV_NO(Op);
                            DTDKG002_Bo.setSLIP_LOT_NO(SLIP_LOT_NO);
                            DTDKG002_Bo.setSLIP_SET_NO(SLIP_SET_NO);
                            DTDKG002_Bo.setACNT_SER_NO(SER_NO);

                            //��sú�O���p�b�ȸ�T(��sG002�M�s�WF001)
                            log.debug("�s�W�Ȧ�>>>" + DTDKG002_Bo);
                            //Ū���Ȧ��M��                                
                            if (isDebug) {
                                log.debug("�s�W�Ȧ�DK_G0Z002>>>");
                                log.debug("DTDKG002_Bo>>>" + DTDKG002_Bo);
                                log.debug("�}�lDK_G0Z002>>>");
                            }
                            new DK_G0Z002().insertDTDKG002ByHandForXA_2(DTDKG002_Bo, rm, user);
                            if (isDebug)
                                log.debug("�s�W�Ȧ����\>>>");
                            if (msg.getReturnCode() != ReturnCode.OK) {
                                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_033") + msg.getMsgDesc());//�Ȧ��X�bDK_G0Z002����
                            }

                        } catch (Exception e) {
                            log.error("", e);
                            throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_039") + e.getMessage());//�I�s�|�p�Ҳ�DK_G0Z002�s�W���insertDTDKG002ByHandForXA_2���~�A
                        }
                    }
                }
                if (!DK_AAZ011_boList.isEmpty()) {
                    //����g�J�|�p�������������
                    //Call�|�p�b�ȼҲ�.�s�W��k
                    theDK_A0Z003.doInsert(DK_AAZ011_boList, msg);

                    if (isDebug)
                        log.debug("DK_AAZ011_boList>>>" + DK_AAZ011_boList);

                    if (msg.getReturnCode() != ReturnCode.OK) {
                        if (isDebug)
                            log.debug("", msg.getException());
                        throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_014") + msg.getMsgDesc());//�I�s�|�p�b�ȼҲ�DK_A0Z003����:
                    }

                }

                //Callú�ڱb�ȽT�{���@�Ҳ�.��s�鵲�b�ȸ�T��k
                //isBatch = false >> C301,C306,C307 �v������
                this.updateCloseAcntInfo(MapUtils.getString(reqMap, "RCV_YM"), MapUtils.getString(reqMap, "PAY_NO"), MapUtils.getString(
                    reqMap, "RCV_NO"), "06", ACNT_DATE_d, Op, SLIP_LOT_NO, SLIP_SET_NO_i, getBigDecimal(SER_NO, BigDecimal.ZERO), user,
                    RTL_BAL_TYPE, isBatch, SUB_CPY_ID);

                //reset isPrePay
                isPrePay = false;
            } else {//�D���

                if ("0".equals(RCV_YM)) {//�wú�Ȧ�
                    String[] TMP_NOs = TMP_NO.split(",");
                    for (String TMPNO : TMP_NOs) {
                        DTEPC309 C309 = new DTEPC309();
                        C309.setSUB_CPY_ID(SUB_CPY_ID);
                        C309.setTMP_NO(TMPNO);
                        C309.setSLIP_DATE(ACNT_DATE_d);
                        C309.setACNT_DATE(ACNT_DATE_d);
                        C309.setACNT_DIV_NO(Op);
                        C309.setSLIP_LOT_NO(SLIP_LOT_NO);
                        C309.setSLIP_SET_NO(Integer.valueOf(SLIP_SET_NO));
                        C309.setACNT_SER_NO(STRING.objToBigDecimal(SER_NO, BigDecimal.ZERO));

                        theEP_Z0C309.updateC309ForACNT(C309);
                    }
                }

                /* [20180207] �W�[�D��سB�z */
                // PAY_NO��PK�A�������oPAY_INFO_MAP�B�z
                Map PAY_INFO_MAP = Map_C306_PAY.get(PAY_NO);

                BigDecimal TKD_AMT = STRING.objToBigDecimal(PAY_INFO_MAP.get("TKD_AMT"), BigDecimal.ZERO);
                if (TKD_AMT.compareTo(BigDecimal.ZERO) > 0) { //�R�Ȧ�
                    //[20180227]:�D��ا�gEP.�Ȧ���(��s�X�b���A)
                    List<DTEPC310> DTMP_INFO_LIST = theEP_Z0C310.queryDTEPC310ByPAY_NO(SUB_CPY_ID, PAY_NO);

                    //�v���B�zTMP_INFO_LIST�A��TMP_INFO_MAP�զ�
                    for (DTEPC310 C310VO : DTMP_INFO_LIST) {
                        //Call�Ȧ��X�b��J�B�R���Ҳ�.�H�u��J�Ю֫�g�J�|�p������k   
                        C310VO.setDACNT_SER_NO(this.getBigDecimal(SER_NO, BigDecimal.ZERO));
                        C310VO.setDACNT_DIV_NO(user.getOpUnit());
                        C310VO.setDACNT_DIV_NAME(user.getDivShortName());
                        C310VO.setSLIP_DATE(Date.valueOf(ACNT_DATE));
                        C310VO.setSLIP_LOT_NO(SLIP_LOT_NO);
                        C310VO.setSLIP_SET_NO(1);
                        theEP_Z0C310.updateC310ForACNT(C310VO);
                    }
                }
                BigDecimal TMP_AMT = STRING.objToBigDecimal(PAY_INFO_MAP.get("TMP_AMT"), BigDecimal.ZERO);
                if (TMP_AMT.compareTo(BigDecimal.ZERO) > 0) { //�Ȧ��J�b
                    //[20180227]�D��ا�gEP.�Ȧ���(��s�X�b���A)
                    //���o�Ȧ��M��
                    List<Map> TMP_INFO_LIST = theEP_Z0C309.queryDTEPC309ByPAY_NO(SUB_CPY_ID, PAY_NO);
                    //�v���B�zTMP_INFO_LIST�A��TMP_INFO_MAP�զ�
                    for (Map TMP_INFO_MAP : TMP_INFO_LIST) {
                        //Call�Ȧ��J�b��J�B�R���Ҳ�.�H�u��J�Ю֫�g�J�|�p������k
                        DTEPC309 C309VO = VOTool.mapToVO(DTEPC309.class, TMP_INFO_MAP);
                        C309VO.setSLIP_DATE(Date.valueOf(ACNT_DATE));
                        C309VO.setACNT_DATE(Date.valueOf(ACNT_DATE));
                        C309VO.setACNT_DIV_NO(Op);
                        C309VO.setSLIP_LOT_NO(SLIP_LOT_NO);
                        C309VO.setSLIP_SET_NO(Integer.valueOf(SLIP_SET_NO));
                        C309VO.setACNT_SER_NO(this.getBigDecimal(SER_NO, BigDecimal.ZERO));
                        theEP_Z0C309.updateC309ForACNT(C309VO);
                    }
                }

                //Callú�ڱb�ȽT�{���@�Ҳ�.��s�鵲�b�ȸ�T��k
                //isBatch = false >> C301,C306,C307 �v������
                this.updateCloseAcntInfo(MapUtils.getString(reqMap, "RCV_YM"), MapUtils.getString(reqMap, "PAY_NO"), MapUtils.getString(
                    reqMap, "RCV_NO"), "06", ACNT_DATE_d, Op, SLIP_LOT_NO, SLIP_SET_NO_i, getBigDecimal(SER_NO, BigDecimal.ZERO), user,
                    RTL_BAL_TYPE, isBatch, SUB_CPY_ID);

            }
        }//end for �v���B�zú�O���p����

        if (isAccountSubCpy && (!isCash && DK_AAZ011_boList.isEmpty())) {
            //�ˮֱb�ȬO�_����
            theDK_F0Z011.isBalance2(Op, Id, ACNT_DATE, SLIP_LOT_NO, SLIP_SET_NO, msg);
            if (msg.getReturnCode() != ReturnCode.OK) {
                throw new ModuleException(msg.getMsgDesc()); //�ˮֱb�ȬO�_���ŵo�Ϳ��~
            }
        }

        //isBatch = true >> C301,C306,C307 �妸����
        if (isBatch) {
            if (isDebug) {
                log.debug(">>>>>> start batch update C301,C306,C307");
                log.debug(">>batch update C307");
            }
            //����s�M��P�b��T
            theEP_Z0C307.acntUpdateBatch(C306PayList, Map_TRN_RCVYM, "06", ACNT_DATE_d, SLIP_LOT_NO, SLIP_SET_NO_i, user, budsC307);
            //����sú�O����
            if (isDebug)
                log.debug(">>batch update C306");
            theEP_Z0C306.acntUpdateBatch(C306PayList, Map_TRN_RCVYM, "06", ACNT_DATE_d, SLIP_LOT_NO, SLIP_SET_NO_i, user, budsC306);
            //����sú�O���p����
            if (isDebug)
                log.debug(">>batch update C301");
            theEP_Z0C301.acntUpdateBatch(C306PayList, Map_TRN_RCVYM, "06", ACNT_DATE_d, SLIP_LOT_NO, SLIP_SET_NO_i, user, budsC301);
        }

        //��s�j�B�q��(�D�wú)
        if (OVERList.size() > 0) {
            List<Map> C301List = new EP_Z0C301().queryListByPayNos(OVERList, SUB_CPY_ID);
            for (Map c301 : C301List) {
                BigDecimal PAY_AMT = STRING.objToBigDecimal(c301.get("PAY_AMT"), BigDecimal.ZERO);
                String C301_ID = MapUtils.getString(c301, "ID");
                if (StringUtils.isNotBlank(C301_ID) && PAY_AMT.compareTo(BigDecimal.ZERO) > 0) {
                    String PAY_NO = MapUtils.getString(c301, "PAY_NO");
                    DTDCH004_BO = new DTDCH004();
                    DTDCH004_BO.setACC_DATE(ACNT_DATE);
                    DTDCH004_BO.setACC_DIV_NO(Op);
                    DTDCH004_BO.setPOLICY_NO(MapUtils.getString(c301, "CRT_NO"));
                    DTDCH004_BO.setACC_KIND("99");
                    DTDCH004_BO.setACC_AMT(PAY_AMT.toPlainString());
                    DTDCH004_BO.setSER_NO(Integer.toString(i));
                    DTDCH004_BO.setPAY_RCV_CODE("DR");
                    DTDCH004_BO.setDACNT_CODE("Y");
                    DTDCH004_BO.setCPTL_KIND("1");
                    DTDCH004_BO.setSYS_NO("EP");
                    DTDCH004_BO.setTRN_KIND("EPC304");
                    DTDCH004_BO.setAPLY_NO(PAY_NO);
                    DTDCH004_BO.setINPUT_DIV_NO(Op);
                    DTDCH004_BO.setINPUT_ID(Id);
                    DTDCH004_BO.setINPUT_NAME(Name);
                    DTDCH004_BO.setINPUT_DATE(currentTime);
                    DTDCH004_BO.setPRE_KEY(PAY_NO + "_" + MapUtils.getString(c301, "RCV_NO"));
                    DTDCH004_BO.setSLIP_SET_NO(SLIP_SET_NO);
                    DTDCH004_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DTDCH004_BO.setUSER_TRN_SERNO(SER_NO);
                    DTDCH004_BO.setUSER_ID(Id);
                    DTDCH004_BO.setCUST_ID(MapUtils.getString(c301, "ID"));
                    DTDCH004_BO.setCUST_NAME(MapUtils.getString(c301, "CUS_NAME"));
                    DTDCH004_BO.setRMT_SET_NO(MapUtils.getString(c301, "RMT_SET_NO"));
                    i++;

                    theDC_H0Z001.insert(DTDCH004_BO, null, rm);

                    if (rm.getReturnCode() != ReturnCode.OK) {
                        throw new ModuleException(rm.getMsgDesc());
                    }
                }
            }
        }
    }

    /**
     * �����T�{�@�~
     * @param ACNT_DATE �b�Ȥ��
     * @param reqList �Ŀ�M��
     * @param user �ϥΪ̸�T
     * @throws Exception 
     */
    public void doCancelConfirm(String ACNT_DATE, String SLIP_LOT_NO, List<Map> reqList, UserObject user, String SUB_CPY_ID,
            BatchUpdateDataSet[] budsArray) throws Exception {

        ErrorInputException eie = null;
        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_011"));//�Ŀ�M�椣�o����
        }
        if (StringUtils.isBlank(ACNT_DATE) || !DATE.isDate(ACNT_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_015"));//�b�Ȥ�����o���ťB�ݬ�����榡
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_010"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        //budsArray != null >> �ϥ�buds //150410 insert
        boolean isBatch = false;
        BatchUpdateDataSet budsC301 = null;
        BatchUpdateDataSet budsC306 = null;
        BatchUpdateDataSet budsC307 = null;
        if (budsArray != null && budsArray.length == 3) {
            isBatch = true;
            budsC301 = budsArray[0];
            budsC306 = budsArray[1];
            budsC307 = budsArray[2];
            if (budsC301 == null || budsC306 == null || budsC307 == null) {
                throw new ErrorInputException("buds�ǤJ�ƶq���~");
            }
        }

        if (isDebug)
            log.debug(">>>>>isBatch:" + isBatch);
        //�]�w�鵲�帹
        //String SLIP_LOT_NO = "EP7";
        //���o����Ǹ�
        String SER_NO = "0";
        String TRN_SER_NO = "";
        String SLIP_SET_NO = "";
        ReturnMessage rm = new ReturnMessage();

        /* [20180207] �����P�_�� if ("00".equals(SUB_CPY_ID)) */
        EP_Z0C306 theEP_Z0C306 = new EP_Z0C306();
        EP_Z0C307 theEP_Z0C307 = new EP_Z0C307();

        //�����oú�O���� //150416 insert 
        List<Map> C306PayList = theEP_Z0C306.queryPayList(reqList, SUB_CPY_ID);
        Map<String, Map> Map_C306_PAY = new HashMap<String, Map>();
        for (Map c306 : C306PayList) {
            Map_C306_PAY.put(MapUtils.getString(c306, "PAY_NO"), c306);
        }
        //�����o�M�����
        Map<String, Map> Map_TRN_RCVYM = new HashMap<String, Map>(); //150416 insert

        //�O�_��s�j�B�q���P�_
        List<String> OVERList = new ArrayList<String>();
        DTDCH004 DTDCH004_BO = new DTDCH004();
        DC_H0Z001 theDC_H0Z001 = new DC_H0Z001();
        int i = 1;
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        DC_B0Z002 theDC_B0Z002 = new DC_B0Z002();
        DK_G0Z002 theDK_G0Z002 = new DK_G0Z002();
        EP_Z0C310 theEP_Z0C310 = new EP_Z0C310();
        EP_Z0C309 theEP_Z0C309 = new EP_Z0C309();

        String RCV_YM = "";
        String PAY_NO = "";
        String TMP_NO = "";
        String DTMP_NO = "";
        String strPayNo = "";
        //Callú�ڱb�ȽT�{���@�Ҳ�.���oú�ڰO���M���k 
        for (Map reqMap : reqList) {
            if (isDebug)
                log.debug(reqMap);
            PAY_NO = MapUtils.getString(reqMap, "PAY_NO");
            TMP_NO = MapUtils.getString(reqMap, "TMP_NO", "");
            DTMP_NO = MapUtils.getString(reqMap, "DTMP_NO", "");

            String[] TMP_NOs = TMP_NO.split(",");
            String[] DTMP_NOs = DTMP_NO.split(",");
            if (strPayNo.equals(PAY_NO)) {
                continue;
            } else {
                strPayNo = PAY_NO;
            }
            Map rtnMap = Map_C306_PAY.get(strPayNo); //150416 update
            SER_NO = MapUtils.getString(rtnMap, "TRN_SER_NO");
            SLIP_SET_NO = MapUtils.getString(rtnMap, "SLIP_SET_NO");
            RCV_YM = MapUtils.getString(reqMap, "RCV_YM");

            //�]�wú�O���������A�g�����Ǹ� //150416 insert
            Map payInfo = new HashMap();
            payInfo.put("TRN_SER_NO", SER_NO);
            payInfo.put("RCV_YM", RCV_YM);
            Map_TRN_RCVYM.put(PAY_NO, payInfo);

            //��������P�b�@�~
            //�v���B�zreqList
            if (getBigDecimal(MapUtils.getString(reqMap, "TKD_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {//�R�Ȧ�
                /* [20180207] �s�W�P�_���I�sEP_Z00030  */
                if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                    //�٭�G003�ǲ�������� 
                    log.error("deleteF001andUpdateG003_XA>>>�}�l");
                    log.error(DTMP_NOs);
                    new DK_G0Z011().deleteF001andUpdateG003_XA2(DTMP_NOs, rm);
                    log.error("deleteF001andUpdateG003_XA>>>����");
                } else {
                    //[20180227]:�D��ا�gEP.�Ȧ���(��s�X�b���A)
                    theEP_Z0C310.updC310sForCancelACNT(SUB_CPY_ID, DTMP_NOs);
                }

                /* [20180207] �s�W�P�_�I�sEP_Z00030  */
            } else if (getBigDecimal(MapUtils.getString(reqMap, "ACNT_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0
                    && theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//�M��P�b
                OVERList.add(PAY_NO); //�Y�M�ᦳ��ơA�h��s�j�B�q��
                //Ū���M��M��
                DataSet ds = Transaction.getDataSet();
                ds.clear();
                ds.setField("ACNT_SET_NO", MapUtils.getString(reqMap, "ACNT_SET_NO"));
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                Map DTEPC307Map = VOTool.findOneToMap(ds, SQL_queryAcntInfo_001);

                Map slipMap = new HashMap();
                slipMap.put("SLIP_DIV_NO", DTEPC307Map.get("ACNT_DIV_NO")); //�s�����
                slipMap.put("SLIP_SET_NO", DTEPC307Map.get("SLIP_SET_NO")); //�ǲ��ո�
                slipMap.put("SLIP_LOT_NO", DTEPC307Map.get("SLIP_LOT_NO")); //�ǲ��帹
                slipMap.put("SLIP_DATE", DTEPC307Map.get("ACNT_DATE")); //�ǲ����
                slipMap.put("USER_TRN_SERNO", DTEPC307Map.get("TRN_SER_NO")); //�g�����Ǹ�
                //new DC_B0Z009().deleteDTDCB007(slipMap);
                theDC_B0Z002.deleteDTDCB004(slipMap, user);

            } else if (getBigDecimal(MapUtils.getString(reqMap, "RMT_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {//�״�
                if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                    OVERList.add(PAY_NO); //�Y�״ڦ���ơA�h��s�j�B�q��
                }
            }

            //Callú�ڱb�ȽT�{���@�Ҳ�.��s�鵲�b�ȸ�T��k           
            this.updateCloseAcntInfo(RCV_YM, strPayNo, MapUtils.getString(reqMap, "RCV_NO", ""), "01", Date.valueOf(ACNT_DATE), user
                    .getOpUnit(), SLIP_LOT_NO, 1, getBigDecimal(SER_NO, BigDecimal.ZERO), user, "", isBatch, SUB_CPY_ID);

            if (isDebug)
                log.debug("�w�P�Ȧ��i�J");
            if (getBigDecimal(MapUtils.getString(reqMap, "CSH_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) == 0) {//�������{���w�P
                log.error("�{�����B>>>");
                log.error(MapUtils.getString(reqMap, "CSH_AMT"));

                if (TMP_NOs.length > 0) {
                    /* [20180207] �s�W�P�_���I�sEP_Z00030  */
                    if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                        List<DTDKG002> DTDKG002_Bo_List = new ArrayList<DTDKG002>();
                        if ("0".equals(RCV_YM)) {//�wú
                            try {
                                if (isDebug)
                                    log.debug("�w�P�Ȧ��i�J�d��DK_G0Z007");
                                for (String TMPNO : TMP_NOs) {
                                    OVERList.remove(PAY_NO);//�קK���ư���
                                    DTDKG002 DTDKG002_Bo = new DK_G0Z007().queryByPKForXA(TMPNO, rm);
                                    DTDKG002_Bo_List.add(DTDKG002_Bo);

                                    String TMP_IN_CD = DTDKG002_Bo.getTMP_IN_CD();
                                    //�״�/�M��:�g�J�j�B�q��
                                    if ("3".equals(TMP_IN_CD) || "B".equals(TMP_IN_CD)) {
                                        BigDecimal PAY_AMT = STRING.objToBigDecimal(DTDKG002_Bo.getACNT_AMT(), BigDecimal.ZERO);
                                        String G002_ID = DTDKG002_Bo.getID();
                                        int G002_CRT_NO_length = DTDKG002_Bo.getPOLICY_NO().length();
                                        if ((StringUtils.isNotBlank(G002_ID) || G002_CRT_NO_length == 10)
                                                && PAY_AMT.compareTo(BigDecimal.ZERO) > 0) {
                                            DTDCH004_BO = new DTDCH004();
                                            DTDCH004_BO.setPRE_KEY(PAY_NO + "_" + DTDKG002_Bo.getTMP_NO());
                                            DTDCH004_BO.setSYS_NO("EP");
                                            i++;
                                            theDC_H0Z001.delete(DTDCH004_BO, null, rm);
                                            if (rm.getReturnCode() != ReturnCode.OK) {
                                                throw new ModuleException(rm.getMsgDesc());
                                            }
                                        }
                                    }

                                    if (isDebug)
                                        log.debug("DTDKG002_Bo_List>>" + DTDKG002_Bo_List);
                                }
                                if (isDebug)
                                    log.debug("�w�P�Ȧ��i�J�d��DK_G0Z007����");
                            } catch (Exception e) {
                                log.error("", e);
                                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_040") + e);//�I�s�|�p�Ҳ�DK_G0Z007��Ʀ��~
                            }
                            if (isDebug)
                                log.debug("�w�P�Ȧ��i�J��sDK_G0Z002");
                            theDK_G0Z002.deleteDTDKF001ForXA_2(DTDKG002_Bo_List, rm);
                            if (isDebug)
                                log.debug("�w�P�Ȧ��i�J��sDK_G0Z002����");
                            if (rm.getReturnCode() != ReturnCode.OK) {
                                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_041") + rm.getMsgDesc());//�I�s�|�p�Ҳ�DK_G0Z002�٭�G002���~
                            }

                        } else if (getBigDecimal(MapUtils.getString(reqMap, "TMP_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {//�D�wú
                            try {
                                for (String TMPNO : TMP_NOs) {
                                    DTDKG002 DTDKG002_Bo = new DK_G0Z007().queryByPKForXA(TMPNO, rm);
                                    DTDKG002_Bo_List.add(DTDKG002_Bo);
                                }
                            } catch (Exception e) {
                                log.error("", e);
                                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_042") + e);//�I�s�|�p�Ҳ�DK_G0Z007��Ʀ��~
                            }
                            theDK_G0Z002.deleteDTDKF001ForXA_2(DTDKG002_Bo_List, rm);
                            if (rm.getReturnCode() != ReturnCode.OK) {
                                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_043") + rm.getMsgDesc());//�I�s�|�p�Ҳ�DK_G0Z002�٭�G002���~
                            }
                        }
                    } else {
                        //[20180227]:�D��ا�gEP.�Ȧ���(��s�X�b���A)
                        if (getBigDecimal(MapUtils.getString(reqMap, "TMP_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {
                            theEP_Z0C309.cancelAcnt(theEP_Z0C309.queryDTEPC309ByTMP_NOs(SUB_CPY_ID, TMP_NOs));
                        }
                    }//end of if(EP_Z00030.isAccountSubCpy(SUB_CPY_ID))//��ؤ~�|�X�b
                }//end of if (TMP_NOs.length > 0)
            }//END IF //IF reqMap.CSH_AMT==0 //�������{���w�P

            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                //����dk���ƧR���ɦܬd�L���
                if (TRN_SER_NO.equals(SER_NO)) {
                    log.debug("loop continue ,TRN_SER_NO =" + TRN_SER_NO);
                    continue;
                } else {
                    TRN_SER_NO = SER_NO;
                }

                //�R���|�p����(DR&CR)
                DTDKF001 DTDKF001_BO = new DTDKF001();
                DTDKF001_BO.setINPUT_ID(user.getEmpID());
                DTDKF001_BO.setTRN_SER_NO(SER_NO);
                DTDKF001_BO.setACNT_DATE(ACNT_DATE);
                DTDKF001_BO.setSLIP_LOT_NO(SLIP_LOT_NO);
                DTDKF001_BO.setSLIP_SET_NO(SLIP_SET_NO);
                DTDKF001_BO.setACNT_DIV_NO(user.getOpUnit());
                DTDKF001_BO.setREL_FILE_NO("DTEPC306");
                if (isDebug) {
                    log.debug("�w�P�Ȧ��i�J�d��DK_G0Z007�}�l");
                    log.debug("DTDKF001_BO>>" + DTDKF001_BO);
                }
                //Call�U����|�p���������ɿ�J�N�R���Ҳ�.Delete����|�p���������ɤ�k
                new DK_F0Z017().deletePlenty(DTDKF001_BO, rm);
                if (isDebug)
                    log.debug("�w�P�Ȧ��i�J�d��DK_F0Z017����");
                if (rm.getReturnCode() != ReturnCode.OK) {
                    throw new ModuleException("�I�s�|�p�Ҳ�DK_F0Z017�RF001���~");
                }
            }
        }//end for (Map reqMap : reqList) {

        if (isBatch) {
            Date ACNT_DATE_d = Date.valueOf(ACNT_DATE);
            Integer SLIP_SET_NO_i = Integer.valueOf(SLIP_SET_NO);
            //�������M��P�b��T
            theEP_Z0C307.acntUpdateBatch(C306PayList, Map_TRN_RCVYM, "01", ACNT_DATE_d, SLIP_LOT_NO, SLIP_SET_NO_i, user, budsC307);
            //������ú�O����
            theEP_Z0C306.acntUpdateBatch(C306PayList, Map_TRN_RCVYM, "01", ACNT_DATE_d, SLIP_LOT_NO, SLIP_SET_NO_i, user, budsC306);
            //������ú�O���p����
            new EP_Z0C301().acntUpdateBatch(C306PayList, Map_TRN_RCVYM, "01", ACNT_DATE_d, SLIP_LOT_NO, SLIP_SET_NO_i, user, budsC301);
        }

        //�R���j�B�q��
        if (isDebug)
            log.debug("#### OVERList::" + OVERList);
        if (OVERList.size() > 0) {
            List<Map> C301List = new EP_Z0C301().queryListByPayNos(OVERList, SUB_CPY_ID);
            if (isDebug)
                log.debug("#### delete DTDCH004.C301List::" + C301List);
            for (Map c301 : C301List) {
                BigDecimal PAY_AMT = STRING.objToBigDecimal(c301.get("PAY_AMT"), BigDecimal.ZERO);
                String C301_ID = MapUtils.getString(c301, "ID");
                if (StringUtils.isNotBlank(C301_ID) && PAY_AMT.compareTo(BigDecimal.ZERO) > 0) {
                    PAY_NO = MapUtils.getString(c301, "PAY_NO");
                    DTDCH004_BO = new DTDCH004();
                    DTDCH004_BO.setPRE_KEY(PAY_NO + "_" + MapUtils.getString(c301, "RCV_NO"));
                    DTDCH004_BO.setSYS_NO("EP");
                    i++;
                    theDC_H0Z001.delete(DTDCH004_BO, null, rm);
                    if (rm.getReturnCode() != ReturnCode.OK) {
                        throw new ModuleException(rm.getMsgDesc());
                    }
                }
            }//end for
        }//end if
    }

    /**
     * ��s�鵲�b�ȸ�T
     * @param PAY_NO ú�O�s��
     * @param RCV_NO �����s��
     * @param TRN_KIND �������
     * @param ACNT_DATE �b�Ȥ��
     * @param ACNT_DIV_NO �b�ȳ��
     * @param SLIP_LOT_NO �ǲ��帹
     * @param SLIP_SET_NO �ǲ��ո�
     * @param TRN_SER_NO �g�����Ǹ�
     * @param user �ϥΪ̸�T
     * @throws Exception 
     */
    public void updateCloseAcntInfo(String RCV_YM, String PAY_NO, String RCV_NO, String TRN_KIND, Date ACNT_DATE, String ACNT_DIV_NO,
            String SLIP_LOT_NO, Integer SLIP_SET_NO, BigDecimal TRN_SER_NO, UserObject user, String BAL_TYPE, boolean isBatch,
            String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_017"));//����������o����
        } else if (!"01".equals(TRN_KIND) && !"06".equals(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_018"));//����������~
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_001"));//�b�ȳ�줣�o����
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_002"));//�ǲ��帹���o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_007"));//�b�Ȥ�����o����
        }
        if (SLIP_SET_NO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_008"));//�ǲ��ո����o����
        }
        if (TRN_SER_NO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_009"));//�g�����Ǹ����o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_010"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }

        if (StringUtils.isNotBlank(PAY_NO)) {
            //���oú�ڰO���M��
            //�v���B�zPAY_INFO_LIST�A��PAY_INFO_MAP�զ�
            for (Map PAY_INFO_MAP : this.queryPayInfoList(PAY_NO, SUB_CPY_ID)) {
                String CHK_SET_NO = MapUtils.getString(PAY_INFO_MAP, "CHK_SET_NO");
                if (StringUtils.isNotBlank(CHK_SET_NO)) {
                    //Call��s���ک��ӱb�ȸ�T��k C302
                    this.updateChkInfo(PAY_NO, CHK_SET_NO, TRN_KIND, ACNT_DATE, ACNT_DIV_NO, SLIP_LOT_NO, SLIP_SET_NO, TRN_SER_NO, user,
                        BAL_TYPE, SUB_CPY_ID);
                }
                String RMT_SET_NO = MapUtils.getString(PAY_INFO_MAP, "RMT_SET_NO");
                if (StringUtils.isNotBlank(RMT_SET_NO)) {
                    //Call��s�״ک��ӱb�ȸ�T��k C303
                    this.updateRmtInfo(PAY_NO, RCV_NO, RMT_SET_NO, TRN_KIND, ACNT_DATE, ACNT_DIV_NO, SLIP_LOT_NO, SLIP_SET_NO, TRN_SER_NO,
                        user, BAL_TYPE, SUB_CPY_ID);
                }
                if (isDebug) {
                    log.debug("ACNT_SET_NO ===> " + MapUtils.getString(PAY_INFO_MAP, "ACNT_SET_NO"));
                }
                String ACNT_SET_NO = MapUtils.getString(PAY_INFO_MAP, "ACNT_SET_NO");
                if (StringUtils.isNotBlank(ACNT_SET_NO)) {
                    //Call��s�M����ӱb�ȸ�T��k(C307)�A�令����s //20150415 update
                    if (!isBatch) {
                        if (isDebug)
                            log.debug(">>�浧update C307");
                        this.updateAcntInfo(PAY_NO, RCV_NO, ACNT_SET_NO, TRN_KIND, ACNT_DATE, ACNT_DIV_NO, SLIP_LOT_NO, SLIP_SET_NO,
                            TRN_SER_NO, SUB_CPY_ID, user);
                    }
                }
            }
            //��sú�ڰO���b�ȸ�T(C306)�A�令����s//20150415 update
            if (!isBatch) {
                if (isDebug)
                    log.debug(">>�浧update C306");
                new EP_Z0C306().updatePayInfo(PAY_NO, TRN_KIND, ACNT_DATE, ACNT_DIV_NO, SLIP_LOT_NO, SLIP_SET_NO, TRN_SER_NO, user,
                    SUB_CPY_ID);
            }

            if (!"0".equals(RCV_YM) && !isBatch) {
                //��sú�O���p�b�ȸ�T(C301)//�վ��ξ��B�z//20150415 update
                if (isDebug)
                    log.debug(">>�浧update C301");
                new EP_Z0C301().updateRltAcntInfo(PAY_NO, TRN_KIND, ACNT_DATE, ACNT_DIV_NO, SLIP_LOT_NO, SLIP_SET_NO, TRN_SER_NO, user,
                    SUB_CPY_ID);
            }
        }
    }

    /**
     * ��s���ک��ӱb�ȸ�T
     * @param PAY_NO ú�O�s��
     * @param CHK_SET_NO ���ڲո�
     * @param TRN_KIND �������
     * @param ACNT_DATE �b�Ȥ��
     * @param ACNT_DIV_NO �b�ȳ��
     * @param SLIP_LOT_NO �ǲ��帹
     * @param SLIP_SET_NO �ǲ��ո�
     * @param TRN_SER_NO �g�����Ǹ�
     * @param user
     * @throws Exception
     */
    public void updateChkInfo(String PAY_NO, String CHK_SET_NO, String TRN_KIND, Date ACNT_DATE, String ACNT_DIV_NO, String SLIP_LOT_NO,
            Integer SLIP_SET_NO, BigDecimal TRN_SER_NO, UserObject user, String BAL_TYPE, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_017"));//����������o����
        } else if (!"01".equals(TRN_KIND) && !"06".equals(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_018"));//����������~
        }
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_005"));//ú�O�s�����o����
        }
        if (StringUtils.isBlank(CHK_SET_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_019"));//���ڲո����o����
        }
        if (StringUtils.isBlank(ACNT_DIV_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_001"));//�b�ȳ�줣�o����
        }
        if (StringUtils.isBlank(SLIP_LOT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_002"));//�ǲ��帹���o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (ACNT_DATE == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_007"));//�b�Ȥ�����o����
        }
        if (SLIP_SET_NO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_008"));//�ǲ��ո����o����
        }
        if (TRN_SER_NO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_009"));//�g�����Ǹ����o����
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_010"));//�ϥΪ̸�T���o����
        }
        if (eie != null) {
            throw eie;
        }
        DJ_C0Z025 theDJ_C0Z025 = new DJ_C0Z025();
        DE_A0Z220 theDE_A0Z220 = new DE_A0Z220();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();

        boolean isAccountSubCpy = theEP_Z00030.isAccountSubCpy(SUB_CPY_ID);
        //Ū��DTEPC301ú�O���p��
        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> CHK_RTL_LIST = null;
        if (isAccountSubCpy) {
            CHK_RTL_LIST = VOTool.findToMaps(ds, SQL_updateChkInfo_001);
        } else {
            /* [20180227]�D��جdEP */
            CHK_RTL_LIST = VOTool.findToMaps(ds, SQL_updateChkInfo_005);
        }
        String Id = user.getEmpID();
        String date = DATE.getDBDate();
        ReturnMessage msg = new ReturnMessage();

        ds.clear();
        ds.setField("CHK_SET_NO", CHK_SET_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if ("06".equals(TRN_KIND)) {
            /* [20180207] �P�_����I�sEP_Z00030  */
            if (isAccountSubCpy) {
                //�H���ڲո�Ū��DTEPC302���ک�����
                List<Map> CHK_INFO_LIST = VOTool.findToMaps(ds, SQL_updateChkInfo_002);

                //�v���B�zCHK_INFO_LIST�A��CHK_INFO_MAP�զ�
                //�ˮ֬O�_���^�y��
                //Call�䲼���Ӭd�߼Ҳ�.�䲼���Ӭd�ߤ�k
                List<DTDEA120> DTDEA120List = new ArrayList<DTDEA120>();
                List<DTDEA310> DTDEA310List = new ArrayList<DTDEA310>();
                for (Map CHK_INFO_MAP : CHK_INFO_LIST) {
                    DTDEA120 DTDEA120_BO = new DTDEA120();

                    String ACNT_NO = MapUtils.getString(CHK_INFO_MAP, "ACNT_NO");
                    String CHK_NO = MapUtils.getString(CHK_INFO_MAP, "CHK_NO");//�q��2�X�����5�X
                    if (isDebug) {
                        log.debug("$$$ ACNT_NO::" + ACNT_NO + " || CHK_NO::" + CHK_NO);
                    }
                    theDJ_C0Z025.getCheckDetail_BO(ACNT_NO.substring(1, 6), CHK_NO, msg);

                    String CO_CHK_TYPE = msg.getReturnCode() != 0 ? "0" : "1";

                    //�զ�DTDEA120�榡

                    DTDEA120_BO.setBANK_NO(STRING.fillZero(MapUtils.getString(CHK_INFO_MAP, "BANK_NO"), 7)); //��w�N��
                    DTDEA120_BO.setCHK_NO(STRING.fillZero(MapUtils.getString(CHK_INFO_MAP, "CHK_NO"), 8)); //���ڸ��X
                    DTDEA120_BO.setACNT_NO(STRING.fillZero(ACNT_NO, 16));//�b��
                    DTDEA120_BO.setCHK_SET_NO(CHK_SET_NO);//���ڲո�
                    DTDEA120_BO.setACNT_DIV_NO(ACNT_DIV_NO);//���b���
                    DTDEA120_BO.setRCV_DIV_NO(ACNT_DIV_NO);//�������(���ڳ��)
                    DTDEA120_BO.setCHK_KIND("8");//���O
                    DTDEA120_BO.setACNT_DATE(ACNT_DATE.toString()); //�@�b���
                    DTDEA120_BO.setPAY_DATE(date);//ú�O���
                    String CHK_AMT = MapUtils.getString(CHK_INFO_MAP, "CHK_AMT");
                    DTDEA120_BO.setCHK_AMT(CHK_AMT);//���ڪ��B
                    DTDEA120_BO.setCHK_DATE(MapUtils.getString(CHK_INFO_MAP, "CHK_DATE"));//���ڤ��
                    DTDEA120_BO.setCLC_NO(STRING.fillBlank("", 7));//���O�N��(7�Ӫťզr��)
                    DTDEA120_BO.setINPUT_ID(Id);//��J�H��
                    DTDEA120_BO.setINPUT_DATE(date);//��J���
                    DTDEA120_BO.setTRN_SER_NO(TRN_SER_NO.toString());//�J�b����Ǹ�
                    DTDEA120_BO.setSLIP_LOT_NO(SLIP_LOT_NO);//�ǲ��帹
                    DTDEA120_BO.setSLIP_SET_NO(SLIP_SET_NO.toString());//�ǲ��ո�
                    DTDEA120_BO.setOVR_PAY_TYPE("0");//��ú�O
                    DTDEA120_BO.setOVR_PAY_AMT("0");//��ú���B
                    DTDEA120_BO.setDP_GRP(STRING.fillBlank("", 1));//��ڲէO(1�Ӫťզr��)
                    DTDEA120_BO.setDACNT_SER_NO("0");//�鵲�Ǹ�
                    DTDEA120_BO.setOLD_CHK_KIND("");//�첼�O
                    DTDEA120_BO.setCO_CHK_TYPE(CO_CHK_TYPE);//�^�y��(���q��)
                    DTDEA120_BO.setBAL_TYPE(BAL_TYPE);
                    if ("CA".equals(BAL_TYPE)) {
                        DTDEA120_BO.setCA_CHK_AMT(CHK_AMT);
                        DTDEA120_BO.setSG_CHK_AMT("0");
                    } else {
                        DTDEA120_BO.setCA_CHK_AMT("0");
                        DTDEA120_BO.setSG_CHK_AMT(CHK_AMT);
                    }

                    DTDEA120List.add(DTDEA120_BO);
                    /*try {
                        //Call���ک��Ӽg�J�Ҳ�.�s�W��k
                        theDE_A0Z220.doInsertForXA(DTDEA120_BO, Name);
                    } catch (Exception me) {
                        log.error("", me);
                        throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_020") + me.getMessage());//�g�J���ک����ɦ��~,
                    }*/

                }//END FOR(�v���B�zCHK_INFO_LIST�A��CHK_INFO_MAP�զ�)

                //�v���B�zCHK_RTL_LIST�A��CHK_RTL_MAP�զ�
                //�զ�DTDEA310�榡
                // DE_A0Z230 theDE_A0Z230 = new DE_A0Z230();
                EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();
                for (Map CHK_RTL_MAP : CHK_RTL_LIST) {
                    DTDEA310 DTDEA310_BO = new DTDEA310();

                    DTDEA310_BO.setCHK_SET_NO(CHK_SET_NO);//���ڲո�
                    DTDEA310_BO.setCASE_NO(MapUtils.getString(CHK_RTL_MAP, "RCV_NO"));//�ץ�s��
                    DTDEA310_BO.setBGN_DATE("00000000");//ú��/ú���l��
                    DTDEA310_BO.setPAY_TYPE("1");//ú�O�O(���I�覡)
                    DTDEA310_BO.setDP_PAR_ENT_NO("00");//��ڳ��J�Ǹ�
                    DTDEA310_BO.setCHK_KIND("8");//���O
                    DTDEA310_BO.setEND_DATE(null);//ú���״�
                    DTDEA310_BO.setOVR_PAY_TYPE("0");//��ú�O
                    DTDEA310_BO.setPAY_DATE(date);//ú�O���
                    DTDEA310_BO.setACNT_DATE(ACNT_DATE.toString());//�b�Ȥ��
                    DTDEA310_BO.setACNT_DIV_NO(ACNT_DIV_NO);//�@�b���
                    DTDEA310_BO.setNET_PAY_AMT(MapUtils.getString(CHK_RTL_MAP, "PAY_AMT"));//��ú���B
                    DTDEA310_BO.setINPUT_ID(Id);//��J�H��
                    DTDEA310_BO.setINPUT_DATE(date);//��J���
                    DTDEA310_BO.setTRN_SER_NO(TRN_SER_NO.toString());//�J�b����Ǹ�
                    DTDEA310_BO.setSLIP_LOT_NO(SLIP_LOT_NO);//�ǲ��帹
                    DTDEA310_BO.setSLIP_SET_NO(SLIP_SET_NO.toString());//�ǲ��ո�
                    DTDEA310_BO.setBAL_TYPE(theEP_Z0G103.getBAL_TYPE(SUB_CPY_ID, MapUtils.getString(CHK_RTL_MAP, "BLD_CD")));//150604 modified for �䲼����.BAL_TYPE�ӨC��������

                    //Call�O����Ӽg�J�Ҳ�.�s�W�O������ɤ�k
                    DTDEA310List.add(DTDEA310_BO);
                    /*try {
                        theDE_A0Z230.insertDTDEA310ForXA(DTDEA310_BO);
                    } catch (Exception me) {
                        log.error("", me);
                        throw new Exception(MessageUtil.getMessage("EP_C30040_MSG_021") + me.getMessage());//�g�J�O������ɦ��~,
                    }*/

                }//END FOR(�v���B�zCHK_RTL_LIST�A��CHK_RTL_MAP�զ�)

                //�g�J���ڨt��
                new DE_A0Z360().doInsertForXA(DTDEA120List, DTDEA310List, user.getEmpName());

            }//end if

            ds.clear();
            //��WDTEPC302���ک����ɱb�ȸ�T
            ds.setField("TRN_SER_NO", TRN_SER_NO);
            ds.setField("ACNT_DATE", ACNT_DATE);
            ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
            ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
            ds.setField("SLIP_SET_NO", SLIP_SET_NO);
            ds.setField("CHK_SET_NO", CHK_SET_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.executeUpdate(ds, SQL_updateChkInfo_003);
        } else if ("01".equals(TRN_KIND)) {
            /* [20180207] �P�_����I�sEP_Z00030  */
            if (isAccountSubCpy) {
                DE_A0Z230 theDE_A0Z230 = new DE_A0Z230();
                //�R�����������ک���
                //Call���ک��Ӽg�J�Ҳ�.�R�� BY ��J�H��ID�B�@�b����B����Ǹ���k
                theDE_A0Z220.doDeleteByINPUT_ID_ForXA(Id, ACNT_DATE.toString(), TRN_SER_NO.toString(), msg, true);
                if (msg.getReturnCode() != 0) {
                    throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_022") + msg.getMsgDesc());//�R�����ک����ɦ��~,
                }
                //�R���������O�����
                //�v���B�zCHK_RTL_LIST�A��CHK_RTL_MAP�զ�
                //Call�O����Ӽg�J�Ҳ�.�R���O�������byKey��k
                //                for (Map CHK_RTL_MAP : CHK_RTL_LIST) {
                //                    theDE_A0Z230.deleteDTDEA310ByKey(CHK_SET_NO, MapUtils.getString(CHK_RTL_MAP, "CRT_NO"), "00000000", "1", "00", msg);

                try {
                    theDE_A0Z230.deleteDTDEA310_ForXA(user.getOpUnit(), ACNT_DATE.toString(), "8", CHK_SET_NO);
                } catch (Exception me) {
                    throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_023") + me.getMessage());//�R���O������ɦ��~,
                }
                //                }
            }

            //�M��DTEPC302���ک����ɱb�ȸ�T
            try {
                ds.clear();
                ds.setField("CHK_SET_NO", CHK_SET_NO);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.executeUpdate(ds, SQL_updateChkInfo_004);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_024"));//��s���ک����ɱb�ȸ�T���~,
            }

        }//end if

    }

    /**
     * ��s�״ک��ӱb�ȸ�T
     * @param PAY_NO ú�O�s��
     * @param RCV_NO �����s��
     * @param RMT_SET_NO �״ڲո�
     * @param TRN_KIND �������
     * @param ACNT_DATE �b�Ȥ��
     * @param ACNT_DIV_NO �b�ȳ��
     * @param SLIP_LOT_NO �ǲ��帹
     * @param SLIP_SET_NO �ǲ��ո�
     * @param TRN_SER_NO �g�����Ǹ�
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void updateRmtInfo(String PAY_NO, String RCV_NO, String RMT_SET_NO, String TRN_KIND, Date ACNT_DATE, String ACNT_DIV_NO,
            String SLIP_LOT_NO, Integer SLIP_SET_NO, BigDecimal TRN_SER_NO, UserObject user, String BAL_TYPE, String SUB_CPY_ID)
            throws ModuleException, DBException {
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_017"));//����������o����
        } else if (!"01".equals(TRN_KIND) && !"06".equals(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_018"));//����������~
        }
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_005"));//ú�O�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //        if (StringUtils.isBlank(RCV_NO)) {
        //            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_031"));//�����s�����o����
        //        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_010"));//�ϥΪ̸�T���o����
        }

        if (eie != null) {
            throw eie;
        }

        //Ū��DTEPC301ú�O���p��
        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DC_G0Z002 theDC_G0Z002 = new DC_G0Z002();
        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        EP_Z0G103 theEP_Z0G103 = new EP_Z0G103();

        boolean isAccountSubCpy = theEP_Z00030.isAccountSubCpy(SUB_CPY_ID);
        StringBuilder sb = new StringBuilder();
        if ("06".equals(TRN_KIND)) {
            List<Map> RMT_RTL_LIST = null;
            if (isAccountSubCpy) {
                RMT_RTL_LIST = VOTool.findToMaps(ds, SQL_updateRmtInfo_001);
            } else {
                /* [20180227]�D��جdEP  */
                RMT_RTL_LIST = VOTool.findToMaps(ds, SQL_updateRmtInfo_005);
            }

            //�v���B�zRMT_RTL_LIST�A��RMT_RTL_MAP�զ�
            //�զ�DTDCG002�榡
            BigDecimal SER_NO = BigDecimal.ZERO;
            Date date = DATE.today();
            Timestamp time = DATE.currentTime();
            String Id = user.getEmpID();
            String name = user.getEmpName();
            String op = user.getOpUnit();
            if (isDebug) {
                log.debug("RMT_RTL_LIST�j�p>>>" + RMT_RTL_LIST.size());
                log.debug("RMT_RTL_LIST" + RMT_RTL_LIST);
            }
            int i = 1;
            int j = RMT_RTL_LIST.size();

            /* [20180207] �P�_����I�sEP_Z00030  */
            if (isAccountSubCpy) {
                for (Map RMT_RTL_MAP : RMT_RTL_LIST) {
                    DTDCG002 DTDCG002_vo = new DTDCG002();
                    if (i != j) {
                        DTDCG002_vo.setNET_PAY_AMT(getBigDecimal(RMT_RTL_MAP.get("PAY_AMT"), BigDecimal.ZERO));
                    } else {
                        BigDecimal PAY_AMT = getBigDecimal(RMT_RTL_MAP.get("PAY_AMT"), BigDecimal.ZERO);
                        BigDecimal TMP_AMT = getBigDecimal(RMT_RTL_MAP.get("TMP_AMT"), BigDecimal.ZERO);
                        DTDCG002_vo.setNET_PAY_AMT(PAY_AMT.add(TMP_AMT));
                    }

                    DTDCG002_vo.setRMT_SET_NO(RMT_SET_NO);
                    DTDCG002_vo.setINDEX_SER_NO(SER_NO = SER_NO.add(BigDecimal.ONE));
                    DTDCG002_vo.setACNT_DATE(ACNT_DATE);
                    DTDCG002_vo.setACNT_DIV_NO(ACNT_DIV_NO);
                    DTDCG002_vo.setSLIP_SET_NO(SLIP_SET_NO);
                    DTDCG002_vo.setSLIP_LOT_NO(SLIP_LOT_NO);
                    DTDCG002_vo.setSYS_KIND("5");
                    DTDCG002_vo.setPOLICY_NO(MapUtils.getString(RMT_RTL_MAP, "CRT_NO"));
                    DTDCG002_vo.setAPLY_NO(PAY_NO);
                    DTDCG002_vo.setPAY_TIMES(getBigDecimal(RMT_RTL_MAP.get("CUS_NO"), null));
                    DTDCG002_vo.setPAY_TYPE(MapUtils.getString(RMT_RTL_MAP, "PAY_KIND"));
                    DTDCG002_vo.setPAY_KIND("1");
                    DTDCG002_vo.setPAY_DATE(date);

                    DTDCG002_vo.setUSER_TRN_SERNO(Integer.valueOf(TRN_SER_NO.toString()));
                    DTDCG002_vo.setUSER_ID(Id);
                    DTDCG002_vo.setOPR_DATE(time);
                    DTDCG002_vo.setOPR_ID(Id);
                    DTDCG002_vo.setOPR_NAME(name);
                    DTDCG002_vo.setOPR_DIV_NO(op);
                    if (StringUtils.isNotBlank(RCV_NO)) {
                        DTDCG002_vo.setPRE_KEY(sb.append(PAY_NO).append(",").append(RCV_NO).toString());
                    } else {
                        DTDCG002_vo.setPRE_KEY(sb.append(PAY_NO).toString());
                    }
                    DTDCG002_vo.setCURR("NTD");
                    DTDCG002_vo.setBAL_TYPE(theEP_Z0G103.getBAL_TYPE(SUB_CPY_ID, MapUtils.getString(RMT_RTL_MAP, "BLD_CD")));//150604 modified for �״ک���.BAL_TYPE�ӨC��������
                    i++;

                    sb.setLength(0);
                    //Call�鵲�פJ��ú�O���p�s�W���ʼҲ�.�s�W�鵲�פJ��ú�O���p�ɤ�k
                    try {
                        if (isDebug)
                            log.debug("�s�WDTDCG002" + DTDCG002_vo);
                        theDC_G0Z002.insertDTDCG002(DTDCG002_vo);
                        log.debug("�s�W����");
                    } catch (ModuleException me) {
                        log.error("", me);
                        throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_025"));//�g�J�鵲�פJ��ú�O���p���~,
                    }
                }
                if (isDebug)
                    log.debug("�s�W����AAAAAAAAA");
            }

            //��WDTEPC303�״ڳ�����ɱb�ȸ�T
            ds.clear();
            ds.setField("TRN_SER_NO", TRN_SER_NO);
            ds.setField("ACNT_DATE", ACNT_DATE);
            ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
            ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
            ds.setField("SLIP_SET_NO", SLIP_SET_NO);
            ds.setField("RMT_SET_NO", RMT_SET_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            try {
                DBUtil.executeUpdate(ds, SQL_updateRmtInfo_002);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_026"));//��s�״ڳ�����ɱb�ȸ�T���~,
            }

        } else if ("01".equals(TRN_KIND)) {
            List<Map> RMT_RTL_LIST = null;
            if (isAccountSubCpy) {
                RMT_RTL_LIST = VOTool.findToMaps(ds, SQL_updateRmtInfo_004);
            } else {
                /* [20180227]�D��جdEP  */
                RMT_RTL_LIST = VOTool.findToMaps(ds, SQL_updateRmtInfo_006);

            }
            /* [20180227] ��P�_��  */
            if (isAccountSubCpy) {
                //�R���鵲�פJ��ú�O���p
                //�v���B�zRMT_RTL_LIST�A��RMT_RTL_MAP�զ�
                //Call�鵲�פJ��ú�O���p�s�W���ʼҲ�.�R���鵲�פJ��ú�O���p��By��Ȥ�k
                for (Map RMT_RTL_MAP : RMT_RTL_LIST) {
                    try {
                        sb.setLength(0);
                        if (StringUtils.isNotBlank(RCV_NO)) {
                            theDC_G0Z002.deleteDTDCG002ByKey("5", sb.append(MapUtils.getString(RMT_RTL_MAP, "PAY_NO")).append(",").append(
                                MapUtils.getString(RMT_RTL_MAP, "RCV_NO")).toString());

                        } else {
                            theDC_G0Z002.deleteDTDCG002ByKey("5", sb.append(MapUtils.getString(RMT_RTL_MAP, "PAY_NO")).toString());
                        }

                    } catch (ModuleException me) {
                        log.error("", me);
                        throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_027"));//�R���鵲�פJ��ú�O���p���~,
                    }
                }
            }

            //�M��DTEPC303�״ڳ�����ɱb�ȸ�T
            ds.clear();
            ds.setField("RMT_SET_NO", RMT_SET_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            try {
                DBUtil.executeUpdate(ds, SQL_updateRmtInfo_003);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_026"));//��s�״ڳ�����ɱb�ȸ�T���~,
            }
        }
    }

    /**
     * ��s�M����ӱb�ȸ�T
     * @param PAY_NO
     * @param RCV_NO
     * @param RMT_SET_NO
     * @param TRN_KIND
     * @param ACNT_DATE
     * @param ACNT_DIV_NO
     * @param SLIP_LOT_NO
     * @param SLIP_SET_NO
     * @param TRN_SER_NO
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void updateAcntInfo(String PAY_NO, String RCV_NO, String ACNT_SET_NO, String TRN_KIND, Date ACNT_DATE, String ACNT_DIV_NO,
            String SLIP_LOT_NO, Integer SLIP_SET_NO, BigDecimal TRN_SER_NO, String SUB_CPY_ID, UserObject user) throws ModuleException,
            DBException {
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_017"));//����������o����
        } else if (!"01".equals(TRN_KIND) && !"06".equals(TRN_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_018"));//����������~
        }
        if (StringUtils.isBlank(PAY_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_005"));//ú�O�s�����o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //        if (StringUtils.isBlank(RCV_NO)) {
        //            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_031"));//�����s�����o����
        //        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30040_MSG_010"));//�ϥΪ̸�T���o����
        }

        if (eie != null) {
            throw eie;
        }

        //Ū��DTEPC301ú�O���p��
        DataSet ds = Transaction.getDataSet();
        ds.setField("PAY_NO", PAY_NO);
        // List<Map> ACNT_RTL_LIST = VOTool.findToMaps(ds, SQL_updateAcntInfo_001);

        if ("06".equals(TRN_KIND)) {
            /* [20180207] �����P�_�� if ("00".equals(SUB_CPY_ID)) */
            //��WDTEPC307�M������ɱb�ȸ�T
            ds.clear();
            ds.setField("TRN_SER_NO", TRN_SER_NO);
            ds.setField("ACNT_DATE", ACNT_DATE);
            ds.setField("ACNT_DIV_NO", ACNT_DIV_NO);
            ds.setField("SLIP_LOT_NO", SLIP_LOT_NO);
            ds.setField("SLIP_SET_NO", SLIP_SET_NO);
            ds.setField("ACNT_SET_NO", ACNT_SET_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            try {
                DBUtil.executeUpdate(ds, SQL_updateAcntInfo_002);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_032"));//��s�M�������ɱb�ȸ�T���~,
            }
        } else if ("01".equals(TRN_KIND)) {
            /* [20180207] �����P�_�� if ("00".equals(SUB_CPY_ID))  */
            //�M��DTEPC307�M������ɱb�ȸ�T
            ds.clear();
            ds.setField("ACNT_SET_NO", ACNT_SET_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            try {
                DBUtil.executeUpdate(ds, SQL_updateAcntInfo_003);
            } catch (ModuleException me) {
                log.error("", me);
                throw new ModuleException(MessageUtil.getMessage("EP_C30040_MSG_032"));//��s�M������ɱb�ȸ�T���~,
            }
        }
    }

    /**
     * ���oBigDecimal
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaluValue) {
        if (obj == null) {
            return defaluValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String value = obj.toString();
        if (NumberUtils.isNumber(value)) {
            return new BigDecimal(value);
        }
        return defaluValue;
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }
}
