package com.cathay.ep.c3.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE        Description  Author
 * 2013/08/20  Created      ������
 *
 * �@�B    �{���\�෧�n�����G
 * �ҲզW��    ú�O���p�R�Ȧ����@�Ҳ�
 * �Ҳ�ID    EP_C30030
 * ���n����    ���o�Ȧ����R�@�~
 *</pre>
 *
 * [20180227] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * 
 * @author ���_��
 * @since 2013/11/7
 */
@SuppressWarnings("unchecked")
public class EP_C30030 {

    private static final String SQL_queryTmpInfoList = "com.cathay.ep.c3.module.EP_C30030.SQL_queryTmpInfoList";

    private static final String SQL_queryTmpInfoList_001 = "com.cathay.ep.c3.module.EP_C30030.SQL_queryTmpInfoList_001";

    /**
     * ���o�Ȧ������M��
     * @param CRT_NO �����N��
     * @param CUS_NO �Ȥ�Ǹ�
     * @param ID �Τ@�s�� 
     * @return �Ȧ������M��
     * @throws ModuleException
     */
    public List<Map> queryTmpInfoList(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30030_MSG_002"));//�ǤJ�d�߸�Ƥ��o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o����
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        setfieldIfExist(ds, "CRT_NO", reqMap);
        setfieldIfExist(ds, "CUS_NO", reqMap);
        setfieldIfExist(ds, "ID", reqMap);
        try {
            List<Map> TMP_INFO_LIST = new ArrayList();
            /* [20180227] �[�P�_��  TODO*/
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                TMP_INFO_LIST = VOTool.findToMaps(ds, SQL_queryTmpInfoList);
            } else {
                /* [20180227]�D��ا�gEP.�Ȧ���  TODO*/
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                TMP_INFO_LIST = VOTool.findToMaps(ds, SQL_queryTmpInfoList_001);
            }
            //�v���B�zTMP_INFO_LIST�A��TMP_MAP�զ�
            //�~�ȧO 
            for (Map map : TMP_INFO_LIST) {
                map.put("SYS_NM", FieldOptionList.getName("EPC3", "SYS_NO", MapUtils.getString(map, "SYS_NO")));
                String CHK_STS_CODE_NM = FieldOptionList.getName("EPC", "CHK_STS_CODE", MapUtils.getString(map, "CHK_STS_CODE"));
                map.put("CHK_STS_CODE_NM", CHK_STS_CODE_NM); //���p����
            }
            return TMP_INFO_LIST;
        } catch (DataNotFoundException dnfe) {
            throw dnfe;
        } catch (ModuleException me) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30030_MSG_001"));//���o�Ȧ������M��o�Ϳ��~,
        }

    }

    /**
     * ���Ȥ~�]�ܼ�
     * @param ds
     * @param key
     * @param map
     */
    private void setfieldIfExist(DataSet ds, String key, Map map) {
        String value = MapUtils.getString(map, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }

}
