package com.cathay.ep.c3.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DataSet;

/**
 * 
<pre>
DATE    Description Author
2013/11/12  Created ������

�@�B  �{���\�෧�n�����G
�ҲզW��    �wú�䲼�I�{�T�{���@�Ҳ�
�Ҳ�ID    EP_C30140
���n����    ���o�䲼�Ȧ��w�I�{�����A�ûP����������p�T�{
</pre>

 * [20180301] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 * 
 * @author ���t�s
 * @since 2013/12/5
 */
@SuppressWarnings("unchecked")
public class EP_C30140 {
    private static final String SQL_queryMatchList_001 = "com.cathay.ep.c3.module.EP_C30140.SQL_queryMatchList_001";

    private static final String SQL_queryMatchList_002 = "com.cathay.ep.c3.module.EP_C30140.SQL_queryMatchList_002";

    private static final String SQL_queryMatchList_003 = "com.cathay.ep.c3.module.EP_C30140.SQL_queryMatchList_003";

    private static final String SQL_queryMatchList_004 = "com.cathay.ep.c3.module.EP_C30140.SQL_queryMatchList_004";

    /**
     * ���o�������M��
     * @param COA_DATE �I�{���
     * @param CFM_DATE �T�{���
     * @return �������M��
     * @throws ModuleException
     */
    public List<Map> queryMatchList(String COA_DATE_S, String COA_DATE_E, String CFM_DATE, String DIV_NO, String SUB_CPY_ID)
            throws ModuleException {

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("DIV_NO", DIV_NO);
        boolean isAccountSubCpy = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);

        if (StringUtils.isNotBlank(COA_DATE_S) && DATE.isDate(COA_DATE_S)) {
            ds.setField("COA_DATE_S", COA_DATE_S);
            if (StringUtils.isNotBlank(COA_DATE_E) && DATE.isDate(COA_DATE_E)) {
                ds.setField("COA_DATE_E", COA_DATE_E);
            }
            /* [20180301] �[�P�_��  */
            if (isAccountSubCpy) {//��ؤ~�|�X�b
                DBUtil.searchAndRetrieve(ds, SQL_queryMatchList_001);
            } else {
                DBUtil.searchAndRetrieve(ds, SQL_queryMatchList_003);
            }
        } else if (StringUtils.isNotBlank(CFM_DATE) && DATE.isDate(CFM_DATE)) {
            ds.setField("CFM_DATE", CFM_DATE);
            /* [20180301] �[�P�_��  */
            if (isAccountSubCpy) {//��ؤ~�|�X�b
                DBUtil.searchAndRetrieve(ds, SQL_queryMatchList_002);
            } else {
                DBUtil.searchAndRetrieve(ds, SQL_queryMatchList_004);
            }
        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30140_MSG_001")); //�I�{����P�T�{����ܤ֭n�@�������ŭȥB�ݬ�����榡
        }

        List<Map> MATCH_LIST = new ArrayList<Map>();
        while (ds.next()) {
            Map MATCH_MAP = VOTool.dataSetToMap(ds);
            MATCH_MAP.put("CAT_PREM_NM", FieldOptionList.getName("EPC", "PAY_KIND", MapUtils.getString(MATCH_MAP, "CAT_PREM")));
            MATCH_MAP.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND", MapUtils.getString(MATCH_MAP, "PAY_KIND")));

            MATCH_LIST.add(MATCH_MAP);
        }

        return MATCH_LIST;
    }

    /**
     * �T�{
     * @param MATCH_LIST �����M��
     * @param user �n�J��
     * @throws Exception
     */
    public void doConfirm(List<Map> MATCH_LIST, UserObject user, BatchUpdateDataSet[] budsArray, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (MATCH_LIST == null || MATCH_LIST.isEmpty()) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30140_MSG_002")); //�����M�椣�o����
        }
        if (user == null) {
            eie = getEieInstance(eie, MessageUtil.getMessage("EP_C30140_MSG_003")); //�n�J�̸�Ƥ��o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEieInstance(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //�զ�ú�ڬ�����T     
        Map PAY_MAP = new HashMap();
        List<Map> PAY_LIST = new ArrayList<Map>();
        List<Map> TKD_LIST = new ArrayList<Map>();
        BigDecimal TKD_AMT = BigDecimal.ZERO;
        for (Map map : MATCH_LIST) {
            BigDecimal mapBD = obj2Big(map, "ACNT_AMT", BigDecimal.ZERO);
            map.put("DACNT_AMT", mapBD.toString());
            map.put("SUB_CPY_ID", SUB_CPY_ID);
            TKD_AMT = TKD_AMT.add(mapBD);
            PAY_LIST.add(map);
            TKD_LIST.add(map);
        }
        PAY_MAP.put("TKD_AMT", TKD_AMT);
        PAY_MAP.put("PAY_TYPE", "6");

        new EP_C30020().insertPayInfo("EPC3_0140", PAY_MAP, PAY_LIST, null, null, TKD_LIST, null, null, null, user, budsArray);
    }

    /**
     * ���~�ˮ�
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getEieInstance(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param o
     * @param defaultValue
     * @return
     * @throws ModuleException 
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) throws ModuleException {
        Object o = MapUtils.getObject(map, key);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }
}
