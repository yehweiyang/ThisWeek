package com.cathay.ep.c3.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * DATE       Description Author
 * 2013/11/05 Created     ������
 *
 * �@�B    �{���\�෧�n�����G
 * �ҲզW��    �Ȧ��R�b��J���@�Ҳ�
 * �Ҳ�ID     EP_C30023
 * ���n����    ���oDTDKG003�������R�b�ɸ�Ƨ@�~
 *</pre>
 *
 * [20180227] �ק��
 * ��ؾɤJ:�Ϥ�call DK�Ҳ�
 *
 * @author ���_��
 * @since 2013/11/27
 */
@SuppressWarnings("unchecked")
public class EP_C30023 {

    private static final String SQL_queryTkdInfoList_001 = "com.cathay.ep.c3.module.EP_C30023.SQL_queryTkdInfoList_001";

    private static final String SQL_queryTkdInfoList_002 = "com.cathay.ep.c3.module.EP_C30023.SQL_queryTkdInfoList_002";

    /**
     * ���o�Ȧ��R�b���ӲM��
     * @param reqMap �d�߼Ȧ��R�b
     * @return �Ȧ��R�b���ӲM��
     * @throws ModuleException
     */
    public List<Map> queryTkdInfoList(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C30023_MSG_002"));//�d�߼Ȧ��R�b���o����
        }
        ErrorInputException eie = null;
        String DTMP_NO = MapUtils.getString(reqMap, "DTMP_NO");
        if (StringUtils.isBlank(DTMP_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C30023_MSG_001"));//�R�Ȧ��s�����o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setFieldValues("DTMP_NO", DTMP_NO.split(","));

        List<Map> TKD_INFO_LIST = new ArrayList<Map>();
        try {
            /* [20180227] �[�P�_��  */
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ~�|�X�b
                DBUtil.searchAndRetrieve(ds, SQL_queryTkdInfoList_001, false);
            } else {
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                DBUtil.searchAndRetrieve(ds, SQL_queryTkdInfoList_002, false);
            }
            while (ds.next()) {
                Map TKD_INFO_MAP = VOTool.dataSetToMap(ds);
                //�Ȧ��ӷ�
                TKD_INFO_MAP.put("TMP_IN_NM", FieldOptionList.getName("EPC3", "TMP_IN_CD", MapUtils.getString(TKD_INFO_MAP, "TMP_IN_CD")));
                //�~�ȧO
                TKD_INFO_MAP.put("SYS_NM", FieldOptionList.getName("EPC3", "SYS_NO", MapUtils.getString(TKD_INFO_MAP, "SYS_NO")));
                //�R�b����
                TKD_INFO_MAP
                        .put("TMP_D_NM", FieldOptionList.getName("EPC3", "TMP_D_KIND", MapUtils.getString(TKD_INFO_MAP, "DTMP_D_KIND")));
                TKD_INFO_LIST.add(TKD_INFO_MAP);
            }
        } catch (ModuleException me) {
            throw new ModuleException(MessageUtil.getMessage("EP_C30023_MSG_002"));//���o�Ȧ��R�b���ӲM��o�Ϳ��~ 
        }
        return TKD_INFO_LIST;

    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }

        eie.appendMessage(errMsg);

        return eie;
    }
}
