package com.cathay.ep.i1.module;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.hr.Employee;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.z0.module.EP_Z0I100;
import com.cathay.ep.z0.module.EP_Z0I101;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.monitorjbl.xlsx.StreamingReader;

/**
 * <pre>
 * DATE       Description Author
 * 2016/11/14 Created     �_�ɪ�
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ���ո�Ƭd�ߺ��@�Ҳ�
 * �Ҳ�ID    EP_I10100
 * ���n����    ���ո�Ƭd�ߺ��@�Ҳ�
 * </pre>
 * @author ���t��
 * @since 2016/11/25
 * AllenTsai 2019/07/25 �Ȥ�y�ʪ��A�s���h���W�Ʒ|���p���I�A�վ��ƳB�z�覡�A�إߦ@�Τ�k�վ��ƳB�z���\�p���I��J�A �קK��l�ƻP�֥[�ϥΪ����A���@�P
 * [20200210]���D��(���D�渹:20200130114032)
 * 1.�ѪRExcel �վ�PMD �B�z(�ɮפ��i�W�L 10MB�BStreamingŪ��xlsx)
 * 2.processExcelData�A���n��getPhysicalNumberOfCells �קK���L�� ���������áA���getLastCellNum
 * AllenTsai 20200220 �վ�a�}, ��ΡB�����קK�a�}�վ㸹�X���~
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_I10100 {

    private static final String SQL_query_001 = "com.cathay.ep.i1.module.EP_I10100.SQL_query_001";

    /**
     * �d�ߥ��դH���M��
     * @param INV_DIV_NO ���թӿ���
     * @return memList  List<Map>   ���դH���M��
     * @throws SQLException
     */
    public List<Map> queryInvId(String INV_DIV_NO) throws SQLException {
        List<Map> memList = new ArrayList<Map>();
        if (StringUtils.isBlank(INV_DIV_NO)) {
            Map INV_DIV_NO_List = FieldOptionList.getName("EP", "I1_INV_DIV");
            for (Object key : INV_DIV_NO_List.keySet()) {
                Employee[] empList = new DivData().getOpDivMember(key.toString());
                for (Employee emp : empList) {
                    Map rtnMap = new HashMap();
                    rtnMap.put("EMP_ID", emp.getEmployeeId());
                    rtnMap.put("EMP_NAME", emp.getName());
                    memList.add(rtnMap);
                }
            }
        } else {
            Employee[] empList = new DivData().getOpDivMember(INV_DIV_NO);
            for (Employee emp : empList) {
                Map rtnMap = new HashMap();
                rtnMap.put("EMP_ID", emp.getEmployeeId());
                rtnMap.put("EMP_NAME", emp.getName());
                memList.add(rtnMap);
            }
        }
        return memList;

    }

    /**
     * �d�߰򥻸�� 
     *          �ѼƦW��   �榡         ����
     * @param   map      Map      
     * @return  rtnList  List<Map>  �򥻸�Ʃ���     
     * @throws ModuleException 
     * 
     */
    public List<Map> query(Map map) throws ModuleException {

        if (map == null || map.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_I10100_MSG_052"));//�򥻸�Ƹ�T���o����
        }
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(map, "SUB_CPY_ID");

        eie = checkStringParam(eie, SUB_CPY_ID, MessageUtil.getMessage("EP_I10100_MSG_053"));//�����q�O���o����
        if (eie != null) {
            throw eie;
        }

        String[] keys = new String[] { "SUB_CPY_ID", "INV_CD", "CITY_CD", "ZONE_CD", "OFC_CLS", "BLD_KD", "PRK_KD", "INV_DIV_NO", "INV_ID",
                "BLD_NAME" };

        DataSet ds = Transaction.getDataSet();
        for (String key : keys) {
            String Stringkey = MapUtils.getString(map, key);
            if (StringUtils.isNotEmpty(Stringkey)) {
                ds.setField(key, map.get(key));
            }
        }
        DBUtil.searchAndRetrieve(ds, SQL_query_001);
        BigDecimal HUNDRED = new BigDecimal("100");
        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map maps = VOTool.dataSetToMap(ds);
            String CITY_CD = MapUtils.getString(maps, "CITY_CD");
            String INV_DIV_NO = MapUtils.getString(maps, "INV_DIV_NO");
            String OFC_CLS = MapUtils.getString(maps, "OFC_CLS");
            String ZONE_CD = MapUtils.getString(maps, "ZONE_CD");
            String BLD_KD = MapUtils.getString(maps, "BLD_KD");//���c�y���� �ϥ�
            String PRK_KD = MapUtils.getString(maps, "PRK_KD");//�����쫬������ �ϥ�
            String INV_YR = MapUtils.getString(maps, "INV_YR");
            String INV_SN = MapUtils.getString(maps, "INV_SN");
            maps.put("CITY_CD_NM", FieldOptionList.getName("EP", "I1_CITY_CD", CITY_CD)); //��������
            maps.put("INV_DIV_NM", FieldOptionList.getName("EP", "I1_INV_DIV", INV_DIV_NO));//�ӿ��줤��          
            maps.put("OFC_CLS_NM", FieldOptionList.getName("EP", "I1_OFC_CLS", OFC_CLS));//�줽�Ǥ���         
            maps.put("ZONE_CD_NM", FieldOptionList.getName("EP", "I1_ZONE_CD_" + CITY_CD, ZONE_CD));//�ϰ줤��
            maps.put("BLD_KD_NM", FieldOptionList.getName("EP", "I1_BLD_KD", BLD_KD));//�c�y����  
            maps.put("PRK_KD_NM", FieldOptionList.getName("EP", "I1_PRK_KD", PRK_KD)); //���쫬������
            maps.put("LST_INV", INV_YR + FieldOptionList.getName("EP", "I1_INV_SN", INV_SN)); //�̪�@������
            BigDecimal EPT_SIZE = getBig(MapUtils.getObject(maps, "EPT_SIZE"));
            BigDecimal RNT_SIZE = getBig(MapUtils.getObject(maps, "RNT_SIZE"));
            BigDecimal EPT_RATE = EPT_SIZE.multiply(HUNDRED).divide(RNT_SIZE, 2, BigDecimal.ROUND_HALF_UP);
            maps.put("EPT_RATE", EPT_RATE);//�Ÿm�v
            rtnList.add(maps);
        }
        return rtnList;
    }

    /**
     * �פJ���
     * <pre>
     * @param reqMap{
     * UPL_DATA = ��ƺ���
     * UPL_FILE = �W���ɮ�
     * SUB_CPY_ID = �����q�O
     * }
     * </pre>
     * @param user
     * @throws Exception
     */
    public void upload(Map reqMap, UserObject user) throws Exception {
        //�ˮֶǤJ�Ѽ�:
        if (reqMap.get("UPL_FILE") == null) {
            throw new Exception(MessageUtil.getMessage("EP_I10100_MSG_001"));
            //��X���~�T��"�פJ�ɮפ��o���ŭ�!"
        }
        FileItem inputFile = (FileItem) reqMap.get("UPL_FILE");
        //[20200210]�W�[�ɮפj�p�ˮ�
        if (inputFile.getSize() > 5 * 1024 * 1024) {//5mb
            throw new ErrorInputException("�W���ɮפj�p�W�L5MB�A�L�k����W�ǧ@�~");
        }
        //���o�ɮפ��e���List<String[]> dataList
        List<String[]> dataList = this.parseInputFile(inputFile);
        //���o�w�s�bDTEPI100�򥻸��
        //���P�����ϰ�W�١B�j�ӦW�٥i�୫��
        List<Map> rtnList;
        try {
            rtnList = new EP_Z0I100().queryDTEPI100(reqMap); //�d�L��Ƶ������`
        } catch (DataNotFoundException dnfe) {
            rtnList = Collections.EMPTY_LIST;
        }
        MultiKeyMap MultiKeyMap = new MultiKeyMap();
        MultiKeyMap MultiKeyMap2 = new MultiKeyMap();
        for (Map map : rtnList) {
            //�����q�O�B��������B�ϰ줤��B�j�Ӥ���B�j�ӥN��
            MultiKeyMap.put(MapUtils.getString(map, "SUB_CPY_ID"), MapUtils.getString(map, "CITY_CD_NM"),
                MapUtils.getString(map, "ZONE_CD_NM"), MapUtils.getString(map, "BLD_NAME"), MapUtils.getString(map, "INV_CD"));
            //�����q�O�B�j�ӥN���B�����N��
            MultiKeyMap2.put(MapUtils.getString(map, "SUB_CPY_ID"), MapUtils.getString(map, "INV_CD"), MapUtils.getString(map, "CITY_CD"));
        }
        //���թӿ���@��P�G�쪺���սd��A�H���ܹ���(�@��G�򶩡B�x�_�B�s�_�B���B�s�ˡB�]�ߡF��l���G��d��)
        Map<String, Object> CITY_SCOPE_Map = FieldOptionList.getName("EP", "I1_CITY_SCOPE_" + user.getDivNo().substring(0, 5));
        //���o�����O�N�X
        Map<String, Object> CITY_CD_Map = FieldOptionList.getName("EP", "I1_CITY_CD");
        if ("1".equals(MapUtils.getString(reqMap, "UPL_DATA"))) { //�򥻸�� 
            //���o�����N�X,�ϰ줤��, �ϰ�N�X
            MultiKeyMap MultiKeyMap1 = new MultiKeyMap();
            //�����M��
            for (String str : CITY_CD_Map.keySet()) {
                Map<String, Object> ZONE_CD_Map = FieldOptionList.getName("EP", "I1_ZONE_CD_" + str);
                for (String key : ZONE_CD_Map.keySet()) {
                    //�����N���B�ϰ줤��B�ϰ�N��
                    MultiKeyMap1.put(str, MapUtils.getString(ZONE_CD_Map, key), key);
                }
            }
            //���o�줽�Ǥ��ťN�X
            Map<String, Object> OFC_CLS_Map = FieldOptionList.getName("EP", "I1_OFC_CLS");
            //���o�c�y�N�X
            Map<String, Object> BLD_KD_Map = FieldOptionList.getName("EP", "I1_BLD_KD");
            //���o���쫬���N�X
            Map<String, Object> PRK_KD_Map = FieldOptionList.getName("EP", "I1_PRK_KD");
            int j = 0;
            StringBuilder errMsg = new StringBuilder();
            List<Map> insertList = new ArrayList<Map>();
            List<Map> updateList = new ArrayList<Map>();
            List<Map> INV_ID_List = this.queryInvId(user.getDivNo());
            Map<String, Object> INV_DIV_NO_Map = FieldOptionList.getName("EP", "I1_INV_DIV");
            for (String[] fields : dataList) {
                j++; //���ܲĴX�����
                //�Ĥ@�欰���Y�A�����~��B�z�U�@��
                if (j == 1) {
                    continue;
                }
                Map data = new HashMap();
                data.put("BLD_NAME", this.doReplace(fields[2])); //�h���ťաB����Ÿ��B�d����
                data.put("ZONE_CD_NM", this.doReplace(fields[1]));
                data.put("UP_FLR", this.doReplace(fields[3]));
                data.put("DWN_FLR", this.doReplace(fields[4]));
                data.put("BLD_SIZE", this.doReplace(fields[5]));
                data.put("BLD_END_DATE", this.getDate(this.doReplace(fields[6])));
                data.put("OFC_CLS_NM", this.doReplace(fields[7]));
                //���o�줽�Ǥ��ťN�X
                for (String key : OFC_CLS_Map.keySet()) {
                    if (MapUtils.getString(OFC_CLS_Map, key, "").equals(MapUtils.getString(data, "OFC_CLS_NM"))) {
                        data.put("OFC_CLS", key);
                        break;
                    }
                }
                if (StringUtils.isBlank(MapUtils.getString(data, "OFC_CLS"))) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_002", new Object[] { j, MapUtils.getString(data, "OFC_CLS_NM") }));
                    //��{0}���d�L�줽�Ǥ���{1}�N�X�A�нT�{��ƬO�_���T?
                }
                data.put("BLD_KD_NM", this.doReplace(fields[8]));//�h���ťաB����Ÿ��B�d����
                //���o�c�y�N�X
                for (String key : BLD_KD_Map.keySet()) {
                    if (MapUtils.getString(BLD_KD_Map, key, "").equals(MapUtils.getString(data, "BLD_KD_NM"))) {
                        data.put("BLD_KD", key);
                        break;
                    }
                }
                if (StringUtils.isBlank(MapUtils.getString(data, "BLD_KD"))) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_003", new Object[] { j, MapUtils.getString(data, "BLD_KD_NM") }));
                    //��{0}���d�L�c�y{1}�N�X�A�нT�{��ƬO�_���T?
                }
                String CITY_CD_NM = this.doReplace(fields[0]); //�h���ťաB����Ÿ��B�d����
                //���o�����N�X
                for (String key : CITY_CD_Map.keySet()) {
                    if (MapUtils.getString(CITY_CD_Map, key, "").equals(CITY_CD_NM)) {
                        data.put("CITY_CD", key);
                        break;
                    }
                }
                if (StringUtils.isBlank(MapUtils.getString(data, "CITY_CD"))) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_050", new Object[] { j, MapUtils.getString(data, "CITY_CD") }));
                    //��{0}���d�L����{1}�N�X�A�нT�{��ƬO�_���T?
                }
                String ADDR_ZIP = this.doReplace(fields[9]); //�h���ťաB����Ÿ��B�d����
                if (ADDR_ZIP.length() < 3 || StringUtils.isBlank(ADDR_ZIP)) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_004", new Object[] { j, ADDR_ZIP })).append(STRING.lineSeparator);
                    //��{0}���l���ϸ�����{1}���~
                }
                data.put("ADDR_ZIP", ADDR_ZIP.substring(0, 3));
                data.put("CITY_CD_NM", CITY_CD_NM);
                Boolean isINV_SCOPE = true;
                for (String key : CITY_SCOPE_Map.keySet()) {
                    if (MapUtils.getString(CITY_SCOPE_Map, key).equals(MapUtils.getString(data, "CITY_CD_NM"))) {
                        isINV_SCOPE = false;
                        break;
                    }
                }
                if (isINV_SCOPE) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_005", new Object[] { j, MapUtils.getString(data, "CITY_CD_NM") }))
                            .append(STRING.lineSeparator);
                    //��{0}������{1}�D�W�ǤH�����թӿ�d��
                }
                //�ο����N���B�ϰ줤����o�ϰ�N��
                if (MultiKeyMap1.containsKey(MapUtils.getString(data, "CITY_CD"), MapUtils.getString(data, "ZONE_CD_NM"))) {
                    Object ZONE_CD = MultiKeyMap1.get(MapUtils.getString(data, "CITY_CD"), MapUtils.getString(data, "ZONE_CD_NM"));
                    data.put("ZONE_CD", ZONE_CD);
                } else {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_006", new Object[] { j, MapUtils.getString(data, "ZONE_CD_NM") }))
                            .append(STRING.lineSeparator);
                    //��{0}���d�L���հϰ�"{1}�N�X�A�нT�{��ƬO�_���T?�Y���s�W�ϰ�A�Ь���A
                }
                data.put("ADDR", this.doReplace(fields[10])); //�h���ťաB����Ÿ��B�d����
                data.put("RNT_SIZE", this.doReplace(fields[11])); //�h���ťաB����Ÿ��B�d����
                data.put("OFC_RNT_SIZE", this.doReplace(fields[12])); //�h���ťաB����Ÿ��B�d����
                data.put("SHOP_RNT_SIZE", this.doReplace(fields[13])); //�h���ťաB����Ÿ��B�d����
                data.put("RNT_PRK", this.doReplace(fields[14])); //�h���ťաB����Ÿ��B�d����
                data.put("PRK_KD_NM", this.doReplace(fields[15])); //�h���ťաB����Ÿ��B�d����
                //���o���쫬���N�X
                if (StringUtils.isNotBlank(MapUtils.getString(data, "PRK_KD_NM"))) {
                    data.put("PRK_KD", "");
                    for (String key : PRK_KD_Map.keySet()) {
                        if (MapUtils.getString(PRK_KD_Map, key, "").equals(MapUtils.getString(data, "PRK_KD_NM"))) {
                            data.put("PRK_KD", key);
                            break;
                        }
                    }
                    if (MapUtils.getString(data, "PRK_KD").equals("")) {
                        errMsg.append(
                            MessageUtil.getMessage("EP_I10100_MSG_007", new Object[] { j, MapUtils.getString(data, "PRK_KD_NM") }))
                                .append(STRING.lineSeparator);
                        //��{0}���d�L���쫬��{1}�N�X�A�нT�{��ƬO�_���T?
                    }
                }

                data.put("INV_DIV_NO", this.doReplace(fields[16])); //�h���ťաB����Ÿ��B�d����
                //�ˮ֩ӿ���N�X

                if (!INV_DIV_NO_Map.keySet().contains(MapUtils.getString(data, "INV_DIV_NO"))) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_011", new Object[] { j, MapUtils.getString(data, "INV_DIV_NO") }))
                            .append(STRING.lineSeparator);
                    //"��{0}���ӿ���N��{1}���~�A�нT�{/n"
                }
                //�ˮ�excel�ӿ���N�X��������user.getDivNo()
                if (!user.getDivNo().equals(MapUtils.getString(data, "INV_DIV_NO"))) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_051",
                        new Object[] { j, MapUtils.getString(data, "INV_DIV_NO"), user.getDivNo() })).append(STRING.lineSeparator);
                }
                data.put("INV_NAME", this.doReplace(fields[17])); //�h���ťաB����Ÿ��B�d����
                boolean isINV_ID = true; //���դH��
                for (Map map : INV_ID_List) {
                    //if data.INV_NAME���s�bINV_ID_List[i].EMP_NAME
                    if (MapUtils.getString(data, "INV_NAME", "").equals(MapUtils.getString(map, "EMP_NAME"))) {
                        isINV_ID = false;
                        data.put("INV_ID", MapUtils.getString(map, "EMP_ID")); //��INV_ID�Jdata
                        break;
                    }
                }
                if (isINV_ID) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_012", new Object[] { j, MapUtils.getString(data, "INV_NAME") }))
                            .append(STRING.lineSeparator); //��{0}�����դH������{1}���~�A�нT�{
                }

                data.put("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
                String errCheck = this.checkData1(data);
                if (StringUtils.isNotBlank(errCheck)) {
                    //��Ʈ榡�B�����ˮ�
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_008", new Object[] { j, errCheck }));
                    //��{0}��{1}
                    continue;
                }
                if (MultiKeyMap.containsKey(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "CITY_CD_NM"),
                    MapUtils.getString(data, "ZONE_CD_NM"), MapUtils.getString(data, "BLD_NAME"))) {
                    //��s
                    data.put("INV_CD", MultiKeyMap.get(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "CITY_CD_NM"),
                        MapUtils.getString(data, "ZONE_CD_NM"), MapUtils.getString(data, "BLD_NAME")));
                    updateList.add(data);
                } else {
                    //�s�W
                    insertList.add(data);
                }
            }
            if (StringUtils.isBlank(errMsg.toString())) {
                EP_Z0I100 EP_Z0I100 = new EP_Z0I100();
                for (Map data : insertList) {
                    EP_Z0I100.insertDTEPI100(data, user);
                }
                for (Map data : updateList) {
                    EP_Z0I100.updateDTEPI100(data, user);
                }
            } else {
                throw new ModuleException(errMsg.toString());
            }
        } else if (MapUtils.getString(reqMap, "UPL_DATA").equals("2")) {
            //���o�w�s�bDTEPI101���ո��
            EP_Z0I101 EP_Z0I101 = new EP_Z0I101();
            List<Map> rtnList2;
            try {
                rtnList2 = EP_Z0I101.queryDTEPI101(reqMap); //�d�L��Ƶ������` 
            } catch (DataNotFoundException dnfe) {
                rtnList2 = Collections.EMPTY_LIST;
            }
            MultiKeyMap MultiKeyMap101 = new MultiKeyMap();
            for (Map map : rtnList2) {
                //�����q�O�B�~�B�u�B���դj�ӥN��
                MultiKeyMap101.put(MapUtils.getString(map, "SUB_CPY_ID"), MapUtils.getString(map, "INV_YR"),
                    MapUtils.getString(map, "INV_SN"), MapUtils.getString(map, "INV_CD"), null);
            }
            //�ӿ���M��
            Map<String, Object> INV_DIV_NO_Map = FieldOptionList.getName("EP", "I1_INV_DIV");
            //���դH���M��
            List<Map> INV_ID_List = this.queryInvId(user.getDivNo());
            int j = 0;
            String INV_YR = "", tempINV_SN, INV_SN = "", CITY_CD_NM = "", ZONE_CD_NM = "", BLD_NAME = "";
            StringBuilder errMsg = new StringBuilder();
            List<Map> insertList = new ArrayList<Map>();
            List<Map> updateList = new ArrayList<Map>();
            Map data = new HashMap();
            for (String[] fields : dataList) {
                j++; //���ܲĴX�����
                if (j == 1) {
                    //�Ĥ@��Ĥ@��: 105-Q1���ո��
                    INV_YR = fields[0] == null ? null : fields[0].substring(0, 3);
                    tempINV_SN = fields[0] == null ? null : fields[0].substring(4, 6);
                    if ("Q1".equals(tempINV_SN)) {
                        INV_SN = "1";
                    } else if ("Q2".equals(tempINV_SN)) {
                        INV_SN = "2";
                    } else if ("Q3".equals(tempINV_SN)) {
                        INV_SN = "3";
                    } else if ("Q4".equals(tempINV_SN)) {
                        INV_SN = "4";
                    }
                    continue;
                }
                //�ĤG��ĤT�欰���Y�A�����~��B�z�U�@��
                if (j == 2 || j == 3) {
                    continue;
                }
                data = new HashMap();
                data.put("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
                data.put("INV_YR", INV_YR);
                data.put("INV_SN", INV_SN);

                //�j�Ӥ���
                BLD_NAME = this.doReplace(fields[2]); //�h���ťաB����Ÿ��B�d����
                if (BLD_NAME.contains(MessageUtil.getMessage("EP_I10100_MSG_009"))) { //"�p�p"
                    //�Ӧ橿���~��B�z�U�@��
                    continue;
                }
                data.put("BLD_NAME", BLD_NAME);

                //��������
                String tempCITY_CD_NM = this.doReplace(fields[0]); //�h���ťաB����Ÿ��B�d����
                if (StringUtils.isNotBlank(tempCITY_CD_NM)) {
                    CITY_CD_NM = tempCITY_CD_NM;
                }
                data.put("CITY_CD_NM", CITY_CD_NM);

                //�ϰ줤��
                String tempZONE_CD_NM = fields[1].replaceAll("\\s|\t|\r|\n|\\,", "");//�h���ťաB����Ÿ��B�d����
                if (StringUtils.isNotBlank(tempZONE_CD_NM)) {
                    ZONE_CD_NM = tempZONE_CD_NM;//��sZONE_CD_NM
                }
                data.put("ZONE_CD_NM", ZONE_CD_NM);

                //���o���դj�ӥN���A�Y�L��ƪ��ܵL�򥻸�ơA���i�פJ
                if (MultiKeyMap.containsKey(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "CITY_CD_NM"),
                    MapUtils.getString(data, "ZONE_CD_NM"), MapUtils.getString(data, "BLD_NAME"))) {
                    data.put("INV_CD", MultiKeyMap.get(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "CITY_CD_NM"),
                        MapUtils.getString(data, "ZONE_CD_NM"), MapUtils.getString(data, "BLD_NAME")));
                } else {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_010",
                        new Object[] { j, MapUtils.getString(data, "ZONE_CD_NM"), MapUtils.getString(data, "BLD_NAME") }))
                            .append(STRING.lineSeparator);
                    //��{0}���d�L���հϰ�{1}�j�ӦW��{2}�򥻸�ơA�Х��s�W�򥻸�ƫ�A�s�W���ո��
                }
                data.put("EPT_SIZE", this.doReplace(fields[5])); //�h���ťաB����Ÿ��B�d����
                data.put("OFFER_AMT", this.doReplace(fields[7]));
                data.put("BASE_AMT", this.doReplace(fields[8]));
                data.put("RNT_PRK_AMT", this.doReplace(fields[13]));
                data.put("EXP_AMT", this.doReplace(fields[14]));
                data.put("SHOP_OFFER_AMT", this.doReplace(fields[15]));
                data.put("SHOP_BASE_AMT", this.doReplace(fields[16]));
                data.put("INV_DIV_NO", this.doReplace(fields[17]));
                //�ˮ֩ӿ���N�X
                if (!INV_DIV_NO_Map.keySet().contains(MapUtils.getString(data, "INV_DIV_NO"))) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_011", new Object[] { j, MapUtils.getString(data, "INV_DIV_NO") }))
                            .append(STRING.lineSeparator);
                    //"��{0}���ӿ���N��{1}���~�A�нT�{/n"
                }
                //�ˮ�excel�ӿ���N�X��������user.getDivNo()
                if (!user.getDivNo().equals(MapUtils.getString(data, "INV_DIV_NO"))) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_051",
                        new Object[] { j, MapUtils.getString(data, "INV_DIV_NO"), user.getDivNo() })).append(STRING.lineSeparator);
                }
                data.put("INV_NAME", this.doReplace(fields[18])); //�h���ťաB����Ÿ��B�d����
                boolean isINV_ID = true; //���դH��
                for (Map map : INV_ID_List) {
                    //if data.INV_NAME���s�bINV_ID_List[i].EMP_NAME
                    if (MapUtils.getString(data, "INV_NAME").equals(MapUtils.getString(map, "EMP_NAME"))) {
                        isINV_ID = false;
                        data.put("INV_ID", MapUtils.getString(map, "EMP_ID")); //��INV_ID�Jdata
                        break;
                    }
                }
                if (isINV_ID) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_012", new Object[] { j, MapUtils.getString(data, "INV_NAME") }))
                            .append(STRING.lineSeparator); //��{0}�����դH������{1}���~�A�нT�{
                }
                //���o�����N��
                String CITY_CD = "";
                if (MultiKeyMap2.containsKey(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "INV_CD"))) {
                    CITY_CD = MultiKeyMap2.get(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "INV_CD")).toString();
                }

                if (!CITY_SCOPE_Map.keySet().contains(CITY_CD)) {
                    errMsg.append(
                        MessageUtil.getMessage("EP_I10100_MSG_013", new Object[] { j, MapUtils.getString(data, "CITY_CD_NM") + CITY_CD }))
                            .append(STRING.lineSeparator);
                    //��{0}������{1}�D�W�ǤH�����թӿ�d��
                }
                //����ˮ�
                String errCheck = this.checkData2(data);
                if (StringUtils.isNotBlank(errCheck)) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_008", new Object[] { j, errCheck }));
                    //��{0}��{1}
                    continue;
                }
                if (MultiKeyMap101.containsKey(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "INV_YR"),
                    MapUtils.getString(data, "INV_SN"), MapUtils.getString(data, "INV_CD"))) {
                    //��s
                    updateList.add(data);
                } else {
                    //�s�W
                    insertList.add(data);

                }
            }
            if (StringUtils.isBlank(errMsg.toString())) {
                for (Map map : insertList) {
                    EP_Z0I101.insertDTEPI101(map, user);
                }
                for (Map map : updateList) {
                    EP_Z0I101.updateDTEPI101(map, user);
                }
            } else {
                throw new ModuleException(errMsg.toString());
            }
        } else if ("3".equals(MapUtils.getString(reqMap, "UPL_DATA"))) { //�Ȥ�y�ʪ�
            EP_Z0I101 EP_Z0I101 = new EP_Z0I101();
            //���o�w�s�bDTEPI101���ո��
            List<Map> rtnList3;
            try {
                rtnList3 = EP_Z0I101.queryDTEPI101(reqMap);//�d�L��Ƶ������` 
            } catch (DataNotFoundException dnfe) {
                rtnList3 = Collections.EMPTY_LIST;
            }
            MultiKeyMap MultiKeyMap101 = new MultiKeyMap();
            for (Map map : rtnList3) {
                MultiKeyMap101.put(MapUtils.getString(map, "SUB_CPY_ID"), MapUtils.getString(map, "INV_YR"),
                    MapUtils.getString(map, "INV_SN"), MapUtils.getString(map, "INV_CD"), null);
            }
            int j = 0;
            String INV_YR = "", tempINV_SN, INV_SN = "", CITY_CD_NM = "", ZONE_CD_NM = "", BLD_NAME = "", MEMO = "", RDC_RNT_SIZE = "0",
                    ADD_RNT_SIZE = "0";
            StringBuilder tempCUST_OUT = new StringBuilder();
            StringBuilder tempCUST_IN = new StringBuilder();
            StringBuilder tempMEMO = new StringBuilder();
            StringBuilder errMsg = new StringBuilder();
            Map data;
            List<Map> updateList = new ArrayList<Map>();
            for (String[] fields : dataList) {
                j++; //���ܲĴX�����
                if (j == 1) {
                    //�Ĥ@��Ĥ@��: 105-Q1���ո��
                    INV_YR = fields[0] == null ? null : fields[0].substring(0, 3);
                    tempINV_SN = fields[0] == null ? null : fields[0].substring(4, 6);
                    if ("Q1".equals(tempINV_SN)) {
                        INV_SN = "1";
                    } else if ("Q2".equals(tempINV_SN)) {
                        INV_SN = "2";
                    } else if ("Q3".equals(tempINV_SN)) {
                        INV_SN = "3";
                    } else if ("Q4".equals(tempINV_SN)) {
                        INV_SN = "4";
                    }
                    continue;
                }
                //�ĤG�欰���Y�A�����~��B�z�U�@��
                if (j == 2) {
                    continue;
                }
                CITY_CD_NM = this.doReplace(fields[0]);//�h���ťաB����Ÿ��B�d����
                if (CITY_CD_NM.contains(MessageUtil.getMessage("EP_I10100_MSG_009"))) {
                    //��1���Ƨt                                                                                                            //�p�p
                    continue;//�Ӧ橿���~��B�z�U�@��};
                }
                ZONE_CD_NM = fields[1] == null ? "" : this.doReplace(fields[1]);//�h���ťաB����Ÿ��B�d����
                BLD_NAME = fields[2] == null ? "" : this.doReplace(fields[2]);//�h���ťաB����Ÿ��B�d����
                RDC_RNT_SIZE = fields[4] == null ? "0" : this.doReplace(fields[4]);//�h���ťաB����Ÿ��B�d����
                ADD_RNT_SIZE = fields[5] == null ? "0" : this.doReplace(fields[5]);//�h���ťաB����Ÿ��B�d����
                MEMO = this.doReplace(fields[6]);//�h���ťաB����Ÿ��B�d����
                if (BLD_NAME.equals("")) {
                    data = updateList.get(updateList.size() - 1);
                    if (!"0".equals(ADD_RNT_SIZE)) {
                        //data.put("ADD_RNT_SIZE", Double.parseDouble(ADD_RNT_SIZE) + (Double) data.get("ADD_RNT_SIZE"));
                        setAddRtnRentSize(ADD_RNT_SIZE, data, "ADD_RNT_SIZE");
                        if (StringUtils.isNotBlank(MapUtils.getString(data, "CUST_IN")) && tempCUST_IN.length() > 0) {
                            tempCUST_IN.setLength(tempCUST_IN.length() - 1);
                            tempCUST_IN.append(",");
                        } else {
                            tempCUST_IN.setLength(0);
                            tempCUST_IN.append(MapUtils.getString(data, "BLD_NAME")).append(":").append("(");
                        }
                        tempCUST_IN.append(this.doReplace(fields[3])).append(":").append(ADD_RNT_SIZE)
                                .append(MessageUtil.getMessage("EP_I10100_MSG_015"));
                        data.put("CUST_IN", tempCUST_IN.toString());
                    }
                    if (!"0".equals(RDC_RNT_SIZE)) {
                        //data.put("RDC_RNT_SIZE", Double.parseDouble(RDC_RNT_SIZE) + (Double) data.get("RDC_RNT_SIZE"));
                        setAddRtnRentSize(RDC_RNT_SIZE, data, "RDC_RNT_SIZE");
                        if (StringUtils.isNotBlank(MapUtils.getString(data, "CUST_OUT")) && tempCUST_OUT.length() > 0) {
                            tempCUST_OUT.setLength(tempCUST_OUT.length() - 1);
                            tempCUST_OUT.append(",");
                        } else {
                            tempCUST_OUT.setLength(0);
                            tempCUST_OUT.append(MapUtils.getString(data, "BLD_NAME")).append(":").append("(");
                        }
                        tempCUST_OUT.append(this.doReplace(fields[3])).append(":").append(RDC_RNT_SIZE)
                                .append(MessageUtil.getMessage("EP_I10100_MSG_015"));
                        data.put("CUST_OUT", tempCUST_OUT.toString());
                    }
                    //20170428 ���ʲ��ޤG��-�G��͡G�פJ��ƫ�A��Ȥ���s���Ƶ���վ㦨�t�ΤW�Ƶ��椺����r�PEXCEL�Ƶ��椺��r�ۦP
                    //EX:�j��:���F���� �Ȥ��d:3F-1_���v�y�����ֹD�ݱоǤ��� �Ƶ�:�L�A�Ƶ���(��):���F����(3F-1_���v�y�����ֹD�ݱоǤ���:�L) �אּ �Ƶ���(�s):�L
                    /*if (StringUtils.isNotBlank(MEMO)) {
                        if (StringUtils.isNotBlank(MapUtils.getString(data, "MEMO")) && tempMEMO.length() > 0) {
                            tempMEMO.setLength(tempMEMO.length() - 1);
                            tempMEMO.append(",");
                        } else {
                            tempMEMO.setLength(0);
                            tempMEMO.append(MapUtils.getString(data, "MEMO")).append(":").append("(");
                        }
                        tempMEMO.append(this.doReplace(fields[3])).append(":").append(MEMO).append(")");
                        data.put("MEMO", tempMEMO.toString());
                    }*/
                    if (StringUtils.isNotBlank(MEMO)) {
                        if (StringUtils.isNotBlank(MapUtils.getString(data, "MEMO")) && tempMEMO.length() > 0) {
                            tempMEMO.append(",");
                        } else {
                            tempMEMO.setLength(0);
                            tempMEMO.append(MapUtils.getString(data, "MEMO"));
                        }
                        tempMEMO.append(MEMO);
                        data.put("MEMO", tempMEMO.toString());
                    }
                } else {
                    data = new HashMap();
                    data.put("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
                    data.put("INV_YR", INV_YR);
                    data.put("INV_SN", INV_SN);
                    data.put("CITY_CD_NM", CITY_CD_NM);
                    data.put("ZONE_CD_NM", ZONE_CD_NM);
                    data.put("BLD_NAME", BLD_NAME);
                    //data.put("MEMO", MEMO);                    
                    //data.put("ADD_RNT_SIZE", Double.parseDouble(ADD_RNT_SIZE));
                    setAddRtnRentSize(ADD_RNT_SIZE, data, "ADD_RNT_SIZE");

                    //data.put("RDC_RNT_SIZE", Double.parseDouble(RDC_RNT_SIZE));
                    setAddRtnRentSize(RDC_RNT_SIZE, data, "RDC_RNT_SIZE");

                    tempCUST_IN.setLength(0);
                    if (!"0".equals(ADD_RNT_SIZE)) {
                        tempCUST_IN.append(BLD_NAME).append("(").append(fields[3].replaceAll("\\s|\t|\r|\n|\\,", "")).append(":")
                                .append(ADD_RNT_SIZE).append(MessageUtil.getMessage("EP_I10100_MSG_015"));
                        data.put("CUST_IN", tempCUST_IN.toString());
                    } else {
                        data.put("CUST_IN", "");
                    }
                    tempCUST_OUT.setLength(0);
                    if (!"0".equals(RDC_RNT_SIZE)) {
                        tempCUST_OUT.append(BLD_NAME).append("(").append(this.doReplace(fields[3])).append(":").append(RDC_RNT_SIZE)
                                .append(MessageUtil.getMessage("EP_I10100_MSG_015"));
                        data.put("CUST_OUT", tempCUST_OUT.toString());
                    } else {
                        data.put("CUST_OUT", "");
                    }
                    tempMEMO.setLength(0);
                    /*if (StringUtils.isNotBlank(MEMO)) {
                        tempMEMO.append(BLD_NAME).append("(").append(this.doReplace(fields[3])).append(":").append(MEMO).append(")");
                        data.put("MEMO", tempMEMO.toString());
                    } else {
                        data.put("MEMO", "");
                    }*/
                    //20170428 ���ʲ��ޤG��-�G��͡G�פJ��ƫ�A��Ȥ���s���Ƶ���վ㦨�t�ΤW�Ƶ��椺����r�PEXCEL�Ƶ��椺��r�ۦP
                    //EX:�j��:���F���� �Ȥ��d:3F-1_���v�y�����ֹD�ݱоǤ��� �Ƶ�:�L�A�Ƶ���(��):���F����(3F-1_���v�y�����ֹD�ݱоǤ���:�L) �אּ �Ƶ���(�s):�L
                    if (StringUtils.isNotBlank(MEMO)) {
                        tempMEMO.append(MEMO);
                        data.put("MEMO", tempMEMO.toString());
                    } else {
                        data.put("MEMO", "");
                    }
                    if (MultiKeyMap.containsKey(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "CITY_CD_NM"),
                        MapUtils.getString(data, "ZONE_CD_NM"), MapUtils.getString(data, "BLD_NAME"))) {
                        data.put("INV_CD", MultiKeyMap.get(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "CITY_CD_NM"),
                            MapUtils.getString(data, "ZONE_CD_NM"), MapUtils.getString(data, "BLD_NAME")));
                    } else {
                        errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_010",
                            new Object[] { j, MapUtils.getString(data, "ZONE_CD_NM"), MapUtils.getString(data, "BLD_NAME") }))
                                .append(STRING.lineSeparator);
                        //��{0}���d�L���հϰ�{1}�j�ӦW��{2}�򥻸�ơA�Х��s�W�򥻸�ƫ�A�s�W���ո��
                    }
                    if (!MultiKeyMap101.containsKey(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "INV_YR"),
                        MapUtils.getString(data, "INV_SN"), MapUtils.getString(data, "INV_CD"))) {
                        errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_016",
                            new Object[] { j, MapUtils.getString(data, "ZONE_CD_NM"), MapUtils.getString(data, "BLD_NAME") }))
                                .append(STRING.lineSeparator);
                        //��{0}���d�L���հϰ�{1}�j�ӦW��{2}���ո�ơA�Х��s�W�өu���ո�ƫ�A�פJ�Ȥ�y�ʪ�
                    } else {
                        //���o�����N��
                        String CITY_CD = "";
                        if (MultiKeyMap2.containsKey(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "INV_CD"))) {
                            CITY_CD = MultiKeyMap2.get(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(data, "INV_CD"))
                                    .toString();
                        }
                        if (!CITY_SCOPE_Map.keySet().contains(CITY_CD)) {
                            errMsg.append(
                                MessageUtil.getMessage("EP_I10100_MSG_013", new Object[] { j, MapUtils.getString(data, "CITY_CD_NM") }))
                                    .append(STRING.lineSeparator);
                            //��{0}������{1}�D�W�ǤH�����թӿ�d��
                        }
                        //����ˮ�
                        String errStr = this.checkData3(data);
                        if (StringUtils.isNotBlank(errStr)) {
                            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_008", new Object[] { j, errStr }));
                        }
                    }
                    //��{0}��{1}
                    updateList.add(data);
                }
            }
            if (StringUtils.isBlank(errMsg.toString())) {
                for (Map map : updateList) {
                    EP_Z0I101.updateDTEPI101ByCust(map, user);
                }
            } else {
                throw new ModuleException(errMsg.toString());
            }
        }
    }

    //20190725 ��ƳB�z�վ㤹�\�p���I��J�A�إߦ@�Τ�k �קK��l�ƻP�֥[�ϥΪ����A���@�P
    private void setAddRtnRentSize(String ADD_RNT_SIZE, Map data, String mapKey) {
        BigDecimal sumValue = (BigDecimal) data.get(mapKey);
        if (sumValue == null) {
            sumValue = BigDecimal.ZERO;
        }
        sumValue = sumValue.add(new BigDecimal(ADD_RNT_SIZE).setScale(2, BigDecimal.ROUND_HALF_UP));
        data.put(mapKey, sumValue);
    }

    /**
     * �ˮְ򥻸�ƶפJ���
     * @param upMap �򥻸��
     * @return errMsg String �ˮֿ��~�T��
     * @throws ErrorInputException 
     */
    @SuppressWarnings("deprecation")
    public String checkData1(Map upMap) throws ErrorInputException {
        if (upMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_I10100_MSG_014")); //�ǤJdata���o����
        }
        StringBuilder errMsg = new StringBuilder();

        String CITY_CD = MapUtils.getString(upMap, "CITY_CD");
        if (StringUtils.isEmpty(CITY_CD) || CITY_CD.length() != 3) {

            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_017")).append(CITY_CD).append(STRING.lineSeparator);
            //�����O�N���ݬ�3�X
        }
        String ZONE_CD = MapUtils.getString(upMap, "ZONE_CD");
        if (StringUtils.isEmpty(ZONE_CD) || ZONE_CD.length() != 3) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_018")).append(ZONE_CD).append(STRING.lineSeparator);
            //�ϰ�N���ݬ�3�X
        }

        String BLD_NAME = MapUtils.getString(upMap, "BLD_NAME");
        //����B���׻ݤp��15�Ӥ���
        if (StringUtils.isEmpty(BLD_NAME) || STRING.doubleByteLength(BLD_NAME) > 30) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_019")).append(BLD_NAME).append(STRING.lineSeparator);
            //�j�ӦW�٪��׶W�L15����
        }
        String ADDR_ZIP = MapUtils.getString(upMap, "ADDR_ZIP");
        if (StringUtils.isEmpty(ADDR_ZIP) || (ADDR_ZIP.length() != 5 && ADDR_ZIP.length() != 3)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_020")).append(ADDR_ZIP).append(STRING.lineSeparator);
            //�l���ϸ��ݬ�3���5��
        }
        String ADDR = MapUtils.getString(upMap, "ADDR");
        //����B���׻ݤp��100�Ӥ���
        if (StringUtils.isEmpty(ADDR) || STRING.doubleByteLength(ADDR) > 200) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_021")).append(ADDR).append(STRING.lineSeparator);
            //�a�}���׶W�L100�Ӥ���
        }
        String OFC_CLS = MapUtils.getString(upMap, "OFC_CLS");
        if (StringUtils.isEmpty(OFC_CLS) || OFC_CLS.length() != 1) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_022")).append(OFC_CLS).append(STRING.lineSeparator);
            //�줽�Ǥ��ťN���ݬ�1��
        }
        String UP_FLR = MapUtils.getString(upMap, "UP_FLR");
        if (StringUtils.isEmpty(UP_FLR) || Integer.parseInt(UP_FLR) < 1 || Integer.parseInt(UP_FLR) > 999) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_023")).append(UP_FLR).append(STRING.lineSeparator);
            //�a�W�h�ݬ�1~999�ƭ�
        }
        String DWN_FLR = MapUtils.getString(upMap, "DWN_FLR");
        if (StringUtils.isEmpty(DWN_FLR) || Integer.parseInt(DWN_FLR) < 0 || Integer.parseInt(DWN_FLR) > 999) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_024")).append(DWN_FLR).append(STRING.lineSeparator);
            //�a�U�h�ݬ�0~999�ƭ�
        }
        String[] temp;
        String BLD_SIZE = MapUtils.getString(upMap, "BLD_SIZE");
        if (StringUtils.isEmpty(BLD_SIZE)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_025")).append(BLD_SIZE).append(STRING.lineSeparator);
            //��a���n��Ʀ��<=5��B�p�Ʀ���׻�<=2��
        } else if (BLD_SIZE.contains(".")) {
            temp = BLD_SIZE.split("\\.");
            if (temp[0].length() > 5 || temp[1].length() > 2) {
                errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_025")).append(BLD_SIZE).append(STRING.lineSeparator);
                //��a���n��Ʀ��<=5��B�p�Ʀ���׻�<=2��
            }

        } else if (BLD_SIZE.length() > 5) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_025")).append(BLD_SIZE).append(STRING.lineSeparator);
            //��a���n��Ʀ��<=5��B�p�Ʀ���׻�<=2��
        }

        //upMap.BLD_END_DATE����B�ݬ����T�褸���~�榡
        String BLD_END_DATE = MapUtils.getString(upMap, "BLD_END_DATE");
        if (StringUtils.isEmpty(DWN_FLR) || !DATE.isDate(BLD_END_DATE)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_049")).append(MapUtils.getString(upMap, "BLD_END_DATE"))
                    .append(STRING.lineSeparator);
            //���u����ݬ����T�褸���~�榡YYYY-MM-DD
        }

        String BLD_KD = MapUtils.getString(upMap, "BLD_KD");
        if (StringUtils.isEmpty(BLD_KD) || BLD_KD.length() != 1) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_026")).append(BLD_KD).append(STRING.lineSeparator);
            //�c�y�N���ݬ�1��
        }
        String RNT_SIZE = MapUtils.getString(upMap, "RNT_SIZE");
        if (StringUtils.isEmpty(RNT_SIZE)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_027")).append(RNT_SIZE).append(STRING.lineSeparator);
            //�`�X�����n��Ʀ��<=6��B�p�Ʀ���׻�<=2��
        } else if (RNT_SIZE.contains(".")) {
            temp = RNT_SIZE.split("\\.");
            if (temp[0].length() > 6 || temp[1].length() > 2) {
                errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_027")).append(RNT_SIZE).append(STRING.lineSeparator);
                //�`�X�����n��Ʀ��<=6��B�p�Ʀ���׻�<=2��
            }
        } else if (RNT_SIZE.length() > 6) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_027")).append(RNT_SIZE).append(STRING.lineSeparator);
            //�`�X�����n��Ʀ��<=6��B�p�Ʀ���׻�<=2��
        }

        String OFC_RNT_SIZE = MapUtils.getString(upMap, "OFC_RNT_SIZE");
        if (StringUtils.isEmpty(OFC_RNT_SIZE)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_028")).append(OFC_RNT_SIZE).append(STRING.lineSeparator);
            //�줽�ǥi�X�����n��Ʀ��<=6��B�p�Ʀ���׻�<=2��
        } else if (OFC_RNT_SIZE.contains(".")) {
            temp = OFC_RNT_SIZE.split("\\.");
            if (temp[0].length() > 6 || temp[1].length() > 2) {
                errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_028")).append(OFC_RNT_SIZE).append(STRING.lineSeparator);
                //�줽�ǥi�X�����n��Ʀ��<=6��B�p�Ʀ���׻�<=2��
            }
        } else if (OFC_RNT_SIZE.length() > 6) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_028")).append(OFC_RNT_SIZE).append(STRING.lineSeparator);
            //�줽�ǥi�X�����n��Ʀ��<=6��B�p�Ʀ���׻�<=2��
        }
        String SHOP_RNT_SIZE = MapUtils.getString(upMap, "SHOP_RNT_SIZE");
        if (StringUtils.isNotEmpty(SHOP_RNT_SIZE)) {
            if (SHOP_RNT_SIZE.contains(".")) {
                temp = SHOP_RNT_SIZE.split("\\.");
                if (temp[0].length() > 4 || temp[1].length() > 2) {
                    errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_029")).append(SHOP_RNT_SIZE).append(STRING.lineSeparator);
                    //�@�ө����i�X�����n��Ʀ��<=4��B�p�Ʀ���׻�<=2��
                }
            } else if (SHOP_RNT_SIZE.length() > 4) {
                errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_029")).append(SHOP_RNT_SIZE).append(STRING.lineSeparator);
                //�@�ө����i�X�����n��Ʀ��<=4��B�p�Ʀ���׻�<=2��
            }
        }
        String RNT_PRK = MapUtils.getString(upMap, "RNT_PRK");
        if (StringUtils.isNotEmpty(RNT_PRK) && (Integer.parseInt(RNT_PRK) < 0 || Integer.parseInt(RNT_PRK) > 999)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_030")).append(RNT_PRK).append(STRING.lineSeparator);
            //�i�X������ƻݬ�0~9999�ƭ�
        }
        String PRK_KD = MapUtils.getString(upMap, "PRK_KD");
        if (StringUtils.isNotEmpty(PRK_KD) && PRK_KD.length() != 1) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_031")).append(PRK_KD).append(STRING.lineSeparator);
            //���쫬���N���ݬ�1��
        }
        return errMsg.toString();
    }

    /**
     * �ˮְ򥻸�ƶפJ���
     * @param upMap �򥻸��
     * @return errMsg String �ˮֿ��~�T��
     * @throws ErrorInputException 
     */
    @SuppressWarnings("deprecation")
    public String checkData2(Map upMap) throws ErrorInputException {
        if (upMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_I10100_MSG_014")); //�ǤJdata���o����
        }
        StringBuilder errMsg = new StringBuilder();

        String INV_CD = MapUtils.getString(upMap, "INV_CD");
        if (StringUtils.isEmpty(INV_CD) || INV_CD.length() != 11) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_032")).append(INV_CD).append(STRING.lineSeparator);
            //���դj�ӥN���ݬ�11��
        }
        String INV_YR = MapUtils.getString(upMap, "INV_YR");
        if (StringUtils.isEmpty(INV_YR) || INV_YR.length() < 2 || INV_YR.length() > 3) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_033")).append(INV_YR).append(STRING.lineSeparator);
            //�~�׻ݬ�2~3��ƭ�
        }
        String INV_SN = MapUtils.getString(upMap, "INV_SN");
        if (StringUtils.isEmpty(INV_SN) || INV_SN.length() != 1) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_034")).append(INV_SN).append(STRING.lineSeparator);
            //�u�O�ݬ�1��
        }
        String[] temp;
        String EPT_SIZE = MapUtils.getString(upMap, "EPT_SIZE");
        if (StringUtils.isEmpty(EPT_SIZE)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_035")).append(EPT_SIZE).append(STRING.lineSeparator);
            //���u�Ÿm�W�ƾ�Ʀ��<=6��B�p�Ʀ���׻�<=2��
        } else if (EPT_SIZE.contains(".")) {
            temp = EPT_SIZE.split("\\.");
            if (temp[0].length() > 6 || temp[1].length() > 2) {
                errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_035")).append(EPT_SIZE).append(STRING.lineSeparator);
                //���u�Ÿm�W�ƾ�Ʀ��<=6��B�p�Ʀ���׻�<=2��
            }
        } else if (EPT_SIZE.length() > 6) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_035")).append(EPT_SIZE).append(STRING.lineSeparator);
            //���u�Ÿm�W�ƾ�Ʀ��<=6��B�p�Ʀ���׻�<=2��
        }

        String OFFER_AMT = MapUtils.getString(upMap, "OFFER_AMT");
        if (StringUtils.isEmpty(OFFER_AMT) || OFFER_AMT.length() > 4 || OFFER_AMT.contains(".") || Integer.parseInt(OFFER_AMT) < 0) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_038")).append(OFFER_AMT).append(STRING.lineSeparator);
            //�����}���ݬ���Ʀ�<=4�쥿���
        }
        String BASE_AMT = MapUtils.getString(upMap, "BASE_AMT");
        if (StringUtils.isEmpty(BASE_AMT) || INV_SN.length() > 4 || BASE_AMT.contains(".") || Integer.parseInt(BASE_AMT) < 0) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_039")).append(BASE_AMT).append(STRING.lineSeparator);
            //���������ݬ���Ʀ�<=4�쥿���
        }
        String RNT_PRK_AMT = MapUtils.getString(upMap, "RNT_PRK_AMT");
        if (StringUtils.isNotEmpty(RNT_PRK_AMT)
                && (RNT_PRK_AMT.length() > 5 || RNT_PRK_AMT.contains(".") || Integer.parseInt(RNT_PRK_AMT) < 0)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_040")).append(RNT_PRK_AMT).append(STRING.lineSeparator);
            //���쯲���ݬ���Ʀ�<=5�쥿���
        }
        String EXP_AMT = MapUtils.getString(upMap, "EXP_AMT");
        if (StringUtils.isNotEmpty(EXP_AMT) && (EXP_AMT.length() > 3 || EXP_AMT.contains(".") || Integer.parseInt(EXP_AMT) < 0)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_041")).append(EXP_AMT).append(STRING.lineSeparator);
            //�޲z�O/�W�ݬ���Ʀ�<=3�쥿���
        }
        String SHOP_OFFER_AMT = MapUtils.getString(upMap, "SHOP_OFFER_AMT");
        if (StringUtils.isNotEmpty(SHOP_OFFER_AMT)
                && (SHOP_OFFER_AMT.length() > 5 || SHOP_OFFER_AMT.contains(".") || Integer.parseInt(SHOP_OFFER_AMT) < 0)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_042")).append(SHOP_OFFER_AMT).append(STRING.lineSeparator);
            //���������}���ݬ���Ʀ�<=5�쥿���
        }
        String SHOP_BASE_AMT = MapUtils.getString(upMap, "SHOP_BASE_AMT");
        if (StringUtils.isNotEmpty(SHOP_BASE_AMT)
                && (SHOP_BASE_AMT.length() > 5 || SHOP_BASE_AMT.contains(".") || Integer.parseInt(SHOP_BASE_AMT) < 0)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_043")).append(SHOP_BASE_AMT).append(STRING.lineSeparator);
            //�������������ݬ���Ʀ�<=5�쥿���
        }
        String INV_ID = MapUtils.getString(upMap, "INV_ID");
        if (StringUtils.isEmpty(INV_ID) || INV_ID.length() != 10) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_044")).append(INV_ID).append(STRING.lineSeparator);
            //���դH��ID�ݬ�10��
        }
        String INV_NAME = MapUtils.getString(upMap, "INV_NAME");
        if (StringUtils.isEmpty(INV_NAME) || STRING.doubleByteLength(INV_NAME) > 10) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_045")).append(INV_NAME).append(STRING.lineSeparator);
            //���դH���m�W���׶W�L5�Ӥ���
        }
        return errMsg.toString();
    }

    /**
     * �ˮְ򥻸�ƶפJ���
     * @param upMap �򥻸��
     * @return errMsg String �ˮֿ��~�T��
     * @throws ErrorInputException 
     */
    @SuppressWarnings("deprecation")
    public String checkData3(Map upMap) throws ErrorInputException {
        if (upMap == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_I10100_MSG_014")); //�ǤJdata���o����
        }
        StringBuilder errMsg = new StringBuilder();
        String INV_CD = MapUtils.getString(upMap, "INV_CD");
        if (StringUtils.isEmpty(INV_CD) || INV_CD.length() != 11) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_032")).append(INV_CD).append(STRING.lineSeparator);
            //"���դj�ӥN���ݬ�11��"
        }
        String INV_YR = MapUtils.getString(upMap, "INV_YR");
        if (StringUtils.isEmpty(INV_YR) || INV_YR.length() < 2 || INV_YR.length() > 3) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_033")).append(INV_YR).append(STRING.lineSeparator);
            //�~�׻ݬ�2~3��ƭ�
        }
        String INV_SN = MapUtils.getString(upMap, "INV_SN");
        if (StringUtils.isEmpty(INV_SN) || INV_SN.length() != 1) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_034")).append(INV_SN).append(STRING.lineSeparator);
            //"�u�O�ݬ�1��"
        }
        String CUST_IN = MapUtils.getString(upMap, "CUST_IN");
        if (upMap.get("CUST_IN") == null || STRING.doubleByteLength(CUST_IN) > 1000) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_046")).append(CUST_IN).append(STRING.lineSeparator);
            //�Ȥ�y�J���׶W�L500�Ӥ���
        }
        String CUST_OUT = MapUtils.getString(upMap, "CUST_OUT");
        if (upMap.get("CUST_OUT") == null || STRING.doubleByteLength(CUST_OUT) > 1000) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_047")).append(CUST_OUT).append(STRING.lineSeparator);
            //�Ȥ�y�X���׶W�L500�Ӥ���
        }
        String RDC_RNT_SIZE = MapUtils.getString(upMap, "RDC_RNT_SIZE");
        if (StringUtils.isEmpty(RDC_RNT_SIZE)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_036")).append(RDC_RNT_SIZE).append(STRING.lineSeparator);
            //�h���W�ƾ�Ʀ��<=6��B�p�Ʀ���׻�<=2��
        } else if (RDC_RNT_SIZE.contains(".")) {
            String[] temp = RDC_RNT_SIZE.split("\\.");
            if (temp[0].length() > 6 || temp[1].length() > 2) {
                errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_036")).append(RDC_RNT_SIZE).append(STRING.lineSeparator);
                //�h���W�ƾ�Ʀ��<=6��B�p�Ʀ���׻�<=2��
            }
        } else if (RDC_RNT_SIZE.length() > 6) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_036")).append(RDC_RNT_SIZE).append(STRING.lineSeparator);
            //�h���W�ƾ�Ʀ��<=6��B�p�Ʀ���׻�<=2��
        }
        String ADD_RNT_SIZE = MapUtils.getString(upMap, "ADD_RNT_SIZE");
        if (StringUtils.isEmpty(ADD_RNT_SIZE)) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_037")).append(ADD_RNT_SIZE).append(STRING.lineSeparator);
            //�s���W�ƾ�Ʀ��<=6��B�p�Ʀ���׻�<=2��
        } else if (ADD_RNT_SIZE.contains(".")) {
            String[] temp = ADD_RNT_SIZE.split("\\.");
            if (temp[0].length() > 6 || temp[1].length() > 2) {
                errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_037")).append(ADD_RNT_SIZE).append(STRING.lineSeparator);
                //�s���W�ƾ�Ʀ��<=6��B�p�Ʀ���׻�<=2��
            }
        } else if (ADD_RNT_SIZE.length() > 6) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_037")).append(ADD_RNT_SIZE).append(STRING.lineSeparator);
            //�s���W�ƾ�Ʀ��<=6��B�p�Ʀ���׻�<=2��
        }
        String MEMO = MapUtils.getString(upMap, "MEMO");
        if (STRING.doubleByteLength(MEMO) > 1000) {
            errMsg.append(MessageUtil.getMessage("EP_I10100_MSG_048")).append(MEMO).append(STRING.lineSeparator);
            //�Ƶ����׶W�L500�Ӥ���
        }
        return errMsg.toString();

    }

    /**
     * �ѪR�W���ɮ�
     * @param inputData
     * @return List<String[]>
     * @throws Exception 
     */
    private List<String[]> parseInputFile(FileItem inputData) throws Exception {

        String filetype = FilenameUtils.getExtension(inputData.getName());
        StringBuilder errMsg = new StringBuilder();
        List<String[]> fileList = null;
        if ("xls".equalsIgnoreCase(filetype) || "xlsx".equalsIgnoreCase(filetype)) {
            Sheet sheet1 = null;
            if ("xls".equalsIgnoreCase(filetype)) {
                HSSFWorkbook wb = new HSSFWorkbook(new POIFSFileSystem(inputData.getInputStream()));
                sheet1 = wb.getSheetAt(0);
            } else {//[20200210]�ק�Ū��workbook�覡
                Workbook wb = StreamingReader.builder().rowCacheSize(50).bufferSize(4096).open(inputData.getInputStream());
                sheet1 = wb.getSheetAt(0);
            }
            //int totalCells = sheet1.getRow(0).getPhysicalNumberOfCells();//���Y����
            //�N��ƳB�z��List
            fileList = this.processExcelData(sheet1);
        }
        //��X�ˮְT��
        if (errMsg.length() > 0) {
            errMsg.insert(0, "�ɮ׮榡���~�A���ˬd���O�_���T");
            throw new ErrorInputException(errMsg.toString());
        }
        return fileList;
    }

    /**
     *  �B�zExcel��Ƥ��e
     * @param sheet1
     * @param outFields
     * @return  List<String[]>
     * @throws Exception 
     */
    private List<String[]> processExcelData(Sheet sheet1) throws Exception {

        List<String[]> fileList = new ArrayList();
        //[20200210]�אּiterator������o
        Iterator<Row> it = sheet1.rowIterator();

        while (it.hasNext()) {
            Row row = it.next();
            String[] tmp = new String[row.getLastCellNum()];//[20200210]�קK���L�� ���������áA���getLastCellNum
            for (int j = 0; j < row.getLastCellNum(); j++) {
                Cell cell = row.getCell(j);
                if (cell != null) {
                    if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC || (cell.getCellType() == Cell.CELL_TYPE_FORMULA
                            && cell.getCachedFormulaResultType() == Cell.CELL_TYPE_NUMERIC)) {//[20200210]�W�[�p�G�O�������X����ƪ��P�_
                        double dValue = cell.getNumericCellValue();
                        if (dValue - (int) dValue < Double.MIN_VALUE) { //�O�_��int��
                            tmp[j] = ObjectUtils.toString((int) dValue);
                        } else {
                            tmp[j] = ObjectUtils.toString(dValue);
                        }
                    } else {
                        //[20200210]�����]�wcellType��String���]�w
                        String tmpStr = cell.getStringCellValue();
                        if (StringUtils.isNotBlank(tmpStr)) {
                            tmp[j] = tmpStr;
                        }
                    }
                }
            }
            fileList.add(tmp);
        }

        return fileList;
    }

    /**
     *  �ഫEXCEL�Ʀr�����DATE�榡
     * @param str
     * @return  String
     */
    private String getDate(String str) {
        if (STRING.isInteger(str)) {
            String str_date = "1900-01-01";
            str_date = DATE.addDate(str_date, 0, 0, new Integer(str));
            return str_date;
        } else {
            return str;
        }
    }

    /**
     *  �h"�ťաB����Ÿ��B�d����"
     * @param str
     * @param def
     * @return String
     */
    private String doReplace(String str) {
        if (StringUtils.isBlank(str)) {
            return null;
        } else {
        	String repStr = str.replaceAll("\\s|\t|\r|\n", "");
        	repStr = repStr.replaceAll("\\,", "�B");
            return repStr;
        }
    }

    /**
     * 
     * @param eie
     * @param parameter
     * @param errMsg
     * @return
     */
    private ErrorInputException checkStringParam(ErrorInputException eie, String parameter, String errMsg) {
        if (StringUtils.isBlank(parameter)) {
            if (eie == null) {
                eie = new ErrorInputException();
            }
            eie.appendMessage(errMsg);
        }
        return eie;
    }

    /**
     * ���o BigDecimal ������
     * @param map
     * @param key
     * @return
     */
    private BigDecimal getBig(Object obj) {

        if (obj == null) {
            return BigDecimal.ZERO;
        }

        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        return new BigDecimal(obj.toString());
    }

}
