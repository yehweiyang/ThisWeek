package com.cathay.ep.i1.module;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * ���վ��v�污�d�߼Ҳ�
 * </pre>
 * @author �©s��
 * @since 2019/7/8
 */
@SuppressWarnings("rawtypes")
public class EP_I10120 {

    private static final String SQL_qryTOWN_001 = "com.cathay.ep.i1.module.EP_I10120.SQL_qryTOWN_001";

    /**
     * �d�ߦ�F��
     * @param CITY_CD ����
     * @return
     * @throws ModuleException
     */
    public List<Map> qryTOWN(String CITY_CD) throws ModuleException {
        if (StringUtils.isBlank(CITY_CD)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_I10120_MSG_001"));//��J����(CITY_CD)���i����
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("CITY", FieldOptionList.getName("EP", "I1_CITY_CD", CITY_CD));

        return VOTool.findToMaps(ds, SQL_qryTOWN_001);
    }
}
