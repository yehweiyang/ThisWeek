package com.cathay.ep.i1.trx;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.jsoup.helper.StringUtil;

import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.Decimal;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.ReturnMessageUtil;
import com.cathay.common.util.STRING;
import com.cathay.ep.i1.module.EPI1_0100_mod;
import com.cathay.ep.i1.module.EPI1_0112_mod;
import com.cathay.ep.i1.module.EP_I10100;
import com.cathay.ep.vo.DTEPI101;
import com.cathay.ep.z0.module.EP_Z0I100;
import com.cathay.ep.z0.module.EP_Z0I101;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;
import com.cathay.common.exception.OverCountLimitException;

/**
 * <pre>
 *  DATE    Description Author
 *  2016/11/1   Created �����p
 *  
 *  �{���\��    �����M�沣�ͧ@�~
 *  �{���W��    RDZ0_2400
 *  �@�~�覡    ONLINE
 *  �{���\��    �����M�沣�ͧ@�~
 *  �{���W��    RDZ0_2400
 *  �@�~�覡    ONLINE
 *  ���n����
 *  (1) �d�ߧ@�~ �w �ϥΪ̫��U�d�߫��s��A�z�L�Ҳը��o�����վ�O���ɵ��G��ܩ�d�ߵ��G�C
 *  (2) �M���@�~ �w �N�����d�߱���M��(��J���M�šA�U�Կ��w�]�������ﶵ)�C
 *  (3) �ץXCSV�@�~ �w �̬d�߱���N�����ܰ϶����M��ץX�C 
 *  (4) ����@�~ �w �̾کҿ�����߻���Ǥ鲣�͸��
 *  (5) ���ͥ�����߻��M��@�~ �w �ȱN��ܬ���������(���߻�)������Ʋ��ͦ�EXCEL��
 *  (6) ���ͤ��������M�� �w �ȱN��ܬ�����������������Ʋ���EXCEL��
 *  (7) �Ƶ����@ �w ��J�Ƶ����e
 *  (8) �T�{ �w �N�f�媬�A�ѡu�ݽT�{�v�ܬ��u�w�T�{�v
 *  (9) �����T�{ �w �N�f�媬�A�ѡu�w�T�{�v�ܬ��u�ݽT�{�v
 *  
 *  ���s���v  FUNC_ID = RDZ02400
 *  
 *  
 * @author ���F��
 * @since 2016/11/23
 * </pre>
 */
@SuppressWarnings("unchecked")
public class EPI1_0112 extends UCBean {
    /** log */
    private final static Logger log = Logger.getLogger(EPI1_0112.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** 
     * �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@
     */
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        //�@�w�n invoke super.start() �H�����v���ˮ�
        super.start(req);
        //�I�s�۩w����l�ʧ@
        initApp(req);
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject,  
     * �γ]�w ReturnMessage �� response code.
     */
    private void initApp(RequestContext req) throws TxException {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);
        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     * @throws ModuleException 
     */
    public ResponseContext doPrompt(RequestContext req) {

        VOTool.setParamsFromLP_JSON(req);

        String SUB_CPY_ID = req.getParameter("SUB_CPY_ID"); //�����q�O 
        String INV_CD = req.getParameter("INV_CD"); //�j�ӥN��:�ŭȪ��s�W��

        resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        resp.addOutputData("INV_CD", INV_CD);

        //�O�����~��T
        StringBuilder errMsgRec = new StringBuilder();

        //�u�M��
        try {
            resp.addOutputData("INV_SN_List", FieldOptionList.getName("EP", "I1_INV_SN"));
            resp.addOutputData("INV_YR", DATE.getROCYear(DATE.getY2KDate())); //�w�]���~
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_001"), e); //���o�u�u�M��v����
            errMsgRec.append("," + MessageUtil.getMessage("EPI1_0112_ERRMSG_001"));
        }

        if (StringUtils.isNotBlank(INV_CD)) {
            String INV_DIV_NO = "";

            //�j�Ӱ򥻸��
            try {
                Map reqMap = new HashMap();
                reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
                reqMap.put("INV_CD", INV_CD);
                Map<String, String> DTEPI100Map = new EP_Z0I100().queryDTEPI100(reqMap).get(0);
                INV_DIV_NO = MapUtils.getString(DTEPI100Map, "INV_DIV_NO");
                for (String key : DTEPI100Map.keySet()) {
                    resp.addOutputData(key, DTEPI100Map.get(key));
                }
                resp.addOutputData("INV_DIV_NO", new DivData().getUnit4ShortName(INV_DIV_NO));

            } catch (Exception e) {
                log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_004"), e); //���o�u�j�Ӱ򥻸�ơv����
                errMsgRec.append("," + MessageUtil.getMessage("EPI1_0112_ERRMSG_004"));
            }
            //���դH���M��
            try {
                resp.addOutputData("INV_ID_List", new EP_I10100().queryInvId(INV_DIV_NO));
            } catch (Exception e) {
                log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_002"), e); //���o�u���դH���M��v����
                errMsgRec.append("," + MessageUtil.getMessage("EPI1_0112_ERRMSG_002"));
            }
            
        } else {
            //���դH���M��
            try {
                resp.addOutputData("INV_ID_List", new EP_I10100().queryInvId(user.getDivNo()));
            } catch (Exception e) {
                log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_002"), e); //���o�u���դH���M��v����
                errMsgRec.append("," + MessageUtil.getMessage("EPI1_0112_ERRMSG_002"));
            }
        }

        if (errMsgRec.length() != 0) {
            ReturnMessageUtil.setMessage(errMsgRec.substring(1), ReturnCode.ERROR, msg);
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        String SUB_CPY_ID = req.getParameter("SUB_CPY_ID"); //�����q�O 
        String INV_CD = req.getParameter("INV_CD"); //�j�ӥN��:�ŭȪ��s�W��
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("INV_CD", INV_CD);
        try {
            List I101List = new EP_Z0I101().queryDTEPI101(reqMap);
            resp.addOutputData("I101List", I101List);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_003"), dnfe); //�d�L��Ƶ������`
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage()); //�s�ʤW�u��ƥ���
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_012"); //�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_014"); //�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_014"), e); //�d�ߥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPI1_0112_ERRMSG_014"); //�d�ߥ���
        }

        return resp;
    }

    /**
     * �~,�u���ʮɳs�ʤW�u���
     * @param req
     * @return
     */
    public ResponseContext getLastSeason(RequestContext req) {

        String INV_CD = req.getParameter("INV_CD");

        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
        reqMap.put("INV_CD", INV_CD);
        reqMap.put("INV_YR", req.getParameter("INV_YR"));
        reqMap.put("INV_SN", req.getParameter("INV_SN"));

        try {
            DTEPI101 LST_SN_Map = new EP_Z0I101().queryLstSn(reqMap);
            Map<String, Object> newMap = VOTool.voToMap(LST_SN_Map);

            for (String key : newMap.keySet()) {
                resp.addOutputData(key, newMap.get(key));
            }
            resp.addOutputData("LST_BASE_AMT", MapUtils.getString(newMap, "BASE_AMT"));
            resp.addOutputData("LST_OFFER_AMT", MapUtils.getString(newMap, "OFFER_AMT"));

            //�s�ʪŸm�v�B�}�����^�T�B�������^�T
            req.setParameter("type", "0");
            getMath(req);
            
            req.setParameter("type", "1");
            req.setParameter("LST_OFFER_AMT", MapUtils.getString(newMap, "OFFER_AMT"));
            getMath(req);
            
            req.setParameter("type", "2");
            req.setParameter("LST_BASE_AMT", MapUtils.getString(newMap, "BASE_AMT"));
            getMath(req);
            
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_003"), dnfe); //�d�L��Ƶ������`
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage()); //�s�ʤW�u��ƥ���
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_012"); //�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_007"); //�s�W����
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_013"), e); //�s�ʤW�u��ƥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPI1_0112_ERRMSG_013"); //�s�ʤW�u��ƥ���
        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {

        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            new EPI1_0100_mod().checkPeriod(user);
            new EPI1_0112_mod().checkInsert(reqMap, user);

            //����s�W�{��
            Transaction.begin();
            try {
                new EP_Z0I101().insertDTEPI101(reqMap, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPI1_0112_ERRMSG_005");//�s�W���\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPI1_0112_ERRMSG_006"); //�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_012"); //�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_007"); //�s�W����
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_007"), e); //�s�W����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPI1_0112_ERRMSG_007"); //�s�W����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {

        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            new EPI1_0100_mod().checkPeriod(user);

            //�ˮ֬O�_�i�ק�
            new EPI1_0112_mod().checkUpdate(reqMap, user);

            //����ק�{��
            Transaction.begin();
            try {
                new EP_Z0I101().updateDTEPI101(reqMap, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPI1_0112_ERRMSG_008");
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPI1_0112_ERRMSG_006"); //�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_012"); //�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_009"); //�ק異��
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_009"), e); //�ק異��
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPI1_0112_ERRMSG_009"); //�ק異��
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {

        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            new EPI1_0100_mod().checkPeriod(user);

            //�ˮ֬O�_�i�R��
            new EPI1_0112_mod().checkDelete(reqMap, user);

            //����ק�{��
            Transaction.begin();
            try {
                new EP_Z0I101().deleteDTEPI101(reqMap, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPI1_0112_ERRMSG_010");//�R�����\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPI1_0112_ERRMSG_006"); //�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_012"); //�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_011"); //�R������
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPI1_0112_ERRMSG_011"), e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPI1_0112_ERRMSG_011"); //�R������
        }

        return resp;
    }

    /**
     * �e�ݶǭȭp��
     * @param req
     * @return
     */
    public ResponseContext getMath(RequestContext req) {

        int type = Integer.parseInt(req.getParameter("type"));
        BigDecimal HUNDRED = new BigDecimal("100");
        BigDecimal NEGA_HUNDRED = new BigDecimal("-100");

        /* type action
         * 0    �p��Ÿm�v
         * 1    �p��}�����^�T
         * 2    �p�⩳�����^�T
         */
        switch (type) {

            case 0:
                BigDecimal EPT_SIZE = getBigDecimal(req.getParameter("EPT_SIZE"));

                Map DTEPI100Map = getDTEPI100Map(req);
                String RNT_SIZE_STRING = MapUtils.getString(DTEPI100Map, "RNT_SIZE");

                if (!StringUtil.isBlank(RNT_SIZE_STRING) && !"0".equals(RNT_SIZE_STRING)) {
                    //�������sor��  ���i��p��
                    BigDecimal RNT_SIZE = getBigDecimal(RNT_SIZE_STRING);
                    BigDecimal EPT_RATE = EPT_SIZE.multiply(HUNDRED).divide(RNT_SIZE, 2, BigDecimal.ROUND_HALF_UP);
                    resp.addOutputData("EPT_RATE", EPT_RATE);
                }

                break;

            case 1:
                BigDecimal OFFER_AMT = getBigDecimal(req.getParameter("OFFER_AMT"));
                String LST_OFFER_AMT_STRING = req.getParameter("LST_OFFER_AMT");

                if (!StringUtil.isBlank(LST_OFFER_AMT_STRING) && !"0".equals(LST_OFFER_AMT_STRING)) {
                    //�������sor��  ���i��p��
                    BigDecimal LST_OFFER_AMT = getBigDecimal(LST_OFFER_AMT_STRING);
                    BigDecimal OFFER_RATE = OFFER_AMT.multiply(HUNDRED).divide(LST_OFFER_AMT, 2, BigDecimal.ROUND_HALF_UP)
                            .add(NEGA_HUNDRED);
                    resp.addOutputData("OFFER_RATE", OFFER_RATE);
                }
                break;

            case 2:
                BigDecimal BASE_AMT = getBigDecimal(req.getParameter("BASE_AMT"));
                String LST_BASE_AMT_STRING = req.getParameter("LST_BASE_AMT");

                if (!StringUtil.isBlank(LST_BASE_AMT_STRING) && !"0".equals(LST_BASE_AMT_STRING)) {
                    //�������sor��  ���i��p��
                    BigDecimal LST_BASE_AMT = getBigDecimal(req.getParameter("LST_BASE_AMT"));
                    BigDecimal BASE_RATE = BASE_AMT.multiply(HUNDRED).divide(LST_BASE_AMT, 2, BigDecimal.ROUND_HALF_UP).add(NEGA_HUNDRED);
                    resp.addOutputData("BASE_RATE", BASE_RATE);
                }
                break;

        }

        return resp;
    }

    /**
     * ���oBigDecimal�î榡��
     * @param param
     * @return
     * @throws ModuleException
     */
    private BigDecimal getBigDecimal(String param) {

        return STRING.objToBigDecimal(param.replace(",", ""), Decimal.ZERO);
    }

    /**
     * ���oDTEPI100Map
     * @param rtnMsg
     * @param req
     * @param resp
     * @throws ModuleException 
     */
    private Map getDTEPI100Map(RequestContext req) {

        String SUB_CPY_ID = req.getParameter("SUB_CPY_ID"); //�����q�O 
        String INV_CD = req.getParameter("INV_CD"); //�j�ӥN��:�ŭȪ��s�W��

        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("INV_CD", INV_CD);

        Map<String, String> DTEPI100Map;
        try {
            DTEPI100Map = new EP_Z0I100().queryDTEPI100(reqMap).get(0);
        } catch (DataNotFoundException dnfe) {
            DTEPI100Map = new HashMap(); //�d�L��Ƶ������`
        } catch (ModuleException e) {
            DTEPI100Map = new HashMap();
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR_MODULE, "EPI1_0112_ERRMSG_004"); 
        }

        return DTEPI100Map;
    }

}
