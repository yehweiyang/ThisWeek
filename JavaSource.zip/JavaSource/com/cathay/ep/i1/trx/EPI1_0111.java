package com.cathay.ep.i1.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.ReturnMessageUtil;
import com.cathay.ep.i1.module.EPI1_0100_mod;
import com.cathay.ep.i1.module.EPI1_0111_mod;
import com.cathay.ep.i1.module.EP_I10100;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0I100;
import com.cathay.ep.z0.module.EP_Z0I101;
import com.cathay.ep.z0.module.EP_Z0I110;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * 2016/11/21   1.0 Created �_�ɪ�
 * �{���\�෧�n�����G
 * �{���\��        �򥻸�ƺ��@
 * �{���W��    EPI1_0111
 * �@�~�覡    ONLINE
 * ���n����
 * (1) ��l�C
 * (2) �s�W �w �ϥΪ̫��U���s��A�s�W�j�Ӱ򥻸�ơC
 * (3) �ק� �w �ϥΪ̫��U���s��A�ק�j�Ӱ򥻸�ơC
 * (4) �R�� �w �ϥΪ̫��U���s��A�R���j�Ӱ򥻸�ơC
 * (5) �W�� �w �ϥΪ̫��U���s��A�W�Ǥj�ӥ~�[�Ӥ��C
 * ���s���v    �M��FUNC_ID = EPI10111
 * �h��y�t    �M��
 * �����q����榡���js  �M��
 * </pre>
 * @author i9300623 ���l��
 * @since 2016/12/19
 * 
 * 2019/07/23 �t�X�q�l�a�ϱM�׷s�W�ק�Method
 * 2019/11/11 AllenTsai �t�X�q�l�a��API�վ�Token�W�[UserID
 * 2019/11/18 AllenTsai �t�X�q�l�a��API�վ�w��T�{�P�_
 * 2019/11/18 AllenTsai �����s�W�q�l�a�ϫ��s
 * 2019/12/31 AllenTsai �q�l�a�ϫ��s�ΥN�X����
 * 2020/03/10 AllenTsai �վ㦳�]�w��ܹq�l�a�Ϥ~�I�s API
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPI1_0111 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPI1_0111.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     */
    private void initApp(RequestContext req) {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);
        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
        String INV_CD = req.getParameter("INV_CD");

        resp.addOutputData("CITY_CD_List", FieldOptionList.getName("EP", "I1_CITY_CD"));
        resp.addOutputData("OFC_CLS_List", FieldOptionList.getName("EP", "I1_OFC_CLS"));
        resp.addOutputData("BLD_KD_List", FieldOptionList.getName("EP", "I1_BLD_KD"));
        resp.addOutputData("PRK_KD_List", FieldOptionList.getName("EP", "I1_PRK_KD"));

        StringBuilder errMsgSb = new StringBuilder();
        try {
            //[20190716] �P�_�O�_����ؤH��
            resp.addOutputData("isAccountSubCpy", new EP_Z00030().isAccountSubCpy(SUB_CPY_ID));
        } catch (Exception e) {
            log.error("�P�_�����q�O����", e);
            errMsgSb.append("," + MessageUtil.getMessage("EPI1_0111_ERRMSG_PROMPT_003"));
        }
        //[20191230] �P�O�e���W�O�_��ܹq�l�a�Ϫ��J�f
        String isEPH21000 = "N";
        try{
        	isEPH21000 = FieldOptionList.getName("EP", "EMAP_ENTRY", "EPH21000");
        } catch(Exception e) {
            //[20190730] �S�]�w�N�X�h�ιw�]"N"
            log.error("�d�L�q�l�a�ϳ]�w��", e);            	
        }     
        log.debug("isEPH21000:"+isEPH21000);
        resp.addOutputData("isEPH21000", isEPH21000);
        //        try {
        //            List<Map>  INV_ID_List = new EP_I10100().queryInvId(user.getDivNo());
        //            resp.addOutputData("INV_ID_List", INV_ID_List);
        //        } catch (Exception e) {
        //            log.error("���o���դH���M�楢��", e);
        //            errMsgSb.append("," + MessageUtil.getMessage("EPI1_0111_ERRMSG_PROMPT_001"));
        //        }

        try {
        	String usrId  = this.getUserObject(req).getEmpID();
            this.query(SUB_CPY_ID, INV_CD, usrId);
        } catch (Exception e) {
            log.error("���o�򥻸�ƥ���", e);
            errMsgSb.append("," + MessageUtil.getMessage("EPI1_0111_ERRMSG_PROMPT_002"));
        }
        if (errMsgSb.length() != 0) {
            ReturnMessageUtil.setMessage(errMsgSb.substring(1), ReturnCode.ERROR, msg);
        }

        return resp;
    }

    /**
     * ���o�ϰ�U�Կ��
     * @param req
     * @return
     */
    public ResponseContext queryZONE_CD_List(RequestContext req) {

        Map ZONE_CD_List = FieldOptionList.getName("EP", "I1_ZONE_CD_" + req.getParameter("CITY_CD"));

        resp.addOutputData("ZONE_CD_List", ZONE_CD_List);

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {

            Map DTEPI100 = VOTool.requestToMap(req);

            new EPI1_0100_mod().checkPeriod(user);
            new EPI1_0111_mod().checkInsert(DTEPI100, user);

            String INV_CD = "";

            Transaction.begin();
            try {
                INV_CD = new EP_Z0I100().insertDTEPI100(DTEPI100, user);
                Transaction.commit();

            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPI1_0111_MSG_INSERT_OK"));//�s�W���\

            try {
            	String usrId  = this.getUserObject(req).getEmpID();
                this.query(req.getParameter("SUB_CPY_ID"), INV_CD, usrId);
            } catch (Exception e) {
                log.error("�s�W���\�A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPI1_0111_MSG_INSERT_001"));//�s�W���\�A���d����
            }
        } catch (ErrorInputException eie) {
            log.error("��J���~�A�s�W����", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�s�W����", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPI1_0111_ERRMSG_INSERT_002"));//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPI1_0111_ERRMSG_INSERT_002"));//�s�W����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {

            Map DTEPI100 = VOTool.requestToMap(req);

            new EPI1_0100_mod().checkPeriod(user);
            new EPI1_0111_mod().checkUpdate(DTEPI100, user);

            Transaction.begin();
            try {
                new EP_Z0I100().updateDTEPI100(DTEPI100, user);
                Transaction.commit();

            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPI1_0111_MSG_UPDATE_OK"));//�ק令�\

            try {
            	String usrId  = this.getUserObject(req).getEmpID();
                this.query(req.getParameter("SUB_CPY_ID"), req.getParameter("INV_CD"), usrId);
            } catch (Exception e) {
                log.error("�ק令�\�A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPI1_0111_MSG_UPDATE_001"));//�ק令�\�A���d����
            }

        } catch (ErrorInputException eie) {
            log.error("��J���~�A�ק異��", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�ק異��", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPI1_0111_ERRMSG_UPDATE_002"));//�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPI1_0111_ERRMSG_UPDATE_002"));//�ק異��
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");

            Map DTEPI100 = new HashMap();
            DTEPI100.put("INV_DIV_NO", req.getParameter("INV_DIV_NO"));
            DTEPI100.put("SUB_CPY_ID", SUB_CPY_ID);
            DTEPI100.put("INV_CD", req.getParameter("INV_CD"));

            new EPI1_0100_mod().checkPeriod(user);
            new EPI1_0111_mod().checkDelete(DTEPI100, user);

            Transaction.begin();
            try {
                new EP_Z0I100().deleteDTEPI100(DTEPI100, user);
                try {
                    new EP_Z0I101().deleteDTEPI101(DTEPI100, user);
                } catch (DataNotFoundException dnfe) {
                    //�d�L��Ƶ������`
                    log.error("�d�L��Ƶ������`", dnfe);
                }
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPI1_0111_MSG_DELETE_OK"));//�R�����\

            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
            resp.addOutputData("INV_CD", "");

        } catch (ErrorInputException eie) {
            log.error("��J���~�A�R������", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�R������", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPI1_0111_ERRMSG_DELETE_002"));//�R������
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPI1_0111_ERRMSG_DELETE_002"));//�R������
        }

        return resp;
    }

    /**
     * �W�����s
     * @param req 
     * @return
     */
    public ResponseContext doUpdateFileNo(RequestContext req) {

        try {
            EP_Z0I100 theEP_Z0I100 = new EP_Z0I100();
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("INV_CD", req.getParameter("INV_CD"));
            Map DTEPI100 = theEP_Z0I100.queryDTEPI100(reqMap).get(0);
            DTEPI100.put("FILE_NO", req.getParameter("FILE_NO"));

            Transaction.begin();
            try {
                theEP_Z0I100.updateDTEPI100(DTEPI100, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPI1_0111_MSG_001");//�W������

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00012");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPI1_0111_MSG_002");//�W������
            }
        } catch (Exception e) {
            log.error("�W������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPI1_0111_MSG_002");//�W������
        }
        return resp;
    }



    /**
     * �@�άd��
     * @param SUB_CPY_ID
     * @param INV_CD
     * @return
     * @throws Exception 
     */
    private void query(String SUB_CPY_ID, String INV_CD, String userId) throws Exception {
        resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        resp.addOutputData("INV_CD", INV_CD);
        List<Map> INV_ID_List = new ArrayList<Map>();

        if (StringUtils.isBlank(INV_CD)) {

            resp.addOutputData("INV_DIV_NO", user.getDivNo());
            resp.addOutputData("INV_DIV_NM", user.getDivShortName());
            INV_ID_List = new EP_I10100().queryInvId(user.getDivNo());
            resp.addOutputData("INV_ID_List", INV_ID_List);

        } else {
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            reqMap.put("INV_CD", INV_CD);

            Map DTEPI100Map = new EP_Z0I100().queryDTEPI100(reqMap).get(0);

            Map ZONE_CD_List = FieldOptionList.getName("EP", "I1_ZONE_CD_" + DTEPI100Map.get("CITY_CD"));
            String INV_DIV_NO = MapUtils.getString(DTEPI100Map, "INV_DIV_NO");
            String INV_DIV_NM = new DivData().getUnit4ShortName(INV_DIV_NO);
            INV_ID_List = new EP_I10100().queryInvId(INV_DIV_NO);

            resp.addOutputData("ZONE_CD_List", ZONE_CD_List);
            resp.addOutputData("INV_DIV_NO", INV_DIV_NO);
            resp.addOutputData("INV_DIV_NM", INV_DIV_NM);
            resp.addOutputData("DTEPI100Map", VOTool.toJSON(DTEPI100Map));
            resp.addOutputData("INV_ID_List", INV_ID_List);
        }

        //[20190723] �P�_�O�_���"�إߦa�Ϥj��"���s, I110�L�Ȥ~�ݭn���, �w�]�����
        boolean hasListI110 = true;
        //[20190723] �P�_�O�_���"�ݩw��T�{", �w�]�����
        boolean needConfirm = false;
        List<String> bldList = new ArrayList<String>();
        bldList.add(INV_CD);
        try {
        	
            //[20191230] �P�O�e���W�O�_��ܹq�l�a�Ϫ��J�f �~�I�sAPI
            String isEPH21000 = "N";
            try{
            	isEPH21000 = FieldOptionList.getName("EP", "EMAP_ENTRY", "EPH21000");
            } catch(Exception e) {
                //[20190730] �S�]�w�N�X�h�ιw�]"N"
                log.error("�d�L�q�l�a�ϳ]�w��", e);            	
            }     
            log.debug("isEPH21000:"+isEPH21000);        	
            if("Y".equals(isEPH21000)) {
                List<Map> newRtnList = new EP_Z0I110().callAPIMap004(bldList, userId);
                //[20190723] �p�GI110����ƫh���"�q�l�a��"���s
                if (newRtnList.size() > 0) {
                    Map mapA110 = newRtnList.get(0);
                    //[20190723] �p�GI110����Ʀ��٨S�w��,�h���"�ݩw��T�{"
                    if ("N".equals(MapUtils.getString(mapA110, "CFM_CD"))) {
                        needConfirm = true;
                    }
                }
            }
        	

        } catch (Exception e) {
            log.error("���o�Ŷ���T����", e);
        }

        resp.addOutputData("hasListI110", hasListI110);
        resp.addOutputData("needConfirm", needConfirm);

    }

}
