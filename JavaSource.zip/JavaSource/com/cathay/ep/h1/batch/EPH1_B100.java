package com.cathay.ep.h1.batch;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.WorkDate;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.rz.s0.module.RZ_S00300;
import com.igsapp.db.BatchQueryDataSet;

/**
 * 
 * <pre>
 * Date    Version Description Author
 * 2020/04/22  1.0 Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ���~�w�s����wĵ�q��
 * �{���W��    EPH1_B100
 * �@�~�覡    BATCH
 * ���n����    �Ƶ{�����ɮ�
 * �w����ƶq   5000 (�̤j��)
 * �@�~�W��    JAEPDG002
 * �~�ȧO EP
 * ���t�ΦW��   H1
 * �B�z�g��    ��
 * ����B�z���  3000
 * 
 * </pre>
 * @author ���f��
 * @since 2020/04/22
 * 2020/04/28 AllenTsai �վ����W�L14�Ѥ~�wĵ�q��
 * 2020/05/19 AllenTsai �վ����W�LT1�wĵ�@���A�W�LT2�~�C�ѳq��
 * 2020/05/2119 AllenTsai �վ�i�H�̾ڥ�������������wĵ����
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPH1_B100 extends EP_BatchBean {
    private static final Logger log = Logger.getLogger(EPH1_B100.class);

    /** �@�~�W�� */
    private static final String JOB_NAME = "JAEPDH001";

    /** �{���W�� */
    private static final String PROGRAM = "EPH1_B100";

    /** ����g�� */
    private static final String PERIOD = "�~";

    /** �t�Τ� */
    private Date SYS_DT = DATE.today();

    private String EVENT_ID = "EP_RA017"; //  �ƥ�N�� 

    private String SUB_CPY_ID = "00"; //  �����q�O

    private EP_B30010 theEP_B30010 = new EP_B30010();

    private EP_Z10030 theEP_Z10030 = new EP_Z10030();

    private RZ_S00300 theRZ_S00300 = new RZ_S00300();

    private List<Map> dataList = new ArrayList<Map>(); //  �q�����������

    private List<Map> recList = new ArrayList<Map>(); //  �q����H

    private List<Map> titleList = new ArrayList<Map>(); //  �q������������

    private String ERROR_COUNT = "���~���";

    private static final String SQL_QUERY_001 = "com.cathay.ep.h1.batch.EPH1_B100.SQL_QUERY_001";

    //����wĵ�q��
    private String EXP_NOTIFY = "Y";
    //����wĵ�q�� �W�L T1�q���@�� 
    private String EXP_DAY_T1 = "14";
    private int EXP_NOTIFY_T1 = -14;
    //����wĵ�q�� �W�L T2 �C�ѳq��
    private String EXP_DAY_T2 = "90";
    private int EXP_NOTIFY_T2 = -90;
    
    @Override
    public void execute(String[] arg0) throws Exception {
        final BatchConstructor bc = new BatchConstructor(JOB_NAME, PROGRAM, PERIOD);

        //�i�z�L�N�X��s����wĵ�q�� 
        try {
        	EXP_NOTIFY = FieldOptionList.getName("EP", "EXP_NOTIFY_CFG", "EXP_NOTIFY");
            EXP_DAY_T1 = FieldOptionList.getName("EP", "EXP_NOTIFY_CFG", "NOTIFY_DAY_T1");
            EXP_DAY_T2 = FieldOptionList.getName("EP", "EXP_NOTIFY_CFG", "NOTIFY_DAY_T2");
            
            EXP_NOTIFY_T1 = 0- Integer.parseInt(EXP_DAY_T1);
            EXP_NOTIFY_T2 = 0- Integer.parseInt(EXP_DAY_T2);
        } catch(Exception e) {
        	
        }
        
        try {
            bc.execute(new BatchConstructor.DataBaseHandler() {

                SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");

                String NOTIFY_DATE_A = fmt.format(WorkDate.getXWorkingDate(SYS_DT, 3, true));

                String NOTIFY_DATE_B = DATE.addDate(String.valueOf(SYS_DT), 0, 0, 14);

                String NOTIFY_DATE_C = DATE.addDate(String.valueOf(SYS_DT), 0, 0, 30);

                String NOTIFY_DATE_E = DATE.addDate(String.valueOf(SYS_DT), 0, 0, 3); //�t�Τ�+3��
                
                String NOTIFY_DATE_F = DATE.addDate(String.valueOf(SYS_DT), 0, 0, EXP_NOTIFY_T1); //�t�Τ�-T1�� (14)
                
                String NOTIFY_DATE_G = DATE.addDate(String.valueOf(SYS_DT), 0, 0, EXP_NOTIFY_T2); //�t�Τ�-T2�� (90)

                String INT_STS = "2";

                int TOT_CNT = 0;

                BigDecimal iTOT_AMT = BigDecimal.ZERO;

                BigDecimal iTOT_EXP_AMT = BigDecimal.ZERO;

                @Override
                protected boolean searchProcess(BatchQueryDataSet bqds) throws Exception {
                    bqds.setField("INT_STS", INT_STS);
                    //����T�Ӥu�@�ѫe�wĵ
                    bqds.setField("NOTIFY_DATE_A", NOTIFY_DATE_A);
                    //���14�ѫe�wĵ
                    bqds.setField("NOTIFY_DATE_B", NOTIFY_DATE_B);
                    //���30�ѫe�wĵ
                    bqds.setField("NOTIFY_DATE_C", NOTIFY_DATE_C);
                    //���3�ѫe�wĵ
                    bqds.setField("NOTIFY_DATE_E", NOTIFY_DATE_E);
                    //�����w�W�LT1
                    bqds.setField("NOTIFY_DATE_F", NOTIFY_DATE_F);
                    //�����w�W�LT2
                    bqds.setField("NOTIFY_DATE_G", NOTIFY_DATE_G);
                    
                    bqds.searchAndRetrieve(SQL_QUERY_001);
                    if (bqds.getTotalCount() == 0) {
                        log.fatal("�d�L���");
                        return false;
                    }
                    return true;
                }

                @Override
                protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {
                    Map dataMap = VOTool.dataSetToMap(bqds);
                    
                    String EXP_DATE = MapUtils.getString(dataMap, "EXP_DATE");
                    boolean isNotify = false;
                    String orgEXP_NOTIFY = "";
                    try {
                    	String orgID = MapUtils.getString(dataMap, "ORG_ID", "");
                    	orgEXP_NOTIFY = FieldOptionList.getName("EP", "EXP_NOTIFY_CFG", orgID);	
                    } catch(Exception e) {
                    	//�����N�X���ȿ��~
                    }
                    //�Y�����⥼�]�w��������]�w �ϥΦ@�γ]�w
                    if(StringUtils.isEmpty(orgEXP_NOTIFY)) {
                    	orgEXP_NOTIFY = EXP_NOTIFY;
                    }
                    String NOTIFY_TYPE = "";
                    if (NOTIFY_DATE_E.equals(EXP_DATE)) {
                        NOTIFY_TYPE = "A:���3�ѫe�wĵ";
                        isNotify = true;
                    } else if (NOTIFY_DATE_A.equals(EXP_DATE)) {
                        NOTIFY_TYPE = "A:����T�Ӥu�@�ѫe�wĵ";
                        isNotify = true;
                    } else if (NOTIFY_DATE_B.equals(EXP_DATE)) {
                        NOTIFY_TYPE = "B:���14�ѫe�wĵ";
                        isNotify = true;
                    } else if (NOTIFY_DATE_C.equals(EXP_DATE)) {
                        NOTIFY_TYPE = "C:���30�ѫe�wĵ";
                        isNotify = true;
                    } else if (NOTIFY_DATE_F.equals(EXP_DATE)) {
                    	NOTIFY_TYPE = "D:�����w�W�L"+EXP_DAY_T1+"��";
                    	//����O�_�q��
                    	if("Y".equals(orgEXP_NOTIFY)) {
                        	isNotify = true;
                    	}
                    } else if (DATE.diffDay(EXP_DATE, String.valueOf(NOTIFY_DATE_G)) > 0) {
                        NOTIFY_TYPE = "D:�����w�W�L"+EXP_DAY_T2+"��";
                        //����O�_�q��
                    	if("Y".equals(orgEXP_NOTIFY)) {
                        	isNotify = true;
                    	}
                    }
                    dataMap.put("NOTIFY_TYPE", NOTIFY_TYPE);
                    if ("4".equals(MapUtils.getString(dataMap, "INV_TERM_UNIT"))) {
                        dataMap.put("PERIOD", "");
                    } else {
                        String INV_TERM_UNIT = FieldOptionList.getName("EP", "INV_TERM_UNIT", MapUtils.getString(dataMap, "INV_TERM_UNIT"));
                        dataMap.put("PERIOD", dataMap.get("INV_TERM_VALUE") + INV_TERM_UNIT);
                    }
                    //�Y�ݳq���~�p��X�p�ȻP�[�J�q������
                    if(isNotify) {
                        TOT_CNT++;
                        iTOT_AMT = iTOT_AMT.add(STRING.objToBigDecimal(dataMap.get("TRD_AMT"), BigDecimal.ZERO));
                        iTOT_EXP_AMT = iTOT_EXP_AMT.add(STRING.objToBigDecimal(dataMap.get("EST_EXP_AMT"), BigDecimal.ZERO));
                        dataMap.put("TRD_AMT", formaterAMTNumber(STRING.objToBigDecimal(dataMap.get("TRD_AMT"), BigDecimal.ZERO)));
                        dataMap.put("EST_EXP_AMT", formaterAMTNumber(STRING.objToBigDecimal(dataMap.get("EST_EXP_AMT"), BigDecimal.ZERO)));
                        dataMap.put("SEQ_NO", TOT_CNT);
                        dataList.add(dataMap);                        
                    }
                }

                @Override
                protected void lastProcess() throws Exception {

                    Map lastMap = new HashMap();
                    lastMap.put("SEQ_NO", "�X�p���");
                    lastMap.put("SP_NM", TOT_CNT);
                    lastMap.put("ORG_NM", "�X�p�w�s���B");
                    lastMap.put("TRD_AMT", formaterAMTNumber(iTOT_AMT));
                    lastMap.put("PERIOD", "�X�p����`�B");
                    lastMap.put("EST_EXP_AMT", formaterAMTNumber(iTOT_EXP_AMT));
                    lastMap.put("EXP_DATE", "");
                    lastMap.put("NOTIFY_TYPE", "");
                    dataList.add(lastMap);

                    Map<String, List<DTEPZ103>> nMap = theEP_Z10030.getMailList(SUB_CPY_ID, EVENT_ID);
                    //���~�B�zB�o�͡A�i�אּ!=
                    if (nMap.size() == 0) {
                        ErrorHandler(bc, "�q����H�]�w���~", "���~�w�s����q����H");
                    }

                    List<DTEPZ103> mailList = nMap.get(SUB_CPY_ID);
                    for (DTEPZ103 z103 : mailList) {
                        Map recepit = new HashMap();
                        recepit.put("EVENT_ID", EVENT_ID);
                        recepit.put("USER_ID", z103.getID());
                        recepit.put("USER_EMAIL", z103.getEMAIL());

                        recList.add(recepit);
                    }

                    String[][] titleArray = { { "SEQ_NO", "�Ǹ�", "10" }, { "SP_NM", "�@�~�D��<br>(����ӷ�)", "10" }, { "ORG_NM", "�����H", "10" }, { "TRD_AMT", "�w�s���B", "10" }, { "PERIOD", "����", "10" }, { "EST_EXP_AMT", "�w������`�B", "15" },
                            { "EXP_DATE", "�����", "10" }, { "NOTIFY_TYPE", "�wĵ����", "25" } };
                    for (String[] title : titleArray) {
                        Map titleMap = new HashMap();
                        titleMap.put("FIELD", title[0]);
                        titleMap.put("FIELD_NM", title[1]);
                        titleMap.put("FIELD_SIZE", title[2]);
                        if (titleList.size() < titleArray.length) {
                            titleList.add(titleMap);
                        } else {
                            continue;//�����Ʀs��H�󤺤����
                        }
                    }
                    String COMP_ID = theEP_B30010.getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);
                    String ERR_MSG = theRZ_S00300.createRecordByDIV(EVENT_ID, "EP", SYS_DT, recList, titleList, dataList, COMP_ID);

                    //���~�B�zC�o��
                    if (ERR_MSG.length() != 0) {
                        ErrorHandler(bc, "�H�e�q�����~", ERR_MSG);
                    }
                }

            });

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal(e.getMessage(), e);
        } finally {
            bc.writeCounter();
            bc.writeErrorLog();

            int batchConstructorExitCode = bc.getExitCode();
            if (batchConstructorExitCode != OK) {
                setExitCode(batchConstructorExitCode);
            }

            printExitCode(getExitCode()); //�^�ǵ� Control_M ���T���N�X , �{���פ�
        }
    }

    /**
     * ���~�B�z
     * @param bc BatchConstructor
     * @param message �T������(MESSAGE)
     * @param memo �K�n(MEMO)
     * @throws Exception �ҥ~
     */
    private void ErrorHandler(BatchConstructor bc, String message, String memo) throws Exception {
        bc.addErrorLog(message, memo);
        setExitCode(ERROR);
        if (bc.getAllCountTypeAndNumber().get(ERROR_COUNT) == null) {
            bc.createCountType(ERROR_COUNT);
        }
        bc.addCountNumber(ERROR_COUNT, 1);
        throw new Exception();
    }

    /**
     * �N���B��3��@�r���A�p��2��
     * @param AMT BigDecimal
     * @return amt String
     */
    private String formaterAMTNumber(BigDecimal AMT) throws ModuleException {

        NumberFormat formatter = new DecimalFormat("#,##0.00");
        String amt = "";
        try {
            amt = formatter.format(AMT);
        } catch (Exception e) {
            log.fatal("��������B�z�A�^�Ǥ@�ӪŭȦ^�h", e);
        }
        return amt;
    }
}
