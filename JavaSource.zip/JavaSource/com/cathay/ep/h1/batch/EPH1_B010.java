package com.cathay.ep.h1.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.BatchConstructor.Options;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.rz.s0.module.RZ_S00300;
import com.cathay.rz.t0.module.RZ_T0Z001;
import com.cathay.rz.vo.DTRZZ020;
import com.cathay.rz.z0.module.RZ_Z0Z002;
import com.cathay.util.FileStoreUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.DataSet;

/**
 * 
 * <pre>
 * Date    Version Description Author
 * 2013/11/04  1.0 Created ������
 * 2018/02/01  �t�X��ؽվ� ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �����T���q���B�z
 * �{���W��    EPH1_B010
 * �@�~�覡    BATCH
 * ���n����    �Ƶ{�����ɮ�
 * �w����ƶq   5000 (�̤j��)
 * �@�~�W��    JAEPDH010
 * �~�ȧO EP
 * ���t�ΦW��   H1
 * �B�z�g��    ��
 * ����B�z���  3000
 * 
 * [20181105] Modified �H�H���~�B�z
 * </pre>
 * @author �¶��� 
 * @since 2014/4/10
 */
@SuppressWarnings("unchecked")
public class EPH1_B010 extends EP_BatchBean {

    private static final String SQL_query_001 = "com.cathay.ep.h1.batch.EPH1_B010.SQL_query_001";

    private static final String countName_executeMethodTatal = "Ū��Z200��Ƶ���";

    private static final String countName_executeMethodSuccess = "������Z200��Ƶ���";

    /**List��Ƥ�����*/
    private static final int createTextFileBatchCount = 2000;

    /**�N�X��Ƭd�߼Ҳ�*/
    private RZ_Z0Z002 theRZ_Z0Z002 = new RZ_Z0Z002();

    private StringBuilder sbf = new StringBuilder();

    /** �{���W�� */
    private String PROGRAM;

    /** ����g�� */
    private String PERIOD;

    /** �@�~�W�� */
    private String JOB_NAME;

    protected Logger log;

    public EPH1_B010() {
        Class theClass = getClass();
        PROGRAM = theClass.getSimpleName();
        JOB_NAME = "JAEPDH010";
        PERIOD = "��";
        log = Logger.getLogger(theClass);
    }

    /**
     * ���o�d�ߦ~��
     * @param QRY_YM  String  �d�ߦ~��
     */
    private String getQryYM() {
        Calendar calendar = Calendar.getInstance();

        SimpleDateFormat df = new SimpleDateFormat("yyyyMM");
        return df.format(calendar.getTime());
    }

    public void execute(String[] args) throws Exception {

        final BatchConstructor bc = new BatchConstructor(JOB_NAME, PROGRAM, PERIOD);

        Options options = bc.getOptions();
        options.setTerminated(true);//���ʥ��ѮɬO�_����

        try {

            Date SYS_DT = DATE.today();
            String qryYM = "";
            try {

                ErrorInputException eie = null;
                if (args == null || args.length == 0) {
                    throw new ErrorInputException("�ǤJ�ѼƤ��o����");
                }

                if (args.length > 0 && StringUtils.isBlank(args[0])) {
                    eie = this.getErrorInputException(eie, "�ƥ�N��(EVENT_ID)���o����");
                }
                if (args.length > 1 && StringUtils.isBlank(args[1])) {
                    eie = this.getErrorInputException(eie, "�����q�O(SUB_CPY_ID)���o����");
                }

                if (args.length > 2 && StringUtils.isNotBlank(args[2])) {
                    qryYM = args[2];
                } else {
                    qryYM = getQryYM();
                }

                if (eie != null) {
                    throw eie;
                }

            } catch (Exception e) {
                setExitCode(ERROR);
                String memo = "�Ѽƿ��~";
                log.fatal(memo, e);
                bc.addErrorLog(memo, e);
                bc.writeErrorLog();
                return;
            }

            final String EVENT_ID = args[0];
            final String SUB_CPY_ID = args[1];

            sbf.append("�ǤJ�ѼơG");
            STRING.newLine(sbf);
            sbf.append("�ƥ�N��(EVENT_ID)��").append(EVENT_ID);
            STRING.newLine(sbf);
            sbf.append("�����q�O(SUB_CPY_ID)��").append(SUB_CPY_ID);
            log.fatal(sbf.toString());
            sbf.setLength(0);

            DataSet ds = Transaction.getDataSet();
            List<Map> methodList;
            try {
                ds.clear();
                ds.setField("EVENT_ID", EVENT_ID);
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                methodList = VOTool.findToMaps(ds, SQL_query_001);
            } catch (DataNotFoundException dnfe) {
                setExitCode(ERROR);
                String memo = "�d���ɮײ��ͳ]�w��(DTEPZ200)�d�L���";
                log.fatal(memo, dnfe);
                bc.addErrorLog(memo, dnfe);
                bc.writeErrorLog();
                return;

            } catch (Exception e) {
                setExitCode(ERROR);
                String memo = "�d���ɮײ��ͳ]�w��(DTEPZ200)�o�Ϳ��~";
                log.fatal(memo, e);

                bc.addErrorLog(memo, e);
                bc.writeErrorLog();
                return;
            }

            final Map<String, List<String>> sFiles = new HashMap<String, List<String>>();//����
            int executeMethodSuccessCount = 0;
            boolean hasEmail = false;//�O�_��Email��
            try {

                for (Map map : methodList) {

                    final Map z200 = map;
                    map.put("QRY_YM", qryYM);
                    final String MTD_ID = MapUtils.getString(z200, "MTD_ID");//method �W��
                    final String PCS_TP = MapUtils.getString(z200, "PCS_TP");
                    final String FELD_NO = MapUtils.getString(z200, "FELD_NO", "");

                    if ("2".equals(PCS_TP)) {
                        hasEmail = true;
                    }

                    if (MTD_ID == null) {
                        setExitCode(ERROR);
                        String memo = "��k�w�q���~";
                        log.fatal(memo);
                        bc.addErrorLog(memo, memo);
                        return;
                    }

                    final String zSUB_CPY_ID = MapUtils.getString(z200, "SUB_CPY_ID");

                    String judgeMTD_ID = MTD_ID.toLowerCase();

                    if (judgeMTD_ID.endsWith("list")) {//��p�g����
                        try {

                            //��X��Ƴ]�w
                            bc.createCountType(FELD_NO);

                            //���o�n�I�s����class
                            Class theClass = getClassName(z200);

                            //���o�n�I�s����method
                            Method CALL_METHOD = theClass.getMethod(MTD_ID, Map.class);

                            //�I�s�Ҳ� ���o��X��Ƥ��e list
                            try {
                                List<Map> result = (List<Map>) CALL_METHOD.invoke(theClass.newInstance(), z200);
                                int total = result.size();
                                bc.addCountNumber(FELD_NO, total);

                                //���ͪ���奻
                                String FILE_ID = createTxtFile(SUB_CPY_ID, EVENT_ID, z200, result);
                                if ("2".equals(PCS_TP)) {
                                    //�������
                                    List<String> lFile;
                                    if (sFiles.containsKey(zSUB_CPY_ID)) {
                                        lFile = sFiles.get(zSUB_CPY_ID);
                                    } else {
                                        lFile = new ArrayList<String>();
                                        sFiles.put(zSUB_CPY_ID, lFile);
                                    }
                                    lFile.add(FILE_ID);
                                }
                            } catch (InvocationTargetException ite) {
                                if (ite.getCause() instanceof DataNotFoundException) {
                                    log.fatal("�d�L���,FELD_NO:" + FELD_NO, ite.getCause());
                                } else {
                                    throw ite;
                                }
                            }

                        } catch (Exception e) {
                            setExitCode(ERROR);
                            sbf.append("�d��").append(FELD_NO).append("�o�Ϳ��~");
                            String memo = sbf.toString();
                            sbf.setLength(0);
                            log.fatal(memo, e);
                            bc.addErrorLog(memo, e);
                            throw e;

                        } finally {
                            bc.writeErrorLog();
                            bc.writeCounter();
                            bc.clearCounter();
                        }

                        executeMethodSuccessCount++;

                    } else if (judgeMTD_ID.endsWith("bqds")) {//��p�g����

                        final StringBuilder textContent = new StringBuilder();

                        //�I�s�Ҳ� ���o��X��Ƥ��e Bqds
                        bc.execute(new BatchConstructor.DataBaseHandler() {

                            private boolean isFirstRowData = true;

                            BufferedWriter bw;

                            String FILE_ID;

                            List<DTRZZ020> fldLists;

                            @Override
                            protected boolean firstProcess() throws Exception {

                                //��Ƭ���
                                bc.createCountType(FELD_NO);

                                try {

                                    String fileName = getFileName(z200);
                                    Map uploadMap = uploadFile(SUB_CPY_ID, PCS_TP, EVENT_ID, fileName);

                                    File serverfile = (File) uploadMap.get("targetFile");
                                    log.fatal("########�ɮפW�Ǹ��|:" + serverfile.getPath());
                                    FILE_ID = MapUtils.getString(uploadMap, "FILE_ID");
                                    bw = EncodingHelper.getBufferedWriter(serverfile);

                                    //���o��X�ɮ�
                                    fldLists = theRZ_Z0Z002.getCodelistAll("EP", MapUtils.getString(z200, "FELD_NO"));

                                    //���Y
                                    if ("1".equals(MapUtils.getString(z200, "HEAD"))) {

                                        for (DTRZZ020 fld : fldLists) {
                                            if (textContent.length() > 0) {
                                                textContent.append(",");
                                            }
                                            textContent.append(fld.getFELD_NAME());
                                        }

                                        if (textContent.length() > 0) {
                                            bw.write(textContent.toString());
                                            bw.flush();
                                            textContent.setLength(0);
                                            isFirstRowData = false;
                                        }
                                    }

                                    return true;
                                } catch (Exception e) {
                                    try {
                                        bc.addErrorLog("", e);
                                    } catch (ModuleException me) {
                                        log.fatal("", me);
                                    }
                                    setExitCode(ERROR);
                                    throw e;
                                }

                            }

                            @Override
                            protected boolean searchProcess(BatchQueryDataSet bqds) throws Exception {

                                try {

                                    //���o�n�I�s����class
                                    Class theClass = getClassName(z200);

                                    //���o�n�I�s����method
                                    Method CALL_METHOD = theClass.getMethod(MTD_ID, new Class[] { Map.class, BatchQueryDataSet.class });

                                    //����d��
                                    String sql = (String) CALL_METHOD.invoke(theClass.newInstance(), new Object[] { z200, bqds });

                                    bqds.searchAndRetrieve(sql);

                                } catch (Exception e) {
                                    log.fatal("", e);
                                    setExitCode(ERROR);
                                    throw e;
                                }

                                int total = bqds.getTotalCount();
                                //                              �d�߷����ơA�i��S��ơA������~                                
                                //                                if (total == 0) {
                                //                                    log.fatal("�d�L���");//�d�L��Ƶ�����,���{������
                                //                                    throw new DataNotFoundException("�妸�d�߬d�L���");
                                //                                }
                                //��Ƭ���
                                bc.addCountNumber(FELD_NO, total);
                                return true;
                            }

                            @Override
                            protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {

                                if (isFirstRowData) {
                                    isFirstRowData = false;
                                } else {
                                    STRING.newLine(textContent);
                                }

                                int firstChar = 0;
                                for (DTRZZ020 fld : fldLists) {
                                    String fieldValue = getFieldValue(bqds, fld.getFELD_CONT());
                                    if (firstChar > 0) {
                                        textContent.append(",");
                                    }
                                    textContent.append(fieldValue);
                                    firstChar++;
                                }
                                firstChar = 0;

                            }

                            @Override
                            protected void executeBatchProcess() throws Exception {
                                try {
                                    bw.write(textContent.toString());
                                } finally {
                                    textContent.setLength(0);
                                }
                            }

                            @Override
                            protected void lastProcess() throws Exception {
                                if ("2".equals(PCS_TP)) {
                                    //�������
                                    List<String> lFile;
                                    if (sFiles.containsKey(zSUB_CPY_ID)) {
                                        lFile = sFiles.get(zSUB_CPY_ID);
                                    } else {
                                        lFile = new ArrayList<String>();
                                        sFiles.put(zSUB_CPY_ID, lFile);
                                    }
                                    lFile.add(FILE_ID);
                                }

                            }

                            @Override
                            protected void finallyProcess() {

                                if (bw != null) {
                                    try {
                                        bw.close();
                                    } catch (IOException e) {
                                        log.fatal(e);
                                    }

                                }
                            }

                        });

                        executeMethodSuccessCount++;
                    } else {
                        setExitCode(ERROR);
                        String memo = "��k�w�q���~";
                        log.fatal(memo);
                        bc.addErrorLog(memo, memo);
                        bc.writeErrorLog();
                        return;
                    }

                }

            } finally {
                bc.createCountType(countName_executeMethodTatal);
                bc.createCountType(countName_executeMethodSuccess);
                bc.addCountNumber(countName_executeMethodTatal, methodList.size());
                bc.addCountNumber(countName_executeMethodSuccess, executeMethodSuccessCount);
                bc.writeCounter();
            }

            //���o�q����H
            if (hasEmail) {

                RZ_S00300 theRZ_S00300 = new RZ_S00300();
                EP_B30010 theEP_B30010 = new EP_B30010();
                RZ_T0Z001 theRZ_T0Z001 = new RZ_T0Z001();
                String COMP_ID = theEP_B30010.getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);

                Map<String, List<DTEPZ103>> nMap;
                try {
                    nMap = new EP_Z10030().getMailList(SUB_CPY_ID, EVENT_ID);
                } catch (DataNotFoundException dnfe) {
                    log.fatal("�d�L���o�q����H���", dnfe);
                    nMap = MapUtils.EMPTY_MAP;

                }

                //[20181105] Modified �H�H���~�B�z
                Iterator entries = nMap.entrySet().iterator();
                while (entries.hasNext()) {
                    Entry thisEntry = (Entry) entries.next();
                    String theSubCpyID = (String) thisEntry.getKey();

                    //���o�H��q����H
                    List<Map> recList = getMailList(nMap.get(theSubCpyID), EVENT_ID);

                    //���o�����q����M��
                    List<String> lFiles = sFiles.get(theSubCpyID);
                    List<Map> emptyList = new ArrayList();
                    String ERR_MSG;
                    if (lFiles == null || lFiles.isEmpty()) { //�H�o�q�����t����
                        ERR_MSG = theRZ_S00300.createRecordByDIV(EVENT_ID, "EP", SYS_DT, recList, emptyList, emptyList, COMP_ID);
                    } else {//�H�o�q���t����
                        String[] fileIDs = lFiles.toArray(new String[lFiles.size()]);
                        ERR_MSG = theRZ_S00300.createRecordByDIV(EVENT_ID, "EP", SYS_DT, recList, "�@", fileIDs, COMP_ID);
                    }

                    if (StringUtils.isNotBlank(ERR_MSG)) {
                        //20181123:���ױH�H���\�Υ��ѳ��N����R��,�קK�ɮפ@���d�bserver
                        if (sFiles != null && !sFiles.isEmpty()) {
                            for (String key : sFiles.keySet()) {
                                List<String> fileIDs = sFiles.get(key);
                                for (String fileID : fileIDs) {
                                    theRZ_T0Z001.removeFileByDiv(fileID, COMP_ID);
                                }
                            }
                        }

                        throw new ModuleException("�H�H���~:" + ERR_MSG);
                    }
                }
                
                //20181123:���ױH�H���\�Υ��ѳ��N����R��,�קK�ɮפ@���d�bserver
                if (sFiles != null && !sFiles.isEmpty()) {
                    for (String key : sFiles.keySet()) {
                        List<String> fileIDs = sFiles.get(key);
                        for (String fileID : fileIDs) {
                            theRZ_T0Z001.removeFileByDiv(fileID, COMP_ID);
                        }
                    }
                }

            }

        } catch (Exception e) {
            setExitCode(ERROR);
            log.fatal("���榳�~", e);

        } finally {

            int batchConstructorExitCode = bc.getExitCode();
            if (batchConstructorExitCode != OK) {
                setExitCode(batchConstructorExitCode);
            }

            printExitCode(getExitCode());
        }
    }

    /**
     * ������
     * @param bqds
     * @param fieldNo
     * @return
     */
    protected String getFieldValue(BatchQueryDataSet bqds, String fieldNo) {
        return ObjectUtils.toString(bqds.getField(fieldNo), "");
    }

    /**
     * ���ͪ����r��
     * @param EVENT_ID
     * @param z200
     * @param result
     * @return
     * @throws Exception
     */
    private String createTxtFile(String SUB_CPY_ID, String EVENT_ID, Map z200, List<Map> result) throws Exception {

        int procCount = 0;

        //���o��X�ɮצW��
        String fileName = getFileName(z200);

        String PCS_TP = MapUtils.getString(z200, "PCS_TP");
        Map uploadMap = this.uploadFile(SUB_CPY_ID, PCS_TP, EVENT_ID, fileName);

        File serverfile = (File) uploadMap.get("targetFile");
        String FILE_ID = MapUtils.getString(uploadMap, "FILE_ID");
        log.fatal("########�ɮפW�Ǹ��|:" + serverfile.getPath());

        List<DTRZZ020> fldLists = new RZ_Z0Z002().getCodelistAll("EP", MapUtils.getString(z200, "FELD_NO"));

        StringBuffer sb = new StringBuffer();
        BufferedWriter bw = null;

        boolean isFirstRowData = true;
        try {
            bw = EncodingHelper.getBufferedWriter(serverfile);

            if ("1".equals(MapUtils.getString(z200, "HEAD"))) {

                for (DTRZZ020 fld : fldLists) {
                    if (sb.length() > 0) {
                        sb.append(',');
                    }
                    sb.append(fld.getFELD_NAME());
                }

                if (sb.length() > 0) {
                    bw.write(sb.toString());
                    bw.flush();
                    sb.setLength(0);
                    isFirstRowData = false;
                }

            }

            for (Map data : result) {

                if (!isFirstRowData) {
                    STRING.newLine(sb);
                } else {
                    isFirstRowData = false;
                }

                //�C�C���e
                int firstChar = 0;
                for (DTRZZ020 fld : fldLists) {
                    if (firstChar > 0) {
                        sb.append(',');
                    }
                    firstChar++;
                    sb.append(MapUtils.getString(data, fld.getFELD_CONT(), ""));

                }
                firstChar = 0;

                procCount++;
                if (procCount == createTextFileBatchCount) {//�C��B�z�g�X
                    try {
                        bw.write(sb.toString());
                        bw.flush();
                        sb.setLength(0);
                    } finally {
                        procCount = 0;
                    }

                }

            }

            //�̫�@��
            if (procCount > 0) {
                try {
                    bw.write(sb.toString());
                    bw.flush();
                    sb.setLength(0);
                } finally {
                    procCount = 0;
                }
            }

        } finally {
            sb.setLength(0);
            if (bw != null) {
                bw.close();
            }
        }

        return FILE_ID;

    }

    /**
     * ���o�����ɦW
     * @param z200
     * @return
     */
    private String getFileName(Map z200) {

        //���o��X�ɮ�
        String filename = MapUtils.getString(z200, "FILE_NAME", "");
        if (filename.indexOf("{EEEMMDD}") != -1) {
            filename = filename.replace("{EEEMMDD}", DATE.getROCDate());
        } else if (filename.indexOf("{EEEMM}") != -1) {
            Calendar calendar = Calendar.getInstance();
            filename = filename.replace("{EEEMM}", DATE.getROCYearAndMonth(new SimpleDateFormat("yyyyMMdd").format(calendar.getTime())));
        } else if (filename.indexOf("{PREEEMM}") != -1) {
            filename = filename.replace("{PREEEMM}", DATE.getROCYearAndMonth(DATE
                    .getYearAndMonth(DATE.addDate(DATE.getY2KDate(), 0, -1, 0))));

        }

        return filename;

    }

    /**
     * ���o�H��q��
     * @param z200
     * @param EVENT_ID
     * @return
     * @throws ClassNotFoundException 
     */
    private Class getClassName(Map z200) throws ClassNotFoundException {

        StringBuffer classFullName = new StringBuffer();

        String CLASS = MapUtils.getString(z200, "MOD_ID");
        String CLASS_lower = CLASS.replace("_", "").toLowerCase();
        //�t�ΧO
        classFullName.append("com.cathay.").append(CLASS_lower.substring(0, 2));
        //�l�t��
        classFullName.append('.').append(CLASS_lower.substring(2, 4));
        //�ҲզW��
        classFullName.append(".batch.").append(CLASS);

        Class theClass = Class.forName(classFullName.toString());

        classFullName.setLength(0);

        return theClass;
    }

    /**
     * ���o�H��q��
     * @param mailList
     * @param EVENT_ID
     * @return
     */
    private List<Map> getMailList(List<DTEPZ103> mailList, String EVENT_ID) {
        List<Map> recList = new ArrayList();
        for (DTEPZ103 z103 : mailList) {
            Map recepit = new HashMap();
            recepit.put("EVENT_ID", EVENT_ID);
            recepit.put("USER_ID", z103.getID());
            recepit.put("USER_EMAIL", z103.getEMAIL());
            recList.add(recepit);
        }

        return recList;

    }

    /**
     * �s�ؤW�Ǫ����ɮ�
     * @param PCS_TP
     * @param EVENT_ID
     * @param FILE_NAME
     * @return
     * @throws Exception
     */
    private Map uploadFile(String SUB_CPY_ID, String PCS_TP, String EVENT_ID, String FILE_NAME) throws Exception {

        log.fatal("########�W���ɦW:" + FILE_NAME);
        StringBuilder data = new StringBuilder();
        Map uploadMap;
        if ("1".equals(PCS_TP)) {
            uploadMap = new HashMap();
            data.append(FileStoreUtil.getFTPH2URoot()).append(File.separator).append("DBEP");
            String dir = data.toString();
            data.append(File.separator).append(FILE_NAME);
            String filePath = data.toString();
            data.setLength(0);
            File dirFile = new File(dir);
            if (!dirFile.exists()) {
                dirFile.mkdirs();
            }
            File newFile = new File(filePath);
            uploadMap.put("targetFile", newFile);

        } else if ("2".equals(PCS_TP)) {
            //���� FILE_ID
            String COMP_ID = new EP_B30010().getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);
            uploadMap = new RZ_T0Z001().uploadFileForBatchByDiv(EVENT_ID, "txt", PROGRAM, PROGRAM, FILE_NAME, FILE_NAME, COMP_ID);
            log.fatal("########�ɮ�FILE_ID:" + MapUtils.getString(uploadMap, "FILE_ID"));
        } else {
            data.append("PCS_TP = ").append(PCS_TP).append("�A����1��2");
            String msg = data.toString();
            data.setLength(0);
            throw new ErrorInputException(msg);
        }

        return uploadMap;
    }

    /**
     * ��wEIE���� 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}