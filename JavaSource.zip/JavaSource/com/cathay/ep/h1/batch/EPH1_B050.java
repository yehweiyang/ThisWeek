package com.cathay.ep.h1.batch;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.ds.z0.module.DS_Z01000;
import com.cathay.ep.a3.module.EP_A30060;
import com.cathay.ep.vo.DTEPZ002;
import com.cathay.ep.z1.module.EP_Z1Z002;
import com.igsapp.db.BatchQueryDataSet;

/** 
 * <pre>
 * DATE    Description Author
 *   2013/11/26  Created ������
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ���{�ﱵ�ɧ妸
 * �{���W��    EPH1_B050 extend EPH1_B010
 * �@�~�覡    BATCH
 * ���n����    �Ƶ{�����ɮ�
 * �w����ƶq   5000 (�̤j��)
 * �@�~�W��    JAEPDH010
 * �~�ȧO EP
 * ���t�ΦW��   H1
 * �B�z�g��    ��
 * ����B�z���  3000
 * 
 * </pre>
 * @author �¶��� 
 * @since 2014/4/16  
 * [190125] �վ�PMD(Do not declare variable as static when use HashMap.)
 */
@SuppressWarnings("unchecked")
public class EPH1_B050 extends EPH1_B010 {

    private static final Logger log = Logger.getLogger(EPH1_B050.class);

    private static final String SQL_queryEPA01Bqds_001 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPA01Bqds_001";

    private static final String SQL_queryEPA02Bqds_001 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPA02Bqds_001";

    private static final String SQL_queryEPA03Bqds_001 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPA03Bqds_001";

    private static final String SQL_queryEPA03RsvBqds_002 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPA03RsvBqds_002";

    private static final String SQL_queryEPA04Bqds_001 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPA04Bqds_001";

    private static final String SQL_queryEPA04RsvBqds_002 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPA04RsvBqds_002";

    private static final String SQL_queryEPB01Bqds_001 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPB01Bqds_001";

    private static final String SQL_queryEPB02Bqds_001 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPB02Bqds_001";

    private static final String SQL_queryEPB03Bqds_001 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPB03Bqds_001";

    private DS_Z01000 theDS_Z0100 = new DS_Z01000();

    private Map<String, String> zipCodeMap = new HashMap<String, String>();

    private static final String SQL_queryEPD01Bqds_001 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPD01Bqds_001";

    //190125�G�վ�PMD(Do not declare variable as static when use HashMap.)
    private static Map<String, String> chgIDMap = Collections.synchronizedMap(new HashMap<String, String>());

    private static final String SQL_queryEPC02Bqds_001 = "com.cathay.ep.h1.batch.EPH1_B050.SQL_queryEPC02Bqds_001";

    static {
        EP_Z1Z002 Z002 = new EP_Z1Z002();

        List<DTEPZ002> A101_2List;
        try {
            A101_2List = Z002.getSysSetList("EPA1_B910", "chgMap1", "", "00");
            for (DTEPZ002 Z002bo : A101_2List) {
                chgIDMap.put(Z002bo.getVALUE2(), Z002bo.getVALUE1());
            }
        } catch (ModuleException e) {
            log.fatal(e);
        }

    }

    /**
     * Ū���j�Ӱ򥻬���
     * @param reqMap
     * @param bqds
     * @return
     */
    public String queryEPA01Bqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPA01Bqds_001;

    }

    /**
     * Ū���j�ӼӼh����
     * @param reqMap
     * @param bqds
     * @return
     */
    public String queryEPA02Bqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPA02Bqds_001;

    }

    /**
     * Ū���j�ӫǧO����
     * @param reqMap
     * @param bqds
     * @return
     */
    public String queryEPA03Bqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPA03Bqds_001;

    }

    public String queryEPA03RsvBqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPA03RsvBqds_002;

    }

    /**
     * Ū���j�Ө������
     * @param reqMap
     * @param bqds
     * @return
     */
    public String queryEPA04Bqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPA04Bqds_001;

    }

    public String queryEPA04RsvBqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPA04RsvBqds_002;

    }

    /**
     * Ū�������򥻸���ɿ�
     * @param reqMap
     * @param bqds
     * @return
     */
    public String queryEPB01Bqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPB01Bqds_001;
    }

    /**
     * Ū�������Ȥ���
     * @param reqMap
     * @param bqds
     * @return
     */
    public String queryEPB02Bqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPB02Bqds_001;

    }

    /**
     * Ū�������Ȥ�q�T���
     * @param reqMap
     * @param bqds
     * @return
     */
    public String queryEPB03Bqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPB03Bqds_001;

    }

    /**
     * Ū�������Ȥ�q�T���
     * @param reqMap
     * @param bqds
     * @return
     */
    public String queryEPD01Bqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("QRY_YM", this.getQryYM(reqMap));
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPD01Bqds_001;

    }

    /**
     * Ū���������
     * @param reqMap
     * @param bqds
     * @return
     */
    public String queryEPC02Bqds(Map reqMap, BatchQueryDataSet bqds) {
        bqds.setField("QRY_YM", this.getQryYM(reqMap));
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        return SQL_queryEPC02Bqds_001;

    }

    /**
     *  Ū���������J���
     * @param reqMap
     * @return rtnList List<Map>   ���믲�����J
     */
    public List<Map> queryC08List(Map reqMap) throws ModuleException, SQLException {
        String QRY_YM = this.getQryYM(reqMap);
        String QRY_YM_ROC = DATE.getROCYearAndMonth(QRY_YM);
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        EP_A30060 theEP_A30060 = new EP_A30060();
        List<Map> divList = theEP_A30060.queryDivList(SUB_CPY_ID);
        List<Map> rtnList = new ArrayList();
        for (Map map : divList) {
            List<Map> recList = theEP_A30060.queryList("1", SUB_CPY_ID, QRY_YM, MapUtils.getString(map, "CLC_DIV_NO"));
            rtnList.addAll(recList);
        }

        for (Map data : rtnList) {
            data.put("CERCVYM", QRY_YM_ROC);
            String ceclcdv = MapUtils.getString(data, "CLC_DIV_NO", "");
            data.put("CLC_DIV_NO", FieldOptionList.getName("EP", "CECLCDV", ceclcdv));
        }
        return rtnList;
    }

    /**
     * ���o�d�ߦ~��
     * @param QRY_YM  String  �d�ߦ~��
     */
    private String getQryYM(Map map) {
        if (map.containsKey("QRY_YM")) {
            return MapUtils.getString(map, "QRY_YM");

        } else {
            Calendar calendar = Calendar.getInstance();

            SimpleDateFormat df = new SimpleDateFormat("yyyyMM");
            return df.format(calendar.getTime());
        }
    }

    @Override
    protected String getFieldValue(BatchQueryDataSet bqds, String fieldNo) {

        List timestamp_dateList = Arrays.asList(new String[] { "CRT_DATE", "BLD_STR_DATE", "BLD_END_DATE", "RNT_STR_DATE", "RNT_END_DATE",
                "NEXT_ADJ_DATE", "NEXT_PAY_DATE", "PMI_S_DATE", "PMI_E_DATE", "ACNT_DATE", "PAY_S_DATE", "PAY_E_DATE", "EXT_DATE",
                "PRP_S_DATE", "TURN_ACNT_DATE", "BDEBT_ACNT_DATE" });
        String filedValue;
        fieldNo = fieldNo.trim();

        if ("BLD_ADDR".equals(fieldNo)) {//�����j�ӦW��
            String BLD_ADDR = ObjectUtils.toString(bqds.getField("BLD_ADDR"));
            filedValue = BLD_ADDR.replaceAll(",", "�A");
        } else if ("USR_NAME".equals(fieldNo)) {//�����j�ӦW��
            String USR_NAME = ObjectUtils.toString(bqds.getField("USR_NAME"));
            filedValue = USR_NAME.replaceAll(",", "�A");
        } else if ("CEADJPT".equals(fieldNo)) {//�կ���v   
            filedValue = "0";
        } else if ("DCT_TYPE".equals(fieldNo)) {
            String dctType = ObjectUtils.toString(bqds.getField("DCT_TYPE"));
            if ("1".equals(dctType)) {
                filedValue = "Y";
            } else {
                filedValue = "N";
            }

        } else if ("COMP_ZIP_CODE_NM".equals(fieldNo)) {//COMP_ZIP_CODE_NM  ���q�a�}--�ϰ줤��              
            String zipCode = ObjectUtils.toString(bqds.getField("COMP_ZIP_CODE"));
            if (StringUtils.isNotBlank(zipCode)) {
                if (zipCodeMap.containsKey(zipCode)) {
                    filedValue = zipCodeMap.get(zipCode);
                } else {
                    try {
                        filedValue = theDS_Z0100.getCityTown(zipCode);
                        if (STRING.doubleByteLength(filedValue) > 12) {
                            filedValue = STRING.subStringByByteArray(filedValue, 12, false);
                        }
                        zipCodeMap.put(zipCode, filedValue);
                    } catch (Exception e) {
                        log.fatal("���o�ϰ줤�妳��", e);
                        filedValue = zipCode;
                    }
                }

            } else {
                filedValue = "";
            }

        } else if ("COMP_ADDR".equals(fieldNo)) {//���q�n�O�a�}
            String COMP_ADDR = ObjectUtils.toString(bqds.getField("COMP_ADDR"));
            filedValue = COMP_ADDR.replaceAll(",", "�A");
        } else if ("CONT_ZIP_CODE_NM".equals(fieldNo)) {//CONT_ZIP_CODE_NM  �q�T�a�}--�ϰ줤��     
            String zipCode = ObjectUtils.toString(bqds.getField("CONT_ZIP_CODE"));
            if (StringUtils.isNotBlank(zipCode)) {
                if (zipCodeMap.containsKey(zipCode)) {
                    filedValue = zipCodeMap.get(zipCode);
                } else {
                    try {
                        filedValue = theDS_Z0100.getCityTown(zipCode);
                        if (STRING.doubleByteLength(filedValue) > 12) {
                            filedValue = STRING.subStringByByteArray(filedValue, 12, false);
                        }
                        zipCodeMap.put(zipCode, filedValue);
                    } catch (Exception e) {
                        log.fatal("���o�ϰ줤�妳��", e);
                        filedValue = zipCode;
                    }
                }

            } else {
                filedValue = "";
            }
        } else if ("CONT_ADDR".equals(fieldNo)) {//�����j�ӦW��
            String CONT_ADDR = ObjectUtils.toString(bqds.getField("CONT_ADDR"));
            filedValue = CONT_ADDR.replaceAll(",", "�A");
        } else if ("CEMALCD".equals(fieldNo)) {//�l�H�N�X
            filedValue = "";
        } else if ("IS_REP_CRT".equals(fieldNo)) {
            String IS_REP_CRT = ObjectUtils.toString(bqds.getField("IS_REP_CRT"));
            if ("Y".equals(IS_REP_CRT)) {
                filedValue = "1";
            } else {
                filedValue = "0";
            }

        } else if ("MON_BRK".equals(fieldNo)) {
            String MON_BRK = ObjectUtils.toString(bqds.getField("MON_BRK"));
            if ("Y".equals(MON_BRK)) {
                filedValue = "1";
            } else {
                filedValue = "0";
            }
        } else if ("B1_TRN_KIND".equals(fieldNo)) {
            filedValue = FieldOptionList.getName("EP", "B01_CETNSKD", super.getFieldValue(bqds, fieldNo));
            //�p�G���]�w�A����X������~
        } else if ("TRN_KIND".equals(fieldNo)) {
            filedValue = FieldOptionList.getName("EP", "A_CETNSKD", super.getFieldValue(bqds, fieldNo));
            //�p�G���]�w�A����X������~
        } else if ("RNT_CHG_TRNKD".equals(fieldNo)) {
            filedValue = FieldOptionList.getName("EP", "B02_CETNSKD", super.getFieldValue(bqds, fieldNo));
            //�p�G���]�w�A����X������~
        } else if ("INT_YM".equals(fieldNo) || "RCV_YM".endsWith(fieldNo)) {
            String yyyyMM = super.getFieldValue(bqds, fieldNo);
            filedValue = DATE.getROCYearAndMonth(yyyyMM);
        } else if ("CLC_DIV_NO".equals(fieldNo)) {
            filedValue = FieldOptionList.getName("EP", "CECLCDV", super.getFieldValue(bqds, fieldNo));
        } else if (timestamp_dateList.contains(fieldNo)) {
            filedValue = super.getFieldValue(bqds, fieldNo);
            if (StringUtils.isNotEmpty(filedValue)) {
                filedValue += " 00:00:00.0000";
            }
        } else if ("ARA_CD".equals(fieldNo)) {
            filedValue = super.getFieldValue(bqds, fieldNo);
            if (StringUtils.isNotEmpty(filedValue)) {
                filedValue = filedValue.substring(2, filedValue.length());
            }
        } else if ("ADJ_UNIT_NUM".equals(fieldNo)) {//�կ���v   
            String ADJ_UNIT = super.getFieldValue(bqds, "ADJ_UNIT");

            filedValue = super.getFieldValue(bqds, fieldNo);
            if ("1".equals(ADJ_UNIT)) {
                try {
                    String RNT_TOT_AMT = super.getFieldValue(bqds, "RNT_TOT_AMT");
                    BigDecimal totAmt = new BigDecimal(RNT_TOT_AMT);
                    BigDecimal ADJ_NUM = new BigDecimal(filedValue);
                    BigDecimal ADJ_RT = ADJ_NUM.divide(totAmt, BigDecimal.ROUND_HALF_UP, 5).multiply(new BigDecimal("100")).setScale(2);
                    filedValue = ADJ_RT.toString();
                } catch (Exception e) {

                }

            }
        } else if ("CHG_ID".equals(fieldNo) || "RNT_CHG_ID".equals(fieldNo) || "BLD_USR_ID".equals(fieldNo)) { //���ʤH��
            filedValue = super.getFieldValue(bqds, fieldNo);
            filedValue = MapUtils.getString(chgIDMap, filedValue, filedValue);
            if (StringUtils.isNotEmpty(filedValue) && filedValue.length() > 8) {
                filedValue = filedValue.substring(0, 8);
            }
        } else if ("ROOM_NO".equals(fieldNo)) { //�ǧO
            filedValue = super.getFieldValue(bqds, fieldNo);
            if (StringUtils.isEmpty(filedValue)) {
                filedValue = "\"\"";
            }
        } else if ("C02_TRN_KIND".equals(fieldNo)) {
            filedValue = super.getFieldValue(bqds, fieldNo);
            int filedValue_SIZE = filedValue.length();
            if (filedValue_SIZE == 6) {
                filedValue = filedValue.substring(filedValue_SIZE - 2, filedValue_SIZE);
            } else {
                filedValue = "05";
            }
        } else if ("C02_OP_STATUS".equals(fieldNo)) {
            filedValue = super.getFieldValue(bqds, fieldNo);
            if ("40".equals(filedValue)) {
                filedValue = "A";
            } else if ("50".equals(filedValue)) {
                filedValue = "B";
            } else {
                filedValue = "";
            }
        } else {
            filedValue = super.getFieldValue(bqds, fieldNo);
        }
        return filedValue;

    }
}
