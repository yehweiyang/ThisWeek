package com.cathay.ep.h1.batch;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.c1.module.EP_C14020;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.DBException;

/** 
 * <pre>
 * DATE    Description Author
 * 2013/11/05  Created ������
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �����q���妸
 * �{���W��    EPH1_B030 extend EPH1_B010
 * �@�~�覡    BATCH
 * ���n����    �Ƶ{�����ɮ�
 * �w����ƶq   5000 (�̤j��)
 * �@�~�W��    JAEPDH010
 * �~�ȧO EP
 * ���t�ΦW��   H1
 * �B�z�g��    ��
 * ����B�z���  3000
 * </pre>
 * @author �¶��� 
 * @since 2014/4/15  
 */
@SuppressWarnings("unchecked")
public class EPH1_B030 extends EPH1_B010 {

    private static final String SQL_getRecBqds_001 = "com.cathay.ep.h1.batch.EPH1_B030.SQL_getRecBqds_001";

    private static final String SQL_getDueRecBqds_001 = "com.cathay.ep.h1.batch.EPH1_B030.SQL_getDueRecBqds_001";

    private static final String SQL_getRecRentFeeBqds_001 = "com.cathay.ep.h1.batch.EPH1_B030.SQL_getRecRentFeeBqds_001";

    private DivData theDivData = new DivData();

    private Map<String, String> divNameMap = new HashMap<String, String>();

    /**
     * Ū�������v�O��
     * @param reqMap
     * @return
     * @throws ModuleException
     * @throws ParseException
     * @throws DBException 
     */
    public List<Map> getRecRateList(Map reqMap) throws ModuleException, ParseException, DBException {

        //���o�����~�� REC_YM = �t�Χ@�~������o YYYYMM �褸�~��
        //Calendar calendar = Calendar.getInstance();
        //String REC_YM = new SimpleDateFormat("yyyyMM").format(calendar.getTime());
        String REC_YM = DATE.getYearAndMonth(DATE.addDate(DATE.getY2KDate(), 0, -1, 0));
        List<Map> recList = new EP_C14020().queryList(new BigDecimal(REC_YM), "", "A", "A", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        Map<String, Map> bldMap = new TreeMap<String, Map>();
        for (Map data : recList) {
            String bldCd = MapUtils.getString(data, "BLD_CD");
            if (bldMap.containsKey(bldCd)) {
                Map recMap = bldMap.get(bldCd);
                String date = MapUtils.getString(data, "date");
                String recDate = MapUtils.getString(recMap, "date");
                if ("10".equals(date)) {
                    recMap.put("RVRT1", getDecimalValue(data, "RVRT"));
                    recMap.put("RVMG1", getDecimalValue(data, "RVMG"));

                    recMap.put("PYRT1", getDecimalValue(data, "PYRT1"));
                    recMap.put("PYMG1", getDecimalValue(data, "PYMG1"));

                    recMap.put("RCVRT1", getDecimalValue(data, "RCVRT1"));
                } else if ("20".equals(date)) {
                    recMap.put("RVRT2", getDecimalValue(data, "RVRT"));
                    recMap.put("RVMG2", getDecimalValue(data, "RVMG"));
                    recMap.put("PYRT2", getDecimalValue(data, "PYRT2"));
                    recMap.put("PYMG2", getDecimalValue(data, "PYMG2"));
                    recMap.put("RCVRT2", getDecimalValue(data, "RCVRT2"));
                    if (date.compareTo(recDate) > 0) {
                        recMap.put("date", date);
                        recMap.put("RCVRT", getDecimalValue(data, "RCVRT2"));
                    }
                } else if ("30".equals(date)) {
                    recMap.put("RVRT3", getDecimalValue(data, "RVRT"));
                    recMap.put("RVMG3", getDecimalValue(data, "RVMG"));
                    recMap.put("PYRT3", getDecimalValue(data, "PYRT3"));
                    recMap.put("PYMG3", getDecimalValue(data, "PYMG3"));
                    recMap.put("RCVRT3", getDecimalValue(data, "RCVRT3"));
                    if (date.compareTo(recDate) > 0) {
                        recMap.put("date", date);
                        recMap.put("RCVRT", getDecimalValue(data, "RCVRT3"));
                    }
                }
            } else {
                String date = MapUtils.getString(data, "date");
                if ("10".equals(date)) {
                    data.put("RVRT1", getDecimalValue(data, "RVRT"));
                    data.put("RVMG1", getDecimalValue(data, "RVMG"));
                    data.put("PYRT1", getDecimalValue(data, "PYRT1"));
                    data.put("PYMG1", getDecimalValue(data, "PYMG1"));
                    data.put("RCVRT1", getDecimalValue(data, "RCVRT1"));
                } else if ("20".equals(date)) {
                    data.put("RVRT2", getDecimalValue(data, "RVRT"));
                    data.put("RVMG2", getDecimalValue(data, "RVMG"));
                    data.put("PYRT2", getDecimalValue(data, "PYRT2"));
                    data.put("PYMG2", getDecimalValue(data, "PYMG2"));
                    data.put("RCVRT2", getDecimalValue(data, "RCVRT2"));
                } else if ("30".equals(date)) {
                    data.put("RVRT3", getDecimalValue(data, "RVRT"));
                    data.put("RVMG3", getDecimalValue(data, "RVMG"));
                    data.put("PYRT3", getDecimalValue(data, "PYRT3"));
                    data.put("PYMG3", getDecimalValue(data, "PYMG3"));
                    data.put("RCVRT3", getDecimalValue(data, "RCVRT3"));
                }
                bldMap.put(bldCd, data);
            }
        }
        List<Map> rtnList = new ArrayList<Map>();
        for (String key : bldMap.keySet()) {
            rtnList.add(bldMap.get(key));
            log.debug("RecMap:" + bldMap.get(key));
        }

        //�d�ߺ���(1:�j�ӥN�� );�j�Ӫ��A (1:�D�B��)
        return rtnList;
    }

    private BigDecimal getDecimalValue(Map data, String fieldName) {
        BigDecimal value = new BigDecimal(MapUtils.getString(data, fieldName, "0"));
        return value;
    }

    /**
     * Ū��������������
     * @param reqMap
     * @param bqds
     * @return
     */
    public String getRecBqds(Map reqMap, BatchQueryDataSet bqds) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        Calendar cal = Calendar.getInstance();

        //���o�����~�� 
        String REC_YM = sdf.format(cal.getTime());

        // ���o�W�������~��  
        cal.add(Calendar.MONTH, -1);//��@�Ӥ�
        String LST_REC_YM = sdf.format(cal.getTime());

        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        bqds.setField("REC_YM", REC_YM);
        bqds.setField("LST_REC_YM", LST_REC_YM);

        return SQL_getRecBqds_001;
    }

    /**
     * Ū������ʦ�����
     * @param reqMap
     * @param bqds
     * @return
     */
    public String getDueRecBqds(Map reqMap, BatchQueryDataSet bqds) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        Calendar cal = Calendar.getInstance();

        // ���o�W�������~��  
        cal.add(Calendar.MONTH, -1);//��@�Ӥ�
        String LST_REC_YM = sdf.format(cal.getTime());

        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        bqds.setField("LST_REC_YM", LST_REC_YM);

        return SQL_getDueRecBqds_001;
    }

    /**
     * Ū����L������������
     * @param reqMap
     * @param bqds
     * @return
     */
    public String getRecRentBqds(Map reqMap, BatchQueryDataSet bqds) {

        return getRecRentFeeBqds(bqds, reqMap, "1");

    }

    /**
     * Ū����L�����޲z�O����
     * @param reqMap
     * @param bqds
     * @return
     */
    public String getRecFeeBqds(Map reqMap, BatchQueryDataSet bqds) {

        return getRecRentFeeBqds(bqds, reqMap, "2");

    }

    @Override
    protected String getFieldValue(BatchQueryDataSet bqds, String fieldNo) {

        String filedValue = super.getFieldValue(bqds, fieldNo);
        String DATA_TYPE = ObjectUtils.toString(bqds.getField("DATA_TYPE"));
        if ("PAY_KIND_NM".equals(fieldNo)) {
            filedValue = FieldOptionList.getName("EP", "PAY_KIND", filedValue);

        } else if ("DATA_TYPE_NM".equals(fieldNo)) {
            if ("1".equals(DATA_TYPE)) {
                filedValue = "����";
            } else if ("2".equals(DATA_TYPE)) {
                filedValue = "�w�P�b";
            }

        } else if ("DIV_NO_NM".equals(fieldNo)) {

            String divName;
            if (divNameMap.containsKey(filedValue)) {
                divName = divNameMap.get(filedValue);
            } else {
                try {
                    //divName = theDivData.getUnit4ShortName(filedValue);
                    //2018-03-13 �վ���W�٧���Ҳ�
                    divName = new EP_A10010().getDivName(filedValue, ObjectUtils.toString(bqds.getField("SUB_CPY_ID")));
                    divNameMap.put(filedValue, divName);
                } catch (ErrorInputException eie) {
                    log.fatal("���o���W�٥���", eie);
                    divName = filedValue;
                } catch (SQLException sqle) {
                    log.fatal("���o���W�٥���", sqle);
                    divName = filedValue;
                }

            }
            filedValue = divName;

        }

        return filedValue;

    }

    /**
     * Ū����L���������޲z�O����
     * @param bqds
     * @param reqMap
     * @param QRY_TYPE
     * @return
     */
    private String getRecRentFeeBqds(BatchQueryDataSet bqds, Map reqMap, String QRY_TYPE) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        Calendar cal = Calendar.getInstance();

        //���o�U�������~�� 
        //cal.add(Calendar.MONTH, 1);//�[�@�Ӥ�
        int NEXT_YR = cal.get(Calendar.YEAR);
        int NEXT_MON = cal.get(Calendar.MONTH) + 1;

        //���o�����~�� -1
        cal.add(Calendar.MONTH, -1);
        String REC_YM = sdf.format(cal.getTime());
        int CURR_YR = cal.get(Calendar.YEAR);
        int CURR_MON = cal.get(Calendar.MONTH) + 1;

        bqds.setField("REC_YM", REC_YM);
        bqds.setField("SUB_CPY_ID", MapUtils.getString(reqMap, "SUB_CPY_ID"));
        String DIV_NO = MapUtils.getString(reqMap, "DIV_NO");
        if (StringUtils.isNotEmpty(DIV_NO)) {
            bqds.setField("DIV_NO", DIV_NO);
        }

        if ("1".equals(QRY_TYPE)) {
            bqds.setField("QRY_TYPE_1", "1");
        } else if ("2".equals(QRY_TYPE)) {
            bqds.setField("QRY_TYPE_2", "1");
        }
        bqds.setField("CURR_YR", CURR_YR);
        bqds.setField("CURR_MON", CURR_MON);
        bqds.setField("NEXT_YR", NEXT_YR);
        bqds.setField("NEXT_MON", NEXT_MON);

        return SQL_getRecRentFeeBqds_001;

    }

}
