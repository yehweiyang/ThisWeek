package com.cathay.ep.h1.module;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.rpt.RptUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2013/9/12   1.0 �s�W  �\�a�s
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �����v�έp�d�߼Ҳ�
 * �{���W��    EP_H10030 
 * ���n����    �d��DTEPC301_ú�O�������
 * </pre>
 * @author �x�Ԫ�
 * @since 2014/1/15
 */
@SuppressWarnings("unchecked")
public class EP_H10030 {

    private static final Logger log = Logger.getLogger(EP_H10030.class);

    private static final boolean isDebug = log.isDebugEnabled();

    private static final String SQL_queryListA_001 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListA_001";

    private static final String SQL_queryListA_002 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListA_002";

    //    private static final String SQL_queryListA_003 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListA_003";
    //
    private static final String SQL_queryListA_004 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListA_004";

    private static final String SQL_queryListA_005 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListA_005";

    private static final String SQL_queryListA_006 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListA_006";

    private static final String SQL_queryListB_001 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListB_001";

    private static final String SQL_queryListB_001_2 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListB_001_2";

    //    private static final String SQL_queryListB_002 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListB_002";

    //    private static final String SQL_queryListB_003 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListB_003";
    //
    private static final String SQL_queryListB_004 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListB_004";

    private static final String SQL_queryListB_005 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListB_005";

    private static final String SQL_queryListB_006 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListB_006";

    private static final String SQL_queryListB_007 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListB_007";

    //
    private static final String SQL_queryListA_007 = "com.cathay.ep.h1.module.EP_H10030.SQL_queryListA_007";

    /**
     * �d�ߦ����v�έp���
     * @param RCV_YM  BigDecimal  �����~��(�褸�~��)
     * @param PAY_S_DATE String  ú�کl��
     * @param PAY_E_DATE String  ú�ڲ״�
     * @param PAY_KIND  String  ú�ں���(A:����, B:�޲z�O)
     * @return   rtnMap  Map<String,List<Map>>  
     *                      <pre>
     *                       Key=rtnList1, value=�����v�M��
     *                       Key=rtnList2, value=�����M��
     *                       Key=rtnList3, value=�W��w���M��
     *                      </pre>
     */
    public Map<String, List<Map>> queryList(BigDecimal RCV_YM, String PAY_S_DATE, String PAY_E_DATE, String PAY_KIND, String SUB_CPY_ID)
            throws ModuleException, ParseException {
        ErrorInputException eie = null;
        if (RCV_YM == null) {
            eie = getErrorInputException(eie, "EP_H10030_MSG_001");//�����~�뤣�o����!
        }
        if (StringUtils.isBlank(PAY_KIND)) {
            eie = getErrorInputException(eie, "EP_H10030_MSG_002");//ú�ں������o����!
        } else if (!ArrayUtils.contains(new String[] { "A", "B" }, PAY_KIND)) {
            eie = getErrorInputException(eie, "EP_H10030_MSG_003");//ú�ں������~!
        }
        if (StringUtils.isBlank(PAY_S_DATE) || StringUtils.isBlank(PAY_E_DATE)) {
            eie = getErrorInputException(eie, "EP_H10030_MSG_006");//ú�ڰ϶����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        if ("A".equals(PAY_KIND)) {
            return this.queryListA(RCV_YM, PAY_S_DATE, PAY_E_DATE, SUB_CPY_ID);
        }
        //if("B".equals(PAY_KIND))
        return this.queryListB(RCV_YM, PAY_S_DATE, PAY_E_DATE, SUB_CPY_ID);

    }

    /**
     * �ץX
     * @param rtnMap
     * @param PAY_KIND
     * @param resp
     */
    public void exportXLS(Map rtnMap, String PAY_KIND, ResponseContext resp) throws Exception {
        FileOutputStream fileOutputString = null;
        try {

            String Name = "";//�d�ߺ����W��
            String[] subTitle_1 = null;//����1 �����Y
            String[] num_subTitle_1 = {};//����1 �Ʀr���
            String[] subTitle_key_1 = {};//����1 key
            String[] subTitle_2;//����2 �����Y
            String[] num_subTitle_2;//����2 �Ʀr���
            String[] subTitle_3 = {};//����3 �����Y 
            String[] num_subTitle_3;//����2 �Ʀr���
            String PAY_KIND_NAME = FieldOptionList.getName("EPC", "PAY_KIND_TWO", PAY_KIND);

            if ("A".equals(PAY_KIND)) {
                Name = "EP_H10030_MSG_004";//���������v�έp
                //�W��, �j�Ӹg��, 30����������, 30��w������, 30�饼������, �����v, �䲼ú�������B, �״�ú�������B
                subTitle_1 = new String[] { "EPH1_0030_UI_SER_NO", "EPH1_0030_UI_BLD_USR_NAME", "EPH1_0030_UI_A_RCV_AMT",
                        "EPH1_0030_UI_A_PAY_AMT", "EPH1_0030_UI_A_UNPAY_AMT", "EPH1_0030_UI_PAY_RATE", "EPH1_0030_UI_A_CHECK_AMT",
                        "EPH1_0030_UI_A_REMIT_AMT" };
                subTitle_key_1 = new String[] { "SER_NO", "BLD_USR_NAME", "RCV_AMT", "PAY_AMT", "UNPAY_AMT", "PAY_RATE", "CHECK_AMT",
                        "REMIT_AMT" };
                // 30����������, 30��w������, 30�饼������, �䲼ú�������B, �״�ú�������B
                num_subTitle_1 = new String[] { "RCV_AMT", "PAY_AMT", "UNPAY_AMT", "CHECK_AMT", "REMIT_AMT" };
                //�w���W�믲�����B, �״�ú�������B
                subTitle_3 = new String[] { "EPH1_0030_UI_E_PAY_AMT", "EPH1_0030_UI_E_REMIT_AMT" };

            } else if ("B".equals(PAY_KIND)) {
                Name = "EP_H10030_MSG_005";//�޲z�O�����v�έp
                //�W��, �j�Ӹg��, 30�������޲z�O, 30��w���޲z�O, 30�饼���޲z�O, �����v, �䲼ú�޲z�O���B, �״�ú�޲z�O���B
                subTitle_1 = new String[] { "EPH1_0030_UI_SER_NO", "EPH1_0030_UI_BLD_USR_NAME", "EPH1_0030_UI_B_RCV_AMT",
                        "EPH1_0030_UI_B_PAY_AMT", "EPH1_0030_UI_B_UNPAY_AMT", "EPH1_0030_UI_PAY_RATE", "EPH1_0030_UI_B_CHECK_AMT",
                        "EPH1_0030_UI_B_REMIT_AMT" };
                subTitle_key_1 = new String[] { "SER_NO", "BLD_USR_NAME", "RCV_AMT", "PAY_AMT", "UNPAY_AMT", "PAY_RATE", "CHECK_AMT",
                        "REMIT_AMT" };
                //30�������޲z�O, 30��w���޲z�O, 30�饼���޲z�O, �䲼ú�޲z�O���B, �״�ú�޲z�O���B
                num_subTitle_1 = new String[] { "RCV_AMT", "PAY_AMT", "UNPAY_AMT", "CHECK_AMT", "REMIT_AMT" };
                //�w���W�޲z�O���B, �״�ú�޲z�O���B
                subTitle_3 = new String[] { "EPH1_0030_UI_F_PAY_AMT", "EPH1_0030_UI_F_REMIT_AMT" };
            }
            //�w���W��xxx���B, �״�úxxx���B
            num_subTitle_3 = new String[] { "PAY_AMT", "REMIT_AMT" };
            //����3 key
            String[] subTitle_key_3 = new String[] { "PAY_AMT", "REMIT_AMT" };

            //A: �����������Ӧp�U     B: �����޲z�O���Ӧp�U
            String Title_2 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TITLE", new Object[] { PAY_KIND_NAME });
            //�j�Ӹg��, �����~��, ��ú����
            subTitle_2 = new String[] { "EPH1_0030_UI_BLD_USR_NAME", "EPH1_0030_UI_RCV_YM", "EPH1_0030_UI_SPR_AMT" };
            num_subTitle_2 = new String[] { "SPR_AMT" };
            //����2  key
            String[] subTitle_key_2 = new String[] { "BLD_USR_NAME", "RCV_YM", "SPR_AMT" };

            //EXCEL �ɦW:fileName_YYYMMDD.xls
            StringBuilder sb = new StringBuilder();

            String fileName = sb.append(MessageUtil.getMessage(Name)).append("_").append(DATE.toDate_yyyyMMdd(DATE.getDBDate())).append(
                ".xls").toString();
            sb.setLength(0);

            HSSFWorkbook workbook = new HSSFWorkbook();// �u�@��
            HSSFSheet sheet = workbook.createSheet(fileName);

            // �]�w���j�p
            getSheetColumnWidth(sheet);
            //TABLE1
            List<Map> rtnList1 = (List<Map>) MapUtils.getObject(rtnMap, "rtnList1");
            //�g�J���Ӹ��
            int nowRow = createworkbook(workbook, sheet, false, rtnList1, "", subTitle_1, subTitle_key_1, num_subTitle_1, 0, 0);

            //TABLE2
            List<Map> rtnList2 = (List<Map>) MapUtils.getObject(rtnMap, "rtnList2");
            //�g�J���Ӹ��
            nowRow = createworkbook(workbook, sheet, true, rtnList2, Title_2, subTitle_2, subTitle_key_2, num_subTitle_2, nowRow, 1);

            //TABLE3
            List<Map> rtnList3 = (List<Map>) MapUtils.getObject(rtnMap, "rtnList3");
            //�g�J���Ӹ��
            createworkbook(workbook, sheet, false, rtnList3, "", subTitle_3, subTitle_key_3, num_subTitle_3, nowRow, 1);
            // ���ͼȦs��
            File downloadFile = RptUtils.createTempFile(fileName);

            // ��X excel �ɪ����|
            String path = downloadFile.getPath();
            fileOutputString = new FileOutputStream(path);
            workbook.write(fileOutputString);
            RptUtils.cryptoDownloadParameterToResp(fileName, downloadFile, resp);
        } finally {
            if (fileOutputString != null) {
                fileOutputString.close();
            }
        }
    }

    /**
     * �X�p���
     * @param List
     * @param Cultext  String SPR_AMT
     * @return
     */
    public BigDecimal calculateList(List<Map> List, String Cultext) {
        BigDecimal TOT_SPR_AMT = BigDecimal.ZERO;
        if (List != null && List.size() > 0) {
            for (Map map : List) {
                TOT_SPR_AMT = TOT_SPR_AMT.add(obj2Big(map, Cultext, BigDecimal.ZERO));
            }
        }
        return TOT_SPR_AMT.setScale(0);
    }

    /**
     * ���Y�]�w
     * @param workbook
     * @param sheet
     * @param title
     * @param subTitle
     * @param nowRow
     * @return
     */
    private int setTitle(HSSFWorkbook workbook, HSSFSheet sheet, String title, String[] subTitle, int nowRow, int startCol) {
        HSSFRow row = sheet.createRow(nowRow);
        //TABLE �W�ٳ]�w
        if (StringUtils.isNotBlank(title)) {
            //�]�wSTYLE
            HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���");//���Y
            setColumn(sheet, row, style0, startCol, title, false, true, nowRow, nowRow, startCol, subTitle.length - 1 + startCol);
            nowRow++;
        }
        //���D
        if (title != null && subTitle.length != 0) {
            HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���");//�����Y
            row = sheet.createRow(nowRow);
            for (int i = 0; i < subTitle.length; i++) {
                setColumn(sheet, row, style1, i + startCol, MessageUtil.getMessage(subTitle[i]), false, false, null, null, null, null);
            }
            nowRow++;
        }
        return nowRow;
    }

    /**
     * �d�߯��������v�έp���
     * @param RCV_YM  BigDecimal  �����~��(�褸�~��)
     * @param PAY_S_DATE   String  ú�کl��
     * @param PAY_E_DATE   String  ú�ڲ״�
     * @return  rtnMap  Map<String,List<Map>> 
     *                  <pre>
     *                  Key=rtnList1, value=���������v�M��
     *                  Key=rtnList2, value=���������M��
     *                  Key=rtnList3, value=�W��w�������M��
     *                  </pre>
     */
    private Map<String, List<Map>> queryListA(BigDecimal RCV_YM, String PAY_S_DATE, String PAY_E_DATE, String SUB_CPY_ID)
            throws ModuleException, ParseException {

        //�_�h�^�ǿ��~�T��:�п�J�����~��
        //���������v�M��
        StringBuffer sb = new StringBuffer();
        String RCV_YM_date = DATE.toDateFormat(sb.append(RCV_YM).append("01").toString(), "yyyyMMdd", "yyyy-MM-dd");//�U��1��
        sb.setLength(0);
        Date ACNT_DATE = Date.valueOf(DATE.addDate(RCV_YM_date, 0, 1, 0));

        //2018-08-10:�į�վ�,���⦸�d���קKsql cost�Ӱ�
        //�d����ú
        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        setFieldIfExist(ds, "PAY_S_DATE", PAY_S_DATE);
        setFieldIfExist(ds, "PAY_E_DATE", PAY_E_DATE);
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID); //�����q�O
        List<Map> RCV_LIST = VOTool.findToMaps(ds, SQL_queryListA_001, false);//20180810:(���D��20180807-0035)�����v�����������B
        if (isDebug)
            log.debug("queryListA.RCV_LIST::" + RCV_LIST);

        //�d�ߤwú
        ds.clear();
        ds.setField("RCV_YM", RCV_YM);
        setFieldIfExist(ds, "PAY_S_DATE", PAY_S_DATE);
        setFieldIfExist(ds, "PAY_E_DATE", PAY_E_DATE);
        ds.setField("ACNT_DATE", ACNT_DATE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID); //�����q�O
        List<Map> tmpPAID_LIST = VOTool.findToMaps(ds, SQL_queryListA_002, false);
        Map<String, Map> PAID_LIST = new HashMap<String, Map>();
        if (tmpPAID_LIST != null) {
            for (Map paidMap : tmpPAID_LIST) {
                PAID_LIST.put(MapUtils.getString(paidMap, "BLD_USR_NAME"), paidMap);
            }
        }
        if (isDebug)
            log.debug("queryListA.PAID_LIST::" + PAID_LIST);

        //�X��(��ú���B+�wú���B)
        List<Map> rtnList1 = new ArrayList<Map>();
        for (Map rcvMap : RCV_LIST) {
            String BLD_USR_NAME = MapUtils.getString(rcvMap, "BLD_USR_NAME");

            //�p������(�������B-�������B)
            BigDecimal RCV_AMT = STRING.objToBigDecimal(rcvMap.get("RCV_AMT"), BigDecimal.ZERO);
            BigDecimal RJT_AMT = STRING.objToBigDecimal(rcvMap.get("RJT_AMT"), BigDecimal.ZERO);
            rcvMap.put("RCV_AMT", RCV_AMT.subtract(RJT_AMT));

            Map paidMap = PAID_LIST.get(BLD_USR_NAME);
            if (paidMap != null && !paidMap.isEmpty()) {
                rcvMap.putAll(paidMap);
            }
            rtnList1.add(rcvMap);
        }

        if (rtnList1 != null) {
            BigDecimal hun = new BigDecimal("100");
            for (Map tempMap : rtnList1) {

                //�p�⥼ú
                BigDecimal PAY_AMT = (BigDecimal) MapUtils.getObject(tempMap, "PAY_AMT", BigDecimal.ZERO);
                BigDecimal RCV_AMT = (BigDecimal) MapUtils.getObject(tempMap, "RCV_AMT", BigDecimal.ZERO);

                tempMap.put("PAY_AMT", PAY_AMT);
                tempMap.put("RCV_AMT", RCV_AMT);
                tempMap.put("CHECK_AMT", STRING.objToBigDecimal(tempMap.get("CHECK_AMT"), BigDecimal.ZERO));
                tempMap.put("REMIT_AMT", STRING.objToBigDecimal(tempMap.get("REMIT_AMT"), BigDecimal.ZERO));
                tempMap.put("UNPAY_AMT", RCV_AMT.subtract(PAY_AMT));
                //�p�⦬���v
                BigDecimal PAY_RATE_ALL = (BigDecimal.ZERO.compareTo(PAY_AMT)) == 0 ? BigDecimal.ZERO : PAY_AMT.multiply(hun).divide(
                    RCV_AMT, 10, BigDecimal.ROUND_HALF_UP);
                BigDecimal PAY_RATE = PAY_RATE_ALL.setScale(2, BigDecimal.ROUND_HALF_UP);
                tempMap.put("PAY_RATE", sb.append(PAY_RATE).append('%').toString());
                tempMap.put("PAY_RATE_NUM", PAY_RATE_ALL);
                sb.setLength(0);
            }
            if (isDebug)
                log.debug("queryListA.rtnList1" + rtnList1);

            //�̦����v�Ƨ�
            Collections.sort(rtnList1, new Comparator<Map>() {
                public int compare(Map o1, Map o2) {
                    BigDecimal hun = new BigDecimal("100");
                    BigDecimal big1 = (BigDecimal) MapUtils.getObject(o1, "PAY_RATE_NUM", BigDecimal.ZERO);
                    BigDecimal big2 = (BigDecimal) MapUtils.getObject(o2, "PAY_RATE_NUM", BigDecimal.ZERO);
                    if (0 == big1.compareTo(hun) && 0 == big2.compareTo(hun)) {//100% -> ��H��
                        BigDecimal big1_1 = (BigDecimal) MapUtils.getObject(o1, "RCV_AMT", BigDecimal.ZERO);
                        BigDecimal big2_2 = (BigDecimal) MapUtils.getObject(o2, "RCV_AMT", BigDecimal.ZERO);
                        return -big1_1.compareTo(big2_2);
                    } else {
                        if (0 == big1.compareTo(big2)) {
                            BigDecimal big1_1 = (BigDecimal) MapUtils.getObject(o1, "UNPAY_AMT", BigDecimal.ZERO);
                            BigDecimal big2_2 = (BigDecimal) MapUtils.getObject(o2, "UNPAY_AMT", BigDecimal.ZERO);
                            return big1_1.compareTo(big2_2);
                        } else {
                            return -big1.compareTo(big2);
                        }
                    }
                }
            });
        }

        //���������M��
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID); //�����q�O
        ds.setField("RCV_YM", RCV_YM);
        setFieldIfExist(ds, "PAY_S_DATE_OLD", PAY_S_DATE);
        setFieldIfExist(ds, "PAY_E_DATE_OLD", PAY_E_DATE);
        List<Map> rtnList2 = VOTool.findToMaps(ds, SQL_queryListA_005, false);

        BigDecimal SPR_AMT = BigDecimal.ZERO;

        if (rtnList2 != null && !rtnList2.isEmpty()) {
            for (Map tmpMap : rtnList2) {
                SPR_AMT = SPR_AMT.add(new BigDecimal(MapUtils.getString(tmpMap, "SPR_AMT", "0")));
            }
        }

        if (isDebug)
            log.debug("queryListA.rtnList2" + rtnList2);

        //�W��w���M��
        ds.clear();
        ds.setField("RCV_YM", RCV_YM);
        setFieldIfExist(ds, "PAY_S_DATE", PAY_S_DATE);
        setFieldIfExist(ds, "PAY_E_DATE", PAY_E_DATE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList3 = VOTool.findToMaps(ds, SQL_queryListA_007, false);

        if (isDebug)
            log.debug("queryListA.rtnList3" + rtnList3);

        if (rtnList1 == null && rtnList2 == null && rtnList3 == null) {
            throw new DataNotFoundException();
        }

        Map rtnMap = new HashMap();
        rtnMap.put("rtnList1", rtnList1);
        rtnMap.put("rtnList2", rtnList2);
        rtnMap.put("rtnList3", rtnList3);
        return rtnMap;

    }

    /**
     * �d�ߺ޲z�O�����v�έp���
     * @param RCV_YM  BigDecimal  �����~��(�褸�~��)
     * @param PAY_S_DATE  String  ú�کl��
     * @param PAY_E_DATE  String  ú�ڲ״�
     * @return  rtnMap  Map<String,List<Map>>  
     *                      <pre>
     *                       Key=rtnList1, value=�޲z�O�����v�M��
     *                       Key=rtnList2, value=�����޲z�O�M��
     *                       Key=rtnList3, value=�W��w���޲z�O�M��
     *                      </pre>
     */
    private Map queryListB(BigDecimal RCV_YM, String PAY_S_DATE, String PAY_E_DATE, String SUB_CPY_ID) throws ParseException,
            ModuleException {
        //�ˮ������~�묰����
        //�_�h�^�ǿ��~�T��:���п�J�����~�롨 
        //�޲z�O�����v�M��
        StringBuffer sb = new StringBuffer();
        String RCV_YM_date = DATE.toDateFormat(sb.append(RCV_YM).append("01").toString(), "yyyyMMdd", "yyyy-MM-dd");//�U��1��
        sb.setLength(0);

        Date ACNT_DATE = Date.valueOf(DATE.addDate(RCV_YM_date, 0, 1, 0));

        //2018-08-10:�į�վ�,���⦸�d���קKsql cost�Ӱ�
        //�d����ú���B
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID); //�����q�O
        ds.setField("RCV_YM", RCV_YM);
        setFieldIfExist(ds, "PAY_S_DATE", PAY_S_DATE);
        setFieldIfExist(ds, "PAY_E_DATE", PAY_E_DATE);
        ds.setField("ACNT_DATE", ACNT_DATE);
        List<Map> RCV_LIST = VOTool.findToMaps(ds, SQL_queryListB_001, false);//20180810:(���D��20180807-0035)�����v�����������B
        if (isDebug)
            log.debug("queryListB.RCV_LIST::" + RCV_LIST);

        //�d�ߤwú���B
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID); //�����q�O
        ds.setField("RCV_YM", RCV_YM);
        setFieldIfExist(ds, "PAY_S_DATE", PAY_S_DATE);
        setFieldIfExist(ds, "PAY_E_DATE", PAY_E_DATE);
        ds.setField("ACNT_DATE", ACNT_DATE);
        List<Map> tmpPAID_LIST = VOTool.findToMaps(ds, SQL_queryListB_001_2, false);
        Map<String, Map> PAID_LIST = new HashMap<String, Map>();
        if (tmpPAID_LIST != null) {
            for (Map paidMap : tmpPAID_LIST) {
                PAID_LIST.put(MapUtils.getString(paidMap, "BLD_USR_NAME"), paidMap);
            }
        }
        if (isDebug)
            log.debug("queryListB.PAID_LIST::" + PAID_LIST);

        //�X��(��ú���B+�wú���B)
        List<Map> rtnList1 = new ArrayList<Map>();
        for (Map rcvMap : RCV_LIST) {
            String BLD_USR_NAME = MapUtils.getString(rcvMap, "BLD_USR_NAME");

            //�p������(�������B-�������B)
            BigDecimal RCV_AMT = STRING.objToBigDecimal(rcvMap.get("RCV_AMT"), BigDecimal.ZERO);
            BigDecimal RJT_AMT = STRING.objToBigDecimal(rcvMap.get("RJT_AMT"), BigDecimal.ZERO);
            rcvMap.put("RCV_AMT", RCV_AMT.subtract(RJT_AMT));

            Map paidMap = PAID_LIST.get(BLD_USR_NAME);
            if (paidMap != null && !paidMap.isEmpty()) {
                rcvMap.putAll(paidMap);
            }
            rtnList1.add(rcvMap);
        }

        if (rtnList1 != null) {
            BigDecimal hun = new BigDecimal("100");
            for (Map tempMap : rtnList1) {

                //�p�⥼ú
                BigDecimal PAY_AMT = STRING.objToBigDecimal(tempMap.get("PAY_AMT"), BigDecimal.ZERO);
                BigDecimal RCV_AMT = STRING.objToBigDecimal(tempMap.get("RCV_AMT"), BigDecimal.ZERO);

                tempMap.put("PAY_AMT", PAY_AMT);
                tempMap.put("RCV_AMT", RCV_AMT);
                tempMap.put("CHECK_AMT", STRING.objToBigDecimal(tempMap.get("CHECK_AMT"), BigDecimal.ZERO));
                tempMap.put("REMIT_AMT", STRING.objToBigDecimal(tempMap.get("REMIT_AMT"), BigDecimal.ZERO));
                tempMap.put("UNPAY_AMT", RCV_AMT.subtract(PAY_AMT));
                //�p�⦬���v
                BigDecimal PAY_RATE_ALL = (BigDecimal.ZERO.compareTo(PAY_AMT)) == 0 ? BigDecimal.ZERO : PAY_AMT.multiply(hun).divide(
                    RCV_AMT, 10, BigDecimal.ROUND_DOWN);
                BigDecimal PAY_RATE = PAY_RATE_ALL.setScale(2, BigDecimal.ROUND_HALF_UP);
                tempMap.put("PAY_RATE", sb.append(PAY_RATE).append('%').toString());
                sb.setLength(0);
                tempMap.put("PAY_RATE_NUM", PAY_RATE_ALL);

            }
            
            if (isDebug)
                log.debug("queryListB.rtnList1::" + rtnList1);
            
            
            //�̦����v�Ƨ�
            Collections.sort(rtnList1, new Comparator<Map>() {
                public int compare(Map o1, Map o2) {
                    BigDecimal hun = new BigDecimal("100");
                    BigDecimal big1 = (BigDecimal) MapUtils.getObject(o1, "PAY_RATE_NUM", BigDecimal.ZERO);
                    BigDecimal big2 = (BigDecimal) MapUtils.getObject(o2, "PAY_RATE_NUM", BigDecimal.ZERO);
                    if (0 == big1.compareTo(hun) && 0 == big2.compareTo(hun)) {//100% -> ��H��
                        BigDecimal big1_1 = (BigDecimal) MapUtils.getObject(o1, "RCV_AMT", BigDecimal.ZERO);
                        BigDecimal big2_2 = (BigDecimal) MapUtils.getObject(o2, "RCV_AMT", BigDecimal.ZERO);
                        return -big1_1.compareTo(big2_2);
                    } else {
                        return -big1.compareTo(big2);
                    }
                }
            });
        }

        //�����޲z�O�M��
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID); //�����q�O
        ds.setField("RCV_YM", RCV_YM);
        setFieldIfExist(ds, "PAY_S_DATE", PAY_S_DATE);
        setFieldIfExist(ds, "PAY_E_DATE", PAY_E_DATE);
        List<Map> rtnList2 = VOTool.findToMaps(ds, SQL_queryListB_005, false);

        BigDecimal SPR_AMT = BigDecimal.ZERO;
        if (rtnList2 != null && !rtnList2.isEmpty()) {
            for (Map tmpMap : rtnList2) {
                SPR_AMT = SPR_AMT.add(new BigDecimal(MapUtils.getString(tmpMap, "SPR_AMT", "0")));
            }
        }
        if (isDebug)
            log.debug("queryListB.rtnList2::" + rtnList2);


        //�W��w���M��
        //String RCV_YM_OLD = DATE.toDateFormat(DATE.addDate(RCV_YM_date, 0, -1, 0), "yyyy-MM-dd", "yyyyMM");
        ds.clear();
        ds.setField("RCVYM", RCV_YM);
        setFieldIfExist(ds, "PAY_S_DATE", PAY_S_DATE);
        setFieldIfExist(ds, "PAY_E_DATE", PAY_E_DATE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList3 = VOTool.findToMaps(ds, SQL_queryListB_007, false);

        if (isDebug)
            log.debug("queryListB.rtnList3::" + rtnList3);
        if (rtnList1 == null && rtnList2 == null && rtnList3 == null) {
            throw new DataNotFoundException();
        }

        Map rtnMap = new HashMap();
        rtnMap.put("rtnList1", rtnList1);
        rtnMap.put("rtnList2", rtnList2);
        rtnMap.put("rtnList3", rtnList3);
        return rtnMap;
    }

    /**
     * ���Ȥ~�]
     * @param ds
     * @param key
     * @param value
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotEmpty(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * �]�w���j�p
     * @param sheet
     */
    private void getSheetColumnWidth(HSSFSheet sheet) {
        //        for (int i = 0; i < countcol; i++) {
        //            sheet.setColumnWidth(i, 30 * 256);
        //        }
        sheet.setColumnWidth(0, 8 * 256);
        sheet.setColumnWidth(1, 20 * 256);
        sheet.setColumnWidth(2, 20 * 256);
        sheet.setColumnWidth(3, 20 * 256);
        sheet.setColumnWidth(4, 20 * 256);
        sheet.setColumnWidth(5, 8 * 256);
        sheet.setColumnWidth(6, 20 * 256);
        sheet.setColumnWidth(7, 20 * 256);
    }

    private void getSheetColumnWidth2(HSSFSheet sheet) {
        //        for (int i = 0; i < countcol; i++) {
        //            sheet.setColumnWidth(i, 30 * 256);
        //        }
        sheet.setColumnWidth(0, 52 * 32);
        sheet.setColumnWidth(1, 122 * 32);
        sheet.setColumnWidth(2, 122 * 32);
        sheet.setColumnWidth(3, 116 * 32);
        sheet.setColumnWidth(4, 87 * 32);
        sheet.setColumnWidth(5, 127 * 32);
        sheet.setColumnWidth(6, 101 * 32);
    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @return
     */
    private HSSFCellStyle createStyle(HSSFWorkbook workbook, int type, String font_type) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();

        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);

        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�j���Y
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            font.setFontHeightInPoints((short) 22); // �j�p         

        } else if (type == 1) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.BLACK.index);
            font.setColor(HSSFColor.BLACK.index);
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 3) {//���ӼƦr
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        }

        style.setFont(font);

        //�~��
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);

        return style;
    }

    private HSSFCellStyle createStyle2(HSSFWorkbook workbook, int type, String font_type, String hasborder) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();

        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);

        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�j���Y
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            font.setFontHeightInPoints((short) 22); // �j�p         

        } else if (type == 1) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.BLACK.index);
            font.setColor(HSSFColor.BLACK.index);
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 3) {//���ӼƦr
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        }

        style.setFont(font);

        //�~��
        if ("ALL".equals(hasborder)) {
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        } else if ("UP".equals(hasborder)) {
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        } else if ("DOWN".equals(hasborder)) {
            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        }

        return style;
    }

    /**
     * �]�w���
     * @param workbook
     * @param sheet
     * @param isCul
     * @param rtnList
     * @param title
     * @param subTitle
     * @param subTitle_key
     * @param num_subTitle
     * @param nowRow
     * @return
     * @throws ModuleException
     */
    private int createworkbook(HSSFWorkbook workbook, HSSFSheet sheet, boolean isCul, List<Map> rtnList, String title, String[] subTitle,
            String[] subTitle_key, String[] num_subTitle, int nowRow, int startCol) throws ModuleException {

        //���D
        nowRow = setTitle(workbook, sheet, title, subTitle, nowRow, startCol);

        //���Ӹ��(�t�X�p)
        if (rtnList != null) {
            nowRow = createDetail(workbook, sheet, isCul, rtnList, subTitle_key, num_subTitle, nowRow, startCol);
        }
        return nowRow + 1;

    }

    private int createworkbook_ld(HSSFWorkbook workbook, HSSFSheet sheet, boolean isCul, List<Map> rtnList, String title,
            String[] subTitle, String[] subTitle_key, String[] num_subTitle, int nowRow, int startCol, LocaleDisplay ld)
            throws ModuleException {

        //���D
        nowRow = setTitle(workbook, sheet, title, subTitle, nowRow, startCol);

        //���Ӹ��(�t�X�p)
        if (rtnList != null) {
            nowRow = createDetail_ld(workbook, sheet, isCul, rtnList, subTitle_key, num_subTitle, nowRow, startCol, ld);
        }
        return nowRow + 1;

    }

    private int createworkbook2_ld(HSSFWorkbook workbook, HSSFSheet sheet, boolean isCul, List<Map> rtnList, String title, String title2,
            String[] subTitle, String[] subTitle_key, String[] num_subTitle, int nowRow, int startCol, List<Map> rtnList2,
            String PAY_KIND_NAME, LocaleDisplay ld) throws ModuleException {

        //���D
        //�]�wSTYLE
        HSSFRow row = sheet.createRow(nowRow);
        HSSFCellStyle style0 = createStyle2(workbook, 3, "�s�ө���", "");//���Y
        HSSFCellStyle style4 = createStyle2(workbook, 4, "�s�ө���", "");//���Ӥ�r
        BigDecimal sum_SPR_AMT = this.calculateList(rtnList, "SPR_AMT");

        setColumn(sheet, row, style0, 1, title, false, true, nowRow, nowRow, 1, 2);
        setColumn(sheet, row, style0, 3, ld.formatNumber("" + sum_SPR_AMT.intValue(), 0, "-"), false, true, nowRow, nowRow, 3, 3);
        setColumn(sheet, row, style4, 4, title2, false, true, nowRow, nowRow, 4, 5);
        nowRow++;

        //�]�wSTYLE
        HSSFCellStyle style1 = createStyle2(workbook, 3, "�s�ө���", "ALL");//���Y
        HSSFCellStyle style2 = createStyle2(workbook, 1, "�s�ө���", "UP");//���Ӥ�r
        HSSFCellStyle style3 = createStyle2(workbook, 1, "�s�ө���", "DOWN");//���Ӥ�r

        String Title_31 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TITLE_4");
        String Title_32 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TITLE_5", new Object[] { PAY_KIND_NAME });
        String Title_33 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TITLE_6");

        //����
        if (rtnList != null && rtnList.size() > 0) {
            for (int i = 0; i < rtnList.size(); i++) {
                Map rtnMap = rtnList.get(i);
                row = sheet.createRow(nowRow);
                setColumn(sheet, row, style0, 1, ld.formatNumber(MapUtils.getString(rtnMap, "SPR_AMT", "0"), 0, "-"), false, false, null,
                    null, null, null);
                setColumn(sheet, row, style4, 2, MapUtils.getString(rtnMap, "BLD_USR_NAME", "0"), false, false, null, null, null, null);

                if (i == 0) {
                    setColumn(sheet, row, style2, 5, Title_31, false, false, null, null, null, null);
                    setColumn(sheet, row, style2, 6, Title_33, false, false, null, null, null, null);
                } else if (i == 1) {
                    setColumn(sheet, row, style3, 5, Title_32, false, false, null, null, null, null);
                    setColumn(sheet, row, style3, 6, Title_32, false, false, null, null, null, null);
                } else if (i == 2) {
                    String PAY_AMT = "0";
                    String REMIT_AMT = "0";
                    if (rtnList2 != null && rtnList2.size() > 0) {
                        PAY_AMT = MapUtils.getString(rtnList2.get(0), "PAY_AMT", "0");
                        REMIT_AMT = MapUtils.getString(rtnList2.get(0), "REMIT_AMT", "0");
                    }
                    setColumn(sheet, row, style1, 5, ld.formatNumber(PAY_AMT, 0, "-"), false, false, null, null, null, null);
                    setColumn(sheet, row, style1, 6, ld.formatNumber(REMIT_AMT, 0, "-"), false, false, null, null, null, null);
                }

                nowRow++;
            }
        }
        if (rtnList == null || rtnList.size() == 0) {
            row = sheet.createRow(nowRow);
            setColumn(sheet, row, style2, 5, Title_31, false, false, null, null, null, null);
            setColumn(sheet, row, style2, 6, Title_33, false, false, null, null, null, null);
            nowRow++;
        }
        if (rtnList == null || rtnList.size() <= 1) {
            row = sheet.createRow(nowRow);
            setColumn(sheet, row, style3, 5, Title_32, false, false, null, null, null, null);
            setColumn(sheet, row, style3, 6, Title_32, false, false, null, null, null, null);
            nowRow++;
        }
        if (rtnList == null || rtnList.size() <= 2) {
            row = sheet.createRow(nowRow);
            String PAY_AMT = "0";
            String REMIT_AMT = "0";
            if (rtnList2 != null && rtnList2.size() > 0) {
                PAY_AMT = MapUtils.getString(rtnList2.get(0), "PAY_AMT", "0");
                REMIT_AMT = MapUtils.getString(rtnList2.get(0), "REMIT_AMT", "0");
            }
            setColumn(sheet, row, style1, 5, ld.formatNumber(PAY_AMT, 0, "-"), false, false, null, null, null, null);
            setColumn(sheet, row, style1, 6, ld.formatNumber(REMIT_AMT, 0, "-"), false, false, null, null, null, null);
            nowRow++;
        }

        return nowRow + 1;

    }

    /**
     * �إߪ��椺�e
     * @param workbook
     * @param sheet
     * @param isCul �O�_�ݦX�p
     * @param rtnList ���Ӹ��
     * @param subTitle_key �C��key��
     * @param num_subTitle  �Ʀr���
     * @param nowRow
     * @return
     * @throws ModuleException
     */
    private int createDetail(HSSFWorkbook workbook, HSSFSheet sheet, boolean isCul, List<Map> rtnList, String[] subTitle_key,
            String[] num_subTitle, int nowRow, int startCol) throws ModuleException {

        //�]�wSTYLE
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���");//���Ӥ�r
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���");//���ӼƦr
        HSSFRow row;

        //����
        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);

            //���Ӹ��
            row = sheet.createRow(nowRow);

            for (int j = 0; j < subTitle_key.length; j++) {
                String key = subTitle_key[j];
                String val = MapUtils.getString(rtnMap, key);
                if ("SER_NO".equals(key)) {
                    //�W��
                    setColumn(sheet, row, style2, j + startCol, String.valueOf(i + 1), false, false, null, null, null, null);
                } else if (ArrayUtils.contains(num_subTitle, key)) {
                    setColumn(sheet, row, style3, j + startCol, val, true, false, null, null, null, null);
                } else {
                    setColumn(sheet, row, style2, j + startCol, val, false, false, null, null, null, null);
                }

            }
            nowRow++;
        }

        //�X�p
        if (isCul) {
            row = sheet.createRow(nowRow);
            setColumn(sheet, row, style2, 1, MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TOTAL", new Object[] { this.calculateList(
                rtnList, "SPR_AMT") }), false, true, nowRow, nowRow, 1, subTitle_key.length);//�@{0}��
            nowRow++;
        }
        return nowRow;
    }

    private int createDetail_ld(HSSFWorkbook workbook, HSSFSheet sheet, boolean isCul, List<Map> rtnList, String[] subTitle_key,
            String[] num_subTitle, int nowRow, int startCol, LocaleDisplay ld) throws ModuleException {

        //�]�wSTYLE
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���");//���Ӥ�r
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���");//���ӼƦr
        HSSFRow row;

        Map<String, String> sumMap = new HashMap();

        //����
        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);

            //���Ӹ��
            row = sheet.createRow(nowRow);

            for (int j = 0; j < subTitle_key.length; j++) {
                String key = subTitle_key[j];
                String val = MapUtils.getString(rtnMap, key);
                if ("SER_NO".equals(key)) {
                    //�W��
                    setColumn(sheet, row, style2, j + startCol, String.valueOf(i + 1), false, false, null, null, null, null);
                } else if (ArrayUtils.contains(num_subTitle, key)) {
                    setColumn(sheet, row, style3, j + startCol, ld.formatNumber(val, 0, "-"), false, false, null, null, null, null);
                    //�[�`
                    BigDecimal old_val = obj2Big(sumMap, key, BigDecimal.ZERO);
                    BigDecimal new_val = obj2Big(rtnMap, key, BigDecimal.ZERO);
                    sumMap.put(key, old_val.add(new_val).toString());
                } else {
                    setColumn(sheet, row, style2, j + startCol, val, false, false, null, null, null, null);
                }

            }
            nowRow++;
        }
        //���Ӫ��`�p
        row = sheet.createRow(nowRow);
        for (int j = 0; j < subTitle_key.length; j++) {
            String key = subTitle_key[j];
            if ("SER_NO".equals(key)) {
                setColumn(sheet, row, style2, j + startCol, MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TOTAL_2"), false, false, null,
                    null, null, null);
            } else if ("PAY_RATE".equals(key)) {
                BigDecimal PAY_AMT = obj2Big(sumMap, "PAY_AMT", BigDecimal.ZERO);
                BigDecimal RCV_AMT = obj2Big(sumMap, "RCV_AMT", BigDecimal.ZERO);
                BigDecimal PAY_RATE = BigDecimal.ZERO;
                if (0 != RCV_AMT.compareTo(BigDecimal.ZERO)) {
                    PAY_RATE = PAY_AMT.multiply(new BigDecimal("100")).divide(RCV_AMT, 2, BigDecimal.ROUND_DOWN);
                }
                setColumn(sheet, row, style2, j + startCol, PAY_RATE.toString() + "%", false, false, null, null, null, null);
            } else if (ArrayUtils.contains(num_subTitle, key)) {
                String val = MapUtils.getString(sumMap, key);
                setColumn(sheet, row, style3, j + startCol, ld.formatNumber(val, 0, "-"), false, false, null, null, null, null);
            } else {
                setColumn(sheet, row, style2, j + startCol, "", false, false, null, null, null, null);
            }
        }
        nowRow++;

        //�X�p
        if (isCul) {
            row = sheet.createRow(nowRow);
            setColumn(sheet, row, style2, 1, MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TOTAL", new Object[] { this.calculateList(
                rtnList, "SPR_AMT") }), false, true, nowRow, nowRow, 1, subTitle_key.length);//�@{0}��
            nowRow++;
        }
        return nowRow;
    }

    /**
     *  �]�w���
     * @param sheet
     * @param bodyRow
     * @param style ���A
     * @param columnNumber ���ͲĴX��cell
     * @param content  ���
     * @param isNumeric �O�_���Ʀr���
     * @param doCombine �O�_�ݦX���x�s��
     * @param firstRow
     * @param lastRow
     * @param firstCol
     * @param lastCol
     */
    private void setColumn(HSSFSheet sheet, HSSFRow bodyRow, HSSFCellStyle style, Integer columnNumber, String content, boolean isNumeric,
            boolean doCombine, Integer firstRow, Integer lastRow, Integer firstCol, Integer lastCol) {

        HSSFCell bodyCell;
        bodyCell = bodyRow.createCell(columnNumber);
        bodyCell.setCellStyle(style);

        if (doCombine) {
            for (int s = firstCol; s <= lastCol; s++) {
                bodyCell = bodyRow.createCell(s);
                bodyCell.setCellStyle(style);
            }

            //�X���x�s��
            CellRangeAddress range_inputCount = new CellRangeAddress(firstRow, lastRow, firstCol, lastCol);
            sheet.addMergedRegion(range_inputCount);

            bodyCell = bodyRow.getCell(firstCol);
        }

        if (isNumeric) {
            if (StringUtils.isNotBlank(content)) {
                bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                Double bodyText = new Double(content);
                bodyCell.setCellValue(bodyText.intValue());
            }
        } else {
            HSSFRichTextString text = new HSSFRichTextString(content);
            bodyCell.setCellValue(text);
        }
    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param map
     * @param key
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            } else {
                String str = o.toString();
                if (StringUtils.isNotBlank(str)) {
                    return new BigDecimal(str);
                } else {
                    return defaultValue;
                }
            }
        }
        return defaultValue;
    }

    /**
     * �ץX(�վ�ƪ�)
     * @param rtnMap
     * @param PAY_KIND
     * @param resp
     */
    public void exportXLS2(Map reqMap, Map rtnMap, String PAY_KIND, ResponseContext resp, UserObject user) throws Exception {
        FileOutputStream fileOutputString = null;
        try {
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            String RCV_YM_str = MapUtils.getString(reqMap, "RCV_YM");
            BigDecimal RCV_YM = null;
            if (NumberUtils.isNumber(RCV_YM_str)) {
                RCV_YM = new BigDecimal(RCV_YM_str);
            }
            int YEAR = RCV_YM.intValue() / 100 - 1911;
            int Month = RCV_YM.intValue() % 100;
            if ("B".equals(PAY_KIND)) {
                Month = (Month == 1) ? 12 : Month - 1;
            }

            int lastMonth = (Month == 1) ? 12 : Month - 1;

            String Name = "";//�d�ߺ����W��
            String[] subTitle_1 = null;//����1 �����Y
            String[] num_subTitle_1 = {};//����1 �Ʀr���
            String[] subTitle_key_1 = {};//����1 key
            String[] subTitle_2;//����2 �����Y
            String[] num_subTitle_2;//����2 �Ʀr���
            String[] subTitle_3 = {};//����3 �����Y 
            String[] num_subTitle_3;//����2 �Ʀr���
            String PAY_KIND_NAME = FieldOptionList.getName("EPC", "PAY_KIND_TWO", PAY_KIND);

            if ("A".equals(PAY_KIND)) {
                Name = "EP_H10030_MSG_004";//���������v�έp
                //�W��, 30����������, 30��w������, 30�饼������, �����v, �״�ú�������B, �j�Ӹg��
                subTitle_1 = new String[] { "EPH1_0030_UI_SER_NO", "EPH1_0030_UI_A_RCV_AMT", "EPH1_0030_UI_A_PAY_AMT",
                        "EPH1_0030_UI_A_UNPAY_AMT", "EPH1_0030_UI_PAY_RATE", "EPH1_0030_UI_A_REMIT_AMT", "EPH1_0030_UI_BLD_USR_NAME" };
                subTitle_key_1 = new String[] { "SER_NO", "RCV_AMT", "PAY_AMT", "UNPAY_AMT", "PAY_RATE", "REMIT_AMT", "BLD_USR_NAME" };
                // 30����������, 30��w������, 30�饼������, �䲼ú�������B, �״�ú�������B
                num_subTitle_1 = new String[] { "RCV_AMT", "PAY_AMT", "UNPAY_AMT", "REMIT_AMT" };
                //�w���W�믲�����B, �״�ú�������B
                subTitle_3 = new String[] { "EPH1_0030_UI_E_PAY_AMT", "EPH1_0030_UI_E_REMIT_AMT" };

            } else if ("B".equals(PAY_KIND)) {
                Name = "EP_H10030_MSG_005";//�޲z�O�����v�έp
                //�W��, 30�������޲z�O, 30��w���޲z�O, 30�饼���޲z�O, �����v, �״�ú�޲z�O���B, �j�Ӹg��
                subTitle_1 = new String[] { "EPH1_0030_UI_SER_NO", "EPH1_0030_UI_B_RCV_AMT", "EPH1_0030_UI_B_PAY_AMT",
                        "EPH1_0030_UI_B_UNPAY_AMT", "EPH1_0030_UI_PAY_RATE", "EPH1_0030_UI_B_REMIT_AMT", "EPH1_0030_UI_BLD_USR_NAME" };
                subTitle_key_1 = new String[] { "SER_NO", "RCV_AMT", "PAY_AMT", "UNPAY_AMT", "PAY_RATE", "REMIT_AMT", "BLD_USR_NAME" };
                //30�������޲z�O, 30��w���޲z�O, 30�饼���޲z�O, �䲼ú�޲z�O���B, �״�ú�޲z�O���B
                num_subTitle_1 = new String[] { "RCV_AMT", "PAY_AMT", "UNPAY_AMT", "REMIT_AMT" };
                //�w���W�޲z�O���B, �״�ú�޲z�O���B
                subTitle_3 = new String[] { "EPH1_0030_UI_F_PAY_AMT", "EPH1_0030_UI_F_REMIT_AMT" };
            }
            //�w���W��xxx���B, �״�úxxx���B
            num_subTitle_3 = new String[] { "PAY_AMT", "REMIT_AMT" };
            //����3 key
            String[] subTitle_key_3 = new String[] { "PAY_AMT", "REMIT_AMT" };

            //A: �����������Ӧp�U     B: �����޲z�O���Ӧp�U
            String Title_2 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TITLE_2", new Object[] { lastMonth, PAY_KIND_NAME });
            String Title_22 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TITLE_3");
            //�j�Ӹg��, �����~��, ��ú����
            subTitle_2 = new String[] { "EPH1_0030_UI_SPR_AMT", "EPH1_0030_UI_BLD_USR_NAME" };
            num_subTitle_2 = new String[] { "SPR_AMT" };
            //����2  key
            String[] subTitle_key_2 = new String[] { "SPR_AMT", "BLD_USR_NAME" };

            //EXCEL �ɦW:fileName_YYYMMDD.xls
            StringBuilder sb = new StringBuilder();

            String fileName = sb.append(MessageUtil.getMessage(Name)).append("_").append(DATE.toDate_yyyyMMdd(DATE.getDBDate())).append(
                ".xls").toString();
            sb.setLength(0);

            LocaleDisplay ld = new LocaleDisplay("EP", user);

            HSSFWorkbook workbook = new HSSFWorkbook();// �u�@��
            HSSFSheet sheet = workbook.createSheet(fileName);

            sheet.setMargin(sheet.TopMargin, (double) 0.2);//�o��O�^�T, ���Oexcel���]�w�O����
            sheet.setMargin(sheet.BottomMargin, (double) 0.2);
            sheet.setMargin(sheet.LeftMargin, (double) 0.16);
            sheet.setMargin(sheet.RightMargin, (double) 0.16);

            // �]�w���j�p
            getSheetColumnWidth2(sheet);

            //TITLE
            HSSFRow row0 = sheet.createRow(0);
            HSSFCellStyle style00 = createStyle2(workbook, 0, "�s�ө���", "");//���Y
            String title00;
            if ("00".equals(SUB_CPY_ID)) {
                title00 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TITLE_00", new Object[] { PAY_KIND_NAME }); //���ʲ��޲z�@�B�G��{0}�����v�ƦW�έp��
            } else {
                title00 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TITLE_00_" + SUB_CPY_ID, new Object[] { PAY_KIND_NAME }); //{}�����v�ƦW�έp��
            }
            setColumn(sheet, row0, style00, 0, title00, false, true, 0, 0, 0, 6);

            HSSFRow row1 = sheet.createRow(1);
            HSSFCellStyle style01 = createStyle2(workbook, 1, "�s�ө���", "");//���Y
            HSSFCellStyle style03 = createStyle2(workbook, 3, "�s�ө���", "");//���Ӥ�r

            String title01 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_TITLE_01", new Object[] { YEAR, Month, PAY_KIND_NAME });
            String prtdate = DATE.getROCDate();

            setColumn(sheet, row1, style01, 1, title01, false, true, 1, 1, 1, 4);
            setColumn(sheet, row1, style03, 4, prtdate, false, true, 1, 1, 5, 6);

            //TABLE1
            List<Map> rtnList1 = (List<Map>) MapUtils.getObject(rtnMap, "rtnList1");
            //�g�J���Ӹ��
            int nowRow = createworkbook_ld(workbook, sheet, false, rtnList1, "", subTitle_1, subTitle_key_1, num_subTitle_1, 2, 0, ld);

            //TABLE2
            List<Map> rtnList2 = (List<Map>) MapUtils.getObject(rtnMap, "rtnList2");
            if (rtnList2 != null && rtnList2.size() > 0) {
                rtnList2 = sumByUserName(rtnList2);
            }

            List<Map> rtnList3 = (List<Map>) MapUtils.getObject(rtnMap, "rtnList3");

            //�g�J���Ӹ��
            nowRow = createworkbook2_ld(workbook, sheet, true, rtnList2, Title_2, Title_22, subTitle_2, subTitle_key_2, num_subTitle_2,
                nowRow, 1, rtnList3, PAY_KIND_NAME, ld);

            //����ñ�W
            String FOOTER_1 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_FOOTER_1");
            String FOOTER_2 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_FOOTER_2");
            String FOOTER_3 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_FOOTER_3");
            String FOOTER_4 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_FOOTER_4");
            String FOOTER_5 = MessageUtil.getMessage("EPH1_0030_UI_TABLE_2_FOOTER_5");

            nowRow++;
            HSSFRow row = sheet.createRow(nowRow);
            HSSFCellStyle style0 = createStyle2(workbook, 3, "�s�ө���", "");//���Y-�a�k
            HSSFCellStyle style1 = createStyle2(workbook, 4, "�s�ө���", "");//���Y-�a��

            setColumn(sheet, row, style1, 0, FOOTER_1, false, false, null, null, null, null);
            setColumn(sheet, row, style0, 1, FOOTER_2, false, false, null, null, null, null);
            setColumn(sheet, row, style1, 3, FOOTER_3, false, false, null, null, null, null);
            setColumn(sheet, row, style1, 5, FOOTER_4, false, false, null, null, null, null);
            setColumn(sheet, row, style1, 6, FOOTER_5, false, false, null, null, null, null);

            nowRow++;

            //�g�J����¾��
            //createworkbook(workbook, sheet, false, rtnList3, "", subTitle_3, subTitle_key_3, num_subTitle_3, nowRow, 1);
            // ���ͼȦs��
            File downloadFile = RptUtils.createTempFile(fileName);

            // ��X excel �ɪ����|
            String path = downloadFile.getPath();
            fileOutputString = new FileOutputStream(path);
            workbook.write(fileOutputString);
            RptUtils.cryptoDownloadParameterToResp(fileName, downloadFile, resp);
        } finally {
            if (fileOutputString != null) {
                fileOutputString.close();
            }
        }
    }

    private List<Map> sumByUserName(List<Map> rtnList2) {
        List<Map> newRtnList = new ArrayList<Map>();
        Map<String, Map> tmpMap = new HashMap();
        for (Map mp : rtnList2) {//"SPR_AMT","BLD_USR_NAME"
            if (tmpMap.containsKey(mp.get("BLD_USR_NAME"))) {
                Map mp2 = tmpMap.get(mp.get("BLD_USR_NAME"));
                mp2.put("SPR_AMT", obj2Big(mp2, "SPR_AMT", BigDecimal.ZERO).add(obj2Big(mp, "SPR_AMT", BigDecimal.ZERO)));
            } else {
                tmpMap.put((String) mp.get("BLD_USR_NAME"), mp);
            }
        }
        newRtnList.addAll(tmpMap.values());
        return newRtnList;
    }

}
