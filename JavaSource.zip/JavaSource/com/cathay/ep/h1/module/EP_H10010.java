package com.cathay.ep.h1.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.z0.module.EP_Z0C202;
import com.cathay.ep.z0.module.EP_Z0C301;
import com.cathay.rpt.CsvUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date Version Description Author
 * 2013/9/12   1.0 �s�W  �\�a�s
 *  <pre>
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ���Q�j�㯲���d�߼Ҳ�
 * �{���W��    EP_H10010 
 * ���n����    �d��DTEPC301_ú�O�������
 *  </pre>
 * @author �����@ 
 * @since 2014/1/2
 * 
 * Add method:  
 * 1. public void exportQueryList(Map<String, Object> exportConfig)
 * 2. private BigDecimal getBigDecimal(Object obj)
 * by i9300606 01/15/2014
 */
@SuppressWarnings("unchecked")
public class EP_H10010 {
    private static final Logger log = Logger.getLogger(EP_H10010.class);

    //    private static final String SQL_queryTOTAL_001 = "com.cathay.ep.h1.module.EP_H10010.SQL_queryTOTAL_001";

    //    private static final String SQL_queryTOTAL2_001 = "com.cathay.ep.h1.module.EP_H10010.SQL_queryTOTAL2_001";

    //    private static final String SQL_queryTOTAL3_001 = "com.cathay.ep.h1.module.EP_H10010.SQL_queryTOTAL3_001";

    private static final String SQL_queryRJT_AMT_001 = "com.cathay.ep.h1.module.EP_H10010.SQL_queryRJT_AMT_001";

    private static final String SQL_queryYEAR_MONTH_RJT_AMT_001 = "com.cathay.ep.h1.module.EP_H10010.SQL_queryYEAR_MONTH_RJT_AMT_001";

    /**
     * �d��ú�O�����ɸ��
     * @param queryType
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(String queryType, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(queryType)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_H10010_MSG_001")); //�d�ߺ������������
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        List<Map> rtnList = null;
        String RCV_YM = DATE.getDBDate().replace("-", "").substring(0, 6);//���Ѧ褸�����6�X�~��
        if ("A".equals(queryType)) {

            rtnList = new EP_Z0C301().queryH010List(RCV_YM, SUB_CPY_ID);
            log.debug("rtnList:" + rtnList);
            //            BigDecimal RCV_YM_bd = new BigDecimal(RCV_YM);

            List<String> lID = new ArrayList<String>();
            for (Map tempMap : rtnList) {
                String ID = MapUtils.getString(tempMap, "ID", "").trim();
                lID.add(ID);
                String CUS_NAME = MapUtils.getString(tempMap, "CUS_NAME", "").trim();
                tempMap.put("CUS_NAME", CUS_NAME);
                //tempMap.put("TOTAL", queryTOTAL(RCV_YM_bd, ID));
                //                tempMap.put("TOTAL3", queryTOTAL3(RCV_YM_bd, MapUtils.getString(tempMap, "ID")));
            }
            //���o����,�㯲��
            EP_Z0C202 modEP_Z0C202 = new EP_Z0C202();
            Map<String, BigDecimal> idTotal = modEP_Z0C202.queryH010TOTAL(RCV_YM, lID, SUB_CPY_ID);
            log.debug("idTotal:" + idTotal);
            Map<String, BigDecimal> idTotal3 = modEP_Z0C202.queryH010TOTAL3(RCV_YM, lID, SUB_CPY_ID);
            log.debug("idTotal3:" + idTotal3);
            for (Map tempMap : rtnList) {
                String ID = MapUtils.getString(tempMap, "ID", "").trim();
                //�������h���B
                BigDecimal RJT_AMT = queryRJT_AMT(RCV_YM, ID, SUB_CPY_ID);
                BigDecimal TOTAL = getBigDecimal(MapUtils.getString(idTotal, ID, "0"));
                log.debug("ID(TOTAL)(�����P�h���B):" + TOTAL);
                log.debug("ID(RJT_AMT):" + RJT_AMT);
                tempMap.put("TOTAL", TOTAL.subtract(RJT_AMT));

                log.debug("ID(TOTAL3):" + MapUtils.getString(idTotal3, ID, "0"));
                tempMap.put("TOTAL3", getBigDecimal(MapUtils.getString(idTotal3, ID, "0")));

            }

        } else if ("B".equals(queryType)) {
            rtnList = new EP_Z0C202().queryH010List(RCV_YM, SUB_CPY_ID);
            log.debug("rtnList:" + rtnList);
            //            String RCV_YM2 = RCV_YM.substring(0, 4) + "01";
            //            DataSet ds = Transaction.getDataSet();
            //            ds.setField("RCV_YM", RCV_YM);
            //            ds.setField("RCV_YM2", RCV_YM2);
            //
            //            rtnList = VOTool.findToMaps(ds, SQL_queryList_002);
            //            BigDecimal RCV_YM_bd = new BigDecimal(RCV_YM);
            List<String> lID = new ArrayList<String>();
            for (Map tempMap : rtnList) {
                String ID = MapUtils.getString(tempMap, "ID", "").trim();
                lID.add(ID);
                String CUS_NAME = MapUtils.getString(tempMap, "CUS_NAME", "").trim();
                tempMap.put("CUS_NAME", CUS_NAME);

            }
            EP_Z0C202 modEP_Z0C202 = new EP_Z0C202();
            EP_Z0C301 modEP_Z0C301 = new EP_Z0C301();
            Map<String, BigDecimal> idTotal2 = modEP_Z0C301.queryH010TOTAL2(RCV_YM, lID, SUB_CPY_ID);
            log.debug("idTotal2:" + idTotal2);
            Map<String, BigDecimal> idTotal3 = modEP_Z0C202.queryH010TOTAL3(RCV_YM, lID, SUB_CPY_ID);
            log.debug("idTotal3:" + idTotal3);

            //�������h���B, ���o���,�㯲��
            for (Map tempMap : rtnList) {
                String ID = MapUtils.getString(tempMap, "ID", "").trim();
                BigDecimal RJT_AMT = queryRJT_AMT(RCV_YM, ID, SUB_CPY_ID);
                BigDecimal TOTAL = new BigDecimal(MapUtils.getString(tempMap, "TOTAL", "0"));
                tempMap.put("TOTAL", TOTAL.subtract(RJT_AMT)); //�ֿn����
                //                tempMap.put("TOTAL", ((BigDecimal) tempMap.get("TOTAL"))
                //                        .subtract(queryRJT_AMT(RCV_YM_bd, MapUtils.getString(tempMap, "ID"))));
                //tempMap.put("TOTAL2", queryTOTAL2(RCV_YM_bd, MapUtils.getString(tempMap, "ID")));
                //tempMap.put("TOTAL3", queryTOTAL3(RCV_YM_bd, MapUtils.getString(tempMap, "ID")));
                tempMap.put("TOTAL2", getBigDecimal(MapUtils.getString(idTotal2, ID, "0"))); //��ú���
                tempMap.put("TOTAL3", getBigDecimal(MapUtils.getString(idTotal3, ID, "0"))); //�㯲��
            }
        }

        return rtnList;

    }

    /**
     * �d�߷��~�ײ֭p�ܷ��믲���`�M
     * @param RCV_YM
     * @param ID
     * @return
     * @throws ModuleException
     */
    private BigDecimal queryTOTAL(BigDecimal RCV_YM, String ID, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (RCV_YM == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_002")); //�����~�묰�������
        }
        if (StringUtils.isEmpty(ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_003")); //�Τ@�s�����������
        }
        if (eie != null) {
            throw eie;
        }

        String RCV_YM_string = RCV_YM.toString();
        List<String> IDs = new ArrayList();
        IDs.add(ID);

        //        String RCV_YM2 = RCV_YM_string.substring(0, 4) + "01";
        //
        //        DataSet ds = Transaction.getDataSet();
        //        ds.setField("RCV_YM", RCV_YM);
        //        ds.setField("RCV_YM2", RCV_YM2);
        //        ds.setFieldValues("ID", IDs);
        //
        //        DBUtil.searchAndRetrieve(ds, SQL_queryTOTAL_001);
        //        ds.next();

        try {
            Map rtnData = new EP_Z0C202().queryH010TOTAL(RCV_YM_string, IDs, SUB_CPY_ID);
            return getBigDecimal(MapUtils.getString(rtnData, ID, "0"));
        } catch (DataNotFoundException e) {
            return BigDecimal.ZERO;
        }

    }

    /**
     * �d�߷��~�ײ֭p�ܷ������`�M
     * @param RCV_YM
     * @param ID
     * @return
     * @throws ModuleException
     */
    public BigDecimal queryTOTAL2(BigDecimal RCV_YM, String ID, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (RCV_YM == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_002")); //�����~�묰�������
        }
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_003")); //�Τ@�s�����������
        }
        if (eie != null) {
            throw eie;
        }

        //        DataSet ds = Transaction.getDataSet();
        //        ds.setField("RCV_YM", RCV_YM);
        //        ds.setField("ID", ID);
        //        DBUtil.searchAndRetrieve(ds, SQL_queryTOTAL2_001);
        //        ds.next();
        //
        //        return getBigDecimal(ds.getField(0));
        String RCV_YM_string = RCV_YM.toString();
        List<String> IDs = new ArrayList();
        IDs.add(ID);
        try {
            Map rtnData = new EP_Z0C301().queryH010TOTAL2(RCV_YM_string, IDs, SUB_CPY_ID);
            return getBigDecimal(MapUtils.getString(rtnData, ID, "0"));
        } catch (DataNotFoundException e) {
            return BigDecimal.ZERO;
        }

    }

    /**
     * �d�߷��~�ײ֭p�ܷ���㯲���`�M
     * @param RCV_YM
     * @param ID
     * @return
     * @throws ModuleException
     */
    public BigDecimal queryTOTAL3(BigDecimal RCV_YM, String ID, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (RCV_YM == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_002")); //�����~�묰�������
        }
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_003")); //�Τ@�s�����������
        }
        if (eie != null) {
            throw eie;
        }

        String RCV_YM_string = RCV_YM.toString();
        //        String RCV_YM2 = RCV_YM_string.substring(0, 4) + "01";
        //        DataSet ds = Transaction.getDataSet();
        //        ds.setField("RCV_YM", RCV_YM);
        //        ds.setField("RCV_YM2", RCV_YM2);
        //        ds.setField("ID", ID);
        //        DBUtil.searchAndRetrieve(ds, SQL_queryTOTAL3_001);
        //        ds.next();
        //
        //        return getBigDecimal(ds.getField(0));
        List<String> IDs = new ArrayList();
        IDs.add(ID);
        try {
            Map rtnData = new EP_Z0C202().queryH010TOTAL3(RCV_YM_string, IDs, SUB_CPY_ID);
            return getBigDecimal(MapUtils.getString(rtnData, ID, "0"));
        } catch (DataNotFoundException e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * ���o��ID�~�׾P�h�O��
     * @param RCV_YM
     * @param ID
     * @return
     * @throws ModuleException
     */
    public BigDecimal queryRJT_AMT(String RCV_YM, String ID, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (RCV_YM == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_002")); //�����~�묰�������
        }
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_003")); //�Τ@�s�����������
        }
        if (eie != null) {
            throw eie;
        }

        String RCV_YM2 = RCV_YM.substring(0, 4) + "01";

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("RCV_YM2", RCV_YM2);//�~��
        ds.setField("ID", ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_queryRJT_AMT_001);
        ds.next();

        return getBigDecimal(ds.getField(0));
    }

    /**
     * ���o��ID����+�~�׾P�h�O��
     * @param RCV_YM
     * @param ID
     * @return
     * @throws ModuleException 
     * @throws ModuleException
     */
    public Map queryYEAR_MONTH_RJT_AMT(String RCV_YM, String ID, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (RCV_YM == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_002")); //�����~�묰�������
        }
        if (StringUtils.isEmpty(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10010_MSG_003")); //�Τ@�s�����������
        }
        if (eie != null) {
            throw eie;
        }

        String RCV_YM2 = RCV_YM.substring(0, 4) + "01";

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("RCV_YM2", RCV_YM2);//�~��
        ds.setField("ID", ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryYEAR_MONTH_RJT_AMT_001, false);
        if (rtnMap == null) {
            return new HashMap();
        }

        return rtnMap;
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param msg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(msg);
        return eie;
    }

    /**
     * �ץXú�O�����ɸ�� add by i9300606 in 01/14/2014
     * @param queryType
     * @return
     * @throws Exception 
     */
    public List<Map> exportQueryList(Map<String, Object> exportConfig) throws Exception {
        String queryType = MapUtils.getString(exportConfig, "QUERY_TYPE");
        String RCV_YM = DATE.getDBDate().replace("-", "").substring(0, 6);//���Ѧ褸�����6�X�~��
        String fileName = MapUtils.getString(exportConfig, "fileName");
        String gridJSON = MapUtils.getString(exportConfig, "gridJSON");
        String SUB_CPY_ID = MapUtils.getString(exportConfig, "SUB_CPY_ID");
        CsvUtils csvUtils = new CsvUtils(fileName, (ResponseContext) exportConfig.get("resp"));
        //���o���Y�θ��(JSON)
        csvUtils.initBatchExportSetting(gridJSON);
        BigDecimal RCV_YM_bd = new BigDecimal(RCV_YM);

        List<Map> rtnList = new ArrayList<Map>();
        BatchQueryDataSet bqds = Transaction.getBatchQueryDataSet();
        bqds.setField("RCV_YM", RCV_YM);
        bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
        try {
            if ("A".equals(queryType)) {
                new EP_Z0C301().bqdsH010Search(bqds, RCV_YM, SUB_CPY_ID);
                while (csvUtils.fetchData(bqds)) {
                    while (csvUtils.next(bqds)) {
                        Map rtnMap = csvUtils.getCurrentMap();
                        rtnList.add(rtnMap);
                        for (Object key : rtnMap.keySet()) {
                            if (rtnMap.get(key) == null) {
                                rtnMap.put(key, "");
                            }
                        }
                        //���o����,�㯲��
                        rtnMap.put("TOTAL", queryTOTAL(RCV_YM_bd, MapUtils.getString(rtnMap, "ID"), SUB_CPY_ID));
                        rtnMap.put("TOTAL3", queryTOTAL3(RCV_YM_bd, MapUtils.getString(rtnMap, "ID"), SUB_CPY_ID));
                        csvUtils.batchCreateCsv();
                    }
                }

            } else if ("B".equals(queryType)) {
                new EP_Z0C202().bqdsH010Search(bqds, RCV_YM, SUB_CPY_ID);
                //                String RCV_YM2 = RCV_YM.substring(0, 4) + "01";
                //                bqds.setField("RCV_YM2", RCV_YM2);
                //                bqds.searchAndRetrieve(SQL_queryList_002);

                while (csvUtils.fetchData(bqds)) {
                    while (csvUtils.next(bqds)) {
                        Map rtnMap = csvUtils.getCurrentMap();
                        rtnList.add(rtnMap);
                        for (Object key : rtnMap.keySet()) {
                            if (rtnMap.get(key) == null) {
                                rtnMap.put(key, "");
                            }
                        }
                        String ID = MapUtils.getString(rtnMap, "ID");
                        //�������h���B, ���o���,�㯲��
                        BigDecimal RJT_AMT = queryRJT_AMT(RCV_YM, ID, SUB_CPY_ID);
                        BigDecimal TOTAL = new BigDecimal(MapUtils.getString(rtnMap, "TOTAL", "0"));
                        rtnMap.put("TOTAL", TOTAL.subtract(RJT_AMT));

                        rtnMap.put("TOTAL2", queryTOTAL2(RCV_YM_bd, ID, SUB_CPY_ID));
                        rtnMap.put("TOTAL3", queryTOTAL3(RCV_YM_bd, ID, SUB_CPY_ID));
                        csvUtils.batchCreateCsv();
                    }
                }
            }

            return rtnList;

        } finally {
            if (bqds != null) {
                bqds.close();
            }
        }
    }

    /**
     * Add by i9300606 01/14/2014
     * �ഫ����Ƭ�Bigdecimal
     * @param obj
     * @return BigDecimal
     */
    private BigDecimal getBigDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }

        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }

        return BigDecimal.ZERO;
    }
}
