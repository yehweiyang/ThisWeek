package com.cathay.ep.h1.module;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * DATE Description Author
 * 2013/11/13  Created ���կ�
 *  <pre>
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �����U������d�ߺ��@�Ҳ�
 * �Ҳ�ID    EP_H10050
 * ���n����    �����U������d�ߺ��@�Ҳ�
 *  </pre>
 * @author �����@ 
 * @since 2014/1/3
 * 
 * Add the selection "8".
 * by i9300606 03/04/2014
 * 
 * 
 * Add methods below:
 * 1.private String getSQLKeyByQRY_KIND(String QRY_KIND)
 * 2.private void getCNName(Map rtnMap)
 * 3.public void exportQueryList(String SUB_CPY_ID, String QRY_KIND, 
 * String QRY_STR_DATE, String QRY_END_DATE, Map exportConfig)
 * by i9300606 01/16/2014
 */
@SuppressWarnings("unchecked")
public class EP_H10050 {

    private static final String SQL_queryList_001 = "com.cathay.ep.h1.module.EP_H10050.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.h1.module.EP_H10050.SQL_queryList_002";

    private static final String SQL_queryList_003 = "com.cathay.ep.h1.module.EP_H10050.SQL_queryList_003";

    private static final String SQL_queryList_004 = "com.cathay.ep.h1.module.EP_H10050.SQL_queryList_004";

    private static final String SQL_queryList_005 = "com.cathay.ep.h1.module.EP_H10050.SQL_queryList_005";

    private static final String SQL_queryList_006 = "com.cathay.ep.h1.module.EP_H10050.SQL_queryList_006";

    private static final String SQL_queryList_007 = "com.cathay.ep.h1.module.EP_H10050.SQL_queryList_007";

    private static final String SQL_queryList_008 = "com.cathay.ep.h1.module.EP_H10050.SQL_queryList_008";

    /**
     * Ū�������U������d�߲M��
     * @param SUB_CPY_ID
     * @param QRY_KIND
     * @param QRY_STR_DATE
     * @param QRY_END_DATE
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(String SUB_CPY_ID, String QRY_KIND, String QRY_STR_DATE, String QRY_END_DATE) throws ModuleException {
        /*
        1.  �����U���կ�����k:
            (a)��կ��ɬd�ߨC���w�ի������̤j�w�դ�, �åѽկ��]�w�ɨ��o�������j��Ӥw�դ�����̤p���կ���
            (b)�ѽկ��]�w�ɬd�ߩ|���կ����������̤p���կ���
        2.  //5��~�H�W�������ե���
            (a)���o�կ��]�w�ɦ��]�w, ���q�������կ���q���H�u�կ���
            (b)���o�����D�ɳ]�w�ݽկ�, �����]�w�կ������
        */
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_001")); //�����q�O���o���ŭ�
        }

        if (!StringUtils.isNumeric(QRY_KIND)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_002")); //�d�ߺ����ǤJ���~
        } else {
            int qry = Integer.parseInt(QRY_KIND);
            if (qry < 1 || qry > 8) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_002")); //�d�ߺ����ǤJ���~
            }
        }

        if ("4".equals(QRY_KIND)) {
            if (StringUtils.isBlank(QRY_STR_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_003")); //�d�߰_�餣�o���ŭ�
            } else if (!DATE.isDate(QRY_STR_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_004")); //�d�߰_��榡���~
            }
            if (StringUtils.isBlank(QRY_END_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_005")); //�d�ߨ��餣�o���ŭ�
            } else if (!DATE.isDate(QRY_END_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_006")); //�d�ߨ���榡���~
            }
        }

        if ("8".equals(QRY_KIND)) {
            if (StringUtils.isBlank(QRY_END_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_005")); //�d�ߨ��餣�o���ŭ�
            } else if (!DATE.isDate(QRY_END_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_006")); //�d�ߨ���榡���~
            }
        }

        if (eie != null) {
            throw eie;
        }

        //�H�ǤJ�d�߫����U������d�߲M��G
        List<Map> rtnList;
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if ("4".equals(QRY_KIND)) {
            ds.setField("QRY_STR_DATE", QRY_STR_DATE);
            ds.setField("QRY_END_DATE", QRY_END_DATE);
        } else if ("8".equals(QRY_KIND)) {
            if (StringUtils.isNotEmpty(QRY_STR_DATE)) {
                ds.setField("QRY_STR_DATE", QRY_STR_DATE);
            }
            ds.setField("QRY_END_DATE", QRY_END_DATE);
        } else if ("2".equals(QRY_KIND)) {
            ds.setField("NEXT_PAY_DATE", DATE.getDBDate());
        }
        rtnList = VOTool.findToMaps(ds, getSQLKeyByQRY_KIND(QRY_KIND));
        //�s�W����^�ǲM�� 
        for (Map rtnMap : rtnList) {
            getCNName(rtnMap);
        }

        return rtnList;

    }

    /**
     * ���o���~�T��
     * @param eie
     * @param msg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(msg);
        return eie;
    }

    /**
     *  Add by i9300606 01/16/2014
     * @param QRY_KIND
     * @return
     */
    private String getSQLKeyByQRY_KIND(String QRY_KIND) {

        switch (Integer.parseInt(QRY_KIND)) {
            case 1:
                return SQL_queryList_001;//�U���կ���p�󤵤��, �����o�Ҧ��������U���կ���, �A�ѥD��join �����U���կ�����o�U���կ���<=���骺�ץ�
            case 2:
                return SQL_queryList_002;//�U����ú��p�󤵤��
            case 3:
                return SQL_queryList_003;//���ĥ�����p�󤵤�
            case 4:
                return SQL_queryList_004;//���ĥ����鸨���J����
            case 5:
                return SQL_queryList_005;//��~�H�W�������ե���
            case 6:
                return SQL_queryList_006;//�L�ĥ�����j�󤵤�
            case 7:
                return SQL_queryList_007;//��~�H�W���ݽկ�����
            case 8:
                return SQL_queryList_008;//�U����ú��p�󤵤��(�[�J�_����d��)
        }

        return null;
    }

    /**
     *  Add by i9300606 01/16/2014
     * @param rtnMap
     * @return
     */
    private void getCNName(Map rtnMap) {
        String PAY_FREQ = MapUtils.getString(rtnMap, "PAY_FREQ");
        String CRT_STS = MapUtils.getString(rtnMap, "CRT_STS");
        String CUS_STS = MapUtils.getString(rtnMap, "CUS_STS");
        String ADJ_TYPE = MapUtils.getString(rtnMap, "ADJ_TYPE");
        String ADJ_PM = MapUtils.getString(rtnMap, "ADJ_PM");
        rtnMap.put("PAY_FREQ_NM", FieldOptionList.getName("EP", "PAY_FREQ", PAY_FREQ));
        rtnMap.put("CRT_STS_NM", FieldOptionList.getName("EP", "CRT_STS", CRT_STS));
        rtnMap.put("CUS_STS_NM", FieldOptionList.getName("EP", "CUS_STS", CUS_STS));
        rtnMap.put("ADJ_TYPE_NM", FieldOptionList.getName("EP", "ADJ_TYPE", ADJ_TYPE));
        rtnMap.put("ADJ_PM_NM", FieldOptionList.getName("EP", "ADJ_PM", ADJ_PM));

        String ADJ_UNIT_NUM = MapUtils.getString(rtnMap, "ADJ_UNIT_NUM", "");
        String ADJ_UNIT = MapUtils.getString(rtnMap, "ADJ_UNIT");
        if (StringUtils.isNotBlank(ADJ_UNIT_NUM)) {
            if ("2".equals(ADJ_UNIT)) {
                rtnMap.put("ADJ_UNIT_NUM_NM", ADJ_UNIT_NUM + "%");
            } else {
                rtnMap.put("ADJ_UNIT_NUM_NM", rtnMap.get("ADJ_UNIT_NUM"));
            }
        } else {
            rtnMap.put("ADJ_UNIT_NUM_NM", "");
        }

    }

    /**
     * Export�����U������d�߲M��
     * Add by i9300606 01/16/2014
     * @param SUB_CPY_ID
     * @param QRY_KIND
     * @param QRY_STR_DATE
     * @param QRY_END_DATE
     * @return
     * @throws Exception 
     */
    public List<Map> exportQueryList(String SUB_CPY_ID, String QRY_KIND, String QRY_STR_DATE, String QRY_END_DATE, Map exportConfig)
            throws Exception {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_001")); //�����q�O���o���ŭ�
        }

        if (!StringUtils.isNumeric(QRY_KIND)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_002")); //�d�ߺ����ǤJ���~
        } else {
            int qry = Integer.parseInt(QRY_KIND);
            if (qry < 1 || qry > 8) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_002")); //�d�ߺ����ǤJ���~
            }
        }

        if ("4".equals(QRY_KIND)) {
            if (StringUtils.isBlank(QRY_STR_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_003")); //�d�߰_�餣�o���ŭ�
            } else if (!DATE.isDate(QRY_STR_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_004")); //�d�߰_��榡���~
            }
            if (StringUtils.isBlank(QRY_END_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_005")); //�d�ߨ��餣�o���ŭ�
            } else if (!DATE.isDate(QRY_END_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_006")); //�d�ߨ���榡���~
            }
        }

        if ("8".equals(QRY_KIND)) {
            if (StringUtils.isBlank(QRY_END_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_005")); //�d�ߨ��餣�o���ŭ�
            } else if (!DATE.isDate(QRY_END_DATE)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_H10050_MSG_006")); //�d�ߨ���榡���~
            }
        }

        if (eie != null) {
            throw eie;
        }

        String fileName = MapUtils.getString(exportConfig, "fileName");
        String gridJSON = MapUtils.getString(exportConfig, "gridJSON");
        UserObject user = (UserObject) exportConfig.get("userObject");
        XlsUtils xlsUtils = new XlsUtils(fileName, 100, 10, (ResponseContext) exportConfig.get("resp"));
        //���o���Y�θ��(JSON)
        xlsUtils.initBatchExportSetting(gridJSON, 1);

        //�H�ǤJ�d�߫����U������d�߲M��G
        BatchQueryDataSet bqds = Transaction.getBatchQueryDataSet();
        bqds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if ("4".equals(QRY_KIND)) {
            bqds.setField("QRY_STR_DATE", QRY_STR_DATE);
            bqds.setField("QRY_END_DATE", QRY_END_DATE);
        } else if ("8".equals(QRY_KIND)) {
            if (StringUtils.isNotEmpty(QRY_STR_DATE)) {
                bqds.setField("QRY_STR_DATE", QRY_STR_DATE);
            }
            bqds.setField("QRY_END_DATE", QRY_END_DATE);
        } else if ("2".equals(QRY_KIND)) {
            bqds.setField("NEXT_PAY_DATE", DATE.getDBDate());
        }

        List<Map> rtnList = new ArrayList<Map>();
        try {
            bqds.searchAndRetrieve(getSQLKeyByQRY_KIND(QRY_KIND));
            LocaleDisplay locale = new LocaleDisplay("EP", user);
            while (xlsUtils.fetchData(bqds)) {
                while (xlsUtils.next(bqds)) {
                    Map rtnMap = xlsUtils.getCurrentMap();
                    rtnList.add(rtnMap);
                    for (Object key : rtnMap.keySet()) {
                        if (rtnMap.get(key) == null) {
                            rtnMap.put(key, "");
                        }
                    }
                    getCNName(rtnMap);

                    rtnMap.put("RNT_STR_DATE", locale.formatDate((Date) bqds.getField("RNT_STR_DATE"), "/", ""));
                    rtnMap.put("RNT_END_DATE", locale.formatDate((Date) bqds.getField("RNT_END_DATE"), "/", ""));
                    rtnMap.put("NEXT_PAY_DATE", locale.formatDate((Date) bqds.getField("NEXT_PAY_DATE"), "/", ""));
                    rtnMap.put("NEXT_ADJ_DATE", locale.formatDate((Date) bqds.getField("NEXT_ADJ_DATE"), "/", ""));
                    xlsUtils.batchCreateXls();
                }
            }
        } finally {
            if (bqds != null) {
                bqds.close();
            }
        }
        return rtnList;
    }
}
