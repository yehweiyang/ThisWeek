package com.cathay.ep.h1.module;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE Description Author
 * 2013/11/12  Created ���կ�
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �ݽT�{�����d�ߺ��@�Ҳ�
 * �Ҳ�ID    EP_H10040
 * ���n����    �ݽT�{�����d�ߺ��@�Ҳ�
 * </pre>
 * @author �x�Ԫ�
 * @since 2014/1/15
 */
@SuppressWarnings("unchecked")
public class EP_H10040 {

    private static final String SQL_queryList_001 = "com.cathay.ep.h1.module.EP_H10040.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.h1.module.EP_H10040.SQL_queryList_002";

    private static final String SQL_queryList_003 = "com.cathay.ep.h1.module.EP_H10040.SQL_queryList_003";

    private static final String SQL_queryList_004 = "com.cathay.ep.h1.module.EP_H10040.SQL_queryList_004";

    /**
     * Ū���ݽT�{�����M��
     * @param SUB_CPY_ID   String  �����q�O
     * @param QRY_KIND     String  �d�ߺ���
     *                      <pre>
     *                      1 �������ĵL�ǧO����
     *                      2 �������ĵL�������
     *                      3 �����L�Ħ��ǧO����
     *                      4 �����L�Ħ��������
     *                      </pre>
     * @return rtnList List<Map>   �ݽT�{������� (�h��)
     */
    public List<Map> queryList(String SUB_CPY_ID, String QRY_KIND) throws Exception {
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("QRY_KIND", QRY_KIND);
        return this.comQuery(reqMap, null, false);
    }

    /**
     * �U��
     * @param reqMap �d�߸��
     * @param resp
     * @throws ModuleException
     */
    public List<Map> xlsDownLoad(Map reqMap, ResponseContext resp) throws Exception {
        return this.comQuery(reqMap, resp, true);
    }

    /**
     * �@�P�d��
     * @param reqMap �d�߸��
     * @param isDownLoad �O�_�U��
     * @param resp
     * @return rtnList
     * @throws Exception 
     */
    private List<Map> comQuery(Map reqMap, ResponseContext resp, boolean isDownLoad) throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        String QRY_KIND = MapUtils.getString(reqMap, "QRY_KIND");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(QRY_KIND)) {
            eie = getErrorInputException(eie, "EP_H10040_MSG_001");//�d�ߺ������o���ŭ�!
        } else if (!ArrayUtils.contains(new String[] { "1", "2", "3", "4" }, QRY_KIND)) {
            eie = getErrorInputException(eie, "EP_H10040_MSG_002");//�d�ߺ������~!
        }
        if (eie != null) {
            throw eie;
        }

        String SQL;
        if ("1".equals(QRY_KIND)) {
            //�������ĵL�ǧO����
            SQL = SQL_queryList_001;
        } else if ("2".equals(QRY_KIND)) {
            //�������ĵL�������
            SQL = SQL_queryList_002;
        } else if ("3".equals(QRY_KIND)) {
            //�����L�Ħ��ǧO����
            SQL = SQL_queryList_003;
        } else {
            //"4".equals(QRY_KIND))
            //�����L�Ħ��������
            SQL = SQL_queryList_004;
        }

        StringBuffer sb = new StringBuffer();
        //�U��
        if (isDownLoad) {
            //�ɦW:QRY_KIND���N�X�W�� + ��_�� +YYYYMMDD.xls  
            String QRY_KIND_NM = FieldOptionList.getName("EP", "QRY_KIND_H140", QRY_KIND);

            String fileName = sb.append(QRY_KIND_NM).append("_").append(DATE.toDate_yyyyMMdd(DATE.getDBDate())).toString();
            sb.setLength(0);
            XlsUtils xlsUtils = new XlsUtils(fileName, resp);
            BatchQueryDataSet bqds = new BatchQueryDataSet();
            bqds.setConnName(Transaction.getDataSet().getConnName());
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            List<Map> rtnList = new ArrayList<Map>();
            try {
                String gridJSON = MapUtils.getString(reqMap, "gridJSON");
                bqds.searchAndRetrieve(SQL);

                if (xlsUtils != null) {
                    xlsUtils.initBatchExportSetting(gridJSON, 1);
                    while (xlsUtils.fetchData(bqds)) {
                        while (xlsUtils.next(bqds)) {
                            Map dataMap = xlsUtils.getCurrentMap();
                            rtnList.add(dataMap);
                            String RNT_TYPE = MapUtils.getString(dataMap, "RNT_TYPE", "");
                            dataMap.put("RNT_TYPE_NM", sb.append(RNT_TYPE).append(FieldOptionList.getName("EP", "RNT_TYPE", RNT_TYPE))
                                    .toString());
                            sb.setLength(0);
                            xlsUtils.batchCreateXls();
                        }
                    }
                }

            } finally {
                if (bqds != null) {
                    bqds.close();
                }
            }
            return rtnList;
        }

        //�@��d��
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL);
        List<Map> rtnList = new ArrayList<Map>();

        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            String RNT_TYPE = MapUtils.getString(rtnMap, "RNT_TYPE", "");
            rtnMap.put("RNT_TYPE_NM", sb.append(RNT_TYPE).append(FieldOptionList.getName("EP", "RNT_TYPE", RNT_TYPE)).toString());
            sb.setLength(0);
            rtnList.add(rtnMap);
        }
        return rtnList;

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}
