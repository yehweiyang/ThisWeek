package com.cathay.ep.h1.module;

import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.util.DATE;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.util.MessageUtil;
import com.igsapp.db.DBException;

/**
 * <pre>
 * �ҲզW�� �����q���d�߼Ҳ�
 * �Ҳ�ID    EP_H1Z040 extends EP_H1Z010
 * ���n����    �����q���d�߼Ҳ�
 * </pre>
 * @author �¶i��
 * @since  2013/12/12
 */
@SuppressWarnings("unchecked")
public class EP_H1Z040 extends EP_H1Z010 {

    private static final String SQL_queryCompBqds_001 = "com.cathay.ep.h1.module.EP_H1Z040.SQL_queryCompBqds_001";

    /**
     * Ū�����q�Ȥ�X������
     * @param reqMap
     * @return
     * @throws ErrorInputException
     * @throws DBException
     */
    public BatchQueryDataSet queryCompBqds(Map reqMap) throws ErrorInputException, DBException {

        String SUB_CPY_ID;
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_H1Z040_MSG_001")); // �����q�O���o����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_H1Z040_MSG_001")); // �����q�O���o����
            }
        }

        BatchQueryDataSet bqds = new BatchQueryDataSet();

        bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
        bqds.setField("QRY_DATE", DATE.getDBDate());

        bqds.searchAndRetrieve(SQL_queryCompBqds_001);

        return bqds;
    }

    /**
     * ������
     * @param bqds
     * @param fieldNo
     * @return
     */
    public String getFieldValue(BatchQueryDataSet bqds, String fieldNo) {

        String fieldValue = super.getFieldValue(bqds, fieldNo);

        if ("CITY_BLD_NAME".equals(fieldNo)) {
            //�����j�ӦW��
            String CITY_BLD_NAME = ObjectUtils.toString(bqds.getField("ZIP_NAME"), "");
            if (CITY_BLD_NAME.length() > 3) {
                CITY_BLD_NAME = CITY_BLD_NAME.substring(0, 3);
            }
            fieldValue = CITY_BLD_NAME + ObjectUtils.toString(bqds.getField("BLD_NAME"));
        } else if ("CUS_NAME".equals(fieldNo)) {
            fieldValue = ObjectUtils.toString(bqds.getField("CUS_NAME"), "").substring(0, 40);
        }

        return fieldValue;
    }
}
