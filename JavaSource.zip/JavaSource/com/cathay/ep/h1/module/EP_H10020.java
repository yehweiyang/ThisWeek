package com.cathay.ep.h1.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.b1.module.EP_B1Z001;
import com.cathay.ep.b2.module.EP_B20010;
import com.cathay.ep.z0.module.EP_Z0C301;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2013/9/13   1.0 �s�W  �\�a�s
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ���Y�H��Ƭd�߼Ҳ�
 * �{���W��    EP_H10020 
 * ���n����    �d��DTEPC301_ú�O�������
 * </pre>
 * 
 * [20180312] �ק��
 * �s�W:���Y�H�h�~�ׯ����j��1000�U���
 * [20181109] ���D��20181001-0133�վ�:���Y�H�㯲���B�����B�޲z�O�ץX�覡(xls->xlsx)
 * 
 * @author �x�Ԫ�
 * @since 2014/1/10
 */
@SuppressWarnings("unchecked")
public class EP_H10020 {
    private static final Logger log = Logger.getLogger(EP_H10020.class);

    private static final boolean isDebug = log.isDebugEnabled();

    private static final String SQL_queryListA_001 = "com.cathay.ep.h1.module.EP_H10020.SQL_queryListA_001";

    // private static final String SQL_queryListB_001 = "com.cathay.ep.h1.module.EP_H10020.SQL_queryListB_001";

    private static final String SQL_queryListC_001 = "com.cathay.ep.h1.module.EP_H10020.SQL_queryListC_001";

    private static final String SQL_queryListE_001 = "com.cathay.ep.h1.module.EP_H10020.SQL_queryListE_001";

    private static final String SQL_queryListF_001 = "com.cathay.ep.h1.module.EP_H10020.SQL_queryListF_001";

    private static final String SQL_queryList_001 = "com.cathay.ep.h1.module.EP_H10020.SQL_queryList_001";

    private static final String SQL_queryListD_001 = "com.cathay.ep.h1.module.EP_H10020.SQL_queryListD_001";

    private static final String SQL_queryListD_002 = "com.cathay.ep.h1.module.EP_H10020.SQL_queryListD_002";

    private static final String SQL_queryListD_003 = "com.cathay.ep.h1.module.EP_H10020.SQL_queryListD_003";

    private static final String SQL_queryListD_004 = "com.cathay.ep.h1.module.EP_H10020.SQL_queryListD_004";

    /**
     * �d�ߤ覡
     * @param DATA_TYPE String �d�ߤ覡
     * @param user UserObject �ϥΪ̸�T
     * @return rtnMap  Map ���Y�H�ֿn�������
     */
    public Map queryList(String DATA_TYPE, UserObject user, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(DATA_TYPE)) {
            eie = getErrorInputException(eie, "EP_H10020_MSG_001");//�d�ߤ覡���o����!
        } else if (!ArrayUtils.contains(new String[] { "A1", "A2", "A3", "B", "C", "D", "D1", "D2", "D3", "E", "F" }, DATA_TYPE)) {
            eie = getErrorInputException(eie, "EP_H10020_MSG_002");//�d�ߤ覡���~!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_H10020_MSG_007");//�ϥΪ̸�T���o����!
        }
        if (eie != null) {
            throw eie;
        }
        //���Y�H���νs�qEPZ002���o

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> Z002 = VOTool.findToMaps(ds, SQL_queryList_001, false);
        if (Z002 == null || Z002.isEmpty()) {
            throw new ModuleException(MessageUtil.getMessage("EP_H10020_MSG_003"));//�гq���t�ΤH���]�w���Y�H���
        }
        StringBuilder sb = new StringBuilder();
        String[] ID = StrToList(Z002, sb);
        sb.setLength(0);

        Map rtnMap = new HashMap();

        if ("A1".equals(DATA_TYPE)) {
            rtnMap.put("rtnList", this.queryListA(null, ID, ds, sb, SUB_CPY_ID));//���Y�H�ֿn�������
        } else if ("A2".equals(DATA_TYPE)) {
            rtnMap.put("rtnList", this.queryListA(new BigDecimal("3000000"), ID, ds, sb, SUB_CPY_ID));//���Y�H�ֿn�����j��300�U���
        } else if ("A3".equals(DATA_TYPE)) {
            rtnMap.put("rtnList", this.queryListA(new BigDecimal("500000000"), ID, ds, sb, SUB_CPY_ID));//���Y�H�ֿn�����j��5�����
        } else if ("B".equals(DATA_TYPE)) {
            //���Y�H������
            List<Map> rtnList = new EP_Z0C301().queryH020List(ID, ds, SUB_CPY_ID);
            for (Map data : rtnList) {
                String value = MapUtils.getString(data, "CUS_NAME", "");
                data.put("CUS_NAME", value.trim());
            }
            rtnMap.put("rtnList", rtnList);
        } else if ("C".equals(DATA_TYPE)) {
            rtnMap.put("rtnList", this.queryListC(ID, ds, sb, SUB_CPY_ID));//���Y�H�޲z�O���
        } else if (DATA_TYPE.startsWith("D")) {
            if (DATA_TYPE.equals("D3")) {
                //[20181109]�S�Ψ�ǤJ�ѼƲ���
                rtnMap = this.queryListD3(ID, ds, sb, SUB_CPY_ID);//���Y�H�O�Ҫ����
            } else {
                rtnMap = this.queryListD(ID, ds, sb, DATA_TYPE, SUB_CPY_ID);//���Y�H�㯲�����
            }
        } else if ("E".equals(DATA_TYPE)) {
            rtnMap.put("rtnList", this.queryListE(ID, SUB_CPY_ID, ds));//���Y�H�ǧO���
        } else if ("F".equals(DATA_TYPE)) {
            rtnMap.put("rtnList", this.queryListF(ID, SUB_CPY_ID, ds));// �h�~�ׯ����j��1000�U���
        }

        return rtnMap;
    }

    /**
     * �ץX���
     * @param reqMap
     * @param user
     * @param resp
     * @throws Exception
     */
    public List<Map> export(Map reqMap, UserObject user, ResponseContext resp) throws Exception {
        //[20181109] �ץX�覡xls�אּxlsx
        Map rtnMap = this.queryList(MapUtils.getString(reqMap, "DATA_TYPE"), user, MapUtils.getString(reqMap, "SUB_CPY_ID"));
        List<Map> rtnList = (List<Map>) MapUtils.getObject(rtnMap, "rtnList");
        XlsUtils xlsUtils = new XlsUtils(MapUtils.getString(reqMap, "fileName"), rtnList, resp, true);
        String gridJSON = MapUtils.getString(reqMap, "gridJSON");
        xlsUtils.initExportSetting(gridJSON);
        xlsUtils.execute(new XlsUtils.ListProcessHandler() {
        });
        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map tmpMap : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", tmpMap.get("ID"));
            logSecurityMap.put("CUS_NAME", tmpMap.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);
        }
        return logSecurityList;

    }

    /**
     * �d�����Y�H�ֿn�������
     * @param LOWERLIMIT BigDecimal  �����U��
     * @param ID
     * @param ds
     * @param sb
     * @return    rtnList List<Map>   ���Y�H�ֿn�������
     */
    private List<Map> queryListA(BigDecimal LOWERLIMIT, String[] ID, DataSet ds, StringBuilder sb, String SUB_CPY_ID)
            throws ModuleException {

        String RCV_YM = DATE.getTodayYearAndMonth();//���褸�~��
        String RCV_YM2 = sb.append(RCV_YM.substring(0, 4)).append("01").toString();//(RCV_YM�������01)
        sb.setLength(0);
        //ú�ں���:1����4�H����5�X�����a7��L
        ds.clear();
        ds.setFieldValues("ID", ID);
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("RCV_YM2", RCV_YM2);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (LOWERLIMIT != null) {
            ds.setField("LOWERLIMIT", LOWERLIMIT);
        }
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryListA_001);
        EP_H10010 theEP_H10010 = new EP_H10010();
        BigDecimal big_RCV_YM = new BigDecimal(RCV_YM);
        for (Map tempMap : rtnList) {
            String mapID = MapUtils.getString(tempMap, "ID");
            //�����������B
            Map RJT_AMTs = theEP_H10010.queryYEAR_MONTH_RJT_AMT(RCV_YM, mapID, SUB_CPY_ID);
            BigDecimal RJT_AMT_YEAR = STRING.objToBigDecimal(RJT_AMTs.get("RJT_AMT_YEAR"), BigDecimal.ZERO);
            BigDecimal TOTAL_YEAR = new BigDecimal(MapUtils.getString(tempMap, "TOTAL_YEAR", "0"));
            tempMap.put("TOTAL_YEAR", TOTAL_YEAR.subtract(RJT_AMT_YEAR)); //�ֿn����(���~)

            BigDecimal RJT_AMT_MONTH = STRING.objToBigDecimal(RJT_AMTs.get("RJT_AMT"), BigDecimal.ZERO);
            BigDecimal TOTAL = new BigDecimal(MapUtils.getString(tempMap, "TOTAL", "0"));
            tempMap.put("TOTAL", TOTAL.subtract(RJT_AMT_MONTH)); //�ֿn����(����)

            tempMap.put("TOTAL2", theEP_H10010.queryTOTAL2(big_RCV_YM, mapID, SUB_CPY_ID));//��ú���
            tempMap.put("TOTAL3", theEP_H10010.queryTOTAL3(big_RCV_YM, mapID, SUB_CPY_ID));//�㯲��
        }
        return rtnList;

    }

    /**
     * �d�����Y�H������
     * @param ID
     * @param ds 
     * @return   rtnList List<Map>   ���Y�H������
     */
    //    private List<Map> queryListB(String[] ID, DataSet ds) throws ModuleException {
    //        ds.clear();
    //        ds.setFieldValues("ID", ID);
    //        return VOTool.findToMaps(ds, SQL_queryListB_001);
    //    }
    /**
     * �d�����Y�H�޲z�O���
     * @param ID
     * @param sb
     * @return  rtnList List<Map>   ���Y�H�޲z�O���
     */
    private List<Map> queryListC(String[] ID, DataSet ds, StringBuilder sb, String SUB_CPY_ID) throws ModuleException {
        String RCV_YM = DATE.getYearAndMonth(DATE.getMonthLastDate());//���褸�~�몺����
        ds.clear();
        String RCV_YM2 = sb.append(RCV_YM.substring(0, 4)).append("01").toString();//(RCV_YM�������01)
        ds.setFieldValues("ID", ID);
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("RCV_YM2", RCV_YM2);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_queryListC_001);

    }

    /**
     * �d�����Y�H�㯲�����
     * @param ID
     * @param sb
     * @return  rtnMap  Map 
     *                  Key=rtnList value=���Y�H�㯲�����
     *                  Key=KeyList value=rtnList��Map��Key�c����List
     */
    private Map queryListD(String[] ID, DataSet ds, StringBuilder sb, String DATA_TYPE, String SUB_CPY_ID) throws ModuleException {

        String today = DATE.getDBDate();
        String RCV_YM1 = DATE.getYearAndMonth(DATE.addDate(today, 0, -3, 0));//���褸�~��-1�Ӥ�
        String RCV_YM2 = DATE.getYearAndMonth(DATE.addDate(today, 0, -2, 0));//���褸�~��-2�Ӥ�
        String RCV_YM3 = DATE.getYearAndMonth(DATE.addDate(today, 0, -1, 0));//���褸�~��-3�Ӥ�
        List<Map> keyList = new ArrayList<Map>();//�N�U��쪺key��J
        //[20181109] ���D��20181001-0133�վ�:���Y�H�㯲���B�����B�޲z�O
        //�d�X�Ҧ����
        ds.clear();
        ds.setField("RCV_YM1", RCV_YM1);
        ds.setField("RCV_YM2", RCV_YM2);

        ds.setField("RCV_YM3", RCV_YM3);
        ds.setFieldValues("ID", ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> dataList = null;

        if ("D".equals(DATA_TYPE) || "D2".equals(DATA_TYPE)) {//���, �޲z�O
            if ("D".equals(DATA_TYPE)) {
                ds.setField("PAY_KIND", 2);
            } else if ("D2".equals(DATA_TYPE)) {
                ds.setField("PAY_KIND", 3);
            }
            dataList = VOTool.findToMaps(ds, SQL_queryListD_002, false);
        } else if ("D1".equals(DATA_TYPE)) {//����, �O�Ҫ�
            if ("D1".equals(DATA_TYPE)) {
                ds.setField("PAY_KIND1", 1);
            }
            dataList = VOTool.findToMaps(ds, SQL_queryListD_003, false);
        }

        if (dataList == null || dataList.isEmpty()) {
            Map rtnMap = new HashMap();
            rtnMap.put("keyList", keyList);
            log.fatal("�d�L���");
            return rtnMap;
        }
        if (isDebug)
            log.debug("### dataList::" + dataList);

        EP_B20010 theEP_B20010 = new EP_B20010();
        String RCV_ROC_YM1 = DATE.getROCYearAndMonth(RCV_YM1);
        String RCV_ROC_YM2 = DATE.getROCYearAndMonth(RCV_YM2);
        String RCV_ROC_YM3 = DATE.getROCYearAndMonth(RCV_YM3);

        List<String> filterIDs = new ArrayList<String>();
        for (Map dataMap : dataList) {
            BigDecimal INV_AMT = STRING.objToBigDecimal(dataMap.get("INV_AMT"), BigDecimal.ZERO);
            if ("D1".equals(DATA_TYPE)) {//�����ݦ����h���B
                dataMap.put("INV_AMT", INV_AMT.subtract(STRING.objToBigDecimal(dataMap.get("RJT_AMT"), BigDecimal.ZERO)));
            }
            if (INV_AMT.compareTo(BigDecimal.ZERO) > 0) {
                String filterId = MapUtils.getString(dataMap, "ID");
                if (!filterIDs.contains(filterId)) {
                    filterIDs.add(filterId);
                }
            }
        }
        if (isDebug)
            log.debug("### filterIDs::" + filterIDs);

        for (int i = 0; i < filterIDs.size(); i++) {
            String id = filterIDs.get(i);
            // key = AMT_0, AMT_1, AMT_2, AMT_3,�K
            Map map = new HashMap();
            map.put("SUB_CPY_ID", "00");
            map.put("ID", id);
            map.put("IS_EXACT", "Y");
            String CUS_NAME;
            try {
                List<Map> B201List = theEP_B20010.queryList(map);
                CUS_NAME = MapUtils.getString(B201List.get(0), "CUS_NAME", id);
            } catch (DataNotFoundException dnfe) {
                log.fatal("�d�L�����Ȥ���:" + id);
                CUS_NAME = id;
            }
            Map keymap = new HashMap();
            keymap.put("key", "AMT_" + (i * 3));
            keymap.put("header", CUS_NAME.trim() + " " + RCV_ROC_YM1 + " " + id);
            keyList.add(keymap);
            keymap = new HashMap();
            keymap.put("key", "AMT_" + (i * 3 + 1));
            keymap.put("header", CUS_NAME.trim() + " " + RCV_ROC_YM2 + " " + id);
            keyList.add(keymap);
            keymap = new HashMap();
            keymap.put("key", "AMT_" + (i * 3 + 2));
            keymap.put("header", CUS_NAME.trim() + " " + RCV_ROC_YM3 + " " + id);
            keyList.add(keymap);
        }

        if (isDebug)
            log.debug("### keyList::" + keyList);

        //�j�ӥN���M��
        ds.clear();
        ds.setFieldValues("ID", filterIDs);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_queryListD_001);
        List<String> BLD_CDList = new ArrayList<String>();
        while (ds.next()) {
            BLD_CDList.add((String) ds.getField(0));
        }
        if (isDebug)
            log.debug("### BLD_CDList::" + BLD_CDList);

        //���নMultikeyMap, �A��z���
        MultiKeyMap mkm = new MultiKeyMap();
        //BLD_CDList.clear();
        for (Map tempMap : dataList) {
            mkm.put(MapUtils.getString(tempMap, "BLD_CD").trim(), MapUtils.getString(tempMap, "ID").trim(), MapUtils.getString(tempMap,
                "RCV_YM").trim(), tempMap);
            //BLD_CDList.add(BLD_CD);
        }
        if (isDebug)
            log.debug("### mkm::" + mkm);

        //��z��rtnList
        List rtnList = new ArrayList();
        EP_A10010 bldmod = new EP_A10010();
        String map_BLD_NAME = "";
        for (String BLD_CD : BLD_CDList) {
            Map newMap = new HashMap();
            Boolean hasData = false;
            for (int i = 0; i < filterIDs.size(); i++) {
                String id = filterIDs.get(i);
                Map YM1Map = (Map) mkm.get(BLD_CD, id, RCV_YM1);
                String AMT_key_1 = sb.append("AMT_").append(i * 3).toString();
                sb.setLength(0);
                if (YM1Map == null || YM1Map.isEmpty()) {
                    newMap.put(AMT_key_1, "");
                } else {
                    newMap.put(AMT_key_1, MapUtils.getString(YM1Map, "INV_AMT", ""));
                    map_BLD_NAME = MapUtils.getString(YM1Map, "BLD_NAME");
                    if (StringUtils.isNotBlank(map_BLD_NAME)) {
                        newMap.put("BLD_NAME", map_BLD_NAME);
                    }
                }
                Map YM2Map = (Map) mkm.get(BLD_CD, id, RCV_YM2);
                String AMT_key_2 = sb.append("AMT_").append(i * 3 + 1).toString();
                sb.setLength(0);
                if (YM2Map == null || YM2Map.isEmpty()) {
                    newMap.put(AMT_key_2, "");
                } else {
                    newMap.put(AMT_key_2, MapUtils.getString(YM2Map, "INV_AMT", ""));
                    map_BLD_NAME = MapUtils.getString(YM2Map, "BLD_NAME");
                    if (StringUtils.isNotBlank(map_BLD_NAME)) {
                        newMap.put("BLD_NAME", map_BLD_NAME);
                    }
                }
                Map YM3Map = (Map) mkm.get(BLD_CD, id, RCV_YM3);
                String AMT_key_3 = sb.append("AMT_").append(i * 3 + 2).toString();
                sb.setLength(0);
                if (YM3Map == null || YM3Map.isEmpty()) {
                    newMap.put(AMT_key_3, "");
                } else {
                    newMap.put(AMT_key_3, MapUtils.getString(YM3Map, "INV_AMT", ""));
                    map_BLD_NAME = MapUtils.getString(YM3Map, "BLD_NAME");
                    if (StringUtils.isNotBlank(map_BLD_NAME)) {
                        newMap.put("BLD_NAME", map_BLD_NAME);
                    }
                }
                String ACNT_DIV_NO = ArrayUtils.contains(new String[] { "A", "B", "C", "D", "E", "T" }, BLD_CD.substring(0, 1)) ? "8300100"
                        : "8300200";
                newMap.put("ACNT_DIV_NO", ACNT_DIV_NO);
                newMap.put("BLD_CD", BLD_CD);

                if (StringUtils.isBlank(MapUtils.getString(newMap, "BLD_NAME", ""))) {
                    try {
                        Map reqMap = new HashMap();
                        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
                        reqMap.put("BLD_CD", BLD_CD);
                        Map rtnMap = bldmod.queryMap(reqMap);
                        newMap.put("BLD_NAME", MapUtils.getString(rtnMap, "BLD_NAME", ""));
                    } catch (Exception e) {
                        // TODO: handle exception
                    }
                }
                if ((YM1Map != null && !YM1Map.isEmpty() && STRING.objToBigDecimal(YM1Map.get("INV_AMT"), BigDecimal.ZERO).compareTo(
                    BigDecimal.ZERO) > 0)
                        || (YM2Map != null && !YM2Map.isEmpty() && STRING.objToBigDecimal(YM2Map.get("INV_AMT"), BigDecimal.ZERO)
                                .compareTo(BigDecimal.ZERO) > 0)
                        || (YM3Map != null && !YM3Map.isEmpty() && STRING.objToBigDecimal(YM3Map.get("INV_AMT"), BigDecimal.ZERO)
                                .compareTo(BigDecimal.ZERO) > 0)) {
                    hasData = true;
                }

            }
            if (hasData) {
                rtnList.add(newMap);
            }
        }
        if (isDebug)
            log.debug("### rtnList::" + rtnList);
        
        Map rtnMap = new HashMap();
        rtnMap.put("keyList", keyList);
        rtnMap.put("rtnList", rtnList);
        return rtnMap;
    }

    /**
     * �d�����Y�H�O�Ҫ����
     * @param ID
     * @param sb
     * @return  rtnMap  Map 
     *                  Key=rtnList value=���Y�H�㯲�����
     *                  Key=KeyList value=rtnList��Map��Key�c����List
     */
    private Map queryListD3(String[] ID, DataSet ds, StringBuilder sb, String SUB_CPY_ID) throws ModuleException {

        String today = DATE.getDBDate();
        String RCV_YM1 = DATE.getYearAndMonth(DATE.addDate(today, 0, -1, 0));//���褸�~��-1�Ӥ�
        List<Map> keyList = new ArrayList<Map>();//�N�U��쪺key��J
        //[20181109] ���D��20181001-0133�վ�:���Y�H�㯲���B�����B�޲z�O
        //�d�X�Ҧ����
        ds.clear();
        ds.setField("RCV_YM1", RCV_YM1);
        ds.setFieldValues("ID", ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        List<Map> dataList = VOTool.findToMaps(ds, SQL_queryListD_004, false);//�O�Ҫ�
        if (dataList == null) {
            Map rtnMap = new HashMap();
            rtnMap.put("keyList", keyList);
            return rtnMap;
        }

        List<String> filterIDs = new ArrayList<String>();
        for (Map dataMap : dataList) {
            if (STRING.objToBigDecimal(dataMap.get("INV_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {
                String filterId = MapUtils.getString(dataMap, "ID");
                if (!filterIDs.contains(filterId)) {
                    filterIDs.add(filterId);
                }
            }
        }

        EP_B20010 theEP_B20010 = new EP_B20010();
        String RCV_ROC_YM1 = DATE.getROCYearAndMonth(RCV_YM1);

        for (int i = 0; i < filterIDs.size(); i++) {
            // key = AMT_0, AMT_1, AMT_2, AMT_3,�K
            String id = filterIDs.get(i);
            Map map = new HashMap();
            map.put("SUB_CPY_ID", "00");
            map.put("ID", id);
            map.put("IS_EXACT", "Y");
            String CUS_NAME;
            try {
                List<Map> B201List = theEP_B20010.queryList(map);
                CUS_NAME = MapUtils.getString(B201List.get(0), "CUS_NAME", id);
            } catch (DataNotFoundException dnfe) {
                log.fatal("�d�L�����Ȥ���:" + id);
                CUS_NAME = id;
            }
            Map keymap = new HashMap();
            keymap.put("key", sb.append("AMT_").append(i * 3).toString());
            sb.setLength(0);
            keymap.put("header", sb.append(CUS_NAME.trim()).append(" ").append(RCV_ROC_YM1).append(" ").append(id).toString());
            sb.setLength(0);
            keyList.add(keymap);
        }
        //�j�ӥN���M��
        ds.clear();
        ds.setFieldValues("ID", filterIDs);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_queryListD_001);
        List<String> BLD_CDList = new ArrayList<String>();
        while (ds.next()) {
            BLD_CDList.add((String) ds.getField(0));
        }
        //���নMultikeyMap, �A��z���
        MultiKeyMap mkm = new MultiKeyMap();
        //BLD_CDList.clear();
        for (Map tempMap : dataList) {
            String BLD_CD = MapUtils.getString(tempMap, "BLD_CD").trim();
            String temp_ID = MapUtils.getString(tempMap, "ID").trim();
            mkm.put(BLD_CD, temp_ID, tempMap);
            //BLD_CDList.add(BLD_CD);
        }
        //��z��rtnList
        List rtnList = new ArrayList();
        EP_A10010 bldmod = new EP_A10010();
        for (String BLD_CD : BLD_CDList) {
            Map newMap = new HashMap();

            Boolean hasData = false;
            for (int i = 0; i < filterIDs.size(); i++) {
                String id = filterIDs.get(i);
                Map YM1Map = (Map) mkm.get(BLD_CD, id);
                String AMT_key_1 = sb.append("AMT_").append(i * 3).toString();
                sb.setLength(0);
                if (YM1Map == null || YM1Map.isEmpty()) {
                    newMap.put(AMT_key_1, "");
                } else {
                    newMap.put(AMT_key_1, MapUtils.getString(YM1Map, "INV_AMT", ""));
                    String map_BLD_NAME = MapUtils.getString(YM1Map, "BLD_NAME");
                    if (StringUtils.isNotBlank(map_BLD_NAME)) {
                        newMap.put("BLD_NAME", map_BLD_NAME);
                    }
                }

                String ACNT_DIV_NO = ArrayUtils.contains(new String[] { "A", "B", "C", "D", "E", "T" }, BLD_CD.substring(0, 1)) ? "8300100"
                        : "8300200";
                newMap.put("ACNT_DIV_NO", ACNT_DIV_NO);
                newMap.put("BLD_CD", BLD_CD);

                if (StringUtils.isBlank(MapUtils.getString(newMap, "BLD_NAME", ""))) {
                    try {
                        Map reqMap = new HashMap();
                        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
                        reqMap.put("BLD_CD", BLD_CD);
                        Map rtnMap = bldmod.queryMap(reqMap);
                        newMap.put("BLD_NAME", MapUtils.getString(rtnMap, "BLD_NAME", ""));
                    } catch (Exception e) {
                        // TODO: handle exception
                    }
                }
                if (YM1Map != null && !YM1Map.isEmpty()
                        && STRING.objToBigDecimal(YM1Map.get("INV_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {
                    hasData = true;
                }
            }
            if (hasData) {
                rtnList.add(newMap);
            }
        }
        Map rtnMap = new HashMap();
        rtnMap.put("keyList", keyList);
        rtnMap.put("rtnList", rtnList);
        return rtnMap;
    }

    /**
     * �d�����Y�H�޲z�O���
     * @param ID
     * @param SUB_CPY_ID
     * @param ds
     * @return   rtnList List<Map>   ���Y�H�޲z�O���
     */
    private List<Map> queryListE(String[] ID, String SUB_CPY_ID, DataSet ds) throws ModuleException {

        ds.clear();
        ds.setFieldValues("ID", ID);
        DBUtil.searchAndRetrieve(ds, SQL_queryListE_001);
        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map tempMap = VOTool.dataSetToMap(ds);
            tempMap.put("PAY_FREQ_NM", FieldOptionList.getName("EPC", "PAY_FREQ", MapUtils.getString(tempMap, "PAY_FREQ")));
            tempMap.put("TAX_TYPE_NM", FieldOptionList.getName("EPC", "TAX_TYPE", MapUtils.getString(tempMap, "TAX_TYPE")));
            tempMap.put("ADJ_TYPE_NM", FieldOptionList.getName("EPC", "ADJ_TYPE", MapUtils.getString(tempMap, "ADJ_TYPE")));
            tempMap.put("ADJ_PM_NM", FieldOptionList.getName("EPC", "ADJ_PM", MapUtils.getString(tempMap, "ADJ_PM")));
            rtnList.add(tempMap);
        }
        //�त��,���o�կ���v/���
        EP_B1Z001 theEP_B1Z001 = new EP_B1Z001();
        for (Map tempMap : rtnList) {
            String CRT_NO = MapUtils.getString(tempMap, "CRT_NO");
            String CUS_NO = MapUtils.getString(tempMap, "CUS_NO");
            tempMap.putAll(theEP_B1Z001.getB105ADJ_UNIT(CRT_NO, CUS_NO, SUB_CPY_ID));
        }
        return rtnList;

    }

    /**
     * �d�����Y�H�������[20180312]
     * @param ID
     * @param SUB_CPY_ID
     * @param ds
     * @return   rtnList List<Map> ���Y�H�������
     */
    private List<Map> queryListF(String[] ID, String SUB_CPY_ID, DataSet ds) throws ModuleException {
        ds.clear();
        ds.setFieldValues("ID", ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_queryListF_001);
    }

    /**
     * �ץX���Ŷ��]�w
     * @param count
     * @return
     */
    //[20181109] ���D��20181001-0133�վ�:���Y�H�㯲���B�����B�޲z�O�ץX�覡(xls->xlsx
    //    private StringBuffer getSqlStr(int count) {
    //        StringBuffer sb = new StringBuffer(
    //                "SELECT SUB_CPY_ID FROM (SELECT a.SUB_CPY_ID FROM DBEP.DTEPA101 a,DBEP.DTEPB102 b ) ORDER BY SUB_CPY_ID fetch first ");
    //        sb.append(String.valueOf(count)).append(" rows only with ur");
    //
    //        return sb;
    //    }
    /**
     * �Nmap��� "VALUE1" "VALUE2" "VALUE3" �զ� ID ���
     * @param Z002
     * @param key
     * @throws ModuleException 
     */
    private String[] StrToList(List<Map> Z002List, StringBuilder sb) throws ModuleException {
        for (Map Z002 : Z002List) {
            String VALUE1 = MapUtils.getString(Z002, "VALUE1");
            if (StringUtils.isNotBlank(VALUE1)) {
                sb.append(VALUE1).append(',');
            }
            String VALUE2 = MapUtils.getString(Z002, "VALUE2");
            if (StringUtils.isNotBlank(VALUE2)) {
                sb.append(VALUE2).append(',');
            }
            String VALUE3 = MapUtils.getString(Z002, "VALUE3");
            if (StringUtils.isNotBlank(VALUE3)) {
                sb.append(VALUE3).append(',');
            }
        }

        String[] strArr = null;
        if (sb.length() == 0) {
            throw new ModuleException(MessageUtil.getMessage("EP_H10020_MSG_003"));//�гq���t�ΤH���]�w���Y�H���
        } else if (sb.length() > 0) {
            strArr = sb.deleteCharAt(sb.length() - 1).toString().split(",");
        }
        return strArr;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}
