package com.cathay.ep.h1.module;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.db.impl.DynamicBatchQueryDataSet;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE Description Author
 * 2013/11/28  Created ���կ�
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ����믲���ֹ���@�Ҳ�
 * �Ҳ�ID    EP_H10060
 * ���n����    ����믲���ֹ���@�Ҳ�
 * </pre>
 * @author �x�Ԫ�
 * @since 2014/1/15
 */
@SuppressWarnings("unchecked")
public class EP_H10060 {
    private static final String SQL_queryList_001 = "com.cathay.ep.h1.module.EP_H10060.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.h1.module.EP_H10060.SQL_queryList_002";

    /**
     * Ū������믲���ֹ����
     * @param SUB_CPY_ID  String  �����q�O
     * @param TAX_TYPE    String  �|�O���� 1 ���t  2 �~�[�Ψ�L
     * @return  rtnList List<Map>   ����믲���ֹ���� (�h��)
     */
    public List<Map> queryList(String SUB_CPY_ID, String TAX_TYPE) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(TAX_TYPE)) {
            eie = getErrorInputException(eie, "EP_H10060_MSG_001");//�|�O�������o���ŭ�!
        } else if (!ArrayUtils.contains(new String[] { "1", "2" }, TAX_TYPE)) {
            eie = getErrorInputException(eie, "EP_H10060_MSG_002");//�|�O�������~!
        }
        if (eie != null) {
            throw eie;
        }
        //�̵|�O���o���ī����Ȥ�䥼�|�믲����P�ǧO�믲�����[�`�����, �t���j��100�̫h�ǥX
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        boolean TAX_TYPE_1 = "1".equals(TAX_TYPE);
        String SQL;
        if (TAX_TYPE_1) {
            SQL = SQL_queryList_001;
        } else {
            SQL = SQL_queryList_002;
        }
        MultiKeyMap mkm = new MultiKeyMap();
        StringBuffer sb = new StringBuffer();
        DBUtil.searchAndRetrieve(ds, SQL);
        List<Map> tmpList = new ArrayList<Map>();
        if (TAX_TYPE_1) {
            BigDecimal onepfive = new BigDecimal("1.05");
            while (ds.next()) {
                Map tmap = VOTool.dataSetToMap(ds);
                String CRT_NO = MapUtils.getString(tmap, "CRT_NO");
                String CUS_NO = MapUtils.getString(tmap, "CUS_NO");
                BigDecimal RNT_SIZE = (BigDecimal) MapUtils.getObject(tmap, "RNT_SIZE", BigDecimal.ZERO);//���n
                BigDecimal FNL_AMT = (BigDecimal) MapUtils.getObject(tmap, "FNL_AMT", BigDecimal.ZERO);//�ǧO���
                BigDecimal A103_CAL_AMT = FNL_AMT.multiply(RNT_SIZE);//�ǧO���*���n
                if (mkm.containsKey(CRT_NO, CUS_NO)) {
                    Map map = (Map) mkm.get(CRT_NO, CUS_NO);
                    BigDecimal bef_A103_CAL_AMT = (BigDecimal) MapUtils.getObject(map, "A103_CAL_AMT", BigDecimal.ZERO);
                    //�v���p�⦹�Ȥ᪺�ǧO���*���n���[�`���B
                    BigDecimal cul_A103_CAL_AMT = bef_A103_CAL_AMT.add(A103_CAL_AMT);
                    BigDecimal B102_NO_TAX_AMT = (BigDecimal) MapUtils.getObject(map, "B102_NO_TAX_AMT", BigDecimal.ZERO);
                    BigDecimal DIFF_AMT = B102_NO_TAX_AMT.subtract(cul_A103_CAL_AMT).abs();
                    map.put("A103_CAL_AMT", cul_A103_CAL_AMT);
                    map.put("DIFF_AMT", DIFF_AMT);
                } else {
                    //���|���B
                    BigDecimal RNT_AMT = (BigDecimal) MapUtils.getObject(tmap, "RNT_AMT", BigDecimal.ZERO);//��|�ˤ��J����
                    //�p��e����Ƥ��t�����B
                    BigDecimal B102_NO_TAX_AMT = RNT_AMT.divide(onepfive, 0, BigDecimal.ROUND_HALF_UP);
                    BigDecimal DIFF_AMT = B102_NO_TAX_AMT.subtract(A103_CAL_AMT).abs();
                    Map rtnMap = new HashMap();
                    rtnMap.put("CRT_NO", CRT_NO);
                    rtnMap.put("CUS_NO", CUS_NO);
                    rtnMap.put("CUS_NAME", tmap.get("CUS_NAME"));
                    rtnMap.put("TAX_TYPE", MapUtils.getString(tmap, "TAX_TYPE"));
                    rtnMap.put("BLD_CD", MapUtils.getString(tmap, "BLD_CD"));
                    rtnMap.put("BLD_NAME", MapUtils.getString(tmap, "BLD_NAME"));
                    rtnMap.put("RNT_AMT", RNT_AMT);//�믲��
                    rtnMap.put("B102_NO_TAX_AMT", B102_NO_TAX_AMT);
                    rtnMap.put("A103_CAL_AMT", A103_CAL_AMT);
                    rtnMap.put("TAX_TYPE_NM", MessageUtil.getMessage("EP_H10060_MSG_003"));//1���t
                    rtnMap.put("DIFF_AMT", DIFF_AMT);
                    mkm.put(CRT_NO, CUS_NO, rtnMap);
                    tmpList.add(rtnMap);
                }
            }
        } else {
            while (ds.next()) {
                Map tmap = VOTool.dataSetToMap(ds);
                String CRT_NO = MapUtils.getString(tmap, "CRT_NO");
                String CUS_NO = MapUtils.getString(tmap, "CUS_NO");
                BigDecimal RNT_SIZE = (BigDecimal) MapUtils.getObject(tmap, "RNT_SIZE", BigDecimal.ZERO);//���n
                BigDecimal FNL_AMT = (BigDecimal) MapUtils.getObject(tmap, "FNL_AMT", BigDecimal.ZERO);//�ǧO���
                BigDecimal A103_CAL_AMT = FNL_AMT.multiply(RNT_SIZE);//�ǧO���*���n

                BigDecimal B102_NO_TAX_AMT;
                if (mkm.containsKey(CRT_NO, CUS_NO)) {
                    Map map = (Map) mkm.get(CRT_NO, CUS_NO);
                    BigDecimal bef_A103_CAL_AMT = (BigDecimal) MapUtils.getObject(map, "A103_CAL_AMT", BigDecimal.ZERO);
                    //�v���p�⦹�Ȥ᪺�ǧO���*���n���[�`���B
                    BigDecimal cul_A103_CAL_AMT = bef_A103_CAL_AMT.add(A103_CAL_AMT);
                    B102_NO_TAX_AMT = (BigDecimal) MapUtils.getObject(map, "B102_NO_TAX_AMT", BigDecimal.ZERO);
                    BigDecimal DIFF_AMT = B102_NO_TAX_AMT.subtract(cul_A103_CAL_AMT).abs();
                    map.put("A103_CAL_AMT", cul_A103_CAL_AMT);
                    map.put("DIFF_AMT", DIFF_AMT);
                } else {
                    //���|���B
                    BigDecimal RNT_AMT = (BigDecimal) MapUtils.getObject(tmap, "RNT_AMT", BigDecimal.ZERO);//��|�ˤ��J����
                    //�p��e����Ƥ��t�����B
                    B102_NO_TAX_AMT = RNT_AMT;
                    BigDecimal DIFF_AMT = B102_NO_TAX_AMT.subtract(A103_CAL_AMT).abs();
                    Map rtnMap = new HashMap();
                    rtnMap.put("CRT_NO", CRT_NO);
                    rtnMap.put("CUS_NO", CUS_NO);
                    rtnMap.put("CUS_NAME", tmap.get("CUS_NAME"));
                    TAX_TYPE = MapUtils.getString(tmap, "TAX_TYPE");
                    rtnMap.put("TAX_TYPE", TAX_TYPE);
                    rtnMap.put("BLD_CD", MapUtils.getString(tmap, "BLD_CD"));
                    rtnMap.put("BLD_NAME", MapUtils.getString(tmap, "BLD_NAME"));
                    rtnMap.put("RNT_AMT", RNT_AMT);
                    rtnMap.put("B102_NO_TAX_AMT", B102_NO_TAX_AMT);
                    rtnMap.put("A103_CAL_AMT", A103_CAL_AMT);
                    rtnMap.put("TAX_TYPE_NM", sb.append(TAX_TYPE).append(FieldOptionList.getName("EP", "TAX_TYPE", TAX_TYPE)).toString());
                    sb.setLength(0);
                    rtnMap.put("DIFF_AMT", DIFF_AMT);
                    mkm.put(CRT_NO, CUS_NO, rtnMap);
                    tmpList.add(rtnMap);
                }
            }
        }

        List<Map> rtnList = new ArrayList<Map>();
        BigDecimal hungr = new BigDecimal("100");
        for (Object mulKey : mkm.keySet()) {
            Map dataMap = (Map) mkm.get(mulKey);
            BigDecimal map_DIFF_AMT = (BigDecimal) MapUtils.getObject(dataMap, "DIFF_AMT", BigDecimal.ZERO);
            if (map_DIFF_AMT.compareTo(hungr) > 0) {
                rtnList.add(dataMap);
            }
        }
        //�̷� BLD_CD ,CRT_NO,CUS_NO�Ƨ�
        Collections.sort(rtnList, new sortRule());
        return rtnList;

    }

    /**
     * �ץX�ɮ�
     * @param reqMap
     * @param resp
     * @throws Exception
     */
    public List<Map> exportXLS(String USER_CPY_ID, String TAX_TYPE, String gridJSON, String filename, ResponseContext resp) throws Exception {
        List<Map> rtnList = this.queryList(USER_CPY_ID, TAX_TYPE);

        StringBuffer sb = getSqlStr(rtnList.size());
        XlsUtils xlsUtils = new XlsUtils(filename, resp);
        // �Y�O�����ץX�ϥ� BatchQueryDataSet �H�קK�W�L2000��
        BatchQueryDataSet q = new BatchQueryDataSet();
        q.setDataSet(Transaction.getDataSet());
        BatchQueryDataSet bqds = new DynamicBatchQueryDataSet(q);

        int i = 0;
        try {
            bqds.searchAndRetrieve(sb.toString());
            if (xlsUtils != null) {

                xlsUtils.initBatchExportSetting(gridJSON, 1);
                while (xlsUtils.fetchData(bqds)) {
                    while (xlsUtils.next(bqds)) {
                        Map dataMap = xlsUtils.getCurrentMap();
                        dataMap.putAll((Map) rtnList.get(i));
                        i++;
                        xlsUtils.batchCreateXls();
                    }
                }
            }
        } finally {
            if (bqds != null) {
                bqds.close();
            }
        }
        return rtnList;
    }

    /**
     * �ץX���Ŷ��]�w
     * @param count
     * @return
     */
    private StringBuffer getSqlStr(int count) {
        StringBuffer sb = new StringBuffer(
                "SELECT SUB_CPY_ID FROM (SELECT a.SUB_CPY_ID FROM DBEP.DTEPA101 a,DBEP.DTEPB102 b ) ORDER BY SUB_CPY_ID fetch first ");
        sb.append(String.valueOf(count)).append(" rows only with ur");

        return sb;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /** 
     * �̷� BLD_CD ,CRT_NO,CUS_NO�Ƨ�
     */
    private class sortRule implements Comparator<Map> {

        public int compare(Map aMap, Map bMap) {

            //�j�ӥN��
            String aBLD_CD = MapUtils.getString(aMap, "BLD_CD");
            String bBLD_CD = MapUtils.getString(bMap, "BLD_CD");
            int i = aBLD_CD.compareTo(bBLD_CD);
            if (i != 0) {
                return i;
            }

            //�����N��
            String aCRT_NO = MapUtils.getString(aMap, "CRT_NO");
            String bCRT_NO = MapUtils.getString(bMap, "CRT_NO");
            int j = aCRT_NO.compareTo(bCRT_NO);
            if (j != 0) {
                return j;
            }

            //�Ȥ�Ǹ�
            String aCUS_NO = MapUtils.getString(aMap, "CUS_NO");
            String bCUS_NO = MapUtils.getString(bMap, "CUS_NO");
            int k = aCUS_NO.compareTo(bCUS_NO);

            return k;

        }
    }

}
