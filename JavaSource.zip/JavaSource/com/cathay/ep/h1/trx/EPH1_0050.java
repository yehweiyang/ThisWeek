package com.cathay.ep.h1.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.h1.module.EP_H10050;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Description                                 Author
 * 2013/11/13     Created                                   ���կ�
 * �@�B  �{���\�෧�n�����G
 * �{���W�� EPH1_0050
 * �{���\�� �����U������d��
 * ���n���� 
 * (1) ��l
 * (2) �d�� �w ���ѨϥΪ̬d�ߦU���������p��ơC
 * (3) �U�� �w ���ѨϥΪ̤U���d�ߵ��G�C
 * (4) �����N���W�s�� �V �s����ӯ����X�d�߭����C
 * (5) �U�����դ�W�s�� �V �s����կ��]�w�e��
 *</pre>
 * @author ù�ΫT
 * @since 2014-01-15
 */
@SuppressWarnings("unchecked")
public class EPH1_0050 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPH1_0050.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        StringBuilder sb = new StringBuilder();//�������~�T��

        try {
            String USER_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user); //���o�����q�O
            resp.addOutputData("USER_CPY_ID", USER_CPY_ID);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            sb.append(eie.getMessage());
            STRING.newLine(sb);
        }

        try {
            resp.addOutputData("QRY_KIND_LIST", FieldOptionList.getName("EP", "QRY_KIND_H150"));//���o�d�ߺ����M��
        } catch (Exception eie) {
            log.error("", eie);
            sb.append(eie.getMessage());
            STRING.newLine(sb);
        }

        if (sb.length() > 0) {
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, sb.toString());
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            resp.addOutputData("rtnList", query(reqMap));
            MessageUtil.setMsg(msg, "MI00020");//�d�ߦ��\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �d��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    private List query(Map reqMap) throws ModuleException {
        List<Map> rtnList = new EP_H10050().queryList(MapUtils.getString(reqMap, "USER_CPY_ID"), MapUtils.getString(reqMap, "QRY_KIND"),
            MapUtils.getString(reqMap, "QRY_STR_DATE"), MapUtils.getString(reqMap, "QRY_END_DATE"));
        //logSecurity
        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map rtnMap : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", rtnMap.get("ID"));
            logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);
        }
        logSecurity(logSecurityList);
        return rtnList;
    }

    /**
     * �ץXexcel
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String QRY_KIND = MapUtils.getString(reqMap, "QRY_KIND");
            String QRY_KIND_NAME = (String) (FieldOptionList.getName("EP", "QRY_KIND_H150")).get(QRY_KIND);
            String fileName = new StringBuilder(QRY_KIND_NAME).append("_").append(DATE.toDate_yyyyMMdd(DATE.getDBDate())).toString();

            Map<String, Object> exportConfig = new HashMap<String, Object>();
            exportConfig.put("fileName", fileName);
            exportConfig.put("resp", resp);
            exportConfig.put("gridJSON", MapUtils.getString(reqMap, "gridJSON"));
            exportConfig.put("userObject", user);
            List<Map> rtnList = new EP_H10050().exportQueryList(MapUtils.getString(reqMap, "USER_CPY_ID"), QRY_KIND, MapUtils.getString(
                reqMap, "QRY_STR_DATE"), MapUtils.getString(reqMap, "QRY_END_DATE"), exportConfig);
            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map rtnMap : rtnList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("ID", rtnMap.get("ID"));
                logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);

            MessageUtil.setMsg(msg, "EP_H10050_MSG_EXPORT_SUCCESS");//�ץX���\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil
                            .getMessage("EP_H10050_ERRMSG_EXPORT_FAILED"));//�ץX����
                }
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EP_H10050_ERRMSG_EXPORT_FAILED"));//�ץX����
        }

        return resp;
    }

}
