package com.cathay.ep.h1.trx;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.h1.module.EP_H10030;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Description Author
 * 2013/9/12   Created �\�a�s
 * 
 * UCEPH1_0030_�����v�έp�d�ߧ@�~
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �����v�έp�d�ߧ@�~
 * �{���W��    EPH1_0030
 * �@�~�覡    ONLINE
 * ���n����    (1) �d�ߡG�����v��Ƭd��
 *             (2) �U���G�U��excel���� 
 * </pre>
 * @author �x�Ԫ�
 * @since 2014/1/17
 */
@SuppressWarnings("unchecked")
public class EPH1_0030 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPH1_0030.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;
    
    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);
        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        //�uú�ں����v�U�Կ��
        resp.addOutputData("PAY_KIND_ONEList", FieldOptionList.getFieldOptions("EPC", "PAY_KIND_TWO"));
        //���o�����q�O
        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
        }
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            Map<String, List<Map>> rtnMap = this.query(reqMap, new EP_H10030());

            resp.addOutputData("rtnList1", (List<Map>) MapUtils.getObject(rtnMap, "rtnList1"));
            List<Map> rtnList2 = (List<Map>) MapUtils.getObject(rtnMap, "rtnList2");
            if (rtnList2 != null && !rtnList2.isEmpty()) {
                resp.addOutputData("SPR_AMT", new EP_H10030().calculateList(rtnList2, "SPR_AMT"));
            }
            resp.addOutputData("rtnList2", rtnList2);
            resp.addOutputData("rtnList3", (List<Map>) MapUtils.getObject(rtnMap, "rtnList3"));

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �@�μҲ�
     * @param reqMap
     * @param theEP_H10030
     */
    private Map<String, List<Map>> query(Map reqMap, EP_H10030 theEP_H10030) throws ModuleException, ParseException {
        String RCV_YM_str = MapUtils.getString(reqMap, "RCV_YM");
        BigDecimal RCV_YM = null;
        if (NumberUtils.isNumber(RCV_YM_str)) {
            RCV_YM = new BigDecimal(RCV_YM_str);
        }
        String PAY_S_DATE = MapUtils.getString(reqMap, "PAY_S_DATE");
        String PAY_E_DATE = MapUtils.getString(reqMap, "PAY_E_DATE");
        String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        return theEP_H10030.queryList(RCV_YM, PAY_S_DATE, PAY_E_DATE, PAY_KIND,SUB_CPY_ID);
    }

    /**
     * �ɮפU��
     * @param req
     * @return
     */
    public ResponseContext doDownload(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            //�ץX
            EP_H10030 theEP_H10030 = new EP_H10030();

            //���o�e���ϥθ��
            Map<String, List<Map>> rtnMap = this.query(reqMap, theEP_H10030);
            String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
            //�ץXEexcel
            //theEP_H10030.exportXLS(rtnMap, PAY_KIND, resp);
            theEP_H10030.exportXLS2(reqMap, rtnMap, PAY_KIND, resp, user);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH1_0030_ERRMSG_001");//�ɮפU������
            }
        } catch (Exception e) {
            log.error("�ɮפU������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPH1_0030_ERRMSG_001");//�ɮפU������
        }
        return resp;
    }

}
