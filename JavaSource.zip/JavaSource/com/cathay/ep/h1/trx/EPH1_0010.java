package com.cathay.ep.h1.trx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.h1.module.EP_H10010;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Description                                 Author
 * 2013/9/12     Created                                   �\�a�s
 * �@�B  �{���\�෧�n�����G
 * �ҲզW�� ���Q�j�㯲���d�ߧ@�~
 * �Ҳ�ID  EPH1_0010
 * ���n���� (1) �d�ߡG�������Ƭd��
 *       (2) �U���G�U��csv���� 
 *</pre>
 * @author ù�ΫT
 * @since 2014-01-13
 */
@SuppressWarnings("unchecked")
public class EPH1_0010 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPH1_0010.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);
        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        StringBuilder sb = new StringBuilder();//�������~�T��

        try {
            resp.addOutputData("QUERY_TYPEList", FieldOptionList.getFieldOptions("EPH", "QUERY_TYPE"));//�u�d�ߺ����v�U�Կ��
        } catch (Exception eie) {
            log.error("", eie);
            sb.append(eie.getMessage());
        }

        if (sb.length() > 0) {
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, sb.toString());
        }

        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC3_0022_MSG_002");//���o�����q�O����
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            resp.addOutputData("rtnList", query(reqMap));
            MessageUtil.setMsg(msg, "MI00020");
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �ץXcsv
     * @param req
     * @return
     */
    public ResponseContext doDownLoad(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String QUERY_TYPE = MapUtils.getString(reqMap, "QUERY_TYPE");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            String fileName = "";
            if ("A".equals(QUERY_TYPE)) {//�ֿn�e���Q�j��ú��������_YYYYMMDD.csv YYYYMMDD��CURRENT DATE
                fileName = new StringBuilder(MessageUtil.getMessage("EPH1_0010_MSG_QUERY_TYPE_A")).append("_").append(
                    DATE.toDate_yyyyMMdd(DATE.getDBDate())).toString();
            } else if ("B".equals(QUERY_TYPE)) {//�ֿn�e���Q�j���������
                fileName = new StringBuilder(MessageUtil.getMessage("EPH1_0010_MSG_QUERY_TYPE_B")).append("_").append(
                    DATE.toDate_yyyyMMdd(DATE.getDBDate())).toString();
            }

            Map<String, Object> exportConfig = new HashMap<String, Object>();
            exportConfig.put("fileName", fileName);
            exportConfig.put("QUERY_TYPE", QUERY_TYPE);
            exportConfig.put("resp", resp);
            exportConfig.put("gridJSON", MapUtils.getString(reqMap, "gridJSON"));
            exportConfig.put("SUB_CPY_ID", SUB_CPY_ID);
            logSecurity(new EP_H10010().exportQueryList(exportConfig));

            MessageUtil.setMsg(msg, "EPH1_0010_ERRMSG_EXPORT_SUCCESS");//�ץX���\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil
                            .getMessage("EPH1_0010_ERRMSG_EXPORT_ERROR"));//�ץX����
                }
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPH1_0010_ERRMSG_EXPORT_ERROR"));//�ץX����
        }

        return resp;
    }

    /**
     * �d��
     * @param reqMap
     * @return
     * @throws ModuleException
     */
    private List query(Map reqMap) throws ModuleException {
        List rtnList = new EP_H10010().queryList(MapUtils.getString(reqMap, "QUERY_TYPE"), MapUtils.getString(reqMap, "SUB_CPY_ID"));
        logSecurity(rtnList);
        return rtnList;
    }

}
