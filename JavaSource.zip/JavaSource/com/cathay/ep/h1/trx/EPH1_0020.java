package com.cathay.ep.h1.trx;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.h1.module.EP_H10020;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Description Author
 * 2013/9/14   Created �\�a�s
 * 
 * UCEPH1_0020_���Y�H��Ƭd�ߧ@�~

�@�B  �{���\�෧�n�����G
�{���\��    ���Y�H��Ƭd�ߧ@�~
�{���W��    EPH1_0020
�@�~�覡    ONLINE
���n����    (1) �d�ߡG���Y�H��Ƭd��
(2) �U���G�U��excel���� 

 * </pre>
 * @author �x�Ԫ�
 * @since 2014/1/13
 */
@SuppressWarnings("unchecked")
public class EPH1_0020 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPH1_0020.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);
        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);
        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        //�W�Ӥ몺����~��        ���B�榡
        DateFormat sdf = new SimpleDateFormat("yyyyMM");
        Calendar cal = Calendar.getInstance();
        //cal.add(Calendar.MONTH, -1);//�W�Ӥ�
        resp.addOutputData("dateym", sdf.format(cal.getTime()));
        //�u��������v�U�Կ��
        resp.addOutputData("DATA_TYPEList", FieldOptionList.getFieldOptions("EPH", "DATA_TYPE"));
        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC3_0022_MSG_002");//���o�����q�O����
        }
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map rtnMap = new EP_H10020().queryList(req.getParameter("DATA_TYPE"), user, req.getParameter("SUB_CPY_ID"));
            resp.addOutputData("keyList", (List<Map>) MapUtils.getObject(rtnMap, "keyList"));
            List<Map> rtnList = (List<Map>) MapUtils.getObject(rtnMap, "rtnList");
            if (rtnList == null || rtnList.isEmpty()) {
                throw new DataNotFoundException();
            }

            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map tmpMap : rtnList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("ID", tmpMap.get("ID"));
                logSecurityMap.put("CUS_NAME", tmpMap.get("CUS_NAME"));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);

            resp.addOutputData("rtnList", rtnList);
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �ɮפU��
     * @param req
     * @return
     */
    public ResponseContext doDownload(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("gridJSON", MapUtils.getString(reqMap, "gridJSON"));
            String fileName = "";
            String DATA_TYPE = MapUtils.getString(reqMap, "DATA_TYPE");
            fileName = (String) FieldOptionList.getName("EPH", "DATA_TYPE").get(DATA_TYPE);

            reqMap.put("fileName", new StringBuilder().append(fileName).append("_").append(DATE.toDate_yyyyMMdd(DATE.getDBDate()))
                    .toString());
            //�ץX
            new EP_H10020().export(reqMap, user, resp);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPH1_0020_ERRMSG_008");//�ɮפU������
            }
        } catch (Exception e) {
            log.error("�ɮפU������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB1_0020_ERRMSG_008");//�ɮפU������
        }
        return resp;
    }

}
