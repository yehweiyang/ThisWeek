package com.cathay.ep.c0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 * DATE    Description Author
 * 2014/03/21  Created ���i��
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �Ȧ��J�b�d�ߩ��Ӫ����ͼҲ�
 * �Ҳ�ID    EP_C0Z003
 * ���n����    �Ȧ��J�b�d�ߩ��Ӫ����ͼҲ�
 * 
 * �G�B�ϥ��ɮסG
 * ����  ���廡��    �ɮצW��
 * 1.      �Ȧ��� DBDK.DVDKG002_FOR_EP
 * 2.      �ӯ�����   DBEP.DTEPB102
 * </pre>
 * @author �¶��� 
 * @since 2014/3/26  
 */
@SuppressWarnings("unchecked")
public class EP_C0Z003 {

    /**
     * �榡�Ƴ������e   
     * @param SlipMap(�p�ݱƧǽХ�treeMap�ǤJ)
     * @param user
     * @return
     * @throws ErrorInputException
     */
    public Map doFormat(Map<String, List<Map>> SlipMap, UserObject user) throws ErrorInputException {
        if (SlipMap == null || SlipMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C0Z003_MSG_001"));//�d�߱��󤣱o���ŭ�
        }

        LocaleDisplay locale = new LocaleDisplay("EP", user);
        Iterator entries = SlipMap.entrySet().iterator();

        //���s( �ǲ����,�ǲ��帹,�s�����,�ǲ��ո�,���I�覡)
        ErrorInputException eie = null;
        List<Map> detailList = new ArrayList();
        while (entries.hasNext()) {
            Entry<String, List<Map>> thisEntry = (Entry<String, List<Map>>) entries.next();
            String key = thisEntry.getKey();
            List<Map> dataList = thisEntry.getValue();
            String[] keys = key.split(",");
            if (keys.length != 4) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_C0Z003_MSG_002"));//�ǤJ�d�߱���:�ǲ�����B�ǲ��帹�B�s�����B�ǲ��ո��Ҷ�����
            }

            if (StringUtils.isBlank(keys[0])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z003_MSG_003"));//�ǲ�������o���ŭ�
            } else if (!DATE.isDate(keys[0])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z003_MSG_004"));//�ǲ�����榡���~
            }
            if (StringUtils.isBlank(keys[1])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z003_MSG_005"));//�ǲ��帹���o���ŭ�
            }
            if (StringUtils.isBlank(keys[2])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z003_MSG_006"));//�s����줣�o���ŭ�
            }
            if (StringUtils.isBlank(keys[3])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z003_MSG_007"));//�ǲ��ո����o���ŭ�
            }

            if (eie != null) {
                throw eie;
            }

            String SLIP_DATE = locale.formatDate(Date.valueOf(keys[0]), "/", "");
            String SLIP_LOT_NO = keys[1];
            String SLIP_DIV_NO = keys[2];
            String SLIP_SET_NO = keys[3];
            BigDecimal TOTAL_ACNT_AMT = BigDecimal.ZERO;
            BigDecimal TOTAL_BAL_AMT = BigDecimal.ZERO;
            for (Map dataMap : dataList) {

                BigDecimal ACNT_AMT = this.objToDec(dataMap.get("ACNT_AMT"), BigDecimal.ZERO);
                BigDecimal BAL_AMT = this.objToDec(dataMap.get("BAL_AMT"), BigDecimal.ZERO);
                String COA_DATE = MapUtils.getString(dataMap, "COA_DATE");
                Map detailMap = new HashMap();

                detailMap.put("SLIP_DATE", SLIP_DATE);
                detailMap.put("SLIP_LOT_NO", SLIP_LOT_NO);
                detailMap.put("SLIP_DIV_NO", SLIP_DIV_NO);
                detailMap.put("SLIP_SET_NO", SLIP_SET_NO);
                detailMap.put("CRT_NO", MapUtils.getString(dataMap, "CRT_NO", ""));
                detailMap.put("CUS_NO", MapUtils.getString(dataMap, "CUS_NO", ""));
                detailMap.put("ACNT_SRC", "��X");
                detailMap.put("CHK_CD_NM", MapUtils.getString(dataMap, "CHK_CD_NM", ""));
                detailMap.put("PAY_KIND_NM", MapUtils.getString(dataMap, "PAY_KIND_NM", ""));
                detailMap.put("INPUT_ID", MapUtils.getString(dataMap, "INPUT_ID", ""));
                detailMap.put("BLD_CD", MapUtils.getString(dataMap, "BLD_CD", ""));
                detailMap.put("ID", MapUtils.getString(dataMap, "ID", ""));
                detailMap.put("CUS_NAME", MapUtils.getString(dataMap, "CUS_NAME", ""));
                detailMap.put("COA_DATE", StringUtils.isNotBlank(COA_DATE) ? locale.formatDate(Date.valueOf(COA_DATE), "/", "") : "");
                detailMap.put("PAY_NO", MapUtils.getString(dataMap, "PAY_NO", ""));
                detailMap.put("BLD_NAME", MapUtils.getString(dataMap, "BLD_NAME", ""));
                detailMap.put("ACNT_AMT", locale.formatNumber(ACNT_AMT, 2, "0"));//�Ȧ����B  
                detailMap.put("BAL_AMT", locale.formatNumber(BAL_AMT, 2, "0"));//�Ȧ��l�B 
                detailList.add(detailMap);

                //�p�p
                TOTAL_ACNT_AMT = TOTAL_ACNT_AMT.add(ACNT_AMT);
                TOTAL_BAL_AMT = TOTAL_BAL_AMT.add(BAL_AMT);
            }
            //��p�p
            Map lastMap = detailList.get(detailList.size() - 1);
            lastMap.put("SIZE", locale.formatNumber(dataList.size(), 0, "0"));//���
            lastMap.put("TOTAL_ACNT_AMT", locale.formatNumber(TOTAL_ACNT_AMT, 2, "0"));//�Ȧ����B  (�p�p)
            lastMap.put("TOTAL_BAL_AMT", locale.formatNumber(TOTAL_BAL_AMT, 2, "0"));// �Ȧ��l�B(�p�p)
        }

        Map params = new HashMap();
        params.put("CURRENT_DATE", locale.formatDate(DATE.today(), "/", ""));
        params.put("REPORT_ID", "EP_C0Z003");
        Map paramMap = new HashMap();
        paramMap.put("REPORT_ID", "EP_C0Z003");
        paramMap.put("params", params);
        paramMap.put("detail", detailList);

        return paramMap;

    }

    /**
     * �C�L�������
     * @param paramMap
     * @param resp
     * @throws ModuleException
     */
    public void doPrint(Map paramMap, ResponseContext resp) {

        JasperReportUtils.addOutputRptDataToResp((String) paramMap.get("REPORT_ID"), (Map) paramMap.get("params"), (List<Map>) paramMap
                .get("detail"), resp);

    }

    /**
     * ��BigDecimal
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal objToDec(Object o, BigDecimal defaultValue) {

        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

}
