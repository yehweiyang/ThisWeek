package com.cathay.ep.c0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.commons.collections.map.LinkedMap;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 * DATE    Description Author
 * 2014/03/20  Created ���i��
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �䲼�״ڰh�O���Ӫ����ͼҲ�
 * �Ҳ�ID    EP_C0Z002
 * ���n����    �䲼�״ڰh�O���Ӫ����ͼҲ�
 * 
 * �G�B�ϥ��ɮסG
 * ����  ���廡��    �ɮצW��
 * 1.      �Ȧ��� DBDK.DVDKG002_FOR_EP
 * 2.      �ӯ�����   DBEP.DTEPB102
 * </pre>
 * @author �¶��� 
 * @since 2014/3/26  
 */
@SuppressWarnings("unchecked")
public class EP_C0Z002 {

    /**
     * �榡�Ƴ������e   
     * @param SlipMap
     * @param user
     * @return
     * @throws ErrorInputException
     */
    public Map doFormat(Map<String, List<Map>> SlipMap, UserObject user) throws ErrorInputException {
        if (SlipMap == null || SlipMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C0Z002_MSG_001"));//�d�߱��󤣱o���ŭ�
        }

        LocaleDisplay locale = new LocaleDisplay("EP", user);
        Iterator entries = SlipMap.entrySet().iterator();
        MultiKeyMap mkm = MultiKeyMap.decorate(new LinkedMap());//�����̷ө�J���ǦC�L
        MultiKeyMap mkmSum = new MultiKeyMap();

        //���s( �ǲ����,�ǲ��帹,�s�����,�ǲ��ո�,���I�覡)
        ErrorInputException eie = null;
        while (entries.hasNext()) {
            Entry<String, List<Map>> thisEntry = (Entry<String, List<Map>>) entries.next();
            String key = thisEntry.getKey();
            List<Map> dataList = thisEntry.getValue();
            String[] keys = key.split(",");
            if (keys.length != 4) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_C0Z002_MSG_002"));//�ǤJ�d�߱���:�ǲ�����B�ǲ��帹�B�s�����B�ǲ��ո��Ҷ�����
            }

            if (StringUtils.isBlank(keys[0])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z002_MSG_003"));//�ǲ�������o���ŭ�
            } else if (!DATE.isDate(keys[0])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z002_MSG_004"));//�ǲ�����榡���~
            }
            if (StringUtils.isBlank(keys[1])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z002_MSG_005"));//�ǲ��帹���o���ŭ�
            }
            if (StringUtils.isBlank(keys[2])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z002_MSG_006"));//�s����줣�o���ŭ�
            }
            if (StringUtils.isBlank(keys[3])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z002_MSG_007"));//�ǲ��ո����o���ŭ�
            }

            if (eie != null) {
                throw eie;
            }

            Date SLIP_DATE = Date.valueOf(keys[0]);
            String SLIP_LOT_NO = keys[1];
            String SLIP_DIV_NO = keys[2];
            String SLIP_SET_NO = keys[3];
            List<Map> newList;
            BigDecimal sumByGroup;
            //�̷�PAY_TYPE�Ƨ�
            Collections.sort(dataList, new sortRule());
            //���s�B�z
            for (Map dataMap : dataList) {
                String PAY_TYPE = MapUtils.getString(dataMap, "PAY_TYPE", "");
                if (StringUtils.isBlank(PAY_TYPE)) {
                    throw new ErrorInputException(MessageUtil.getMessage("EP_C0Z002_MSG_008"));//���I�覡���o���ŭ�
                }

                if (!mkm.containsKey(SLIP_DATE, SLIP_LOT_NO, SLIP_DIV_NO, SLIP_SET_NO, PAY_TYPE)) {
                    newList = new ArrayList();
                    mkm.put(SLIP_DATE, SLIP_LOT_NO, SLIP_DIV_NO, SLIP_SET_NO, PAY_TYPE, newList);
                    sumByGroup = BigDecimal.ZERO;
                } else {
                    newList = (List<Map>) mkm.get(SLIP_DATE, SLIP_LOT_NO, SLIP_DIV_NO, SLIP_SET_NO, PAY_TYPE);
                    sumByGroup = (BigDecimal) mkmSum.get(SLIP_DATE, SLIP_LOT_NO, SLIP_DIV_NO, SLIP_SET_NO, PAY_TYPE);
                }

                BigDecimal AMT = this.objToDec(dataMap.get("AMT"), BigDecimal.ZERO);
                Map detailMap = new HashMap();
                String HEADER;
                if ("1".equals(PAY_TYPE)) {
                    HEADER = "�״ڰh�O���Ӫ�";
                } else if ("2".equals(PAY_TYPE)) {
                    HEADER = "�{���h�O���Ӫ�";
                } else if ("3".equals(PAY_TYPE)) {
                    HEADER = "�䲼�h�O���Ӫ�";
                } else {
                    HEADER = "";
                }
                detailMap.put("HEADER", HEADER);
                detailMap.put("SLIP_DATE", locale.formatDate(SLIP_DATE, "/", ""));
                detailMap.put("SLIP_LOT_NO", SLIP_LOT_NO);
                detailMap.put("SLIP_DIV_NO", SLIP_DIV_NO);
                detailMap.put("SLIP_SET_NO", SLIP_SET_NO);
                detailMap.put("PAY_TYPE", PAY_TYPE);
                detailMap.put("CRT_NO", MapUtils.getString(dataMap, "CRT_NO", ""));
                detailMap.put("CUS_NO", MapUtils.getString(dataMap, "CUS_NO", ""));
                detailMap.put("ID", MapUtils.getString(dataMap, "ID", ""));
                detailMap.put("BLD_CD", MapUtils.getString(dataMap, "BLD_CD", ""));
                detailMap.put("CUS_NAME", MapUtils.getString(dataMap, "CUS_NAME", ""));
                detailMap.put("ACPT_ACNT_NAME", MapUtils.getString(dataMap, "ACPT_ACNT_NAME", ""));
                detailMap.put("AMT", locale.formatNumber(AMT, 2, "0"));//�h�O���B

                newList.add(detailMap);
                mkmSum.put(SLIP_DATE, SLIP_LOT_NO, SLIP_DIV_NO, SLIP_SET_NO, PAY_TYPE, sumByGroup.add(AMT));
            }
        }

        List<Map> detailList = new ArrayList();
        Iterator iters = mkm.keySet().iterator();
        while (iters.hasNext()) {
            MultiKey mk = (MultiKey) iters.next();
            BigDecimal sumByGroup = (BigDecimal) mkmSum.get(mk);
            List<Map> newList = (List<Map>) mkm.get(mk);
            int size = newList.size();
            Map lastMap = newList.get(size - 1);
            lastMap.put("SIZE", locale.formatNumber(size, 0, "0"));//���
            lastMap.put("TOTAL_AMT", locale.formatNumber(sumByGroup, 2, "0"));//�p�p
            detailList.addAll(newList);
        }

        Map params = new HashMap();
        params.put("CURRENT_DATE", locale.formatDate(DATE.today(), "/", ""));
        params.put("REPORT_ID", "EP_C0Z002");
        Map paramMap = new HashMap();
        paramMap.put("REPORT_ID", "EP_C0Z002");
        paramMap.put("params", params);
        paramMap.put("detail", detailList);

        return paramMap;

    }

    /**
     * �C�L�������
     * @param paramMap
     * @param resp
     * @throws ModuleException
     */
    public void doPrint(Map paramMap, ResponseContext resp) {

        JasperReportUtils.addOutputRptDataToResp((String) paramMap.get("REPORT_ID"), (Map) paramMap.get("params"), (List<Map>) paramMap
                .get("detail"), resp);

    }

    /**
     * ��BigDecimal
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal objToDec(Object o, BigDecimal defaultValue) {

        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return defaultValue;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /** 
     * �̷� PAY_TYPE �I�ڤ覡�Ƨ�
     */
    private class sortRule implements Comparator<Map> {

        public int compare(Map aMap, Map bMap) {

            String aValue = MapUtils.getString(aMap, "PAY_TYPE");
            String bValue = MapUtils.getString(bMap, "PAY_TYPE");
            return aValue.compareTo(bValue);

        }
    }

}
