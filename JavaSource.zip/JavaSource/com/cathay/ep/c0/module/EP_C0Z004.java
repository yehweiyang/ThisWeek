package com.cathay.ep.c0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE Description Author
 * 2014/05/22  Created ���i��
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ú�O��X���Ӫ����ͼҲ�
 * �Ҳ�ID    EP_C0Z004
 * ���n����    ú�O��X���Ӫ����ͼҲ�
 * </pre>
 * @author �Ťl��
 * @since 2014/5/26
 */
@SuppressWarnings("unchecked")
public class EP_C0Z004 {

    /**
     * �榡�Ƴ������e   
     * @param SlipMap
     * @param user
     * @return
     * @throws ErrorInputException
     */
    public Map doFormat(Map<String, List<Map>> SlipMap, UserObject user) throws ErrorInputException {
        if (SlipMap == null || SlipMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C0Z004_MSG_001"));//�d�߱��󤣱o���ŭ�
        }

        LocaleDisplay locale = new LocaleDisplay("EP", user);
        Iterator entries = SlipMap.entrySet().iterator();

        ErrorInputException eie = null;
        List<Map> detailList = new ArrayList();
        while (entries.hasNext()) {
            Entry<String, List<Map>> thisEntry = (Entry<String, List<Map>>) entries.next();
            String key = thisEntry.getKey();
            List<Map> dataList = thisEntry.getValue();
            String[] keys = key.split(",");

            if (keys.length != 4) {
                throw new ErrorInputException(MessageUtil.getMessage("EP_C0Z004_MSG_002"));//�ǤJ�d�߱���:�ǲ�����B�ǲ��帹�B�s�����B�ǲ��ո��Ҷ�����
            }

            if (StringUtils.isBlank(keys[0])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z004_MSG_003"));//�ǲ�������o���ŭ�
            } else if (!DATE.isDate(keys[0])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z004_MSG_004"));//�ǲ�����榡���~
            }
            if (StringUtils.isBlank(keys[1])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z004_MSG_005"));//�ǲ��帹���o���ŭ�
            }
            if (StringUtils.isBlank(keys[2])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z004_MSG_006"));//�s����줣�o���ŭ�
            }
            if (StringUtils.isBlank(keys[3])) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C0Z004_MSG_007"));//�ǲ��ո����o���ŭ�
            }

            if (eie != null) {
                throw eie;
            }
            String SLIP_DATE = locale.formatDate(Date.valueOf(keys[0]), "/", "");
            String SLIP_LOT_NO = keys[1];
            String SLIP_DIV_NO = keys[2];
            String SLIP_SET_NO = keys[3];
            BigDecimal TOTAL_SWP_AMT = BigDecimal.ZERO;
            for (Map dataMap : dataList) {
                BigDecimal SWP_AMT = STRING.objToBigDecimal(dataMap.get("SWP_AMT"), BigDecimal.ZERO);
                String SWP_DATE = MapUtils.getString(dataMap, "SWP_DATE");
                String COA_DATE = MapUtils.getString(dataMap, "COA_DATE");            
                String RCV_YM = MapUtils.getString(dataMap, "RCV_YM", "");
                Map detailMap = new HashMap();
                detailMap.put("SLIP_DATE", SLIP_DATE);
                detailMap.put("SLIP_LOT_NO", SLIP_LOT_NO);
                detailMap.put("SLIP_DIV_NO", SLIP_DIV_NO);
                detailMap.put("SLIP_SET_NO", SLIP_SET_NO);
                detailMap.put("CRT_NO", MapUtils.getString(dataMap, "CRT_NO", ""));
                detailMap.put("ID", MapUtils.getString(dataMap, "ID", ""));
                detailMap.put("CUS_NAME", MapUtils.getString(dataMap, "CUS_NAME", "").replace(" ", ""));
                detailMap.put("RCV_YM", StringUtils.isNotBlank(RCV_YM) ? locale.formatDateym(RCV_YM, null) : "");
                detailMap.put("PAY_KIND_NM", MapUtils.getString(dataMap, "PAY_KIND_NM", ""));
                detailMap.put("SWP_KIND_NM", MapUtils.getString(dataMap, "SWP_KIND_NM", ""));
                detailMap.put("PAY_TYPE_NM", MapUtils.getString(dataMap, "PAY_TYPE_NM", ""));
                detailMap.put("CHK_CD_NM", MapUtils.getString(dataMap, "CHK_CD_NM", ""));
                detailMap.put("CHK_SET_NO", MapUtils.getString(dataMap, "CHK_SET_NO", ""));

                detailMap.put("BLD_CD", MapUtils.getString(dataMap, "BLD_CD", ""));
                detailMap.put("CUS_NO", MapUtils.getString(dataMap, "CUS_NO", ""));
                detailMap.put("PAY_NO", MapUtils.getString(dataMap, "PAY_NO", ""));
                detailMap.put("SWP_DATE", StringUtils.isNotBlank(SWP_DATE) ? locale.formatDate(Date.valueOf(SWP_DATE), "/", "") : "");
                detailMap.put("INPUT_NAME", MapUtils.getString(dataMap, "INPUT_NAME", ""));
                detailMap.put("COA_DATE", StringUtils.isNotBlank(COA_DATE) ? locale.formatDate(Date.valueOf(COA_DATE), "/", "") : "");
                detailMap.put("INV_NO", MapUtils.getString(dataMap, "INV_NO", ""));
                detailMap.put("SWP_AMT", locale.formatNumber(SWP_AMT, 2, "0"));//ú�ڪ��B                 
                detailList.add(detailMap);
                
                //�X�p
                TOTAL_SWP_AMT = TOTAL_SWP_AMT.add(SWP_AMT);
            }
            //�X�p
            Map lastMap = detailList.get(detailList.size() - 1);
            lastMap.put("SIZE", locale.formatNumber(dataList.size(), 0, "0"));//���
            lastMap.put("TOTAL_SWP_AMT", locale.formatNumber(TOTAL_SWP_AMT, 2, "0"));//ú�ڪ��B   (�X�p)
        }
        Map params = new HashMap();
        params.put("CURRENT_DATE", locale.formatDate(DATE.today(), "/", ""));
        params.put("REPORT_ID", "EP_C0Z004");
        Map paramMap = new HashMap();
        paramMap.put("REPORT_ID", "EP_C0Z004");
        paramMap.put("params", params);
        paramMap.put("detail", detailList);

        return paramMap;
    }

    /**
     * �C�L�������
     * @param paramMap
     * @param resp
     * @throws ModuleException
     */
    public void doPrint(Map paramMap, ResponseContext resp) {

        JasperReportUtils.addOutputRptDataToResp((String) paramMap.get("REPORT_ID"), (Map) paramMap.get("params"), (List<Map>) paramMap
                .get("detail"), resp);

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
