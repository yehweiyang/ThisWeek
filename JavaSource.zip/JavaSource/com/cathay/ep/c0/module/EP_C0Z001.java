package com.cathay.ep.c0.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.validate.ValidateUtil;
import com.cathay.dd.b0.module.DD_B0Z018;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.MessageUtil;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/** 
 * <pre>
 * DATE    Description Author
 * 2013/12/25  Created ���i��
 * 2018/01/29  �q�l�o���վ�~�W�榡 ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �o���������ͼҲ�
 * �Ҳ�ID    EP_C0Z001
 * ���n����    �o���������ͼҲ�
 *  
 * </pre>
 * @author �¶��� 
 * @since 2013/12/30  
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C0Z001 {

    private static final Logger log = Logger.getLogger(EP_C0Z001.class);

    private static final boolean isDebug = log.isDebugEnabled();

    /**
     * �C�L�o��
     * @param dataList
     * @return
     */
    public Map doFormat(List<Map> dataList) {
        //�]�w�Ѽ�
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Map<String, String> params = new HashMap<String, String>();
        paramMap.put("params", params);
        String REPORT_ID = "EP_C0Z001";//�����W��
        paramMap.put("REPORT_ID", REPORT_ID);
        params.put("REPORT_ID", REPORT_ID);

        StringBuilder sb = new StringBuilder();
        //�]�w����϶�
        String[] MONTH_RANGEs = { "1-2", "3-4", "5-6", "7-8", "9-10", "11-12" };
        int THIS_DAY = 0;//�Ѽ�
        int THIS_MONTH = 0;//������
        int THIS_YEAR = 0;//����~

        DecimalFormat df = new DecimalFormat("#,##0");
        List<Map<String, String>> printList = new ArrayList<Map<String, String>>();
        for (Map dataMap : dataList) {
            Map<String, String> printMap = new HashMap<String, String>();
            printMap.put("SUB_CPY_ID", MapUtils.getString(dataMap, "SUB_CPY_ID", ""));
            String INV_DATE = MapUtils.getString(dataMap, "INV_DATE", "");//�}�ߤ��

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(Date.valueOf(INV_DATE));
            THIS_DAY = calendar.get(Calendar.DATE);//�Ѽ�
            THIS_MONTH = calendar.get(Calendar.MONTH) + 1;//������
            THIS_YEAR = calendar.get(Calendar.YEAR) - 1911;//����~
            sb.append("���إ���").append(THIS_YEAR).append("�~");

            if (THIS_MONTH % 2 == 0) {
                sb.append(MONTH_RANGEs[(THIS_MONTH / 2) - 1]);
            } else {
                sb.append(MONTH_RANGEs[THIS_MONTH / 2]);
            }
            String MONTH_RANGE = sb.append("���").toString();
            sb.setLength(0);

            String PAY_KIND = MapUtils.getString(dataMap, "PAY_KIND");
            String PIN_NAME = MapUtils.getString(dataMap, "PIN_NAME", "");
            String INV_NO = MapUtils.getString(dataMap, "INV_NO", "");
            String PAY_KIND_NM = FieldOptionList.getName("EPC", "PAY_KIND_FOUR", PAY_KIND);
            String PAY_S_DATE_ROC = DATE.toROCDate(MapUtils.getString(dataMap, "PAY_S_DATE", "1913-01-01"));
            String PAY_E_DATE_ROC = DATE.toROCDate(MapUtils.getString(dataMap, "PAY_E_DATE", "1913-01-01"));
            String FLD_NO = MapUtils.getString(dataMap, "FLD_NO", "");
            String ROOM_NO = MapUtils.getString(dataMap, "ROOM_NO", "");
            String PRK_NO = MapUtils.getString(dataMap, "PRK_NO", "");
            String DCT_TYPE = MapUtils.getString(dataMap, "DCT_TYPE", "");//���ڤ覡  1:�H�Υd  2:���~
            String CARD_NO = MapUtils.getString(dataMap, "CARD_NO", "");
            String CRT_NO = MapUtils.getString(dataMap, "CRT_NO", "");
            String TAX_TYPE = MapUtils.getString(dataMap, "TAX_TYPE", "");
            String TAX_FREE_CD = MapUtils.getString(dataMap, "TAX_FREE_CD", "");

            //�]�w�~�W
            if (!"6".equals(PAY_KIND)) {
                sb.append("�X��").append(MapUtils.getString(dataMap, "BLD_NAME", ""));
            } else {
                sb.append(PIN_NAME.length() >= 6 ? PIN_NAME.substring(0, 6) : PIN_NAME.substring(0, PIN_NAME.length()));
            }

            if ("6".equals(PAY_KIND)) {
                if (PIN_NAME.length() >= 6) {
                    sb.append("\n").append(PIN_NAME.substring(6, PIN_NAME.length()));
                }
            } else if ("7".equals(PAY_KIND)) {
                sb.append("\n").append(PAY_KIND_NM);
            } else {
                sb.append("\n").append(PAY_S_DATE_ROC).append(" - ").append(PAY_E_DATE_ROC).append("  ").append(PAY_KIND_NM);
            }

            if (StringUtils.isBlank(FLD_NO)) {
                if (StringUtils.isNotBlank(PRK_NO)) {
                    sb.append("\n").append(PRK_NO);
                }
            } else {
                sb.append("\n").append(FLD_NO).append(" ").append(ROOM_NO);
            }

            if ("1".equals(DCT_TYPE)) {
                sb.append("\nñ�b�d���X�G").append(StringUtils.right(CARD_NO, 4));
            }

            if (CRT_NO.startsWith("OZ")) {
                sb.append("\nñ�b�d���X�G").append(StringUtils.right(CRT_NO, 4));
            }

            if ("3".equals(TAX_TYPE)) {
                if (StringUtils.isBlank(CRT_NO)) {
                    //�L�����s�� ���C�L �K�|���Ҹ�
                } else {
                    sb.append("\n�K�|���Ҹ��G").append(StringUtils.trim(TAX_FREE_CD));
                }
            }
            //150420 modifid for �K���վ�
            //�Y���K�����A�~�W�W�[�C�L�K������
            String EXP_STR_DATE = MapUtils.getString(dataMap, "EXP_STR_DATE");
            if ("1".equals(PAY_KIND) && StringUtils.isNotBlank(EXP_STR_DATE)) {
                sb.append(",").append(STRING.lineSeparator);
                sb.append("�K������(").append(DATE.toROCDate(EXP_STR_DATE)).append("~").append(DATE.toROCDate(MapUtils.getString(dataMap, "EXP_END_DATE", "1913-01-01"))).append(")");
            }
            printMap.put("INV_NAME", sb.toString());//�~�W 

            sb.setLength(0);
            //�]�w�`�p���B(�Ҭ���ƭ�,�G�L����˥h���Ʀ�)
            BigDecimal INV_AMT = ((BigDecimal) MapUtils.getObject(dataMap, "INV_AMT", BigDecimal.ZERO)).setScale(0, BigDecimal.ROUND_DOWN);
            BigDecimal SAL_AMT = ((BigDecimal) MapUtils.getObject(dataMap, "SAL_AMT", BigDecimal.ZERO)).setScale(0, BigDecimal.ROUND_DOWN);
            BigDecimal TAX_AMT = ((BigDecimal) MapUtils.getObject(dataMap, "TAX_AMT", BigDecimal.ZERO)).setScale(0, BigDecimal.ROUND_DOWN);
            BigDecimal TOTAL_AMT = SAL_AMT.add(TAX_AMT).setScale(0, BigDecimal.ROUND_DOWN);//�L����˥h���Ʀ�

            //�]�w�`�p���B��r
            String strTOTAL_AMT = STRING.fillZero(TOTAL_AMT.toPlainString(), 9, null);

            char[] DIGITs = strTOTAL_AMT.toCharArray();
            int strTOTAL_AMT_size = strTOTAL_AMT.length();
            int index = strTOTAL_AMT_size;
            printMap.put("DIGIT_10", "");
            printMap.put("DIGIT_11", "");
            printMap.put("DIGIT_12", "");
            for (char N : DIGITs) {
                printMap.put("DIGIT_" + index, STRING.toROCMoneyFormat(String.valueOf(N), "", false));
                index--;
            }

            if (strTOTAL_AMT_size > 9) {
                switch (strTOTAL_AMT_size) {
                    case 10:
                        printMap.put("DIGIT_10", MapUtils.getString(printMap, "DIGIT_10") + "�B");
                        break;
                    case 11:
                        printMap.put("DIGIT_10", MapUtils.getString(printMap, "DIGIT_10") + "�B");
                        printMap.put("DIGIT_11", MapUtils.getString(printMap, "DIGIT_11") + "��");
                        break;
                    case 13:
                        printMap.put("DIGIT_10", MapUtils.getString(printMap, "DIGIT_10") + "�B");
                        printMap.put("DIGIT_11", MapUtils.getString(printMap, "DIGIT_11") + "��");
                        printMap.put("DIGIT_12", MapUtils.getString(printMap, "DIGIT_12") + "�a");
                        break;
                }
            }

            printMap.put("MONTH_RANGE", MONTH_RANGE);
            printMap.put("SER_NO", MapUtils.getString(dataMap, "SER_NO", ""));//�y����
            printMap.put("THIS_YEAR", String.valueOf(THIS_YEAR));//�o���}�ߤ��-�~ 
            printMap.put("THIS_MONTH", String.valueOf(THIS_MONTH));//�o���}�ߤ��-�� 
            printMap.put("THIS_DAY", String.valueOf(THIS_DAY));//�o���}�ߤ��-��
            printMap.put("INV_NO", INV_NO);//�o�����X 
            printMap.put("CUS_NAME", MapUtils.getString(dataMap, "CUS_NAME", "�@"));//�R���H 
            printMap.put("CHK_NO", MapUtils.getString(dataMap, "CHK_NO", ""));//�ˬd���X
            String ID = StringUtils.trim(MapUtils.getString(dataMap, "ID", ""));
            if (StringUtils.isNotBlank(ID) && NumberUtils.isNumber(ID)) {
                printMap.put("ID", ID);//�Τ@�s��
            } else {
                printMap.put("ID", "�@");
            }
            printMap.put("CRT_NO", MapUtils.getString(dataMap, "CRT_NO", ""));//�Ȥ�N�� 

            String ID_TYPE = MapUtils.getString(dataMap, "ID_TYPE", "");
            if ("1".equals(TAX_TYPE) || "2".equals(TAX_TYPE)) {
                printMap.put("TAX_TYPE_A", "V");//��~�|-���|
                if ((TAX_AMT.compareTo(new BigDecimal("0")) != 0)) {
                    //160512 modified by i9301216 : ��ӤG�T�p���P�_�覡,�ȤT�p��(���q�渹)����ܵ|�B;��L�������
                    if ((StringUtils.isNotBlank(ID_TYPE) && "1".equals(ID_TYPE)) || ValidateUtil.checkCOID(ID)) {//�ҥ�������νs>���q�渹
                        printMap.put("TAX_AMT", df.format(TAX_AMT));//��~�|���B  
                    } else {
                        printMap.put("TAX_AMT", "");//��~�|���B  
                    }
                } else {
                    printMap.put("TAX_AMT", "");//��~�|���B  
                }
            } else if ("3".equals(TAX_TYPE)) {
                printMap.put("TAX_TYPE_B", "V");//��~�|-�s�|�v
                printMap.put("TAX_AMT", "");//��~�|���B  
            } else if ("4".equals(TAX_TYPE)) {
                printMap.put("TAX_TYPE_C", "V");//��~�|-�K�|
                printMap.put("TAX_AMT", "");//��~�|���B  
            }
            printMap.put("INV_AMT", df.format(INV_AMT));//�o�����B
            printMap.put("TOTAL_AMT", df.format(TOTAL_AMT));//�P���B+��~�|�X�p

            //N�p��
            //160317 : modified : ���q�渹>�T�p��,��L>�G�p��
            if (StringUtils.isNotBlank(ID_TYPE) && "1".equals(ID_TYPE)) {//�ҥ�������νs>���q�渹
                printMap.put("INV_FORMATE", "�T�p��");
                printMap.put("SAL_AMT", df.format(SAL_AMT));//�P���B
            } else {
                if (ValidateUtil.checkCOID(ID)) {//�P�_�O�_�����q�渹
                    printMap.put("INV_FORMATE", "�T�p��");
                    printMap.put("SAL_AMT", df.format(SAL_AMT));//�P���B
                } else {
                    printMap.put("INV_FORMATE", "�G�p��");
                    printMap.put("SAL_AMT", df.format(TOTAL_AMT));//�P���B+�|�B
                }
            }

            printList.add(printMap);

        }

        paramMap.put("detail", printList); //����

        return paramMap;

    }

    /**
     * �C�L�o��
     * @param dataList
     * @return
     * @throws ErrorInputException 
     */
    public Map doFormatForElcInv(List<Map> dataList, String SUB_CPY_ID) throws ModuleException {
        if (dataList == null || dataList.isEmpty()) {
            throw new ErrorInputException("�ǤJ��ƲM�椣�i���ŭ�");
        }
        List<Map> B2BList = new ArrayList<Map>();
        List<Map> B2CList = new ArrayList<Map>();
        StringBuilder sb = new StringBuilder();

        //�~�W�M��
        Map PIN_NAMEmap = getPIN_NAMEs(SUB_CPY_ID, null);

        for (Map dataMap : dataList) {
            Map data = new HashMap();
            String TAX_TP = null;
            if ("1".equals(MapUtils.getString(dataMap, "TAX_TYPE")) || "2".equals(MapUtils.getString(dataMap, "TAX_TYPE"))) {
                TAX_TP = "1"; //���|
            } else if ("3".equals(MapUtils.getString(dataMap, "TAX_TYPE"))) {
                TAX_TP = "2"; //�s�|�v
            } else if ("4".equals(MapUtils.getString(dataMap, "TAX_TYPE"))) {
                TAX_TP = "3"; //�K�|
            }

            String TRANS_STATUS = "";
            if (dataMap.get("PRT_DATE") != null) {
                TRANS_STATUS = "Y";
            }
            String PAY_KIND = MapUtils.getString(dataMap, "PAY_KIND");
            if ("A".equals(MapUtils.getString(dataMap, "INV_TYPE"))) {//B2B�o��
                data.put("CASE_TYPE", "A");
                data.put("CASE_STATUS", "1");
                data.put("USE_TYPE", "EP1");
                data.put("TRANS_TYPE", MapUtils.getString(dataMap, "TRANS_TYPE"));
                data.put("TRANS_STATUS", TRANS_STATUS);
                data.put("AMT", MapUtils.getString(dataMap, "INV_AMT"));
                data.put("TAX_AMT", MapUtils.getString(dataMap, "TAX_AMT"));
                data.put("PROD_AMT", MapUtils.getString(dataMap, "SAL_AMT"));
                data.put("BAL_AMT", MapUtils.getString(dataMap, "INV_AMT"));
                data.put("INV_YM", MapUtils.getString(dataMap, "RCV_YM"));
                data.put("INV_TP", "07");
                data.put("TAX_TP", TAX_TP);
                data.put("SELLER_NM", "����H��");
                data.put("SELLER_BAN", "03374707");
                data.put("BUYER_NM", MapUtils.getString(dataMap, "CUS_NAME"));
                data.put("BUYER_BAN", MapUtils.getString(dataMap, "ID"));
                data.put("INV_NO", MapUtils.getString(dataMap, "INV_NO"));
                data.put("INV_TS", DATE.dateToTimestamp(Date.valueOf(MapUtils.getString(dataMap, "INV_DATE"))));

                //�~�W�����榡�վ�
                this.getPIN_NAMEForPrint(dataMap, data, sb, PIN_NAMEmap);

                data.put("RANDOM_NO", MapUtils.getString(dataMap, "CHK_NO"));
                if ("2".equals(PAY_KIND)) {
                    data.put("EPKEY", MapUtils.getString(dataMap, "INT_NO"));
                } else {
                    data.put("EPKEY", MapUtils.getString(dataMap, "RCV_NO"));
                }
                B2BList.add(data);

            } else {//B2C�o��
                data.put("CASE_TYPE", "A");
                data.put("CASE_STATUS", "1");
                data.put("USE_TYPE", "EP1");
                data.put("TRANS_TYPE", MapUtils.getString(dataMap, "TRANS_TYPE"));
                data.put("TRANS_STATUS", TRANS_STATUS);
                data.put("AMT", MapUtils.getString(dataMap, "INV_AMT"));
                data.put("TAX_AMT", MapUtils.getString(dataMap, "TAX_AMT"));
                data.put("PROD_AMT", MapUtils.getString(dataMap, "SAL_AMT"));
                data.put("BAL_AMT", MapUtils.getString(dataMap, "INV_AMT"));
                data.put("INV_YM", MapUtils.getString(dataMap, "RCV_YM"));
                data.put("INV_TP", "07");
                data.put("TAX_TP", TAX_TP);
                data.put("SELLER_NM", "����H��");
                data.put("SELLER_BAN", "03374707");
                String CUS_NAME = MapUtils.getString(dataMap, "CUS_NAME");
                data.put("BUYER_NM", CUS_NAME);
                data.put("BUYER_BAN", MapUtils.getString(dataMap, ""));
                data.put("INV_NO", MapUtils.getString(dataMap, "INV_NO"));
                data.put("INV_TS", DATE.dateToTimestamp(Date.valueOf(MapUtils.getString(dataMap, "INV_DATE"))));
                //�~�W�����榡�վ�
                this.getPIN_NAMEForPrint(dataMap, data, sb, PIN_NAMEmap);

                data.put("RANDOM_NO", MapUtils.getString(dataMap, "CHK_NO"));
                if ("2".equals(PAY_KIND)) {
                    data.put("EPKEY", MapUtils.getString(dataMap, "INT_NO"));
                } else {
                    data.put("EPKEY", MapUtils.getString(dataMap, "RCV_NO"));
                }
                B2CList.add(data);

            }
        }
        Map rtnMap = new HashMap();
        rtnMap.put("B2BList", B2BList);
        rtnMap.put("B2CList", B2CList);
        return rtnMap;

    }

    /**
     * �C�L�������
     * @param paramMap
     * @param resp
     * @throws ModuleException
     */
    public void doPrint(Map paramMap, ResponseContext resp) {
        if (isDebug) {
            log.debug("#### paramMap:" + paramMap);
        }
        JasperReportUtils.addOutputRptDataToResp((String) paramMap.get("REPORT_ID"), (Map) paramMap.get("params"), (List<Map>) paramMap.get("detail"), resp);

    }

    /**
     * �̤����q�O���o�~�W�M��
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException 
     */
    public Map getPIN_NAMEs(String SUB_CPY_ID, String PIN_CODE) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException("�ǤJ�����q�O���i���ŭ�");
        }

        Map PIN_NAMEmap = new HashMap();
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {
            List<Map> PIN_CODE_LIST;
            if (StringUtils.isNotBlank(PIN_CODE)) {
                PIN_CODE_LIST = new DD_B0Z018().queryDtddb070(PIN_CODE);//�~�W�N�X/����
            } else {
                PIN_CODE_LIST = new DD_B0Z018().queryDtddb070("");//�~�W�N�X/����
            }
            for (Map mp : PIN_CODE_LIST) {
                PIN_NAMEmap.put(MapUtils.getString(mp, "PIN_CODE", ""), MapUtils.getString(mp, "PIN_NAME", ""));
            }
        } else { //: �վ���
            PIN_NAMEmap = FieldOptionList.getName("EP", "PIN_CODE");
        }

        return PIN_NAMEmap;
    }

    /**
     * �q�l�o��[�}�ߥ�] 
     * �զ��~�W 
     * @param rtnMap
     * @throws ModuleException 
     */
    public void getPIN_NAME(Map rtnMap, StringBuilder sb) throws ModuleException {
        /* �榡�G
         * #�j�ӦW��
         * #ú�کl�� ~ #ú�ڲ״�
         * #�Ӽh #�ǧO
         * #����
         * �K�������G#�K���l�� ~ #�K���״�
         * ñ�b�d���G#ñ�b�d��
         * �K�|�Ҹ��G#�K�|�Ҹ�
         */

        //���o����~ú�کl���״�
        String rtnMap_PAY_S_DATE = MapUtils.getString(rtnMap, "PAY_S_DATE");
        String rtnMap_PAY_E_DATE = MapUtils.getString(rtnMap, "PAY_E_DATE");
        String PAY_S_ROC = DATE.toROCDate(rtnMap_PAY_S_DATE); //�ର������ 
        String PAY_E_ROC = DATE.toROCDate(rtnMap_PAY_E_DATE); //�ର������

        String CRT_NO = MapUtils.getString(rtnMap, "CRT_NO");

        String FLD_NO = MapUtils.getString(rtnMap, "FLD_NO", "");
        String ROOM_NO = MapUtils.getString(rtnMap, "ROOM_NO", "");
        String PRK_NO = MapUtils.getString(rtnMap, "PRK_NO", "");

        sb.setLength(0);
        //�վ�q�l�o���~�W�榡
        sb.append(MapUtils.getString(rtnMap, "BLD_NAME", "")).append(STRING.lineSeparator);
        sb.append(PAY_S_ROC).append('~').append(PAY_E_ROC);
        if (StringUtils.isNotBlank(FLD_NO)) {
            sb.append(STRING.lineSeparator).append(FLD_NO).append(' ').append(ROOM_NO);
        } else {
            if (StringUtils.isNotBlank(PRK_NO)) {
                sb.append(STRING.lineSeparator).append(PRK_NO);
            }
        }

        //�Y���K�����A�~�W�W�[�C�L�K������
        String EXP_STR_DATE = MapUtils.getString(rtnMap, "EXP_STR_DATE");
        if ("1".equals(MapUtils.getString(rtnMap, "PAY_KIND")) && StringUtils.isNotBlank(EXP_STR_DATE)) {
            sb.append(STRING.lineSeparator);
            sb.append(MessageUtil.getMessage("EP_C21040_MSG_EXP_DATE")/*�K������:*/).append(DATE.toROCDate(EXP_STR_DATE)).append("~").append(DATE.toROCDate(MapUtils.getString(rtnMap, "EXP_END_DATE", "1913-01-01")));
        }

        //ñ�b�d���X
        if ("1".equals(MapUtils.getString(rtnMap, "DCT_TYPE"))) {
            sb.append(STRING.lineSeparator);
            sb.append(MessageUtil.getMessage("EP_C21040_MSG_CARD_NO")/*ñ�b�d���X:*/).append(StringUtils.right(MapUtils.getString(rtnMap, "CARD_NO"), 4));
        }

        if (CRT_NO.startsWith("OZ")) {
            sb.append(STRING.lineSeparator);
            sb.append(MessageUtil.getMessage("EP_C21040_MSG_CARD_NO")/*ñ�b�d���X:*/).append(StringUtils.right(CRT_NO, 4));
        }

        //�K�|���Ҹ�
        String TAX_TYPE = MapUtils.getString(rtnMap, "TAX_TYPE");
        if ("3".equals(TAX_TYPE)) {
            if (StringUtils.isBlank(CRT_NO)) {
                //�L�����s�� ���C�L �K�|���Ҹ�
            } else {
                sb.append(STRING.lineSeparator);
                sb.append(MessageUtil.getMessage("EP_C21040_MSG_TAX_FREE_CD")/*�K�|���Ҹ�:*/).append(StringUtils.trim(MapUtils.getString(rtnMap, "TAX_FREE_CD")));
            }
        }

        rtnMap.put("PIN_NAME", sb.toString());
    }

    /**
     * �q�l�o�� [�C�L��]
     * ��´�~�W+�Ƶ�����
     * @param dataMap �ӷ�map
     * @param data �ت�map
     * @param sb
     * @param PIN_NAMEmap
     * @throws ModuleException 
     */
    public String getPIN_NAMEForPrint(Map dataMap, Map data, StringBuilder sb, Map PIN_NAMEmap) throws ModuleException {
        /* �q�l�o���C�L�~�W�榡 [PIN_NAME�GCASE_MEMO] �G
         * PIN_NAME = #PIN_CODE + #PAY_KIND
         * CASE_MEMO = #PIN_NAME (�o���}�߮�EP_C0Z001.getPIN_NAME�զn��)
         */
        if (data == null) {//�Y�L�ت���map�N��Ʀ^�g��ӷ�map
            data = dataMap;
        }
        String PIN_CODE = MapUtils.getString(dataMap, "PIN_CODE");
        String PIN_NAME = MapUtils.getString(dataMap, "PIN_NAME");
        String CASE_MEMO = "";
        data.put("PIN_CODE", PIN_CODE);

        //�o���Ƶ�����
        if (StringUtils.isNotBlank(PIN_CODE) && !PIN_NAME.startsWith("�X��")) {//180129�վ��
            if (PIN_NAMEmap != null) {
                data.put("PIN_NAME", MapUtils.getString(PIN_NAMEmap, PIN_CODE));
            } else {
                try {
                    PIN_NAMEmap = this.getPIN_NAMEs(MapUtils.getString(dataMap, "SUB_CPY_ID"), PIN_CODE);
                    data.put("PIN_NAME", MapUtils.getString(PIN_NAMEmap, PIN_CODE));
                } catch (ModuleException e) {
                    log.error("���o�~�W���~");
                    throw new ModuleException("���o�~�W���~", e);
                }
            }
            sb.setLength(0);
            sb.append(MapUtils.getString(dataMap, "PIN_NAME"));
            sb.append(STRING.lineSeparator).append(MapUtils.getString(dataMap, "CRT_NO")).append("-").append(MapUtils.getString(dataMap, "CUS_NO"));
            //20200414: ��ة��ӥ[�L�Ȥ�m�W
            if (!"A".equals(MapUtils.getString(dataMap, "INV_TYPE")) || "01".equals(MapUtils.getString(dataMap, "SUB_CPY_ID"))) {//B2C OR ���
                sb.append(STRING.lineSeparator).append(MapUtils.getString(dataMap, "CUS_NAME"));//171226:�s�|:B2C�o���W�����Ȥ�W�٥H�K�ӿ�H���o��o��
            }
            //170408:�s�|:�D����/�޲z�O/�㯲�����o���ݦb�o���W�[ú�ں���
            String PAY_KIND = MapUtils.getString(dataMap, "PAY_KIND");
            if (!("1".equals(PAY_KIND) || "2".equals(PAY_KIND) || "3".equals(PAY_KIND))) {
                sb.append(STRING.lineSeparator).append(FieldOptionList.getName("EP", "PAY_KIND", PAY_KIND));
            }
            if (isDebug) {
                log.debug("### PAY_KIND::" + PAY_KIND);
                log.debug("### CASE_MEMO::" + sb.toString());
            }
            CASE_MEMO = sb.toString();
            data.put("CASE_MEMO", CASE_MEMO);
        } else {//180129�վ�e
            data.put("PIN_NAME", PIN_NAME);
            if ("A".equals(MapUtils.getString(dataMap, "INV_TYPE"))) {
                data.put("CASE_MEMO", "");
            } else {
                CASE_MEMO = MapUtils.getString(dataMap, "CUS_NAME");
                data.put("CASE_MEMO", CASE_MEMO);//171226:�s�|:B2C�o���W�����Ȥ�W�٥H�K�ӿ�H���o��o��
            }
        }

        sb.setLength(0);
        return sb.append(PIN_NAME).append("�G").append(CASE_MEMO).toString();
    }

    /**
     * �q�l�o�� [�d�ߥ�]
     * ��´�~�W(EP�d�ߵe��)
     * @param rtnMap
     * @param sb
     * @param PIN_NAMEmap
     * @throws ModuleException
     */
    public String getPIN_NAMEForQuery(Map rtnMap, StringBuilder sb, Map PIN_NAMEmap) throws ModuleException {
        /* �d�� �q�l�o���~�W�榡 [PIN_NAME�GCASE_MEMO] �G
         * PIN_NAME = #PIN_CODE + #PAY_KIND
         * CASE_MEMO = #PIN_NAME (�o���}�߮�EP_C21040.getPIN_NAME�զn��)
         * ** replace�մ���Ÿ�
         */
        if (sb == null) {
            sb = new StringBuilder();
        } else {
            sb.setLength(0);
        }

        String PIN_CODE = MapUtils.getString(rtnMap, "PIN_CODE");
        String PIN_NAME = MapUtils.getString(rtnMap, "PIN_NAME");
        if (StringUtils.isNotBlank(PIN_CODE) && !PIN_NAME.startsWith("�X��")) {
            //���o�~�W�N������M��
            try {
                if (PIN_NAMEmap == null) {
                    PIN_NAMEmap = this.getPIN_NAMEs(MapUtils.getString(rtnMap, "SUB_CPY_ID"), PIN_CODE);
                }
            } catch (ModuleException e) {
                log.error("���o�~�W���~", e);
                throw new ModuleException("���o�~�W���~", e);
            } //���o�~�W����
            sb.append(MapUtils.getString(PIN_NAMEmap, PIN_CODE));
            sb.append("�G");
        }
        sb.append(MapUtils.getString(rtnMap, "PIN_NAME").replace(STRING.lineSeparator, " ")); //�~�W���_��

        PIN_NAME = sb.toString();
        rtnMap.put("PIN_NAME", PIN_NAME);

        return PIN_NAME;
    }
}
