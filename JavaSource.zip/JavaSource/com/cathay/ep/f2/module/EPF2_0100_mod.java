package com.cathay.ep.f2.module;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.util.STRING;
import com.cathay.dk.bo.DTDKM001;
import com.cathay.dk.m0.module.DK_M0Z002;
import com.cathay.ep.vo.DTEPF130;
import com.cathay.ep.vo.DTEPF160;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F130;
import com.cathay.ep.z0.module.EP_Z0F160;

/**
 * Date Version Description Author
 * 2014/9/23   1.0 Created ����i
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �дڮ־P�ˮּҲ�
 * �{���W��    EPF1_0106_mod.java
 * �@�~�覡    MODULE
 * ���n����    
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EPF2_0100_mod {
    private static final Logger log = Logger.getLogger(EPF2_0100_mod.class);

    /**
     * �ˮֽдڮ־P���I�ɬO�_���s�b
     * @param EPF160Vo
     * @throws ModuleException
     */
    public String checkisNull(DTEPF160 EPF160Vo) throws ModuleException {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String PAY_CASE_NO = null;
        if (EPF160Vo == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF2_0100_mod_MSG_001"));//�ǤJ�дڮ־P���I�ɤ��i����!
        } else {
            SUB_CPY_ID = EPF160Vo.getSUB_CPY_ID();
            PAY_CASE_NO = EPF160Vo.getPAY_CASE_NO();
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF2_0100_mod_MSG_002")); //�ǤJ�����q�O���o���ŭ�!
            }
            if (StringUtils.isBlank(PAY_CASE_NO)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF2_0100_mod_MSG_003")); //�ǤJ�дڽs�����o���ŭ�!
            }
        }

        if (eie != null) {
            throw eie;
        }

        String ACC_SECVER_DATE = "";

        //�d�L��ƥ�X���~
        Map rtnMap;
        try {
            rtnMap = new EP_Z0F160().queryMap(PAY_CASE_NO, EPF160Vo.getPAY_SER_NO().toString(), SUB_CPY_ID);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPF2_0100_mod_MSG_004") + PAY_CASE_NO);//�L���дڮ־P���PAY_CASE_NO!
        }
        //�дڽT�{���ˮ�DK�дڮ־P�ץ󪬺A
        //DK_M0Z002.query1DKM001(String QUERY_TYPE, String AUD_STS, String CASE_NO, List INPUT_DIV_NO_List, String BUD_DIV_NO);
        if (EPF160Vo.getPAY_CFM_DATE() != null) {
            String CASE_NO = MapUtils.getString(rtnMap, "CASE_NO");
            List<DTDKM001> DKM001 = new DK_M0Z002().query1DKM001("2", null, MapUtils.getString(rtnMap, "CASE_NO"), null, null);
            for (DTDKM001 dtdkm001 : DKM001) {
                if (!"A".equals(dtdkm001.getAUD_STS())) {
                    throw new ModuleException(MessageUtil.getMessage("EPF2_0100_mod_MSG_005") + CASE_NO);//�дڮ־P�@�~�|������,�|�p�ץ�s��!
                } else {
                    ACC_SECVER_DATE = dtdkm001.getACC_SECVER_DATE();
                    if (StringUtils.isBlank(ACC_SECVER_DATE)) {
                        throw new ModuleException("�дڰO���s��(" + CASE_NO + ")�L�|�p�Ю֤��!");
                    }
                }
            }

        }
        return ACC_SECVER_DATE;
    }

    /**
     *  �ˮֽдڮץ�s�����B�O�_�W�L�u�{�������B
     * @param reqList
     * @throws Exception
     */
    public void checAplyNo(List<Map> reqList) throws Exception {
        if (reqList == null || reqList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF2_0100_mod_MSG_006"));//�ǤJ�дڮץ󤣥i����! //TODO
        }
        EP_Z0F130 theEP_Z0F130 = new EP_Z0F130();
        EP_Z0F110 theEP_Z0F110 = new EP_Z0F110();
        for (Map reqMap : reqList) {
            BigDecimal F130_PAY_AMT;
            String MEMO_NO = MapUtils.getString(reqMap, "MEMO_NO");
            String PRO_NO = MapUtils.getString(reqMap, "PRO_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isNotBlank(MEMO_NO) && StringUtils.isNotBlank(PRO_NO)) {
                DTEPF130 F130Vo = new DTEPF130();
                F130Vo.setSUB_CPY_ID(SUB_CPY_ID);
                F130Vo.setAPLY_NO(MapUtils.getString(reqMap, "APLY_NO"));
                //F130Vo.setMEMO_NO(MapUtils.getInteger(reqMap, "MEMO_NO"));
                F130Vo.setPRO_NO(MapUtils.getInteger(reqMap, "PRO_NO"));//�ۦP�u�ص����P�t��
                List<Map> DBF130VoList = theEP_Z0F130.queryF130List(F130Vo);
                F130_PAY_AMT = BigDecimal.ZERO;
                for (Map DBF130Map : DBF130VoList) {
                    F130_PAY_AMT = F130_PAY_AMT.add(STRING.objToBigDecimal(DBF130Map.get("CLR_AMT"), BigDecimal.ZERO));
                }
                log.debug("### checAplyNo.F130_PAY_AMT(total):" + F130_PAY_AMT + "||PRO_NO:" + PRO_NO);
            } else {
                Map DBF110Map = theEP_Z0F110.queryMap(MapUtils.getString(reqMap, "APLY_NO"), SUB_CPY_ID);
                BigDecimal CLR_AMT = STRING.objToBigDecimal(DBF110Map.get("CLR_AMT"), BigDecimal.ZERO);
                BigDecimal ACT_AMT = STRING.objToBigDecimal(DBF110Map.get("ACT_AMT"), BigDecimal.ZERO);
                F130_PAY_AMT = CLR_AMT.add(ACT_AMT);
                log.debug("### checAplyNo.F130_PAY_AMT:" + F130_PAY_AMT);
            }

            BigDecimal F160_PAY_AMT = STRING.objToBigDecimal(reqMap.get("PAY_AMT"), BigDecimal.ZERO).add(
                STRING.objToBigDecimal(reqMap.get("TAX_AMT"), BigDecimal.ZERO));
            if (F160_PAY_AMT.compareTo(F130_PAY_AMT) > 0) {
                throw new ModuleException(MessageUtil.getMessage("EPF2_0100_mod_MSG_007"));//�X����дڮ־P���B���i�j��u�{�������B TODO
            }

        }
    }

    /**
     * �ˮ֨����дڮ־P
     * @param F160
     * @throws ModuleException 
     */
    public void checkCancel(DTEPF160 F160) throws ModuleException {

        //�ˮֶǤJ�Ѽ�:
        String CASE_NO = F160.getCASE_NO();
        if (StringUtils.isBlank(CASE_NO)) {
            throw new ErrorInputException("�ǤJ�дڰO���s�����o���ŭ�!");
        }

        //�d�߽дڮ־P�t�νдڬ���
        List<DTDKM001> listDK;
        try {
            listDK = new DK_M0Z002().query1DKM001("2", null, CASE_NO, null, null);
            for (DTDKM001 dkM001 : listDK) {
                //���A�� 0, X �άd������ �� �W��~�i�H����
                String AUD_STS = dkM001.getAUD_STS();
                if (!("X".equals(AUD_STS) || "0".equals(AUD_STS))) {
                    throw new ModuleException("�дڰO��(" + CASE_NO + ")���A�D�h��A�L�k�����дڮ־P");
                }
            }
        } catch (DataNotFoundException dnfe) {
            //�d������ �� �W��~�i�H����
        }

    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
