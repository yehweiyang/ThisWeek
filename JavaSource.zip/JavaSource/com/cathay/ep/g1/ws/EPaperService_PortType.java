/**
 * EPaperService_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 * 2019/10/21 AllenTsai �z�Ljava org.apache.axis.wsdl.WSDL2Java -o src -p com.cathay.ep.g1.ws ...\dpland.wsdl
 */
package com.cathay.ep.g1.ws;

import java.rmi.RemoteException;

public interface EPaperService_PortType extends java.rmi.Remote {
    public String applyEDOC(String xml) throws RemoteException;
    public String applyQuery(String bioid, String entID, String cityID, String areaID, String sectionID, String IR00, String IR49, String LIDN, String startDate, String endDate, String applyUse) throws RemoteException;
    public String applyQuery(String bioid) throws RemoteException;
    public String combinePDF(String xml) throws RemoteException;
    public String combineQuery(String pdfno) throws RemoteException;
    public String exportEDOCData(String guid) throws RemoteException;
    public String applyQuery2(String BIOID, String OID, String cityID, String areaID, String sectionID, String IR00, String IR49, String LIDN, String startDate, String endDate, String applyUser) throws RemoteException;
    public String getCity() throws RemoteException;
    public String getSection(String cityID) throws RemoteException;
    public String getVersion() throws RemoteException;
}
