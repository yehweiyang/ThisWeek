/**
 * EPaperServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 * 2019/10/21 AllenTsai �z�Ljava org.apache.axis.wsdl.WSDL2Java -o src -p com.cathay.ep.g1.ws ...\dpland.wsdl
 */

package com.cathay.ep.g1.ws;

import java.net.URL;
import java.rmi.RemoteException;
import java.util.Enumeration;

import javax.xml.namespace.QName;

import org.apache.axis.AxisFault;
import org.apache.axis.NoEndPointException;
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.constants.Style;
import org.apache.axis.constants.Use;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.description.ParameterDesc;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.JavaUtils;
import org.apache.log4j.Logger;

public class EPaperServiceSoapBindingStub extends org.apache.axis.client.Stub
		implements com.cathay.ep.g1.ws.EPaperService_PortType {
	
	private static final Logger log = Logger.getLogger(EPaperServiceSoapBindingStub.class);
	

	static OperationDesc[] _operations;

	static {
		_operations = new OperationDesc[10];
		_initOperationDesc1();
	}

	private static void _initOperationDesc1() {
		OperationDesc oper;
		ParameterDesc param;
		oper = new OperationDesc();
		oper.setName("applyEDOC");
		param = new ParameterDesc(
				new QName("", "xml"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new QName(
				"http://schemas.xmlsoap.org/soap/encoding/", "string"));
		oper.setReturnClass(String.class);
		oper.setReturnQName(new QName("", "applyEDOCReturn"));
		oper.setStyle(Style.RPC);
		oper.setUse(Use.ENCODED);
		_operations[0] = oper;

		oper = new OperationDesc();
		oper.setName("applyQuery");
		param = new ParameterDesc(
				new QName("", "bioid"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "EntID"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "CityID"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "AreaID"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "SectionID"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "IR00"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "IR49"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "LIDN"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "StartDate"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "EndDate"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "ApplyUse"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new QName(
				"http://schemas.xmlsoap.org/soap/encoding/", "string"));
		oper.setReturnClass(String.class);
		oper.setReturnQName(new QName("", "applyQueryReturn"));
		oper.setStyle(Style.RPC);
		oper.setUse(Use.ENCODED);
		_operations[1] = oper;

		oper = new OperationDesc();
		oper.setName("applyQuery");
		param = new ParameterDesc(
				new QName("", "bioid"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new QName(
				"http://schemas.xmlsoap.org/soap/encoding/", "string"));
		oper.setReturnClass(String.class);
		oper.setReturnQName(new QName("", "applyQueryReturn"));
		oper.setStyle(Style.RPC);
		oper.setUse(Use.ENCODED);
		_operations[2] = oper;

		oper = new OperationDesc();
		oper.setName("combinePDF");
		param = new ParameterDesc(
				new QName("", "xml"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new QName(
				"http://schemas.xmlsoap.org/soap/encoding/", "string"));
		oper.setReturnClass(String.class);
		oper.setReturnQName(new QName("", "combinePDFReturn"));
		oper.setStyle(Style.RPC);
		oper.setUse(Use.ENCODED);
		_operations[3] = oper;

		oper = new OperationDesc();
		oper.setName("combineQuery");
		param = new ParameterDesc(
				new QName("", "pdfno"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new QName(
				"http://schemas.xmlsoap.org/soap/encoding/", "string"));
		oper.setReturnClass(String.class);
		oper.setReturnQName(new QName("", "combineQueryReturn"));
		oper.setStyle(Style.RPC);
		oper.setUse(Use.ENCODED);
		_operations[4] = oper;

		oper = new OperationDesc();
		oper.setName("exportEDOCData");
		param = new ParameterDesc(
				new QName("", "guid"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new QName(
				"http://schemas.xmlsoap.org/soap/encoding/", "string"));
		oper.setReturnClass(String.class);
		oper.setReturnQName(new QName("", "exportEDOCDataReturn"));
		oper.setStyle(Style.RPC);
		oper.setUse(Use.ENCODED);
		_operations[5] = oper;

		oper = new OperationDesc();
		oper.setName("applyQuery2");
		param = new ParameterDesc(
				new QName("", "BIOID"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "OID"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "CityID"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "AreaID"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "SectionID"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "IR00"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "IR49"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "LIDN"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "StartDate"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "EndDate"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		param = new ParameterDesc(
				new QName("", "ApplyUser"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new QName(
				"http://schemas.xmlsoap.org/soap/encoding/", "string"));
		oper.setReturnClass(String.class);
		oper.setReturnQName(new QName("", "applyQuery2Return"));
		oper.setStyle(Style.RPC);
		oper.setUse(Use.ENCODED);
		_operations[6] = oper;

		oper = new OperationDesc();
		oper.setName("getCity");
		oper.setReturnType(new QName(
				"http://schemas.xmlsoap.org/soap/encoding/", "string"));
		oper.setReturnClass(String.class);
		oper.setReturnQName(new QName("", "getCityReturn"));
		oper.setStyle(Style.RPC);
		oper.setUse(Use.ENCODED);
		_operations[7] = oper;

		oper = new OperationDesc();
		oper.setName("getSection");
		param = new ParameterDesc(
				new QName("", "cityID"),
				ParameterDesc.IN,
				new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"),
				String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new QName(
				"http://schemas.xmlsoap.org/soap/encoding/", "string"));
		oper.setReturnClass(String.class);
		oper.setReturnQName(new QName("", "getSectionReturn"));
		oper.setStyle(Style.RPC);
		oper.setUse(Use.ENCODED);
		_operations[8] = oper;

		oper = new OperationDesc();
		oper.setName("getVersion");
		oper.setReturnType(new QName(
				"http://schemas.xmlsoap.org/soap/encoding/", "string"));
		oper.setReturnClass(String.class);
		oper.setReturnQName(new QName("", "getVersionReturn"));
		oper.setStyle(Style.RPC);
		oper.setUse(Use.ENCODED);
		_operations[9] = oper;

	}

	public EPaperServiceSoapBindingStub() throws AxisFault {
		this(null);
	}

	public EPaperServiceSoapBindingStub(URL endpointURL,
			Service service) throws AxisFault {
		this(service);
		super.cachedEndpoint = endpointURL;
	}

	public EPaperServiceSoapBindingStub(Service service)
			throws AxisFault {
		if (service == null) {
			super.service = new Service();
		} else {
			super.service = service;
		}
		((Service) super.service).setTypeMappingVersion("1.2");
	}

	protected Call createCall() throws RemoteException {
		try {
			Call _call = super._createCall();
			if (super.maintainSessionSet) {
				_call.setMaintainSession(super.maintainSession);
			}
			if (super.cachedUsername != null) {
				_call.setUsername(super.cachedUsername);
			}
			if (super.cachedPassword != null) {
				_call.setPassword(super.cachedPassword);
			}
			if (super.cachedEndpoint != null) {
				_call.setTargetEndpointAddress(super.cachedEndpoint);
			}
			if (super.cachedTimeout != null) {
				_call.setTimeout(super.cachedTimeout);
			}
			if (super.cachedPortName != null) {
				_call.setPortName(super.cachedPortName);
			}
			Enumeration keys = super.cachedProperties.keys();
			while (keys.hasMoreElements()) {
				String key = (String) keys.nextElement();
				_call.setProperty(key, super.cachedProperties.get(key));
			}
			return _call;
		} catch (java.lang.Throwable _t) {
			log.fatal(_t, _t);
			throw new AxisFault("Failure trying to get the Call object", _t);
		}
	}

	public String applyEDOC(String xml) throws RemoteException {
		if (super.cachedEndpoint == null) {
			throw new NoEndPointException();
		}
		Call _call = createCall();
		_call.setOperation(_operations[0]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("");
		_call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new QName(
				"http://Cathay.webservice.eDoc.secureinside.com", "applyEDOC"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try {
			Object _resp = _call.invoke(new Object[] { xml });

			if (_resp instanceof RemoteException) {
				throw (RemoteException) _resp;
			} else {
				extractAttachments(_call);
				try {
					return (String) _resp;
				} catch (Exception _exception) {
					return (String) JavaUtils.convert(_resp, String.class);
				}
			}
		} catch (AxisFault axisFaultException) {
			log.fatal(axisFaultException, axisFaultException);
			throw axisFaultException;
		}
	}

	public String applyQuery(String bioid, String entID, String cityID,
			String areaID, String sectionID, String IR00, String IR49,
			String LIDN, String startDate, String endDate, String applyUse)
			throws RemoteException {
		if (super.cachedEndpoint == null) {
			throw new NoEndPointException();
		}
		Call _call = createCall();
		_call.setOperation(_operations[1]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("");
		_call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new QName(
				"http://Cathay.webservice.eDoc.secureinside.com", "applyQuery"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try {
			Object _resp = _call.invoke(new Object[] { bioid, entID, cityID,
					areaID, sectionID, IR00, IR49, LIDN, startDate, endDate,
					applyUse });

			if (_resp instanceof RemoteException) {
				throw (RemoteException) _resp;
			} else {
				extractAttachments(_call);
				try {
					return (String) _resp;
				} catch (Exception _exception) {
					return (String) JavaUtils.convert(_resp, String.class);
				}
			}
		} catch (AxisFault axisFaultException) {
			log.fatal(axisFaultException, axisFaultException);
			throw axisFaultException;
		}
	}

	public String applyQuery(String bioid) throws RemoteException {
		if (super.cachedEndpoint == null) {
			throw new NoEndPointException();
		}
		Call _call = createCall();
		_call.setOperation(_operations[2]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("");
		_call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new QName(
				"http://webservice.eDoc.secureinside.com", "applyQuery"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try {
			Object _resp = _call.invoke(new Object[] { bioid });

			if (_resp instanceof RemoteException) {
				throw (RemoteException) _resp;
			} else {
				extractAttachments(_call);
				try {
					return (String) _resp;
				} catch (Exception _exception) {
					return (String) JavaUtils.convert(_resp, String.class);
				}
			}
		} catch (AxisFault axisFaultException) {
			log.fatal(axisFaultException, axisFaultException);
			throw axisFaultException;
		}
	}

	public String combinePDF(String xml) throws RemoteException {
		if (super.cachedEndpoint == null) {
			throw new NoEndPointException();
		}
		Call _call = createCall();
		_call.setOperation(_operations[3]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("");
		_call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new QName(
				"http://Cathay.webservice.eDoc.secureinside.com", "combinePDF"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try {
			Object _resp = _call.invoke(new Object[] { xml });

			if (_resp instanceof RemoteException) {
				throw (RemoteException) _resp;
			} else {
				extractAttachments(_call);
				try {
					return (String) _resp;
				} catch (Exception _exception) {
					return (String) JavaUtils.convert(_resp, String.class);
				}
			}
		} catch (AxisFault axisFaultException) {
			log.fatal(axisFaultException,axisFaultException);
			throw axisFaultException;
		}
	}

	public String combineQuery(String pdfno) throws RemoteException {
		if (super.cachedEndpoint == null) {
			throw new NoEndPointException();
		}
		Call _call = createCall();
		_call.setOperation(_operations[4]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("");
		_call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new QName(
				"http://Cathay.webservice.eDoc.secureinside.com",
				"combineQuery"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try {
			Object _resp = _call.invoke(new Object[] { pdfno });

			if (_resp instanceof RemoteException) {
				throw (RemoteException) _resp;
			} else {
				extractAttachments(_call);
				try {
					return (String) _resp;
				} catch (Exception _exception) {
					return (String) JavaUtils.convert(_resp, String.class);
				}
			}
		} catch (AxisFault axisFaultException) {
			log.fatal(axisFaultException,axisFaultException);
			throw axisFaultException;
		}
	}

	public String exportEDOCData(String guid) throws RemoteException {
		if (super.cachedEndpoint == null) {
			throw new NoEndPointException();
		}
		Call _call = createCall();
		_call.setOperation(_operations[5]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("");
		_call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new QName(
				"http://webservice.eDoc.secureinside.com", "exportEDOCData"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try {
			Object _resp = _call.invoke(new Object[] { guid });

			if (_resp instanceof RemoteException) {
				throw (RemoteException) _resp;
			} else {
				extractAttachments(_call);
				try {
					return (String) _resp;
				} catch (Exception _exception) {
					return (String) JavaUtils.convert(_resp, String.class);
				}
			}
		} catch (AxisFault axisFaultException) {
			log.fatal(axisFaultException,axisFaultException);
			throw axisFaultException;
		}
	}

	public String applyQuery2(String BIOID, String OID, String cityID,
			String areaID, String sectionID, String IR00, String IR49,
			String LIDN, String startDate, String endDate, String applyUser)
			throws RemoteException {
		if (super.cachedEndpoint == null) {
			throw new NoEndPointException();
		}
		Call _call = createCall();
		_call.setOperation(_operations[6]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("");
		_call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new QName(
				"http://webservice.eDoc.secureinside.com", "applyQuery2"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try {
			Object _resp = _call.invoke(new Object[] { BIOID, OID, cityID,
					areaID, sectionID, IR00, IR49, LIDN, startDate, endDate,
					applyUser });

			if (_resp instanceof RemoteException) {
				throw (RemoteException) _resp;
			} else {
				extractAttachments(_call);
				try {
					return (String) _resp;
				} catch (Exception _exception) {
					return (String) JavaUtils.convert(_resp, String.class);
				}
			}
		} catch (AxisFault axisFaultException) {
			log.fatal(axisFaultException, axisFaultException);
			throw axisFaultException;
		}
	}

	public String getCity() throws RemoteException {
		if (super.cachedEndpoint == null) {
			throw new NoEndPointException();
		}
		Call _call = createCall();
		_call.setOperation(_operations[7]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("");
		_call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new QName(
				"http://webservice.eDoc.secureinside.com", "getCity"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try {
			Object _resp = _call.invoke(new Object[] {});

			if (_resp instanceof RemoteException) {
				throw (RemoteException) _resp;
			} else {
				extractAttachments(_call);
				try {
					return (String) _resp;
				} catch (Exception _exception) {
					return (String) JavaUtils.convert(_resp, String.class);
				}
			}
		} catch (AxisFault axisFaultException) {
			log.fatal(axisFaultException,axisFaultException);
			throw axisFaultException;
		}
	}

	public String getSection(String cityID) throws RemoteException {
		if (super.cachedEndpoint == null) {
			throw new NoEndPointException();
		}
		Call _call = createCall();
		_call.setOperation(_operations[8]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("");
		_call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new QName(
				"http://webservice.eDoc.secureinside.com", "getSection"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try {
			Object _resp = _call.invoke(new Object[] { cityID });

			if (_resp instanceof RemoteException) {
				throw (RemoteException) _resp;
			} else {
				extractAttachments(_call);
				try {
					return (String) _resp;
				} catch (Exception _exception) {
					return (String) JavaUtils.convert(_resp, String.class);
				}
			}
		} catch (AxisFault axisFaultException) {
			log.fatal(axisFaultException,axisFaultException);
			throw axisFaultException;
		}
	}

	public String getVersion() throws RemoteException {
		if (super.cachedEndpoint == null) {
			throw new NoEndPointException();
		}
		Call _call = createCall();
		_call.setOperation(_operations[9]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("");
		_call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new QName(
				"http://webservice.eDoc.secureinside.com", "getVersion"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try {
			Object _resp = _call.invoke(new Object[] {});

			if (_resp instanceof RemoteException) {
				throw (RemoteException) _resp;
			} else {
				extractAttachments(_call);
				try {
					return (String) _resp;
				} catch (Exception _exception) {
					return (String) JavaUtils.convert(_resp, String.class);
				}
			}
		} catch (AxisFault axisFaultException) {
			log.fatal(axisFaultException,axisFaultException);
			throw axisFaultException;
		}
	}

}
