package com.cathay.ep.g1.ws;
import java.io.Serializable;
import java.io.StringReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.rpc.ServiceException;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.LRUMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.cache.CacheManager;
import com.cathay.ep.g1.xml.apl.EDOCAPPLY;
import com.cathay.ep.g1.xml.exp.EDOCExport;
import com.cathay.ep.g1.xml.qry.EDOCQuery;
import com.cathay.ep.g1.xml.sct.SectionInfo;
import com.cathay.ep.z0.module.EP_Z0G511;
import com.cathay.util.VOHelper;

/**
 * �q�l�å������A�ȩI�s�Ҳ�
 * DPLand EPaper Web Service �Τ�ݤu��禡�w�A��K�I�s�q�l�å������A��
 * 1.�z�LWSDL to Java���� ��Stub Port�I�s�q�l�å������A��
 * 2.�z�LJAXB�i��XML Mapping��K�ѪR�����A�Ȫ��^�ǵ��G
 * @author i9301212
 * 2019/10/21 AllenTsai �إ�DPLand EPaper Web Service �Τ�ݤu��禡�w�A��K�I�s�q�l�å������A��
 * 2019/11/11 AllenTsai �վ�API�e�����]�ȳB�z
 * 2019/11/12 AllenTsai �վ㰣�k�p��B�z �����w�p�Ʀ�ƻP�i��覡
 * 2019/11/12 AllenTsai �վ��v�����n = (�Ӽh���n + ���ݫؿv���n + �@�P�����������n) * �Ҧ��v����
 * 2019/11/12 AllenTsai �վ㥭�褽�ت����n�p���p���I4��A�W�[�W�ƭ��n�p��
 * 2019/11/14 AllenTsai �վ��v���W�ƦP�ɿ�X�W�ƻP���褽��
 * 2019/11/18 AllenTsai �վ㰣�k�ݶǤJ�i���ƻP�i��覡
 * 2019/11/19 AllenTsai �վ�W�[���O�O�_���L���v�Q��ƻP�Ҧ��v��L�n�O�ƶ��P�@�P�ϥγ�������L�n�O�ƶ�
 * 2019/11/20 AllenTsai �z�L�{������ Axis log4j DEBUG�T���A�]�w��Level.ERROR
 * 2019/12/12 AllenTsai �վ�{���B�z�@�P�ϥγ����A���� ������0 �����p
 */
public class DPLandHelper {
	

	//���褽�حp��i��
	private static final int AREA_SIZE_SCALE = 4;
	//�W�ƭp��i��
	private static final int AREA_PING_SCALE = 2;
	
	private static final BigDecimal M2_TO_PING = new BigDecimal("0.3025");


	private static final Logger log = Logger.getLogger(DPLandHelper.class);
	
	
	//�q�l�å������ϰ�q�p�q�M��
	private static Map citySessionCacheMap;	
	
    static {
        citySessionCacheMap = CacheManager.register("DPLandHelper_querySection_�q�l�å������ϰ�q�p�q�M��", new LRUMap(10));
    }
	
	/**
	 * �ӽФg�a�Ϋت��q�l�å�
	 * @param rtnMap
	 * @return
	 * @throws ModuleException
	 */
	public Map<String, String> applyEDoc(Map<String, String> rtnMap) throws ModuleException {
			
		EPaperServiceServiceLocator locator = new EPaperServiceServiceLocator();		
		try{
			closeAxisLogLevel();
		} catch(Throwable e) {
			log.fatal(e, e);
		}

		try {
			Map<String, String> appRtnMap = new HashMap<String, String>();
			EPaperService_PortType service = locator.getEPaperService();
			

			appRtnMap.put("CODE", "X");
			DPLandHelper dpland = new DPLandHelper();
			String xml = dpland.getAplyXML(rtnMap);
			log.debug("================= XML  =================\n"+xml);
			String result = service.applyEDOC(xml);
			log.debug("ApplyEDOC Result: \n"+result);
			
			JAXBContext jaxbContext = JAXBContext.newInstance(EDOCAPPLY.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			
			StringReader reader = new StringReader(result);
			EDOCAPPLY edocApply= (EDOCAPPLY) unmarshaller.unmarshal(reader);
//			log.debug(edocQuery);
			EDOCAPPLY.RespMsg  respMsg = edocApply.getRespMsg();
			appRtnMap.put("CODE", respMsg.getCode());
			appRtnMap.put("RESP_MSG",  respMsg.getValue());
//			log.debug(qryResult);
			log.debug("========================  �ӽФg�a�Ϋت��q�l�å�  ========================");	
			log.debug("�ӽФg�a�Ϋت��q�l�å�: "+respMsg.getCode()+" "+respMsg.getValue());
			return appRtnMap;	
		} catch (ServiceException e1) {
			log.fatal(e1,e1);
			throw new ModuleException(e1);
		} catch (JAXBException e) {
			log.fatal(e);
			throw new ModuleException(e);
		} catch (RemoteException e) {
			log.fatal(e);
			throw new ModuleException(e);
		}
		

	}
	
	/**
	 * ���o�����M��
	 * @return List<Map> 
	 *  �C����Ʀ� {CITY_ID=376570000A, CITY_NM=�򶩥�}
	 * @throws ModuleException 
	 */
	public List<Map> getCityList() throws ModuleException {
		List<Map> rtnList = new ArrayList<Map>();

		if(citySessionCacheMap.containsKey("CITY_LIST")) {
			rtnList = (List<Map> ) citySessionCacheMap.get("CITY_LIST");			
		} else{
			rtnList = queryCity();
			//�N�M���J Cached Map �קK���ƩI�s Web Service
			citySessionCacheMap.put("CITY_LIST", rtnList);
		}
		return rtnList;

	}	
	
	/**
	 * �I�sWebService ���o�����M��
	 * @return List<Map> 
	 *  �C����Ʀ� {CITY_ID=376570000A, CITY_NM=�򶩥�}
	 * @throws ModuleException 
	 */
	private List<Map> queryCity() throws ModuleException {
		EPaperServiceServiceLocator locator = new EPaperServiceServiceLocator();			
		try{
			closeAxisLogLevel();
		} catch(Throwable e) {
			log.fatal(e, e);
		}

		List<Map> rtnList = new ArrayList<Map>();

		
		EPaperService_PortType service;
		try {
			service = locator.getEPaperService();
			String result = service.getCity();
			log.debug("queryCity Result: \n"+result);	
			

			JAXBContext jaxbContext = JAXBContext.newInstance(SectionInfo.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			
			StringReader reader = new StringReader(result);
			SectionInfo section= (SectionInfo) unmarshaller.unmarshal(reader);
//			log.debug(edocQuery);
			SectionInfo.RespMsg  respMsg = section.getRespMsg();
			SectionInfo.Result qryResult = section.getResult();
			
			List<SectionInfo.Result.City> cities =  qryResult.getCity();
			log.debug("���G: "+respMsg.getCode() +" "+ respMsg.getValue());
//			log.debug(qryResult);
			log.debug("========================  ���o�Ҧ��������N�X���  ========================");			
			for(SectionInfo.Result.City city: cities) {
				Map data = new HashMap();
				data.put("CITY_ID", city.getID());
				data.put("CITY_NM", city.getName());
//				log.debug(data);
				rtnList.add(data);
			}
					

			
		} catch (ServiceException e1) {
			log.fatal(e1,e1);
			throw new ModuleException(e1);
		} catch (JAXBException e) {
			log.fatal(e);
			throw new ModuleException(e);
		} catch (RemoteException e) {
			log.fatal(e);
			throw new ModuleException(e);
		}

	
		return rtnList;	
	}	
	
	
	
	/**
	 * �d�߹q�l�å��վ\�i��
	 * @param aplyNo �վ\�ӽнs��
	 * @param baseCd ��a�N��
	 * @return
	 * @throws ModuleException
	 */
	public Map<String, Map> queryApplyNo(String aplyNo, String baseCd)
			throws ModuleException {
		String bioID = getBIOID(aplyNo, baseCd);
		Map<String, Map> resultMap = queryByBIOID(bioID, "", ""); 
		return resultMap;

	}
	public Map<String, Map> queryByBIOID(String bioID, String begDate, String endDate) throws ModuleException {
		return queryByBIOIDOID(bioID,"", begDate, endDate);
	}
	/**
	 * @param bioID �q�l�å����z�s��
	 * @param OID  ���zOID
	 * @param begDate �}�l��� yyyymmdd
	 * @param endDate ������� yyyymmdd
	 * @return �q�l�å����z�i�׬d��
	 * @throws ModuleException
	 */
	public Map<String, Map> queryByBIOIDOID(String bioID, String oid, String begDate, String endDate) throws ModuleException {
		Map<String, Map> resultMap = new HashMap<String, Map>();
		try {
			
			EPaperServiceServiceLocator locator = new EPaperServiceServiceLocator();			
			try{
				closeAxisLogLevel();
			} catch(Throwable e) {
				log.fatal(e, e);
			}

			EPaperService_PortType service = locator.getEPaperService();
			
			String result = service.applyQuery2(bioID, oid, "", "", "", "", "", "", begDate, endDate, "");
			log.debug("queryApply2 Result: \n"+result);
			
			JAXBContext jaxbContext = JAXBContext.newInstance(EDOCQuery.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			
			StringReader reader = new StringReader(result);
			EDOCQuery edocQuery= (EDOCQuery) unmarshaller.unmarshal(reader);
//			log.debug(edocQuery);
			EDOCQuery.Result  qryResult = edocQuery.getResult();
			EDOCQuery.RespMsg resp = edocQuery.getRespMsg();
			if(resp.getCode().equals("0")) {
//				log.debug(qryResult);
				log.debug("========================  �d�߹q�l�å��ӽжi��  ========================");			
				List<EDOCQuery.Result.EDOCData>  edocDatas = qryResult.getEDOCData();
				for(EDOCQuery.Result.EDOCData edocData: edocDatas) {
					String key = edocData.getBIOID()+"_"+edocData.getOID();
					Map rtnMap = new HashMap<String, String>();
					rtnMap.put("APLY_OID_KEY", key);
					rtnMap.put("IR49_NO", edocData.getIR49());
					rtnMap.put("EP_KIND", edocData.getIR00().getID());
					String strApplyDate = edocData.getApplyDate();
					if(StringUtils.isNotEmpty(strApplyDate)) {
						strApplyDate = DATE.getDBTimeStamp(strApplyDate);
					}
					rtnMap.put("EP_APL_DATE", strApplyDate);
					rtnMap.put("EP_APLY_STS", edocData.getStatus().getCode());
					rtnMap.put("EP_APLY_DESC", edocData.getStatus().getDesc());
					StringBuilder sbMsg = new StringBuilder();
					List<Serializable> listSer = edocData.getStatus().getContent();
					for(Serializable ser: listSer) {
						if(ser instanceof String) {
							sbMsg.append(ser.toString());							
						}

					}
					String aplyMsg = StringUtils.abbreviate(sbMsg.toString(), 100);
					rtnMap.put("EP_APLY_MSG", aplyMsg);
					rtnMap.put("EP_URL", StringUtils.replace(edocData.getURL(), "&amp;", "&"));
					rtnMap.put("EP_GUID", edocData.getGUID());
					rtnMap.put("EP_PAGE", edocData.getPage());
					if(resultMap.containsKey(key)) {
						log.debug("====== KEY EXIST:"+key);
						Map existMap =  resultMap.get(key);
						String epAplyDate =  strApplyDate;
						String existAplyDate = MapUtils.getString(existMap, "EP_APL_DATE", "");
						if(StringUtils.isNotEmpty(existAplyDate) && epAplyDate.compareTo(existAplyDate) >0) {
							log.debug("====== epAplyDate ("+epAplyDate+") > existAplyDate ("+existAplyDate+")��s�ץX���");
							resultMap.put(key, rtnMap);
						} 
					} else {
						resultMap.put(key, rtnMap);	
					}
					
//					if(!"D".equals(edocData.getStatus().getCode())) {
//						continue;
//					}

					
					//JAXBElement qryResult = edocQuery.getValue();
//					log.debug(edocData);
				}				
			}

			return resultMap;	
		} catch (ServiceException e1) {
			log.fatal(e1,e1);
			throw new ModuleException(e1);
		} catch (JAXBException e) {
			log.fatal(e);
			throw new ModuleException(e);
		} catch (RemoteException e) {
			log.fatal(e);
			throw new ModuleException(e);
		}
	}		
	
	
	/**
	 * ���o��J�������ϰ�M��
	 * @param cityID �����N�X
	 * @return �ϰ�M��
	 * @throws ModuleException
	 */
	public List<Map> getCityAreaList(String cityID) throws ModuleException  {
		
		List<Map> rtnList = new ArrayList<Map>();

		if(citySessionCacheMap.containsKey(cityID)) {
			Map<String,List> citySessionMap =  (Map<String, List>) citySessionCacheMap.get(cityID);
			rtnList = citySessionMap.get("AREA");
		} else{
			Map<String,List> citySessionMap = querySection(cityID);
			//�N�M���J Cached Map �קK���ƩI�s Web Service
			citySessionCacheMap.put(cityID, citySessionMap);
			rtnList = citySessionMap.get("AREA");
		}
		return rtnList;
	}
	
	/**
	 * ���o��J�����ϰ줧�a�q�p�q�M��
	 * @param cityID �����N�X
	 * @param areaID �ϰ�N�X
	 * @return �a�q�p�q�M��
	 * @throws ModuleException
	 */
	public List<Map> getAreaSectionList(String cityID, String areaID) throws ModuleException  {
		
		List<Map> rtnList = new ArrayList<Map>();
		
		Map<String,List> sessionMap;
		if(citySessionCacheMap.containsKey(cityID)) {
			sessionMap =  (Map<String, List>) citySessionCacheMap.get(cityID);
		} else{
			sessionMap = querySection(cityID);
			//�N�M���J Cached Map �קK���ƩI�s Web Service
			citySessionCacheMap.put(cityID, sessionMap);
		}
		
		
		String key =cityID+"_"+areaID;
		rtnList = (List<Map>) sessionMap.get(key);
		log.debug("rtnList size:"+ rtnList.size());
		if(rtnList==null) {
			throw new IllegalArgumentException("�ǤJ������["+cityID+"]�ϰ�["+areaID+"]�N�����~�A�d�L���");
		}
		
		return rtnList;
	}	
	
	/**
	 * ���o��J�����ϰ�ŦX�a�q�p�q�W�٤��a�q�p�q�M��
	 * @param cityID �����N�X
	 * @param areaID �ϰ�N�X
	 * @param qrySessName �a�q�p�q�W��
	 * @return �����ϰ�ŦX�a�q�p�q�W�٤��p �a�q�p�q�M��
	 * @throws ModuleException
	 */
	public List<Map> getSugSectionList(String cityID, String areaID, String qrySessName) throws ModuleException  {
		
		List<Map> rtnList = getAreaSectionList(cityID, areaID);
		List<Map> sugList = new ArrayList<Map>();
		for(Map data: rtnList) {
			String sessionName = MapUtils.getString(data, "SESSION_NM");
			if(sessionName.indexOf(qrySessName) >=0) {
				sugList.add(data);
			}
		}
		
		
		return sugList;
	}		
	
	/**
	 * �I�sWebService ���o�������ϰ�P�a�q�p�q�M��
	 * @param (cityID) �����N�X
	 * @return �ӿ������ϰ�M��P�a�q�p�q�M��
	 * @throws ModuleException
	 */
	private Map querySection(String cityID) throws ModuleException  {

		try {
			Map<String , List> rtnMap = new HashMap<String, List>();
			EPaperServiceServiceLocator locator = new EPaperServiceServiceLocator();
			try{
				closeAxisLogLevel();
			} catch(Throwable e) {
				log.fatal(e, e);
			}

			EPaperService_PortType service = locator.getEPaperService();
			
			String result = service.getSection(cityID);
			log.debug("querySection Result: \n"+result);
			List<Map> areaList = new ArrayList<Map>();
			StringBuilder sb = new StringBuilder();			
			JAXBContext jaxbContext = JAXBContext.newInstance(SectionInfo.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			
			StringReader reader = new StringReader(result);
			SectionInfo sectionInfo= (SectionInfo) unmarshaller.unmarshal(reader);
//			log.debug(edocQuery);
			SectionInfo.RespMsg  respMsg = sectionInfo.getRespMsg();
			SectionInfo.Result qryResult = sectionInfo.getResult();
			
			List<SectionInfo.Result.City> cities =  qryResult.getCity();
			log.debug("���G: "+respMsg.getCode() +" "+ respMsg.getValue());
//			log.debug(qryResult);
			log.debug("========================  ���o�S�w�������q�p�q���  ========================");		

			for(SectionInfo.Result.City city: cities) {
				log.debug(city.getID() +": "+ city.getName());
				List<SectionInfo.Result.City.Area> areas =  city.getArea();
				for(SectionInfo.Result.City.Area area: areas) {
					Map mapArea = new HashMap();//VOHelper.voToMap(area);
					mapArea.put("AREA_ID", area.getID());
					mapArea.put("AREA_NM", area.getName());
					areaList.add(mapArea);
					
					List<SectionInfo.Result.City.Area.Section> sections =  area.getSection();
					List<Map> sectionList = new ArrayList<Map>();
					for(SectionInfo.Result.City.Area.Section section: sections) {
						//log.debug("==== �a��: "+section.getLN() + section.getLNName()+ ", �q�p�q:"+ section.getID() +": " + section.getValue());
						Map mapSection = new HashMap();
						mapSection.put("SESSION_ID", section.getID());
						mapSection.put("SESSION_NM", section.getValue());
						mapSection.put("LN", section.getLN());
						mapSection.put("LN_NM", section.getLNName());
						sectionList.add(mapSection);
					}
					rtnMap.put(city.getID().trim()+"_"+ area.getID().trim(), sectionList);					
					
				}	
				//JAXBElement qryResult = edocQuery.getValue();
//				log.debug(edocData);
			}
			log.debug(sb);
			rtnMap.put("AREA", areaList);
			return rtnMap;	
		} catch (ServiceException e1) {
			log.fatal(e1,e1);
			throw new ModuleException(e1);
		} catch (JAXBException e) {
			log.fatal(e);
			throw new ModuleException(e);
		} catch (RemoteException e) {
			log.fatal(e);
			throw new ModuleException(e);
		}	

	}		

	
	/**
	 * �ץX�ت��å����
	 * @param guid 
	 * @param dataMap �g�ت��å����
	 * @return Map<String, Object> 
	 *   �ت��å����          BUILD_REG: Map    
	 *   �ت��Ӽh���       FLOOR_LIST: List<Map>  
	 *   �ت��Ҧ��v���        OWN_LIST: List<Map> 
	 *   �@�P�ϥγ���    COMMON_LIST: List<Map>
	 * @throws ModuleException
	 */
	public Map exportBuildEDOCData(String guid, Map dataMap)
			throws ModuleException{
		Map resultMap = new HashMap();
		
		try {
			EPaperServiceServiceLocator locator = new EPaperServiceServiceLocator();			
			try{
				closeAxisLogLevel();
			} catch(Throwable e) {
				log.fatal(e, e);
			}

			EPaperService_PortType service = locator.getEPaperService();
			
			String result = service.exportEDOCData(guid);
			log.debug("exportEDOCData Result: \n"+result);
			
			JAXBContext jaxbContext = JAXBContext.newInstance(EDOCExport.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			
			StringReader reader = new StringReader(result);
			EDOCExport edocExport= (EDOCExport) unmarshaller.unmarshal(reader);
//			log.debug(edocQuery);
			EDOCExport.RespMsg  respMsg = edocExport.getRespMsg();
			//�d�ߦ��\
			if(respMsg.getCode().equals("0")) {
				log.debug("getRespMsg:"+ respMsg.getCode() + ":" + respMsg.getValue());
//				log.debug(qryResult);
				BigDecimal totBldAreaSize = BigDecimal.ZERO;
				
				EDOCExport.EDOCData  edocData = edocExport.getEDOCData();
				EDOCExport.EDOCData.BuildREG buidReg = edocData.getBuildREG();
//				log.debug("========================  �ت��å����  ========================");
				Map mapBuild = new HashMap();
				BigDecimal areaSize = getAreaSize( buidReg.getTotalAreaSize());
				mapBuild.put("BLD_NO", formatBuildNo(buidReg.getBuildNo()));
				mapBuild.put("CITY_NM", buidReg.getCity().getValue());
				mapBuild.put("AREA_NM", buidReg.getArea().getValue());
				mapBuild.put("SESSION_NM", buidReg.getSection().getValue());
				mapBuild.put("BLD_ADDR", buidReg.getAddress());
				mapBuild.put("AREA_SIZE", areaSize);
				mapBuild.put("FIN_DATE", buidReg.getFinishDate());
				mapBuild.put("BLD_LVL", buidReg.getBuildLevel());
				mapBuild.put("PRPS_ID", buidReg.getPurpose().getID() );
				mapBuild.put("PRPS_NM", buidReg.getPurpose().getValue());
				mapBuild.put("MAT_ID", buidReg.getMaterial().getID());
				mapBuild.put("MAT_NM", buidReg.getMaterial().getValue());
				mapBuild.put("REG_DATE", buidReg.getRegisterReason().getDate());
				List<EDOCExport.EDOCData.BuildREG.OtherRegister> registers =buidReg.getOtherRegister();
				StringBuilder sbReg = new StringBuilder();
				for(EDOCExport.EDOCData.BuildREG.OtherRegister othReg: registers) {
//					log.debug("�䥦�n�O�ƶ�:"+othReg.getID()+ " " + othReg.getValue());	
					sbReg.append(othReg.getValue()).append("\n");
				}
				String regDesc = StringUtils.abbreviate(sbReg.toString(), 200);
				mapBuild.put("REG_DESC", regDesc);
				
//				log.debug("========================  �ت��Ҧ��v���  ========================");
				List<EDOCExport.EDOCData.BuildREG.BTEBOW> owners = buidReg.getBTEBOW();

				List<Map> ownList = new ArrayList<Map>();
				long lLCM =1;
				int ownSeq = 1;
				boolean othReg = false;
				for(EDOCExport.EDOCData.BuildREG.BTEBOW own: owners) {
					Map buildOwn = getBuildOwnData(ownSeq, own);
					if("Y".equals(MapUtils.getString(buildOwn, "OTH_REG"))) {
						othReg = true;
					}
					ownList.add(buildOwn);
					//�p���v�Q�d����� ������
					long lDeonminator = own.getRightsRange().getDenominator();
					lLCM = calLCM(lLCM, lDeonminator);
					ownSeq++;
				}
				if(othReg){
					mapBuild.put("OTH_REG", "Y");	
				} else {
					mapBuild.put("OTH_REG", "N");
				}
				
				
				//�]�w�Ҧ��v���
				resultMap.put("OWN_LIST", ownList);
				
				log.debug("�Ҧ��v�[�`������: "+lLCM);
				long sumNum = getTotOwnNumerator(ownList, lLCM);
	            //�p��Ҧ��v�`���� 
				mapBuild.put("TOT_HLD_D", lLCM);
				mapBuild.put("TOT_HLD_N", sumNum);
				//2019/11/12 �վ㰣�k�p��B�z �����w�p�Ʀ�ƻP�i��覡
				BigDecimal bdLandArea = areaSize;							
				totBldAreaSize = areaSize;
				
				
				List<Map> floorList = new ArrayList<Map>();
				int floorSeq =1;
				List<EDOCExport.EDOCData.BuildREG.FloorInfo> floors = buidReg.getFloorInfo();
				for(EDOCExport.EDOCData.BuildREG.FloorInfo flr: floors) {
					Map mapFloor = new HashMap();
					mapFloor.put("FLR_SEQ", floorSeq);
					String buildType = flr.getBuildType().getType();
					mapFloor.put("BLD_TP", buildType );
					mapFloor.put("BLD_TP_NM",  flr.getBuildType().getValue());
					mapFloor.put("PRPS_CD", flr.getPurpose().getID());
					mapFloor.put("PRPS_CD_NM", flr.getPurpose().getValue());
					BigDecimal floorAreaSize = getAreaSize(flr.getAreaSize());
					//�Ӽh���n���`�B�z
					if(floorAreaSize.compareTo(BigDecimal.ZERO) ==0) {
						EP_Z0G511 theEP_Z0G511 = new EP_Z0G511();
						try{
							List<Map> pcsList = theEP_Z0G511.queryG540List("A", dataMap);	
							for(Map pcsData:pcsList) {
								String pcsMemo = MapUtils.getString(pcsData, "ALT_PCS_MEMO");
								if(StringUtils.isNotEmpty(pcsMemo)){
									Map pcsMap = VOTool.jsonToMap(pcsMemo);
									//{BLD_TP=S,BLD_TP_NM=���������ǡB�������C�������D�������褽��,AREA_SIZE=998.92}
									if(buildType.equals(MapUtils.getString(pcsMap, "BLD_TP"))&& 
											MapUtils.getString(pcsMap, "BLD_TP_NM","").equals(flr.getPurpose().getValue())) {
										floorAreaSize = new BigDecimal(MapUtils.getString(pcsMap, "AREA_SIZE"));
										floorAreaSize = floorAreaSize.setScale(AREA_SIZE_SCALE, RoundingMode.HALF_UP);
									}
								}
							}
						} catch(Exception e) {
							//ignore dataNotFoundException
							log.fatal("�Ӽh���`�B�z���~:",e);
						}
						
					}
					//���ݫؿv  �[�`�ت��v���`���n
					if("S".equals(buildType)) {
						totBldAreaSize = totBldAreaSize.add(floorAreaSize);
					}
					mapFloor.put("AREA_SIZE", floorAreaSize);
					floorList.add(mapFloor);
//					log.debug("�ت��Ӽh���O:"+flr.getBuildType().getType() + flr.getBuildType().getValue() +", �γ~:"+flr.getPurpose().getID() + flr.getPurpose().getValue() + ", ���n:"+flr.getAreaSize());
					floorSeq++;
				}
				resultMap.put("FLOOR_LIST", floorList);

				
				
				
				List<Map> commonList = new ArrayList<Map>();
				int cmnSeq = 1;
				List<EDOCExport.EDOCData.BuildREG.BTOD31> shares = buidReg.getBTOD31();
				for(EDOCExport.EDOCData.BuildREG.BTOD31 share: shares) {
					Map mapCmn = new HashMap();
					mapCmn.put("CMN_SEQ", cmnSeq);
					mapCmn.put("CMN_BLD_NO", formatBuildNo(share.getCommonUseBuildNo().getValue()));
					//RGTHLD_N	�v�Q�d����l
					int RGTHLD_N =  share.getRightsRange().getNumerator();
					//RGTHLD_D	�v�Q�d�����
					int RGTHLD_D =  share.getRightsRange().getDenominator();
					mapCmn.put("RGTHLD_D", RGTHLD_N);
					mapCmn.put("RGTHLD_N", RGTHLD_D);
					BigDecimal cmnAreaSize = getAreaSize(share.getAreaSize());
					mapCmn.put("AREA_SIZE", cmnAreaSize);
					
					//�@�P�����̷ӫ������ �p��������n 
					BigDecimal BD_RGTHLD_D = new BigDecimal(RGTHLD_D);
					//�B�z�@�P�ϥΫ��� ������0 �����p
					BigDecimal RGTHLD_SIZE = BigDecimal.ZERO;
					if(!BD_RGTHLD_D.equals(BigDecimal.ZERO)) {
						RGTHLD_SIZE = cmnAreaSize.multiply(new BigDecimal(RGTHLD_N))
								.divide(BD_RGTHLD_D,AREA_SIZE_SCALE, RoundingMode.HALF_UP);
						
					}
					mapCmn.put("RGTHLD_SIZE", RGTHLD_SIZE);
					
					List<EDOCExport.EDOCData.BuildREG.BTOD31.OtherRegister> listothReg =  share.getOtherRegister();
					sbReg.setLength(0);
					for(EDOCExport.EDOCData.BuildREG.BTOD31.OtherRegister cmnOthReg: listothReg) {
//						log.debug("�䥦�n�O�ƶ�:"+othReg.getID()+ " " + othReg.getValue());	
						sbReg.append(cmnOthReg.getValue()).append("\n");
					}
					String cmnOthRegDesc = StringUtils.abbreviate(sbReg.toString(), 200);
					mapCmn.put("OTH_REG_DESC", cmnOthRegDesc);
					//�@�P�������������n   �[�`��ت��v���`���n
					totBldAreaSize = totBldAreaSize.add(RGTHLD_SIZE);

					commonList.add(mapCmn);
					cmnSeq++;
				}	
				
				resultMap.put("COMMON_LIST", commonList);
				//�p��ت��v�����n  �ت��`���n(totBldAreaSize �Ӽh���n+���ݫؿv+ �@�P�����������n) * �Ҧ��v���l (sumNum)/ �Ҧ��v���� (LCM)
				bdLandArea = totBldAreaSize.multiply(new BigDecimal(sumNum));
				bdLandArea = bdLandArea.divide( new BigDecimal(lLCM), AREA_SIZE_SCALE, RoundingMode.HALF_UP);	

				mapBuild.put("BLD_AREA_M2", bdLandArea);
				mapBuild.put("ADJ_AREA_M2", bdLandArea);
				//�ت��v���W��
				BigDecimal bdLandPingSize = bdLandArea.multiply(M2_TO_PING).setScale(AREA_PING_SCALE, RoundingMode.HALF_UP);				
				mapBuild.put("BLD_AREA", bdLandPingSize);
				mapBuild.put("ADJ_AREA", bdLandPingSize);
				
				List<EDOCExport.EDOCData.BuildREG.BTCLOR>  listBTCLOR  = buidReg.getBTCLOR();
				if(listBTCLOR!=null && listBTCLOR.size()>0) {
					mapBuild.put("BTCLOR", "Y");
				} else {
					mapBuild.put("BTCLOR", "N");
				}
				//�]�w�ت��å����
				resultMap.put("BUILD_REG", mapBuild);						
			}

			
			return resultMap;	
		} catch (ServiceException e1) {
			log.fatal(e1,e1);
			throw new ModuleException(e1);
		} catch (JAXBException e) {
			log.fatal(e);
			throw new ModuleException(e);
		} catch (RemoteException e) {
			log.fatal(e);
			throw new ModuleException(e);
		}
	
	}

	private String formatBuildNo(String buildNo) {
		if(buildNo.length()==8) {
			return buildNo.substring(0,5)+"-" +buildNo.substring(5,8);
		}
		return buildNo;
	}
	
	private String formatLandNo(String landNo) {
		if(landNo.length()==8) {
			return landNo.substring(0,4)+"-" +landNo.substring(4,8);
		}
		return landNo;
	}		
	
	/**
	 * �ץX�g�a�å����
	 * @param guid
	 * @return Map <String, Object> 
	 *   �g�a�å����     LAND_REG:  Map    
	 *   �g�a�Ҧ��v���  OWN_LIST: List<Map> 
	 * @throws ModuleException

	 */
	public Map exportLandEDOCData(String guid, Map dataMap)
			throws ModuleException {
		
		Map resultMap = new HashMap(); 
		try {
			EPaperServiceServiceLocator locator = new EPaperServiceServiceLocator();			
			try{
				closeAxisLogLevel();
			} catch(Throwable e) {
				log.fatal(e, e);
			}

			EPaperService_PortType service = locator.getEPaperService();
			
			String result = service.exportEDOCData(guid);
			log.debug("exportEDOCData Result: \n"+result);
			
			JAXBContext jaxbContext = JAXBContext.newInstance(EDOCExport.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			
			StringReader reader = new StringReader(result);
			EDOCExport edocExport= (EDOCExport) unmarshaller.unmarshal(reader);
//			log.debug(edocQuery);
			EDOCExport.RespMsg  respMsg = edocExport.getRespMsg();
			log.debug("getRespMsg:"+ respMsg.getCode() + ":" + respMsg.getValue());
//			log.debug(qryResult);
			//�d�ߦ��\
			if(respMsg.getCode().equals("0")) {
				EDOCExport.EDOCData  edocData = edocExport.getEDOCData();
				
				EDOCExport.EDOCData.LandREG landReg = edocData.getLandREG();
				
				if(landReg !=null) {
					Map rtnMap = new HashMap(); 
//					log.debug("========================  �g�a�å����  ========================");
//					log.debug("�g�a�y��: "+landReg.getCity().getValue() + "  " + landReg.getArea().getValue()  + "  " + landReg.getSection().getValue());
//					log.debug("�a��:"+ landReg.getLandNo());
//					log.debug("�g�a���n: "+landReg.getAreaSize());
//					log.debug("�g�a�ϥΤ���: "+landReg.getOutLine().getID()+landReg.getOutLine().getValue());
//					log.debug("�g�a�ϥΦa���O: "+landReg.getUseType().getID()+landReg.getUseType().getValue());				
//					log.debug("�n�O���: "+landReg.getRegisterReason().getDate() +", ��]: " +landReg.getRegisterReason().getID() +landReg.getRegisterReason().getValue());
//					log.debug("���i���: "+landReg.getPublicValue().getDate() + ", �{��: " + landReg.getPublicValue().getValue());
					
					rtnMap.put("CITY_ID", landReg.getCity().getID());
					rtnMap.put("CITY_NM", landReg.getCity().getValue() );
					rtnMap.put("AREA_ID", landReg.getArea().getID());
					rtnMap.put("AREA_NM", landReg.getArea().getValue());
					rtnMap.put("SESSION_ID", landReg.getSection().getID());
					rtnMap.put("SESSION_NM", landReg.getSection().getValue());				
					rtnMap.put("LAND_NO", formatLandNo(landReg.getLandNo()));
					rtnMap.put("REG_DATE", landReg.getRegisterReason().getDate());
					rtnMap.put("REG_RSN_ID", landReg.getRegisterReason().getID());
					rtnMap.put("REG_RSN_NM", landReg.getRegisterReason().getValue());				
					rtnMap.put("PUB_YM", landReg.getPublicValue().getDate());
					rtnMap.put("PUB_VAL", landReg.getPublicValue().getValue());
					BigDecimal areaSize = getAreaSize(landReg.getAreaSize());
					rtnMap.put("AREA_SIZE", areaSize);				
//					log.debug("========================  �g�a�Ҧ��v��   ========================" );
					List<EDOCExport.EDOCData.LandREG.BTBLOW>  landOwns =  landReg.getBTBLOW();
					List<Map> ownList = new ArrayList<Map>();
					//�p���v�O�d�� ������ �̤p������ LCM
					int ownSeq = 1;
					long lLCM =1;
					boolean othReg = false;
					for(EDOCExport.EDOCData.LandREG.BTBLOW own: landOwns) {
						Map landOwn = getLandOwnData(ownSeq, own);
						rtnMap.put("OWN_ID",  own.getOwner().getID());
						rtnMap.put("OWN_NM", own.getOwner().getValue());
						if("Y".equals(MapUtils.getString(landOwn, "OTH_REG"))) {
							othReg = true;
						}
						ownList.add(landOwn);
						//�v�Q�d�����
						long lDeonminator = own.getRightsRange().getDenominator();

						lLCM = calLCM(lLCM, lDeonminator);

						ownSeq++;
					}
					
					if(othReg){
						rtnMap.put("OTH_REG", "Y");	
					} else {
						rtnMap.put("OTH_REG", "N");
					}
					//�]�w�Ҧ��v���
					resultMap.put("OWN_LIST", ownList);
					log.debug("�Ҧ��v�[�`������: "+lLCM);

					long sumNum = getTotOwnNumerator(ownList, lLCM);

					rtnMap.put("TOT_HLD_D", lLCM);
					rtnMap.put("TOT_HLD_N", sumNum);
					//�p��Ҧ��v���n
					//�p��g�a�v�����n (���褽��) =  �g�a���n(areaSize) * �Ҧ��v���l (sumNum)/ �Ҧ��v���� (LCM)
					BigDecimal bdLandArea = areaSize;
					bdLandArea = bdLandArea.multiply(new BigDecimal(sumNum));
					bdLandArea = bdLandArea.divide( new BigDecimal(lLCM), AREA_SIZE_SCALE, RoundingMode.HALF_UP);					
					rtnMap.put("LND_AREA_M2", bdLandArea);
					rtnMap.put("ADJ_AREA_M2", bdLandArea);
					//�p��ت��v�����n (���褽��) = �p��g�a�v�����n (���褽��) * 0.3025

					//�g�a�v���W��
					BigDecimal bdLandPingSize = bdLandArea.multiply(M2_TO_PING).setScale(AREA_PING_SCALE, RoundingMode.HALF_UP);					
					rtnMap.put("LND_AREA", bdLandPingSize);
					rtnMap.put("ADJ_AREA", bdLandPingSize);
					
					List<EDOCExport.EDOCData.LandREG.BTCLOR>  listBTCLOR  = landReg.getBTCLOR();
					if(listBTCLOR!=null && listBTCLOR.size()>0) {
						rtnMap.put("BTCLOR", "Y"); 
					} else {
						rtnMap.put("BTCLOR", "N");
					}
					
				    //�]�w�g�a�å����
					resultMap.put("LAND_REG", rtnMap);
				}				
			}
			String ALT_PCS_MEMO = MapUtils.getString(dataMap, "ALT_PCS_MEMO");
			Map landMap = (Map) resultMap.get("LAND_REG");
			adjustAreaSize(ALT_PCS_MEMO, landMap);

			return resultMap;	
		} catch (ServiceException e1) {
			log.fatal(e1,e1);
			throw new ModuleException(e1);
		} catch (JAXBException e) {
			log.fatal(e);
			throw new ModuleException(e);
		} catch (RemoteException e) {
			log.fatal(e);
			throw new ModuleException(e);
		}

	}

	//�v�����n���`�B�z �v�����n�������
	private void adjustAreaSize(String ALT_PCS_MEMO, Map areaMap) {

		if(StringUtils.isNotEmpty(ALT_PCS_MEMO)) {
			//�v�����n�W��
			BigDecimal area = (BigDecimal) areaMap.get("ADJ_AREA");
			//�v�����n���褽��
			BigDecimal areaM2 = (BigDecimal) areaMap.get("ADJ_AREA_M2");
			
			try {
				//{"CAL_TP"="S","CAL_N_LIST"="[613052,25000]","CAL_D"=724200}
                //{"CAL_TP"="M","CAL_N"="613052","CAL_D"=724200}
				Map pcsInfo = VOTool.jsonToMap(ALT_PCS_MEMO);
				String calType = MapUtils.getString(pcsInfo, "CAL_TP");
				if("M".equals(calType)) {
					//CAL_D					����
					String strCalD = MapUtils.getString(pcsInfo, "CAL_D");
					//CAL_N					���l
					String strCalN = MapUtils.getString(pcsInfo, "CAL_N");
					
					if(StringUtils.isNotEmpty(strCalD) && StringUtils.isNotEmpty(strCalN)) {
						BigDecimal calD = new BigDecimal(strCalD);
						BigDecimal calN = new BigDecimal(strCalN);	
						areaM2 =areaM2.multiply(calN).divide(calD, AREA_SIZE_SCALE, RoundingMode.HALF_UP);
						
						area = areaM2.multiply(M2_TO_PING).setScale(AREA_PING_SCALE, RoundingMode.HALF_UP);
						//�v�����n�W��
						areaMap.put("ADJ_AREA", area);
						//�v�����n���褽��
						areaMap.put("ADJ_AREA_M2", areaM2);
					}
					
				} else if("S".equals(calType)) {
					//����
					//CAL_D					����
					String strCalD = MapUtils.getString(pcsInfo, "CAL_D");
					//CAL_N_LIST			���l
					String strCalNList = MapUtils.getString(pcsInfo, "CAL_N_LIST");
					strCalNList = StringUtils.replace(strCalNList, "[", "");
					strCalNList = StringUtils.replace(strCalNList, "]", "");
					BigDecimal adjArea = area;
					BigDecimal adjAreaM2 = areaM2;
					if(StringUtils.isNotEmpty(strCalD) && StringUtils.isNotEmpty(strCalNList)) {
						BigDecimal calD = new BigDecimal(strCalD);
						String[] calNList = StringUtils.split(strCalNList, ",");
						for(String strCalN: calNList) {
							BigDecimal calN = new BigDecimal(strCalN);	
							BigDecimal altAreaM2 = areaM2.multiply(calN).divide(calD, AREA_SIZE_SCALE, RoundingMode.HALF_UP);
							
							BigDecimal altArea = altAreaM2.multiply(M2_TO_PING).setScale(AREA_PING_SCALE, RoundingMode.HALF_UP);
							adjAreaM2 = adjAreaM2.subtract(altAreaM2);
							adjArea = adjArea.subtract(altArea);
						}
						//�v�����n�W��
						areaMap.put("ADJ_AREA", adjArea);
						//�v�����n���褽��
						areaMap.put("ADJ_AREA_M2", adjAreaM2);						
					}
				}
			} catch (Exception e) {
				log.fatal("�v�����n�ҥ~�B�z���~",e);
			}

		}
	}

	private BigDecimal getAreaSize(float area) {
		BigDecimal areaSize = new BigDecimal(area).setScale(AREA_SIZE_SCALE, RoundingMode.HALF_UP);
		return areaSize;
	}

	private long getTotOwnNumerator(List<Map> ownList, long lLCM) {
		long sumNum = 0;
		for(Map ownData: ownList) {
			int RGTHLD_D = MapUtils.getInteger(ownData, "RGTHLD_D");
			int RGTHLD_N = MapUtils.getInteger(ownData, "RGTHLD_N");
			sumNum += ((lLCM / RGTHLD_D) * RGTHLD_N );
		}
		log.debug("�Ҧ��v�[�`�����l: "+ sumNum);
		return sumNum;
	}

	//���o�g�a�Ҧ��v���
	private Map getLandOwnData(int ownSeq,
			EDOCExport.EDOCData.LandREG.BTBLOW own) {
		Map landOwn = new HashMap();
		landOwn.put("OWN_SEQ", ownSeq);
		landOwn.put("OWN_ID", own.getOwner().getID());
		landOwn.put("OWN_NM", own.getOwner().getValue());
		landOwn.put("RGTHLD_D", own.getRightsRange().getDenominator());
		landOwn.put("RGTHLD_N", own.getRightsRange().getNumerator());
		landOwn.put("REG_DATE", own.getRegisterReason().getDate() );
		landOwn.put("RH_DATE", own.getRegisterReason().getHDate());
		landOwn.put("RSN_CD", own.getRegisterReason().getID());
		landOwn.put("RSN_DES", own.getRegisterReason().getValue());
		List<EDOCExport.EDOCData.LandREG.BTBLOW.OtherRegister> othRegList = own.getOtherRegister();
		if(othRegList!=null && othRegList.size()>0) {
			landOwn.put("OTH_REG", "Y");
		} else {
			landOwn.put("OTH_REG", "N");
		}
		return landOwn;
	}		

	//���o�ت��Ҧ��v���
	private Map getBuildOwnData(int ownSeq,
			EDOCExport.EDOCData.BuildREG.BTEBOW own) {
		Map landOwn = new HashMap();
		landOwn.put("OWN_SEQ", ownSeq);
		landOwn.put("OWN_ID", own.getOwner().getID());
		landOwn.put("OWN_NM", own.getOwner().getValue());
		landOwn.put("RGTHLD_D", own.getRightsRange().getDenominator());
		landOwn.put("RGTHLD_N", own.getRightsRange().getNumerator());
		landOwn.put("REG_DATE", own.getRegisterReason().getDate() );
		landOwn.put("RH_DATE", own.getRegisterReason().getHDate());
		landOwn.put("RSN_CD", own.getRegisterReason().getID());
		landOwn.put("RSN_DES", own.getRegisterReason().getValue());
		List<EDOCExport.EDOCData.BuildREG.BTEBOW.OtherRegister> othRegList = own.getOtherRegister();
		if(othRegList!=null && othRegList.size()>0) {
			landOwn.put("OTH_REG", "Y");
		} else {
			landOwn.put("OTH_REG", "N");
		}
		return landOwn;
	}		

	
	/*
	 * @param rtnMap
	 * @return
	 */
	private String getAplyXML(Map rtnMap) {
		//�q�l�å��վ\�]�w�� 
		Map srvConfigs = FieldOptionList.getFieldOptions("EP", "DPLandService");
		String maxPage = MapUtils.getString(srvConfigs, "MAX_PAGE"); //�վ\���ƭ���
		String entID = MapUtils.getString(srvConfigs, "ENTERPRISE_ID"); //�ӽХ��~ID
		String entNm = MapUtils.getString(srvConfigs, "ENTERPRISE_NM"); //�ӽХ��~�W��
		String aplyDiv = MapUtils.getString(srvConfigs, "APLY_DIV"); //�ӽг��
		String aplyDivNm = MapUtils.getString(srvConfigs, "APLY_DIV_NM"); //�ӽг��W��
		String APPLY_TYPE = MapUtils.getString(srvConfigs, "APLY_TYPE", "0"); //�ӽеn�O�å�������, "0"�ӤH����; "1"����; "2"�Хܳ�; "3"�Ҧ��v��; "4"�L���v�Q��; "5"�L���v�Q�����ӤH; "6"�Хܳ��ΩҦ��v��; "7"�Хܳ��ΥL���v�Q��
		String APLY_MODE = MapUtils.getString(srvConfigs, "APLY_MODE", "0"); //�ӽмҦ�, �ǤJ0���ܤ@��ӽ�; �ǤJ1���ܥߧY�ӽ�(�j���ӽ�)
		
		String bioID = getBIOID(rtnMap);
		String oID =   MapUtils.getString(rtnMap,"EP_SEQ","X");
		String cityID = MapUtils.getString(rtnMap,"CITY_ID");  //�����N�X
		String areaID = MapUtils.getString(rtnMap,"AREA_ID");  //�m�����ϥN�X  
		String lnID = MapUtils.getString(rtnMap,"LN_ID");  //�a�ҥN�X
		String aplyUserID = MapUtils.getString(rtnMap,"APLY_ID");  //�ӽФH��
		String aplyUserName = MapUtils.getString(rtnMap,"APLY_NM");  //�ӽФH���m�W
		
		String ownerID = MapUtils.getString(rtnMap,"OWN_ID"); //�Ҧ��v�H�Τ@�s��
		String sessionID = MapUtils.getString(rtnMap,"SESSION_ID"); //�q�p�q�N�X   �C�~�q
		String EP_KIND = MapUtils.getString(rtnMap,"EP_KIND");  //�å�����
		String IRC_NO = "";  //�a��
		String IRF_NO = "";  //�ظ�
		if("C".equals(EP_KIND)) {
			IRC_NO = MapUtils.getString(rtnMap,"IR49_NO");  //�a��	
		} else if("F".equals(EP_KIND)) {
			IRF_NO = MapUtils.getString(rtnMap,"IR49_NO");  //�ظ�
		} else {
			throw new IllegalArgumentException("�å��������~�ݬ�(C/F)");
		}
  
		StringBuilder  sbxml= new StringBuilder();
		 sbxml.append("<?xml version=\"1.0\" encoding=\"Big5\"?>  ");
		 sbxml.append("\n<EDOCAPPLY version=\"1.0\">");
		 sbxml.append("\n  <REQUEST>");
		 sbxml.append("\n    <ApplyInfo>");
		 sbxml.append("\n       <ApplyMode>").append(APLY_MODE).append("</ApplyMode>"); //�ӽмҦ�, �ǤJ0���ܤ@��ӽ�; �ǤJ1���ܥߧY�ӽ�(�j���ӽ�)
		 sbxml.append("\n       <MaxPage>").append(maxPage).append("</MaxPage>");
		 sbxml.append("\n       <BIOID>").append(bioID).append("</BIOID>");  //�t�ξ�X���s��1
		 sbxml.append("\n       <OID>").append(oID).append("</OID>");  //�t�ξ�X���s��2
		 sbxml.append("\n       <User ID=\"").append(aplyUserID).append("\">").append(aplyUserName).append("</User>");
		 sbxml.append("\n       <Unit ID=\"").append(aplyDiv).append("\">").append(aplyDivNm).append("</Unit>");
		 sbxml.append("\n       <Enterprise ID=\"").append(entID).append("\">").append(entNm).append("</Enterprise>");
//		 sbxml.append("\n       <Account ID=\"batch_cathay\" PWD=\"BE9056619AE43B\" ACCTYPE=\"2\">����H�ش��ձb��</Account>");
//		 sbxml.append("\n       <AAA_CODE></AAA_CODE>");
//		 sbxml.append("\n       <Charge>");
//		 sbxml.append("\n          <TYPE></TYPE>");
//		 sbxml.append("\n          <User ID=\"A123739658\">������</User>");
//		 sbxml.append("\n          <Unit ID=\"90034\">��ڸ�T��</Unit>");
//		 sbxml.append("\n       </Charge>");
//		 sbxml.append("\n       <ApplyUserType>5</ApplyUserType>");
//		 sbxml.append("\n       <CERT_ID></CERT_ID>");
//		 sbxml.append("\n       <CERT_NAME></CERT_NAME>");
		 sbxml.append("\n    </ApplyInfo>");
		 sbxml.append("\n    <DATA NO=\"1\">");  //�å��ӽи��
		 sbxml.append("\n      <CITYID>").append(cityID).append("</CITYID>");  //�����N�X        �O�n��
		 sbxml.append("\n      <AREAID>").append(areaID).append("</AREAID>");  //�m�����ϥN�X     �����
		 sbxml.append("\n      <LN>").append(lnID).append("</LN>");      //�a�ҥN�X  // �x�n   
		 sbxml.append("\n      <IR48>").append(sessionID).append("</IR48>");      //�q�p�q�N�X   �C�~�q
		 sbxml.append("\n      <IRC>").append(IRC_NO).append("</IRC>");      //�a��
		 sbxml.append("\n      <IRF>").append(IRF_NO).append("</IRF>");    //�ظ�  
		 sbxml.append("\n      <LIDN>").append(ownerID).append("</LIDN>");  //�Ҧ��v�H�Τ@�s�� 
		 sbxml.append("\n      <REG CHECK=\"Y\">");    //�ӽеn�O�å��_, �ǤJ"Y"���ܥӽ�;�ǤJ"N"���ܤ��ӽ�    
		 sbxml.append("\n        <PRINT_HD>N</PRINT_HD>");   //�O�_�C�L�a�W�ت��ظ�  
		 sbxml.append("\n        <PRINT_OD>N</PRINT_OD>");   //�O�_�C�L�D�ت�����
		 sbxml.append("\n        <TYPE>").append(APPLY_TYPE).append("</TYPE>");  //�ӽеn�O�å�������, "0"�ӤH����; "1"����; "2"�Хܳ�; "3"�Ҧ��v��; "4"�L���v�Q��; "5"�L���v�Q�����ӤH; "6"�Хܳ��ΩҦ��v��; "7"�Хܳ��ΥL���v�Q��  
		 sbxml.append("\n      </REG>");
		 sbxml.append("\n      <PRC CHECK=\"N\">");
		 sbxml.append("\n        <BRSURVEY>N</BRSURVEY>");
		 sbxml.append("\n        <AA16 TYPE=\"1\" CHECK=\"N\"> ");  //�����ӽЮ�, ��������@�� "0",���ܤ��C�L���i�{��; "1",���ܦC�L�������i�{��; "2",���ܦC�L���~���i�{��; "3",���ܦC�L�����P���~���i�{��;
		 sbxml.append("\n            <START_YEAR></START_YEAR>      ");  //�H3�X����~������		 TYPE: 2,3�ɥ�����J
		 sbxml.append("\n            <END_YEAR></END_YEAR>          ");  //�H3�X����~������		 TYPE: 2,3�ɥ�����J
		 sbxml.append("\n        </AA16>                          ");
		 sbxml.append("\n        <BB21 CHECK=\"N\" TYPE=\"1\">");
		 sbxml.append("\n          <START_YEAR></START_YEAR>");
		 sbxml.append("\n          <END_YEAR></END_YEAR>");
		 sbxml.append("\n        </BB21>");
		 sbxml.append("\n        <SRPRCE></SRPRCE>");
		 sbxml.append("\n        <PRC_TYPE>0</PRC_TYPE>"); //�����ӽЮ�, ��������@��	"0"�ӤH; "1"����
		 sbxml.append("\n        <PRC_SAME>Y</PRC_SAME>");
		 sbxml.append("\n      </PRC>");
		 
		 sbxml.append("\n      <EMAP CHECK = \"N\">");
		 sbxml.append("\n        <TYPE></TYPE>");  //�����ӽЮ�, ��������@��"1"���ܦa�y�Ϥ����I�y��;	"2"���ܦa�y�ϨC�@�Ӧa���y��; "3"���ܦa�}
		 sbxml.append("\n        <ADDR></ADDR>");
		 sbxml.append("\n      </EMAP>");
		 sbxml.append("\n      <PIC1 CHECK=\"N\">");
		 sbxml.append("\n        <P1>N</P1>");
		 sbxml.append("\n        <P2>-1</P2>");
		 sbxml.append("\n        <PIC1_SAME>Y</PIC1_SAME>");
		 sbxml.append("\n      </PIC1>");
		 sbxml.append("\n      <PIC2 CHECK=\"N\">");
		 sbxml.append("\n        <PIC2_SAME>Y</PIC2_SAME>");
		 sbxml.append("\n      </PIC2>");
		 sbxml.append("\n      <IDX CHECK=\"N\">");
		 sbxml.append("\n        <IS03></IS03>");
		 sbxml.append("\n        <IS04_1></IS04_1>");
		 sbxml.append("\n        <IS04_2></IS04_2>");
		 sbxml.append("\n        <IS00>A</IS00>");
		 sbxml.append("\n        <IS01></IS01>");
		 sbxml.append("\n        <ISTYPE></ISTYPE>");
		 sbxml.append("\n        <IDX_SAME>Y</IDX_SAME>");
		 sbxml.append("\n      </IDX>");		 
		 sbxml.append("\n      <IDR CHECK=\"N\">");
		 sbxml.append("\n        <IS03></IS03>");
		 sbxml.append("\n        <IS04_1></IS04_1>");
		 sbxml.append("\n        <IS04_1C></IS04_1C>");
		 sbxml.append("\n        <IS04_2></IS04_2>");
		 sbxml.append("\n        <IDR_SAME>Y</IDR_SAME>");
		 sbxml.append("\n      </IDR>");
		 sbxml.append("\n      <REF CHECK=\"N\">");
		 sbxml.append("\n        <REF_SAME>Y</REF_SAME>");
		 sbxml.append("\n      </REF>");
		 sbxml.append("\n      <SAVE_P00>N</SAVE_P00>");

		 sbxml.append("\n    </DATA>");
		 sbxml.append("\n  </REQUEST>");
		 sbxml.append("\n</EDOCAPPLY>");
	
		return sbxml.toString();
	}

	/**
	 * ���o�q�l�å��e��s��
	 * @param rtnMap �վ\�ץ�
	 * EP_APLY_NO �վ\�s��
	 * BASE_CD ��a�N��
	 * @return �q�l�å��e��s��
	 */
	private String getBIOID(Map rtnMap) {
		String bioID = getBIOID(MapUtils.getString(rtnMap,"EP_APLY_NO") , MapUtils.getString(rtnMap,"BASE_CD"));
		return bioID;
	}
	

	//�r��B�z
	StringBuilder sb = new StringBuilder();
	/**
	 * ���o�q�l�å��e��s��
	 * @param aplyNO �վ\�s��
	 * @param baseCD ��a�N��
	 * @return �q�l�å��e��s��
	 */
	public String getBIOID(String aplyNO, String baseCD) {
		sb.append(aplyNO).append("_").append(baseCD);
		String bioID = sb.toString();
		sb.setLength(0);
		return bioID;
	}
	
	/**
	 * ���o�̤p������  Least Common Multiple
	 * @param a �ƭ�1
	 * @param b �ƭ�2
	 * @return �o�̤p������
	 */
	public long calLCM(long a, long b){
	    return a * (b / calGCD(a, b));
	}

	/**
	 * ���o�̤j���]��  Greatest Common Divisor
	 * @param a �ƭ�1
	 * @param b �ƭ�2
	 * @return �̤j���]��
	 */
	public long calGCD(long a, long b){
//		log.debug("GCD("+a+","+b+"):");
	    while (b > 0) {
	        long temp = b;
	        b = a % b; // % is remainder
	        a = temp;
	    }
//	    log.debug("==>"+ a);
	    return a;
	}
	
	private void closeAxisLogLevel(){
		Logger.getLogger("org.apache.axis").setLevel(Level.ERROR);
		Logger.getLogger("org.apache.axis.ConfigurationException").setLevel(Level.ERROR);
		Logger.getLogger("org.apache.axis.transport.HTTPSender").setLevel(Level.ERROR);
		Logger.getLogger("org.apache.common.beanutils.converters.AbstractConverter").setLevel(Level.ERROR);
		Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.ERROR);
		Logger.getLogger("httpclient.wire.header").setLevel(Level.ERROR);
		Logger.getLogger("httpclient.wire.content").setLevel(Level.ERROR);
		Logger.getLogger("httpclient.wire.content").setLevel(Level.ERROR);
	}

}

