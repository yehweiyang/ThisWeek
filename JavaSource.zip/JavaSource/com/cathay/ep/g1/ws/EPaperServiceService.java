/**
 * EPaperServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 * 2019/10/21 AllenTsai �z�Ljava org.apache.axis.wsdl.WSDL2Java -o src -p com.cathay.ep.g1.ws ...\dpland.wsdl
 */

package com.cathay.ep.g1.ws;

import java.net.URL;

import javax.xml.rpc.ServiceException;

public interface EPaperServiceService extends javax.xml.rpc.Service {
    public java.lang.String getEPaperServiceAddress();

    public EPaperService_PortType getEPaperService() throws ServiceException;

    public EPaperService_PortType getEPaperService(URL portAddress) throws ServiceException;
}
