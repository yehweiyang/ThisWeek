/**
 * EPaperServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 * 2019/10/21 AllenTsai �z�Ljava org.apache.axis.wsdl.WSDL2Java -o src -p com.cathay.ep.g1.ws d:\dpland\dpland.wsdl
 */

package com.cathay.ep.g1.ws;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.Remote;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;

import org.apache.axis.AxisFault;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.client.Service;
import org.apache.axis.client.Stub;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.Log;


public class EPaperServiceServiceLocator extends Service implements
		EPaperServiceService {
	
	private static final Logger log = Logger.getLogger(EPaperServiceServiceLocator.class);

	//OLD EPAPER_SERVICE
	private static final String EPAPER_SERVICE_URL = "http://10.195.45.100/EPaper/services/EPaperService";
	//NEW EPAPER_SERVICE
//	private static final String EPAPER_SERVICE_URL = "http://10.95.42.175/EPaper/service/EPaperService";
	/**
	 * 
	 */
	private static final long serialVersionUID = -5130726758225472526L;

	public EPaperServiceServiceLocator() {
	}

	public EPaperServiceServiceLocator(EngineConfiguration config) {
		super(config);
	}

	public EPaperServiceServiceLocator(String wsdlLoc, QName sName)
			throws ServiceException {
		super(wsdlLoc, sName);
	}

	// Use to get a proxy class for EPaperService
	private String EPaperService_address = getEPaperServiceURL();

	public String getEPaperServiceAddress() {
		return EPaperService_address;
	}

	/**
	 * ���oDPLand EPaper WebService Service URL 
	 * �N�X EP.DPLandService KEY:EPAPER_SERVICE_URL
	 * @return EPAPER_SERVICE_URL
	 */
	private String getEPaperServiceURL() {
		String serviceURL = FieldOptionList.getName("EP", "DPLandService","EPAPER_SERVICE_URL");
		log.debug("�q�l�å��A�ȺݤfserviceURL: "+serviceURL);
		if(StringUtils.isEmpty(serviceURL)) {
			throw new RuntimeException("�q�l�å��A�Ⱥݤf�|���]�w[DPLandService.EPAPER_SERVICE_URL]");
		}
		return serviceURL;
//		return EPAPER_SERVICE_URL;
	}

	// The WSDD service name defaults to the port name.
	private String EPaperServiceWSDDServiceName = "EPaperService";

	public String getEPaperServiceWSDDServiceName() {
		return EPaperServiceWSDDServiceName;
	}

	public void setEPaperServiceWSDDServiceName(String name) {
		EPaperServiceWSDDServiceName = name;
	}

	public EPaperService_PortType getEPaperService()
			throws ServiceException {
		URL endpoint;
		try {
			endpoint = new URL(EPaperService_address);
		} catch (MalformedURLException e) {
			throw new ServiceException(e);
		}
		return getEPaperService(endpoint);
	}

	public EPaperService_PortType getEPaperService(
			URL portAddress) throws ServiceException {
		try {
			EPaperServiceSoapBindingStub _stub = new EPaperServiceSoapBindingStub(
					portAddress, this);
			_stub.setPortName(getEPaperServiceWSDDServiceName());
			return _stub;
		} catch (AxisFault e) {
			return null;
		}
	}

	public void setEPaperServiceEndpointAddress(String address) {
		EPaperService_address = address;
	}

	/**
	 * For the given interface, get the stub implementation. If this service has
	 * no port for the given interface, then ServiceException is thrown.
	 */
	public Remote getPort(Class serviceEndpointInterface)
			throws ServiceException {
		try {
			if (EPaperService_PortType.class
					.isAssignableFrom(serviceEndpointInterface)) {
				EPaperServiceSoapBindingStub _stub = new EPaperServiceSoapBindingStub(
						new URL(EPaperService_address), this);
				_stub.setPortName(getEPaperServiceWSDDServiceName());
				return _stub;
			}
		} catch (Throwable t) {
			throw new ServiceException(t);
		}
		throw new ServiceException(
				"There is no stub implementation for the interface:  "
						+ (serviceEndpointInterface == null ? "null"
								: serviceEndpointInterface.getName()));
	}

	/**
	 * For the given interface, get the stub implementation. If this service has
	 * no port for the given interface, then ServiceException is thrown.
	 */
	public Remote getPort(QName portName,
			Class serviceEndpointInterface) throws ServiceException {
		if (portName == null) {
			return getPort(serviceEndpointInterface);
		}
		String inputPortName = portName.getLocalPart();
		if ("EPaperService".equals(inputPortName)) {
			return getEPaperService();
		} else {
			Remote _stub = getPort(serviceEndpointInterface);
			((Stub) _stub).setPortName(portName);
			return _stub;
		}
	}

	public QName getServiceName() {
		return new QName(EPAPER_SERVICE_URL,
				"EPaperServiceService");
	}

	private java.util.HashSet ports = null;

	public java.util.Iterator getPorts() {
		if (ports == null) {
			ports = new java.util.HashSet();
			ports.add(new QName(
					EPAPER_SERVICE_URL,
					"EPaperService"));
		}
		return ports.iterator();
	}

	/**
	 * Set the endpoint address for the specified port name.
	 */
	public void setEndpointAddress(String portName, String address)
			throws ServiceException {

		if ("EPaperService".equals(portName)) {
			setEPaperServiceEndpointAddress(address);
		} else { // Unknown Port Name
			throw new ServiceException(
					" Cannot set Endpoint Address for Unknown Port" + portName);
		}
	}

	/**
	 * Set the endpoint address for the specified port name.
	 */
	public void setEndpointAddress(QName portName, String address)
			throws ServiceException {
		setEndpointAddress(portName.getLocalPart(), address);
	}

}
