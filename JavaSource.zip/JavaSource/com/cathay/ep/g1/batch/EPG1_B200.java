package com.cathay.ep.g1.batch;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorLogException;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z0.module.EP_Z0A110;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.rz.s0.module.RZ_S00300;
import com.cathay.util.FileStoreUtil;
import com.igsapp.db.BatchQueryDataSet;

/**
 * <pre>
 * ���ʤ�� ����  ���ʻ���    ���ʤH��    �߮׳渹
 * 2020/01/20  1   Created ������ 190704000597
 * �@�B   �{���\�෧�n�����G
 * �{���\��    �g�a�겣��ƦP�B�B�z
 * �{���W��    EPG1_B200.java
 * �@�~�覡    BATCH
 * ���n����    �妸�G�C��g�a�겣�P�B���ɻP�H�e�ݩw��q�����t�d�g��
 * �@�~���x    ���@��  �����O�q��  �����
 * �ϥι�H    �����u(UCBean)  ���Ȥ�(CustomerBean)
 * �Ӹ�B���覡  �e��  ���L ���B�� ��securitylog �ݾB��/
 * �g�JLOG
 * ����ƦW��   
 *     �����C�L    ���L ���B�� ��securitylog     
 *     �ɮפU��    ���L ���B�� ��securitylog     
 * �w����ƶq   1000
 * �@�~�W��    JAEPDA002
 * �~�ȧO EP
 * ���t�ΦW��   G1
 * �B�z�g��    �u�@��
 * ����B�z���  50��A����I�s API �P�_�w�쵲�G
 * �ݨD���    ���ʲ���곡���ʲ�����
 * �@�~���    ����T����ڸ�T��
 * �H�H�B�z    �H�H��H    ���L ���Ȥ�@�����I���u�@�����Y���~���u�@���X�@�t��
 *     �H�H�覡    ���L ��Billhunter�@��MailSender
 * </pre>
 * @author ���ި|
 * @since 2020/02/12
 * 2020/02/14 AllenTsai �վ�겣�s�����o�覡�P�I�sAPI���{���X�P��ƱƧǡB���a�ʻP�g�a����
 * 2020/02/18 AllenTsai �վ��X�W�[�ק�ɶ��B�H���P�m�W
 * 2020/02/24 AllenTsai �վ�w���u�j�Ӽе����R���A�B�z�g�a�M������d�߸�ƭ��ƿ�X���D
 **/
@SuppressWarnings({ "rawtypes", "unchecked" })
public class EPG1_B200 extends EP_BatchBean {

    /** logger */
    private static final Logger log = Logger.getLogger(EPG1_B200.class);

    /** �@�~�W�� */
    private static final String JOB_NAME = "JAEPDA002";

    /** �{���W�� */
    private static final String PROGRAM = "EPG1_B200";

    /** �B�z�g�� */
    private static final String PERIOD = "�u�@��";

    private static final String INPUT_COUNT = "�g�a�겣�ݳB�z����";

    private static final String OUTPUT_COUNT = "���դj�ӪŶ���Ƨ�s����";

    private static final String NOTIFY_ERR_COUNT = "�q����H�]�w���~����";

    private static final String SEND_ERR_COUNT = "�H�e�q�����~����";


    /** �q������������]�w*/
    private String[] FIELD = { "CITY_NM", "AREA_NM", "INV_CD", "SLF_CD", "BASE_BLD_NAME", "BLD_ADDR", "MEMO" };

    /** �q������������]�w*/
    private String[] FIELD_NM = { "����", "�ϰ�", "���N��", "�ۥΥN��", "�j�ӦW��", "�j�Ӧa�}", "�a�ϩw�컡��" };

    /** �q������������]�w*/
    private String[] FIELD_SIZE = { "5", "5", "5", "5", "15", "30", "10" };

    StringBuilder sb = new StringBuilder();

	private static final String SQL_QUERY_001 = "com.cathay.ep.g1.batch.EPG1_B200.SQL_QUERY_001";

    public void execute(String[] args) throws Exception {

        final BatchConstructor bc = new BatchConstructor(JOB_NAME, PROGRAM, PERIOD);

        try {
            bc.createCountType(INPUT_COUNT);
            bc.createCountType(OUTPUT_COUNT);
            bc.createCountType(NOTIFY_ERR_COUNT);
            bc.createCountType(SEND_ERR_COUNT);

            bc.execute(new BatchConstructor.DataBaseHandler() {

                

                List<Map> baseList = new ArrayList();//�g�a�겣�M��

                List<Map> dataList = new ArrayList();//�q�����������

                List<Map> recList = new ArrayList();//�q����H�M��  

                //���� �n�R�����겣�M��
                Map<String, Map> deleteLandMap = new TreeMap<String, Map>();
              //���� �w�g�B�z�L���겣�M��A�קK�겣�����d�ߥX�ӡA�R���겣�M��P�_���~
                Set<String> assetSet = new TreeSet<String>();

                String SUB_CPY_ID = "00"; //�����q�O

                String EVENT_ID = "EP_RA015";//�ƥ�N��

                String delimiter = null;

                BufferedWriter bwBuild = null;

                String newline = System.getProperty("line.separator");

                @Override
                protected boolean firstProcess() throws Exception {
                    //���o�q�l�a�Ϥg�a�겣�ɮ׳]�w
                    Map<String, String> mapLandMap = FieldOptionList.getName("EP", "EMAP_INV_LAND");

                    //�]�w�q����H�M��  
                    this.getRecList();

                    //���o��X�ɮ׸�T
                    bwBuild = EncodingHelper.getBufferedWriter(
                        sb.append(FileStoreUtil.getFTPH2URoot()).append(File.separator).append("DBEP").append(File.separator)
                                .append(MapUtils.getString(mapLandMap, "FILE_NAME")).toString(),
                        MapUtils.getString(mapLandMap, "FILE_ENCODING"));
                    delimiter = MapUtils.getString(mapLandMap, "DELIMITER");

                    //��X���D��
                    String HEAD_ROW_1 = MapUtils.getString(mapLandMap, "HEAD_ROW_1");
                    String HEAD_ROW_2 = MapUtils.getString(mapLandMap, "HEAD_ROW_2");
                    
                    sb.setLength(0);
                    String strHeadRow = sb.append(HEAD_ROW_1).append(delimiter).append(HEAD_ROW_2).toString();
                    log.debug("HeadRow:"+ strHeadRow);

                    bwBuild.write(strHeadRow);
                    bwBuild.write(newline);

                    return true;
                }

                @Override
                protected boolean searchProcess(BatchQueryDataSet bqds) throws Exception {
                    bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    bqds.searchAndRetrieve(SQL_QUERY_001);
                    int totalCount = bqds.getTotalCount();
                    if (totalCount == 0) {
                        log.fatal("�d�L�ݳB�z�����");
                        return false;
                    }
                    bc.addCountNumber(INPUT_COUNT, totalCount);
                    return true;
                }

                List<String> keysSetNULLintoEmpty = Arrays.asList(new String[] { "INV_CD", "SLF_CD", "BASE_BLD_NAME" });

                @Override
                protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {
                    //���o�óB�z�g�a�겣���
                    baseList.add(this.processDataMap(bqds));
                }

                @Override
                protected void executeBatchProcess() throws Exception {
                    //�v���B�z�g�a�겣�j�ӪŶ��w��ݳB�z���
                    try {
                        //�I�sAPI ���o�y�Щw�쵲�G
                    	Map<String, Map> rtnAPILandMap = this.callAPICathayLifeLand();

                        //�v���B�z �g�a�겣�M��
                        for (Map baseMap : baseList) {
                            sb.setLength(0);
                            //�եX�겣�s��
                            String strBaseCd = MapUtils.getString(baseMap, "BASE_CD");
                            String strTrsSeq = MapUtils.getString(baseMap, "TRS_SEQ"); 
                            String baseKey = sb.append(strBaseCd).append('_')
                                    .append(strTrsSeq).toString();

                            this.addEDIT_TYPEintoBaseMap(baseMap, baseKey, rtnAPILandMap);
                            //�w�B���겣 ����X�����
                            if ("pass".equals(MapUtils.getString(baseMap, "EDIT_TYPE"))) {
                                continue;
                            } else {
                                sb.setLength(0);
                                //2020/02/24 AllenTsai �վ�R�����겣�s���P�_����
                                String assetKey = sb.append(SUB_CPY_ID).append(strBaseCd).append(strTrsSeq).toString();
                                if(!"Delete".equals(MapUtils.getString(baseMap, "EDIT_TYPE"))) {
                                	//��Ƥ����d�ߡA�e�@���X�R�����ץ�A�᭱�@�妳�d�ߥX�ӡA�����R���겣�M��
                                	if(deleteLandMap.containsKey(assetKey)) {
                                    	deleteLandMap.remove(assetKey);                                		
                                	}
                                	//�����B�z�L���겣�M��
                                	assetSet.add(assetKey);
                                }                              	
                            }


                            //�N��ƿ�X�����
                            this.writeOneLine(baseMap);
                            bwBuild.write(newline);
                            bc.addCountNumber(OUTPUT_COUNT, 1);

                            //����API�ӵ��g�a��Ƹ��
                            rtnAPILandMap.remove(baseKey);
                        }

                        //�P�_API�^�ǫݧR���겣���ӡA�v���P�_ rtnAPILandMap �|���B�z���
                        for (String rtnAPILandMapKey : rtnAPILandMap.keySet()) {
                            String[] splitedKeys = rtnAPILandMapKey.split("_");
                            String baseCD = splitedKeys[0];
                            String trsSEQ = splitedKeys[1];
                            Map deleteMap = new HashMap();
                            deleteMap.put("SUB_CPY_ID", SUB_CPY_ID);
                            deleteMap.put("BASE_CD", baseCD);
                            deleteMap.put("TRS_SEQ", trsSEQ);
                            deleteMap.put("EDIT_TYPE", "Delete");
                            sb.setLength(0);
                            String deleteKey = sb.append(SUB_CPY_ID).append(baseCD).append(trsSEQ).toString();
                            if(!assetSet.contains(deleteKey)) {
                                if (!deleteLandMap.containsKey(deleteKey)) {
                                	deleteLandMap.put(deleteKey, deleteMap);
                                }
                            }
                        }
                        baseList.clear();
                    } catch (Exception e) {
                        log.fatal("�B�z�g�a�겣�j�ӪŶ��w��ݳB�z��Ƶo�Ϳ��~�G" + e.getMessage(), e);
                        throw e;
                    }
                }

                @Override
                protected void lastProcess() throws Exception {
                	
                    //�P�_API�^�ǫݧR���겣���ӡA�v���P�_ rtnAPILandMap �|���B�z���
                    for (String delKey : deleteLandMap.keySet()) {
                        Map deleteMap = deleteLandMap.get(delKey);
                        this.writeOneLine(deleteMap);
                        bwBuild.write(newline);
                    }
                	
                    //�̫�B�z�Ҧ��d�ߵ��G�ɡA�ˮ֬O�_�ݱH�e�q����
                    //�P�_ dataList ���� >0 �~�B�z
                    if (dataList.isEmpty()) {
                        return;
                    }
                    //���o�T���q�������q�O
                    String COMP_ID = new EP_B30010().getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);

                    //�B�zEMAIL����������]�w:
                    List titleList = new ArrayList();
                    for (int i = 0; i < FIELD.length; i++) {
                        Map titleMap = new HashMap();
                        titleMap.put("FIELD", FIELD[i]);
                        titleMap.put("FIELD_NM", FIELD_NM[i]);
                        titleMap.put("FIELD_SIZE", FIELD_SIZE[i]);
                        titleList.add(titleMap);
                    }
                    String ERR_MSG = new RZ_S00300().createRecordByDIV(EVENT_ID, "EP", DATE.today(), recList, titleList, dataList, COMP_ID);
                    if (StringUtils.isNotBlank(ERR_MSG)) {
                        log.fatal("�H�e�q�����~," + ERR_MSG);
                        bc.addErrorLog("�H�e�q�����~", ERR_MSG);
                        bc.writeErrorLog();
                        bc.addCountNumber(SEND_ERR_COUNT, 1);
                    }
                }

                @Override
                protected void finallyProcess() {
                    try {
                        if (bwBuild != null) {
                            bwBuild.close();
                        }
                    } catch (IOException e) {
                        log.fatal("�����ɮ׿��~", e);
                    }
                }

                /**
                 * �]�w�q����H�M��
                 * @param recList
                 * @param SUB_CPY_ID
                 * @param EVENT_ID
                 * @throws ModuleException
                 * @throws ErrorLogException
                 */
                private void getRecList() throws ModuleException, ErrorLogException {
                    try {
                        Map<String, List<DTEPZ103>> nMap = new EP_Z10030().getMailList(SUB_CPY_ID, EVENT_ID);
                        List<DTEPZ103> mailList = nMap.get(SUB_CPY_ID);
                        for (DTEPZ103 z103 : mailList) {
                            Map recepit = new HashMap();
                            recepit.put("EVENT_ID", EVENT_ID);
                            recepit.put("USER_ID", z103.getID());
                            recepit.put("USER_EMAIL", z103.getEMAIL());
                            recList.add(recepit);
                        }

                    } catch (DataNotFoundException dnfe) {
                        bc.addErrorLog("�q����H�]�w���~", "���o�g�a�겣�w��q����H");
                        bc.writeErrorLog();
                        bc.addCountNumber(NOTIFY_ERR_COUNT, 1);
                        throw dnfe;
                    }
                }

                /**
                 * �g�J�@��baseMap�� ����
                 * @param bwBuild
                 * @param baseMap
                 * @param dataUpdType
                 * @param delimiter
                 * @throws IOException
                 */
                private void writeOneLine(Map baseMap) throws IOException {
                    bwBuild.write(MapUtils.getString(baseMap, "SUB_CPY_ID", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "BASE_CD", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "TRS_SEQ", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "INV_CD", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "SLF_CD", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "BASE_BLD_NAME", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "BLD_ADDR", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "BASE_TYPE", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "CITY_NM", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "AREA_NM", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "SESSION_NM", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "LND_NO", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "BLD_NO", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "LND_HLD_STS", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "LND_AREA", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "BLD_AREA", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "LND_USE", ""));
                    bwBuild.write(delimiter);
                    //�ק�ɶ�	 modify_time	
                    bwBuild.write(MapUtils.getString(baseMap, "CHG_DATE", ""));
                    bwBuild.write(delimiter);
                    //�ק�H���m�W	 modify_user	
                    bwBuild.write(MapUtils.getString(baseMap, "CHG_NAME", ""));
                    bwBuild.write(delimiter);
                    //�ק�H��ID 	modify_userid
                    bwBuild.write(MapUtils.getString(baseMap, "CHG_ID", ""));
                    bwBuild.write(delimiter);
                    bwBuild.write(MapUtils.getString(baseMap, "EDIT_TYPE", ""));
//                    for (int i = 0; i < keySize; i++) {
//                        String key = fileKeys[i];
//                        bwBuild.write(MapUtils.getString(baseMap, key, ""));
//                        if (i != (keySize - 1)) {
//                            bwBuild.write(delimiter);
//                        }
//                    }
                }

                /**
                 * ���o�óB�z�g�a���
                 * @param bqds
                 * @return dataMap
                 */
                private Map processDataMap(BatchQueryDataSet bqds) {
                    //���o�g�a�겣���
                    Map dataMap = VOTool.dataSetToMap(bqds);
                    //�B�z�å��Ǹ�
                    String BASE_TYPE = MapUtils.getString(dataMap, "BASE_TYPE");
                    if (!"1".equals(BASE_TYPE)) {
                        dataMap.put("TRS_SEQ", "00000");
                    }
                    //�B�z�j�Ӧa�}
                    String BLD_ADDR = MapUtils.getString(dataMap, "BLD_ADDR");
                    if (StringUtils.isBlank(BLD_ADDR)) {
                        if ("3".equals(BASE_TYPE)) {
                            dataMap.put("BLD_ADDR", MapUtils.getString(dataMap, "BASE_BLD_ADDR"));
                        } else {
                            dataMap.put("BLD_ADDR", MapUtils.getString(dataMap, "SESSION_NM") + MapUtils.getString(dataMap, "LND_NO"));
                        }
                    }
                    //�ŭȳB�z
                    for (String key : keysSetNULLintoEmpty) {
                        if (StringUtils.isBlank(MapUtils.getString(dataMap, key))) {
                            dataMap.put(key, "");
                        }
                    }
                    return dataMap;
                }

                /**
                 * callCathayLifeLandAPI
                 * @param bldList
                 * @return
                 * @throws Exception
                 */
                private Map<String, Map> callAPICathayLifeLand() throws Exception {
                	//�I�sAPI ���o�y�Щw�쵲�G
                	Map<String, Map> rtnAPILandMap = new HashMap<String, Map>();
                    Map reqMap = new HashMap();
                    List<Map<String, String>> assetList = new ArrayList<Map<String, String>>();
                    List<String> baseKeyList = new ArrayList<String>();
                    for (Map data : baseList) {
                        String subCpyID = MapUtils.getString(data, "SUB_CPY_ID");
                        String baseCD = MapUtils.getString(data, "BASE_CD");
                        String baseKey = (subCpyID + baseCD);
                        if (!baseKeyList.contains(baseKey)) {
                            Map<String, String> asset = new HashMap<String, String>();
                            asset.put("subCpyID", subCpyID);
                            asset.put("baseCD", baseCD);
                            assetList.add(asset);
                            baseKeyList.add(baseKey);
                        }
                    }
                    reqMap.put("assetsNo", assetList);

                    Map appInfo = new HashMap();
                    appInfo.put("appId", "EP");
                    appInfo.put("sourceCode", PROGRAM);
                    reqMap.put("appInfo", appInfo);
                    String jsonStr = VOTool.toJSON(reqMap);

                    log.debug("callAPICathayLifeLand JSON:" + jsonStr);


                    Object result = new EP_Z0A110().callAPI("MAP003", jsonStr, PROGRAM);
                    String strResult = result.toString();
                    log.debug("/api/CathayLifeLand ��ؤg�a��Ƭd��:\n" + strResult);
                    Map rtnMap = VOTool.jsonToMap(VOTool.toJSON(result));
                    String strSuccess = MapUtils.getString(rtnMap, "success");
                    log.debug("success: " + strSuccess);
                    Object detail = MapUtils.getObject(rtnMap, "result");
                    log.debug(detail.getClass());
                    if (strSuccess.equals("true")) {
                        List<Map> assList = (List<Map>) detail;
                        log.debug("�idetail�j:" + detail);
                        for (Map asset : assList) {
                            String baseCd = MapUtils.getString(asset, "baseCD");
                            List<Map> trsList = VOTool.jsonAryToMaps(MapUtils.getString(asset, "trsList"));
                            for (Map trs : trsList) {
                            	trs.put("BASE_CD", baseCd);
                                String trsSeq = MapUtils.getString(trs, "trsSeq");
                                String lv = MapUtils.getString(trs, "lv");
                                rtnAPILandMap.put(baseCd + "_" + trsSeq, trs);
                            }
                        }
                        log.debug("�iAPIResult�j:" + rtnAPILandMap);
                    }
                    return rtnAPILandMap;
                }

                /**
                 * �ھکw�쵥�ŧP�_�g�a��ƪ�EDIT_TYPE
                 * @param baseMap
                 */
                private void addEDIT_TYPEintoBaseMap(Map baseMap, String key, Map<String, Map> rtnAPILandMap) {
                    //�P�_�w�쵥��
                	Map rtnMap =  MapUtils.getMap(rtnAPILandMap, key);
                	if(rtnMap!=null) {
                		baseMap.putAll(rtnMap);	
                	}
                	
                    String locateLevel  = MapUtils.getString(rtnMap, "lv");
                    //�P�_��ƦP�B���� dataUpdType
                    String dataUpdType;
                    //�Y�겣�Φa���w�g�B���Τw���u�j��  
                    if ("4".equals(MapUtils.getString(baseMap, "BASE_TYPE")) 
                    		|| "3".equals(MapUtils.getString(baseMap, "BASE_TYPE"))
                    		|| "0".equals(MapUtils.getString(baseMap, "EP_STS")) ) {
                        if (StringUtils.isNotBlank(locateLevel)) {//�q�l�a�Ϧs�b�ӵ����
                            dataUpdType = "Delete";
                        } else {//�q�l�a�Ϥ��s�b�ӵ����
                            dataUpdType = "pass";
                        }
                    } else {//�겣�Φa���|���B��
                        if (StringUtils.isNotBlank(locateLevel)) {//�q�l�a�Ϧs�b�ӵ����
                            dataUpdType = "Update";
                            //�|���w��T�{ �H�e�q��
                            if (!"99".equals(locateLevel)) {
                                baseMap.put("MEMO", "�ݩw��");
                                dataList.add(baseMap);
                            }
                        } else {//�q�l�a�Ϥ��s�b�ӵ����
                            dataUpdType = "Insert";
                            baseMap.put("MEMO", "�ݦP�B�P�w��");
                            dataList.add(baseMap);
                        }
                    }
                    baseMap.put("EDIT_TYPE", dataUpdType);
                }
            });

        } catch (Exception e) {
            log.fatal("����妸�ɵo�Ϳ��~�G" + e.getMessage(), e);
            setExitCode(ERROR);
        } finally {
            int batchConstructorExitCode = bc.getExitCode();
            if (batchConstructorExitCode != OK) {
                setExitCode(batchConstructorExitCode);
            }
            printExitCode(batchConstructorExitCode);
        }
    }
}
