package com.cathay.ep.b1.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.b1.module.EP_B10100;
import com.cathay.ep.b1.module.EP_B1Z002;
import com.cathay.ep.b3.module.EPB3_0010_mod;
import com.cathay.ep.b3.module.EP_B30040;
import com.cathay.ep.c2.trx.EPC2_2040;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Version Description Author
 * 2013/10/15   1.0     Created ���կ�
 *
 * UCEPB1_0100_���u�k�պ�T�{
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ���u�k�պ�T�{
 * �{���W��    EPB1_0100
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 * (2) ���� �w �}�ҵ������ѨϥΪ̬d�߫�����ơA�I���a�^�A�����������C
 * (3) �d�� �w ���ѨϥΪ̬d�߫����Ȥ��ƥH�ѿ���C
 * (4) �ק� �V ���ѨϥΪ��I���i�պ�ק諾�u�k�պ��ơC
 * (5) �d�ߩ��� �w ���ѨϥΪ̬d�ߪ��u�k�պ�T�{���ơC
 * (6) �պ� �w ���ѨϥΪ̸պ⪽�u�k��ơC
 * (7) �^�Ȥ��� �w ���ѨϥΪ̦^��Ȥ��������C
 * (8) �T�{ �w ���ѨϥΪ̽T�{���u�k��ơC
 * (9) �^�϶��]�w �w ���ѨϥΪ̦^��K���կ��϶���ܭ����C
 * </pre>                                 
 * @author ����[
 * @since 2013-12-10
 */
@SuppressWarnings("unchecked")
public class EPB1_0100 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_2040.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        String IN_CRT_NO = req.getParameter("IN_CRT_NO");//�ǤJ�����N��
        String IN_CUS_NO = req.getParameter("IN_CUS_NO");//�ǤJ�Ȥ�Ǹ�
        String USER_CPY_ID = null;
        try {
            USER_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", USER_CPY_ID);
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPB1_0100_ERRMSG_001");//���o�����q�O����
        }

        resp.addOutputData("IN_CRT_NO", IN_CRT_NO);
        resp.addOutputData("IN_CUS_NO", IN_CUS_NO);
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            String IN_CRT_NO = req.getParameter("IN_CRT_NO");//�ǤJ�����N��
            String IN_CUS_NO = req.getParameter("IN_CUS_NO");//�ǤJ�Ȥ�Ǹ�
            String USER_CPY_ID = req.getParameter("USER_CPY_ID");

            query(USER_CPY_ID, IN_CRT_NO, IN_CUS_NO, new EP_B10100());

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            if (Boolean.valueOf(req.getParameter("isPrompt"))) {
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "MEP00001");//�d�L���
            } else {
                MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
            }
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0100_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �d�ߩ���
     * @param req
     * @return
     */
    public ResponseContext doQueryDetail(RequestContext req) {
        try {

            Map rtnBMap = VOTool.jsonToMap(req.getParameter("rtnBMap"));
            // 20161223 LogSecurity ���v        
            try{
                Map logOneSecurityMap = new HashMap();
                logOneSecurityMap.put("CUS_NAME", MapUtils.getString(rtnBMap, "CUS_NAME", "") );
                logSecurity(logOneSecurityMap);            	
            } catch(Exception e) {            	
            }            
            String USER_CPY_ID = req.getParameter("USER_CPY_ID");

            EP_B30040 theEP_B30040 = new EP_B30040();

            String CRT_NO = MapUtils.getString(rtnBMap, "CRT_NO");
            String CUS_NO = MapUtils.getString(rtnBMap, "CUS_NO");

            try {
                List<Map> rtnDList = theEP_B30040.getAdjRntList(USER_CPY_ID, CRT_NO, CUS_NO, null, null, null);
                resp.addOutputData("rtnDList", rtnDList);
            } catch (DataNotFoundException e) {
                if (STRING.objToBigDecimal(rtnBMap.get("RNT_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) != 0) {
                    throw new ModuleException(MessageUtil.getMessage("EPB1_0100_ERRMSG_002", new Object[] { CRT_NO, CUS_NO }));//�d�L������:{0} �A�Ȥ�Ǹ�:{1} ���կ��϶��A�Х��]�w�կ��϶���A�i��պ�
                }

            }

            try {
                List<Map> rtnEList = theEP_B30040.getNoRntList(USER_CPY_ID, CRT_NO, CUS_NO, null, null, null);
                resp.addOutputData("rtnEList", rtnEList);
            } catch (DataNotFoundException dnfe) {
                log.debug("rtnEList�d�L��Ƶ������`");
            }

            try {
                List<Map> rtnFList = new EP_B10100().getCfmList(USER_CPY_ID, CRT_NO, CUS_NO);
                resp.addOutputData("rtnFList", rtnFList);
            } catch (DataNotFoundException e) {
                throw new ModuleException(MessageUtil.getMessage("EPB1_0100_ERRMSG_003", new Object[] { CRT_NO, CUS_NO }));//�d�L������:{0} �A�Ȥ�Ǹ�:{1} �����u�k�պ�T�{���G�A�Х��i��պ�T�{
            }
            resp.addOutputData("rtnBMap", rtnBMap);

            MessageUtil.setMsg(msg, "MI00020");//�d�ߦ��\

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0100_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }
        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {

            Map rtnBMap = VOTool.jsonToMap(req.getParameter("rtnBMap"));
            
            // 20161223 LogSecurity ���v        
            try{
                Map logOneSecurityMap = new HashMap();
                logOneSecurityMap.put("CUS_NAME", MapUtils.getString(rtnBMap, "CUS_NAME", "") );
                logSecurity(logOneSecurityMap);            	
            } catch(Exception e) {            	
            }
            
            String USER_CPY_ID = req.getParameter("USER_CPY_ID");
            String CRT_NO = MapUtils.getString(rtnBMap, "CRT_NO");
            String CUS_NO = MapUtils.getString(rtnBMap, "CUS_NO");

            //�ˮ֬O�_����������L�|���������ץ�
            DTEPB301 B301vo = new DTEPB301();
            B301vo.setSUB_CPY_ID(USER_CPY_ID);
            B301vo.setCRT_NO(CRT_NO);
            if (new EPB3_0010_mod().checkDTEPB301CrtNo(B301vo, "N")) {//�Y�����f�֪���|�d��
                throw new ModuleException(MessageUtil.getMessage("EPB1_0100_ERRMSG_004"));//�������|���w���󥼧�s�D�ɤ��o�ק�
            }

            EP_B30040 theEP_B30040 = new EP_B30040();

            try {
                List<Map> rtnDList = theEP_B30040.getAdjRntList(USER_CPY_ID, CRT_NO, CUS_NO, null, null, null);
                resp.addOutputData("rtnDList", rtnDList);
            } catch (DataNotFoundException dnfe) {
                if (STRING.objToBigDecimal(rtnBMap.get("RNT_AMT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) != 0) {
                    throw new ModuleException(MessageUtil.getMessage("EPB1_0100_ERRMSG_002", new Object[] { CRT_NO, CUS_NO }));//�d�L������:{0} �A�Ȥ�Ǹ�:{1} ���կ��϶��A�Х��]�w�կ��϶���A�i��պ�
                }
            }

            try {
                List<Map> rtnEList = theEP_B30040.getNoRntList(USER_CPY_ID, CRT_NO, CUS_NO, null, null, null);
                resp.addOutputData("rtnEList", rtnEList);
            } catch (DataNotFoundException dnfe) {
                log.debug("rtnEList�d�L��Ƶ������`");
            }

            resp.addOutputData("rtnBMap", rtnBMap);

            MessageUtil.setMsg(msg, "MI00020");//�d�ߦ��\ 

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0100_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �պ�
     * @param req
     * @return
     */
    public ResponseContext doCalculate(RequestContext req) {
        try {

            Map rtnBMap = VOTool.jsonToMap(req.getParameter("rtnBMap"));
            List<Map> rtnDList = VOTool.jsonAryToMaps(req.getParameter("rtnDList"));
            List<Map> rtnEList = VOTool.jsonAryToMaps(req.getParameter("rtnEList"));

            String USER_CPY_ID = req.getParameter("USER_CPY_ID");
            String CRT_NO = MapUtils.getString(rtnBMap, "CRT_NO");
            String CUS_NO = MapUtils.getString(rtnBMap, "CUS_NO");

            //�ˮ֬O�_����������L�|���������ץ�
            DTEPB301 B301vo = new DTEPB301();
            B301vo.setSUB_CPY_ID(USER_CPY_ID);
            B301vo.setCRT_NO(CRT_NO);
            if (new EPB3_0010_mod().checkDTEPB301CrtNo(B301vo, "N")) {
                throw new ModuleException(MessageUtil.getMessage("EPB1_0100_ERRMSG_004"));//�������|���w���󥼧�s�D�ɤ��o�ק�
            }

            List<Map> B106_List = null;
            try {
                B106_List = new EP_B10100().getCfmList(USER_CPY_ID, CRT_NO, CUS_NO);
            } catch (DataNotFoundException dnfe) {
                if (log.isDebugEnabled()) {
                    log.debug("B106_List�d�L��Ƶ������`");
                }
            }
            resp.addOutputData("rtnFList", new EP_B1Z002().doTrialLine(rtnBMap, rtnEList, rtnDList, B106_List));
            resp.addOutputData("rtnBMap", rtnBMap);

            MessageUtil.setMsg(msg, "EPB1_0100_ERRMSG_007");//�պ⦨�\
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0100_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0100_ERRMSG_008");//�պ⥢��
                }
            }
        } catch (Exception e) {
            log.error("�պ⥢��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB1_0100_ERRMSG_008");//�պ⥢��
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {
        try {
            Map rtnBMap = VOTool.jsonToMap(req.getParameter("rtnBMap"));

            List<Map> rtnFList = VOTool.jsonAryToMaps(req.getParameter("rtnFList"));

            String USER_CPY_ID = req.getParameter("USER_CPY_ID");
            String CRT_NO = MapUtils.getString(rtnBMap, "CRT_NO");

            //�ˮ֬O�_����������L�|���������ץ�
            DTEPB301 B301vo = new DTEPB301();
            B301vo.setSUB_CPY_ID(USER_CPY_ID);
            B301vo.setCRT_NO(CRT_NO);
            if (new EPB3_0010_mod().checkDTEPB301CrtNo(B301vo, "N")) {
                throw new ModuleException(MessageUtil.getMessage("EPB1_0100_ERRMSG_004"));//�������|���w���󥼧�s�D�ɤ��o�ק�
            }

            EP_B10100 theEP_B10100 = new EP_B10100();

            Transaction.begin();
            try {
                theEP_B10100.confirm(USER_CPY_ID, rtnBMap, rtnFList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            try {
                String IN_CRT_NO = req.getParameter("IN_CRT_NO");//�ǤJ�����N��
                String IN_CUS_NO = req.getParameter("IN_CUS_NO");//�ǤJ�Ȥ�Ǹ�
                query(USER_CPY_ID, IN_CRT_NO, IN_CUS_NO, theEP_B10100);
            } catch (DataNotFoundException e) {
                log.error("�T�{����,�d�L���", e);
                MessageUtil.setMsg(msg, "EPB1_0100_ERRMSG_005");//�T�{�����A�d�L���
            }

            MessageUtil.setMsg(msg, "EPB1_0100_ERRMSG_009");//�T�{���\ 
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0100_ERRMSG_006");//�T�{����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB1_0100_ERRMSG_006");//�T�{����
        }

        return resp;
    }

    /**
     * �@�άd��
     * @param SUB_CPY_ID
     * @param INV_NO
     * @param theEP_C22030
     * @throws ModuleException
     */
    private void query(String USER_CPY_ID, String IN_CRT_NO, String IN_CUS_NO, EP_B10100 theEP_B10100) throws ModuleException {
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", USER_CPY_ID);
        reqMap.put("CRT_NO", IN_CRT_NO);
        reqMap.put("CUS_NO", IN_CUS_NO);
        List<Map> rtnList = theEP_B10100.queryList(reqMap);
        // 20161223 LogSecurity
        try{
      		List<Map> logSecurityList = new ArrayList<Map>();
      		for (Map tmpRecord : rtnList) {
      			Map logSecurityMap = new HashMap();
      			// �Ȥ�m�W
      			logSecurityMap.put("CUS_NAME", 
      					MapUtils.getString(tmpRecord,"CUS_NAME", ""));
      			logSecurityList.add(logSecurityMap);
      		}
      		logSecurity(logSecurityList);
      		logSecurityList.clear();
        } catch(Throwable e) {
        	log.warn(e, e);
        }   
        resp.addOutputData("rtnBList", rtnList);
    }

}
