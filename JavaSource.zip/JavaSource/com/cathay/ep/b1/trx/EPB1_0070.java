package com.cathay.ep.b1.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.b1.module.EPB1_0070_mod;
import com.cathay.ep.b1.module.EP_B10070;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 *      Date    Version Description Author
 *      2013/9/23   1.0 Created ���կ�
 *      
 *      UCEPB1_0070_�K�|�Ҹ���J
 *      
 *      �@�B  �{���\�෧�n�����G
 *      �{���\��    �K�|�Ҹ���J
 *      �{���W��    EPB1_0070
 *      �@�~�覡    ONLINE
 *      ���n����    (1) ��l
 *                  (2) ���� �w �}�ҵ������ѨϥΪ̬d�߫�����ơA�I���a�^�A�����������C
 *                  (3) �d�� �w ���ѨϥΪ̬d�ߧK�|�Ҹ���ơC
 *                  (4) �s�W �w ���ѨϥΪ̷s�W�K�|�Ҹ���ơC
 *                  (5) �ק� �V ���ѨϥΪ̭ק�K�|�Ҹ���ơC
 *                  (6) �R�� �w ���ѨϥΪ̧R���K�|�Ҹ���ơC
 *                  (7) �M�� �w �M�ŵe���i��J���C
 *                  
 *      ���s���v    �M��
 *      �����q���
 *      �榡���js  �M��
 *      �h��y�t    �M��
 *      �h���d��    ������                    
 * </pre>
 * @author �x�Ԫ�
 * @since  2013-11-12
 */
@SuppressWarnings("unchecked")
public class EPB1_0070 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPB1_0070.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);
        try {
            resp.addOutputData("USER_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPB1_0070_ERRMSG_001");//���o�����q�O����
        }
        resp.addOutputData("LINK_FROM", req.getParameter("LINK_FROM"));//�W��e��
        resp.addOutputData("CRT_NO", req.getParameter("IN_CRT_NO"));//�W��ǤJ�����N��
        resp.addOutputData("TAX_FREE_CD", req.getParameter("IN_TAX_FREE_CD")); //�W��ǤJ�K�|�Ҹ�

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            this.query(VOTool.jsonToMap(req.getParameter("reqMap")), new EP_B10070());
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L�������
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0070_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �d��
     * @param reqMap
     * @param ep_b10070
     */
    private void query(Map reqMap, EP_B10070 theEP_B10070) throws ModuleException {
        resp.addOutputData("rtnList", theEP_B10070.queryList(reqMap));
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {

            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            String CRT_NO = req.getParameter("CRT_NO");
            String TAX_FREE_CD = req.getParameter("TAX_FREE_CD");
            new EPB1_0070_mod().chkInput(SUB_CPY_ID, CRT_NO, TAX_FREE_CD, "I");
            EP_B10070 theEP_B10070 = new EP_B10070();

            //����s�W�{��
            Transaction.begin();
            try {
                theEP_B10070.insert(SUB_CPY_ID, CRT_NO, TAX_FREE_CD, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "MEP00004");//�s�W����
            try {
                Map reqMap = new HashMap();
                reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
                reqMap.put("CRT_NO", CRT_NO);
                reqMap.put("TAX_FREE_CD", TAX_FREE_CD);
                this.query(reqMap, theEP_B10070);
            } catch (DataNotFoundException e) {
                log.error("�s�W�����A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB1_0070_MSG_005");//�s�W�����A�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataDuplicateException dde) {
            log.error("�s�W���ѡA��Ƥw�s�b", dde);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_DUP, "MEP00006");//�s�W���ѡA��Ƥw�s�b
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00005");//�s�W����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            String TAX_FREE_CD = MapUtils.getString(reqMap, "TAX_FREE_CD");
            EPB1_0070_mod theEPB1_0070_mod = new EPB1_0070_mod();
            List<Map> updList = VOTool.jsonAryToMaps(req.getParameter("updList"));
            List<Map> new_updList = new ArrayList<Map>();
            Set CRT_NO_SET = new HashSet<String>();
            for (Map updMap : updList) {
                String CRT_NO = MapUtils.getString(updMap, "CRT_NO");
                if (!CRT_NO_SET.contains(CRT_NO)) {
                    theEPB1_0070_mod.chkInput(SUB_CPY_ID, CRT_NO, TAX_FREE_CD, "U");
                    new_updList.add(updMap);
                    CRT_NO_SET.add(CRT_NO);
                }
            }
            EP_B10070 theEP_B10070 = new EP_B10070();

            Transaction.begin();
            try {
                theEP_B10070.updList(new_updList, user, TAX_FREE_CD, SUB_CPY_ID, "U");
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB1_0070_MSG_002");//�ץ�����
            try {
                this.query(reqMap, theEP_B10070);
            } catch (DataNotFoundException e) {
                log.error("�ץ������A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB1_0070_MSG_004");//�ץ������A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0070_ERRMSG_003");//�ץ�����
            }
        } catch (Exception e) {
            log.error("�ק�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB1_0070_ERRMSG_003");//�ץ�����
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            EPB1_0070_mod theEPB1_0070_mod = new EPB1_0070_mod();
            List<Map> delList = VOTool.jsonAryToMaps(req.getParameter("delList"));
            List<Map> new_delList = new ArrayList<Map>();
            Set CRT_NO_SET = new HashSet<String>();
            for (Map delMap : delList) {
                String CRT_NO = MapUtils.getString(delMap, "CRT_NO");
                if (!CRT_NO_SET.contains(CRT_NO)) {
                    theEPB1_0070_mod.chkInput(SUB_CPY_ID, CRT_NO, null, "D");
                    new_delList.add(delMap);
                    CRT_NO_SET.add(CRT_NO);
                }
            }
            EP_B10070 theEP_B10070 = new EP_B10070();

            Transaction.begin();
            try {
                theEP_B10070.updList(new_delList, user, null, SUB_CPY_ID, "D");
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00010");//�R������
            try {
                this.query(reqMap, theEP_B10070);
            } catch (DataNotFoundException e) {
                log.error("�d�L���", e);
                MessageUtil.setMsg(msg, "EPB1_0070_MSG_006");//�R�������A�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00011");//�R������
            }
        } catch (Exception e) {
            log.error("�R���@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00011");//�R������
        }

        return resp;
    }
}
