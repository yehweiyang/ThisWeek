package com.cathay.ep.b1.trx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.hr.DivData;
import com.cathay.common.hr.Employee;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.hr.Unit;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.b1.module.EP_B10040;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.vo.DTEPB103;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 *  Date    Version Description Author
 *  2013/8/1    1.0 Created ���կ�
 *  
 *  UCEPB1_0040_�Ƶ�����
 *  
 *  �@�B  �{���\�෧�n�����G
 *  �{���\��    �Ƶ�����
 *  �{���W��    EPB1_0040
 *  �@�~�覡    ONLINE
 *  ���n����    (1) ��l 
 *              (2) ���o�ӯ��Ȥ��TLIST �V ��J�Ȥ�Ǹ���s�ʨ��o�өӯ��Ȥ��T�C
 *              (3) ���o�q���H����T �V ��J�q���H��ID��s�ʨ��o��ID��T�C
 *              (4) �d�� �w �ϥΪ̫��U�d�߫��s��A�I�sEP_B10040�Ҳը��o�����Ƶ��M���T�C
 *              (5) �s�W �w ���ѨϥΪ̷s�W�Ƶ���T�C
 *              (6) �ק� �w ���ѨϥΪ̭ק�Ƶ���T�C
 *              (7) �R�� �w ���ѨϥΪ̧R���Ƶ���T�C
 *              (8) ���� �w ���ѨϥΪ̰w��ݳq�����Ƶ����B�z�����ɰ����װʧ@�C
 *              (9) �ץX - ���ѨϥΪ̤U���e���M���T�C
 *              (10)    �ɮ׽s���s�� �w �ϥΪ̥i�d�ߩΤU���w�W�Ǥ��ɮסC
 *              (11)    �ɮפW�� �V �ϥΪ̥i�w��Y�Ƶ��W���ɮ׳Ƭd�C
 *  ���s���v    �M��
 *  �����q���
 *  �榡js      �M��
 *  �h��y�t    �M��
 *  �h���d��    ������                                    
 * </pre>
 * @author �x�Ԫ�
 * @since 2013/12/5
 */
@SuppressWarnings("unchecked")
public class EPB1_0040 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPB1_0040.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);
        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            //�ѤH�Ƹ�ƨ��o��T
            resp.addOutputData("IS_FROM_HR", StringUtils.isNotBlank(FieldOptionList.getName("EP", "CPY_CTR", SUB_CPY_ID)));
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPB1_0040_ERRMSG_001");//���o�����q�O����
        }
        //���o�B�z���A
        resp.addOutputData("PROC_STS_LIST", FieldOptionList.getName("EP", "PROC_STS"));
        //���o�q���O
        resp.addOutputData("INFM_TYPE_LIST", FieldOptionList.getName("EP", "INFM_TYPE"));
        //�����N��
        String CRT_NO = req.getParameter("IN_CRT_NO");
        //�Ȥ�Ǹ�
        resp.addOutputData("IN_CUS_NO", req.getParameter("CUS_NO"));
        String APLY_NO = req.getParameter("APLY_NO");
        resp.addOutputData("APLY_NO", req.getParameter("APLY_NO"));
        if (StringUtils.isNotEmpty(APLY_NO)) {
            try {
                Map rtnB301Map = new EP_B30010().queryMap(APLY_NO);
                CRT_NO = MapUtils.getString(rtnB301Map, "CRT_NO");
            } catch (Exception e) {
                log.error("�ץ�_�ܧ���� �d�ߥ���", e);
            }
        }
        resp.addOutputData("IN_CRT_NO", CRT_NO);
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            this.query(reqMap, new EP_B10040());
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            //ReturnCode.OK ��l:�d�L��Ƶ������`�A���q�T��
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �@�άd��
     * @param reqMap
     * @param theEP_B10040
     */
    private void query(Map reqMap, EP_B10040 theEP_B10040) throws Exception {
        resp.addOutputData("rtnList", theEP_B10040.queryList(reqMap, user, resp));
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            DTEPB103 B103VO = VOTool.jsonToVO(DTEPB103.class, req.getParameter("B103VO"));
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");

            EP_B10040 theEP_B10040 = new EP_B10040();
            Transaction.begin();
            try {
                theEP_B10040.insert(SUB_CPY_ID, B103VO, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00004");//�s�W����
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", B103VO.getSUB_CPY_ID());
            String CRT_NO = B103VO.getCRT_NO();
            reqMap.put("CRT_NO", CRT_NO);
            resp.addOutputData("CRT_NO", CRT_NO);
            try {
                this.query(reqMap, theEP_B10040);
            } catch (DataNotFoundException e) {
                log.error("�s�W�����A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB1_0040_MSG_002");//�s�W�����A�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataDuplicateException dde) {
            log.error("�s�W���ѡA��Ƥw�s�b", dde);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_DUP, "MEP00006");//�s�W���ѡA��Ƥw�s�b
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W�@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00005");//�s�W����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {
            DTEPB103 B103VO = VOTool.jsonToVO(DTEPB103.class, req.getParameter("updList"));

            EP_B10040 theEP_B10040 = new EP_B10040();
            Transaction.begin();
            try {
                theEP_B10040.update(B103VO, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB1_0040_MSG_003");//�ץ�����
            try {
                this.query(VOTool.jsonToMap(req.getParameter("reqMap")), theEP_B10040);
            } catch (DataNotFoundException e) {
                log.error("�ץ������A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB1_0040_MSG_004");//�ץ������A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB1_0040_ERRMSG_005");//�ץ����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0040_ERRMSG_006");//�ץ�����
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB1_0040_ERRMSG_006");//�ץ�����
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            List<Map> delList = VOTool.jsonAryToMaps(req.getParameter("delList"));
            EP_B10040 theEP_B10040 = new EP_B10040();
            Transaction.begin();
            try {
                theEP_B10040.delete(delList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "MEP00010");//�R������
            try {
                this.query(VOTool.jsonToMap(req.getParameter("reqMap")), theEP_B10040);
            } catch (DataNotFoundException e) {
                log.error("�R�������A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB1_0040_MSG_007");//�R�������A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB1_0040_ERRMSG_004");//�R�����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00011");//�R������
            }
        } catch (Exception e) {
            log.error("�R���@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00011");//�R������
        }

        return resp;
    }

    /**
     * ����
     * @param req
     * @return
     */
    public ResponseContext doEndCase(RequestContext req) {
        try {
            List<Map> B103List = VOTool.jsonAryToMaps(req.getParameter("B103List"));
            EP_B10040 theEP_B10040 = new EP_B10040();
            Transaction.begin();
            try {
                theEP_B10040.endCase(B103List, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPB1_0040_MSG_008");//���ק���

            try {
                this.query(VOTool.jsonToMap(req.getParameter("reqMap")), theEP_B10040);
            } catch (DataNotFoundException e) {
                log.error("���ק����A�d�L���", e);
                MessageUtil.setMsg(msg, "EPB1_0040_MSG_009");//���ק����A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPB1_0040_ERRMSG_010");//���ץ��ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0040_ERRMSG_011");//���ץ���
            }
        } catch (Exception e) {
            log.error("���ץ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB1_0040_ERRMSG_011");//���ץ���
        }
        return resp;
    }

    /**
     * �ץX
     * @param req
     * @return
     */
    public ResponseContext doExportExcel(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("gridJSON", MapUtils.getString(reqMap, "gridJSON"));
            reqMap
                    .put("fileName", new StringBuilder().append("MEMO").append("_").append(DATE.toDate_yyyyMMdd(DATE.getDBDate()))
                            .toString());
            reqMap.put("isExport", true);
            //�ץX
            new EP_B10040().queryList(reqMap, user, resp);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPB1_0040_ERRMSG_012");//�ɮפU������
            }
        } catch (Exception e) {
            log.error("�ɮפU������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPB1_0040_ERRMSG_012");//�ɮפU������
        }
        return resp;
    }

    /**
     * �s�ʳq���O1�A���oEMAIL
     * @param req
     * @return
     */
    public ResponseContext doChangeINFM(RequestContext req) {
        try {
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            String CRT_NO = req.getParameter("CRT_NO");
            String CUS_NO = req.getParameter("CUS_NO");

            Map rtnMap;
            try {
                rtnMap = new EP_B10040().queryTenentMap(SUB_CPY_ID, CRT_NO, CUS_NO);
            } catch (DataNotFoundException dnfe) {
                Map qryMap = new HashMap();
                qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
                qryMap.put("CRT_NO", CRT_NO);
                qryMap.put("CUS_NO", CUS_NO);
                rtnMap = new EP_B10020().querytmpMap(qryMap);
            }
            resp.addOutputData("CUS_NAME", MapUtils.getString(rtnMap, "CUS_NAME"));
            String CLC_DIV_NO = MapUtils.getString(rtnMap, "CLC_DIV_NO");
            if (StringUtils.isNotBlank(CLC_DIV_NO)) {
                resp.addOutputData("CLC_DIV_NO", CLC_DIV_NO);
                Unit CLC_DIV_NO_unit = new DivData().getUnit(CLC_DIV_NO);
                if (CLC_DIV_NO_unit != null) {
                    resp.addOutputData("EMAIL", CLC_DIV_NO_unit.getDivEmail());
                } else {
                    MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPB1_0040_ERRMSG_017");//�L������ơA���oEMAIL����
                }
            }

        } catch (Exception e) {
            log.error("���oEMAIL���ѡA�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPB1_0040_ERRMSG_013");//���oEMAIL����
        }

        return resp;
    }

    /**
     * ���o�ӯ��Ȥ��T
     * @param req
     * @return
     */
    public ResponseContext doGetCUS_INFM(RequestContext req) {
        try {
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            String CRT_NO = req.getParameter("CRT_NO");
            String CUS_NO = req.getParameter("CUS_NO");
            Map rtnMap;
            try {
                rtnMap = new EP_B10040().queryTenentMap(SUB_CPY_ID, CRT_NO, CUS_NO);
            } catch (DataNotFoundException dnfe) {
                rtnMap  = new HashMap();
            }
            
            if(rtnMap.isEmpty() || StringUtils.isBlank(MapUtils.getString(rtnMap, "CUS_NAME"))){
                Map qryMap = new HashMap();
                qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
                qryMap.put("CRT_NO", CRT_NO);
                qryMap.put("CUS_NO", CUS_NO);
                rtnMap = new EP_B10020().querytmpMap(qryMap);                
            }

            resp.addOutputData("CUS_NAME", MapUtils.getString(rtnMap, "CUS_NAME"));
            resp.addOutputData("CLC_DIV_NO", MapUtils.getString(rtnMap, "CLC_DIV_NO"));
        } catch (Exception e) {
            log.error("���o�ӯ��Ȥ��T�A�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPB1_0040_ERRMSG_014");//���o�ӯ��Ȥ��T����
        }

        return resp;
    }

    /**
     * ���o�q���H����T
     * @param req
     * @return
     */
    public ResponseContext doGetINFM_ID_EMAIL(RequestContext req) {
        try {
            Employee emp = new PersonnelData().getByEmployeeID(req.getParameter("INFM_ID"), true);
            if (emp != null) {
                resp.addOutputData("Name", emp.getName());
                resp.addOutputData("Email", emp.getEmail());
            } else {
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPB1_0040_ERRMSG_016");//�d�L���q���H��ID�A���ˮ�
            }
        } catch (Exception e) {
            log.error("���o�q���H����T�A�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, "EPB1_0040_ERRMSG_019");//���o�q���H����T����
        }

        return resp;
    }
}
