package com.cathay.ep.b1.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE Description Author
 * 2013/11/6   Created 黃纓茹
 * 
 * 一、  程式功能概要說明：
 * 模組名稱    契約條碼列印維護模組
 * 模組ID    EP_B10080
 * 概要說明    契約條碼列印維護模組
 * 
 * </pre>
 * @author 洪晟芳
 * @since 2013/12/13
 * 
 * [20200310] 列印標籤優化；由原本4格改成16格
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_B10080 {
    private static final String SQL_queryList_001 = "com.cathay.ep.b1.module.EP_B10080.SQL_queryList_001";

    /**
     * 查詢契約承租戶列印清單
     * @param SUB_CPY_ID  String  分公司別 
     * @param qryCrtList String[]    查詢契約清單
     * @return rtnList List<Map>   契約承租戶清單(DTEPB102欄位)
     * @throws ModuleException
     */
    public List<Map> queryList(String SUB_CPY_ID, String[] qryCrtList) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//分公司別不得為空值
        }
        if (qryCrtList == null || qryCrtList.length == 0) {
            eie = getErrorInputException(eie, "EP_B10080_MSG_001");//查詢契約清單不得為空值!
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("qryCrtList", qryCrtList);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);
        for (Map rtnMap : rtnList) {
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            rtnMap.put("CUS_STS_NM", FieldOptionList.getName("EP", "CUS_STS", MapUtils.getString(rtnMap, "CUS_STS")));
        }
        return rtnList;

    }

    /**
     * 重整條碼標籤列印清單
     * @param prtList   List<Map>   列印清單<MAP>
     *                      <pre>
     *                          CRT_NO = 契約代號
     *                          CUS_NO = 客戶序號
     *                          CUS_NAME = 客戶名稱
     *                          RNT_STR_DATE = 起租日期
     *                          RNT_END_DATE = 到期日期
     *                      </pre>
     * @param PRT_TYPE  String  條碼列印種類 1條碼標籤2條碼3標籤
     * @param PRT_STR_NUM int 列印起始位置
     * @return fmtList List<Map>   重整列印清單
     */
    public List<Map> fmtPrtList(List<Map> prtList, String PRT_TYPE, int PRT_STR_NUM) throws ErrorInputException {
        /* 
         *         1.   User 目前使用LP-8000 點陣式印表機
         *         2.  兩筆資料列印在1張貼紙, 每份列印底稿有4張貼紙(A4紙可排下2份底稿, 即8張貼紙)
         *         3.  依條碼列印種類決定是否加印該筆契約的條碼. 若選擇條碼, 則每個契約只印一筆條碼, 不須列印契約明細. 若選擇條碼標籤, 則須在列印每筆契約承租戶明細開始前, 加印該契約之條碼
         *         4.  列印時兩筆資料為一組(一張貼紙), 若不同契約則須換下一張貼紙開始印
         *         5.  可選擇列印起始位置, 選擇範圍為1~16 (由第一張開始印~第十六張開始印)
         *         [20200310]底稿由原本4格改成16格
         *         [20200310]列印起始位置，由原本1~4之整數改為 1~16 之整數!
         */

        ErrorInputException eie = null;
        if (StringUtils.isBlank(PRT_TYPE)) {
            eie = getErrorInputException(eie, "EP_B10080_MSG_002");//條碼列印種類不得為空值!
        }
        if (prtList == null || prtList.isEmpty()) {
            eie = getErrorInputException(eie, "EP_B10080_MSG_003");//條碼標籤列印資料不得為空值!
        }

        //if (PRT_STR_NUM > 4 || PRT_STR_NUM < 1) {
        //[20200311]列印起始位置，由原本1~4之整數改為 1~16 之整數!
        if (PRT_STR_NUM > 16 || PRT_STR_NUM < 1) {
            eie = getErrorInputException(eie, "EP_B10080_MSG_004");//列印起始位置有誤，只可為 1~16 之整數!
        }
        if (eie != null) {
            throw eie;
        }

        //將列印清單排序
        // 將prtList依照CRT_NO契約代號, CUS_NO客戶序號遞增排序
        Collections.sort(prtList, new Comparator<Map>() {
            public int compare(Map o1, Map o2) {
                String str1 = MapUtils.getString(o1, "CRT_NO");
                String str2 = MapUtils.getString(o2, "CRT_NO");
                int r = str1.compareTo(str2);
                if (r != 0) {
                    return r;
                }

                Integer into1 = MapUtils.getInteger(o1, "CUS_NO");
                Integer into2 = MapUtils.getInteger(o2, "CUS_NO");
                return r = into1.compareTo(into2);
            }

        });

        //輸出資料
        List<Map> tmpList = new ArrayList<Map>();
        //[20200310]奇數欄位資料
        List<Map> tmpList_Odd = new ArrayList<Map>();
        //[20200310]偶數欄位資料
        List<Map> tmpList_Even = new ArrayList<Map>();

        //DATA_TYPE 0:空白1:條碼2:明細
        /*
        //依據PRT_STR_NUM列印起始位置增加空白列以控制起始列印位置
        if (PRT_STR_NUM > 1) {
            Map map = new HashMap();
            map.put("DATA_TYPE", "0");
            for (int i = 0; i < 2 * (PRT_STR_NUM - 1); i++) {
                tmpList.add(map);//增加空白列 EX: 若傳入由第3張開始印, 增加4列空白資料
            }
        }
        */

        //[20200310]判斷資料要加在哪個偶數欄位或是奇數欄位
        //isLeftSide為true 資料存在tmpList_Odd， isLeftSide為falsetmpList_Even
        boolean isLeftSide = PRT_STR_NUM % 2 == 1 ? true : false;

        //[20200310]依據PRT_STR_NUM列印起始位置增加空白列以控制起始列印位置        
        if (PRT_STR_NUM > 1) {
            int tmpList_Odd_spaceRow = PRT_STR_NUM % 2 == 1 ? PRT_STR_NUM - 1 : PRT_STR_NUM;

            //增加第一欄位上方空白列
            Map map_Odd = new HashMap();
            map_Odd.put("DATA_TYPE_ODD", "0");
            for (int i = 0; i < tmpList_Odd_spaceRow; i++) {
                tmpList_Odd.add(map_Odd);//增加空白列 EX: 若傳入由第4張開始印, 奇數欄位增加4列空白資料
            }

            //增加第二欄上方空白列
            Map map_Even = new HashMap();
            map_Even.put("DATA_TYPE_EVEN", "0");
            int tmpList_Even_spaceRow = PRT_STR_NUM % 2 == 1 ? PRT_STR_NUM - 1 : PRT_STR_NUM - 2;
            for (int i = 0; i < tmpList_Even_spaceRow; i++) {
                tmpList_Even.add(map_Even);//增加空白列 EX: 若傳入由第4張開始印,偶數欄位增加2列空白資料
            }
        }

        //依照PRT_TYPE條碼列印種類重新產生列印清單
        String brfCRT_NO = null;
        String brfCUS_NO = null;
        StringBuilder sb = new StringBuilder();

        //[20200310]計算貼紙已有資料數(一張貼紙最多兩筆資料);
        int dataNum = 0;

        for (Map prtMap : prtList) {
            String nowCRT_NO = MapUtils.getString(prtMap, "CRT_NO", "");
            String nowCUS_NO = MapUtils.getString(prtMap, "CUS_NO", "");
            boolean b_CRT_NO = !StringUtils.equals(brfCRT_NO, nowCRT_NO);

            if (b_CRT_NO) {
                /*
                //若不同契約須換下一張貼紙
                //若tmpList筆數為奇數筆        
                if (tmpList.size() % 2 == 1) {
                    Map map = new HashMap();
                    map.put("DATA_TYPE", "0");
                    //tmpList.add(map);
                }
                */

                //[20200310]若tmpList_Odd或tmpList_Even筆數為奇數筆
                if (isLeftSide) {
                    Map map = new HashMap();
                    map.put("DATA_TYPE_ODD", "0");
                    if (tmpList_Odd.size() % 2 == 1) {
                        tmpList_Odd.add(map);
                        dataNum++;
                    }
                } else {
                    Map map = new HashMap();
                    map.put("DATA_TYPE_EVEN", "0");
                    if (tmpList_Even.size() % 2 == 1) {
                        tmpList_Even.add(map);
                        dataNum++;
                    }
                }

                //[20200310]判斷一張貼紙是否已有兩筆資料，若為兩筆資料則將下一筆資料加入至另一個List
                if (dataNum >= 2) {
                    isLeftSide = !isLeftSide;
                    dataNum = 0;
                }

                if ("1".equals(PRT_TYPE) || "2".equals(PRT_TYPE)) {
                    /*
                    //增加列印條碼
                    Map map = new HashMap();
                    map.put("DATA_TYPE", "1");//條碼  
                    map.put("CRT_NO_CODE", sb.append('*').append(nowCRT_NO).append('*').toString());
                    sb.setLength(0);
                    map.put("CRT_NO", nowCRT_NO);
                    map.put("CUS_NO", nowCUS_NO);
                    tmpList.add(map);
                    */

                    //[20200316]增加列印條碼
                    Map map = new HashMap();
                    map.put(isLeftSide ? "DATA_TYPE_ODD" : "DATA_TYPE_EVEN", "1");//條碼  
                    map.put(isLeftSide ? "CRT_NO_CODE_ODD" : "CRT_NO_CODE_EVEN", sb.append('*').append(nowCRT_NO).append('*').toString());
                    sb.setLength(0);
                    map.put(isLeftSide ? "CRT_NO_ODD" : "CRT_NO_EVEN", nowCRT_NO);
                    map.put(isLeftSide ? "CUS_NO_ODD" : "CUS_NO_EVEN", nowCUS_NO);

                    //[20200316]判斷奇數筆的資料加入tmpList_Odd，偶數筆的資料加入tmpList_Even
                    if (isLeftSide) {
                        tmpList_Odd.add(map);
                    } else {
                        tmpList_Even.add(map);
                    }

                    //[20200316]累計貼紙資料數
                    dataNum++;


                    if ("2".equals(PRT_TYPE)) {
                        continue;
                    }
                }

            }

            if ("1".equals(PRT_TYPE) || "3".equals(PRT_TYPE)) {
                //列印明細
                if (b_CRT_NO || !StringUtils.equals(brfCUS_NO, nowCUS_NO)) {
                    Map map = new HashMap();
                    /*
                    map.put("DATA_TYPE", "2");//2明細
                    map.put("CUS_NO", nowCUS_NO);
                    map.put("CRT_NO", nowCRT_NO);
                    map.put("CUS_NAME", MapUtils.getString(prtMap, "CUS_NAME", ""));
                    map.put("RNT_STR_DATE", MapUtils.getString(prtMap, "RNT_STR_DATE_SUB", ""));
                    map.put("RNT_END_DATE", MapUtils.getString(prtMap, "RNT_END_DATE_SUB", ""));
                    tmpList.add(map);
                    */
                    
                    //[20200316]根據資料奇偶數加入列印明細
                    map.put(isLeftSide ? "DATA_TYPE_ODD" : "DATA_TYPE_EVEN", "2");//2明細
                    map.put(isLeftSide ? "CRT_NO_ODD" : "CRT_NO_EVEN", nowCRT_NO);
                    map.put(isLeftSide ? "CUS_NO_ODD" : "CUS_NO_EVEN", nowCUS_NO);
                    map.put(isLeftSide ? "CUS_NAME_ODD" : "CUS_NAME_EVEN", MapUtils.getString(prtMap, "CUS_NAME", ""));
                    map.put(isLeftSide ? "RNT_STR_DATE_ODD" : "RNT_STR_DATE_EVEN", MapUtils.getString(prtMap, "RNT_STR_DATE_SUB", ""));
                    map.put(isLeftSide ? "RNT_END_DATE_ODD" : "RNT_END_DATE_EVEN", MapUtils.getString(prtMap, "RNT_END_DATE_SUB", ""));
                    

                    //[20200316]判斷奇數筆的資料加入tmpList_Odd，偶數筆的資料加入tmpList_Even
                    if (isLeftSide) {
                        tmpList_Odd.add(map);
                    } else {
                        tmpList_Even.add(map);
                    }
                    
                    //[20200316]判斷一張貼紙是否已有兩筆資料，若為兩筆資料則將下一筆資料加入至另一個List
                    dataNum++;                   
                    if (dataNum >= 2) {
                        isLeftSide = !isLeftSide;
                        dataNum = 0;
                    }
                    
                }

            }
            brfCRT_NO = nowCRT_NO;

        }

        //[20200316]當最後一張貼只在奇數欄位時，將右邊的偶數欄位加入空白列與奇數欄位的列數相同
        int tmpList_Odd_Size = tmpList_Odd.size();
        int tmpList_Even_Size = tmpList_Even.size();
        if (tmpList_Odd_Size > tmpList_Even_Size) {
            Map map = new HashMap();
            map.put("DATA_TYPE_EVEN", "0");
            for (int i = tmpList_Even_Size; i < tmpList_Odd_Size; i++) {
                tmpList_Even.add(map);
            }
        }

        //[20200316]將tmpList_Odd和tmpList_Even資料加入到tmpList
        String[] fields = { "DATA_TYPE", "CRT_NO", "CUS_NO", "RNT_STR_DATE", "RNT_END_DATE", "CUS_NAME", "CRT_NO_CODE" };
        for (int i = 0; i < tmpList_Odd_Size; i++) {
            //合併欄位
            tmpList.add(setTmpList(tmpList_Odd, tmpList_Even, i, fields));
        }

        return tmpList;

    }

    /**
     * 條碼標籤列印格式
     * @param prtList  列印清單<MAP>
     *                      <pre>
     *                          CRT_NO = 契約代號
     *                          CUS_NO = 客戶序號
     *                          CUS_NAME = 客戶名稱
     *                          RNT_STR_DATE = 起租日期
     *                          RNT_END_DATE = 到期日期
     *                      </pre>
     * @param PRT_TYPE   String  條碼列印種類 1條碼標籤2條碼3標籤
     * @param PRT_STR_NUM int 列印起始位置
     * @return
     */
    public Map prtCrt(List<Map> prtList, String PRT_TYPE, int PRT_STR_NUM) throws ErrorInputException {
        /* 
         * 1.  整理列印清單
         * 2.  產生列印報表
         */
        //重新整理列印清單
        List<Map> fmtList = this.fmtPrtList(prtList, PRT_TYPE, PRT_STR_NUM);

        //設定回傳值
        Map param = new HashMap();
        //列印日期
        param.put("REPORT_ID", "EP_B10080");
        Map rtnMap = new HashMap();
        rtnMap.put("params", param);
        rtnMap.put("detail", fmtList);
        return rtnMap;

    }

    /**
     * 列印條碼標籤報表
     * @param reqMap
     * @param resp
     */
    public void print(Map reqMap, ResponseContext resp) {
        JasperReportUtils.addOutputRptDataToResp("EP_B10080", (Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), resp);
    }

    /**
     * 制定EIE實體
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * [20200316]奇數欄位與偶數欄位合併
     * @param tmpList_Odd   奇數欄位
     * @param tmpList_Even  偶數欄位
     * @param index         資料順序
     * @param fieldName     欄位名稱
     */
    private Map setTmpList(List<Map> tmpList_Odd, List<Map> tmpList_Even, int index, String[] fields) {
        Map map = new HashMap();
        for (String fieldName : fields) {
            String Odd_Field = fieldName + "_ODD";
            String Even_Field = fieldName + "_EVEN";
            //奇數欄位
            map.put(Odd_Field, tmpList_Odd.get(index).get(Odd_Field));
            //偶數欄位
            map.put(Even_Field, tmpList_Even.get(index).get(Even_Field));
        }
        return map;
    }
}
