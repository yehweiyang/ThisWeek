package com.cathay.ep.b1.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.vo.DTEPB102;
import com.cathay.ep.vo.DTEPB102_LOG;
import com.cathay.ep.vo.DTEPB301;
import com.cathay.ep.vo.DTEPB303;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 *      DATE    Description Author
 *      2013/08/26  Created ���կ�
 *      
 *      �@�B  �{���\�෧�n�����G
 *      �ҲզW��    �ӯ���O�����@�Ҳ�
 *      �Ҳ�ID    EP_B10020
 *      ���n����    �ӯ���O�����@�Ҳ�
 *      
 * </pre>
 * @author �x�Ԫ�
 * @since  2013-09-11
 */
@SuppressWarnings("unchecked")
public class EP_B10020 {
    private static final String SQL_queryList_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.b1.module.EP_B10020.SQL_queryList_002";

    private static final String SQL_queryMap_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_queryMap_001";

    private static final String SQL_queryMap_002 = "com.cathay.ep.b1.module.EP_B10020.SQL_queryMap_002";

    private static final String SQL_queryTmpMap_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_queryTmpMap_001";

    private static final String SQL_queryTenentList_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_queryTenentList_001";

    private static final String SQL_queryVldCus_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_queryVldCus_001";

    private static final String SQL_getCrtSum_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_getCrtSum_001";

    private static final String SQL_getCrtSum_002 = "com.cathay.ep.b1.module.EP_B10020.SQL_getCrtSum_002";

    private static final String SQL_getBldRntByTax_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_getBldRntByTax_001";

    private static final String SQL_getBldRmPms_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_getBldRmPms_001";

    private static final String SQL_queryRm_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_queryRm_001";

    private static final String SQL_queryCar_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_queryCar_001";

    private static final String SQL_updateCUSInfo_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_updateCUSInfo_001";

    private static final String SQL_recoverCUSInfo_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_recoverCUSInfo_001";

    private static final String SQL_recoverCUSInfo_002 = "com.cathay.ep.b1.module.EP_B10020.SQL_recoverCUSInfo_002";

    private static final String SQL_chkAdjPrd_001 = "com.cathay.ep.b1.module.EP_B10020.SQL_chkAdjPrd_001";

    private static final String SQL_chkAdjPrd_002 = "com.cathay.ep.b1.module.EP_B10020.SQL_chkAdjPrd_002";

    /**
     * Ū���ץ󫴬��ӯ����ܧ�����ɲM��
     * @param reqMap
     *          <pre>
     *              SUB_CPY_ID = �����q�O
     *              APLY_NO = �ץ�s��
     *              CRT_NO = �����N��
     *              CUS_NO = �Ȥ�Ǹ�
     *              QuerySts = �d�ߪ��A: 1 ����
     *              QueryDate = �d�ߤ��
     *          </pre>
     * @return List<Map>   ����_�ӯ�������DTEPB102(�h��)
     */
    public List<Map> queryList(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10020_MSG_001");//����_�ӯ����Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        if (StringUtils.isBlank(APLY_NO) && StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_041");//�ץ�s���Ϋ����N�����o�Ҭ��ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setfieldIfExist(ds, reqMap, "CUS_NO");
        setfieldIfExist(ds, reqMap, "QueryDate");
        if ("1".equals(MapUtils.getString(reqMap, "QuerySts"))) {
            ds.setField("CUS_STS", "3");
        }

        List<Map> rtnList;
        if (StringUtils.isNotBlank(APLY_NO)) {
            ds.setField("APLY_NO", APLY_NO);
            if (StringUtils.isNotBlank(CRT_NO)) {
                ds.setField("CRT_NO", CRT_NO);
            }
            rtnList = VOTool.findToMaps(ds, SQL_queryList_001);
        } else {
            ds.setField("CRT_NO", CRT_NO);
            rtnList = VOTool.findToMaps(ds, SQL_queryList_002);
        }
        StringBuilder sb = new StringBuilder();
        for (Map rtnMap : rtnList) {
            rtnMap.put("JOB_TYPE_NM", getNM(rtnMap, "JOB_TYPE", "JOB_TYPE", false, sb));
            rtnMap.put("RNT_TYPE_NM", getNM(rtnMap, "RNT_TYPE", "RNT_TYPE", false, sb));
            rtnMap.put("PMS_TYPE_NM", getNM(rtnMap, "PMS_TYPE", "PMS_TYPE", false, sb));
            rtnMap.put("CUS_STS_NM", getNM(rtnMap, "CUS_STS", "CUS_STS", false, sb));
            rtnMap.put("ADJ_KIND_NM", getNM(rtnMap, "ADJ_KIND", "ADJ_KIND", false, sb));
            rtnMap.put("MON_BRK_NM", getNM(rtnMap, "MON_BRK", "MON_BRK", false, sb));
            rtnMap.put("TRN_KIND_NM", getNM(rtnMap, "TRN_KIND", "TRN_KIND", false, sb));
            rtnMap.put("DATA_TYPE_NM", getNM(rtnMap, "DATA_TYPE", "DATA_TYPE", false, sb));

            rtnMap.put("RNT_CHG_TRNKD_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "RNT_CHG_TRNKD")));

            String TEL = MapUtils.getString(rtnMap, "TEL");
            if (StringUtils.isNotBlank(TEL)) {
                String TEL_AREA = MapUtils.getString(rtnMap, "TEL_AREA");
                if (StringUtils.isNotBlank(TEL_AREA)) {
                    sb.append(TEL_AREA).append("-");
                }
                sb.append(TEL);
                String TEL_EXT = MapUtils.getString(rtnMap, "TEL_EXT");
                if (StringUtils.isNotBlank(TEL_EXT)) {
                    sb.append("-").append(TEL_EXT);
                }
                rtnMap.put("CONT_TEL", sb.toString());
                sb.setLength(0);
            }

            String DCT_TYPE = MapUtils.getString(rtnMap, "DCT_TYPE");
            rtnMap.put("DCT_TYPE_NM", FieldOptionList.getName("EP", "DCT_TYPE", DCT_TYPE));

            //�]�w�O�_�H�ΥdúIS_CARD
            if ("1".equals(DCT_TYPE)) {
                rtnMap.put("IS_CARD", "Y");
                rtnMap.put("IS_CARD_NM", MessageUtil.getMessage("EP_B10020_IS_CARD_NM_Y"));//�O
            } else {
                rtnMap.put("IS_CARD", "N");
                rtnMap.put("IS_CARD_NM", MessageUtil.getMessage("EP_B10020_IS_CARD_NM_N"));//�_
            }

        }
        return rtnList;
    }

    /**
     * Ū���浧�ӯ���򥻸����
     * @param reqMap Map
     *                  <pre>
     *                      SUB_CPY_ID = �����q�O
     *                      CRT_NO = �����N��
     *                      CUS_NO = �Ȥ�N��
     *                      APLY_NO = �ץ�s��
     *                      DATA_TYPE = �������
     *                  </pre>
     * @return   rtnMap  Map �����򥻸��
     */
    public Map queryMap(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10020_MSG_001");//����_�ӯ����Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�N�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        Map rtnMap;
        if (StringUtils.isNotBlank(APLY_NO)) {
            //�d�Ӯץ�s���Ȧs�ɬO�_�����ӯ�����
            ds.setField("APLY_NO", APLY_NO);
            String DATA_TYPE = MapUtils.getString(reqMap, "DATA_TYPE");
            if (StringUtils.isNotBlank(DATA_TYPE)) {
                ds.setField("DATA_TYPE", DATA_TYPE);
            } else {
                ds.setField("DATA_TYPE_B", "B");
            }
            rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_001);
            rtnMap.put("TABLE", "DTEPB303");
        } else {
            //�d�ߥD�� �ӯ�������(DTEPB102)
            rtnMap = VOTool.findOneToMap(ds, SQL_queryMap_002);
            rtnMap.put("TABLE", "DTEPB102");
        }
        return rtnMap;
    }

    /**
     * Ū�������j�ӤΫȤ�򥻸��
     * @param reqMap Map
     *                  <pre>
     *                      SUB_CPY_ID = �����q�O
     *                      CRT_NO = �����N��
     *                      CUS_NO = �Ȥ�N��
     *                      ID = �ҥ󸹽X
     *                      STATUS �d�ߪ��A(0������)
     *                  </pre>
     * @return rtnList List<Map>   �ӯ��Ȥ��TList<MAP> ���e��
     *                              DTEPA101�j��_�򥻸����
     *                              DTEPB101����_�򥻸��
     *                              DTEPB102����_�ӯ����� �Ҧ����
     */
    public List<Map> queryTenentList(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10020_MSG_001");//����_�ӯ����Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String ID = MapUtils.getString(reqMap, "ID");
        if (StringUtils.isBlank(CRT_NO) && StringUtils.isBlank(ID)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_042");//�����N�����ҥ󸹽X���ܤ@��J!
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ�����q�O�Ϋ����N���d�߫����򥻸����(DTEPB101)�B�j�Ӱ򥻸����(DTEPA101)�Ωӯ����T(DTEPB102)�G

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setfieldIfExist(ds, reqMap, "CRT_NO");
        setfieldIfExist(ds, reqMap, "CUS_NO");
        setfieldIfExist(ds, reqMap, "ID");
        if ("0".equals(MapUtils.getString(reqMap, "STATUS"))) {
            ds.setField("CURRENT DATE", DATE.today());
        }
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryTenentList_001);
        StringBuilder sb = new StringBuilder();
        for (Map rtnMap : rtnList) {
            rtnMap.put("JOB_TYPE_NM", getNM(rtnMap, "JOB_TYPE", "JOB_TYPE", true, sb));
            rtnMap.put("RNT_TYPE_NM", getNM(rtnMap, "RNT_TYPE", "RNT_TYPE", true, sb));
            rtnMap.put("PMS_TYPE_NM", getNM(rtnMap, "PMS_TYPE", "PMS_TYPE", true, sb));
            rtnMap.put("CUS_STS_NM", getNM(rtnMap, "CUS_STS", "CUS_STS", true, sb));
            rtnMap.put("ADJ_KIND_NM", getNM(rtnMap, "ADJ_KIND", "ADJ_KIND", true, sb));
            rtnMap.put("MON_BRK_NM", getNM(rtnMap, "MON_BRK", "MON_BRK", true, sb));
            rtnMap.put("TRN_KIND_NM", getNM(rtnMap, "TRN_KIND", "TRN_KIND", true, sb));
            String DCT_TYPE = MapUtils.getString(rtnMap, "DCT_TYPE", "");
            rtnMap.put("DCT_TYPE_NM", sb.append(DCT_TYPE).append(FieldOptionList.getName("EP", "DCT_TYPE", DCT_TYPE)).toString());
            sb.setLength(0);
            rtnMap.put("CRT_STS_NM", getNM(rtnMap, "CRT_STS_B101", "CRT_STS", true, sb));
            rtnMap.put("TAX_TYPE_NM", getNM(rtnMap, "TAX_TYPE_B101", "TAX_TYPE", true, sb));
            rtnMap.put("RLT_CD_NM", getNM(rtnMap, "RLT_CD_B101", "RLT_CD", true, sb));
            rtnMap.put("PAY_FREQ_NM", getNM(rtnMap, "PAY_FREQ_B101", "PAY_FREQ", true, sb));
            rtnMap.put("RNT_TYPE_NM_B101", getNM(rtnMap, "RNT_TYPE_B101", "RNT_TYPE", true, sb));
            rtnMap.put("ADJ_TYPE_NM", getNM(rtnMap, "ADJ_TYPE_B101", "ADJ_TYPE", true, sb));
            rtnMap.put("ADJ_PM_NM", getNM(rtnMap, "ADJ_PM_B101", "ADJ_PM", true, sb));
            rtnMap.put("CASE_TYPE_NM", getNM(rtnMap, "CASE_TYPE_B101", "CASE_TYPE", true, sb));
            rtnMap.put("TRN_KIND_NM_B101", getNM(rtnMap, "TRN_KIND_B101", "TRN_KIND", true, sb));
            rtnMap.put("RNT_CHG_TRNKD_NM", getNM(rtnMap, "RNT_CHG_TRNKD", "TRN_KIND", true, sb));
            //�]�w�O�_�H�ΥdúIS_CARD  
            if ("1".equals(DCT_TYPE)) {
                rtnMap.put("IS_CARD", "Y");
                rtnMap.put("IS_CARD_NM", MessageUtil.getMessage("EP_B10020_IS_CARD_NM_Y"));//�O
            } else {
                rtnMap.put("IS_CARD", "N");
                rtnMap.put("IS_CARD_NM", MessageUtil.getMessage("EP_B10020_IS_CARD_NM_N"));//�_
            }
            String IS_BOARD = MapUtils.getString(rtnMap, "IS_BOARD_B101");
            if ("Y".equals(IS_BOARD)) {
                rtnMap.put("IS_BOARD_NM", MessageUtil.getMessage("EP_B10020_IS_BOARD_NM_001"));//�O
            } else {
                rtnMap.put("IS_BOARD_NM", MessageUtil.getMessage("EP_B10020_IS_BOARD_NM_002"));//�_
            }

        }

        return rtnList;

    }

    /**
     * Ū�������ǧO�M��
     * @param reqMap
     *          <pre>
     *           SUB_CPY_ID = �����q�O
     *           CRT_NO = �����N��
     *           CUS_NO = �Ȥ�Ǹ�
     *          </pre>
     * @return  rtnList List<Map>   �j��_�ǧO�O����DTEPA103(�h��)
     */
    public List<Map> queryRm(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10020_MSG_005");//�j��_�ǧO��Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        setfieldIfExist(ds, reqMap, "CUS_NO");
        return VOTool.findToMaps(ds, SQL_queryRm_001);
    }

    /**
     * Ū����������M��
     * @param reqMap
     *          <pre>
     *           SUB_CPY_ID = �����q�O
     *           CRT_NO = �����N��
     *           CUS_NO = �Ȥ�Ǹ�
     *          </pre>
     * @return  rtnList List<Map>  �j��_����O����DTEPA104(�h��)
     */
    public List<Map> queryCar(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10020_MSG_006");//�j��_�����Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        setfieldIfExist(ds, reqMap, "CUS_NO");
        return VOTool.findToMaps(ds, SQL_queryCar_001);
    }

    /**
     * ���o���ĩӯ����
     * @param SUB_CPY_ID  String  �����q�O
     * @param CRT_NO      String  �����N��
     * @param QueryDate   String  �d�ߤ��
     * @return rtnMap  Map 
     *                  MAIN_CNT  �D�ɩӯ����
     *                  TMP_CNT   �Ȧs�ɩӯ����
     */
    public Map queryVldCus(String SUB_CPY_ID, String CRT_NO, String QueryDate) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(QueryDate)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_007");//�d�ߤ�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�H�ǤJ���d�ߤ���d�ߥD�ɤμȦs�ɨ��o��d�ߤ餴���Ĥ������ӯ����

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("QueryDate", QueryDate);
        return VOTool.findOneToMap(ds, SQL_queryVldCus_001);
    }

    /**
     * ���o�D�ɫ����ӯ����ɩӯ����n�Ϊ��B�`�p
     * @param SUB_CPY_ID  String  �����q�O
     * @param CRT_NO      String  �����N�� 
     * @param ELM_CUSNO   String  �ư��Ȥ�Ǹ�(//���C�J�p�⤧�Ȥ�Ǹ�)
     * @param QuerySts    String  �d�ߪ��A  1 ����
     * @param IS_CHK_TEMP boolean �O�_�d�ӯ���Ȧs��
     * @return rtnMap  MAP 
     *                  <pre>
     *                  SUM_RNT_SIZE�`�ӯ��W��
     *                  SUM_RNT_AMT�`�믲��
     *                  SUM_PMS_AMT�`���
     *                  TSUM_RNT_SIZE�Ȧs�`�ӯ��W��
     *                  TSUM_RNT_AMT�Ȧs�`�믲��
     *                  TSUM_PMS_AMT�Ȧs�`���
     *                  </pre>
     */
    public Map getCrtSum(String SUB_CPY_ID, String CRT_NO, String ELM_CUSNO, String QuerySts, boolean IS_CHK_TEMP) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        Set<String> CUS_NO_Set = new HashSet();
        Map rtnMap = new HashMap();
        if (IS_CHK_TEMP) {
            ds.clear();
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            ds.setField("CRT_NO", CRT_NO);
            if (StringUtils.isNotBlank(ELM_CUSNO)) {
                ds.setField("ELM_CUSNO", ELM_CUSNO);
            }
            if ("1".equals(QuerySts)) {
                ds.setField("CUS_STS", "3");
            }
            DBUtil.searchAndRetrieve(ds, SQL_getCrtSum_002, false);
            BigDecimal TSUM_RNT_SIZE = BigDecimal.ZERO;
            BigDecimal TSUM_RNT_AMT = BigDecimal.ZERO;
            BigDecimal TSUM_PMS_AMT = BigDecimal.ZERO;

            while (ds.next()) {
                Map map = VOTool.dataSetToMap(ds);
                CUS_NO_Set.add(MapUtils.getString(map, "CUS_NO"));
                String DATA_TYPE = MapUtils.getString(map, "DATA_TYPE");
                BigDecimal RNT_SIZE = getDecimal(map.get("RNT_SIZE"));
                BigDecimal RNT_AMT = getDecimal(map.get("RNT_AMT"));
                BigDecimal PMS_AMT = getDecimal(map.get("PMS_AMT"));
                if ("I".equals(DATA_TYPE) || "A".equals(DATA_TYPE)) {
                    String CUS_STS = MapUtils.getString(map, "CUS_STS");
                    if (!"3".equals(CUS_STS)) {
                        TSUM_RNT_SIZE = TSUM_RNT_SIZE.add(RNT_SIZE);
                        TSUM_RNT_AMT = TSUM_RNT_AMT.add(RNT_AMT);
                        TSUM_PMS_AMT = TSUM_PMS_AMT.add(PMS_AMT);
                    }

                } else if ("D".equals(DATA_TYPE)) {
                    TSUM_RNT_SIZE = TSUM_RNT_SIZE.subtract(RNT_SIZE);
                    TSUM_RNT_AMT = TSUM_RNT_AMT.subtract(RNT_AMT);
                    TSUM_PMS_AMT = TSUM_PMS_AMT.subtract(PMS_AMT);
                }
            }
            rtnMap.put("TSUM_RNT_SIZE", TSUM_RNT_SIZE);
            rtnMap.put("TSUM_RNT_AMT", TSUM_RNT_AMT);
            rtnMap.put("TSUM_PMS_AMT", TSUM_PMS_AMT);

        }
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        if (StringUtils.isNotBlank(ELM_CUSNO)) {
            ds.setField("ELM_CUSNO", ELM_CUSNO);
        }
        if ("1".equals(QuerySts)) {
            ds.setField("CUS_STS", "3");
        }
        BigDecimal SUM_RNT_SIZE = BigDecimal.ZERO;
        BigDecimal SUM_RNT_AMT = BigDecimal.ZERO;
        BigDecimal SUM_PMS_AMT = BigDecimal.ZERO;
        DBUtil.searchAndRetrieve(ds, SQL_getCrtSum_001, false);

        while (ds.next()) {
            Map map = VOTool.dataSetToMap(ds);
            String CUS_NO = MapUtils.getString(map, "CUS_NO");
            if (!CUS_NO_Set.contains(CUS_NO)) {
                String CUS_STS = MapUtils.getString(map, "CUS_STS");
                if (!"3".equals(CUS_STS)) {
                    SUM_RNT_SIZE = SUM_RNT_SIZE.add((BigDecimal) MapUtils.getObject(map, "RNT_SIZE", BigDecimal.ZERO));
                    SUM_RNT_AMT = SUM_RNT_AMT.add((BigDecimal) MapUtils.getObject(map, "RNT_AMT", BigDecimal.ZERO));
                    SUM_PMS_AMT = SUM_PMS_AMT.add((BigDecimal) MapUtils.getObject(map, "PMS_AMT", BigDecimal.ZERO));
                }
            }
        }

        rtnMap.put("SUM_RNT_SIZE", SUM_RNT_SIZE);
        rtnMap.put("SUM_RNT_AMT", SUM_RNT_AMT);
        rtnMap.put("SUM_PMS_AMT", SUM_PMS_AMT);

        return rtnMap;

    }

    /**
     * �̵|�O�Τj�Ө��o�D�ɦ��ī����ӯ����B�`�p
     * @param BLD_CD  String  �j�ӥN��
     * @param SUB_CPY_ID  String  �����q�O
     * @return List    List<Map>   
     *                  <pre>
     *                  TAX_TYPE�|�O
     *                  RNT_AMT�믲��
     *                  </pre>
     */
    public List<Map> getBldRntByTax(String BLD_CD, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        if (StringUtils.isNotBlank(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        return VOTool.findToMaps(ds, SQL_getBldRntByTax_001);
    }

    /**
     * �̤j�Ө��o�ӯ��ǧO�`���
     * @param BLD_CD  String  �j�ӥN��
     * @param SUB_CPY_ID  String  �����q�O
     * @return TOT_PMS_AMT BigDecimal  �j���`���
     */
    public BigDecimal getBldRmPms(String BLD_CD, String SUB_CPY_ID) throws ModuleException {
        if (StringUtils.isBlank(BLD_CD)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_B10020_MSG_008"));//�j�ӥN�����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.searchAndRetrieve(ds, SQL_getBldRmPms_001);
        ds.next();
        return getDecimal(ds.getField(0));
    }

    /**
     * ���o�U�U����ú��
     * @param SUB_CPY_ID  String  �����q�O
     * @param CRT_NO  String  �����N��
     * @param CUS_NO  int �Ȥ�Ǹ�
     * @param IS_OVER_ENDDT  boolean �O�_�P�_�W�L���������
     * @return Next2_PAY_DATE  String  �U�U����ú��
     */
    public String getNext2PayDate(String SUB_CPY_ID, String CRT_NO, int CUS_NO, boolean IS_OVER_ENDDT) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //���o�����Ωӯ����T
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        reqMap.put("CRT_NO", CRT_NO);
        reqMap.put("CUS_NO", CUS_NO);
        List<Map> rtnList = null;
        try {
            rtnList = this.queryTenentList(reqMap);

        } catch (DataNotFoundException dnfe) {
            throw getErrorInputException(eie, "EP_B10020_MSG_010");//�d�L�������ӯ����T
        }

        Map rtnListMap1 = rtnList.get(0);
        String PAY_FREQ = MapUtils.getString(rtnListMap1, "PAY_FREQ_B101");
        if (StringUtils.isBlank(PAY_FREQ)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_004");//����������ú�O���ŭ�!
        }
        String NEXT_PAY_DATE = MapUtils.getString(rtnListMap1, "NEXT_PAY_DATE");
        if (StringUtils.isBlank(NEXT_PAY_DATE)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_030");//���������Ȥᤧ�U����ú�鬰�ŭ�!
        }
        String RNT_END_DATE = MapUtils.getString(rtnListMap1, "RNT_END_DATE");
        if (StringUtils.isBlank(RNT_END_DATE)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_031");//���������Ȥᤧ����������ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        if ("1".equals(PAY_FREQ)) {
            //ú�O��1:��ú
            //  Next2_PAY_DATE = NEXT_PAY_DATE + 1�Ӥ�
            NEXT_PAY_DATE = DATE.addDate(NEXT_PAY_DATE, 0, 1, 0);

        } else if ("2".equals(PAY_FREQ)) {
            //ú�O��2:�uú
            //Next2_PAY_DATE = NEXT_PAY_DATE + 3�Ӥ�
            NEXT_PAY_DATE = DATE.addDate(NEXT_PAY_DATE, 0, 3, 0);

        } else if ("3".equals(PAY_FREQ)) {
            //ú�O��3:�b�~ú
            //Next2_PAY_DATE = NEXT_PAY_DATE + 6�Ӥ�
            NEXT_PAY_DATE = DATE.addDate(NEXT_PAY_DATE, 0, 6, 0);
        } else if ("4".equals(PAY_FREQ)) {
            //ú�O��4:�~ú
            //Next2_PAY_DATE = NEXT_PAY_DATE + 1�~
            NEXT_PAY_DATE = DATE.addDate(NEXT_PAY_DATE, 1, 0, 0);
        } else if ("5".equals(PAY_FREQ)) {
            //ú�O��5:����ú
            //Next2_PAY_DATE = NEXT_PAY_DATE + 2�Ӥ�
            NEXT_PAY_DATE = DATE.addDate(NEXT_PAY_DATE, 0, 2, 0);
        } else if ("6".equals(PAY_FREQ)) {
            //ú�O��6:Ļú
            //Next2_PAY_DATE = RNT_END_DATE + 1��
            NEXT_PAY_DATE = DATE.addDate(RNT_END_DATE, 0, 0, 1);
        }

        //�P�_�W�L���������
        if (IS_OVER_ENDDT && RNT_END_DATE.compareTo(NEXT_PAY_DATE) < 0) {
            // Next2_PAY_DATE = RNT_END_DATE + 1��      
            NEXT_PAY_DATE = DATE.addDate(RNT_END_DATE, 0, 0, 1);
        }

        return NEXT_PAY_DATE;
    }

    /**
     * �s�W�ӯ�������
     * @param B102Vo       DTEPB102    ����_�ӯ�������
     * @param UPD_DATE     String      �J�ɤ���ɶ�
     * @param UPD_APLY_NO  String      �J�ɮץ�s��
     * @param UPD_TRN_KIND String      �J�ɥ������
     */
    public void insertDTEPB102(DTEPB102 B102Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {
        ErrorInputException eie = null;
        //�ˮֶǤJ�Ѽ�:
        eie = this.CheckparamDTEPB102(eie, B102Vo);
        if (eie != null) {
            throw eie;
        }
        //�s�W����_�ӯ������� DTEPB102�G
        VOTool.insert(B102Vo);
        //�g�@��LOG��
        this.insertLog(B102Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND, false);

    }

    /**
     * �R���ӯ�������
     * @param B102Vo       DTEPB102    ����_�ӯ�������
     * @param UPD_DATE     String      �J�ɤ���ɶ�
     * @param UPD_APLY_NO  String      �J�ɮץ�s��
     * @param UPD_TRN_KIND String      �J�ɥ������
     */
    public void deleteDTEPB102(DTEPB102 B102Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {
        ErrorInputException eie = null;
        eie = this.CheckparamDTEPB102(eie, B102Vo);
        if (eie != null) {
            throw eie;
        }
        //�g�@��LOG��
        this.insertLog(B102Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND, true);
        //�R�������ӯ������� DTEPB102�G
        VOTool.delByPK(B102Vo);

    }

    /**
     * �ק﫴��_�ӯ�������
     * @param B102Vo        DTEPB102    ����_�ӯ�������
     * @param UPD_DATE      String      �J�ɤ���ɶ�
     * @param UPD_APLY_NO   String      �J�ɮץ�s��
     * @param UPD_TRN_KIND  String      �J�ɥ������
     */
    public void updateDTEPB102(DTEPB102 B102Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND) throws ModuleException {
        ErrorInputException eie = null;
        eie = this.CheckparamDTEPB102(eie, B102Vo);
        if (eie != null) {
            throw eie;
        }
        //�g�@��LOG��
        this.insertLog(B102Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND, false);
        //�ק﫴���ӯ������� DTEPB102�G
        VOTool.update(B102Vo);

    }

    /**
     * �ק﫴���Ȥ���B  (�妸�@��)
     * @param reqMap Map 
     *                  <pre>
     *                       SUB_CPY_ID �����q�O
     *                       CRT_NO �����N��
     *                       CUS_NO �Ȥ�Ǹ�
     *                       //���ʤH����T
     *                       UPD_TRN_KIND�J�ɥ������
     *                       UPD_DATE�J�ɤ���ɶ�
     *                       UPD_APLY_NO�J�ɮץ�s��
     *                       CHG_DIV_NO���ʳ��
     *                       CHG_ID����ID
     *                       CHG_NAME���ʩm�W
     *                       //�H�U���i�ܧ󤧫���������
     *                       RNT_AMT�믲��
     *                       PMS_AMT ���
     *                       RNT_SIZE �ӯ��W��
     *                       CUS_STS �Ȥ᪬�p
     *                       DCT_TYPE ���ڤ覡
     *                       SLRY_ID���~ID
     *                       NEXT_PAY_DATE�U����ú��
     *                  </pre>
     *                  
     */
    public void updateCUSInfo(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10020_MSG_012");//�����Ȥ��Ƥ��o����
        }
        //�ˮֶǤJ�Ѽ�:
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        Integer CUS_NO = MapUtils.getInteger(reqMap, "CUS_NO");
        if (CUS_NO == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�Ǹ����o���ŭ�
        }
        String UPD_TRN_KIND = MapUtils.getString(reqMap, "UPD_TRN_KIND");
        if (StringUtils.isBlank(UPD_TRN_KIND)) {

            eie = getErrorInputException(eie, "EP_B10020_MSG_013");//�J�ɥ���������o���ŭ�
        }
        String UPD_DATE = MapUtils.getString(reqMap, "UPD_DATE");
        if (StringUtils.isBlank(UPD_DATE)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_014");//�J�ɤ�����o���ŭ�
        }
        String UPD_APLY_NO = MapUtils.getString(reqMap, "UPD_APLY_NO");
        if (StringUtils.isBlank(UPD_APLY_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_015");//�J�ɮץ�s�����o���ŭ�
        }
        String CHG_DIV_NO = MapUtils.getString(reqMap, "CHG_DIV_NO");
        if (StringUtils.isBlank(CHG_DIV_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_016");//���ʳ�줣�o���ŭ�
        }
        String CHG_ID = MapUtils.getString(reqMap, "CHG_ID");
        if (StringUtils.isBlank(CHG_ID)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_017");//����ID���o���ŭ�
        }
        String CHG_NAME = MapUtils.getString(reqMap, "CHG_NAME");
        if (StringUtils.isBlank(CHG_NAME)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_018");//���ʩm�W���o���ŭ�
        }

        //�ˮ֭n���ʪ���줣�i�Ҭ��ŭ�
        BigDecimal RNT_AMT = obj2Big(reqMap, "RNT_AMT");
        BigDecimal PMS_AMT = obj2Big(reqMap, "PMS_AMT");
        BigDecimal RNT_SIZE = obj2Big(reqMap, "RNT_SIZE");
        String CUS_STS = MapUtils.getString(reqMap, "CUS_STS");
        String DCT_TYPE = MapUtils.getString(reqMap, "DCT_TYPE");
        String NEXT_PAY_DATE = MapUtils.getString(reqMap, "NEXT_PAY_DATE");
        String SLRY_ID = MapUtils.getString(reqMap, "SLRY_ID");
        if (RNT_AMT == null && PMS_AMT == null && RNT_SIZE == null && StringUtils.isBlank(CUS_STS) && StringUtils.isBlank(DCT_TYPE)
                && StringUtils.isBlank(NEXT_PAY_DATE)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_019");//�n��s�������ӯ�������즳�~�A�Ҭ��ŭ�
        } else {
            if (StringUtils.isNotBlank(DCT_TYPE) && !"1".equals(DCT_TYPE) && !"2".equals(DCT_TYPE) && !"N".equals(DCT_TYPE)) {
                eie = getErrorInputException(eie, "EP_B10020_MSG_020");//���ڤ覡�榡���~
            } else if ("2".equals(DCT_TYPE) && StringUtils.isBlank(SLRY_ID)) {
                eie = getErrorInputException(eie, "EP_B10020_MSG_021");//���~ID��������
            }
            if (StringUtils.isNotBlank(CUS_STS) && !"0".equals(CUS_STS) && !"1".equals(CUS_STS) && !"2".equals(CUS_STS)
                    && !"3".equals(CUS_STS)) {
                eie = getErrorInputException(eie, "EP_B10020_MSG_022");//�Ȥ᪬�p�榡���~
            }
        }
        if (eie != null) {
            throw eie;
        }

        //�����ӯ���Ȧs���
        Map B102Map = new HashMap();
        B102Map.put("SUB_CPY_ID", SUB_CPY_ID);
        B102Map.put("CRT_NO", CRT_NO);
        B102Map.put("CUS_NO", CUS_NO);
        DTEPB303 B303Vo = VOTool.mapToVO(DTEPB303.class, this.queryMap(B102Map));

        if (RNT_AMT != null) {
            B303Vo.setRNT_AMT(RNT_AMT);
        }
        if (PMS_AMT != null) {
            B303Vo.setPMS_AMT(PMS_AMT);
        }
        if (RNT_SIZE != null) {
            B303Vo.setRNT_SIZE(RNT_SIZE);
        }
        if (StringUtils.isNotBlank(CUS_STS)) {
            B303Vo.setCUS_STS(CUS_STS);
        }
        if (StringUtils.isNotEmpty(NEXT_PAY_DATE)) {
            B303Vo.setNEXT_PAY_DATE(java.sql.Date.valueOf(NEXT_PAY_DATE));
        }

        if ("N".equals(DCT_TYPE)) {
            B303Vo.setDCT_TYPE(null);
            B303Vo.setSLRY_ID(null);
        } else if ("1".equals(DCT_TYPE)) {
            B303Vo.setDCT_TYPE("1");
            B303Vo.setSLRY_ID(null);
        } else if ("2".equals(DCT_TYPE)) {
            B303Vo.setDCT_TYPE("2");
            B303Vo.setSLRY_ID(SLRY_ID);

        }
        B303Vo.setAPLY_NO(UPD_APLY_NO);
        B303Vo.setDATA_TYPE("A");
        this.insertDTEPB303(B303Vo, "U", null); //�@�~���� U �ק�
        //��s�����ӯ�����
        //�g�@��LOG��
        DTEPB102 B102Vo = new DTEPB102();
        B102Vo.setSUB_CPY_ID(SUB_CPY_ID);
        B102Vo.setCRT_NO(CRT_NO);
        B102Vo.setCUS_NO(CUS_NO);
        this.insertLog(B102Vo, UPD_DATE, UPD_APLY_NO, UPD_TRN_KIND, false);

        //�ק﫴���򥻸���� DTEPB102�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("UPD_DATE", UPD_DATE);
        ds.setField("CHG_DIV_NO", CHG_DIV_NO);
        ds.setField("CHG_ID", CHG_ID);
        ds.setField("CHG_NAME", CHG_NAME);
        ds.setField("UPD_APLY_NO", UPD_APLY_NO);
        ds.setField("UPD_TRN_KIND", UPD_TRN_KIND);

        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (RNT_AMT != null) {
            ds.setField("RNT_AMT", RNT_AMT);
        }
        if (PMS_AMT != null) {
            ds.setField("PMS_AMT", PMS_AMT);
        }
        if (RNT_SIZE != null) {
            ds.setField("RNT_SIZE", RNT_SIZE);
        }
        if (StringUtils.isNotEmpty(CUS_STS)) {
            ds.setField("CUS_STS", CUS_STS);
        }
        if (StringUtils.isNotEmpty(NEXT_PAY_DATE)) {
            ds.setField("NEXT_PAY_DATE", NEXT_PAY_DATE);
        }
        if ("N".equals(DCT_TYPE)) {
            ds.setField("DCT_TYPE", null);
            ds.setField("SLRY_ID", null);
        } else if ("1".equals(DCT_TYPE)) {
            ds.setField("DCT_TYPE", "1");
            ds.setField("SLRY_ID", null);
        } else if ("2".equals(DCT_TYPE)) {
            ds.setField("DCT_TYPE", "2");
            if (StringUtils.isNotBlank(SLRY_ID)) {
                ds.setField("SLRY_ID", SLRY_ID);
            }
        }
        DBUtil.executeUpdate(ds, SQL_updateCUSInfo_001);
    }

    /**
     * �^�_�Ȥ���
     * @param reqMap Map
     *          <pre>
     *               SUB_CPY_ID�����q�O
     *               CRT_NO �����N��
     *               CUS_NO �Ȥ�Ǹ�
     *               UPD_TRN_KIND�J�ɥ������
     *               UPD_DATE�J�ɤ���ɶ�
     *               UPD_APLY_NO�J�ɮץ�s��
     *          </pre>
     * @param user  userObject  �ϥΪ̸�T
     */
    public void recoverCUSInfo(Map reqMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_032");//�ϥΪ̸�T���o����
        }
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10020_MSG_012");//�����Ȥ��Ƥ��o����
        }
        //�ˮֶǤJ�Ѽ�:
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        Integer CUS_NO = MapUtils.getInteger(reqMap, "CUS_NO");
        if (CUS_NO == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�Ǹ����o���ŭ�
        }
        String UPD_TRN_KIND = MapUtils.getString(reqMap, "UPD_TRN_KIND");
        if (StringUtils.isBlank(UPD_TRN_KIND)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_013");//�J�ɥ���������o���ŭ�
        } else if (!"EPC204".equals(UPD_TRN_KIND) && !"EPC205".equals(UPD_TRN_KIND)) {
            //�ثe�u���\���: EPC204�o���@�o, EPC205�@�o���X�b���^�_, ���`�N�Y����L�Ȧs�ɲ��ʫh���i���P�ץ�s���D��, �ݥ[�ˮ�)
            eie = getErrorInputException(eie, "EP_B10020_MSG_033");//����������~
        }

        String UPD_DATE = MapUtils.getString(reqMap, "UPD_DATE");
        if (StringUtils.isBlank(UPD_DATE)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_014");//�J�ɤ�����o���ŭ�
        }
        String UPD_APLY_NO = MapUtils.getString(reqMap, "UPD_APLY_NO");
        if (StringUtils.isBlank(UPD_APLY_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_015");//�J�ɮץ�s�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�d�ߩӯ����ƨ��ˮ֥D�ɪ��A
        HashMap B102Map = new HashMap();
        B102Map.put("SUB_CPY_ID", SUB_CPY_ID);
        B102Map.put("CRT_NO", CRT_NO);
        B102Map.put("CUS_NO", CUS_NO);
        Map cusMap = this.queryMap(B102Map);

        if (!UPD_TRN_KIND.equals(MapUtils.getString(cusMap, "TRN_KIND")) || !UPD_DATE.equals(MapUtils.getString(cusMap, "CHG_DATE"))
                || !UPD_APLY_NO.equals(MapUtils.getString(cusMap, "APLY_NO"))) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_B10020_MSG_034", new Object[] { CRT_NO, CUS_NO }));//������:{0} �Ȥ�Ǹ�:{1} ��Ƥw���ʡA���o����!
        }
        //���o�^�_���
        DTEPB102_LOG B102Log = new DTEPB102_LOG();
        B102Log.setUPD_DATE(DATE.toTimestamp(UPD_DATE));
        B102Log.setSUB_CPY_ID(SUB_CPY_ID);
        B102Log.setCRT_NO(CRT_NO);
        B102Log.setCUS_NO(CUS_NO);
        B102Log = VOTool.findByPKWithUR(B102Log);

        //�^�_�����ӯ�����
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", B102Log.getCRT_NO());
        ds.setField("CUS_NO", B102Log.getCUS_NO());
        ds.setField("CUS_NAME", B102Log.getCUS_NAME());
        ds.setField("ID", B102Log.getID());
        ds.setField("JOB_TYPE", B102Log.getJOB_TYPE());
        ds.setField("RNT_TYPE", B102Log.getRNT_TYPE());
        ds.setField("RNT_STR_DATE", B102Log.getRNT_STR_DATE());
        ds.setField("RNT_END_DATE", B102Log.getRNT_END_DATE());
        ds.setField("PMS_TYPE", B102Log.getPMS_TYPE());
        ds.setField("RNT_SIZE", B102Log.getRNT_SIZE());
        ds.setField("RNT_AMT", B102Log.getRNT_AMT());
        ds.setField("PMS_AMT", B102Log.getPMS_AMT());
        ds.setField("NEXT_PAY_DATE", B102Log.getNEXT_PAY_DATE());
        ds.setField("CUS_STS", B102Log.getCUS_STS());
        ds.setField("DCT_TYPE", B102Log.getDCT_TYPE());
        ds.setField("SLRY_ID", B102Log.getSLRY_ID());
        ds.setField("ADJ_KIND", B102Log.getADJ_KIND());
        ds.setField("MON_BRK", B102Log.getMON_BRK());
        ds.setField("MON_BRK_EDATE", B102Log.getMON_BRK_EDATE());
        ds.setField("ORG_RNT_AMT", B102Log.getORG_RNT_AMT());
        ds.setField("ACPT_BANK_NO", B102Log.getACPT_BANK_NO());
        ds.setField("ACPT_ACNT_NO", B102Log.getACPT_ACNT_NO());
        ds.setField("CUS_ID", B102Log.getCUS_ID());
        ds.setField("BOSS_NAME", B102Log.getBOSS_NAME());
        ds.setField("COMP_ZIP_CODE", B102Log.getCOMP_ZIP_CODE());
        ds.setField("COMP_ADDR", B102Log.getCOMP_ADDR());
        ds.setField("CONT_NAME", B102Log.getCONT_NAME());
        ds.setField("CONT_MOBIL_NO", B102Log.getCONT_MOBIL_NO());
        ds.setField("TEL_AREA", B102Log.getTEL_AREA());
        ds.setField("TEL", B102Log.getTEL());
        ds.setField("TEL_EXT", B102Log.getTEL_EXT());
        ds.setField("CONT_ZIP_CODE", B102Log.getCONT_ZIP_CODE());
        ds.setField("CONT_ADDR", B102Log.getCONT_ADDR());
        ds.setField("CUS_EMAIL", B102Log.getCUS_EMAIL());
        ds.setField("FILE_NO", B102Log.getFILE_NO());
        ds.setField("MEMO", B102Log.getMEMO());
        ds.setField("CONT_CHG_ID", B102Log.getCONT_CHG_ID());
        ds.setField("CONT_CHG_NAME", B102Log.getCONT_CHG_NAME());
        ds.setField("CONT_CHG_DATE", B102Log.getCONT_CHG_DATE());
        ds.setField("CONT_CHG_APLYNO", B102Log.getCONT_CHG_APLYNO());
        ds.setField("RNT_CHG_ID", B102Log.getRNT_CHG_ID());
        ds.setField("RNT_CHG_NAME", B102Log.getRNT_CHG_NAME());
        ds.setField("RNT_CHG_DATE", B102Log.getRNT_CHG_DATE());
        ds.setField("RNT_CHG_APLYNO", B102Log.getRNT_CHG_APLYNO());
        ds.setField("RNT_CHG_TRNKD", B102Log.getRNT_CHG_TRNKD());
        ds.setField("CHG_DATE", B102Log.getCHG_DATE());
        ds.setField("CHG_DIV_NO", B102Log.getCHG_DIV_NO());
        ds.setField("CHG_ID", B102Log.getCHG_ID());
        ds.setField("CHG_NAME", B102Log.getCHG_NAME());
        ds.setField("APLY_NO", B102Log.getAPLY_NO());
        ds.setField("TRN_KIND", B102Log.getTRN_KIND());
        DBUtil.executeUpdate(ds, SQL_recoverCUSInfo_001);

        //�R���ӵ�LOG����
        VOTool.delByPK(B102Log);
        //��s�ץ���������P
        ds.clear();
        ds.setField("APLY_NO", UPD_APLY_NO);
        ds.setField("LST_PROC_DATE", DATE.currentTime());
        ds.setField("LST_PROC_ID", user.getEmpID());
        ds.setField("LST_PROC_DIV", user.getOpUnit());
        ds.setField("LST_PROC_NAME", user.getEmpName());
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        DBUtil.executeUpdate(ds, SQL_recoverCUSInfo_002);
    }

    /**
     * �s�W����_�ӯ�����LOG��
     * @param B102Vo       DTEPA102    ����_�ӯ�������
     * @param UPD_DATE     String      �J�ɤ���ɶ�
     * @param UPD_APLY_NO  String      �J�ɮץ�s��
     * @param UPD_TRN_KIND String      �J�ɥ������
     * @param isDelete     boolean     �O�_�R��
     */
    public void insertLog(DTEPB102 B102Vo, String UPD_DATE, String UPD_APLY_NO, String UPD_TRN_KIND, boolean isDelete)
            throws ModuleException {

        //�g�@��LOG��
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", B102Vo.getSUB_CPY_ID());
        reqMap.put("CRT_NO", B102Vo.getCRT_NO());
        reqMap.put("CUS_NO", B102Vo.getCUS_NO());
        DTEPB102_LOG B102Vo_Log = VOTool.mapToVO(DTEPB102_LOG.class, this.queryMap(reqMap));
        B102Vo_Log.setUPD_DATE(DATE.toTimestamp(UPD_DATE));
        B102Vo_Log.setUPD_APLY_NO(UPD_APLY_NO);
        B102Vo_Log.setUPD_TRN_KIND(UPD_TRN_KIND);
        VOTool.insert(B102Vo_Log);

    }

    /**
     * �s�W�ץ�ӯ�������
     * @param B303Vo     DTEPB303    �ץ�_�����ӯ�������
     * @param OPR_KIND   String      �@�~����    �u�i�� I�s�W, D�R��, U�ק�
     * @param TAX_TYPE   String      �|�O
     */
    public void insertDTEPB303(DTEPB303 B303Vo, String OPR_KIND, String TAX_TYPE) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(OPR_KIND)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_024");//�@�~�������o���ŭ�
        }
        if (B303Vo == null) {
            throw getErrorInputException(eie, "EP_B10020_MSG_011");//����_�ӯ������ɤ��o����
        }
        String SUB_CPY_ID = B303Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String APLY_NO = B303Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_025");//�ץ�s�����o���ŭ�
        }
        String DATA_TYPE = B303Vo.getDATA_TYPE();
        if (StringUtils.isBlank(DATA_TYPE)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_028");//����������o���ŭ�
        }
        String CRT_NO = B303Vo.getCRT_NO();
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        Integer CUS_NO = B303Vo.getCUS_NO();
        if (CUS_NO == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�Ǹ����o���ŭ�
        }

        if (!"I".equals(OPR_KIND) && !"D".equals(OPR_KIND) && !"U".equals(OPR_KIND)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_026");//�ǤJ�@�~�������~
        }
        if (eie != null) {
            throw eie;
        }
        int APLY_SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "009", APLY_NO, "APLY_NO");
        //�s�W�ץ�_�����ӯ�������DTEPB303�G
        B303Vo.setAPLY_SER_NO(APLY_SER_NO);
        if ("I".equals(B303Vo.getDATA_TYPE())) {
            BigDecimal RNT_AMT = B303Vo.getRNT_AMT();
            B303Vo.setORG_RNT_AMT(getORG_RNT_AMT(TAX_TYPE, RNT_AMT));
        } else if ("A".equals(B303Vo.getDATA_TYPE())
                && StringUtils.isNotEmpty(TAX_TYPE)
                && (B303Vo.getRNT_STR_DATE() != null && DATE.diffDay(B303Vo.getRNT_STR_DATE(), Date.valueOf(DATE.getMonthFirstDate())) <= 0)) {
            //�������_��>=����멳��, ��l������۲���, �H�K�Y�믲��KEY���L�k�ץ�
            BigDecimal RNT_AMT = B303Vo.getRNT_AMT();
            B303Vo.setORG_RNT_AMT(getORG_RNT_AMT(TAX_TYPE, RNT_AMT));
        }
        VOTool.insert(B303Vo);
        if ("U".equals(OPR_KIND)) {
            //�ק�ɼW�[2����ơA�@�����ʫeB(�d�D�ɸ�T)�A�@�����ʫ�A(�ǤJ)

            //�s�W���ʫe��T:�d�ߥD�ɸ��
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
            reqMap.put("CRT_NO", CRT_NO);
            reqMap.put("CUS_NO", CUS_NO);

            DTEPB303 B303Vo_B = VOTool.mapToVO(DTEPB303.class, this.queryMap(reqMap));
            B303Vo_B.setAPLY_NO(APLY_NO);
            B303Vo_B.setAPLY_SER_NO(APLY_SER_NO);
            B303Vo_B.setDATA_TYPE("B");
            VOTool.insert(B303Vo_B);
        }

    }

    /**
     * �R���ץ�ӯ�������
     * @param B303Vo DTEPB303    �ץ�_�����ӯ�������
     */
    public void deleteDTEPB303(DTEPB303 B303Vo) throws ModuleException {
        ErrorInputException eie = null;
        eie = this.CheckparamDTEPB303(eie, B303Vo);
        String DATA_TYPE = B303Vo.getDATA_TYPE();
        if (StringUtils.isBlank(DATA_TYPE)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_028");//����������o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }
        //�R���ץ�_�����ӯ�������DTEPB303�G
        VOTool.delByPK(B303Vo);
        //�Y�������A�ɶ��NB�]�@�֧R��
        if ("A".equals(DATA_TYPE)) {
            B303Vo.setDATA_TYPE("B");
            VOTool.delByPK(B303Vo);
        }

    }

    /**
     * �ק�ץ�ӯ�������
     * @param B303Vo DTEPB303  �ץ�_�����ӯ�������
     */
    public void updateDTEPB303(DTEPB303 B303Vo) throws ModuleException {
        ErrorInputException eie = null;
        eie = this.CheckparamDTEPB303(eie, B303Vo);
        String DATA_TYPE = B303Vo.getDATA_TYPE();
        if (StringUtils.isBlank(DATA_TYPE)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_028");//����������o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�ק�ץ�_�����ӯ�������DTEPB303�G
        VOTool.update(B303Vo);

    }

    /**
     * �P�_�����ӯ����ƬO�_����
     * @param B102Vo   DTEPB102    ����_�ӯ�������
     * @param B102Vo_Log  DTEPB102_LOG    ����_�ӯ�������LOG
     * @return  isDiff  boolean �O�_�t��
     */
    public boolean checkIsDiff(DTEPB102 B102Vo, DTEPB102_LOG B102Vo_Log) throws ErrorInputException {
        ErrorInputException eie = null;
        if (B102Vo == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_011");//����_�ӯ������ɤ��o����
        }
        if (B102Vo_Log == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_027");//����_�ӯ�������LOG���o����
        }
        if (eie != null) {
            throw eie;
        }
        if (!StringUtils.equals(B102Vo_Log.getCUS_NAME(), B102Vo.getCUS_NAME()) || !StringUtils.equals(B102Vo_Log.getID(), B102Vo.getID())
                || !StringUtils.equals(B102Vo_Log.getJOB_TYPE(), B102Vo.getJOB_TYPE())
                || !StringUtils.equals(B102Vo_Log.getRNT_TYPE(), B102Vo.getRNT_TYPE())
                || !voValcompare(B102Vo_Log.getRNT_STR_DATE(), B102Vo.getRNT_STR_DATE())
                || !voValcompare(B102Vo_Log.getRNT_END_DATE(), B102Vo.getRNT_END_DATE())
                || !StringUtils.equals(B102Vo_Log.getPMS_TYPE(), B102Vo.getPMS_TYPE())
                || !voValcompare(B102Vo_Log.getRNT_SIZE(), B102Vo.getRNT_SIZE())
                || !voValcompare(B102Vo_Log.getRNT_AMT(), B102Vo.getRNT_AMT())
                || !voValcompare(B102Vo_Log.getPMS_AMT(), B102Vo.getPMS_AMT())
                || !voValcompare(B102Vo_Log.getNEXT_PAY_DATE(), B102Vo.getNEXT_PAY_DATE())
                || !StringUtils.equals(B102Vo_Log.getCUS_STS(), B102Vo.getCUS_STS())
                || !StringUtils.equals(B102Vo_Log.getDCT_TYPE(), B102Vo.getDCT_TYPE())
                || !StringUtils.equals(B102Vo_Log.getADJ_KIND(), B102Vo.getADJ_KIND())
                || !StringUtils.equals(B102Vo_Log.getMON_BRK(), B102Vo.getMON_BRK())
                || !voValcompare(B102Vo_Log.getMON_BRK_EDATE(), B102Vo.getMON_BRK_EDATE())
                || !voValcompare(B102Vo_Log.getORG_RNT_AMT(), B102Vo.getORG_RNT_AMT())
                || !StringUtils.equals(B102Vo_Log.getCUS_ID(), B102Vo.getCUS_ID())
                || !StringUtils.equals(B102Vo_Log.getBOSS_NAME(), B102Vo.getBOSS_NAME())
                || !StringUtils.equals(B102Vo_Log.getCOMP_ZIP_CODE(), B102Vo.getCOMP_ZIP_CODE())
                || !StringUtils.equals(B102Vo_Log.getCOMP_ADDR(), B102Vo.getCOMP_ADDR())
                || !StringUtils.equals(B102Vo_Log.getCONT_NAME(), B102Vo.getCONT_NAME())
                || !StringUtils.equals(B102Vo_Log.getCONT_MOBIL_NO(), B102Vo.getCONT_MOBIL_NO())
                || !StringUtils.equals(B102Vo_Log.getTEL_AREA(), B102Vo.getTEL_AREA())
                || !StringUtils.equals(B102Vo_Log.getTEL(), B102Vo.getTEL())
                || !StringUtils.equals(B102Vo_Log.getTEL_EXT(), B102Vo.getTEL_EXT())
                || !StringUtils.equals(B102Vo_Log.getCONT_ZIP_CODE(), B102Vo.getCONT_ZIP_CODE())
                || !StringUtils.equals(B102Vo_Log.getCONT_ADDR(), B102Vo.getCONT_ADDR())
                || !StringUtils.equals(B102Vo_Log.getMEMO(), B102Vo.getMEMO())
                || !StringUtils.equals(B102Vo_Log.getFILE_NO(), B102Vo.getFILE_NO())
                || !StringUtils.equals(B102Vo_Log.getSUB_CPY_ID(), B102Vo.getSUB_CPY_ID())) {
            return true;
        }
        return false;
    }

    /**
     * �ק�
     * @param B303Vo   DTEPB303    �ץ�_�����ӯ�����
     * @param BLD_CD   String  �j�ӥN��
     * @throws ModuleException
     */
    public void update(DTEPB303 B303Vo, String BLD_CD, String TAX_TYPE) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_008");//�j�ӥN�����o���ŭ�
        }
        if (B303Vo == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_011");//����_�ӯ������ɤ��o����
            throw eie;
        }
        String SUB_CPY_ID = B303Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String APLY_NO = B303Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_025");//�ץ�s�����o���ŭ�
        }
        String CRT_NO = B303Vo.getCRT_NO();
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }

        if (B303Vo.getCUS_NO() == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�Ǹ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        this.insertDTEPB303(B303Vo, "U", TAX_TYPE); //�ާ@���� U �ק�
        //��s�ץ��ܧ�����j�ӤΫ�����T
        DTEPB301 B301VO = new DTEPB301();
        B301VO.setAPLY_NO(B303Vo.getAPLY_NO());
        B301VO.setCRT_NO(B303Vo.getCRT_NO());
        B301VO.setBLD_CD(BLD_CD);
        B301VO.setSUB_CPY_ID(SUB_CPY_ID);
        new EP_B30010().updateDTEPB301MainInfo(B301VO);

    }

    /**
     * �s�W
     * @param B303Vo  DTEPB303    �ץ�_�����ӯ�����
     * @param BLD_CD   String  �j�ӥN��
     * @param TAX_TYPE String  �|�O     
     * @throws ModuleException
     */
    public void insert(DTEPB303 B303Vo, String BLD_CD, String TAX_TYPE) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_008");//�j�ӥN�����o���ŭ�
        }
        if (B303Vo == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_011");//����_�ӯ������ɤ��o����
            throw eie;
        }
        String SUB_CPY_ID = B303Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String APLY_NO = B303Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_025");//�ץ�s�����o���ŭ�
        }
        String CRT_NO = B303Vo.getCRT_NO();
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        if (B303Vo.getCUS_NO() == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�Ǹ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        this.insertDTEPB303(B303Vo, "I", TAX_TYPE); //�ާ@���� I �s�W
        //��s�ץ��ܧ�����j�ӤΫ�����T
        DTEPB301 B301VO = new DTEPB301();
        B301VO.setAPLY_NO(B303Vo.getAPLY_NO());
        B301VO.setCRT_NO(B303Vo.getCRT_NO());
        B301VO.setBLD_CD(BLD_CD);
        B301VO.setSUB_CPY_ID(SUB_CPY_ID);
        new EP_B30010().updateDTEPB301MainInfo(B301VO);

    }

    /**
     * �R��
     * @param B303Vo  DTEPB303    �ץ�_�����ӯ�����
     * @param BLD_CD   String  �j�ӥN��
     */
    public void delete(DTEPB303 B303Vo, String BLD_CD) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_008");//�j�ӥN�����o���ŭ�
        }
        if (B303Vo == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_011");//����_�ӯ������ɤ��o����
            throw eie;
        }
        String SUB_CPY_ID = B303Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String APLY_NO = B303Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_025");//�ץ�s�����o���ŭ�
        }
        String CRT_NO = B303Vo.getCRT_NO();
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }

        if (B303Vo.getCUS_NO() == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�Ǹ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        this.insertDTEPB303(B303Vo, "D", null); //�ާ@���� D �R��
        //��s�ץ��ܧ�����j�ӤΫ�����T
        DTEPB301 B301VO = new DTEPB301();
        B301VO.setAPLY_NO(B303Vo.getAPLY_NO());
        B301VO.setCRT_NO(B303Vo.getCRT_NO());
        B301VO.setBLD_CD(BLD_CD);
        B301VO.setSUB_CPY_ID(SUB_CPY_ID);
        new EP_B30010().updateDTEPB301MainInfo(B301VO);

    }

    /**
     * �վ�
     * @param B303Vo    �ץ�_�����ӯ�����
     * @param BLD_CD    �j�ӥN��
     * @param TAX_TYPE  �|�O
     */
    public void change(DTEPB303 B303Vo, String BLD_CD, String TAX_TYPE) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_008");//�j�ӥN�����o���ŭ�
        }
        if (B303Vo == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_011");//����_�ӯ������ɤ��o����
            throw eie;
        }
        String SUB_CPY_ID = B303Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String APLY_NO = B303Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_025");//�ץ�s�����o���ŭ�
        }
        String CRT_NO = B303Vo.getCRT_NO();
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }

        if (B303Vo.getCUS_NO() == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�Ǹ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        if ("I".equals(B303Vo.getDATA_TYPE())) {
            B303Vo.setORG_RNT_AMT(getORG_RNT_AMT(TAX_TYPE, B303Vo.getRNT_AMT()));
        } else if ("A".equals(B303Vo.getDATA_TYPE())
                && StringUtils.isNotEmpty(TAX_TYPE)
                && (B303Vo.getRNT_STR_DATE() != null && DATE.diffDay(B303Vo.getRNT_STR_DATE(), Date.valueOf(DATE.getMonthFirstDate())) <= 0)) {
            //�������_��>=����멳��, ��l������۲���, �H�K�Y�믲��KEY���L�k�ץ�
            B303Vo.setORG_RNT_AMT(getORG_RNT_AMT(TAX_TYPE, B303Vo.getRNT_AMT()));
        }

        this.updateDTEPB303(B303Vo);
        //��s�ץ��ܧ�����j�ӤΫ�����T
        DTEPB301 B301VO = new DTEPB301();
        B301VO.setAPLY_NO(B303Vo.getAPLY_NO());
        B301VO.setCRT_NO(B303Vo.getCRT_NO());
        B301VO.setBLD_CD(BLD_CD);
        B301VO.setSUB_CPY_ID(SUB_CPY_ID);
        new EP_B30010().updateDTEPB301MainInfo(B301VO);
    }

    /**
     * �ӯ����Ю֤J�D��
     * @param B301Vo DTEPB301    (DTEPB301���)
     *                  <pre>
     *                  SUB_CPY_ID �����q�O
     *                  APLY_NO �ץ�s��
     *                  CRT_NO�����N��
     *                  BLD_CD�j�ӥN��
     *                  TRN_KIND �������
     *                  INPUT_DIV_NO ��J�H�����
     *                  INPUT_NAME��J�H���m�W
     *                  INPUT_ID��J�H��ID
     *                  </pre>
     * @param UPD_TIME  Timestamp   ��s����ɶ�
     */
    public void approve(DTEPB301 B301Vo, Timestamp UPD_TIME) throws ModuleException {
        ErrorInputException eie = null;
        if (UPD_TIME == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_035");//��s����ɶ����o����
        }
        if (B301Vo == null) {
            throw getErrorInputException(eie, "EP_B10020_MSG_036");//�ץ��ܧ��������ɤ��o����
        }
        String SUB_CPY_ID = B301Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String APLY_NO = B301Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_025");//�ץ�s�����o���ŭ�
        }
        String CRT_NO = B301Vo.getCRT_NO();
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        String BLD_CD = B301Vo.getBLD_CD();
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_008");//�j�ӥN�����o���ŭ�
        }
        String TRN_KIND = B301Vo.getTRN_KIND();
        if (StringUtils.isBlank(TRN_KIND)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_037");//����������o���ŭ�
        }
        String INPUT_DIV_NO = B301Vo.getINPUT_DIV_NO();
        if (StringUtils.isBlank(INPUT_DIV_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_038");//��J�H����줣�o���ŭ�
        }
        String INPUT_NAME = B301Vo.getINPUT_NAME();
        if (StringUtils.isBlank(INPUT_NAME)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_039");//��J�H���m�W���o���ŭ�
        }
        String INPUT_ID = B301Vo.getINPUT_ID();
        if (StringUtils.isBlank(INPUT_ID)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_040");//��J�H�����o���ŭ�
        }

        if (eie != null) {
            throw eie;
        }
        //�d�߲��ʩ���.
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        reqMap.put("APLY_NO", APLY_NO);//�ץ�s��
        reqMap.put("CRT_NO", CRT_NO);//�����N��

        List<Map> rtnList = this.queryList(reqMap);
        String UPD_TIMEstr = UPD_TIME.toString();
        //�v���B�z���ʩ���
        for (Map rtnMap : rtnList) {
            String DATA_TYPE = MapUtils.getString(rtnMap, "DATA_TYPE");
            if (!"B".equals(DATA_TYPE)) { //Before ����Ƥ����B�z
                DTEPB102 B102Vo = VOTool.mapToVO(DTEPB102.class, rtnMap);
                B102Vo.setCHG_DATE(UPD_TIME);
                B102Vo.setCHG_DIV_NO(INPUT_DIV_NO);
                B102Vo.setCHG_ID(INPUT_ID);
                B102Vo.setCHG_NAME(INPUT_NAME);
                B102Vo.setAPLY_NO(APLY_NO);
                B102Vo.setTRN_KIND(TRN_KIND);
                B102Vo.setRNT_CHG_ID(INPUT_ID);
                B102Vo.setRNT_CHG_NAME(INPUT_NAME);
                B102Vo.setRNT_CHG_DATE(UPD_TIME);
                B102Vo.setRNT_CHG_APLYNO(APLY_NO);
                B102Vo.setRNT_CHG_TRNKD(TRN_KIND);
                if ("I".equals(DATA_TYPE)) {
                    this.insertDTEPB102(B102Vo, UPD_TIMEstr, APLY_NO, TRN_KIND);
                } else if ("D".equals(DATA_TYPE)) {
                    this.deleteDTEPB102(B102Vo, UPD_TIMEstr, APLY_NO, TRN_KIND);
                } else if ("A".equals(DATA_TYPE)) {
                    this.updateDTEPB102(B102Vo, UPD_TIMEstr, APLY_NO, TRN_KIND);
                }
            }

        }

    }

    /**
     * Ū���浧�Ȧs�ɩӯ���򥻸����
     * @param reqMap Map
     *                  <pre>
     *                      SUB_CPY_ID = �����q�O
     *                      CRT_NO = �����N��
     *                      CUS_NO = �Ȥ�N��                      
     *                  </pre>
     * @return   rtnMap  Map �ӯ���򥻸��
     */
    public Map querytmpMap(Map reqMap) throws ModuleException {

        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10020_MSG_001");//����_�ӯ����Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�N�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);

        return VOTool.findOneToMap(ds, SQL_queryTmpMap_001);
    }

    /**
     * �ˮ֬O�_�]�w�կ��϶�
     * @param reqMap  Map 
     *          <pre>
     *          SUB_CPY_ID = �����q�O
     *          CRT_NO = �����N��
     *          APLY_NO = �ץ�s��
     *          </pre>
     * @throws ModuleException
     */
    public void chkAdjPrd(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10020_MSG_001");//����_�ӯ����Ƥ��o����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_025");//�ץ�s�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //���o�����ɬ��կ�, �����ܧ󬰷s�W�B����>0���ӯ����ƨ��ˮ֬O�_���]�w�կ��϶��H�K���կ��ɭY���]�w�կ��϶��ӵL�k���
        DataSet ds = Transaction.getDataSet();

        ds.setField("APLY_NO", APLY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        DBUtil.searchAndRetrieve(ds, SQL_chkAdjPrd_001, false);
        Set<String> tmpCusArray1 = new HashSet<String>(); //���o�Ȧs�ɫȤ�Ǹ�array
        while (ds.next()) {
            tmpCusArray1.add(String.valueOf(ds.getField("CUS_NO")));
        }
        if (tmpCusArray1.isEmpty()) {
            return;//�Y�L��Ƥ������~
        }

        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        ds.setFieldValues("tmpCusArray1", tmpCusArray1.toArray());
        DBUtil.searchAndRetrieve(ds, SQL_chkAdjPrd_002, false);
        // �YmainAdjList���ŭȫh��X���~�T�� ���Х��]�w���������կ��϶��A�Ȥ�Ǹ��G�� + tmpCusArray2
        Set<String> mainAdjSet = new HashSet<String>();
        while (ds.next()) {
            mainAdjSet.add(String.valueOf(ds.getField("CUS_NO")));
        }
        if (mainAdjSet.isEmpty()) {
            throw new ModuleException(MessageUtil.getMessage("EP_B10100_MSG_035", new Object[] { tmpCusArray1 }));
            //�Х��]�w���������կ��϶��A�Ȥ�Ǹ��G{0}   {0}:tmpCusArray2
        }

        Set<String> tmpCusArray2 = new HashSet<String>();
        for (String cusArray1 : tmpCusArray1) {
            if (!mainAdjSet.contains(cusArray1)) {
                tmpCusArray2.add(cusArray1);
            }
        }
        if (tmpCusArray2.isEmpty()) {
            return;
        }
        throw new ModuleException(MessageUtil.getMessage("EP_B10100_MSG_035", new Object[] { tmpCusArray2 }));
        //�Х��]�w���������կ��϶��A�Ȥ�Ǹ��G{0}   {0}:tmpCusArray3

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * ���Ȥ~�]�ܼ�
     * @param ds
     * @param key
     * @param value
     */
    private void setfieldIfExist(DataSet ds, Map reqMap, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * �ˮֶǤJ�Ѽ� DTEPB102 B102Vo  
     * @param B102Vo DTEPB102
     */
    private ErrorInputException CheckparamDTEPB102(ErrorInputException eie, DTEPB102 B102Vo) throws ErrorInputException {
        if (B102Vo == null) {
            throw getErrorInputException(eie, "EP_B10020_MSG_011");//����_�ӯ����Ƥ��o����
        }
        String SUB_CPY_ID = B102Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String CRT_NO = B102Vo.getCRT_NO();
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        Integer CUS_NO = B102Vo.getCUS_NO();
        if (CUS_NO == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�Ǹ����o���ŭ�
        }
        return eie;
    }

    /**
     * �ˮֶǤJ�Ѽ� DTEPB303 B303Vo  ��������
     * @param eie
     * @param B303Vo
     * @return
     */
    private ErrorInputException CheckparamDTEPB303(ErrorInputException eie, DTEPB303 B303Vo) throws ErrorInputException {
        if (B303Vo == null) {
            throw getErrorInputException(eie, "EP_B10020_MSG_011");//����_�ӯ������ɤ��o����
        }
        String SUB_CPY_ID = B303Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�
        }
        String APLY_NO = B303Vo.getAPLY_NO();
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_025");//�ץ�s�����o���ŭ�
        }
        String CRT_NO = B303Vo.getCRT_NO();
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_002");//�����N�����o���ŭ�
        }
        if (B303Vo.getCUS_NO() == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_003");//�Ȥ�Ǹ����o���ŭ�
        }
        Integer APLY_SER_NO = B303Vo.getAPLY_SER_NO();
        if (APLY_SER_NO == null) {
            eie = getErrorInputException(eie, "EP_B10020_MSG_029");//�ץ�Ǹ����o���ŭ�
        }
        return eie;

    }

    /**
     * VO ����ȬO�_�۵�
     * @param A101Vo_val
     * @param A101Vo_Log_val
     * @return
     */
    private boolean voValcompare(Object B102Vo_Log_val, Object B102Vo_val) {

        if (B102Vo_val == null) {
            if (B102Vo_Log_val == null) {
                return true;
            }
        } else {
            if (B102Vo_Log_val != null) {
                if (B102Vo_val instanceof BigDecimal && B102Vo_Log_val instanceof BigDecimal) {
                    return ((BigDecimal) B102Vo_val).compareTo((BigDecimal) B102Vo_Log_val) == 0;
                }
                if (B102Vo_val instanceof Date && B102Vo_Log_val instanceof Date) {
                    return ((Date) B102Vo_val).compareTo((Date) B102Vo_Log_val) == 0;
                }
            }
        }
        return false;
    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param o
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key) {
        Object o = MapUtils.getObject(map, key);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            }
            String ostr = o.toString();
            if (NumberUtils.isNumber(ostr)) {
                return new BigDecimal(ostr);
            }
        }
        return null;
    }

    /**
     * �ھ�MAP key �å[�P�_�O�_�[�N�X�A�^�Ǩ��o����
     * @param rtnMap
     * @param key
     * @param Field_key
     * @param addcode
     * @param sb
     * @return
     */
    private String getNM(Map rtnMap, String key, String Field_key, boolean addcode, StringBuilder sb) {
        String value = MapUtils.getString(rtnMap, key, "");
        if (addcode) {
            String CODE_NM = sb.append(value).append(FieldOptionList.getName("EP", Field_key, value)).toString();
            sb.setLength(0);
            return CODE_NM;
        }
        return FieldOptionList.getName("EP", Field_key, value);
    }

    /**
     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getDecimal(Object obj) {
        if (obj == null) {
            return BigDecimal.ZERO;
        }
        if (BigDecimal.class.isInstance(obj)) {
            return (BigDecimal) obj;
        }
        return new BigDecimal(String.valueOf(obj));
    }

    /**
     * ���o��l����
     * @param TAX_TYPE
     * @param RNT_AMT
     * @return
     */
    private BigDecimal getORG_RNT_AMT(String TAX_TYPE, BigDecimal RNT_AMT) {
        if (RNT_AMT != null) {
            if ("1".equals(TAX_TYPE)) {
                RNT_AMT = RNT_AMT.divide(new BigDecimal("1.05"), 0, BigDecimal.ROUND_HALF_UP);
            }
        }
        return RNT_AMT;
    }
}
