package com.cathay.ep.b1.module;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.vo.DTEPA101;
import com.cathay.ep.vo.DTEPB102;
import com.cathay.ep.vo.DTEPB103;
import com.cathay.ep.vo.DTEPB103_LOG;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * DATE Description Author
 * 2013/08/05  Created ���կ�
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �Ƶ������Ҳ�
 * �Ҳ�ID    EP_B10040
 * ���n����    �Ƶ��������@�Ҳ�
 * </pre>
 * @author �x�Ԫ�
 * @since 2013/12/2
 */
@SuppressWarnings("unchecked")
public class EP_B10040 {
    private static final Logger log = Logger.getLogger(EP_B10040.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.b1.module.EP_B10040.SQL_queryList_001";

    private static final String SQL_queryMap_001 = "com.cathay.ep.b1.module.EP_B10040.SQL_queryMap_001";

    private XlsUtils xlsUtils;

    private static MultiKeyMap TENENT_MAP;

    static {
        TENENT_MAP = new MultiKeyMap();
    }

    /**
     * Ū�������Ƶ��ɲM��
     * @param reqMap
     *             <pre>
     *              SUB_CPY_ID  String  �����q�O
     *              CRT_NO  String  �����N��
     *              CUS_NO  String  �Ȥ�Ǹ�
     *              YEAR    String  �~��
     *              CLC_DIV_NO  String  �ӿ��O
     *              resp         ResponseContext
     *             </pre>
     * @param user UserObject
     * @param resp ResponseContext
     * @return rtnList List<Map>   ����_�Ƶ���DTEPB103 DTEPB102.�Ȥ�m�W
     * @throws Exception
     */
    public List<Map> queryList(Map reqMap, UserObject user, ResponseContext resp) throws Exception {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10040_MSG_001");//�ǤJ��Ƥ��o����!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        String CLC_DIV_NO = MapUtils.getString(reqMap, "CLC_DIV_NO");
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String YEAR = MapUtils.getString(reqMap, "YEAR");
        if (StringUtils.isBlank(CRT_NO) && StringUtils.isBlank(YEAR)) {
            if (StringUtils.isBlank(CLC_DIV_NO)) {
                eie = getErrorInputException(eie, "EP_B10040_MSG_010");//�����N���B�~�סB�ӿ��O���i�Ҭ��ŭ�!
            } else {
                eie = getErrorInputException(eie, "EP_B10040_MSG_011");//�ݦA��J�����N�� �� �~��!
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_005");//�ϥΪ̸�T���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        if (StringUtils.isNotBlank(CLC_DIV_NO) && CLC_DIV_NO.length() < 8) {
            CLC_DIV_NO = StringUtils.rightPad(CLC_DIV_NO, 7, "0");
        }
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        boolean isExport = (Boolean) MapUtils.getObject(reqMap, "isExport", false);
        if (isExport) {
            LocaleDisplay display = new LocaleDisplay("EP", user);
            xlsUtils = new XlsUtils(MapUtils.getString(reqMap, "fileName"), 100, 10, resp);
            BatchQueryDataSet bqds = new BatchQueryDataSet();
            bqds.setConnName(Transaction.getDataSet().getConnName());

            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            setfieldIfExist(bqds, "CRT_NO", CRT_NO);
            setfieldIfExist(bqds, "CUS_NO", CUS_NO);
            setfieldIfExist(bqds, "YEAR", YEAR);
            setfieldIfExist(bqds, "CLC_DIV_NO", CLC_DIV_NO);
            try {
                String gridJSON = MapUtils.getString(reqMap, "gridJSON");

                bqds.searchAndRetrieve(SQL_queryList_001);
                if (xlsUtils != null) {
                    xlsUtils.initBatchExportSetting(gridJSON, 1);
                    while (xlsUtils.fetchData(bqds)) {
                        while (xlsUtils.next(bqds)) {
                            Map dataMap = xlsUtils.getCurrentMap();
                            dataMap.put("YEAR", display.formatDatey(bqds.getField("YEAR"), ""));
                            dataMap.put("INFM_DATE", display.formatDate((Date) bqds.getField("INFM_DATE"), "", ""));
                            dataMap.put("CHG_DATE", display.formatTimestamp((Timestamp) bqds.getField("CHG_DATE"), "-", ""));
                            dataMap.put("INFM_TYPE_NM", FieldOptionList
                                    .getName("EP", "INFM_TYPE", MapUtils.getString(dataMap, "INFM_TYPE")));
                            dataMap.put("PROC_STS_NM", FieldOptionList.getName("EP", "PROC_STS", MapUtils.getString(dataMap, "PROC_STS")));
                            xlsUtils.batchCreateXls();
                        }
                    }
                }
            } finally {
                if (bqds != null) {
                    bqds.close();
                }
            }

            return null;

        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setfieldIfExist(ds, "CRT_NO", CRT_NO);
        setfieldIfExist(ds, "CUS_NO", CUS_NO);
        setfieldIfExist(ds, "YEAR", YEAR);
        setfieldIfExist(ds, "CLC_DIV_NO", CLC_DIV_NO);

        Map<String, String> tmpCusNmMap = new HashMap<String, String>(); //tmp�ӯ���m�W

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);
        for (Map rtnMap : rtnList) {
            String MEMO = MapUtils.getString(rtnMap, "MEMO", "");
            rtnMap.put("MEMO", StringUtils.replace(MEMO, "", "\n").trim());
            rtnMap.put("INFM_TYPE_NM", FieldOptionList.getName("EP", "INFM_TYPE", MapUtils.getString(rtnMap, "INFM_TYPE")));
            rtnMap.put("PROC_STS_NM", FieldOptionList.getName("EP", "PROC_STS", MapUtils.getString(rtnMap, "PROC_STS")));
            if (StringUtils.isEmpty(MapUtils.getString(rtnMap, "CUS_NAME"))) {
                String rtnCRT_NO = MapUtils.getString(rtnMap, "CRT_NO");
                String rtnCUS_NO = MapUtils.getString(rtnMap, "CUS_NO");

                String compareKey = rtnCRT_NO + rtnCUS_NO;
                if (!tmpCusNmMap.containsKey(compareKey) && StringUtils.isNotBlank(rtnCRT_NO)) {//���ǳƵ��L�����N��, CALL �Ҳշ|����, �G���ư������N������                    
                    Map qryMap = new HashMap();
                    Map tmpMap = new HashMap();
                    qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
                    qryMap.put("CRT_NO", rtnCRT_NO);
                    qryMap.put("CUS_NO", rtnCUS_NO);
                    try {
                        tmpMap = new EP_B10020().querytmpMap(qryMap);
                        tmpCusNmMap.put(compareKey, MapUtils.getString(tmpMap, "CUS_NAME"));
                        rtnMap.put("CUS_NAME", tmpCusNmMap.get(rtnCUS_NO));
                    } catch (DataNotFoundException dnfe) {
                    }
                }
                rtnMap.put("CUS_NAME", tmpCusNmMap.get(compareKey));
            }
        }
        return rtnList;

    }

    /**
     * Ū������_�Ƶ���
     * @param reqMap Map
     *          <pre>
     *               SUB_CPY_ID = �����q�O
     *               CRT_NO = �����N��
     *               CUS_NO = �Ȥ�Ǹ�
     *               SER_NO = �y����
     *          </pre>
     * @return  rtnMap  Map DTEPB103����_�Ƶ���
     */
    public Map queryMap(Map reqMap) throws ModuleException {
        ErrorInputException eie = null;
        if (reqMap == null || reqMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10040_MSG_001");//�ǤJ��Ƥ��o����!
        }
        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_002");//�����N�����o���ŭ�!
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_003");//�Ȥ�Ǹ����o���ŭ�!
        }
        String SER_NO = MapUtils.getString(reqMap, "SER_NO");
        if (StringUtils.isBlank(SER_NO)) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_004");//�y�������o���ŭ�!
        }
        String YEAR = MapUtils.getString(reqMap, "YEAR");
        if (StringUtils.isBlank(YEAR)) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_012");//�~�פ��o���ŭ�!
        }
        String CLC_DIV_NO = MapUtils.getString(reqMap, "CLC_DIV_NO");
        if (StringUtils.isBlank(CLC_DIV_NO)) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_013");//�ӿ��O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("SER_NO", SER_NO);
        ds.setField("YEAR", YEAR);
        ds.setField("CLC_DIV_NO", CLC_DIV_NO);
        return VOTool.findOneToMap(ds, SQL_queryMap_001);

    }

    /**
     * ���o�����ӯ�����
     * @param SUB_CPY_ID  String  �����q�O
     * @param CRT_NO  String  �����N��
     * @param CUS_NO  String  �Ȥ�Ǹ�
     * @return rtnMap  Map 
     *                  <pre> 
     *                  CUS_NAME �Ȥ�m�W
     *                  CLC_DIV_NO �ӿ��O
     *                  CUS_INFO_MAP �����ӯ����T
     *                  </pre> 
     */
    public Map queryTenentMap(String SUB_CPY_ID, String CRT_NO, String CUS_NO) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_002");//�����N�����o���ŭ�!
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_003");//�Ȥ�Ǹ����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        EP_B10010 theEP_B10010 = new EP_B10010();

        Map tmpMap;

        if (TENENT_MAP.containsKey(SUB_CPY_ID, CRT_NO)) {
            tmpMap = (Map) TENENT_MAP.get(SUB_CPY_ID, CRT_NO);
        } else {
            tmpMap = theEP_B10010.queryMap(SUB_CPY_ID, CRT_NO);
            TENENT_MAP.put(SUB_CPY_ID, CRT_NO, tmpMap);

        }

        Map rtnMap = new HashMap();

        rtnMap.put("CUS_INFO_MAP", tmpMap);
        List<DTEPB102> B102List = (List<DTEPB102>) MapUtils.getObject(tmpMap, "List<DTEPB102>");
        if (B102List != null) {
            for (DTEPB102 B102VO : B102List) {
                Integer B102VO_CUS_NO = B102VO.getCUS_NO();
                if (CRT_NO.equals(B102VO.getCRT_NO()) && B102VO_CUS_NO != null && Integer.valueOf(CUS_NO).compareTo(B102VO_CUS_NO) == 0) {
                    rtnMap.put("CUS_NAME", B102VO.getCUS_NAME());//�Ȥ�m�W
                    break;
                }
            }
        }

        DTEPA101 A101 = (DTEPA101) MapUtils.getObject(tmpMap, "DTEPA101");
        if (A101 != null) {
            rtnMap.put("CLC_DIV_NO", A101.getCLC_DIV_NO());//�ӿ��O
        }

        return rtnMap;
    }

    /**
     * �s�W����_�Ƶ���
     * @param SUB_CPY_ID  String  �����q�O
     * @param B103Vo      DTEPB103    ����_�Ƶ���
     * @param user    userObject  �ϥΪ̸�T
     */
    public void insert(String SUB_CPY_ID, DTEPB103 B103Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_005");//�ϥΪ̸�T���o���ŭ�!
        }
        if (B103Vo == null) {
            throw getErrorInputException(eie, "EP_B10040_MSG_006");//�����Ƶ��ɸ�T���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //���o�Ƶ��y����BY�~�סB�����N���B�Ȥ�Ǹ� 
        StringBuilder sb = new StringBuilder();
        String CRT_NO = B103Vo.getCRT_NO();
        String PARAM1 = sb.append(B103Vo.getYEAR()).append(B103Vo.getCLC_DIV_NO()).toString();
        sb.setLength(0);
        Integer CUS_NO = B103Vo.getCUS_NO();
        String strCUS_NO;
        if (CUS_NO == null) {
            B103Vo.setCUS_NO(0);
            strCUS_NO = "0";
        } else {
            strCUS_NO = String.valueOf(CUS_NO);
        }
        String PARAM2 = sb.append(CRT_NO).append(strCUS_NO).toString();

        //���o�ӯ����T
        Map rtnMap;
        try {
            rtnMap = this.queryTenentMap(SUB_CPY_ID, CRT_NO, strCUS_NO);
        } catch (DataNotFoundException dnfe) {
            log.error("�D�ɬd�L���ӯ����T", dnfe);
            Map qryMap = new HashMap();
            qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
            qryMap.put("CRT_NO", CRT_NO);
            qryMap.put("CUS_NO", CUS_NO);
            try {
                rtnMap = new EP_B10020().querytmpMap(qryMap);
            } catch (DataNotFoundException df) {
                throw new ModuleException(MessageUtil.getMessage("EP_B10040_MSG_009"));//�d�L���ӯ����T
            }
        }

        int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "007", PARAM1, PARAM2);
        B103Vo.setSER_NO(SER_NO);

        //�s�W����_�Ƶ���DTEPB103�G
        B103Vo.setSUB_CPY_ID(SUB_CPY_ID);
        String INFM_TYPE = B103Vo.getINFM_TYPE();
        if ("0".equals(INFM_TYPE)) {
            //���q��
            B103Vo.setPROC_STS(null);
            B103Vo.setINFM_DATE(null);
            B103Vo.setINFM_ID(null);
            B103Vo.setINFM_NAME(null);
            B103Vo.setINFM_EMAIL(null);

        } else if ("1".equals(INFM_TYPE)) {
            //�q�����
            B103Vo.setPROC_STS("N");
            B103Vo.setINFM_ID(null);
            B103Vo.setINFM_NAME(null);
        } else {
            //"2".equals(INFM_TYPE
            //�q���ӤH
            B103Vo.setPROC_STS("N");
        }

        B103Vo.setEND_CASE_DATE(null);
        //B103Vo.setCLC_DIV_NO(MapUtils.getString(rtnMap, "CLC_DIV_NO")); >> ��H�e�������D�H�K�y�����Ǹ��ɦ��~!
        B103Vo.setCHG_DATE(DATE.currentTime());
        B103Vo.setCHG_DIV_NO(user.getOpUnit());
        B103Vo.setCHG_ID(user.getEmpID());
        B103Vo.setCHG_NAME(user.getEmpName());
        VOTool.insert(B103Vo);
        //�g�J�@��LOG��
        this.insertLog(B103Vo, "I", user);

    }

    /**
     * ��s����_�Ƶ���
     * @param B103Vo DTEPB103    ����_�Ƶ���
     * @param user   userObject  �ϥΪ̸�T
     */
    public void update(DTEPB103 B103Vo, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (B103Vo == null) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_006");//�����Ƶ��ɸ�T���o���ŭ�!
        } else if (StringUtils.isBlank(B103Vo.getSUB_CPY_ID())) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_005");//�ϥΪ̸�T���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�ק﫴��_�Ƶ���DTEPB103�G
        String INFM_TYPE = B103Vo.getINFM_TYPE();
        String PROC_STS = B103Vo.getPROC_STS();
        if ("0".equals(INFM_TYPE)) {
            //���q��
            B103Vo.setPROC_STS(null);
            B103Vo.setINFM_DATE(null);
            B103Vo.setINFM_ID(null);
            B103Vo.setINFM_NAME(null);
            B103Vo.setINFM_EMAIL(null);
            B103Vo.setEND_CASE_DATE(null);

        } else if ("1".equals(INFM_TYPE) && !"Y".equals(PROC_STS)) {
            //�q�����
            B103Vo.setPROC_STS("N");
            B103Vo.setINFM_ID(null);
            B103Vo.setINFM_NAME(null);
            B103Vo.setEND_CASE_DATE(null);
        } else if ("2".equals(INFM_TYPE) && !"Y".equals(PROC_STS)) {
            //"2".equals(INFM_TYPE) 
            //�q���ӤH
            B103Vo.setPROC_STS("N");
            B103Vo.setEND_CASE_DATE(null);
        }
        B103Vo.setCHG_DATE(DATE.currentTime());
        B103Vo.setCHG_DIV_NO(user.getOpUnit());
        B103Vo.setCHG_ID(user.getEmpID());
        B103Vo.setCHG_NAME(user.getEmpName());
        //�g�J�@��LOG��
        this.insertLog(B103Vo, "U", user);
        VOTool.update(B103Vo);

    }

    /**
     * �R������_�Ƶ�������
     * @param delList List<Map>   <MAP>:DTEPB103����_�Ƶ�������
     * @param user userObject  �ϥΪ̸�T
     */
    public void delete(List<Map> delList, UserObject user) throws ModuleException {
        ErrorInputException eie = null;

        if (user == null) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_005");//�ϥΪ̸�T���o���ŭ�!
        }
        if (delList == null || delList.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10040_MSG_007");//����_�Ƶ������ɤ��o����!
        }
        //�v���ˮֶǤJ�Ѽ�:
        for (Map map : delList) {
            DTEPB103 B103VO = VOTool.mapToVO(DTEPB103.class, map);
            if (StringUtils.isBlank(B103VO.getSUB_CPY_ID())) {
                throw getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
            }
        }
        if (eie != null) {
            throw eie;
        }

        //�R������_�Ƶ���DTEPB103�G
        for (Map map : delList) {
            DTEPB103 B103VO = VOTool.mapToVO(DTEPB103.class, map);
            //�g�J�@��LOG��
            this.insertLog(B103VO, "D", user);
            //�R������_�Ƶ���DTEPB103
            VOTool.delByPK(B103VO);
        }

    }

    /**
     * �N����_�Ƶ������ɧ�s������
     * @param endCaseList  List<Map>   <MAP>:DTEPB103����_�Ƶ�������
     * @param user UserObject  �ϥΪ̸�T
     */
    public void endCase(List<Map> endCaseList, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_005");//�ϥΪ̸�T���o���ŭ�!
        }
        if (endCaseList == null || endCaseList.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10040_MSG_007");//����_�Ƶ������ɤ��o����!
        }
        //�v���ˮֶǤJ�Ѽ�:
        for (Map map : endCaseList) {
            DTEPB103 B103VO = VOTool.mapToVO(DTEPB103.class, map);
            if (StringUtils.isBlank(B103VO.getSUB_CPY_ID())) {
                throw getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
            }
        }
        if (eie != null) {
            throw eie;
        }
        Timestamp curr_time = DATE.currentTime();
        Date today = DATE.today();
        String OpUnit = user.getOpUnit();
        String EmpID = user.getEmpID();
        String EmpName = user.getEmpName();
        for (Map map : endCaseList) {
            DTEPB103 B103VO = VOTool.mapToVO(DTEPB103.class, map);
            this.insertLog(B103VO, "U", user);
            B103VO.setEND_CASE_DATE(today);//�@�~���
            B103VO.setCHG_DATE(curr_time);//�@�~����ɶ�
            B103VO.setCHG_DIV_NO(OpUnit);
            B103VO.setCHG_ID(EmpID);
            B103VO.setCHG_NAME(EmpName);
            B103VO.setPROC_STS("Y");
            //��s����_�Ƶ�������DTEPB103���׸�T
            VOTool.update(B103VO);
        }

    }

    /**
     * �s�W����_�Ƶ���LOG
     * @param B103Vo  DTEPB103    ����_�Ƶ���
     * @param DATA_TYPE  String  �������(I:�s�W,U:��s,D:�R��)
     * @param user    UserObject  �ϥΪ̸�T
     */
    public void insertLog(DTEPB103 B103Vo, String DATA_TYPE, UserObject user) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(DATA_TYPE)) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_008");//�������
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B10040_MSG_005");//�ϥΪ̸�T���o���ŭ�!
        }
        if (B103Vo == null) {
            throw getErrorInputException(eie, "EP_B10040_MSG_006");//�����Ƶ��ɸ�T���o���ŭ�!
        }
        String SUB_CPY_ID = B103Vo.getSUB_CPY_ID();
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //�g�@��LOG��
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", B103Vo.getSUB_CPY_ID());
        reqMap.put("CRT_NO", B103Vo.getCRT_NO());
        reqMap.put("CUS_NO", B103Vo.getCUS_NO());
        reqMap.put("YEAR", B103Vo.getYEAR());
        reqMap.put("CLC_DIV_NO", B103Vo.getCLC_DIV_NO());
        reqMap.put("SER_NO", B103Vo.getSER_NO());

        DTEPB103_LOG B103Vo_Log = VOTool.mapToVO(DTEPB103_LOG.class, this.queryMap(reqMap));
        B103Vo_Log.setDATA_TYPE(DATA_TYPE);
        B103Vo_Log.setUPD_DATE(DATE.currentTime());
        VOTool.insert(B103Vo_Log);

    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * ���Ȥ~�]�ܼ�
     * @param ds
     * @param value
     */
    private void setfieldIfExist(DataSet ds, String key, String value) {

        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }
}
