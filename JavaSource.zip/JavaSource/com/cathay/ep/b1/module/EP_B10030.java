package com.cathay.ep.b1.module;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.vo.DTEPB102;
import com.cathay.ep.vo.DTEPB303;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 *      DATE    Description Author
 *      2013/10/30  Created ���կ�
 *      
 *      �@�B  �{���\�෧�n�����G
 *      �ҲզW��    �q�T�a�}���@�Ҳ�
 *      �Ҳ�ID    EP_B10030
 *      ���n����    �q�T�a�}���@�Ҳ�
 * </pre>
 * @author �x�Ԫ�
 * @since  2013-11-26
 */
@SuppressWarnings("unchecked")
public class EP_B10030 {
    private static final Logger log = Logger.getLogger(EP_B10030.class);

    private static final String SQL_update_001 = "com.cathay.ep.b1.module.EP_B10030.SQL_update_001";

    /**
     * ��s�p���q�T�a�}
     * @param SUB_CPY_ID  String  �����q�O
     * @param updMap Map
     *                  <pre>
     *                       CRT_NO = �����N��      
     *                       CUS_NO = �Ȥ�Ǹ�      
     *                       CUS_ID = �Ȥ�s��      
     *                       BOSS_NAME = �t�d�H        
     *                       COMP_ZIP_CODE = ���q�l���ϸ�  
     *                       COMP_ADDR = ���q�n�O�a�}  
     *                       CONT_NAME = �p���H        
     *                       CONT_MOBIL_NO = �p���H���    
     *                       TEL_AREA = �q�ܰϽX      
     *                       TEL = �q��          
     *                       TEL_EXT = �q�ܤ���      
     *                       CONT_ZIP_CODE = �q�T�a�l���ϸ�
     *                       CONT_ADDR = �q�T�a�}      
     *                       CUS_EMAIL = �Ȥ�EMAIL     
     *                       FILE_NO = �ɮ׽s��
     *                  </pre>
     * @param user UserObject  �ϥΪ̸�T
     */
    public void update(String SUB_CPY_ID, Map updMap, UserObject user) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        if (user == null) {
            eie = getErrorInputException(eie, "EP_B10030_MSG_001");//�ϥΪ̸�T���o���ŭ�!
        }
        if (updMap == null || updMap.isEmpty()) {
            throw getErrorInputException(eie, "EP_B10030_MSG_002");//�ץ���Ƥ��o���ŭ�!
        }
        String CRT_NO = MapUtils.getString(updMap, "CRT_NO");
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B10030_MSG_003");//�����N�����o���ŭ�!
        }
        Integer CUS_NO = MapUtils.getInteger(updMap, "CUS_NO");
        if (CUS_NO == null) {
            eie = getErrorInputException(eie, "EP_B10030_MSG_004");//�Ȥ�Ǹ����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //���o�쫴����T
        updMap.put("SUB_CPY_ID", SUB_CPY_ID);
        EP_B10020 theEP_B10020 = new EP_B10020();
        Map orgB102Map;
        try {
            orgB102Map = theEP_B10020.queryMap(updMap);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L�������ӯ���D�ɸ��", dnfe);
            throw getErrorInputException(eie, "EP_B10030_MSG_006");//�d�L�������ӯ���D�ɸ��!
        }
        Map B101Map;
        try {
            B101Map = new EP_B10010().queryMap(updMap);
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L�������D�ɸ��", dnfe);
            throw getErrorInputException(eie, "EP_B10030_MSG_005");//�d�L�������D�ɸ��!
        }
        //�g�J�ץ���
        Map reqMap = new HashMap();
        reqMap.put("SUB_CPY_ID", B101Map.get("SUB_CPY_ID")); 
        reqMap.put("BLD_CD", B101Map.get("BLD_CD"));
        reqMap.put("CRT_NO",  B101Map.get("CRT_NO"));
        reqMap.put("UPD_TRN_KIND", "EPB012");//EPB012�q�T��ƺ��@ 
        String UPD_DATE = DATE.getDBTimeStamp();//�@�~����ɶ�
        reqMap.put("UPD_DATE", UPD_DATE);
        String CHG_DIV_NO = user.getOpUnit();
        reqMap.put("CHG_DIV_NO", CHG_DIV_NO);
        String CHG_ID = user.getEmpID();
        reqMap.put("CHG_ID", CHG_ID);
        String CHG_NAME = user.getEmpName();
        reqMap.put("CHG_NAME", CHG_NAME);

        //�����ӯ���Ȧs���
        DTEPB303 B303Vo = VOTool.mapToVO(DTEPB303.class, orgB102Map);
        B303Vo.setDATA_TYPE("A");
        String APLY_NO = new EP_B30010().insertForUpdMain(reqMap);
        B303Vo.setAPLY_NO(APLY_NO);

        String BOSS_NAME = MapUtils.getString(updMap, "BOSS_NAME");
        B303Vo.setBOSS_NAME(BOSS_NAME);
        String COMP_ZIP_CODE = MapUtils.getString(updMap, "COMP_ZIP_CODE");
        B303Vo.setCOMP_ZIP_CODE(COMP_ZIP_CODE);
        String COMP_ADDR = MapUtils.getString(updMap, "COMP_ADDR");
        B303Vo.setCOMP_ADDR(COMP_ADDR);
        String CONT_NAME = MapUtils.getString(updMap, "CONT_NAME");
        B303Vo.setCONT_NAME(CONT_NAME);
        String CONT_MOBIL_NO = MapUtils.getString(updMap, "CONT_MOBIL_NO");
        B303Vo.setCONT_MOBIL_NO(CONT_MOBIL_NO);
        String TEL_AREA = MapUtils.getString(updMap, "TEL_AREA");
        B303Vo.setTEL_AREA(TEL_AREA);
        String TEL = MapUtils.getString(updMap, "TEL");
        B303Vo.setTEL(TEL);
        String TEL_EXT = MapUtils.getString(updMap, "TEL_EXT");
        B303Vo.setTEL_EXT(TEL_EXT);
        String CONT_ZIP_CODE = MapUtils.getString(updMap, "CONT_ZIP_CODE");
        B303Vo.setCONT_ZIP_CODE(CONT_ZIP_CODE);
        String CONT_ADDR = MapUtils.getString(updMap, "CONT_ADDR");
        B303Vo.setCONT_ADDR(CONT_ADDR);
        String CUS_EMAIL = MapUtils.getString(updMap, "CUS_EMAIL");
        B303Vo.setCUS_EMAIL(CUS_EMAIL);
        String FILE_NO = MapUtils.getString(updMap, "FILE_NO");
        B303Vo.setFILE_NO(FILE_NO);
        theEP_B10020.insertDTEPB303(B303Vo, "U", null); //�@�~���� U �ק�
        //��s�����ӯ�����
        //�g�@��LOG��
        DTEPB102 B102Vo = new DTEPB102();
        B102Vo.setSUB_CPY_ID(SUB_CPY_ID);
        B102Vo.setCRT_NO(CRT_NO);
        B102Vo.setCUS_NO(CUS_NO);
        theEP_B10020.insertLog(B102Vo, UPD_DATE, APLY_NO, "EPB012", false);
        //�ק﫴���򥻸���� DTEPB102�G
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("BOSS_NAME", BOSS_NAME);
        ds.setField("COMP_ZIP_CODE", COMP_ZIP_CODE);
        ds.setField("COMP_ADDR", COMP_ADDR);
        ds.setField("CONT_NAME", CONT_NAME);
        ds.setField("CONT_MOBIL_NO", CONT_MOBIL_NO);
        ds.setField("TEL_AREA", TEL_AREA);
        ds.setField("TEL", TEL);
        ds.setField("TEL_EXT", TEL_EXT);
        ds.setField("CONT_ZIP_CODE", CONT_ZIP_CODE);
        ds.setField("CONT_ADDR", CONT_ADDR);
        ds.setField("CUS_EMAIL", CUS_EMAIL);
        ds.setField("FILE_NO", FILE_NO);        
        ds.setField("UPD_DATE", UPD_DATE);
        ds.setField("CHG_DIV_NO", CHG_DIV_NO);
        ds.setField("CHG_ID", CHG_ID);
        ds.setField("CHG_NAME", CHG_NAME);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("TRN_KIND", "EPB012");               
        DBUtil.executeUpdate(ds, SQL_update_001);
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}
