package com.cathay.ep.b1.module;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.util.Transaction;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

@SuppressWarnings("rawtypes")
public class EPB1_0110_mod {
    private static final String SQL_checkDTEPC210RCV_YM_001 = "com.cathay.ep.b1.module.EPB1_0110_mod.SQL_checkDTEPC210RCV_YM_001";

    private static final String SQL_checkDTEPC205_001 = "com.cathay.ep.b1.module.EPB1_0110_mod.SQL_checkDTEPC205_001";

    private static final String SQL_queryDTEPC210R_001 = "com.cathay.ep.b1.module.EPB1_0110_mod.SQL_queryDTEPC210R_001";

    /**
     * �ˮ�IFRS�C��������粒���T�{�ɸ��
     * @param RCV_YM    �����~��
     * @throws DBException
     * @throws ErrorInputException
     */
    public void checkDTEPC210RCV_YM(String RCV_YM) throws DBException, ErrorInputException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(RCV_YM)) {
            throw getErrorInputException(eie, "EPB1_0110_mod_ERRMSG_01");//�����~�뤣�o����!
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.searchAndRetrieve(SQL_checkDTEPC210RCV_YM_001);

        if (ds.next() && (Integer) ds.getField(0) > 0) {
            throw getErrorInputException(eie, "EPB1_0110_mod_ERRMSG_02");//�w�g����IFRS�C��������粒���T�{�ɸ��,���i���
        }
    }

    /**
     * �ˮ֬O�_�T�{����
     * @param RCV_YYYY  �����~
     * @param RCV_MM    ������
     * @throws ErrorInputException
     * @throws DBException
     */
    public void checkDTEPC205(String RCV_YYYY, String RCV_MM) throws ErrorInputException, DBException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(RCV_YYYY)) {
            eie = getErrorInputException(eie, "EPB1_0110_mod_ERRMSG_03");//�����~���o���ŭ�!
        }
        if (StringUtils.isBlank(RCV_MM)) {
            eie = getErrorInputException(eie, "EPB1_0110_mod_ERRMSG_04");//�����뤣�o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YYYY", RCV_YYYY);
        ds.setField("RCV_MM", RCV_MM);
        ds.searchAndRetrieve(SQL_checkDTEPC205_001);
        if (ds.next() && (Integer) ds.getField(0) > 0) {
            throw getErrorInputException(eie, "EPB1_0110_mod_ERRMSG_05");//IFRS�o���������٥��T�{��,���i���
        }

    }

    /**
     * �d��DTEPC210 (IFRS�C��������粒���T�{��)
     * @param   RCV_YM  �����~��
     * @return  rtnMap
     * @throws  ModuleException
     */
    public Map queryDTEPC210R(String RCV_YM) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(RCV_YM)) {
            throw getErrorInputException(eie, "EPB1_0110_mod_ERRMSG_01");//�����~�뤣�o����!
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_queryDTEPC210R_001);

        return rtnMap;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}
