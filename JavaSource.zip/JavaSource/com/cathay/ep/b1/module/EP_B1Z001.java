package com.cathay.ep.b1.module;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * Date Version Description Author
 * 2013/9/13   1.0 �s�W  �\�a�s
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ������Ʀ@�P�d�߼Ҳ�
 * �{���W��    EP_B1Z001 
 * ���n����    �d��DTEPB101�������������
 * </pre>
 * @author �x�Ԫ�
 * @since 2014/1/14
 */
@SuppressWarnings("unchecked")
public class EP_B1Z001 {
    private static final String SQL_getB105ADJ_UNIT_001 = "com.cathay.ep.b1.module.EP_B1Z001.SQL_getB105ADJ_UNIT_001";

    private static final String SQL_getB105ADJ_UNIT_002 = "com.cathay.ep.b1.module.EP_B1Z001.SQL_getB105ADJ_UNIT_002";

    private static final String SQL_getB105ADJ_UNIT_003 = "com.cathay.ep.b1.module.EP_B1Z001.SQL_getB105ADJ_UNIT_003";    

    /**
     * �d�߽կ���/�����
     * @param CRT_NO  String  �����N��
     * @param CUS_NO  String  �Ȥ�Ǹ�
     * @param SUB_CPY_ID   String  �����q�O
     * @return rtnMap Map �կ����
     *                  <pre>
     *                      ADJ_UNIT_NUM : �կ���
     *                      ADJ_UNIT : �կ����N��
     *                      ADJ_UNIT_NM : �կ���줤��
     *                  </pre>
     */
    public Map getB105ADJ_UNIT(String CRT_NO, String CUS_NO, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");//�����q�O���o���ŭ�!
        }
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, "EP_B1Z001_MSG_001");//�����N�����o���ŭ�!
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, "EP_B1Z001_MSG_002");//�Ȥ�Ǹ����o���ŭ�!
        }
        if (eie != null) {
            throw eie;
        }
        //���d�կ��϶��]�����Ѹ��
        Date today = DATE.today();
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("today", today);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_getB105ADJ_UNIT_001, false);

        if (rtnMap != null && !rtnMap.isEmpty()) {
            rtnMap.put("ADJ_UNIT_NM", FieldOptionList.getName("EPB", "ADJ_UNIT", MapUtils.getString(rtnMap, "ADJ_UNIT")));
            return rtnMap;
        }
        //�d�L�h�̫�@���կ��϶�
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("today", today);
        rtnMap = VOTool.findOneToMap(ds, SQL_getB105ADJ_UNIT_002, false);
        if (rtnMap != null && !rtnMap.isEmpty()) {           
            rtnMap.put("ADJ_UNIT_NM", FieldOptionList.getName("EPB", "ADJ_UNIT", MapUtils.getString(rtnMap, "ADJ_UNIT")));
            return rtnMap;
        }

        //�d���ӳ̷s�@���կ��϶�
        ds.clear();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("today", today);
        rtnMap = VOTool.findOneToMap(ds, SQL_getB105ADJ_UNIT_003, false);
        if (rtnMap != null && !rtnMap.isEmpty()) {           
            rtnMap.put("ADJ_UNIT_NM", FieldOptionList.getName("EPB", "ADJ_UNIT", MapUtils.getString(rtnMap, "ADJ_UNIT")));
            return rtnMap;
        }
        return new HashMap();
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }
}
