package com.cathay.ep.g2.module;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.ep.z0.module.EP_Z0G230;

/**
 * <pre>
 * �{���\��    ��a���Ⱥ��@�@�~�ˮּҲ�
 * �{���W��    EPG2_0200_mod.java
 * �@�~�覡    MODULE
 * ���n����    
 * </pre>
 * @author ����[
 * @since 2015/1/9
 */
@SuppressWarnings("unchecked")
public class EPG2_0200_mod {

    private static final Logger log = Logger.getLogger(EPG2_0200_mod.class);

    private String[] colNames = { "EPG2_0200_UI_SERNO", "EPG2_0200_UI_BASE_CD", "EPG2_0200_UI_BASE_BLD_NAME", "EPG2_0200_UI_BASE_ADDR",
            "EPG2_0200_UI_COST_YR", "EPG2_0200_UI_COST_MN", "EPG2_0200_UI_COST_DY", "EPG2_0200_UI_COMP1", "EPG2_0200_UI_COMP2",
            "EPG2_0200_UI_LND_EVAL1", "EPG2_0200_UI_BLD_EVAL1", "EPG2_0200_UI_EVAL1", "EPG2_0200_UI_LND_EVAL2", "EPG2_0200_UI_BLD_EVAL2",
            "EPG2_0200_UI_EVAL2", "EPG2_0200_UI_FL_LND_EVAL", "EPG2_0200_UI_FL_BLD_EVAL", "EPG2_0200_UI_FL_EVAL", "EPG2_0200_UI_LND_TAX",
            "EPG2_0200_UI_INV_RT", "EPG2_0200_UI_INV_LND_EVAL", "EPG2_0200_UI_INV_BLD_EVAL", "EPG2_0200_UI_INV_EVAL",
            "EPG2_0200_UI_INV_LND_TAX" };

    /**
     * �ˮ֤W��
     * @param reqMap
     * @param fileItem
     * @throws ModuleException
     * @throws IOException
     */
    public void checkFormat(Map reqMap, FileItem fileItem) throws ModuleException, IOException {

        //�ˮ��ɮװ��ɦW�O�_���T(�i��xlsx)���X��X���~���ɮװ��ɦW���� xlsx��  (�����j�p�g)
        String FILE_NAME = fileItem.getName().toUpperCase();

        //�ˮ��ɮפ��e�榡
        InputStream is = fileItem.getInputStream();
        Workbook wb = null;
        // �ˮֹq�l�ɮ榡�O�_���T�A
        if (FILE_NAME.endsWith("XLSX")) {
            wb = new XSSFWorkbook(is);
        } else if (FILE_NAME.endsWith("XLS")) {
            POIFSFileSystem fs = new POIFSFileSystem(is);
            wb = new HSSFWorkbook(fs);
        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EPG2_0200_mod_ERR_001")); //�ɮ׮榡���~�A�ɮװ��ɦW���� xlsx
        }

        //�ˮ֤W���ɮפ��e�O�_�w�g�s�b
        try {
            new EP_Z0G230().queryList(reqMap);
            throw new ModuleException(MessageUtil.getMessage("EPG2_0200_mod_ERR_002"));//�����~��w�g����ơA�Х��R���A���s�W��
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L��Ƶ������`");
        }

        Map evaMap = FieldOptionList.getFieldOptions("EP", "EVAL_INFO");
        //�ˮ����
        //�ѪR��ɦ��ȸ��        
        String SHEET = MapUtils.getString(evaMap, "SHEET_A"); //[0]
        String BEG_ROW = MapUtils.getString(evaMap, "BEG_ROW_A"); //[2]        
        chkDataType(wb, SHEET, BEG_ROW, "1");
        //�ѪR���h���ȸ��
        SHEET = MapUtils.getString(evaMap, "SHEET_B"); //[0]
        BEG_ROW = MapUtils.getString(evaMap, "BEG_ROW_B"); //[2]        
        chkDataType(wb, SHEET, BEG_ROW, "2");
        if (is != null) {
            is.close();
        }

    }

    /**
     * �ˮֱ��R����ƬO�_�w�g�s�b
     * @param reqMap
     * @throws ModuleException
     */
    public void checkDelete(Map reqMap) throws ModuleException {

        //�ˮֱ��R����ƬO�_�w�g�s�b
        try {
            new EP_Z0G230().queryList(reqMap);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPG2_0200_mod_ERR_005"));//�d�L��ơA�L�k�R��
        }
    }

    /**
     * �ˮ֤W���ɮ����
     * @param wb
     * @param SHEET
     * @param BEG_ROW
     * @param type
     * @throws ModuleException
     */
    private void chkDataType(Workbook wb, String SHEET, String BEG_ROW, String type) throws ModuleException {
        Sheet sheet = wb.getSheetAt(Integer.parseInt(SHEET));
        if (sheet == null) {
            throw new ModuleException("�䤣�������sheet: ");
        }
        int begRow = Integer.parseInt(BEG_ROW);
        ErrorInputException eie = null;
        for (int i = begRow; i < sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String no = getCellValue(row, 1, "");
            if(StringUtils.isBlank(no)) {
            	break;
            }
            String eval1 = getCellValue(row, 8, "");
            String eval2 = getCellValue(row, 9, "");
            //validType(val,notNull,isNumeric);
            eie = validType(getCellValue(row, 2, ""), true, false, 2, eie);//��a�N��
            eie = validType(getCellValue(row, 5, ""), false, true, 5, eie);//�M��~
            eie = validType(getCellValue(row, 6, ""), false, true, 6, eie);//�M���
            eie = validType(getCellValue(row, 7, ""), false, true, 7, eie);//�M���
            if(StringUtils.isNotEmpty(eval1)) {
                eie = validType(getCellValue(row, 10, ""), false, true, 10, eie);//�g�a����(1)
                eie = validType(getCellValue(row, 11, ""), false, true, 11, eie);//�ت�����(1)
                eie = validType(getCellValue(row, 12, ""), false, true, 12, eie);//����(1)            	
            }
            if(StringUtils.isNotEmpty(eval2)) {
                eie = validType(getCellValue(row, 13, ""), false, true, 13, eie);//�g�a����(2)
                eie = validType(getCellValue(row, 14, ""), false, true, 14, eie);//�ت�����(2)
                eie = validType(getCellValue(row, 15, ""), false, true, 15, eie);//����(2)
            }
            eie = validType(getCellValue(row, 16, ""), false, true, 16, eie);//�J�`�ĥΪ��g�a����
            eie = validType(getCellValue(row, 17, ""), false, true, 17, eie);//�J�`�ĥΪ��ت�����
            eie = validType(getCellValue(row, 18, ""), true, true, 18, eie);//�J�`�ĥΪ�����
            eie = validType(getCellValue(row, 19, ""), false, true, 19, eie);//�J�`�ĥΪ��g�W�|
            if ("2".equals(type)) {
                //���h���� �h�����
                eie = validType(getCellValue(row, 20, ""), true, true, 20, eie);//�Ӽh����� 
                eie = validType(getCellValue(row, 21, ""), false, true, 21, eie);//Check��Ҥg�a����
                eie = validType(getCellValue(row, 22, ""), false, true, 22, eie);//Check��ҫت�����
                eie = validType(getCellValue(row, 23, ""), false, true, 23, eie);//Check��Ҧ���
                eie = validType(getCellValue(row, 24, ""), false, true, 24, eie);//Check��Ҥg�W�|
            }
        }
        if (eie != null) {
            throw eie;
        }
    }

    /**
     * �ˮ֤W�����榡
     * @param value
     * @param notNull
     * @param isNumeric
     * @param isSTS
     * @return
     * @throws ErrorInputException
     */
    private ErrorInputException validType(String value, boolean notNull, boolean isNumeric, int cIdx, ErrorInputException eie) {
        String colName = MessageUtil.getMessage(colNames[cIdx - 1]);
        if (notNull && StringUtils.isBlank(value)) {
            log.error("���~���:" + cIdx);
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPG2_0200_mod_ERR_003"), colName);//�W���ɮ����榡���~(���i����)�A���:
            //throw new ErrorInputException(MessageUtil.getMessage("EPG2_0200_mod_ERR_003"));//�W���ɮ����榡���~(���i����)
        }
        if (isNumeric && StringUtils.isNotBlank(value) && !STRING.isNumeric(value)) {
            log.error("���~���:" + cIdx);
            eie = getErrorInputException(eie, MessageUtil.getMessage("EPG2_0200_mod_ERR_004"), colName);//�W���ɮ����榡���~(�Ʀr�榡)�A���:
            //throw new ErrorInputException(MessageUtil.getMessage("EPG2_0200_mod_ERR_004"));//�W���ɮ����榡���~(�Ʀr�榡)
        }
        return eie;
    }

    /**
     * ���o�W���ɮ������
     * @param row
     * @param cIdx
     * @param defauleValue
     * @return
     */
    private String getCellValue(Row row, int cIdx, String defauleValue) {
        String cellValue = defauleValue;
        if (row == null) {
            return cellValue;
        }
        Cell cell = row.getCell(cIdx - 1);
        if (cell == null) {
            return cellValue;
        }
        int cell_type = cell.getCellType();
        if (cell_type == Cell.CELL_TYPE_FORMULA) {
            switch (cell.getCachedFormulaResultType()) {
                case Cell.CELL_TYPE_STRING:
                    RichTextString str = (RichTextString) cell.getRichStringCellValue();
                    if (str != null && str.length() > 0) {
                        cellValue = str.getString();
                    }
                    break;

                case Cell.CELL_TYPE_NUMERIC:
                    BigDecimal decValue = new BigDecimal(cell.getNumericCellValue());
                    cellValue = decValue.toPlainString();
                    break;
                case Cell.CELL_TYPE_BOOLEAN:
                case Cell.CELL_TYPE_ERROR:
                    break;
            }

        } else if (cell_type == Cell.CELL_TYPE_NUMERIC) {
            BigDecimal decValue = new BigDecimal(cell.getNumericCellValue());
            cellValue = decValue.toPlainString();
        } else if (cell_type == Cell.CELL_TYPE_BOOLEAN) {
            cellValue = cell.getBooleanCellValue() ? "Y" : "N";
        } else if (cell_type == Cell.CELL_TYPE_STRING) {
            cellValue = cell.getStringCellValue();
        }
        return cellValue;
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg, String colName) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg + colName);
        return eie;
    }
}
