package com.cathay.ep.g4.batch;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchProcesser;
import com.cathay.common.util.batch.CountManager;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.batch.ErrorLog;
import com.cathay.common.util.batch.GroupHandler;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.cathay.zz.x0.module.ZZ_X0Z004;
import com.cathay.zz.x0.module.ZZ_X0Z007;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * Date Version Description Author
 * 2015/01/20  1.0 Create  ������
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �Y�ɧQ�βv�妸�B�z
 * �{���W��    EPG4_B100.java
 * �@�~�覡    BATCH
 * ���n����    Ū����a�j�өӯ����Ӧ���ӯ�����
 * �w����ƶq   3500
 * �@�~�W��    JAEPOG200
 * �~�ȧO EP
 * ���t�ΦW��   G4
 * �B�z�g��    ��
 * ����B�z���  �w�]��
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EPG4_B100 extends EP_BatchBean {
    /** log */
    private static final Logger log = Logger.getLogger(EPG4_B100.class);

    /** �@�~�W�� */
    private static final String JOB_NAME = "JAEPOG200";

    /** �{���W�� */
    private static final String PROGRAM = "EPG4_B100";

    /** �~�ȧO */
    private static final String BUSINESS = "EP";

    /** ���t�ΦW�� */
    private static final String SUBSYSTEM = "G4";

    /** ����g�� */
    private static final String PERIOD = "��";

    /** �]�� true �Ѥ����O�p�Ƥμg���~�T��, false �Шϥ� ErrorLog ��CountManager �ۦ�g���~�T���έp�� */
    private static final boolean isAUTO_WRITELOG = false;

    private static final String INPUT_COUNT = "��J���";

    private static final String ERROR_COUNT = "���~���";

    private static final String OUTPUT_COUNT = "��X���";

    private static final String G420cnt = "��a�J��s�W����";

    private static final String G401cnt = "�ӯ����ӷs�W����";

    private static final String G400cnt = "��a���ӷs�W����";

    private static final String tableNameDTEPG401 = "��������������©��ӡ]DBEP.DTEPG401�^";

    private static final String tableNameDTEPG420 = "�����a�J����ӡ]DBEP.DTEPG420�^";

    private static final String tableNameDTEPG400 = "�����a�Y�ɧQ�Ω��ӡ]DBEP.DTEPG400�^";

    private static final String BASE_STR_DATE = "2014-01-01";

    private BatchUpdateDataSet buds_INSERT_TABLE_G420;

    private BatchUpdateDataSet buds_INSERT_TABLE_G401;

    private BatchUpdateDataSet buds_INSERT_TABLE_G400;

    private final StringBuilder sb;

    private final static BigDecimal BD_12 = new BigDecimal("12");

    private final static BigDecimal BD_1P05 = new BigDecimal("1.05");

    /** �d�ߪ����� */
    private BatchQueryDataSet bqds;

    /** �M�����O�@�Τ����~�T���O������ */
    private ErrorLog errorLog;

    /** �p�ƾ� */
    private CountManager countManager;

    /** �̿��~���h�Ũ��o���~����� */
    private ErrorHandler errorHandler;

    /** �P�@�妸�h�� table ���� , �������~����� , �ñN���T����Ƽg�J */
    private GroupHandler groupHandler;

    /** ���s���� */
    private BatchProcesser batchProcesser;

    private static final String SQL_DELETE_001 = "com.cathay.ep.g4.batch.EPG4_B100.SQL_DELETE_001";

    private static final String SQL_DELETE_002 = "com.cathay.ep.g4.batch.EPG4_B100.SQL_DELETE_002";

    private static final String SQL_DELETE_003 = "com.cathay.ep.g4.batch.EPG4_B100.SQL_DELETE_003";

    private static final String SQL_QUERYforBaseInfo_001 = "com.cathay.ep.g4.batch.EPG4_B100.SQL_QUERYforBaseInfo_001";

    private static final String INSERT_DTEPG420 = "com.cathay.ep.g4.batch.EPG4_B100.INSERT_DTEPG420";

    private static final String SQL_QUERYforInsertDTEPG401_001 = "com.cathay.ep.g4.batch.EPG4_B100.SQL_QUERYforInsertDTEPG401_001";

    private static final String INSERT_DTEPG401 = "com.cathay.ep.g4.batch.EPG4_B100.INSERT_DTEPG401";

    private static final String SQL_QUERYforInsertDTEPG400_001 = "com.cathay.ep.g4.batch.EPG4_B100.SQL_QUERYforInsertDTEPG400_001";

    private static final String INSERT_DTEPG400 = "com.cathay.ep.g4.batch.EPG4_B100.INSERT_DTEPG400";

    public EPG4_B100() throws Exception {
        // �]�w�����O���غc�l,�ǤJ true �Ѥ����O�p�Ƥμg���~�T��
        super(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isAUTO_WRITELOG);

        // ���~�T���O������
        countManager = new CountManager(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD);

        errorLog = new ErrorLog(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM);

        errorHandler = new ErrorHandler();

        bqds = getBatchQueryDataSet();

        groupHandler = new GroupHandler();

        batchProcesser = new BatchProcesser();

        buds_INSERT_TABLE_G420 = getBatchUpdateDataSet();

        buds_INSERT_TABLE_G401 = getBatchUpdateDataSet();

        buds_INSERT_TABLE_G400 = getBatchUpdateDataSet();
        sb = new StringBuilder();

        this.initCountManager();
    }

    public void execute(String[] args) throws Exception {

        try {
            String SUB_CPY_ID = null; //�����q
            String CAL_YM = null; //�p��~��
            String CAL_TP = null; //�p������(1:�Y�ɧQ��;2:�J��+�Y�ɧQ��)
            String IDX_RT = null;// ���ЧQ�v
            String EmpID = null;//�@�~�H��
            String EmpName = null;// �@�~�H���m�W
            String OpUnit = null;// �@�~���
            String BAT_KEY = null;//����@�~

            args = new ZZ_X0Z007(PROGRAM).retrieveParam(null, 8);
            if (args == null || args.length != 8) {
                setExitCode(ERROR);
                log.error("���o�妸����Ѽƿ��~");
                throw new ErrorInputException("���o�妸����Ѽƿ��~");
            }

            
            if (args != null && args.length == 8) {
            	log.debug("�妸����Ѽ�: "+Arrays.asList(args));
                SUB_CPY_ID = args[0];
                CAL_YM = args[1];
                CAL_TP = args[2];
                IDX_RT = args[3];
                EmpID = args[4];
                EmpName = args[5];
                OpUnit = args[6];
                BAT_KEY = args[7];
            }
            ZZ_X0Z004 aZZ_X0Z004 = new ZZ_X0Z004(PROGRAM, BAT_KEY);

            //�z�L�u�W�妸����Ҳհ���
            ReturnMessage rm = new ReturnMessage();
            //�ŧi�妸�}�l
            try {
                aZZ_X0Z004.startBatch(rm);
            } catch (Exception e) {
                log.error("�u�W�妸�Ұʿ��~", e);
                throw e;
            }
            if (rm.getReturnCode() != ReturnCode.OK) {
                String errorMsg = "�u�W�妸�Ұʿ��~";
                setExitCode(ERROR);
                log.error(errorMsg);
                throw new ModuleException(errorMsg);
            }
            try {
                //�R����������������©���
                deleteDTEPG401(SUB_CPY_ID, CAL_YM);

                //�R�������a�J�����
                if ("2".equals(CAL_TP)) {
                    deleteDTEPG420(SUB_CPY_ID, CAL_YM);
                }

                //�R�������a�Y�ɧQ�Ω���
                deleteDTEPG400(SUB_CPY_ID, CAL_YM);

                //���Ͱ�a�J����
                if ("2".equals(CAL_TP)) {
                    createBaseInfo(SUB_CPY_ID, CAL_YM, EmpID, EmpName, OpUnit);
                }
                //���ͷ�������������µ��G
                insertToDTEPG401(SUB_CPY_ID, CAL_YM, EmpID, EmpName, OpUnit);

                // ���ͷ����a�Y�ɧQ�βv���G
                createG400(SUB_CPY_ID, CAL_YM, new BigDecimal(IDX_RT), EmpID, EmpName, OpUnit);
            } finally {
                //�z�L�u�W�妸����Ҳհ���
                //�ŧi�妸����
                aZZ_X0Z004.endBatch(rm);

                if (rm.getReturnCode() != ReturnCode.OK) {
                    String errorMsg = "�u�W�妸�������~";
                    setExitCode(ERROR);
                    log.error(errorMsg);
                    throw new ModuleException(errorMsg);
                }
            }

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("����ɵo�Ϳ��~", e);
        } finally {

            log.error(countManager);

            if (countManager != null) {
                countManager.writeLog();
            }
            if (buds_INSERT_TABLE_G420 != null) {
                buds_INSERT_TABLE_G420.close();
            }
            if (buds_INSERT_TABLE_G401 != null) {
                buds_INSERT_TABLE_G401.close();
            }
            if (buds_INSERT_TABLE_G400 != null) {
                buds_INSERT_TABLE_G400.close();
            }
            if (bqds != null) {
                bqds.close();
            }

            printExitCode(getExitCode());
        }

    }

    /**
     * �R����������������©���
     * @param SUB_CPY_ID
     * @param CAL_YM
     * @throws Exception
     */
    private void deleteDTEPG401(String SUB_CPY_ID, String CAL_YM) throws Exception {
        //��Ƶ��Ƴ̦h�X�d���A �i�H�����R��
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CAL_YM", CAL_YM);
        ds.update(SQL_DELETE_001);

    }

    /**
     * �R�������a�J�����
     * @param SUB_CPY_ID
     * @param CAL_YM
     * @throws Exception
     */
    private void deleteDTEPG420(String SUB_CPY_ID, String CAL_YM) throws Exception {
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CAL_YM", CAL_YM);
        ds.update(SQL_DELETE_002);
    }

    /**
     * �R�������a�Y�ɧQ�Ω���
     * @param SUB_CPY_ID
     * @param CAL_YM
     * @throws Exception
     */
    private void deleteDTEPG400(String SUB_CPY_ID, String CAL_YM) throws Exception {
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("CAL_YM", CAL_YM);
        ds.update(SQL_DELETE_003);
    }

    /**
     * �s�W��a�J����
     * @param SUB_CPY_ID
     * @param CAL_YM
     * @throws Exception 
     */
    private void createBaseInfo(String SUB_CPY_ID, String CAL_YM, String EmpID, String EmpName, String OpUnit) throws Exception {
        bqds.clear();

        bqds.setField("CAL_YM", CAL_YM);
        bqds.setField("DEPR_KD", "3");
        bqds.setField("ACC_DEPR_KD", "1");//�|�k
        try {
            searchAndRetrieve(bqds, SQL_QUERYforBaseInfo_001);
        } catch (Exception e) {
            String msg = "���o��a�J���T���~";

            log.fatal(msg, e);
            setExitCode(ERROR);
            errorLog.addErrorLog(msg, e);
            errorLog.getErrorCountAndWriteErrorMessage();
            return;
        }
        int inputCount = getInputCount();
        if (inputCount == 0) {
            String msg = "���o��a�J���T���~";

            log.fatal(msg);
            setExitCode(ERROR);
            errorLog.addErrorLog(msg, msg);
            errorLog.getErrorCountAndWriteErrorMessage();
            return;
        }
        countManager.addCountNumber(INPUT_COUNT, inputCount); // �]�w��X���

        buds_INSERT_TABLE_G420.clear();
        buds_INSERT_TABLE_G420.preparedBatch(INSERT_DTEPG420);
        Timestamp currentTime = DATE.currentTime();
        for (prepareFetch(); fetchData(bqds); goNext()) { //�������
            try {
                buds_INSERT_TABLE_G420.beginTransaction();
                while (bqds.next()) {
                    groupHandler.begin();

                    setDTEPG420Field(CAL_YM, EmpID, EmpName, OpUnit, currentTime);
                    buds_INSERT_TABLE_G420.addBatch();
                    groupHandler.joinGroup(INSERT_DTEPG420);
                    groupHandler.end();
                }
                int countByinsert = executeBatchByBatchUpdateDataSet("�s�W", buds_INSERT_TABLE_G420, INSERT_DTEPG420, tableNameDTEPG420,
                    ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                groupHandler.displayRevomeIndex();
                //�Y�S�����~�� index �s�b
                if (groupHandler.isSuccess()) {

                    buds_INSERT_TABLE_G420.endTransaction();
                    countManager.addCountNumber(G420cnt, countByinsert);

                    //�Y�����~�� index �s�b
                } else {
                    setExitCode(ERROR);

                    buds_INSERT_TABLE_G420.rollbackTransaction();

                    buds_INSERT_TABLE_G420.beginTransaction();

                    int reDocountByInsert = reDoBatchByBatchUpdateDataSet(buds_INSERT_TABLE_G420, INSERT_DTEPG420);

                    buds_INSERT_TABLE_G420.endTransaction();

                    countManager.addCountNumber(G420cnt, reDocountByInsert);

                }
            } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                buds_INSERT_TABLE_G420.rollbackTransaction(); //�^�_��媺�@�~
                setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
                log.fatal("���Ͱ�a�J����~", e);
                errorLog.addErrorLog("���Ͱ�a�J����~", e);
                throw e; //�Y�o�Ϳ��~�h�{���X�פ�

            } finally {

                groupHandler.clear();

                //�g�X���~��ưO���� , �C�@�����@��               
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                //�������~���
                countManager.addCountNumber(ERROR_COUNT, errorCount);

            }
        }
    }

    /**
     * ���ͷ�������������µ��G
     * @param SUB_CPY_ID
     * @param CAL_YM
     * @param EmpID
     * @param EmpName
     * @param OpUnit
     * @throws Exception
     */
    private void insertToDTEPG401(String SUB_CPY_ID, String CAL_YM, String EmpID, String EmpName, String OpUnit) throws Exception {
        bqds.clear();

        bqds.setField("CAL_YM", CAL_YM);
        bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
        bqds.setField("BASE_STR_DATE", BASE_STR_DATE);
        try {
            searchAndRetrieve(bqds, SQL_QUERYforInsertDTEPG401_001);
        } catch (Exception e) {
            String msg = "���o��a�ӯ����Ӧ��~";

            log.fatal(msg, e);
            setExitCode(ERROR);
            errorLog.addErrorLog(msg, e);
            errorLog.getErrorCountAndWriteErrorMessage();
            return;
        }
        int inputCount = getInputCount();
        if (inputCount == 0) {
            String msg = "���o��a�ӯ����Ӧ��~";

            log.fatal(msg);
            setExitCode(ERROR);
            errorLog.addErrorLog(msg, msg);
            errorLog.getErrorCountAndWriteErrorMessage();
            return;
        }

        buds_INSERT_TABLE_G401.clear();
        buds_INSERT_TABLE_G401.preparedBatch(INSERT_DTEPG401);
        Timestamp currentTime = DATE.currentTime();
        for (prepareFetch(); fetchData(bqds); goNext()) { //�������
            try {
                buds_INSERT_TABLE_G401.beginTransaction();
                while (bqds.next()) {
                    groupHandler.begin();

                    setDTEPG401Field(CAL_YM, EmpID, EmpName, OpUnit, currentTime);
                    buds_INSERT_TABLE_G401.addBatch();
                    groupHandler.joinGroup(INSERT_DTEPG401);
                    groupHandler.end();
                }
                int countByinsert = executeBatchByBatchUpdateDataSet("�s�W", buds_INSERT_TABLE_G401, INSERT_DTEPG401, tableNameDTEPG401,
                    ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                groupHandler.displayRevomeIndex();
                //�Y�S�����~�� index �s�b
                if (groupHandler.isSuccess()) {

                    buds_INSERT_TABLE_G401.endTransaction();
                    countManager.addCountNumber(G401cnt, countByinsert);

                    //�Y�����~�� index �s�b
                } else {
                    setExitCode(ERROR);

                    buds_INSERT_TABLE_G401.rollbackTransaction();

                    buds_INSERT_TABLE_G401.beginTransaction();

                    int reDocountByInsert = reDoBatchByBatchUpdateDataSet(buds_INSERT_TABLE_G401, INSERT_DTEPG401);

                    buds_INSERT_TABLE_G401.endTransaction();

                    countManager.addCountNumber(G401cnt, reDocountByInsert);

                }
            } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                buds_INSERT_TABLE_G401.rollbackTransaction(); //�^�_��媺�@�~
                setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
                log.fatal("�ӯ����ӳB�z���~", e);
                errorLog.addErrorLog("�ӯ����ӳB�z���~", e);
                throw e; //�Y�o�Ϳ��~�h�{���X�פ�

            } finally {

                groupHandler.clear();

                //�g�X���~��ưO���� , �C�@�����@��               
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                //�������~���
                countManager.addCountNumber(ERROR_COUNT, errorCount);

            }
        }
    }

    /**
     * ���ͷ����a�Y�ɧQ�βv���G
     * @param SUB_CPY_ID
     * @param CAL_YM
     * @param IDX_RT
     * @param EmpID
     * @param EmpName
     * @param OpUnit
     * @throws Exception
     */
    private void createG400(String SUB_CPY_ID, String CAL_YM, BigDecimal IDX_RT, String EmpID, String EmpName, String OpUnit)
            throws Exception {
        bqds.clear();

        bqds.setField("CAL_YM", CAL_YM);
        try {
            searchAndRetrieve(bqds, SQL_QUERYforInsertDTEPG400_001);
        } catch (Exception e) {
            String msg = "���o�����������©��Ӧ��~";

            log.fatal(msg, e);
            setExitCode(ERROR);
            errorLog.addErrorLog(msg, e);
            errorLog.getErrorCountAndWriteErrorMessage();
            return;
        }
        int inputCount = getInputCount();
        if (inputCount == 0) {
            String msg = "���o�����������©��Ӧ��~";

            log.fatal(msg);
            setExitCode(ERROR);
            errorLog.addErrorLog(msg, msg);
            errorLog.getErrorCountAndWriteErrorMessage();
            return;
        }

        buds_INSERT_TABLE_G400.clear();
        buds_INSERT_TABLE_G400.preparedBatch(INSERT_DTEPG400);
        Timestamp currentTime = DATE.currentTime();
        for (prepareFetch(); fetchData(bqds); goNext()) { //�������
            try {
                buds_INSERT_TABLE_G400.beginTransaction();
                while (bqds.next()) {
                    groupHandler.begin();
                    setDTEPG400Field(CAL_YM, IDX_RT, EmpID, EmpName, OpUnit, currentTime);
                    buds_INSERT_TABLE_G400.addBatch();
                    groupHandler.joinGroup(INSERT_DTEPG400);
                    groupHandler.end();
                }
                int countByinsert = executeBatchByBatchUpdateDataSet("�s�W", buds_INSERT_TABLE_G400, INSERT_DTEPG400, tableNameDTEPG400,
                    ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                groupHandler.displayRevomeIndex();
                //�Y�S�����~�� index �s�b
                if (groupHandler.isSuccess()) {

                    buds_INSERT_TABLE_G400.endTransaction();
                    countManager.addCountNumber(G400cnt, countByinsert);

                    //�Y�����~�� index �s�b
                } else {
                    setExitCode(ERROR);

                    buds_INSERT_TABLE_G400.rollbackTransaction();

                    buds_INSERT_TABLE_G400.beginTransaction();

                    int reDocountByInsert = reDoBatchByBatchUpdateDataSet(buds_INSERT_TABLE_G400, INSERT_DTEPG400);

                    buds_INSERT_TABLE_G400.endTransaction();

                    countManager.addCountNumber(G400cnt, reDocountByInsert);

                }
            } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                buds_INSERT_TABLE_G400.rollbackTransaction(); //�^�_��媺�@�~
                setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
                log.fatal("��a�Y�ɧQ�βv�B�z���~", e);
                errorLog.addErrorLog("�ӯ����ӳB�z���~", e);
                throw e; //�Y�o�Ϳ��~�h�{���X�פ�

            } finally {

                groupHandler.clear();

                //�g�X���~��ưO���� , �C�@�����@��               
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                //�������~���
                countManager.addCountNumber(ERROR_COUNT, errorCount);

            }
        }
    }

    /**
     * �]�wG420���
     * @param CAL_YM
     * @param EmpID
     * @param EmpName
     * @param OpUnit
     * @param currentTime
     */
    private void setDTEPG420Field(String CAL_YM, String EmpID, String EmpName, String OpUnit, Timestamp currentTime) {
        //���W��
        //INV_RNT_SIZE  = bqds.INV_RNT_SIZE
        BigDecimal INV_RNT_SIZE = STRING.objToBigDecimal(bqds.getField("INV_RNT_SIZE"), BigDecimal.ZERO);
        //2.    ��ꦨ��IF(bqds.FL_EVAL ����)
        BigDecimal FL_EVAL = STRING.objToBigDecimal(bqds.getField("FL_EVAL"), BigDecimal.ZERO);
        BigDecimal COST_AMT = STRING.objToBigDecimal(bqds.getField("COST_AMT"), BigDecimal.ZERO);
        BigDecimal IFRS_COST_AMT = STRING.objToBigDecimal(bqds.getField("IFRS_COST_AMT"), BigDecimal.ZERO);
        BigDecimal DEPR_AMT = STRING.objToBigDecimal(bqds.getField("DEPR_AMT"), BigDecimal.ZERO);
        BigDecimal BLD_COST_AMT;
        if (FL_EVAL.compareTo(BigDecimal.ZERO) != 0) {
            BLD_COST_AMT = FL_EVAL;
        } else {
            BLD_COST_AMT = IFRS_COST_AMT.subtract(DEPR_AMT);
        }
        BigDecimal TOT_RNT_SIZE = STRING.objToBigDecimal(bqds.getField("TOT_RNT_SIZE"), BigDecimal.ZERO);
        BigDecimal RNT_RT;
        if (TOT_RNT_SIZE.compareTo(BigDecimal.ZERO) == 0) {
            BLD_COST_AMT = BigDecimal.ZERO;
            RNT_RT = BigDecimal.ZERO;
        } else {
            BLD_COST_AMT = BLD_COST_AMT.multiply(INV_RNT_SIZE).divide(TOT_RNT_SIZE, 0, BigDecimal.ROUND_HALF_UP);//BLD_COST_AMT * INV_RNT_SIZE / TOT_RNT_SIZE�A�|�ˤ��J����
            RNT_RT = INV_RNT_SIZE.divide(TOT_RNT_SIZE, 14, BigDecimal.ROUND_HALF_UP);//bqds.INV_RNT_SIZE / bqds.TOT_RNT_SIZE�A�|�ˤ��J��p�Ʀ��14��
        }

        buds_INSERT_TABLE_G420.setField("SUB_CPY_ID", bqds.getField("SUB_CPY_ID"));
        buds_INSERT_TABLE_G420.setField("UP_TP", "1");
        buds_INSERT_TABLE_G420.setField("BSLD_CD", bqds.getField("BASE_CD"));
        buds_INSERT_TABLE_G420.setField("CAL_YM", CAL_YM);
        buds_INSERT_TABLE_G420.setField("BASE_BLD_NAME", bqds.getField("BASE_BLD_NAME"));
        buds_INSERT_TABLE_G420.setField("IFRS_INV_RT", bqds.getField("IFRS_INV_RT"));
        buds_INSERT_TABLE_G420.setField("TOT_RNT_SIZE", TOT_RNT_SIZE);
        buds_INSERT_TABLE_G420.setField("RNT_RT", RNT_RT);
        buds_INSERT_TABLE_G420.setField("INV_RNT_SIZE", INV_RNT_SIZE);
        buds_INSERT_TABLE_G420.setField("FL_EVAL", FL_EVAL);
        buds_INSERT_TABLE_G420.setField("COST_AMT", COST_AMT);
        buds_INSERT_TABLE_G420.setField("BLD_COST_AMT", BLD_COST_AMT);
        buds_INSERT_TABLE_G420.setField("BLD_AREA", bqds.getField("BLD_AREA"));
        buds_INSERT_TABLE_G420.setField("LND_AREA", bqds.getField("LND_AREA"));
        buds_INSERT_TABLE_G420.setField("PRK_AREA", bqds.getField("PRK_AREA"));
        /* buds_INSERT_TABLE_G420.setField("DIFF_FEE", bqds.getField("DIFF_FEE"));//�L�����
         buds_INSERT_TABLE_G420.setField("EMPTY_FEE", bqds.getField("EMPTY_FEE"));//�L�����
         buds_INSERT_TABLE_G420.setField("SLF_RNT_AMT", bqds.getField("SLF_RNT_AMT"));//�L�����
         buds_INSERT_TABLE_G420.setField("LAND_TAX", bqds.getField("LAND_TAX"));//�L�����
         buds_INSERT_TABLE_G420.setField("HOUSE_TAX", bqds.getField("HOUSE_TAX"));//�L�����
         buds_INSERT_TABLE_G420.setField("PREM_AMT", bqds.getField("PREM_AMT"));//�L�����*/
        buds_INSERT_TABLE_G420.setField("CHG_DATE", currentTime);
        buds_INSERT_TABLE_G420.setField("CHG_DIV_NO", OpUnit);
        buds_INSERT_TABLE_G420.setField("CHG_ID", EmpID);
        buds_INSERT_TABLE_G420.setField("CHG_NAME", EmpName);
    }

    /**
     * �]�wG401 ���
     * @param CAL_YM
     * @param EmpID
     * @param EmpName
     * @param OpUnit
     * @param currentTime
     */
    private void setDTEPG401Field(String CAL_YM, String EmpID, String EmpName, String OpUnit, Timestamp currentTime) {
        //�p��ӯ��[�v�b�������A�|�ˤ��J��p�ƨ��
        BigDecimal WT_COST_AMT = BigDecimal.ZERO;
        BigDecimal ROOM_SIZE = STRING.objToBigDecimal(bqds.getField("ROOM_SIZE"), BigDecimal.ZERO);
        BigDecimal INV_RNT_SIZE = STRING.objToBigDecimal(bqds.getField("INV_RNT_SIZE"), BigDecimal.ZERO);

        if (INV_RNT_SIZE.compareTo(BigDecimal.ZERO) != 0) {
            WT_COST_AMT = STRING.objToBigDecimal(bqds.getField("BLD_COST_AMT"), BigDecimal.ZERO).multiply(ROOM_SIZE).divide(INV_RNT_SIZE,
                0, BigDecimal.ROUND_HALF_UP);
        }

        buds_INSERT_TABLE_G401.setField("SUB_CPY_ID", bqds.getField("SUB_CPY_ID"));
        buds_INSERT_TABLE_G401.setField("BASE_CD", bqds.getField("BASE_CD"));
        buds_INSERT_TABLE_G401.setField("CAL_YM", CAL_YM);
        buds_INSERT_TABLE_G401.setField("BLD_CD", bqds.getField("BLD_CD"));
        buds_INSERT_TABLE_G401.setField("FLD_NO", bqds.getField("FLD_NO"));

        buds_INSERT_TABLE_G401.setField("ROOM_NO", bqds.getField("ROOM_NO"));
        buds_INSERT_TABLE_G401.setField("CRT_NO", bqds.getField("CRT_NO"));
        buds_INSERT_TABLE_G401.setField("CUS_NO", bqds.getField("CUS_NO"));
        String TAX_TYPE = bqds.getField("TAX_TYPE", "").toString();
        buds_INSERT_TABLE_G401.setField("TAX_TYPE", TAX_TYPE);
        buds_INSERT_TABLE_G401.setField("ROOM_SIZE", ROOM_SIZE);
        buds_INSERT_TABLE_G401.setField("RNT_SIZE", bqds.getField("RNT_SIZE"));
        buds_INSERT_TABLE_G401.setField("INV_RNT_SIZE", INV_RNT_SIZE);
        buds_INSERT_TABLE_G401.setField("RNT_STR_DATE", bqds.getField("RNT_STR_DATE"));
        buds_INSERT_TABLE_G401.setField("RNT_END_DATE", bqds.getField("RNT_END_DATE"));
        buds_INSERT_TABLE_G401.setField("CRT_DATE", bqds.getField("CRT_DATE"));
        buds_INSERT_TABLE_G401.setField("USE_TYPE", bqds.getField("USE_TYPE"));

        BigDecimal ORG_RNT_AMT = (BigDecimal) bqds.getField("ORG_RNT_AMT");
        if (ORG_RNT_AMT == null) {
            ORG_RNT_AMT = (BigDecimal) bqds.getField("RNT_AMT");
            if ("1".equals(TAX_TYPE)) {
                ORG_RNT_AMT = ORG_RNT_AMT.divide(BD_1P05, 0, BigDecimal.ROUND_HALF_UP);
            }
        }

        buds_INSERT_TABLE_G401.setField("ORG_RNT_AMT", ORG_RNT_AMT);
        buds_INSERT_TABLE_G401.setField("FL_EVAL", bqds.getField("FL_EVAL"));
        buds_INSERT_TABLE_G401.setField("COST_AMT", bqds.getField("COST_AMT"));
        buds_INSERT_TABLE_G401.setField("BLD_COST_AMT", bqds.getField("BLD_COST_AMT"));
        buds_INSERT_TABLE_G401.setField("WT_COST_AMT", WT_COST_AMT);
        buds_INSERT_TABLE_G401.setField("INV_BLD_KD", bqds.getField("INV_BLD_KD"));
        buds_INSERT_TABLE_G401.setField("CHG_DATE", currentTime);
        buds_INSERT_TABLE_G401.setField("CHG_DIV_NO", OpUnit);
        buds_INSERT_TABLE_G401.setField("CHG_ID", EmpID);
        buds_INSERT_TABLE_G401.setField("CHG_NAME", EmpName);
    }

    /**
     * �]�wG400 ���
     * @param CAL_YM
     * @param IDX_RT
     * @param EmpID
     * @param EmpName
     * @param OpUnit
     * @param currentTime
     */
    private void setDTEPG400Field(String CAL_YM, BigDecimal IDX_RT, String EmpID, String EmpName, String OpUnit, Timestamp currentTime) {
        //�~�Ư������J
        BigDecimal SUM_RNT_AMT = STRING.objToBigDecimal(bqds.getField("ORG_RNT_AMT"), BigDecimal.ZERO).multiply(BD_12);
        SUM_RNT_AMT = SUM_RNT_AMT.multiply(BD_1P05);
        //�p��Ÿm���n
        BigDecimal INV_RNT_SIZE = STRING.objToBigDecimal(bqds.getField("INV_RNT_SIZE"), BigDecimal.ZERO);
        BigDecimal ROOM_SIZE = STRING.objToBigDecimal(bqds.getField("ROOM_SIZE"), BigDecimal.ZERO);
        BigDecimal EMP_SIZE = INV_RNT_SIZE.subtract(ROOM_SIZE);
        if (EMP_SIZE.compareTo(BigDecimal.ZERO) < 0) {
            EMP_SIZE = BigDecimal.ZERO;
        }

        //�p��b������(�Ҽ{�Ÿm���n�b������)
        BigDecimal WT_COST_AMT = STRING.objToBigDecimal(bqds.getField("WT_COST_AMT"), BigDecimal.ZERO);
        BigDecimal EMP_COST = BigDecimal.ZERO;
        if (EMP_SIZE.compareTo(BigDecimal.ZERO) > 0) {
            if (INV_RNT_SIZE.compareTo(BigDecimal.ZERO) != 0) {
                EMP_COST = STRING.objToBigDecimal(bqds.getField("BLD_COST_AMT"), BigDecimal.ZERO).multiply(EMP_SIZE).divide(INV_RNT_SIZE,
                    2, BigDecimal.ROUND_HALF_UP);
            }
            WT_COST_AMT = WT_COST_AMT.add(EMP_COST);
        }
        log.debug("BASE_CD" + bqds.getField("BASE_CD") + ", INV_RNT_SIZE" + INV_RNT_SIZE + ", ROOM_SIZE " + ROOM_SIZE + ", EMP_SIZE"
                + EMP_SIZE + ", EMP_COST=" + EMP_COST);

        WT_COST_AMT.setScale(0, BigDecimal.ROUND_HALF_UP);

        //�p����S�v
        BigDecimal RTN_RT = BigDecimal.ZERO;
        if (WT_COST_AMT.compareTo(BigDecimal.ZERO) != 0) {
            RTN_RT = SUM_RNT_AMT.divide(WT_COST_AMT, 5, BigDecimal.ROUND_HALF_UP);
        }

        //�p��X���v
        BigDecimal USE_RT = BigDecimal.ZERO;
        if (INV_RNT_SIZE.compareTo(BigDecimal.ZERO) != 0) {
            USE_RT = STRING.objToBigDecimal(bqds.getField("ROOM_SIZE"), BigDecimal.ZERO).divide(INV_RNT_SIZE, 4, BigDecimal.ROUND_HALF_UP);
        }

        //�p�����v����
        String RTN_LMT = (String) bqds.getField("RTN_LMT");
        log.fatal("======RTN_LMT=====" + RTN_LMT);
        log.fatal("======RTN_LMT=====" + FieldOptionList.getName("EP", "RTN_LMT_RT", RTN_LMT));
        BigDecimal MIN_RTN_RT = IDX_RT.add(new BigDecimal(FieldOptionList.getName("EP", "RTN_LMT_RT", RTN_LMT)));

        //�P�_�ˮֽX
        String CHK_CODE = "N";
        if (USE_RT.compareTo(new BigDecimal(0.6)) >= 0 && RTN_RT.compareTo(MIN_RTN_RT) > 0) {
            CHK_CODE = "Y";
        }
        BigDecimal TOT_RNT_SIZE = STRING.objToBigDecimal(bqds.getField("TOT_RNT_SIZE"), BigDecimal.ZERO);
        buds_INSERT_TABLE_G400.setField("SUB_CPY_ID", bqds.getField("SUB_CPY_ID"));
        buds_INSERT_TABLE_G400.setField("BASE_CD", bqds.getField("BASE_CD"));
        buds_INSERT_TABLE_G400.setField("CAL_YM", CAL_YM);
        buds_INSERT_TABLE_G400.setField("IFRS_INV_RT", bqds.getField("IFRS_INV_RT"));
        buds_INSERT_TABLE_G400.setField("TOT_RNT_SIZE", TOT_RNT_SIZE);
        buds_INSERT_TABLE_G400.setField("RNT_RT", bqds.getField("RNT_RT"));
        buds_INSERT_TABLE_G400.setField("INV_RNT_SIZE", INV_RNT_SIZE);
        buds_INSERT_TABLE_G400.setField("FL_EVAL", bqds.getField("FL_EVAL"));
        buds_INSERT_TABLE_G400.setField("COST_AMT", bqds.getField("COST_AMT"));
        buds_INSERT_TABLE_G400.setField("BLD_AREA", bqds.getField("BLD_AREA"));
        buds_INSERT_TABLE_G400.setField("PRK_AREA", bqds.getField("PRK_AREA"));
        buds_INSERT_TABLE_G400.setField("INV_BLD_KD", bqds.getField("INV_BLD_KD"));
        buds_INSERT_TABLE_G400.setField("BASE_BLD_NAME", bqds.getField("BASE_BLD_NAME"));
        buds_INSERT_TABLE_G400.setField("RNT_SIZE", bqds.getField("ROOM_SIZE"));
        buds_INSERT_TABLE_G400.setField("SLF_SIZE", TOT_RNT_SIZE.subtract(INV_RNT_SIZE));
        buds_INSERT_TABLE_G400.setField("USE_RT", USE_RT);
        buds_INSERT_TABLE_G400.setField("SUM_RNT_AMT", SUM_RNT_AMT);
        buds_INSERT_TABLE_G400.setField("WT_COST_AMT", WT_COST_AMT);
        buds_INSERT_TABLE_G400.setField("RTN_RT", RTN_RT);
        buds_INSERT_TABLE_G400.setField("IDX_RT", IDX_RT);
        buds_INSERT_TABLE_G400.setField("RTN_LMT", RTN_LMT);
        buds_INSERT_TABLE_G400.setField("MIN_RTN_RT", MIN_RTN_RT);
        buds_INSERT_TABLE_G400.setField("CHK_CODE", CHK_CODE);
        buds_INSERT_TABLE_G400.setField("CHG_DATE", currentTime);
        buds_INSERT_TABLE_G400.setField("CHG_DIV_NO", OpUnit);
        buds_INSERT_TABLE_G400.setField("CHG_ID", EmpID);
        buds_INSERT_TABLE_G400.setField("CHG_NAME", EmpName);

    }

    /**
     * ��l�p��
     * @throws ModuleException
     */
    private void initCountManager() throws ModuleException {

        countManager.createCountType("START");
        countManager.writeLog();
        countManager.clearCountTypeAndNumber();

        countManager.createCountType(INPUT_COUNT);
        countManager.createCountType(ERROR_COUNT);
        countManager.createCountType(OUTPUT_COUNT);
        countManager.createCountType(G420cnt);
        countManager.createCountType(G401cnt);
        countManager.createCountType(G400cnt);
    }

    /**
     * ����妸�ðO����X��ƥB�B�z���~��
     * @param action
     * @param buds
     * @param sql
     * @param tableName
     * @param executeStatusType
     * @return
     * @throws DBException
     */
    private int executeBatchByBatchUpdateDataSet(String action, BatchUpdateDataSet buds, String key, String tableName, int executeStatusType)
            throws DBException {

        //�^�ǰ��檺���G , �i�Ѧҳ̤U�����N�X��
        int buds_Ret[] = buds.executeBatch();

        //���]���~���}�C
        Object errObject[][] = errorHandler.getErrorArray(buds.getBatchUpdateErrorArray(), buds_Ret, buds.getBatchMapsArray(),
            executeStatusType);

        //executebatch���~�B�z
        //�^�Ǫ����� �� Object[i][3] , 
        //Object[i][0] �N���ĴX�����~ , index �� 0 �}�l ,
        //Object[i][1] �� Map , ���ܿ��~�� key �� value
        //Object[i][2] ��SQLException , �i�� SQLSTATE �� CODE �P�_��ؿ��~
        if (errObject != null && errObject.length > 0) {

            for (int i = 0; i < errObject.length; i++) {
                Map errorDataMap = (Map) errObject[i][1];
                sb.append(action).append(tableName).append("���`");
                sb.append("�F�]�w�Ѽ� = ").append(errorDataMap);
                String message = sb.toString();
                sb.setLength(0);
                errorLog.addErrorLog(message, errObject[i][2]);
            }
        }

        //���XaddBatch�������
        int outputCount = buds_Ret.length;

        //�N��X��Ʀ�����Insert�ɵo�ͪ����~
        outputCount -= errObject.length;

        groupHandler.removeIndex(errObject, key);

        return outputCount;
    }

    /**
     * 
     * @param buds
     * @param key
     * @return
     * @throws DBException
     */
    private int reDoBatchByBatchUpdateDataSet(BatchUpdateDataSet buds, String key) throws DBException {

        //���o���T�����
        List redoList = groupHandler.filterExecuteList(buds.getBatchMapsArray(), key);

        //�]�w redo ���Ѽ�
        batchProcesser.setFields(redoList, buds);

        //���s����
        int output[] = buds.executeBatch();

        return output.length;
    }
}
