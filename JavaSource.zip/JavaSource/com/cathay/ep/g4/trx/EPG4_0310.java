package com.cathay.ep.g4.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.ep.g3.module.EPG3_0100_mod;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0G400;
import com.cathay.ep.z0.module.EP_Z0G420;
import com.cathay.rpt.XlsUtils;
import com.cathay.rpt.XlsUtils.SORT_RULE;
import com.cathay.rpt.datasource.xls.ColumnOptions;
import com.cathay.rpt.datasource.xls.ColumnSetting;
import com.cathay.util.ControlMCaller;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2015/01/20  1.0 Created ������
 * 
 * UCEPG4_0310_�Y�ɧQ�βv�@�~
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �Y�ɧQ�βv�@�~
 * �{���W��    EPG4_0310
 * �@�~�覡    ONLINE
 * ���n����    (1) �d�߫��s�G�d�ߧY�ɧQ�βv�C
 * (2) ���͸�ƫ��s�G�u�W�I�s�妸�A����Y�ɧQ�Χ妸�B�z�A���ͷ���Y�ɧQ�βv���G�C
 * ���s���v    FUNC_ID = EPG40310
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 * </pre>
 * @author ����[
 * @since 2015/1/22
 */
@SuppressWarnings("unchecked")
public class EPG4_0310 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPG4_0310.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    private BigDecimal percent = new BigDecimal("100");

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        //���o�����q
        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
        } catch (ErrorInputException e) {
            log.error("��l���o�����q�O����");
        }
        //���o��a�J���ƨӷ�
        resp.addOutputData("G4CalList", FieldOptionList.getName("EP", "G4_CAL_TP"));

        //�b�U�O�M��
        resp.addOutputData("BALTYPEList", FieldOptionList.getName("EP", "BAL_TYPE"));
        
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            /*dataMap.put("IDX_RT", STRING.objToBigDecimal(dataMap.get("IDX_RT"), BigDecimal.ZERO).divide(percent, 4,
                BigDecimal.ROUND_HALF_UP));//�ʤ�����p��*/

            List<Map> rtnList = new EP_Z0G400().query(dataMap);
            int NO = 0;
            for (Map rtnMap : rtnList) {
                rtnMap.put("NO", ++NO);

                //�ഫ�ʤ���
                rtnMap.put("RNT_RT", STRING.objToBigDecimal(rtnMap.get("RNT_RT"), BigDecimal.ZERO).multiply(percent));
                rtnMap.put("RTN_RT", STRING.objToBigDecimal(rtnMap.get("RTN_RT"), BigDecimal.ZERO).multiply(percent));
                rtnMap.put("USE_RT", STRING.objToBigDecimal(rtnMap.get("USE_RT"), BigDecimal.ZERO).multiply(percent));
                rtnMap.put("MIN_RTN_RT", STRING.objToBigDecimal(rtnMap.get("MIN_RTN_RT"), BigDecimal.ZERO).multiply(percent));
            }
            resp.addOutputData("rtnList", rtnList);

            MessageUtil.setMsg(msg, "EPG4_0310_ERRMSG_001");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPG4_0310_ERRMSG_002");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0310_ERRMSG_003");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0310_ERRMSG_004");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPG4_0310_ERRMSG_004");//�d�ߥ���
        }

        return resp;
    }

    /**
     * ���͸��
     * @param req
     * @return
     */
    public ResponseContext doCreateData(RequestContext req) {
        try {

            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            dataMap.put("IDX_RT", STRING.objToBigDecimal(dataMap.get("IDX_RT"), BigDecimal.ZERO).divide(percent, 5,
                BigDecimal.ROUND_HALF_UP));//�ʤ�����p��

            //�ˮְ�a�J����
            String G4_CAL_TP = MapUtils.getString(dataMap, "G4_CAL_TP");
            if ("1".equals(G4_CAL_TP)) { // �W�ǷJ����
                try {
                    dataMap.put("UP_TP", "1");
                    new EP_Z0G420().queryList(dataMap);
                } catch (DataNotFoundException dnfe) {
                    throw new ModuleException("EPG4_0310_ERRMSG_005");//��a�J���Ʃ|���W�ǡA���i�ާ@
                }
            }

            //�ˮ֧��³B�z���A
            Map deprMap = new HashMap();
            String SUB_CPY_ID = MapUtils.getString(dataMap, "SUB_CPY_ID");
            String CAL_YM = MapUtils.getString(dataMap, "CAL_YM");
            deprMap.put("SUB_CPY_ID", SUB_CPY_ID);
            deprMap.put("DEPR_KD", "3");// (IFRS)
            deprMap.put("DEPR_YM", CAL_YM);

            new EPG3_0100_mod().checkUpdStatus(deprMap, "1");
            Transaction.begin();
            try {
                ControlMCaller caller = new ControlMCaller(true);
                String BAT_KEY = new StringBuilder().append(SUB_CPY_ID).append("_").append(CAL_YM).toString();
                String[] batchArgArray = new String[] { SUB_CPY_ID, CAL_YM, G4_CAL_TP, MapUtils.getString(dataMap, "IDX_RT"),
                        user.getEmpID(), user.getEmpName(), user.getOpUnit(), BAT_KEY };
                caller.runBatch("EPG4_B100", BAT_KEY, batchArgArray, true);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
            }

            MessageUtil.setMsg(msg, "EPG4_0310_ERRMSG_006");//�Y�ɧQ�βv�妸�B�z���еy�᭫�s�d��
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0310_ERRMSG_007");//���ͥ���
            }
        } catch (Exception e) {
            log.error("���ͥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPG4_0310_ERRMSG_007");//���ͥ���
        }

        return resp;
    }

    /**
     * �ץX
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {
        try {

            Map dataMap = VOTool.jsonToMap(req.getParameter("dataMap"));
            /*dataMap.put("IDX_RT", STRING.objToBigDecimal(dataMap.get("IDX_RT"), BigDecimal.ZERO).divide(percent, 4,
                BigDecimal.ROUND_HALF_UP));//�ʤ�����p��*/
            List<Map> rtnList = new EP_Z0G400().query(dataMap);

            //�����ɦW :�j�ӧY�ɧQ�βv_YYYYMMDD.xls
            StringBuilder sb = new StringBuilder();
            String fileName = sb.append(MessageUtil.getMessage("EPG4_0310_MSG_FILE_NAME")).append("_").append(
                DATE.toDate_yyyyMMdd(DATE.getDBDate())).toString();//�j�ӧY�ɧQ�βv_YYYYMMDD

            //�]�w��Ʈ榡
            List<List<ColumnSetting>> titles = new ArrayList<List<ColumnSetting>>();
            List<List<ColumnSetting>> records = new ArrayList<List<ColumnSetting>>();
            //�]�w"�Ĥ@��"
            final LocaleDisplay display = new LocaleDisplay("EP", user);
            sb.setLength(0);
            //�i�p��~��j�j�ӧY�ɧQ�βv
            String title = sb.append(display.formatDateym(MapUtils.getString(dataMap, "CAL_YM"), null)).append(
                MessageUtil.getMessage("EPG4_0310_MSG_FILE_NAME")).toString();
            setTitles(titles, records, title);

            //�ץXexcel
            XlsUtils xlsUtils = new XlsUtils(fileName, rtnList, resp);
            xlsUtils.parseToSheetSetting(fileName, titles, records);
            xlsUtils.execute(new XlsUtils.ListProcessHandler() {
                int NO = 0;

                /**
                 * �v���B�z
                 */
                @Override
                protected boolean dataOutputProcess(Map dataMap) {
                    dataMap.put("NO", ++NO);
                    dataMap.put("CAL_YM", display.formatDateym(dataMap.get("CAL_YM"), ""));

                    //�ഫ�ʤ���
                    dataMap.put("RNT_RT", STRING.objToBigDecimal(dataMap.get("RNT_RT"), BigDecimal.ZERO).multiply(percent));
                    dataMap.put("RTN_RT", STRING.objToBigDecimal(dataMap.get("RTN_RT"), BigDecimal.ZERO).multiply(percent));
                    dataMap.put("USE_RT", STRING.objToBigDecimal(dataMap.get("USE_RT"), BigDecimal.ZERO).multiply(percent));
                    dataMap.put("MIN_RTN_RT", STRING.objToBigDecimal(dataMap.get("MIN_RTN_RT"), BigDecimal.ZERO).multiply(percent));
                    return true;//true:�����n�ץX ; false:�������ץX
                }

            });

            MessageUtil.setMsg(msg, "EPG4_0310_ERRMSG_008");//�ץX����
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0310_ERRMSG_009");//�ץX����
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPG4_0310_ERRMSG_009");//�ץX����
        }

        return resp;
    }

    /**
     * �]�w�ץX���榡
     * @param titles
     * @param records
     * @param title
     */
    private void setTitles(List<List<ColumnSetting>> titles, List<List<ColumnSetting>> records, String title) {

        //�ɮפ��e�Ĥ@��Х[�W�H�U���
        List<ColumnSetting> titleRow = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(titleRow, XlsUtils.EMPTY, title, new ColumnOptions(1, 15));
        titles.add(titleRow);

        List<ColumnSetting> firstRow = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_NO"), new ColumnOptions(1, 1));//�Ǹ�
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_INV_BLD_KD_NM"), new ColumnOptions(1, 1));//���j�Ӥ���
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_BASE_CD"), new ColumnOptions(1, 1));//��a�N��
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_BASE_BLD_NAME"), new ColumnOptions(1, 1));//�j�ӦW��
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_TOT_RNT_SIZE"), new ColumnOptions(1, 1));//�`�Ӽh���n
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_INV_RNT_SIZE"), new ColumnOptions(1, 1));//���W��
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_SLF_SIZE"), new ColumnOptions(1, 1));//�ۥΩW��
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_RNT_RT"), new ColumnOptions(1, 1));//�i�X�����
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_RNT_SIZE"), new ColumnOptions(1, 1));//��ڥX���W��
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_USE_RT"), new ColumnOptions(1, 1));//�X���v
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_SUM_RNT_AMT"), new ColumnOptions(1, 1));//����
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_WT_COST_AMT"), new ColumnOptions(1, 1));//�b������
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_RTN_RT"), new ColumnOptions(1, 1));//���S�v
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_MIN_RTN_RT"), new ColumnOptions(1, 1));//�̤p����v
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0310_UI_CHK_CODE"), new ColumnOptions(1, 1));//�ˮ�
        titles.add(firstRow);

        //���e
        List<ColumnSetting> firstRow_ = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow_, "NO", XlsUtils.EMPTY);//�Ǹ�
        XlsUtils.addColumnAttrs(firstRow_, "INV_BLD_KD_NM", XlsUtils.EMPTY);//���j�Ӥ���
        XlsUtils.addColumnAttrs(firstRow_, "BASE_CD", XlsUtils.EMPTY);//��a�N��
        XlsUtils.addColumnAttrs(firstRow_, "BASE_BLD_NAME", XlsUtils.EMPTY);//�j�ӦW��
        XlsUtils.addColumnAttrs(firstRow_, "TOT_RNT_SIZE", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));//�`�Ӽh���n
        XlsUtils.addColumnAttrs(firstRow_, "INV_RNT_SIZE", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));//���W��
        XlsUtils.addColumnAttrs(firstRow_, "SLF_SIZE", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));//�ۥΩW��
        XlsUtils.addColumnAttrs(firstRow_, "RNT_RT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));//�i�X�����
        XlsUtils.addColumnAttrs(firstRow_, "RNT_SIZE", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));//��ڥX���W��
        XlsUtils.addColumnAttrs(firstRow_, "USE_RT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));//�X���v
        XlsUtils.addColumnAttrs(firstRow_, "SUM_RNT_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));//����
        XlsUtils.addColumnAttrs(firstRow_, "WT_COST_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));//�b������
        XlsUtils.addColumnAttrs(firstRow_, "RTN_RT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));//���S�v
        XlsUtils.addColumnAttrs(firstRow_, "MIN_RTN_RT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));//�̤p����v
        XlsUtils.addColumnAttrs(firstRow_, "CHK_CODE", XlsUtils.EMPTY);//�ˮ�
        records.add(firstRow_);

    }

}
