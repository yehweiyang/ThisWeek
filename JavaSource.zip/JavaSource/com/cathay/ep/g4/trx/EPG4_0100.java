package com.cathay.ep.g4.trx;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.ep.g4.module.EP_G40100;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0G100;
import com.cathay.ep.z0.module.EP_Z0G110;
import com.cathay.ep.z0.module.EP_Z0G510;
import com.cathay.rpt.XlsUtils;
import com.cathay.rpt.XlsUtils.SORT_RULE;
import com.cathay.rpt.datasource.xls.ColumnOptions;
import com.cathay.rpt.datasource.xls.ColumnSetting;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2014/12/04  1.0 Created ������
 * 
 * UCEPG4_0100_��a�d��
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    ��a�d��
 * �{���W��    EPG4_0100
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l�C
 * (2) �d�� �w �ϥΪ̫��U���s��A�d�߰�a���Ӹ�ơC
 * (2) �j�ӦW�� �w �ϥΪ̫��s���A�i�J��a��X�d�ߵe���C
 * (3) �ץX �w �ϥΪ̫��U���s��A�ץX��a���ӲM���ơC
 * (2) ��a��s �w �ϥΪ̫��U���s��A�s�����a�߮ק@�~�C
 * (2) �j�ӹ�Ӻ��@ �w �ϥΪ̫��U���s��A�s���j�ӹ���ɺ��@��ơC
 * (2) ������������ �w �ϥΪ̫��U���s��A�s����a�����������@�@�~�C
 * (3) ���������R�P�w �ϥΪ̫��U���s��A�s����a�����R�P�e���C
 * ���s���v    �M��FUNC_ID = EPG40100
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 * 
 * [20190223] �W�[�d�ߤ���A�ץX�W�[���Y�B�R�����ϥε{��  �߮׳渹 : 190130000429
 * [20191119] �W�[�վ\�ӽЫ��s�P�W�[�d�߱��� �߮׳渹 : 191025000965
 * [20191126] Modified �W�[�ˮ֬O�_���å��վ\�]�w �߮׳渹 : 191025000965
 * </pre>
 * @author ����[
 * @since 2014/12/25
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPG4_0100 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPG4_0100.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);

        resp.addOutputData("BASE_CD", req.getParameter("BASE_CD"));

        //���o�����q�O
        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
        } catch (ErrorInputException e) {
            log.error("��l���o�����q�O����");
        }

        //�����M��
        resp.addOutputData("ZONEList", FieldOptionList.getName("EP", "ZONE"));
        //���O
        resp.addOutputData("INV_TPList", FieldOptionList.getName("EP", "INV_TP"));
        //�d������
        resp.addOutputData("qryTPList", FieldOptionList.getName("EP", "G41_QRY_TP"));

        resp.addOutputData("TODAY", DATE.today());
        /*[20190223] �ק�� �s�W������l���� */

        //��a����
        resp.addOutputData("BASE_TYPE_List", FieldOptionList.getName("EP", "BASE_TYPE")); //[20191119]�s�W�U�Կ��

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> rtnList = new EP_G40100().queryList(reqMap);

            Map sumMap = this.countTotal(rtnList);

            resp.addOutputData("rtnList", rtnList);
            resp.addOutputData("sumMap", sumMap);

            MessageUtil.setMsg(msg, "EPG4_0100_MSG_001");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPG4_0100_MSG_002");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0100_MSG_003");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0100_MSG_004");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPG4_0100_MSG_004");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �ץX
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {
        try {
            /*[20190223] �ץX�ק�A�s�W�T��title�ۭqSheetSetting */
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> dataList = new EP_G40100().queryList(reqMap);

            //�����ɦW :���I�s���w�s�d��_YYYYMMDD.xls
            String G41_QRY_TP_NM = MapUtils.getString(reqMap, "G41_QRY_TP_NM");//�d����������            
            String fileName = MessageUtil.getMessage("EPG4_0100_MSG_FILE_NAME") + DATE.toDate_yyyyMMdd(DATE.getDBDate());//��a����_YYYYMMDD
            if (!"����".equals(G41_QRY_TP_NM)) {
                fileName = G41_QRY_TP_NM + fileName;
            }
            //�[�J�X�p�C
            Map sumMap = this.countTotal(dataList);
            sumMap.put("SLF_CD", MessageUtil.getMessage("EPG4_0100_UI_SUM"));//"�X�p"
            dataList.add(sumMap);
            final LocaleDisplay display = new LocaleDisplay("EP", user);

            List<List<ColumnSetting>> titles = new ArrayList<List<ColumnSetting>>();
            List<ColumnSetting> title1 = new ArrayList<ColumnSetting>();
            StringBuilder sb = new StringBuilder();
            XlsUtils.addColumnAttrs(title1, XlsUtils.EMPTY, sb.append(MessageUtil.getMessage("EPG4_0100_UI_G41_QRY_TP")).append(':')
                    .append(reqMap.get("G41_QRY_TP_NM")).toString(), new ColumnOptions(1, 11, SORT_RULE.STRING));
            titles.add(title1);
            sb.setLength(0);
            List<ColumnSetting> title2 = new ArrayList<ColumnSetting>();
            XlsUtils.addColumnAttrs(title2, XlsUtils.EMPTY,
                sb.append(MessageUtil.getMessage("EPG4_0100_UI_TRN_DT")).append(':').append(MapUtils.getString(reqMap, "QRY_DATE", ""))
                        .toString(), new ColumnOptions(1, 11, SORT_RULE.STRING));
            titles.add(title2);
            sb.setLength(0);
            List<ColumnSetting> title3 = new ArrayList<ColumnSetting>();
            XlsUtils.addColumnAttrs(title3, XlsUtils.EMPTY,
                sb.append(MessageUtil.getMessage("EPG4_0100_UI_PRD_DT")).append(':').append(DATE.today()).toString(), new ColumnOptions(1,
                        11, SORT_RULE.STRING));
            titles.add(title3);
            sb.setLength(0);
            List<ColumnSetting> title4 = new ArrayList<ColumnSetting>();

            List<List<ColumnSetting>> records = new ArrayList<List<ColumnSetting>>();
            List<ColumnSetting> firstRow_ = new ArrayList<ColumnSetting>();
            records.add(firstRow_);

            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_NO"));
            XlsUtils.addColumnAttrs(firstRow_, "NO", MessageUtil.getMessage("EPG4_0100_UI_NO"), new ColumnOptions(1, 1, SORT_RULE.STRING));
            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_SLF_CD"));
            XlsUtils.addColumnAttrs(firstRow_, "SLF_CD", MessageUtil.getMessage("EPG4_0100_UI_SLF_CD"), new ColumnOptions(1, 1,
                    SORT_RULE.STRING));
            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_INV_CD"));
            XlsUtils.addColumnAttrs(firstRow_, "INV_CD", MessageUtil.getMessage("EPG4_0100_UI_INV_CD"), new ColumnOptions(1, 1,
                    SORT_RULE.STRING));
            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_BASE_BLD_NAME"));
            XlsUtils.addColumnAttrs(firstRow_, "BASE_BLD_NAME", MessageUtil.getMessage("EPG4_0100_UI_BASE_BLD_NAME"), new ColumnOptions(1,
                    1, SORT_RULE.STRING));
            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_ZONE"));
            XlsUtils.addColumnAttrs(firstRow_, "ZONE_NM", MessageUtil.getMessage("EPG4_0100_UI_ZONE"), new ColumnOptions(1, 1,
                    SORT_RULE.STRING));
            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_ZONE_CD"));
            XlsUtils.addColumnAttrs(firstRow_, "ZONE_CD_NM", MessageUtil.getMessage("EPG4_0100_UI_ZONE_CD"), new ColumnOptions(1, 1,
                    SORT_RULE.STRING));
            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_BLD_ADDR"));
            XlsUtils.addColumnAttrs(firstRow_, "BLD_ADDR", MessageUtil.getMessage("EPG4_0100_UI_BLD_ADDR"), new ColumnOptions(1, 1,
                    SORT_RULE.STRING));
            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_LND_LOCATE"));
            XlsUtils.addColumnAttrs(firstRow_, "LND_LOCATE", MessageUtil.getMessage("EPG4_0100_UI_LND_LOCATE"), new ColumnOptions(1, 1,
                    SORT_RULE.STRING));
            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_AREA"));
            XlsUtils.addColumnAttrs(firstRow_, "AREA", MessageUtil.getMessage("EPG4_0100_UI_AREA"), new ColumnOptions(1, 1,
                    SORT_RULE.NUMBER));
            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_BUY_DT"));
            XlsUtils.addColumnAttrs(firstRow_, "BUY_DT", MessageUtil.getMessage("EPG4_0100_UI_BUY_DT"), new ColumnOptions(1, 1,
                    SORT_RULE.STRING));
            XlsUtils.addColumnAttrs(title4, XlsUtils.EMPTY, MessageUtil.getMessage("EPG4_0100_UI_BUY_AMT"));
            XlsUtils.addColumnAttrs(firstRow_, "BUY_AMT", MessageUtil.getMessage("EPG4_0100_UI_BUY_AMT"), new ColumnOptions(1, 1,
                    SORT_RULE.NUMBER));

            titles.add(title4);

            XlsUtils xlsUtils = new XlsUtils(fileName, dataList, resp);
            xlsUtils.parseToSheetSetting(fileName, titles, records);
            xlsUtils.initExportSetting();

            xlsUtils.execute(new XlsUtils.ListProcessHandler() {
                @Override
                protected boolean dataOutputProcess(Map dataMap) {
                    dataMap.put("BUY_DT", display.formatDate((Date) dataMap.get("BUY_DT"), "/", ""));
                    return true;
                }
            });

            MessageUtil.setMsg(msg, "EPG4_0100_MSG_005");//�ץX����
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0100_MSG_006");//�ץX����
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPG4_0100_MSG_006");//�ץX����
        }

        return resp;
    }

    /**
     * �u�ϰ�O�v�U�Կ��s��
     * @param req
     * @return
     */
    public ResponseContext doGetZONE_CD(RequestContext req) {
        try {
            //�u�ϰ�O�v�U�Կ��G
            resp.addOutputData("ZONE_CDList", FieldOptionList.getName("EP", "ZONE_CD_" + req.getParameter("ZONE")));
        } catch (Exception e) {
            log.error("�u�ϰ�O�v�U�Կ��s�ʥ���", e);
        }

        return resp;
    }


    //[20191119]�s�Wmethod
    /**
     * �վ\�ӽ�
     * @param req
     * @return
     */
    public ResponseContext doApply(RequestContext req) {
        try {

            Map aplyMap = VOTool.jsonToMap(req.getParameter("aplyMap"));
            List<Map> tmpBldList = VOTool.jsonAryToMaps(req.getParameter("bldList"));
            List<String> bldList = new ArrayList();
            for (Map map : tmpBldList) {
                bldList.add(MapUtils.getString(map, "BASE_CD"));
            }
            //[20191122]�s�W�վ\����������
            String APLY_MEMO = MapUtils.getString(aplyMap, "APLY_MEMO");
            if (StringUtils.isBlank(APLY_MEMO)) {
                throw new ErrorInputException("EPG4_0100_MSG_011");//�վ\�������i����
            }

            StringBuilder sb = new StringBuilder();
            //�d�߰�a�վ\�ݳB�z�M��
            try {
                List<Map> pcsBaseList = new EP_Z0G510().queryBaseProcessList(MapUtils.getString(aplyMap, "SUB_CPY_ID"), bldList);
                sb.append(MessageUtil.getMessage("EPG4_0100_MSG_007"));//�����a���b�վ\�å�
                for (Map map : pcsBaseList) {
                    sb.append(STRING.lineSeparator).append(MapUtils.getString(map, "BASE_BLD_NAME", ""));
                }
                throw new ModuleException(sb.toString());
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L��Ƶ������`", dnfe);
            }
            //[20191126]�W�[�ˮ֬O�_���å��վ\�]�w(�ק�}�l)
            //�d�߰�a�վ\�]�w�M��
            try {
                List<Map> noCfgList = new EP_Z0G100().queryBaseConfigList(MapUtils.getString(aplyMap, "SUB_CPY_ID"), bldList);
                if (noCfgList.size() == bldList.size()) {
                    throw new ModuleException(MessageUtil.getMessage("EPG4_0100_MSG_012"));//�Ŀ�M�泣���]�w��a�å�
                }
                boolean applyConfirmIsNotY = !"Y".equals(req.getParameter("applyConfirm"));
                sb.setLength(0);
                sb.append(MessageUtil.getMessage("EPG4_0100_MSG_013"));//������a�|���]�w�å��A�T�{�վ\�H���]�w�p�U
                for (Map map : noCfgList) {
                    if (applyConfirmIsNotY) {
                        sb.append(STRING.lineSeparator).append(MapUtils.getString(map, "BASE_BLD_NAME", ""));
                    } else {
                        //�w�g�T�{�u�վ\�������å��N��S���å��վ\�]�w��BASE_CD����
                        bldList.remove(MapUtils.getString(map, "BASE_CD"));
                    }
                }
                if (applyConfirmIsNotY) {
                    resp.addOutputData("confirmMsg", sb.toString());
                    return resp;
                }
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L��a�վ\�]�w�M���Ƶ������`", dnfe);
            }
            //[20191126](�קﵲ��)
            EP_G40100 theEP_G40100 = new EP_G40100();
            EP_Z0G110 theEP_Z0G110 = new EP_Z0G110();
            Transaction.begin();
            try {
                //�s�W�å��վ\�ӽ�
                String aplyNo = theEP_G40100.applyG500(aplyMap, user);
                //�]�w�վ\�s�� 
                aplyMap.put("EP_APLY_NO", aplyNo);
                //�妸��s��a�վ\�s��
                theEP_Z0G110.batchUpdateAplyNo(aplyMap, bldList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPG4_0100_MSG_009");//�վ\�ӽЧ���
        } catch (ErrorInputException eie) {
            log.error(eie, eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPG4_0100_MSG_002");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("�վ\�ӽХ���", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0100_MSG_003");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0100_MSG_010");//�վ\�ӽХ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPG4_0100_MSG_010");//�վ\�ӽЧ�������
        }

        return resp;
    }

    /**
     * @param rtnList
     * @return
     */
    private Map countTotal(List<Map> rtnList) {
        String[] fieldsForGroupTotal = { "AREA", "BUY_AMT" };

        Map<String, BigDecimal> amtMap = new HashMap<String, BigDecimal>();
        int i = 0;
        for (Map rtnMap : rtnList) {
            rtnMap.put("NO", ++i);
            for (String field : fieldsForGroupTotal) {
                BigDecimal value_amtMap = STRING.objToBigDecimal(amtMap.get(field), BigDecimal.ZERO);
                BigDecimal value_rtnMap = STRING.objToBigDecimal(rtnMap.get(field), BigDecimal.ZERO);
                amtMap.put(field, value_amtMap.add(value_rtnMap));
            }
        }

        return amtMap;
    }

}
