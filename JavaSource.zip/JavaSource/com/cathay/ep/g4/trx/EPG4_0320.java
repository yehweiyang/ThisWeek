package com.cathay.ep.g4.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0G410;
import com.cathay.ep.z0.module.EP_Z0G420;
import com.cathay.rpt.XlsUtils;
import com.cathay.rpt.XlsUtils.SORT_RULE;
import com.cathay.rpt.datasource.xls.ColumnOptions;
import com.cathay.rpt.datasource.xls.ColumnSetting;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2015/01/20  1.0 Created ������
 * UCEPG4_0320_�������J���p�@�~�@�~
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �������J���p�@�~�@�~
 * �{���W��    EPG4_0320 
 * �@�~�覡    ONLINE
 * ���n����    (1) �d�߫��s�G�d�߯������J���p���C
 * (2) ���͸�ƫ��s�G���ͷ��믲�����J���p���G�C
 * (3) �ץX���s�G�ץX�������J���p���G�C
 * ���s���v    FUNC_ID = EPG40320
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 * </pre>
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EPG4_0320 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPG4_0320.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    private BigDecimal percent = new BigDecimal("100");;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        //���o�����q�O
        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
        } catch (ErrorInputException e) {
            log.error("��l���o�����q�O����");
        }
        //���o��������
        resp.addOutputData("costKDList", FieldOptionList.getName("EP", "COST_KD"));
        //�b�U�O�M��
        resp.addOutputData("BALTYPEList", FieldOptionList.getName("EP", "BAL_TYPE"));
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            this.query(req);
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");
        }

        return resp;
    }

    /**
     * ���͸��
     * @param req
     * @return
     */
    public ResponseContext doProcess(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            // �ˮְ�a�J����
            reqMap.put("UP_TP", "1");
            EP_Z0G420 theEP_Z0G420 = new EP_Z0G420();
            try {
                theEP_Z0G420.queryList(reqMap);
            } catch (DataNotFoundException dnfe) {
                throw new ModuleException(MessageUtil.getMessage("EPG4_0320_ERRMSG_006"));//�L�k���o�j�Ӱ�a�J����
            }

            //�ˮֵ|����ƬO�_�W��
            reqMap.put("UP_TP", "3");
            try {
                theEP_Z0G420.queryList(reqMap);
            } catch (DataNotFoundException dnfe) {
                throw new ModuleException(MessageUtil.getMessage("EPG4_0320_ERRMSG_007"));//����|����Ʃ|���W�ǡA���i�ާ@
            }

            //�ˮֺ޲z�O��ƬO�_�W��
            reqMap.put("UP_TP", "2");
            try {
                theEP_Z0G420.queryList(reqMap);
            } catch (DataNotFoundException dnfe) {
                throw new ModuleException(MessageUtil.getMessage("EPG4_0320_ERRMSG_008"));//����޲z�O��Ʃ|���W�ǡA���i�ާ@
            }

            Transaction.begin();
            try {

                new EP_Z0G410().process(reqMap, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPG4_0320_ERRMSG_002");//�j�Ӧ��J��X�B�z����

            try {
                this.query(req);
            } catch (Exception e) {
                log.error("�j�Ӧ��J��X�B�z����, ���d����", e);
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0320_ERRMSG_003");//�j�Ӧ��J��X�B�z����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPG4_0320_ERRMSG_003");//�j�Ӧ��J��X�B�z����
        }

        return resp;
    }

    /**
     * �ץX
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            List<Map> rtnList = new EP_Z0G410().queryList(reqMap);

            //�����ɦW :�j�Ӧ��J��X���p_YYYYMMDD.xls
            StringBuilder sb = new StringBuilder();
            String fileName = sb.append(MessageUtil.getMessage("EPG4_0320_MSG_FILE_NAME")).append("_").append(
                DATE.toDate_yyyyMMdd(DATE.getDBDate())).toString();//�j�ӧY�ɧQ�βv_YYYYMMDD

            //�]�w��Ʈ榡
            List<List<ColumnSetting>> titles = new ArrayList<List<ColumnSetting>>();
            List<List<ColumnSetting>> records = new ArrayList<List<ColumnSetting>>();
            //�]�w"�Ĥ@��"
            final LocaleDisplay display = new LocaleDisplay("EP", user);
            sb.setLength(0);
            //�i�p��~��j�j�Ӧ��J��X���p
            String title = sb.append(display.formatDateym(MapUtils.getString(reqMap, "CAL_YM"), null)).append(
                MessageUtil.getMessage("EPG4_0320_MSG_FILE_NAME")).toString();
            setTitles(titles, records, title);

            //�ץXexcel
            XlsUtils xlsUtils = new XlsUtils(fileName, rtnList, resp);
            xlsUtils.parseToSheetSetting(fileName, titles, records);
            xlsUtils.execute(new XlsUtils.ListProcessHandler() {
                int NO = 0;

                /**
                 * �v���B�z
                 */
                @Override
                protected boolean dataOutputProcess(Map dataMap) {
                    dataMap.put("NO", ++NO);
                    dataMap.put("CAL_YM", display.formatDateym(dataMap.get("CAL_YM"), ""));

                    //�ഫ�ʤ���
                    dataMap.put("USE_RT", STRING.objToBigDecimal(dataMap.get("USE_RT"), BigDecimal.ZERO).multiply(percent));
                    dataMap.put("GRS_RTN_RT", STRING.objToBigDecimal(dataMap.get("GRS_RTN_RT"), BigDecimal.ZERO).multiply(percent));
                    dataMap.put("NET_RTN_RT", STRING.objToBigDecimal(dataMap.get("NET_RTN_RT"), BigDecimal.ZERO).multiply(percent));
                    return true;//true:�����n�ץX ; false:�������ץX
                }

            });

            MessageUtil.setMsg(msg, "EPG4_0320_ERRMSG_004");//�ץX����
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPG4_0320_ERRMSG_005");//�ץX����
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPG4_0320_ERRMSG_005");//�ץX����
        }

        return resp;
    }

    private void query(RequestContext req) throws ModuleException {
        Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
        List<Map> rtnList = new EP_Z0G410().queryList(reqMap);

        for (Map rtnMap : rtnList) {

            //�ഫ�ʤ���               
            rtnMap.put("USE_RT", STRING.objToBigDecimal(rtnMap.get("USE_RT"), BigDecimal.ZERO).multiply(percent));
            rtnMap.put("GRS_RTN_RT", STRING.objToBigDecimal(rtnMap.get("GRS_RTN_RT"), BigDecimal.ZERO).multiply(percent));
            rtnMap.put("NET_RTN_RT", STRING.objToBigDecimal(rtnMap.get("NET_RTN_RT"), BigDecimal.ZERO).multiply(percent));
        }
        resp.addOutputData("rtnList", rtnList);
    }

    /**
     * �]�w�ץX���榡
     * @param titles
     * @param records
     * @param title
     */
    private void setTitles(List<List<ColumnSetting>> titles, List<List<ColumnSetting>> records, String title) {

        //�ɮפ��e�Ĥ@��Х[�W�H�U���
        List<ColumnSetting> titleRow = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(titleRow, XlsUtils.EMPTY, title, new ColumnOptions(1, 25));
        titles.add(titleRow);

        List<ColumnSetting> firstRow = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG10120_NO"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG10120_INV_BLD_KD_NM"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG10120_BLD_CD"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG10120_BLD_NAME"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG10120_BLD_AREA"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG10120_PRK_AREA"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_TOT_RNT_SIZE"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_INV_RNT_SIZE"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_SLF_SIZE"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_SLF_RNT_AMT"), new ColumnOptions(1, 1));

        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_RNT_SIZE"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_USE_RT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_NET_SAL_AMT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_ALL_RNT_AMT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_SUM_NET_AMT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_MNG_AMT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_FEE_AMT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_FIX_AMT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_HOUSE_TAX"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_LAND_TAX"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_PREM_AMT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_NET_AMT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_BLD_COST_AMT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_GRS_RTN_RT"), new ColumnOptions(1, 1));
        XlsUtils.addColumnAttrs(firstRow, XlsUtils.EMPTY, MessageUtil.getMessage("EPG40320_NET_RTN_RT"), new ColumnOptions(1, 1));
        titles.add(firstRow);

        //���e
        List<ColumnSetting> firstRow_ = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow_, "NO", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "INV_BLD_KD_NM", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "BLD_CD", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "BLD_NAME", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "BLD_AREA", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "PRK_AREA", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "BLD_SIZE", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "INV_RNT_SIZE", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "SLF_SIZE", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "SLF_RNT_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "RNT_SIZE", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "USE_RT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "NET_SAL_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "ALL_RNT_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "SUM_NET_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "MNG_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "FEE_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "FIX_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "HOUSE_TAX", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "LAND_TAX", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "PREM_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "NET_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "BLD_COST_AMT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "GRS_RTN_RT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        XlsUtils.addColumnAttrs(firstRow_, "NET_RTN_RT", XlsUtils.EMPTY, new ColumnOptions(1, 1, SORT_RULE.NUMBER));
        records.add(firstRow_);

    }
}
