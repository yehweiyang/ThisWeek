package com.cathay.ep.f1.trx;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.CustomerBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.f1.module.EP_F10500;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0F170;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * ���~/����    
 * UCEPF1_0500_��µ��X�d��  
 * ��Ʈw����   DB2
 * ���@�� ��ڸ�T��  
 * �t�d�H ����i
 * @author �Ťl��
 * 
 * @version 2018/01/26 ���~��:�s��µ�t�γB�z�[�J���P��/��H��
 *
 */
@SuppressWarnings("unchecked")
public class EPF1_0500 extends CustomerBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPF1_0500.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);

        try {
            String LP_JSON = ObjectUtils.toString(req.getParameter("LP_JSON"), null); // LP_JSON
            if (StringUtils.isNotBlank(LP_JSON)) {
                resp.addOutputData("LP_JSON", LP_JSON);
                //�ɭ����A�O�_����^
                String IS_BACK = ObjectUtils.toString(req.getParameter("IS_BACK"), "N");
                resp.addOutputData("IS_BACK", IS_BACK);

                // JSON�r���ફ��
                Map LP_JSONMap = VOTool.jsonToMap(LP_JSON);
                /*int count = listLP_JSON.size() - 1;
                if (count >= 0) {
                    // ��@ VOTool.setParamsFromLP_JSON(req);
                    //���o�̫�@��LP_JSON
                    Map LP_JSONparams = listLP_JSON.get(count);*/

                    boolean isCheckParamsInRequest = "N".equals(IS_BACK);
                    resp.addOutputData("LP_JSONparams", LP_JSONMap);

                    //���O��^�ɱNLP_JSON�r���h�̫�@�Ӫ���
                    if (!isCheckParamsInRequest) {
                        Map LP_Map = new HashMap();
                        LP_Map.put("BLD_CD", LP_JSONMap.get("BLD_CD"));
                        LP_Map.put("APLY_NO", LP_JSONMap.get("APLY_NO"));
                        LP_Map.put("APLY_TP", LP_JSONMap.get("APLY_TP"));
                        LP_Map.put("OP_STATUS", LP_JSONMap.get("OP_STATUS"));                        
                        LP_Map.put("EXP_TP", LP_JSONMap.get("EXP_TP"));  
                        LP_Map.put("DATE_TYPE", LP_JSONMap.get("DATE_TYPE"));
                        LP_Map.put("DATE1", LP_JSONMap.get("DATE1"));
                        LP_Map.put("DATE2", LP_JSONMap.get("DATE2"));
                        LP_Map.put("SIGN", LP_JSONMap.get("SIGN"));
                        LP_Map.put("CLR_AMT", LP_JSONMap.get("CLR_AMT"));
                        LP_Map.put("INPUT_DATES", LP_JSONMap.get("INPUT_DATES"));   
                        LP_Map.put("INPUT_DATEE", LP_JSONMap.get("INPUT_DATEE"));   
                        LP_Map.put("END_APLY_DATES", LP_JSONMap.get("END_APLY_DATES"));
                        LP_Map.put("END_APLY_DATEE", LP_JSONMap.get("END_APLY_DATEE"));
                        resp.addOutputData("LP_Map", VOTool.toJSON(LP_Map));
                        //listLP_JSON.remove(count);
                        resp.addOutputData("LP_JSON", VOTool.toJSON(LP_JSONMap));
                    }

               // }
            }
        } catch (Exception e) {
            log.error("LP_JSON�ѪR���~�I", e);
        }
        StringBuilder sb = new StringBuilder();
        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            sb.append(MessageUtil.getMessage("EPF1_0500_ERRMSG_001"));//���o�����q�O����
            STRING.newLine(sb);
        }
        resp.addOutputData("DATE_TYPE_LIST", FieldOptionList.getName("EP", "DATE_TP_F100"));
        resp.addOutputData("SIGN_LIST", FieldOptionList.getName("EP", "SIGN"));
        resp.addOutputData("OP_STATUS_LIST", FieldOptionList.getName("EP", "OP_STATUS_F100"));
        //���o�ץ�����M��
        resp.addOutputData("APLY_TP_LIST", FieldOptionList.getName("EP", "APLY_TP_F500"));

        //���o�O�κ����M��
        resp.addOutputData("EXP_TP_LIST", FieldOptionList.getName("EP", "EXP_TP_F101"));
        

        //��µ��ӿ�(FIX_DIV_ID)
        try {
            //��@�Τ�k
            resp.addOutputData("FIX_DIV_ID_LIST", new EP_A10010().getDivMember());
        } catch (SQLException e) {
            sb.append(MessageUtil.getMessage("EPF1_0500_ERRMSG_002"));//���o��µ��ӿ쥢��
        }
        //���o�ۥΥX���M��
        resp.addOutputData("USE_TP_LIST", FieldOptionList.getName("EP", "USE_TP_F101"));

        if (sb.length() != 0) {
            MessageUtil.setErrorMsg(msg, sb.toString());
            sb.setLength(0);
        }
        return resp;
    }

    /**
     * �d��
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String DATE_TYPE=MapUtils.getString(reqMap, "DATE_TYPE");
            if(StringUtils.isNotBlank(DATE_TYPE)){
                if("1".equals(DATE_TYPE)){///�߮פ�
                    reqMap.put("INPUT_DATES", reqMap.get("DATE1"));
                    reqMap.put("INPUT_DATEE", reqMap.get("DATE2"));
                }else if("2".equals(DATE_TYPE)){//���פ�
                    reqMap.put("END_APLY_DATES", reqMap.get("DATE1"));
                    reqMap.put("END_APLY_DATEE", reqMap.get("DATE2"));
                }else if("3".equals(DATE_TYPE)){//�D��ñ�֤�
                    reqMap.put("DIV_CFM_DATES", reqMap.get("DATE1"));
                    reqMap.put("DIV_CFM_DATEE", reqMap.get("DATE2"));
                }else if("4".equals(DATE_TYPE)){//�q���I�u��
                    reqMap.put("INFM_CONS_DATES", reqMap.get("DATE1"));
                    reqMap.put("INFM_CONS_DATEE", reqMap.get("DATE2"));
                }else if("5".equals(DATE_TYPE)){//����q���I�u���
                    reqMap.put("PRE_CONS_DATES", reqMap.get("DATE1"));
                    reqMap.put("PRE_CONS_DATEE", reqMap.get("DATE2"));
                }else if("6".equals(DATE_TYPE)){//�P��
                    reqMap.put("CLOSE_DATES", reqMap.get("DATE1"));
                    reqMap.put("CLOSE_DATEE", reqMap.get("DATE2"));
                }
            }
            resp.addOutputData("rtnList", new EP_F10500().queryList(reqMap));

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002")); //�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001"); //�d�L���            
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028")); //�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003")); //�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003")); //�d�ߥ���
        }

        return resp;
    }

    /**
     * �j�M����-�j�ӫ�ĳ�M��
     * @param req
     * @return
     */
    public ResponseContext doSuggestBLD_CD(RequestContext req) {
        try {
            //�u�j�ӫ�ĳ�M��v��ĳ���G 
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_CD", req.getParameter("suggestValue"));
            List<Map> BLD_CDList = new EP_Z0F170().queryList(reqMap);

            resp.addOutputData("suggestResult", BLD_CDList);
        } catch (Exception e) {
            log.error("�j�ӷj�M���ܬd�ߥ���", e);
        }
        return resp;
    }

    /**
     * �ץ�����s�� �ץ󪬺A �O�κ���
     * @param req
     * @return
     */
    public ResponseContext doChangeAPLY_TP(RequestContext req) {
        try {
            if ("1".equals(req.getParameter("APLY_TP"))) {
                //�ץ�������s�P��
                resp.addOutputData("OP_STATUS_LIST", FieldOptionList.getName("EP", "OP_STATUS_F501"));
                resp.addOutputData("EXP_TP_LIST", FieldOptionList.getName("EP", "EXP_TP_F101"));
            } else {
                //�@��Υ���
                resp.addOutputData("OP_STATUS_LIST", FieldOptionList.getName("EP", "OP_STATUS_F502"));
                resp.addOutputData("EXP_TP_LIST", FieldOptionList.getName("EP", "EXP_TP_F101"));
            }

        } catch (Exception e) {
            log.error("�ץ�����s�ʬd�ߥ���", e);
        }
        return resp;
    }
}
