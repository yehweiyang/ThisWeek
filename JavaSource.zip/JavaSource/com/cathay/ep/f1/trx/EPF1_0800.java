package com.cathay.ep.f1.trx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.vo.DTEPF151;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0F151;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;
/**
 * ���~/����    UCEPF1_0800_�M����d��   
 * ��Ʈw����   DB2
 * ���@�� ��ڸ�T��   
 * �t�d�H ����i
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EPF1_0800 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPF1_0800.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }
    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);

        try {
            String LP_JSON = ObjectUtils.toString(req.getParameter("LP_JSON"), null); // LP_JSON
            if (StringUtils.isNotBlank(LP_JSON)) {
                resp.addOutputData("LP_JSON", LP_JSON);
                //�ɭ����A�O�_����^
                String IS_BACK = ObjectUtils.toString(req.getParameter("IS_BACK"), "N");
                resp.addOutputData("IS_BACK", IS_BACK);

                // JSON�r���ફ��
                List<Map> listLP_JSON = VOTool.jsonAryToMaps(LP_JSON);
                int count = listLP_JSON.size() - 1;
                if (count >= 0) {
                    // ��@ VOTool.setParamsFromLP_JSON(req);
                    //���o�̫�@��LP_JSON
                    Map LP_JSONparams = listLP_JSON.get(count);

                    boolean isCheckParamsInRequest = "N".equals(IS_BACK);
                    resp.addOutputData("LP_JSONparams", LP_JSONparams);

                    //���O��^�ɱNLP_JSON�r���h�̫�@�Ӫ���
                    if (!isCheckParamsInRequest) {
                        Map LP_Map = new HashMap();
                        LP_Map.put("APLY_NO", listLP_JSON.get(0).get("APLY_NO"));
                        LP_Map.put("CLOSE_TP", listLP_JSON.get(0).get("CLOSE_TP"));
                        LP_Map.put("SUB_ITEM_NO", listLP_JSON.get(0).get("SUB_ITEM_NO"));                                              
                        resp.addOutputData("LP_Map", VOTool.toJSON(LP_Map));
                        listLP_JSON.remove(count);
                        resp.addOutputData("LP_JSON", VOTool.toJSON(listLP_JSON));
                    }

                }
            }
        } catch (Exception e) {
            log.error("LP_JSON�ѪR���~�I", e);
        }
        StringBuilder sb = new StringBuilder();
        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            sb.append(MessageUtil.getMessage("EPF1_0800_ERRMSG_001"));//���o�����q�O����
            STRING.newLine(sb);
        }
       
        //���o�M�����
        resp.addOutputData("CLOSE_TP_LIST", FieldOptionList.getName("EP", "CLOSE_TP_F105"));
        //���o�M�ⶵ��
        resp.addOutputData("SUB_ITEM_NO_LIST", FieldOptionList.getName("EP", "SUB_ITEM_NO_F105"));
        if (sb.length() != 0) {
            MessageUtil.setErrorMsg(msg, sb.toString());
            sb.setLength(0);
        }
        return resp;
    }
    /**
     * �d��
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            resp.addOutputData("rtnList", new EP_Z0F151().queryF151List(VOTool.jsonToVO(DTEPF151.class, req.getParameter("reqMap"))));
            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002")); //�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001"); //�d�L���            
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028")); //�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003")); //�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003")); //�d�ߥ���
        }

        return resp;
    }
}
