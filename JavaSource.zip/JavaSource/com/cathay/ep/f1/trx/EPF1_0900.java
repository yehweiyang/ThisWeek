package com.cathay.ep.f1.trx;

import java.sql.Date;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.ep.f1.module.EP_F10900;
import com.cathay.ep.g4.module.EP_G40100;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.XlsUtils;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.common.util.annotation.CallMethod;
import com.igsapp.common.util.annotation.TxBean;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * ���ʤ��     ����    ���ʻ���     ���ʤH��
   2019/5/3     1.0     Created     �L�ç�

    �{���\��    �]�Ƽi���d��
    �{���W��    EPF1_0900
    �@�~�覡    ONLINE
    ���n����    
    (1) �d�� �w ���ѨϥΪ̬d�߳]�Ƽi�����
    (2) �s�W �w ���ѨϥΪ̷s�W�j�ӳ]�Ƴ]�w���
    (3) �ק� �w ���ѨϥΪ̭ק�j�ӳ]�Ƴ]�w���
    (4) �R�� �w ���ѨϥΪ̧R���j�ӳ]�Ƴ]�w���
    ���s���v    ���M��
    �h��y�t    �M��
 * </pre>
 * @author ������
 * @since 2019/5/23
 */

@TxBean
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPF1_0900 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPF1_0900.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode(CallMethod.CODE_SUCCESS);
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    @CallMethod(action = "prompt", url = "/EP/F1/EPF1_0900/EPF10900.jsp")
    public ResponseContext doPrompt(RequestContext req) {
        
        //����
        VOTool.setParamsFromLP_JSON(req);
        StringBuilder err_sb = new StringBuilder();
        
        //���o�����q�O
        String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            try {
                SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
                resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            } catch (Exception e) {
                log.error("���o�����q�O����", e);
                err_sb.append(MessageUtil.getMessage("EP_UI_MSG_EPF10900_001"));//���o�����q�O����
                STRING.newLine(err_sb);
            }
        }
        resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        resp.addOutputData("BLD_CD", req.getParameter("BLD_CD"));

        //���o�]�ƺ����M��
        try {
            Map EQP_CD_LIST = FieldOptionList.getName("EP", "EQP_CD");
            resp.addOutputData("EQP_CD_LIST", EQP_CD_LIST);
        } catch (Exception e) {
            log.error("���o�]�ƺ����U�Կ�楢��", e);
            err_sb.append(MessageUtil.getMessage("EP_UI_MSG_EPF10900_002"));//���o�]�ƺ����U�Կ�楢��
            STRING.newLine(err_sb);
        }

        //���o����Ÿ��M��
        try {
            Map SIGN_LIST = FieldOptionList.getName("EP", "SIGN");
            resp.addOutputData("SIGN_LIST", SIGN_LIST);
        } catch (Exception e) {
            log.error("���o����Ÿ��U�Կ�楢��", e);
            err_sb.append(MessageUtil.getMessage("EP_UI_MSG_EPF10900_003"));//���o����Ÿ��U�Կ�楢��
            STRING.newLine(err_sb);
        }

        //���o���زM��
        try {
            Map AIR_CON_TP_LIST = FieldOptionList.getName("EP", "AIR_CON_TP");
            resp.addOutputData("AIR_CON_TP_LIST", AIR_CON_TP_LIST);
        } catch (Exception e) {
            log.error("���o���ؤU�Կ�楢��", e);
            err_sb.append(MessageUtil.getMessage("EP_UI_MSG_EPF10900_004"));//���o���ؤU�Կ�楢��
            STRING.newLine(err_sb);
        }

        //���o�����覡�M��
        try {
            Map AIR_CON_RAD_LIST = FieldOptionList.getName("EP", "AIR_CON_RAD");
            resp.addOutputData("AIR_CON_RAD_LIST", AIR_CON_RAD_LIST);
        } catch (Exception e) {
            log.error("���o�����覡�U�Կ�楢��", e);
            err_sb.append(MessageUtil.getMessage("EP_UI_MSG_EPF10900_005"));//���o�����覡�U�Կ�楢��
            STRING.newLine(err_sb);
        }

        //���o����/�L�ĲM��
        try {
            Map VALID_LIST = FieldOptionList.getName("EP", "VALID");
            resp.addOutputData("VALID_LIST", VALID_LIST);
        } catch (Exception e) {
            log.error("���o����/�L�ĤU�Կ�楢��", e);
            err_sb.append(MessageUtil.getMessage("EP_UI_MSG_EPF10900_011"));//���o����/�L�ĤU�Կ�楢��
            STRING.newLine(err_sb);
        }
        
        if (err_sb.length() != 0) {
            MessageUtil.setErrorMsg(msg, err_sb.toString());
            err_sb.setLength(0);
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    @CallMethod(action = "query", type = CallMethod.TYPE_AJAX)
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            resp.addOutputData("rtnList", new EP_F10900().query(reqMap));
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }
    
    /**
     * �ץX
     * @param req
     * @return
     */
    @CallMethod(action = "export", type = CallMethod.TYPE_AJAX)
    public ResponseContext doExport(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> rtnList = new EP_F10900().query(reqMap);

            String gridJSON = MapUtils.getString(reqMap, "gridJSON");
            //�����ɦW :�]�Ƽi���d��_YYYYMMDD.xls
            String fileName = MessageUtil.getMessage("EP_UI_MSG_EPF10900_014") + DATE.toDate_yyyyMMdd(DATE.getDBDate());//�]�Ƽi���d��_YYYYMMDD

            final LocaleDisplay display = new LocaleDisplay("EP", user);
            //�ץXexcel
            XlsUtils xlsUtils = new XlsUtils(fileName, rtnList, resp);
            xlsUtils.initExportSetting(gridJSON);
            xlsUtils.execute(new XlsUtils.ListProcessHandler() {

                @Override
                protected boolean dataOutputProcess(Map dataMap) {
                    dataMap.put("FIX_DATE", display.formatDate((Date) dataMap.get("FIX_DATE"), "/", ""));
                    return true;
                }
            });

            MessageUtil.setMsg(msg, "EP_UI_MSG_EPF10900_012");//�ץX����
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EP_UI_MSG_EPF10900_013");//�ץX����
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EP_UI_MSG_EPF10900_013");//�ץX����
        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    @CallMethod(action = "insert", type = CallMethod.TYPE_AJAX)
    public ResponseContext doInsert(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            String EQP_ID = null;
            EP_F10900 theEP_F10900 = new EP_F10900();
            Transaction.begin();
            try {
                EQP_ID = theEP_F10900.insert(reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
   
            MessageUtil.setMsg(msg, "MEP00004");//�s�W����

            try {
                Map queryMap = new HashMap();
                queryMap.put("SUB_CPY_ID", reqMap.get("SUB_CPY_ID"));
                queryMap.put("EQP_ID", EQP_ID);
                resp.addOutputData("rtnList", theEP_F10900.query(queryMap));
            } catch (Exception e) {
                log.error("�s�W���\�A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EP_UI_MSG_EPF10900_006");//�s�W���\�A���d����
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00005");//�s�W����
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    @CallMethod(action = "delete", type = CallMethod.TYPE_AJAX)
    public ResponseContext doDelete(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String EQP_ID = req.getParameter("EQP_ID");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");

            EP_F10900 theEP_F10900 = new EP_F10900();
            Transaction.begin();
            try {
                theEP_F10900.delete(EQP_ID, SUB_CPY_ID);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "MEP00010");//�R������

            try {
                resp.addOutputData("rtnList", theEP_F10900.query(reqMap));
            } catch (DataNotFoundException e) {
                log.error("�R�������A���d�d�L���", e);
            } catch (Exception e) {
                log.error("�R�������A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EP_UI_MSG_EPF10900_007");//�R�������A���d����
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00011");//�R������
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00011");//�R������
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    @CallMethod(action = "update", type = CallMethod.TYPE_AJAX)
    public ResponseContext doUpdate(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            Map queryMap = VOTool.jsonToMap(req.getParameter("queryMap"));

            EP_F10900 theEP_F10900 = new EP_F10900();
            Transaction.begin();
            try {
                theEP_F10900.update(reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EP_UI_MSG_EPF10900_008");//�ק令�\

            try {
                resp.addOutputData("rtnList", theEP_F10900.query(queryMap));
                
                List<Map> F190List = theEP_F10900.query(reqMap);
                if (F190List.size() > 0) {
                    resp.addOutputData("ROC_UPDATE_DATE", MapUtils.getString(F190List.get(0), "ROC_UPDATE_DATE"));
                }
            } catch (Exception e) {
                log.error("�ק令�\�A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EP_UI_MSG_EPF10900_009");//�ק令�\�A���d����
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EP_UI_MSG_EPF10900_010"); //�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EP_UI_MSG_EPF10900_010");//�ק異��
        }

        return resp;
    }

    /**
     * �]�ƺ���(�j��) �s�� �]�ƺ���(����)
     * @param req
     * @return
     */
    @CallMethod(action = "changeEQP_CD", type = CallMethod.TYPE_AJAX)
    public ResponseContext doChangeEQP_CD(RequestContext req) {
        try {
            String EQP_CD = req.getParameter("EQP_CD");
            if ("1".equals(EQP_CD)) { //����]��
                resp.addOutputData("SUB_EQP_CD_LIST", FieldOptionList.getName("EP", "SUB_EQP_CD_F901"));
            } else if ("2".equals(EQP_CD)) { //�q��
                resp.addOutputData("SUB_EQP_CD_LIST", FieldOptionList.getName("EP", "SUB_EQP_CD_F902"));
            } else if ("3".equals(EQP_CD)) { //�Ž�
                resp.addOutputData("SUB_EQP_CD_LIST", FieldOptionList.getName("EP", "SUB_EQP_CD_F903"));
            } else if ("4".equals(EQP_CD)) { //���Ƥ��νå�
                resp.addOutputData("SUB_EQP_CD_LIST", FieldOptionList.getName("EP", "SUB_EQP_CD_F904"));
            } else if ("5".equals(EQP_CD)) { //�����Τ����z�q
                resp.addOutputData("SUB_EQP_CD_LIST", FieldOptionList.getName("EP", "SUB_EQP_CD_F905"));
            } else {
                resp.addOutputData("SUB_EQP_CD_LIST", Collections.EMPTY_MAP);
            }
        } catch (Exception e) {
            log.error("�]�ƺ����s�ʬd�ߥ���", e);
        }
        return resp;
    }
}