package com.cathay.ep.f1.trx;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.message.MessageHelper;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.CustomerBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.ReturnMessageUtil;
import com.cathay.common.util.STRING;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.f1.module.EPF1_0100_mod;
import com.cathay.ep.f1.module.EPF1_0102_mod;
import com.cathay.ep.f1.module.EP_F10300;
import com.cathay.ep.f1.module.EP_F10310;
import com.cathay.ep.vo.DTEPF110;
import com.cathay.ep.vo.DTEPF130;
import com.cathay.ep.vo.DTEPF160;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z00100;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F120;
import com.cathay.ep.z0.module.EP_Z0F130;
import com.cathay.ep.z0.module.EP_Z0F160;
import com.cathay.ep.z0.module.EP_Z0F170;
import com.cathay.rz.IConstants;
import com.cathay.rz.n0.module.RZ_N00100;
import com.cathay.rz.vo.DTRZN011;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date Version Description Author
2014/9/15   1.0 Created ����i

UCEPF1_0100_��µ�ӽ�

�@�B  �{���\�෧�n�����G
�{���\��    ��µ�ӽ�
�{���W��    EPF1_0100
�@�~�覡    ONLINE
���n����    (1) ��l
(2) �߮� �w ���ѨϥΪ̷s�W��µ�e�f�ץ�C
(3) �e�� �V ���ѨϥΪ̴����µ�e�f�ץ�C
(4) ����(��µ��) �w ���ѨϥΪ̮ץ󬣵o�t�d�H�C
(5) �T�{�u�k �w ���ѨϥΪ̹s�P�ץ�T�{�u�k�C
(6) �D��ñ�� �w ���ѨϥΪ̹s�P�ץ�D��ñ�֡C
(7) ����(��µ��) �w ���ѨϥΪ̮ץ󬣵o�t�d�H�C
(8) �T�{���u �w ���ѨϥΪ̽T�{�ץ�Ҧ����جҤw���u�C
(9) �����禬 �w ���ѨϥΪ̭�µ�ץ󴣥��禬�C
(10)    �����禬 �w ���ѨϥΪ̭�µ�ץ󥿦��禬�C
(11)    �����k�� �w ���ѨϥΪ̭�µ�ץ󵲮��k�ɡC
(12)    �����e�� �w ���ѨϥΪ̨��������µ�e�f�ץ�C
(13)    �h�^ �w ���ѨϥΪ̨����ץ󬣵o�t�d�H�C
(14)    �����T�{�u�k �w ���ѨϥΪ̹s�P�ץ�����T�{�u�k�C
(15)    �����D��ñ�� �w ���ѨϥΪ̹s�P�ץ�����D��ñ�֡C
(16)    ��������(��µ��) �w ���ѨϥΪ̨����ץ󬣵o�t�d�H�C
(17)    �������u �w ���ѨϥΪ̨����T�{���u�C
(18)    �������� �w ���ѨϥΪ̭�µ�ץ��������C
(19)    �����禬 �w ���ѨϥΪ̭�µ�ץ�����禬�C
(20)    �R�� �w ���ѨϥΪ̧R���߮׸�ơC
(21)    �h�^���� �w ���ѨϥΪ̭�µ�ץ�h�^�����禬�C
(22)    �C�L�禬��� �w ���ѨϥΪ̶}�ҦC�L�禬��Ƶ����C
(23)    �C�L�дک��� �w ���ѨϥΪ̶}�ҦC�L�禬��Ƶ����C
(24)    �P�� �w ���ѨϥΪ̾P�׮ץ�C
(25)    �j�ӥN������ �w ���ѨϥΪ̤j�ӯ��ޡC
(26)    �������Ңw ���ѨϥΪ̭�������޿�C
(27)    �^�W�� �w �ϥΪ̥i�z�L�����s�^�W�h�e���C
���s���v    �M��FUNC_ID = EPF10100
�h��y�t    �M��
�����q���
�榡���js  �M��V������        V�u����                                      

 * @author �Ťl��
 * 
 * @version 2018/01/26 ���~��:�s��µ�t�γB�z�[�J���P��/��H��
 *
 */
@SuppressWarnings("unchecked")
public class EPF1_0100 extends CustomerBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPF1_0100.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        VOTool.setParamsFromLP_JSON(req);
        StringBuilder sb = new StringBuilder();
        String SUB_CPY_ID = null;
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            sb.append(MessageUtil.getMessage("EPF1_0100_ERRMSG_001"));//���o�����q�O����
            STRING.newLine(sb);
        }
        Map rtnF110Map = new HashMap();
        EP_Z0F110 voMod = new EP_Z0F110();
        EP_Z00100 theEP_Z00100 = new EP_Z00100();
        try {
            String LP_JSON = ObjectUtils.toString(req.getParameter("LP_JSON"), null); // LP_JSON
            if (StringUtils.isNotBlank(LP_JSON)) {
                resp.addOutputData("LP_JSON", LP_JSON);
                //�ɭ����A�O�_����^
                String IS_BACK = ObjectUtils.toString(req.getParameter("IS_BACK"), "N");
                resp.addOutputData("IS_BACK", IS_BACK);

                resp.addOutputData("save_obj", ObjectUtils.toString(req.getParameter("save_obj"), null));// save_obj : ��d�߽ե�

                // JSON�r���ફ��
                List<Map> listLP_JSON = VOTool.jsonAryToMaps(LP_JSON);
                int count = listLP_JSON.size() - 1;

                if (count >= 0) {
                    // ��@ VOTool.setParamsFromLP_JSON(req);
                    //���o�̫�@��LP_JSON
                    Map LP_JSONparams = listLP_JSON.get(count);

                    boolean isCheckParamsInRequest = "N".equals(IS_BACK);

                    for (Object params_key : LP_JSONparams.keySet()) {
                        //�Y�O��^�A�j���л\REQUSET�A�Y�O�ɭ����л\��lREQUEST
                        String params_key_string = ObjectUtils.toString(params_key);
                        if (!isCheckParamsInRequest || StringUtils.isBlank(req.getParameter(params_key_string))) {
                            req.setParameter(params_key_string, ObjectUtils.toString(LP_JSONparams.get(params_key), ""));
                        }
                    }
                    //���O��^�ɱNLP_JSON�r���h�̫�@�Ӫ���
                    if (!isCheckParamsInRequest) {
                        listLP_JSON.remove(count);
                        resp.addOutputData("LP_JSON", VOTool.toJSON(listLP_JSON));
                    }
                }
            }

            String APLY_NO = req.getParameter("APLY_NO");
            if (StringUtils.isNotBlank(APLY_NO)) {
                rtnF110Map = voMod.queryMap(APLY_NO, SUB_CPY_ID);
                resp.addOutputData("RTN_STS_LIST", voMod.getBackStatus(MapUtils.getString(rtnF110Map, "APLY_TP"), MapUtils.getString(
                    rtnF110Map, "OP_STATUS"), user));
            }

        } catch (Exception e) {
            log.error("LP_JSON�ѪR���~�I", e);
        }

        setBtnPrivilege(rtnF110Map, SUB_CPY_ID);

        //�ץ�s��
        String LINK_FROM = req.getParameter("LINK_FROM");
        String APLY_NO = req.getParameter("APLY_NO");
        resp.addOutputData("LINK_FROM", LINK_FROM);
        resp.addOutputData("APLY_NO", APLY_NO);
        if (StringUtils.isNotBlank(LINK_FROM)) {
            if (StringUtils.isBlank(APLY_NO)) {
                sb.append(MessageUtil.getMessage("EPF1_0100_ERRMSG_002"));//�ץ�s�������ǤJ
                STRING.newLine(sb);
            }
        }

        try {
            //���o��µ��H���M��A��@�Τ�k
            resp.addOutputData("FIX_DIV_ID_LIST", new EP_A10010().getDivMember());
        } catch (Exception e) {
            log.error("���o�u��µ��H���v�M�楢��", e);
            sb.append(MessageUtil.getMessage("EPF1_0100_ERRMSG_012"));//���o�u��µ��H���v�M�楢��
            STRING.newLine(sb);
        }
        try {
            //���o��µ�դH���M��
            List<Map> FIX_GROUP_ID_LIST_1 = theEP_Z00100.getEmpList(FieldOptionList.getName("EP", "DIV_F106", "FIX_GROUP_1"), SUB_CPY_ID);
            FIX_GROUP_ID_LIST_1.addAll(theEP_Z00100.getEmpList(FieldOptionList.getName("EP", "DIV_F106", "FIX_GROUP_2"), SUB_CPY_ID));
            resp.addOutputData("FIX_GROUP_ID_LIST", FIX_GROUP_ID_LIST_1);
        } catch (Exception e) {
            log.error("���o�u��µ�դH���v�M�楢��", e);
            sb.append(MessageUtil.getMessage("EPF1_0100_ERRMSG_013"));//���o�u��µ�դH���v�M�楢��
            STRING.newLine(sb);
        }
        try {
            //���o�����դH���M��
            resp.addOutputData("SUBCON_GROUP_ID_LIST", theEP_Z00100.getEmpList(FieldOptionList.getName("EP", "DIV_F106", "SUBCON_GROUP"),
                SUB_CPY_ID));
        } catch (Exception e) {
            log.error("���o�u�����դH���v�M�楢��", e);
            sb.append(MessageUtil.getMessage("EPF1_0100_ERRMSG_065"));//���o�u�����դH���v�M�楢��
            STRING.newLine(sb);
        }
        if (sb.length() != 0) {
            MessageUtil.setErrorMsg(msg, sb.toString());
            sb.setLength(0);
        }
        //���o�ץ�����M��
        resp.addOutputData("APLY_TP_LIST", FieldOptionList.getName("EP", "APLY_TP_F101"));
        // ���o�ۥ�/�X���M��
        resp.addOutputData("USE_TP_LIST", FieldOptionList.getName("EP", "USE_TP_F101"));

        try {
            resp.addOutputData("NEWS_LIST", FieldOptionList.getName("EP", "NEWS"));
        } catch (Exception e) {
            resp.addOutputData("NEWS_LIST", "");
        }

        return resp;
    }

    public void setBtnPrivilege(Map rtnF110Map, String SUB_CPY_ID) {

        EPF1_0102_mod mod = new EPF1_0102_mod();
        //��µ��b�ȤH��
        String[] ACCOUNT_IDS = FieldOptionList.getName("EP", "ACCOUNTS_ID", "ACCOUNTS_IDS").split(",");
        //��µ��W�űb��
        String[] fixSuperId = FieldOptionList.getName("EP", "SUPER_ID", "FIX_SUPER_ID").split(",");
        //��µ�նW�űb��
        String[] fixSuperIdMap = FieldOptionList.getName("EP", "SUPER_ID", "FIXG_SUPER_ID").split(",");
        //��µ�쬣��
        String FIX_DIV_ROLE = FieldOptionList.getName("EP", "EP_ROLES", "FIX_DIV_ROLE");//"RLEP015"��µ�쬣��
        //String FIX_GROUP_ROLE = FieldOptionList.getName("EP", "EP_ROLES", "FIX_GROUP_ROLE");//"RLEP016"��µ��
        //��A
        String RLZZ0EP = FieldOptionList.getName("EP", "DIV_F106", "RLZZ0EP");
        if (mod.isItSuperRole(RLZZ0EP, user)) {
            resp.addOutputData("IS_SUPER", "Y");
        } else {
            resp.addOutputData("IS_SUPER", "N");
        }

        //�߮פH
        if (mod.isInputUser(rtnF110Map, user) || mod.isItSuperRole(RLZZ0EP, user) || mod.isSuperIdMap(fixSuperId, user)) {
            log.debug("IS_INPUT_USER=Y");
            resp.addOutputData("IS_INPUT_USER", "Y");
        } else {
            resp.addOutputData("IS_INPUT_USER", "N");
        }

        //�߮פH �ۥέ�µ�g��
        if (mod.isInputAgent(rtnF110Map, user)) {
            log.debug("IS_INPUT_AGENT");
            resp.addOutputData("IS_INPUT_AGENT", "Y");
        } else {
            resp.addOutputData("IS_INPUT_AGENT", "N");
        }
        //��µ��t�d�H
        if (mod.isFixUser(rtnF110Map, user) || mod.isItSuperRole(RLZZ0EP, user) || mod.isSuperIdMap(fixSuperId, user)
                || mod.isAccountsUser(rtnF110Map, user, ACCOUNT_IDS)) {
            resp.addOutputData("IS_FIX_USER", "Y");
        } else {
            resp.addOutputData("IS_FIX_USER", "N");
        }
        //���ʲ���µ�쬣��
        if ((mod.isItSuperRole(FIX_DIV_ROLE, user)) || mod.isSuperIdMap(fixSuperId, user) || mod.isItSuperRole(RLZZ0EP, user)) {
            resp.addOutputData("IS_CAN_RLEP015", "Y");
        } else {
            resp.addOutputData("IS_CAN_RLEP015", "N");
        }
        //���ʲ���µ��ﬣ��
        if ((mod.isFixUserMgr(user)) || mod.isSuperIdMap(fixSuperId, user) || mod.isItSuperRole(RLZZ0EP, user)) {
            resp.addOutputData("IS_FIX_MGR", "Y");
        } else {
            resp.addOutputData("IS_FIX_MGR", "N");
        }

        //�D��
        String IS_MGR = "";
        if (user.getDivNo().startsWith("EP9")) {
            try {
                Map map1 = new EP_Z00100().getEmp(user.getEmpID(), SUB_CPY_ID);
                IS_MGR = MapUtils.getString(map1, "IS_MGR");
            } catch (ModuleException e) {
                log.error("�d�߼ӺޤH�� ����", e);
            }
        }
        //�M��_�ϭ�µ�ղժ�
        String FIX_GROUP_ROLE1 = FieldOptionList.getName("EP", "EP_ROLES", "FIX_GROUP_ROLE1");//"ROZZEP5"�_�ϭ�µ��
        if (mod.isSubconMgr(IS_MGR, FIX_GROUP_ROLE1, user) || mod.isSuperIdMap(fixSuperIdMap, user) || mod.isItSuperRole(RLZZ0EP, user)) {
            resp.addOutputData("IS_ROZZEP5", "Y");
        } else {
            resp.addOutputData("IS_ROZZEP5", "N");
        }
        //�M�餤�n�ϭ�µ�ղժ�
        String FIX_GROUP_ROLE2 = FieldOptionList.getName("EP", "EP_ROLES", "FIX_GROUP_ROLE2");//"ROZZEP6"���n�ϭ�µ��
        if (mod.isSubconMgr(IS_MGR, FIX_GROUP_ROLE2, user) || mod.isSuperIdMap(fixSuperIdMap, user) || mod.isItSuperRole(RLZZ0EP, user)) {
            resp.addOutputData("IS_ROZZEP6", "Y");
        } else {
            resp.addOutputData("IS_ROZZEP6", "N");
        }

        /* i9300622 2015/9/30 start*/
        //��µ�թӿ�
        if (mod.isFixGroupUser(rtnF110Map, user) || mod.isItSuperRole(RLZZ0EP, user)) {
            log.debug("IS_FIXGRP_USER");
            resp.addOutputData("IS_FIXGRP_USER", "Y");
        } else {
            resp.addOutputData("IS_FIXGRP_USER", "N");
        }
        //�����լ����M���F�޲z�� //"ROZZEP2"��F�� 
        String[] SUBCON_GROUP_ROLE2 = FieldOptionList.getName("EP", "EP_ROLES", "SUBCON_GROUP_ROLE2").split(",");
        if (mod.isSuperIdMap(SUBCON_GROUP_ROLE2, user) || mod.isItSuperRole(RLZZ0EP, user)) {
            resp.addOutputData("IS_ROZZEP2", "Y");
        } else {
            resp.addOutputData("IS_ROZZEP2", "N");
        }
        resp.addOutputData("IS_FIXGRP_MGR1", "N");//��µ�հƲz
        resp.addOutputData("IS_FIXGRP_MGR2", "N");//��µ�ոg�z
        String OpUnit = user.getOpUnit();
        if ("EP".equals(OpUnit.substring(0, 2))) {
            try {
                Map map1 = new EP_Z00100().getEmp(user.getEmpID(), SUB_CPY_ID);
                IS_MGR = MapUtils.getString(map1, "IS_MGR");
                if ("1".equals(IS_MGR)) {
                    if (mod.isItSuperRole("ROZZEP5", user) || (mod.isItSuperRole("ROZZEP6", user))) {//��µ��
                        resp.addOutputData("IS_FIXGRP_MGR1", "Y");//��µ�հƲz
                    } else if (mod.isItSuperRole("ROZZEP4", user)) {
                        resp.addOutputData("IS_FIXGRP_MGR2", "Y"); //��µ���g�z
                    }
                }
            } catch (Exception e) {
                log.error("���o�v�����⥢��", e);
            }
        }

        //�����լ����M���F�޲z�� //"ROZZEP2"��F�� 
        if (mod.isSuperIdMap(SUBCON_GROUP_ROLE2, user) || mod.isItSuperRole(RLZZ0EP, user)) {
            resp.addOutputData("IS_ROZZEP2", "Y");
        } else {
            resp.addOutputData("IS_ROZZEP2", "N");
        }
        /* i9300622 2015/9/30 end*/
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            this.query(req.getParameter("APLY_NO"), req.getParameter("SUB_CPY_ID"));

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");
        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {

            DTEPF110 DTEPF110VO = VOTool.jsonToVO(DTEPF110.class, req.getParameter("reqMap"));
            String user_Unit = user.getOpUnit();
            String user_ID = user.getEmpID();
            Timestamp currentTime = DATE.currentTime();
            DTEPF110VO.setLST_PROC_DATE(currentTime);
            DTEPF110VO.setLST_PROC_DIV(user_Unit);
            DTEPF110VO.setLST_PROC_ID(user_ID);
            DTEPF110VO.setINPUT_DIV_NO(user_Unit);
            DTEPF110VO.setINPUT_DATE(currentTime);
            DTEPF110VO.setINPUT_ID(user_ID);

            chkBLD_NAME(DTEPF110VO);

            Map userMap = new HashMap();
            userMap.put("CHG_DIV_NO", user_Unit);
            userMap.put("CHG_ID", user_ID);
            userMap.put("CHG_NAME", user.getEmpName());
            userMap.put("CHG_DATE", currentTime);
            userMap.put("INPUT_ID", user_ID);

            String SUB_CPY_ID = DTEPF110VO.getSUB_CPY_ID();

            Transaction.begin();
            Map rtnMap;
            try {
                rtnMap = new EP_Z0F110().insert(DTEPF110VO, userMap);
                try {
                    Map f110Map = VOTool.voToMap(DTEPF110VO);
                    this.setBtnPrivilege(f110Map, SUB_CPY_ID);
                } catch (Exception e) {
                    log.fatal("�]�w�v��", e);
                }

                resp.addOutputData("rtnMap", rtnMap);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_003");//�߮ק���

            try {
                this.query(MapUtils.getString(rtnMap, "APLY_NO"), SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�߮ק����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_004");//�߮ק����A���d�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_005");//�߮ץ���
            }
        } catch (Exception e) {
            log.error("�߮ץ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_005");//�߮ץ���
        }

        return resp;
    }

    /**
     * �e��
     * @param req
     * @return
     */
    public ResponseContext doSubmit(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�e��");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_1, EP_Z0F110.ST_100, SUB_CPY_ID);

            Transaction.begin();

            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_1);
                //���⬰��µ��g��
                //resp.addOutputData("", outputData);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_006");//�e�󧹦�

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�e�󧹦��A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0101_ERRMSG_007");//�e�󥢱ѡA���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_008");//�e�󥢱�
            }
        } catch (Exception e) {
            log.error("�e�󥢱�", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_008");//�e�󥢱�
        }

        return resp;
    }

    /**
     * �����e��
     * @param req
     * @return
     */
    public ResponseContext doCancelSubmit(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�����e��");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_2, EP_Z0F110.ST_200, SUB_CPY_ID);

            Transaction.begin();

            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_2);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_009");//�����e�󧹦�

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�����e�󧹦��A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_010");//�����e�󧹦��A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_011");//�����e�󥢱�
            }
        } catch (Exception e) {
            log.error("�����e�󥢱�", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_011");//�����e�󥢱�
        }

        return resp;
    }

    /**
     * ����(��µ��)
     * @param req
     * @return
     */
    public ResponseContext doAssign(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "����(��µ��)");
            boolean IS_CHANGE = MapUtils.getBoolean(reqMap, "IS_CHANGE");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (EP_Z0F110.ST_1.equals(MapUtils.getString(reqMap, "APLY_TP")) && !IS_CHANGE) {
                // 1:�s�P��
                new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_1, EP_Z0F110.ST_200, SUB_CPY_ID);
            } else if (!IS_CHANGE) {
                //2:�@���B3:�����
                new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_1, EP_Z0F110.ST_200, SUB_CPY_ID);
            }

            Transaction.begin();

            try {
                if (IS_CHANGE) {
                    new EP_Z0F110().updateFiXDivID(reqMap, user);
                } else {
                    new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_1);
                }

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_014");//����(��µ��)����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("����(��µ��)�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_015");//����(��µ��)�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_016");//����(��µ��)����
            }
        } catch (Exception e) {
            log.error("����(��µ��)����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_016");//����(��µ��)����
        }

        return resp;
    }

    /**
     * �h��
     * @param req
     * @return
     */
    public ResponseContext doReject(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�h��");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            EPF1_0100_mod theEPF1_0100_mod = new EPF1_0100_mod();
            boolean isDelF160 = false;
            if (EP_Z0F110.ST_1.equals(MapUtils.getString(reqMap, "APLY_TP"))) {
                // 1:�s�P��
                theEPF1_0100_mod.chkApproveFlow(APLY_NO, EP_Z0F110.ST_2, MapUtils.getString(reqMap, "OP_STATUS"), SUB_CPY_ID);
            } else {
                //2:�@���B3:�����
                theEPF1_0100_mod.chkApproveFlow(APLY_NO, EP_Z0F110.ST_2, MapUtils.getString(reqMap, "OP_STATUS"), SUB_CPY_ID);

                //�ˮ֬O�_�w���д���F160,�Y���BPAY_DATE<>null:�L�k�h��,PAY_DATE=null:�R��F160
                isDelF160 = theEPF1_0100_mod.chkF160(reqMap);
            }

            Transaction.begin();
            try {
                new EP_Z0F110().returnToStatus(reqMap, user, MapUtils.getString(reqMap, "RTN_STS"), MapUtils.getString(reqMap, "str"));

                //�R��F160
                if (isDelF160) {
                    EP_Z0F160 theEP_Z0F160 = new EP_Z0F160();
                    List<Map> F160List = theEP_Z0F160.qryChkList(APLY_NO, SUB_CPY_ID);
                    for (Map F160 : F160List) {
                        theEP_Z0F160.delete(VOTool.mapToVO(DTEPF160.class, F160));
                    }
                }

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_017");
            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�h�^�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_018");//�h�^�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_019");//�h�^����
            }
        } catch (Exception e) {
            log.error("�h�^����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_019");//�h�^����
        }

        return resp;
    }

    /**
     * �h�^
     * @param req
     * @return
     */
    public ResponseContext doCancelAssign(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�h�^");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (EP_Z0F110.ST_1.equals(MapUtils.getString(reqMap, "APLY_TP"))) {
                // 1:�s�P��
                new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_2, EP_Z0F110.ST_420 + "|" + EP_Z0F110.ST_200, SUB_CPY_ID);
            } else {
                //2:�@���B3:�����
                new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_2, EP_Z0F110.ST_300 + "|" + EP_Z0F110.ST_200, SUB_CPY_ID);
            }

            Transaction.begin();
            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_3);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_017");//�h�^����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�h�^�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_018");//�h�^�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_019");//�h�^����
            }
        } catch (Exception e) {
            log.error("�h�^����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_019");//�h�^����
        }

        return resp;
    }

    /**
     * ����(��µ��)
     * @param req
     * @return
     */
    public ResponseContext doAssign2(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "����(��µ��)");
            boolean IS_CHANGE = MapUtils.getBoolean(reqMap, "IS_CHANGE");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (!IS_CHANGE) {
                new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_1, EP_Z0F110.ST_300, SUB_CPY_ID);
            }

            Transaction.begin();
            try {
                if (IS_CHANGE) {
                    new EP_Z0F110().updateFiXGroupID(reqMap, user);
                } else {
                    new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_1);
                }

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_020");//����(��µ��)����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("����(��µ��)�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_021");//����(��µ��)�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_022");//����(��µ��)����
            }
        } catch (Exception e) {
            log.error("����(��µ��)����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_022");//����(��µ��)����
        }

        return resp;
    }

    /**
     * ��������(��µ��)
     * @param req
     * @return
     */
    public ResponseContext doCancelAssign2(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "��������(��µ��)");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_2, EP_Z0F110.ST_400, SUB_CPY_ID);

            Transaction.begin();
            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_2);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_023");//��������(��µ��)����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("��������(��µ��)�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_024");//��������(��µ��)�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_025");//��������(��µ��)����
            }
        } catch (Exception e) {
            log.error("����(��µ��)����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_025");//��������(��µ��)����
        }

        return resp;
    }

    /**
     * �T�{���u
     * @param req
     * @return
     */
    public ResponseContext doConfirmWork(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�T�{���u");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            EPF1_0100_mod theEPF1_0100_mod = new EPF1_0100_mod();
            theEPF1_0100_mod.chkApproveFlow(APLY_NO, EP_Z0F110.ST_1, EP_Z0F110.ST_400, SUB_CPY_ID);
            //�ˮ֭�µ�ץ�O�_�i�T�{���u
            theEPF1_0100_mod.chkFixFinal(APLY_NO, null, SUB_CPY_ID);
            reqMap.put("FIX_FINAL_DATE", DATE.currentTime());

            //�ˮ֬O�_�i�۰ʲ��ͽд���
            boolean autoInserF160 = false;
            String APLY_TP = MapUtils.getString(reqMap, "APLY_TP");
            String PRO_NO = null;
            if ("2".equals(APLY_TP) || "3".equals(APLY_TP)) {//�D�X����B�P�@�t��,�۰ʲ��ͽдڮ־P��
                Map rtnMap = this.chkAutoInserF160(APLY_NO, SUB_CPY_ID);
                autoInserF160 = MapUtils.getBooleanValue(rtnMap, "autoInserF160");
                PRO_NO = MapUtils.getString(rtnMap, "PRO_NO");
            }
            if (autoInserF160 && (new EP_Z0F160().queryCount(APLY_NO, null, PRO_NO, null, SUB_CPY_ID) > 0)) {
                throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_016"));//���t�Ӥw�д�
            }

            Transaction.begin();
            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_1);

                if (autoInserF160) {//����F160
                    Map F120 = new EP_Z0F120().queryF120List(APLY_NO, SUB_CPY_ID).get(0);
                    new EP_F10300().insert(APLY_NO, PRO_NO, SUB_CPY_ID, MapUtils.getString(F120, "EXP_TP"), user);
                }

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_026");//�T�{���u����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�T�{���u�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_027");//�T�{���u�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_028");//�T�{���u����
            }
        } catch (Exception e) {
            log.error("�T�{���u����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_028");//�T�{���u����
        }

        return resp;
    }

    /**
     * �T�{�O�_�ݦ۰ʲ��ͽдڮ־P��(�@�����,�D�X����,��@�t��)
     * @param aply_no
     * @param sub_cpy_id
     * @throws Exception 
     */
    private Map chkAutoInserF160(String APLY_NO, String SUB_CPY_ID) throws Exception {
        DTEPF130 F130Vo = new DTEPF130();
        F130Vo.setSUB_CPY_ID(SUB_CPY_ID);
        F130Vo.setAPLY_NO(APLY_NO);
        List<Map> F130List = new EP_Z0F130().queryF130List(F130Vo);
        String tmpPRO_NO = null;
        boolean autoInserF160 = true;
        for (Map F130 : F130List) {
            if ("1".equals(MapUtils.getString(F130, "IS_CONT"))) {
                autoInserF160 = false;
                break;
            }
            if (tmpPRO_NO == null) {//��l�Ĥ@�����t�ӽs��(�u�اǸ�)
                tmpPRO_NO = MapUtils.getString(F130, "PRO_NO");
            } else if (!StringUtils.equals(tmpPRO_NO, MapUtils.getString(F130, "PRO_NO"))) {//�����P���t�ӽs��
                autoInserF160 = false;
                break;
            }
        }
        Map rtnMap = new HashMap();
        rtnMap.put("autoInserF160", autoInserF160);
        if (autoInserF160) {
            rtnMap.put("PRO_NO", MapUtils.getString(F130List.get(0), "PRO_NO"));
        }
        log.debug("#### auto insert F160.rtnMap = " + rtnMap);
        return rtnMap;
    }

    /**
     * �������u
     * @param req
     * @return
     */
    public ResponseContext doCancelWork(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�������u");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            EPF1_0100_mod theEPF1_0100_mod = new EPF1_0100_mod();
            theEPF1_0100_mod.chkApproveFlow(APLY_NO, EP_Z0F110.ST_2, "410", SUB_CPY_ID);
            //�ˮ֬O�_�w���д���F160,�Y���BPAY_DATE<>null:�L�k�h��,PAY_DATE=null:�R��F160
            boolean isDelF160 = theEPF1_0100_mod.chkF160(reqMap);

            Transaction.begin();
            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_2);

                //�R��F160
                if (isDelF160) {
                    EP_Z0F160 theEP_Z0F160 = new EP_Z0F160();
                    List<Map> F160List = theEP_Z0F160.qryChkList(APLY_NO, SUB_CPY_ID);
                    for (Map F160 : F160List) {
                        theEP_Z0F160.delete(VOTool.mapToVO(DTEPF160.class, F160));
                    }
                }

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_029");//�������u����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�������u�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0101_ERRMSG_030");//�������u�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_031");//�������u����
            }
        } catch (Exception e) {
            log.error("�������u����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_031");//�������u����
        }

        return resp;
    }

    /**
     * �禬
     * @param req
     * @return
     */
    public ResponseContext doCommit(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            // String APLY_TP = MapUtils.getString(reqMap, "APLY_TP");
            reqMap.put("AUTH_DESC", "�禬");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            EPF1_0100_mod theEPF1_0100_mod = new EPF1_0100_mod();
            theEPF1_0100_mod.chkApproveFlow(APLY_NO, EP_Z0F110.ST_1, EP_Z0F110.ST_500, SUB_CPY_ID);
            //�ˮ֭�µ�ץ�O�_�i�����禬
            theEPF1_0100_mod.chkSubUsr(APLY_NO, SUB_CPY_ID);
            reqMap.put("SUB_USR_DATE", DATE.currentTime());
            //�s�P��µ�A�����禬�W�[�����u�ɶ�
            /*if(EP_Z0F110.ST_1.equals(APLY_TP)){
                reqMap.put("FIX_FINAL_DATE", DATE.currentTime());
            }*/

            Transaction.begin();
            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_1);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_032");//�����禬����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�禬�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0101_ERRMSG_033");//�����禬�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_034");//�����禬����
            }
        } catch (Exception e) {
            log.error("�禬����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_034");//�����禬����
        }

        return resp;
    }

    /**
     * �����禬
     * @param req
     * @return
     */
    public ResponseContext doCancelCommit(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�����禬");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_2, EP_Z0F110.ST_600, SUB_CPY_ID);

            Transaction.begin();
            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_2);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_035");//�����禬����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�����禬�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_036");//�����禬�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_037");//�����禬����
            }
        } catch (Exception e) {
            log.error("�����禬����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_037");//�����禬����
        }

        return resp;
    }

    /**
     * �дڤ��T�{
     * @param req
     * @return
     */
    public ResponseContext doReadyCheck(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�дڤ��T�{");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            List reqList = new ArrayList();
            reqList.add(reqMap);

            new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_1, EP_Z0F110.ST_600, SUB_CPY_ID);
            reqMap.put("USR_FINAL_DATE", DATE.currentTime());

            Transaction.setXAMode();
            Transaction.begin();

            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_1);
                if (EP_Z0F110.ST_1.equals(MapUtils.getString(reqMap, "APLY_TP"))) {//�ץ�������s�P��
                    new EP_F10300().insert(reqList, user, reqMap);
                }

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_038");//�дڤ��T�{����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�дڤ��T�{�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_039");//�дڤ��T�{�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_040");//�дڤ��T�{����
            }
        } catch (Exception e) {
            log.error("�дڤ��T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_040");//�дڤ��T�{����
        }

        return resp;
    }

    /**
     * �����дڤ��T�{
     * @param req
     * @return
     */
    public ResponseContext doCancelCheck(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�����дڤ��T�{");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_2, EP_Z0F110.ST_700, SUB_CPY_ID);

            Transaction.begin();

            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_2);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_041");//�����дڤ��T�{����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�����дڤ��T�{�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_042");//�����дڤ��T�{�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_043");//�����дڤ��T�{����
            }
        } catch (Exception e) {
            log.error("�дڤ��T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_043");//�����дڤ��T�{����
        }

        return resp;
    }

    /**
     * �����k��
     * @param req
     * @return
     */
    public ResponseContext doClose(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�����k��");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            EPF1_0100_mod theEPF1_0100_mod = new EPF1_0100_mod();
            theEPF1_0100_mod.chkApproveFlow(APLY_NO, EP_Z0F110.ST_1, EP_Z0F110.ST_700, SUB_CPY_ID);
            //�ˮ֭�µ�ץ�O�_�i�����k��
            theEPF1_0100_mod.chkEndAply(APLY_NO, SUB_CPY_ID);
            reqMap.put("END_APLY_DATE", DATE.currentTime());

            Transaction.begin();

            try {
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_1);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_044");//�����k�ɧ���

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�����k�ɧ����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_045");//�����k�ɧ����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_046");//�����k�ɥ���
            }
        } catch (Exception e) {
            log.error("�����k�ɥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_046");//�����k�ɥ���
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�R��");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            new EPF1_0100_mod().chkDelete(APLY_NO, SUB_CPY_ID);

            Transaction.begin();

            try {
                new EP_Z0F110().delete(VOTool.mapToVO(DTEPF110.class, reqMap), user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_047");//�R������

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�R�������A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_048");//�R�������A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_049");//�R������
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_049");//�R������
        }

        return resp;
    }

    /**
     * �T�{�u�k
     * @param req
     * @return
     */
    public ResponseContext doConfirmCFM_WORK_MO(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�T�{�u�k");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            EP_Z0F110 theEP_Z0F110 = new EP_Z0F110();
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_1, EP_Z0F110.ST_420, SUB_CPY_ID);
            Map rtnMap = theEP_Z0F110.queryMap(APLY_NO, SUB_CPY_ID);

            //�T�����e
            //EP_E00010_MSG_001
            //�ץ�s�� : {0}�A���A:�ݳB�z
            //{0} :insMap.PS_SER_NO
            StringBuilder sb = sendMailFormat(APLY_NO);

            Transaction.begin();
            try {
                reqMap.put("DIV_CFM_DATE", DATE.getY2KDate());//�D��ñ�֤��
                reqMap.put("INFM_CONS_DATE", DATE.getY2KDate());//�q���I�u���
                theEP_Z0F110.update(reqMap, user, EP_Z0F110.ST_1);
                //�q���ӿ�H
                String INPUT_ID = MapUtils.getString(rtnMap, "INPUT_ID");
                String INPUT_NM = MapUtils.getString(rtnMap, "INPUT_NM");
                String INPUT_DIV_NO = MapUtils.getString(rtnMap, "INPUT_DIV_NO");
                String INPUT_DIV_NM = MapUtils.getString(rtnMap, "INPUT_DIV_NM");
                //�O�_��ؤH��
                boolean isOut = false;
                if (INPUT_DIV_NO.startsWith("EP9")) {
                    isOut = true;
                }
                Map emp = new EP_F10310().getEmpMap(INPUT_ID, isOut, SUB_CPY_ID);
                String INFM_EMAIL = MapUtils.getString(emp, "EMAIL");
                theEP_Z0F110.senMail(APLY_NO, INPUT_ID, INPUT_NM, INFM_EMAIL, INPUT_DIV_NO, INPUT_DIV_NM, sb.toString());
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_050");//�T�{�u�k����EPF1_0100_ERRMSG_050

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�T�{�u�k�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_051");//�T�{�u�k�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_052");//�T�{�u�k����
            }
        } catch (Exception e) {
            log.error("�T�{�u�k����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_052");//�T�{�u�k����
        }

        return resp;
    }

    private StringBuilder sendMailFormat(String APLY_NO) {
        StringBuilder sb = new StringBuilder();
        sb.append("<META http-equiv=Content-Type content='text/html; charset=BIG5'></META>\n");
        sb.append("<html>\n");
        sb.append("<head></head>\n<body bgColor=#FFFFFF>\n");

        sb.append("<body>");

        sb.append("<BR>");
        sb.append("<table border='1' cellpadding='0' cellspacing='1' width='50%'>");

        sb.append("<tr>");
        sb.append("<td align='center'>").append(MessageUtil.getMessage("EPF1_0100_ERRMSG_050_1")).append("</td>");
        sb.append("<td align='center'>").append(MessageUtil.getMessage("EPF1_0100_ERRMSG_050_2")).append("</td>");

        sb.append("</tr>");

        sb.append("<tr>");
        sb.append("<td align='center'>").append(APLY_NO).append("</td>");
        sb.append("<td align='center'>").append(MessageUtil.getMessage("EPF1_0100_ERRMSG_050_3")).append("</td>");

        sb.append("</tr>");

        sb.append("</table>");

        sb.append("</body></html>");
        return sb;
    }

    /**
     * �����T�{�u�k
     * @param req
     * @return
     */
    public ResponseContext doCancelCFM_WORK_MO(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�����T�{�u�k");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, EP_Z0F110.ST_2, EP_Z0F110.ST_500, SUB_CPY_ID);

            Transaction.begin();

            try {
                reqMap.put("DIV_CFM_DATE", null);//�D��ñ�֤��
                reqMap.put("INFM_CONS_DATE", null);//�q���I�u���                
                new EP_Z0F110().update(reqMap, user, EP_Z0F110.ST_2);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_053");//�����T�{�u�k����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�����T�{�u�k�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_054");//�����T�{�u�k�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_055");//�����T�{�u�k����
            }
        } catch (Exception e) {
            log.error("�����T�{�u�k����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_055");//�����T�{�u�k����
        }

        return resp;
    }

    /**
     * �P��
     * @param req
     * @return
     */
    public ResponseContext doCancel(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�P��");
            DTEPF110 DTEPF110VO = VOTool.jsonToVO(DTEPF110.class, req.getParameter("reqMap"));
            String SUB_CPY_ID = DTEPF110VO.getSUB_CPY_ID();
            String APLY_NO = DTEPF110VO.getAPLY_NO();
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            new EPF1_0100_mod().chkCancel(APLY_NO, SUB_CPY_ID);

            Transaction.begin();

            try {
                new EP_Z0F110().cancel(DTEPF110VO, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_062");//�P�ק���

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�P�ק����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_063");//�P�ק����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_064");//�P�ץ���
            }
        } catch (Exception e) {
            log.error("�P�ץ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_064");//�P�ץ���
        }

        return resp;
    }

    /**
     * i9300622 2015/9/30
     * ���u�����ҩ�
     * @param req
     * @return
     */
    public ResponseContext doMaterialCertification(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "���u�����ҩ�");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, "1", "410", SUB_CPY_ID);

            Transaction.begin();
            try {
                new EP_Z0F110().approve(reqMap, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_068");//���u�����ҩ�����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("���u�����ҩ������A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_069");//���u�����ҩ������A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_070");//���u�����ҩ�����
            }
        } catch (Exception e) {
            log.error("���u�����ҩ�����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_070");//���u�����ҩ�����
        }

        return resp;
    }

    /**
     * i9300622 2015/9/30
     * �����ҩ��Ʋz�f��
     * @param req
     * @return
     */
    public ResponseContext doMaterialCertificationViceSupervisorApprove(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�����ҩ��Ʋz�f��");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, "1", "430", SUB_CPY_ID);

            Transaction.begin();
            try {
                new EP_Z0F110().approve(reqMap, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_071");//�����ҩ��Ʋz��֧���

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�����ҩ��Ʋz��֧����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_072");//�����ҩ��Ʋz��֧����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_073");//�����ҩ��Ʋz��֥���
            }
        } catch (Exception e) {
            log.error("�����ҩ��Ʋz��֥���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_073");//�����ҩ��Ʋz��֥���
        }

        return resp;
    }

    /**
     * i9300622 2015/9/30
     * �����ҩ��g�z�f��
     * @param req
     * @return
     */
    public ResponseContext doMaterialCertificationSupervisorApprove(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�����ҩ��g�z�f��");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, "1", "440", SUB_CPY_ID);

            Transaction.begin();
            try {
                new EP_Z0F110().approve(reqMap, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_074");//�����ҩ��g�z�Ю֧���

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�����ҩ��g�z�Ю֧����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_075");//�����ҩ��g�z�Ю֧����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_076");//�����ҩ��g�z�Ю֥���
            }
        } catch (Exception e) {
            log.error("�����ҩ��g�z�Ю֥���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_076");//�����ҩ��g�z�Ю֥���
        }

        return resp;
    }

    /**
     * i9300622 2015/9/30
     * �O�T�ѽT�{
     * @param req
     * @return
     */
    public ResponseContext doGuarantee(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�O�T�ѽT�{");
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, "1", "510", SUB_CPY_ID);

            Transaction.begin();
            try {
                new EP_Z0F110().approve(reqMap, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_077");//�O�T�ѽT�{����

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�O�T�ѽT�{�����A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_078");//�O�T�ѽT�{�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_079");//�O�T�ѽT�{����
            }
        } catch (Exception e) {
            log.error("�O�T�ѽT�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_079");//�O�T�ѽT�{����
        }

        return resp;
    }

    /**
     * i9300622 2015/9/30
     * �C�L�дڳq��
     * @param req
     * @return
     */
    public ResponseContext doInvoice(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�C�L�дڳq��");
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            new EPF1_0100_mod().chkApproveFlow(APLY_NO, "1", "500", SUB_CPY_ID);

            Transaction.begin();
            try {
                //�I�s�Ҳղ��ͽдڳq����
                String fileID = new EP_Z0F110().createUploadPDF(reqMap, user, "2", resp, req);
                resp.addOutputData("fileID", fileID);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_080");//�C�L�дڳq������

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�C�L�дڳq�������A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_081");//�C�L�дڳq�������A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_082");//�C�L�дڳq������
            }
        } catch (Exception e) {
            log.error("�C�L�дڳq������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_082");//�C�L�дڳq������
        }

        return resp;
    }

    /**
     * i9300622 2015/9/30
     * �C�L�禬��
     * @param req
     * @return
     */
    public ResponseContext doAcceptance(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("AUTH_DESC", "�C�L�禬��");
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            //�ˮ֭�µ�ץ�y�{���A�O�_�i����
            EPF1_0100_mod theEPF1_0100_mod = new EPF1_0100_mod();
            theEPF1_0100_mod.chkApproveFlow(APLY_NO, "1", "500", SUB_CPY_ID);
            //�ˮ֭�µ�ץ�O�_�i�����禬
            //theEPF1_0100_mod.chkSubUsr(APLY_NO);

            Transaction.begin();
            try {
                //�I�s�ҲզC�L�禬��
                String fileID = new EP_Z0F110().createUploadPDF(reqMap, user, "1", resp, req);

                resp.addOutputData("fileID", fileID);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_083");//�C�L�禬�槹��

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�C�L�禬�槹���A���d�d�L���", e);
                MessageHelper.setReturnMessage(msg, ReturnCode.OK, "EPF1_0100_ERRMSG_084");//�C�L�禬�槹���A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0100_ERRMSG_085");//�C�L�禬�楢��
            }
        } catch (Exception e) {
            log.error("�C�L�禬�楢��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0100_ERRMSG_085");//�C�L�禬�楢��
        }

        return resp;
    }

    /**
     * �j�M����-�j�ӫ�ĳ�M��
     * @param req
     * @return
     */
    public ResponseContext doSuggestBLD_CD(RequestContext req) {
        try {
            //�u�j�ӫ�ĳ�M��v��ĳ���G 
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_CD", req.getParameter("suggestValue"));
            List<Map> rtnList = new EP_Z0F170().queryList(reqMap);
            List<Map> BLD_CDList = new ArrayList<Map>();
            Map trnMap;
            for (Map map : rtnList) {
                trnMap = new HashMap();
                trnMap.put("INPUT_CD", map.get("INPUT_CD"));
                trnMap.put("INPUT_NM", map.get("INPUT_NM"));
                String BLD_NM = MapUtils.getString(map, "BLD_NAME");
                String BLD_CD = MapUtils.getString(map, "BLD_CD");
                String BLD_ADDR = MapUtils.getString(map, "BLD_ADDR");
                String BLD_USE_CD = MapUtils.getString(map, "BLD_USE_CD");
                trnMap.put("BLD_NM", BLD_NM);
                trnMap.put("BLD_CD", BLD_CD);
                trnMap.put("BLD_ADDR", BLD_ADDR);
                trnMap.put("BLD_USE_CD", BLD_USE_CD);
                BLD_CDList.add(trnMap);
            }
            resp.addOutputData("suggestResult", BLD_CDList);
        } catch (Exception e) {
            log.error("�j�ӷj�M���ܬd�ߥ���", e);
        }
        return resp;
    }

    /**
     * �f��y�{�d��
     * @param req
     * @return
     */
    public ResponseContext doCourse(RequestContext req) {
        try {
            String flowNo = req.getParameter("FLOW_NO");
            String[] flowNoGroup = flowNo.split(",");
            List<DTRZN011> resultList = new ArrayList<DTRZN011>();
            RZ_N00100 aRZ_N00100 = new RZ_N00100();
            for (int i = 0; i < flowNoGroup.length; i++) {
                DTRZN011 aDTRZN011 = new DTRZN011();
                if (!"".equals(flowNoGroup[i])) {
                    aDTRZN011.setFLOW_NO(flowNoGroup[i]);
                }
                List<DTRZN011> voList = aRZ_N00100.queryDTRZN011(aDTRZN011);
                resultList.addAll(voList);
            }
            
            //20190211 �q���@�~�ӽЮ�190130000633:��µ�e������������� 
            for (DTRZN011 theDTRZN011 : resultList) {
                //�@�~��������ܬA������r
                String[] authDescGroup = theDTRZN011.getAUTH_DESC().split("[(]");
                theDTRZN011.setAUTH_DESC(authDescGroup[0]);
                //��ܻ�������ܬA������r
                String[] commentGroup = theDTRZN011.getCOMMENT().split("[(]");
                theDTRZN011.setCOMMENT(commentGroup[0]);
            }

            try {
                List<Map<String, String>> todoList = new EPF1_0100_mod().getToDoList(req.getParameter("APLY_NO"), req
                        .getParameter("SUB_CPY_ID"));
                resp.addOutputData("todoList", todoList);
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L�N��M��", dnfe);
            }
            resp.addOutputData("resultList", resultList);
            ReturnMessageUtil.setMessage(IConstants.MI00020, ReturnCode.OK, msg);

        } catch (Exception e) {
            if (log.isDebugEnabled()) {
                log.error(e);
            }
            ReturnMessageUtil.setMessage(IConstants.ME00632, ReturnCode.OK, msg);
        }
        return resp;
    }

    /**
     * �@�άd��
     * @param reqMap
     * @param theEP_A30040
     * @throws Exception 
     */
    private void query(String APLY_NO, String SUB_CPY_ID) throws Exception {
        Map rtnMap = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
        try {
            List<Map> voList = new EP_Z0F120().queryF120List(APLY_NO, SUB_CPY_ID);//�Ƨѿ�
            String FLOW_NO = MapUtils.getString(rtnMap, "FLOW_NO");
            boolean isFirst = true;
            for (Map map : voList) {
                if (isFirst) {
                    if (user.getEmpID().equals(MapUtils.getString(map, "SUBCON_GROUP_ID", ""))) {
                        resp.addOutputData("IS_SUBCON_GROUP_ID", "Y");
                    }
                    isFirst = false;
                }
                String TFLOW_NO = MapUtils.getString(map, "FLOW_NO");
                if (StringUtils.isNotBlank(TFLOW_NO)) {
                    FLOW_NO = FLOW_NO + "," + TFLOW_NO;
                }
            }
            rtnMap.put("FLOW_NO", FLOW_NO);
        } catch (DataNotFoundException e) {
            //�d�L��Ƶ������`
        }

        setBtnPrivilege(rtnMap, SUB_CPY_ID);

        resp.addOutputData("rtnMap", rtnMap);
        StringBuilder sb = new StringBuilder();
        String APLY_TP = MapUtils.getString(rtnMap, "APLY_TP");
        String OP_STATUS = MapUtils.getString(rtnMap, "OP_STATUS");
        String EXP_TP = MapUtils.getString(rtnMap, "EXP_TP");
        if (EP_Z0F110.ST_1.equals(APLY_TP)) {
            //�s�P��µ�ץ�u���߮׭�ñ
            sb = sb.append(APLY_TP).append("XXXX");
        } else if (EP_Z0F110.ST_2.equals(APLY_TP)) {
            //�@���µ�ץ�̶i����ܭ�ñ
            sb.append(APLY_TP).append(OP_STATUS).append("X").toString();
        } else if (EP_Z0F110.ST_3.equals(APLY_TP)) {
            //�����µ�ץ�̶i����ܭ�ñ
            sb.append(APLY_TP).append(OP_STATUS).append("X").toString();
        }
        //���إ߳Ƨѿ��e���i�T�{���u
        //�إ߳Ƨѿ��ᦳ���w�ƬI�u���u�{�������i�T�{���u
        if (EP_Z0F110.ST_2.equals(APLY_TP) || EP_Z0F110.ST_3.equals(APLY_TP)) {
            isHidBtnConfirmWork(APLY_NO, resp);
        }
        //��A
        boolean isItSuperRole = isItSuperRole();
        boolean isFixDivRole = isFixDivRole1();

        Map tabMap = FieldOptionList.getName("EP", sb.toString());
        List<Map> TAB_LIST = new ArrayList<Map>();
        for (Object every_key : tabMap.keySet()) {
            if ("EPF10104".equals(every_key)) {
                //�������R
                if (!EP_Z0F110.ST_1.equals(APLY_TP) && (isFixDivRole || isItSuperRole)) {
                    //�D�s�P��B����µ��H���~�i�@�~
                    //�߮׸�ơB�Ƨѿ��B�u�{����
                    Map map = new HashMap();
                    map.put("id", every_key);
                    map.put("title", MapUtils.getString(tabMap, every_key, ""));
                    TAB_LIST.add(map);
                }
            } else {
                //�߮׸�ơB�Ƨѿ��B�u�{����
                Map map = new HashMap();
                map.put("id", every_key);
                map.put("title", MapUtils.getString(tabMap, every_key, ""));
                if (every_key.equals("EPF10102") && !EP_Z0F110.ST_1.equals(APLY_TP) && EP_Z0F110.ST_400.equals(OP_STATUS)) {
                    boolean jumpTabsRole = false;
                    String[] noJumpTabsRoles = FieldOptionList.getName("EP", "NO_JUMP_TABS_ROLE", "ROLE_CONTROL").split(",");
                    for (int i = 0; i < noJumpTabsRoles.length; i++) {
                        String noJumpTabsRole = noJumpTabsRoles[i];
                        if (user.getRoles().containsKey(noJumpTabsRole)) {
                            jumpTabsRole = true;
                        }
                    }

                    if (jumpTabsRole) {
                        map.put("defaultSelect", true);
                    }

                }
                TAB_LIST.add(map);
            }
        }

        if (!EP_Z0F110.ST_1.equals(APLY_TP) && EP_Z0F110.ST_3.equals(EXP_TP) && (isFixDivRole || isItSuperRole)) {
            //�D�s�P��B��������~�ݥX�{�M�����ñ
            //TAB_LIST.add(map);
            sb.delete(0, sb.length());
            Map tab1Map = FieldOptionList.getName("EP", sb.append("XXXX").append(EXP_TP).toString());
            for (Object every_key : tab1Map.keySet()) {
                Map map = new HashMap();
                map.put("id", every_key);
                map.put("title", MapUtils.getString(tab1Map, every_key, ""));
                TAB_LIST.add(map);
            }
        }

        resp.addOutputData("TAB_LIST", TAB_LIST);

    }

    /**
     * �P�_��µ�լO�_�i�T�{���u�B�P�_��µ�լO�_�i��������(��µ��)
     * @param APLY_NO
     * @return
     * @throws Exception
     */
    private boolean isHidBtnConfirmWork(String APLY_NO, ResponseContext resp) throws Exception {
        boolean isHidBtnConfirmWork = false;
        boolean isHidBtnCancelAssign2 = false;
        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            List<Map> voList = new EP_Z0F120().queryF120List(APLY_NO, SUB_CPY_ID);
            for (Map map : voList) {
                String OP_STATUS_120 = MapUtils.getString(map, "OP_STATUS", "");

                if (!EP_Z0F110.ST_490.equals(OP_STATUS_120)) {
                    isHidBtnConfirmWork = true;
                }
            }
            if (voList.size() > 0) {
                isHidBtnCancelAssign2 = true;
            }
        } catch (DataNotFoundException e) {
            isHidBtnConfirmWork = true;
        }
        resp.addOutputData("isHidBtnConfirmWork", isHidBtnConfirmWork);
        resp.addOutputData("isHidBtnCancelAssign2", isHidBtnCancelAssign2);
        return isHidBtnConfirmWork;
    }

    /**
     * �ˬd�j�ӦW�٩Τj�Ӧa�}�O�_��
     * @param DTEPF110VO
     * @throws ModuleException
     */
    private void chkBLD_NAME(DTEPF110 DTEPF110VO) throws ModuleException {
        //�j�ӦW�٩Τj�Ӧa�}�L�ȮɡA�d��EP_Z0F170().queryList(reqMap)�N�j�ӦW�٩Τj�Ӧa�}�g�J��Ʈw
        if (StringUtils.isBlank(DTEPF110VO.getBLD_NM()) || StringUtils.isBlank(DTEPF110VO.getBLD_ADDR())) {
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", DTEPF110VO.getSUB_CPY_ID());
            reqMap.put("BLD_CD", DTEPF110VO.getBLD_CD());
            try {
                Map BLD_MAP = new EP_Z0F170().queryList(reqMap).get(0);
                DTEPF110VO.setBLD_ADDR(MapUtils.getString(BLD_MAP, "BLD_ADDR"));
                DTEPF110VO.setBLD_NM(MapUtils.getString(BLD_MAP, "BLD_NAME"));
            } catch (DataNotFoundException dnfe) {
                throw new ModuleException("�d�L���j��");
            }
        }

    }

    //��A����
    private boolean isItSuperRole() {
        String RLZZ0EP = FieldOptionList.getName("EP", "DIV_F106", "RLZZ0EP");
        return user.getRoles().containsKey(RLZZ0EP);
    }

    //��µ�쨤��
    private boolean isFixDivRole1() {
        String FIX_DIV_ROLE = FieldOptionList.getName("EP", "EP_ROLES", "FIX_DIV_ROLE1");//"RLEP014"��µ��
        return user.getRoles().containsKey(FIX_DIV_ROLE);
    }
}
