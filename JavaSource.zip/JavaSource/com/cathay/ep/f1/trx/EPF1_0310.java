package com.cathay.ep.f1.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.CustomerBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.df.b0.module.DF_B0Z001;
import com.cathay.dj.a0.module.DJ_A0Z002;
import com.cathay.dj.bo.DTDJA004;
import com.cathay.dk.m0.module.DK_M0Z016;
import com.cathay.ep.f1.module.EPF1_0102_mod;
import com.cathay.ep.f1.module.EPF1_0310_mod;
import com.cathay.ep.f1.module.EP_F10310;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F180;
import com.cathay.rpt.RptUtils;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.db.DBException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2015/12/22 1.0 Created ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW�� ��޵|�뵲�@�~
 * �Ҳ�ID   EPF1_0310
 * ���n���� (1) ��l
 *          (2) �d��
 *          (3) �T�{
 *          (4) �����T�{
 *          (5) �д�
 *          (6) �����д�
 *          (7) �дڽT�{ 
 *          (8) �ץX 
 *</pre>
 * @author �d�ÿ�
 * @since 2016-01-13
 * 2019/12/03 �E�Ͷv:��T���������@�~�ӽЮ�191202000999�G�дڦ걵�Q�`���Y�H�d��(�W��t�X�վ�)
 */

@SuppressWarnings("unchecked")
public class EPF1_0310 extends CustomerBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPF1_0310.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        StringBuilder sb = new StringBuilder();

        resp.addOutputData("CMM_YM", DATE.getTodayYearAndMonth());

        // ���o�����q�O
        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
            sb.append(MessageUtil.getMessage("EPF1_0310_ERRMSG_001")); // ���o�����q�O����
            STRING.newLine(sb);
        }

        // ���o�@�~�i�ײM��
        try {
            resp.addOutputData("OP_STATUS_LIST", FieldOptionList.getName("EP", "F180_OP_STATUS"));
        } catch (Exception e) {
            log.error("���o�@�~�i�ײM��", e);
            sb.append(MessageUtil.getMessage("EPF1_0310_ERRMSG_002")); // ���o�@�~�i�ײM��
            STRING.newLine(sb);
        }

        String SUP_ID = "70577266"; // �t�ӥN���A�w�]�M��Ӻ� 7577266        
        resp.addOutputData("SUP_ID", SUP_ID);
        try {
            getSUP_NM(SUP_ID);
        } catch (Exception e) {
            log.error("���o�t�ӦW�٥���", e);
            sb.append(MessageUtil.getMessage("EPF1_0310_ERRMSG_003")); // ���o�t�ӦW�٥���
            STRING.newLine(sb);
        }

        // ���o�w����M��
        try {
            resp.addOutputData("BUD_DIV_NO_LIST", new DF_B0Z001().getCurrYearDivAcnt(user.getOpUnit()));
        } catch (Exception e) {
            log.error("���o�w����M�楢��", e);
            sb.append(MessageUtil.getMessage("EPF1_0310_ERRMSG_004")); // ���o�w����M�楢��
            STRING.newLine(sb);
        }

        //��µ��t�d�H ��µ��    3
        EPF1_0102_mod mod = new EPF1_0102_mod();
        //��µ��W�űb��
        String[] fixSuperId = FieldOptionList.getName("EP", "SUPER_ID", "FIX_SUPER_ID").split(",");
        if (user.getRoles().containsKey("RLEP014") || mod.isSuperIdMap(fixSuperId, user)) {
            log.debug("IS_FIX_DIV");
            //��µ��b�ȤH��
            String[] ACCOUNT_IDS = FieldOptionList.getName("EP", "ACCOUNTS_ID", "ACCOUNTS_IDS").split(",");
            if (mod.isSuperIdMap(ACCOUNT_IDS, user) || mod.isSuperIdMap(fixSuperId, user)) {
                log.debug("IS_ACCOUNT_ID");
                resp.addOutputData("IS_ACCOUNT_ID", "Y");
            }
        }

        if (sb.length() != 0) {
            MessageUtil.setErrorMsg(msg, sb.toString());
            sb.setLength(0);
        }

        return resp;
    }

    /**
     * �t�ӥN���s�ʼt�ӦW��
     * @param req
     * @return
     */
    public ResponseContext doGetSUP_NM(RequestContext req) {

        try {
            getSUP_NM(req.getParameter("SUP_ID"));
        } catch (Exception e) {
            log.error("���o�t�ӦW�٥���", e);
        }
        return resp;
    }

    /**
     * �d�߬d�߼t�ӥN��
     * @param SUP_ID
     * @throws DBException
     * @throws ModuleException
     */
    private void getSUP_NM(String SUP_ID) throws DBException, ModuleException {

        ReturnMessage rtnMsg = new ReturnMessage();
        DTDJA004 DTDJA004vo = new DJ_A0Z002().doQuery(SUP_ID, rtnMsg);
        if (rtnMsg.getReturnCode() == ReturnCode.OK) {
            resp.addOutputData("SUP_NM", DTDJA004vo.getACPT_NAME());
        } else if (rtnMsg.getReturnCode() == ReturnCode.DATA_NOT_FOUND) {
            resp.addOutputData("SUP_NM", SUP_ID);
        } else {
            throw new ModuleException(rtnMsg.getMsgDesc());
        }
    }

    /**
     * �w����s�ʹw����
     * @param req
     * @return
     */
    public ResponseContext doGetBUD_ACNT_CODE(RequestContext req) {

        try {
            //�w����
            String OUT_STR = getBUD_ACNT_CODE(req.getParameter("BUD_DIV_NO"), new DF_B0Z001().getCurrYearDivAcnt(user.getOpUnit()));

            List<Map> tmpList = new ArrayList();
            String[] OUT_STR_array = OUT_STR.split(",");
            for (String str : OUT_STR_array) {
                String[] tempstr = str.split(":")[0].split("\\.");
                Map BUD_ACNT_Map = new HashMap();
                BUD_ACNT_Map.put("key", tempstr[0]);
                BUD_ACNT_Map.put("value", tempstr[1]);
                tmpList.add(BUD_ACNT_Map);
            }
            resp.addOutputData("BUD_ACNT_CODE_LIST", tmpList);

        } catch (Exception e) {
            log.error("���o�w���إ���", e);
        }
        return resp;
    }

    /**
     * @param BUD_DIV_NO
     * @param DTDFA004List
     * @return
     * @throws ModuleException
     */
    private String getBUD_ACNT_CODE(String BUD_DIV_NO, List DTDFA004List) throws ModuleException {
        String OUT_STR = "";
        StringBuilder sb = new StringBuilder();
        HashMap totalMap = getMap(DTDFA004List, BUD_DIV_NO);
        List bolist = (List) totalMap.get("BUD_ACNT_CODEList");

        for (int i = 0; i < bolist.size(); i++) {
            Map outMap = (Map) bolist.get(i);
            sb.append(STRING.objToStrNoNull(outMap.get("BUD_ACNT_CODE"))).append(".").append(
                STRING.objToStrNoNull(outMap.get("BUD_ACNT_NAME"))).append(":").append(STRING.objToStrNoNull(outMap.get("BUD_ACNT_CODE")))
                    .append(" ").append(STRING.objToStrNoNull(outMap.get("BUD_ACNT_NAME"))).append(",");

        }
        // �����̫�@�ӳr��
        if (sb.length() > 0) {
            OUT_STR = sb.substring(0, sb.length() - 1);
        }

        return OUT_STR;
    }

    /**
     * @param DTDFA004List
     * @param strBUD_DIV_NO
     * @return
     * @throws ModuleException
     */
    private HashMap getMap(List DTDFA004List, String strBUD_DIV_NO) throws ModuleException {
        HashMap totalmp = new HashMap();

        String BUD_ACNT_CODE = "";

        List BUD_ACNT_CODEList = new ArrayList();

        for (int i = 0; i < DTDFA004List.size(); i++) {
            Map div_noMap = (Map) DTDFA004List.get(i);

            Map mpAcnt_Code = new HashMap();

            if (strBUD_DIV_NO.equals(div_noMap.get("BUD_DIV_NO"))) {
                if (!BUD_ACNT_CODE.equals(STRING.objToStrNoNull(div_noMap.get("BUD_ACNT_CODE")))) {
                    mpAcnt_Code.put("BUD_ACNT_CODE", STRING.objToStrNoNull(div_noMap.get("BUD_ACNT_CODE")));
                    mpAcnt_Code.put("BUD_ACNT_NAME", STRING.objToStrNoNull(div_noMap.get("BUD_ACNT_NAME")));

                }
                BUD_ACNT_CODEList.add(mpAcnt_Code);
                BUD_ACNT_CODE = STRING.objToStrNoNull(div_noMap.get("BUD_ACNT_CODE"));
            }
        }
        totalmp.put("BUD_ACNT_CODEList", BUD_ACNT_CODEList);

        return totalmp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            query(reqMap);

            MessageUtil.setMsg(msg, "MEP00002");

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");
        }

        return resp;
    }

    /**
     * @param qryMap
     * @throws ModuleException
     */
    private void query(Map qryMap) throws ModuleException {
        resp.addOutputData("rtnList", new EP_F10310().queryList(qryMap, MapUtils.getString(qryMap, "SUB_CPY_ID")));
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    public ResponseContext doConfirm(RequestContext req) {

        try {
            Map qryMap = VOTool.jsonToMap(req.getParameter("qryMap"));
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            Map copyReqMap = new HashMap();
            copyReqMap.put("CMM_YM", MapUtils.getString(reqMap, "CMM_YM"));
            List rtnList;
            try {
                rtnList = new EP_Z0F180().queryList(copyReqMap, SUB_CPY_ID);
            } catch (DataNotFoundException e) {
                // �d�L��ƬO�����`
                rtnList = new ArrayList();
            }
            // ���d�뵲�ץ�M��  
            String DATE_S = MapUtils.getString(reqMap, "DATE_S");
            String DATE_E = MapUtils.getString(reqMap, "DATE_E");
            List reqList = new EP_Z0F110().queryByCMMDATE(SUB_CPY_ID, DATE_S, DATE_E); // �d�ߥ��뵲F110
            // �ˮ֭�µ�ץ󪬺A�O�_�Ҥw���ץB���뵲:
            new EPF1_0310_mod().chkConfirm(reqList);
            new EPF1_0310_mod().chkConfirm1(reqList, rtnList);

            // �뵲�T�{
            Transaction.begin();
            try {
                new EP_F10310().confirm(reqList, reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPF1_0310_MSG_001"); // �뵲�T�{����

            try {
                query(qryMap);
            } catch (DataNotFoundException dnfe) {
                log.error("�뵲�T�{�����A���d�d�L���", dnfe);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPF1_0310_MSG_002"); // �뵲�T�{�����A���d�d�L���
            } catch (Exception e) {
                log.error("�뵲�T�{�����A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPF1_0310_MSG_003"); // �뵲�T�{�����A���d����
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0310_ERRMSG_006"); // �뵲�T�{����
            }
        } catch (Exception e) {
            log.error("�뵲�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0310_ERRMSG_006"); // �뵲�T�{����
        }
        return resp;
    }

    /**
     * �����T�{
     * @param req
     * @return
     */
    public ResponseContext doCancelConfirm(RequestContext req) {

        try {
            Map qryMap = VOTool.jsonToMap(req.getParameter("qryMap"));
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            // �ˮ֤뵲�O���O�_�w�д�
            new EPF1_0310_mod().chkCancelConfirm(reqMap);

            // �����뵲�T�{
            Transaction.begin();
            try {
                new EP_F10310().cancelConfirm(reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPF1_0310_MSG_004"); // �����뵲�T�{����

            try {
                query(qryMap);
            } catch (DataNotFoundException dnfe) {
                log.error("�����뵲�T�{�����A���d�d�L���", dnfe);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPF1_0310_MSG_005"); // �����뵲�T�{�����A���d�d�L���
            } catch (Exception e) {
                log.error("�����뵲�T�{�����A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPF1_0310_MSG_006"); // �����뵲�T�{�����A���d����
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0310_ERRMSG_007"); // �����뵲�T�{����
            }
        } catch (Exception e) {
            log.error("�뵲�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0310_ERRMSG_007"); // �����뵲�T�{����
        }
        return resp;
    }

    /**
     * �д�
     * @param req
     * @return
     */
    public ResponseContext doPay(RequestContext req) {

        try {
            Map qryMap = VOTool.jsonToMap(req.getParameter("qryMap"));
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            Map F180Map = VOTool.jsonToMap(req.getParameter("F180Map"));
            F180Map.put("SUB_CPY_ID", reqMap.get("SUB_CPY_ID"));
            // �ˮ֤뵲�O���O�_�w�д�
            new EPF1_0310_mod().chkPay(F180Map);

            //20191203��T���������@�~�ӽЮ�191202000999�G�дڦ걵�Q�`���Y�H�d��(�W��t�X�վ�) by �E�Ͷv
            //�]�W��call�дڼҲղ��ͽдڮץ󬰸󥭥xXA�s�u�A�ӽдڼҲդ��ˮ֬O�_���Q�`���Y�H���Ҳլ��W�߳s�u�A�bXA�s�u�����|�P�_�W�߳s�u��XA�s�u�C
            //����󥭥xXA�s�u�e�A���ˮ֬O�_���Q�`���Y�H�A�h�L�bXA�s�u���J�W�߳s�u���D�C
            //���קK�s�u�P�_���D�A�N�ˮ֬O�_���Q�`���Y�H���Ҳղ���call�дڼҲդ��e����d�ߡA�A�N�d�ߧQ�`���Y�H���G�@�P�ǤJ�дڼҲաC
            String SUP_ID = MapUtils.getString(F180Map, "SUP_ID");
            try {
	            log.fatal("******�d�ߧQ�`���Y�H���[�}�l]******");
	            
				log.fatal("******�d�ߧQ�`���Y�H���[�}�l]******");

				String IS_PRO_REL = new DK_M0Z016().getIS_PRO_REL(SUP_ID);

				log.fatal("******�d�ߧQ�`���Y�H���[����]******"); 
	            F180Map.put("IS_PRO_REL", IS_PRO_REL);
            } catch (Exception e) {
	            log.fatal(SUP_ID + "�d��FM_P2Z001.getIOPartyCheck�Q�`���Y�H���~�G" + e.getMessage());
                throw new ModuleException("�d�ߧQ�`���Y�H���~�G" + e.getMessage());
            }
            
            // �뵲�д�
            Transaction.setXAMode();
            Transaction.begin();
            try {
                new EP_F10310().pay(F180Map, reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPF1_0310_MSG_007"); // �뵲�дڧ���

            try {
                query(qryMap);
            } catch (DataNotFoundException dnfe) {
                log.error("�뵲�дڧ����A���d�d�L���", dnfe);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPF1_0310_MSG_008"); // �뵲�дڧ����A���d�d�L���
            } catch (Exception e) {
                log.error("�뵲�дڧ����A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPF1_0310_MSG_009"); // �뵲�дڧ����A���d����
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0310_ERRMSG_008"); // �뵲�дڥ���
            }
        } catch (Exception e) {
            log.error("�뵲�дڥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0310_ERRMSG_008"); // �뵲�дڥ���
        }
        return resp;
    }

    /**
     * �����д�
     * @param req
     * @return
     */
    public ResponseContext doCancelPay(RequestContext req) {

        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            Map qryMap = VOTool.jsonToMap(req.getParameter("qryMap"));
            // �ˮ֤뵲�O���O�_�w�д�
            reqMap.put("SUB_CPY_ID", qryMap.get("SUB_CPY_ID"));
            new EPF1_0310_mod().chkCanclePay(reqMap);

            // �����뵲�д�
            Transaction.setXAMode();
            Transaction.begin();
            try {
                new EP_F10310().cancelPay(reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPF1_0310_MSG_010"); // �����뵲�дڧ���

            try {
                query(qryMap);
            } catch (DataNotFoundException dnfe) {
                log.error("�����뵲�дڧ����A���d�d�L���", dnfe);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPF1_0310_MSG_011"); // �����뵲�дڧ����A���d�d�L���
            } catch (Exception e) {
                log.error("�����뵲�дڧ����A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPF1_0310_MSG_012"); // �����뵲�дڧ����A���d����
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0310_ERRMSG_009"); // �����뵲�дڥ���
            }
        } catch (Exception e) {
            log.error("�����뵲�дڥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0310_ERRMSG_009"); // �����뵲�дڥ���
        }
        return resp;
    }

    /**
     * �дڽT�{
     * @param req
     * @return
     */
    public ResponseContext doPayConfirm(RequestContext req) {

        try {
            Map qryMap = VOTool.jsonToMap(req.getParameter("qryMap"));
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            Map F180Map = VOTool.jsonToMap(req.getParameter("F180Map"));
            F180Map.put("SUB_CPY_ID", reqMap.get("SUB_CPY_ID"));
            // �ˮ֤뵲�O���O�_�w�дڽT�{
            String ACC_SECVER_DATE = new EPF1_0310_mod().chkPayConfirm(F180Map);
            reqMap.put("ACC_SECVER_DATE", ACC_SECVER_DATE);

            // �����뵲�д�
            Transaction.setXAMode();
            Transaction.begin();
            try {
                new EP_F10310().payConfirm(F180Map, reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPF1_0310_MSG_013"); // �뵲�дڽT�{����

            try {
                query(qryMap);
            } catch (DataNotFoundException dnfe) {
                log.error("�뵲�дڽT�{�����A���d�d�L���", dnfe);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPF1_0310_MSG_014"); // �뵲�дڽT�{�����A���d�d�L���
            } catch (Exception e) {
                log.error("�뵲�дڽT�{�����A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EPF1_0310_MSG_015"); // �뵲�дڽT�{�����A���d����
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0310_ERRMSG_010"); // �뵲�дڽT�{����
            }
        } catch (Exception e) {
            log.error("�����뵲�дڥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0310_ERRMSG_010"); // �뵲�дڽT�{����
        }
        return resp;
    }

    /**
     * �ץX
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {

        try {
            Map reqMap = new HashMap();
            reqMap.put("CMM_APLY_NO", req.getParameter("CMM_APLY_NO"));
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));

            String[] fileInfo = new EP_F10310().export(reqMap, user);
            RptUtils.cryptoDownloadParameterToResp(fileInfo[0], fileInfo[1], resp);

            MessageUtil.setMsg(msg, "EPF1_0310_MSG_011"); // �ץX����
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0310_ERRMSG_011"); // �ץX����
                }
            }
        } catch (Exception e) {
            log.error("�ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0310_ERRMSG_011"); // �ץX����
        }

        return resp;
    }

    /**
     * �C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {
            Map reqMap = new HashMap();
            reqMap.put("CMM_APLY_NO", req.getParameter("CMM_APLY_NO"));
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));

            Map fileInfo = new EP_F10310().print(reqMap, user);

            JasperReportUtils
                    .addOutputRptDataToResp("EP_F10300_3", (Map) fileInfo.get("paramMap"), (List) fileInfo.get("printList3"), resp);

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPF1_0101_ERRMSG_006"));//�C�L���\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPF1_0101_ERRMSG_007"));//�C�L����
                }
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPF1_0101_ERRMSG_007"));//�C�L����
        }

        return resp;
    }
}
