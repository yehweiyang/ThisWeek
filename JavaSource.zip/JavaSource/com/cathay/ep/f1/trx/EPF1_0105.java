package com.cathay.ep.f1.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.f1.module.EPF1_0105_mod;
import com.cathay.ep.vo.DTEPF150;
import com.cathay.ep.vo.DTEPF151;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F150;
import com.cathay.ep.z0.module.EP_Z0F151;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2014/8/26   1.0 Created ����i
 * 
 * UCEPF1_0105_�M���
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �M���
 * �{���W��    EPF1_0105
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 * (2) �i�϶�B�j�s�W �w ���ѨϥΪ̷s�W�M�����ơC
 * (3) �i�϶�B�j�ק� �w ���ѨϥΪ̭ק�M�����ơC
 * (4) �i�϶�B�j�R�� �w ���ѨϥΪ̧R���M�����ơC
 * (5) �i�϶�C�j�s�W�@�C �w ���ѨϥΪ̷s�W�@���ťզC�C
 * (6) �i�϶�C�j�R�����C �w ���ѨϥΪ̧R�����C��ơC
 * ���s���v    �M��FUNC_ID = EPF10105
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 * �h���d��     v�L         ������          �u����
 * </pre>
 * @author ����[
 * @since 2014/11/13
 */
@SuppressWarnings("unchecked")
public class EPF1_0105 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPF1_0105.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    private String[] totCol = { "TOTAL_PAY_AMT", "YEAR_PAY_AMT", "TAX_PAY_AMT", "CLOSE_PAY_AMT" };

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        VOTool.setParamsFromLP_JSON(req);

        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����");
        }
        resp.addOutputData("APLY_NO", req.getParameter("APLY_NO")); //�ץ�s��

        resp.addOutputData("USER_ID", user.getEmpID());

        try {
            resp.addOutputData("CLOSE_TP_LIST", FieldOptionList.getName("EP", "CLOSE_TP_F105"));
        } catch (Exception e) {
            log.error("���o�M������M�楢��");
        }
        try {
            resp.addOutputData("SUB_ITEM_NM", FieldOptionList.getName("EP", "SUB_ITEM_NO_F105"));
        } catch (Exception e) {
            log.error("���o�M�ⶵ�زM�楢��");
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            //(�w�] �b��CLOSE_TP=1)
            this.query(req.getParameter("APLY_NO"), req.getParameter("SUB_CPY_ID"), req.getParameter("CLOSE_TP"), new EP_Z0F150());

            MessageUtil.setMsg(msg, "EPF1_0105_MSG_001");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPF1_0105_MSG_002");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0105_MSG_003");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0105_MSG_004");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0105_MSG_004");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {

            Map DTEPF110 = VOTool.jsonToMap(req.getParameter("DTEPF110"));
            String APLY_NO = MapUtils.getString(DTEPF110, "APLY_NO");
            String CLOSE_TP = MapUtils.getString(DTEPF110, "CLOSE_TP");
            String SUB_CPY_ID = MapUtils.getString(DTEPF110, "SUB_CPY_ID");

            List<DTEPF150> rtnF150List = VOTool.jsonAryToVOs(DTEPF150.class, req.getParameter("rtnF150List"));
            List<DTEPF151> rtnF151List = VOTool.jsonAryToVOs(DTEPF151.class, req.getParameter("rtnF151List"));

            //�ˮ֭�µ�ץ�B�Ƨѿ��i�׬O�_�i���ʡA���i�h��X���~
            new EPF1_0105_mod().chkChangeable(APLY_NO, user, SUB_CPY_ID);

            EP_Z0F150 theEP_Z0F150 = new EP_Z0F150();

            Transaction.begin();
            try {

                //�s�W��µ�ץ�_�M����
                theEP_Z0F150.insert(APLY_NO, CLOSE_TP, MapUtils.getString(DTEPF110, "BLD_NM"), MapUtils.getString(DTEPF110, "BLD_ADDR"),
                    rtnF150List, rtnF151List, user, null);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPF1_0105_MSG_005");//�s�W����

            try {
                this.query(APLY_NO, SUB_CPY_ID, CLOSE_TP, theEP_Z0F150);
            } catch (Exception e) {
                log.error("�s�W����,���d����");
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0105_MSG_006");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0105_MSG_006");//�s�W����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {

            Map DTEPF110 = VOTool.jsonToMap(req.getParameter("DTEPF110"));
            String APLY_NO = MapUtils.getString(DTEPF110, "APLY_NO");
            String CLOSE_TP = MapUtils.getString(DTEPF110, "CLOSE_TP");
            String SUB_CPY_ID = MapUtils.getString(DTEPF110, "SUB_CPY_ID");

            List<DTEPF150> rtnF150List = VOTool.jsonAryToVOs(DTEPF150.class, req.getParameter("rtnF150List"));
            List<DTEPF151> rtnF151List = VOTool.jsonAryToVOs(DTEPF151.class, req.getParameter("rtnF151List"));

            //�ˮ֭�µ�ץ�B�Ƨѿ��i�׬O�_�i���ʡA���i�h��X���~
            new EPF1_0105_mod().chkChangeable(APLY_NO, user, SUB_CPY_ID);

            EP_Z0F150 theEP_Z0F150 = new EP_Z0F150();

            Transaction.begin();
            try {

                //�ק��µ�ץ�_�M����
                theEP_Z0F150.update(APLY_NO, CLOSE_TP, MapUtils.getString(DTEPF110, "BLD_NM"), MapUtils.getString(DTEPF110, "BLD_ADDR"),
                    rtnF150List, rtnF151List, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPF1_0105_MSG_007");//�ק粒��

            try {
                this.query(APLY_NO, SUB_CPY_ID, CLOSE_TP, theEP_Z0F150);
            } catch (Exception e) {
                log.error("�ק粒��,���d����");
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0105_MSG_013");//�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0105_MSG_013");//�ק異��
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {

            String APLY_NO = req.getParameter("APLY_NO");
            String CLOSE_TP = req.getParameter("CLOSE_TP");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");

            //�ˮ֭�µ�ץ�B�Ƨѿ��i�׬O�_�i���ʡA���i�h��X���~
            new EPF1_0105_mod().chkChangeable(APLY_NO, user, SUB_CPY_ID);

            EP_Z0F150 theEP_Z0F150 = new EP_Z0F150();

            Transaction.begin();
            try {

                //�R����µ�ץ�_�M����
                theEP_Z0F150.delete(APLY_NO, CLOSE_TP, user, SUB_CPY_ID);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPF1_0105_MSG_008");//�R������

            try {
                this.query(APLY_NO, SUB_CPY_ID, CLOSE_TP, theEP_Z0F150);
            } catch (Exception e) {
                log.error("�R������,���d����");
            }
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0105_MSG_014");//�R������
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0105_MSG_014");//�R������
        }

        return resp;
    }

    /**
     * �p��X�p
     * @param req
     * @return
     */
    public ResponseContext doCount(RequestContext req) {
        try {
            Map rowData = VOTool.jsonToMap(req.getParameter("rowData"));
            int index = MapUtils.getIntValue(rowData, "ITEM_NO");
            List<Map> colData = VOTool.jsonAryToMaps(req.getParameter("colData"));
            String colName = req.getParameter("colName");

            if ("ALL".equals(colName)) {

                Map totMap = new HashMap();
                for (Map col : colData) {
                    for (String key : totCol) {
                        totMap.put(key, STRING.objToBigDecimal(totMap.get(key), BigDecimal.ZERO).add(
                            STRING.objToBigDecimal(col.get(key), BigDecimal.ZERO)));
                    }
                }

                resp.addOutputData("totMap", totMap);

            } else if ("CLOSE_PAY_AMT".equals(colName)) {

                resp.addOutputData("rowData", rowData);

                //��:tot >> col , CLOSE_PAY_AMT
                BigDecimal colTot = BigDecimal.ZERO;
                for (Map col : colData) {
                    colTot = colTot.add(STRING.objToBigDecimal(col.get("CLOSE_PAY_AMT"), BigDecimal.ZERO));
                }
                resp.addOutputData("colTot", colTot);
                resp.addOutputData("CLOSE_PAY_AMT_TOT", colTot);

            } else {
                //��:tot
                BigDecimal rolTot = BigDecimal.ZERO;
                for (String key : totCol) {
                    if ("CLOSE_PAY_AMT".equals(key)) {
                        rowData.put("CLOSE_PAY_AMT", rolTot);
                    } else {
                        rolTot = rolTot.add(STRING.objToBigDecimal(rowData.get(key), BigDecimal.ZERO));
                    }
                }
                resp.addOutputData("rowData", rowData);

                //��:tot >> col , CLOSE_PAY_AMT
                BigDecimal colTot = BigDecimal.ZERO;
                BigDecimal CLOSE_PAY_AMT_TOT = BigDecimal.ZERO;
                for (int i = 0; i < colData.size(); i++) {
                    Map col = colData.get(i);
                    if (i == (index - 1)) {
                        CLOSE_PAY_AMT_TOT = CLOSE_PAY_AMT_TOT.add(rolTot);
                    } else {
                        CLOSE_PAY_AMT_TOT = CLOSE_PAY_AMT_TOT.add(STRING.objToBigDecimal(col.get("CLOSE_PAY_AMT"), BigDecimal.ZERO));
                    }
                    colTot = colTot.add(STRING.objToBigDecimal(col.get(colName), BigDecimal.ZERO));
                }
                resp.addOutputData("colTot", colTot);
                resp.addOutputData("CLOSE_PAY_AMT_TOT", CLOSE_PAY_AMT_TOT);

            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0105_MSG_011");//�p��X�p����
            }
        } catch (Exception e) {
            log.error("�p��X�p����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0105_MSG_011");//�p��X�p����
        }

        return resp;
    }

    /**
     * �p��X�p
     * @param req
     * @return
     */
    public ResponseContext doCount2(RequestContext req) {
        try {

            List<Map> records = VOTool.jsonAryToMaps(req.getParameter("records"));

            Map tempMap = new HashMap();
            String first_char = null;
            BigDecimal SUB_TOT = BigDecimal.ZERO;
            BigDecimal ALL_TOT = BigDecimal.ZERO;
            for (Map rec : records) {
                String SUB_ITEM_NO = MapUtils.getString(rec, "SUB_ITEM_NO");

                if ("0".equals(SUB_ITEM_NO.substring(1, 2))) { //�j��
                    //�B�z�W�@�յ���
                    tempMap.put("ITEM_TOTAL", SUB_TOT);
                    ALL_TOT = ALL_TOT.add(SUB_TOT);
                    SUB_TOT = BigDecimal.ZERO;

                    first_char = SUB_ITEM_NO.substring(0, 1);
                    tempMap = rec;
                } else if (first_char.equals(SUB_ITEM_NO.substring(0, 1))) {
                    SUB_TOT = SUB_TOT.add(STRING.objToBigDecimal(rec.get("SUB_ITEM"), BigDecimal.ZERO));
                }
            }
            //�̫�@���B�z
            tempMap.put("ITEM_TOTAL", SUB_TOT);
            ALL_TOT = ALL_TOT.add(SUB_TOT);

            resp.addOutputData("records", records);
            resp.addOutputData("ALL_TOT", ALL_TOT);

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0105_MSG_011"); //�p��X�p����         
            }
        } catch (Exception e) {
            log.error("�p��X�p����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0105_MSG_011");//�p��X�p����
        }

        return resp;
    }

    /**
     * ��@�d��
     * @param APLY_NO
     * @param SUB_CPY_ID
     * @param CLOSE_TP
     * @param theEP_Z0F150
     * @throws Exception
     */
    private void query(String APLY_NO, String SUB_CPY_ID, String CLOSE_TP, EP_Z0F150 theEP_Z0F150) throws Exception {

        if (StringUtils.isBlank(APLY_NO)) {
            throw new ErrorInputException("EPF1_0105_MSG_012");//�Х��^�W���i��d�ߧ@�~ 
        }

        //�a�X�ץ�M������(�w�] �b��CLOSE_TP=1)
        Map rtnF110Map;
        try {
            rtnF110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
            //�YrtnF110Map�d�L��ƫh��ܿ��~�T��:���d�L���ץ�s����T��
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException("EPF1_0105_MSG_009");//�d�L���ץ�s����T 
        }

        DTEPF150 F150 = new DTEPF150();
        F150.setAPLY_NO(APLY_NO);
        F150.setSUB_CPY_ID(SUB_CPY_ID);
        F150.setCLOSE_TP(CLOSE_TP);
        List<Map> rtnF150List = null;
        try {
            rtnF150List = theEP_Z0F150.queryF150List(F150);
            Map totMap = new HashMap();
            for (Map rtnF150 : rtnF150List) {
                for (String key : totCol) {
                    totMap.put(key, STRING.objToBigDecimal(totMap.get(key), BigDecimal.ZERO).add(
                        STRING.objToBigDecimal(rtnF150.get(key), BigDecimal.ZERO)));
                }
            }

            //�X�p
            Map totalMap = new HashMap();
            totalMap.put("text", MessageUtil.getMessage("EPF1_0105_MSG_015"));//"�X�p"
            totalMap.put("value", totMap);

            List<Map> totalList = new ArrayList<Map>();
            totalList.add(totalMap);

            resp.addOutputData("totalList", totalList);
            resp.addOutputData("rtnF150List", rtnF150List);
        } catch (DataNotFoundException dnfe) {
            //�YrtnF150List�d�L��ƫh��ܿ��~�T��:���d�L���ץ�s���M�����T��
            log.error("F150�d�L���");
        }

        DTEPF151 F151 = new DTEPF151();
        F151.setAPLY_NO(APLY_NO);
        F151.setSUB_CPY_ID(SUB_CPY_ID);
        F151.setCLOSE_TP(CLOSE_TP);
        List<Map> rtnF151List = null;
        try {
            rtnF151List = new EP_Z0F151().queryF151List(F151);

            BigDecimal CLOSE_AMT = BigDecimal.ZERO;
            for (Map rtnF151 : rtnF151List) {
                CLOSE_AMT = CLOSE_AMT.add(STRING.objToBigDecimal(rtnF151.get("ITEM_TOTAL"), BigDecimal.ZERO));
            }
            rtnF110Map.put("CLOSE_AMT", CLOSE_AMT);

            resp.addOutputData("rtnF151List", rtnF151List);
            //�YrtnF151List�d�L��ƫh��ܿ��~�T��:���d�L���ץ�s���M�����T��
        } catch (DataNotFoundException dnfe) {
            log.error("F151�d�L���");
        }

        resp.addOutputData("rtnF110Map", rtnF110Map);

        if ((rtnF150List == null || rtnF150List.isEmpty()) && (rtnF151List == null || rtnF151List.isEmpty())) {
            throw new ModuleException("EPF1_0105_MSG_010");//�d�L���ץ�s���M�����T
        }

    }
}
