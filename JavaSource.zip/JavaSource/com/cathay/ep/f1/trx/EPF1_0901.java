package com.cathay.ep.f1.trx;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.ep.f1.module.EP_F10901;
import com.cathay.ep.z0.module.EP_Z0F160;
import com.cathay.ep.z0.module.EP_Z0F190;
import com.cathay.ep.z0.module.EP_Z0F191;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.common.util.annotation.CallMethod;
import com.igsapp.common.util.annotation.TxBean;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * ���ʤ��     ����    ���ʻ���     ���ʤH��
   2019/5/21    1.0     Created     �L�ç�

    �{���\��    �]�Ƽi������
    �{���W��    EPF1_0901
    �@�~�覡    ONLINE
    ���n����    
    (1) ��l
    (2) �s�W �w ���ѨϥΪ̷s�W�j�ӳ]�Ʃ��Ӹ��
    (3) �T�{ �w ���ѨϥΪ̭ק�j�ӳ]�Ʃ��Ӹ��
    (4) �R�� �w ���ѨϥΪ̧R���j�ӳ]�Ʃ��Ӹ��
    ���s���v    ���M��
    �h��y�t    �M��
 * </pre>
 * @author ������
 * @since 2019/5/27
 */

@TxBean
@SuppressWarnings( { "unchecked" })
public class EPF1_0901 extends UCBean {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPF1_0901.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode(CallMethod.CODE_SUCCESS);
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    @CallMethod(action = "prompt", url = "/EP/F1/EPF1_0900/EPF10901.jsp")
    public ResponseContext doPrompt(RequestContext req) {

        VOTool.setParamsFromLP_JSON(req);

        //��l���Ȩæ^��
        String APLY_NO = req.getParameter("APLY_NO"); //�ץ�s��
        String SUB_CPY_ID = req.getParameter("SUB_CPY_ID"); //�����q�O
        String EQP_ID = req.getParameter("EQP_ID");
        resp.addOutputData("APLY_NO", APLY_NO);//�ץ�s��     
        resp.addOutputData("EQP_ID", EQP_ID);//�]�ƽs��             
        resp.addOutputData("BLD_CD", req.getParameter("BLD_CD"));//�j�ӥN��
        resp.addOutputData("BLD_NM", req.getParameter("BLD_NM"));//�j�ӦW��   
        resp.addOutputData("FIX_MO", req.getParameter("FIX_MO"));//��µ���e
        resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O

        try {
            EP_F10901 theEP_F10901 = new EP_F10901();
            List<Map> rtnList = null;
            if (StringUtils.isNotBlank(APLY_NO)) {
                rtnList = theEP_F10901.queryDTEPF191byAplyNo(APLY_NO, SUB_CPY_ID);
            } else {
                rtnList = theEP_F10901.query(EQP_ID, SUB_CPY_ID);
            }
            resp.addOutputData("rtnList", VOTool.toJSON(rtnList));
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        //���o�]�ƺ����M��
        try {
            Map EQP_CD_MAP = FieldOptionList.getName("EP", "EQP_CD");
            resp.addOutputData("EQP_CD_MAP", EQP_CD_MAP);
        } catch (Exception e) {
            log.error("���o�]�ƺ����U�Կ���l�ƥ���", e);
            MessageUtil.setErrorMsg(msg, "EP_UI_MSG_EPF10901_001");//���o�]�ƺ����U�Կ���l�ƥ���
        }

        return resp;
    }

    /**
     * �s�W�᭫�d
     * @param req
     * @return
     */
    @CallMethod(action = "insert", type = CallMethod.TYPE_AJAX)
    public ResponseContext doInsert(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            EP_F10901 theEP_F10901 = new EP_F10901();
            Transaction.begin();
            try {
                theEP_F10901.insert(reqMap, true);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "MEP00004");//�s�W����

            try {
                resp.addOutputData("rtnList", theEP_F10901.queryDTEPF191byAplyNo(APLY_NO, SUB_CPY_ID));
            } catch (Exception e) {
                log.error("�s�W���\�A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EP_UI_MSG_EPF10901_002");//�s�W���\�A���d����
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00005");//�s�W����
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     */
    @CallMethod(action = "confirm", type = CallMethod.TYPE_AJAX)
    public ResponseContext doConfirm(RequestContext req) {
        try {
            List<Map> rtnList = VOTool.jsonAryToMaps(req.getParameter("rtnList"));
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            EP_F10901 theEP_F10901 = new EP_F10901();
            Transaction.begin();
            try {
                new EP_Z0F191().delete(APLY_NO, SUB_CPY_ID, false);

                BigDecimal TOTAL_AMT = BigDecimal.ZERO; //�����`���B
                for (int i = 0; i < rtnList.size(); i++) {
                    Map rtnMap = rtnList.get(i);
                    TOTAL_AMT = TOTAL_AMT.add(STRING.objToBigDecimal(rtnMap.get("FIX_AMT"), BigDecimal.ZERO));
                    rtnMap.put("SER_NO", i + 1);
                    theEP_F10901.insert(rtnMap, false);
                }

                //���o�дڪ��B
                BigDecimal FIX_AMT = BigDecimal.ZERO;
                try {
                    List<Map> F160List = new EP_Z0F160().qryChkList(APLY_NO, SUB_CPY_ID);
                    for (Map F160Map : F160List) {
                        String TAX_TP = MapUtils.getString(F160Map, "TAX_TP");
                        if ("2".equals(TAX_TP)) {
                            //�|�O�A 2:�~�[ (���|)
                            FIX_AMT = FIX_AMT.add(STRING.objToBigDecimal(F160Map.get("PAY_AMT"), BigDecimal.ZERO).add(
                                STRING.objToBigDecimal(F160Map.get("TAX_AMT"), BigDecimal.ZERO)));
                        } else if ("1".equals(TAX_TP)) {
                            //�|�O�A1:���t (�t�|)
                            FIX_AMT = FIX_AMT.add(STRING.objToBigDecimal(F160Map.get("PAY_AMT"), BigDecimal.ZERO));
                        }
                    }

                    if (TOTAL_AMT.compareTo(FIX_AMT) != 0) {
                        //�Y�����`���B������дڪ��B,��X���~�T��: �������`���B�G + TOTAL_AMT + �P�дڪ��B�G + FIX_AMT + ���šA�L�k�T�{!��
                        StringBuilder sb = new StringBuilder();
                        sb.append(MessageUtil.getMessage("EP_UI_MSG_EPF10901_007")).append(TOTAL_AMT).append(
                            MessageUtil.getMessage("EP_UI_MSG_EPF10901_008")).append(FIX_AMT).append(
                            MessageUtil.getMessage("EP_UI_MSG_EPF10901_009"));
                        String msg = sb.toString();
                        sb.setLength(0);
                        throw new ModuleException(msg);
                    }
                } catch (DataNotFoundException dnfe) {
                    //�d�L��Ƶ������`
                }

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EP_UI_MSG_EPF10901_003");//�T�{����

            try {
                resp.addOutputData("rtnList", theEP_F10901.queryDTEPF191byAplyNo(APLY_NO, SUB_CPY_ID));
            } catch (DataNotFoundException e) {
                log.error("�T�{�����A���d�d�L���", e);
            } catch (Exception e) {
                log.error("�T�{�����A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EP_UI_MSG_EPF10901_004");//�T�{�����A���d����
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EP_UI_MSG_EPF10901_005");//�T�{����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EP_UI_MSG_EPF10901_005");//�T�{����
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    @CallMethod(action = "delete", type = CallMethod.TYPE_AJAX)
    public ResponseContext doDelete(RequestContext req) {
        try {
            List<Map> rtnList = VOTool.jsonAryToMaps(req.getParameter("rtnList"));
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            EP_F10901 theEP_F10901 = new EP_F10901();
            Transaction.begin();
            try {
                new EP_Z0F191().delete(APLY_NO, SUB_CPY_ID, false);

                for (int i = 0; i < rtnList.size(); i++) {
                    Map rtnMap = rtnList.get(i);
                    rtnMap.put("SER_NO", i + 1);
                    theEP_F10901.insert(rtnMap, false);
                }

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "MEP00010");//�R������

            try {
                resp.addOutputData("rtnList", theEP_F10901.queryDTEPF191byAplyNo(APLY_NO, SUB_CPY_ID));
            } catch (DataNotFoundException e) {
                log.error("�R�������A���d�d�L���", e);
            } catch (Exception e) {
                log.error("�R�������A���d����", e);
                MessageUtil.setReturnMessage(msg, ReturnCode.OK, "EP_UI_MSG_EPF10901_006");//�R�������A���d����
            }

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00011");//�R������
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00011");//�R������
        }

        return resp;
    }

    /**
     * �]�ƺ���(�j��) �s�� �]�ƺ���(����)
     * @param req
     * @return
     */
    @CallMethod(action = "changeEQP_CD", type = CallMethod.TYPE_AJAX)
    public ResponseContext doChangeEQP_CD(RequestContext req) {
        try {
            String EQP_CD = req.getParameter("EQP_CD");
            if ("1".equals(EQP_CD)) { //����]��
                resp.addOutputData("SUB_EQP_CD_LIST", FieldOptionList.getName("EP", "SUB_EQP_CD_F901"));
            } else if ("2".equals(EQP_CD)) { //�q��
                resp.addOutputData("SUB_EQP_CD_LIST", FieldOptionList.getName("EP", "SUB_EQP_CD_F902"));
            } else if ("3".equals(EQP_CD)) { //�Ž�
                resp.addOutputData("SUB_EQP_CD_LIST", FieldOptionList.getName("EP", "SUB_EQP_CD_F903"));
            } else if ("4".equals(EQP_CD)) { //���Ƥ��νå�
                resp.addOutputData("SUB_EQP_CD_LIST", FieldOptionList.getName("EP", "SUB_EQP_CD_F904"));
            } else if ("5".equals(EQP_CD)) { //�����Τ����z�q
                resp.addOutputData("SUB_EQP_CD_LIST", FieldOptionList.getName("EP", "SUB_EQP_CD_F905"));
            } else {
                resp.addOutputData("SUB_EQP_CD_LIST", Collections.EMPTY_MAP);
            }
        } catch (Exception e) {
            log.error("�]�ƺ����s�ʬd�ߥ���", e);
        }
        return resp;
    }

    /**
     * �]�ƺ���(����) �s�� �]�ƧǸ�
     * @param req
     * @return
     */
    @CallMethod(action = "changeSUB_EQP_CD", type = CallMethod.TYPE_AJAX)
    public ResponseContext dochangeSUB_EQP_CD(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            resp.addOutputData("EQP_NO_LIST", new EP_Z0F190().queryEqpNo(reqMap));
        } catch (Exception e) {
            log.error("�]�ƺ����s�ʬd�ߥ���", e);
        }
        return resp;
    }
}