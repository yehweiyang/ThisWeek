package com.cathay.ep.f1.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.hr.DivData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.CustomerBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.STRING;
import com.cathay.dj.a0.module.DTDJA004_mod;
import com.cathay.ep.f1.module.EPF1_0102_mod;
import com.cathay.ep.f1.module.EPF1_0103_mod;
import com.cathay.ep.f1.module.EP_F10300;
import com.cathay.ep.vo.DTEPF120;
import com.cathay.ep.vo.DTEPF130;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F120;
import com.cathay.ep.z0.module.EP_Z0F130;
import com.cathay.ep.z0.module.EP_Z0F160;
import com.cathay.rz.n0.module.RZ_N0Z001;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date Version Description Author
 * 2014/9/1    1.0 Created ����i
 * 
 * UCEPF1_0103_�u�{����
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �u�{����
 * �{���W��    EPF1_0103
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 * (2) �i�϶�B�j�s�W �w ���ѨϥΪ̷s�W�u�{������ơC
 * (3) �i�϶�B�j�ק� �w ���ѨϥΪ̭ק�u�{������ơC
 * (4) �i�϶�B�j�R�� �w ���ѨϥΪ̧R���u�{������ơC
 * XAMode   �_         v�O
 * ���s���v    �M��FUNC_ID = EPF10103
 * �h��y�t    �M��
 * �����q���
 * �榡���js  �M��
 * �h���d��     �L         ������         v�u����
 * </pre>
 * @author ����[
 * @since 2014/11/21
 */
@SuppressWarnings("unchecked")
public class EPF1_0103 extends CustomerBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPF1_0103.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     * @throws Exception 
     */
    public ResponseContext doPrompt(RequestContext req) throws Exception {

        VOTool.setParamsFromLP_JSON(req);

        resp.addOutputData("USER_ID", user.getEmpID());

        String APLY_NO = req.getParameter("APLY_NO");
        resp.addOutputData("APLY_NO", APLY_NO); //�ץ�s��

        if (StringUtils.isBlank(APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_001"));//�Х��^�W���i��d�ߧ@�~ 
        }
        String SUB_CPY_ID = null;
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����");
        }

        try {
            Map rtnF110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
            resp.addOutputData("rtnF110Map", VOTool.toJSON(rtnF110Map));
            //�YrtnF110Map�d�L��ƫh��ܿ��~�T��:���d�L���ץ�s����T

            //151104 modified 
            String APLY_TP = MapUtils.getString(rtnF110Map, "APLY_TP");
            //���oDISABLE ITME �M��A�N�s����� DISABELD
            resp.addOutputData("DISABLE_ITME", FieldOptionList.getName("EP", "F0103_DISABLE_ITEM", "F120_" + APLY_TP));

        } catch (DataNotFoundException e) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0103_MEG_002"), e);//�d�L���ץ�s����T
        }

        //���o�u�{�k�ݲM��
        resp.addOutputData("PRO_OWN_LIST", FieldOptionList.getName("EP", "PRO_OWN"));

        //���o�X����M��
        resp.addOutputData("IS_CONT_LIST", FieldOptionList.getName("EP", "IS_CONT"));

        //���o�O�κ����M��
        resp.addOutputData("EXP_TP_LIST", FieldOptionList.getName("EP", "EXP_TP_F101"));

        //���o��µ��H���i�ק蠟���A
        resp.addOutputData("can_upd_OP_STATUS", FieldOptionList.getName("EP", "UPD_OP_STATUS", "F110"));

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            //boolean isFirstQuery = "Y".equals(req.getParameter("isFirstQuery"));//�O�_�������d��(�u�����\��T�w�Ѽ�)

            query(req);

            /*if (isFirstQuery) {
                //�����T��            
                MessageUtil.setMsg(msg, "EPF1_0103_MEG_003");//�d�ߧ���
            }*/
            MessageUtil.setMsg(msg, "EPF1_0103_MEG_003");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "EPF1_0103_MEG_004");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0103_MEG_005");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0103_MEG_006");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0103_MEG_006");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            String APLY_NO = req.getParameter("APLY_NO");
            Integer MEMO_NO = Integer.valueOf(req.getParameter("MEMO_NO"));

            //�ˮ֭�µ�ץ�B�Ƨѿ��i�׬O�_�i���ʡA���i�h��X���~
            new EPF1_0103_mod().chkChangeable(APLY_NO, user, MEMO_NO, "1", req.getParameter("SUB_CPY_ID"));

            DTEPF130 F130 = VOTool.jsonToVO(DTEPF130.class, req.getParameter("DTEPF130"));

            //�D�X�����ˮּt�Ӥw�дڤ��i�A�l�[�˶���
            if ("2".equals(F130.getIS_CONT())) {
                if (new EP_Z0F160().queryCount(F130.getAPLY_NO(), null, null, F130.getSUP_ID(), F130.getSUB_CPY_ID()) > 0) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_022"));//���t�Ӥw�дڤ��i�A�l�[���
                }
            }

            Transaction.begin();
            try {
                //�s�W��µ�ץ�_�u�{�������
                resp.addOutputData("PRO_NO", new EP_Z0F130().insert(F130, user));

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPF1_0103_MEG_008");//�s�W����
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0103_MEG_009");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0103_MEG_009");//�s�W����
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {

            String APLY_NO = req.getParameter("APLY_NO");
            Integer MEMO_NO = Integer.valueOf(req.getParameter("MEMO_NO"));
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            //�ˮ֭�µ�ץ�B�Ƨѿ��i�׬O�_�i���ʡA���i�h��X���~
            new EPF1_0103_mod().chkChangeable(APLY_NO, user, MEMO_NO, "1", SUB_CPY_ID);

            DTEPF130 F130 = VOTool.jsonToVO(DTEPF130.class, req.getParameter("DTEPF130"));

            //�D�X�����ˮּt�Ӥw�дڤ��i�A�l�[�˶���
            if ("2".equals(F130.getIS_CONT())) {
                if (new EP_Z0F160().queryCount(F130.getAPLY_NO(), null, null, F130.getSUP_ID(), F130.getSUB_CPY_ID()) > 0) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_022"));//���t�Ӥw�дڤ��i�A�l�[���
                }
            }

            Transaction.begin();
            try {
                //�R����µ�ץ�_�u�{�������
                new EP_Z0F130().delete(F130, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPF1_0103_MEG_010");//�R������
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0103_MEG_011");//�R������
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0103_MEG_011");//�R������
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {

            String APLY_NO = req.getParameter("APLY_NO");
            Integer MEMO_NO = Integer.valueOf(req.getParameter("MEMO_NO"));
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            EPF1_0103_mod theEPF1_0103_mod = new EPF1_0103_mod();
            //�ˮ֭�µ�ץ�B�Ƨѿ��i�׬O�_�i���ʡA���i�h��X���~
            Map mapF110 = theEPF1_0103_mod.chkChangeable(APLY_NO, user, MEMO_NO, "2", SUB_CPY_ID);

            DTEPF130 F130 = VOTool.jsonToVO(DTEPF130.class, req.getParameter("DTEPF130"));

            //�D�X�����ˮּt�Ӥw�дڤ��i�A�l�[�˶���
            if (!MapUtils.getBoolean(mapF110, "isFIX_DIV_UPD_OP_STATUS") && "2".equals(F130.getIS_CONT())) {
                if (new EP_Z0F160().queryCount(F130.getAPLY_NO(), null, null, F130.getSUP_ID(), F130.getSUB_CPY_ID()) > 0) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_022"));//���t�Ӥw�дڤ��i�A�l�[���
                }
            }

            //�ˮּt��:�ۦP�t�Ӥu�اǸ��n�@�P //modified:151124
            if (StringUtils.isNotBlank(F130.getSUP_ID())) {
                theEPF1_0103_mod.chkSUP_ID(F130);
            }

            //�D��µ�ץ�t�d�H���i����!!
            DTEPF120 F120Vo = new DTEPF120();
            F120Vo.setAPLY_NO(APLY_NO);
            F120Vo.setSUB_CPY_ID(new EP_Z00030().getSUB_CPY_ID(user));
            F120Vo.setMEMO_NO(F130.getMEMO_NO());
            List<Map> DBF120VoList = new EP_Z0F120().queryF120List(F120Vo);
            Map F120Map = DBF120VoList.get(0);
            String OP_STATUE = MapUtils.getString(F120Map, "OP_STATUE");
            boolean updateConsDate = false;
            if (EP_Z0F120.ST_480.equals(OP_STATUE)) {
                updateConsDate = true;
            }

            //�ˮ֬I�u���
            if (F130.getCONS_SDATE() != null || F130.getCONS_EDATE() != null) {
                String CHK_DATE = "2".equals(MapUtils.getString(F120Map, "APLY_TP")) ? MapUtils.getString(F120Map, "INFM_CONS_DATE")
                        : MapUtils.getString(F120Map, "PRE_CONS_DATE");//�@��:�q���I�u���||����:����I�u�q�����
                new EPF1_0102_mod().chkCONS_DATE(F130.getCONS_SDATE().toString(), F130.getCONS_EDATE().toString(), CHK_DATE);
            }

            String NULLIFY = req.getParameter("NULLIFY");

            Transaction.begin();
            try {

                //�ק��µ�ץ�_�u�{�������
                if (updateConsDate) {
                    new EP_Z0F130().updateConsDate(F130, user);
                } else {
                    new EP_Z0F130().update(F130, user);
                }

                //�Y�e���O�κ����P�ץ󤣦P�ɡA��s��µ�ץ�O�κ��� //151105,modified
                String EXP_TP = req.getParameter("EXP_TP");
                if (StringUtils.isNotBlank(EXP_TP) && !EXP_TP.equals(MapUtils.getString(mapF110, "EXP_TP"))) {
                    new EP_Z0F110().updateExeTp(mapF110, EXP_TP, user);
                }

                if (StringUtils.isNotBlank(NULLIFY)) {//��µ��H���ק�ݿ�J�ק��]
                    String CHG_ID = user.getEmpID();
                    String CHG_DIV_NO = user.getDivNo();
                    if (CHG_DIV_NO.startsWith("EP9")) {
                        CHG_ID = "SYSTEM";
                        CHG_DIV_NO = "";
                    }
                    String COMMENT = "�ק�u�{����(" + user.getEmpName() + ")�A�ק��]:" + NULLIFY;
                    new RZ_N0Z001().assignOPStatus(MapUtils.getString(F120Map, "FLOW_NO"), "�ק�", COMMENT, OP_STATUE, CHG_ID, CHG_DIV_NO);
                }

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPF1_0103_MEG_012");//�ק粒��
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0103_MEG_014");//�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0103_MEG_014");//�ק異��
        }

        return resp;
    }

    /**
     * ���u
     * @param req
     * @return
     */
    public ResponseContext doUpdateFinalDate(RequestContext req) {
        try {

            String APLY_NO = req.getParameter("APLY_NO");
            Integer MEMO_NO = Integer.valueOf(req.getParameter("MEMO_NO"));
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            //3.3.1 //�ˮ֭�µ�ץ�B�Ƨѿ��i�׬O�_�i���ʡA���i�h��X���~
            new EPF1_0103_mod().chkChangeable(APLY_NO, user, MEMO_NO, "3", SUB_CPY_ID);

            DTEPF130 F130 = VOTool.jsonToVO(DTEPF130.class, req.getParameter("DTEPF130"));

            try {

                //��µ�ץ�_�u�{�������u
                new EP_Z0F130().updateFinalDate(F130, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPF1_0103_MEG_012");//�ק粒��
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0103_MEG_014");//�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0103_MEG_014");//�ק異��
        }

        return resp;
    }

    /**
     * �u�t�ӦW�١v��ĳ���
     * @param req
     * @return
     */
    public ResponseContext doSuggest(RequestContext req) {
        try {
            //�u�t�ӫ�ĳ�M��v��ĳ���G

            String TYPE = req.getParameter("TYPE");
            String SUP_NM = req.getParameter("suggestValue");
            List<Map> SUP_NMList = new ArrayList<Map>();
            if (StringUtils.isNotBlank(TYPE)) {
                if (SUP_NM.length() >= 5 && STRING.isMatchPattern(SUP_NM, "^\\w+$")) {
                    String newSuggestValue = STRING.fillCharFromRightExt(SUP_NM, 7, '0');
                    Map map = new HashMap();
                    map.put("SUP_NM", new DivData().getUnit4ShortName(newSuggestValue));
                    map.put("SUP_ID", newSuggestValue);
                    SUP_NMList.add(map);
                }
            } else {
                try {
                    List<Map> rtnList = new DTDJA004_mod().Query_ACPT_NAME(SUP_NM);
                    Map trnMap;
                    //Set<String> SUP_NMSet = new HashSet<String>();
                    MultiKeyMap SUP_NMSet = new MultiKeyMap();
                    for (Map map : rtnList) {
                        String ACPT_NAME = MapUtils.getString(map, "ACPT_NAME", "").trim();
                        String SUP_ID = MapUtils.getString(map, "ID");
                        if (StringUtils.isNotBlank(ACPT_NAME) && !SUP_NMSet.containsKey(ACPT_NAME, SUP_ID)) {
                            trnMap = new HashMap();
                            trnMap.put("SUP_ID", SUP_ID);
                            trnMap.put("SUP_NM", ACPT_NAME);
                            SUP_NMList.add(trnMap);
                            SUP_NMSet.put(ACPT_NAME, SUP_ID, trnMap);
                        }
                    }

                } catch (DataNotFoundException dnfe) {
                    log.error("�̼t�ӦW�٬d�ߥ���", dnfe);
                }
            }
            resp.addOutputData("suggestResult", SUP_NMList);

        } catch (Exception e) {
            log.error("�t�ӷj�M���ܬd�ߥ���", e);
        }
        return resp;
    }

    /**
     * �Ƨѿ�
     * @param req
     * @return
     */
    public ResponseContext doGetF120(RequestContext req) {
        //�Ƨѿ� 
        try {
            String APLY_NO = req.getParameter("APLY_NO");
            String MEMO_NO = req.getParameter("MEMO_NO");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            if (StringUtils.isNotBlank(MEMO_NO)) {
                List<Map> rtnList = new EP_Z0F120().queryF120List(APLY_NO, MEMO_NO, SUB_CPY_ID);
                resp.addOutputData("rtnF120Map", rtnList.get(0));
            } else {
                resp.addOutputData("rtnF120Map", Collections.EMPTY_MAP);
            }
        } catch (DataNotFoundException dnfe) {
            log.debug("�Ƨѿ��d�L���");
        } catch (Exception e) {
            log.error("�Ƨѿ��d�ߥ���", e);
        }

        return resp;
    }

    /**
     * ��@�d��
     * @param isFirstQuery
     * @param req
     * @throws Exception
     */
    private void query(RequestContext req) throws Exception {
        Map param = VOTool.jsonToMap(req.getParameter("params"));//TablUI-Ajax �Ѽ�(�u�����\��T�w�Ѽ�) 

        String APLY_NO = MapUtils.getString(param, "APLY_NO");
        String SUB_CPY_ID = MapUtils.getString(param, "SUB_CPY_ID");

        //String loadStrat = req.getParameter("loadStrat");//�_�l��ƦC(�u�����\��T�w�Ѽ�)
        //String loadEnd = req.getParameter("loadEnd");//������ƦC(�u�����\��T�w�Ѽ�)

        try {

            DTEPF130 F130 = new DTEPF130();
            F130.setAPLY_NO(APLY_NO);
            F130.setSUB_CPY_ID(SUB_CPY_ID);
            ////�u�����^��records((�T�w))
            List<Map> rtnF130List = new EP_Z0F130().queryF130List(F130);
            Map tmpMap = new HashMap();
            tmpMap.put("CLR_AMT", BigDecimal.ZERO);
            tmpMap.put("CONT_AMT", BigDecimal.ZERO);

            String user_id = user.getEmpID();
            StringBuilder sb = new StringBuilder();
            for (Map rtnMap : rtnF130List) {
                tmpMap.put("CLR_AMT", STRING.objToBigDecimal(tmpMap.get("CLR_AMT"), BigDecimal.ZERO).add(
                    STRING.objToBigDecimal(rtnMap.get("CLR_AMT"), BigDecimal.ZERO)));
                tmpMap.put("CONT_AMT", STRING.objToBigDecimal(tmpMap.get("CONT_AMT"), BigDecimal.ZERO).add(
                    STRING.objToBigDecimal(rtnMap.get("CONT_AMT"), BigDecimal.ZERO)));

                //�̳Ƨѿ����A���o EDIT_ITEM�M��A�N�s����� DISABELD
                String APLY_TP = MapUtils.getString(rtnMap, "APLY_TP");
                String F120_OP_STATUS = MapUtils.getString(rtnMap, "F120_OP_STATUS");
                sb.setLength(0);
                if (user_id.equals(MapUtils.getString(rtnMap, "FIX_GROUP_ID"))) { //��µ��
                    sb.append("F120G_");
                } else if (user_id.equals(MapUtils.getString(rtnMap, "FIX_DIV_ID"))) {//��µ��
                    sb.append("F120F_");
                } else if (user_id.equals(MapUtils.getString(rtnMap, "SUBCON_GROUP_ID"))) { //������
                    sb.append("F120S_");
                }
                sb.append(APLY_TP).append("_").append(F120_OP_STATUS);
                rtnMap.put("EDIT_ITEM", FieldOptionList.getName("EP", "F0103_EDIT_ITEM", sb.toString()));

            }

            resp.addOutputData("rtnList", rtnF130List);
            resp.addOutputData("totalMap", tmpMap);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException("EPF1_0103_MEG_007", dnfe);//�d�L���ץ�s���u�{������T
        }

    }

    /**
     * �д�
     * @param req
     * @return
     */
    public ResponseContext doPayment(RequestContext req) {
        try {
            DTEPF130 F130 = VOTool.jsonToVO(DTEPF130.class, req.getParameter("DTEPF130"));
            String F110_OP_STATUS = req.getParameter("F110_OP_STATUS");

            String APLY_NO = F130.getAPLY_NO();
            String MEMO_NO = F130.getMEMO_NO().toString();
            String PRO_NO = F130.getPRO_NO().toString();
            String SUB_CPY_ID = F130.getSUB_CPY_ID();

            //���oF120�Ƨѿ�
            Map F120 = new EP_Z0F120().queryF120List(APLY_NO, MEMO_NO, SUB_CPY_ID).get(0);
            //����ˮ�
            if ("2".equals(F130.getIS_CONT())) {//�D�X����
                //1-1.�D�X����>�D��ޥ�ݤw�����禬(F110_OP_STATUS == 700)
                //1-2.�D�X����>�дڥu�i�@���A�w�д���ܰT�������t�Ӥw�дڡ�
                String IS_BM = MapUtils.getString(F120, "IS_BM");
                if ("2".equals(IS_BM) && "500".compareTo(F110_OP_STATUS) > 0) {//�D��ޥ�
                    throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_023"));//�D��ޥ�ݽT�{���u
                }
                //�ץ�w�g���� �L�k���ͽдڬ���
                if ("800".equals(F110_OP_STATUS)) {//�D��ޥ�
                    throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_024"));//�ץ�w�g���� 
                }
                if (new EP_Z0F160().queryCount(APLY_NO, null, null, F130.getSUP_ID(), SUB_CPY_ID) > 0) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_016"));//���t�Ӥw�д�
                }
            } else {//�X����
                //2-1.�X����>���w�ƬI�u��ܰT�����|���}�l�I�u���i�дڡ��C
                //2-2.�X����>�����u�e�A�дڪ��B�w�F�L�X�����B9���A��ܰT�����дڪ��B���i�W�L�X�����B9�����C
                //2-3.�X����>�w�̫�@���дڡA�S�A�д���ܰT�����дڪ��B�W�L�X�����B���C
                if (F130.getCONS_SDATE() == null) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_017"));//�|���}�l�I�u���i�д�
                }
                if (F130.getFINAL_DATE() == null) {
                    BigDecimal TOT_PAY_AMT = new EP_Z0F160().qryTotalAmt(F130.getCONT_NO(), SUB_CPY_ID);
                    BigDecimal CONT_AMT = F130.getCONT_AMT();
                    if (TOT_PAY_AMT.compareTo(CONT_AMT.multiply(new BigDecimal("0.9"))) > 0) {
                        throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_018"));//�дڪ��B���i�W�L�X�����B9��
                    }
                    if (TOT_PAY_AMT.compareTo(CONT_AMT) == 0) {
                        throw new ErrorInputException(MessageUtil.getMessage("EPF1_0103_MEG_019"));//�дڪ��B�W�L�X�����B
                    }
                }
            }
            Transaction.begin();
            try {
                //�д�
                //List<Map> reqList = new ArrayList<Map>();
                //reqList.add(VOTool.voToMap(F130));
                //�վ�Ҳռt�Ө��o��Ƥ�k
                new EP_F10300().insert(APLY_NO, PRO_NO, SUB_CPY_ID, MapUtils.getString(F120, "EXP_TP"), user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPF1_0103_MEG_020");//�дڤw�e��
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0103_MEG_021");//�дڥ���
            }
        } catch (Exception e) {
            log.error("�дڥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0103_MEG_021");//�дڥ���
        }

        return resp;
    }

}
