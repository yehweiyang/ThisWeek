package com.cathay.ep.f1.trx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.hr.DivData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.CustomerBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.dj.a0.module.DTDJA004_mod;
import com.cathay.ep.f1.module.EPF1_0102_mod;
import com.cathay.ep.f1.module.EP_F10310;
import com.cathay.ep.vo.DTEPF110;
import com.cathay.ep.vo.DTEPF120;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F120;
import com.cathay.ep.z0.module.EP_Z0F170;
import com.cathay.rz.n0.module.RZ_N00100;
import com.cathay.rz.n0.module.RZ_N0Z001;
import com.cathay.rz.vo.DTRZN010;
import com.cathay.rz.vo.DTRZN011;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date Version Description Author
2014/8/4    1.0 Created ����i

UCEPF1_0100_��µ�ӽ�

�@�B  �{���\�෧�n�����G
�{���\��    �߮׸��
�{���W��    EPF1_0101
�@�~�覡    ONLINE
���n����    (1) ��l
(2) �ק� �w ���ѨϥΪ̭ק��µ�ץ��ơC
(3) �W�� - �ɬd�Ӥ��γ�����
(4) �W�� - �禬�Ӥ�
���s���v    �M��FUNC_ID = EPF10101
�h��y�t    �M��
�����q���
�榡���js  �M��
�h���d��    X�L        X������        V�u����                                      

 * @author �Ťl��
 * 
 * @version 2018/01/26 ���~��:�s��µ�t�γB�z�[�J���P��/��H��
 *
 */
@SuppressWarnings("unchecked")
public class EPF1_0101 extends CustomerBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPF1_0101.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);
        StringBuilder sb = new StringBuilder();
        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            sb.append(MessageUtil.getMessage("EPF1_0101_ERRMSG_001"));//���o�����q�O����
            STRING.newLine(sb);
        }

        resp.addOutputData("user_DIVNO", user.getDivNo());
        resp.addOutputData("user_EMPID", user.getEmpID());

        //��µ����N��
        resp.addOutputData("FIX_DIV", FieldOptionList.getName("EP", "DIV_F106", "FIX_DIV"));
        //��µ��H�~���\�@�~�����(�䴩)
        resp.addOutputData("FIX_DIV_SUPPORT", FieldOptionList.getName("EP", "DIV_F106", "FIX_DIV_SUPPORT"));
        
        //�ץ�s��
        String APLY_NO = req.getParameter("APLY_NO");
        if (StringUtils.isBlank(APLY_NO)) {
            sb.append(MessageUtil.getMessage("EPF1_0101_ERRMSG_002"));//�ץ�s�������ǤJ
            STRING.newLine(sb);
        }
        if (sb.length() != 0) {
            MessageUtil.setErrorMsg(msg, sb.toString());
            sb.setLength(0);
        }
        resp.addOutputData("APLY_NO", APLY_NO);
        String msgDesc = req.getParameter("msgDesc");
        resp.addOutputData("msgDesc", msgDesc);
        String returnCode = req.getParameter("returnCode");
        resp.addOutputData("returnCode", returnCode);
        //���o�ץ�����M��
        resp.addOutputData("APLY_TP_LIST", FieldOptionList.getName("EP", "APLY_TP_F101"));
        // ���o�ۥ�/�X���M��
        resp.addOutputData("USE_TP_LIST", FieldOptionList.getName("EP", "USE_TP_F101"));
        //���o�O�κ����M��
        resp.addOutputData("EXP_TP_LIST", FieldOptionList.getName("EP", "EXP_TP_F101"));
        // ���o���O�M��
        resp.addOutputData("CURR_LIST", FieldOptionList.getName("EP", "CURR"));
        // ���o�u�u�{�k�ݡv�M�� 
        resp.addOutputData("PRO_OWN_LIST", FieldOptionList.getName("EP", "PRO_OWN"));

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        String msgDesc = null;
        Integer returnCode = null;
        try {
            //���o�j�Ӱ򥻸��
            String APLY_NO = req.getParameter("APLY_NO");
            msgDesc = req.getParameter("msgDesc");
            String rCode = req.getParameter("returnCode");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            returnCode = (rCode != null && NumberUtils.isNumber(rCode)) ? Integer.valueOf(rCode) : null;
            this.query(APLY_NO, SUB_CPY_ID);
            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");
        }

        if (StringUtils.isNotBlank(msgDesc)) {
            if (ReturnCode.OK == returnCode) {
                MessageUtil.setMsg(msg, msgDesc);
            } else if (ReturnCode.ERROR_INPUT == returnCode) {
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, msgDesc);
            } else if (ReturnCode.DATA_NOT_FOUND == returnCode) {
                MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, msgDesc);
            } else if (ReturnCode.ERROR_MODULE == returnCode) {
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, msgDesc);
            } else if (ReturnCode.ERROR == returnCode) {
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, msgDesc);
            }
        }

        return resp;
    }

    /**
     * ��s
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {

            DTEPF110 DTEPF110VO = VOTool.jsonToVO(DTEPF110.class, req.getParameter("reqMap"));
            DTEPF110VO.setLST_PROC_DATE(DATE.currentTime());
            DTEPF110VO.setLST_PROC_DIV(user.getOpUnit());
            DTEPF110VO.setLST_PROC_ID(user.getEmpID());
            String APLY_NO = DTEPF110VO.getAPLY_NO();
            String SUB_CPY_ID = DTEPF110VO.getSUB_CPY_ID();
            //�j�ӦW�٩Τj�Ӧa�}�L�ȮɡA�d��EP_Z0F170().queryList(reqMap)�N�j�ӦW�٩Τj�Ӧa�}�g�J��Ʈw
            if (StringUtils.isBlank(DTEPF110VO.getBLD_NM()) || StringUtils.isBlank(DTEPF110VO.getBLD_ADDR())) {
                Map reqMap = new HashMap();
                reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
                reqMap.put("BLD_CD", DTEPF110VO.getBLD_CD());
                try {
                    Map BLD_MAP = new EP_Z0F170().queryList(reqMap).get(0);
                    DTEPF110VO.setBLD_ADDR(MapUtils.getString(BLD_MAP, "BLD_ADDR"));
                    DTEPF110VO.setBLD_NM(MapUtils.getString(BLD_MAP, "BLD_NAME"));
                } catch (DataNotFoundException dnfe) {
                    throw new ModuleException("�d�L���j��");
                }
            }

            RZ_N0Z001 aRZ_N0Z001 = new RZ_N0Z001();
            Map DBF110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
            String Map_APLY_TP = MapUtils.getString(DBF110Map, "APLY_TP");
            String Map_OP_STATUS = MapUtils.getString(DBF110Map, "OP_STATUS");
            boolean isChangeAplyTp = !Map_APLY_TP.equals(DTEPF110VO.getAPLY_TP());
            //boolean isChangeAplyTp = (!Map_APLY_TP.equals(DTEPF110VO.getAPLY_TP()) && "400".equals(Map_OP_STATUS));
            Transaction.begin();
            try {
                new EP_Z0F110().updateF110(DTEPF110VO, user, isChangeAplyTp, DBF110Map);

                if (isChangeAplyTp) {
                    //String CHG_ID = user.getEmpID();
                    String CHG_NAME = user.getEmpName();
                    String CHG_DIV_NO = user.getDivNo();
                    if (CHG_DIV_NO.startsWith("EP9")) {
                        //CHG_ID = "SYSTEM";
                        CHG_DIV_NO = "";
                    }
                    //�ק�D�y�{
                    if (EP_Z0F110.ST_1.equals(DTEPF110VO.getAPLY_TP())) {
                        this.assignChangeFlow(DTEPF110VO.getFLOW_NO(), "�ק�", "�קאּ�s�P��µ(" + CHG_NAME + ")", user, "EPF1_0100", Map_OP_STATUS);
                    } else if (EP_Z0F110.ST_2.equals(DTEPF110VO.getAPLY_TP())) {
                        this.assignChangeFlow(DTEPF110VO.getFLOW_NO(), "�ק�", "�קאּ�@���µ(" + CHG_NAME + ")", user, "EPF1_0200", Map_OP_STATUS);
                    } else if (EP_Z0F110.ST_3.equals(DTEPF110VO.getAPLY_TP())) {
                        this.assignChangeFlow(DTEPF110VO.getFLOW_NO(), "�ק�", "�קאּ�����µ(" + CHG_NAME + ")", user, "EPF1_0200", Map_OP_STATUS);
                    }
                    if ("400".equals(Map_OP_STATUS)) {
                        //�ק�Ƨѿ��y�{
                        List<Map> voList = new EP_Z0F120().queryF120List(APLY_NO, SUB_CPY_ID);
                        for (Map map : voList) {
                            String FLOW_NO = MapUtils.getString(map, "FLOW_NO", "");
                            String MEMO_OP_STATUS = MapUtils.getString(map, "OP_STATUS", "");
                            if (EP_Z0F110.ST_2.equals(DTEPF110VO.getAPLY_TP())) {
                                aRZ_N0Z001.assignChangeFlow(FLOW_NO, "�ק�", "�קאּ�@���µ(" + CHG_NAME + ")", user, "EPF1_0240", MEMO_OP_STATUS);
                            } else if (EP_Z0F110.ST_3.equals(DTEPF110VO.getAPLY_TP())) {
                                aRZ_N0Z001.assignChangeFlow(FLOW_NO, "�ק�", "�קאּ�����µ(" + CHG_NAME + ")", user, "EPF1_0340", MEMO_OP_STATUS);
                            }
                        }
                    }
                    //20170414 �Y�h�^�ܥ߮׫ݰe�󪬺A(100)�ܧ�ɦ��w�Ƨѿ����,�h�@�֭ק�Ƨѿ��y�{
                    if ("100".equals(Map_OP_STATUS)) {
                        //�ק�Ƨѿ��y�{
                        List<Map> voList = new EP_Z0F120().queryF120List(APLY_NO, SUB_CPY_ID);
                        for (Map map : voList) {
                            String MEMO_NO = MapUtils.getString(map, "MEMO_NO");
                            //�Y�Ƨѿ��渹������
                            if (StringUtils.isNotBlank(MEMO_NO)) {
                                String FLOW_NO = MapUtils.getString(map, "FLOW_NO", "");
                                //�Ƨѿ��y�{�@�ְh�^�ܫݳƧѿ��e��
                                if (EP_Z0F110.ST_2.equals(DTEPF110VO.getAPLY_TP())) {
                                    aRZ_N0Z001.assignChangeFlow(FLOW_NO, "�ק�", "�קאּ�@���µ(" + CHG_NAME + ")", user, "EPF1_0240", "410");
                                } else if (EP_Z0F110.ST_3.equals(DTEPF110VO.getAPLY_TP())) {
                                    aRZ_N0Z001.assignChangeFlow(FLOW_NO, "�ק�", "�קאּ�����µ(" + CHG_NAME + ")", user, "EPF1_0340", "410");
                                }
                                //��s�Ƨѿ��y�{�i��
                                DTEPF120 F120Vo = new DTEPF120();
                                F120Vo.setAPLY_NO(APLY_NO);
                                F120Vo.setMEMO_NO(NumberUtils.toInt(MEMO_NO));
                                F120Vo.setSUB_CPY_ID(SUB_CPY_ID);
                                F120Vo.setOP_STATUS("410");
                                new EP_Z0F120().update(F120Vo, user);
                            }
                        }
                    }
                }
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPF1_0101_ERRMSG_003");//�ק粒��

            try {
                this.query(APLY_NO, SUB_CPY_ID);
            } catch (Exception e) {
                log.error("�ק粒���A���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPF1_0101_ERRMSG_004");//�ק粒���A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPF1_0101_ERRMSG_005");//�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPF1_0101_ERRMSG_005");//�ק異��
        }

        return resp;
    }

    /**
     * �C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {
            EP_Z0F110 theEP_Z0F110 = new EP_Z0F110();

            Map rtnMap = theEP_Z0F110.queryMap(req.getParameter("APLY_NO"), req.getParameter("SUB_CPY_ID"));

            Map rptMap = theEP_Z0F110.doFmtRpt(rtnMap, user);
            theEP_Z0F110.prtRpt(rptMap, resp);

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPF1_0101_ERRMSG_006"));//�C�L���\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPF1_0101_ERRMSG_007"));//�C�L����
                }
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPF1_0101_ERRMSG_007"));//�C�L����
        }

        return resp;
    }

    /**
     * �j�M����-�j�ӫ�ĳ�M��
     * @param req
     * @return
     */
    public ResponseContext doSuggestBLD_CD(RequestContext req) {
        try {
            //�u�j�ӫ�ĳ�M��v��ĳ���G 
            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_CD", req.getParameter("suggestValue"));
            List<Map> BLD_CDList = new EP_Z0F170().queryList(reqMap);

            resp.addOutputData("suggestResult", BLD_CDList);
        } catch (Exception e) {
            log.error("�j�ӷj�M���ܬd�ߥ���", e);
        }
        return resp;
    }

    /**
     * �j�M����-�t�ӫ�ĳ�M��
     * @param req
     * @return
     */
    public ResponseContext doSuggestSUP_NM(RequestContext req) {
        try {
            //�u�t�ӫ�ĳ�M��v��ĳ���G

            String TYPE = req.getParameter("TYPE");
            String SUP_NM = req.getParameter("suggestValue");
            List<Map> SUP_NMList = new ArrayList<Map>();
            if (StringUtils.isNotBlank(TYPE)) {
                if (SUP_NM.length() >= 5 && STRING.isMatchPattern(SUP_NM, "^\\w+$")) {
                    String newSuggestValue = STRING.fillCharFromRightExt(SUP_NM, 7, '0');
                    Map map = new HashMap();
                    map.put("SUP_NM", new DivData().getUnit4ShortName(newSuggestValue));
                    map.put("SUP_ID", newSuggestValue);
                    SUP_NMList.add(map);
                }
            } else {
                try {
                    List<Map> rtnList = new DTDJA004_mod().Query_ACPT_NAME(SUP_NM);
                    Map trnMap;
                    Set<String> SUP_NMSet = new HashSet<String>();
                    for (Map map : rtnList) {
                        String ACPT_NAME = MapUtils.getString(map, "ACPT_NAME", "").trim();
                        if (StringUtils.isNotBlank(ACPT_NAME) && !SUP_NMSet.contains(ACPT_NAME)) {
                            trnMap = new HashMap();
                            trnMap.put("SUP_ID", map.get("ID"));
                            trnMap.put("SUP_NM", ACPT_NAME);
                            SUP_NMList.add(trnMap);
                            SUP_NMSet.add(ACPT_NAME);
                        }
                    }

                } catch (DataNotFoundException dnfe) {
                    log.error("�̼t�ӦW�٬d�ߥ���", dnfe);
                }
            }
            resp.addOutputData("suggestResult", SUP_NMList);

        } catch (Exception e) {
            log.error("�t�ӷj�M���ܬd�ߥ���", e);
        }
        return resp;
    }

    /**
     * �p����B���
     * @param req
     * @return
     */
    /*public ResponseContext doCount(RequestContext req) {
        try {

            String CLR_AMT = req.getParameter("CLR_AMT");

            BigDecimal outNum = STRING.objToBigDecimal(CLR_AMT, BigDecimal.ZERO).multiply(new BigDecimal("0.11")).setScale(0,
                BigDecimal.ROUND_HALF_UP);

            resp.addOutputData("CLR_AMT", outNum);

        } catch (Exception e) {
            log.error("�p����B�����~", e);
        }
        return resp;

    /**
     * �@�άd��
     * @param reqMap
     * @param theEP_A30040
     * @throws Exception 
     */
    private void query(String APLY_NO, String SUB_CPY_ID) throws Exception {
        Map rtnMap = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);

        //���o�j�Ӹ��(for�ˮ֨ϥΧO)
        Map BLD_CDMap = new EP_Z0F170().queryMap(rtnMap);
        resp.addOutputData("BLD_USE_CD", MapUtils.getString(BLD_CDMap, "BLD_USE_CD"));

        resp.addOutputData("rtnMap", rtnMap);

        //151102 �P�_�O�_���ҤU�N�z�H
        resp.addOutputData("isInputAgent", new EPF1_0102_mod().isInputAgent(rtnMap, user) ? "Y" : "N");

        //���إ߳Ƨѿ��e���i�T�{���u
        //�إ߳Ƨѿ��ᦳ���w�ƬI�u���u�{�������i�T�{���u
        String APLY_TP = MapUtils.getString(rtnMap, "APLY_TP");
        if (EP_Z0F110.ST_2.equals(APLY_TP) || EP_Z0F110.ST_3.equals(APLY_TP)) {
            isHidAplyTp(APLY_NO, resp, SUB_CPY_ID);
        }
    }

    /**
     * �P�_��µ��O�_�i���ʮץ����
     * @param APLY_NO
     * @return
     * @throws Exception
     */
    private void isHidAplyTp(String APLY_NO, ResponseContext resp, String SUB_CPY_ID) throws Exception {
        boolean isUpdAplyTp = false;
        boolean isHidUpdateBtn = false;
        try {
            String[] btnUpdateArray = FieldOptionList.getName("EP", "BTN_CONTRAL", "BTN_UPDATE_APRV").split(",");
            String[] aplyTpArray = FieldOptionList.getName("EP", "BTN_CONTRAL", "APLY_TP_UPDATE").split(",");
            List<Map> voList = new EP_Z0F120().queryF120List(APLY_NO, SUB_CPY_ID);

            if (voList != null && !voList.isEmpty()) {
                resp.addOutputData("F120_OP_STATUS", MapUtils.getString(voList.get(0), "OP_STATUS", ""));
            }
            for (Map map : voList) {
                String OP_STATUS_120 = MapUtils.getString(map, "OP_STATUS", "");

                //if (!EP_Z0F110.ST_420.equals(OP_STATUS_120) && !EP_Z0F110.ST_460.equals(OP_STATUS_120) && !EP_Z0F110.ST_470.equals(OP_STATUS_120)) {
                if (!ArrayUtils.contains(btnUpdateArray, OP_STATUS_120)) {
                    isHidUpdateBtn = true;
                }
                if (!ArrayUtils.contains(aplyTpArray, OP_STATUS_120)) {
                    isUpdAplyTp = true;
                }
            }
            if (voList.size() > 1) {
                isHidUpdateBtn = true;
                isUpdAplyTp = true;
            }
        } catch (DataNotFoundException e) {
            isHidUpdateBtn = false;
            isUpdAplyTp = false;
        }
        resp.addOutputData("isHidUpdateBtn", isHidUpdateBtn);
        resp.addOutputData("isUpdAplyTp", isUpdAplyTp);
    }

    public void assignChangeFlow(String FLOW_NO, String AUTH_DESC, String COMMENT, UserObject user, String NEW_FLOW_TYPE,
            String NEW_OP_STATUS) throws ModuleException {
        String CHG_ID = user.getEmpID();
        String CHG_NAME = user.getEmpName();
        String CHG_DIV_NO = user.getDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }

        RZ_N00100 theRZ_N00100 = new RZ_N00100();
        DTRZN010 voDTRZN010 = new DTRZN010();
        voDTRZN010.setFLOW_NO(FLOW_NO);
        voDTRZN010.setFLOW_TYPE(NEW_FLOW_TYPE);
        voDTRZN010.setOP_STATUS(NEW_OP_STATUS);
        voDTRZN010.setAUTH_DESC(AUTH_DESC);
        voDTRZN010.setLST_PROC_ID(CHG_ID);
        voDTRZN010.setLST_PROC_NAME(CHG_NAME);
        voDTRZN010.setLST_PROC_DIV(CHG_DIV_NO);
        voDTRZN010.setLST_PROC_DATE(DATE.currentTime());
        theRZ_N00100.updateFlow(voDTRZN010);

        DTRZN011 voDTRZN011 = new DTRZN011();
        voDTRZN011.setFLOW_NO(FLOW_NO);
        voDTRZN011.setFLOW_TYPE(NEW_FLOW_TYPE);
        voDTRZN011.setOP_STATUS(NEW_OP_STATUS);
        voDTRZN011.setAUTH_DESC(AUTH_DESC);
        voDTRZN011.setCOMMENT(COMMENT);
        voDTRZN011.setLST_PROC_ID(CHG_ID);
        voDTRZN011.setLST_PROC_NAME(CHG_NAME);
        voDTRZN011.setLST_PROC_DIV(CHG_DIV_NO);
        voDTRZN011.setLST_PROC_DATE(DATE.currentTime());
        theRZ_N00100.insertEventLog(voDTRZN011);
    }

    /**
     * �d�ߤH���q��
     * @param req
     * @return
     */
    public ResponseContext doGetTEL(RequestContext req) {
        try {

            try {
                resp.addOutputData("rtnMap", new EP_F10310().getEmpData(req.getParameter("EMP_ID"), req.getParameter("EMP_TYPE"), req
                        .getParameter("SUB_CPY_ID")));
            } catch (DataNotFoundException dnfe) {
                throw new ModuleException("�d�L�H�Ƹ��");
            }

            MessageUtil.setMsg(msg, "MI00020");
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error(dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00630");
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630");
        }

        return resp;
    }
}
