package com.cathay.ep.f1.batch;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.service.ConfigManager;
import com.cathay.common.trx.BatchBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.util.FileStoreUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

public class EPF1_B900 extends BatchBean {

    private static Logger log = Logger.getLogger(EPF1_B900.class);

    private static String newLine = System.getProperty("line.separator");

    public static boolean isProduct() {
        try {
            String svrType = ConfigManager.getProperty("ebaf.ServerType");
            return "P".equals(svrType);
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public void execute(String[] args) throws Exception {
        try {
            createDataFile("DTEPF110", args);
            createDataFile("DTEPF120", args);
            createDataFile("DTEPF130", args);
            createDataFile("DTEPF140", args);
            createDataFile("DTEPF160", args);

        } catch (DBException e) {
            log.fatal(e, e);
        }
    }

    public int createDataFile(String table, String[] args) throws DBException, FileNotFoundException {
        String dir = FileStoreUtil.getFTPH2URoot() + File.separator + "DBEP";
        String outputFile = dir + File.separator + table + ".TXT";

        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(outputFile)));

        DataSet ds = null;

        int serNo = 0;
        String sqlCmd = null;
        DataProcessor dp = getDataProcessor(table, args);

        try {
            String STR_DATE = DATE.addDate(DATE.getDBDate(), 0, 0, -1);
            String END_DATE = DATE.getDBDate();
            if (args == null || args.length == 0 || StringUtils.isBlank(args[0])) {
                try{
                    STR_DATE = FieldOptionList.getName("EP", "EPF1_B900", "STR_DATE");
                }catch (Exception e) {
                    STR_DATE = DATE.addDate(DATE.getDBDate(), 0, 0, -1);
                }
                END_DATE = DATE.getDBDate();
            } else if(args.length == 1){
                STR_DATE = args[0];
                END_DATE = args[0];
            } else if(args.length == 2){
                STR_DATE = args[0];
                END_DATE = args[1];                
            }
            
            sqlCmd = dp.getSqlCmd(args);

            ds = Transaction.getDynamicDataSet();
            ds.setField("STR_DATE", STR_DATE);
            ds.setField("END_DATE", END_DATE);
            ds.searchAndRetrieve(sqlCmd);
            log.debug("SQL:" + sqlCmd);

            while (ds.next()) {
                serNo++;
                try {
                    StringBuffer sb = dp.processDataFile(ds, serNo);
                    if (sb != null && sb.length() > 0) {
                        sb.append(newLine);
                    }
                    bos.write(sb.toString().getBytes());
                } catch (Exception e) {
                    log.fatal("", e);
                }
            }

        } catch (DBException e) {
            log.fatal(sqlCmd);
            log.fatal(e);

            throw e;
        } finally {
            if (ds != null) {
                ds.clear();
            }
            try {
                if (bos != null) {
                    bos.flush();
                    bos.close();
                }
            } catch (Exception e) { /* Ignore Exception */
            }

        }

        return serNo;

    }

    private DataProcessor getDataProcessor(String table, String[] args) {
        if ("DTEPF110".equals(table)) {
            return new DataProcessorF110(table, args);
        } else if ("DTEPF120".equals(table)) {
            return new DataProcessorF120(table, args);
        } else if ("DTEPF130".equals(table)) {
            return new DataProcessorF130(table, args);
        } else if ("DTEPF140".equals(table)) {
            return new DataProcessorF140(table, args);
        } else if ("DTEPF160".equals(table)) {
            return new DataProcessorF160(table, args);
        }

        throw new UnsupportedOperationException("Table [" + table + "] Processor Not Defined");
    }

    private static abstract class DataProcessor {
        public abstract String getSqlCmd(String[] args);

        public abstract StringBuffer processDataFile(DataSet ds, int row) throws SQLException;

        protected String tableName;
        protected String[] args;

        public DataProcessor(String table, String[] args) {
            this.tableName = table;
            this.args = args;
        }

        public String getTable() {
            return this.tableName;
        }

        public String getValue(DataSet rs, String field) throws SQLException {
            String value = "";
            value = ObjectUtils.toString(rs.getField(field));
            value = value == null ? "" : value.trim();
            value = StringUtils.replace(value, ",", "�A");
            return value;
        }
        
        public String getTimeStampt(String val) throws SQLException {
            String value = "";
            if(StringUtils.isNotBlank(val)){
                value = DATE.getDBTimeStamp(val)+".000000";
            }
            return value;
        }


        public String getDefultValue(DataSet rs, String field) throws SQLException {
            String value = ObjectUtils.toString(rs.getField(field));
            value = StringUtils.isBlank(value) ? "�@" : value.trim();
            value = StringUtils.replace(value, ",", "�A");
            return value;
        }

        public String getDate(DataSet rs, String fieldName) throws SQLException {
            String strDate = getValue(rs, fieldName);
            if (strDate != null && strDate.length() > 10) {
                strDate = strDate.substring(0, 10);
            }
            return strDate;
        }

        public String getBldAddr(DataSet rs, String CEADRAR) throws SQLException {
            String CEBLDAD = getValue(rs, "CEBLDAD");
            if (CEADRAR.length() > 3) {
                String city = CEADRAR.substring(0, 3);

                CEBLDAD = getValue(rs, "CEBLDAD");
                if (!CEBLDAD.startsWith(CEADRAR)) {
                    if (CEBLDAD.startsWith(city)) {
                        CEBLDAD = StringUtils.replace(CEBLDAD, city, CEADRAR);
                    } else {
                        CEBLDAD = CEADRAR + CEBLDAD;
                    }
                }
            }
            return CEBLDAD;
        }

    }

    private static class DataProcessorF110 extends DataProcessor {

        public String getSqlCmd(String[] args) {
            
            String sql = "select  COALESCE(a.CEAPYNO,'') || '' || COALESCE(c.CEAPYSR,'') CEAPYNO,a.CEBLDCD,a.CEBLDNM,a.CEFIXMO,a.CEREQDV,a.CEREQDT,a.CEREQNO,a.CECHKDT,a.CEPRCID,a.CETNSKD,a.CETNSDT,a.CEUSRID,a.CECHECK,a.CEPREAMT, b.CEBLDSG,c.CEAPYKD,c.CEFEEKD,c.CECRGDT,c.CEFINDT,c.CESUPID,c.CESUPAM,c.CEMEMOF,c.CEMEMOF2,c.CEMEMOF3,c.CEMEMOF4,c.CEMEMOF5,c.CEWRKKD , c.CEFIXMH, c.CEWRKDT  ,d.CEADRAR, d.CEBLDAD "
                    + " from DTEPF01 a  "
                    + " LEFT JOIN (select distinct CEBLDCD, CEBLDSG from DTEPF04  )  b on b.CEBLDCD = a.CEBLDCD  "
                    + " LEFT JOIN (  select CEAPYNO, (CESUPID) as CESUPID, (CEWRKKD) as CEWRKKD, (CEAPYSR) as CEAPYSR, (CEFIXMH) as CEFIXMH, (CEAPYKD) as CEAPYKD, (CEFEEKD) as CEFEEKD,(CECRGDT) as CECRGDT,(CEFINDT) as CEFINDT,(CESUPAM) as CESUPAM,(CEMEMOF) as CEMEMOF, (CEMEMOF2) as CEMEMOF2,(CEMEMOF3) as CEMEMOF3,(CEMEMOF4) as CEMEMOF4, (CEMEMOF5) as CEMEMOF5, CEWRKDT  "
                    + " from DTEPF02  "
                    + " )  c on c.CEAPYNO = a.CEAPYNO "
                    + " left join DTEPA01 d on d.CEBLDCD = a.CEBLDCD where c.CEAPYSR != '' and a.CETNSDT between ':STR_DATE' and ':END_DATE' ORDER BY a.CEAPYNO,c.CEAPYSR with ur";
            return sql;
        }

        public DataProcessorF110(String table, String[] args) {
            super(table, args);
        }

        protected String getMemo(DataSet rs) throws SQLException {
            StringBuffer sb = new StringBuffer();

            sb.append(replaceBlank(getValue(rs, "CEMEMOF")));
            sb.append(replaceBlank(getValue(rs, "CEMEMOF2")));
            sb.append(replaceBlank(getValue(rs, "CEMEMOF3")));
            sb.append(replaceBlank(getValue(rs, "CEMEMOF4")));
            sb.append(replaceBlank(getValue(rs, "CEMEMOF5")));
            String memo = sb.toString();

            try {
                memo = STRING.subStringByByteArray(memo, 260, false);
            } catch (Exception e) {
                memo = StringUtils.abbreviate(memo, 130);
            }
            if (StringUtils.isEmpty(memo)) {
                memo = "\"\"";
            }
            return memo;
        }

        public String replaceBlank(String str) {
            String dest = "";
            if (str != null) {
                Pattern p = Pattern.compile("\\s*|\t|\r|\n");
                Matcher m = p.matcher(str);
                dest = m.replaceAll("");
                dest = dest.replace('"', '.');
            }
            return dest;
        }

        public StringBuffer processDataFile(DataSet rs, int serNo) throws SQLException {
            if (serNo % 10000 == 0) {
                log.debug("process line:" + serNo);
            }

            StringBuffer sb = new StringBuffer(1024);

            //          1   APLY_NO VARCHAR 12 0 PK    NO  �ץ�s��     DTEPF01.CEAPYNO
            sb.append(getValue(rs, "CEAPYNO")).append(",");
            //          2   SUB_CPY_ID VARCHAR 2 0     NO  �����q�O �����q�O            00
            sb.append("00").append(",");
            //          3   BLD_CD  VARCHAR 8   N       �j�ӥN��            DTEPF01.CEBLDCD
            if (StringUtils.isBlank(getValue(rs, "CEBLDCD"))) {
                if (StringUtils.isNotBlank(getDefultValue(rs, "CEBLDNM"))) {
                    String CEBLDNM = getDefultValue(rs, "CEBLDNM");
                    if ("�g���j��".equals(CEBLDNM)) {
                        sb.append("B022").append(",");
                    } else if ("��T�A�Ȥ���".equals(CEBLDNM)) {
                        sb.append("XA01").append(",");
                    }
                } else {
                    sb.append("�@").append(",");
                }
            } else {
                sb.append(getValue(rs, "CEBLDCD")).append(",");
            }
            //          4   BLD_NM  VARCHAR 20  N       �j�ӦW��            DTEPF01.CEBLDNM
            sb.append(getDefultValue(rs, "CEBLDNM")).append(",");
            //          5   BLD_ADDR    VARCHAR 100         �y���a�I            DTEPF04.CEADRAR+DTEPF04.CEBLDAD
            sb.append(getAddress(rs)).append(",");
            //          6   FIX_MO  VARCHAR 260 N       ��µ���e            DTEPF01.CEFIXMO
            sb.append("\"").append(replaceBlank(getValue(rs, "CEFIXMO"))).append("\"").append(",");
            //          7   INPUT_DIV_NO    VARCHAR 7   N       �߮׳��            DTEPF01.CEREQDV
            //sb.append(getValue(rs, "CEREQDV")).append(",");  ����W�LTABLE����
            sb.append("\"\"").append(",");
            //          8   INPUT_DATE  TIMESTAMP       N       �߮פ���ɶ�          DTEPF01.CEREQDT
            sb.append(getTimeStampt(getValue(rs, "CEREQDT"))).append(",");
            //          9   INPUT_ID    VARCHAR 10  N       �߮פH��ID          SYSTEM
            sb.append(getValue(rs, "CEUSRID")).append(",");
            //          10  APLY_TP VARCHAR 1   N       �ץ����    "1:�s�P��2:�@���3:�����"       DTEPF02.CEAPYKD
            String aplyType = getValue(rs, "CEAPYKD");
            sb.append("\"").append(aplyType).append("\"").append(",");
            //          11  USE_TP  VARCHAR 1   N       �ϥΪ��p����  "1:�X��2:�ۥ�"      DTEPF04.CEBLDSG
            sb.append("\"").append(getValue(rs, "CEBLDSG").replaceAll("0", "")).append("\"").append(",");
            //          12  EXP_TP  VARCHAR 1           �O�κ���    "0:�O�Υ�(�D�w���Y���P�w����) 1:�O�Υ�(�w���) 2:�겣�� 3:������"     DTEPF02.CEFEEKD
            sb.append(getValue(rs, "CEFEEKD")).append(",");
            //          13  FIX_FILE_NO VARCHAR 20          �ɬd�ɮ׽s��
            sb.append("").append(",");
            //          14  FINAL_FILE_NO   VARCHAR 20          �禬�ɮ׽s��
            sb.append("").append(",");
            //          15  FIX_DIV_ID  VARCHAR 10          ��µ��H��           DTEPF01.CEPRCID
            sb.append(getValue(rs, "CEPRCID")).append(",");
            //          16  FIX_GROUP_ID    VARCHAR 10          ��µ�դH��
            sb.append("").append(",");
            //          17  FIX_FINAL_DATE  TIMESTAMP               ���u�ɶ�
            sb.append("").append(",");
            //          18  SUB_USR_DATE    TIMESTAMP               �����禬�ɶ�
            sb.append("").append(",");
            //          19  USR_FINAL_DATE  TIMESTAMP               �����禬�ɶ�          DTEPF02.CECRGDT
            sb.append(getTimeStampt(getValue(rs, "CECRGDT"))).append(",");
            //          20  END_APLY_DATE   TIMESTAMP               �����k�ɮɶ�          DTEPF02.CEFINDT         
            sb.append(getTimeStampt(getValue(rs, "CEFINDT"))).append(",");
            //          21  SUP_ID  VARCHAR 10          �t�ӽs��    "�s�P��ϥ����        DTEPF02.CESUPID
            if ("1".equals(aplyType)) {
                sb.append(getValue(rs, "CESUPID")).append(",");
            } else {
                sb.append("").append(",");
            }
            //          22  CLR_AMT DECIMAL 5,0         ���B(�t�|)  �s�P��ϥ����     DTEPF02.CESUPAM
            if ("1".equals(aplyType)) {
                sb.append(getValue(rs, "CESUPAM")).append(",");
            } else {
                sb.append("").append(",");
            }
            //          23  ACT_AMT DECIMAL 5,0         ��޵| �s�P��ϥ����
            sb.append("").append(",");
            ;
            //          24  CURR    VARCHAR 3       NTD ���O          NTD
            sb.append("NTD").append(",");
            //          25  CFM_WORK_MO VARCHAR 260         �T�{�u�k����  �s�P��ϥ����     "DTEPF02.CEMEMOF
            if ("1".equals(aplyType)) {
                sb.append(replaceBlank(getMemo(rs))).append(",");
            } else {
                sb.append("").append(",");
            }
            //          26  MGR_PPL_MO  VARCHAR 260         �D�ްh�^����  �s�P��ϥ����
            sb.append("\"\"").append(",");
            //          34  WAR_MON DECIMAL 3,0         �O�T���    �s�P��ϥ����
            if ("1".equals(aplyType)) {
                sb.append(getValue(rs, "CEFIXMH")).append(",");
            } else {
                sb.append("").append(",");
            }
            //          27  PRO_OWN VARCHAR 1           �u�{�k��   �s�P��ϥ����
            if ("1".equals(aplyType)) {
                sb.append(getValue(rs, "CEWRKKD")).append(",");
            } else {
                sb.append("\"\"").append(",");
            }
            //          28  FLOW_NO VARCHAR 20  N       �f��y�{�s��  "�f�����(FLOW_TYPE) �s�P��:EPF1_0100 �@���:EPF1_0200 �����:EPF1_0200"
            sb.append("\"\"").append(",");
            ;
            //          29  OP_STATUS   VARCHAR 3   N       �@�~�i��    "100:�߮�(�߮׫ݰe��)
            sb.append("800").append(",");
            ;
            //          30  REQNO   VARCHAR 5           �ӽнs��            DTEPF01.CEREQNO
            sb.append(getValue(rs, "CEREQNO")).append(",");
            ;
            //          31  LST_PROC_DATE   TIMESTAMP       N       �@�~�ɶ�            DTEPF01.CETNSDT
            sb.append(getTimeStampt(getValue(rs, "CETNSDT"))).append(",");
            ;
            //          32  LST_PROC_ID VARCHAR 10  N       �@�~�H��            DTEPF01.CEUSRID
            sb.append(getValue(rs, "CEUSRID")).append(",");
            ;
            //          33  LST_PROC_DIV    VARCHAR 7   N       �@�~���            SYSTEM
            sb.append("\"\"").append(",");

            //          35  NULLIFY VARCHAR 200         �P�׭�]
            sb.append("\"\"").append(",");

            //          36  EST_AMT INT             �w�����B            DTEPF01.CEPREAMT
            sb.append(getValue(rs, "CEPREAMT")).append(",");
            ;
            //          37  CHECK   VARCHAR 1           �e��  "0:�_ 1:�O"       DTEPF01.CECHECK
            sb.append(getValue(rs, "CECHECK")).append(",");

            //          38  DIV_CFM_DATE DATE             �D��ñ�֤��            DTEPF01.CECHKDT
            sb.append(getDate(rs, "CECHKDT")).append(",");
            ;
            //          39  INFM_CONS_DATE   DATE           �q���I�u���       DTEPF02.CEWRKDT
            sb.append(getDate(rs, "CEWRKDT"));

            return sb;

        }

        protected String getAddress(DataSet rs) throws SQLException {
            String xx = "";
            String a = "";
            String b = "";

            a = getValue(rs, "CEADRAR");

            b = getValue(rs, "CEBLDAD");

            if (StringUtils.isNotBlank(a)) {
                xx = xx + a;
            }
            if (StringUtils.isNotBlank(b)) {
                xx = xx + b;
            }
            return xx;
        }

    }

    private static class DataProcessorF120 extends DataProcessorF110 {

        public String getSqlCmd(String[] args) {
            String sql = " SELECT COALESCE(b.CEAPYNO,'') || '' || COALESCE(b.CEAPYSR,'') CEAPYNO,b.CEAPYSR,b.CEAPYKD,b.CEWRKKD,b.CEFEEKD,b.CEFIXMH,b.CEWRKCD,b.CEMEMOF,b.CEMEMOF2,b.CEMEMOF3,b.CEMEMOF4,b.CEMEMOF5,b.CEAPYDT,b.CEVRPDT,b.CEWRKDT,b.CECRGDT,b.CEFINDT,b.CESUPID,b.CESUPNM,b.CESUPAM,b.CECFMDT,b.CETNSKD,b.CETNSDT,b.CEUSRID FROM DTEPF02 b join DTEPF01 a  on b.CEAPYNO = a.CEAPYNO  where b.CEAPYKD <> '1' and b.CETNSDT between ':STR_DATE' and ':END_DATE' ORDER BY b.CEAPYNO,b.CEAPYSR with ur";
            return sql;
        }

        public DataProcessorF120(String table, String[] args) {
            super(table, args);
        }

        public StringBuffer processDataFile(DataSet rs, int serNo) throws SQLException {
            if (serNo % 10000 == 0) {
                log.debug("process line:" + serNo);
            }

            StringBuffer sb = new StringBuffer(1024);

            //          APLY_NO VARCHAR 12  N       �ץ�s��    �褸���+�y����(4�X)        DTEPF02.CEAPYNO
            sb.append(getValue(rs, "CEAPYNO").replace('��', '1')).append(",");
            //          MEMO_NO INTEGER     N       �Ƨѿ��渹           DTEPF02.CEAPYSR
            sb.append(getValue(rs, "CEAPYSR").replace('��', '1')).append(",");
            //          SUB_CPY_ID  VARCHAR 2   N       �����q�O            00
            sb.append("00").append(",");
            //          IS_BM   VARCHAR 1   N       ��ޥ� "1:��ޥ� 2:�D��ޥ�"
            sb.append("\"\"").append(",");
            //          MEMO_MO VARCHAR 260 N       �Ƨѿ�����           "DTEPF02.CEMEMOF DTEPF02.CEMEMOF2 DTEPF02.CEMEMOF3 DTEPF02.CEMEMOF4 DTEPF02.CEMEMOF5
            sb.append(getMemo(rs)).append(",");
            //          MEMO_AMT    DECIMAL 12,2            �Ƨѿ����B
            sb.append("").append(",");
            //          PPL_FILE_NO VARCHAR 20          �e�֪��ɮ�       
            sb.append("").append(",");
            //          MEMO_FILE_NO    VARCHAR 20          �Ƨѿ��ɮ�   
            sb.append("").append(",");
            //          CFM_WORK_MO VARCHAR 260         �T�{�u�k����          
            sb.append("\"\"").append(",");
            //          SUBCON_GROUP_ID VARCHAR 10          �o�]�դH��
            sb.append("\"\"").append(",");
            //          FLOW_NO VARCHAR 20  N       �f��y�{�s��  "�f�����(FLOW_TYPE) �@���:EPF1_0240 �����:EPF1_0340"
            sb.append("\"\"").append(",");
            //          OP_STATUS   CHAR    3   N       �@�~�i��    "410:�s�W(�ݳƧѿ��e��)420:�e��(�ݽT�{�u�k)430:�T�{�u�k(�ݥD��ñ��)440:�D��ñ��(�ݬ���(�o�]��)) 450:�o�]�դw����(�ݴ������)
            sb.append("\"\"").append(",");
            //          LST_PROC_DATE   TIMESTAMP       N       �@�~�ɶ�            �t�ήɶ�
            sb.append(getTimeStampt(getValue(rs, "CETNSDT"))).append(",");
            //          LST_PROC_ID VARCHAR 10  N       �@�~�H��            SYSTEM
            sb.append(getValue(rs, "CEUSRID")).append(",");
            //          LST_PROC_DIV    VARCHAR 7   N       �@�~���            SYSTEM
            sb.append("\"\"");
            ;

            //          CHG_NAME    ���ʤH���m�W  VARCHAR 30  ��Ӫ� �X�������
            sb.append("");

            return sb;

        }

    }

    private static class DataProcessorF130 extends DataProcessor {

        public DataProcessorF130(String table, String[] args) {
            super(table, args);
        }

        public String getSqlCmd(String[] args) {
            //return "SELECT * FROM DTEPF02 where CEAPYKD <> '1' ";
            String sql = " SELECT COALESCE(b.CEAPYNO,'') || '' || COALESCE(b.CEAPYSR,'') CEAPYNO,b.CEAPYSR,b.CEAPYKD,b.CEWRKKD,b.CEFEEKD,b.CEFIXMH,b.CEWRKCD,b.CEMEMOF,b.CEMEMOF2,b.CEMEMOF3,b.CEMEMOF4,b.CEMEMOF5,b.CEAPYDT,b.CEVRPDT,b.CEWRKDT,b.CECRGDT,b.CEFINDT,b.CESUPID,b.CESUPNM,b.CESUPAM,b.CECFMDT,b.CETNSKD,b.CETNSDT,b.CEUSRID FROM DTEPF02 b join DTEPF01 a  on b.CEAPYNO = a.CEAPYNO  where b.CEAPYKD <> '1' and b.CETNSDT between ':STR_DATE' and ':END_DATE' ORDER BY b.CEAPYNO,b.CEAPYSR with ur";
            return sql;
        }

        public StringBuffer processDataFile(DataSet rs, int serNo) throws SQLException {
            if (serNo % 10000 == 0) {
                log.debug("process line:" + serNo);
            }
            StringBuffer sb = new StringBuffer(1024);
            //          APLY_NO VARCHAR 12  N       �ץ�s��    �褸���+�y����(4�X)        DTEPF02.CEAPYNO
            sb.append(getValue(rs, "CEAPYNO").replace('��', '1')).append(",");
            //          MEMO_NO INTEGER     N       �Ƨѿ��渹           DTEPF02.CEAPYSR
            sb.append(getValue(rs, "CEAPYSR").replace('��', '1')).append(",");
            //          PRO_NO  INTEGER     N       �u�اǸ�            �y����
            sb.append("1").append(",");
            //          SUB_CPY_ID  VARCHAR 2   N       �����q�O    00:����H��     00
            sb.append("00").append(",");
            //          PROJECT_TP  VARCHAR 60          �u�{����
            sb.append("").append(",");
            //          WAR_MON DECIMAL 2,0         �O�T���            DTEPF02.CEFIXMH
            sb.append(getValue(rs, "CEFIXMH")).append(",");
            //          7   CNT DECIMAL 2,0         �ƶq          DTEPF03.CEPRTQT
            sb.append("").append(",");
            //          8   UNIT    VARCHAR 10          ���          DTEPF03.CEUNIT
            sb.append("").append(",");
            //          9   PRICE   DECIMAL 12,2            ���          DTEPF03.CEPRTAM
            sb.append("").append(",");
            //          10  EST_AMT DECIMAL 12,2            �w�����B(�t�|)            DTEPF03.CEPRTSM
            sb.append("").append(",");
            //          SUP_ID  VARCHAR 10          �t�ӽs��    DTEPF100.SUP_ID     DTEPF02.CESUPID
            sb.append(getValue(rs, "CESUPID")).append(",");
            //          CLR_AMT DECIMAL 12,2            �������B(�t�|)            DTEPF02.CESUPAM
            sb.append(getValue(rs, "CESUPAM")).append(",");
            //          ACT_AMT DECIMAL 12,2            ��@���B(�t�|)            DTEPF02.CESUPAM
            sb.append(getValue(rs, "CESUPAM")).append(",");
            //          PR_AMT  DECIMAL 12,2            ���I�l�B(�t�|)    �Ĥ@��=��@���B(�t�|)
            sb.append("0").append(",");
            //          PRO_OWN VARCHAR 1           �u�{�k��     1:�ؿv2:���q3:���C 4:�Ž� 5:��׫ؿv 6:��׾��q 7:��׸��C 8:��תŽ�      DTEPF02.CEWRKKD
            sb.append(getValue(rs, "CEWRKKD")).append(",");

            //          IS_CONT VARCHAR 1           �X���� "1:�X���� 2:�D�X����"  
            sb.append("").append(",");
            //          CONT_NO VARCHAR 14          �X���s��
            sb.append("").append(",");
            //          CONT_AMT    DECIMAL 12,2            �X�����B
            sb.append("").append(",");
            //          CONS_SDATE  DATE                �I�u�_��            DTEPF02.CEWRKDT
            sb.append(getDate(rs, "CEWRKDT")).append(",");
            //          CONS_EDATE  DATE                �I�u����            DTEPF02.CEWRKDT
            sb.append(getDate(rs, "CEWRKDT")).append(",");
            //          FINAL_DATE  DATE                ���u���            
            sb.append("").append(",");
            //          LST_PROC_DATE   TIMESTAMP       N       �@�~�ɶ�            CETNSDT
            sb.append(getTimeStampt(getValue(rs, "CETNSDT"))).append(",");
            //          LST_PROC_ID VARCHAR 10  N       �@�~�H��            CEUSRID
            sb.append(getValue(rs, "CEUSRID")).append(",");
            //          LST_PROC_DIV    VARCHAR 7   N       �@�~���            SYSTEM
            sb.append("\"\"");

            return sb;
        }
    }

    private static class DataProcessorF140 extends DataProcessor {

        private Map<MultiKey, Integer> serMap = new HashMap<MultiKey, Integer>();

        public DataProcessorF140(String table, String[] args) {
            super(table, args);
        }

        public String getSqlCmd(String[] args) {
            String sql = " select COALESCE(a.CEAPYNO,'') || '' || COALESCE(a.CEAPYSR,'') CEAPYNO,a.CEAPYSR,a.CEPRTNM,a.CEPRTAM,a.CEPRTQT,a.CEPRTSM,a.CEUNIT,a.CETNSKD,a.CETNSDT ,a.CEORDER,a.CEUSRID from DTEPF03 a where a.CETNSDT between ':STR_DATE' and ':END_DATE' order by a.CEAPYNO, a.CEAPYSR,a.CEORDER with ur";
            return sql;
        }

        public StringBuffer processDataFile(DataSet rs, int serNo) throws SQLException {
            if (serNo % 10000 == 0) {
                log.debug("process line:" + serNo);
            }

            StringBuffer sb = new StringBuffer(1024);
            String aply_NO = getValue(rs, "CEAPYNO").replace('��', '1').replace('A', '1').replace("1 3", "0");
            //          APLY_NO VARCHAR 12  N       �ץ�s��    �褸���+�y����(4�X)        DTEPF03.CEAPYNO
            sb.append(aply_NO).append(",");
            //          MEMO_NO INTEGER     N       �Ƨѿ��渹           DTEPF03.CEAPYSR
            String memNo = getValue(rs, "CEAPYSR").replace('��', '1').replace('A', '1').replace("1 3", "0");
            if (StringUtils.isBlank(memNo)) {
                memNo = "0";
            }
            String proNo = "1";
            String order = getValue(rs, "CEORDER");
            sb.append(memNo).append(",");
            //          PRO_NO  INTEGER     N       �u�اǸ�            �y����
            sb.append(proNo).append(",");
            MultiKey key = new MultiKey(aply_NO, memNo, proNo, order);
            int prtNo;
            if (serMap.containsKey(key)) {
                prtNo = serMap.get(key) + 1;
            } else {
                prtNo = NumberUtils.toInt(order);
                serMap.put(key, prtNo);
            }
            //          PRT_NO  INTEGER     N       ��µ�Ǹ�            DTEPF03.CEORDER
            sb.append(prtNo).append(",");
            //          SUB_CPY_ID  VARCHAR 2   N       �����q�O    00:����H��     00
            sb.append("00").append(",");
            //          MAT_ID  VARCHAR 5           ���ƥN�X
            sb.append("\"\"").append(",");
            //          MAT_NM  VARCHAR 600         ���ƫ~�W            DTEPF03.CEPRTNM
            sb.append(replaceBlank(getValue(rs, "CEPRTNM"))).append(",");
            //          CNT DECIMAL 2,0         ���Ƽƶq            DTEPF03.CEPRTQT
            sb.append(getValue(rs, "CEPRTQT")).append(",");
            //          UNIT    VARCHAR 10          ���Ƴ��            DTEPF03.CEUNIT
            sb.append(getValue(rs, "CEUNIT")).append(",");
            //          PRICE   DECIMAL 12,2            ���Ƴ��            DTEPF03.CEPRTAM
            sb.append(getValue(rs, "CEPRTAM")).append(",");
            //          EST_AMT DECIMAL 12,2            ���B          DTEPF03.CEPRTSM
            sb.append(getValue(rs, "CEPRTSM"));

            return sb;
        }

        public String replaceBlank(String str) {
            String dest = "";
            if (str != null) {
                Pattern p = Pattern.compile("\\s*|\t|\r|\n");
                Matcher m = p.matcher(str);
                dest = m.replaceAll("");
                dest = dest.replace('"', '.');
            }
            return dest;
        }
    }

    private static class DataProcessorF160 extends DataProcessor {

        public DataProcessorF160(String table, String[] args) {
            super(table, args);
        }

        public String getSqlCmd(String[] args) {
            String sql = " select   COALESCE(a.CEAPYNO,'') || '' || COALESCE(c.CEAPYSR,'') CEAPYNO,COALESCE(c.CEAPYSR,'') CEAPYSR,c.CESUPID,c.CEAPYSR,c.CESUPAM, e.CEINVNO,c.CECRGDT,c.CECFMDT,c.CETNSDT,c.CEUSRID from DTEPF01 a  JOIN DTEPF02 c on c.CEAPYNO = a.CEAPYNO left join (select DISTINCT CEAPYNO,CEAPYSR,CEINVNO from DTEPF03 ) e on e.CEAPYNO = c.CEAPYNO and e.CEAPYSR = c.CEAPYSR where c.CEAPYNO is not null and c.CETNSDT between ':STR_DATE' and ':END_DATE' ORDER BY a.CEAPYNO,c.CEAPYSR with ur";
            return sql;
        }

        public StringBuffer processDataFile(DataSet rs, int serNo) throws SQLException {
            if (serNo % 10000 == 0) {
                log.debug("process line:" + serNo);
            }
            StringBuffer sb = new StringBuffer(1024);

            //1   PAY_CASE_NO VARCHAR 11  N       �дڽs��
            sb.append(getValue(rs, "CEAPYNO").replace('��', '1')).append(",");
            //2   PAY_SER_NO  INTEGER     N       �дڧǸ�
            sb.append(getValue(rs, "CEAPYSR").replace('��', '1')).append(",");
            //3   SUB_CPY_ID  VARCHAR 2   N       �����q�O
            sb.append("00").append(",");
            //4   APLY_NO VARCHAR 12  N       �ץ�s��
            sb.append(getValue(rs, "CEAPYNO").replace('��', '1')).append(",");
            //7   CONT_NO VARCHAR 14          �X���s��
            sb.append("").append(",");
            //8   SUP_ID  VARCHAR 10          �t�ӽs��
            sb.append(getValue(rs, "CESUPID")).append(",");
            //11  PAY_AMT DECIMAL 12,2            �дڪ��B
            sb.append(getValue(rs, "CESUPAM")).append(",");
            //12  TAX_AMT DECIMAL 12,2            �дڵ|�B
            sb.append("0").append(",");
            //13  INV_NO  VARCHAR 10          �o�����X
            sb.append(getValue(rs, "CEINVNO")).append(",");
            //14  PAY_DATE    TIMESTAMP               �дڤ��
            sb.append(getTimeStampt(getValue(rs, "CECRGDT"))).append(",");
            //15  PAY_CFM_DATE    TIMESTAMP               �дڽT�{���
            sb.append(getTimeStampt(getValue(rs, "CECFMDT"))).append(",");
            //16  CASE_NO VARCHAR 11          �дڰO���s��
            sb.append("").append(",");
            //17  ACC_TP  VARCHAR 1   N       �|�p����
            sb.append("\"\"").append(",");
            //18  TAX_TP  VARCHAR 1   N       �|�O
            sb.append("\"\"").append(",");
            //19  DATA_SOURCE VARCHAR 1   N       ��ƨӷ�
            sb.append("1").append(",");
            //20  LST_PROC_DATE   TIMESTAMP       N       �@�~�ɶ�
            sb.append(getTimeStampt(getValue(rs, "CETNSDT"))).append(",");
            //21  LST_PROC_ID VARCHAR 10  N       �@�~�H��
            sb.append(getValue(rs, "CEUSRID")).append(",");
            //22  LST_PROC_DIV    VARCHAR 7   N       �@�~���
            sb.append("\"\"").append(",");
            //9   MEMO_NO INTEGER             �Ƨѿ��渹
            sb.append(getValue(rs, "CEAPYSR").replace('��', '1')).append(",");
            //10  PRO_NO  INTEGER             �u�اǸ�
            sb.append("1");

            return sb;
        }
    }

}
