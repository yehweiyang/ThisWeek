package com.cathay.ep.f1.batch;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.rz.t0.module.RZ_T0Z001;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/** 
 * <pre>
 * Date    Version Description Author
 * 2016/06/06  1.0 Created �L�ç�
 * 
 * �@�B  �{���\�෧�n�����G 
 * �{���\��    ��µ�ץ󦨥����R���
 * �{���W��    EPF1_B102.java
 * �@�~�覡    BATCH
 * ���n����    �ɭ�µ�ץ󦨥����R���(EPF1_0102�e�֪��W��)
 * �w����ƶq   
 * �@�~�W��    BEPF1_B102
 * �~�ȧO EP
 * ���t�ΦW��   F1
 * �B�z�g��    ��
 * ����B�z���  �w�]��
 * </pre>
 * @author �L�ç�
 * @since 2016/06/08  
 */
@SuppressWarnings("unchecked")
public class EPF1_B102 extends EP_BatchBean {

    /** logger */
    private static final Logger log = Logger.getLogger(EPF1_B102.class);

    /** �@�~�W�� */
    private static final String JOB_NAME = "BEPF1_B102";

    /** �{���W�� */
    private static final String PROGRAM = "EPF1_B102";

    /** �~�ȧO */
    private static final String BUSINESS = "EP";

    /** ���t�ΦW�� */
    private static final String SUBSYSTEM = "F1";

    /** ����g�� */
    private static final String PERIOD = "��";

    /** �]�� true �Ѥ����O�p�Ƥμg���~�T��, false �Шϥ� ErrorLog ��CountManager �ۦ�g���~�T���έp�� */
    private static final boolean isAUTO_WRITELOG = false;

    private static final StringBuffer sbf = new StringBuffer(); //���~�ץ�s���M��

    private static final String SQL_delete_001 = "com.cathay.ep.f1.batch.EPF1_B102.SQL_delete_001";

    private static final String SQL_insert_001 = "com.cathay.ep.f1.batch.EPF1_B102.SQL_insert_001";

    private static final String SQL_query_001 = "com.cathay.ep.f1.batch.EPF1_B102.SQL_query_001";

    public EPF1_B102() throws Exception {

        //�]�w�����O���غc�l,�ǤJ true �Ѥ����O�p�Ƥμg���~�T��
        super(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isAUTO_WRITELOG);

    }

    public void execute(String args[]) throws Exception { //����妸�@�~      

        final BatchConstructor bc = new BatchConstructor(JOB_NAME, "EPF1_B102", "��");

        final Map cntMap = new HashMap();//�O�J����
        cntMap.put("INPUT_CNT", 0);
        cntMap.put("ERROR_CNT", 0);

        try {
            final String APLY_NO;
            final String MEMO_NO;
            if (args != null && args.length > 0) {
                //���ե�
                APLY_NO = args[0];
                MEMO_NO = args[1];
                DataSet ds = Transaction.getDataSet();
                try {
                    //�M��F140����
                    ds.setField("APLY_NO", APLY_NO);
                    ds.setField("MEMO_NO", MEMO_NO);
                    ds.setField("SUB_CPY_ID", "00");
                    DBUtil.executeUpdate(ds, SQL_delete_001);
                } catch (DataNotFoundException dnfe) {
                    //�d�L��Ƶ������`
                } catch (Exception e) {
                    setExitCode(ERROR);
                    String memo = "�M��F140��ƥ���";
                    log.fatal(memo, e);
                    bc.addErrorLog(memo, memo);
                    bc.writeErrorLog();
                    return;
                }
            } else {
                APLY_NO = "";
                MEMO_NO = "";
            }

            bc.execute(new BatchConstructor.DataBaseHandler() {

                //insert->DTEPF140
                BatchUpdateDataSet insert_buds = bc.getBatchUpdateDataSet(SQL_insert_001, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                @Override
                protected boolean searchProcess(BatchQueryDataSet bqds) throws DBException {
                    if (StringUtils.isNotBlank(APLY_NO)) {
                        bqds.setField("APLY_NO", APLY_NO);
                    }
                    bqds.searchAndRetrieve(SQL_query_001);
                    if (bqds.getTotalCount() == 0) {
                        log.fatal("�d�L���,�������`");
                    }
                    return true;
                }

                @Override
                protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {

                    String s_AplyNo = ObjectUtils.toString(bqds.getField("APLY_NO"));
                    String s_MemoNo = ObjectUtils.toString(bqds.getField("MEMO_NO"));
                    String s_FileNo = ObjectUtils.toString(bqds.getField("PPL_FILE_NO"));

                    RZ_T0Z001 theRZ_T0Z001 = new RZ_T0Z001();

                    //���o�ɮ�ID
                    List<Map> fileInfoList;
                    try {
                        fileInfoList = theRZ_T0Z001.getFileInfo(s_FileNo, "EP", "EP_Z00010");
                    } catch (Exception e) {
                        //�~��B�z�U�@�����
                        log.fatal("���o�ɮ׵o�Ϳ��~ : " + s_FileNo);
                        bc.addErrorLog("���o�ɮ׵o�Ϳ��~", e);
                        bc.writeErrorLog();
                        return;
                    }

                    //���o�ɮ׸��|
                    String[] fileInfoData;
                    try {
                        fileInfoData = theRZ_T0Z001.getDownloadFilePath(MapUtils.getString(fileInfoList.get(0), "FILE_ID"));
                    } catch (Exception e) {
                        //�~��B�z�U�@�����
                        log.fatal("���o�ɮ׸��|�o�Ϳ��~ : " + s_FileNo);
                        bc.addErrorLog("���o�ɮ׸��|�o�Ϳ��~", e);
                        bc.writeErrorLog();
                        return;
                    }

                    String s_FileName = fileInfoData[0];
                    String s_FileType = s_FileName.substring(s_FileName.lastIndexOf(".") + 1);
                    String s_FilePath = fileInfoData[1];
                    File targetFile = new File(s_FilePath);

                    List<Map> fileF140List = new ArrayList();
                    Sheet sheet1 = null;
                    try {
                        if ("xls".equalsIgnoreCase(s_FileType)) {
                            HSSFWorkbook wb = new HSSFWorkbook(new BufferedInputStream(new FileInputStream(targetFile)));
                            int wbCountSheet = wb.getNumberOfSheets();
                            for (int i = 0; i < wbCountSheet; i++) {
                                if (i != 0) {
                                    sheet1 = wb.getSheetAt(i);
                                    try {
                                        this.processExcelData(fileF140List, sheet1);
                                    } catch (Exception e) {
                                        //                                        log.fatal("�o�Ϳ��~�ץ�s�� : " + s_AplyNo);
                                        sbf.append(',').append(s_AplyNo);
                                    }
                                }
                            }
                        } else {
                            XSSFWorkbook wb = new XSSFWorkbook(new BufferedInputStream(new FileInputStream(targetFile)));
                            int wbCountSheet = wb.getNumberOfSheets();
                            for (int i = 0; i < wbCountSheet; i++) {
                                if (i != 0) {
                                    sheet1 = wb.getSheetAt(i);
                                    try {
                                        this.processExcelData(fileF140List, sheet1);
                                    } catch (Exception e) {
                                        //                                        log.fatal("�o�Ϳ��~�ץ�s�� : " + s_AplyNo);
                                        sbf.append(',').append(s_AplyNo);
                                    }
                                }
                            }
                        }
                    } catch (Exception e) {
                        //                        log.fatal("�o�Ϳ��~�ץ�s�� : " + s_AplyNo);
                        sbf.append(',').append(s_AplyNo);
                    }

                    //�s�WF140�s���
                    int i = 1;
                    for (Map fileMap : fileF140List) {
                        insert_buds.setField("APLY_NO", s_AplyNo);
                        insert_buds.setField("MEMO_NO", s_MemoNo);
                        insert_buds.setField("SUB_CPY_ID", "00");
                        insert_buds.setField("PRO_NO", 1);
                        insert_buds.setField("PRT_NO", i);
                        insert_buds.setField("CNT", STRING.objToBigDecimal(fileMap.get("CNT"), BigDecimal.ZERO));
                        insert_buds.setField("UNIT", MapUtils.getString(fileMap, "UNIT"));
                        insert_buds.setField("PRICE", STRING.objToBigDecimal(fileMap.get("PRICE"), BigDecimal.ZERO));
                        insert_buds.setField("MAT_NM", MapUtils.getString(fileMap, "PROJECT_TP"));
                        insert_buds.setField("EST_AMT", STRING.objToBigDecimal(fileMap.get("EST_AMT"), BigDecimal.ZERO));
                        addBatchAndJoinGroup(insert_buds);
                        i++;
                    }
                }

                /**
                 * Ū��EXCEL���e
                 */
                private List<Map> processExcelData(List<Map> fileList, Sheet sheet1) {

                    boolean tempboolean = false;
                    boolean tempboolean2 = false;
                    int chkStop = 0;
                    for (int i = 6; i < sheet1.getPhysicalNumberOfRows(); i++) { //Row(���L���Y)
                        if (tempboolean2) {
                            break;
                        }

                        Row row = sheet1.getRow(i);
                        String tmpStr;
                        String tmpStr4;
                        String tmpStr5;
                        String tmpStr6;
                        String tmpStr7;
                        String tmpStr8;
                        String chkStr;

                        if (row != null) {
                            if (!tempboolean) {

                                Cell cell = row.getCell(0);
                                if (cell != null) {
                                    try {
                                        cell.setCellType(Cell.CELL_TYPE_STRING); //��������নString
                                        tmpStr = cell.getStringCellValue();
                                    } catch (NullPointerException e) {
                                        throw e;
                                    }
                                } else { //�Y�L�Ȭ���
                                    tmpStr = "";
                                }

                                if ("����".equals(tmpStr)) {
                                    tempboolean = true;
                                }

                            } else {

                                Map rntMap = new HashMap();
                                Cell cellj = row.getCell(0); //����
                                Cell cell4 = row.getCell(1); //���ƤΤu�{����                                                                                                                                
                                Cell cell5 = row.getCell(2); //��  
                                Cell cell6 = row.getCell(3); //�ƶq 
                                Cell cell7 = row.getCell(4); //���           
                                Cell cell8 = row.getCell(5); //���B

                                chkStr = this.getCellValue(cellj);
                                tmpStr4 = this.getCellValue(cell4);
                                tmpStr5 = this.getCellValue(cell5);
                                tmpStr6 = this.getCellValue(cell6);
                                tmpStr7 = this.getCellValue(cell7);
                                tmpStr8 = this.getCellValue(cell8);

                                if (StringUtils.isBlank(chkStr) && StringUtils.isBlank(tmpStr4) && StringUtils.isBlank(tmpStr5)
                                        && StringUtils.isBlank(tmpStr6) && StringUtils.isBlank(tmpStr7) && StringUtils.isBlank(tmpStr8)) {//�Y�����欰�ūh��
                                    chkStop++;
                                    if (chkStop == 10) {//�s��ťդQ�C ���U�@��SHEET
                                        tempboolean2 = true;
                                        tempboolean = false;
                                        break;
                                    }

                                } else {
                                    tempboolean2 = false;
                                    tempboolean = true;
                                    chkStop = 0;
                                    if (StringUtils.isNotBlank(chkStr) && StringUtils.isNotBlank(tmpStr4)
                                            && StringUtils.isNotBlank(tmpStr5) && StringUtils.isNotBlank(tmpStr6)
                                            && StringUtils.isNotBlank(tmpStr7) && StringUtils.isNotBlank(tmpStr8)) {
                                        if ((STRING.isNumeric(tmpStr7)) && (STRING.isNumeric(tmpStr8))) {//���,���B�����ťB�����Ʀr
                                            rntMap.put("PROJECT_TP", tmpStr4);
                                            rntMap.put("UNIT", tmpStr5);
                                            rntMap.put("CNT", tmpStr6);
                                            rntMap.put("PRICE", tmpStr7);
                                            rntMap.put("EST_AMT", tmpStr8);

                                            fileList.add(rntMap);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    return fileList;
                }

                private String getCellValue(Cell cellj) {
                    try {
                        if (cellj != null) {
                            cellj.setCellType(Cell.CELL_TYPE_STRING); //��������নString
                            return cellj.getStringCellValue();
                        }
                    } catch (Exception e) {
                        return "";
                    }
                    return "";
                }
            });

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("����ɵo�Ϳ��~", e);
        } finally {
            //�P�_�O�_��X���~�M��
            if (sbf.length() > 0) {
                log.fatal("�o�Ϳ��~�ץ�s�� �G" + sbf.substring(1));
            }

            int batchConstructorExitCode = bc.getExitCode();
            if (batchConstructorExitCode != OK) {
                setExitCode(batchConstructorExitCode);
            }
            printExitCode(getExitCode());
        }
    }
}
