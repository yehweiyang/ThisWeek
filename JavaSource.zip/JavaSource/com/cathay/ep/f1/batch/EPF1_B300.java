package com.cathay.ep.f1.batch;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.ConfigManager;
import com.cathay.common.util.DATE;
import com.cathay.common.util.batch.BatchConstructor;
import com.cathay.common.util.batch.BatchConstructor.Options;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.common.util.http.HttpClientHelper;
import com.cathay.common.util.http.HttpClientHelper.HttpResponseType;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.rz.z0.module.RZ_Z0Z002;
import com.cathay.util.Transaction;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/**
 * <pre>
 *  �@�B  �{���\�෧�n�����G
 *  �{���\��    ���ʲ��Ȥ�d�߬~������I���ŧ@�~
 *  �{���W��    EPF1_B300.java
 *  �@�~�覡    BATCH
 *  ���n����    
 *  1.�C�u�@����[�дڮ־P���I��(DTEPF160)]�����ʲ��Ȥ�ID�Ωm�W�d�߬~������I����
 *  2.�g�J[�Ȥ᭷�I������(DTEPZ400)]
 *  3.�]���󥭥x�A�G�ϥ�call API�覡�d�ߨ���W��
 *  4.
 * </pre>
 * 
 * @author �¤l��
 * @since 2019.04.26
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPF1_B300 extends EP_BatchBean {

    private static final Logger log = Logger.getLogger(EPF1_B300.class);

    /** �@�~�W��*/
    private static final String JOB_NAME = "JAEPDC999";

    /** �{���W�� */
    private static final String PROGRAM = "EPF1_B300";

    /** ����g�� */
    private static final String PERIOD = "��";

    private boolean isDebug = log.isDebugEnabled();

    private static final String SQL_insertDTEPZ400 = "com.cathay.ep.f1.batch.EPF1_B300.SQL_insertDTEPZ400";

    //private static final String SQL_updateDTEPZ400 = "com.cathay.ep.f1.batch.EPF1_B300.SQL_updateDTEPZ400";

    private static final String SQL_query_001 = "com.cathay.ep.f1.batch.EPF1_B300.SQL_query_001";

    private static final String SQL_deleteDTEPZ400 = "com.cathay.ep.f1.batch.EPF1_B300.SQL_deleteDTEPZ400";

    @Override
    public void execute(String[] args) throws Exception {

        final BatchConstructor bc = new BatchConstructor(JOB_NAME, PROGRAM, PERIOD);

        try {

            log.fatal("<================����DTEPZ400�Ȥ᭷�I������================>");
            Options options = bc.getOptions();
            options.setIndividualStatistics(true);

            bc.execute(new BatchConstructor.DataBaseHandler() {

                BatchUpdateDataSet buds_insert_DTEPZ400 = bc.getBatchUpdateDataSet(SQL_insertDTEPZ400,
                    ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);

                /*BatchUpdateDataSet buds_update_DTEPZ400 = bc.getBatchUpdateDataSet(SQL_updateDTEPZ400,
                    ErrorHandler.DATA_NOT_FOUND_SUCCESS_DUPLICATE_FAIL);*/

                StringBuilder sb = new StringBuilder();

                RZ_Z0Z002 theRZ_Z0Z002 = new RZ_Z0Z002();

                //AI_L0Z002 theAI_L0Z002 = new AI_L0Z002();

                Timestamp currentTime;

                @Override
                protected boolean searchProcess(BatchQueryDataSet bqds) throws DBException, ModuleException {
                    //1.�d��PAY_DATE(�дڤ��)��USR_FINAL_DATE(�����禬�ɶ�)��FIX_FINAL_DATE(���u�ɶ�)12�Ӥ뤺��[�дڮ־P���I��(DTEPF160)]�C
                    //2.�]���ۦP�Τ@�s�������P���q�W�١A�G�������P���p�C
                    bqds.searchAndRetrieve(SQL_query_001);

                    if (bqds.getTotalCount() == 0) {
                        log.fatal("�d�L�Ȥ���");
                        return false;
                    } else {
                        log.fatal("<================�R��DTEPZ400�Ȥ᭷�I������================>");
                        DataSet ds = Transaction.getDataSet();
                        DBUtil.executeUpdate(ds, SQL_deleteDTEPZ400, false);
                    }
                    return true;
                }

                @Override
                protected void forEachProcess(BatchQueryDataSet bqds) throws Exception {
                    String ID = ObjectUtils.toString(bqds.getField("SUP_ID"));//�t�ӽs��
                    String NAME = ObjectUtils.toString(bqds.getField("SUP_NM"));//�t�ӦW��
                    //String LEVEL = theAI_L0Z002.doAccountLEVEL(ID, NAME, "EP", ""); //�~������I����

                    //���ˮ֨���W��
                    String api = "AI/doAccountLEVEL";
                    //���oSERVER����
                    String serverType = ConfigManager.getProperty("ebaf.ServerType");
                    log.debug("serverType>>" + serverType);
                    //���o�����ҩ��}
                    String targetURL = theRZ_Z0Z002.getCodeName("EP", "AI_FUND_APIURL", serverType) + api;//"ZZ", "APIM_URL"
                    //http://swas3.cathaylife.com.tw/ZSWeb/api/AI/doAccountLEVEL
                    log.debug("targetURL>>" + targetURL);
                    //�]�w�Ѽ�
                    Map parameterMap = new HashMap();
                    parameterMap.put("ID", ID);
                    parameterMap.put("NAME", NAME);
                    parameterMap.put("Q_KIND", "EP");
                    parameterMap.put("SRC_KEY", "");
                    //�z�LAPI���o����M�� "AI/doAccountLEVEL"
                    Map responseMap = doAPIPost(targetURL, parameterMap);

                    String LEVEL = "";
                    Integer result = MapUtils.getInteger(responseMap, "returnCode", 1);
                    if (result == 0) {
                        LEVEL = (String) MapUtils.getObject(responseMap, "detail", Collections.EMPTY_LIST);
                        log.debug("ID::" + ID + ",LEVEL::" + LEVEL);
                        //3���
                    }
                    log.fatal("<================�s�WDTEPZ400�Ȥ᭷�I������================>");
                    buds_insert_DTEPZ400.setField("CUSTOMER_ID", ID);
                    buds_insert_DTEPZ400.setField("CUSTOMER_NAME", NAME);
                    buds_insert_DTEPZ400.setField("RISK_LEVEL", LEVEL);
                    addBatchAndJoinGroup(buds_insert_DTEPZ400);
                }

                @Override
                protected void executeBatchProcess() throws Exception {
                    currentTime = DATE.currentTime();
                }

                @Override
                protected String formatErrorDetailMessage(Map errorDataMap) {
                    String ID = MapUtils.getString(errorDataMap, "ID");
                    String msg = sb.append("ID�G").append(ID).append("�A�s�WZ400���~").toString();

                    Map tempMap = new HashMap();
                    tempMap.put("PROC_NAME", PROGRAM);
                    tempMap.put("EXEC_TIME", currentTime);
                    tempMap.put("OTHER_ID", ID);
                    tempMap.put("MSG", msg);
                    log.fatal("���~��T:" + tempMap);
                    sb.setLength(0);
                    return msg;
                }

            });

        } catch (Exception e) {
            setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
            log.fatal("����ɵo�Ϳ��~", e);
        } finally {

            int batchConstructorExitCode = bc.getExitCode();
            if (batchConstructorExitCode != OK) {
                setExitCode(batchConstructorExitCode);
            }
            printExitCode(getExitCode());
        }
    }

    /**
     * HTTP POST�q��
     * @param url
     * @param ID
     * @return Map responseObj
     * @throws Exception 
     * @throws Exception
     */
    private Map doAPIPost(String url, Map parameterMap) throws Exception {

        try {
            HttpClientHelper httpClientHelper = new HttpClientHelper();
            Object responseObj = httpClientHelper.getHttpResponseByJSON(url, Collections.EMPTY_MAP, VOTool.toJSON(parameterMap),
                HttpResponseType.STRING, "UTF-8");
            if (isDebug) {
                log.debug("�o�e�ШD�� URL�G" + url);
                //�o�e�ШD�� URL�Ghttp://swas3.cathaylife.com.tw/ZSWeb/api/AI/doAccountLEVEL
                log.debug("�ϥΰѼơGparameterMap = " + parameterMap);
                //�ϥΰѼơGparameterMap = {NAME=�F��������, SRC_KEY=201809175315, Q_KIND=EP, ID=}
                log.debug("�o�쪺�^���G" + responseObj);
                //�o�쪺�^���G{"returnCode":"0","detail":"0","returnMsg":"API success"}
            }

            return VOTool.jsonToMap(responseObj.toString());
        } catch (Exception e) {
            log.fatal("�I�sAPI �o�ͨҥ~���~", e);
            throw e;
        }
    }
}
