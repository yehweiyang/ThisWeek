package com.cathay.ep.f1.module;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.ep.vo.DTEPF130;
import com.cathay.ep.vo.DTEPF150;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F120;
import com.cathay.ep.z0.module.EP_Z0F130;
import com.cathay.ep.z0.module.EP_Z0F150;
import com.cathay.ep.z0.module.EP_Z0F160;
import com.cathay.rz.n0.module.RZ_N00100;
import com.igsapp.db.DBException;

/**
 * Date Version Description Author
 * 2014/08/15  Created ����i 2014/08/15
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �߮׸���ˮּҲ�
 * �{���W��    EPF1_0101_mod.java
 * �@�~�覡    MODULE
 * ���n����    
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EPF1_0100_mod {

    private static final Logger log = Logger.getLogger(EPF1_0100_mod.class);

    /**
     * �ˮ֭�µ�ץ�O�_�i�ק�
     * @param APLY_NO
     * @throws Exception
     */
    public void chkChangeable(String APLY_NO, String SUB_CPY_ID) throws Exception {
        if (StringUtils.isBlank(APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0100_mod_MSG_001"));//�ǤJ�ץ�s������!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //���o��µ�ץ�򥻸����
        Map F110Map;
        try {
            F110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
            //�P�_�i�׬O�_�i�ק�

        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_002"));//�L����µ�ץ�s��!
        }
        String OP_STATUS = MapUtils.getString(F110Map, "OP_STATUS");
        if (!EP_Z0F110.ST_100.equals(OP_STATUS) && EP_Z0F110.ST_400.equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_003"));//��µ�ץ�i�׫D�߮׫ݰe��A���i�ק�
        }

    }

    /**
     * �ˮ֭�µ�ץ�y�{���A�O�_�i����
     * @param APLY_NO
     * @param approve
     * @param OP_STATUS �e���i��
     * @param chkOP_STATUS ����ɶi��
     * @throws Exception
     */
    public void chkApproveFlow(String APLY_NO, String approve, String chkOP_STATUS, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0100_mod_MSG_001")); //�ǤJ�ץ�s������!
        }
        if (StringUtils.isBlank(approve)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0100_mod_MSG_004")); //�ǤJ�ץ󪬺A����!
        }
        if (StringUtils.isBlank(chkOP_STATUS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0100_mod_MSG_003")); //�ǤJ�ץ�i�׬���!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        //�d�߭�µ�ץ�_�򥻸��
        Map F110Map;
        try {
            F110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);

        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_002"));//�L����µ�ץ�s��!
        }
        String OP_STATUS_Map = MapUtils.getString(F110Map, "OP_STATUS");

        if (!chkOP_STATUS.equals(OP_STATUS_Map)) {
            if (chkOP_STATUS.indexOf(OP_STATUS_Map) < 0) {
                throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_026"));//���ץ�@�~�i�צ��~���i���ʡA�Э��s�d�߫�A�i����!        		
            }
        }

        String APLY_TP = MapUtils.getString(F110Map, "APLY_TP");
        if (EP_Z0F110.ST_1.equals(approve)) {
            //�D�s�P��B�ݥ����禬(600)�i���ܫݵ����k��(700)
            if (!EP_Z0F110.ST_1.equals(APLY_TP) && EP_Z0F110.ST_600.equals(OP_STATUS_Map)) {
                //�ˮֶO�κ������]�w
                String EXP_TP = MapUtils.getString(F110Map, "EXP_TP");
                if (StringUtils.isBlank(EXP_TP)) {
                    throw new ModuleException(MessageUtil.getMessage("EP_Z0F110_MSG_013"));//�O�κ������i����!
                }
            }

            if (EP_Z0F110.ST_1.equals(APLY_TP) && EP_Z0F110.ST_100.equals(OP_STATUS_Map)) {
                // 1:�s�P�� 
                // 100:�߮׫ݰe��
                String SUP_ID = MapUtils.getString(F110Map, "SUP_ID");
                if (StringUtils.isBlank(SUP_ID)) {
                    throw new ModuleException(MessageUtil.getMessage("EP_Z0F110_MSG_010"));//�t�Ӹ�T���i����
                }
                BigDecimal CLR_AMT = NumberUtils.createBigDecimal(MapUtils.getString(F110Map, "CLR_AMT", "0"));
                BigDecimal ACT_AMT = NumberUtils.createBigDecimal(MapUtils.getString(F110Map, "ACT_AMT", "0"));
                BigDecimal TOT_AMT = CLR_AMT.add(ACT_AMT);

                String USE_TP = MapUtils.getString(F110Map, "USE_TP");
                BigDecimal checkTOT_AMT = STRING.objToBigDecimal(FieldOptionList.getName("EP", "LIMIT_TOT_AMT", USE_TP), null);//�ۥ�20000,�X���]��޵|18000
                log.debug("### checkTOT_AMT::" + checkTOT_AMT);
                if (checkTOT_AMT != null) {
                    if (TOT_AMT.compareTo(checkTOT_AMT) > 0) {
                        String BLD_CD = MapUtils.getString(F110Map, "BLD_CD");
                        List SG_BLD_CD = null;
                        try {
                            SG_BLD_CD = FieldOptionList.getAllOption("EP", "SG_BLD_CD");
                        } catch (Exception e) {
                            log.debug("���o�u���ְ��_�j�ӥN��(�s�P��µ����2�U������)�v����");
                        }
                        if (SG_BLD_CD == null || !SG_BLD_CD.contains(BLD_CD)) {
                            throw new ModuleException(MessageUtil.getMessage("EP_Z0F110_MSG_011", new Object[] {
                                    FieldOptionList.getName("EP", "USE_TP_F101", USE_TP), checkTOT_AMT }));//�s�P�ץ�({0}),���B���i�W�L{1}
                        } else {
                            log.debug("�����ְ��_�j�ӥN��,�s�P��µ����2�U������");
                        }

                    }
                }
            }
        }

    }

    /**
     * �ˮ֭�µ�ץ�O�_�i�T�{���u
     * @param APLY_NO
     * @param MEMO_NO
     * @param SUB_CPY_ID
     * @throws Exception 
     */
    public void chkFixFinal(String APLY_NO, String MEMO_NO, String SUB_CPY_ID) throws Exception {
        if (StringUtils.isBlank(APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0100_mod_MSG_001"));//�ǤJ�ץ�s������!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //�P�_�Ҧ��Ƨѿ����u�{�����O�_�Ҥw�w�ƬI�u
        //Ū����µ�ץ�_�Ƨѿ��ɲM��
        List<Map> rtnList = new EP_Z0F120().queryF120List(APLY_NO, SUB_CPY_ID);
        for (Map rtnMap : rtnList) {
            String OP_STATUS = MapUtils.getString(rtnMap, "OP_STATUS");
            if (!EP_Z0F110.ST_490.equals(OP_STATUS) && !EP_Z0F120.ST_499.equals(OP_STATUS)) {
                throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_014"));//�|���Ƨѿ����w�ƬI�u!
            }
        }
        EP_Z0F130 theEP_Z0F130 = new EP_Z0F130();
        DTEPF130 F130Vo = new DTEPF130();
        F130Vo.setAPLY_NO(APLY_NO);
        for (Map rtnMap : rtnList) {
            F130Vo.setMEMO_NO(MapUtils.getInteger(rtnMap, "MEMO_NO"));
            F130Vo.setSUB_CPY_ID(MapUtils.getString(rtnMap, "SUB_CPY_ID"));
            List<Map> DBF130VoList = theEP_Z0F130.queryF130List(F130Vo);
            //�v���P�_�u�{�����I�u���:
            for (Map DBF130Vo : DBF130VoList) {
                if (StringUtils.isEmpty(MapUtils.getString(DBF130Vo, "FINAL_DATE"))) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_027")); //�|���u�{���������u!
                }
            }
        }
    }

    /**
     * �ˮ֭�µ�ץ�O�_�i�����禬
     * @param APLY_NO
     * @throws Exception
     */
    public void chkSubUsr(String APLY_NO, String SUB_CPY_ID) throws Exception {
        if (StringUtils.isBlank(APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0100_mod_MSG_001"));//�ǤJ�ץ�s������!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //���o��µ�ץ�򥻸����
        Map F110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
        //�P�_�禬�Ӥ��O�_�w�W��
        if (StringUtils.isBlank(MapUtils.getString(F110Map, "FINAL_FILE_NO"))) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_015"));//���W���禬�Ӥ�!
        }
        String OP_STATUS = MapUtils.getString(F110Map, "OP_STATUS");
        if (!EP_Z0F110.ST_500.equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_009"));//���ץ�׫D�ݴ����禬�A�@�~�i�פ��i����!
        }

    }

    /**
     * �ˮ֭�µ�ץ�O�_�i�����k��
     * @param APLY_NO
     * @throws Exception
     */
    public void chkEndAply(String APLY_NO, String SUB_CPY_ID) throws Exception {
        if (StringUtils.isBlank(APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0100_mod_MSG_001"));//�ǤJ�ץ�s������!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //���o��µ�ץ�򥻸����
        Map F110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
        //String APLY_TP = MapUtils.getString(F110Map, "APLY_TP");
        //�P�_�O�_�w�дڮ־P
        List<Map> tmpList = new EP_Z0F160().qryChkList(APLY_NO, SUB_CPY_ID);
        StringBuilder sb = new StringBuilder();
        for (Map rtnMap : tmpList) {
            if (StringUtils.isBlank(MapUtils.getString(rtnMap, "PAY_CFM_DATE"))) {
                sb.append(",").append("�дڽs��:").append(MapUtils.getString(rtnMap, "PAY_CASE_NO"));
            }
        }
        if (sb.length() > 0) {

            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_016", new Object[] { sb.substring(1) }));//�ץ�дڮ־P�@�~�|������ �A{0}
        }
        //      20150610 �y�{�|���j���ˮ֥��n��J�������R��ơA���ץ����ˮ�
        //        if(!EP_Z0F110.ST_1.equals(APLY_TP)){
        //            //�P�_�O�_�w��g�������R
        //            //Ū����µ�ץ�_�������R�ɲM��
        //            DTEPF140 DTEPF140VO = new DTEPF140();
        //            DTEPF140VO.setSUB_CPY_ID(MapUtils.getString(F110Map, "SUB_CPY_ID"));
        //            DTEPF140VO.setAPLY_NO(APLY_NO);
        //            try {
        //                List<Map> mapList = new EP_Z0F140().queryF140List(DTEPF140VO);
        //                boolean isThrow = true;
        //                for (Map map : mapList) {
        //                    String PRT_NO = MapUtils.getString(map, "PRT_NO");
        //                    if (StringUtils.isNotBlank(PRT_NO)) {
        //                        isThrow = false;
        //                    }
        //                }
        //                if (isThrow) {
        //                    throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_017"));//�|����g�������R!
        //                }
        //            } catch (DataNotFoundException dnfe) {
        //                throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_017"));//�|����g�������R!
        //            }
        //        }
        //�P�_������O�_�w��g�M���
        if ("3".equals(MapUtils.getString(F110Map, "EXP_TP"))) {
            DTEPF150 DTEPF150VO = new DTEPF150();
            DTEPF150VO.setAPLY_NO(APLY_NO);
            DTEPF150VO.setSUB_CPY_ID(SUB_CPY_ID);
            try {
                new EP_Z0F150().queryF150List(DTEPF150VO);
            } catch (DataNotFoundException dnfe) {
                throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_018"));//�|����g�M���!
            }
        }

    }

    /**
     * �ˮ֭�µ�ץ�O�_�i�R��
     * @param APLY_NO
     * @throws Exception
     */
    public void chkDelete(String APLY_NO, String SUB_CPY_ID) throws Exception {
        if (StringUtils.isBlank(APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0100_mod_MSG_001"));//�ǤJ�ץ�s������!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //���o��µ�ץ�򥻸����
        Map F110Map;
        try {
            F110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
            //�P�_�i�׬O�_�i�ק�

        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_002"));//�L����µ�ץ�s��!
        }
        if (!EP_Z0F110.ST_100.equals(MapUtils.getString(F110Map, "OP_STATUS"))) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_019"));//��µ�ץ�i�׫D�߮׫ݰe��A���i�R��!
        }
    }

    /**
     * �ˮ֭�µ�ץ�O�_�i�P��
     * @param APLY_NO
     * @throws Exception
     */
    public void chkCancel(String APLY_NO, String SUB_CPY_ID) throws Exception {
        if (StringUtils.isBlank(APLY_NO)) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0100_mod_MSG_001"));//�ǤJ�ץ�s������!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        //���o��µ�ץ�򥻸����
        Map F110Map;
        try {
            F110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_002"));//�L����µ�ץ�s��!
        }
        //�P�_�i�׬O�_�i�ק�
        String OP_STATUS = MapUtils.getString(F110Map, "OP_STATUS");
        if (EP_Z0F110.ST_100.equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_020"));//��µ�ץ�i�׬��߮׫ݰe��A�Ъ����R���A���i�P��!             
        } else if (EP_Z0F110.ST_600.equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_021"));//��µ�ץ�w�����禬�A���i�P��!
        } else if (EP_Z0F110.ST_700.equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_022"));//��µ�ץ�w�����禬�A���i�P��!
        } else if (EP_Z0F110.ST_800.equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_023"));//��µ�ץ�w�����k�ɡA���i�P��!
        } else if ("000".equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_024"));//µ�ץ�w�P�סA���i�A�P��!
        }
    }

    /**
     * �ˮ֬O�_�w���д���F160
     * �Y���BPAY_DATE<>null:�L�k�h��,PAY_DATE=null:�R��F160
     * @param reqMap�GAPLY_NO,OP_STATUS(�h���e���A),RTN_STS(�h���᪬�A)
     * @return true:�ݧR��,false:���ݧR��
     * @throws ModuleException
     */
    public boolean chkF160(Map reqMap) throws ModuleException {
        String OP_STATUS = MapUtils.getString(reqMap, "OP_STATUS");
        String RTN_STS = MapUtils.getString(reqMap, "RTN_STS");

        //�h�����A��"�w���u(400)"
        if (OP_STATUS.compareTo(EP_Z0F110.ST_400) > 0 && RTN_STS.compareTo(EP_Z0F110.ST_400) <= 0) {
            List<Map> F160List;
            try {
                F160List = new EP_Z0F160().qryChkList(MapUtils.getString(reqMap, "APLY_NO"), MapUtils.getString(reqMap, "SUB_CPY_ID"));
            } catch (DataNotFoundException dnfe) {
                log.error("�d�L�дڮ־P��,���`");
                return false;
            }
            for (Map F160 : F160List) {
                if (StringUtils.isNotBlank(MapUtils.getString(F160, "PAY_DATE"))) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0100_mod_MSG_025"));//�Ӯץ�w�g�дڡA�Х��R���дڧ@�~�A�A�h��
                }
            }
            return true;//�ݧR��F160
        }
        return false;

    }

    /**
     * ���o��µ�ץ�ݿ�H���M��
     * @param APLY_NO
     * @param SUB_CPY_ID
     * @return true:�ݧR��,false:���ݧR��
     * @throws ModuleException
     */
    public List<Map<String, String>> getToDoList(String APLY_NO, String SUB_CPY_ID) throws ModuleException {
        List<Map<String, String>> rtnList = new ArrayList<Map<String, String>>();

        RZ_N00100 theRZ_N00100 = new RZ_N00100();
        EP_F10310 theEP_F10310 = new EP_F10310();
//        EP_E00010 theEP_E00010 = new EP_E00010();
        //���o��µ�ץ�
        Map f110Map = Collections.EMPTY_MAP;
        try {
            f110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
        } catch (DBException e) {
            log.fatal(e, e);
            throw new ModuleException("�d�ߥ߮׳楢��");
        } catch (SQLException e) {
            log.fatal(e, e);
            throw new ModuleException("�d�ߥ߮׳楢��");
        }
        log.debug("### DTEPF110:" + f110Map);

        //���o��µ�ץ�Ƨѿ��M��
        List<Map> f120List = new EP_Z0F120().queryF120List(APLY_NO, SUB_CPY_ID);
        log.debug("### f120List:" + f120List);

        Map todoMap = FieldOptionList.getFieldOptions("EP", "F0400_TODO_STS");
        log.debug("### todoMap:" + todoMap);

        for (Object key : todoMap.keySet()) {
            String aplyTpRoleTp = key.toString();
            String[] todoType = StringUtils.split(aplyTpRoleTp, "_");
            String opType = todoType[0];
            String roleTp = todoType[1];
            String toDoStatus = MapUtils.getString(todoMap, key);
            String APLY_TP = MapUtils.getString(f110Map, "APLY_TP");

            log.debug("### roleTp:" + roleTp);
            if ("F110".equals(opType)) {
                String f110OpStatus = MapUtils.getString(f110Map, "OP_STATUS");

                if (toDoStatus.indexOf(f110OpStatus) >= 0) {

                    String OP_STATUS_NM;
                    if ("1".equals(APLY_TP)) {
                        OP_STATUS_NM = theRZ_N00100.queryStatusNM("EPF1_0100", f110OpStatus);
                    } else {
                        OP_STATUS_NM = theRZ_N00100.queryStatusNM("EPF1_0200", f110OpStatus);
                    }
                    Map<String, String> data = new HashMap<String, String>();
                    data.put("OP_TYPE_NM", FieldOptionList.getName("EP", "TODO_OP_TYPE", opType));
                    data.put("OP_STATUS_NM", OP_STATUS_NM);
                    //�]�w�ݳB�z�H����T
                    setEmpInfo(theEP_F10310, f110Map, roleTp, data, SUB_CPY_ID);
                    roleTp = MapUtils.getString(data, "roleTp", roleTp);
                    data.put("ROLE_NM", FieldOptionList.getName("EP", "TODO_ROLE_TYPE", roleTp));
                    rtnList.add(data);
                }
            } else if ("F120".equals(opType)) {
                for (Map f120Map : f120List) {
                    String f120OpStatus = MapUtils.getString(f120Map, "OP_STATUS");
                    if (StringUtils.isBlank(f120OpStatus)) {
                        continue;
                    }

                    if (toDoStatus.indexOf(f120OpStatus) >= 0) {
                        Map<String, String> data = new HashMap<String, String>();
                        data.put("OP_TYPE_NM", FieldOptionList.getName("EP", "TODO_OP_TYPE", opType));
                        data.put("ROLE_NM", FieldOptionList.getName("EP", "TODO_ROLE_TYPE", roleTp));
                        String OP_STATUS_NM;
                        if ("2".equals(APLY_TP)) {
                            OP_STATUS_NM = theRZ_N00100.queryStatusNM("EPF1_0240", f120OpStatus);
                        } else {
                            OP_STATUS_NM = theRZ_N00100.queryStatusNM("EPF1_0340", f120OpStatus);
                        }
                        data.put("OP_STATUS_NM", OP_STATUS_NM);
                        //�]�w�ݳB�z�H����T
                        if ("8".equals(roleTp)) {
                            setEmpInfo(theEP_F10310, f120Map, roleTp, data, SUB_CPY_ID);
                        } else {
                            setEmpInfo(theEP_F10310, f110Map, roleTp, data, SUB_CPY_ID);
                        }

                        rtnList.add(data);
                    }

                }

            }

        }

        return rtnList;

    }

    private void setEmpInfo(EP_F10310 theEP_F10310, Map f110Map, String roleTp, Map<String, String> data, String SUB_CPY_ID)
            throws ModuleException {
        Map emp = theEP_F10310.getEmpData(f110Map, roleTp, SUB_CPY_ID);
        if ("3".equals(roleTp) && emp.isEmpty()) {//FIX_DIV_ID����>��µ�쥼����
            data.put("roleTp", "2");
        }
        data.put("INSTITUTION_PHONE", MapUtils.getString(emp, "INSTITUTION_PHONE", ""));
        data.put("NAME", MapUtils.getString(emp, "NAME", ""));
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
