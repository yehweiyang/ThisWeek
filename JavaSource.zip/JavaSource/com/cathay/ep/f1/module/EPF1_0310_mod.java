package com.cathay.ep.f1.module;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.dk.bo.DTDKM001;
import com.cathay.dk.m0.module.DK_M0Z002;
import com.cathay.ep.z0.module.EP_Z0F180;

/**
 * <pre>
 * DATE Description Author
 * 2015/12/22 Created ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��޵|�ˮּҲ�
 * �Ҳ�ID      EPZ0_F180_mod
 * ���n����    ��޵|�ˮּҲ�
 * </pre>
 * @author �d�ÿ�
 * @since 2015/01/12
 */
@SuppressWarnings("unchecked")
public class EPF1_0310_mod {

    /**
     * �ˮ���޶O�뵲�T�{
     * @param reqList
     * @throws ModuleException
     */
    public void chkConfirm(List<Map> reqList) throws ModuleException {

        if (reqList == null || reqList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_001")); // �ǤJ�ѼƤ��i����
        }

        // �ˮ֭�µ�ץ󪬺A�O�_�Ҥw���ץB���뵲
        StringBuilder tmpAPLY_NO = new StringBuilder();
        for (Map reqMap : reqList) {
            if (!"800".equals(MapUtils.getString(reqMap, "OP_STATUS")) || reqMap.get("CMM_APLY_NO") != null) {
                tmpAPLY_NO.append(reqMap.get("APLY_NO")).append(',');
            }
        }
        if (tmpAPLY_NO.length() > 0) {
            tmpAPLY_NO.setLength(tmpAPLY_NO.length() - 1);
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_002", new Object[] { tmpAPLY_NO.toString() })); // ��µ�ץ�{0}�ݤw���ץB�|���뵲
        }
    }

    /**
     * �ˮ���޶O�뵲�T�{
     * @param reqList
     * @param rtnList
     * @throws ModuleException
     */
    public void chkConfirm1(List<Map> reqList, List<Map> rtnList) throws ModuleException {

        if (reqList == null || reqList.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_001")); // �ǤJ�ѼƤ��i����
        }

        BigDecimal TOT_CMM_FEE = BigDecimal.ZERO;
        BigDecimal CMM_RATE = STRING.objToBigDecimal(FieldOptionList.getName("EP", "CMM_SET", "CMM_RATE"), BigDecimal.ZERO);
        BigDecimal CMM_MAX = STRING.objToBigDecimal(FieldOptionList.getName("EP", "CMM_SET", "CMM_MAX"), BigDecimal.ZERO);
        // �ˮ֭�µ�ץ󪬺A�O�_�Ҥw���ץB���뵲
        StringBuilder tmpAPLY_NO = new StringBuilder();
        for (Map reqMap : reqList) {
            if (!"800".equals(MapUtils.getString(reqMap, "OP_STATUS")) || reqMap.get("CMM_APLY_NO") != null) {
                tmpAPLY_NO.append(reqMap.get("APLY_NO")).append(',');
            }
            BigDecimal CLR_AMT = STRING.objToBigDecimal(reqMap.get("CLR_AMT"), BigDecimal.ZERO);
            BigDecimal CMM_FEE = CLR_AMT.multiply(CMM_RATE).setScale(0, BigDecimal.ROUND_HALF_UP);
            TOT_CMM_FEE = TOT_CMM_FEE.add(CMM_FEE); // ��޶O���B
        }

        for (Map reqMap : rtnList) {
            BigDecimal dbTOT_CMM_FEE = STRING.objToBigDecimal(reqMap.get("TOT_CMM_FEE"), BigDecimal.ZERO);
            TOT_CMM_FEE = TOT_CMM_FEE.add(dbTOT_CMM_FEE); // ��޶O���B
        }

        if (TOT_CMM_FEE.compareTo(CMM_MAX) > 0) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_011")); // ��޶O�ӽФ��i�W�L22�U
        }
    }

    /**
     * �ˮ֨����T�{
     * @param reqMap
     * @throws ModuleException
     */
    public void chkCancelConfirm(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_001")); // �ǤJ�ѼƤ��i����
        }

        // �ˮ֤뵲�O���O�_�w�д�
        Map F180Map = new EP_Z0F180().queryByPK(MapUtils.getString(reqMap, "CMM_APLY_NO"), MapUtils.getString(reqMap, "SUB_CPY_ID"));
        if (F180Map.get("PAY_DATE") != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_003")); // �뵲�O���w�дڡA���i�����T�{
        }
    }

    /**
     * �ˮ���޶O�д�
     * @param reqMap
     * @throws ModuleException
     */
    public void chkPay(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_001")); // �ǤJ�ѼƤ��i����
        }

        // �ˮ֤뵲�O���O�_�w�д�
        Map F180Map = new EP_Z0F180().queryByPK(MapUtils.getString(reqMap, "CMM_APLY_NO"), MapUtils.getString(reqMap, "SUB_CPY_ID"));
        if (F180Map.get("PAY_DATE") != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_004")); // �뵲�O���w�д�
        }
    }

    /**
     * �ˮ���޶O�����д�
     * @param reqMap
     * @throws ModuleException
     */
    public void chkCanclePay(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_001")); // �ǤJ�ѼƤ��i����
        }

        // �ˮ֤뵲�O���O�_�w�д�
        Map F180Map = new EP_Z0F180().queryByPK(MapUtils.getString(reqMap, "CMM_APLY_NO"), MapUtils.getString(reqMap, "SUB_CPY_ID"));
        if (F180Map.get("PAY_CFM_DATE") != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_005")); // �뵲�O���w�дڽT�{�A���i�����д�
        }

        // DK���A�� 0,X�άd�����ƮɤW��~�i�H����
        try {
            List<DTDKM001> DKM001List = new DK_M0Z002().query1DKM001("2", null, MapUtils.getString(F180Map, "CASE_NO"), null, null);
            for (DTDKM001 DKM001 : DKM001List) {
                String AUD_STS = DKM001.getAUD_STS();
                if (!("0".equals(AUD_STS) || "X".equals(AUD_STS))) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_006", new Object[] { MapUtils.getString(
                        F180Map, "CASE_NO") })); // ���дڮ־P�|�p�|���@�~�����A�L�k�����G{0}
                }
            }
        } catch (DataNotFoundException dnfe) {
        }
    }

    /**
     * �ˮ���޶O�дڽT�{
     * @param reqMap
     * @return 
     * @throws ModuleException
     */
    public String chkPayConfirm(Map reqMap) throws ModuleException {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_001")); // �ǤJ�ѼƤ��i����
        }

        // �ˮ֤뵲�O���O�_�w�д�
        Map F180Map = new EP_Z0F180().queryByPK(MapUtils.getString(reqMap, "CMM_APLY_NO"), MapUtils.getString(reqMap, "SUB_CPY_ID"));
        if (F180Map.get("PAY_CFM_DATE") != null) {
            throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_007")); // �뵲�O���w�дڽT�{
        }

        // �ˮ�DK�дڮ־P�ץ󪬺A
        List<DTDKM001> DKM001List = null;
        try {
            DKM001List = new DK_M0Z002().query1DKM001("2", null, MapUtils.getString(F180Map, "CASE_NO"), null, null);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0310_mod_MSG_008")); // �L���дڮ־P���
        }
        String ACC_SECVER_DATE = "";
        for (DTDKM001 DKM001 : DKM001List) {
            if (!"A".equals(DKM001.getAUD_STS())) {
                throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_009", new Object[] { MapUtils.getString(F180Map,
                    "CASE_NO") })); // ���дڮ־P�|�p�|���@�~�����A�|�p�ץ�s���G{0}
            }
            ACC_SECVER_DATE = DKM001.getACC_SECVER_DATE();
            if (StringUtils.isBlank(ACC_SECVER_DATE)) {
                throw new ErrorInputException(MessageUtil.getMessage("EPF1_0310_mod_MSG_010", new Object[] { MapUtils.getString(F180Map,
                    "CASE_NO") })); // �дڰO���s��({0})�L�|�p�Ю֤��
            }
        }
        return ACC_SECVER_DATE;
    }
}
