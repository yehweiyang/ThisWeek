package com.cathay.ep.f1.module;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.EmployeeDetail;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F120;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * ���~/����    UCEP_F10500_��µ��X�d�߼Ҳ�    
 * ��Ʈw����   DB2
 * ���@�� ��ڸ�T��   �t�d�H ����i
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EP_F10500 {

    private static final String ST_3 = "3";

    private static final String ST_2 = "2";

    private static final String ST_1 = "1";

    private static final String SQL_queryList_001 = "com.cathay.ep.f1.module.EP_F10500.SQL_queryList_001";

    private static final String SQL_queryforCLR_AMT_001 = "com.cathay.ep.f1.module.EP_F10500.SQL_queryforCLR_AMT_001";

    /* private static final String SQL_update_001 = "com.cathay.ep.f1.module.EP_F10500.SQL_update_001";
    UPDATE DBEP.DTEPF110
    SET OP_STATUS=':OP_STATUS'
    WHERE APLY_NO=':APLY_NO'*/

    /* private static final String SQL_update_002 = "com.cathay.ep.f1.module.EP_F10500.SQL_update_002";
      UPDATE DBEP.DTEPF120
    SET OP_STATUS=':OP_STATUS'
    WHERE APLY_NO=':APLY_NO'
    and MEMO_NO=':MEMO_NO'*/

    /**
     * ��µ��X�d��
     * @param BLD_CD
     * @param APLY_NO
     * @param APLY_TP
     * @param OP_STATUS
     * @param EXP_TP
     * @param INPUT_DATES
     * @param INPUT_DATEE
     * @param END_APLY_DATES
     * @param END_APLY_DATEE
     * @return
     * @throws Exception 
     */
    public List<Map> queryList(Map reqMap) throws Exception {
        /*if (StringUtils.isBlank(APLY_TP)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_F10500_MSG_001"));//�ǤJ�ץ�������i����
        }*/
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        if (StringUtils.isNotBlank(APLY_NO) && APLY_NO.length() == 6) {
            APLY_NO = APLY_NO + "%";
        }
        String APLY_TP = MapUtils.getString(reqMap, "APLY_TP");
        String OP_STATUS = MapUtils.getString(reqMap, "OP_STATUS");
        String FIX_DIV_ID = MapUtils.getString(reqMap, "FIX_DIV_ID");
        String EXP_TP = MapUtils.getString(reqMap, "EXP_TP");
        String USE_TP = MapUtils.getString(reqMap, "USE_TP");
        String INPUT_DATES = MapUtils.getString(reqMap, "INPUT_DATES");
        String INPUT_DATEE = MapUtils.getString(reqMap, "INPUT_DATEE");
        String END_APLY_DATES = MapUtils.getString(reqMap, "END_APLY_DATES");
        String END_APLY_DATEE = MapUtils.getString(reqMap, "END_APLY_DATEE");
        String DIV_CFM_DATES = MapUtils.getString(reqMap, "DIV_CFM_DATES");
        String DIV_CFM_DATEE = MapUtils.getString(reqMap, "DIV_CFM_DATEE");
        String INFM_CONS_DATES = MapUtils.getString(reqMap, "INFM_CONS_DATES");
        String INFM_CONS_DATEE = MapUtils.getString(reqMap, "INFM_CONS_DATEE");
        String PRE_CONS_DATES = MapUtils.getString(reqMap, "PRE_CONS_DATES");
        String PRE_CONS_DATEE = MapUtils.getString(reqMap, "PRE_CONS_DATEE");
        String CLOSE_DATES = MapUtils.getString(reqMap, "CLOSE_DATES");
        String CLOSE_DATEE = MapUtils.getString(reqMap, "CLOSE_DATEE");

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        String SIGN = MapUtils.getString(reqMap, "SIGN");
        if (StringUtils.isNotBlank(SIGN)) {
            if (ST_1.equals(SIGN)) {
                ds.setField("SIGN_1", ST_1);
            } else if (ST_2.equals(SIGN)) {
                ds.setField("SIGN_2", ST_1);
            } else if (ST_3.equals(SIGN)) {
                ds.setField("SIGN_3", ST_1);
            }
            ds.setField("CLR_AMT", reqMap.get("CLR_AMT"));
        }
        String APLY_NO_STATUS = MapUtils.getString(reqMap, "APLY_NO_STATUS");
        if (StringUtils.isNotBlank(APLY_NO_STATUS)) {
            if (ST_1.equals(APLY_NO_STATUS)) {
                ds.setField("APLY_NO_STATUS_1", ST_1);
            } else if (ST_2.equals(APLY_NO_STATUS)) {
                ds.setField("APLY_NO_STATUS_2", ST_1);
            }
        }

        setFieldValuesIfExist(ds, "APLY_TP", APLY_TP);
        setFieldIfExist(ds, "BLD_CD", BLD_CD);
        setFieldIfExist(ds, "APLY_NO", APLY_NO);
        setFieldIfExist(ds, "OP_STATUS", OP_STATUS);
        setFieldIfExist(ds, "EXP_TP", EXP_TP);
        setFieldIfExist(ds, "USE_TP", USE_TP);
        setFieldIfExist(ds, "INPUT_DATES", INPUT_DATES);
        setFieldIfExist(ds, "INPUT_DATEE", INPUT_DATEE);
        setFieldIfExist(ds, "END_APLY_DATES", END_APLY_DATES);
        setFieldIfExist(ds, "END_APLY_DATEE", END_APLY_DATEE);
        setFieldIfExist(ds, "FIX_DIV_ID", FIX_DIV_ID);
        if (StringUtils.isBlank(APLY_TP)) {
            setFieldIfExist(ds, "DIV_CFM_DATES", DIV_CFM_DATES);
            setFieldIfExist(ds, "DIV_CFM_DATEE", DIV_CFM_DATEE);
            setFieldIfExist(ds, "INFM_CONS_DATES", INFM_CONS_DATES);
            setFieldIfExist(ds, "INFM_CONS_DATEE", INFM_CONS_DATEE);
        } else if (EP_Z0F110.ST_1.equals(APLY_TP)) {
            setFieldIfExist(ds, "DIV_CFM_DATES_1", DIV_CFM_DATES);
            setFieldIfExist(ds, "DIV_CFM_DATEE_1", DIV_CFM_DATEE);
            setFieldIfExist(ds, "INFM_CONS_DATES_1", INFM_CONS_DATES);
            setFieldIfExist(ds, "INFM_CONS_DATEE_1", INFM_CONS_DATEE);
        } else if (!EP_Z0F110.ST_1.equals(APLY_TP)) {
            setFieldIfExist(ds, "DIV_CFM_DATES_2", DIV_CFM_DATES);
            setFieldIfExist(ds, "DIV_CFM_DATEE_2", DIV_CFM_DATEE);
            setFieldIfExist(ds, "INFM_CONS_DATES_2", INFM_CONS_DATES);
            setFieldIfExist(ds, "INFM_CONS_DATEE_2", INFM_CONS_DATEE);
        }
        setFieldIfExist(ds, "PRE_CONS_DATES", PRE_CONS_DATES);
        setFieldIfExist(ds, "PRE_CONS_DATEE", PRE_CONS_DATEE);

        if (StringUtils.isNotBlank(CLOSE_DATES) && StringUtils.isNotBlank(CLOSE_DATEE)) {//�P�פ��
            ds.setField("CLOSE_OP_STATUS", "000");
            ds.setField("CLOSE_DATES", CLOSE_DATES);
            ds.setField("CLOSE_DATEE", CLOSE_DATEE);
        }

        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);
        PersonnelData pd = new PersonnelData();
        EP_F10310 theEP_F10310 = new EP_F10310();
        EP_Z0F110 theEP_Z0F110 = new EP_Z0F110();
        EP_Z0F120 theEP_Z0F120 = new EP_Z0F120();

        for (Map rtnMap : rtnList) {
            //�ץ����
            rtnMap.put("APLY_TP_NM", FieldOptionList.getName("EP", "APLY_TP_F101", MapUtils.getString(rtnMap, "APLY_TP")));
            //�ϥΪ��p����
            rtnMap.put("USE_TP_NM", FieldOptionList.getName("EP", "USE_TP_F101", MapUtils.getString(rtnMap, "USE_TP")));
            //�O�κ���
            rtnMap.put("EXP_TP_NM", FieldOptionList.getName("EP", "EXP_TP_F101", MapUtils.getString(rtnMap, "EXP_TP")));

            //��µ��H��
            String rtn_FIX_DIV_ID = MapUtils.getString(rtnMap, "FIX_DIV_ID");
            if (StringUtils.isNotBlank(rtn_FIX_DIV_ID)) {
                String FIX_DIV_NM = MapUtils.getString(rtnMap, "FIX_DIV_NM");
                if (StringUtils.isEmpty(FIX_DIV_NM)) {
                    EmployeeDetail ep = pd.getByEmployeeID2(rtn_FIX_DIV_ID);
                    if (ep != null) {
                        FIX_DIV_NM = ep.getName();
                    } else {
                        FIX_DIV_NM = "";
                    }
                }
                rtnMap.put("FIX_DIV_NM", FIX_DIV_NM);
            }

            //��µ�դH��
            String FIX_GROUP_ID = MapUtils.getString(rtnMap, "FIX_GROUP_ID");
            if (StringUtils.isNotBlank(FIX_GROUP_ID)) {
                String FIX_GROUP_NM = MapUtils.getString(rtnMap, "FIX_GROUP_NM");
                if (StringUtils.isEmpty(FIX_GROUP_NM)) {
                    try {
                        FIX_GROUP_NM = MapUtils.getString(theEP_F10310.getEmpMap(FIX_GROUP_ID, true, SUB_CPY_ID), "NAME");
                    } catch (Exception e) {
                        FIX_GROUP_NM = "�L���H��";
                    }
                }
                rtnMap.put("FIX_GROUP_NM", FIX_GROUP_NM);
            }
            //�o�]�դH��
            String SUBCON_GROUP_ID = MapUtils.getString(rtnMap, "SUBCON_GROUP_ID");
            if (StringUtils.isNotBlank(SUBCON_GROUP_ID)) {
                String SUBCON_GROUP_NM = MapUtils.getString(rtnMap, "SUBCON_GROUP_NM");
                if (StringUtils.isEmpty(SUBCON_GROUP_NM)) {
                    try {
                        SUBCON_GROUP_NM = MapUtils.getString(theEP_F10310.getEmpMap(SUBCON_GROUP_ID, true, SUB_CPY_ID), "NAME");
                    } catch (Exception e) {
                        SUBCON_GROUP_NM = "�L���H��";
                    }
                }
                rtnMap.put("SUBCON_GROUP_NM", SUBCON_GROUP_NM);
            }
            //�@�~�H��
            String LST_PROC_NM = MapUtils.getString(rtnMap, "LST_PROC_NM");
            if (StringUtils.isEmpty(LST_PROC_NM)) {
                if (MapUtils.getString(rtnMap, "LST_PROC_DIV", "").startsWith("EP9")) {
                    try {
                        rtnMap.put("LST_PROC_NM", theEP_F10310.getEmpMap(MapUtils.getString(rtnMap, "LST_PROC_ID"), true, SUB_CPY_ID).get(
                            "NAME"));
                    } catch (DataNotFoundException e) {
                        rtnMap.put("LST_PROC_NM", "�L���H��");
                    }
                } else {
                    EmployeeDetail ep = pd.getByEmployeeID2(MapUtils.getString(rtnMap, "LST_PROC_ID"));
                    if (ep != null) {
                        rtnMap.put("LST_PROC_NM", ep.getName());
                    } else {
                        rtnMap.put("LST_PROC_NM", "");
                    }
                }
            } else {
                rtnMap.put("LST_PROC_NM", LST_PROC_NM);
            }

            //�@�~�i��
            theEP_Z0F120.setOP_STATUS_NM(rtnMap);
            //�t�ӦW��
            theEP_Z0F110.setSUP_NM(rtnMap);

        }
        return rtnList;
    }

    /**
     * 
     * @param SUB_CPY_ID
     * @param BEG_DATE
     * @param END_DATE
     * @return
     * @throws ModuleException
     */
    public Map queryforCLR_AMT(String SUB_CPY_ID, String BEG_DATE, String END_DATE) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10500_MSG_005"));//�ǤJ�����q�O���i����
        }
        if (StringUtils.isBlank(BEG_DATE)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10500_MSG_006"));//�ǤJ�}�l�餣�i����
        }
        if (StringUtils.isBlank(END_DATE)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10500_MSG_007"));//�ǤJ�����餣�i����
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BEG_DATE", BEG_DATE);
        ds.setField("END_DATE", END_DATE);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryforCLR_AMT_001);
        Map rtnMap = new HashMap();
        for (Map tmpMap : rtnList) {
            rtnMap.put(tmpMap.get("BLD_CD"), tmpMap.get("CLR_AMT"));
        }
        return rtnMap;
    }

    /**
     * ���P�ץ�
     * @param APLY_NO
     * @param MEMO_NO
     * @param OP_STATUS
     * @throws ModuleException
     */
    /*public void update(String APLY_NO, String MEMO_NO, String OP_STATUS) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10500_MSG_002"));//�ǤJ�ץ�s�����i����
        }
        if (StringUtils.isBlank(MEMO_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10500_MSG_003"));//�ǤJ�Ƨѿ��渹���i����
        }
        if (StringUtils.isBlank(OP_STATUS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10500_MSG_004"));//�ǤJ�ץ󪬺A���i����
        }
        if (eie != null) {
            throw eie;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("OP_STATUS", OP_STATUS);//�P�׬�000
        DBUtil.executeUpdate(ds, SQL_update_001);

        ds.clear();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("MEMO_NO", MEMO_NO);
        ds.setField("OP_STATUS", OP_STATUS);//�P�׬�000
        DBUtil.executeUpdate(ds, SQL_update_002);
    }
    */
    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {

        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldValuesIfExist(DataSet ds, String key, String value) {

        if (StringUtils.isNotBlank(value)) {
            ds.setFieldValues(key, value.split(","));
        }
    }
}
