package com.cathay.ep.f1.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPF191;
import com.cathay.ep.z0.module.EP_Z0F160;
import com.cathay.ep.z0.module.EP_Z0F190;
import com.cathay.ep.z0.module.EP_Z0F191;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �@�B   �{���\�෧�n����
 * �ҲզW�� �j�ӳ]�ƺ��װO���d�߼Ҳ�
 * �Ҳ�ID EP_F10901
 * ���n���� �j�ӳ]�ƺ��װO���d�߼Ҳ�(�ݨϥΦh��y�t��)
 * 
 * �G�B   �ϥ��ɮסG
 * 1.�j�ӳ]�Ƴ]�w�� DTEPF190 
 * 2.�j�ӳ]�ƺ��װO����DTEPF191 
 * 
 * �T�B   �ϥμҲաG
 * �j�ӳ]�Ƴ]�w��SQL�@�μҲ�   EP_Z0F191
 * 
 * @author 
 * @since 2019-05-24
 * </pre>
 */
@SuppressWarnings({ "unchecked" })
public class EP_F10901 {
    
    private static final String SQL_query_001 = "com.cathay.ep.f1.module.EP_F10901.SQL_query_001";
    
    private static final String SQL_queryDTEPF191byAplyNo_001 = "com.cathay.ep.f1.module.EP_F10901.SQL_queryDTEPF191byAplyNo_001";

    /**
     * �d�ߤj�ӳ]�ƺ��װO�����(by EQP_ID)
     * @param EQP_ID
     * @param SUB_CPY_ID
     * @return rtnList
     * @throws ModuleException 
     */

    public List<Map> query(String EQP_ID, String SUB_CPY_ID) throws ModuleException {
        
        ErrorInputException eie = null;
        
        if (StringUtils.isBlank(EQP_ID)) {
            eie = getEie(eie, MessageUtil.getMessage("EP_F10901_MSG_001")); //�]�ƽs�����o����
        }
        
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, MessageUtil.getMessage("EP_F10901_MSG_002")); //�����q�O���o����
        }
        
        if (eie != null) {
            throw eie;
        }
        
        DataSet ds = Transaction.getDataSet();
        ds.setField("EQP_ID", EQP_ID);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        
        DBUtil.searchAndRetrieve(ds, SQL_query_001);
        
        StringBuilder sb = new StringBuilder();
        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            
            //���o�]�ƺ���(�j��)����
            String D_EQP_CD = MapUtils.getString(rtnMap, "EQP_CD");
            String D_EQP_CD_NM = FieldOptionList.getName("EP", "EQP_CD", D_EQP_CD);

            //���o�]�ƺ���(����)����
            String D_SUB_EQP_CD = MapUtils.getString(rtnMap, "SUB_EQP_CD");
            String D_SUB_EQP_CD_NM = "";
            if ("1".equals(D_EQP_CD)) { //����]��
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F901", D_SUB_EQP_CD);
            } else if ("2".equals(D_EQP_CD)) { //�q��
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F902", D_SUB_EQP_CD);
            } else if ("3".equals(D_EQP_CD)) { //�Ž�
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F903", D_SUB_EQP_CD);
            } else if ("4".equals(D_EQP_CD)) { //���Ƥ��νå�
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F904", D_SUB_EQP_CD);
            } else if ("5".equals(D_EQP_CD)) { //�����Τ����z�q
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F905", D_SUB_EQP_CD);
            }

            //���o�]�ƺ����G�]�ƺ���(�j��)���� + �]�ƺ���(����)���� + �]�ƺ���(�W��X)
            String D_CODE = MapUtils.getString(rtnMap, "CODE");
            String EQP_CD_NM = sb.append(D_EQP_CD_NM).append("(").append(D_SUB_EQP_CD_NM).append(D_CODE).append(")").toString();
            sb.setLength(0);
            
            rtnMap.put("EQP_CD_NM", EQP_CD_NM);

            rtnList.add(rtnMap);
        }
        return rtnList;
    }
    
    /**
     * �d�ߤj�ӳ]�ƺ��װO�����(by APLY_NO)
     * @param APLY_NO
     * @param SUB_CPY_ID
     * @return rtnList
     * @throws ModuleException 
     */

    public List<Map> queryDTEPF191byAplyNo(String APLY_NO, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        
        if (StringUtils.isBlank(APLY_NO)) {
            eie = getEie(eie, MessageUtil.getMessage("EP_F10901_MSG_003")); //�ץ�s�����o����
        }
        
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, MessageUtil.getMessage("EP_F10901_MSG_002")); //�����q�O���o����
        }
        
        if (eie != null) {
            throw eie;
        }
        
        DataSet ds = Transaction.getDataSet();
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        
        DBUtil.searchAndRetrieve(ds, SQL_queryDTEPF191byAplyNo_001);
        
        StringBuilder sb = new StringBuilder();
        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);

            //���o�]�ƺ���(�j��)����
            String D_EQP_CD = MapUtils.getString(rtnMap, "EQP_CD");
            String D_EQP_CD_NM = FieldOptionList.getName("EP", "EQP_CD", D_EQP_CD);

            //���o�]�ƺ���(����)����
            String D_SUB_EQP_CD = MapUtils.getString(rtnMap, "SUB_EQP_CD");
            String D_SUB_EQP_CD_NM = "";
            if ("1".equals(D_EQP_CD)) { //����]��
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F901", D_SUB_EQP_CD);
            } else if ("2".equals(D_EQP_CD)) { //�q��
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F902", D_SUB_EQP_CD);
            } else if ("3".equals(D_EQP_CD)) { //�Ž�
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F903", D_SUB_EQP_CD);
            } else if ("4".equals(D_EQP_CD)) { //���Ƥ��νå�
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F904", D_SUB_EQP_CD);
            } else if ("5".equals(D_EQP_CD)) { //�����Τ����z�q
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F905", D_SUB_EQP_CD);
            }

            //���o�]�ƺ����G�]�ƺ���(�j��)���� + �]�ƺ���(����)���� + �]�ƺ���(�W��X)
            String D_CODE = MapUtils.getString(rtnMap, "CODE");
            String EQP_CD_NM = sb.append(D_EQP_CD_NM).append("(").append(D_SUB_EQP_CD_NM).append(D_CODE).append(")").toString();
            sb.setLength(0);
            
            rtnMap.put("EQP_CD_NM", EQP_CD_NM);

            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * �s�W�j�ӳ]�ƺ��װO�����
     * @param reqMap
     * @return
     * @throws Exception
     */

    public void insert(Map reqMap, boolean isInsertNewData) throws Exception {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_F10901_MSG_004")); //�ǤJ�ѼƤ��o����
        }

        DTEPF191 F191VO = new DTEPF191();
        
        if (isInsertNewData) {
            
            ErrorInputException eie = null;
            
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            if (StringUtils.isBlank(APLY_NO)) {
                eie = getEie(eie, MessageUtil.getMessage("EP_F10901_MSG_003")); //�ץ�s�����o����
            }
            
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getEie(eie, MessageUtil.getMessage("EP_F10901_MSG_002")); //�����q�O���o����
            }
            
            if (eie != null) {
                throw eie;
            }
            
            //���o�]�ƽs��
            String EQP_ID;
            try {
                EQP_ID = new EP_Z0F190().queryEqpId(reqMap);
            } catch (DataNotFoundException dnfe) {
                //�d�L�]�ƽs���A�Х��ܳ]�Ƽi���d�߷s�W�]�Ƹ�Ʃ���
                throw new ErrorInputException(MessageUtil.getMessage("EP_F10901_MSG_006"));
            }
            
            //���o��µ���e
            String FIX_MO = MapUtils.getString(reqMap, "FIX_MO");
            String MEMO = StringUtils.isNotBlank(FIX_MO) ? FIX_MO : "";
            
            //���o�дڪ��B
            BigDecimal FIX_AMT = BigDecimal.ZERO;
            try {
                List<Map> F160List = new EP_Z0F160().qryChkList(APLY_NO, SUB_CPY_ID);
                for (Map F160Map : F160List) {
                    String TAX_TP = MapUtils.getString(F160Map, "TAX_TP");
                    if ("2".equals(TAX_TP)) {
                        //�|�O�A 2:�~�[ (���|)
                        FIX_AMT = FIX_AMT.add(STRING.objToBigDecimal(F160Map.get("PAY_AMT"), BigDecimal.ZERO).add(
                            STRING.objToBigDecimal(F160Map.get("TAX_AMT"), BigDecimal.ZERO)));
                    } else if ("1".equals(TAX_TP)) {
                        //�|�O�A1:���t (�t�|)
                        FIX_AMT = FIX_AMT.add(STRING.objToBigDecimal(F160Map.get("PAY_AMT"), BigDecimal.ZERO));
                    }
                }
            } catch (DataNotFoundException dnfe) {
                //�d�L��Ƶ������`
            }
            
            //���o�y����
            int SerNo = new EP_Z0F191().queryDTEPF191MaxSerNo(reqMap);
            
            F191VO.setEQP_ID(EQP_ID);
            F191VO.setSUB_CPY_ID(SUB_CPY_ID);
            F191VO.setAPLY_NO(APLY_NO);
            F191VO.setSER_NO(SerNo + 1);
            F191VO.setMEMO(MEMO);
            F191VO.setFIX_AMT(FIX_AMT);
            F191VO.setFIX_DATE(null);
            
        } else {
            
            ErrorInputException eie = null;
            
            String EQP_ID = MapUtils.getString(reqMap, "EQP_ID");
            if (StringUtils.isBlank(EQP_ID)) {
                eie = getEie(eie, MessageUtil.getMessage("EP_F10901_MSG_001")); //�]�ƽs�����o����
            }
            
            String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
            if (StringUtils.isBlank(APLY_NO)) {
                eie = getEie(eie, MessageUtil.getMessage("EP_F10901_MSG_003")); //�ץ�s�����o����
            }
            
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getEie(eie, MessageUtil.getMessage("EP_F10901_MSG_002")); //�����q�O���o����
            }
            
            String SER_NO = MapUtils.getString(reqMap, "SER_NO");
            if (SER_NO == null) {
                eie = getEie(eie, MessageUtil.getMessage("EP_F10901_MSG_005")); //�y�������o����
            }
            
            if (eie != null) {
                throw eie;
            }
            
            F191VO.setEQP_ID(EQP_ID);
            F191VO.setSUB_CPY_ID(SUB_CPY_ID);
            F191VO.setAPLY_NO(APLY_NO);
            F191VO.setSER_NO(Integer.valueOf(SER_NO));
            F191VO.setMEMO(MapUtils.getString(reqMap, "MEMO"));
            F191VO.setFIX_AMT(STRING.objToBigDecimal(reqMap.get("FIX_AMT"), BigDecimal.ZERO));
            String FIX_DATE = MapUtils.getString(reqMap, "FIX_DATE");
            F191VO.setFIX_DATE(DATE.isDate(FIX_DATE) ? Date.valueOf(FIX_DATE) : null);
        }

        //�s�W�j�ӳ]�ƺ��װO�����(DTEPF191)
        VOTool.insert(F191VO);
    }

    /**
     * �@�ΰѼ��ˮ�
     * @param eie
     * @param msg
     */
    private ErrorInputException getEie(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(msg));
        return eie;
    }
}
