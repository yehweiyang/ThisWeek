package com.cathay.ep.f1.module;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPF190;
import com.cathay.ep.z0.module.EP_Z0F190;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * <pre>
 * �@�B   �{���\�෧�n����
 * �ҲզW�� �]�Ƽi���d�߼Ҳ�
 * �Ҳ�ID EP_F10900
 * ���n���� �]�Ƽi���d�߼Ҳ�(�ݨϥΦh��y�t��)
 * 
 * �G�B   �ϥ��ɮסG
 * 1.�j�ӳ]�Ƴ]�w�� DTEPF190 
 * 2.�j�ӳ]�ƺ��װO����DTEPF191 
 * 
 * �T�B   �ϥμҲաG
 * �j�ӳ]�Ƴ]�w��SQL�@�μҲ�   EP_Z0F190
 * 
 * @author ������
 * @since 2019-05-21
 * </pre>
 */
@SuppressWarnings( { "unchecked" })
public class EP_F10900 {

    private static final String SQL_query_001 = "com.cathay.ep.f1.module.EP_F10900.SQL_query_001";

    private static final String SQL_update_001 = "com.cathay.ep.f1.module.EP_F10900.SQL_update_001";

    private static final String ST_1 = "1";

    private static final String ST_2 = "2";

    private static final String ST_3 = "3";

    /**
     * �d�ߤj�ӳ]�Ƹ��
     * @param reqMap
     * @return
     * @throws Exception
     */
    public List<Map> query(Map reqMap) throws Exception {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_F10900_MSG_001")); //�ǤJ�ѼƤ��o����
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID"); //�����q�O
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_F10900_MSG_002")); //�����q�O���o���ŭ�
        }

        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD"); //�j�ӥN��
        String EQP_ID = MapUtils.getString(reqMap, "EQP_ID"); //�]�ƽs��
        String EQP_CD = MapUtils.getString(reqMap, "EQP_CD"); //�]�ƺ���(�j��)
        String SUB_EQP_CD = MapUtils.getString(reqMap, "SUB_EQP_CD"); //�]�ƺ���(����)
        String CODE = MapUtils.getString(reqMap, "CODE"); //�]�ƺ���(�W��X)
        
        String FIX_CNT = MapUtils.getString(reqMap, "FIX_CNT"); //���ײֿn����
        String FIX_AMT = MapUtils.getString(reqMap, "FIX_AMT"); //���ײֿn���B

        DataSet ds = Transaction.getDataSet();

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        if (StringUtils.isNotEmpty(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }

        if (StringUtils.isNotEmpty(EQP_ID)) {
            ds.setField("EQP_ID", EQP_ID);
        }

        if (StringUtils.isNotEmpty(EQP_CD)) {
            ds.setField("EQP_CD", EQP_CD);
        }
        
        if (StringUtils.isNotEmpty(SUB_EQP_CD)) {
            ds.setField("SUB_EQP_CD", SUB_EQP_CD);
        }
        
        if (StringUtils.isNotEmpty(CODE)) {
            ds.setField("CODE", CODE);
        }

        //�X�t�~�� �T�ӧP�_
        //�B�z����Ÿ�(�X�t�~��)
        String SIGN1 = MapUtils.getString(reqMap, "SIGN1");
        String EQP_YR = MapUtils.getString(reqMap, "EQP_YR"); //�X�t�~��
        if (StringUtils.isNotEmpty(EQP_YR) && StringUtils.isNotEmpty(SIGN1)) {
            if (ST_1.equals(SIGN1)) {
                ds.setField("EQP_YR_1", EQP_YR);
            } else if (ST_2.equals(SIGN1)) {
                ds.setField("EQP_YR_2", EQP_YR);
            } else if (ST_3.equals(SIGN1)) {
                ds.setField("EQP_YR_3", EQP_YR);
            }
        }

        //�B�z����Ÿ�(���ײֿn����)
        String SIGN2 = MapUtils.getString(reqMap, "SIGN2");
        if (StringUtils.isNotEmpty(SIGN2) && StringUtils.isNotEmpty(FIX_CNT)) {
            if (ST_1.equals(SIGN2)) {
                ds.setField("FIX_CNT_1", FIX_CNT);
            } else if (ST_2.equals(SIGN2)) {
                ds.setField("FIX_CNT_2", FIX_CNT);
            } else if (ST_3.equals(SIGN2)) {
                ds.setField("FIX_CNT_3", FIX_CNT);
            }
        }

        //�B�z����Ÿ�(���ײֿn���B)
        String SIGN3 = MapUtils.getString(reqMap, "SIGN3");
        if (StringUtils.isNotEmpty(SIGN3) && StringUtils.isNotEmpty(FIX_AMT)) {
            if (ST_1.equals(SIGN3)) {
                ds.setField("FIX_AMT_1", FIX_AMT);
            } else if (ST_2.equals(SIGN3)) {
                ds.setField("FIX_AMT_2", FIX_AMT);
            } else if (ST_3.equals(SIGN3)) {
                ds.setField("FIX_AMT_3", FIX_AMT);
            }
        }

        DBUtil.searchAndRetrieve(ds, SQL_query_001);

        StringBuilder sb = new StringBuilder();
        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);

            //���o�]�ƺ���(�j��)����
            String D_EQP_CD = MapUtils.getString(rtnMap, "EQP_CD");
            String D_EQP_CD_NM = FieldOptionList.getName("EP", "EQP_CD", D_EQP_CD);

            //���o�]�ƺ���(����)����
            String D_SUB_EQP_CD = MapUtils.getString(rtnMap, "SUB_EQP_CD");
            String D_SUB_EQP_CD_NM = "";
            if ("1".equals(D_EQP_CD)) { //����]��
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F901", D_SUB_EQP_CD);
            } else if ("2".equals(D_EQP_CD)) { //�q��
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F902", D_SUB_EQP_CD);
            } else if ("3".equals(D_EQP_CD)) { //�Ž�
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F903", D_SUB_EQP_CD);
            } else if ("4".equals(D_EQP_CD)) { //���Ƥ��νå�
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F904", D_SUB_EQP_CD);
            } else if ("5".equals(D_EQP_CD)) { //�����Τ����z�q
                D_SUB_EQP_CD_NM = FieldOptionList.getName("EP", "SUB_EQP_CD_F905", D_SUB_EQP_CD);
            }

            //���o�]�ƺ����G�]�ƺ���(�j��)���� + �]�ƺ���(����)���� + �]�ƺ���(�W��X)
            String D_CODE = MapUtils.getString(rtnMap, "CODE");
            String EQP_CD_NM = sb.append(D_EQP_CD_NM).append("(").append(D_SUB_EQP_CD_NM).append(D_CODE).append(")").toString();
            sb.setLength(0);
            
            rtnMap.put("EQP_CD_NM", EQP_CD_NM);

            //���o���ĵL�Ĥ���
            rtnMap.put("VALID_NM", FieldOptionList.getName("EP", "VALID", MapUtils.getString(rtnMap, "VALID")));

            //���o��Ƨ�s���(����~)
            String UPDATE_DATE = MapUtils.getString(rtnMap, "UPDATE_DATE");
            rtnMap.put("ROC_UPDATE_DATE", DATE.isDate(UPDATE_DATE) ? DATE.toROCFormat(UPDATE_DATE, "/") : "");

            //�����]�ƺ������o�]�ƳW�����W��
            String EQP_SPECS = FieldOptionList.getName("EP", "EQP_SPECS", D_EQP_CD + D_SUB_EQP_CD);
            if (StringUtils.isNotBlank(EQP_SPECS)) {
                String[] EQP_SPECS_AR = EQP_SPECS.split(",");
                for (int i = 0; i < EQP_SPECS_AR.length; i++) {
                    int j = i + 1;
                    rtnMap.put("EQP_SPEC_NM" + j, EQP_SPECS_AR[i]);
                }
                rtnMap.put("EQP_SPEC_SIZE", EQP_SPECS_AR.length);
            } else {
                rtnMap.put("EQP_SPEC_SIZE", 0);
            }
            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * �s�W�j�ӳ]�Ƹ��
     * @param reqMap
     * @return
     * @throws Exception
     */
    public String insert(Map reqMap, UserObject user) throws Exception {

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_F10900_MSG_001")); //�ǤJ�ѼƤ��o����
        }

        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID"); //�����q�O
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_F10900_MSG_002")); //�����q�O���o���ŭ�
        }

        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
        String EQP_CD = MapUtils.getString(reqMap, "EQP_CD"); //�]�ƺ���(�j��)
        String SUB_EQP_CD = MapUtils.getString(reqMap, "SUB_EQP_CD"); //�]�ƺ���(����)
        String CODE = MapUtils.getString(reqMap, "CODE"); //�]�ƺ���(�W��X)

        Map inMap = new HashMap();
        inMap.put("BLD_CD", BLD_CD);
        inMap.put("EQP_CD", EQP_CD);
        inMap.put("SUB_EQP_CD", SUB_EQP_CD);

        int SerNo = new EP_Z0F190().queryDTEPF190MaxSerNo(inMap);
        int SerNO_add_1 = SerNo + 1;
        String SER_NO = Integer.toString(SerNO_add_1);

        //����3�X �ѥ���}�l�ɹs
        SER_NO = STRING.fillZero(SER_NO, 3, EncodingHelper.DefaultCharset);

        //�]�ƽs�� = �j�ӥN��(4�X)+�]�ƥN�X(7�X:�j��1�X+�p��2�X+�W��X4�X)+�y����(3�X)
        StringBuilder sb = new StringBuilder();
        String EQP_ID = sb.append(BLD_CD).append(EQP_CD).append(SUB_EQP_CD).append(CODE).append(SER_NO).toString();
        sb.setLength(0);

        DTEPF190 F190VO = new DTEPF190();
        F190VO.setEQP_ID(EQP_ID);
        F190VO.setSUB_CPY_ID(SUB_CPY_ID);
        F190VO.setBLD_CD(BLD_CD);
        F190VO.setBLD_NM(MapUtils.getString(reqMap, "BLD_NM"));
        F190VO.setEQP_CD(EQP_CD);
        F190VO.setSUB_EQP_CD(SUB_EQP_CD);
        F190VO.setCODE(CODE);
        F190VO.setSER_NO(SerNO_add_1);
        F190VO.setVALID("1");
        F190VO.setUPDATE_ID(user.getEmpID());
        F190VO.setUPDATE_DATE(DATE.today());
        //�s�W�j�ӳ]�Ƹ��(DTEPF190)
        VOTool.insert(F190VO);

        return EQP_ID;
    }

    /**
     * �ק�j�ӳ]�Ƹ��
     * @param reqMap
     * @return
     * @throws Exception
     */
    public void update(Map reqMap, UserObject user) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_F10900_MSG_001")); //�ǤJ�ѼƤ��o����
        }

        ErrorInputException eie = null;
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, "EP_F10900_MSG_002"); //�����q�O���o���ŭ�
        }
        String EQP_ID = MapUtils.getString(reqMap, "EQP_ID");
        if (StringUtils.isBlank(EQP_ID)) {
            eie = getEie(eie, "EP_F10900_MSG_003"); //�]�ƽs�����o���ŭ�
        }
        String EQP_NO = MapUtils.getString(reqMap, "EQP_NO");
        if (StringUtils.isBlank(EQP_NO)) {
            eie = getEie(eie, "EP_F10900_MSG_004"); //�]�ƧǸ����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DTEPF190 F190VO = new DTEPF190();
        F190VO.setEQP_ID(EQP_ID);
        F190VO.setSUB_CPY_ID(SUB_CPY_ID);
        //���o�j�ӳ]�Ƹ��
        DTEPF190 DBF190VO = VOTool.findByPKWithUR(F190VO);

        DBF190VO.setEQP_FR(MapUtils.getString(reqMap, "EQP_FR"));
        DBF190VO.setEQP_LB(MapUtils.getString(reqMap, "EQP_LB"));
        DBF190VO.setEQP_YR(MapUtils.getString(reqMap, "EQP_YR"));
        DBF190VO.setEQP_MD(MapUtils.getString(reqMap, "EQP_MD"));
        DBF190VO.setVALID(MapUtils.getString(reqMap, "VALID"));
        DBF190VO.setMEMO(MapUtils.getString(reqMap, "MEMO"));
        DBF190VO.setEQP_NO(MapUtils.getInteger(reqMap, "EQP_NO"));
        //�ק�H���Τ�� ;
        DBF190VO.setUPDATE_ID(user.getEmpID());
        DBF190VO.setUPDATE_DATE(DATE.today());

        //���o�W�� 
        DBF190VO.setEQP_SPEC1(MapUtils.getString(reqMap, "EQP_SPEC1", ""));
        DBF190VO.setEQP_SPEC2(MapUtils.getString(reqMap, "EQP_SPEC2", ""));
        DBF190VO.setEQP_SPEC3(MapUtils.getString(reqMap, "EQP_SPEC3", ""));
        DBF190VO.setEQP_SPEC4(MapUtils.getString(reqMap, "EQP_SPEC4", ""));
        DBF190VO.setEQP_SPEC5(MapUtils.getString(reqMap, "EQP_SPEC5", ""));

        VOTool.update(DBF190VO);

        //��s���e�]�Ƹ�Ƭ��L��
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("BLD_CD", DBF190VO.getBLD_CD());
        ds.setField("EQP_CD", DBF190VO.getEQP_CD());
        ds.setField("SUB_EQP_CD", DBF190VO.getSUB_EQP_CD());
        ds.setField("EQP_NO", EQP_NO);
        ds.setField("EQP_ID", EQP_ID);
        DBUtil.executeUpdate(ds, SQL_update_001, false);
    }

    /**
     * �R���j�ӳ]�Ƹ��
     * @param EQP_ID  SUB_CPY_ID
     * @return
     * @throws Exception
     */

    public void delete(String EQP_ID, String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getEie(eie, "EP_F10900_MSG_002"); //�����q�O���o���ŭ�
        }
        if (StringUtils.isBlank(EQP_ID)) {
            eie = getEie(eie, "EP_F10900_MSG_003"); //�]�ƽs�����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DTEPF190 F190VO = new DTEPF190();
        F190VO.setEQP_ID(EQP_ID);
        F190VO.setSUB_CPY_ID(SUB_CPY_ID);
        VOTool.delByPK(F190VO);
    }

    /**
     * �@�ΰѼ��ˮ�
     * @param eie
     * @param msg
     */
    private ErrorInputException getEie(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(msg));
        return eie;
    }
}
