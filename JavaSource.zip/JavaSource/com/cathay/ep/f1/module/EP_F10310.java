package com.cathay.ep.f1.module;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.Employee;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.df.bo.DTDFD013;
import com.cathay.df.bo.DTDFD017;
import com.cathay.df.d1.module.DF_D1Z013;
import com.cathay.dj.a0.module.DJ_A0Z002;
import com.cathay.dk.bo.DTDKM001;
import com.cathay.dk.bo.DTDKM002;
import com.cathay.dk.m0.module.DK_M0Z016;
import com.cathay.ep.z0.module.EP_Z00100;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F180;
import com.cathay.ep.z0.module.EP_Z0F181;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.rpt.RptUtils;
import com.cathay.rz.n0.module.RZ_N00100;
import com.cathay.rz.n0.module.RZ_N0Z001;
import com.cathay.rz.vo.DTRZN010;
import com.cathay.util.ReturnCode;
import com.igsapp.db.DBException;

/**
 * <pre>
 * DATE Description Author
 * 2015/12/22 Created ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    ��޵|���@�Ҳ�
 * �Ҳ�ID      EP_Z0F180
 * ���n����    ��޵|���@�Ҳ�
 * </pre>
 * @author �d�ÿ�
 * @since 2015/01/12
 * 2019/12/03 �E�Ͷv:��T���������@�~�ӽЮ�191202000999�G�дڦ걵�Q�`���Y�H�d��(�W��t�X�վ�)
 */
@SuppressWarnings("unchecked")
public class EP_F10310 {

    private static final Logger log = Logger.getLogger(EP_F10310.class);

//    private EP_E00010 theEP_E00010 = new EP_E00010();

    /**
     * �ˮ���޶O�뵲�T�{
     * @param reqMap
     * @param SUB_CPY_ID
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap, String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;

        String OP_STATUS = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_001")); // �d�߱��󤣥i����
        } else {
            OP_STATUS = MapUtils.getString(reqMap, "OP_STATUS");
            if (StringUtils.isBlank(OP_STATUS)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_002")); // ���A���i����
            }
        }

        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_003")); // �����q�O���i����
        }

        if (eie != null) {
            throw eie;
        }

        List<Map> rtnList;
        if ("0".equals(OP_STATUS)) {
            String DATE_S = MapUtils.getString(reqMap, "DATE_S");
            String DATE_E = MapUtils.getString(reqMap, "DATE_E");
            rtnList = new EP_Z0F110().queryByCMMDATE(SUB_CPY_ID, DATE_S, DATE_E); // �d�ߥ��뵲F110

            for (Map rtnMap : rtnList) {
                rtnMap.put("USE_TP_NM", FieldOptionList.getName("EP", "USE_TP_F101", MapUtils.getString(rtnMap, "USE_TP"))); // ���o�u�γ~�v����
                rtnMap.put("EXP_TP_NM", FieldOptionList.getName("EP", "EXP_TP_F101", MapUtils.getString(rtnMap, "EXP_TP"))); // ���o�u�O�κ����v����
                rtnMap.put("PRO_OWN_NM", FieldOptionList.getName("EP", "PRO_OWN", MapUtils.getString(rtnMap, "PRO_OWN"))); // ���o�u�u�{�k�ݡv����
                rtnMap.put("APLY_TP_NM", FieldOptionList.getName("EP", "APLY_TP_F101", MapUtils.getString(rtnMap, "APLY_TP"))); // ���o�u�u�{�k�ݡv����
                rtnMap.put("TOT_CLR_AMT", STRING.objToBigDecimal(rtnMap.get("TOT_CLR_AMT"), BigDecimal.ZERO).add(
                    STRING.objToBigDecimal(rtnMap.get("CLR_AMT"), BigDecimal.ZERO))); // ���B�[�`
                rtnMap.put("TOT_CNT", STRING.objToBigDecimal(rtnMap.get("TOT_CNT"), BigDecimal.ZERO).add(BigDecimal.ONE)); // ��ƥ[�`
            }

        } else {
            rtnList = new EP_Z0F180().queryList(reqMap, SUB_CPY_ID);
            PersonnelData pd = new PersonnelData();
            Map<String, String> tmpEmpMap = new HashMap<String, String>();
            for (Map rtnMap : rtnList) {
                rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "F180_OP_STATUS", OP_STATUS)); // ���o�u���A�v����
                String INPUT_ID = MapUtils.getString(rtnMap, "INPUT_ID");
                String[] tmp = this.getEmpName(INPUT_ID, tmpEmpMap, pd, SUB_CPY_ID).split(",");
                rtnMap.put("INPUT_NM", tmp[0]);
                rtnMap.put("INPUT_DIV_NM", tmp[1]);
                String LST_PROC_ID = MapUtils.getString(rtnMap, "LST_PROC_ID");
                tmp = this.getEmpName(LST_PROC_ID, tmpEmpMap, pd, SUB_CPY_ID).split(",");
                rtnMap.put("LST_PROC_NM", tmp[0]);
                rtnMap.put("LST_PROC_DIV_NM", tmp[1]);
            }
        }

        return rtnList;
    }

    /**
     * ��޶O�뵲�T�{
     * @param reqMap
     * @param SUB_CPY_ID
     * @throws ModuleException
     * @throws DBException 
     */
    public void confirm(List<Map> reqList, Map reqMap, UserObject user) throws ModuleException, DBException {

        ErrorInputException eie = null;

        if (reqList == null || reqList.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_004")); // ��µ�ץ�M�椣�i����
        }

        String SUB_CPY_ID = null;
        String SUP_ID = null;
        String SUP_NM = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_005")); // �ǤJ�ѼƤ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            SUP_ID = MapUtils.getString(reqMap, "SUP_ID");
            SUP_NM = MapUtils.getString(reqMap, "SUP_NM");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_003")); // �����q�O���i����
            }
            if (StringUtils.isBlank(SUP_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_006")); // �t�ӥN�����i����
            }
            if (StringUtils.isBlank(SUP_NM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_007")); // �t�ӦW�٤��i����
            }
        }

        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_008")); // �ǤJ�ϥΪ̸�Ƥ��i����
        }

        if (eie != null) {
            throw eie;
        }

        // �뵲�~��
        String CMM_YM = DATE.getTodayYearAndMonth();
        // ���o��޶O�s�� : �����q+�뵲�~��+�y����
        String CMM_APLY_NO = new EP_Z0Z001().createNextNo(SUB_CPY_ID, "042", DATE.getY2KYear(DATE.getDBDate()), "CMM_APLY_NO", SUB_CPY_ID
                + CMM_YM, 4);

        // ��sDTEPF110���A
        new EP_Z0F110().updateCMM_APLY_NO(reqList, CMM_APLY_NO, user);

        // ��޶O���
        BigDecimal CMM_RATE = STRING.objToBigDecimal(FieldOptionList.getName("EP", "CMM_SET", "CMM_RATE"), BigDecimal.ZERO);

        List<Map> F181List = new ArrayList<Map>();

        BigDecimal TOT_CLR_AMT = BigDecimal.ZERO;
        BigDecimal TOT_CMM_FEE = BigDecimal.ZERO;

        Timestamp currentTime = DATE.currentTime();
        String empId = user.getEmpID();
        String empNm = user.getEmpName();
        String divNo = user.getDivNo();

        for (Map m : reqList) {
            Map F181Map = new HashMap();
            F181Map.put("CMM_APLY_NO", CMM_APLY_NO);
            F181Map.put("APLY_NO", m.get("APLY_NO"));
            F181Map.put("APLY_TP", m.get("APLY_TP"));
            F181Map.put("USE_TP", m.get("USE_TP"));
            F181Map.put("BLD_CD", m.get("BLD_CD"));
            F181Map.put("BLD_NM", m.get("BLD_NM"));
            F181Map.put("SUP_ID", m.get("SUP_ID"));
            F181Map.put("SUP_NM", m.get("SUP_NM"));
            F181Map.put("FIX_MO", m.get("FIX_MO"));
            F181Map.put("USR_FINAL_DATE", m.get("USR_FINAL_DATE"));
            F181Map.put("END_APLY_DATE", m.get("END_APLY_DATE"));

            BigDecimal CLR_AMT = STRING.objToBigDecimal(m.get("CLR_AMT"), BigDecimal.ZERO);
            F181Map.put("CLR_AMT", CLR_AMT);
            TOT_CLR_AMT = TOT_CLR_AMT.add(CLR_AMT); // �`��µ���B

            BigDecimal CMM_FEE = CLR_AMT.multiply(CMM_RATE).setScale(0, BigDecimal.ROUND_HALF_UP);
            F181Map.put("CMM_FEE", CMM_FEE);
            TOT_CMM_FEE = TOT_CMM_FEE.add(CMM_FEE); // ��޶O���B

            F181Map.put("LST_PROC_DATE", currentTime);
            F181Map.put("LST_PROC_ID", empId);
            F181Map.put("LST_PROC_DIV", divNo);
            F181List.add(F181Map);
        }

        // �妸�g�JDTEPF181��޶O������
        new EP_Z0F181().insert(F181List);

        // RZ�f��
        String CHG_ID = empId;
        String CHG_DIV_NO = divNo;
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String authDesc = "��޶O�T�{";
        String comment = new StringBuilder().append(authDesc).append(':').append(CMM_APLY_NO).append('(').append(empNm).append(')')
                .toString();
        String strFlowNo = new RZ_N0Z001().startFlow("EPF1_0400", authDesc, comment, CHG_ID, CHG_DIV_NO);

        // �g�JDTEPF180��޶O�O����
        Map F180Map = new HashMap();
        F180Map.put("CMM_APLY_NO", CMM_APLY_NO);
        F180Map.put("SUB_CPY_ID", SUB_CPY_ID);
        F180Map.put("CMM_YM", CMM_YM);
        F180Map.put("CMM_CNT", reqList.size()); // �뵲����
        F180Map.put("TOT_CLR_AMT", TOT_CLR_AMT); // �`��µ���B
        F180Map.put("TOT_CMM_FEE", TOT_CMM_FEE); // ��޶O���B
        BigDecimal UN_TAX_AMT = TOT_CMM_FEE.divide(new BigDecimal("1.05"), 0, BigDecimal.ROUND_HALF_UP); // ���|���B
        BigDecimal TAX_AMT = TOT_CMM_FEE.subtract(UN_TAX_AMT); // �|�B
        F180Map.put("UNTAX_AMT", UN_TAX_AMT);
        F180Map.put("TAX_AMT", TAX_AMT);
        F180Map.put("INPUT_ID", empId);
        F180Map.put("INPUT_DIV_NO", divNo);
        F180Map.put("INPUT_DATE", currentTime);
        F180Map.put("SUP_ID", SUP_ID);
        F180Map.put("SUP_NM", SUP_NM);
        F180Map.put("FLOW_NO", strFlowNo);
        F180Map.put("OP_STATUS", "100");
        F180Map.put("LST_PROC_DATE", currentTime);
        F180Map.put("LST_PROC_ID", empId);
        F180Map.put("LST_PROC_DIV", divNo);
        new EP_Z0F180().insert(F180Map);
    }

    /**
     * �����T�{
     * @param reqMap
     * @param user
     * @throws ModuleException
     * @throws DBException 
     */
    public void cancelConfirm(Map reqMap, UserObject user) throws ModuleException, DBException {

        ErrorInputException eie = null;

        String SUB_CPY_ID = null;
        String CMM_APLY_NO = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_005")); // �ǤJ�ѼƤ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            CMM_APLY_NO = MapUtils.getString(reqMap, "CMM_APLY_NO");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_003")); // �����q�O���i����
            }
            if (StringUtils.isBlank(CMM_APLY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_009")); // ��޶O�뵲�s�����i����
            }
        }

        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_008")); // �ǤJ�ϥΪ̸�Ƥ��i����
        }

        if (eie != null) {
            throw eie;
        }

        EP_Z0F110 mEP_Z0F110 = new EP_Z0F110();
        EP_Z0F180 mEP_Z0F180 = new EP_Z0F180();

        List<Map> F110List = mEP_Z0F110.queryByCMM(SUB_CPY_ID, CMM_APLY_NO);

        // ��sDTEPF110���A
        mEP_Z0F110.updateCMM_APLY_NO(F110List, null, user);

        // �R��DTEPF181��޶O������
        new EP_Z0F181().deleteByCMM_APLY_NO(CMM_APLY_NO);

        Map F180Map = mEP_Z0F180.queryByPK(CMM_APLY_NO, SUB_CPY_ID);

        // RZ�f��
        String CHG_ID = user.getEmpID();
        String CHG_DIV_NO = user.getUserDivNo();
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String authDesc = "�R����޶O";
        String comment = new StringBuilder().append(authDesc).append(':').append(MapUtils.getString(F180Map, "CMM_APLY_NO")).append('(')
                .append(user.getEmpName()).append(')').toString();
        new RZ_N0Z001().deleteFlow(MapUtils.getString(F180Map, "FLOW_NO"), authDesc, comment, CHG_ID, CHG_DIV_NO);

        // �R��DTEPF180��޶O�O����
        mEP_Z0F180.delete(CMM_APLY_NO, SUB_CPY_ID);
    }

    /**
     * ��޶O�д�
     * @param reqMap
     * @param reqMap
     * @param user
     * @throws Exception 
     */
    public void pay(Map F180Map, Map reqMap, UserObject user) throws Exception {

        ErrorInputException eie = null;

        if (F180Map == null || F180Map.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_010")); // ��޶O�뵲�O�����i����
        }

        String SUB_CPY_ID = null;
        String INV_NO = null;
        String BUD_DIV_NO = null;
        String BUD_ACNT_CODE = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_005")); // �ǤJ�ѼƤ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            INV_NO = MapUtils.getString(reqMap, "INV_NO");
            BUD_DIV_NO = MapUtils.getString(reqMap, "BUD_DIV_NO");
            BUD_ACNT_CODE = MapUtils.getString(reqMap, "BUD_ACNT_CODE");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_003")); // �����q�O���i����
            }
            if (StringUtils.isBlank(INV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_011")); // �o�����X���i����
            }
            if (StringUtils.isBlank(BUD_DIV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_012")); // �w���줣�i����
            }
            if (StringUtils.isBlank(BUD_ACNT_CODE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_013")); // �w���ؤ��i����
            }
        }

        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_008")); // �ǤJ�ϥΪ̸�Ƥ��i����
        }

        if (eie != null) {
            throw eie;
        }

        String currentTime = DATE.getDBTimeStamp();
        String empId = user.getEmpID();
        String empNm = user.getEmpName();
        String divNo = user.getDivNo();
        String opUnit = user.getOpUnit();
        String opUnitNm = user.getOpUnitShortName();

        String todayYYMM = DATE.getTodayYearAndMonth();

        // �զ�DTDKM001:��޶O�`���B
        DTDKM001 DKM001 = new DTDKM001();
        DKM001.setFEE_TYPE("0");
        DKM001.setAUD_STS("1");
        DKM001.setINPUT_ID(empId);
        DKM001.setINPUT_NAME(empNm);
        DKM001.setINPUT_DATE(currentTime);
        DKM001.setINPUT_DIV_NO(opUnit);
        DKM001.setINPUT_DIV_NAME(opUnitNm);
        DKM001.setTOT_AMT(MapUtils.getString(F180Map, "TOT_CMM_FEE"));
        DKM001.setMEMO("��µ");
        DKM001.setIS_DOC_NEED("N");
        DKM001.setBUD_DIV_NO(BUD_DIV_NO);
        DKM001.setBUD_ACNT_CODE(BUD_ACNT_CODE);
        DKM001.setBUD_YYMM(todayYYMM);
        DKM001.setSYS_NO("EP");//�t�ΧO

        // ���o�w��j���ά�l�ӥ� //�Ѧ�EP_Z0F160. submitDk
        // ���o�j������  
        String BUD_BIG_CODE;
        try {
            BUD_BIG_CODE = FieldOptionList.getName("EP", "BUD_ACNT_BIG_CODE", BUD_ACNT_CODE);
        } catch (Exception e) {
            log.debug("�L�]�w�w��j��");
            BUD_BIG_CODE = "";
        }
        List<Map> DTDFD013List = new DF_D1Z013().doQueryWithName(BUD_DIV_NO, BUD_ACNT_CODE, BUD_BIG_CODE, "", "");

        // �w�]�T�w���Ĥ@��
        Map DTDFD013List_0 = DTDFD013List.get(0);
        DTDFD013 DTDFD013VO = VOTool.mapToVO(DTDFD013.class, DTDFD013List_0); //�|�p��
        DTDFD017 DTDFD017VO = VOTool.mapToVO(DTDFD017.class, DTDFD013List_0); //�w��

        // �զ�2��DTDKM002
        List<DTDKM002> DKM002List = new ArrayList<DTDKM002>();

        String SUP_ID = MapUtils.getString(F180Map, "SUP_ID");
        ReturnMessage rm = new ReturnMessage();
        String ACPT_NAME = new DJ_A0Z002().doQuery(SUP_ID, rm).getACPT_NAME();
        if (rm.getReturnCode() != ReturnCode.OK) {
            throw new ModuleException(rm.getMsgDesc());
        }
        
        //20191203��T���������@�~�ӽЮ�191202000999�G�дڦ걵�Q�`���Y�H�d��(�W��t�X�վ�) by �E�Ͷv
        //�]�W��call�дڼҲղ��ͽдڮץ󬰸󥭥xXA�s�u�A�ӽдڼҲդ��ˮ֬O�_���Q�`���Y�H���Ҳլ��W�߳s�u�A�bXA�s�u�����|�P�_�W�߳s�u��XA�s�u�C
        //����󥭥xXA�s�u�e�A���ˮ֬O�_���Q�`���Y�H�A�h�L�bXA�s�u���J�W�߳s�u���D�C
        //���קK�s�u�P�_���D�A�N�ˮ֬O�_���Q�`���Y�H���Ҳղ���call�дڼҲդ��e����d�ߡA�A�N�d�ߧQ�`���Y�H���G�@�P�ǤJ�дڼҲաC
        
    	//���B�NXA�s�u�~�d�n���Q�`���Y�H���G�ǳƦn�A�A��JDTDKM002VO���ǤJDK

        //���|
        DTDKM002 DKM002_1 = new DTDKM002();
        DKM002_1.setPAY_TYPE("1");
        DKM002_1.setUSE_YYMM(todayYYMM);
        DKM002_1.setUSE_DIV_NO(opUnit);
        DKM002_1.setUSE_DIV_NAME(opUnitNm);
        DKM002_1.setACPT_CODE("3");
        DKM002_1.setACPT_ID(SUP_ID);
        DKM002_1.setACPT_NAME(ACPT_NAME);
        DKM002_1.setTAX_ID("");
        DKM002_1.setTAX_NAME("");
        DKM002_1.setCORP_NO(SUP_ID);
        DKM002_1.setINVOICE_NO(INV_NO);
        DKM002_1.setAMT(MapUtils.getString(F180Map, "UNTAX_AMT"));
        DKM002_1.setBUD_BIG_CODE(DTDFD017VO.getBUD_BIG_CODE());
        DKM002_1.setBUD_MID_CODE(DTDFD017VO.getBUD_MID_CODE());
        DKM002_1.setBUD_SML_CODE(DTDFD017VO.getBUD_SML_CODE());
        DKM002_1.setBUD_BIG_NAME(DTDFD017VO.getBUD_BIG_NAME());
        DKM002_1.setBUD_MID_NAME(DTDFD017VO.getBUD_MID_NAME());
        DKM002_1.setBUD_SML_NAME(DTDFD017VO.getBUD_SML_NAME());
        DKM002_1.setBAL_TYPE("CA");
        DKM002_1.setDR_ACNT_CODE(DTDFD013VO.getCE_ACC_CD());
        DKM002_1.setDR_SBAC_CODE(DTDFD013VO.getCE_SBACC_CD());
        DKM002_1.setDR_DLAC_CODE(DTDFD013VO.getCE_DLACC_CD());
        DKM002_1.setDR_ACNT_NAME(DTDFD013VO.getCE_ACC_CD());
        DKM002_1.setDR_SBAC_NAME(DTDFD013VO.getCE_SBACC_CD());
        DKM002_1.setDR_DLAC_NAME(DTDFD013VO.getCE_ACC_CD());
        DKM002_1.setIS_PRO_REL(MapUtils.getString(F180Map, "IS_PRO_REL")); //�O�_���Q�`���Y�H
        DKM002List.add(DKM002_1);

        //�|�B
        DTDKM002 DKM002_2 = new DTDKM002();
        DKM002_2.setPAY_TYPE("1");
        DKM002_2.setUSE_YYMM(todayYYMM);
        DKM002_2.setUSE_DIV_NO(opUnit);
        DKM002_2.setUSE_DIV_NAME(opUnitNm);
        DKM002_2.setACPT_CODE("3");
        DKM002_2.setACPT_ID(SUP_ID);
        DKM002_2.setACPT_NAME(ACPT_NAME);
        DKM002_2.setTAX_ID("");
        DKM002_2.setTAX_NAME("");
        DKM002_2.setCORP_NO(SUP_ID);
        DKM002_2.setINVOICE_NO(INV_NO);
        DKM002_2.setAMT(MapUtils.getString(F180Map, "TAX_AMT"));
        DKM002_2.setBUD_BIG_CODE(DTDFD017VO.getBUD_BIG_CODE());
        DKM002_2.setBUD_MID_CODE(DTDFD017VO.getBUD_MID_CODE());
        DKM002_2.setBUD_SML_CODE(DTDFD017VO.getBUD_SML_CODE());
        DKM002_2.setBUD_BIG_NAME(DTDFD017VO.getBUD_BIG_NAME());
        DKM002_2.setBUD_MID_NAME(DTDFD017VO.getBUD_MID_NAME());
        DKM002_2.setBUD_SML_NAME(DTDFD017VO.getBUD_SML_NAME());
        DKM002_2.setBAL_TYPE("CA");
        DKM002_2.setDR_ACNT_CODE(DTDFD013VO.getCE_ACC_CD());
        DKM002_2.setDR_SBAC_CODE(DTDFD013VO.getCE_SBACC_CD());
        DKM002_2.setDR_DLAC_CODE(DTDFD013VO.getCE_DLACC_CD());
        DKM002_2.setDR_ACNT_NAME(DTDFD013VO.getCE_ACC_CD());
        DKM002_2.setDR_SBAC_NAME(DTDFD013VO.getCE_SBACC_CD());
        DKM002_2.setDR_DLAC_NAME(DTDFD013VO.getCE_ACC_CD());
        DKM002_2.setIS_PRO_REL(MapUtils.getString(F180Map, "IS_PRO_REL")); //�O�_���Q�`���Y�H
        DKM002List.add(DKM002_2);

        // �дڮ־P�JDK��
        String DKM_CASE_NO = new DK_M0Z016().insert1DKM("", DKM001, DKM002List);

        // ��sRZ�f��
        String FLOW_NO = MapUtils.getString(F180Map, "FLOW_NO");
        String CHG_ID = empId;
        String CHG_DIV_NO = divNo;
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String authDesc = "��޶O�д�";
        String comment = new StringBuilder().append(authDesc).append(':').append(MapUtils.getString(F180Map, "CMM_APLY_NO")).append('(')
                .append(empNm).append(')').toString();
        new RZ_N0Z001().approveFlow(FLOW_NO, authDesc, comment, CHG_ID, CHG_DIV_NO);

        DTRZN010 voDTRZN010 = new DTRZN010();
        voDTRZN010.setFLOW_NO(FLOW_NO);
        voDTRZN010 = new RZ_N00100().queryDTRZN010(voDTRZN010).get(0);
        String next_OP_STATUS = voDTRZN010.getOP_STATUS();

        // ��sDTEPF180��޶O�O����
        F180Map.put("OP_STATUS", next_OP_STATUS);
        F180Map.put("CASE_NO", DKM_CASE_NO);
        F180Map.put("PAY_DATE", DATE.today());
        F180Map.put("LST_PROC_DATE", currentTime);
        F180Map.put("LST_PROC_ID", empId);
        F180Map.put("LST_PROC_DIV", divNo);
        new EP_Z0F180().updateOP_STATUS(F180Map, "1");
    }

    /**
     * ��޶O�����д�
     * @param reqMap
     * @param user
     * @throws ModuleException
     */
    public void cancelPay(Map reqMap, UserObject user) throws ModuleException {

        ErrorInputException eie = null;

        String SUB_CPY_ID = null;
        String CMM_APLY_NO = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_005")); // �ǤJ�ѼƤ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            CMM_APLY_NO = MapUtils.getString(reqMap, "CMM_APLY_NO");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_003")); // �����q�O���i����
            }
            if (StringUtils.isBlank(CMM_APLY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_009")); // ��޶O�뵲�s�����i����
            }
        }

        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_008")); // �ǤJ�ϥΪ̸�Ƥ��i����
        }

        if (eie != null) {
            throw eie;
        }

        EP_Z0F180 mEP_Z0F180 = new EP_Z0F180();

        Map F180Map = mEP_Z0F180.queryByPK(CMM_APLY_NO, SUB_CPY_ID);

        String empId = user.getEmpID();
        String empNm = user.getEmpName();
        String divNo = user.getDivNo();

        // ��sRZ�f��
        String FLOW_NO = MapUtils.getString(F180Map, "FLOW_NO");
        String CHG_ID = empId;
        String CHG_DIV_NO = divNo;
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String authDesc = "��޶O�����д�";
        String comment = new StringBuilder().append(authDesc).append(':').append(MapUtils.getString(F180Map, "CMM_APLY_NO")).append('(')
                .append(empNm).append(')').toString();
        new RZ_N0Z001().rejectFlow(FLOW_NO, authDesc, comment, CHG_ID, CHG_DIV_NO);

        DTRZN010 voDTRZN010 = new DTRZN010();
        voDTRZN010.setFLOW_NO(FLOW_NO);
        voDTRZN010 = new RZ_N00100().queryDTRZN010(voDTRZN010).get(0);
        String next_OP_STATUS = voDTRZN010.getOP_STATUS();

        //��sDTEPF180 ��޶O�O����
        F180Map.put("OP_STATUS", next_OP_STATUS);
        F180Map.put("LST_PROC_DATE", DATE.currentTime());
        F180Map.put("LST_PROC_ID", empId);
        F180Map.put("LST_PROC_DIV", divNo);
        mEP_Z0F180.updateOP_STATUS(F180Map, "2");
    }

    /**
     * ��޶O�дڽT�{
     * @param F180Map
     * @param reqMap
     * @param user
     * @throws ModuleException
     */
    public void payConfirm(Map F180Map, Map reqMap, UserObject user) throws ModuleException {

        ErrorInputException eie = null;

        if (F180Map == null || F180Map.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_010")); // ��޶O�뵲�O�����i����
        }

        String SUB_CPY_ID = null;
        String PAY_CFM_DATE = null;
        String ACC_SECVER_DATE = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_005")); // �ǤJ�ѼƤ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            PAY_CFM_DATE = MapUtils.getString(reqMap, "PAY_CFM_DATE");
            ACC_SECVER_DATE = MapUtils.getString(reqMap, "ACC_SECVER_DATE");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_003")); // �����q�O���i����
            }
            if (StringUtils.isBlank(PAY_CFM_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_014")); // �дڽT�{�餣�i����
            }
            if (StringUtils.isBlank(ACC_SECVER_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_015")); // �|�p�Ю֤餣�i����
            }
        }

        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_008")); // �ǤJ�ϥΪ̸�Ƥ��i����
        }

        if (eie != null) {
            throw eie;
        }

        String empId = user.getEmpID();
        String empNm = user.getEmpName();
        String divNo = user.getDivNo();

        // ��sRZ�f��
        String FLOW_NO = MapUtils.getString(F180Map, "FLOW_NO");
        String CHG_ID = empId;
        String CHG_DIV_NO = divNo;
        if (CHG_DIV_NO.startsWith("EP9")) {
            //�_�פΰe��ɫD��ؤH���|��������H���W�ٻP���W��
            CHG_ID = "SYSTEM";
            CHG_DIV_NO = "";
        }
        String authDesc = "��޶O�дڽT�{";
        String comment = new StringBuilder().append(authDesc).append(':').append(MapUtils.getString(F180Map, "CMM_APLY_NO")).append('(')
                .append(empNm).append(')').toString();
        new RZ_N0Z001().approveFlow(FLOW_NO, authDesc, comment, CHG_ID, CHG_DIV_NO);

        DTRZN010 voDTRZN010 = new DTRZN010();
        voDTRZN010.setFLOW_NO(FLOW_NO);
        voDTRZN010 = new RZ_N00100().queryDTRZN010(voDTRZN010).get(0);
        String next_OP_STATUS = voDTRZN010.getOP_STATUS();

        // ��sDTEPF180 ��޶O�O����
        F180Map.put("OP_STATUS", next_OP_STATUS);
        F180Map.put("PAY_CFM_DATE", PAY_CFM_DATE);
        F180Map.put("ACC_SECVER_DATE", ACC_SECVER_DATE);
        F180Map.put("LST_PROC_DATE", DATE.currentTime());
        F180Map.put("LST_PROC_ID", empId);
        F180Map.put("LST_PROC_DIV", divNo);
        new EP_Z0F180().updateOP_STATUS(F180Map, "3");
    }

    /**
     * �C�L
     * @param reqMap
     * @param user
     * @return 
     * @throws Exception
     */
    public Map print(Map reqMap, UserObject user) throws Exception {

        ErrorInputException eie = null;

        String CMM_APLY_NO = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_001")); // �d�߱��󤣥i����
        } else {
            CMM_APLY_NO = MapUtils.getString(reqMap, "CMM_APLY_NO");
            if (StringUtils.isBlank(CMM_APLY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_009")); // ��޶O�뵲�s�����i����
            }
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_003")); // �����q�O���i����
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_008")); // �ǤJ�ϥΪ̸�Ƥ��i����
        }

        if (eie != null) {
            throw eie;
        }

        Map F180Map = new EP_Z0F180().queryByPK(CMM_APLY_NO, SUB_CPY_ID);

        // ���o�u���A�v����
        F180Map.put("OP_STATUS_NM", FieldOptionList.getName("EP", "F180_OP_STATUS", MapUtils.getString(F180Map, "OP_STATUS")));
        List<Map> F181List = new EP_Z0F181().queryByCMM_APLY_NO(CMM_APLY_NO);

        BigDecimal TOT_CLR_AMT = BigDecimal.ZERO;
        BigDecimal TOT_CMM_FEE = BigDecimal.ZERO;
        int SEQ_NO = 1;
        for (Map F181Map : F181List) {
            TOT_CLR_AMT = TOT_CLR_AMT.add(STRING.objToBigDecimal(F181Map.get("CLR_AMT"), BigDecimal.ZERO));
            TOT_CMM_FEE = TOT_CMM_FEE.add(STRING.objToBigDecimal(F181Map.get("CMM_FEE"), BigDecimal.ZERO));
            F181Map.put("END_APLY_DATE", DATE.toROCFormat(MapUtils.getString(F181Map, "END_APLY_DATE").substring(0, 10), "/"));
            F181Map.put("CLR_AMT", STRING.moneyFormat(MapUtils.getString(F181Map, "CLR_AMT")));
            F181Map.put("CMM_FEE", STRING.moneyFormat(MapUtils.getString(F181Map, "CMM_FEE")));
            F181Map.put("SEQ_NO", String.valueOf(SEQ_NO)); // ���o�u�ץ�����v����
            F181Map.put("USE_TP_NM", FieldOptionList.getName("EP", "USE_TP_F101", MapUtils.getString(F181Map, "USE_TP"))); // ���o�u�γ~�v����
            F181Map.put("EXP_TP_NM", FieldOptionList.getName("EP", "EXP_TP_F101", MapUtils.getString(F181Map, "EXP_TP"))); // ���o�u�O�κ����v����
            F181Map.put("PRO_OWN_NM", FieldOptionList.getName("EP", "PRO_OWN", MapUtils.getString(F181Map, "PRO_OWN"))); // ���o�u�u�{�k�ݡv����
            F181Map.put("APLY_TP_NM", FieldOptionList.getName("EP", "APLY_TP_F101", MapUtils.getString(F181Map, "APLY_TP"))); // ���o�u�ץ�����v����

            SEQ_NO++;
        }

        LocaleDisplay LD = new LocaleDisplay("EP", user);

        Map lastMap = new HashMap();
        lastMap.put("SEQ_NO", "");
        lastMap.put("APLY_NO", "");
        lastMap.put("BLD_NM", "");
        lastMap.put("FIX_MO", "�X�p");
        lastMap.put("CMM_FEE", LD.formatNumber(TOT_CMM_FEE, 0, ""));
        F181List.add(lastMap);

        //�]�w15��
        int size = F181List.size();
        if (size % 15 > 0) {
            for (int i = size % 15; i < 15; i++) {
                F181List.add(new HashMap<String, String>());
            }
        }

        Map<String, Object> paramMap = new HashMap<String, Object>();

        paramMap.put("REPORT_ID", "EP_F10300_3");
        String YearMM = LD.formatDateym(DATE.today(), "");
        paramMap.put("YEAR", YearMM.substring(0, 3));
        paramMap.put("MONTH", YearMM.substring(3, 5));

        //paramMap.put("TOTAL_AMT", LD.formatNumber(TOT_CLR_AMT, 0, ""));
        //paramMap.put("APLY_TP", APLY_TP);

        Map rtnMap = new HashMap();
        rtnMap.put("paramMap", paramMap);
        rtnMap.put("printList3", F181List);
        return rtnMap;
        //JasperReportUtils.addOutputRptDataToResp("EP_F10300_3", paramMap, printList3, resp);

        /*
        F180Map.put("TOT_CNT", F181List.size()); // ���ƥ[�`
        F180Map.put("TOT_CLR_AMT", TOT_CLR_AMT); // ���B�[�`

        // �ɦW  F180Map.CMM_YM ��޶O�뵲�M��.xlsx
        String fileName = DATE.getROCYearAndMonth(MapUtils.getString(F180Map, "CMM_YM")) + "��޶O�뵲�M��.xlsx";

        // Excel��X����
        int totalColumns = 7;

        FileOutputStream fos = null;
        try {
            //���o�j�ӦW�� 
            Workbook workbook = new XSSFWorkbook();// �u�@��
            Sheet sheet = workbook.createSheet(fileName); // �]�w���j�p 

            // �]�w���j�p
            setSheetColumnWidth(sheet, totalColumns);

            // �g�J���
            createWorkbook(workbook, sheet, F180Map, F181List, user.getEmpName());

            // ���ͼȦs��
            File downloadFile = RptUtils.createTempFile(fileName);
            String path = downloadFile.getPath();
            fos = new FileOutputStream(path);
            workbook.write(fos);

            return new String[] { fileName, path };
        } finally {
            if (fos != null) {
                fos.close();
            }
        }*/
    }

    /**
     * �ץX
     * @param reqMap
     * @param user
     * @return 
     * @throws Exception
     */
    public String[] export(Map reqMap, UserObject user) throws Exception {

        ErrorInputException eie = null;

        String CMM_APLY_NO = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_001")); // �d�߱��󤣥i����
        } else {
            CMM_APLY_NO = MapUtils.getString(reqMap, "CMM_APLY_NO");
            if (StringUtils.isBlank(CMM_APLY_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_009")); // ��޶O�뵲�s�����i����
            }
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); // �����q�O���o���ŭ�
            }
        }

        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_F10310_MSG_008")); // �ǤJ�ϥΪ̸�Ƥ��i����
        }

        if (eie != null) {
            throw eie;
        }

        Map F180Map = new EP_Z0F180().queryByPK(CMM_APLY_NO, SUB_CPY_ID);

        // ���o�u���A�v����
        F180Map.put("OP_STATUS_NM", FieldOptionList.getName("EP", "F180_OP_STATUS", MapUtils.getString(F180Map, "OP_STATUS")));
        List<Map> F181List = new EP_Z0F181().queryByCMM_APLY_NO(CMM_APLY_NO);

        BigDecimal TOT_CLR_AMT = BigDecimal.ZERO;
        BigDecimal TOT_CMM_FEE = BigDecimal.ZERO;

        for (Map F181Map : F181List) {
            F181Map.put("USE_TP_NM", FieldOptionList.getName("EP", "USE_TP_F101", MapUtils.getString(F181Map, "USE_TP"))); // ���o�u�γ~�v����
            F181Map.put("EXP_TP_NM", FieldOptionList.getName("EP", "EXP_TP_F101", MapUtils.getString(F181Map, "EXP_TP"))); // ���o�u�O�κ����v����
            F181Map.put("PRO_OWN_NM", FieldOptionList.getName("EP", "PRO_OWN", MapUtils.getString(F181Map, "PRO_OWN"))); // ���o�u�u�{�k�ݡv����
            F181Map.put("APLY_TP_NM", FieldOptionList.getName("EP", "APLY_TP_F101", MapUtils.getString(F181Map, "APLY_TP"))); // ���o�u�ץ�����v����

            TOT_CLR_AMT = TOT_CLR_AMT.add(STRING.objToBigDecimal(F181Map.get("CLR_AMT"), BigDecimal.ZERO));
            TOT_CMM_FEE = TOT_CMM_FEE.add(STRING.objToBigDecimal(F181Map.get("CMM_FEE"), BigDecimal.ZERO));
        }

        F180Map.put("TOT_CNT", F181List.size()); // ���ƥ[�`
        F180Map.put("TOT_CLR_AMT", TOT_CLR_AMT); // ���B�[�`
        F180Map.put("TOT_CMM_FEE", TOT_CMM_FEE); // ���B�[�`

        // �ɦW  F180Map.CMM_YM ��޶O�뵲�M��.xlsx
        String fileName = DATE.getROCYearAndMonth(MapUtils.getString(F180Map, "CMM_YM")) + "��޶O�뵲�M��.xlsx";

        // Excel��X����
        int totalColumns = 7;

        FileOutputStream fos = null;
        try {
            //���o�j�ӦW�� 
            Workbook workbook = new XSSFWorkbook();// �u�@��
            Sheet sheet = workbook.createSheet(fileName); // �]�w���j�p 

            // �]�w���j�p
            setSheetColumnWidth(sheet, totalColumns);

            // �g�J���
            createWorkbook(workbook, sheet, F180Map, F181List, user.getEmpName());

            // ���ͼȦs��
            File downloadFile = RptUtils.createTempFile(fileName);
            String path = downloadFile.getPath();
            fos = new FileOutputStream(path);
            workbook.write(fos);

            return new String[] { fileName, path };
        } finally {
            if (fos != null) {
                fos.close();
            }
        }
    }

    /** * �]�w���j�p 
     * @param sheet 
     * @param totalColumns 
     */
    private void setSheetColumnWidth(Sheet sheet, int totalColumns) {
        int i = 0;
        while (i < totalColumns) {
            sheet.setColumnWidth(i, 20 * 256);
            i++;
        }
    }

    /**
     * �]�w���
     * @param workbook
     * @param sheet
     * @param isNeedSub
     * @param rtnList
     * @throws ModuleException
     */
    private void createWorkbook(Workbook workbook, Sheet sheet, Map rtnMap, List<Map> rtnList, String empNm) throws ModuleException {

        // �]�wSTYLE
        CellStyle style1 = createStyle(workbook, 1, "�s�ө���");//�����Y
        CellStyle style2 = createStyle(workbook, 2, "�s�ө���");//�m����r
        CellStyle style3 = createStyle(workbook, 3, "�s�ө���");//�a�k��r
        CellStyle style4 = createStyle(workbook, 4, "�s�ө���");//�a����r
        CellStyle style5 = createStyle(workbook, 5, "�s�ө���");//�a����r�I���Ǧ�

        Row row;
        int beginRow = 0;
        int totalColumns = 7;

        // �K�n���
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style5, 0, MessageUtil.getMessage("EP_F10310_CMM_YM"), false, true, 0, 0, 0, 1);
        setColumn(sheet, row, style4, 2, DATE.getROCYearAndMonth(MapUtils.getString(rtnMap, "CMM_YM")), false, false, null, null, null,
            null);
        setColumn(sheet, row, style5, 3, MessageUtil.getMessage("EP_F10310_SUP_NM"), false, false, null, null, null, null);
        setColumn(sheet, row, style4, 4, MapUtils.getString(rtnMap, "SUP_ID"), false, false, null, null, null, null);
        setColumn(sheet, row, style5, 5, MessageUtil.getMessage("EP_F10310_SHEET_EMP_NM"), false, false, null, null, null, null);
        setColumn(sheet, row, style4, 6, empNm, false, false, null, null, null, null);
        beginRow++;

        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style5, 0, MessageUtil.getMessage("EP_F10310_CMM_CNT"), false, true, 1, 1, 0, 1);
        setColumn(sheet, row, style3, 2, MapUtils.getString(rtnMap, "TOT_CNT"), true, false, null, null, null, null);
        setColumn(sheet, row, style5, 3, MessageUtil.getMessage("EP_F10310_CMM_FEE"), false, false, null, null, null, null);
        //setColumn(sheet, row, style3, 4, MapUtils.getString(rtnMap, "TOT_CLR_AMT"), true, false, null, null, null, null);
        setColumn(sheet, row, style3, 4, MapUtils.getString(rtnMap, "TOT_CMM_FEE"), true, false, null, null, null, null);
        setColumn(sheet, row, style5, 5, MessageUtil.getMessage("EP_F10310_SHEET_DATE"), false, false, null, null, null, null);
        setColumn(sheet, row, style4, 6, DATE.toROCFormat(DATE.getDBDate(), "/"), false, false, null, null, null, null);
        beginRow += 2;

        // ���Y
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style1, 0, MessageUtil.getMessage("EP_F10310_SEQ"), false, false, null, null, null, null); // ����
        setColumn(sheet, row, style1, 1, MessageUtil.getMessage("EP_F10310_APLY_NO"), false, false, null, null, null, null); // �ץ�s��
        setColumn(sheet, row, style1, 2, MessageUtil.getMessage("EP_F10310_BLD_NM"), false, false, null, null, null, null);// �j�ӦW��
        setColumn(sheet, row, style1, 3, MessageUtil.getMessage("EP_F10310_FIX_MO"), false, false, null, null, null, null);// ��µ���e
        setColumn(sheet, row, style1, 4, MessageUtil.getMessage("EP_F10310_END_APLY_DATE"), false, false, null, null, null, null);// �����k�ɮɶ�
        setColumn(sheet, row, style1, 5, MessageUtil.getMessage("EP_F10310_CLR_AMT"), false, false, null, null, null, null);// ��µ���B
        setColumn(sheet, row, style1, 6, MessageUtil.getMessage("EP_F10310_CMM_FEE"), false, false, null, null, null, null);// ��޶O��
        beginRow++;

        // ���Ӹ��(�t�X�p,�s�դp�p)
        createDetail(beginRow, sheet, row, style2, style3, style4, rtnList, totalColumns);
    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @return
     */
    private CellStyle createStyle(Workbook workbook, int type, String font_type) {

        // Style
        CellStyle style = workbook.createCellStyle();

        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);

        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 1) {//�����D
            style.setAlignment(CellStyle.ALIGN_CENTER);
            font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(CellStyle.ALIGN_CENTER);
        } else if (type == 3) {//���ӼƦr
            style.setAlignment(CellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(CellStyle.ALIGN_LEFT);
        } else if (type == 5) {//�I���Ǧ�
            style.setAlignment(CellStyle.ALIGN_LEFT);
            style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
            style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        }

        style.setFont(font);

        //�~��
        style.setBorderTop(CellStyle.BORDER_THIN);
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBorderLeft(CellStyle.BORDER_THIN);
        style.setBorderRight(CellStyle.BORDER_THIN);

        return style;
    }

    /**
     * �إߪ��椺�e
     * @param beginRow
     * @param sheet
     * @param row
     * @param style2
     * @param style3
     * @param isNeedSub �O�_�ݸs�դp�p
     * @param rtnList ���Ӹ��
     * @param totalColumns �C�C���
     * @throws ModuleException
     */
    private void createDetail(int beginRow, Sheet sheet, Row row, CellStyle style2, CellStyle style3, CellStyle style4, List<Map> rtnList,
            int totalColumns) throws ModuleException {

        BigDecimal TOT_CMM_FEE = BigDecimal.ZERO;

        for (int i = 0; i < rtnList.size(); i++) {

            Map rtnMap = rtnList.get(i);
            row = sheet.createRow(beginRow);
            setColumn(sheet, row, style2, 0, String.valueOf(i + 1), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 1, MapUtils.getString(rtnMap, "APLY_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 2, MapUtils.getString(rtnMap, "BLD_NM"), false, false, null, null, null, null);
            setColumn(sheet, row, style4, 3, MapUtils.getString(rtnMap, "FIX_MO"), false, false, null, null, null, null);
            String END_APLY_DATE = MapUtils.getString(rtnMap, "END_APLY_DATE");
            if (StringUtils.isNotBlank(END_APLY_DATE)) {
                END_APLY_DATE = DATE.toROCFormat(END_APLY_DATE.substring(0, 10), "/");
            }
            setColumn(sheet, row, style2, 4, END_APLY_DATE, false, false, null, null, null, null);
            setColumn(sheet, row, style3, 5, MapUtils.getString(rtnMap, "CLR_AMT"), true, false, null, null, null, null);
            setColumn(sheet, row, style3, 6, MapUtils.getString(rtnMap, "CMM_FEE"), true, false, null, null, null, null);
            beginRow++;

            // �X�p�p��
            TOT_CMM_FEE = TOT_CMM_FEE.add(STRING.objToBigDecimal(rtnMap.get("CMM_FEE"), BigDecimal.ZERO)); // �`��޶O��
        }

        //�X�p
        row = sheet.createRow(beginRow);
        for (int j = 0; j < totalColumns; j++) {
            if (j == 0) {
                setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EP_F10310_TOTAL"), false, false, null, null, null, null);//�X�p
            } else if (j == 6) {
                setColumn(sheet, row, style3, 6, TOT_CMM_FEE.toPlainString(), true, false, null, null, null, null);
            } else {
                setColumn(sheet, row, style2, j, null, false, false, null, null, null, null); // �®تŮ�
            }
        }
    }

    private DecimalFormat df = new DecimalFormat("#,###");

    /**
     *  �]�w���
     * @param sheet
     * @param bodyRow
     * @param style ���A
     * @param columnNumber ���ͲĴX��cell
     * @param content  ���
     * @param isNumeric �O�_���Ʀr���
     * @param doCombine �O�_�ݦX���x�s��
     * @param firstRow
     * @param lastRow
     * @param firstCol
     * @param lastCol
     */
    private void setColumn(Sheet sheet, Row row, CellStyle style, Integer columnNumber, String content, boolean isNumeric,
            boolean doCombine, Integer firstRow, Integer lastRow, Integer firstCol, Integer lastCol) {

        Cell cell = row.createCell(columnNumber);
        cell.setCellStyle(style);

        if (doCombine) {
            for (int s = firstCol; s <= lastCol; s++) {
                cell = row.createCell(s);
                cell.setCellStyle(style);
            }

            //�X���x�s��
            CellRangeAddress range_inputCount = new CellRangeAddress(firstRow, lastRow, firstCol, lastCol);
            sheet.addMergedRegion(range_inputCount);

            cell = row.getCell(firstCol);
        }

        if (isNumeric) {
            if (StringUtils.isNotBlank(content)) {
                cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
                Double bodyText = new Double(content);
                cell.setCellValue(df.format(bodyText));
            }
        } else {
            RichTextString text = new XSSFRichTextString(content);
            cell.setCellValue(text);
        }
    }

    /**
     * ���o�H���m�W
     * @param LST_PROC_ID
     * @param tmpEmpMap
     * @param rtnMap
     * @param pd
     */
    private String getEmpName(String ID, Map<String, String> tmpEmpMap, PersonnelData pd, String SUB_CPY_ID) {
        if (StringUtils.isNotBlank(tmpEmpMap.get(ID))) {
            return tmpEmpMap.get(ID);
        }

        String tmp;
        String name;
        try {
            name = (String) getEmpMap(ID, true, SUB_CPY_ID).get("NAME");
        } catch (Exception e) {
            log.error("�~���H���d�L���");
            try {
                name = pd.getByEmployeeID2(ID).getName();
            } catch (SQLException e1) {
                log.error("�����H���d�L���");
                name = "�d�L���H";
            }

        }
        String divName;
        try {
            divName = pd.getByEmployeeID(ID).getDivShortName();
        } catch (Exception e) {
            divName = "�d�L�����";
        }
        tmp = name + "," + divName;
        tmpEmpMap.put(ID, tmp);
        return tmp;
    }
    
    /**
     * ���o�H�����
     * @param EMPLOYEE_ID
     * roleTp ����O 
     * 1    �{���޲z�H��
     * 2    ��µ�쬣��
     * 3    ��µ��
     * 4    ��µ��
     * 5    ��µ��b�ȸg��
     * 6    ��µ�հƲz
     * 7    ��µ�ոg�z
     * 8    ������
     * 9    �����լ���
     * A    �����հƲz
     * B    �����ոg�z
     * @return
     * @throws Exception
     */
    public Map getEmpData(Map dataMap, String roleTp, String SUB_CPY_ID) throws ModuleException {
        String empID;
        String empType;
        if ("3".equals(roleTp)) {//��µ�쬣��,��µ��
            empID = MapUtils.getString(dataMap, "FIX_DIV_ID");
            empType = "2";
            if (StringUtils.isBlank(empID)) {//FIX_DIV_ID����>��µ�쥼����
                return Collections.EMPTY_MAP;
            }
        } else if ("8".equals(roleTp)) {
            empID = MapUtils.getString(dataMap, "SUBCON_GROUP_ID");
            empType = "4";
        } else if ("4".equals(roleTp)) {
            empID = MapUtils.getString(dataMap, "FIX_GROUP_ID");
            empType = "3";
        } else if ("1".equals(roleTp)) {
            empID = MapUtils.getString(dataMap, "INPUT_ID");
            empType = "1";
        } else {
            return Collections.EMPTY_MAP;
        }
        try {
            return getEmpData(empID, empType, SUB_CPY_ID);
        } catch (Exception e) {
            log.fatal(e, e);
            throw new ModuleException(e);
        }

    }
    
    /**
     * ���o�H�����
     * @param EMPLOYEE_ID
     * @empType (1:�߮פH;2:��µ��;3:��µ��;4:������)
     * @return
     * @throws Exception
     */
    public Map getEmpData(String EMPLOYEE_ID, String empType, String SUB_CPY_ID) throws Exception {

        Map map = new HashMap<String, String>();
        if ("3".equals(empType) || "4".equals(empType)) {
            map = getEmpMap(EMPLOYEE_ID, true, SUB_CPY_ID);
        } else if ("2".equals(empType)) {
            map = getEmpMap(EMPLOYEE_ID, false, SUB_CPY_ID);
        } else {
            try {
                map = getEmpMap(EMPLOYEE_ID, true, SUB_CPY_ID);
            } catch (DataNotFoundException dnfe) {
                log.debug("�~�����u�d�L���");
                map = getEmpMap(EMPLOYEE_ID, false, SUB_CPY_ID);
            }
        }
        return map;
    }
    
    
    /**
     * ���o�H�����
     * @param ID
     * @return
     * @throws Exception
     */
    public Map getEmpMap(String ID, boolean isOut, String SUB_CPY_ID) throws Exception {

        Map map = new HashMap<String, String>();
        if (!isOut) {
            PersonnelData thePersonnelData = new PersonnelData();
            Employee emp = thePersonnelData.getByEmployeeID(ID, true);
            if (emp == null) {
                throw new ModuleException("�d�L�H�Ƹ��");
            }
            map.put("NAME", emp.getName());
            map.put("EMPLOYEE_ID", emp.getEmployeeId());
            map.put("EMAIL", emp.getEmail());
            map.put("DIV_NO", emp.getDivNo());
            map.put("DIV_SHORT_NAME", emp.getDivFullName());
            String PHONE1 = emp.getInstitutionPhone1();
            String PHONE2 = emp.getInstitutionPhone2();
            String PHONE3 = emp.getInstitutionPhone3();
            map.put("PHONE1", PHONE1);
            map.put("PHONE2", PHONE2);
            map.put("PHONE3", PHONE3);
            map.put("CELLPHONE", emp.getCellularPhone());
            log.fatal("emp:" + emp);
            String INSTITUTION_PHONE = "";
            if (StringUtils.isNotEmpty(PHONE1)) {
                if (PHONE2.startsWith(PHONE1)) {
                    INSTITUTION_PHONE = PHONE1 + "-" + PHONE2.substring(PHONE1.length());
                } else {
                    INSTITUTION_PHONE = PHONE1 + "-" + PHONE2;
                }
            } else {
                INSTITUTION_PHONE = PHONE2;
            }

            if (StringUtils.isNotEmpty(PHONE3)) {
                INSTITUTION_PHONE = INSTITUTION_PHONE + "-" + PHONE3;
            }

            map.put("INSTITUTION_PHONE", INSTITUTION_PHONE);
        } else {
            Map reqMap = new HashMap<String, String>();
            reqMap.put("FL_TP", "2");
            reqMap.put("DIV_TP", "Q");
            EP_Z00100 z1 = new EP_Z00100();
            map = z1.getEmp(ID, SUB_CPY_ID);
            map.put("DIV_SHORT_NAME", z1.getDivName(MapUtils.getString(map, "DIV_NO"), SUB_CPY_ID));
        }

        return map;
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {

        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
