package com.cathay.ep.f1.module;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.ep.vo.DTEPF120;
import com.cathay.ep.vo.DTEPF130;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F120;
import com.cathay.ep.z0.module.EP_Z0F130;

/**
 * Date Version Description Author
 * 2014/08/15  Created ����i 2014/08/15
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �Ƨѿ��ˮּҲ�
 * �{���W��    EPF1_0102_mod.java
 * �@�~�覡    MODULE
 * ���n����    
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EPF1_0102_mod {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPF1_0102_mod.class);

    /**
     * �ˮ֭�µ�ץ�i�׬O�_�i�קﲧ��
     * @param APLY_NO
     * @param user
     * @param btn_id
     * @throws Exception
     */
    public void chkChangeable(String APLY_NO, UserObject user, String btn_id, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_001")); //�ǤJ�ץ�s�����i����!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_002")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }
        //���o��µ�ץ�򥻸����
        Map DBF110Map;
        try {
            DBF110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_003"));//�L����µ�ץ�s��!
        }
        DTEPF120 F120Vo = new DTEPF120();
        F120Vo.setAPLY_NO(APLY_NO);
        F120Vo.setSUB_CPY_ID(SUB_CPY_ID);
        List<Map> DBF120VoList = new EP_Z0F120().queryF120List(F120Vo, false, null, false, null, null, null);
        String[] btnChangeArray = FieldOptionList.getName("EP", "BTN_CONTRAL", "BTN_CHANGE").split(",");
        if (!ArrayUtils.contains(btnChangeArray, btn_id)) {
            //�D��µ�ץ�t�d�H���i����!!
            String EMP_ID = user.getEmpID();
            if (!EMP_ID.equals(MapUtils.getString(DBF110Map, "FIX_DIV_ID"))
                    && !EMP_ID.equals(MapUtils.getString(DBF110Map, "FIX_GROUP_ID"))) {
                boolean isThrow = true;
                for (Map DBF120Map : DBF120VoList) {
                    String SUBCON_GROUP_ID = MapUtils.getString(DBF120Map, "SUBCON_GROUP_ID");
                    if (StringUtils.isNotBlank(SUBCON_GROUP_ID) && EMP_ID.equals(SUBCON_GROUP_ID)) {
                        isThrow = false;
                    }
                }
                if (isThrow) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_004"));//�D��µ�ץ�t�d�H���i����!
                }
            }
        }
        //�P�_�i�׬O�_�i�ק�
        String OP_STATUS = MapUtils.getString(DBF110Map, "OP_STATUS");
        if ("100".equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_005"));//��µ�ץ�i�׬��߮׫ݰe��A���i�ק�!
        } else if ("200".equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_006"));//��µ�ץ�i�׬��ݬ���(��µ��)�A���i�ק�!
        } else if ("300".equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_007"));//��µ�ץ�i�׬��ݬ���(��µ��)�A���i�ק�!
        } else if ("500".equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_008"));//��µ�ץ�i�פw�T�{���u�A���i�ק�!
        } else if ("600".equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_009"));//��µ�ץ�i�פw�����禬�A���i�ק�!
        } else if ("700".equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_010"));//��µ�ץ�i�פw�����禬�A���i�ק�!
        } else if ("800".equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_011"));//��µ�ץ�i�פw�����k�ɡA���i�ק�!
        } else if ("000".equals(OP_STATUS)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_012"));//��µ�ץ�i�פw�P�סA���i�ק�!
        }

    }

    /**
     * �ˮ֭�µ�ץ�i�׬O�_�i�i������
     * @param APLY_NO
     * @param MEMO_NO
     * @param SUB_CPY_ID
     * @param user
     * @param F120Vo
     * @param DBF110Map
     * @param DBF120VoList
     * @param btn_id
     * @param pass
     * @return
     * @throws Exception
     */
    public boolean chkApprove(String APLY_NO, String MEMO_NO, String SUB_CPY_ID, UserObject user, DTEPF120 F120Vo, Map DBF110Map,
            List<Map> DBF120VoList, String btn_id, String pass) throws Exception {
        boolean isApprove = true;
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_001")); //�ǤJ�ץ�s�����i����!
        }
        if (StringUtils.isBlank(MEMO_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_013")); //�ǤJ�Ƨѿ��渹���i����!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_002")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }

        //String APLY_TP = MapUtils.getString(DBF110Map, "APLY_TP");

        DTEPF130 F130Vo = new DTEPF130();
        F130Vo.setAPLY_NO(APLY_NO);
        F130Vo.setSUB_CPY_ID(SUB_CPY_ID);
        F130Vo.setMEMO_NO(Integer.valueOf(MEMO_NO));
        List<Map> DBF130VoList;
        try {
            DBF130VoList = new EP_Z0F130().queryF130List(F130Vo);
        } catch (DataNotFoundException e) {
            log.fatal("", e);
            DBF130VoList = new ArrayList<Map>();
        }

        //�Ƨѿ��e��
        //�ˮ֬O�_���u�{����
        if (btn_id.equals("btn_approve_A")) {
            this.chkPRO_NO(DBF130VoList);
        }

        //�w�ƬI�u
        //�ˮ֤u�جO�_������I�u���
        if (btn_id.equals("btn_approve_H")) {
            this.chkCONS_DATE(DBF130VoList, DBF120VoList.get(0));
        }

        //�T�{�u�k�B��������B�T�{����
        if ("btn_approve_B".equals(btn_id) || "btn_approve_E".equals(btn_id) || "btn_approve_F".equals(btn_id)) {
            if ("2".equals(F120Vo.getIS_BM())) {//�T�{�u�k�B��������B�T�{�����A�D��ޥ�u���@���u�{����
                if (DBF130VoList.size() > 1) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0102_MSG_chkIS_BM"));//�D��ޥ�u�঳�@���u�{����
                }
            }
            if ("btn_approve_E".equals(btn_id)) {//��������ˮ֤u�ؼt�Ӥ��i����
                StringBuilder sb = new StringBuilder();
                for (Map F130 : DBF130VoList) {
                    if (StringUtils.isBlank(MapUtils.getString(F130, "SUP_ID"))) {
                        sb.append(MapUtils.getString(F130, "PRO_NO")).append("�B");
                    }
                }

                if (sb.length() != 0) {
                    sb.setLength(sb.length() - 1);
                    throw new ModuleException("�u�ؼt�Ӥ��i����,�u�اǸ�:" + sb.toString());
                }
            }
        }

        //�b�q���I�u
        if ("btn_approve_G".equals(btn_id)) {//�b�q���I�u�ɡAF110.�O�κ�����"�u�{�k��"������ﶵ
            StringBuilder sb = new StringBuilder();
            StringBuilder sb2 = new StringBuilder();
            for (Map F130 : DBF130VoList) {
                if (StringUtils.isBlank(MapUtils.getString(F130, "PRO_OWN"))) {
                    sb.append(MapUtils.getString(F130, "PRO_NO")).append("�B");
                }
                if ("1".equals(MapUtils.getString(F130, "IS_CONT"))) {//�X����
                    if (StringUtils.isBlank(MapUtils.getString(F130, "CONT_NO"))
                            || STRING.objToBigDecimal(F130.get("CONT_AMT"), null) == null) {
                        sb2.append(MapUtils.getString(F130, "PRO_NO")).append("�B");
                    }
                }
            }
            String PRO_OWN_ERR = "";
            if (sb.length() != 0) {
                sb.setLength(sb.length() - 1);
                PRO_OWN_ERR = sb.toString();
                log.debug("### PRO_OWN_ERR:" + PRO_OWN_ERR);
                sb.setLength(0);
            }
            String CONT_ERR = "";
            if (sb2.length() != 0) {
                sb2.setLength(sb2.length() - 1);
                CONT_ERR = sb2.toString();
                log.debug("### CONT_ERR:" + CONT_ERR);
                sb2.setLength(0);
            }
            String EXP_TP_ERR = "";
            if (StringUtils.isBlank(MapUtils.getString(DBF110Map, "EXP_TP"))) {
                EXP_TP_ERR = MessageUtil.getMessage("EPF1_0102_mod_MSG_026");//�O���`�����i����
            }

            if (StringUtils.isNotBlank(EXP_TP_ERR)) {
                sb.append(EXP_TP_ERR);
            }
            if (StringUtils.isNotBlank(PRO_OWN_ERR)) {
                if (sb.length() != 0) {
                    sb.append(STRING.lineSeparator);
                }
                sb.append(MessageUtil.getMessage("EPF1_0102_mod_MSG_027")/*�u�{�k�ݤ��i����:*/).append(PRO_OWN_ERR);
            }
            if (StringUtils.isNotBlank(CONT_ERR)) {
                if (sb.length() != 0) {
                    sb.append(STRING.lineSeparator);
                }
                sb.append(MessageUtil.getMessage("EPF1_0102_mod_MSG_028")/*�X���󤧦X���s��/�X�����B���i����:*/).append(CONT_ERR);
            }

            if (sb.length() != 0) {
                throw new ModuleException(sb.toString());
            }
        }

        //�D��µ�ץ�t�d�H���i����!!
        //String[] btnAprvArray = new String[] { "btn_approve_I", "btn_approve_J", "btn_approve_D" };
        String[] btnAprvArray = FieldOptionList.getName("EP", "BTN_CONTRAL", "BTN_APRV").split(",");
        if (!ArrayUtils.contains(btnAprvArray, btn_id)) {
            String EMP_ID = user.getEmpID();
            String FIX_DIV_ID = MapUtils.getString(DBF110Map, "FIX_DIV_ID");
            String FIX_GROUP_ID = MapUtils.getString(DBF110Map, "FIX_GROUP_ID");
            if (!EMP_ID.equals(FIX_DIV_ID) && !EMP_ID.equals(FIX_GROUP_ID)) {
                boolean isThrow = true;
                for (Map DBF120Map : DBF120VoList) {
                    String SUBCON_GROUP_ID = MapUtils.getString(DBF120Map, "SUBCON_GROUP_ID");
                    String OP_STATUS = MapUtils.getString(DBF120Map, "OP_STATUS");
                    if (EP_Z0F120.ST_440.equals(OP_STATUS)) {//�T�{�u�k(�ݬ���(�o�]��))
                        //2:�@���
                        if (StringUtils.isBlank(SUBCON_GROUP_ID)) {
                            isThrow = false;
                        } else if (StringUtils.isNotBlank(SUBCON_GROUP_ID) && EMP_ID.equals(SUBCON_GROUP_ID)) {
                            isThrow = false;
                        }
                    } else if (StringUtils.isNotBlank(SUBCON_GROUP_ID) && EMP_ID.equals(SUBCON_GROUP_ID)) {
                        isThrow = false;
                    }
                }
                if (isThrow) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_004"));//�D��µ�ץ�t�d�H���i����!
                }
            }
        }

        //�P�_�i�׬O�_�i�ק�
        for (Map DBF120Map : DBF120VoList) {
            //String OP_STATUS = MapUtils.getString(DBF120Map, "OP_STATUS");
            if (btn_id.equals("btn_approve_A")/*EP_Z0F120.ST_410.equals(OP_STATUS)*/) {//�s�W(�ݳƧѿ��e��)
                if (StringUtils.isBlank(MapUtils.getString(DBF120Map, "IS_BM"))) {
                    eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_014")); //��ޥ󤣥i����!
                }
                if (StringUtils.isBlank(MapUtils.getString(DBF120Map, "MEMO_MO"))) {
                    eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_015")); //�Ƨѿ��������i����!
                }
                if (StringUtils.isBlank(MapUtils.getString(DBF120Map, "PPL_FILE_NO")) && !"true".equals(pass)) {
                    eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_017")); //�e�֪��ɮפ��i����!
                }
                if (StringUtils.isBlank(MapUtils.getString(DBF120Map, "MEMO_FILE_NO")) && !"true".equals(pass)) {
                    eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_018")); //�Ƨѿ��ɮפ��i����!
                }
                if (eie != null) {
                    throw eie;
                }
            } else if (btn_id.equals("btn_approve_B")/*EP_Z0F120.ST_420.equals(OP_STATUS)*/) {//�e��(�ݽT�{�u�k)
                if (StringUtils.isBlank(F120Vo.getCFM_WORK_MO())) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_019")); //�T�{�u�k�������i����!
                }
            } else if (btn_id.equals("btn_approve_D")/*EP_Z0F120.ST_440.equals(OP_STATUS)*/) {//�T�{�u�k(�ݬ���(�o�]��))
                if (StringUtils.isBlank(F120Vo.getSUBCON_GROUP_ID())) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_021")); //�o�]�դH�����i����!
                }
            } else if (btn_id.equals("btn_approve_E")/*EP_Z0F120.ST_450.equals(OP_STATUS)*/) {//�o�]�դw����(�ݴ������)
                this.chkPRO_NO(DBF130VoList);

                if (StringUtils.isBlank(MapUtils.getString(DBF120Map, "MEMO_AMT"))) {
                    eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_016")); //�Ƨѿ����B���i����!
                }

                if (eie != null) {
                    throw eie;
                }

                //�v���P�_�u�{�����������B
                for (Map DBF130Map : DBF130VoList) {
                    if (StringUtils.isBlank(MapUtils.getString(DBF130Map, "CLR_AMT"))) {
                        throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_022")); //�|���u�{��������������B!
                    }
                }
            }

        }

        return isApprove;
    }

    /**
     * �ˮ֭�µ�ץ�i�׬O�_�i�i������
     * @param APLY_NO
     * @param MEMO_NO
     * @param SUB_CPY_ID
     * @param user
     * @param btn_id
     * @throws Exception
     */
    public void chkReject(String APLY_NO, String MEMO_NO, String SUB_CPY_ID, UserObject user, String btn_id) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_001")); //�ǤJ�ץ�s�����i����!
        }
        if (StringUtils.isBlank(MEMO_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_013")); //�ǤJ�Ƨѿ��渹���i����!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0102_mod_MSG_002")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }
        //���o��µ�ץ�򥻸����
        Map DBF110Map;
        try {
            DBF110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_003"));//�L����µ�ץ�s��!
        }
        List<Map> DBF120VoList = new EP_Z0F120().queryF120List(APLY_NO, MEMO_NO, SUB_CPY_ID);

        //�D��µ�ץ�t�d�H���i����!!
        String[] btnRejcArray = FieldOptionList.getName("EP", "BTN_CONTRAL", "BTN_REJECT").split(",");
        if (!ArrayUtils.contains(btnRejcArray, btn_id)) {
            String EMP_ID = user.getEmpID();
            if (!EMP_ID.equals(MapUtils.getString(DBF110Map, "FIX_DIV_ID"))
                    && !EMP_ID.equals(MapUtils.getString(DBF110Map, "FIX_GROUP_ID"))) {
                boolean isThrow = true;
                for (Map DBF120Map : DBF120VoList) {
                    String SUBCON_GROUP_ID = MapUtils.getString(DBF120Map, "SUBCON_GROUP_ID");
                    if (StringUtils.isNotBlank(SUBCON_GROUP_ID) && EMP_ID.equals(SUBCON_GROUP_ID)) {
                        isThrow = false;
                    }
                }
                if (isThrow) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_004"));//�D��µ�ץ�t�d�H���i����!
                }
            }
        }
        //�P�_�i�׬O�_�i�ק�
        for (Map DBF120Map : DBF120VoList) {
            String OP_STATUS = MapUtils.getString(DBF120Map, "OP_STATUS");
            if (EP_Z0F120.ST_490.equals(OP_STATUS)) {
                throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_024"));//�Ƨѿ��w�w�ƬI�u�A���i�����վ�!
            } else if (EP_Z0F120.ST_499.equals(OP_STATUS)) {
                throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_025"));//�Ƨѿ��w�P�סA���i�����վ�!
            }
        }
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    //�o�]�դH��ID���@
    public boolean isSubListId(List<Map> SUBCON_GROUP_ID_LIST, UserObject user) {
        boolean isSubconGroupIdList = false;
        for (Map map : SUBCON_GROUP_ID_LIST) {
            if (StringUtils.isNotBlank(MapUtils.getString(map, user.getEmpID()))) {
                isSubconGroupIdList = true;
            }
        }
        return isSubconGroupIdList;
    }

    //��µ��H��
    public boolean isFixUser(Map rtnF110Map, UserObject user) {
        String FIX_DIV_ID = MapUtils.getString(rtnF110Map, "FIX_DIV_ID");
        return user.getEmpID().equals(FIX_DIV_ID);
    }

    //��µ��b�ȤH��
    public boolean isAccountsUser(Map rtnF110Map, UserObject user, String[] ACCOUNT_IDS) {
        String FIX_DIV_ID = MapUtils.getString(rtnF110Map, "FIX_DIV_ID");
        String OP_STATUS = MapUtils.getString(rtnF110Map, "OP_STATUS");
        if (EP_Z0F110.ST_700.equals(OP_STATUS) && StringUtils.isNotBlank(FIX_DIV_ID) && ArrayUtils.contains(ACCOUNT_IDS, user.getEmpID())) {
            //�b�ȤH���A�˵��ݵ����k��
            return true;
        }
        return false;
    }

    //��µ��D��
    public boolean isFixUserMgr(UserObject user) {
        String MANAGE_ROLE = FieldOptionList.getName("EP", "EP_ROLES", "MANAGE_ROLE");//"RLEP018"�D��ñ��
        return user.getRoles().containsKey(MANAGE_ROLE);
    }

    //��µ�դH��
    public boolean isFixGroupUser(Map rtnF110Map, UserObject user) {
        String FIX_GROUP_ID = MapUtils.getString(rtnF110Map, "FIX_GROUP_ID");
        return user.getEmpID().equals(FIX_GROUP_ID);
    }

    //��A����
    public boolean isItSuperRole(String CHK_ROLE, UserObject user) {
        boolean ischeckRole = user.getRoles().containsKey(CHK_ROLE);
        if (!ischeckRole) {
            try {
                //���o�Ӻޤ��]����
                String DIV_ROLE = FieldOptionList.getName("EP", "EP9_ROLE", user.getOpUnit());//"RLEP018"�D��ñ��
                ischeckRole = CHK_ROLE.equals(DIV_ROLE);
            } catch (Exception e) {

            }
        }
        return ischeckRole;
    }

    //�W�űb��
    public boolean isSuperIdMap(String[] superId, UserObject user) {
        return ArrayUtils.contains(superId, user.getEmpID());
    }

    //�o�]�պ޲z�H��
    public boolean isSubconMgr(String IS_MGR, String SUBCON_GROUP_ROLE0, UserObject user) {
        return (isItSuperRole(SUBCON_GROUP_ROLE0, user) && EP_Z0F110.ST_1.equals(IS_MGR));
    }

    public boolean isInputAgent(UserObject user) {

        log.debug("#### user:" + user);
        String inputAgent1 = FieldOptionList.getName("EP", "DIV_F106", "INPUT_AGENT1");
        log.debug("user.getRoles:" + user.getRoles());
        log.debug("inputAgent1:" + inputAgent1 + "; " + user.getRoles().containsKey(inputAgent1));
        if (user.getRoles().containsKey(inputAgent1)) {
            return true;
        }
        String inputAgent2 = FieldOptionList.getName("EP", "DIV_F106", "INPUT_AGENT2");
        log.debug("inputAgent2:" + inputAgent1 + "; " + user.getRoles().containsKey(inputAgent2));
        if (user.getRoles().containsKey(inputAgent2)) {
            return true;
        }
        return false;
    }

    //�߮פH
    public boolean isInputUser(Map rtnF110Map, UserObject user) {
        String INPUT_ID = MapUtils.getString(rtnF110Map, "INPUT_ID");
        String INPUT_DIV_NO = MapUtils.getString(rtnF110Map, "INPUT_DIV_NO");

        log.fatal("INPUT_ID:" + INPUT_ID);
        log.fatal("INPUT_DIV_NO:" + INPUT_DIV_NO);
        String OP_STATUS = MapUtils.getString(rtnF110Map, "OP_STATUS", "");
        log.fatal("OP_STATUS:" + OP_STATUS);
        //�ư� �ۥέ�µ�g��
        if (isInputAgent(user)) {
            return false;
        }

        if (StringUtils.isEmpty(INPUT_ID)) {
            return true;
        } else {
            boolean isSamePeople = user.getEmpID().equals(INPUT_ID);
            if (isSamePeople) {
                //�P�H
                return isSamePeople;
            } else {
                //�P���
                String divNo = user.getOpUnit();
                String chkDivNo = getChkDivNo(divNo);
                log
                        .debug("INPUT_DIV_NO:" + INPUT_DIV_NO + " chkDivNo[" + divNo + "]" + chkDivNo + ": "
                                + INPUT_DIV_NO.startsWith(chkDivNo));
                return INPUT_DIV_NO.startsWith(chkDivNo);
            }
        }
    }

    //���o�Ұϳ��A�h�����N�����ƹs
    public String getChkDivNo(String divNO) {
        Pattern pe2 = Pattern.compile("(\\w*[^0]+)([0]*)$");
        Matcher con2 = pe2.matcher(divNO);
        log.debug("Test DivNO");
        String chkDiv = divNO;
        if (con2.find()) {
            chkDiv = con2.group(1);
        }
        log.debug("divno[" + divNO + "], chk divNo:" + chkDiv);
        return chkDiv;
    }

    //�߮פH
    public boolean isInputAgent(Map rtnF110Map, UserObject user) {
        String INPUT_DIV_NO = MapUtils.getString(rtnF110Map, "INPUT_DIV_NO");
        if (StringUtils.isBlank(INPUT_DIV_NO)) {//���e��LINPUT_DIV_NO
            return true;
        }
        //�ư� �ۥέ�µ�g��
        String inputAgent1 = FieldOptionList.getName("EP", "DIV_F106", "INPUT_AGENT1");
        String inputAgent2 = FieldOptionList.getName("EP", "DIV_F106", "INPUT_AGENT2");
        Hashtable userRoles = user.getRoles();
        log.debug("#### isInputAgent.userRoles = " + userRoles);
        if (userRoles.containsKey(inputAgent1) || userRoles.containsKey(inputAgent2)) {
            /* INPUT_DIV_NO�h0,user_DIV_NO�h0
             * ����.startWith(�u��) = true
             * ex.INPUT_DIV_NO = 9301200;user_DIV_NO = 9301299 (user����J�H�����ҤU)
             * INPUT_DIV_NO = 9301299;user_DIV_NO = 9301200 (user����J�H�����D��)
             */
            String user_DIV_NO = this.getChkDivNo(user.getOpUnit());
            INPUT_DIV_NO = this.getChkDivNo(INPUT_DIV_NO);
            log.debug("#### userDIV_NO = " + user_DIV_NO);
            log.debug("#### INPUT_DIV_NO = " + INPUT_DIV_NO);

            return (INPUT_DIV_NO.length() > user_DIV_NO.length()) ? INPUT_DIV_NO.startsWith(user_DIV_NO) : user_DIV_NO
                    .startsWith(INPUT_DIV_NO);
        }
        return false;
    }

    /**
     * �w�ƬI�u,�ˮ֬I�u����O�_����
     * @param SUB_CPY_ID
     * @param APLY_NO
     * @param MEMO_NO
     * @throws Exception
     */
    public void chkCONS_DATE(List<Map> F130List, Map F120vo) throws Exception {
        String CHK_DATE = "2".equals(MapUtils.getString(F120vo, "APLY_TP")) ? MapUtils.getString(F120vo, "INFM_CONS_DATE") : MapUtils
                .getString(F120vo, "PRE_CONS_DATE");//�@��:�q���I�u���||����:����I�u�q�����
        for (Map F130 : F130List) {
            String CONS_SDATE = MapUtils.getString(F130, "CONS_SDATE");
            String CONS_EDATE = MapUtils.getString(F130, "CONS_EDATE");
            this.chkCONS_DATE(CONS_SDATE, CONS_EDATE, CHK_DATE);
        }
    }

    public void chkCONS_DATE(String CONS_SDATE, String CONS_EDATE, String CHK_DATE) throws Exception {

        if (StringUtils.isBlank(CONS_SDATE) || StringUtils.isBlank(CONS_EDATE)) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_029"));//�w�ƬI�u:�I�u������i����
        }
        if (DATE.diffDay(CHK_DATE, CONS_SDATE) < 0 || DATE.diffDay(CHK_DATE, CONS_EDATE) < 0) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_030"));//�w�ƬI�u:�I�u������i�p��I�u�q�����
        }
    }

    /**
     * �Ƨѿ��e��:�ˮ֤u�ؤ��i����
     * @param SUB_CPY_ID
     * @param APLY_NO
     * @param MEMO_NO
     * @param APLY_TP
     * @param F120vo
     * @throws Exception
     */
    public void chkPRO_NO(List<Map> F130List) throws Exception {
        if (F130List == null || F130List.isEmpty()) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_031"));//�п�J�u�{����
        }

        for (Map F130 : F130List) {
            String PROJECT_TP = MapUtils.getString(F130, "PROJECT_TP");
            if (StringUtils.isBlank(PROJECT_TP)) {
                throw new ModuleException(MessageUtil.getMessage("EPF1_0102_mod_MSG_032"));//�u�{�������i����
            }
        }
    }

}
