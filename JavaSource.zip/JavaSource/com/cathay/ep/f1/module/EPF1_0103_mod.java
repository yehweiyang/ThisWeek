package com.cathay.ep.f1.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.FieldOptionList;
import com.cathay.ep.vo.DTEPF130;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F120;
import com.cathay.ep.z0.module.EP_Z0F130;

/**
 * Date Version Description Author
 * 2014/08/15  Created ����i 2014/08/15
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �������R�ˮּҲ�
 * �{���W��    EPF1_0104_mod.java
 * �@�~�覡    MODULE
 * ���n����    
 * @author �Ťl��
 *
 */
@SuppressWarnings("unchecked")
public class EPF1_0103_mod {
    private static final Logger log = Logger.getLogger(EPF1_0103_mod.class);

    /**
     * 
     * @param APLY_NO
     * @param user
     * @param MEMO_NO
     * @param opType : 1:�s�W/�R��; 2: �ק� ;3:��s���u���
     * @throws Exception
     */
    public Map chkChangeable(String APLY_NO, UserObject user, Integer MEMO_NO, String opType, String SUB_CPY_ID) throws Exception {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0103_mod_MSG_001")); //�ǤJ�ץ�s�����i����!
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020")); //�����q�O���o���ŭ�
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EPF1_0103_mod_MSG_002")); //�ǤJ�ϥΪ̸�T����!
        }
        if (eie != null) {
            throw eie;
        }
        //���o��µ�ץ�򥻸����
        //���o��µ�ץ�򥻸����
        Map DBF110Map;
        try {
            DBF110Map = new EP_Z0F110().queryMap(APLY_NO, SUB_CPY_ID);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EPF1_0103_mod_MSG_003"));//�L����µ�ץ�s��!
        }
        //�D��µ�ץ�t�d�H���i����!!
        List<Map> DBF120VoList = new EP_Z0F120().queryF120List(APLY_NO, MEMO_NO.toString(), SUB_CPY_ID);//�]�t�h��O��
        //�L�o
        String EMP_ID = user.getEmpID();
        if (!EMP_ID.equals(MapUtils.getString(DBF110Map, "FIX_DIV_ID")) && !EMP_ID.equals(MapUtils.getString(DBF110Map, "FIX_GROUP_ID"))) {
            boolean isThrow = true;
            for (Map DBF120Map : DBF120VoList) {
                String SUBCON_GROUP_ID = MapUtils.getString(DBF120Map, "SUBCON_GROUP_ID");
                if (EMP_ID.equals(SUBCON_GROUP_ID)) {
                    isThrow = false;
                }
            }
            if (isThrow) {
                throw new ModuleException(MessageUtil.getMessage("EPF1_0103_mod_MSG_004"));//�D��µ�ץ�t�d�H���i����!
            }
        }

        //�P�_�i�׬O�_�i�ק� //151104 modified:�ק��ˮ�
        String OP_STATUS = MapUtils.getString(DBF110Map, "OP_STATUS");
        String can_upd_OP_STATUSs = FieldOptionList.getName("EP", "UPD_OP_STATUS", "F110");
        String[] can_upd_OP_STATUS = can_upd_OP_STATUSs.split(",");
        boolean isFIX_DIV_UPD_OP_STATUS = (ArrayUtils.contains(can_upd_OP_STATUS, OP_STATUS) && EMP_ID.equals(MapUtils.getString(DBF110Map,
            "FIX_DIV_ID")));
        DBF110Map.put("isFIX_DIV_UPD_OP_STATUS", isFIX_DIV_UPD_OP_STATUS);
        if (!isFIX_DIV_UPD_OP_STATUS) {//��µ��H���i�ק�)
            if (!EP_Z0F110.ST_400.equals(OP_STATUS)) {
                if ("1".equals(opType)) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0103_mod_MSG_017"));//��µ�ץ�i�׫D�Ƨѿ��B�z���A���i�s�W/�R���u��!
                } else if ("2".equals(opType)) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0103_mod_MSG_018"));//��µ�ץ�i�׫D�Ƨѿ��B�z���A���i�ק�u��!   
                } else if ("3".equals(opType)) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0103_mod_MSG_019"));//��µ�ץ�i�׫D�Ƨѿ��B�z���A���i��s���u���!  
                }
            }

            //�v���P�_�Ƨѿ��i��:
            StringBuilder sb = new StringBuilder();
            for (Map DBF120Map : DBF120VoList) {
                sb.setLength(0);
                String CHK_KEY = sb.append("F120_").append(MapUtils.getString(DBF120Map, "APLY_TP")).append("_").append(opType).toString();

                String CHK_STS = FieldOptionList.getName("EP", "F0103_CHK_STS", CHK_KEY);
                String CHK_STS_MSG = FieldOptionList.getName("EP", "F0103_CHK_STS_MSG", CHK_KEY);
                if (StringUtils.isBlank(CHK_STS) || StringUtils.isBlank(CHK_STS_MSG)) {
                    throw new ModuleException(MessageUtil.getMessage("EPF1_0103_mod_MSG_020"));//�Ƨѿ��ץ��ˮ֪��A���]�w
                }
                List<String> CHK_STSs = new ArrayList<String>();
                Collections.addAll(CHK_STSs, CHK_STS.split("\\|"));
                log.debug("### CHK_STSs:" + CHK_STSs);
                String OP_STATUS_MEMO = MapUtils.getString(DBF120Map, "OP_STATUS");
                log.debug("### OP_STATUS_MEMO:" + OP_STATUS_MEMO);
                if (!CHK_STSs.contains(OP_STATUS_MEMO)) {
                    throw new ModuleException(CHK_STS_MSG);
                }
            }
        }
        return DBF110Map;

    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �ˮּt��
     * @param f130
     * @throws Exception 
     */
    public void chkSUP_ID(DTEPF130 F130) throws Exception {
        DTEPF130 reqF130 = new DTEPF130();
        reqF130.setSUB_CPY_ID(F130.getSUB_CPY_ID());
        reqF130.setAPLY_NO(F130.getAPLY_NO());
        List<Map> DBF130VoList = new EP_Z0F130().queryF130List(reqF130);

        String chk_SUP_ID = F130.getSUP_ID();
        for (Map F130map : DBF130VoList) {
            String map_SUP_ID = MapUtils.getString(F130map, "SUP_ID");
            if (StringUtils.equals(chk_SUP_ID, map_SUP_ID) && (F130.getPRO_NO().compareTo(MapUtils.getInteger(F130map, "PRO_NO"))) != 0) {
                throw new ModuleException(MessageUtil.getMessage("EPF1_0103_mod_MSG_021", new Object[] {
                        MapUtils.getString(F130map, "MEMO_NO"), MapUtils.getString(F130map, "PRO_NO") }));
                //���t�Ӥw�s�b:�Ƨѿ�{0},�u�اǸ�{1}
            }
        }

    }
}
