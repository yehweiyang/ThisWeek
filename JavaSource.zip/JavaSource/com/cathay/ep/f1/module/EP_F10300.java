package com.cathay.ep.f1.module;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.DivData;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.ConfigManager;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.common.util.http.HttpClientHelper;
import com.cathay.common.util.http.HttpClientHelper.HttpResponseType;
import com.cathay.dj.a0.module.DJ_A0Z002;
import com.cathay.dj.bo.DTDJA004;
import com.cathay.ep.z0.module.EP_Z00100;
import com.cathay.ep.z0.module.EP_Z0F110;
import com.cathay.ep.z0.module.EP_Z0F160;
import com.cathay.ep.z0.module.EP_Z0F170;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.rpt.RptUtils;
import com.cathay.rz.z0.module.RZ_Z0Z002;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * DATE Description Author
 * 2014/09/22  Created ����i
 * 2018/09/10  Updated �L�ç� �q���@�~�ӽЮ�180724001527:��µ�дڨt���u�� 
 * 
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �C�L�禬��ƺ��@�Ҳ�
 * �Ҳ�ID    EP_F10300 
 * ���n����    �C�L�禬��ƺ��@�Ҳ�
 * @author �Ťl��
 * @version 2018-12-11 ���~�� �վ�߮׸�Ƶe���C�L�\��i�H�ήץ�s���C�L�禬��P�дک��Ӫ�
 * [2019.04.18] �į�ﵽ
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_F10300 {

    private static final String SQL_queryList_001 = "com.cathay.ep.f1.module.EP_F10300.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.f1.module.EP_F10300.SQL_queryList_002";

    //private static final String SQL_insert_001 = "com.cathay.ep.f1.module.EP_F10300.SQL_insert_001";

    //private static final String SQL_insert_002 = "com.cathay.ep.f1.module.EP_F10300.SQL_insert_002";

    private static final String SQL_printRent_001A = "com.cathay.ep.f1.module.EP_F10300.SQL_printRent_001A";

    private static final String SQL_printRent_001 = "com.cathay.ep.f1.module.EP_F10300.SQL_printRent_001";

    private static final String SQL_printRent_002 = "com.cathay.ep.f1.module.EP_F10300.SQL_printRent_002";

    private static final String SQL_printRent_003 = "com.cathay.ep.f1.module.EP_F10300.SQL_printRent_003";

    private static final String SQL_printRent_004 = "com.cathay.ep.f1.module.EP_F10300.SQL_printRent_004";

    private static final String SQL_printRent_005 = "com.cathay.ep.f1.module.EP_F10300.SQL_printRent_005";

    private static final String SQL_queryList_003 = "com.cathay.ep.f1.module.EP_F10300.SQL_queryList_003";

    private static final String SQL_queryList_004 = "com.cathay.ep.f1.module.EP_F10300.SQL_queryList_004";

    private static final String SQL_insert_003 = "com.cathay.ep.f1.module.EP_F10300.SQL_insert_003";

    private static BigDecimal BD_105 = new BigDecimal("1.05");

    private static final Logger log = Logger.getLogger(EP_F10300.class);

    private boolean isDebug = log.isDebugEnabled();

    private static final String SQL_queryList_007 = "com.cathay.ep.f1.module.EP_F10300.SQL_queryList_007";

    private static final String SQL_printRent_007 = "com.cathay.ep.f1.module.EP_F10300.SQL_printRent_007";

    private static final String SQL_queryList_008 = "com.cathay.ep.f1.module.EP_F10300.SQL_queryList_008";

    private static final String SQL_printRent_008 = "com.cathay.ep.f1.module.EP_F10300.SQL_printRent_008";

    /**
     * Ū���C�L�禬���
     * @param reqMap
     * @param user
     * @return
     * @throws Exception 
     */
    public List<Map> queryList(Map reqMap, UserObject user) throws Exception {

        String SUB_CPY_ID = null;

        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_F10300_MSG_001"));//�ǤJ��Ƥ��i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        DataSet ds = Transaction.getDataSet();
        String DATE_TP = MapUtils.getString(reqMap, "DATE_TP");
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        setFieldIfExist(ds, reqMap, "USE_TP");
        setFieldIfExist(ds, reqMap, "EXP_TP");
        setFieldIfExist(ds, reqMap, "OP_STATUS");
        setFieldIfExist(ds, reqMap, "APLY_TP");
        setFieldIfExist(ds, reqMap, "BLD_CD");
        setFieldIfExist(ds, reqMap, "APLY_NO");
        String DATE_S = MapUtils.getString(reqMap, "DATE_S");
        String DATE_E = MapUtils.getString(reqMap, "DATE_E");
        if ("1".equals(DATE_TP)) {
            if (StringUtils.isNotBlank(DATE_S) && StringUtils.isNotBlank(DATE_E)) {
                ds.setField("DATE_TP_1", "1");
                ds.setField("DATE_S", DATE_S);
                ds.setField("DATE_E", DATE_E);
            }
        } else if ("2".equals(DATE_TP)) {
            if (StringUtils.isNotBlank(DATE_S) && StringUtils.isNotBlank(DATE_E)) {
                ds.setField("DATE_TP_2", "2");
                ds.setField("DATE_S", DATE_S);
                ds.setField("DATE_E", DATE_E);
            }
        } else if ("3".equals(DATE_TP)) {
            if (StringUtils.isNotBlank(DATE_S) && StringUtils.isNotBlank(DATE_E)) {
                ds.setField("DATE_TP_3", "3");
                ds.setField("DATE_S", DATE_S);
                ds.setField("DATE_E", DATE_E);
            }
        }
        String IS_CONT = MapUtils.getString(reqMap, "IS_CONT");
        if ("1".equals(IS_CONT)) {
            ds.setField("IS_CONT_1", "1");
        } else if ("2".equals(IS_CONT)) {
            ds.setField("IS_CONT_2", "2");
        }
        String NOT_PAY = MapUtils.getString(reqMap, "NOT_PAY");
        if ("1".equals(NOT_PAY)) {
            ds.setField("NOT_PAY", "1");
        }

        //�̳��������d�߸�ơA���ͳ���
        String REPORT_TP = MapUtils.getString(reqMap, "REPORT_TP");
        String APLY_NO = MapUtils.getString(reqMap, "APLY_NO");
        String APLY_TP = MapUtils.getString(reqMap, "APLY_TP");
        if ("7".equals(REPORT_TP)) {//(�ץ�w�д�)�AEXCEL����
            DBUtil.searchAndRetrieve(ds, SQL_queryList_007);
        } else if ("8".equals(REPORT_TP)) {//(�w�q���I�u�|���д�)�AEXCEL����
            DBUtil.searchAndRetrieve(ds, SQL_queryList_008);
        } else if ("5".equals(REPORT_TP)) {//(�q���}�o�����Ӫ�)�AEXCEL����
            if (StringUtils.isBlank(APLY_NO)) {
                if (!"1".equals(APLY_TP)) {
                    ds.setField("NOT_APLY_TP", "1");
                }
            }
            DBUtil.searchAndRetrieve(ds, SQL_queryList_002);
        } else if ("4".equals(REPORT_TP)) {//�дک��Ӫ�
            DBUtil.searchAndRetrieve(ds, SQL_queryList_003);
        } else if ("3".equals(REPORT_TP)) {//�дک��Ӫ�
            DBUtil.searchAndRetrieve(ds, SQL_queryList_003);
        } else if ("2".equals(REPORT_TP)) { //�u�{�дڥӽЪ�
            if (StringUtils.isBlank(APLY_NO)) {
                if (!"1".equals(APLY_TP)) {
                    ds.setField("NOT_APLY_TP", "1");
                }
            }
            DBUtil.searchAndRetrieve(ds, SQL_queryList_004);
        } else {
            if (StringUtils.isBlank(APLY_NO)) {
                if (!"1".equals(APLY_TP)) {
                    ds.setField("NOT_APLY_TP", "1");
                }
            }
            DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        }
        List<Map> rtnList = new ArrayList();
        EP_Z0F110 theEP_Z0F110 = new EP_Z0F110();
        EP_Z00100 theEP_Z00100 = new EP_Z00100();
        RZ_Z0Z002 theRZ_Z0Z002 = new RZ_Z0Z002();//[2019.04.18]�į�ﵽ
        DivData divData = new DivData();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            //2018-06-19 ���~�� �t�X�~������k�վ�ǤJ�Ѽ�
            rtnMap.put("REPORT_TP", REPORT_TP);
            this.getNM(rtnMap, theEP_Z0F110, theEP_Z00100, divData, theRZ_Z0Z002);//[2019.04.18]�į�ﵽ
            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
     * �s�W(�s�P)�дڮ־P���
     * @param reqList
     * @param user
     * @param reqMap
     * @throws ModuleException
     * @throws DBException 
     */
    public void insert(List<Map> reqList, UserObject user, Map reqMap) throws ModuleException, DBException {
        ErrorInputException eie = null;

        if (reqList == null || reqList.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_003"));//�ǤJ�ץ�s�����i����
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_004"));// �ǤJ�ϥΪ̸�T���i���� 
        }
        if (reqMap == null || reqMap.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_005"));// �ǤJ�d�߱��󤣥i����
        }
        if (eie != null) {
            throw eie;
        }
        List<String> aplyNoList = new ArrayList();
        for (Map tmpMap : reqList) {
            String APLY_NO = MapUtils.getString(tmpMap, "APLY_NO");
            if (!aplyNoList.contains(APLY_NO)) {
                aplyNoList.add(APLY_NO);
            }
        }
        //���o�C�L�禬��ƲM��
        DataSet ds = Transaction.getDataSet();

        List<Map> rtnList = new EP_Z0F110().qryListForF116(aplyNoList, MapUtils.getString(reqMap, "SUB_CPY_ID"), ds);

        //���o�ץ�s��(�Ҧ������q�O�@�νs�X, �G�����q�O�T�w��00)
        String currentDate = DATE.toDate_yyyyMMdd(DATE.getDBDate());
        //�v���B�z���ʦC�L�禬���
        Timestamp currentTime = DATE.currentTime();
        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();
        EP_Z0F160 theEP_Z0F160 = new EP_Z0F160();
        DJ_A0Z002 theDJ_A0Z002 = new DJ_A0Z002();
        ReturnMessage rm = new ReturnMessage();
        String user_ID = user.getEmpID();
        String user_DivNo = user.getDivNo();
        BigDecimal param = new BigDecimal("1.05");
        int i = 0;
        for (Map rtnMap : rtnList) {
            //���o�ץ�s��(�Ҧ������q�O�@�νs�X, �G�����q�O�T�w��00)
            String PAY_CASE_NO = theEP_Z0Z001.createNextNo("00", "034", currentDate, "PAY_CASE_NO", currentDate, 3);
            String USE_TP = MapUtils.getString(rtnMap, "USE_TP");
            String SUB_CPY_ID = MapUtils.getString(rtnMap, "SUB_CPY_ID");
            String APLY_NO = MapUtils.getString(rtnMap, "APLY_NO");
            String MEMO_NO = MapUtils.getString(rtnMap, "MEMO_NO");
            String PRO_NO = MapUtils.getString(rtnMap, "PRO_NO");
            String CONT_NO = MapUtils.getString(rtnMap, "CONT_NO");
            String SUP_ID = MapUtils.getString(rtnMap, "SUP_ID");
            String SUP_NM = MapUtils.getString(rtnMap, "SUP_NM");
            String ACPT_ID = SUP_ID;
            String ACPT_CODE = "";
            String EXP_TP = MapUtils.getString(reqMap, "EXP_TP");
            String APLY_TP = MapUtils.getString(reqMap, "APLY_TP");

            BigDecimal CLR_AMT = STRING.objToBigDecimal(rtnMap.get("CLR_AMT"), BigDecimal.ZERO);
            BigDecimal ACT_AMT = STRING.objToBigDecimal(rtnMap.get("ACT_AMT"), BigDecimal.ZERO);
            BigDecimal PAY_AMT = CLR_AMT.add(ACT_AMT);
            BigDecimal UNTAX_AMT = PAY_AMT.divide(param, 0, BigDecimal.ROUND_HALF_UP);
            BigDecimal TAX_AMT = PAY_AMT.subtract(UNTAX_AMT);

            if ("3".equals(EXP_TP)) {
                //������(EXP_TP=3)����µ�ץ󶷩�����/�ۥΤ��
                //�I�s�Ҳ�
                //BigDecimal PAY_AMT = STRING.objToBigDecimal(reqMap.get("PAY_AMT"), BigDecimal.ZERO);
                String BLD_CD = MapUtils.getString(rtnMap, "BLD_CD");
                //20190220 �t�X�����ݨD�վ�IFRS_INV_RT��DTEPG100����DTEPF170
                Map map = new HashMap();
                map.put("SUB_CPY_ID", SUB_CPY_ID);
                map.put("BLD_CD", BLD_CD);
                Map mapBase = new EP_Z0F170().queryMap(map);
                //Map mapBase = new EP_Z0G103().queryBaseByBldCd(SUB_CPY_ID, BLD_CD);
                //Map mapBase = new HashMap<String, String>();
                //mapBase.put("IFRS_INV_RT", "1");
                //���1�� �����B INV_AMT = PAY_AMT * mapBase.IFRS_INV_RT
                //�ۥ�1�� �ۥΪ��B USE_AMT = PAY_AMT - �����B
                BigDecimal IFRS_INV_RT = NumberUtils.createBigDecimal(MapUtils.getString(mapBase, "IFRS_INV_RT", "0"));
                //BigDecimal IFRS_INV_RT = BigDecimal.ONE;
                BigDecimal INV_AMT = PAY_AMT.multiply(IFRS_INV_RT).setScale(0, BigDecimal.ROUND_HALF_UP);
                BigDecimal USE_AMT = PAY_AMT.subtract(INV_AMT);
                // ��ⵧ
                if (INV_AMT.compareTo(BigDecimal.ZERO) > 0) {
                    //���X���A�~�[
                    i++;
                    ds.clear();
                    ds.setField("PAY_CASE_NO", PAY_CASE_NO);
                    ds.setField("PAY_SER_NO", i);//�y����//�дڧǸ�
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    ds.setField("APLY_NO", APLY_NO);
                    ds.setField("MEMO_NO", MEMO_NO);
                    ds.setField("PRO_NO", PRO_NO);
                    ds.setField("CONT_NO", CONT_NO);
                    ds.setField("SUP_ID", SUP_ID);
                    ds.setField("SUP_NM", SUP_NM);
                    ds.setField("ACPT_ID", ACPT_ID);
                    ds.setField("ACPT_CODE", ACPT_CODE);
                    ds.setField("INV_NO", null);
                    ds.setField("PAY_DATE", null);
                    ds.setField("PAY_CFM_DATE", null);
                    ds.setField("CASE_NO", null);
                    ds.setField("ACC_TP", "1");
                    ds.setField("DATA_SOURCE", "1");
                    ds.setField("LST_PROC_DATE", currentTime);
                    ds.setField("LST_PROC_ID", user_ID);
                    ds.setField("LST_PROC_DIV", user_DivNo);
                    //�X���A�~�[
                    //BigDecimal TAX_AMT = INV_AMT.subtract(INV_AMT.divide(param, 0, BigDecimal.ROUND_HALF_UP));
                    ds.setField("TAX_TP", "2");//�|�O�A 2:�~�[ (���|)
                    BigDecimal ins_PAY_AMT = INV_AMT.divide(param, 0, BigDecimal.ROUND_HALF_UP);
                    ds.setField("PAY_AMT", ins_PAY_AMT);
                    ds.setField("TAX_AMT", INV_AMT.subtract(ins_PAY_AMT));//�дڵ|�B
                    theEP_Z0F160.insert(ds);
                }
                if (USE_AMT.compareTo(BigDecimal.ZERO) > 0) {
                    i++;
                    ds.clear();
                    ds.setField("PAY_CASE_NO", PAY_CASE_NO);
                    ds.setField("PAY_SER_NO", i);//�y����//�дڧǸ�
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    ds.setField("APLY_NO", APLY_NO);
                    ds.setField("MEMO_NO", MEMO_NO);
                    ds.setField("PRO_NO", PRO_NO);
                    ds.setField("CONT_NO", CONT_NO);
                    ds.setField("SUP_ID", SUP_ID);
                    ds.setField("SUP_NM", SUP_NM);
                    ds.setField("ACPT_ID", ACPT_ID);
                    ds.setField("ACPT_CODE", ACPT_CODE);
                    ds.setField("INV_NO", null);
                    ds.setField("PAY_DATE", null);
                    ds.setField("PAY_CFM_DATE", null);
                    ds.setField("CASE_NO", null);
                    ds.setField("ACC_TP", "1");
                    ds.setField("DATA_SOURCE", "1");
                    ds.setField("LST_PROC_DATE", currentTime);
                    ds.setField("LST_PROC_ID", user_ID);
                    ds.setField("LST_PROC_DIV", user_DivNo);
                    //�ۥΡA���t (�t�|)
                    ds.setField("TAX_TP", "1");//�|�O�A 2:�~�[ (���|)
                    ds.setField("PAY_AMT", USE_AMT);
                    ds.setField("TAX_AMT", "0");
                    theEP_Z0F160.insert(ds);
                }

            } else {
                i++;
                ds.clear();
                ds.setField("PAY_CASE_NO", PAY_CASE_NO);
                ds.setField("PAY_SER_NO", i);//�y����//�дڧǸ�
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                ds.setField("APLY_NO", APLY_NO);
                ds.setField("MEMO_NO", MEMO_NO);
                ds.setField("PRO_NO", PRO_NO);
                ds.setField("CONT_NO", CONT_NO);
                ds.setField("SUP_ID", SUP_ID);
                ds.setField("SUP_NM", SUP_NM);
                ds.setField("ACPT_ID", ACPT_ID);
                ds.setField("ACPT_CODE", ACPT_CODE);
                ds.setField("INV_NO", null);
                ds.setField("PAY_DATE", null);
                ds.setField("PAY_CFM_DATE", null);
                ds.setField("CASE_NO", null);
                ds.setField("ACC_TP", "1");
                ds.setField("DATA_SOURCE", "1");
                ds.setField("LST_PROC_DATE", currentTime);
                ds.setField("LST_PROC_ID", user_ID);
                ds.setField("LST_PROC_DIV", user_DivNo);
                if ("1".equals(USE_TP) && !"2".equals(EXP_TP)) { //�O�κ������겣��A�L����|�B
                    //�X���A�~�[
                    ds.setField("TAX_TP", "2");
                    //BigDecimal TAX_AMT = STRING.objToBigDecimal(rtnMap.get("TAX_AMT"), BigDecimal.ZERO);
                    ds.setField("PAY_AMT", PAY_AMT.subtract(TAX_AMT));
                    ds.setField("TAX_AMT", TAX_AMT);

                    //�s�P��µ
                    if ("1".equals(APLY_TP)) {
                        ds.setField("ACPT_CODE", "3");// �t��(�k�H)
                        ds.setField("ACPT_ID", rtnMap.get("SUP_ID")); //�t�Ӳνs
                        ds.setField("INV_NO", rtnMap.get("INV_NO")); //�o�����X
                    }
                } else if ("2".equals(USE_TP) || "2".equals(EXP_TP)) {// �O�κ������겣��A�L����|�B
                    ds.setField("TAX_TP", "1");
                    ds.setField("PAY_AMT", PAY_AMT);
                    ds.setField("TAX_AMT", "0");

                    //�s�P��µ
                    if ("1".equals(APLY_TP)) {
                        //�]�w�o�����X
                        ds.setField("INV_NO", rtnMap.get("INV_NO")); //�o�����X

                        String INPUT_DIV_NO = MapUtils.getString(rtnMap, "INPUT_DIV_NO");
                        DTDJA004 DTDJA004VO = theDJ_A0Z002.doQuery(ACPT_ID, rm);
                        if (rm.getReturnCode() == 0 && DTDJA004VO != null && StringUtils.isNotBlank(DTDJA004VO.getACPT_NAME())) {
                            ds.setField("ACPT_CODE", "3");// �t��(�k�H)
                            ds.setField("ACPT_ID", rtnMap.get("SUP_ID")); //�t�Ӳνs
                        } else if (StringUtils.isNotBlank(INPUT_DIV_NO) && !INPUT_DIV_NO.startsWith("EP")) {
                            ds.setField("ACPT_CODE", "1"); //���
                            ds.setField("ACPT_ID", INPUT_DIV_NO); //�߮׳��
                        }
                    }
                }
                theEP_Z0F160.insert(ds);
            }
        }
    }

    /**
     * �s�W(�@��)�дڮ־P���
     * @param APLY_NO
     * @param MEMO_NO
     * @param PRO_NO
     * @param SUB_CPY_ID
     * @param EXP_TP
     * @param user
     * @throws ModuleException
     * @throws DBException
     */
    public void insert(String APLY_NO, String PRO_NO, String SUB_CPY_ID, String EXP_TP, UserObject user) throws Exception, DBException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(APLY_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_003"));//�ǤJ�ץ�s�����i����
        }
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_004"));// �ǤJ�ϥΪ̸�T���i���� 
        }
        if (StringUtils.isBlank(PRO_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_010"));//�ǤJ�u�اǸ����i����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_011"));//�ǤJ�����q�O���i����
        }
        if (eie != null) {
            throw eie;
        }

        //���o�C�L�禬��ƲM��
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("APLY_NO", APLY_NO);
        ds.setField("PRO_NO", PRO_NO);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_insert_003);

        //���o�ץ�s��(�Ҧ������q�O�@�νs�X, �G�����q�O�T�w��00)(EX:20130822)
        String currentDate = DATE.toDate_yyyyMMdd(DATE.getDBDate());//��褸�~�K�X 
        String PAY_CASE_NO = new EP_Z0Z001().createNextNo("00", "034", currentDate, "PAY_CASE_NO", currentDate, 3);
        Timestamp UPD_TIME = DATE.currentTime();
        String LST_PROC_ID = user.getEmpID();
        String LST_PROC_DIV = user.getDivNo();
        BigDecimal param = new BigDecimal("1.05");
        EP_Z0F160 theEP_Z0F160 = new EP_Z0F160();
        DJ_A0Z002 theDJ_A0Z002 = new DJ_A0Z002();
        ReturnMessage rm = new ReturnMessage();
        int i = 0;
        String MEMO_NO;
        for (Map rtnMap : rtnList) {
            //���o�ץ�s��(�Ҧ������q�O�@�νs�X, �G�����q�O�T�w��00)
            MEMO_NO = MapUtils.getString(rtnMap, "MEMO_NO");
            String USE_TP = MapUtils.getString(rtnMap, "USE_TP");
            String CONT_NO = MapUtils.getString(rtnMap, "CONT_NO");
            String SUP_ID = MapUtils.getString(rtnMap, "SUP_ID");
            String SUP_NM = MapUtils.getString(rtnMap, "SUP_NM");
            if (StringUtils.isBlank(SUP_NM)) {
                //DTDJA004 DTDJA004VO = theDJ_A0Z002.doQuery(SUP_ID, rm);
                Map map = theDJ_A0Z002.doQueryDataByID(SUP_ID, Transaction.getDataSet());
                if (map != null) {
                    SUP_NM = MapUtils.getString(map, "NAME");
                }
            }

            //CASE WHEN A.APLY_TP IN ('1') THEN A.ACT_AMT ELSE SUM(B.ACT_AMT) END as ACT_AMT
            BigDecimal CLR_AMT = STRING.objToBigDecimal(MapUtils.getString(rtnMap, "CLR_AMT"), BigDecimal.ZERO);
            BigDecimal ACT_AMT = STRING.objToBigDecimal(MapUtils.getString(rtnMap, "ACT_AMT"), BigDecimal.ZERO);
            String APLY_TP = MapUtils.getString(rtnMap, "APLY_TP");
            BigDecimal CAL_PAY_AMT;
            //CASE WHEN A.APLY_TP IN ('1') THEN (A.CLR_AMT + A.ACT_AMT)  ELSE SUM (B.CLR_AMT) END   PAY_AMT,
            if ("1".equals(APLY_TP)) {
                CAL_PAY_AMT = CLR_AMT.add(ACT_AMT);
            } else {
                CAL_PAY_AMT = CLR_AMT;
            }
            //�p��|�B
            BigDecimal UNTAX_AMT = CAL_PAY_AMT.divide(BD_105, 0, BigDecimal.ROUND_HALF_UP);
            BigDecimal CAL_TAX_AMT = CAL_PAY_AMT.subtract(UNTAX_AMT);
            rtnMap.put("PAY_AMT", CAL_PAY_AMT);
            rtnMap.put("TAX_AMT", CAL_TAX_AMT);

            String ACPT_ID = SUP_ID;
            String ACPT_CODE = "";
            if ("3".equals(EXP_TP)) {
                //������(EXP_TP=3)����µ�ץ󶷩�����/�ۥΤ��
                //�I�s�Ҳ�
                BigDecimal PAY_AMT = STRING.objToBigDecimal(rtnMap.get("PAY_AMT"), BigDecimal.ZERO);
                String BLD_CD = MapUtils.getString(rtnMap, "BLD_CD");
                //20190220 �t�X�����ݨD�վ�IFRS_INV_RT��DTEPG100����DTEPF170
                Map map = new HashMap();
                map.put("SUB_CPY_ID", SUB_CPY_ID);
                map.put("BLD_CD", BLD_CD);
                Map mapBase = new EP_Z0F170().queryMap(map);
                //Map mapBase = new EP_Z0G103().queryBaseByBldCd(SUB_CPY_ID, BLD_CD);
                //Map mapBase = new HashMap<String, String>();
                //mapBase.put("IFRS_INV_RT", "1");
                //���1�� �����B INV_AMT = PAY_AMT * mapBase.IFRS_INV_RT
                //�ۥ�1�� �ۥΪ��B USE_AMT = PAY_AMT - �����B
                BigDecimal IFRS_INV_RT = NumberUtils.createBigDecimal(MapUtils.getString(mapBase, "IFRS_INV_RT", "0"));
                //BigDecimal IFRS_INV_RT = BigDecimal.ONE;
                BigDecimal INV_AMT = PAY_AMT.multiply(IFRS_INV_RT).setScale(0, BigDecimal.ROUND_HALF_UP);
                BigDecimal USE_AMT = PAY_AMT.subtract(INV_AMT);
                // ��ⵧ
                if (INV_AMT.compareTo(BigDecimal.ZERO) > 0) {
                    //���X���A�~�[
                    i++;
                    ds.clear();
                    ds.setField("PAY_CASE_NO", PAY_CASE_NO);
                    ds.setField("PAY_SER_NO", i);//�y����//�дڧǸ�
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    ds.setField("APLY_NO", APLY_NO);
                    ds.setField("MEMO_NO", MEMO_NO);
                    ds.setField("PRO_NO", PRO_NO);
                    ds.setField("CONT_NO", CONT_NO);
                    ds.setField("SUP_ID", SUP_ID);
                    ds.setField("SUP_NM", SUP_NM);
                    ds.setField("ACPT_ID", ACPT_ID);
                    ds.setField("ACPT_CODE", ACPT_CODE);
                    ds.setField("INV_NO", null);
                    ds.setField("PAY_DATE", null);
                    ds.setField("PAY_CFM_DATE", null);
                    ds.setField("CASE_NO", null);
                    ds.setField("ACC_TP", "1");
                    ds.setField("DATA_SOURCE", "1");
                    ds.setField("LST_PROC_DATE", UPD_TIME);
                    ds.setField("LST_PROC_ID", LST_PROC_ID);
                    ds.setField("LST_PROC_DIV", LST_PROC_DIV);
                    //�X���A�~�[
                    ds.setField("TAX_TP", "2");//�|�O�A 2:�~�[ (���|)
                    BigDecimal ins_PAY_AMT = INV_AMT.divide(param, 0, BigDecimal.ROUND_HALF_UP);
                    ds.setField("PAY_AMT", ins_PAY_AMT);
                    ds.setField("TAX_AMT", INV_AMT.subtract(ins_PAY_AMT));//�дڵ|�B
                    theEP_Z0F160.insert(ds);
                }
                if (USE_AMT.compareTo(BigDecimal.ZERO) > 0) {
                    i++;
                    ds.clear();
                    ds.setField("PAY_CASE_NO", PAY_CASE_NO);
                    ds.setField("PAY_SER_NO", i);//�y����//�дڧǸ�
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    ds.setField("APLY_NO", APLY_NO);
                    ds.setField("MEMO_NO", MEMO_NO);
                    ds.setField("PRO_NO", PRO_NO);
                    ds.setField("CONT_NO", CONT_NO);
                    ds.setField("SUP_ID", SUP_ID);
                    ds.setField("SUP_NM", SUP_NM);
                    ds.setField("ACPT_ID", ACPT_ID);
                    ds.setField("ACPT_CODE", ACPT_CODE);
                    ds.setField("INV_NO", null);
                    ds.setField("PAY_DATE", null);
                    ds.setField("PAY_CFM_DATE", null);
                    ds.setField("CASE_NO", null);
                    ds.setField("ACC_TP", "1");
                    ds.setField("DATA_SOURCE", "1");
                    ds.setField("LST_PROC_DATE", UPD_TIME);
                    ds.setField("LST_PROC_ID", LST_PROC_ID);
                    ds.setField("LST_PROC_DIV", LST_PROC_DIV);
                    //�ۥΡA���t (�t�|)
                    ds.setField("TAX_TP", "1");//�|�O�A 2:�~�[ (���|)
                    ds.setField("PAY_AMT", USE_AMT);
                    ds.setField("TAX_AMT", "0");
                    theEP_Z0F160.insert(ds);
                }

            } else {
                i++;
                ds.clear();
                ds.setField("PAY_CASE_NO", PAY_CASE_NO);
                ds.setField("PAY_SER_NO", i);//�y����//�дڧǸ�
                ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                ds.setField("APLY_NO", APLY_NO);
                ds.setField("MEMO_NO", MEMO_NO);
                ds.setField("PRO_NO", PRO_NO);
                ds.setField("CONT_NO", CONT_NO);
                ds.setField("SUP_ID", SUP_ID);
                ds.setField("SUP_NM", SUP_NM);
                ds.setField("ACPT_ID", ACPT_ID);
                ds.setField("ACPT_CODE", ACPT_CODE);
                ds.setField("INV_NO", null);
                ds.setField("PAY_DATE", null);
                ds.setField("PAY_CFM_DATE", null);
                ds.setField("CASE_NO", null);
                ds.setField("ACC_TP", "1");
                ds.setField("DATA_SOURCE", "1");
                ds.setField("LST_PROC_DATE", UPD_TIME);
                ds.setField("LST_PROC_ID", LST_PROC_ID);
                ds.setField("LST_PROC_DIV", LST_PROC_DIV);
                if ("1".equals(USE_TP) && !"2".equals(EXP_TP)) {// �O�κ������겣��A�L����|�B
                    //�X���A�~�[
                    ds.setField("TAX_TP", "2");
                    BigDecimal TAX_AMT = STRING.objToBigDecimal(rtnMap.get("TAX_AMT"), BigDecimal.ZERO);
                    ds.setField("PAY_AMT", STRING.objToBigDecimal(rtnMap.get("PAY_AMT"), BigDecimal.ZERO).subtract(TAX_AMT));
                    ds.setField("TAX_AMT", TAX_AMT);
                    //�s�P��µ
                    if ("1".equals(APLY_TP)) {
                        ds.setField("ACPT_CODE", "3");// �t��(�k�H)
                        ds.setField("ACPT_ID", rtnMap.get("SUP_ID")); //�t�Ӳνs
                    }
                } else if ("2".equals(USE_TP) || "2".equals(EXP_TP)) {// �O�κ������겣��A�L����|�B
                    ds.setField("TAX_TP", "1");
                    ds.setField("PAY_AMT", rtnMap.get("PAY_AMT"));
                    ds.setField("TAX_AMT", "0");

                    //�s�P��µ
                    if ("1".equals(APLY_TP)) {
                        String INPUT_DIV_NO = MapUtils.getString(rtnMap, "INPUT_DIV_NO");
                        DTDJA004 DTDJA004VO = theDJ_A0Z002.doQuery(ACPT_ID, rm);
                        if (rm.getReturnCode() == 0 && DTDJA004VO != null && StringUtils.isNotBlank(DTDJA004VO.getACPT_NAME())) {
                            ds.setField("ACPT_CODE", "3");// �t��(�k�H)
                            ds.setField("ACPT_ID", rtnMap.get("SUP_ID")); //�t�Ӳνs
                        } else if (StringUtils.isNotBlank(INPUT_DIV_NO) && !INPUT_DIV_NO.startsWith("EP")) {
                            ds.setField("ACPT_CODE", "1"); //���
                            ds.setField("ACPT_ID", INPUT_DIV_NO); //�߮׳��
                        }
                    }
                }
                theEP_Z0F160.insert(ds);
            }
        }
    }

    /**
     * �C�L����overload���J���{���ϥ�
     * @param reqList
     * @param user
     * @param reqMap
     * @param resp
     * @throws Exception 
     */
    public void printRent(List<Map> reqList, UserObject user, Map reqMap, ResponseContext resp, RequestContext req) throws Exception {
        //�w�]�����oPDF�ɮ�
        this.printRent(reqList, user, reqMap, resp, req, false);
    }

    /**
     * �C�L����
     * @param reqList
     * @param user
     * @param reqMap
     * @param resp
     * @return
     * @throws Exception 
     */
    public FileItem printRent(List<Map> reqList, UserObject user, Map reqMap, ResponseContext resp, RequestContext req, boolean createPDF)
            throws Exception {
        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        if (user == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_004"));// �ǤJ�ϥΪ̸�T���i���� 
        }
        if (reqMap == null || reqMap.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_005"));// �ǤJ�d�߱��󤣥i����
        } else {
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));// �����q�O���o���ŭ�
            }
        }
        if (!createPDF && resp == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_006"));// �ǤJresponse���i����
        }
        if (!createPDF && (reqList == null || reqList.isEmpty())) {
            if (reqMap == null) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_003"));//�ǤJ�ץ�s�����i����
            } else {
                //�̳��������d�߸�ơA���ͳ���
                String REPORT_TP = MapUtils.getString(reqMap, "REPORT_TP");
                if (!"7".equals(REPORT_TP) && !"8".equals(REPORT_TP)) {
                    eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_F10300_MSG_003"));//�ǤJ�ץ�s�����i����
                }
            }
        }
        if (eie != null) {
            throw eie;
        }

        MultiKeyMap mkm = new MultiKeyMap();
        List<String> aplyNoList = new ArrayList();
        for (Map tmpMap : reqList) {
            String APLY_NO = MapUtils.getString(tmpMap, "APLY_NO");
            if (!aplyNoList.contains(APLY_NO)) {
                aplyNoList.add(APLY_NO);
            }
            String tmpAPLY_NO = MapUtils.getString(tmpMap, "APLY_NO");
            String tmpMEMO_NO = MapUtils.getString(tmpMap, "MEMO_NO");
            String tmpPRO_NO = MapUtils.getString(tmpMap, "PRO_NO");
            mkm.put(tmpAPLY_NO, tmpMEMO_NO, tmpPRO_NO, "");
        }

        //�̳��������d�߸�ơA���ͳ���
        String REPORT_TP = MapUtils.getString(reqMap, "REPORT_TP");
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        FileItem fi = null;
        if (!"7".equals(REPORT_TP) && !"8".equals(REPORT_TP)) {

            Map APLY_TP_F101 = FieldOptionList.getName("EP", "APLY_TP_F101");

            String APLY_TP = MapUtils.getString(reqList.get(0), "APLY_TP");

            //String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            //2018-09-10 ���~��(���ʲ���µ��):�C�L�禬��Ƶe���s�W��@�d�߱���i�ץ�s���j
            //String APLY_TPs = MapUtils.getString(APLY_TP_F101, MapUtils.getString(reqMap, "APLY_TP"));
            String APLY_TPs = MapUtils.getString(APLY_TP_F101, APLY_TP);

            boolean createFileItem = false;

            //�]�w PDF�ɮצW��
            String tempFileFullPath = null;
            if (createPDF && "1".equals(APLY_TP)) {
                createFileItem = true;
                tempFileFullPath = RptUtils.markTempFileFullPath();
                if (!"pdf".equals(FilenameUtils.getExtension(tempFileFullPath))) {
                    tempFileFullPath += ".pdf";
                }
            }

            if ("1".equals(REPORT_TP)) {//(���~�禬��)�APDF����
                ds.setFieldValues("aplyNoList", aplyNoList);
                List<Map> rtnList;
                if ("1".equals(APLY_TP)) {
                    ds.setField("APLY_TP", "1");
                    rtnList = VOTool.findToMaps(ds, SQL_printRent_001A);
                } else {
                    rtnList = VOTool.findToMaps(ds, SQL_printRent_001);
                }
                //2018-09-10 ���~��(���ʲ���µ��):���������i���~�禬��j�A����@��µ�ץ󦳦h�Ӥ��P�u�{�ɡA�קאּ�u�C�L������u�{�ӫD�����u�{
                List<Map> printList = new ArrayList();
                for (Map rtnMap : rtnList) {
                    if ("1".equals(APLY_TP)) {
                        String APLY_NO = MapUtils.getString(rtnMap, "APLY_NO");
                        for (Map tmpMap : reqList) {
                            String tmpAPLY_NO = MapUtils.getString(tmpMap, "APLY_NO");
                            if (StringUtils.equals(APLY_NO, tmpAPLY_NO)) {
                                printList.add(rtnMap);
                            }
                        }
                    } else {
                        String APLY_NO = MapUtils.getString(rtnMap, "APLY_NO");
                        String MEMO_NO = MapUtils.getString(rtnMap, "MEMO_NO");
                        String PRO_NO = MapUtils.getString(rtnMap, "PRO_NO");
                        for (Map tmpMap : reqList) {
                            String tmpAPLY_NO = MapUtils.getString(tmpMap, "APLY_NO");
                            String tmpMEMO_NO = MapUtils.getString(tmpMap, "MEMO_NO");
                            String tmpPRO_NO = MapUtils.getString(tmpMap, "PRO_NO");
                            if (StringUtils.equals(APLY_NO, tmpAPLY_NO) && StringUtils.equals(MEMO_NO, tmpMEMO_NO)
                                    && StringUtils.equals(PRO_NO, tmpPRO_NO)) {
                                printList.add(rtnMap);
                            } else if (StringUtils.equals(APLY_NO, tmpAPLY_NO) && StringUtils.isBlank(tmpMEMO_NO)
                                    && StringUtils.isBlank(tmpPRO_NO)) {
                                //2018-12-11 ���~�� �վ�߮׸�Ƶe���C�L�\��i�H�ήץ�s���C�L�禬��P�дک��Ӫ�
                                printList.add(rtnMap);
                            }
                        }
                    }
                }

                Map param = new HashMap(); //������param
                Map param1 = new HashMap(); //�l����param
                Map keyMap = new HashMap(); //��group key

                param.put("REPORT_ID", "EP_F10300_1");
                param.put("PAGE_BREAK", (printList.size() > 15) ? "1" : "0");

                param1.put("REPORT_ID", "EP_F10300_1_1");
                param1.putAll(this.doFmtRptList1(printList, user));

                keyMap.put("1", printList);
                keyMap.put("2", printList);
                param1.put("EP_F10300_1_1_Group", keyMap);

                List<Map> countList = new ArrayList();//������detail
                Map detail1 = new HashMap();
                detail1.put("SER_NO", "1"); //group key
                countList.add(detail1);
                detail1 = new HashMap();
                detail1.put("SER_NO", "2");
                countList.add(detail1);

                Map[] inputParams = new Map[] { param, param1 };
                List[] inputDetailLists = new List[] { countList, Collections.EMPTY_LIST };

                if (createFileItem) {
                    new RptUtils().createPDFFile(inputParams, inputDetailLists, tempFileFullPath, null);
                    fi = this.createFileItem(new File(tempFileFullPath));
                } else {
                    new JasperReportUtils().outputRptData(new String[] { "EP_F10300_1", "EP_F10300_1_1" }, inputParams, inputDetailLists,
                        req, resp);
                }

            } else if ("2".equals(REPORT_TP)) {//(�u�{�дڥӽЪ�)�APDF����
                ds.setFieldValues("aplyNoList", aplyNoList);
                List<Map> printList2 = VOTool.findToMaps(ds, SQL_printRent_002);
                fi = printReport2(user, resp, APLY_TPs, printList2, req, createFileItem, tempFileFullPath, SUB_CPY_ID);
            } else if ("3".equals(REPORT_TP)) {//(�дڥζ��`��)�APDF����
                ds.setFieldValues("aplyNoList", aplyNoList);
                List<Map> printList3 = VOTool.findToMaps(ds, SQL_printRent_003);
                Map paramMap = this.doFmtRptList3(printList3, user, APLY_TPs);
                String DATE_S = MapUtils.getString(reqMap, "DATE_S");
                String DATE_E = MapUtils.getString(reqMap, "DATE_E");
                LocaleDisplay LD = new LocaleDisplay("EP", user);
                //�]�w���Y�d�߰_����
                paramMap.put("DATE_S", LD.formatDate(Date.valueOf(DATE_S), "/", ""));
                paramMap.put("DATE_E", LD.formatDate(Date.valueOf(DATE_E), "/", ""));
                //�W�[�@���`�p
                Map lastMap = new HashMap();
                lastMap.put("SEQ_NO", "");
                lastMap.put("APLY_NO", "");
                lastMap.put("BLD_NM", "");
                lastMap.put("PROJECT_TP", "�`�p");
                lastMap.put("ACT_AMT", paramMap.get("TOTAL_AMT"));
                printList3.add(lastMap);
                //�]�w15��
                int size = printList3.size();
                if (size % 15 > 0) {
                    for (int i = size % 15; i < 15; i++) {
                        printList3.add(new HashMap<String, String>());
                    }
                }

                JasperReportUtils.addOutputRptDataToResp("EP_F10300_3", paramMap, printList3, resp);
            } else if ("4".equals(REPORT_TP)) {//(�дک��Ӫ�)�APDF����
                //�дڮ־P���
                ds.setFieldValues("aplyNoList", aplyNoList);
                List<Map> rtnList = VOTool.findToMaps(ds, SQL_printRent_004);

                //�v���P�_�A��z��3��������ơA�C��������ơA����ƫh�C�L�A�L��ƫh���C�L
                //�D�����󪺩Ҧ��X������µ�ץ�L�X�@���X��������
                //�D�����󪺩Ҧ��ۥΪ���µ�ץ�L�X�@���ۥΪ�����
                //������(EXP_TP=3)����µ�ץ󶷩�����/�ۥΤ��
                LocaleDisplay LD = new LocaleDisplay("EP", user);
                List<Map> tmpList = new ArrayList();//�D�����󪺩Ҧ��X��
                List<Map> tmpList2 = new ArrayList();//�D�����󪺩Ҧ��ۥ�
                List<Map> tmpList3 = new ArrayList();//������

                EP_Z0F110 theEP_Z0F110 = new EP_Z0F110();
                EP_Z00100 theEP_Z00100 = new EP_Z00100();
                RZ_Z0Z002 theRZ_Z0Z002 = new RZ_Z0Z002();//[2019.04.18]�į�ﵽ
                DivData divData = new DivData();

                BigDecimal TOTAL_AMT = BigDecimal.ZERO;
                BigDecimal TOTAL_AMT2 = BigDecimal.ZERO;
                BigDecimal TOTAL_AMT3 = BigDecimal.ZERO;
                int cntFor_1 = 0;
                int cntFor_2 = 0;
                int cntFor_3 = 0;
                //2018-09-10 ���~��(���ʲ���µ��):���������i�дک��Ӫ��j�A����@��µ�ץ󦳦h�Ӥ��P�u�{�ɡA�קאּ�u�C�L������u�{�ӫD�����u�{
                List<Map> printList = new ArrayList();
                for (Map rtnMap : rtnList) {
                    if ("1".equals(APLY_TP)) {
                        String APLY_NO = MapUtils.getString(rtnMap, "APLY_NO");
                        for (Map tmpMap : reqList) {
                            String tmpAPLY_NO = MapUtils.getString(tmpMap, "APLY_NO");
                            if (StringUtils.equals(APLY_NO, tmpAPLY_NO)) {
                                printList.add(rtnMap);
                            }
                        }
                    } else {
                        String APLY_NO = MapUtils.getString(rtnMap, "APLY_NO");
                        String MEMO_NO = MapUtils.getString(rtnMap, "MEMO_NO");
                        String PRO_NO = MapUtils.getString(rtnMap, "PRO_NO");
                        for (Map tmpMap : reqList) {
                            String tmpAPLY_NO = MapUtils.getString(tmpMap, "APLY_NO");
                            String tmpMEMO_NO = MapUtils.getString(tmpMap, "MEMO_NO");
                            String tmpPRO_NO = MapUtils.getString(tmpMap, "PRO_NO");
                            if (StringUtils.equals(APLY_NO, tmpAPLY_NO) && StringUtils.equals(MEMO_NO, tmpMEMO_NO)
                                    && StringUtils.equals(PRO_NO, tmpPRO_NO)) {
                                printList.add(rtnMap);
                            } else if (StringUtils.equals(APLY_NO, tmpAPLY_NO) && StringUtils.isBlank(tmpMEMO_NO)
                                    && StringUtils.isBlank(tmpPRO_NO)) {
                                //2018-12-11 ���~�� �վ�߮׸�Ƶe���C�L�\��i�H�ήץ�s���C�L�禬��P�дک��Ӫ�
                                printList.add(rtnMap);
                            }
                        }
                    }
                }
                
                for (Map printMap : printList) {
                    //���o�����������
                    //2018-06-19 ���~�� �t�X�~������k�վ�ǤJ�Ѽ�
                    printMap.put("REPORT_TP", REPORT_TP);
                    this.getNM(printMap, theEP_Z0F110, theEP_Z00100, divData, theRZ_Z0Z002);//[2019.04.18]�į�ﵽ
                    String USE_TP = MapUtils.getString(printMap, "USE_TP");
                    String EXP_TP = MapUtils.getString(printMap, "EXP_TP");
                    BigDecimal AMT = STRING.objToBigDecimal(printMap.get("AMT"), BigDecimal.ZERO);
                    String PAY_DATE = MapUtils.getString(printMap, "PAY_DATE");
                    String PAY_CFM_DATE = MapUtils.getString(printMap, "PAY_CFM_DATE");

                    if (DATE.isDBTimeStamp(PAY_DATE)) {
                        printMap.put("PAY_DATE", LD.formatDate(DATE.timestampToDate(PAY_DATE), "/", ""));
                    } else if (DATE.isDate(PAY_DATE)) {
                        printMap.put("PAY_DATE", LD.formatDate(Date.valueOf(PAY_DATE), "/", ""));
                    }
                    if (DATE.isDBTimeStamp(PAY_CFM_DATE)) {
                        printMap.put("PAY_CFM_DATE", LD.formatDate(DATE.timestampToDate(PAY_CFM_DATE), "/", ""));
                    } else if (DATE.isDate(PAY_CFM_DATE)) {
                        printMap.put("PAY_CFM_DATE", LD.formatDate(Date.valueOf(PAY_CFM_DATE), "/", ""));
                    }
                    chkMap(printMap, LD);
                    if (!"3".equals(EXP_TP) && "1".equals(USE_TP)) {
                        TOTAL_AMT = TOTAL_AMT.add(AMT);
                        tmpList.add(printMap);
                        cntFor_1++;
                    } else if (!"3".equals(EXP_TP) && "2".equals(USE_TP)) {
                        TOTAL_AMT2 = TOTAL_AMT2.add(AMT);
                        tmpList2.add(printMap);
                        cntFor_2++;
                    } else if ("3".equals(EXP_TP)) {
                        TOTAL_AMT3 = TOTAL_AMT3.add(AMT);
                        // ��ⵧ
                        tmpList3.add(printMap);
                        cntFor_3++;
                    }
                }
                List<Map[]> RPT_PARAMList = new ArrayList<Map[]>();
                List<List[]> RPT_DETAILList_F = new ArrayList<List[]>();
                String DATE_S = MapUtils.getString(reqMap, "DATE_S");
                String DATE_E = MapUtils.getString(reqMap, "DATE_E");
                if (tmpList != null && !tmpList.isEmpty()) {
                    Map paramMap = new HashMap();
                    paramMap.put("REPORT_ID", "EP_F10300_41");

                    if (StringUtils.isNotBlank(DATE_S)) {
                        paramMap.put("DATE_S", LD.formatDate(Date.valueOf(DATE_S), "/", ""));
                    } else {
                        paramMap.put("DATE_S", "");
                    }
                    if (StringUtils.isNotBlank(DATE_E)) {
                        paramMap.put("DATE_E", LD.formatDate(Date.valueOf(DATE_E), "/", ""));
                    } else {
                        paramMap.put("DATE_E", "");
                    }

                    paramMap.put("USE_TP_NM", MessageUtil.getMessage("EP_F10300_MSG_007"));//�X��
                    paramMap.put("PRINT_DATE", LD.formatDate(DATE.today(), "/", ""));
                    paramMap.put("PRINT_DIV", user.getDivShortName());
                    paramMap.put("CNT", String.valueOf(cntFor_1));
                    paramMap.put("TOTAL_AMT", LD.formatNumber(TOTAL_AMT, 0, ""));
                    RPT_PARAMList.add(new Map[] { paramMap });
                    RPT_DETAILList_F.add(new List[] { tmpList });
                }
                if (tmpList2 != null && !tmpList2.isEmpty()) {
                    Map paramMap = new HashMap();
                    paramMap.put("REPORT_ID", "EP_F10300_42");

                    if (StringUtils.isNotBlank(DATE_S)) {
                        paramMap.put("DATE_S", LD.formatDate(Date.valueOf(DATE_S), "/", ""));
                    } else {
                        paramMap.put("DATE_S", "");
                    }
                    if (StringUtils.isNotBlank(DATE_E)) {
                        paramMap.put("DATE_E", LD.formatDate(Date.valueOf(DATE_E), "/", ""));
                    } else {
                        paramMap.put("DATE_E", "");
                    }
                    paramMap.put("USE_TP_NM", MessageUtil.getMessage("EP_F10300_MSG_008"));//�ۥ�
                    paramMap.put("PRINT_DATE", LD.formatDate(DATE.today(), "/", ""));
                    paramMap.put("PRINT_DIV", user.getDivShortName());
                    paramMap.put("CNT", String.valueOf(cntFor_2));
                    paramMap.put("TOTAL_AMT", LD.formatNumber(TOTAL_AMT2, 0, ""));
                    RPT_PARAMList.add(new Map[] { paramMap });
                    RPT_DETAILList_F.add(new List[] { tmpList2 });
                }
                if (tmpList3 != null && !tmpList3.isEmpty()) {
                    Map paramMap = new HashMap();
                    paramMap.put("REPORT_ID", "EP_F10300_43");

                    if (StringUtils.isNotBlank(DATE_S)) {
                        paramMap.put("DATE_S", LD.formatDate(Date.valueOf(DATE_S), "/", ""));
                    } else {
                        paramMap.put("DATE_S", "");
                    }
                    if (StringUtils.isNotBlank(DATE_E)) {
                        paramMap.put("DATE_E", LD.formatDate(Date.valueOf(DATE_E), "/", ""));
                    } else {
                        paramMap.put("DATE_E", "");
                    }
                    paramMap.put("USE_TP_NM", MessageUtil.getMessage("EP_F10300_MSG_007"));//�X��
                    paramMap.put("PRINT_DATE", LD.formatDate(DATE.today(), "/", ""));
                    paramMap.put("PRINT_DIV", user.getDivShortName());
                    paramMap.put("CNT", String.valueOf(cntFor_3));
                    paramMap.put("TOTAL_AMT", LD.formatNumber(TOTAL_AMT3, 0, ""));
                    RPT_PARAMList.add(new Map[] { paramMap });
                    RPT_DETAILList_F.add(new List[] { tmpList3 });
                }

                int paramsSize = RPT_PARAMList.size();
                Map[][] inputParams = RPT_PARAMList.toArray(new Map[paramsSize][]);

                List[][] inputDetailLists = RPT_DETAILList_F.toArray(new List[RPT_DETAILList_F.size()][]);
                String[] reportIds = new String[paramsSize];
                for (int i = 0; i < paramsSize; i++) {
                    reportIds[i] = "EP_F10300";
                }
                JasperReportUtils.addOutputRptDataToResp(reportIds, inputParams, inputDetailLists, req, resp);
            } else if ("5".equals(REPORT_TP)) {//(�q���}�o�����Ӫ�)�AEXCEL����
                if (!"1".equals(APLY_TP)) {
                    ds.setField("NOT_APLY_TP", "1");
                }
                ds.setFieldValues("aplyNoList", aplyNoList);
                List<Map> printList5 = VOTool.findToMaps(ds, SQL_printRent_005);
                List<Map> countList = this.doFmtRptList5(printList5, user);
                log.debug("$$$$countList::" + countList);
                this.exportXLS(printList5, countList, resp, user, reqMap);
            }
        } else {
            if ("7".equals(REPORT_TP)) {//(�ץ�w�д�)�AEXCEL����
                setFieldIfExist(ds, reqMap, "USE_TP");
                String DATE_S = MapUtils.getString(reqMap, "DATE_S");
                String DATE_E = MapUtils.getString(reqMap, "DATE_E");
                ds.setField("DATE_TP_1", "1");
                ds.setField("DATE_S", DATE_S);
                ds.setField("DATE_E", DATE_E);
                List<Map> printList7 = VOTool.findToMaps(ds, SQL_printRent_007);
                List<Map> countList = this.doFmtRptList7(printList7);
                log.debug("$$$$countList::" + countList);
                this.exportXLS7(countList, resp, user, reqMap);
            } else if ("8".equals(REPORT_TP)) {//(�w�q���I�u�|���д�)�AEXCEL����
                List<Map> printList7 = VOTool.findToMaps(ds, SQL_printRent_008);
                List<Map> countList = this.doFmtRptList7(printList7);
                log.debug("$$$$countList::" + countList);
                this.exportXLS7(countList, resp, user, reqMap);
            }
        }

        return fi;
    }

    /**
     * �ˬdMAP �����
     * @param rtnMap
     * @param LD
     */
    private void chkMap(Map rtnMap, LocaleDisplay LD) {
        Iterator it = rtnMap.keySet().iterator();
        while (it.hasNext()) {
            String key = (String) it.next();
            Object obj = rtnMap.get(key);
            if (obj == null) {
                rtnMap.put(key, "");
            } else if (obj instanceof BigDecimal) {
                rtnMap.put(key, LD.formatNumber(obj, 0, ""));
            } else if (obj instanceof Date) {
                rtnMap.put(key, LD.formatDate((Date) obj, "/", ""));
            } else if (obj instanceof Timestamp) {
                rtnMap.put(key, LD.formatTimestamp((Timestamp) obj, "/", ""));
            } else {
                rtnMap.put(key, obj.toString());
            }
        }
    }

    /**
     * (���~�禬��) ������ƳB�z
     * @param rtnList
     * @param user
     */
    private Map doFmtRptList1(List<Map> rtnList, UserObject user) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        //StringBuilder sb = new StringBuilder();
        Map tmpMap = rtnList.get(0);
        paramMap.put("BLD_NM", MapUtils.getString(tmpMap, "BLD_NM", ""));
        //20181005 ���~��(���ʲ���µ��):�R���帹���X�קK�y���~�|
        /*sb.append(MapUtils.getString(tmpMap, "APLY_NO", "")).append(MapUtils.getString(tmpMap, "MEMO_NO", "")).append(
            MapUtils.getString(tmpMap, "PRO_NO", ""));
        paramMap.put("APLY_NO", sb.toString());*/
        paramMap.put("APLY_NO", MapUtils.getString(tmpMap, "APLY_NO", ""));
        LocaleDisplay LD = new LocaleDisplay("EP", user);
        convertString(rtnList, LD);
        return paramMap;
    }

    /**
     * (�u�{�дڥӽЪ�)������ƳB�z
     */
    private Map doFmtRptList2(List<Map> rtnList, UserObject user, String APLY_TP) {
        String FIX_DIV_NM = "";
        for (Map map : rtnList) {
            if (StringUtils.isBlank(FIX_DIV_NM)) {
                FIX_DIV_NM = MapUtils.getString(map, "FIX_DIV_NM", "");
                if (StringUtils.isBlank(FIX_DIV_NM)) {
                    try {
                        FIX_DIV_NM = new PersonnelData().getByEmployeeID(MapUtils.getString(map, "FIX_DIV_ID")).getName();
                    } catch (Exception e) {
                        log.error("���o��µ��H���m�W���~", e);
                    }
                }
            }
            map.put("WAR_MON", MapUtils.getString(map, "WAR_MON", ""));
        }

        Map<String, Object> paramMap = new HashMap<String, Object>();
        LocaleDisplay LD = new LocaleDisplay("EP", user);
        paramMap.put("REPORT_ID", "EP_F10300_2");
        String YearMM = LD.formatDateym(DATE.today(), "");
        paramMap.put("YEAR", YearMM.substring(0, 3));
        paramMap.put("MONTH", YearMM.substring(3, 5));
        BigDecimal TOTAL_AMT = convertString(rtnList, LD);
        paramMap.put("TOTAL_AMT", LD.formatNumber(TOTAL_AMT, 0, ""));
        paramMap.put("ROC_TOTAL_AMT", STRING.toROCMoneyFormat(TOTAL_AMT.toPlainString(), "��", true));
        paramMap.put("APLY_TP", APLY_TP);
        paramMap.put("FIX_DIV_NM", FIX_DIV_NM);
        return paramMap;
    }

    /**
     * (�u�{�дڥӽЪ�)������ƳB�z
     */
    private Map doFmtRptList22(List<Map> rtnList, UserObject user, String APLY_TP) {
        String FIX_DIV_NM = "";
        for (Map map : rtnList) {
            if (StringUtils.isBlank(FIX_DIV_NM)) {
                FIX_DIV_NM = MapUtils.getString(map, "FIX_DIV_NM", "");
                if (StringUtils.isBlank(FIX_DIV_NM)) {
                    try {
                        FIX_DIV_NM = new PersonnelData().getByEmployeeID(MapUtils.getString(map, "FIX_DIV_ID")).getName();
                    } catch (Exception e) {
                        log.error("���o��µ��H���m�W���~", e);
                    }
                }
            }
            map.put("WAR_MON", MapUtils.getString(map, "WAR_MON", ""));
        }

        Map<String, Object> paramMap = new HashMap<String, Object>();
        LocaleDisplay LD = new LocaleDisplay("EP", user);
        paramMap.put("REPORT_ID", "EP_F10300_22");
        String YearMM = LD.formatDateym(DATE.today(), "");
        paramMap.put("YEAR", YearMM.substring(0, 3));
        paramMap.put("MONTH", YearMM.substring(3, 5));
        BigDecimal TOTAL_AMT = convertString(rtnList, LD);
        paramMap.put("TOTAL_AMT", LD.formatNumber(TOTAL_AMT, 0, ""));
        paramMap.put("ROC_TOTAL_AMT", STRING.toROCMoneyFormat(TOTAL_AMT.toPlainString(), "��", true));
        paramMap.put("APLY_TP", APLY_TP);
        paramMap.put("FIX_DIV_NM", FIX_DIV_NM);
        return paramMap;
    }

    /**
     * (�дڥζ��`��)
     * @param rtnList
     * @param user
     */
    private Map doFmtRptList3(List<Map> rtnList, UserObject user, String APLY_TP) {
        for (Map map : rtnList) {
            map.put("WAR_MON", MapUtils.getString(map, "WAR_MON", ""));
        }

        Map<String, Object> paramMap = new HashMap<String, Object>();

        LocaleDisplay LD = new LocaleDisplay("EP", user);
        paramMap.put("REPORT_ID", "EP_F10300_3");
        String YearMM = LD.formatDateym(DATE.today(), "");
        paramMap.put("YEAR", YearMM.substring(0, 3));
        paramMap.put("MONTH", YearMM.substring(3, 5));
        BigDecimal TOTAL_AMT = convertString(rtnList, LD);
        paramMap.put("TOTAL_AMT", LD.formatNumber(TOTAL_AMT, 0, ""));
        paramMap.put("APLY_TP", APLY_TP);
        return paramMap;

    }

    /**
     * (�q���}�o�����Ӫ�)
     * @param printList5
     * @param user
     */
    private List<Map> doFmtRptList5(List<Map> printList5, UserObject user) {
        String ST_X = "X";
        List<Map> countList = new ArrayList();
        MultiKeyMap mkMap = new MultiKeyMap();
        MultiKeyMap mkMap2 = new MultiKeyMap();
        BigDecimal TOTAL_AMT = BigDecimal.ZERO;
        //LocaleDisplay LD = new LocaleDisplay("EP", user);
        List<Map> tmpList1 = new ArrayList();//�X���O��
        List<Map> tmpList2 = new ArrayList();//�ۥζO��
        for (Map rtnMap : printList5) {
            String EXP_TP = MapUtils.getString(rtnMap, "EXP_TP");
            String USE_TP = MapUtils.getString(rtnMap, "USE_TP");
            //���o�u�γ~�v����:
            rtnMap.put("USE_TP_NM", FieldOptionList.getName("EP", "USE_TP_F101", MapUtils.getString(rtnMap, "USE_TP")));
            //���o�u�O�κ����v����
            rtnMap.put("EXP_TP_NM", FieldOptionList.getName("EP", "EXP_TP_F101", MapUtils.getString(rtnMap, "EXP_TP")));

            BigDecimal AMT = STRING.objToBigDecimal(rtnMap.get("AMT"), BigDecimal.ZERO);
            BigDecimal TAX_AMT = STRING.objToBigDecimal(rtnMap.get("TAX_AMT"), BigDecimal.ZERO);
            TOTAL_AMT = TOTAL_AMT.add(AMT);
            if ("0".equals(EXP_TP) || "4".equals(EXP_TP)) {//�D�w���
                Map tmpMap;
                if (!mkMap.containsKey(ST_X, "0")) {
                    tmpMap = new HashMap();
                    tmpMap.put("TYPE", "3");
                    tmpMap.put("CNT", 1);
                    tmpMap.put("AMT", AMT);
                    tmpMap.put("TAX_AMT", TAX_AMT);
                    tmpMap.put("INV_NUMBER", 1);
                    tmpMap.put("MEMO", "�C��@�i");
                    mkMap.put(ST_X, "0", tmpMap);
                } else {
                    tmpMap = (Map) mkMap.get(ST_X, "0");
                    tmpMap.put("CNT", MapUtils.getIntValue(tmpMap, "CNT") + 1);
                    tmpMap.put("AMT", STRING.objToBigDecimal(tmpMap.get("AMT"), BigDecimal.ZERO).add(AMT));
                    tmpMap.put("TAX_AMT", STRING.objToBigDecimal(tmpMap.get("TAX_AMT"), BigDecimal.ZERO).add(TAX_AMT));
                    tmpMap.put("INV_NUMBER", MapUtils.getIntValue(tmpMap, "INV_NUMBER") + 1);
                }

            } else if ("3".equals(EXP_TP)) { //������
                Map tmpMap;

                if (BigDecimal.ZERO.compareTo(TAX_AMT) > 0) {//���
                    tmpList1.add(rtnMap);
                    if (!mkMap2.containsKey("1", EXP_TP)) {//���O��
                        tmpMap = new HashMap();
                        tmpMap.put("TYPE", USE_TP);
                        tmpMap.put("CNT", 1);
                        tmpMap.put("AMT", AMT);
                        tmpMap.put("TAX_AMT", TAX_AMT);
                        tmpMap.put("INV_NUMBER", 0);
                        tmpMap.put("MEMO", "�}���@�i");
                        mkMap2.put("1", EXP_TP, tmpMap);
                    } else {
                        tmpMap = (Map) mkMap2.get("1", EXP_TP);
                        tmpMap.put("CNT", MapUtils.getIntValue(tmpMap, "CNT") + 1);
                        tmpMap.put("AMT", STRING.objToBigDecimal(tmpMap.get("AMT"), BigDecimal.ZERO).add(AMT));
                        tmpMap.put("TAX_AMT", STRING.objToBigDecimal(tmpMap.get("TAX_AMT"), BigDecimal.ZERO).add(TAX_AMT));
                    }
                } else if (BigDecimal.ZERO.compareTo(TAX_AMT) <= 0) {//�ۥ�
                    tmpList2.add(rtnMap);
                    if (!mkMap2.containsKey("2", EXP_TP)) {//�ۥζO��
                        tmpMap = new HashMap();
                        tmpMap.put("TYPE", USE_TP);
                        tmpMap.put("CNT", 1);
                        tmpMap.put("AMT", AMT);
                        tmpMap.put("TAX_AMT", TAX_AMT);
                        tmpMap.put("INV_NUMBER", 0);
                        tmpMap.put("MEMO", "�}���@�i");
                        mkMap2.put("2", EXP_TP, tmpMap);
                    } else {
                        tmpMap = (Map) mkMap2.get("2", EXP_TP);
                        tmpMap.put("CNT", MapUtils.getIntValue(tmpMap, "CNT") + 1);
                        tmpMap.put("AMT", STRING.objToBigDecimal(tmpMap.get("AMT"), BigDecimal.ZERO).add(AMT));
                        tmpMap.put("TAX_AMT", STRING.objToBigDecimal(tmpMap.get("TAX_AMT"), BigDecimal.ZERO).add(TAX_AMT));
                    }
                }

            } else if ("2".equals(EXP_TP)) {//�겣 
                Map tmpMap;
                if (!mkMap.containsKey(ST_X, EXP_TP)) {
                    tmpMap = new HashMap();
                    tmpMap.put("TYPE", EXP_TP);
                    tmpMap.put("CNT", 1);
                    tmpMap.put("AMT", AMT);
                    tmpMap.put("TAX_AMT", TAX_AMT);
                    tmpMap.put("INV_NUMBER", 1);
                    tmpMap.put("MEMO", "�}���@�i");
                    mkMap.put(ST_X, EXP_TP, tmpMap);
                } else {
                    tmpMap = (Map) mkMap.get(ST_X, EXP_TP);
                    tmpMap.put("CNT", MapUtils.getIntValue(tmpMap, "CNT") + 1);
                    tmpMap.put("AMT", STRING.objToBigDecimal(tmpMap.get("AMT"), BigDecimal.ZERO).add(AMT));
                    tmpMap.put("TAX_AMT", STRING.objToBigDecimal(tmpMap.get("TAX_AMT"), BigDecimal.ZERO).add(TAX_AMT));

                }
            } else if ("1".equals(EXP_TP)) {//�O�Υ�

                if ("1".equals(USE_TP)) {//�X��
                    tmpList1.add(rtnMap);
                    Map tmpMap;
                    if (!mkMap2.containsKey(USE_TP, EXP_TP)) {//�X���O��
                        tmpMap = new HashMap();
                        tmpMap.put("TYPE", USE_TP);
                        tmpMap.put("CNT", 1);
                        tmpMap.put("AMT", AMT);
                        tmpMap.put("TAX_AMT", TAX_AMT);
                        tmpMap.put("INV_NUMBER", 0);
                        tmpMap.put("MEMO", "�}���@�i");
                        mkMap2.put(USE_TP, EXP_TP, tmpMap);
                    } else {
                        tmpMap = (Map) mkMap2.get(USE_TP, EXP_TP);
                        tmpMap.put("CNT", MapUtils.getIntValue(tmpMap, "CNT") + 1);
                        tmpMap.put("AMT", STRING.objToBigDecimal(tmpMap.get("AMT"), BigDecimal.ZERO).add(AMT));
                        tmpMap.put("TAX_AMT", STRING.objToBigDecimal(tmpMap.get("TAX_AMT"), BigDecimal.ZERO).add(TAX_AMT));
                    }
                } else if ("2".equals(USE_TP)) {//�ۥ�
                    tmpList2.add(rtnMap);
                    Map tmpMap;
                    if (!mkMap2.containsKey(USE_TP, EXP_TP)) {//�ۥζO��
                        tmpMap = new HashMap();
                        tmpMap.put("TYPE", USE_TP);
                        tmpMap.put("CNT", 1);
                        tmpMap.put("AMT", AMT);
                        tmpMap.put("TAX_AMT", TAX_AMT);
                        tmpMap.put("INV_NUMBER", 0);
                        tmpMap.put("MEMO", "�}���@�i");
                        mkMap2.put(USE_TP, EXP_TP, tmpMap);
                    } else {
                        tmpMap = (Map) mkMap2.get(USE_TP, EXP_TP);
                        tmpMap.put("CNT", MapUtils.getIntValue(tmpMap, "CNT") + 1);
                        tmpMap.put("AMT", STRING.objToBigDecimal(tmpMap.get("AMT"), BigDecimal.ZERO).add(AMT));
                        tmpMap.put("TAX_AMT", STRING.objToBigDecimal(tmpMap.get("TAX_AMT"), BigDecimal.ZERO).add(TAX_AMT));
                    }
                }
            }
        }
        if (mkMap.containsKey(ST_X, "0")) {//�D�w���
            Map keyMap = (Map) mkMap.get(ST_X, "0");
            BigDecimal AMT = STRING.objToBigDecimal(keyMap.get("AMT"), BigDecimal.ZERO);
            BigDecimal PAY_AMT = AMT.divide(new BigDecimal(1.05), 0, BigDecimal.ROUND_HALF_UP);
            //BigDecimal TAX_AMT = PAY_AMT.multiply(new BigDecimal(0.05)).setScale(0, BigDecimal.ROUND_HALF_UP);
            BigDecimal TAX_AMT = AMT.subtract(PAY_AMT);
            keyMap.put("TAX_AMT", TAX_AMT);
            keyMap.put("TYPE", "�D�w���");
            countList.add(keyMap);
        } else {
            Map NullMap = new HashMap();
            NullMap.put("TYPE", "�D�w���");
            NullMap.put("AMT", "0");
            NullMap.put("CNT", "0");
            NullMap.put("TAX_AMT", "0");
            NullMap.put("INV_NUMBER", "0");
            countList.add(NullMap);
        }
        if (mkMap.containsKey("1", "3")) {//������(���)
            Map keyMap = (Map) mkMap.get("1", "3");
            keyMap.put("TYPE", "������(���)");
            countList.add(keyMap);
        } else {
            Map NullMap = new HashMap();
            NullMap.put("TYPE", "������(���)");
            NullMap.put("AMT", "0");
            NullMap.put("CNT", "0");
            NullMap.put("TAX_AMT", "0");
            NullMap.put("INV_NUMBER", "0");
            countList.add(NullMap);
        }
        if (mkMap.containsKey("2", "3")) {//������
            Map keyMap = (Map) mkMap.get("2", "3");
            keyMap.put("TYPE", "������(�ۥ�)");
            BigDecimal AMT = STRING.objToBigDecimal(keyMap.get("AMT"), BigDecimal.ZERO);
            BigDecimal PAY_AMT = AMT.divide(new BigDecimal(1.05), 0, BigDecimal.ROUND_HALF_UP);
            //BigDecimal TAX_AMT = PAY_AMT.multiply(new BigDecimal(0.05)).setScale(0, BigDecimal.ROUND_HALF_UP);
            BigDecimal TAX_AMT = AMT.subtract(PAY_AMT);
            keyMap.put("TAX_AMT", TAX_AMT);
            countList.add(keyMap);
        } else {
            Map NullMap = new HashMap();
            NullMap.put("TYPE", "������(�ۥ�)");
            NullMap.put("AMT", "0");
            NullMap.put("CNT", "0");
            NullMap.put("TAX_AMT", "0");
            NullMap.put("INV_NUMBER", "0");
            countList.add(NullMap);
        }
        if (mkMap.containsKey(ST_X, "2")) {//�겣��
            Map keyMap = (Map) mkMap.get(ST_X, "2");
            keyMap.put("TYPE", "�겣��");
            BigDecimal AMT = STRING.objToBigDecimal(keyMap.get("AMT"), BigDecimal.ZERO);
            BigDecimal PAY_AMT = AMT.divide(new BigDecimal(1.05), 0, BigDecimal.ROUND_HALF_UP);
            //BigDecimal TAX_AMT = PAY_AMT.multiply(new BigDecimal(0.05)).setScale(0, BigDecimal.ROUND_HALF_UP);
            BigDecimal TAX_AMT = AMT.subtract(PAY_AMT);
            keyMap.put("TAX_AMT", TAX_AMT);
            if (TAX_AMT.add(PAY_AMT).compareTo(AMT) == 0) {
                keyMap.put("INV_NUMBER", "1");
            } else {
                keyMap.put("ERROR", "Y");
                keyMap.put("INV_NUMBER", "1");
            }
            countList.add(keyMap);
        } else {
            Map NullMap = new HashMap();
            NullMap.put("TYPE", "�겣��");
            NullMap.put("AMT", "0");
            NullMap.put("CNT", "0");
            NullMap.put("TAX_AMT", "0");
            NullMap.put("INV_NUMBER", "0");
            countList.add(NullMap);
        }

        //�B�z �P�_�O�Υ�[�`����B
        if (mkMap2.containsKey("1", "1")) {//�X���O��
            Map keyMap = (Map) mkMap2.get("1", "1");
            keyMap.put("TYPE", "�X���O��");
            BigDecimal AMT = STRING.objToBigDecimal(keyMap.get("AMT"), BigDecimal.ZERO);
            BigDecimal PAY_AMT = AMT.divide(new BigDecimal(1.05), 0, BigDecimal.ROUND_HALF_UP);
            //BigDecimal TAX_AMT = PAY_AMT.multiply(new BigDecimal(0.05)).setScale(0, BigDecimal.ROUND_HALF_UP);
            BigDecimal TAX_AMT = AMT.subtract(PAY_AMT);
            if (TAX_AMT.add(PAY_AMT).compareTo(AMT) == 0) {
                keyMap.put("INV_NUMBER", "1");
            } else {
                keyMap.put("ERROR", "Y");
                keyMap.put("INV_NUMBER", "1");
            }
            countList.add(keyMap);
        } else {
            Map NullMap = new HashMap();
            NullMap.put("TYPE", "�X���O��");
            NullMap.put("AMT", "0");
            NullMap.put("CNT", "0");
            NullMap.put("TAX_AMT", "0");
            NullMap.put("INV_NUMBER", "0");
            countList.add(NullMap);
        }
        if (mkMap2.containsKey("2", "1")) {//�ۥζO��
            Map keyMap = (Map) mkMap2.get("2", "1");
            keyMap.put("TYPE", "�ۥζO��");
            BigDecimal AMT = STRING.objToBigDecimal(keyMap.get("AMT"), BigDecimal.ZERO);
            BigDecimal PAY_AMT = AMT.divide(new BigDecimal(1.05), 0, BigDecimal.ROUND_HALF_UP);
            //BigDecimal TAX_AMT = PAY_AMT.multiply(new BigDecimal(0.05)).setScale(0, BigDecimal.ROUND_HALF_UP);
            BigDecimal TAX_AMT = AMT.subtract(PAY_AMT);
            keyMap.put("TAX_AMT", TAX_AMT);
            if (TAX_AMT.add(PAY_AMT).compareTo(AMT) == 0) {
                keyMap.put("INV_NUMBER", "1");
            } else {
                keyMap.put("ERROR", "Y");
                keyMap.put("INV_NUMBER", "1");
            }
            countList.add(keyMap);
        } else {
            Map NullMap = new HashMap();
            NullMap.put("TYPE", "�ۥζO��");
            NullMap.put("AMT", "0");
            NullMap.put("CNT", "0");
            NullMap.put("TAX_AMT", "0");
            NullMap.put("INV_NUMBER", "0");
            countList.add(NullMap);
        }
        return countList;
    }

    /**
     * ����EXCEL
     * @param rtnList
     * @param resp
     * @param user
     * @throws Exception
     */
    private void exportXLS(List<Map> rtnList, List<Map> countList, ResponseContext resp, UserObject user, Map reqMap) throws Exception {
        HSSFWorkbook workbook = new HSSFWorkbook();// �u�@��
        String name = "�q���}�o�����Ӫ�";
        HSSFSheet sheet = workbook.createSheet(name);
        StringBuffer sb = new StringBuffer();

        this.createworkbook(workbook, sheet, rtnList, countList, user, reqMap);

        sb.append(name).append('_').append(DATE.getY2KDate().replace("-", "")).append(".xls");
        String filename = sb.toString();

        // ���ͼȦs��
        File downloadFile = RptUtils.createTempFile(filename);
        // ��X excel �ɪ����|
        String path = downloadFile.getPath();
        FileOutputStream fileOutputString = new FileOutputStream(path);
        workbook.write(fileOutputString);
        fileOutputString.close();
        RptUtils.cryptoDownloadParameterToResp(filename, downloadFile, resp);
    }

    /**
     * ����WORKBOOK
     * @throws ModuleException 
     */
    private void createworkbook(HSSFWorkbook workbook, HSSFSheet sheet, List<Map> rtnList, List<Map> countList, UserObject user, Map reqMap)
            throws ModuleException {

        //�]�wSTYLE
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���"); //���Y
        HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���"); //�����Y
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���"); //���Ӥ�r
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���"); //���ӼƦr
        HSSFCellStyle style4 = createStyle(workbook, 4, "�s�ө���"); //��r�a��

        HSSFRow row;
        int beginRow = 1;
        int totalColumns = 6;

        //���D
        String DATE_S = MapUtils.getString(reqMap, "DATE_S");
        String DATE_E = MapUtils.getString(reqMap, "DATE_E");
        String RNT_TP_NM = DATE_S + "��" + DATE_E + "�����禬�ץ����";
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style0, 0, RNT_TP_NM, false, true, beginRow, beginRow, 0, totalColumns - 2, false); //101/11/23/��101/12/7�����禬�ץ����
        setColumn(sheet, row, style0, 5, "TO�G�M�餽�J�j�H�޲z���@", false, false, null, null, null, null, false); //TO�G�M�餽�J�j�H�޲z���@
        beginRow++;

        //���Y
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style1, 0, "�׸�", false, false, null, null, null, null, false); //�׸�
        setColumn(sheet, row, style1, 1, "�j�ӦW��", false, false, null, null, null, null, false); //�j�ӦW��
        setColumn(sheet, row, style1, 2, "�ϥΧO", false, false, null, null, null, null, false); //�ϥΧO
        setColumn(sheet, row, style1, 3, "�w��O", false, false, null, null, null, null, false); //�w��O
        setColumn(sheet, row, style1, 4, "��µ���B", false, false, null, null, null, null, false); //��µ���B
        setColumn(sheet, row, style1, 5, "�ӽФ��e", false, false, null, null, null, null, false); //�ӽФ��e

        beginRow++;

        //���Ӹ��(�t�X�p,�s�դp�p)
        createDetail(workbook, beginRow, sheet, row, style1, style2, style3, style4, rtnList, totalColumns, countList);
    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @return
     */
    private HSSFCellStyle createStyle(HSSFWorkbook workbook, int type, String font_type) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();

        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);

        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�j���Y
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            font.setFontHeightInPoints((short) 22); // �j�p         

        } else if (type == 1) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.BLACK.index);
            font.setColor(HSSFColor.BLACK.index);
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 3) {//���ӼƦr
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        }

        style.setFont(font);

        if (type != 0) {
            //�~��
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        }

        return style;
    }

    /**
     *  �]�w���
     * @param sheet
     * @param bodyRow
     * @param style ���A
     * @param columnNumber ���ͲĴX��cell
     * @param content  ���
     * @param doCombine �O�_�ݦX���x�s��
     * @param firstRow
     * @param lastRow
     * @param firstCol
     * @param lastCol
     * @param backGround
     */
    private void setColumn(HSSFSheet sheet, HSSFRow bodyRow, HSSFCellStyle style, Integer columnNumber, String content, boolean isNumeric,
            boolean doCombine, Integer firstRow, Integer lastRow, Integer firstCol, Integer lastCol, boolean backGround) {

        HSSFCell bodyCell;
        bodyCell = bodyRow.createCell(columnNumber);
        bodyCell.setCellStyle(style);

        if (doCombine) {
            for (int s = firstCol; s <= lastCol; s++) {
                bodyCell = bodyRow.createCell(s);
                bodyCell.setCellStyle(style);
            }

            //�X���x�s��
            CellRangeAddress range_inputCount = new CellRangeAddress(firstRow, lastRow, firstCol, lastCol);
            sheet.addMergedRegion(range_inputCount);

            bodyCell = bodyRow.getCell(firstCol);
        }

        if (isNumeric) {
            if (StringUtils.isNotBlank(content)) {
                bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                Double bodyText = new Double(content);
                bodyCell.setCellValue(bodyText);
            }
        } else {
            HSSFRichTextString text = new HSSFRichTextString(content);
            bodyCell.setCellValue(text);
        }

        sheet.setColumnWidth(columnNumber, 20 * 256);
        style.setWrapText(true);

        if (backGround) {
            style.setFillForegroundColor(HSSFColor.RED.index);
            style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        }
    }

    /**
     * �إߪ��椺�e
     * @param beginRow
     * @param sheet
     * @param row
     * @param style1
     * @param style2
     * @param style3
     * @param style4
     * @param rtnList   ���Ӹ��
     * @param totalColumns  �C�C���
     * @param countList
     * @throws ModuleException
     */
    private void createDetail(HSSFWorkbook workbook, int beginRow, HSSFSheet sheet, HSSFRow row, HSSFCellStyle style1,
            HSSFCellStyle style2, HSSFCellStyle style3, HSSFCellStyle style4, List<Map> rtnList, int totalColumns, List<Map> countList)
            throws ModuleException {

        BigDecimal AMT = BigDecimal.ZERO;

        HSSFCellStyle style2_1 = createStyle(workbook, 2, "�s�ө���"); //���Ӥ�r
        HSSFCellStyle style3_1 = createStyle(workbook, 3, "�s�ө���"); //���ӼƦr
        HSSFCellStyle style4_1 = createStyle(workbook, 4, "�s�ө���"); //��r�a��

        //����
        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);

            //���Ӹ��
            row = sheet.createRow(beginRow);
            setColumn(sheet, row, style2, 0, MapUtils.getString(rtnMap, "APLY_NO") + "-" + MapUtils.getString(rtnMap, "MEMO_NO"), false,
                false, null, null, null, null, false);//�׸�
            setColumn(sheet, row, style4, 1, MapUtils.getString(rtnMap, "BLD_NM"), false, false, null, null, null, null, false); //�j�ӦW��
            setColumn(sheet, row, style2, 2, MapUtils.getString(rtnMap, "USE_TP_NM"), false, false, null, null, null, null, false); //�ϥΧO
            setColumn(sheet, row, style2, 3, MapUtils.getString(rtnMap, "EXP_TP_NM"), false, false, null, null, null, null, false);//�w��O
            setColumn(sheet, row, style3, 4, MapUtils.getString(rtnMap, "AMT"), false, false, null, null, null, null, false);//��µ���B
            setColumn(sheet, row, style4, 5, MapUtils.getString(rtnMap, "FIX_MO"), false, false, null, null, null, null, false);//�ӽФ��e

            beginRow++;

            //�X�p�p��
            AMT = AMT.add(obj2Big(rtnMap, "AMT", BigDecimal.ZERO));

        }

        //�X�p
        row = sheet.createRow(beginRow);
        for (int j = 0; j < totalColumns; j++) {
            if (j == 1) {
                setColumn(sheet, row, style2, j, "�@" + rtnList.size() + "��", false, true, beginRow, beginRow, 0, 1, false);//�@�X��
            } else if (j == 4) {
                setColumn(sheet, row, style3, j, AMT.toPlainString(), true, false, null, null, null, null, false);//�`���B
            } else {
                setColumn(sheet, row, style2, j, null, false, false, null, null, null, null, false);//�®تŮ�
            }
        }

        beginRow++;
        beginRow++;

        //���Ӹ��
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style2, 0, "����", false, false, null, null, null, null, false);//����
        setColumn(sheet, row, style2, 1, "���", false, false, null, null, null, null, false); //���
        setColumn(sheet, row, style2, 2, "���B", false, false, null, null, null, null, false); //���B
        setColumn(sheet, row, style2, 3, "�|�B", false, false, null, null, null, null, false);//�|�B
        setColumn(sheet, row, style2, 4, "�o����", false, false, null, null, null, null, false);//�o����
        setColumn(sheet, row, style2, 5, "�Ƶ�", false, false, null, null, null, null, false);//�Ƶ�

        beginRow++;

        AMT = BigDecimal.ZERO;
        BigDecimal TAX_AMT = BigDecimal.ZERO;
        BigDecimal CNT = BigDecimal.ZERO;
        BigDecimal INV_NUMBER = BigDecimal.ZERO;

        //����
        for (int i = 0; i < countList.size(); i++) {
            Map<String, Object> rtnMap = countList.get(i);
            String ERROR = MapUtils.getString(rtnMap, "ERROR");
            boolean backGround = "Y".equals(ERROR);
            //���Ӹ��
            row = sheet.createRow(beginRow);
            if (backGround) {
                //if (true) {
                setColumn(sheet, row, style2_1, 0, MapUtils.getString(rtnMap, "TYPE"), false, false, null, null, null, null, false);//����
                setColumn(sheet, row, style3_1, 1, MapUtils.getString(rtnMap, "CNT"), false, false, null, null, null, null, true); //���
                setColumn(sheet, row, style3_1, 2, MapUtils.getString(rtnMap, "AMT"), false, false, null, null, null, null, true); //���B
                setColumn(sheet, row, style3_1, 3, MapUtils.getString(rtnMap, "TAX_AMT"), false, false, null, null, null, null, true); //�|�B
                setColumn(sheet, row, style3_1, 4, MapUtils.getString(rtnMap, "INV_NUMBER"), false, false, null, null, null, null, true);//�o����
                setColumn(sheet, row, style4_1, 5, MapUtils.getString(rtnMap, "MEMO"), false, false, null, null, null, null, false);//�Ƶ�
            } else {
                setColumn(sheet, row, style2, 0, MapUtils.getString(rtnMap, "TYPE"), false, false, null, null, null, null, false);//����
                setColumn(sheet, row, style3, 1, MapUtils.getString(rtnMap, "CNT"), false, false, null, null, null, null, false); //���
                setColumn(sheet, row, style3, 2, MapUtils.getString(rtnMap, "AMT"), false, false, null, null, null, null, false); //���B
                setColumn(sheet, row, style3, 3, MapUtils.getString(rtnMap, "TAX_AMT"), false, false, null, null, null, null, false); //�|�B
                setColumn(sheet, row, style3, 4, MapUtils.getString(rtnMap, "INV_NUMBER"), false, false, null, null, null, null, false);//�o����
                setColumn(sheet, row, style4, 5, MapUtils.getString(rtnMap, "MEMO"), false, false, null, null, null, null, false);//�Ƶ�
            }

            beginRow++;

            AMT = AMT.add(obj2Big(rtnMap, "AMT", BigDecimal.ZERO));
            CNT = CNT.add(obj2Big(rtnMap, "CNT", BigDecimal.ZERO));
            TAX_AMT = TAX_AMT.add(obj2Big(rtnMap, "TAX_AMT", BigDecimal.ZERO));
            INV_NUMBER = INV_NUMBER.add(obj2Big(rtnMap, "INV_NUMBER", BigDecimal.ZERO));

        }

        //�X�p
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style2, 0, "�X�p", false, false, null, null, null, null, false);//�X�p
        setColumn(sheet, row, style3, 1, CNT.toPlainString(), false, false, null, null, null, null, false); //���
        setColumn(sheet, row, style3, 2, AMT.toPlainString(), false, false, null, null, null, null, false); //���B
        setColumn(sheet, row, style3, 3, TAX_AMT.toPlainString(), false, false, null, null, null, null, false); //�|�B
        setColumn(sheet, row, style3, 4, INV_NUMBER.toPlainString(), false, false, null, null, null, null, false);//�o����
        setColumn(sheet, row, style4, 5, "", false, false, null, null, null, null, false);//�Ƶ�

    }

    /**
     * �P�_�O�_�� BigDecimal �榡�A�w�藍�P���p�i���ഫ
     * @param map
     * @param key
     * @param defaultValue
     * @return
     */
    private BigDecimal obj2Big(Map map, String key, BigDecimal defaultValue) {
        Object o = MapUtils.getObject(map, key, defaultValue);
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o;
            } else {
                String str = o.toString();
                if (StringUtils.isNotBlank(str)) {
                    return new BigDecimal(str);
                } else {
                    return defaultValue;
                }
            }
        }
        return defaultValue;
    }

    /**
     * Deliver decimal/int to iReport will cause many problems,
     * so All data will be convert to String.
     * @param rtnMap
     */
    private BigDecimal convertString(List<Map> rptList, LocaleDisplay LD) {
        BigDecimal TOTAL_AMT = BigDecimal.ZERO;
        int i = 1;
        EP_Z0F110 theEP_Z0F110 = new EP_Z0F110();

        for (Map rtnMap : rptList) {

            rtnMap.put("SEQ_NO", i++);
            try {
                theEP_Z0F110.setSUP_NM(rtnMap);
                rtnMap.put("SUP_ID", MapUtils.getString(rtnMap, "SUP_NM"));
            } catch (Exception e) {
                rtnMap.put("SUP_NM", "");
            }

            Iterator it = rtnMap.keySet().iterator();
            while (it.hasNext()) {
                String key = (String) it.next();
                Object obj = rtnMap.get(key);
                if ("ACT_AMT".equals(key)) {
                    TOTAL_AMT = TOTAL_AMT.add(STRING.objToBigDecimal(obj, BigDecimal.ZERO));
                }
                if (obj == null) {
                    rtnMap.put(key, "");
                } else if (obj instanceof BigDecimal) {

                    rtnMap.put(key, LD.formatNumber(obj, 0, ""));
                } else {
                    rtnMap.put(key, obj.toString());
                }
            }

        }
        return TOTAL_AMT;
    }

    /**
     * ErrorInputException
     * @param eie
     * @param errMsg
     * @return 
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * �]�wdataset��
     * @param ds
     * @param value
     * @param key
     */
    private void setFieldIfExist(DataSet ds, Map reqMap, String key) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * ���o����������
     * @param rtnMap
     * @param theEP_Z0F110
     * @param theEP_Z00100
     * @param divData
     * @param SUB_CPY_ID
     * @param user
     * @throws Exception 
     */
    private void getNM(Map rtnMap, EP_Z0F110 theEP_Z0F110, EP_Z00100 theEP_Z00100, DivData divData, RZ_Z0Z002 theRZ_Z0Z002)
            throws Exception {
        //���o�u�γ~�v����:
        rtnMap.put("USE_TP_NM", FieldOptionList.getName("EP", "USE_TP_F101", MapUtils.getString(rtnMap, "USE_TP")));
        //���o�u�O�κ����v����
        rtnMap.put("EXP_TP_NM", FieldOptionList.getName("EP", "EXP_TP_F101", MapUtils.getString(rtnMap, "EXP_TP")));
        //���o�u�t�ӡv����
        theEP_Z0F110.setSUP_NM(rtnMap);
        //���o�u�u�{�k�ݡv����
        rtnMap.put("PRO_OWN_NM", FieldOptionList.getName("EP", "PRO_OWN", MapUtils.getString(rtnMap, "PRO_OWN")));
        //���o�u�ץ�����v����
        rtnMap.put("APLY_TP_NM", FieldOptionList.getName("EP", "APLY_TP_F101", MapUtils.getString(rtnMap, "APLY_TP")));
        //���o��줤��
        String INPUT_DIV_NO = MapUtils.getString(rtnMap, "INPUT_DIV_NO");
        String INPUT_DIV_NM = MapUtils.getString(rtnMap, "INPUT_DIV_NM");
        //if (StringUtils.isNotBlank(INPUT_DIV_NO)) {
        if (StringUtils.isNotBlank(INPUT_DIV_NO) && StringUtils.isBlank(INPUT_DIV_NM)) {//[2019.04.18]�į�ﵽ
            //try {
            //rtnMap.put("INPUT_DIV_NM", theEP_Z00100.getDivName(INPUT_DIV_NO, SUB_CPY_ID));//[2019.04.18]�į�ﵽ
            //} catch (DataNotFoundException e) {
            try {
                rtnMap.put("INPUT_DIV_NM", divData.getUnit4ShortName(INPUT_DIV_NO));
            } catch (SQLException e1) {
                rtnMap.put("INPUT_DIV_NM", INPUT_DIV_NO);
            }
            //}
        }

        //2018-06-19 ���~�� �t�X�~������k�վ�ǤJ�Ѽ�
        rtnMap.put("LEVEL_CH", "�_");
        String SUP_NM = MapUtils.getString(rtnMap, "SUP_NM");
        String APLY_NO = MapUtils.getString(rtnMap, "APLY_NO");
        String REPORT_TP = MapUtils.getString(rtnMap, "REPORT_TP");
        String LEVEL = MapUtils.getString(rtnMap, "LEVEL");
        log.debug("rtnMap>>" + rtnMap);//TODO
        if (StringUtils.isNotBlank(LEVEL) && "3".equals(LEVEL)) {
            rtnMap.put("LEVEL_CH", "�O");
        }
        //�P�_�����t�ӦW�١A�B�����������дک��Ӫ��A�~�d�߸��
        //if (StringUtils.isNotBlank(SUP_NM) && !"�L���t��".equals(SUP_NM) && "4".equals(REPORT_TP)) {
        if (StringUtils.isNotBlank(SUP_NM) && !"�L���t��".equals(SUP_NM) && "4".equals(REPORT_TP) && StringUtils.isBlank(LEVEL)) {//[2019.04.18]�į�ﵽ
            //���ˮ֨���W��
            String api = "AI/doAccountLEVEL";
            //���oSERVER����
            String serverType = ConfigManager.getProperty("ebaf.ServerType");
            log.debug("serverType>>" + serverType);
            //���o�����ҩ��}
            String targetURL = theRZ_Z0Z002.getCodeName("EP", "AI_FUND_APIURL", serverType) + api;//"ZZ", "APIM_URL"
            //http://swas3.cathaylife.com.tw/ZSWeb/api/AI/doAccountLEVEL
            log.debug("targetURL>>" + targetURL);
            //�]�w�Ѽ�
            Map parameterMap = new HashMap();
            parameterMap.put("ID", "");
            parameterMap.put("NAME", SUP_NM);
            parameterMap.put("Q_KIND", "EP");
            parameterMap.put("SRC_KEY", APLY_NO);
            //�z�LAPI���o����]�w�M�� "AI/doAccountLEVEL"
            Map responseMap = doAPIPost(targetURL, parameterMap);

            String LEVEL_CH = "";
            Integer result = MapUtils.getInteger(responseMap, "returnCode", 1);
            if (result == 0) {
                LEVEL_CH = (String) MapUtils.getObject(responseMap, "detail", Collections.EMPTY_LIST);
                log.debug("LEVEL_CH::" + LEVEL_CH);
                //3���
                if ("3".equals(LEVEL_CH)) {
                    rtnMap.put("LEVEL_CH", "�O");
                }
            } else {
                StringBuilder errorMessage = new StringBuilder("���o�æ�����W��A�I�sAPI�^�����~�A���~���G").append(MapUtils.getString(responseMap,
                    "returnMsg"));
                log.error(errorMessage.toString());
                throw new ModuleException(errorMessage.toString());
            }
        }
    }

    /**
     * HTTP POST�q��
     * @param url
     * @param ID
     * @return Map responseObj
     * @throws Exception 
     * @throws Exception
     */
    public Map doAPIPost(String url, Map parameterMap) throws Exception {

        try {
            HttpClientHelper httpClientHelper = new HttpClientHelper();
            Object responseObj = httpClientHelper.getHttpResponseByJSON(url, Collections.EMPTY_MAP, VOTool.toJSON(parameterMap),
                HttpResponseType.STRING, "UTF-8");
            if (isDebug) {
                log.debug("�o�e�ШD�� URL�G" + url);
                //�o�e�ШD�� URL�Ghttp://swas3.cathaylife.com.tw/ZSWeb/api/AI/doAccountLEVEL
                log.debug("�ϥΰѼơGparameterMap = " + parameterMap);
                //�ϥΰѼơGparameterMap = {NAME=�FO������, SRC_KEY=201809175315, Q_KIND=EP, ID=}
                log.debug("�o�쪺�^���G" + responseObj);
                //�o�쪺�^���G{"returnCode":"0","detail":"0","returnMsg":"API success"}
            }

            return VOTool.jsonToMap(responseObj.toString());
        } catch (Exception e) {
            log.fatal("�I�sAPI �o�ͨҥ~���~", e);
            throw e;
        }

    }

    /**
     * �u�{�дڥӽЪ�(�ۥΩΥX��)
     * @param user
     * @param resp
     * @param APLY_TPs
     * @param printList2
     * @param REPORT_TYPE
     * @return
     * @throws ModuleException 
     * @throws IOException 
     */
    private FileItem printReport2(UserObject user, ResponseContext resp, String APLY_TPs, List<Map> printList2, RequestContext req,
            boolean createFileItem, String tempFilePath, String SUB_CPY_ID) throws ModuleException, IOException {
        List<Map> printList2_1 = new ArrayList<Map>();//�X��
        List<Map> printList2_2 = new ArrayList<Map>();//�ۥ�
        DivData divData = new DivData();
        EP_Z00100 theEP_Z00100 = new EP_Z00100();

        //�t�Ӳνs
        String SUP_ID = "";
        //���o��줤��
        String INPUT_DIV_NO = "";
        for (Map map : printList2) {
            String USE_TP = MapUtils.getString(map, "USE_TP", "");
            BigDecimal F110_ACT_AMT = STRING.objToBigDecimal(map.get("F110_ACT_AMT"), BigDecimal.ZERO);
            if (EP_Z0F110.ST_1.equals(USE_TP) && BigDecimal.ZERO.compareTo(F110_ACT_AMT) < 0) {
                //�X��
                printList2_1.add(map);
            } else {
                //�ۥ�
                //�t�Ӳνs
                if (StringUtils.isNotBlank(MapUtils.getString(map, "SUP_ID", ""))) {
                    SUP_ID = MapUtils.getString(map, "SUP_ID", "");
                }
                //��줤��
                INPUT_DIV_NO = MapUtils.getString(map, "INPUT_DIV_NO");
                if (StringUtils.isNotBlank(INPUT_DIV_NO)) {
                    try {
                        INPUT_DIV_NO = theEP_Z00100.getDivName(INPUT_DIV_NO, SUB_CPY_ID);
                    } catch (DataNotFoundException e1) {
                        try {
                            INPUT_DIV_NO = divData.getUnit4ShortName(INPUT_DIV_NO);
                        } catch (SQLException e) {
                            INPUT_DIV_NO = user.getDivShortName();
                        }
                    }
                }
                if (StringUtils.isBlank(INPUT_DIV_NO)) {
                    INPUT_DIV_NO = user.getDivShortName();
                }
                printList2_2.add(map);
            }
        }
        if (printList2_1.size() % 11 > 0) {
            //�X��
            for (int i = printList2_1.size() % 11; i < 11; i++) {
                printList2_1.add(new HashMap<String, String>());
            }
        }
        if (printList2_2.size() % 11 > 0) {
            //�ۥ�
            for (int i = printList2_2.size() % 11; i < 11; i++) {
                if (i == 10) {
                    //�����A�Ȥ��ߤw�d�s�Ƭd(¾���ΦL)
                    Map map = new HashMap<String, String>();
                    //"�@�P�w��¾�~�a�`�i���Ѽt�Ӳνs:" + SUP_ID + "�@" + INPUT_DIV_NO + "�w�d�s�Ƭd(¾���ΦL)"
                    map.put("PROJECT_TP", MessageUtil.getMessage("EP_F10300_MSG_012", new Object[] { SUP_ID, INPUT_DIV_NO }));
                    printList2_2.add(map);
                } else {
                    printList2_2.add(new HashMap<String, String>());
                }
            }
        }

        FileItem fi = null;

        Map paramMap2_1 = this.doFmtRptList2(printList2_1, user, APLY_TPs);
        Map paramMap2_2 = this.doFmtRptList22(printList2_2, user, APLY_TPs);
        //JasperReportUtils.addOutputRptDataToResp(REPORT_TYPE, paramMap, printList2, resp);
        if (!printList2_1.isEmpty() && !printList2_2.isEmpty()) {

            Map[][] inputParams = new Map[][] { new Map[] { paramMap2_1 }, new Map[] { paramMap2_2 } };
            List[][] inputDetailLists = new List[][] { new List[] { printList2_1 }, new List[] { printList2_2 } };

            if (createFileItem) {
                new RptUtils().createPDFFile(inputParams, inputDetailLists, tempFilePath, null);
                fi = this.createFileItem(new File(tempFilePath));
            } else {
                JasperReportUtils.addOutputRptDataToResp(new String[] { "EP_F10300_2", "EP_F10300_22" }, inputParams, inputDetailLists,
                    req, resp);
            }
        } else if (!printList2_1.isEmpty()) {
            if (createFileItem) {
                new RptUtils().createPDFFile(paramMap2_1, printList2_1, tempFilePath, null);
                fi = this.createFileItem(new File(tempFilePath));
            } else {
                JasperReportUtils.addOutputRptDataToResp("EP_F10300_2", paramMap2_1, printList2_1, resp);
            }
        } else if (!printList2_2.isEmpty()) {
            if (createFileItem) {
                new RptUtils().createPDFFile(paramMap2_2, printList2_2, tempFilePath, null);
                fi = this.createFileItem(new File(tempFilePath));
            } else {
                JasperReportUtils.addOutputRptDataToResp("EP_F10300_22", paramMap2_2, printList2_2, resp);
            }
        }

        return fi;
    }

    /**
     * ���� FileItem ����
     * @param file
     * @return
     * @throws IOException
     */
    private FileItem createFileItem(File file) throws IOException {
        String fieldName = "uploadFile";

        FileItemFactory factory = new DiskFileItemFactory();

        FileItem fileItem = factory.createItem(fieldName, "text/plain", true, file.getName());

        FileInputStream fis = null;
        OutputStream os = null;

        try {

            fis = new FileInputStream(file);
            os = fileItem.getOutputStream();

            int bytesRead = 0;
            byte[] buffer = new byte[1024];

            while ((bytesRead = fis.read(buffer, 0, 1024)) != -1) {
                os.write(buffer, 0, bytesRead);
            }

        } finally {
            if (os != null) {
                os.close();
            }
            if (os != null) {
                fis.close();
            }
        }

        return fileItem;
    }

    /**
     * (�O�Υ�������Ӫ�)
     * @param printList7
     * @param user
     */
    private List<Map> doFmtRptList7(List<Map> printList7) {

        for (Map rtnMap : printList7) {
            String EXP_TP = MapUtils.getString(rtnMap, "EXP_TP");
            String USE_TP = MapUtils.getString(rtnMap, "USE_TP");
            String APLY_TP = MapUtils.getString(rtnMap, "APLY_TP");
            //���o�u�γ~�v����:
            rtnMap.put("USE_TP_NM", FieldOptionList.getName("EP", "USE_TP_F101", USE_TP));
            //���o�u�O�κ����v����
            rtnMap.put("EXP_TP_NM", FieldOptionList.getName("EP", "EXP_TP_F101", EXP_TP));
            //���o�u�ץ�����v����
            rtnMap.put("APLY_TP_NM", FieldOptionList.getName("EP", "APLY_TP_F101", APLY_TP));
        }

        return printList7;
    }

    /**
     * ����EXCEL
     * @param rtnList
     * @param resp
     * @param user
     * @throws Exception
     */
    private void exportXLS7(List<Map> countList, ResponseContext resp, UserObject user, Map reqMap) throws Exception {
        HSSFWorkbook workbook = new HSSFWorkbook();// �u�@��
        String name = "";
        String REPORT_TP = MapUtils.getString(reqMap, "REPORT_TP");
        if ("7".equals(REPORT_TP)) {
            name = "�ץ�w�д�";
        } else if ("8".equals(REPORT_TP)) {
            name = "�w�q���I�u�|���д�";
        }
        HSSFSheet sheet = workbook.createSheet(name);
        StringBuffer sb = new StringBuffer();

        this.createworkbook7(workbook, sheet, countList, user, reqMap);

        sb.append(name).append('_').append(DATE.getY2KDate().replace("-", "")).append(".xls");
        String filename = sb.toString();

        // ���ͼȦs��
        File downloadFile = RptUtils.createTempFile(filename);
        // ��X excel �ɪ����|
        String path = downloadFile.getPath();
        FileOutputStream fileOutputString = new FileOutputStream(path);
        workbook.write(fileOutputString);
        fileOutputString.close();
        RptUtils.cryptoDownloadParameterToResp(filename, downloadFile, resp);
    }

    /**
     * ����WORKBOOK
     * @throws ModuleException 
     */
    private void createworkbook7(HSSFWorkbook workbook, HSSFSheet sheet, List<Map> rtnList, UserObject user, Map reqMap)
            throws ModuleException {
        String REPORT_TP = MapUtils.getString(reqMap, "REPORT_TP");
        //�]�wSTYLE
        HSSFCellStyle style0 = createStyle7(workbook, 0, "�s�ө���"); //�����Y
        HSSFCellStyle style1 = createStyle7(workbook, 1, "�s�ө���"); //���Ӥ�r
        HSSFCellStyle style2 = createStyle7(workbook, 2, "�s�ө���"); //���ӼƦr
        HSSFCellStyle style3 = createStyle7(workbook, 3, "�s�ө���"); //��r�a��

        HSSFRow row;
        int beginRow = 0;
        int totalColumns = 10;

        //���Y
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style0, 0, "�׸�", false, false, null, null, null, null, false); //�׸�
        setColumn(sheet, row, style0, 1, "�j�ӦW��", false, false, null, null, null, null, false); //�j�ӦW��
        setColumn(sheet, row, style0, 2, "�дڤ�", false, false, null, null, null, null, false); //�дڤ�
        setColumn(sheet, row, style0, 3, "�ӽФ��e", false, false, null, null, null, null, false); //�ӽФ��e
        setColumn(sheet, row, style0, 4, "�o�]���B", false, false, null, null, null, null, false); //�o�]���B
        setColumn(sheet, row, style0, 5, "�j�ӽs��", false, false, null, null, null, null, false); //�j�ӽs��
        setColumn(sheet, row, style0, 6, "�ϥΧO", false, false, null, null, null, null, false); //�ϥΧO
        setColumn(sheet, row, style0, 7, "�w��O", false, false, null, null, null, null, false); //�w��O
        if ("7".equals(REPORT_TP)) {
            setColumn(sheet, row, style0, 8, "�I�u��", false, false, null, null, null, null, false); //�I�u��
        } else if ("8".equals(REPORT_TP)) {
            setColumn(sheet, row, style0, 8, "�I�u��(�|���д�)", false, false, null, null, null, null, false); //�I�u��
        }
        setColumn(sheet, row, style0, 9, "�ץ����O", false, false, null, null, null, null, false); //�ץ����O
        if ("8".equals(REPORT_TP)) {
            setColumn(sheet, row, style0, 10, "����I�u��", false, false, null, null, null, null, false); //����I�u��
        }

        beginRow++;

        //���Ӹ��(�t�X�p,�s�դp�p)
        createDetail7(workbook, beginRow, sheet, row, style1, style2, style3, rtnList, totalColumns);
    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @return
     */
    private HSSFCellStyle createStyle7(HSSFWorkbook workbook, int type, String font_type) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();

        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);

        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 1) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 2) {//���ӼƦr
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 3) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        }

        style.setFont(font);

        //�~��
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);

        return style;
    }

    /**
     * �إߪ��椺�e
     * @param beginRow
     * @param sheet
     * @param row
     * @param style1
     * @param style2
     * @param style3
     * @param style4
     * @param rtnList   ���Ӹ��
     * @param totalColumns  �C�C���
     * @param countList
     * @throws ModuleException
     */
    private void createDetail7(HSSFWorkbook workbook, int beginRow, HSSFSheet sheet, HSSFRow row, HSSFCellStyle style1,
            HSSFCellStyle style2, HSSFCellStyle style3, List<Map> rtnList, int totalColumns) throws ModuleException {

        BigDecimal ACT_AMT = BigDecimal.ZERO;

        //����
        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);

            String PAY_DATE = MapUtils.getString(rtnMap, "PAY_DATE");
            String INFM_CONS_DATE = MapUtils.getString(rtnMap, "INFM_CONS_DATE");
            String PRE_CONS_DATE = MapUtils.getString(rtnMap, "PRE_CONS_DATE");

            //���Ӹ��
            row = sheet.createRow(beginRow);
            setColumn(sheet, row, style1, 0, MapUtils.getString(rtnMap, "APLY_NO"), false, false, null, null, null, null, false);//�׸�      
            setColumn(sheet, row, style3, 1, MapUtils.getString(rtnMap, "BLD_NM"), false, false, null, null, null, null, false); //�j�ӦW��
            if (StringUtils.isNotBlank(PAY_DATE)) {
                setColumn(sheet, row, style1, 2, DATE.toROCDate(PAY_DATE), false, false, null, null, null, null, false);//�дڤ�
            } else {
                setColumn(sheet, row, style1, 2, PAY_DATE, false, false, null, null, null, null, false);//�дڤ�
            }
            setColumn(sheet, row, style3, 3, MapUtils.getString(rtnMap, "PROJECT_TP"), false, false, null, null, null, null, false);//�ӽФ��e
            setColumn(sheet, row, style2, 4, MapUtils.getString(rtnMap, "ACT_AMT"), true, false, null, null, null, null, false);//�o�]���B
            setColumn(sheet, row, style1, 5, MapUtils.getString(rtnMap, "BLD_CD"), false, false, null, null, null, null, false);//�j�ӽs��
            setColumn(sheet, row, style1, 6, MapUtils.getString(rtnMap, "USE_TP_NM"), false, false, null, null, null, null, false); //�ϥΧO
            setColumn(sheet, row, style1, 7, MapUtils.getString(rtnMap, "EXP_TP_NM"), false, false, null, null, null, null, false);//�w��O
            if (StringUtils.isNotBlank(INFM_CONS_DATE)) {
                setColumn(sheet, row, style1, 8, DATE.toROCDate(INFM_CONS_DATE), false, false, null, null, null, null, false);//�I�u��
            } else {
                setColumn(sheet, row, style1, 8, INFM_CONS_DATE, false, false, null, null, null, null, false);//�I�u��
            }

            setColumn(sheet, row, style1, 9, MapUtils.getString(rtnMap, "APLY_TP_NM"), false, false, null, null, null, null, false);//�ץ����O
            if (StringUtils.isNotBlank(PRE_CONS_DATE)) {
                setColumn(sheet, row, style1, 10, DATE.toROCDate(PRE_CONS_DATE), false, false, null, null, null, null, false);//����I�u��
            } else {
                setColumn(sheet, row, style1, 10, PRE_CONS_DATE, false, false, null, null, null, null, false);//����I�u��
            }

            beginRow++;

            //�X�p�p��
            ACT_AMT = ACT_AMT.add(obj2Big(rtnMap, "ACT_AMT", BigDecimal.ZERO));

        }

        //�X�p
        row = sheet.createRow(beginRow);
        for (int j = 0; j < totalColumns; j++) {
            /*if (j == 1) {
                setColumn(sheet, row, style1, j, "�@" + rtnList.size() + "��", false, true, beginRow, beginRow, 0, 1, false);//�@�X��
            } else*/
            if (j == 4) {
                setColumn(sheet, row, style2, j, ACT_AMT.toPlainString(), true, false, null, null, null, null, false);//�`���B
            } else {
                setColumn(sheet, row, style1, j, null, false, false, null, null, null, null, false);//�®تŮ�
            }
        }

    }
}
