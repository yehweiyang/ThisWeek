package com.cathay.ep.c1.module;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.DATE;
import com.cathay.common.util.STRING;
import com.cathay.ep.a3.module.EP_A30040;
import com.cathay.ep.b1.module.EP_B10010;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.vo.DTEPC101;
import com.cathay.ep.z0.module.EP_Z0C101;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * DATE    Description Author
 * 2013/10/9   Created �רK��
 * 2018/03/7   �t�X��ؾɤJ�վ� ����[
 *
 * �@�B  �{���\�෧�n�����G
 * �ҲզW��    �����ɦ@�μҲ�
 * �Ҳ�ID    EP_C1Z001
 * ���n����    �������ɦ@�μҲ�
 *
 * @author ����[
 * @since 2013-10-18
 */

@SuppressWarnings("unchecked")
public class EP_C1Z001 {

    private static final String SQL_getN_NEXT_PAY_DATE_001 = "com.cathay.ep.c1.module.EP_C1Z001.SQL_getN_NEXT_PAY_DATE_001";

    private static final String SQL_queryRNTAmt_001 = "com.cathay.ep.c1.module.EP_C1Z001.SQL_queryRNTAmt_001";

    private static final String SQL_queryRNTAmtByBldcd_001 = "com.cathay.ep.c1.module.EP_C1Z001.SQL_queryRNTAmtByBldcd_001";

    private static final Logger log = Logger.getLogger(EP_C1Z001.class);

    private boolean isDebug = log.isDebugEnabled();

    /**
     * ���o�U�U����ú��Ҳ�
     * @param CRT_NO    �����N��
     * @param CUS_NO    �Ȥ�Ǹ�
     * @param ED_YET    �O�_�n�P�_���������
     * @param NEXT_PAY_DATE    ���w�Y�U����ú�鬰���
     * @return NEW_PAY_DATE    �U�U����ú��
     * @throws ModuleException
     */
    public String getN_NEXT_PAY_DATE(String CRT_NO, String CUS_NO, Boolean ED_YET, String NEXT_PAY_DATE, String SUB_CPY_ID)
            throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_001"));//�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_002"));//�Ȥ�Ǹ����o���ŭ�
        }
        if (ED_YET == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_003"));//�O�_�n�P�_��������� ���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_getN_NEXT_PAY_DATE_001);

        String BASE_N_PAY_DATE;
        if (StringUtils.isBlank(NEXT_PAY_DATE)) {
            BASE_N_PAY_DATE = MapUtils.getString(rtnMap, "NEXT_PAY_DATE");//���Ĥ@�����(�����Ȥ��ɤW���U����ú��)
        } else {
            BASE_N_PAY_DATE = NEXT_PAY_DATE;
        }

        String RNT_END_DATE = MapUtils.getString(rtnMap, "RNT_END_DATE");//���������

        int PAY_FREQ = MapUtils.getIntValue(rtnMap, "PAY_FREQ");
        String NEW_PAY_DATE;
        switch (PAY_FREQ) {
            case 1: //��ú
                NEW_PAY_DATE = DATE.addDate(BASE_N_PAY_DATE, 0, 1, 0);
                break;
            case 2: //�uú
                NEW_PAY_DATE = DATE.addDate(BASE_N_PAY_DATE, 0, 3, 0);
                break;
            case 3: //�b�~ú
                NEW_PAY_DATE = DATE.addDate(BASE_N_PAY_DATE, 0, 6, 0);
                break;
            case 4: //�~ú
                NEW_PAY_DATE = DATE.addDate(BASE_N_PAY_DATE, 1, 0, 0);
                break;
            case 5: //����ú
                NEW_PAY_DATE = DATE.addDate(BASE_N_PAY_DATE, 0, 2, 0);
                break;
            case 6: //Ļú
                NEW_PAY_DATE = DATE.addDate(RNT_END_DATE, 0, 0, 1);
                break;
            default:
                NEW_PAY_DATE = null;
                break;
        }

        if (ED_YET) {//���P�_���������E

            if (DATE.diffDay(RNT_END_DATE, NEW_PAY_DATE) > 0) {

                //���������@��
                NEW_PAY_DATE = DATE.addDate(RNT_END_DATE, 0, 0, 1);
            }
        }

        return NEW_PAY_DATE;

    }

    /**
     * ���o�U����ú��Ҳ�
     * @param CRT_NO    �����N��
     * @param CUS_NO    �Ȥ�Ǹ�
     * @param PAY_E_DATE    ú�ڲ״�
     * @param SUB_CPY_ID    �����q�O
     * @return NEXT_PAY_DATE    �U����ú�鬰
     * @throws ModuleException
     */
    public String getR_NEXT_PAY_DATE(String CRT_NO, String CUS_NO, String PAY_E_DATE, String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_001"));//�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_002"));//�Ȥ�Ǹ����o���ŭ�
        }
        if (PAY_E_DATE == null) {
            eie = getErrorInputException(eie, "");//ú�ڲ״� ���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        Map rtnMap = VOTool.findOneToMap(ds, SQL_getN_NEXT_PAY_DATE_001);

        String BASE_N_PAY_DATE;
        BASE_N_PAY_DATE = MapUtils.getString(rtnMap, "NEXT_PAY_DATE");//���Ĥ@�����(�����Ȥ��ɤW���U����ú��)
        if (isDebug) {
            log.debug("@@@BASE_N_PAY_DATE=" + BASE_N_PAY_DATE);
            log.debug("@@@PAY_E_DATE=" + PAY_E_DATE);
        }

        String R_NEXT_PAY_DATE = BASE_N_PAY_DATE;

        if (DATE.diffDay(BASE_N_PAY_DATE, PAY_E_DATE) > 0) {

            //ú�ڲ״���@��
            R_NEXT_PAY_DATE = DATE.addDate(PAY_E_DATE, 0, 0, 1);
        }
        if (isDebug) {
            log.debug("@@@R_NEXT_PAY_DATE=" + R_NEXT_PAY_DATE);
        }

        return R_NEXT_PAY_DATE;

    }

    /**
     * �������B�p��Ҳ�
     * @param RNT_AMT       �믲��
     * @param PAY_STR_DT    ú�کl��
     * @param PAY_END_DT    ú�ڲ״�
     * @param RNT_END_DATE  �������
     * @param PAY_FREQ      ú�O
     * @param NEXT_PAY_DATE �U����ú��
     * @param NextRNPDT     �U�U����ú��
     * @return  RCV_AMT     �������B
     * @throws ErrorInputException
     */
    public String caculatePeriodAmt(String RNT_AMT, String PAY_STR_DT, String PAY_END_DT, String RNT_END_DATE, String PAY_FREQ,
            String NEXT_PAY_DATE, String NextRNPDT) throws ErrorInputException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(RNT_AMT)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_004"));//�믲�����o���ŭ�
        }
        if (StringUtils.isBlank(PAY_STR_DT)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_005"));//ú�کl�����o���ŭ�
        }
        if (StringUtils.isBlank(PAY_END_DT)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_006"));//ú�ڲ״����o���ŭ�
        }
        if (StringUtils.isBlank(RNT_END_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_007"));//����������o���ŭ�
        }
        if (StringUtils.isBlank(PAY_FREQ)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_008"));//ú�O���o���ŭ�
        }
        if (StringUtils.isBlank(NEXT_PAY_DATE)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_009"));//�U����ú�餣�o���ŭ�
        }
        if (StringUtils.isBlank(NextRNPDT)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_010"));//�U�U����ú�餣�o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        BigDecimal RNT_AMT_bd = toDecimal(RNT_AMT);
        String Final_Amt = "";

        if (isDebug) {
            log.debug("@@@RNT_AMT_bd=" + RNT_AMT_bd);
        }
        //�����
        if (PAY_STR_DT.subSequence(0, 7).equals(PAY_END_DT.substring(0, 7))) {

            //�p��g�L�Ѽ�
            int passDay = DATE.diffDay(PAY_STR_DT, PAY_END_DT) + 1;

            //�Ӥ���Ѽ�
            String intDay = DATE.getMonthLastDate(PAY_STR_DT).substring(8, 10);

            //�p����������
            BigDecimal tmpFinalAmt = RNT_AMT_bd.multiply(new BigDecimal(String.valueOf(passDay)).divide(toDecimal(intDay), 8,
                BigDecimal.ROUND_HALF_UP));

            Final_Amt = tmpFinalAmt.setScale(0, BigDecimal.ROUND_HALF_UP).toString();

            if (isDebug) {
                log.debug("@@@�����");
                log.debug("@@@passDay=" + passDay);
                log.debug("@@@intDay=" + intDay);
                log.debug("@@@tmpFinalAmt=" + tmpFinalAmt);
                log.debug("@@@Final_Amt=" + Final_Amt);
            }

        } else { //���A���D����ú�کl��~�״�
            //ú�ڲ״�+1��<>�U�U����ú��  �� ú�کl��<>�U����ú��

            String PAY_END_DT_1 = DATE.addDate(PAY_END_DT, 0, 0, 1);

            String[] PAY_STR_DT_a = DATE.parseNumber(PAY_STR_DT);
            String[] PAY_END_DT_a = DATE.parseNumber(PAY_END_DT);
            if (isDebug) {
                log.debug("@@@ PAY_END_DT_1=" + PAY_END_DT_1);
                log.debug("@@@ NextRNPDT=" + NextRNPDT);
                log.debug("@@@ PAY_STR_DT_a=" + PAY_STR_DT_a);
                log.debug("@@@ PAY_END_DT_a=" + PAY_END_DT_a);
                log.debug("@@@ PAY_STR_DT_a[1]=" + PAY_STR_DT_a[1]);
                log.debug("@@@ PAY_END_DT_a[1]=" + PAY_END_DT_a[1]);
                log.debug("@@@ NEXT_PAY_DATE=" + NEXT_PAY_DATE);
            }
            if (!PAY_END_DT_1.equals(NextRNPDT) || !PAY_STR_DT.equals(NEXT_PAY_DATE)) {

                if (PAY_STR_DT_a[2].equals(DATE.parseNumber(PAY_END_DT_1)[2])) {
                    if ("01".equals(PAY_STR_DT_a[2])) {
                        Integer[] passYYMMDD = DATE.diffDay_YYMMDD(PAY_STR_DT, PAY_END_DT);
                        Final_Amt = toDecimal(RNT_AMT).multiply(new BigDecimal(passYYMMDD[1] + 1)).toString();
                        /*Final_Amt = toDecimal(RNT_AMT).multiply(
                            toDecimal(PAY_END_DT_a[1]).subtract(toDecimal(PAY_STR_DT_a[1])).add(BigDecimal.ONE)).toString();*/
                    } else {
                        Integer[] passYYMMDD = DATE.diffDay_YYMMDD(PAY_STR_DT, PAY_END_DT);
                        Final_Amt = toDecimal(RNT_AMT).multiply(new BigDecimal(passYYMMDD[1] + 1)).toString();
                        //Final_Amt = toDecimal(RNT_AMT).multiply(toDecimal(PAY_END_DT_a[1]).subtract(toDecimal(PAY_STR_DT_a[1]))).toString();
                        if (isDebug) {
                            log.debug("@@@ toDecimal(RNT_AMT).multiply(new BigDecimal(passYYMMDD[1]+ 1)).toString()="
                                    + toDecimal(RNT_AMT).multiply(new BigDecimal(passYYMMDD[1] + 1)).toString());
                        }
                    }
                } else {
                    Final_Amt = this.caculateBreakMonthAmt(RNT_AMT, PAY_STR_DT, PAY_END_DT);
                }
                if (isDebug) {
                    log.debug("@@@���A���D����ú�کl��~�״�");
                    log.debug("@@@Final_Amt=" + Final_Amt);
                }

            } else {// �����O����ú�کl��~�״�

                switch (Integer.parseInt(PAY_FREQ)) {
                    case 1:
                        Final_Amt = RNT_AMT_bd.multiply(BigDecimal.ONE).toString();
                        break;
                    case 2:
                        Final_Amt = RNT_AMT_bd.multiply(toDecimal("3")).toString();
                        break;
                    case 3:
                        Final_Amt = RNT_AMT_bd.multiply(toDecimal("6")).toString();
                        break;
                    case 4:
                        Final_Amt = RNT_AMT_bd.multiply(toDecimal("12")).toString();
                        break;
                    case 5:
                        Final_Amt = RNT_AMT_bd.multiply(toDecimal("2")).toString();
                        break;
                    case 6:
                        if (PAY_STR_DT_a[2].equals(DATE.parseNumber(PAY_END_DT_1)[2])) {

                            if ("01".equals(PAY_STR_DT_a[2])) {
                                Integer[] passYYMMDD = DATE.diffDay_YYMMDD(PAY_STR_DT, PAY_END_DT);
                                Final_Amt = toDecimal(RNT_AMT).multiply(new BigDecimal(passYYMMDD[1] + 1)).toString();
                                //Final_Amt = RNT_AMT_bd.multiply(
                                // toDecimal(PAY_END_DT_a[1]).subtract(toDecimal(PAY_STR_DT_a[1])).add(BigDecimal.ONE)).toString();
                                if (isDebug) {
                                    log.debug("@@@ toDecimal(RNT_AMT).multiply(new BigDecimal(passYYMMDD[1]+ 1)).toString()="
                                            + toDecimal(RNT_AMT).multiply(new BigDecimal(passYYMMDD[1] + 1)).toString());
                                }
                            } else {
                                Integer[] passYYMMDD = DATE.diffDay_YYMMDD(PAY_STR_DT, PAY_END_DT);
                                Final_Amt = toDecimal(RNT_AMT).multiply(new BigDecimal(passYYMMDD[1] + 1)).toString();
                                //Final_Amt = RNT_AMT_bd.multiply(toDecimal(PAY_END_DT_a[1]).subtract(toDecimal(PAY_STR_DT_a[1]))).toString();
                                if (isDebug) {
                                    log.debug("@@@ toDecimal(RNT_AMT).multiply(new BigDecimal(passYYMMDD[1]+ 1)).toString()="
                                            + toDecimal(RNT_AMT).multiply(new BigDecimal(passYYMMDD[1] + 1)).toString());
                                }
                            }

                        } else {
                            Final_Amt = this.caculateBreakMonthAmt(RNT_AMT, PAY_STR_DT, PAY_END_DT);
                        }
                        break;
                    default:
                        Final_Amt = "";

                }
                if (isDebug) {
                    log.debug("@@@�����O����ú�کl��~�״�");
                    log.debug("@@@PAY_FREQ=" + PAY_FREQ);
                    log.debug("@@@Final_Amt=" + Final_Amt);
                }

            }
        }
        return Final_Amt;
    }

    /**
     * �p��}���������B�Ҳ�
     * @param RNT_AMT       �믲��
     * @param PAY_STR_DT    ú�کl��
     * @param PAY_END_DT    ú�ڲ״�
     * @return  AMT         �������B
     * @throws ErrorInputException
     */
    public String caculateBreakMonthAmt(String RNT_AMT, String PAY_STR_DT, String PAY_END_DT) throws ErrorInputException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(RNT_AMT)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_004"));//�믲�����o���ŭ�
        }
        if (StringUtils.isBlank(PAY_STR_DT)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_005"));//ú�کl�����o���ŭ�
        }
        if (StringUtils.isBlank(PAY_END_DT)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_006"));//ú�ڲ״����o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        //������ú�کl��~�״����������B�p��

        //�p��Ĥ@�Ӥ�(�}��)
        //�_�l����Ѽ�
        BigDecimal intDay = toDecimal(DATE.getMonthLastDate(PAY_STR_DT).substring(8, 10));
        String PAY_END_DT_1 = DATE.addDate(PAY_END_DT, 0, 0, 1);
        String[] PAY_STR_DT_a = DATE.parseNumber(PAY_STR_DT);
        String[] PAY_END_DT_a = DATE.parseNumber(PAY_END_DT);
        BigDecimal RNT_AMT_bd = toDecimal(RNT_AMT);

        if (isDebug) {
            log.debug("PAY_STR_DT=" + PAY_STR_DT);
            log.debug("PAY_END_DT=" + PAY_END_DT);
            log.debug("intDay=" + intDay);
        }

        //�p����������
        BigDecimal temp = intDay.subtract(new BigDecimal(PAY_STR_DT_a[2])).add(new BigDecimal("1"));
        BigDecimal tmpAMT = RNT_AMT_bd.multiply(temp.divide(intDay, 8, BigDecimal.ROUND_HALF_UP));
        if (isDebug) {
            log.debug("�Ĥ@�Ӥ�(�}��)�Ѽ�temp=" + temp);
            log.debug("�Ĥ@�Ӥ�(�}��)tmpAMT=" + tmpAMT);
        }

        //�p���������
        //���oú�کl���U�@�Ӥ뤧�멳��
        String tmpNEXT = DATE.getMonthLastDate(DATE.addDate(PAY_STR_DT, 0, 1, 0));
        if (isDebug) {
            log.debug("ú�کl���U�@�Ӥ뤧�멳��tmpNEXT=" + tmpNEXT);
            log.debug("ú�ڲ״�PAY_END_DT=" + PAY_END_DT);
        }

        while (tmpNEXT.compareTo(PAY_END_DT) < 0) {
            tmpAMT = tmpAMT.add(RNT_AMT_bd);
            tmpNEXT = DATE.getMonthLastDate(DATE.addDate(tmpNEXT, 0, 1, 0));
            if (isDebug) {
                log.debug("@@@tmpNEXT=" + tmpNEXT);
                log.debug("�p���������tmpAMT=" + tmpAMT);
            }
        }

        //�p��̫�@�Ӥ�(�P�_�O�_������==>���e�p��L�F)
        if (!PAY_END_DT_a[1].equals(DATE.parseNumber(DATE.addDate(tmpNEXT, 0, -1, 0))[1])) {
            //�פ����Ѽ�
            intDay = toDecimal(DATE.getMonthLastDate(PAY_END_DT).substring(8, 10));
            BigDecimal tmpAMT_F = RNT_AMT_bd.multiply(toDecimal(PAY_END_DT_a[2]).divide(intDay, 8, BigDecimal.ROUND_HALF_UP));
            tmpAMT = tmpAMT.add(tmpAMT_F);
            tmpAMT = tmpAMT.setScale(0, BigDecimal.ROUND_HALF_UP);
            if (isDebug) {
                log.debug("@@@intDay=" + intDay);
                log.debug("�p��̫�@�Ӥ�tmpAMT_F=" + tmpAMT_F);
                log.debug("tmpAMT=" + tmpAMT);
            }

        }

        return tmpAMT.toString();

    }

    /**
     * �d�߯������J���ӼҲ�
     * @param RCV_YM_S    �����~��
     * @param RCV_YM_E    �����~��
     * @param BLD_CD    �j�ӥN��
     * @param DIV_NO    �ӿ���
     * @param CRT_NO    �����N��
     * @param CUS_NO    �Ȥ�Ǹ�
     * @param SUB_CPY_ID    �����q�O
     * @return resultList   �������J����
     * @throws ModuleException
     */
    public List<Map> queryRNTAmt(String RCV_YM_S, String RCV_YM_E, String BLD_CD, String DIV_NO, String CRT_NO, String CUS_NO,
            String SUB_CPY_ID) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_014"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        StringBuilder sb = new StringBuilder();
        String RCV_YM_BD = sb.append(RCV_YM_E).insert(4, "-").append("-01").toString();
        sb.setLength(0);
        String RCV_YM_ED = DATE.getMonthLastDate(RCV_YM_BD);
        String RCV_YM_S_BD = sb.append(RCV_YM_S).insert(4, "-").append("-01").toString();

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("RCV_YM_S", RCV_YM_S);
        ds.setField("RCV_YM_E", RCV_YM_E);
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("CUS_NO", CUS_NO);
        ds.setField("RCV_YM_BD", RCV_YM_BD);
        ds.setField("RCV_YM_ED", RCV_YM_ED);
        ds.setField("RCV_YM_S_BD", RCV_YM_S_BD);

        if (StringUtils.isNotEmpty(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }
        if (StringUtils.isNotEmpty(DIV_NO)) {
            ds.setField("DIV_NO", DIV_NO);
        }

        return VOTool.findToMaps(ds, SQL_queryRNTAmt_001);
    }

    /**
     * �d�ߤj�ӯ������J�Ҳ�
     * @param RCV_YM_S        �����~��}�l
     * @param RCV_YM_E        �����~�뵲��
     * @param BLD_CD        �j�ӥN��
     * @param DIV_NO        �ӿ���
     * @param SUB_CPY_ID    �����q�O
     * @return resultList   �������J����
     * @throws ModuleException
     */
    public List<Map> queryRNTAmtByBldcd(String RCV_YM_S, String RCV_YM_E, String BLD_CD, String DIV_NO, String SUB_CPY_ID)
            throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(RCV_YM_S)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_024"));//�����~��}�l���o���ŭ�
        }
        if (StringUtils.isBlank(RCV_YM_E)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_025"));//�����~�뵲�����o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_014"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        StringBuilder sb = new StringBuilder();
        String RCV_YM_BD = sb.append(RCV_YM_E).insert(4, "-").append("-01").toString();
        sb.setLength(0);
        String RCV_YM_ED = DATE.getMonthLastDate(RCV_YM_BD);
        String RCV_YM_S_BD = sb.append(RCV_YM_S).insert(4, "-").append("-01").toString();

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setField("RCV_YM_S", RCV_YM_S);
        ds.setField("RCV_YM_E", RCV_YM_E);
        ds.setField("RCV_YM_BD", RCV_YM_BD);
        ds.setField("RCV_YM_ED", RCV_YM_ED);
        ds.setField("RCV_YM_S_BD", RCV_YM_S_BD);

        if (StringUtils.isNotEmpty(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }
        if (StringUtils.isNotEmpty(DIV_NO)) {
            ds.setField("DIV_NO", DIV_NO);
        }

        return VOTool.findToMaps(ds, SQL_queryRNTAmtByBldcd_001);

    }

    /**
     * �s�W������
     * @param DTEPC101_VO   ������
     * @throws ModuleException
     */
    public void insertDTEPC101(DTEPC101 DTEPC101_VO) throws ModuleException {
        this.setC101_Data_RcvNo(DTEPC101_VO);

        //�s�W������(DTEPC101)
        //VOTool.insert(DTEPC101_VO);
        new EP_Z0C101().insert(DTEPC101_VO);

    }

    /**
     * ���,��rcv_no
     * @param DTEPC101_VO
     * @throws ModuleException 
     */
    public void setC101_Data_RcvNo(DTEPC101 DTEPC101_VO) throws ModuleException {

        ErrorInputException eie = null;
        String SUB_CPY_ID = null;
        String PAY_KIND = null;
        BigDecimal RCV_YM = null;
        String FLD_NO = "";
        String ROOM_NO = "";
        String PRK_NO = "";

        if (DTEPC101_VO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_015"));//�����ɤ��o���ŭ�
        } else {

            SUB_CPY_ID = DTEPC101_VO.getSUB_CPY_ID();
            RCV_YM = DTEPC101_VO.getRCV_YM();
            PAY_KIND = DTEPC101_VO.getPAY_KIND();

            FLD_NO = DTEPC101_VO.getFLD_NO();
            ROOM_NO = DTEPC101_VO.getROOM_NO();
            PRK_NO = DTEPC101_VO.getPRK_NO();

            BigDecimal SAL_AMT = STRING.objToBigDecimal(DTEPC101_VO.getSAL_AMT(), BigDecimal.ZERO);
            BigDecimal TAX_AMT = STRING.objToBigDecimal(DTEPC101_VO.getTAX_AMT(), BigDecimal.ZERO);
            BigDecimal INV_AMT = STRING.objToBigDecimal(DTEPC101_VO.getINV_AMT(), BigDecimal.ZERO);

            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_014"));//�����q�O���o���ŭ�
            }
            if (RCV_YM == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_011"));//�����~�뤣�o���ŭ�
            }
            if (StringUtils.isBlank(PAY_KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_016"));//ú�ں������o���ŭ�
            } else if ("1 2 3 4 5 6 7 8".indexOf(PAY_KIND) < 0) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_017"));//ú�ں��� ����1~7
            }
            if (StringUtils.isBlank(DTEPC101_VO.getCRT_NO())) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_001"));//�����N�����o���ŭ�
            }
            if (DTEPC101_VO.getCUS_NO() == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_002"));//�Ȥ�Ǹ����o���ŭ�
            }
            if (DTEPC101_VO.getPAY_S_DATE() == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_005"));//ú�کl�����o���ŭ�
            }
            if (DTEPC101_VO.getPAY_E_DATE() == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_006"));//ú�ڲ״����o���ŭ�
            }
            //            if (StringUtils.isBlank(DTEPC101_VO.getID())) {
            //                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_018"));//�Τ@�s�����o���ŭ�
            //            }
            if (StringUtils.isBlank(DTEPC101_VO.getBLD_CD())) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_012"));//�j�ӥN�����o���ŭ�
            }
            String TAX_TYPE = DTEPC101_VO.getTAX_TYPE();
            if (!"2".equals(PAY_KIND)) {
                if (StringUtils.isBlank(TAX_TYPE)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_019"));//�|�O���o���ŭ�
                } else if ("1 2 3 4".indexOf(TAX_TYPE) < 0) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_020", new Object[] { DTEPC101_VO.getCRT_NO() }));//�����N��({0})�A�|�O ����1~4
                }
                //�ˮֵo�����B=�P���B+�|�B
                if (INV_AMT.compareTo(SAL_AMT.add(TAX_AMT)) != 0) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPC1_0030_UI_007"));//�o�����B������(�P���B+�|�B)
                }
            }

        }
        if (eie != null) {
            throw eie;
        }

        if (StringUtils.isBlank(FLD_NO) && StringUtils.isBlank(ROOM_NO) && StringUtils.isBlank(PRK_NO)) {
            String CRT_NO = DTEPC101_VO.getCRT_NO();
            if (!"5".equals(PAY_KIND) && !"8".equals(PAY_KIND) && !("4".equals(PAY_KIND) && (CRT_NO.startsWith("OZ") || CRT_NO.startsWith("OR")))) {
                Map queryMap = new HashMap();
                queryMap.put("SUB_CPY_ID", DTEPC101_VO.getSUB_CPY_ID());
                queryMap.put("CRT_NO", DTEPC101_VO.getCRT_NO());
                queryMap.put("IS_CHK_TEMP", "N");
                queryMap.put("BLD_CD", DTEPC101_VO.getBLD_CD());
                Map B101Map = new EP_B10010().queryMap(queryMap);

                //���o���Ȥᤧ�ӯ����
                queryMap.put("CUS_NO", DTEPC101_VO.getCUS_NO());

                String RNT_TYPE = MapUtils.getString(B101Map, "RNT_TYPE");
                List<Map> rentList;
                Map rentMap = new HashMap();
                try {

                    if ("3".equals(RNT_TYPE) || "9".equals(RNT_TYPE)) { //�ӯ��O=3���� 9���u����
                        rentList = new EP_B10020().queryCar(queryMap);
                    } else {
                        rentList = new EP_B10020().queryRm(queryMap);
                    }
                    rentMap = rentList.get(0); //���Ĥ@�����
                    FLD_NO = MapUtils.getString(rentMap, "FLD_NO", "");
                    ROOM_NO = MapUtils.getString(rentMap, "ROOM_NO", "");
                    PRK_NO = MapUtils.getString(rentMap, "PRK_NO", "");

                } catch (DataNotFoundException e) {
                    try {
                        //�d�߹w���� ���ǧO�Ψ���
                        queryMap.put("RNT_KD", "3");
                        rentList = new EP_A30040().queryList(queryMap);
                        if (!rentList.isEmpty()) {
                            rentMap = rentList.get(0); //���Ĥ@�����
                        }
                    } catch (DataNotFoundException e1) {

                    }

                }
                DTEPC101_VO.setFLD_NO(FLD_NO);
                DTEPC101_VO.setROOM_NO(ROOM_NO);
                DTEPC101_VO.setPRK_NO(PRK_NO);
            }

        }

        //���o�����s��=�����q�O(2)+�����~��(6)+ú�ں���(1)+�y����(4)
        if (StringUtils.isBlank(DTEPC101_VO.getRCV_NO())) {
            int SER_NO = new EP_Z0Z001().createNextNumber(SUB_CPY_ID, "008", RCV_YM.toString(), PAY_KIND);
            DTEPC101_VO.setRCV_NO(new StringBuilder().append(SUB_CPY_ID).append(RCV_YM).append(PAY_KIND).append(
                STRING.fillZero(String.valueOf(SER_NO), 4)).toString());
            //���o�f��y����strFlowNo
        }
        //new RZ_N0Z001().startFlow(DTEPC101_VO);
        //���o�Ҳզ^��DTEPC101_VO��FLOW_NO,OP_STATUS //�f��y�{�s��,�@�~�i��
    }

    /**
     * ��s������
     * @param DTEPC101_VO   ������
     * @throws ModuleException
     */
    public void updateDTEPC101(DTEPC101 DTEPC101_VO) throws ModuleException {

        ErrorInputException eie = null;
        if (DTEPC101_VO == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_015"));//�����ɤ��o���ŭ�
        } else {

            if (StringUtils.isBlank(DTEPC101_VO.getRCV_NO())) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_021"));//�����s�����o���ŭ�
            }
            if (StringUtils.isBlank(DTEPC101_VO.getSUB_CPY_ID())) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_014"));//�����q�O���o���ŭ�
            }
            if (DTEPC101_VO.getRCV_YM() == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_011"));//�����~�뤣�o���ŭ�
            }
            String PAY_KIND = DTEPC101_VO.getPAY_KIND();
            if (StringUtils.isBlank(PAY_KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_016"));//ú�ں������o���ŭ�
            } else if ("1 2 3 4 5 6 7 8".indexOf(PAY_KIND) < 0) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_017"));//ú�ں��� ����1~7
            }
            if (StringUtils.isBlank(DTEPC101_VO.getCRT_NO())) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_001"));//�����N�����o���ŭ�
            }
            if (DTEPC101_VO.getCUS_NO() == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_002"));//�Ȥ�Ǹ����o���ŭ�
            }
            if (DTEPC101_VO.getPAY_S_DATE() == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_005"));//ú�کl�����o���ŭ�
            }
            if (DTEPC101_VO.getPAY_E_DATE() == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_006"));//ú�ڲ״����o���ŭ�
            }
            //            if (StringUtils.isBlank(DTEPC101_VO.getID())) {
            //                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_018"));//�Τ@�s�����o���ŭ�
            //            }
            if (StringUtils.isBlank(DTEPC101_VO.getBLD_CD())) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_012"));//�j�ӥN�����o���ŭ�
            }
            String TAX_TYPE = DTEPC101_VO.getTAX_TYPE();
            if (StringUtils.isBlank(TAX_TYPE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_019"));//�|�O���o���ŭ�
            } else if ("1 2 3 4".indexOf(TAX_TYPE) < 0) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_020"));//�|�O ����1~4
            }
            /*if (StringUtils.isBlank(DTEPC101_VO.getFLOW_NO())) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_022"));//�f��y�{�s�����o���ŭ�
            }*/
            if (DTEPC101_VO.getLST_PROC_DATE() == null) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C1Z001_MSG_023"));//�@�~�ɶ����o���ŭ�
            }
        }
        if (eie != null) {
            throw eie;
        }

        //VOTool.delByPK(DTEPC101_VO);

        //VOTool.insert(DTEPC101_VO);
        new EP_Z0C101().update(DTEPC101_VO);

    }

    /**
     * �R��������
     * @param DTEPC101_VO   ������
     * @throws ModuleException
     */
    public void deleteDTEPC101(DTEPC101 DTEPC101_VO) throws ModuleException {
        if (DTEPC101_VO == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C1Z001_MSG_015"));//�����ɤ��o���ŭ�
        }
        if (StringUtils.isBlank(DTEPC101_VO.getRCV_NO())) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C1Z001_MSG_021"));//�����s�����o���ŭ�
        }

        //VOTool.delByPK(DTEPC101_VO);
        new EP_Z0C101().delete(DTEPC101_VO);
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }

    /**
     * String to BigDecimal
     * @param val
     * @return
     */
    private BigDecimal toDecimal(String val) {
        if (StringUtils.isBlank(val)) {
            return null;
        }
        return new BigDecimal(val);
    }

}
