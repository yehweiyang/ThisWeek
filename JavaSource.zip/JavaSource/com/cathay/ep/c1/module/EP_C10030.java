package com.cathay.ep.c1.module;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.a3.module.EP_A30040;
import com.cathay.ep.b1.module.EP_B10010;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.vo.DTEPC101;
import com.cathay.ep.z0.module.EP_Z0Z001;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 * Date Version Description Author
 * 2013/9/26   1.0 �s�W  �\�a�s
 * 2018/1/31   1.1 �q�l�o��:�w�T�{���������i�R��  ����[
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �����ɿ�J�Ҳ�
 * �{���W��    EP_C10030
 * ���n����    �����ɸ�ƺ��@
 * 
 * 
 * [20180306] �ק��
 * ��ؾɤJ�Gú�ں����s�W�{�ɰ�����
 *
 * @author ����[
 * @since 2013-10-16  
 */

@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C10030 {

    private static final Logger log = Logger.getLogger(EP_C10030.class);

    //private static final String SQL_insertC101_001 = "com.cathay.ep.c1.module.EP_C10030.SQL_insertC101_001";

    private static final String SQL_insertC101_002 = "com.cathay.ep.c1.module.EP_C10030.SQL_insertC101_002";

    private static final String SQL_deleteC101_001 = "com.cathay.ep.c1.module.EP_C10030.SQL_deleteC101_001";

    private static final String SQL_chkInsertC101_001 = "com.cathay.ep.c1.module.EP_C10030.SQL_chkInsertC101_001";

    private static final String SQL_updateC101_001 = "com.cathay.ep.c1.module.EP_C10030.SQL_updateC101_001";

    //    private static final String SQL_getBLD_NAME_001 = "com.cathay.ep.c1.module.EP_C10030.SQL_getBLD_NAME_001";

    private boolean isDebug = log.isDebugEnabled();

    /**
     * �d���������   
     * @param RCV_YM    �����~��
     * @param CRT_NO    �����N��
     * @param CUS_NO    �Ȥ�Ǹ�
     * @param PAY_KIND  ú�ں���
     * @param ID        �Τ@�s��
     * @param SUB_CPY_ID �����q�O
     * @return rtnList  �������List
     * @throws Exception 
     */
    public List<Map> queryList(String RCV_YM, String CRT_NO, String CUS_NO, String PAY_KIND, String ID, String SUB_CPY_ID) throws Exception {
        if (StringUtils.isBlank(CRT_NO) || StringUtils.isBlank(CUS_NO)) {
            throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_008"));//�����N��,�Ȥ�Ǹ����������
        }

        Map qryMap = new HashMap();
        qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
        qryMap.put("RCV_YM", RCV_YM);
        qryMap.put("CRT_NO", CRT_NO);
        qryMap.put("CUS_NO", CUS_NO);
        qryMap.put("PAY_KIND", PAY_KIND);
        qryMap.put("ID", ID);

        List<Map> rtnList = new EP_C10010().query1(qryMap);

        for (Map rtnMap : rtnList) {
            //rtnMap.put("DIV_NAME", new DivData().getUnit4ShortName(MapUtils.getString(rtnMap, "DIV_NO")));
            //2018-03-13 �վ���W�٧���Ҳ�
            rtnMap.put("DIV_NAME", new EP_A10010().getDivName(MapUtils.getString(rtnMap, "DIV_NO"), SUB_CPY_ID));
            rtnMap.put("TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE", ""));
        }

        return rtnList;

    }

    /**
     * �s�W�������
     * @param reqMap    �e���ǤJ�����
     * @param user      �ϥΪ̸��
     * @return
     * @throws ModuleException 
     * @throws SQLException 
     */
    public DTEPC101 insertC101(Map reqMap, UserObject user) throws ModuleException, SQLException {

        ErrorInputException eie = null;
        String RCV_YM = null;
        String PAY_KIND = null;
        String SAL_AMT = null;
        String SUB_CPY_ID = null;
        String FLD_NO = "";
        String ROOM_NO = "";
        String PRK_NO = "";

        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_001"));//��J�ѼƤ��o���ŭ�
        } else {
            RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
            PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
            SAL_AMT = MapUtils.getString(reqMap, "SAL_AMT");
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(RCV_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_002"));//�����~�묰�������
            }
            if (StringUtils.isBlank(PAY_KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_003"));//ú�ں������������
            }
            if (StringUtils.isBlank(SAL_AMT)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_004"));//�������B���������
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_005"));//�ϥΪ̪��󤣱o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }
        String INV_AMT = MapUtils.getString(reqMap, "INV_AMT");
        String TAX_AMT = MapUtils.getString(reqMap, "TAX_AMT", "").replaceAll(",", "");
        reqMap.put("TAX_AMT", TAX_AMT);
        String PAY_S_DATE = MapUtils.getString(reqMap, "PAY_S_DATE");
        String PAY_E_DATE = MapUtils.getString(reqMap, "PAY_E_DATE");

        if (!"4".equals(PAY_KIND)) {
            if (StringUtils.isBlank(PAY_S_DATE) || StringUtils.isBlank(PAY_E_DATE)) {
                throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_011"));//ú�کl��, ú�ڲ״����������
            }
            if (PAY_E_DATE.compareTo(PAY_S_DATE) < 0) {
                throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_012"));//ú�کl���β״���J���~
            }
        }

        reqMap.put("SPR_AMT", MapUtils.getString(reqMap, "INV_AMT"));

        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
        String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
        String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");

        String today = DATE.getDBDate();

        //�P�_�O�_���q�l�o��
        BigDecimal START_YM = STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO);
        boolean isEleInv = (new BigDecimal(RCV_YM).compareTo(START_YM) >= 0);
        log.debug("##### isEleInv::" + isEleInv);

        DataSet ds = Transaction.getDataSet();

        EP_Z0Z001 theEP_Z0Z001 = new EP_Z0Z001();

        //�X�����aOR �H�����L�����N�� OR [20180306]�{�ɰ����� 
        if ("5".equals(PAY_KIND) || ("4".equals(PAY_KIND) && StringUtils.isBlank(CRT_NO)) || "8".equals(PAY_KIND)) {
            //�X�����a OR [20180306]�{�ɰ����� �ˮ�
            if ("5".equals(PAY_KIND) || "8".equals(PAY_KIND)) {
                //�ˮ�REQMAP.CRT_NO, REQMAP.CUS_NO���ť�
                if (StringUtils.isNotBlank(CRT_NO) || StringUtils.isNotBlank(CUS_NO)) {
                    if ("5".equals(PAY_KIND)) {
                        eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_006"));//�X�����a���ο�J�����N��,�Ȥ�Ǹ�
                    } else {
                        eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_029"));//�{�ɰ����줣�ο�J�����N��,�Ȥ�Ǹ�
                    }
                }
            }
            if (StringUtils.isBlank(BLD_CD) || StringUtils.isBlank(MapUtils.getString(reqMap, "CUS_NAME")) || StringUtils.isBlank(MapUtils.getString(reqMap, "TAX_TYPE"))) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_007"));//�j�ӥN��, �Ȥ�W��, �|�O���������
            }
            if (eie != null) {
                throw eie;
            }
            //�t�Φ۰ʲ��ͧǸ�
            CUS_NO = "1";
            reqMap.put("CUS_NO", CUS_NO);
            String CARD_NO = MapUtils.getString(reqMap, "CARD_NO");
            if (StringUtils.isNotBlank(CARD_NO)) {
                CRT_NO = "OZ0000" + CARD_NO;
            } else {
                CRT_NO = "OR" + STRING.fillZero(String.valueOf(theEP_Z0Z001.createNextNumber(SUB_CPY_ID, "004", "C1", "0030")), 8);
            }
            reqMap.put("CRT_NO", CRT_NO);
            reqMap.put("PAY_CD", "0");
            //20200203 : �Y�L�Ȥ��T(�������)�A�o�����Τ覡�w�]��A�ȥ�
            reqMap.put("INV_TRANS_TYPE", "A");

        } else {
            //�ˮ�REQMAP.CRT_NO, REQMAP.CUS_NO���ť�
            if (StringUtils.isBlank(CRT_NO) || StringUtils.isBlank(CUS_NO)) {
                throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_008"));//�����N��,�Ȥ�Ǹ����������
            }
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("CUS_NO", CUS_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);

            Map qryMap = new HashMap();
            qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
            qryMap.put("CRT_NO", CRT_NO);
            qryMap.put("CUS_NO", CUS_NO);
            qryMap.put("QuerySts", "1");
            qryMap.put("QueryDate", today);

            List<Map> B102List;
            try {
                B102List = new EP_B10020().queryList(qryMap);
            } catch (DataNotFoundException dnfe) {
                B102List = null;
                log.debug("B102List�d�L���");
            }

            ds.clear();
            ds.setField("CRT_NO", CRT_NO);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.searchAndRetrieve(ds, SQL_insertC101_002);
            ds.next();
            String CNT = String.valueOf(ds.getField(0));
            if (!(B102List == null || "0".equals(CNT))) {
                reqMap.put("ID", B102List.get(0).get("ID"));
                reqMap.put("CUS_NAME", B102List.get(0).get("CUS_NAME"));
                reqMap.put("PAY_CD", B102List.get(0).get("CUS_STS"));
            }

            //�H�����N��,�Ȥ�Ǹ��dB101,B102���
            Map B101B102Map = queryB101B102Map(CRT_NO, CUS_NO, PAY_KIND, SUB_CPY_ID);
            //20200203:�o�����Τ覡�A�e�����ȡA�N����e�����ȡA�S���A�쫴�����
            if (isEleInv) {
                String INV_TRANS_TYPE = MapUtils.getString(reqMap, "INV_TRANS_TYPE", "A");
                if (StringUtils.isBlank(INV_TRANS_TYPE)) {
                    INV_TRANS_TYPE = MapUtils.getString(B101B102Map, "TRANS_TYPE", "A");
                }
                
                //20200319 �t�ӡG��بS���ʶR�H�eEMAIL���A�ȡA�Gb2b�o���ҥH�ȥ����D
                if("01".equals(SUB_CPY_ID) && "B".equals(INV_TRANS_TYPE)) {
                    INV_TRANS_TYPE = "A";
                }
                
                B101B102Map.put("INV_TRANS_TYPE", INV_TRANS_TYPE);
            } else {
                B101B102Map.put("INV_TRANS_TYPE", "A");
            }
            reqMap.putAll(B101B102Map);

            //���o���Ȥᤧ�ӯ����
            Map queryMap = new HashMap();
            queryMap.put("SUB_CPY_ID", SUB_CPY_ID);
            queryMap.put("CRT_NO", CRT_NO);
            queryMap.put("IS_CHK_TEMP", "N");
            queryMap.put("CUS_NO", CUS_NO);

            Map B101Map = new EP_B10010().queryMap(queryMap);
            String RNT_TYPE = MapUtils.getString(B101Map, "RNT_TYPE");
            List<Map> rentList;
            Map rentMap = new HashMap();
            try {

                if ("3".equals(RNT_TYPE) || "9".equals(RNT_TYPE)) { //�ӯ��O=3���� 9���u����
                    rentList = new EP_B10020().queryCar(queryMap);
                } else {
                    rentList = new EP_B10020().queryRm(queryMap);
                }
                rentMap = rentList.get(0); //���Ĥ@�����
            } catch (DataNotFoundException e) {
                try {
                    //�d�߹w���� ���ǧO�Ψ���
                    queryMap.put("RNT_KD", "3");
                    queryMap.put("BLD_CD", BLD_CD);
                    rentList = new EP_A30040().queryList(queryMap);
                    if (!rentList.isEmpty()) {
                        rentMap = rentList.get(0); //���Ĥ@�����
                    }

                } catch (DataNotFoundException e1) {

                }

            }
            FLD_NO = MapUtils.getString(rentMap, "FLD_NO", "");
            ROOM_NO = MapUtils.getString(rentMap, "ROOM_NO", "");
            PRK_NO = MapUtils.getString(rentMap, "PRK_NO", "");

        }

        //        if ("4".equals(PAY_KIND)) {//�H����
        //            reqMap.put("PAY_S_DATE", today);
        //            reqMap.put("PAY_E_DATE", today);
        //        }

        fmtAMT(reqMap);

        //�d�j�Ӹ��
        if (StringUtils.isNotBlank(BLD_CD)) {
            Map qryMapA = new HashMap();
            qryMapA.put("SUB_CPY_ID", SUB_CPY_ID);
            qryMapA.put("BLD_CD", BLD_CD);
            Map A101 = new EP_A10010().queryMap(qryMapA);

            reqMap.put("BLD_USR_ID", MapUtils.getString(A101, "BLD_USR_ID"));
            reqMap.put("BLD_USR_NAME", MapUtils.getString(A101, "BLD_USR_NAME"));
            reqMap.put("DIV_NO", MapUtils.getString(A101, "CLC_DIV_NO"));

        } else {
            reqMap.put("DIV_NO", user.getDivNo());
        }

        reqMap.put("FLD_NO", FLD_NO);
        reqMap.put("ROOM_NO", ROOM_NO);
        reqMap.put("PRK_NO", PRK_NO);
        if (isDebug) {
            log.debug("@@@INV_AMT=" + INV_AMT);
            log.debug("@@@SAL_AMT=" + SAL_AMT);
            log.debug("@@@TAX_AMT=" + TAX_AMT);
            log.debug("@@@PAY_S_DATE=" + PAY_S_DATE);
            log.debug("@@@PAY_E_DATE=" + PAY_E_DATE);
            log.debug("@@@FLD_NO=" + FLD_NO);
            log.debug("@@@ROOM_NO=" + ROOM_NO);
            log.debug("@@@PRK_NO=" + PRK_NO);
            log.debug("@@@INV_TRANS_TYPE=" + reqMap.get("INV_TRANS_TYPE"));
        }

        //��L�w��
        reqMap.put("EXT_TYPE", "3");
        reqMap.put("RJT_CD", "N");
        reqMap.put("TRN_KIND", "03");
        reqMap.put("EXT_DATE", DATE.getDBDate());
        reqMap.put("LST_PROC_DATE", DATE.getDBTimeStamp());
        reqMap.put("LST_PROC_ID", user.getEmpID());
        reqMap.put("LST_PROC_DIV", user.getDivNo());
        reqMap.put("LST_PROC_NAME", user.getEmpName());
        DTEPC101 DTEPC101_VO = VOTool.mapToVO(DTEPC101.class, reqMap);
        new EP_C1Z001().insertDTEPC101(DTEPC101_VO);
        return DTEPC101_VO;
    }

    /**
     * �B�z���B
     * @param reqMap    �e���ǤJ�����
     * @throws ModuleException 
     */
    private void fmtAMT(Map reqMap) throws ModuleException {
        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");

        String dateRCV_YM = splitYYYYMM(RCV_YM);
        String RCV_S_DT = DATE.getMonthFirstDate(dateRCV_YM);//���Ӧ~��Ĥ@��
        String PRP_S_DATE = DATE.getMonthFirstDate(DATE.addDate(RCV_S_DT, 0, 1, 0));//������1 ��
        String PAY_S_DATE = MapUtils.getString(reqMap, "PAY_S_DATE");
        String PAY_E_DATE = MapUtils.getString(reqMap, "PAY_E_DATE");
        String TAX_TYPE = MapUtils.getString(reqMap, "TAX_TYPE");
        BigDecimal PASS_DAY = new BigDecimal(DATE.diffDay(PAY_S_DATE, PAY_E_DATE) + 1);
        if (DATE.diffDay(PAY_S_DATE, PRP_S_DATE) < 0) {//�Yú�کl��>�w���l��  �h�w���l��=ú�کl��
            PRP_S_DATE = PAY_S_DATE;
        }
        reqMap.put("PRP_S_DATE", PRP_S_DATE);
        reqMap.put("PASS_DAY", PASS_DAY);

        log.fatal(reqMap);
        log.fatal(MapUtils.getString(reqMap, "INV_AMT", "0"));

        BigDecimal SAL_AMT = STRING.objToBigDecimal(MapUtils.getString(reqMap, "SAL_AMT").replaceAll(",", ""), BigDecimal.ZERO);
        BigDecimal INV_AMT = STRING.objToBigDecimal(MapUtils.getString(reqMap, "INV_AMT").replaceAll(",", ""), BigDecimal.ZERO);
        BigDecimal TAX_AMT = STRING.objToBigDecimal(MapUtils.getString(reqMap, "TAX_AMT").replaceAll(",", ""), BigDecimal.ZERO);
        if (isDebug) {
            log.debug("@@@BEFORE........................");
            log.debug("@@@TAX_TYPE=" + TAX_TYPE);
            log.debug("@@@INV_AMT=" + INV_AMT);
            log.debug("@@@SAL_AMT=" + SAL_AMT);
            log.debug("@@@TAX_AMT=" + TAX_AMT);
        }
        String RNT_AMT = new EP_C10010().caculateCurrentAmt(SAL_AMT.toString(), PASS_DAY.toString(), PAY_S_DATE, PAY_E_DATE, STRING.objToStrNoNull(reqMap.get("PRP_S_DATE")));
        reqMap.put("RNT_AMT", new BigDecimal(RNT_AMT));
        BigDecimal PRP_AMT = new BigDecimal(MapUtils.getInteger(reqMap, "SAL_AMT")).subtract(new BigDecimal(MapUtils.getInteger(reqMap, "RNT_AMT")));
        reqMap.put("PRP_AMT", PRP_AMT);
        reqMap.put("PRP_SP_AMT", PRP_AMT);
        String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
        //���s�p��P���B�B�|�B�B�o�����B
        if ("1".equals(TAX_TYPE)) { //���t
            if (!"2".equals(PAY_KIND)) {
                SAL_AMT = INV_AMT.divide(new BigDecimal("1.05"), 0, BigDecimal.ROUND_HALF_UP);
                TAX_AMT = INV_AMT.subtract(SAL_AMT);
            }

        } else if ("2".equals(TAX_TYPE)) { //�~�[
            TAX_AMT = SAL_AMT.multiply(new BigDecimal("0.05")).setScale(0, BigDecimal.ROUND_HALF_UP);
        } else if ("3".equals(TAX_TYPE)) { //�s�|�v�A�K�|
            TAX_AMT = BigDecimal.ZERO;
        }
        INV_AMT = SAL_AMT.add(TAX_AMT);
        if (isDebug) {
            log.debug("@@@AFTER........................");
            log.debug("@@@INV_AMT=" + INV_AMT);
            log.debug("@@@SAL_AMT=" + SAL_AMT);
            log.debug("@@@TAX_AMT=" + TAX_AMT);
        }
        reqMap.put("INV_AMT", INV_AMT);
        reqMap.put("SAL_AMT", SAL_AMT);
        reqMap.put("TAX_AMT", TAX_AMT);
        reqMap.put("SPR_AMT", INV_AMT);

        //
        if ("2".equals(MapUtils.getString(reqMap, "PAY_KIND"))) {
            reqMap.put("TAX_AMT", "0");
            reqMap.put("INV_AMT", "0");
            reqMap.put("RNT_AMT", "0");
            reqMap.put("PRP_AMT", "0");
            reqMap.put("PRP_SP_AMT", "0");
            reqMap.put("SPR_AMT", reqMap.get("SAL_AMT"));
        }

    }

    /**
     * �N�褸�~���ഫ������榡
     * @param yyyymm
     * @return
     */
    private String splitYYYYMM(String yyyymm) {
        StringBuilder sb = new StringBuilder();
        sb.append(yyyymm.substring(0, 4)).append("-");
        sb.append(yyyymm.substring(4, 6)).append("-01");//�w�]�����1
        return sb.toString();
    }

    /**
          * �d�߫���/�Ȥ��� 
     * @param CRT_NO    �����N��
     * @param CUS_NO    �Ȥ�Ǹ�
     * @param PAY_KIND  ú�����O
     * @param user      �ϥΪ̪���
     * @return  rtnMap  ����/�Ȥ���
     * @throws ModuleException 
     */
    private Map queryB101B102Map(String CRT_NO, String CUS_NO, String PAY_KIND, String SUB_CPY_ID) throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(CRT_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_014"));//�����N�����o���ŭ�
        }
        if (StringUtils.isBlank(CUS_NO)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_015"));//�Ȥ�Ǹ����o���ŭ�
        }
        if (StringUtils.isBlank(PAY_KIND)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_016"));//ú�����O���o���ŭ�
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        Map rtnMap = new HashMap();
        //�H�����N��,�Ȥ�Ǹ��dB101,B102���

        Map qryMap = new HashMap();
        qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
        qryMap.put("CRT_NO", CRT_NO);
        qryMap.put("CUS_NO", CUS_NO);

        try {
            Map B102Map = new EP_B10020().queryMap(qryMap);
            rtnMap.put("ID", B102Map.get("ID"));
            rtnMap.put("CUS_NAME", B102Map.get("CUS_NAME"));
            rtnMap.put("PAY_CD", B102Map.get("CUS_STS"));
            //20200203:�o�����Τ覡�F�D�q�l�o���Ҭ�A�ȥ�
            String INV_TRANS_TYPE = MapUtils.getString(B102Map, "INV_TRANS_TYPE", "A");
            rtnMap.put("TRANS_TYPE", (StringUtils.isNotBlank(INV_TRANS_TYPE)) ? INV_TRANS_TYPE : "A");
        } catch (DataNotFoundException dnfe) {
            log.debug("EP_B10020�d�L���");
            rtnMap.put("TRANS_TYPE", "A");//20200203:�L�Ȥ��T�A�o�����Τ覡�w�]��A�ȥ�
        }

        //20191022���D��s�� 20191009-0064 by�E�Ͷv
        //ú�ں������H�����A�u��J�v�Ρu�ק�v�A�p�������l�B���W�h���@�P
        //�P���T�{��A�H�������|�O�Ҭ�"���t"�A�����l�B=�o�����B
        //�Y��H����PAY_KIND = 4 �n�s�ʦ����t �����
        //���B�վ㦨�A�D�H�����A�h���d�j�Ӹ��
        if (!"4".equals(PAY_KIND)) {
            try {
                Map B101Map = new EP_B10010().queryMap(qryMap);
                rtnMap.put("BLD_CD", B101Map.get("BLD_CD"));
                rtnMap.put("TAX_TYPE", B101Map.get("TAX_TYPE"));
            } catch (DataNotFoundException dnfe) {
                log.debug("B101Map�d�L���");
            }
        }

        return rtnMap;
    }

    /**
     * ��s�������
     * @param reqMap    �e���ǤJ�����
     * @param user      �ϥΪ̸��
     * @throws SQLException 
     * @throws ModuleException 
     */
    public void updateC101(Map reqMap, UserObject user) throws ModuleException, SQLException {
        ErrorInputException eie = null;
        String RCV_NO = null;
        String RCV_YM = null;
        String PAY_KIND = null;
        String PAY_S_DATE = null;
        String PAY_E_DATE = null;
        String CRT_NO = null;
        String CUS_NO = null;
        String ID = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_001"));//��J�ѼƤ��o���ŭ�
        } else {
            RCV_NO = MapUtils.getString(reqMap, "RCV_NO");
            RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
            PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
            PAY_S_DATE = MapUtils.getString(reqMap, "PAY_S_DATE");
            PAY_E_DATE = MapUtils.getString(reqMap, "PAY_E_DATE");
            CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
            CUS_NO = MapUtils.getString(reqMap, "CUS_NO");
            ID = MapUtils.getString(reqMap, "ID");
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(RCV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_017"));//�����s�����������
            }
            if (StringUtils.isBlank(RCV_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_002"));//�����~�묰�������
            }
            if (StringUtils.isBlank(PAY_KIND)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_003"));//ú�ں������������
            }
            if (StringUtils.isBlank(PAY_S_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_018"));//ú�کl�����������
            }
            if (StringUtils.isBlank(PAY_E_DATE)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_019"));//ú�ڲ״����������
            }
            if (StringUtils.isBlank(CRT_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_020"));//�����N�����������
            }
            if (StringUtils.isBlank(CUS_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_021"));//�Ǹ����������
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
            if (!"5".equals(PAY_KIND) && !"8".equals(PAY_KIND)) {//�X�����a
                if (StringUtils.isBlank(ID)) {
                    eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_028"));//�Τ@�s�����������
                }
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_005"));//�ϥΪ̪��󤣱o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        Map C101Map_DB = VOTool.findOneToMap(ds, SQL_updateC101_001, false);

        if (C101Map_DB == null || C101Map_DB.isEmpty()) {
            throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_022"));//�d�L��ƥi�ק�
        }

        String C101_PAY_KIND = MapUtils.getString(C101Map_DB, "PAY_KIND");

        if (!RCV_YM.equals(MapUtils.getString(C101Map_DB, "RCV_YM")) || !PAY_KIND.equals(C101_PAY_KIND) || !PAY_S_DATE.equals(MapUtils.getString(C101Map_DB, "PAY_S_DATE")) || !PAY_E_DATE.equals(MapUtils.getString(C101Map_DB, "PAY_E_DATE"))
                || !CRT_NO.equals(MapUtils.getString(C101Map_DB, "CRT_NO")) || !CUS_NO.equals(MapUtils.getString(C101Map_DB, "CUS_NO"))) {
            throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_023"));//�����~��/ú�ں���/ú�کl��/ú�ڲ״�/�����N��/�Ǹ� ���i����
        }

        if ("1".equals(C101_PAY_KIND) && !"3".equals(MapUtils.getString(C101Map_DB, "EXT_TYPE"))) {
            throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_024"));//ú�ں����� �����B�D���H�u��J,���i�ץ�!
        }
        if (StringUtils.isNotBlank(MapUtils.getString(C101Map_DB, "INV_NO")) || StringUtils.isNotBlank(MapUtils.getString(C101Map_DB, "ACNT_DATE"))) {
            throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_025"));//��Ƥw�T�{���i�ץ�
        }

        //�P�_�O�_���q�l�o��
        BigDecimal START_YM = STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO);
        boolean isEleInv = (new BigDecimal(RCV_YM).compareTo(START_YM) >= 0);
        log.debug("##### isEleInv::" + isEleInv);

        fmtAMT(reqMap);//��ú�ں���, ���, �B�z�U���B���
        String today = DATE.getDBTimeStamp();
        String user_id = user.getEmpID();
        String user_div = user.getDivNo();
        String user_name = user.getEmpName();

        if ("4".equals(C101_PAY_KIND)) {//�H����
            C101Map_DB.put("SAL_AMT", MapUtils.getString(reqMap, "SAL_AMT").replaceAll(",", ""));
            C101Map_DB.put("TAX_AMT", MapUtils.getString(reqMap, "TAX_AMT").replaceAll(",", ""));
            C101Map_DB.put("INV_AMT", MapUtils.getString(reqMap, "INV_AMT").replaceAll(",", ""));
            //20191022���D��s�� 20191009-0064 by�E�Ͷv
            //ú�ں������H�����A�u��J�v�Ρu�ק�v�A�p�������l�B���W�h���@�P
            //�P���T�{��A�H�������|�O�Ҭ�"���t"�A�����l�B=�o�����B
            //�H����SPR_AMT (�����l�B) �n= INV_AMT (�o�����B)
            C101Map_DB.put("SPR_AMT", MapUtils.getString(reqMap, "INV_AMT").replaceAll(",", ""));
            C101Map_DB.put("RNT_AMT", MapUtils.getString(reqMap, "RNT_AMT").replaceAll(",", ""));
            C101Map_DB.put("TRN_KIND", "0A"); //�ץ�
            C101Map_DB.put("RCV_NO", RCV_NO);
            C101Map_DB.put("PROC_DATE", today);
            C101Map_DB.put("PROC_ID", user_id);
            C101Map_DB.put("PROC_DIV", user_div);
            C101Map_DB.put("PROC_NAME", user_name);

            //20200203:�o�����Τ覡�F�D�q�l�o���Ҭ�A�ȥ�
            String INV_TRANS_TYPE = MapUtils.getString(reqMap, "INV_TRANS_TYPE", "A");
            C101Map_DB.put("INV_TRANS_TYPE", (isEleInv && StringUtils.isNotBlank(INV_TRANS_TYPE)) ? INV_TRANS_TYPE : "A");

        } else {
            String BLD_CD = MapUtils.getString(reqMap, "BLD_CD");
            Map B101B102Map = queryB101B102Map(CRT_NO, CUS_NO, PAY_KIND, SUB_CPY_ID);
            //20200203:�o�����Τ覡�A�e�����ȡA�N����e�����ȡA�S���A�쫴�����
            if (isEleInv) {
                String INV_TRANS_TYPE = MapUtils.getString(reqMap, "INV_TRANS_TYPE", "A");
                if (StringUtils.isBlank(INV_TRANS_TYPE)) {
                    INV_TRANS_TYPE = MapUtils.getString(B101B102Map, "TRANS_TYPE", "A");
                }
                
                //20200319 �t�ӡG��بS���ʶR�H�eEMAIL���A�ȡA�Gb2b�o���ҥH�ȥ����D
                if("01".equals(SUB_CPY_ID) && "B".equals(INV_TRANS_TYPE)) {
                    INV_TRANS_TYPE = "A";
                }
                
                B101B102Map.put("INV_TRANS_TYPE", INV_TRANS_TYPE);
            } else {
                B101B102Map.put("INV_TRANS_TYPE", "A");
            }
            reqMap.putAll(B101B102Map);

            //�d�j�Ӹ��
            Map qryMap = new HashMap();
            qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
            qryMap.put("BLD_CD", BLD_CD);
            Map A101 = new EP_A10010().queryMap(qryMap);
            String BLD_USR_ID = MapUtils.getString(A101, "BLD_USR_ID");
            String BLD_USR_NAME = MapUtils.getString(A101, "BLD_USR_NAME");
            reqMap.put("BLD_USR_ID", BLD_USR_ID);
            reqMap.put("BLD_USR_NAME", BLD_USR_NAME);

            C101Map_DB.put("BLD_CD", BLD_CD);
            C101Map_DB.put("ID", ID);
            C101Map_DB.put("CUS_NAME", MapUtils.getString(reqMap, "CUS_NAME"));
            C101Map_DB.put("BLD_NAME", MapUtils.getString(reqMap, "BLD_NAME"));
            C101Map_DB.put("BLD_USR_NAME", BLD_USR_NAME);
            C101Map_DB.put("BLD_USR_ID", BLD_USR_ID);
            C101Map_DB.put("DIV_NO", MapUtils.getString(reqMap, "DIV_NO"));
            C101Map_DB.put("INV_AMT", MapUtils.getString(reqMap, "INV_AMT"));
            C101Map_DB.put("SAL_AMT", MapUtils.getString(reqMap, "SAL_AMT"));
            C101Map_DB.put("TAX_AMT", MapUtils.getString(reqMap, "TAX_AMT").replaceAll(",", ""));
            C101Map_DB.put("TAX_TYPE", MapUtils.getString(reqMap, "TAX_TYPE"));
            C101Map_DB.put("SPR_AMT", MapUtils.getString(reqMap, "SPR_AMT"));
            C101Map_DB.put("RNT_AMT", MapUtils.getString(reqMap, "RNT_AMT"));
            C101Map_DB.put("PRP_AMT", MapUtils.getString(reqMap, "PRP_AMT"));
            C101Map_DB.put("PRP_SP_AMT", MapUtils.getString(reqMap, "PRP_SP_AMT"));
            C101Map_DB.put("RCV_NO", RCV_NO);
            C101Map_DB.put("TRN_KIND", "0A"); //�ץ�
            C101Map_DB.put("PROC_DATE", today);
            C101Map_DB.put("PROC_ID", user_id);
            C101Map_DB.put("PROC_DIV", user_div);
            C101Map_DB.put("PROC_NAME", user_name);
            C101Map_DB.put("INV_TRANS_TYPE", MapUtils.getString(reqMap, "INV_TRANS_TYPE"));//20200203:�o����Τ覡
        }
        new EP_C1Z001().updateDTEPC101(VOTool.mapToVO(DTEPC101.class, C101Map_DB));

    }

    /**
     * �R���������
     * @param reqMap    �e���ǤJ�����
     * @param user      �ϥΪ̸��
     * @throws ModuleException
     */
    public void deleteC101(Map reqMap, UserObject user) throws ModuleException {
        ErrorInputException eie = null;
        String RCV_NO = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_001"));//��J�ѼƤ��o���ŭ�
        } else {
            RCV_NO = MapUtils.getString(reqMap, "RCV_NO");
            if (StringUtils.isBlank(RCV_NO)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_017"));//�����s�����������
            }
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_005"));//�ϥΪ̪��󤣱o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_NO", RCV_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        Map C101Map_DB;
        try {
            C101Map_DB = VOTool.findOneToMap(ds, SQL_deleteC101_001);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_026"));//�d�L��ƥi�R��
        }

        //20180126 �]�q�l�o���X�b��~�|���o�����X,�W�[�P�_���A�w�T�{�N���i�H�R��
        if (!"0".equals(MapUtils.getString(C101Map_DB, "OP_STATUS")) || StringUtils.isNotBlank(MapUtils.getString(C101Map_DB, "INV_NO")) || StringUtils.isNotBlank(MapUtils.getString(C101Map_DB, "ACNT_DATE"))) {
            throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_027"));//��Ƥw�T�{���i�R��
        }

        //160216 modified by i9301216:�]����������ݽT�{,�ˮ������l�B�O�_������
        if ("2".equals(MapUtils.getString(C101Map_DB, "PAY_KIND"))) {//���
            if (STRING.objToBigDecimal(C101Map_DB.get("SPR_AMT"), BigDecimal.ZERO).compareTo(STRING.objToBigDecimal(C101Map_DB.get("SAL_AMT"), BigDecimal.ZERO).add(STRING.objToBigDecimal(C101Map_DB.get("TAX_AMT"), BigDecimal.ZERO))) != 0) {
                throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_029"));//����wú�ڤ��i�R��(�����l�B!=�������B(�P���B)+�|�B)
            }
        }

        new EP_C1Z001().deleteDTEPC101(VOTool.mapToVO(DTEPC101.class, C101Map_DB));

    }

    /**
     * �s�W�ˮ�
     * @param reqMap    �e���ǤJ�����
     * @param user      �ϥΪ̸��
     * @return CHKFLAG  �O�_��ܽT�{����
     * @throws ModuleException 
     */
    public boolean chkInsertC101(Map reqMap, UserObject user) throws ModuleException {

        ErrorInputException eie = null;
        String RCV_YM = null;
        String SUB_CPY_ID = null;
        if (reqMap == null || reqMap.isEmpty()) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_001"));//��J�ѼƤ��o���ŭ�
        } else {
            RCV_YM = MapUtils.getString(reqMap, "RCV_YM");

            if (StringUtils.isBlank(RCV_YM)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_002"));//�����~�묰�������
            }
            SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            if (StringUtils.isBlank(SUB_CPY_ID)) {
                eie = getErrorInputException(eie, MessageUtil.getMessage("MEP00020"));//�����q�O���o���ŭ�
            }
        }
        if (user == null) {
            eie = getErrorInputException(eie, MessageUtil.getMessage("EP_C10030_MSG_005"));//�ϥΪ̪��󤣱o���ŭ�
        }
        if (eie != null) {
            throw eie;
        }

        String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");

        Map qryMap = new HashMap();
        qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
        qryMap.put("CRT_NO", CRT_NO);
        qryMap.put("CUS_NO", reqMap.get("CUS_NO"));
        //qryMap.put("QueryDate", DATE.getDBDate());

        try {
            new EP_B10020().queryList(qryMap);
        } catch (DataNotFoundException dnfe) {
            throw new ModuleException(MessageUtil.getMessage("EP_C10030_MSG_009"));//�ϥΪ̪��󤣱o���ŭ�
        }

        qryMap = new HashMap();
        qryMap.put("SUB_CPY_ID", SUB_CPY_ID);
        qryMap.put("CRT_NO", CRT_NO);
        qryMap.put("CUS_NO", reqMap.get("CUS_NO"));
        qryMap.put("QuerySts", "1");
        //qryMap.put("QueryDate", DATE.getDBDate());

        try {
            new EP_B10020().queryList(qryMap);
        } catch (DataNotFoundException dnfe) {
            log.debug("B102List�d�L���");
            return true;
        }
        DataSet ds = Transaction.getDataSet();
        ds.setField("CRT_NO", CRT_NO);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);

        DBUtil.searchAndRetrieve(ds, SQL_chkInsertC101_001);
        ds.next();
        String CNT = String.valueOf(ds.getField("tempCNT"));
        if ("0".equals(CNT)) {
            return true;
        }
        return false;
    }

    /**
     * ���o�j�ӦW��
     * @param BLD_CD
     * @return
     * @throws ModuleException
     * @throws SQLException 
     */
    public String getBLD_NAME(String BLD_CD, String SUB_CPY_ID) throws ModuleException, SQLException {
        //        DataSet ds = Transaction.getDataSet();
        //        ds.setField("BLD_CD", BLD_CD);
        //        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        //        DBUtil.searchAndRetrieve(ds, SQL_getBLD_NAME_001);
        //        
        //        ds.next();
        //    	return (String) ds.getField("BLD_NAME");
        Map reqMap = new HashMap();
        reqMap.put("BLD_CD", BLD_CD);
        reqMap.put("SUB_CPY_ID", SUB_CPY_ID);
        return MapUtils.getString(new EP_A10010().queryMap(reqMap), "BLD_NAME");
    }

    /**
     * ��wEIE����
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(errMsg);
        return eie;
    }
}
