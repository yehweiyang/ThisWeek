package com.cathay.ep.c1.module;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.rpt.RptUtils;
import com.cathay.rpt.XlsUtils;
import com.cathay.rpt.XlsUtils.SORT_RULE;
import com.cathay.rpt.datasource.xls.ColumnOptions;
import com.cathay.rpt.datasource.xls.ColumnSetting;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date     Version Description     Author 
 * 2013/8/5     1.0         �s�W    �\�a�s
 * 
 * �@�B �{���\�෧�n�����G 
 * �{���\�� �j�Ӧ����v�Ҳ� 
 * �{���W�� EP_C14020 
 * ���n���� �qDTEPC101_������,DTEPA101_�j�Ӱ򥻸����, DTEPC103_�޲z�O���u�������, DTEPC306_ú�ڬ����ɾ�X�d�߸��
 * 
 * [20180308] �ק��
 * ���:����10,20,30��
 * 
 * @author ����[
 * @since 2014-01-10
 */
@SuppressWarnings("unchecked")
public class EP_C14020 {
    //private static final Logger log = Logger.getLogger(EP_C14020.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.c1.module.EP_C14020.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.c1.module.EP_C14020.SQL_queryList_002";

    private static final String SQL_queryList_003 = "com.cathay.ep.c1.module.EP_C14020.SQL_queryList_003";

    private static final String SQL_queryPAYAMT_001 = "com.cathay.ep.c1.module.EP_C14020.SQL_queryPAYAMT_001";

    private static final String SQL_queryForRpt1_001 = "com.cathay.ep.c1.module.EP_C14020.SQL_queryForRpt1_001";

    private static final String SQL_queryForRpt2_001 = "com.cathay.ep.c1.module.EP_C14020.SQL_queryForRpt2_001";

    private static final String SQL_queryPAYAMT_NEW_001 = "com.cathay.ep.c1.module.EP_C14020.SQL_queryPAYAMT_NEW_001";

    /**�C�L�w����b���Ӫ��A�@������*/
    private static final int prtRpt1PageSize = 30;

    private static final String SQL_queryForRpt1_002 = "com.cathay.ep.c1.module.EP_C14020.SQL_queryForRpt1_002";

    /**
     * �d�ߦ����v���
     * 
     * @param RCV_YM �����~��(�褸�~��)
     * @param DIV_NO �ӿ��O
     * @param SORT_TYPE �ƧǱ���(A:�����v/B:�j�өʽ�)
     * @param GROUP_TYPE ���s�W�h (A:�C10��,B:����)
     * @param SUB_CPY_ID �����q�O
     * @return rtnList �����v���List
     * @throws ModuleException
     * @throws ParseException
     * @throws DBException 
     */
    public List<Map> queryList(BigDecimal RCV_YM, String DIV_NO, String SORT_TYPE, String GROUP_TYPE, String SUB_CPY_ID)
            throws ModuleException, ParseException, DBException {
        if (RCV_YM == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C14020_MSG_002"));// �����~�묰�������
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("MEP00020"));// �����q�O���o���ŭ�
        }
        // ���d�ӿ��O�U���j�Ӹ��
        DataSet ds = Transaction.getDataSet();
        if (StringUtils.isNotEmpty(DIV_NO)) {
            ds.setField("DIV_NO", DIV_NO);
        }
        if (StringUtils.isNotEmpty(SUB_CPY_ID)) {
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        }

        DBUtil.searchAndRetrieve(ds, SQL_queryList_001);
        List<Map> rtnList = new ArrayList<Map>();
        StringBuilder sb = new StringBuilder();
        String RCV_YM_date = DATE.toDateFormat(sb.append(RCV_YM).append("01").toString(), "yyyyMMdd", "yyyy-MM-dd");
        sb.setLength(0);
        String FEE_RCV_YM = DATE.toDateFormat(DATE.addDate(RCV_YM_date, 0, -1, 0), "yyyy-MM-dd", "yyyyMM");//���W�Ӥ�
        List<String> BLD_CDs = new ArrayList<String>();
        while (ds.next()) {
            Map tempMap = VOTool.dataSetToMap(ds);
            tempMap.put("RCV_YM", RCV_YM);
            tempMap.put("BLD_KD_1_NAME", FieldOptionList.getName("EPC", "BLD_KD_1", MapUtils.getString(tempMap, "BLD_KD_1")));// �j�өʽ褤��
            BLD_CDs.add(MapUtils.getString(tempMap, "BLD_CD"));
            tempMap.put("FEE_RCV_YM", FEE_RCV_YM);
            rtnList.add(tempMap);
        }

        //��l�Ѽ�
        Date date10 = Date.valueOf(DATE.toDateFormat((RCV_YM.toPlainString() + "11"), "yyyyMMdd", "yyyy-MM-dd"));
        Date date20 = Date.valueOf(DATE.toDateFormat((RCV_YM.toPlainString() + "21"), "yyyyMMdd", "yyyy-MM-dd"));
        Date date30 = Date.valueOf(DATE.toDateFormat((RCV_YM.add(BigDecimal.ONE).toPlainString() + "01"), "yyyyMMdd", "yyyy-MM-dd"));
        //rVsMap �j�ӥN�����������B���
        //rVsMap  KEY : �j�ӥN��  
        /*rVsMap  VALUE : 
        If(��A��== GROUP_TYPE)
            Map {RVRT1 = 10���������� ,RVMG1 = 10�������޲z�O ,RVRT2 = 20���������� ,RVMG2 = 20�������޲z�O ,RVRT3 = 30���������� ,RVMG3 = 30�������޲z�O ,PYRT1 = 10�鯲��, PYRT2 = 20�鯲��, PYRT3 = 30�鯲�� , PYMG1 = 10��޲z�O, PYMG1 = 20��޲z�O, PYMG1 = 30��޲z�O}
        Else //�����s�����Ѹ��
            Map {RVRT =�������� ,RVMG =�����޲z�O ,PYRT =����, PYMG =�޲z�O}
        End if
        */
        Map<String, Map<String, BigDecimal>> rVsMap = new HashMap<String, Map<String, BigDecimal>>();

        //���o �j��  RVRT:��������
        BatchQueryDataSet bqds = null;
        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            bqds.setField("RCV_YM", RCV_YM);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            bqds.setFieldValues("BLD_CDs", BLD_CDs);
            bqds.searchAndRetrieve(SQL_queryList_002);

            int groupCount = 2000;//�C�妸�d��2000�����
            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��
            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map INV_AMTMap = VOTool.dataSetToMap(bqds);

                    String BLD_CD = MapUtils.getString(INV_AMTMap, "BLD_CD");
                    BigDecimal INV_AMT = getBigDecimal(bqds.getField("INV_AMT"), BigDecimal.ZERO);
                    String EXT_DATE_str = ObjectUtils.toString(bqds.getField("EXT_DATE"), null);
                    Date EXT_DATE = null;
                    if (EXT_DATE_str != null) {
                        EXT_DATE = Date.valueOf(EXT_DATE_str);
                    }
                    Map<String, BigDecimal> map;
                    if (rVsMap.containsKey(BLD_CD)) {
                        map = (Map<String, BigDecimal>) rVsMap.get(BLD_CD);
                        //[20180308] �[���s�P�_ 
                        if ("A".equals(GROUP_TYPE)) {
                            if (EXT_DATE == null || EXT_DATE.compareTo(date10) < 0) {
                                map.put("RVRT1", getBigDecimal(map.get("RVRT1"), BigDecimal.ZERO).add(INV_AMT));
                                map.put("RVRT2", getBigDecimal(map.get("RVRT2"), BigDecimal.ZERO).add(INV_AMT));
                            } else if (EXT_DATE.compareTo(date20) < 0) {
                                map.put("RVRT2", getBigDecimal(map.get("RVRT2"), BigDecimal.ZERO).add(INV_AMT));
                            }
                            map.put("RVRT3", getBigDecimal(map.get("RVRT3"), BigDecimal.ZERO).add(INV_AMT));
                        } else {
                            map.put("RVRT", getBigDecimal(map.get("RVRT"), BigDecimal.ZERO).add(INV_AMT));
                        }
                        rVsMap.put(BLD_CD, map);
                    } else {
                        map = new HashMap<String, BigDecimal>();
                        //[20180308] �[���s�P�_ 
                        if ("A".equals(GROUP_TYPE)) {
                            if (EXT_DATE == null || EXT_DATE.compareTo(date10) < 0) {
                                map.put("RVRT1", INV_AMT);
                                map.put("RVRT2", INV_AMT);
                            } else if (EXT_DATE.compareTo(date20) < 0) {
                                map.put("RVRT2", INV_AMT);
                            }
                            map.put("RVRT3", INV_AMT);
                        } else {
                            map.put("RVRT", INV_AMT);
                        }
                        rVsMap.put(BLD_CD, map);
                    }
                }
            }
        } finally {
            if (bqds != null) {
                bqds.close();//�����妸�d�߳s�u
            }
        }

        //���o �j��  RVMG:�����޲z�O
        try {
            bqds = Transaction.getBatchQueryDataSet();//���o�妸�s�u
            bqds.setField("FEE_RCV_YM", FEE_RCV_YM);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            bqds.setFieldValues("BLD_CDs", BLD_CDs);
            bqds.searchAndRetrieve(SQL_queryList_003);
            int groupCount = 2000;//�C�妸�d��2000�����
            int totalcount = bqds.getTotalCount(); //�d�߸���`����
            int tmpCount = totalcount % groupCount;//�P�_�̫�@��O�_�㰣2000��
            int group = (totalcount / groupCount) + (tmpCount > 0 ? 1 : 0);//�`�@��group��d��
            for (int i = 0; i < group; i++) {

                int beginIdx = i * groupCount + 1;//�C���d�߰_�l����
                int endIdx = (i + 1) * groupCount + 1;//�C���d�̫߳ᵧ��

                if (endIdx > totalcount) {
                    endIdx = totalcount + 1; // �קK�W�L�̤j��
                }

                bqds.fetchData(beginIdx, endIdx);

                while (bqds.next()) {
                    Map INV_AMTMap = VOTool.dataSetToMap(bqds);
                    String BLD_CD = MapUtils.getString(INV_AMTMap, "BLD_CD");
                    BigDecimal RCV_AMT = getBigDecimal(bqds.getField("RCV_AMT"), BigDecimal.ZERO);
                    Map<String, BigDecimal> map;
                    if (rVsMap.containsKey(BLD_CD)) {
                        map = (Map<String, BigDecimal>) rVsMap.get(BLD_CD);
                        //[20180308] �[���s�P�_ 
                        if ("A".equals(GROUP_TYPE)) {
                            map.put("RVMG1", getBigDecimal(map.get("RVMG1"), BigDecimal.ZERO).add(RCV_AMT));
                            map.put("RVMG2", getBigDecimal(map.get("RVMG2"), BigDecimal.ZERO).add(RCV_AMT));
                            map.put("RVMG3", getBigDecimal(map.get("RVMG3"), BigDecimal.ZERO).add(RCV_AMT));
                        } else {
                            map.put("RVMG", getBigDecimal(map.get("RVMG"), BigDecimal.ZERO).add(RCV_AMT));
                        }
                        rVsMap.put(BLD_CD, map);
                    } else {
                        map = new HashMap<String, BigDecimal>();
                        //[20180308] �[���s�P�_ 
                        if ("A".equals(GROUP_TYPE)) {
                            map.put("RVMG1", RCV_AMT);
                            map.put("RVMG2", RCV_AMT);
                            map.put("RVMG3", RCV_AMT);
                        } else {
                            map.put("RVMG", RCV_AMT);
                        }
                        rVsMap.put(BLD_CD, map);
                    }
                }
            }
        } finally {
            if (bqds != null) {
                bqds.close();//�����妸�d�߳s�u
            }
        }

        if (rVsMap.isEmpty()) {
            throw new DataNotFoundException("�d�L���");
        }

        // �A�[�J�����v���

        //�p��10��,20��,30��
        this.queryPAYAMT_NEW(RCV_YM, BLD_CDs, date10, date20, date30, rVsMap, FEE_RCV_YM, SUB_CPY_ID, GROUP_TYPE);
        //�^�Ǫ����
        List<Map> newRtnList = new ArrayList<Map>();
        BigDecimal hun = new BigDecimal("100");
        for (Map rtnMap : rtnList) {
            String BLD_CD = MapUtils.getString(rtnMap, "BLD_CD");
            //�ھڤj�ӥN����X���� �����
            Map<String, BigDecimal> map = (Map<String, BigDecimal>) rVsMap.get(BLD_CD);

            //�Y �j�� �b��Ƥ��A�L�۹��������ڸ�ơA���Ÿ��
            if (map == null) {
                map = new HashMap();
            }
            //[20180308] �[���s�P�_ 
            if ("A".equals(GROUP_TYPE)) {
                //�զX�^�Ǹ��( �N�@���j�ӥN���3�� ���O�O 10��20��30�� �����)
                Map temp10 = new HashMap();//10����
                Map temp20 = new HashMap();//20����
                Map temp30 = new HashMap();//30����
                temp10.put("date", "10");
                temp20.put("date", "20");
                temp30.put("date", "30");
                temp10.putAll(rtnMap);
                temp20.putAll(rtnMap);
                temp30.putAll(rtnMap);

                BigDecimal RVRT1 = getBigDecimal(map.get("RVRT1"), BigDecimal.ZERO);
                BigDecimal RVMG1 = getBigDecimal(map.get("RVMG1"), BigDecimal.ZERO);
                BigDecimal RVRT2 = getBigDecimal(map.get("RVRT2"), BigDecimal.ZERO);
                BigDecimal RVMG2 = getBigDecimal(map.get("RVMG2"), BigDecimal.ZERO);
                BigDecimal RVRT3 = getBigDecimal(map.get("RVRT3"), BigDecimal.ZERO);
                BigDecimal RVMG3 = getBigDecimal(map.get("RVMG3"), BigDecimal.ZERO);
                BigDecimal RCVRT1 = BigDecimal.ZERO;// �����v(%)  (�ƧǨϥ�)
                BigDecimal RCVRT2 = BigDecimal.ZERO;// �����v(%)  (�ƧǨϥ�)
                BigDecimal RCVRT3 = BigDecimal.ZERO;// �����v(%)  (�ƧǨϥ�)
                BigDecimal RVRT_RVMG1 = RVRT1.add(RVMG1);//������
                BigDecimal RVRT_RVMG2 = RVRT2.add(RVMG2);//������
                BigDecimal RVRT_RVMG3 = RVRT3.add(RVMG3);//������

                if (BigDecimal.ZERO.compareTo(RVRT_RVMG1) == 0) {
                    //������ 0 ���p
                    temp10.putAll(map);
                    temp10.put("RVRT", BigDecimal.ZERO);
                    temp10.put("RVMG", BigDecimal.ZERO);
                    temp10.put("PYRT", BigDecimal.ZERO);
                    temp10.put("PYMG", BigDecimal.ZERO);
                    temp10.put("RCVRT", BigDecimal.ZERO);
                } else {
                    temp10.putAll(map);
                    //�����v(%)�p���I���G���,�|�ˤ��J
                    //(PAY_AMT_10_A + PAY_AMT_10_B)/(RVRT+RVMG)*100
                    BigDecimal PYRT1 = getBigDecimal(map.get("PYRT1"), BigDecimal.ZERO);
                    BigDecimal PYMG1 = getBigDecimal(map.get("PYMG1"), BigDecimal.ZERO);
                    //  BigDecimal RCVRT1Param = PAY_AMT_10_A.add(PAY_AMT_10_B);
                    BigDecimal RCVRT1Param = PYRT1.add(PYMG1);
                    temp10.put("RCVRT1", RCVRT1Param.divide(RVRT_RVMG1, 4, BigDecimal.ROUND_HALF_UP).multiply(hun));// 10 �� �����v(%)

                    RCVRT1 = RCVRT1Param.divide(RVRT_RVMG1, 4, BigDecimal.ROUND_HALF_UP).multiply(hun);// 30 �� �����v(%)

                    temp10.put("RVRT", RVRT1);// 10����������
                    temp10.put("RVMG", RVMG1);// 10�������޲z�O
                    temp10.put("PYRT", PYRT1);// 10��w�P����
                    temp10.put("PYMG", PYMG1);// 10��w�P�޲z�O
                    temp10.put("RCVRT", RCVRT1);// �����v(%)  (�ƧǨϥ�)
                }

                if (BigDecimal.ZERO.compareTo(RVRT_RVMG2) == 0) {
                    //������ 0 ���p
                    temp20.putAll(map);
                    temp20.put("RVRT", BigDecimal.ZERO);
                    temp20.put("RVMG", BigDecimal.ZERO);
                    temp20.put("PYRT", BigDecimal.ZERO);
                    temp20.put("PYMG", BigDecimal.ZERO);
                    temp20.put("RCVRT", BigDecimal.ZERO);
                } else {
                    temp20.putAll(map);
                    //�����v(%)�p���I���G���,�|�ˤ��J
                    //(PAY_AMT_10_A + PAY_AMT_10_B)/(RVRT+RVMG)*100
                    BigDecimal PYRT2 = getBigDecimal(map.get("PYRT2"), BigDecimal.ZERO);
                    BigDecimal PYMG2 = getBigDecimal(map.get("PYMG2"), BigDecimal.ZERO);
                    //  BigDecimal RCVRT1Param = PAY_AMT_10_A.add(PAY_AMT_10_B);
                    BigDecimal RCVRT2Param = PYRT2.add(PYMG2);
                    temp20.put("RCVRT2", RCVRT2Param.divide(RVRT_RVMG2, 4, BigDecimal.ROUND_HALF_UP).multiply(hun));// 10 �� �����v(%)

                    RCVRT2 = RCVRT2Param.divide(RVRT_RVMG2, 4, BigDecimal.ROUND_HALF_UP).multiply(hun);// 30 �� �����v(%)

                    temp20.put("RVRT", RVRT2);// 10����������
                    temp20.put("RVMG", RVMG2);// 10�������޲z�O
                    temp20.put("PYRT", PYRT2);// 10��w�P����
                    temp20.put("PYMG", PYMG2);// 10��w�P�޲z�O
                    temp20.put("RCVRT", RCVRT2);// �����v(%)  (�ƧǨϥ�)
                }

                if (BigDecimal.ZERO.compareTo(RVRT_RVMG3) == 0) {
                    //������ 0 ���p
                    temp30.putAll(map);
                    temp30.put("RVRT", BigDecimal.ZERO);
                    temp30.put("RVMG", BigDecimal.ZERO);
                    temp30.put("PYRT", BigDecimal.ZERO);
                    temp30.put("PYMG", BigDecimal.ZERO);
                    temp30.put("RCVRT", BigDecimal.ZERO);
                } else {

                    temp30.putAll(map);

                    //�����v(%)�p���I���G���,�|�ˤ��J
                    //(PAY_AMT_30_A + PAY_AMT_30_B)/(RVRT+RVMG)*100
                    BigDecimal PYRT3 = getBigDecimal(map.get("PYRT3"), BigDecimal.ZERO);
                    BigDecimal PYMG3 = getBigDecimal(map.get("PYMG3"), BigDecimal.ZERO);
                    //BigDecimal RCVRT3Param = PAY_AMT_30_A.add(PAY_AMT_30_B);
                    BigDecimal RCVRT3Param = PYRT3.add(PYMG3);
                    RCVRT3 = RCVRT3Param.divide(RVRT_RVMG3, 4, BigDecimal.ROUND_HALF_UP).multiply(hun);// 30 �� �����v(%)
                    temp30.put("RCVRT", RCVRT3); //30�� �����v(%)

                    temp30.put("RVRT", RVRT3);// 30����������
                    temp30.put("RVMG", RVMG3);// 30�������޲z�O
                    temp30.put("PYRT", PYRT3);// 30��w�P����
                    temp30.put("PYMG", PYMG3); // 30��w�P�޲z�O

                    temp10.put("RCVRT3", RCVRT3);// �����v(%)  (�ƧǨϥ�)
                    temp20.put("RCVRT3", RCVRT3);// �����v(%)  (�ƧǨϥ�)
                    temp30.put("RCVRT3", RCVRT3);// �����v(%) (�ƧǨϥ�)

                }
                //�N��ƥ[�J�^��list (newRtnList)
                newRtnList.add(temp10); // 10��
                newRtnList.add(temp20); // 20��
                newRtnList.add(temp30); // 30��
            } else {
                //[20180308]���s�P�_else 
                Map temp = new HashMap();//���
                temp.put("date", DATE.today());
                temp.putAll(rtnMap);

                BigDecimal RVRT = getBigDecimal(map.get("RVRT"), BigDecimal.ZERO);
                BigDecimal RVMG = getBigDecimal(map.get("RVMG"), BigDecimal.ZERO);
                BigDecimal PYRT = getBigDecimal(map.get("PYRT"), BigDecimal.ZERO);
                BigDecimal PYMG = getBigDecimal(map.get("PYMG"), BigDecimal.ZERO);

                BigDecimal RCVRT = BigDecimal.ZERO;// �����v(%) 
                BigDecimal RRCVRT = BigDecimal.ZERO;// ���������v(%)
                BigDecimal RVRT_RVMG = RVRT.add(RVMG);//������+�޲z�O

                if (BigDecimal.ZERO.compareTo(RVRT_RVMG) == 0) { //������ 0 ���p
                    temp.putAll(map);
                    temp.put("RVRT", BigDecimal.ZERO);
                    temp.put("RVMG", BigDecimal.ZERO);
                    temp.put("PYRT", BigDecimal.ZERO);
                    temp.put("PYMG", BigDecimal.ZERO);
                    temp.put("DPYRT", BigDecimal.ZERO);
                    temp.put("DPYMG", BigDecimal.ZERO);
                    temp.put("RRCVRT", BigDecimal.ZERO);
                    temp.put("RCVRT", BigDecimal.ZERO);
                    temp.put("RCVRT3", BigDecimal.ZERO);// �����v(%)  (�ƧǨϥ�)
                } else {
                    temp.putAll(map);
                    //�����v(%)�p���I���G���,�|�ˤ��J
                    //(PAY_AMT_R + PAY_AMT_M)/(RVRT+RVMG)*100
                    BigDecimal RCVRTParam = PYRT.add(PYMG);
                    RCVRT = RCVRTParam.divide(RVRT_RVMG, 4, BigDecimal.ROUND_HALF_UP).multiply(hun);//�����v(%)
                    //���:�W ���[�����v���
                    if (BigDecimal.ZERO.compareTo(RVRT) == 0) { //������ 0 ���p
                        RRCVRT = BigDecimal.ZERO;
                    } else {
                        RRCVRT = PYRT.divide(RVRT, 4, BigDecimal.ROUND_HALF_UP).multiply(hun);//�����v(%)
                    }
                    temp.put("RVRT", RVRT);//��������
                    temp.put("RVMG", RVMG);//�����޲z�O
                    temp.put("PYRT", PYRT);//�w�P����
                    temp.put("PYMG", PYMG);//�w�P�޲z�O
                    temp.put("DPYRT", RVRT.subtract(PYRT));//���:��ú����
                    temp.put("DPYMG", RVMG.subtract(PYMG));//���:��ú�޲z�O
                    temp.put("RRCVRT", RRCVRT);//���������v(%)
                    temp.put("RCVRT", RCVRT);//�����v(%)
                    temp.put("RCVRT3", RRCVRT);// �����v(%)  (�ƧǨϥ�)
                }//end if
                newRtnList.add(temp);
            }//END IF
        }//END FOR
        //�Ƨ�    A:�����v ,B:�j�өʽ� ,C:�j�ӥN��
        if ("A".equals(SORT_TYPE)) {
            Collections.sort(newRtnList, new genComparatorA());
        } else if ("B".equals(SORT_TYPE)) {
            Collections.sort(newRtnList, new genComparatorB());
        } else {
            Collections.sort(newRtnList, new genComparatorC());
        }
        // Collections.sort(newRtnList, ("A".equals(SORT_TYPE)) ? new genComparatorA() : new genComparatorB());

        return newRtnList;
    }

    /**
     * �d�w������/�޲z�O
     * @param RCV_YM  BigDicemal  �����~��
     * @param DATE_10 Date    10���
     * @param DATE_20 Date    20���
     * @param DATE_30 Date    30���
     * @param rVsMap Map �⦬���v���
     * @param GROUP_TYPE ���s�W�h
     * @param BLD_CD  String  �j�ӥN��
     * @throws ModuleException
     */
    private void queryPAYAMT_NEW(BigDecimal RCV_YM, List<String> BLD_CDs, Date DATE_10, Date DATE_20, Date DATE_30,
            Map<String, Map<String, BigDecimal>> rVsMap, String FEE_RCV_YM, String SUB_CPY_ID, String GROUP_TYPE) throws ModuleException {
        ErrorInputException eie = null;
        if (RCV_YM == null) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_002");// �����~�묰�������
        }
        if (DATE_10 == null) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_005");//���10��[�`���󬰥������
        }
        if (DATE_20 == null) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_006");//���20�骺�[�`���󬰥������
        }
        if (DATE_30 == null) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_007");//���30�骺�[�`���󬰥������
        }
        if (rVsMap == null || rVsMap.isEmpty()) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_009");//�⦬���v��Ƥ��o����
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ� 
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("FEE_RCV_YM", FEE_RCV_YM);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        ds.setFieldValues("BLD_CDs", BLD_CDs);

        //[20180308]�Y���H10����s,�d����H�e�������v 
        if ("B".equals(GROUP_TYPE)) {
            ds.setField("DATE_30", DATE.addDate(DATE.getDBDate(), 0, 0, 1));
        } else {
            ds.setField("DATE_30", DATE_30);
        }
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryPAYAMT_NEW_001, false);
        //20190703���D��s�� 20190703-0092  
        //��ر��v���ʲ��޲z�t�ξɤJ�ɡA�s�Wú�ں���"8�X�����a"�C�b�j�Ӧ����v�@�~(�p��w�P����)�ι�b���Ӫ��ɥ��Nú�ں���"8�X�����a"�����B��i�h�C
        String[] PAY_KIND_A = { "1", "4", "5", "7", "8" };
        String PAY_KIND_B = "3";
        if (rtnList != null) {
            for (Map rtnMap : rtnList) {

                String BLD_CD = MapUtils.getString(rtnMap, "BLD_CD");
                String PAY_KIND = MapUtils.getString(rtnMap, "PAY_KIND");
                BigDecimal PAY_AMT = getBigDecimal(rtnMap.get("PAY_AMT"), BigDecimal.ZERO);
                Date ACNT_DATE = (Date) MapUtils.getObject(rtnMap, "ACNT_DATE");
                Map<String, BigDecimal> tempMap;
                if (rVsMap.containsKey(BLD_CD)) {
                    tempMap = (Map<String, BigDecimal>) rVsMap.get(BLD_CD);
                } else {
                    tempMap = new HashMap<String, BigDecimal>();
                    rVsMap.put(BLD_CD, tempMap);
                }
                //[20180308]���s�P�_ 
                if ("A".equals(GROUP_TYPE)) {
                    if (ArrayUtils.contains(PAY_KIND_A, PAY_KIND)) {

                        if (ACNT_DATE.compareTo(DATE_10) < 0) {
                            //10�鯲��
                            tempMap.put("PYRT1", getBigDecimal(tempMap.get("PYRT1"), BigDecimal.ZERO).add(PAY_AMT));
                        }
                        if (ACNT_DATE.compareTo(DATE_20) < 0) {
                            //20�鯲��
                            tempMap.put("PYRT2", getBigDecimal(tempMap.get("PYRT2"), BigDecimal.ZERO).add(PAY_AMT));
                        }
                        if (ACNT_DATE.compareTo(DATE_30) < 0) {
                            //30�鯲��
                            tempMap.put("PYRT3", getBigDecimal(tempMap.get("PYRT3"), BigDecimal.ZERO).add(PAY_AMT));
                        }

                    } else if (PAY_KIND_B.equals(PAY_KIND)) {
                        if (ACNT_DATE.compareTo(DATE_10) < 0) {

                            //10��޲z�O
                            tempMap.put("PYMG1", getBigDecimal(tempMap.get("PYMG1"), BigDecimal.ZERO).add(PAY_AMT));
                        }
                        if (ACNT_DATE.compareTo(DATE_20) < 0) {
                            //20��޲z�O
                            tempMap.put("PYMG2", getBigDecimal(tempMap.get("PYMG2"), BigDecimal.ZERO).add(PAY_AMT));
                        }
                        if (ACNT_DATE.compareTo(DATE_30) < 0) {
                            //30��޲z�O
                            tempMap.put("PYMG3", getBigDecimal(tempMap.get("PYMG3"), BigDecimal.ZERO).add(PAY_AMT));
                        }
                    }
                } else {
                    //[20180308]���s�P�_ else 
                    if (ArrayUtils.contains(PAY_KIND_A, PAY_KIND)) {
                        //����
                        tempMap.put("PYRT", getBigDecimal(tempMap.get("PYRT"), BigDecimal.ZERO).add(PAY_AMT));
                    } else if (PAY_KIND_B.equals(PAY_KIND)) {
                        //�޲z�O
                        tempMap.put("PYMG", getBigDecimal(tempMap.get("PYMG"), BigDecimal.ZERO).add(PAY_AMT));
                    }
                }//END IF
            }//End for
        }
    }

    /**
     * �d�w������/�޲z�O
     * 
     * @param RCV_YM
     *            �����~��
     * @param BLD_CD
     *            �j�ӥN��
     * @param DATE_xx
     *            ����[�`����
     * @param QUERY_TYPE
     *            �d�����O(A:����/B:�޲z�O)
     * @return rtnValue ���B�[�`
     * @throws ModuleException
     */
    public BigDecimal queryPAYAMT(BigDecimal RCV_YM, String BLD_CD, Date DATE_xx, String QUERY_TYPE) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(BLD_CD)) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_001");// �j�ӥN�����������
        }
        if (RCV_YM == null) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_002");// �����~�묰�������
        }
        if (StringUtils.isBlank(QUERY_TYPE)) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_003");// �d�����O���������
        }
        if (DATE_xx == null) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_004");// ����[�`���󬰥������
        }
        if (eie != null) {
            throw eie;
        }

        // �dú�O���p��
        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("BLD_CD", BLD_CD);
        ds.setField("DATE_xx", DATE_xx);
        String[] PAY_KIND;
        if ("A".equals(QUERY_TYPE)) {// ����
            //20190703���D��s�� 20190703-0092  
            //��ر��v���ʲ��޲z�t�ξɤJ�ɡA�s�Wú�ں���"8�X�����a"�C�b�j�Ӧ����v�@�~(�p��w�P����)�ι�b���Ӫ��ɥ��Nú�ں���"8�X�����a"�����B��i�h�C
            PAY_KIND = new String[] { "1", "4", "5", "7", "8" };
        } else {// �޲z�O
            PAY_KIND = new String[] { "3" };
        }
        ds.setFieldValues("PAY_KIND", PAY_KIND);
        DBUtil.searchAndRetrieve(ds, SQL_queryPAYAMT_001);
        ds.next();
        return getBigDecimal(ds.getField("PAY_AMT"), BigDecimal.ZERO);
    }

    /**
     * �ƧǤ���W�h:��O+�����v
     */
    public class genComparatorA implements Comparator<Map> {
        public int compare(Map aMap, Map bMap) {
            String aCLC_DIV_NO = MapUtils.getString(aMap, "CLC_DIV_NO");
            String bCLC_DIV_NO = MapUtils.getString(bMap, "CLC_DIV_NO");
            if (0 != aCLC_DIV_NO.compareTo(bCLC_DIV_NO)) {
                return aCLC_DIV_NO.compareTo(bCLC_DIV_NO);
            }

            BigDecimal aRCVRT3 = getBigDecimal(aMap.get("RCVRT3"), BigDecimal.ZERO);
            BigDecimal bRCVRT3 = getBigDecimal(bMap.get("RCVRT3"), BigDecimal.ZERO);
            return (bRCVRT3).compareTo(aRCVRT3);// �Ѥj��p
        }
    }

    /**
     * �ƧǤ���W�h:��O+�j�өʽ�
     */
    public class genComparatorB implements Comparator<Map> {
        public int compare(Map aMap, Map bMap) {
            String aCLC_DIV_NO = MapUtils.getString(aMap, "CLC_DIV_NO");
            String bCLC_DIV_NO = MapUtils.getString(bMap, "CLC_DIV_NO");
            if (0 != aCLC_DIV_NO.compareTo(bCLC_DIV_NO)) {
                return aCLC_DIV_NO.compareTo(bCLC_DIV_NO);
            }

            String aBLD_KD_1 = MapUtils.getString(aMap, "BLD_KD_1");
            String bBLD_KD_1 = MapUtils.getString(bMap, "BLD_KD_1");
            return (aBLD_KD_1).compareTo(bBLD_KD_1);
        }
    }

    /**
     * �ƧǤ���W�h:��O+�j�ӥN��
     */
    public class genComparatorC implements Comparator<Map> {
        public int compare(Map aMap, Map bMap) {
            String aCLC_DIV_NO = MapUtils.getString(aMap, "CLC_DIV_NO");
            String bCLC_DIV_NO = MapUtils.getString(bMap, "CLC_DIV_NO");
            if (0 != aCLC_DIV_NO.compareTo(bCLC_DIV_NO)) {
                return aCLC_DIV_NO.compareTo(bCLC_DIV_NO);
            }

            String aBLD_CD_1 = MapUtils.getString(aMap, "BLD_CD");
            String aBLD_CD_2 = MapUtils.getString(bMap, "BLD_CD");
            return (aBLD_CD_1).compareTo(aBLD_CD_2);
        }
    }

    /**
     * �ƧǤ���W�h:��O+�j�ӥN��
     */
    public class genComparatorD implements Comparator<Map> {

        public int compare(Map aMap, Map bMap) {
            //���
            String aDIV_NO = MapUtils.getString(aMap, "DIV_NO");
            String bDIV_NO = MapUtils.getString(bMap, "DIV_NO");
            int j = aDIV_NO.compareTo(bDIV_NO);
            if (j != 0) {
                return j;
            }
            //�j�ӥN��
            String aBLD_CD = MapUtils.getString(aMap, "BLD_CD");
            String bBLD_CD = MapUtils.getString(bMap, "BLD_CD");
            int i = aBLD_CD.compareTo(bBLD_CD);
            return i;

        }
    }

    /**
     * �d�߸��:�w����b���Ӫ�
     * 
     * @param RCV_YM
     *            �����~��(�褸�~��)
     * @return rtnList �����v���List
     * @throws ModuleException
     */
    public List<Map> queryForRpt1(BigDecimal RCV_YM, String BLD_CD, String ACNT_TYPE, String SUB_CPY_ID) throws ModuleException {
        if (RCV_YM == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C14020_MSG_002"));// �����~�묰�������
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        if (StringUtils.isNotBlank(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }
        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else if ("2".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE2", "2");
        }
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryForRpt1_001, false);

        ds.clear();
        ds.setField("RCV_YM", RCV_YM);
        String PRP_E_DATE = DATE.addDate(DATE.getMonthFirstDate(RCV_YM.toPlainString()), 0, 0, -1);
        ds.setField("PRP_E_DATE", PRP_E_DATE);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (StringUtils.isNotBlank(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }
        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else if ("2".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE2", "2");
        }
        List<Map> tmpList = VOTool.findToMaps(ds, SQL_queryForRpt1_002, false);

        if (tmpList != null && !tmpList.isEmpty()) {
            for (Map tmpMap : tmpList) {
                tmpMap.put("RCV_YM", RCV_YM);
            }
            rtnList.addAll(tmpList);
        }

        if (rtnList == null || rtnList.isEmpty()) {
            throw new DataNotFoundException("�d�L���");
        }
        Collections.sort(rtnList, new genComparatorD());

        return rtnList;

    }

    /**
     * �d�߸��:�j�ӹw�����Ӫ�
     * 
     * @param RCV_YM
     *            �����~��(�褸�~��)
     * @return rtnList �����v���List
     * @throws ModuleException
     */
    public List<Map> queryForRpt2(BigDecimal RCV_YM, String BLD_CD, String ACNT_TYPE) throws ModuleException {
        if (RCV_YM == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C14020_MSG_002"));// �����~�묰�������
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        if (StringUtils.isNotBlank(BLD_CD)) {
            ds.setField("BLD_CD", BLD_CD);
        }
        if ("1".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE1", "1");
        } else if ("2".equals(ACNT_TYPE)) {
            ds.setField("ACNT_TYPE2", "2");
        }
        return VOTool.findToMaps(ds, SQL_queryForRpt2_001);
    }

    /**
     * ��z�w����b���Ӫ��������榡
     * 
     * @param RCV_YM �����~��(�褸�~��)
     * @param user
     * @return rtnMap �����ΰѼ�
     * @throws ModuleException
     */
    public Map doFmtRpt1(BigDecimal RCV_YM, String BLD_CD, String ACNT_TYPE, UserObject user, String SUB_CPY_ID) throws ModuleException {
        if (RCV_YM == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C14020_MSG_002"));// �����~�묰�������
        }

        List<Map> rptList = queryForRpt1(RCV_YM, BLD_CD, ACNT_TYPE, SUB_CPY_ID);
        LocaleDisplay locale = new LocaleDisplay("EP", user);
        String REPORT_ID = "EP_C14020_1"; // �����s��
        Map param = new HashMap();
        param.put("PRINT_DATE", locale.formatDate(DATE.today(), "/", ""));
        param.put("REPORT_ID", REPORT_ID);
        List detail = new ArrayList();
        for (Map dataMap : rptList) {
            Map detailMap = new HashMap();
            detailMap.put("RCV_YM", locale.formatDateym(MapUtils.getString(dataMap, "RCV_YM"), ""));
            detailMap.put("DIV_NO", MapUtils.getString(dataMap, "DIV_NO", ""));
            detailMap.put("CRT_NO", MapUtils.getString(dataMap, "CRT_NO", ""));
            detailMap.put("CUS_NO", MapUtils.getString(dataMap, "CUS_NO", ""));
            detailMap.put("CUS_NAME", MapUtils.getString(dataMap, "CUS_NAME", ""));
            detailMap.put("ACNT_DATE", locale.formatDate((Date) dataMap.get("ACNT_DATE"), "/", ""));
            detailMap.put("PRP_S_DATE", locale.formatDate((Date) dataMap.get("PRP_S_DATE"), "/", ""));
            detailMap.put("PRP_E_DATE", locale.formatDate((Date) dataMap.get("PRP_E_DATE"), "/", ""));
            detailMap.put("BLD_CD", MapUtils.getString(dataMap, "BLD_CD", ""));
            detailMap.put("INV_NO", MapUtils.getString(dataMap, "INV_NO", ""));
            detailMap.put("PRP_AMT", locale.formatNumber(dataMap.get("PRP_AMT"), 0, "0"));
            detailMap.put("PRP_SP_AMT", locale.formatNumber(dataMap.get("PRP_SP_AMT"), 0, "0"));
            detail.add(detailMap);
        }

        // ���ո�ƳB�z
        Map GroupDataMap = formatCalList1(rptList, locale);
        // �U�s�ե[�`�����
        Map<String, List<Map>> TEAM_Map = MapUtils.getMap(GroupDataMap, "TEAM_Map", Collections.EMPTY_MAP);

        // �l����
        String REPORT_ID_1 = REPORT_ID + "_1";
        Map param1 = new HashMap();
        param1.put("REPORT_ID", REPORT_ID_1);
        param1.put("EP_C14020_1_1_Group", TEAM_Map);

        Map rtnMap = new HashMap();
        rtnMap.put("param", param);
        rtnMap.put("detail", detail);
        rtnMap.put("param1", param1);
        return rtnMap;
    }

    /**
     * ��z�j�ӹw�����Ӫ��������榡
     * 
     * @param RCV_YM �����~��(�褸�~��)
     * @param user
     * @return rtnMap �����ΰѼ�
     * @throws ModuleException
     */
    public Map doFmtRpt2(BigDecimal RCV_YM, String BLD_CD, String ACNT_TYPE, UserObject user) throws ModuleException {
        if (RCV_YM == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C14020_MSG_002"));// �����~�묰�������
        }

        List<Map> rptList = queryForRpt2(RCV_YM, BLD_CD, ACNT_TYPE);
        LocaleDisplay locale = new LocaleDisplay("EP", user);
        String REPORT_ID = "EP_C14020_2"; // �����s��
        Map param = new HashMap();
        param.put("PRINT_DATE", locale.formatDate(DATE.today(), "/", ""));
        param.put("REPORT_ID", REPORT_ID);

        List detail = new ArrayList();
        for (Map dataMap : rptList) {
            Map detailMap = new HashMap();
            detailMap.put("RCV_YM", locale.formatDateym(MapUtils.getString(dataMap, "RCV_YM"), ""));
            detailMap.put("DIV_NO", MapUtils.getString(dataMap, "DIV_NO", ""));
            detailMap.put("BLD_CD", MapUtils.getString(dataMap, "BLD_CD", ""));
            detailMap.put("BLD_NAME", MapUtils.getString(dataMap, "BLD_NAME", ""));
            detailMap.put("SAL_AMT", locale.formatNumber(dataMap.get("SAL_AMT"), 0, "0"));
            detailMap.put("TAX_AMT", locale.formatNumber(dataMap.get("TAX_AMT"), 0, "0"));
            detailMap.put("INV_AMT", locale.formatNumber(dataMap.get("INV_AMT"), 0, "0"));
            detailMap.put("RNT_AMT", locale.formatNumber(dataMap.get("RNT_AMT"), 0, "0"));
            detailMap.put("PRP_AMT", locale.formatNumber(dataMap.get("PRP_AMT"), 0, "0"));
            detail.add(detailMap);
        }

        // ���ո�ƳB�z
        Map GroupDataMap = formatCalList2(rptList, locale);
        // �U�s�ե[�`�����
        Map<String, List<Map>> TEAM_Map = MapUtils.getMap(GroupDataMap, "TEAM_Map", Collections.EMPTY_MAP);

        // �l����
        String REPORT_ID_1 = REPORT_ID + "_1";
        Map param1 = new HashMap();
        param1.put("REPORT_ID", REPORT_ID_1);
        param1.put("EP_C14020_2_1_Group", TEAM_Map);

        Map rtnMap = new HashMap();
        rtnMap.put("param", param);
        rtnMap.put("detail", detail);
        rtnMap.put("param1", param1);
        return rtnMap;
    }

    /**
     * �C�L�w����b���Ӫ���k
     * 
     * @param rtnMap
     * @param resp
     */

    public void prtRpt1(Map rtnMap, ResponseContext resp, RequestContext req) {
        List<Map> detail = (List<Map>) rtnMap.get("detail");
        Map param = (Map) rtnMap.get("param");
        Map param1 = (Map) rtnMap.get("param1");
        Map<String, List<Map>> TEAM_MAP = (Map) param1.get("EP_C14020_1_1_Group");

        int commit_size = prtRpt1PageSize * 1; //�@��20���i�H�ݨD���ܵ���  �L1��

        List<Map> newdetail = new ArrayList<Map>();
        StringBuffer sb = new StringBuffer();
        String preBLD_DIVkey = "";
        String preDIVkey = "";
        for (int i = 0; i < detail.size(); i++) {
            Map map = (Map) detail.get(i);
            String DIV_NO = MapUtils.getString(map, "DIV_NO");
            String BLD_CD = MapUtils.getString(map, "BLD_CD");
            String RCV_YM = MapUtils.getString(map, "RCV_YM");

            String BLD_DIVkey = sb.append(DIV_NO).append('&').append(BLD_CD).toString();
            sb.setLength(0);
            if (i != 0) {
                if (!preBLD_DIVkey.equals(BLD_DIVkey)) {
                    Map BLD_DIV_TMap = ((List<Map>) TEAM_MAP.get(preBLD_DIVkey)).get(0);
                    BLD_DIV_TMap.put("PRINT_SUBBD_SUM", "Y");
                    BLD_DIV_TMap.put("DIV_NO", preDIVkey);
                    BLD_DIV_TMap.put("RCV_YM", RCV_YM);
                    BLD_DIV_TMap.put("BLD_CD", preBLD_DIVkey.split("&")[1]);
                    newdetail.add(BLD_DIV_TMap);
                    if (newdetail.size() % prtRpt1PageSize != 0) {
                        Map etymap = new HashMap();
                        etymap.put("EMPTY", "Y");
                        etymap.put("DIV_NO", DIV_NO);
                        etymap.put("RCV_YM", RCV_YM);
                        newdetail.add(etymap);
                    }
                }
                if (!preDIVkey.equals(DIV_NO)) {
                    Map DIV_TMap = ((List<Map>) TEAM_MAP.get(preDIVkey)).get(0);
                    DIV_TMap.put("PRINT_SUBD_SUM", "Y");
                    DIV_TMap.put("DIV_NO", preDIVkey);
                    DIV_TMap.put("RCV_YM", RCV_YM);
                    newdetail.add(DIV_TMap);
                    int recListE = prtRpt1PageSize - newdetail.size() % prtRpt1PageSize;
                    for (int j = 0; j < recListE; j++) {
                        Map etymap = new HashMap();
                        etymap.put("DIV_NO", DIV_NO);
                        etymap.put("RCV_YM", RCV_YM);
                        newdetail.add(etymap);
                    }
                }
            }
            map.put("PRINT_DETAIL", "Y");
            newdetail.add(map);
            preBLD_DIVkey = BLD_DIVkey;
            preDIVkey = DIV_NO;

        }
        //�̫�@�����

        if (!newdetail.isEmpty()) {
            Map lastNewdetail = newdetail.get(newdetail.size() - 1);
            String RCV_YM = MapUtils.getString(detail.get(detail.size() - 1), "RCV_YM");
            if (!lastNewdetail.containsKey("PRINT_SUBBD_SUM")) {
                Map BLD_DIV_TMap = ((List<Map>) TEAM_MAP.get(preBLD_DIVkey)).get(0);
                BLD_DIV_TMap.put("PRINT_SUBBD_SUM", "Y");
                BLD_DIV_TMap.put("DIV_NO", preDIVkey);
                BLD_DIV_TMap.put("RCV_YM", RCV_YM);
                BLD_DIV_TMap.put("BLD_CD", preBLD_DIVkey.split("&")[1]);
                newdetail.add(BLD_DIV_TMap);
                Map etymap = new HashMap();
                etymap.put("EMPTY", "Y");
                etymap.put("DIV_NO", preDIVkey);
                etymap.put("RCV_YM", RCV_YM);
                newdetail.add(etymap);
            }
            if (!lastNewdetail.containsKey("PRINT_SUBD_SUM")) {
                Map DIV_TMap = ((List<Map>) TEAM_MAP.get(preDIVkey)).get(0);
                DIV_TMap.put("PRINT_SUBD_SUM", "Y");
                DIV_TMap.put("DIV_NO", preDIVkey);
                DIV_TMap.put("RCV_YM", RCV_YM);
                newdetail.add(DIV_TMap);
            }
            Map ALL_TOTAL = ((List<Map>) TEAM_MAP.get("ALL_TOTAL")).get(0);
            ALL_TOTAL.put("PRINT_SUM", "Y");
            ALL_TOTAL.put("DIV_NO", preDIVkey);
            ALL_TOTAL.put("RCV_YM", RCV_YM);
            newdetail.add(ALL_TOTAL);
        }

        int allsize = newdetail.size();
        int Times = ((newdetail.size() - 1) / commit_size) + 1;//����PDF����
        //�UPDF�Ѽ�
        String reportIds[] = new String[Times];
        Map inputParams[][] = new Map[Times][];
        List inputDetailLists[][] = new List[Times][];
        Map[] inputParam = new Map[] { param };
        for (int i = 1; i <= Times; i++) {
            reportIds[i - 1] = "EP_C14020_1";
            int initS = (i - 1) * commit_size;
            int initE = (i == Times) ? allsize : i * commit_size;
            List<Map> details = new ArrayList<Map>();//�C����LIST���
            for (int j = initS; j < initE; j++) {
                Map map = (Map) newdetail.get(j);
                //�C������
                String PAGE_C = String.valueOf((j / prtRpt1PageSize) + 1);
                map.put("PAGE_C", PAGE_C);
                //�C���̫�@������
                map.put("END", (j == initE - 1) ? "Y" : "N");
                if (j == allsize - 1) {
                    param.put("PAGE_T", PAGE_C);
                }
                details.add(map);
            }

            inputParams[i - 1] = inputParam;
            inputDetailLists[i - 1] = new List[] { details };

        }

        JasperReportUtils.addOutputRptDataToResp(reportIds, inputParams, inputDetailLists, req, resp);
    }

    /**
     * �C�L�j�ӹw�����Ӫ���k
     * 
     * @param rtnMap
     * @param resp
     */
    public void prtRpt2(Map rtnMap, ResponseContext resp) {
        JasperReportUtils.addOutputRptDataToResp(new String[] { "EP_C14020_2", "EP_C14020_2_1" }, new Map[] { (Map) rtnMap.get("param"),
                (Map) rtnMap.get("param1") }, new List[] { (List) rtnMap.get("detail"), Collections.EMPTY_LIST }, resp);
    }

    /**
     * ��z�����v�έp���������榡
     * @param RCV_YM
     * @param DIV_NO
     * @param SORT_TYPE
     * @param SUB_CPY_ID
     * @param user
     * @param GROUP_TYPE ���s�W�h
     * @return
     * @throws ModuleException
     * @throws ParseException
     * @throws SQLException
     * @throws DBException 
     */
    public Map doFmtRpt3(BigDecimal RCV_YM, String DIV_NO, String SORT_TYPE, String SUB_CPY_ID, UserObject user, String GROUP_TYPE)
            throws ModuleException, ParseException, SQLException, DBException {

        // �ˮֿ�J�Ѽ�
        ErrorInputException eie = null;
        if (RCV_YM == null) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_002");// �����~�묰�������
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ� 
        }
        //[20180308]���s�P�_ 
        if (StringUtils.isBlank(GROUP_TYPE)) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_010"); //���s�W�h���������
        } else if (!"A".equals(GROUP_TYPE)) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_011"); //�D�H10����s�ШϥζץX�\��
        }
        if (eie != null) {
            throw eie;
        }
        List<Map> rptList_ori = queryList(RCV_YM, DIV_NO, SORT_TYPE, GROUP_TYPE, SUB_CPY_ID);
        List<Map> rtnList = new ArrayList();

        for (int i = 0; i < rptList_ori.size(); i = i + 3) {
            Map date10Map = rptList_ori.get(i);
            Map date20Map = rptList_ori.get(i + 1);
            Map date30Map = rptList_ori.get(i + 2);

            Map rtnMap = new HashMap();
            rtnMap.put("CLC_DIV_NO", date10Map.get("CLC_DIV_NO"));
            rtnMap.put("CUS_CNT", date10Map.get("CUS_CNT"));
            rtnMap.put("BLD_NAME", date10Map.get("BLD_NAME"));
            rtnMap.put("RVRT10", date10Map.get("RVRT"));
            rtnMap.put("RVMG10", date10Map.get("RVMG"));
            rtnMap.put("PYRT10", date10Map.get("PYRT"));
            rtnMap.put("PYMG10", date10Map.get("PYMG"));
            rtnMap.put("RCVRT310", date10Map.get("RCVRT"));
            rtnMap.put("RVRT20", date20Map.get("RVRT"));
            rtnMap.put("RVMG20", date20Map.get("RVMG"));
            rtnMap.put("PYRT20", date20Map.get("PYRT"));
            rtnMap.put("PYMG20", date20Map.get("PYMG"));
            rtnMap.put("RCVRT320", date20Map.get("RCVRT"));
            rtnMap.put("RVRT30", date30Map.get("RVRT"));
            rtnMap.put("RVMG30", date30Map.get("RVMG"));
            rtnMap.put("PYRT30", date30Map.get("PYRT"));
            rtnMap.put("PYMG30", date30Map.get("PYMG"));
            rtnMap.put("RCVRT330", date30Map.get("RCVRT"));
            rtnMap.put("PYRTALL", new BigDecimal(MapUtils.getString(date30Map, "PYRT")).add(new BigDecimal(MapUtils.getString(date30Map,
                "PYMG"))));
            rtnMap.put("BLD_USR_NAME", date10Map.get("BLD_USR_NAME"));
            rtnList.add(rtnMap);
        }

        LocaleDisplay locale = new LocaleDisplay("EP", user);
        String REPORT_ID = "EP_C14020_3"; // �����s��
        Map param = new HashMap();

        param.put("PRINT_DATE", locale.formatDate(DATE.today(), "/", ""));
        param.put("REPORT_ID", REPORT_ID);
        param.put("RCV_YM", locale.formatDateym(RCV_YM, ""));
        // [20180308] 
        param.put("SUB_CPY_ID", SUB_CPY_ID);
        String RCV_YMstr = locale.formatDateym(RCV_YM, "");
        if ("00".equals(SUB_CPY_ID)) {
            param.put("TITLE", MessageUtil.getMessage("EP_C14020_MSG_013", new Object[] { RCV_YMstr })); //{0}����޲z�@�G�쯲���κ޲z�O�����v�έp��
        } else {
            param.put("TITLE", MessageUtil.getMessage("EP_C14020_MSG_014", new Object[] { RCV_YMstr })); //{0}��������κ޲z�O�����v�έp��
        }// END IF

        List detail = new ArrayList();
        Map tempMap = new HashMap();
        EP_A10010 theEP_A10010 = new EP_A10010();
        for (Map dataMap : rtnList) {
            Map detailMap = new HashMap();
            String CLC_DIV_NO = MapUtils.getString(dataMap, "CLC_DIV_NO");
            if (StringUtils.isBlank(MapUtils.getString(tempMap, CLC_DIV_NO))) {
                String CLC_DIV_NM = theEP_A10010.getDivName(CLC_DIV_NO, SUB_CPY_ID);
                tempMap.put(CLC_DIV_NO, CLC_DIV_NM);
                detailMap.put("CLC_DIV_NM", CLC_DIV_NM);
            } else {
                detailMap.put("CLC_DIV_NM", MapUtils.getString(tempMap, CLC_DIV_NO));
            }
            detailMap.put("CLC_DIV_NO", CLC_DIV_NO);

            detailMap.put("SAL_AMT", locale.formatNumber(dataMap.get("SAL_AMT"), 0, "0"));

            detailMap.put("BLD_NAME", MapUtils.getString(dataMap, "BLD_NAME"));
            detailMap.put("CUS_CNT", locale.formatNumber(dataMap.get("CUS_CNT"), 0, "0"));
            detailMap.put("RVRT10", locale.formatNumber(dataMap.get("RVRT10"), 0, "0"));
            detailMap.put("RVMG10", locale.formatNumber(dataMap.get("RVMG10"), 0, "0"));
            detailMap.put("PYRT10", locale.formatNumber(dataMap.get("PYRT10"), 0, "0"));
            detailMap.put("PYMG10", locale.formatNumber(dataMap.get("PYMG10"), 0, "0"));
            detailMap.put("RCVRT310", locale.formatNumber(dataMap.get("RCVRT310"), 2, "0"));
            detailMap.put("RVRT20", locale.formatNumber(dataMap.get("RVRT20"), 0, "0"));
            detailMap.put("RVMG20", locale.formatNumber(dataMap.get("RVMG20"), 0, "0"));
            detailMap.put("PYRT20", locale.formatNumber(dataMap.get("PYRT20"), 0, "0"));
            detailMap.put("PYMG20", locale.formatNumber(dataMap.get("PYMG20"), 0, "0"));
            detailMap.put("RCVRT320", locale.formatNumber(dataMap.get("RCVRT320"), 2, "0"));
            detailMap.put("RVRT30", locale.formatNumber(dataMap.get("RVRT30"), 0, "0"));
            detailMap.put("RVMG30", locale.formatNumber(dataMap.get("RVMG30"), 0, "0"));
            detailMap.put("PYRT30", locale.formatNumber(dataMap.get("PYRT30"), 0, "0"));
            detailMap.put("PYMG30", locale.formatNumber(dataMap.get("PYMG30"), 0, "0"));
            detailMap.put("RCVRT330", locale.formatNumber(dataMap.get("RCVRT330"), 2, "0"));

            detailMap.put("PYRTALL", locale.formatNumber(dataMap.get("PYRTALL"), 0, "0"));
            detailMap.put("RCVRT330", locale.formatNumber(dataMap.get("RCVRT330"), 2, "0"));
            detailMap.put("BLD_USR_NAME", MapUtils.getString(dataMap, "BLD_USR_NAME"));

            detail.add(detailMap);
        }

        // ���ո�ƳB�z
        Map GroupDataMap = formatCalList3(rtnList, locale);
        // �U�s�ե[�`�����
        Map<String, List<Map>> TEAM_Map = MapUtils.getMap(GroupDataMap, "TEAM_Map", Collections.EMPTY_MAP);

        // �l����
        String REPORT_ID_1 = REPORT_ID + "_1";
        Map param1 = new HashMap();
        param1.put("REPORT_ID", REPORT_ID_1);
        param1.put("EP_C14020_3_1_Group", TEAM_Map);

        Map rtnMap = new HashMap();
        rtnMap.put("param", param);
        rtnMap.put("detail", detail);
        rtnMap.put("param1", param1);
        return rtnMap;
    }

    /**
     * �C�L���v�έp��������
     * @param rtnMap
     * @param resp
     */
    public void prtRpt3(Map rtnMap, ResponseContext resp) {
        JasperReportUtils.addOutputRptDataToResp(new String[] { "EP_C14020_3", "EP_C14020_3_1" }, new Map[] { (Map) rtnMap.get("param"),
                (Map) rtnMap.get("param1") }, new List[] { (List) rtnMap.get("detail"), Collections.EMPTY_LIST }, resp);
    }

    /**
     * ��z�����v�έp���������榡(���H10����s) [20180308] TODO
     * @param RCV_YM �����~��(�褸�~��)
     * @param DIV_NO �ӿ��O
     * @param SORT_TYPE �ƧǱ���(A:�����v/B:�j�өʽ�)
     * @param SUB_CPY_ID �����q�O
     * @param user
     * @param GROUP_TYPE ���s�W�h
     * @return
     * @throws ModuleException
     * @throws ParseException 
     * @throws DBException 
     * @throws SQLException 
     */
    public Map doFmtRpt4(BigDecimal RCV_YM, String DIV_NO, String SORT_TYPE, String SUB_CPY_ID, UserObject user, String GROUP_TYPE)
            throws ModuleException, DBException, ParseException, SQLException {
        // �ˮֿ�J�Ѽ�
        ErrorInputException eie = null;
        if (RCV_YM == null) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_002");// �����~�묰�������
        }
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = getErrorInputException(eie, "MEP00020");// �����q�O���o���ŭ� 
        }
        if (StringUtils.isBlank(GROUP_TYPE)) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_010"); //���s�W�h���������
        } else if (!"B".equals(GROUP_TYPE)) {
            eie = getErrorInputException(eie, "EP_C14020_MSG_012"); //�D�H10����s�Шϥγ������s�\��
        }
        if (eie != null) {
            throw eie;
        }
        StringBuilder sb = new StringBuilder();

        LocaleDisplay locale = new LocaleDisplay("EP", user);

        List<Map> rptList_ori = this.queryList(RCV_YM, DIV_NO, SORT_TYPE, GROUP_TYPE, SUB_CPY_ID);

        List<Map> rtnList = new ArrayList();
        EP_A10010 theEP_A10010 = new EP_A10010();
        Map sum = new HashMap();
        Map sum_sub = new HashMap();
        for (Map dataMap : rptList_ori) {
            Map rtnMap = new HashMap();
            String CLC_DIV_NO = MapUtils.getString(dataMap, "CLC_DIV_NO");
            String CLC_DIV_NM = "";
            if (StringUtils.isNotBlank(CLC_DIV_NO)) {
                CLC_DIV_NM = theEP_A10010.getDivName(CLC_DIV_NO, SUB_CPY_ID);
                rtnMap.put("CLC_DIV_NM", CLC_DIV_NM);
                rtnMap.put("CLC_DIV_NO", CLC_DIV_NO);
            }
            rtnMap.put("CUS_CNT", dataMap.get("CUS_CNT"));
            rtnMap.put("BLD_NAME", dataMap.get("BLD_NAME"));
            BigDecimal RVRT = getBigDecimal(dataMap.get("RVRT"), BigDecimal.ZERO);
            rtnMap.put("RVRT", locale.formatNumber(RVRT, 0, "0"));

            BigDecimal RVMG = getBigDecimal(dataMap.get("RVMG"), BigDecimal.ZERO);
            rtnMap.put("RVMG", locale.formatNumber(RVMG, 0, "0"));

            BigDecimal PYRT = getBigDecimal(dataMap.get("PYRT"), BigDecimal.ZERO);
            rtnMap.put("PYRT", locale.formatNumber(PYRT, 0, "0"));

            BigDecimal PYMG = getBigDecimal(dataMap.get("PYMG"), BigDecimal.ZERO);
            rtnMap.put("PYMG", locale.formatNumber(PYMG, 0, "0"));

            BigDecimal DPYRT = getBigDecimal(dataMap.get("DPYRT"), BigDecimal.ZERO);
            rtnMap.put("DPYRT", locale.formatNumber(DPYRT, 0, "0"));

            BigDecimal DPYMG = getBigDecimal(dataMap.get("DPYMG"), BigDecimal.ZERO);
            rtnMap.put("DPYMG", locale.formatNumber(DPYMG, 0, "0"));

            BigDecimal RCVRT = getBigDecimal(dataMap.get("RCVRT"), BigDecimal.ZERO);
            rtnMap.put("RCVRT", locale.formatNumber(RCVRT, 2, "0"));

            BigDecimal RRCVRT = getBigDecimal(dataMap.get("RRCVRT"), BigDecimal.ZERO);
            rtnMap.put("RRCVRT", locale.formatNumber(RRCVRT, 2, "0"));

            BigDecimal PYRTALL = getBigDecimal(dataMap.get("PYRT"), BigDecimal.ZERO).add(
                getBigDecimal(dataMap.get("PYMG"), BigDecimal.ZERO));
            rtnMap.put("PYRTALL", locale.formatNumber(PYRTALL, 0, "0"));

            rtnMap.put("BLD_USR_NAME", dataMap.get("BLD_USR_NAME"));
            rtnList.add(rtnMap);

            //�`�p
            if (sum.isEmpty()) {
                sum.put("BLD_NAME", "�`�p");
                sum.put("RVRT", RVRT);
                sum.put("RVMG", RVMG);
                sum.put("PYRT", PYRT);
                sum.put("PYMG", PYMG);
                sum.put("DPYRT", DPYRT);
                sum.put("DPYMG", DPYMG);
                sum.put("RCVRT", RCVRT);
                sum.put("RRCVRT", RRCVRT);
            } else {
                sum.put("RVRT", getBigDecimal(sum.get("RVRT"), BigDecimal.ZERO).add(RVRT));
                sum.put("RVMG", getBigDecimal(sum.get("RVMG"), BigDecimal.ZERO).add(RVMG));
                sum.put("PYRT", getBigDecimal(sum.get("PYRT"), BigDecimal.ZERO).add(PYRT));
                sum.put("PYMG", getBigDecimal(sum.get("PYMG"), BigDecimal.ZERO).add(PYMG));
                sum.put("DPYRT", getBigDecimal(sum.get("DPYRT"), BigDecimal.ZERO).add(DPYRT));
                sum.put("DPYMG", getBigDecimal(sum.get("DPYMG"), BigDecimal.ZERO).add(DPYMG));
                sum.put("RCVRT", getBigDecimal(sum.get("RCVRT"), BigDecimal.ZERO).add(RCVRT));
                sum.put("RRCVRT", getBigDecimal(sum.get("RRCVRT"), BigDecimal.ZERO).add(RRCVRT));
            }
            //�s�դp�p           
            if (!sum_sub.containsKey(CLC_DIV_NO)) {
                Map temp = new HashMap();
                temp.put("BLD_NAME", CLC_DIV_NM);
                temp.put("RVRT", RVRT);
                temp.put("RVMG", RVMG);
                temp.put("PYRT", PYRT);
                temp.put("PYMG", PYMG);
                temp.put("DPYRT", DPYRT);
                temp.put("DPYMG", DPYMG);
                temp.put("RCVRT", RCVRT);
                temp.put("RRCVRT", RRCVRT);
                sum_sub.put(CLC_DIV_NO, temp);
            } else {
                Map temp = MapUtils.getMap(sum_sub, CLC_DIV_NO);
                temp.put("RVRT", getBigDecimal(temp.get("RVRT"), BigDecimal.ZERO).add(RVRT));
                temp.put("RVMG", getBigDecimal(temp.get("RVMG"), BigDecimal.ZERO).add(RVMG));
                temp.put("PYRT", getBigDecimal(temp.get("PYRT"), BigDecimal.ZERO).add(PYRT));
                temp.put("PYMG", getBigDecimal(temp.get("PYMG"), BigDecimal.ZERO).add(PYMG));
                temp.put("DPYRT", getBigDecimal(temp.get("DPYRT"), BigDecimal.ZERO).add(DPYRT));
                temp.put("DPYMG", getBigDecimal(temp.get("DPYMG"), BigDecimal.ZERO).add(DPYMG));
                temp.put("RCVRT", getBigDecimal(temp.get("RCVRT"), BigDecimal.ZERO).add(RCVRT));
                temp.put("RRCVRT", getBigDecimal(temp.get("RRCVRT"), BigDecimal.ZERO).add(RRCVRT));
                sum_sub.put(CLC_DIV_NO, temp);
            }
        }
        if (!sum_sub.isEmpty()) {
            for (Object key : sum_sub.keySet()) {
                Map temp = MapUtils.getMap(sum_sub, key);
                temp.put("RVRT", locale.formatNumber(temp.get("RVRT"), 0, "0"));
                temp.put("RVMG", locale.formatNumber(temp.get("RVMG"), 0, "0"));
                temp.put("PYRT", locale.formatNumber(temp.get("PYRT"), 0, "0"));
                temp.put("PYMG", locale.formatNumber(temp.get("PYMG"), 0, "0"));
                temp.put("DPYRT", locale.formatNumber(temp.get("DPYRT"), 0, "0"));
                temp.put("DPYMG", locale.formatNumber(temp.get("DPYMG"), 0, "0"));
                temp.put("RCVRT", locale.formatNumber(temp.get("RCVRT"), 2, "0"));
                temp.put("RRCVRT", locale.formatNumber(temp.get("RRCVRT"), 2, "0"));
                rtnList.add(temp);
            }
        }
        if (!sum.isEmpty()) {
            sum.put("RVRT", locale.formatNumber(sum.get("RVRT"), 0, "0"));
            sum.put("RVMG", locale.formatNumber(sum.get("RVMG"), 0, "0"));
            sum.put("PYRT", locale.formatNumber(sum.get("PYRT"), 0, "0"));
            sum.put("PYMG", locale.formatNumber(sum.get("PYMG"), 0, "0"));
            sum.put("DPYRT", locale.formatNumber(sum.get("DPYRT"), 0, "0"));
            sum.put("DPYMG", locale.formatNumber(sum.get("DPYMG"), 0, "0"));
            sum.put("RCVRT", locale.formatNumber(sum.get("RCVRT"), 2, "0"));
            sum.put("RRCVRT", locale.formatNumber(sum.get("RRCVRT"), 2, "0"));
            rtnList.add(sum);
        }

        String RCV_YMstr = locale.formatDateym(RCV_YM, "");
        String PRINT_DATE = locale.formatDate(DATE.today(), "/", "");
        String TITLE = "";
        if ("00".equals(SUB_CPY_ID)) {
            TITLE = MessageUtil.getMessage("EP_C14020_MSG_013", new Object[] { RCV_YMstr }); //{0}����޲z�@�G�쯲���κ޲z�O�����v�έp��
        } else {
            TITLE = MessageUtil.getMessage("EP_C14020_MSG_014", new Object[] { RCV_YMstr }); //{0}��������κ޲z�O�����v�έp��
        }
        sb.setLength(0);

        String memo = MessageUtil.getMessage("EP_C14020_MSG_015", new Object[] { PRINT_DATE }); //��{0}�e�������v�έp
        sb.setLength(0);

        //�ɦW�GRCV_YM(����~)+ ��������κ޲z�O�����v�έp��+��_��+TODAY��.xlsx��        
        String fileName = sb.append(TITLE).append('_').append(DATE.toDate_yyyyMMdd(DATE.getDBDate())).toString();
        sb.setLength(0);

        Map rtnMap = new HashMap();
        rtnMap.put("rtnList", rtnList);
        rtnMap.put("fileName", fileName);
        rtnMap.put("PRINT_DATE", PRINT_DATE);
        rtnMap.put("TITLE", TITLE);
        rtnMap.put("memo", memo);

        return rtnMap;
    }

    /**
     * �ץXexcel [20180308] TODO
     * @param rtnMap
     * @param resp
     * @throws Exception 
     */
    public void prtRpt4(Map rtnMap, ResponseContext resp) throws Exception {

        String fileName = MapUtils.getString(rtnMap, "fileName");
        String PRINT_DATE = MapUtils.getString(rtnMap, "PRINT_DATE");
        String TITLE = MapUtils.getString(rtnMap, "TITLE");
        String memo = MapUtils.getString(rtnMap, "memo");
        List<Map> rtnList = (List<Map>) rtnMap.get("rtnList");

        List<List<ColumnSetting>> titles = new ArrayList<List<ColumnSetting>>();

        List<ColumnSetting> firstRow2 = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow2, XlsUtils.EMPTY, TITLE, new ColumnOptions(1, 10, SORT_RULE.STRING));
        XlsUtils.addColumnAttrs(firstRow2, XlsUtils.EMPTY, MessageUtil.getMessage("EP_C14020_MSG_016", new Object[] { PRINT_DATE }),
            new ColumnOptions(1, 2, SORT_RULE.STRING));
        titles.add(firstRow2); //�C�L���: {0}

        List<ColumnSetting> firstRow3 = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow3, XlsUtils.EMPTY, "", new ColumnOptions(1, 10, SORT_RULE.STRING));
        XlsUtils.addColumnAttrs(firstRow3, XlsUtils.EMPTY, memo, new ColumnOptions(1, 2, SORT_RULE.STRING));
        titles.add(firstRow3);

        List<ColumnSetting> firstRow4 = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow4, XlsUtils.EMPTY, MessageUtil.getMessage("EPC1_4020_UI_BLD_NAME"), new ColumnOptions(2, 1,
                SORT_RULE.STRING));//�j�ӦW��
        XlsUtils.addColumnAttrs(firstRow4, XlsUtils.EMPTY, MessageUtil.getMessage("EPC1_4020_UI_CUS_CNT"), new ColumnOptions(2, 1,
                SORT_RULE.STRING));//�ӯ����
        XlsUtils.addColumnAttrs(firstRow4, XlsUtils.EMPTY, MessageUtil.getMessage("EP_C14020_MSG_017"), new ColumnOptions(1, 2,
                SORT_RULE.STRING));//�������B
        XlsUtils.addColumnAttrs(firstRow4, XlsUtils.EMPTY, MessageUtil.getMessage("EP_C14020_MSG_018"), new ColumnOptions(1, 2,
                SORT_RULE.STRING)); //�wú���B
        XlsUtils.addColumnAttrs(firstRow4, XlsUtils.EMPTY, MessageUtil.getMessage("EP_C14020_MSG_021"), new ColumnOptions(1, 2,
                SORT_RULE.STRING)); //��ú���B
        XlsUtils.addColumnAttrs(firstRow4, XlsUtils.EMPTY, MessageUtil.getMessage("EPC1_4020_UI_RRCVRT") + '%', new ColumnOptions(2, 1,
                SORT_RULE.STRING));//���������v
        XlsUtils.addColumnAttrs(firstRow4, XlsUtils.EMPTY, MessageUtil.getMessage("EPC1_4020_UI_RCVRT") + '%', new ColumnOptions(2, 1,
                SORT_RULE.STRING));//�����v
        XlsUtils.addColumnAttrs(firstRow4, XlsUtils.EMPTY, MessageUtil.getMessage("EP_C14020_MSG_019"), new ColumnOptions(2, 1,
                SORT_RULE.STRING)); //�g��
        XlsUtils.addColumnAttrs(firstRow4, XlsUtils.EMPTY, MessageUtil.getMessage("EP_C14020_MSG_020"), new ColumnOptions(2, 1,
                SORT_RULE.STRING)); //��������]
        titles.add(firstRow4);

        List<ColumnSetting> firstRow5 = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow5, XlsUtils.EMPTY, MessageUtil.getMessage("EPC1_4020_UI_RVRT"), new ColumnOptions(1, 1,
                SORT_RULE.STRING));//��������
        XlsUtils.addColumnAttrs(firstRow5, XlsUtils.EMPTY, MessageUtil.getMessage("EPC1_4020_UI_RVMG"), new ColumnOptions(1, 1,
                SORT_RULE.STRING));//�����޶O
        XlsUtils.addColumnAttrs(firstRow5, XlsUtils.EMPTY, MessageUtil.getMessage("EPC1_4020_UI_PYRT"), new ColumnOptions(1, 1,
                SORT_RULE.STRING));//�w�P����
        XlsUtils.addColumnAttrs(firstRow5, XlsUtils.EMPTY, MessageUtil.getMessage("EPC1_4020_UI_PYMG"), new ColumnOptions(1, 1,
                SORT_RULE.STRING));//�w�P�޲z�O
        XlsUtils.addColumnAttrs(firstRow5, XlsUtils.EMPTY, MessageUtil.getMessage("EPC1_4020_UI_DPYRT"), new ColumnOptions(1, 1,
                SORT_RULE.STRING));//���P����
        XlsUtils.addColumnAttrs(firstRow5, XlsUtils.EMPTY, MessageUtil.getMessage("EPC1_4020_UI_DPYMG"), new ColumnOptions(1, 1,
                SORT_RULE.STRING));//���P�޲z�O
        titles.add(firstRow5);

        List<List<ColumnSetting>> records = new ArrayList<List<ColumnSetting>>();
        List<ColumnSetting> firstRow_ = new ArrayList<ColumnSetting>();
        XlsUtils.addColumnAttrs(firstRow_, "BLD_NAME", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "CUS_CNT", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "RVRT", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "RVMG", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "PYRT", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "PYMG", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "DPYRT", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "DPYMG", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "RRCVRT", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "RCVRT", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "BLD_USR_NAME", XlsUtils.EMPTY);
        XlsUtils.addColumnAttrs(firstRow_, "", XlsUtils.EMPTY);
        records.add(firstRow_);

        XlsUtils xlsUtils = new XlsUtils(fileName, rtnList, resp);
        xlsUtils.parseToSheetSetting("sheet1", titles, records);
        xlsUtils.initExportSetting();

        xlsUtils.execute(new XlsUtils.ListProcessHandler() {
        });

        // ���ͼȦs��       
        File downloadFile = RptUtils.createTempFile(fileName);

        RptUtils.cryptoDownloadParameterToResp(fileName, downloadFile, resp);
    }

    //================================================================================================================================//
    /**
     * �i����s�[�`(�����@)
     * @param rtnList
     * @param locale
     * @return
     */
    private Map formatCalList1(List<Map> rtnList, LocaleDisplay locale) {

        // �B�z��ƪ�Map
        Map GroupDataMap = new HashMap();
        // �U�s�ե[�`�����
        Map<String, List<Map>> TEAM_Map = new HashMap<String, List<Map>>();
        // ���B���
        String[] moneyField = { "PRP_AMT", "PRP_SP_AMT" };

        StringBuilder sb = new StringBuilder();
        for (Map<String, Object> rtnMap : rtnList) {
            // �����`�X
            sumGroupMap(TEAM_Map, rtnMap, "ALL_TOTAL", moneyField);
            // �P�@�ӳ��N�� (�w�����B�B�w���l�B) [�~�h]

            String DIV_NO = MapUtils.getString(rtnMap, "DIV_NO");
            sumGroupMap(TEAM_Map, rtnMap, DIV_NO, moneyField);

            // �P�@�ӳ��N���P�j�ӥN�� (�w�����B�B�w���l�B)
            String BLD_CD = MapUtils.getString(rtnMap, "BLD_CD");
            String DIV_NO_BLD_CD = sb.append(DIV_NO).append("&").append(BLD_CD).toString();
            sumGroupMap(TEAM_Map, rtnMap, DIV_NO_BLD_CD, moneyField);

            sb.setLength(0);
        }
        // �U�s�ե[�`����ơA�i�� toString �ഫ
        for (String key : TEAM_Map.keySet()) {
            Map TEAM_Map_list_map = TEAM_Map.get(key).get(0);
            for (Object map : TEAM_Map_list_map.keySet()) {
                TEAM_Map_list_map.put(map, locale.formatNumber(MapUtils.getObject(TEAM_Map_list_map, map), 0, ""));
            }
        }
        GroupDataMap.put("TEAM_Map", TEAM_Map);
        return GroupDataMap;
    }

    /**
     * �i����s�[�`(�����G)
     * @param rtnList
     * @param locale
     * @return
     */
    private Map formatCalList2(List<Map> rtnList, LocaleDisplay locale) {

        // �B�z��ƪ�Map
        Map GroupDataMap = new HashMap();
        // �U�s�ե[�`�����
        Map<String, List<Map>> TEAM_Map = new HashMap<String, List<Map>>();
        // ���B���
        String[] moneyField = { "SAL_AMT", "TAX_AMT", "INV_AMT", "RNT_AMT", "PRP_AMT" };

        StringBuilder sb = new StringBuilder();
        for (Map<String, Object> rtnMap : rtnList) {
            // �����`�X
            sumGroupMap(TEAM_Map, rtnMap, "ALL_TOTAL", moneyField);

            // �P�@�ӳ��N�� (�w�����B�B�w���l�B) [�~�h]
            String DIV_NO = MapUtils.getString(rtnMap, "DIV_NO");
            sumGroupMap(TEAM_Map, rtnMap, DIV_NO, moneyField);

            sb.setLength(0);
        }
        // �U�s�ե[�`����ơA�i�� toString �ഫ
        for (String key : TEAM_Map.keySet()) {
            Map TEAM_Map_list_map = TEAM_Map.get(key).get(0);
            for (Object map : TEAM_Map_list_map.keySet()) {
                TEAM_Map_list_map.put(map, locale.formatNumber(MapUtils.getObject(TEAM_Map_list_map, map), 0, ""));
            }
        }
        GroupDataMap.put("TEAM_Map", TEAM_Map);
        return GroupDataMap;
    }

    /**
     * �i����s�[�`(�����T)
     * @param rtnList
     * @param locale
     * @return
     */
    private Map formatCalList3(List<Map> rtnList, LocaleDisplay locale) {

        // �B�z��ƪ�Map
        Map GroupDataMap = new HashMap();
        // �U�s�ե[�`�����
        Map<String, List<Map>> TEAM_Map = new HashMap<String, List<Map>>();
        // ���B���
        String[] moneyField = { "CUS_CNT", "RVRT10", "RVMG10", "PYRT10", "PYMG10", "RCVRT310", "RVRT20", "RVMG20", "PYRT20", "PYMG20",
                "RCVRT320", "RVRT30", "RVMG30", "PYRT30", "PYMG30", "RCVRT330", "PYRTALL" };

        StringBuilder sb = new StringBuilder();
        for (Map<String, Object> rtnMap : rtnList) {
            // �����`�X
            sumGroupMap(TEAM_Map, rtnMap, "ALL_TOTAL", moneyField);

            // �P�@�ӳ��N�� (�w�����B�B�w���l�B) [�~�h]
            String CLC_DIV_NO = MapUtils.getString(rtnMap, "CLC_DIV_NO");
            sumGroupMap(TEAM_Map, rtnMap, CLC_DIV_NO, moneyField);

            sb.setLength(0);
        }

        BigDecimal hun = new BigDecimal("100");
        for (String key : TEAM_Map.keySet()) {
            Map TEAM_Map_list_map = TEAM_Map.get(key).get(0);
            for (Object map : TEAM_Map_list_map.keySet()) {
                if (map.equals("RCVRT310") || map.equals("RCVRT320") || map.equals("RCVRT330")) {
                    BigDecimal RCVRT;
                    BigDecimal RV;
                    BigDecimal PY;
                    if (map.equals("RCVRT310")) {
                        //�����v(%)�p���I���G���,�|�ˤ��J
                        //(PAY_AMT_20_A + PAY_AMT_20_B)/(RVRT+RVMG)*100
                        RV = getBigDecimal(TEAM_Map_list_map.get("RVRT10"), BigDecimal.ZERO).add(
                            getBigDecimal(TEAM_Map_list_map.get("RVMG10"), BigDecimal.ZERO));
                        PY = getBigDecimal(TEAM_Map_list_map.get("PYRT10"), BigDecimal.ZERO).add(
                            getBigDecimal(TEAM_Map_list_map.get("PYMG10"), BigDecimal.ZERO));
                    } else if (map.equals("RCVRT320")) {
                        //�����v(%)�p���I���G���,�|�ˤ��J
                        //(PAY_AMT_20_A + PAY_AMT_20_B)/(RVRT+RVMG)*100
                        RV = getBigDecimal(TEAM_Map_list_map.get("RVRT20"), BigDecimal.ZERO).add(
                            getBigDecimal(TEAM_Map_list_map.get("RVMG20"), BigDecimal.ZERO));
                        PY = getBigDecimal(TEAM_Map_list_map.get("PYRT20"), BigDecimal.ZERO).add(
                            getBigDecimal(TEAM_Map_list_map.get("PYMG20"), BigDecimal.ZERO));
                    } else {
                        //�����v(%)�p���I���G���,�|�ˤ��J
                        //(PAY_AMT_20_A + PAY_AMT_20_B)/(RVRT+RVMG)*100
                        RV = getBigDecimal(TEAM_Map_list_map.get("RVRT30"), BigDecimal.ZERO).add(
                            getBigDecimal(TEAM_Map_list_map.get("RVMG30"), BigDecimal.ZERO));
                        PY = getBigDecimal(TEAM_Map_list_map.get("PYRT30"), BigDecimal.ZERO).add(
                            getBigDecimal(TEAM_Map_list_map.get("PYMG30"), BigDecimal.ZERO));
                    }
                    if (RV.compareTo(BigDecimal.ZERO) > 0) {
                        RCVRT = PY.divide(RV, 4, BigDecimal.ROUND_HALF_UP).multiply(hun);
                    } else {
                        RCVRT = BigDecimal.ZERO;
                    }
                    TEAM_Map_list_map.put(map, RCVRT);
                }
            }
        }
        // �U�s�ե[�`����ơA�i�� toString �ഫ
        for (String key : TEAM_Map.keySet()) {
            Map TEAM_Map_list_map = TEAM_Map.get(key).get(0);
            for (Object map : TEAM_Map_list_map.keySet()) {
                if (map.equals("RCVRT310") || map.equals("RCVRT320") || map.equals("RCVRT330")) {
                    TEAM_Map_list_map.put(map, locale.formatNumber(MapUtils.getObject(TEAM_Map_list_map, map), 2, "0"));
                } else {
                    TEAM_Map_list_map.put(map, locale.formatNumber(MapUtils.getObject(TEAM_Map_list_map, map), 0, "0"));
                }
            }
        }
        GroupDataMap.put("TEAM_Map", TEAM_Map);
        return GroupDataMap;
    }

    /**
     * �ھڤ��P�s�աA���� key : �s�� �P value : �s�ժ��B��� List<Map>
     * 
     * @param TEAM_Map
     * @param rtnMap
     * @param sumGroupKey
     *            >> DIV_NO
     * @param moneyField
     */
    private void sumGroupMap(Map<String, List<Map>> TEAM_Map, Map rtnMap, String sumGroupKey, String[] moneyField) {
        List<Map> sumGroup_List;
        Map<String, List<Map>> sumGroup_Map;
        if (TEAM_Map.containsKey(sumGroupKey)) {
            sumGroup_Map = TEAM_Map.get(sumGroupKey).get(0);
        } else {
            sumGroup_List = new ArrayList<Map>();
            sumGroup_Map = new HashMap<String, List<Map>>();
            sumGroup_List.add(sumGroup_Map);
            TEAM_Map.put(sumGroupKey, sumGroup_List);
        }
        for (String moneyKey : moneyField) {
            MoneyTotal(sumGroup_Map, rtnMap, moneyKey);
        }
    }

    /**
     * �ھڤ��P���A�i��[�`
     * 
     * @param keymap
     * @param rtnMap
     * @param key
     *            >> BLD_CD
     */
    private void MoneyTotal(Map keymap, Map<String, Object> rtnMap, String key) {
        // �[�`Map = { key : TOT_key }
        BigDecimal BEFORE_VALUE = STRING.objToBigDecimal(MapUtils.getObject(keymap, key, BigDecimal.ZERO), BigDecimal.ZERO);
        BigDecimal NOW_VALUE = STRING.objToBigDecimal(MapUtils.getObject(rtnMap, key, BigDecimal.ZERO), BigDecimal.ZERO);
        keymap.put(key, BEFORE_VALUE.add(NOW_VALUE));
    }

    /**
     * ��wEIE����
     * 
     * @param eie
     * @param errMsg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String errMsg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(MessageUtil.getMessage(errMsg));
        return eie;
    }

    /**
     * �૬�A�M���w�]
     * 
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

}
