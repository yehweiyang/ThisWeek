package com.cathay.ep.c1.module;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFPrintSetup;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.Base64;
import com.cathay.common.util.CathayZipUtils;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EncodingHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.MASK;
import com.cathay.common.util.MailParser;
import com.cathay.common.util.MailParser.MailContent;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.STRING;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.rpt.RptUtils;
import com.cathay.rz.s0.module.RZ_S00300;
import com.cathay.rz.t0.module.RZ_T0Z001;
import com.cathay.util.FileStoreUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 *  <pre> 
 * Date Version Description Author
 * 2013/8/9    1.0 �s�W  �\�a�s

 * �@�B  �{���\�෧�n�����G
 * �{���\��    �H�Υd�дھP�b�Ҳ�
 * �{���W��    EP_C14030 
 * ���n����    �qDTEPB102_����_�ӯ�����, DTEPB202_�Ȥ�_�H�Υd���v�Ѹ��, DTEPC101_������
 *  </pre>
 * @author �����@ 
 * @since 2013/12/20
 * 
 * [20200413]�ק��
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C14030 {
    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EP_C14030.class);

    private static final String SQL_queryList_001 = "com.cathay.ep.c1.module.EP_C14030.SQL_queryList_001";

    /**
     * �d�߫H�Υd�дڸ��
     * @param RCV_YM
     * @param DIV_NO
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(Map reqMap) throws Exception {
        ErrorInputException eie = null;
        if (reqMap == null) {
            throw this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_007"));//�d�߸�Ƥ��i����
        }
        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
        if (StringUtils.isBlank(RCV_YM)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_008")); //�����~�묰�������
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_009")); // �����q�O���i����
        }
        //        if (StringUtils.isBlank(DIV_NO)) {
        //            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_005")); //�ӿ��쬰�������
        //        }
        if (eie != null) {
            throw eie;
        }
        Integer RCV_YMint = Integer.parseInt(RCV_YM);
        String DIV_NO = MapUtils.getString(reqMap, "DIV_NO");
        //String RCV_YMm1 = DATE.toDateFormat(DATE.getLastMonthFirstDate(RCV_YM), "yyyy-MM-dd", "yyyyMM");
        String RCV_YMm1 = DATE.getLastMonthFirstDate(RCV_YM);

        DataSet ds = Transaction.getDataSet();
        ds.setField("RCV_YM", RCV_YM);
        ds.setField("RCV_YMm1", RCV_YMm1);
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (RCV_YMint % 100 == 6 || RCV_YMint % 100 == 12) {
            ds.setField("RCV_YM2", DATE.getMonthFirstDate(RCV_YM));
        } else {
            ds.setField("RCV_YM2", RCV_YMm1);
        }
        if (StringUtils.isNotBlank(DIV_NO)) {
            ds.setField("DIV_NO", DIV_NO);
        }

        //���d�ӿ��O�U���j�Ӹ��
        return VOTool.findToMaps(ds, SQL_queryList_001);
    }

    // [20200413]�s�W�{���X: �s�W�Ѽ�SUB_CPY_ID
    /**
     * �M���������
     * @param rtnList �����v���List
     * @param Rptpath �ɮ׸��|
     * @param SUB_CPY_ID �����q�O
     * @throws Exception 
     */
    public void data2Rpt(List<Map> rtnList, String Rptpath, Map reqMap) throws Exception {
        ErrorInputException eie = null;
        if (rtnList == null || rtnList.isEmpty()) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_001")); //�����v���List���i����
        }
        if (StringUtils.isBlank(Rptpath)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_002")); //�ɮ׸��|���i����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        // [20200413]�s�W�{���X: �����q�O�ˮ�
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_009")); // �����q�O���i����
        }
        if (eie != null) {
            throw eie;
        }

        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
        String RCV_YM_ROC = DATE.getROCYearAndMonth(RCV_YM);
        String DIV_NO = MapUtils.getString(reqMap, "DIV_NO", "");

        //1.�إ��ɮ�
        BufferedWriter bw = null;
        File file1;

        BigDecimal sumamt = BigDecimal.ZERO;
        String cnt = String.valueOf(rtnList.size());
        try {
            log.debug("## Rptpath::" + Rptpath);
            file1 = new File(Rptpath);
            bw = EncodingHelper.getBufferedWriter(file1);

            //StringBuilder sumamt_builder = new StringBuilder();
            StringBuilder sb = new StringBuilder();
            //2�v���g�J
            for (int i = 0; i < rtnList.size(); i++) {
                Map tempMap = rtnList.get(i);
                bw.write(data2RptStr(tempMap, String.valueOf(i), sb));
                sumamt = sumamt.add(new BigDecimal(MapUtils.getString(tempMap, "SPR_AMT", "0")));
                //sumamt_builder.append(tempMap.get("SPR_AMT"));
            }
            //String sumamt = sumamt_builder.toString();
            //3.�̫�@�� = "CA11" + �`���B + ���� + 19��0 + 106�Ӫť�
            bw.write(new StringBuilder("CA11").append(STRING.fillZero("" + sumamt.intValue(), 12, EncodingHelper.DefaultCharset)).append(STRING.fillZero(cnt, 7, EncodingHelper.DefaultCharset))
                    .append(STRING.fillZero("", 19, EncodingHelper.DefaultCharset)).append(STRING.fillBlank("", 106, EncodingHelper.DefaultCharset)).toString());
            bw.flush();
            // [20200413]�R���{���X: �R��return file
        } finally {
            if (bw != null) {
                bw.close();
            }
        }

        // [20200413]�s�W�{���X:���Y�����αH�H
        String EVENT_ID = "EP_RA016";
        String PROGRAM = "EPC1_4030";
        String COMP_ID = new EP_B30010().getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);
        // �N�ɮ����Y�A�W�Ǩ�H�����
        Map zipOption = FieldOptionList.getName("EP", EVENT_ID + "_ZIP");
        File h2udir = new File(FileStoreUtil.getFTPH2URoot(), "/DBEP/C1/EPC1_4030/"); // �Ȧs���|
        if (!h2udir.exists()) {
            h2udir.mkdirs();
        }
        File zipFile = new File(h2udir, RCV_YM_ROC + MapUtils.getString(zipOption, "ZIP_FILE")); // �ɦW:{RCV_YM}����H�ذӰȥd
        String zipREMARK = MapUtils.getString(zipOption, "REMARK"); // �Ƶ�
        String zipFilePath = zipFile.getAbsolutePath();

        RZ_T0Z001 theRZ_T0Z001 = new RZ_T0Z001();
        Map uploadMap = theRZ_T0Z001.uploadFileForBatchByDiv(EVENT_ID, "zip", PROGRAM, PROGRAM, zipREMARK, zipFilePath, COMP_ID);

        // �z�L���ͤW�Ǫ����ɮ׸��|�A�N�ɮײM�����Y�A�é�ܤW�Ǫ��󪺥ؼ��ɮ׸��|
        CathayZipUtils.zipFile(file1, (File) uploadMap.get("targetFile"), MapUtils.getString(zipOption, "ZIP_WORD"));

        List<Map> recList;
        try {
            // �����
            List<DTEPZ103> rtnMailList;
            try {
                rtnMailList = new EP_Z10030().getMailList(SUB_CPY_ID, EVENT_ID).get(SUB_CPY_ID);
            } catch (DataNotFoundException dnfe) {
                throw new ModuleException(MessageUtil.getMessage("EP_C14030_MSG_010"));//�d�L����̳]�w
            }
            recList = new ArrayList<Map>();
            for (DTEPZ103 rtnMail : rtnMailList) {
                Map recMap = new HashMap();
                recMap.put("EVENT_ID", EVENT_ID);
                recMap.put("USER_ID", rtnMail.getID());
                recMap.put("USER_EMAIL", rtnMail.getEMAIL());
                recList.add(recMap);
            }

            String FILE_ID = MapUtils.getString(uploadMap, "FILE_ID");
            String[] fileIDs = new String[] { FILE_ID };
            //�H�󤺮e�G{RCV_YM} ����H�ذӰȥd \n ��ơG{CNT}�� \n ���B�G{AMT}��
            StringBuilder htmlSb = new StringBuilder();
            htmlSb.append("<html><head><meta http-equiv='Content-Type' content='text/html; charset=big5'></head>");
            htmlSb.append("<body><BR>");
            htmlSb.append(MessageUtil.getMessage("EP_C14030_MSG_011", new String[] { RCV_YM_ROC })).append("<BR>");
            htmlSb.append(MessageUtil.getMessage("EP_C14030_MSG_012", new String[] { STRING.commaFormatNumber(cnt) })).append("<BR>");
            htmlSb.append(MessageUtil.getMessage("EP_C14030_MSG_013", new String[] { STRING.commaFormatNumber(sumamt.toPlainString()) })).append("<BR>");
            htmlSb.append("<BR><BR>");
            //mailSender ���ҩ��ΰѼ�
            htmlSb.append("<INPUT type='hidden' id='").append(PROGRAM).append("' ");
            if (StringUtils.isNotBlank(DIV_NO)) {
                htmlSb.append(" DIV_NO='").append(DIV_NO).append("' ");
            }
            htmlSb.append(" RCV_YM='").append(RCV_YM).append("' ");
            htmlSb.append(" SUB_CPY_ID='").append(SUB_CPY_ID).append("' ");
            htmlSb.append(">");
            String mailContent = htmlSb.toString();
            //���ҥθ��:�n�J�H��
            String INPUT_ID = MapUtils.getString(reqMap, "INPUT_ID");
            String INPUT_DIV_NO = MapUtils.getString(reqMap, "INPUT_DIV_NO");
            String ERR_MSG = new RZ_S00300().createRecordByDIV(EVENT_ID, "EP", DATE.today(), recList, mailContent, fileIDs, COMP_ID, INPUT_DIV_NO, INPUT_ID, PROGRAM);
            if (StringUtils.isNotBlank(ERR_MSG)) {
                throw new ModuleException(ERR_MSG);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            //�L�צ��\�P�_�A�ұN����Ȧs�ɧR��,�קK�ɮפ@���d�bserver
            //txt��
            String FILE_ID = MapUtils.getString(uploadMap, "FILE_ID");
            theRZ_T0Z001.removeFileByDiv(FILE_ID, COMP_ID);
            //���Y��
            this.delFile(file1);
        }

    }

    /**
     * �M����������r��榡
     * @param tempMap
     * @param idx
     * @return
     * @throws ErrorInputException 
     */
    public String data2RptStr(Map tempMap, String idx, StringBuilder sb) throws ErrorInputException {
        ErrorInputException eie = null;
        if (tempMap == null) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_003")); //�����v���Map���i����
        }
        if (StringUtils.isBlank(idx)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_004")); //�y�������i����
        }
        if (eie != null) {
            throw eie;
        }

        if (sb != null) {
            sb.setLength(0);
        } else {
            sb = new StringBuilder();
        }
        sb.append("200113000 ");//�ө��N��:����10,��1~10�X
        sb.append(STRING.fillBlank(MapUtils.getString(tempMap, "CARD_NO"), 16, EncodingHelper.DefaultCharset));//�d��:����16, ��11~26�X
        sb.append(STRING.fillZero(idx, 10, EncodingHelper.DefaultCharset));//�y����:����10, ��27~36�X, �����0
        sb.append(STRING.fillBlank(DATE.toDate_yyyyMMdd(DATE.getDBDate()), 8, EncodingHelper.DefaultCharset));//���v��:����8,��37~44�X, �t�Τ��, yyyymmdd�榡
        StringBuilder sb2 = new StringBuilder();
        sb2.append(DATE.getROCYearAndMonth(DATE.toDate_yyyyMMdd(MapUtils.getString(tempMap, "PAY_S_DATE"))).substring(1));
        String BLD_NAME = MapUtils.getString(tempMap, "BLD_NAME", "") + MapUtils.getString(tempMap, "PAY_KIND_NAME", "");
        if (BLD_NAME.length() > 9) {
            String[] BLD_NAME_arr = BLD_NAME.split("�j��");
            BLD_NAME = "";
            for (String str : BLD_NAME_arr) {
                BLD_NAME = BLD_NAME + str;
            }
        }
        if (BLD_NAME.length() > 9) {
            BLD_NAME = BLD_NAME.substring(0, 9);
        }
        sb2.append(BLD_NAME);
        sb.append(STRING.fillBlank(sb2.toString(), 38, EncodingHelper.DefaultCharset));//�������:����38,��45~82�X,PAY_S_DATE�����~��yymm + BLD_NAME + PAY_KIND_NAME, �k��ɪť�
        sb.append(STRING.fillZero("" + new BigDecimal(MapUtils.getString(tempMap, "SPR_AMT", "0")).intValue(), 9, EncodingHelper.DefaultCharset));//������B:����9, ��83~91�X, �����0
        sb.append("00");//�i�f:����2, ��92~93�X
        sb.append(STRING.fillBlank(MapUtils.getString(tempMap, "CRT_NO"), 10, EncodingHelper.DefaultCharset));//DTEPC101�����N��:����10, ��94~103�X
        sb.append(STRING.fillBlank(MapUtils.getString(tempMap, "CUS_NO"), 1, EncodingHelper.DefaultCharset));//DTEPC101�Ȥ�Ǹ�:����1, ��104�X
        String inv_no = MapUtils.getString(tempMap, "INV_NO", "");
        inv_no = (StringUtils.isBlank(inv_no) || inv_no.length() < 10) ? inv_no : inv_no.substring(3, 10);
        sb.append(STRING.fillBlank(inv_no, 7, EncodingHelper.DefaultCharset));//DTEPC101�o�����X��7�X:����7, ��105~111�X
        sb.append(STRING.fillBlank(MapUtils.getString(tempMap, "PAY_KIND"), 1, EncodingHelper.DefaultCharset));//DTEPC101ú�ں���:����1, ��112�X
        sb.append(STRING.fillBlank("", 23, EncodingHelper.DefaultCharset));//23�ť�(�Ȧ�^�ǭ�) , ��113~135�X
        sb.append(STRING.fillBlank(DATE.toROCDate(MapUtils.getString(tempMap, "PAY_S_DATE")).substring(1), 6, EncodingHelper.DefaultCharset)); //DTEPC101ú�کl��,�������榡:����6, ��136~141�X
        sb.append(STRING.fillBlank(DATE.toROCDate(MapUtils.getString(tempMap, "PAY_E_DATE")).substring(1), 7, EncodingHelper.DefaultCharset)); //DTEPC101ú�ڲ״�,�������榡:����7, ��142~147�X
        //sb.append(" ");//1�ť�, ��148�X
        sb.append("\r\n");
        return sb.toString();

    }

    /**
     * ���o���~�T��
     * @param eie
     * @param msg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(msg);
        return eie;
    }

    /**
     * �ץX
     * @param BLD_CD        �j�ӥN��
     * @param SUB_CPY_ID    �����q�O
     * @param RCV_YM        �����~��
     * @param reqMap        �ץX���
     * @param resp
     * @throws Exception
     */
    public List<Map> export(Map reqMap, UserObject user, ResponseContext resp) throws Exception {
        ErrorInputException eie = null;
        if (reqMap == null) {
            throw this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_007"));//�d�߸�Ƥ��i����
        }
        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
        if (StringUtils.isBlank(RCV_YM)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14030_MSG_008")); //�����~�묰�������
        }
        if (eie != null) {
            throw eie;
        }

        FileOutputStream fileOutputString = null;
        try {
            //�ɦW
            String fileName = MapUtils.getString(reqMap, "fileName");

            //data 
            List<Map> dataList = this.queryList(reqMap);

            HSSFWorkbook workbook = new HSSFWorkbook();// �u�@��
            HSSFSheet sheet = workbook.createSheet(fileName);
            sheet.setMargin(HSSFSheet.TopMargin, (double) 0.2);//�o��O�^�T, ���Oexcel���]�w�O����
            sheet.setMargin(HSSFSheet.BottomMargin, (double) 0.2);
            sheet.setMargin(HSSFSheet.LeftMargin, (double) 0.16);
            sheet.setMargin(HSSFSheet.RightMargin, (double) 0.16);

            HSSFPrintSetup printset = sheet.getPrintSetup();
            printset.setLandscape(true);

            // �]�w���j�p
            getSheetColumnWidth(sheet);

            LocaleDisplay display = new LocaleDisplay("EP", user);
            //�g�J���Ӹ��
            createworkbook(workbook, sheet, dataList, MapUtils.getString(reqMap, "RCV_YM"), display);

            // ���ͼȦs��
            File downloadFile = RptUtils.createTempFile(fileName);

            // ��X excel �ɪ����|
            String path = downloadFile.getPath();
            fileOutputString = new FileOutputStream(path);
            workbook.write(fileOutputString);
            RptUtils.cryptoDownloadParameterToResp(fileName, downloadFile, resp);

            return dataList;
        } finally {
            if (fileOutputString != null) {
                fileOutputString.close();
            }
        }

    }

    /**
     * �]�w���j�p
     * @param sheet
     */
    private void getSheetColumnWidth(HSSFSheet sheet) {
        sheet.setColumnWidth(0, 86 * 32);//�ө��N��
        sheet.setColumnWidth(1, 135 * 32);//�d��
        sheet.setColumnWidth(2, 46 * 32);//�Ǹ�
        sheet.setColumnWidth(3, 70 * 32);//���ɤ�
        sheet.setColumnWidth(4, 192 * 32);//�b��W��
        sheet.setColumnWidth(5, 94 * 32);//���B
        sheet.setColumnWidth(6, 98 * 32);//�����N��
        sheet.setColumnWidth(7, 53 * 32);//�Ȥ�Ǹ�
        sheet.setColumnWidth(8, 95 * 32);//�o�����X
        sheet.setColumnWidth(9, 78 * 32);//ú�ں���
        sheet.setColumnWidth(10, 78 * 32);//ú�کl��
        sheet.setColumnWidth(11, 78 * 32);//ú�ڲ״�
    }

    /**
     * �]�w���
     * @param workbook
     * @param sheet
     * @param isNeedSub
     * @param rtnList
     * @throws ModuleException
     */
    private void createworkbook(HSSFWorkbook workbook, HSSFSheet sheet, List<Map> rtnList, String RCV_YM, LocaleDisplay display) throws ModuleException {

        //�]�wSTYLE
        HSSFCellStyle style0 = createStyle(workbook, 0, "�s�ө���", false);//���Y
        HSSFCellStyle style01 = createStyle(workbook, 1, "�s�ө���", false);//���Y
        HSSFCellStyle style1 = createStyle(workbook, 1, "�s�ө���", true);//�����Y
        HSSFCellStyle style2 = createStyle(workbook, 2, "�s�ө���", true);//���Ӥ�r
        HSSFCellStyle style3 = createStyle(workbook, 3, "�s�ө���", true);//���ӼƦr
        HSSFCellStyle style4 = createStyle(workbook, 4, "�s�ө���", true);//���Ӥ�r

        HSSFRow row;
        int beginRow = 0;
        int totalColumns = 12;

        //���D
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style0, 0, display.formatDateym(RCV_YM, "") + MessageUtil.getMessage("EPC1_4030_UI_TITLE")/*�H�Υd�дک���*/, false, true, beginRow, beginRow, 0, 9);
        setColumn(sheet, row, style01, 1, MessageUtil.getMessage("EPC1_4030_UI_PRI_DATE")/*�L�s���:*/
                + display.formatDate(DATE.today(), "/", ""),
            false, true, beginRow, beginRow, 10, 11);
        beginRow++;

        //���Y
        row = sheet.createRow(beginRow);
        setColumn(sheet, row, style1, 0, MessageUtil.getMessage("EPC1_4030_UI_019"), false, false, null, null, null, null);//�ө��N��
        setColumn(sheet, row, style1, 1, MessageUtil.getMessage("EPC1_4030_UI_016"), false, false, null, null, null, null);//�d��
        setColumn(sheet, row, style1, 2, MessageUtil.getMessage("EPC1_4030_UI_020"), false, false, null, null, null, null);//�Ǹ�
        setColumn(sheet, row, style1, 3, MessageUtil.getMessage("EPC1_4030_UI_021"), false, false, null, null, null, null);//���ɤ�
        setColumn(sheet, row, style1, 4, MessageUtil.getMessage("EPC1_4030_UI_022"), false, false, null, null, null, null);//�b��W��
        setColumn(sheet, row, style1, 5, MessageUtil.getMessage("EPC1_4030_UI_007"), false, false, null, null, null, null);//���B
        setColumn(sheet, row, style1, 6, MessageUtil.getMessage("EPC1_4030_UI_006"), false, false, null, null, null, null);//�����N��
        setColumn(sheet, row, style1, 7, MessageUtil.getMessage("EPC1_4030_UI_012"), false, false, null, null, null, null);//�Ȥ�Ǹ�
        setColumn(sheet, row, style1, 8, MessageUtil.getMessage("EPC1_4030_UI_013"), false, false, null, null, null, null);//�o�����X
        setColumn(sheet, row, style1, 9, MessageUtil.getMessage("EPC1_4030_UI_009"), false, false, null, null, null, null);//ú�ں���
        setColumn(sheet, row, style1, 10, MessageUtil.getMessage("EPC1_4030_UI_014"), false, false, null, null, null, null);//ú�کl��
        setColumn(sheet, row, style1, 11, MessageUtil.getMessage("EPC1_4030_UI_015"), false, false, null, null, null, null);//ú�ڲ״�

        beginRow++;

        //���Ӹ��(�t�X�p,�s�դp�p)
        createDetail(beginRow, sheet, row, style2, style3, style4, rtnList, totalColumns, display);

    }

    /**
     * �]�w���STYLE
     * @param workbook
     * @param type
     * @param font_type
     * @return
     */
    private HSSFCellStyle createStyle(HSSFWorkbook workbook, int type, String font_type, boolean hasBorder) {

        // Style
        HSSFCellStyle style = workbook.createCellStyle();

        //�r��
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12); // �j�p

        //�r���C��
        font.setColor(HSSFColor.BLACK.index);
        font.setFontName(font_type);

        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER); // �����m�� 
        if (type == 0) {//�j���Y
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            font.setFontHeightInPoints((short) 22); // �j�p         
        } else if (type == 1) {//�����D
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.BLACK.index);
            font.setColor(HSSFColor.BLACK.index);
        } else if (type == 2) {//���Ӥ�r
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        } else if (type == 3) {//���ӼƦr
            style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        } else if (type == 4) {//��r�a��
            style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        }

        style.setFont(font);

        //�~��
        if (hasBorder) {
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        }

        return style;
    }

    /**
     * �إߪ��椺�e
     * @param beginRow
     * @param sheet
     * @param row
     * @param style2
     * @param style3
     * @param isNeedSub �O�_�ݸs�դp�p
     * @param rtnList ���Ӹ��
     * @param totalColumns �C�C���
     * @throws ModuleException
     */
    private void createDetail(int beginRow, HSSFSheet sheet, HSSFRow row, HSSFCellStyle style2, HSSFCellStyle style3, HSSFCellStyle style4, List<Map> rtnList, int totalColumns, LocaleDisplay display) throws ModuleException {
        BigDecimal TOT_SPR_AMT = BigDecimal.ZERO;
        String today = display.formatDate(DATE.today(), "", "");

        for (int i = 0; i < rtnList.size(); i++) {
            Map<String, Object> rtnMap = rtnList.get(i);

            //���Ӹ�� style3
            row = sheet.createRow(beginRow);
            setColumn(sheet, row, style2, 0, "200113000", false, false, null, null, null, null);
            setColumn(sheet, row, style2, 1, MASK.getMaskPolicyNo(MapUtils.getString(rtnMap, "CARD_NO"), 5, 12), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 2, String.valueOf(i + 1), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 3, today, false, false, null, null, null, null);
            setColumn(sheet, row, style4, 4, MapUtils.getString(rtnMap, "BLD_NAME") + MapUtils.getString(rtnMap, "PAY_KIND_NAME"), false, false, null, null, null, null);
            setColumn(sheet, row, style3, 5, MapUtils.getString(rtnMap, "SPR_AMT"), true, false, null, null, null, null);
            setColumn(sheet, row, style2, 6, MapUtils.getString(rtnMap, "CRT_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 7, MapUtils.getString(rtnMap, "CUS_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 8, MapUtils.getString(rtnMap, "INV_NO"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 9, MapUtils.getString(rtnMap, "PAY_KIND_NAME"), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 10, display.formatDate((Date) rtnMap.get("PAY_S_DATE"), "", ""), false, false, null, null, null, null);
            setColumn(sheet, row, style2, 11, display.formatDate((Date) rtnMap.get("PAY_E_DATE"), "", ""), false, false, null, null, null, null);
            beginRow++;

            //�X�p�p��
            TOT_SPR_AMT = TOT_SPR_AMT.add(getBigDecimal(rtnMap.get("SPR_AMT"), BigDecimal.ZERO));

        }

        //�X�p
        row = sheet.createRow(beginRow);
        for (int j = 0; j < totalColumns; j++) {
            if (j == 0) {
                setColumn(sheet, row, style2, 0, MessageUtil.getMessage("EPC1_4030_UI_TOT"), false, false, null, null, null, null);//�X�p
            } else if (j == 2) {
                setColumn(sheet, row, style3, 2, String.valueOf(rtnList.size()), true, false, null, null, null, null);
            } else if (j == 5) {
                setColumn(sheet, row, style3, 5, TOT_SPR_AMT.toPlainString(), true, false, null, null, null, null);
            } else {
                setColumn(sheet, row, style2, j, null, false, false, null, null, null, null);//�®تŮ�
            }
        }

    }

    /**
     *  �]�w���
     * @param sheet
     * @param bodyRow
     * @param style ���A
     * @param columnNumber ���ͲĴX��cell
     * @param content  ���
     * @param isNumeric �O�_���Ʀr���
     * @param doCombine �O�_�ݦX���x�s��
     * @param firstRow
     * @param lastRow
     * @param firstCol
     * @param lastCol
     */
    private void setColumn(HSSFSheet sheet, HSSFRow bodyRow, HSSFCellStyle style, Integer columnNumber, String content, boolean isNumeric, boolean doCombine, Integer firstRow, Integer lastRow, Integer firstCol, Integer lastCol) {

        HSSFCell bodyCell;
        bodyCell = bodyRow.createCell(columnNumber);
        bodyCell.setCellStyle(style);

        if (doCombine) {
            for (int s = firstCol; s <= lastCol; s++) {
                bodyCell = bodyRow.createCell(s);
                bodyCell.setCellStyle(style);
            }

            //�X���x�s��
            CellRangeAddress range_inputCount = new CellRangeAddress(firstRow, lastRow, firstCol, lastCol);
            sheet.addMergedRegion(range_inputCount);

            bodyCell = bodyRow.getCell(firstCol);
        }

        if (isNumeric) {
            if (StringUtils.isNotBlank(content)) {
                bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                Double bodyText = new Double(content);
                bodyCell.setCellValue(bodyText);
            }
        } else {
            HSSFRichTextString text = new HSSFRichTextString(content);
            bodyCell.setCellValue(text);
        }
    }

    /**
     * �૬�A�M���w�]
     * 
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

    /**
     * �H�����ҩ���ˮּҲ�:���ҴC���ɪ��B�B���ƬO�_�P��Ʈw�d�ߵ��G�@�P
     * 2020/04/23
     * @param mailData
     * @throws Exception
     */
    public void validate4Rpt(String mailData) throws Exception {
        if (StringUtils.isBlank(mailData)) {
            throw new ModuleException("�S���ǤJ�Ѽ�");
        }
        //log.debug("#### mailData::" + mailData);

        String PROGRAM_ID = "EPC1_4030";
        Map mailMap = this.parseNDLPMail(mailData, PROGRAM_ID);

        String mailArticle = MapUtils.getString(mailMap, "mailArticle");
        File[] mailAttachments = (File[]) mailMap.get("mailAttachments");

        //�ѪR�H�󤺤�
        Element infoElement = this.getInfoElementByID(mailArticle, PROGRAM_ID);
        //�d��DB���
        Map qryMap = new HashMap();
        qryMap.put("RCV_YM", infoElement.attr("RCV_YM"));
        qryMap.put("DIV_NO", infoElement.attr("DIV_NO"));
        qryMap.put("SUB_CPY_ID", infoElement.attr("SUB_CPY_ID"));
        List<Map> dbList = this.queryList(qryMap);
        BigDecimal db_AMT = BigDecimal.ZERO;
        BigDecimal db_CNT = BigDecimal.ZERO;
        for (Map map : dbList) {
            db_AMT = db_AMT.add(STRING.objToBigDecimal(map.get("SPR_AMT"), BigDecimal.ZERO));
            db_CNT = db_CNT.add(BigDecimal.ONE);
        }

        //�ѪR����
        //1.�����Y
        String ZIP_WORD = FieldOptionList.getName("EP", "EP_RA016_ZIP", "ZIP_WORD"); //�K�X
        File[] dirFiles;
        try {
            dirFiles = this.unzipFile(mailAttachments[0], ZIP_WORD);
        } catch (Exception e) {
            log.error("�����Y����ZIP�ɵo�Ϳ��~", e);
            throw new ModuleException("�����Y����ZIP�ɵo�Ϳ��~");
        }
        if (dirFiles.length < 1) {
            throw new ModuleException("����ZIP�ɤ��L�ɮ�");
        }

        BigDecimal txt_AMT = BigDecimal.ZERO;//���Ӫ��B�[�`
        BigDecimal txt_CNT = BigDecimal.ZERO;//���ӵ���
        BigDecimal CA11_AMT = BigDecimal.ZERO;//�C���ɳ̫�@�� �`���B
        BigDecimal CA11_CNT = BigDecimal.ZERO;//�C���ɳ̫�@�� �`����

        //2.�ѪRtxt
        File txtFile = dirFiles[0];
        BufferedReader br = EncodingHelper.getBufferedReader(txtFile, "BIG5");
        try {
            String line = br.readLine();
            while (line != null) {
                //log.debug("## line::" + line);
                if (StringUtils.isBlank(line)) {
                    break;
                }
                if (line.startsWith("CA11")) {//�̫�@��
                    CA11_AMT = STRING.objToBigDecimal(STRING.subStringUtil(line, 5, 16, EncodingHelper.Charset_BIG5), BigDecimal.ZERO);//�`���B
                    CA11_CNT = STRING.objToBigDecimal(STRING.subStringUtil(line, 17, 23, EncodingHelper.Charset_BIG5), BigDecimal.ZERO);//�`����
                    break;
                }

                //�C�����
                txt_AMT = txt_AMT.add(STRING.objToBigDecimal(STRING.subStringUtil(line, 83, 91, EncodingHelper.Charset_BIG5), BigDecimal.ZERO));
                txt_CNT = txt_CNT.add(BigDecimal.ONE);

                line = br.readLine();
            }
        } finally {
            br.close();
        }

        log.debug("#### txt_CNT=" + txt_CNT + " ,db_CNT=" + db_CNT + " ,CA11_CNT=" + CA11_CNT);
        log.debug("#### txt_AMT=" + txt_AMT + " ,db_AMT=" + db_AMT + " ,CA11_AMT=" + CA11_AMT);

        //�ˮ�
        if (txt_CNT.compareTo(CA11_CNT) != 0 || txt_CNT.compareTo(db_CNT) != 0) {
            //api�L�k��ܦh��y�t
            throw new ModuleException("�C���ɵ��Ʀ��~(��Ʈw:" + db_CNT + "�A�C����:" + txt_CNT + "�A�C�����`�M:" + CA11_CNT + ")");//�C���ɵ��Ʀ��~(��Ʈw:{0}�A�C����:{1})
        }
        if (txt_AMT.compareTo(CA11_AMT) != 0 || txt_AMT.compareTo(db_AMT) != 0) {
            //api�L�k��ܦh��y�t
            throw new ModuleException("�C�����`���B���~(��Ʈw:" + db_AMT + "�A�C����:" + txt_AMT + "�A�C�����`�M:" + CA11_AMT + ")");//�C�����`���B���~(��Ʈw:{0}�A�C����:{1})
        }
    }

    /**
     * mailSender ���ҩ��:�ѪRNDLP�H��
     * (���ӥi�Ԧ@�μҲ�) //FIXME
     * @param mailData
     * @return
     * @throws Exception 
     */
    public Map parseNDLPMail(String mailData, String PROGRAM_ID) throws Exception {
        if (StringUtils.isBlank(mailData)) {
            throw new ModuleException("�S���ǤJ�Ѽ�");
        }

        StringBuilder sb = new StringBuilder();

        //NDLP�ഫ�Ȧs�ɸ��|: /data/ep/zz/mailSender/
        sb.append(File.separator).append("ep").append(File.separator).append("zz").append(File.separator).append("mailSender").append(File.separator);
        File tarFile = this.makeDir(FileStoreUtil.getSaveRoot().getPath(), sb.toString());
        String filePath = tarFile.getAbsolutePath() + File.separator;

        //NDLP�ഫ�Ȧs�ɮשR�W: [PROGRAM_ID]_NDLP_MAIL_[TimeStamp].eml
        sb.setLength(0);
        String currentTimeStamp = DATE.getDBTimeStamp().replace("-", "").replace(".", "");
        sb.append(PROGRAM_ID).append("_NDLP_MAIL_").append(currentTimeStamp).append(".eml");
        String fileNM = sb.toString();

        //�榡�ഫ( ByteArray to File )
        File mailFile = null;
        try {
            /**
             * �]Base64�b���P�@�~���ҡA���S���r��(�p�j�p��Ÿ�)��decode�٭�X�|���@�ǳ\���~�t�A
             * �y���٭�᪺eml�ɤ������A�榡�|�����D�A�]������t�η|���NFile�নString�A����URLDecoder.encode�ഫ�@���S���r���A
             * �A��Base64.encode�A�ഫ�@��(���X�r�[�K)��ǰe�i��
             */
            /** ===== �i�Ĥ@�h(�~�h)Base64 ��decode�j ===== */
            //Data�ǳ�: String to ByteArray
            byte[] file_bytearray = Base64.decode(mailData);
            log.debug("file_bytearray length: " + file_bytearray.length);

            /** ===== �i�ĤG�hURLDecoder ��decode�j ===== */
            //�٭�����ǿ�Ѽƪ��S���r��
            String file_decode = new String(file_bytearray, "Big5");
            file_decode = URLDecoder.decode(file_decode, "Big5");
            log.debug("file_decode length: " + file_decode.length());

            mailFile = new File(filePath, fileNM);
            //�R���P�ɦW��mail��(�p�G������)
            this.delFile(mailFile);

            //decode File String to File            
            FileUtils.writeStringToFile(mailFile, file_decode, "Big5");

        } catch (Exception e) {
            log.error("�ǤJ�ѤJ�榡�ഫ��eml File����!", e);
            throw new ModuleException("�ǤJ�ѤJ�榡�ഫ��eml File����!");
        } finally {
            if (mailFile != null) {
                log.debug("mailFile path: " + mailFile.getAbsolutePath());
            }
        }

        /**
         * ��:
         * NDLP�d�I�U�Ӫ��H��A�~���|�b�]�@�h�q���T���h�A����~�O�H�e����leml�ɡC
         */
        // [eml��] �� [MailContent ����] => NDLP�h
        MailParser theMailParser = new MailParser();
        MailContent NDLP_mailCont = theMailParser.parseMail(mailFile);

        //���o����(Original Mail��l�H�e�H��eml)
        File[] originalMail = NDLP_mailCont.getMailAttachments();
        log.debug("originalMail: " + originalMail.length);

        log.fatal("==== �}�l�ѪR��leml�� ====");
        // [eml��] �� [MailContent ����] => ���o�u��l�H�e�H�󤺮e�v
        MailContent original_mailCont = theMailParser.parseMail(originalMail[0]);

        //���omail����
        String mailArticle = original_mailCont.getMailArticle();
        mailArticle = URLDecoder.decode(mailArticle, EncodingHelper.serverEncoding); //�٭�����ǿ�Ѽƪ��S���r��
        log.debug("mailArticle=== " + mailArticle);

        //���omail����
        File[] mailAttachments = original_mailCont.getMailAttachments();

        Map rtnMap = new HashMap();
        rtnMap.put("NDLP_mailCont", NDLP_mailCont);
        rtnMap.put("originalMail", originalMail);
        rtnMap.put("mailArticle", mailArticle);
        rtnMap.put("mailAttachments", mailAttachments);

        return rtnMap;
    }

    /**
     * mailSender ���ҩ��:���o�H�󤺤媺input��� 
     * <INPUT id='[PROGRAM_ID]' ...>
     * (���ӥi�Ԧ@�μҲ�) //FIXME
     * @param mailArticle
     * @param pROGRAM_ID
     * @return
     * @throws ModuleException 
     */
    public Element getInfoElementByID(String mailArticle, String PROGRAM_ID) throws ModuleException {
        Document doc = Jsoup.parse(mailArticle);
        Elements inputElems = doc.select("input");

        Element infoElement = null;
        for (Element elem : inputElems) {
            infoElement = elem.getElementById(PROGRAM_ID);
            if (infoElement != null) {
                break;
            }
        }

        if (infoElement == null) {
            throw new ModuleException("�ѪR������o���ø�T���~!");
        }

        return infoElement;
    }

    /**
     * mailSender ���ҩ��:����zip�ɸ����Y
     * (���ӥi�Ԧ@�μҲ�)  //FIXME
     * @param inFile �n�����Y��ZIP��
     * @param password �����Y�K�X
     * @return �����Y�᪺�ɮװ}�C
     * @throws Exception 
     */
    public File[] unzipFile(File inFile, String password) throws Exception {
        //���oZIP���ɮצW��(�@����ظ�Ƨ��W�٥�)
        String inFileNM = FilenameUtils.getBaseName(inFile.getName());

        //���o�����Y�ت��a���|
        StringBuilder sb = new StringBuilder();
        File directoryFile;
        //�l�����
        //�g�ɸ��|: /data/ep/zz/mailSender/unzip/ + �l�����ZIP���ɮצW��
        sb.append(File.separator).append("ep").append(File.separator).append("zz").append(File.separator).append("mailSender").append(File.separator).append("unzip").append(File.separator).append(inFileNM).append(File.separator);
        directoryFile = this.makeDir(FileStoreUtil.getSaveRoot().getPath(), sb.toString());
        log.error("=== directoryFile: " + directoryFile);

        //�N���o���|�U�����e�P�ɦW���Ҧ��ɮײM��
        File[] dirFiles = directoryFile.listFiles();
        if (dirFiles != null) {
            for (File file : dirFiles) {
                try {
                    file.delete();
                } catch (Exception e) {
                    log.error("�R�������Y�ɸ�Ƨ�����Ƶo�Ϳ��~�A�ɮ׸��|: " + directoryFile.getPath(), e);
                    throw e;
                }
            }
        }

        //�����YZIP��
        //�l����󪺦��K�X
        CathayZipUtils.unZipFile(inFile, directoryFile, password);

        //���o�����Y��̷sFile�M��
        File[] newDirFiles = directoryFile.listFiles();
        return newDirFiles;
    }

    /**
     * �إ߸�Ƨ��A�Y���s�b�h�إ�
     * @param oldDir SERVER���|
     * @param folderName ��Ƨ��W��
     * @return String 
     */
    private File makeDir(String oldDir, String folderName) {
        // �إ߸�Ƨ�
        File targetFile = new File(oldDir, folderName);
        if (!targetFile.exists() && !targetFile.isDirectory()) { // �p��Ƨ����s�b�A�~�إ߸�Ƨ�
            targetFile.mkdirs();
        }
        return targetFile;
    }

    /**
     * �R�����e���L��eml��
     * @param mailFile
     */
    private void delFile(File file) {
        try {
            if (file.exists()) {
                file.delete();
                log.debug("=== do delete file: " + file.getAbsolutePath());
            }
        } catch (Exception e) {
            log.error("�R�ɿ��~���v�T!", e);
        }
    }

}
