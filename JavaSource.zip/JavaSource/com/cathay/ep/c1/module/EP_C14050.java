package com.cathay.ep.c1.module;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.util.FieldOptionList;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 *<pre> 
 * Date        Version  Description  Author
 * 2013/8/13   1.0      �s�W         �\�a�s
 * 
 * �@�B   �{���\�෧�n�����G
 * �{���\��    ������S���o�����X�d�߼Ҳ�
 * �{���W��    EP_C14050 
 * ���n����    �qDTEPC101_�����ɬd�X�L�o�����X���
 *</pre>
 * @author ���_��
 * @since 2013/9/23
 */

@SuppressWarnings("unchecked")
public class EP_C14050 {

    private static final String SQL_queryList_001 = "com.cathay.ep.c1.module.EP_C14050.SQL_queryList_001";

    /**
     * �d�������ɸ��
     * @param RCV_YM �����~��(�褸�~��)
     * @param DIV_NO �ӿ��O
     * @return
     * @throws ModuleException
     */
    public List<Map> queryList(BigDecimal RCV_YM, String DIV_NO,String SUB_CPY_ID) throws ModuleException {
        if(StringUtils.isBlank(SUB_CPY_ID)){
            throw new ErrorInputException(MessageUtil.getMessage("EPC2_2040_mod_MSG_001"));//�����q�O���������
        }
        
        
        DataSet ds = Transaction.getDataSet();

        if (RCV_YM != null) {
            ds.setField("RCV_YM", RCV_YM);
        }
        if (StringUtils.isNotBlank(DIV_NO)) {
            ds.setField("DIV_NO", DIV_NO);
        }

        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        List<Map> rtnList = VOTool.findToMaps(ds, SQL_queryList_001);
        
        for(Map mp : rtnList){
            String PAY_KIND_NM = FieldOptionList.getName("EPC", "PAY_KIND", MapUtils.getString(mp, "PAY_KIND"));
            if(StringUtils.isNotBlank(PAY_KIND_NM)){
                mp.put("PAY_KIND", PAY_KIND_NM);
            }
            String PAY_CD_NM = FieldOptionList.getName("EPC", "PAY_CD", MapUtils.getString(mp, "PAY_CD"));
            if(StringUtils.isNotBlank(PAY_CD_NM)){
                mp.put("PAY_CD", PAY_CD_NM);
            }
            String EXT_TYPE_NM = FieldOptionList.getName("EPC", "EXT_TYPE", MapUtils.getString(mp, "EXT_TYPE"));
            if(StringUtils.isNotBlank(EXT_TYPE_NM)){
                mp.put("EXT_TYPE", EXT_TYPE_NM);
            }
            String TAX_TYPE_NM = FieldOptionList.getName("EPC", "TAX_TYPE", MapUtils.getString(mp, "TAX_TYPE"));
            if(StringUtils.isNotBlank(PAY_KIND_NM)){
                mp.put("TAX_TYPE", TAX_TYPE_NM);
            }
            String TRN_KIND_NM = FieldOptionList.getName("EPC", "TRN_KIND_C101", MapUtils.getString(mp, "TRN_KIND"));
            if(StringUtils.isNotBlank(TRN_KIND_NM)){
                mp.put("TRN_KIND", TRN_KIND_NM);
            }
        }
        
        return rtnList;

    }

}
