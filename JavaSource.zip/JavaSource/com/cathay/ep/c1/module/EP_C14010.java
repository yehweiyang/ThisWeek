package com.cathay.ep.c1.module;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.hr.Employee;
import com.cathay.common.hr.PersonnelData;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LocaleDisplay;
import com.cathay.common.util.NumberUtils;
import com.cathay.common.util.db.DBUtil;
import com.cathay.db.impl.BatchQueryDataSet;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.CsvUtils;
import com.cathay.rpt.RptUtils;
import com.cathay.util.Transaction;
import com.cathay.util.jasper.JasperReportUtils;
import com.igsapp.db.DataSet;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date Version Description Author
 * 2013/7/10   1.0 �s�W  �\�a�s
 *  <pre>
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �ʦ����ӼҲ�
 * �{���W��    EP_C14010 
 * ���n����    �qDTEPC101_������, DTEPA101_�j�Ӱ򥻸����, DTEPC202_�o����, DTEPB102_�����Ȥ���, DTEPB101_�����D�ɾ�X�d�߸��
 *  </pre>
 *  
 * [20180307] �ק��
 * ��ءG�{�ɰ�����
 * 
 * @author �����@ 
 * @since 2014/1/3
 * 
 * 2019/07/15 �©s�� �s�W queryAllDuePayList ��k
 * 2020/04/14 AllenTsai ���D�渹20200331-0009 �վ�U��
 * 
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C14010 {

    private static final String SQL_queryList_001 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryList_001";

    private static final String SQL_queryList_002 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryList_002";

    private static final String SQL_queryList_003 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryList_003";

    private static final String SQL_queryList_004 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryList_004";

    private static final String SQL_queryList_005 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryList_005";

    private static final String SQL_queryForRpt1_001 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryForRpt1_001";

    private static final String SQL_queryForRpt2_001 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryForRpt2_001";

    private static final String SQL_queryForRpt2_002 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryForRpt2_002";

    private static final String SQL_queryForRpt2_003 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryForRpt2_003";

    private static final String SQL_queryForRpt2_004 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryForRpt2_004";

    private static final String SQL_queryAllDuePayList_001 = "com.cathay.ep.c1.module.EP_C14010.SQL_queryAllDuePayList_001";

    /**
     * �d�߶ʦ����Ӹ��
     * @param RCV_YM
     * @param PAY_KIND
     * @param CUS_STS
     * @param BLDUSRID
     * @param DIV_NO
     * @return
     * @throws ModuleException 
     */
    public List<Map> queryList(String SUB_CPY_ID, BigDecimal RCV_YM, String PAY_KIND, String CUS_STS, String BLDUSRID, String BLDUSRNM,
            String DIV_NO, String DCT_TYPE) throws ModuleException {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_027")); //�����q�O���������
        }
        if (StringUtils.isBlank(CUS_STS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_001")); //�Ȥ᪬�p���������
        }
        if ("0".equals(CUS_STS)) {// �Ȥ᪬�p=���`
            //�ˮ�RCV_YM, PAY_KIND������
            //            if (RCV_YM == null) {
            //                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_002")); //�ʦ��~�묰�������
            //            }
            if (StringUtils.isBlank(PAY_KIND)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_003")); //ú�ں������������
            }
        }
        if (eie != null) {
            throw eie;
        }
        //�D�n�qC101�����ɬd���
        List<Map> rtnList = new ArrayList<Map>();
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (null != RCV_YM) {
            ds.setField("RCV_YM", RCV_YM);
        }
        //setFieldIfExistandLike(ds, "DIV_NO", DIV_NO);
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ��d���
            setFieldIfExist(ds, "DIV_NO", DIV_NO);
        }
        setFieldIfExist(ds, "BLDUSRID", BLDUSRID);
        setFieldIfExist(ds, "DCT_TYPE", DCT_TYPE);
        if (StringUtils.isNotBlank(BLDUSRNM)) {
            ds.setField("BLDUSRNAME", "%" + BLDUSRNM + "%");
        }

        String sql;
        if ("0".equals(CUS_STS)) {// �Ȥ᪬�p=���`
            if ("1".equals(PAY_KIND)) {// ú�ں���=����(1)+��L(7)+����(6)
                ds.setField("PAY_KIND_1", "1");
                if (null == RCV_YM) {
                    ds.setField("RCV_YM2", new BigDecimal(DATE.getTodayYearAndMonth()));
                }
                sql = SQL_queryList_001;
                /*[20180307] �P�_����[�{�ɰ����� */
            } else if ("4".equals(PAY_KIND) || "5".equals(PAY_KIND) || "8".equals(PAY_KIND)) {// ú�ں���=�H����(4)�B����(5)�B�{�ɰ�����(8)
                ds.setField("PAY_KIND", PAY_KIND);
                if (null == RCV_YM) {
                    ds.setField("RCV_YM2", new BigDecimal(DATE.getTodayYearAndMonth()));
                }
                sql = SQL_queryList_001;
            } else {
                if ("2".equals(PAY_KIND)) {// ú�ں���=���(2)
                    ds.setField("PAY_KIND", "2");
                } else if ("3".equals(PAY_KIND)) {// ú�ں���=�޲z�O(3)
                    ds.setField("PAY_KIND", "3");
                    ds.setField("paykind2", 1);
                    ds.setField("paykind3", 1);
                    if (null == RCV_YM) {
                        ds.setField("RCV_YM2", new BigDecimal(DATE.getTodayYearAndMonth()));
                    }
                }
                sql = SQL_queryList_002;
            }
        } else if ("1".equals(CUS_STS)) {// �Ȥ᪬�p=�����`
            sql = SQL_queryList_003;
        } else if ("2".equals(CUS_STS)) {// �Ȥ᪬�p=�������ʤ�
            sql = SQL_queryList_004;
        } else { //if ("2".equals(CUS_STS)) {// �Ȥ᪬�p=�פ�
            sql = SQL_queryList_005;
        }

        DBUtil.searchAndRetrieve(ds, sql);
        while (ds.next()) {
            Map map = new HashMap();
            map = VOTool.dataSetToMap(ds);
            //�����ഫ
            map.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND_ONE", MapUtils.getString(map, "PAY_KIND")));
            map.put("CUS_STS_NM", FieldOptionList.getName("EPC", "CUS_STS_ONE", MapUtils.getString(map, "CUS_STS")));
            String PAY_CD_NM = FieldOptionList.getName("EPC", "PAY_CD", MapUtils.getString(map, "PAY_CD"));
            if (StringUtils.isNotBlank(PAY_CD_NM)) {
                map.put("PAY_CD", PAY_CD_NM);
            }
            map.put("DCT_TYPE_NM", FieldOptionList.getName("EP", "DCT_TYPE", MapUtils.getString(map, "DCT_TYPE")));
            rtnList.add(map);
        }

        return rtnList;

    }

    /**
     * �d�߶ʦ���C�L(01)�θ��
     * @param CRT_NO
     * @param CUS_NO
     * @param BLDUSRID
     * @param DIV_NO
     * @param RCV_YM
     * @return
     * @throws ModuleException
     */
    public List<Map> queryForRpt1(String SUB_CPY_ID, String CRT_NO, String CUS_NO, String BLDUSRID, String BLDUSRNM, String DIV_NO,
            BigDecimal RCV_YM) throws ModuleException {
        ErrorInputException eie = null;
        if (StringUtils.isBlank(DIV_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_004")); //�ӿ��O���������
        }
        //        if (null == RCV_YM) {
        //            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_005")); //�����~�묰�������
        //        }
        if ((StringUtils.isBlank(CRT_NO) && !StringUtils.isBlank(CUS_NO)) || (!StringUtils.isBlank(CRT_NO) && StringUtils.isBlank(CUS_NO))) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_006")); //�����s��/�Ȥ�N�����P�ɦ���
        }
        if (eie != null) {
            throw eie;
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ��d���
            setFieldIfExist(ds, "DIV_NO", DIV_NO);
        }
        if (RCV_YM != null) {
            ds.setField("RCV_YM", RCV_YM);
        }
        setFieldIfExist(ds, "BLDUSRID", BLDUSRID);
        if (StringUtils.isNotBlank(BLDUSRNM)) {
            ds.setField("BLDUSRNAME", "%" + BLDUSRNM + "%");
        }
        //setFieldIfExist(ds, "BLDUSRNAME", BLDUSRID);
        setFieldIfExist(ds, "CRT_NO", CRT_NO);
        setFieldIfExist(ds, "CUS_NO", CUS_NO);

        return VOTool.findToMaps(ds, SQL_queryForRpt1_001);
    }

    /**
     * ��z�ʦ���C�L(01)�����榡
     * @param BLDUS
     * @param CLCDV
     * @param RCV_YM
     * @param checkList
     * @return
     * @throws ModuleException
     */
    public Map doFmtRpt1(String SUB_CPY_ID, String BLDUS, String BLDUSRNM, String CLCDV, BigDecimal RCV_YM, List<Map> checkList)
            throws ModuleException {
        if (checkList == null) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C14010_MSG_008"));//�Ŀ�M�椣�i����
        }

        //�v���B�zcheckList�নrptlist
        List<Map> rptList = new ArrayList<Map>();
        if (0 == checkList.size()) {
            rptList = queryForRpt1(SUB_CPY_ID, null, null, BLDUS, BLDUSRNM, CLCDV, RCV_YM);
        } else {
            for (Map tempMap : checkList) {
                String CRT_NO = MapUtils.getString(tempMap, "CRT_NO");
                String CUS_NO = MapUtils.getString(tempMap, "CUS_NO");
                if (StringUtils.isBlank(CRT_NO) || StringUtils.isBlank(CUS_NO)) {
                    throw new ErrorInputException("EP_C14010_MSG_007");//�����s��,�Ȥ�Ǹ����Ҧ���, �нT�{��A�C�L
                }
                rptList.addAll(queryForRpt1(SUB_CPY_ID, CRT_NO, CUS_NO, BLDUS, BLDUSRNM, CLCDV, RCV_YM));
            }
        }
        //[20180326] �̤����q�O���o���q��T 
        Map COMP_INFO = FieldOptionList.getFieldOptions("EP", "COMP_INFO_" + SUB_CPY_ID);
        boolean isShow = new EP_Z00030().isAccountSubCpy(SUB_CPY_ID);

        DecimalFormat df = new DecimalFormat("#,##0.##");
        StringBuilder sb = new StringBuilder();
        Map TOTAL_Map = new HashMap();
        Map PAY_KIND_Map = new HashMap();
        Map PAY_S_DATE_Map = new HashMap();
        PersonnelData thePersonnelData = new PersonnelData();
        Map tmpTEL = new HashMap();
        for (Map map : rptList) {//���s��map
            String CRT_NO = MapUtils.getString(map, "CRT_NO");
            String CUS_NO = MapUtils.getString(map, "CUS_NO");
            String CRTNO_CUSNO = CRT_NO + CUS_NO;//�̷ӫ����N�� �Ȥ�Ǹ����@����key
            BigDecimal bdSPR_AMT = (BigDecimal) map.get("SPR_AMT");
            BigDecimal totalSPR_AMT = (BigDecimal) MapUtils.getObject(TOTAL_Map, CRTNO_CUSNO, BigDecimal.ZERO);
            TOTAL_Map.put(CRTNO_CUSNO, totalSPR_AMT.add(bdSPR_AMT));
            map.put("CRTNO_CUSNO", CRTNO_CUSNO);
            String PAY_S_DATE = MapUtils.getString(map, "PAY_S_DATE");
            if (StringUtils.isNotBlank(PAY_S_DATE)) {
                String ROC_PAY_S_DATE = DATE.formatToROCDate(MapUtils.getString(map, "PAY_S_DATE"));
                //EP_C14010_MSG_009  ����{0}�~{1}���
                int ROC_PAY_S_DATE_len = ROC_PAY_S_DATE.length();
                int year_loc = ROC_PAY_S_DATE_len - 4;
                map.put(
                    "PAY_S_DATE",
                    MessageUtil.getMessage("EP_C14010_MSG_009",
                        new Object[] { ROC_PAY_S_DATE.substring(0, year_loc), ROC_PAY_S_DATE.substring(year_loc, ROC_PAY_S_DATE_len - 2) }));
            } else {
                map.put("PAY_S_DATE", "");
            }
            map.put("CRTNO_CUSNO", CRTNO_CUSNO);

            String PAY_KIND = MapUtils.getString(map, "PAY_KIND");
            String PAY_KIND_NM = FieldOptionList.getName("EPC", "PAY_KIND_ONE", PAY_KIND);
            map.put("PAY_KIND", PAY_KIND_NM);
            sb.setLength(0);
            String tmpPAY_KIND = MapUtils.getString(PAY_KIND_Map, CRTNO_CUSNO, "");
            PAY_KIND_Map.put(CRTNO_CUSNO, (StringUtils.isBlank(tmpPAY_KIND)) ? PAY_KIND_NM : (tmpPAY_KIND.indexOf(PAY_KIND_NM) < 0 ? sb
                    .append(tmpPAY_KIND).append("�B").append(PAY_KIND_NM) : tmpPAY_KIND));//�ӫȤ��ú��ú�ں���

            //�����H�����_��
            if (PAY_KIND.equals("1")) {//�����~�n
                String tmpPAY_S_DATE = MapUtils.getString(PAY_S_DATE_Map, CRTNO_CUSNO, null);
                PAY_S_DATE_Map.put(CRTNO_CUSNO, (tmpPAY_S_DATE == null) ? PAY_S_DATE
                        : (DATE.diffDay(tmpPAY_S_DATE, PAY_S_DATE) > 0 ? tmpPAY_S_DATE : PAY_S_DATE));//TODO
            }

            //�ӿ�H���q��
            String ID = MapUtils.getString(map, "BLD_USR_ID");
            String TEL = MapUtils.getString(tmpTEL, ID);
            if (StringUtils.isEmpty(TEL)) {
                Employee emp;
                try {
                    emp = thePersonnelData.getByEmployeeID(ID, true);
                } catch (Exception e) {
                    emp = null;
                }
                TEL = (emp == null) ? " " : emp.getInstitutionPhone3();
                map.put("BLD_USR_TEL", TEL);
            } else {
                map.put("BLD_USR_TEL", TEL);
            }
            //[20180326] ���q�W��, ���q�W��-���, ���q�a�}-�l���ϸ�, ���q�a�} 
            map.put("COMP_NAME", MapUtils.getString(COMP_INFO, "COMP_NAME"));
            map.put("COMP_DIV", MapUtils.getString(COMP_INFO, "COMP_DIV"));
            map.put("COMP_ZIP_CODE", MapUtils.getString(COMP_INFO, "COMP_ZIP_CODE"));
            map.put("COMP_ADDR", MapUtils.getString(COMP_INFO, "COMP_ADDR"));
            map.put("isShow", isShow);
        }
        for (Map rtnMap : rptList) {
            String CRT_NO = MapUtils.getString(rtnMap, "CRT_NO");
            String CUS_NO = MapUtils.getString(rtnMap, "CUS_NO");
            String CRTNO_CUSNO = CRT_NO + CUS_NO;
            for (Object every_key : rtnMap.keySet()) {
                Object obj = MapUtils.getObject(rtnMap, every_key, "");
                if (BigDecimal.class.isInstance(obj)) {
                    rtnMap.put(every_key, "NT$" + (df.format(obj)).toString());
                } else if ("ROOM_NO FLD_NO PRK_NO".indexOf((String) every_key) >= 0) {
                    if (StringUtils.isNotBlank(obj.toString())) {
                        rtnMap.put(every_key, obj.toString() + MessageUtil.getMessage("EP_C14010_MSG_" + every_key));
                    } else {
                        rtnMap.put(every_key, "");
                    }
                } else {
                    rtnMap.put(every_key, obj.toString());
                }
            }
            rtnMap.put("SUB_SPR_AMT", "NT$" + df.format(TOTAL_Map.get(CRTNO_CUSNO)));
            rtnMap.put("ALL_PAY_KIND", PAY_KIND_Map.get(CRTNO_CUSNO).toString());
            if (StringUtils.isNotBlank(MapUtils.getString(PAY_S_DATE_Map, CRTNO_CUSNO))) {
                String ROC_PAY_S_DATE = DATE.formatToROCDate(MapUtils.getString(PAY_S_DATE_Map, CRTNO_CUSNO));
                int ROC_PAY_S_DATE_len = ROC_PAY_S_DATE.length();
                int year_loc = ROC_PAY_S_DATE_len - 4;
                int month_loc = ROC_PAY_S_DATE_len - 2;
                rtnMap.put(
                    "MIN_PAY_S_DATE",
                    MessageUtil.getMessage(
                        "EP_C14010_MSG_010",
                        new Object[] { ROC_PAY_S_DATE.substring(0, year_loc), ROC_PAY_S_DATE.substring(year_loc, month_loc),
                                ROC_PAY_S_DATE.substring(month_loc, ROC_PAY_S_DATE_len) }));
            }
        }

        String CurrentDate = DATE.getROCDate();
        Map map = new HashMap();
        //���o�����榡���
        Map param = new HashMap();
        /*-----------------------�զ��������--------------------------*/
        String PRINT_DATE = MessageUtil.getMessage(
            "EP_C14010_MSG_010",
            new Object[] { CurrentDate.substring(0, CurrentDate.length() - 4),
                    CurrentDate.substring(CurrentDate.length() - 4, CurrentDate.length() - 2),
                    CurrentDate.substring(CurrentDate.length() - 2) });//{0}�~{1}��{2}��
        param.put("PRINT_DATE", PRINT_DATE);

        param.put("REPORT_ID", "EP_C14010_01");
        map.put("params", param);
        map.put("detail", rptList);
        return map;
    }

    /**
     * �C�L�ʦ����k
     * @param reqMap
     * @param resp
     * @throws ModuleException 
     */
    public void prtRpt1(Map reqMap, ResponseContext resp) throws ModuleException {
        //JasperReportUtils.addOutputRptDataToResp("EP_C14010_01", (Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), resp);

        String fileName = new StringBuilder().append("OVERDUEPAYMENT_").append(DATE.getROCDate()).append(".pdf").toString();

        String createFileFullPath = RptUtils.createTempFile(fileName).getAbsolutePath();
        try {
            new RptUtils().createPDFFile((Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), createFileFullPath);
        } catch (Exception e) {
            throw new ModuleException("���ͦ���PDF����:" + e.getMessage());
        }
        try {
            RptUtils.cryptoDownloadParameterToResp(fileName, createFileFullPath, resp);
        } catch (Exception e) {
            throw new ModuleException("�^�ǥ[�K��������|�o�Ϳ��~:" + e.getMessage());
        }
    }

    /**
     * �d�߳����L�s(02)�θ��
     * @param CUS_STS
     * @param PAY_KIND
     * @param RCV_YM
     * @param BLDUSRID
     * @param DIV_NO
     * @return
     * @throws ModuleException
     */
    public List<Map> queryForRpt2(String SUB_CPY_ID, String CUS_STS, String PAY_KIND, BigDecimal RCV_YM, String BLDUSRID, String BLDUSRNM,
            String DIV_NO) throws ModuleException {
        ErrorInputException eie = null;

        if (StringUtils.isBlank(CUS_STS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_001")); //�Ȥ᪬�p��������� 
        }
        if (StringUtils.isBlank(DIV_NO)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_004")); //�ӿ��O���������
        }
        if ("0".equals(CUS_STS)) {// �Ȥ᪬�p=���`
            //            if (RCV_YM == null) {
            //                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_002")); //�ʦ��~�묰�������
            //            }
            if (StringUtils.isBlank(PAY_KIND)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_003")); //ú�ں������������
            }
        }
        if (eie != null) {
            throw eie;
        }

        List<Map> rtnList;
        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);
        if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ��d���
            setFieldIfExist(ds, "DIV_NO", DIV_NO);
        }
        setFieldIfExist(ds, "BLDUSRID", BLDUSRID);
        if (StringUtils.isNotBlank(BLDUSRNM)) {
            ds.setField("BLDUSRNAME", "%" + BLDUSRNM + "%");
        }
        //setFieldIfExist(ds, "BLDUSRNAME", BLDUSRID);
        if ("0".equals(CUS_STS)) {// �Ȥ᪬�p=���`
            if (RCV_YM != null) {
                ds.setField("RCV_YM", RCV_YM);
            }
            if ("1".equals(PAY_KIND)) {// ú�ں���=����(1)+��L(7)+����(6)
                if (RCV_YM == null) {
                    ds.setField("RCV_YM2", new BigDecimal(DATE.getTodayYearAndMonth()));
                }
                ds.setField("PAY_KIND_1", "1");
                rtnList = VOTool.findToMaps(ds, SQL_queryForRpt2_001);
                /*[20180307] �P�_����[�{�ɰ����� */
            } else if ("4".equals(PAY_KIND) || "5".equals(PAY_KIND) || "8".equals(PAY_KIND)) {// ú�ں���=�H����(4)�B����(5)�B�{�ɰ�����(8)
                if (RCV_YM == null) {
                    ds.setField("RCV_YM2", new BigDecimal(DATE.getTodayYearAndMonth()));
                }
                ds.setField("PAY_KIND", PAY_KIND);
                rtnList = VOTool.findToMaps(ds, SQL_queryForRpt2_001);
            } else if ("2".equals(PAY_KIND)) { //���(2)
                rtnList = VOTool.findToMaps(ds, SQL_queryForRpt2_002);
            } else {//if ("3".equals(PAY_KIND)) { //�޲z�O(3)
                if (RCV_YM == null) {
                    ds.setField("RCV_YM2", new BigDecimal(DATE.getTodayYearAndMonth()));
                }
                rtnList = VOTool.findToMaps(ds, SQL_queryForRpt2_003);
            }
        } else {// CUS_STS ==��1��(�����`),��2��(���ʤ�)
            ds.setField("CUS_STS", CUS_STS);
            rtnList = VOTool.findToMaps(ds, SQL_queryForRpt2_004);
        }

        return rtnList;
    }

    /**
     * ��z�����L�s(02)�������榡
     * @param RPT_TYPE   String  �����榡
     *                  <PRE>
     *                  1:��ú���Ӫ�
     *                  2:�ʦ����Ӫ�
     *                  3:�b�b���Ӫ�
     *                  </PRE>
     * @param rptList   List<Map>   �������e���
     * @param PAY_KIND  String  ú�ں���
     * @param user
     * @return
     * @throws ModuleException
     */
    public Map doFmtRpt2(String RPT_TYPE, List<Map> rptList, String PAY_KIND, UserObject user, boolean defaultYM) throws ModuleException {

        LocaleDisplay locale = new LocaleDisplay("EP", user);

        String currentDate = DATE.getDBDate();
        if (defaultYM) {
            currentDate = DATE.getLastMonthLastDate();
        }

        BigDecimal totalSPR_AMT = BigDecimal.ZERO;
        StringBuilder sb = new StringBuilder();
        boolean RPT_TYPE_1 = "1".equals(RPT_TYPE);
        Integer maxRCV_YM = 0;
        for (int i = 0; i < rptList.size(); i++) {
            Map map = rptList.get(i);
            Integer intRCV_YM = MapUtils.getInteger(map, "RCV_YM", 0);
            if (intRCV_YM > maxRCV_YM) {
                maxRCV_YM = intRCV_YM;
            }
            for (Object key : map.keySet()) {
                if (map.get(key) == null) {
                    map.put(key, "");
                } else if ("SPR_AMT".equals(key)) {
                    BigDecimal bdSPR_AMT = getBigDecimal(map.get("SPR_AMT"));
                    totalSPR_AMT = totalSPR_AMT.add(bdSPR_AMT);
                    map.put("SPR_AMT", locale.formatNumber(bdSPR_AMT, 2, ""));

                } else if ("CUS_NO".equals(key)) {
                    map.put(key, MapUtils.getString(map, key, ""));
                }

            }

            String VALUE7;
            if (RPT_TYPE_1) {
                sb.setLength(0);
                VALUE7 = sb.append(str2LocaleDate(map, "PAY_S_DATE".toString(), locale)).append('~')
                        .append(str2LocaleDate(map, "PAY_E_DATE".toString(), locale)).toString();
            } else {
                VALUE7 = intRCV_YM.toString();
                map.put("VALUE12", str2LocaleDate(map, "TURN_ACNT_DATE".toString(), locale));
                map.put("VALUE13", str2LocaleDate(map, "TURN_ACNT_DATE".toString(), locale));
                map.put("VALUE14", str2LocaleDate(map, "BDEBT_ACNT_DATE".toString(), locale));
            }
            map.put("PAY_KIND", FieldOptionList.getName("EPC", "PAY_KIND_ONE", PAY_KIND));
            map.put("VALUE7", VALUE7);

        }
        //�]�w���Y
        String HEADER = "";
        String TITLE7 = "";
        String TITLE12 = "";
        String TITLE13 = "";
        String TITLE14 = "";
        if (RPT_TYPE_1) {
            String YYYYMM = locale.formatDateym(maxRCV_YM, "");
            int len = YYYYMM.length();
            String mon = YYYYMM.substring(len - 2, len);
            String year = YYYYMM.substring(0, len - 2);
            sb.setLength(0);
            String maxRCV_YM_NM = MessageUtil.getMessage("EP_C14010_MSG_011", new Object[] { year, mon });
            PAY_KIND = FieldOptionList.getName("EPC", "PAY_KIND_ONE", PAY_KIND);
            String Current_date = MessageUtil.getMessage("EP_C14010_MSG_010", new Object[] { locale.formatDatey(currentDate, ""),
                    currentDate.split("-")[1], currentDate.split("-")[2] });
            HEADER = MessageUtil.getMessage("EP_C14010_MSG_012", new Object[] { maxRCV_YM_NM, PAY_KIND, Current_date });//{0}{1}�֭p��{2} ��ú���Ӫ�
            TITLE7 = MessageUtil.getMessage("EP_C14010_MSG_013");//�n������
            TITLE12 = MessageUtil.getMessage("EP_C14010_MSG_014");//�w�o��ú��
            TITLE13 = MessageUtil.getMessage("EP_C14010_MSG_015");//�w�o�פ��
            TITLE14 = MessageUtil.getMessage("EP_C14010_MSG_016");//��������]
        } else if ("2".equals(RPT_TYPE)) {
            HEADER = MessageUtil.getMessage("EP_C14010_MSG_017");//��ʦ��ڶ����Ӫ�
            TITLE7 = MessageUtil.getMessage("EP_C14010_MSG_018");//�����~��
            TITLE12 = MessageUtil.getMessage("EP_C14010_MSG_019");//�J�b�ǲ���
            TITLE13 = MessageUtil.getMessage("EP_C14010_MSG_020");//��ʦ���
            TITLE14 = MessageUtil.getMessage("EP_C14010_MSG_021");//��b�b��
        } else if ("3".equals(RPT_TYPE)) {
            HEADER = MessageUtil.getMessage("EP_C14010_MSG_022");//��Ʃ�b�b���Ӫ�
            TITLE7 = MessageUtil.getMessage("EP_C14010_MSG_023");//�����~��
            TITLE12 = MessageUtil.getMessage("EP_C14010_MSG_024");//�J�b�ǲ���
            TITLE13 = MessageUtil.getMessage("EP_C14010_MSG_025");//��ʦ���
            TITLE14 = MessageUtil.getMessage("EP_C14010_MSG_026");//��b�b��
        }
        Map map = new HashMap();
        //���o�����榡���
        Map param = new HashMap();
        /*-----------------------�զ��������--------------------------*/
        param.put("HEADER", HEADER);
        param.put("TITLE7", TITLE7);
        param.put("TITLE12", TITLE12);
        param.put("TITLE13", TITLE13);
        param.put("TITLE14", TITLE14);
        param.put("PRINT_DATE", locale.formatDate(DATE.today(), "/", ""));
        param.put("REPORT_ID", "EP_C14010_02");
        param.put("totalSPR_AMT", locale.formatNumber(totalSPR_AMT, 2, ""));
        param.put("RPT_TYPE", RPT_TYPE);

        map.put("params", param);
        map.put("detail", rptList);
        return map;
    }

    /**
     * ��z�����L�s(03)�������榡
     * @param CUS_STS
     * @param PAY_KIND
     * @param RCV_YM
     * @param BLDUS
     * @param CLCDV
     * @return
     * @throws ModuleException
     */
    public Map doFmtRpt22(String SUB_CPY_ID, String CUS_STS, String PAY_KIND, BigDecimal RCV_YM, String BLDUS, String BLDUSRNM,
            String CLCDV, UserObject user) throws ModuleException {

        List<Map> rptList = queryForRpt2(SUB_CPY_ID, CUS_STS, PAY_KIND, RCV_YM, BLDUS, BLDUSRNM, CLCDV);

        LocaleDisplay locale = new LocaleDisplay("EP", user);
        StringBuilder sb = new StringBuilder();
        String currentDate = DATE.getDBDate();
        String currentDateChinese = MessageUtil.getMessage("EP_C14010_MSG_010", new Object[] { locale.formatDatey(currentDate, ""),
                currentDate.split("-")[1], currentDate.split("-")[2] });//{0}�~{1}��{2}��
        sb.setLength(0);
        BigDecimal totalRNT_AMT = BigDecimal.ZERO;
        for (int i = 0; i < rptList.size(); i++) {
            Map map = rptList.get(i);
            for (Object key : map.keySet()) {
                if (MapUtils.getObject(map, key) == null) {
                    map.put(key, "");
                } else if ("CUS_NO".equals(key)) {
                    map.put("CUS_NO", String.valueOf((Integer) map.get("CUS_NO")));
                } else if ("RNT_AMT".equals(key)) {
                    BigDecimal bdRNT_AMT = (BigDecimal) map.get("RNT_AMT");
                    totalRNT_AMT = totalRNT_AMT.add(bdRNT_AMT);
                    map.put("RNT_AMT", locale.formatNumber(bdRNT_AMT, 2, ""));
                } else if ("NEXT_PAY_DATE".equals(key)) {
                    map.put(key, MapUtils.getString(map, key, ""));
                } else if ("PAY_FREQ".equals(key)) {
                    map.put("PAY_FREQ", FieldOptionList.getName("EPC", "PAY_FREQ", MapUtils.getString(map, "PAY_FREQ")));
                }
            }
            map.put("CUS_STS", FieldOptionList.getName("EPC", "CUS_STS_ONE", CUS_STS));
            map.put("Current_date", currentDateChinese);
        }

        Map map = new HashMap();
        //���o�����榡���
        Map param = new HashMap();
        /*-----------------------�զ��������--------------------------*/
        param.put("PRINT_DATE", locale.formatDate(Date.valueOf(currentDate), "/", ""));
        param.put("REPORT_ID", "EP_C14010_03");
        param.put("totalRNT_AMT", locale.formatNumber(totalRNT_AMT, 2, ""));
        map.put("params", param);
        map.put("detail", rptList);
        return map;
    }

    /**
     * �����L�s��k(���`)
     * @param reqMap
     * @param resp
     * @param req
     */
    public void prtRpt2(Map reqMap, ResponseContext resp, RequestContext req) {
        List<Map> detail = (List<Map>) reqMap.get("detail");
        Map params = (Map) reqMap.get("params");
        int datasize = detail.size();
        int page_size = 25;
        int commit_size = page_size * 4; //�@��100���i�H�ݨD���ܵ���  �L4��
        int Times = ((datasize - 1) / commit_size) + 1;//����PDF����
        //�UPDF�Ѽ�
        String reportIds[] = new String[Times];
        Map inputParams[][] = new Map[Times][];
        List inputDetailLists[][] = new List[Times][];
        for (int i = 1; i <= Times; i++) {
            reportIds[i - 1] = "EP_C14010_02";
            inputParams[i - 1] = new Map[] { params };
            int initS = (i - 1) * commit_size;
            int initE = (i == Times) ? datasize : i * commit_size;
            List<Map> details = new ArrayList<Map>();//�C����LIST���
            for (int j = initS; j < initE; j++) {
                Map map = (Map) detail.get(j);
                //�C������
                map.put("PAGE_C", String.valueOf(j / page_size + 1));
                //�̫�@���ݦX�p
                map.put("PRINT_SUM", (i == Times) ? "Y" : "N");
                //�C���̫�@������
                map.put("END", (j == initE - 1) ? "Y" : "N");
                map.put("CNT", String.valueOf(j + 1));
                details.add(map);
            }
            inputDetailLists[i - 1] = new List[] { details };
        }
        JasperReportUtils.addOutputRptDataToResp(reportIds, inputParams, inputDetailLists, req, resp);
    }

    /**
     * �����L�s��k(�����`,���ʤ�)
     * @param reqMap
     * @param resp
     * @return
     */
    public void prtRpt22(Map reqMap, ResponseContext resp) {
        JasperReportUtils.addOutputRptDataToResp("EP_C14010_03", (Map) reqMap.get("params"), (List<Map>) reqMap.get("detail"), resp);
    }

    /**
     * �ץXcsv
     * @param reqMap
     * @throws Exception 
     */
    public List<Map> queryByAllforExcel(String SUB_CPY_ID, BigDecimal RCV_YM, String PAY_KIND, String CUS_STS, String BLDUSRID,
            String BLDUSRNM, String DIV_NO, String DCT_TYPE, Map reqMap, ResponseContext resp, UserObject user) throws Exception {

        ErrorInputException eie = null;
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_027")); //�����q�O���������
        }
        if (StringUtils.isBlank(CUS_STS)) {
            eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_001")); //�Ȥ᪬�p���������
        }

        if ("0".equals(CUS_STS)) {// �Ȥ᪬�p=���`
            //�ˮ�RCV_YM, PAY_KIND������
            //            if (RCV_YM == null) {
            //                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_002")); //�ʦ��~�묰�������
            //            }
            if (StringUtils.isBlank(PAY_KIND)) {
                eie = this.getErrorInputException(eie, MessageUtil.getMessage("EP_C14010_MSG_003")); //ú�ں������������
            }
        }
        if (eie != null) {
            throw eie;
        }

        String fileName = MapUtils.getString(reqMap, "fileName");

        BatchQueryDataSet bqds = Transaction.getBatchQueryDataSet();
        LocaleDisplay ld = new LocaleDisplay("EP", user);
        try {
            CsvUtils csvUtils = new CsvUtils(fileName, resp);
            // ���o���Y�θ��(JSON)
            //csvUtils.initBatchExportSetting(gridJSON);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            if (null != RCV_YM) {
                bqds.setField("RCV_YM", RCV_YM);
            }
            //setFieldIfExistandLike(bqds, "DIV_NO", DIV_NO);
            if (new EP_Z00030().isAccountSubCpy(SUB_CPY_ID)) {//��ؤ��d���
                setFieldIfExist(bqds, "DIV_NO", DIV_NO);
            }
            setFieldIfExist(bqds, "BLDUSRID", BLDUSRID);
            setFieldIfExist(bqds, "DCT_TYPE", DCT_TYPE);
            if (StringUtils.isNotBlank(BLDUSRNM)) {
                bqds.setField("BLDUSRNAME", "%" + BLDUSRNM + "%");
            }
            //setFieldIfExist(bqds, "BLDUSRNAME", BLDUSRID);
            if ("0".equals(CUS_STS)) {// �Ȥ᪬�p=���`
                
            	if("A".equals(PAY_KIND)) {
                    if (RCV_YM == null) {        	
                    	BigDecimal rcvYM2 =  new BigDecimal(DATE.getTodayYearAndMonth());
                        //�p�GRCV_YM�S��J
                    	bqds.setField("RCV_YM2", rcvYM2);
                        //��������� �����~��
                    	bqds.setField("PAY_KIND_2", "2");                    	
                    } else {
                    	bqds.setField("RCV_YM", RCV_YM);
                    }
                    this.setFieldIfExist(bqds, "CLCDV", reqMap);//�ӿ���
                    this.setFieldIfExist(bqds, "BLDUS", reqMap);//�j�Ӹg��ID
                    this.setFieldIfExistandLike(bqds, "BLDUSNM", reqMap);//�j�Ӹg��m�W�ҽk�d��
                    this.setFieldIfExist(bqds, "DCT_TYPE", reqMap);//���ڤ覡
                    bqds.searchAndRetrieve(SQL_queryAllDuePayList_001);

            	} else if ("1".equals(PAY_KIND)) {// ú�ں���=����(1)+��L(7)+����(6)
                    if (null == RCV_YM) {
                        bqds.setField("RCV_YM2", new BigDecimal(DATE.getTodayYearAndMonth()));
                    }
                    bqds.setField("PAY_KIND_1", "1");
                    bqds.searchAndRetrieve(SQL_queryList_001);
                } else if ("4".equals(PAY_KIND) || "5".equals(PAY_KIND) || "8".equals(PAY_KIND)) {// ú�ں���=�H����(4)�B����(5)
                    bqds.setField("PAY_KIND", PAY_KIND);
                    if (null == RCV_YM) {
                        bqds.setField("RCV_YM2", new BigDecimal(DATE.getTodayYearAndMonth()));
                    }
                    bqds.searchAndRetrieve(SQL_queryList_001);
                } else {
                    if ("2".equals(PAY_KIND)) {// ú�ں���=���(2)
                        bqds.setField("PAY_KIND", "2");
                    } else if ("3".equals(PAY_KIND)) {// ú�ں���=�޲z�O(3)
                        bqds.setField("PAY_KIND", "3");
                        bqds.setField("paykind2", 1);
                        bqds.setField("paykind3", 1);
                        if (null == RCV_YM) {
                            bqds.setField("RCV_YM2", new BigDecimal(DATE.getTodayYearAndMonth()));
                        }
                    }
                    bqds.searchAndRetrieve(SQL_queryList_002);
                }
            } else if ("1".equals(CUS_STS)) {// �Ȥ᪬�p=�����`
                bqds.searchAndRetrieve(SQL_queryList_003);
            } else if ("2".equals(CUS_STS)) {// �Ȥ᪬�p=�������ʤ�
                bqds.searchAndRetrieve(SQL_queryList_004);
            }

            if ("0".equals(CUS_STS)) {
                String[] title = new String[] { MessageUtil.getMessage("EPC1_4010_UI_012")/*�����~��*/,
                        MessageUtil.getMessage("EPC1_4010_UI_013")/*�j�ӥN��*/, MessageUtil.getMessage("EPC1_4010_UI_014")/*�j�ӦW��*/,
                        MessageUtil.getMessage("EPC1_4010_UI_015")/*�Ӽh*/, MessageUtil.getMessage("EPC1_4010_UI_016")/*�ǧO*/,
                        MessageUtil.getMessage("EPC1_4010_UI_017")/*����*/, MessageUtil.getMessage("EPC1_4010_UI_018")/*�����N��*/,
                        MessageUtil.getMessage("EPC1_4010_UI_019")/*�Ǹ�*/, MessageUtil.getMessage("EPC1_4010_UI_020")/*�Ȥ�W��*/,
                        MessageUtil.getMessage("EPC1_4010_UI_021")/*ú�کl��*/, MessageUtil.getMessage("EPC1_4010_UI_022")/*ú�ڲ״�*/,
                        MessageUtil.getMessage("EPC1_4010_UI_023")/*ú�ں���*/, MessageUtil.getMessage("EPC1_4010_UI_024")/*�����l�B*/,
                        MessageUtil.getMessage("EPC1_4010_UI_025")/*�o�����X*/, MessageUtil.getMessage("EPC1_4010_UI_026") /*�j�Ӹg��*/,
                        MessageUtil.getMessage("EPC1_4010_UI_027") /*�Ȥ᪬�p*/, MessageUtil.getMessage("EPC1_4010_UI_040") /*���ڤ覡*/};

                String[] template = new String[] { "RCV_YM", "BLD_CD", "BLD_NAME", "FLD_NO", "ROOM_NO", "PRK_NO", "CRT_NO", "CUS_NO",
                        "CUS_NAME", "PAY_S_DATE", "PAY_E_DATE", "PAY_KIND_NM", "SPR_AMT", "INV_NO", "BLD_USR_NAME", "PAY_CD", "DCT_TYPE_NM" };
                csvUtils.initBatchExportSetting(title, template);
            } else {
                String[] title = new String[] { MessageUtil.getMessage("EPC1_4010_UI_013")/*�j�ӥN��*/,
                        MessageUtil.getMessage("EPC1_4010_UI_014")/*�j�ӦW��*/, MessageUtil.getMessage("EPC1_4010_UI_018")/*�����N��*/,
                        MessageUtil.getMessage("EPC1_4010_UI_028")/*�Τ@�s��*/, MessageUtil.getMessage("EPC1_4010_UI_020")/*�Ȥ�W��*/,
                        MessageUtil.getMessage("EPC1_4010_UI_029")/*�_�����*/, MessageUtil.getMessage("EPC1_4010_UI_030")/*���������*/,
                        MessageUtil.getMessage("EPC1_4010_UI_031")/*�믲��*/, MessageUtil.getMessage("EPC1_4010_UI_032")/*�U����ú��*/,
                        MessageUtil.getMessage("EPC1_4010_UI_026")/*�j�Ӹg��*/, MessageUtil.getMessage("EPC1_4010_UI_033") /*ú�O*/};

                String[] template = new String[] { "BLD_CD", "BLD_NAME", "CRT_NO", "ID", "CUS_NAME", "RNT_STR_DATE", "RNT_END_DATE",
                        "RNT_AMT", "NEXT_PAY_DATE", "PAY_FREQ" };
                csvUtils.initBatchExportSetting(title, template);
            }
            List<Map> rtnLogSecurityList = new ArrayList<Map>();
            while (csvUtils.fetchData(bqds)) {
                while (csvUtils.next(bqds)) {
                    Map rtnMap = csvUtils.getCurrentMap();
                    for (Object key : rtnMap.keySet()) {
                        if (rtnMap.get(key) == null) {
                            rtnMap.put(key, "");
                        }

                    }

                    //logSecurity
                    Map logSecurityMap = new HashMap();
                    logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                    rtnLogSecurityList.add(logSecurityMap);

                    //�����ഫ
                    if ("0".equals(CUS_STS)) {
                        rtnMap.put("RCV_YM", ld.formatDateym(rtnMap.get("RCV_YM"), ""));
                        rtnMap.put("PAY_S_DATE",
                            ld.formatDate(Date.valueOf(MapUtils.getString(rtnMap, "PAY_S_DATE").replace("/", "-")), "/", ""));
                        rtnMap.put("PAY_E_DATE", ld.formatDate((Date) bqds.getField("PAY_E_DATE"), "/", ""));

                    } else {
                        rtnMap.put("RNT_STR_DATE",
                            ld.formatDate(Date.valueOf(MapUtils.getString(rtnMap, "RNT_STR_DATE").replace("/", "-")), "/", ""));
                        rtnMap.put("RNT_END_DATE",
                            ld.formatDate(Date.valueOf(MapUtils.getString(rtnMap, "RNT_END_DATE").replace("/", "-")), "/", ""));
                        rtnMap.put("NEXT_PAY_DATE",
                            ld.formatDate(Date.valueOf(MapUtils.getString(rtnMap, "NEXT_PAY_DATE").replace("/", "-")), "/", ""));
                    }
                    rtnMap.put("PAY_KIND_NM", FieldOptionList.getName("EPC", "PAY_KIND_ONE", MapUtils.getString(rtnMap, "PAY_KIND")));
                    rtnMap.put("CUS_STS_NM", FieldOptionList.getName("EPC", "CUS_STS_ONE", MapUtils.getString(rtnMap, "CUS_STS")));
                    String PAY_CD_NM = FieldOptionList.getName("EPC", "PAY_CD", MapUtils.getString(rtnMap, "PAY_CD"));
                    if (StringUtils.isNotBlank(PAY_CD_NM)) {
                        rtnMap.put("PAY_CD", PAY_CD_NM);
                    }
                    rtnMap.put("DCT_TYPE_NM", FieldOptionList.getName("EP", "DCT_TYPE", MapUtils.getString(rtnMap, "DCT_TYPE")));
                    csvUtils.batchCreateCsv();
                }
            }

            return rtnLogSecurityList;

        } finally {
            if (bqds != null) {
                bqds.close();
            }
        }

    }

    /**
     * [20190715] �d����ú�O�������ʦ�����
     * @param reqMap
     * @return
     * @throws ModuleException 
     */
    public List<Map> queryAllDuePayList(Map reqMap) throws ModuleException {
        if (reqMap == null || reqMap.isEmpty()) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C14010_MSG_027"));//��JreqMap���i����
        }
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
        if (StringUtils.isBlank(SUB_CPY_ID)) {
            throw new ErrorInputException(MessageUtil.getMessage("EP_C14010_MSG_029"));//��J�����q�O(SUB_CPY_ID)���i����
        }

        DataSet ds = Transaction.getDataSet();
        ds.setField("SUB_CPY_ID", SUB_CPY_ID);//�����q�O

        String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
        if (StringUtils.isBlank(RCV_YM)) {        	
        	BigDecimal rcvYM2 =  new BigDecimal(DATE.getTodayYearAndMonth());
            //�p�GRCV_YM�S��J
            ds.setField("RCV_YM2", rcvYM2);
            //��������� �����~��
            ds.setField("PAY_KIND_2", "2");
            
        } else {
            ds.setField("RCV_YM", RCV_YM);
        }

        this.setFieldIfExist(ds, "CLCDV", reqMap);//�ӿ���
        this.setFieldIfExist(ds, "BLDUS", reqMap);//�j�Ӹg��ID
        this.setFieldIfExistandLike(ds, "BLDUSNM", reqMap);//�j�Ӹg��m�W�ҽk�d��
        this.setFieldIfExist(ds, "DCT_TYPE", reqMap);//���ڤ覡

        List<Map> rtnList = new ArrayList<Map>();

        DBUtil.searchAndRetrieve(ds, SQL_queryAllDuePayList_001);

        Map PAY_KIND_ONE_Map = FieldOptionList.getFieldOptions("EPC", "PAY_KIND_ONE");
        Map CUS_STS_ONE_Map = FieldOptionList.getFieldOptions("EPC", "CUS_STS_ONE");
        Map PAY_CD_Map = FieldOptionList.getFieldOptions("EPC", "PAY_CD");
        Map DCT_TYPE_Map = FieldOptionList.getFieldOptions("EP", "DCT_TYPE");

        while (ds.next()) {
            Map rtnMap = new HashMap();
            rtnMap = VOTool.dataSetToMap(ds);
            //�����ഫ
            rtnMap.put("PAY_KIND_NM", PAY_KIND_ONE_Map.get(rtnMap.get("PAY_KIND")));//ú�ں���
            rtnMap.put("CUS_STS_NM", CUS_STS_ONE_Map.get(rtnMap.get("CUS_STS")));//�Ȥ᪬�p
            String PAY_CD_NM = MapUtils.getString(PAY_CD_Map, rtnMap.get("PAY_CD"));
            if (StringUtils.isNotBlank(PAY_CD_NM)) {
                rtnMap.put("PAY_CD", PAY_CD_NM);
            }
            rtnMap.put("DCT_TYPE_NM", DCT_TYPE_Map.get(rtnMap.get("DCT_TYPE")));//���ڤ覡
            rtnList.add(rtnMap);
        }

        return rtnList;
    }

    /**
     * SQL�����D���n�Ѽ�
     * @param ds
     * @param reqMap
     * @param key
     */
    private void setFieldIfExist(DataSet ds, String key, String value) {
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * [20190715] �YreqMap���ѼƫhSetField
     * @param ds
     * @param key
     * @param reqMap
     */
    private void setFieldIfExist(DataSet ds, String key, Map reqMap) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * [20190715] �YreqMap���Ѽƫh�i��ҽkSetField
     * @param ds
     * @param key
     * @param reqMap
     */
    private void setFieldIfExistandLike(DataSet ds, String key, Map reqMap) {
        String value = MapUtils.getString(reqMap, key);
        if (StringUtils.isNotBlank(value)) {
            StringBuilder sb = new StringBuilder();
            ds.setField(key, sb.append('%').append(value).append('%').toString());
        }
    }

    /**
     * ���o���~�T��
     * @param eie
     * @param msg
     * @return
     */
    private ErrorInputException getErrorInputException(ErrorInputException eie, String msg) {
        if (eie == null) {
            eie = new ErrorInputException();
        }
        eie.appendMessage(msg);
        return eie;
    }

    /**
     * ��LocaleDisplay�ഫ����榡
     * @param map
     * @param key
     * @param defaultValue
     * @return
     */
    private String str2LocaleDate(Map map, String key, LocaleDisplay locale) {
        String str = MapUtils.getString(map, key);
        return StringUtils.isNotBlank(str) ? locale.formatDate(Date.valueOf(str), "/", "") : "";

    }

    /**
     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getBigDecimal(Object obj) {
        if (obj != null) {
            if (BigDecimal.class.isInstance(obj)) {
                return (BigDecimal) obj;
            }
            String value = obj.toString();
            if (NumberUtils.isNumber(value)) {
                return new BigDecimal(value);
            }
        }
        return BigDecimal.ZERO;
    }
}
