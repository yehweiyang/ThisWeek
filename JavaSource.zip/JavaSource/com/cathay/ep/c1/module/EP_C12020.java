package com.cathay.ep.c1.module;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.exception.DataDuplicateException;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.STRING;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.vo.DTEPC101;
import com.cathay.util.MessageUtil;
import com.cathay.util.Transaction;
import com.igsapp.db.DataSet;

/**
 *<pre>
 * DATE        Description  Author
 * 2013/9/25    Created      Ĭ�f�g
 * �@�B�{���\�෧�n�����G
 * �ҲզW��    �޺޲z�O���u�T�{���@�Ҳ� 
 * �Ҳ�ID      EP_C12020
 * ���n����    �B�z�޲z�O���u�T�{�@�~
 *</pre>
 * 
 * @author ���o��
 * @since 2013/12/11   
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EP_C12020 {
    private static final Logger log = Logger.getLogger(EP_C12020.class);

    private boolean isDebug = log.isDebugEnabled();

    private static final String SQL_query_001 = "com.cathay.ep.c1.module.EP_C12020.SQL_query_001";

    private static final String SQL_doConfirm_001 = "com.cathay.ep.c1.module.EP_C12020.SQL_doConfirm_001";

    //private static final String SQL_ConfirmC101_001 = "com.cathay.ep.c1.module.EP_C12020.SQL_ConfirmC101_001";

    private static final String SQL_doCancelConfirm_001 = "com.cathay.ep.c1.module.EP_C12020.SQL_doCancelConfirm_001";

    //private static final String SQL_CancelC101_001 = "com.cathay.ep.c1.module.EP_C12020.SQL_CancelC101_001";

    /**
          * �d�ߺ޲z�O���u����
     * @param  rtnList       �޲z�O����
     * @throws ModuleException
     */
    public List<Map> query(Map map) throws ModuleException {

        DataSet ds = Transaction.getDataSet();

        setFieldIfExist(ds, map, "SUB_CPY_ID"); // �����q�O
        setFieldIfExist(ds, map, "RCV_NO"); // �����s��
        setFieldIfExist(ds, map, "RCV_YM"); // �����~��
        setFieldIfExist(ds, map, "BLD_CD"); // �j�ӥN��
        setFieldIfExist(ds, map, "CRT_NO"); // �����N��
        setFieldIfExist(ds, map, "CUS_NO"); // �Ȥ�Ǹ�
        setFieldIfExist(ds, map, "OP_STATUS"); // �i��

        DBUtil.searchAndRetrieve(ds, SQL_query_001);

        //�B�z�N�X����,�s�W����^�ǲM��
        List<Map> rtnList = new ArrayList<Map>();
        while (ds.next()) {
            Map rtnMap = VOTool.dataSetToMap(ds);
            rtnMap.put("TRN_KIND_NM", FieldOptionList.getName("EP", "TRN_KIND", MapUtils.getString(rtnMap, "TRN_KIND")));
            rtnMap.put("OP_STATUS_NM", FieldOptionList.getName("EP", "OP_STATUS_C103", MapUtils.getString(rtnMap, "OP_STATUS").trim()));

            rtnList.add(rtnMap);
        }
        return rtnList;
    }

    /**
          *  �T�{�@�~
     * @param reqList   �Ŀ�M��
     * @param user      �ϥΪ̸�T
     * @throws Exception 
     */
    public void doConfirm(List<Map> reqList, UserObject user) throws Exception {

        DataSet ds = Transaction.getDataSet();

        String EmpID = user.getEmpID();
        String DivNo = user.getDivNo();
        String EmpName = user.getEmpName();

        Timestamp currentTime = DATE.currentTime();

        BigDecimal START_YM = STRING.objToBigDecimal(FieldOptionList.getName("EP", "ELE_INV", "START_YM"), BigDecimal.ZERO);

        EP_C1Z001 theEP_C1Z001 = new EP_C1Z001();
        String RCV_YM = "";

        String SUB_CPY_ID = MapUtils.getString(reqList.get(0), "SUB_CPY_ID");

        for (Map reqMap : reqList) {

            if (!"0".equals(MapUtils.getString(reqMap, "OP_STATUS"))) {
                throw new ModuleException(MessageUtil.getMessage("EP_C20010_MSG_028"));//�������㯲�������w�s�b,�G���ɩ�
            }
            if (StringUtils.isBlank(SUB_CPY_ID)) {
                throw new ModuleException(MessageUtil.getMessage("MEP00020"));// �����q�O���o���ŭ�
            }

            //�J������
            try {

                //�p��l���״�
                String PAY_S_DATE = DATE.getMonthFirstDate(MapUtils.getString(reqMap, "RCV_YM")); //���o�����~���1��
                String PAY_E_DATE = DATE.getMonthLastDate(MapUtils.getString(reqMap, "RCV_YM")); //���o�����~��̫�1��

                reqMap.put("PAY_S_DATE", PAY_S_DATE);
                reqMap.put("PAY_E_DATE", PAY_E_DATE);

                //�p��g�L�Ѽ�  
                BigDecimal PASS_DAY = new BigDecimal(DATE.diffDay(PAY_S_DATE, PAY_E_DATE)).add(BigDecimal.ONE);
                reqMap.put("PASS_DAY", PASS_DAY);

                if (isDebug)
                    log.debug("##### S-DATE-E >> PASSDAY=> [" + PASS_DAY + "] [" + PAY_S_DATE + "] [" + PAY_E_DATE + "]");

                // �C�~6��� 12��}����o��, ��l����C�U��������
                //20191022���D��s�� 20190724-0114 by�E�Ͷv
                //�b�޲z�O���u�T�{���������ɮɡA�P�_���u�~��p����몺�ܡA�����~�묰����
                String CURR_S_DATE = DATE.getMonthFirstDate(DATE.getDBDate()); //����@��                
                String month = MapUtils.getString(reqMap, "RCV_YM").substring(4, 6);
                if (PAY_S_DATE.compareTo(CURR_S_DATE) < 0) {
                    RCV_YM = DATE.getYearAndMonth(CURR_S_DATE);
                } else if ("06".equals(month) || "12".equals(month)) {
                    RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
                } else {
                    RCV_YM = DATE.getYearAndMonth(DATE.addDate(PAY_E_DATE, 0, 1, 0));
                }
                reqMap.put("RCV_YM", RCV_YM);

                //��L�w��
                reqMap.put("PAY_CD", "0");
                reqMap.put("EXT_TYPE", "1");
                reqMap.put("PAY_KIND", "3");
                reqMap.put("RJT_CD", "N");
                reqMap.put("TRN_KIND", "EPC011");
                reqMap.put("EXT_DATE", DATE.getDBDate());
                reqMap.put("LST_PROC_DATE", DATE.getDBTimeStamp());
                reqMap.put("LST_PROC_ID", EmpID);
                reqMap.put("LST_PROC_DIV", DivNo);
                reqMap.put("LST_PROC_NAME", EmpName);

                //20200305 �o����Τ覡�A�D�q�l�o���Ҭ�A�ȥ�
                if (new BigDecimal(RCV_YM).compareTo(START_YM) < 0) {//�D�q�l�o��
                    reqMap.put("INV_TRANS_TYPE", "A");
                } else if ("01".equals(SUB_CPY_ID) && "B".equals(MapUtils.getString(reqMap, "INV_TRANS_TYPE"))) {
                    //20200319 �t�ӡG��بS���ʶR�H�eEMAIL���A�ȡA�Gb2b�o���ҥH�ȥ����D
                    reqMap.put("INV_TRANS_TYPE", "A");
                }

                if (isDebug)
                    log.debug("##### insert reqMap=" + reqMap.toString());

                try {

                    DTEPC101 DTEPC101_VO = VOTool.mapToVO(DTEPC101.class, reqMap);

                    //�s�W������(DTEPC101)
                    if (isDebug)
                        log.debug("##### insert C101_VO=" + DTEPC101_VO.toString());
                    theEP_C1Z001.insertDTEPC101(DTEPC101_VO);
                    //VOTool.insert(DTEPC101_VO);

                } catch (Exception e) {
                    log.error("####�s�W������C101���~_" + reqMap.toString() + e);
                    throw e;
                }
            } catch (ErrorInputException eie) {
                log.error("", eie);
                throw eie;

            } catch (DataDuplicateException dnfe) {
                log.error("�s�W���ѡA��ƭ���", dnfe);
                throw dnfe;

            } catch (ModuleException me) {
                if (me.getRootException() == null) {
                    log.error("", me);
                    throw me;
                } else {
                    log.error(me.getMessage(), me.getRootException());
                    throw me;

                }
            } catch (Exception e) {
                log.error("�s�W����", e);
                throw e;

            }

            //��s�ץ�c103�i��:
            ds.clear();
            ds.setField("TRN_KIND", "02");
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            setFieldbox(ds, reqMap, "RCV_NO");
            ds.setField("currentTime", currentTime);
            ds.setField("EmpID", EmpID);
            ds.setField("DIV_NO", DivNo);
            ds.setField("EMP_NAME", EmpName);
            DBUtil.executeUpdate(ds, SQL_doConfirm_001);

        }
    }

    /**
          * �����T�{�@�~
     * @param reqList   �Ŀ�M��
     * @param user      �ϥΪ̸�T
     * @throws Exception 
     */

    public void doCancelConfirm(List<Map> reqList, UserObject user) throws Exception {

        //���o�����q�O
        String SUB_CPY_ID = MapUtils.getString(reqList.get(0), "SUB_CPY_ID");
        DataSet ds = Transaction.getDataSet();

        String EmpID = user.getEmpID();
        String DivNo = user.getDivNo();
        String EmpName = user.getEmpName();

        Timestamp currentTime = DATE.currentTime();
        EP_C10030 theEP_C10030 = new EP_C10030();
        //        RZ_N0Z001 N0Z001 = new RZ_N0Z001();
        for (Map reqMap : reqList) {
            if (StringUtils.isBlank(MapUtils.getString(reqMap, "SUB_CPY_ID"))) {
                throw new ModuleException(MessageUtil.getMessage("MEP00020"));// �����q�O���o���ŭ�
            }
            try {

                //�R������

                try {
                    theEP_C10030.deleteC101(reqMap, user);

                } catch (Exception e) {

                    throw e;
                }

            } catch (ErrorInputException eie) {
                log.error("", eie);
                throw eie;

            } catch (DataNotFoundException dnfe) {
                log.error("�R�����ѡA�L�ӵ����", dnfe);
                throw dnfe;

            } catch (ModuleException me) {
                if (me.getRootException() == null) {
                    log.error("", me);
                    throw me;
                } else {
                    log.error(me.getMessage(), me.getRootException());
                    throw me;

                }
            } catch (Exception e) {
                log.error("�R������", e);
                throw e;

            }

            //��s�f��i�סG
            //  String FLOW_NO = MapUtils.getString(reqMap, "FLOW_NO");
            //  N0Z001.rejectFlow(FLOW_NO, "�����T�{", "", user.getEmpID(), user.getDivNo());
            //��s�ץ�i��:
            ds.clear();

            setFieldbox(ds, reqMap, "RCV_NO");
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            setFieldbox(ds, reqMap, "CUS_NO");
            setFieldbox(ds, reqMap, "CRT_NO");

            ds.setField("currentTime", currentTime);
            ds.setField("EmpID", EmpID);
            ds.setField("DIV_NO", DivNo);
            ds.setField("EMP_NAME", EmpName);

            //2019-03-13���D��s�� 20190312-0101  
            //�޲z�O�Τ��u�����T�{��A���N������(DTEPC103)�W��TRN_KIND�h�^��01(��J)�A�ٺ����b02(�T�{)�A�ɭP�R�����ˮָӥ󤴬��T�{���A�A�Ӥ��o�R���C
            //�վ�{���A�����T�{�ݧ�sTRN_KIND��01(��J)
            ds.setField("TRN_KIND", "01");

            DBUtil.executeUpdate(ds, SQL_doCancelConfirm_001);

        }
    }

    /**
     * @param ds
     * @param map
     * @param key
     */
    private void setFieldIfExist(DataSet ds, Map map, String key) {
        String value = MapUtils.getString(map, key);
        if (StringUtils.isNotBlank(value)) {
            ds.setField(key, value);
        }
    }

    /**
     * @param ds
     * @param map
     * @param key
     */
    private void setFieldbox(DataSet ds, Map map, String key) {
        String value = MapUtils.getString(map, key);
        ds.setField(key, value);
    }

}
