package com.cathay.ep.c1.trx;

import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.c1.module.EPC1_1020_mod;
import com.cathay.ep.c1.module.EP_C11020;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C102;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Version  Description  Author
 * 2013-09-03  1.0      Created      ���|��
 *
 * UCEPC1_1020_�H�u�կ��@�~
 * 
 * �@�B   �{���\�෧�n�����G
 * �{���\��    �H�u�կ��@�~
 * �{���W��    EPC1_1020
 * �@�~�覡    ONLINE
 * ���n����    ���\�ध�D�n�ت����N�C��C��կ��թ㫴����ƨöi��T�{�P�Ю֡C
 *            (1) �d�ߡG��ܿ�J���զ~��B�ӿ��O�B�կ��覡�B�կ������B�i�סB�����N���B�Ȥ�Ǹ��A�d�߽կ��թ��ơC
 *            (2) ���G�̿�J�����զ~�����կ��թ��ơC
 *            (3) �T�{�G�̤Ŀ諸�կ��թ��ƶi��T�{�C
 *            (4) �����T�{�G�̤Ŀ諸�կ��թ��ƶi������T�{�C
 *            (5) �Ю֡G�̤Ŀ諸�կ��թ��ƶi���Ю֡C
 *            (6) �C�L�����G���ͽկ��թ�����C 
 *</pre>
 * @author ���_��
 * @since 2013/9/30
 */
@SuppressWarnings("unchecked")
public class EPC1_1020 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC1_1020.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        try {
            //�ǤJ�������q�O
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        } catch (ErrorInputException eie) {
            log.error("���o�����q�O����", eie);
            MessageUtil.setErrorMsg(msg, "EPC1_1020_UI_005");//���o�����q�O����
        }

        try {
            resp.addOutputData("ADJ_TYPE", FieldOptionList.getFieldOptions("EP", "ADJ_TYPE"));
            resp.addOutputData("ADJ_UNIT", FieldOptionList.getFieldOptions("EP", "ADJ_UNIT_C"));
            resp.addOutputData("DEL_CD", FieldOptionList.getFieldOptions("EP", "DEL_CD"));
            resp.addOutputData("ADJ_PM", FieldOptionList.getFieldOptions("EP", "ADJ_PM_C"));
        } catch (Exception e) {
            log.error("�U�Կ����o����", e);
            MessageUtil.setErrorMsg(msg, "EPC1_1020_UI_006");//�U�Կ����o����
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMap"));

            this.queryM(reqMap);

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC1_1020_UI_001"));//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPC1_1020_UI_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC1_1020_UI_003"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC1_1020_UI_004"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPC1_1020_UI_004"), e);//�d�ߥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_1020_UI_004"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapUpdate"));

            new EPC1_1020_mod().checkUpdate(reqMap);

            Transaction.begin();
            try {
                new EP_Z0C102().update(reqMap, user.getEmpID(), user.getEmpName(), user.getOpUnit());
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC1_1020_UI_007"));//�ק粒��

            //�d��
            try {
                this.queryM(reqMap);
            } catch (Exception e) {
                throw e;
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("EPC1_1020_UI_002"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_1020_UI_008");//�@�~����
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_1020_UI_008"));//�@�~����
        }

        return resp;
    }

    /**
     * �c��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapUpdate"));

            new EPC1_1020_mod().checkDelete(reqMap);

            Transaction.begin();
            try {
                new EP_Z0C102().cancel(reqMap, user.getEmpID(), user.getEmpName(), user.getOpUnit());
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC1_1020_UI_009"));//�簣����

            //�d��
            try {
                this.queryM(reqMap);
            } catch (Exception e) {
                throw e;
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_1020_UI_008");//�@�~����
            }
        } catch (Exception e) {
            log.error("�c������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_1020_UI_008"));//�@�~����
        }

        return resp;
    }

    /**
     * �����c��
     * @param req
     * @return
     */
    public ResponseContext doUndelete(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("storeMapUpdate"));

            Transaction.begin();
            try {
                new EP_Z0C102().unCancel(reqMap, user.getEmpID(), user.getEmpName(), user.getOpUnit());
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC1_1020_UI_010"));//�����簣����

            //�d��
            try {
                this.queryM(reqMap);
            } catch (Exception e) {
                throw e;
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_1020_UI_008");//�@�~����
            }
        } catch (Exception e) {
            log.error("�����c������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_1020_UI_008"));//�@�~����
        }

        return resp;

    }

    /**
     * �d��
     * @param reqMap
     * @throws ModuleException
     */
    private void queryM(Map reqMap) throws ModuleException {

        new EPC1_1020_mod().checkQuery(reqMap);

        Map queMap = new EP_C11020().query(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(reqMap, "ADJ_YM"), MapUtils
                .getString(reqMap, "CRT_NO"), MapUtils.getString(reqMap, "CUS_NO"));

        logSecurity(queMap);
        resp.addOutputData("rtnMap", queMap);
    }

}