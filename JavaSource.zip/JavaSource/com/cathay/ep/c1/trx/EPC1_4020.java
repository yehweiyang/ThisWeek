package com.cathay.ep.c1.trx;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.c1.module.EP_C14020;
import com.cathay.ep.c2.trx.EPC2_0030;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Description Author
 * 2013/8/5     Created �\�a�s
 * 
 * UCEPC1_4020_�j�Ӧ����v�@�~
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �j�Ӧ����v�@�~
 * �{���W��    EPC1_4020
 * �@�~�覡    ONLINE
 * ���n����    (1) �d�ߡG�ʦ����Ӹ�Ƭd��
 *             (2) �w����b���Ӫ��G�H�����N�����D�����ӳ���
 *             (3) �j�ӹw�����Ӫ��G�H�j�ӥN�����D�����ӳ���
 * </pre>
 * @author ����[
 * @since 2014-01-10
 */
@SuppressWarnings("unchecked")
public class EPC1_4020 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC2_0030.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        String SUB_CPY_ID = "";
        try {
            SUB_CPY_ID = theEP_Z00030.getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
        }

        resp.addOutputData("SORT_ONEList", FieldOptionList.getFieldOptions("EPC", "SORT_ONE"));
        try {
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                resp.addOutputData("CLCDVList", FieldOptionList.getFieldOptions("EPC", "CLCDV"));
            } else {
                resp.addOutputData("CLCDVList", FieldOptionList.getFieldOptions("EP", "AGT_DIV_" + SUB_CPY_ID));
            }
        } catch (ErrorInputException e) {
            log.error("���o��쥢��", e);
        }
        //[20180308]
        resp.addOutputData("GROUP_TYPEList", FieldOptionList.getFieldOptions("EP", "GROUP_TYPE"));
        
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            resp.addOutputData("rtnList", new EP_C14020().queryList(new BigDecimal(req.getParameter("RCV_YM")), req.getParameter("DIV_NO"),
                req.getParameter("SORT_TYPE"), req.getParameter("GROUP_TYPE"), req.getParameter("SUB_CPY_ID")));

            MessageUtil.setMsg(msg, "MI00020");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "ME00630");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "ME00630");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �C�L�w����b���Ӫ�
     * @param req
     * @return
     */
    /*public ResponseContext doReportPrt1(RequestContext req) {
        try {

            EP_C14020 theEP_C14020 = new EP_C14020();
            Map rptMap = theEP_C14020.doFmtRpt1(new BigDecimal(req.getParameter("RCV_YM")), "", "", user);

            theEP_C14020.prtRpt1(rptMap, resp, req);

        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_4020_ERRMSG_001");//�C�L����
                }
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_4020_ERRMSG_001");//�C�L����
        }

        return resp;
    }*/

    /**
     * �C�L�j�ӹw�����Ӫ�
     * @param req
     * @return
     */
    /*public ResponseContext doReportPrt2(RequestContext req) {
        try {

            EP_C14020 theEP_C14020 = new EP_C14020();
            Map rptMap = theEP_C14020.doFmtRpt2(new BigDecimal(req.getParameter("RCV_YM")), "", "", user);

            theEP_C14020.prtRpt2(rptMap, resp);
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_4020_ERRMSG_001");//�C�L����
                }
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_4020_ERRMSG_001");//�C�L����
        }

        return resp;
    }*/

    /**
     * �C�L
     * @param req
     * @return
     */
    public ResponseContext doReportPrt3(RequestContext req) {
        try {

            EP_C14020 theEP_C14020 = new EP_C14020();
            Map rptMap = theEP_C14020.doFmtRpt3(new BigDecimal(req.getParameter("RCV_YM")), req.getParameter("DIV_NO"), req
                    .getParameter("SORT_TYPE"), req.getParameter("SUB_CPY_ID"), user, req.getParameter("GROUP_TYPE"));

            theEP_C14020.prtRpt3(rptMap, resp);
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_4020_ERRMSG_001");//�C�L����
                }
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_4020_ERRMSG_001");//�C�L����
        }
        return resp;
    }

    /**
     *  �ץX [20180308]
     * @param req
     * @return
     */
    public ResponseContext doExport(RequestContext req) {
        try {

            EP_C14020 theEP_C14020 = new EP_C14020();
            Map rptMap = theEP_C14020.doFmtRpt4(new BigDecimal(req.getParameter("RCV_YM")), req.getParameter("DIV_NO"), req
                    .getParameter("SORT_TYPE"), req.getParameter("SUB_CPY_ID"), user, req.getParameter("GROUP_TYPE"));
            theEP_C14020.prtRpt4(rptMap, resp);
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "ME00632");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00028");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_4020_ERRMSG_001");//�C�L����
                }
            }
        } catch (Exception e) {
            log.error("�C�L����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_4020_ERRMSG_003");//�ץX����
        }
        return resp;
    }
}
