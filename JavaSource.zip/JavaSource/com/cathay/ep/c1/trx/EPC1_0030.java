package com.cathay.ep.c1.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.c1.module.EPC1_0010_mod;
import com.cathay.ep.c1.module.EP_C10030;
import com.cathay.ep.vo.DTEPC101;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0B201;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date     Description     Author
 * 2013/10/2    Created      �\�a�s
 * 2018/03/18   �t�X��ؽվ�     ����[
 * 2018/08/09   �p�p��:�����~�뤣�i�j��U��(�t�X�q�l�o�����i���e�}�W�L1�Ӥ�H�W�o��)
 *
 * UCEPC1_0030_�����ɿ�J�@�~
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �����ɿ�J�@�~
 * �{���W��    EPC1_0030
 * �@�~�覡    ONLINE
 * ���n����    (1) �d�ߡG�d��������
 *            (2) ��J�G�s�W������
 *            (3) �ק�G�ק�������
 *            (4) �R���G�R��������
 * 
 * @author ����[
 * @since 2013-10-16
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC1_0030 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EP_C10030.class);

    private boolean isDebug = log.isDebugEnabled();

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);
        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC1_0010_ERRMSG_001");//���o�����q�O����
        }
        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {

        VOTool.setParamsFromLP_JSON(req);
        try {
            int iCUR_YM = Integer.parseInt(DATE.getTodayYearAndMonth().toString()) - 191100;
            resp.addOutputData("RCV_YM", Integer.toString(iCUR_YM));

            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC1_0030_UI_004");//���o�����q�O����
        }
        resp.addOutputData("CRT_NO", req.getParameter("CRT_NO"));
        resp.addOutputData("CUS_NO", req.getParameter("CUS_NO"));

        resp.addOutputData("PAY_KIND_ONEList", FieldOptionList.getFieldOptions("EPC", "PAY_KIND"));
        resp.addOutputData("TAX_TYPEList", FieldOptionList.getFieldOptions("EPC", "TAX_TYPE"));

        resp.addOutputData("CURRENT_DATE", DATE.today());
        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            resp.addOutputData("rtnList", query(reqMap, new EP_C10030()));

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߦ��\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC1_0030_UI_001"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * ��@�d��
     * @param reqMap
     * @param theEP_C10030
     * @return
     * @throws Exception 
     */
    private List<Map> query(Map reqMap, EP_C10030 theEP_C10030) throws Exception {
        List<Map> rtnList = theEP_C10030.queryList(MapUtils.getString(reqMap, "RCV_YM"), MapUtils.getString(reqMap, "CRT_NO"),
            MapUtils.getString(reqMap, "CUS_NO"), MapUtils.getString(reqMap, "PAY_KIND"), MapUtils.getString(reqMap, "ID"),
            MapUtils.getString(reqMap, "SUB_CPY_ID"));

        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map map : rtnList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("CUS_NAME", map.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);
        }
        logSecurity(logSecurityList);

        return rtnList;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            //            reqMap.put("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
            EP_C10030 theEP_C10030 = new EP_C10030();
            EPC1_0010_mod theEPC1_0010_mod = new EPC1_0010_mod();
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");

            //�ˮ������~��O�_�p��ثe�~��
            theEPC1_0010_mod.checkRCV_YM(RCV_YM);//�����~��

            Transaction.begin();
            try {
                theEP_C10030.updateC101(reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            try {
                resp.addOutputData("rtnList", query(reqMap, theEP_C10030));
            } catch (DataNotFoundException e) {
                log.error("�ץ�����,�d�L���", e);
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00007"));//�ץ�����
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00009"));//�ץ����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00008"));//�ץ�����
            }
        } catch (Exception e) {
            log.error("�ץ�����", e);//�ץ�����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00008"));//�ץ�����
        }

        return resp;
    }

    /**
     * �ˮַs�W
     * @param req
     * @return
     */
    public ResponseContext doChkInsert(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String ChkInsertType = req.getParameter("ChkInsertType");
            String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
            BigDecimal SAL_AMT = new BigDecimal(MapUtils.getString(reqMap, "SAL_AMT"));
            BigDecimal TAX_AMT = new BigDecimal(MapUtils.getString(reqMap, "TAX_AMT"));
            BigDecimal INV_AMT = new BigDecimal(MapUtils.getString(reqMap, "INV_AMT"));
            if ("1".equals(ChkInsertType)) {
                //180809:�p�p��:�����~�뤣�i�j��U��(�t�X�q�l�o�����i���e�}�W�L1�Ӥ�H�W�o��)
                int current_yyyymm = new Integer(DATE.getYearAndMonth(DATE.addDate(DATE.getDBDate(), 0, 1, 0)));
                int RCV_YM = MapUtils.getInteger(reqMap, "RCV_YM");
                if (RCV_YM > current_yyyymm) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPC1_0030_UI_008"));//�����~�뤣�i�j��U��
                }

                //����
                String NEXT_PAY_DATE = MapUtils.getString(reqMap, "NEXT_PAY_DATE");
                if ("1".equals(PAY_KIND)) {
                    if (!DATE.isDate(NEXT_PAY_DATE)) {
                        throw new ErrorInputException(MessageUtil.getMessage("EPC1_0030_UI_005"));//�ӫ����L�U����ú��
                    }
                    String PAY_E_DATE = MapUtils.getString(reqMap, "PAY_E_DATE");
                    if (PAY_E_DATE.compareTo(NEXT_PAY_DATE) < 0) {
                        Hashtable userRoles = user.getRoles();
                        if (userRoles.containsKey("RLEP003")) {
                            //���ʲ��Юָg��
                            //ú�کl���p��U����ú��!!
                            resp.addOutputData("result", true);
                        } else {
                            throw new ErrorInputException(MessageUtil.getMessage("EPC1_0030_UI_006"));//ú�کl�����o�p��U����ú��
                        }
                    }
                }
            } else if ("2".equals(ChkInsertType)) {
                //���:�s�W�{�ɰ�����
                if ("5".equals(PAY_KIND) || "8".equals(PAY_KIND)
                        || ("4".equals(PAY_KIND) && StringUtils.isBlank(MapUtils.getString(reqMap, "CRT_NO")))) {
                    resp.addOutputData("result", false);
                } else {
                    resp.addOutputData("result", new EP_C10030().chkInsertC101(reqMap, user));
                }

            }
            if (isDebug) {
                log.debug("@@@INV_AMT=" + INV_AMT);
                log.debug("@@@SAL_AMT=" + SAL_AMT);
                log.debug("@@@TAX_AMT=" + TAX_AMT);
            }
            if (!"2".equals(PAY_KIND)) {
                //�ˮֵo�����B=�P���B+�|�B
                if (INV_AMT.compareTo(SAL_AMT.add(TAX_AMT)) != 0) {
                    throw new ErrorInputException(MessageUtil.getMessage("EPC1_0030_UI_007"));//�o�����B������(�P���B+�|�B)
                }
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC1_0030_UI_001"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC1_0030_UI_002"));//�ˮַs�W ����
                }
            }
        } catch (Exception e) {
            log.error("�ˮַs�W ����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_0030_UI_002"));//�ˮַs�W ����
        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");

            EPC1_0010_mod theEPC1_0010_mod = new EPC1_0010_mod();
            //�ˮ������~��O�_�p��ثe�~��
            theEPC1_0010_mod.checkRCV_YM(RCV_YM);//�����~��

            EP_C10030 theEP_C10030 = new EP_C10030();

            Transaction.begin();
            DTEPC101 DTEPC101_VO;
            try {
                DTEPC101_VO = theEP_C10030.insertC101(reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            resp.addOutputData("C101VO", DTEPC101_VO);
            MessageUtil.setMsg(msg, "MEP00004");//�s�W����
            try {
                Map map = new HashMap();
                map.put("RCV_YM", DTEPC101_VO.getRCV_YM());//�����~��
                map.put("CRT_NO", DTEPC101_VO.getCRT_NO());//�����N��
                map.put("CUS_NO", DTEPC101_VO.getCUS_NO());//�Ȥ�Ǹ�
                map.put("PAY_KIND", DTEPC101_VO.getPAY_KIND());//ú�ں���
                map.put("ID", DTEPC101_VO.getID());
                map.put("SUB_CPY_ID", DTEPC101_VO.getSUB_CPY_ID());
                resp.addOutputData("rtnList", query(map, theEP_C10030));
                resp.addOutputData("INV_NO", DTEPC101_VO.getINV_NO());
                resp.addOutputData("DIV_NO", DTEPC101_VO.getDIV_NO());
                resp.addOutputData("EXT_DATE", DTEPC101_VO.getDIV_NO());
                resp.addOutputData("LST_PROC_NAME", DTEPC101_VO.getLST_PROC_NAME());
                resp.addOutputData("LST_PROC_DATE", DTEPC101_VO.getLST_PROC_DATE());
                resp.addOutputData("LST_PROC_DATE", DTEPC101_VO.getLST_PROC_DATE());
                resp.addOutputData("ACNT_DATE", DTEPC101_VO.getACNT_DATE());

            } catch (DataNotFoundException e) {
                log.error("�s�W����,�d�L���", e);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�d�L���", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00005"));//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00005"));//�s�W����
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            EP_C10030 theEP_C10030 = new EP_C10030();

            Transaction.begin();
            try {
                theEP_C10030.deleteC101(reqMap, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            try {
                resp.addOutputData("rtnList", query(reqMap, theEP_C10030));
            } catch (DataNotFoundException e) {
                log.error("�R�����\ �d�L���", e);
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00010"));//�R������
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("�R�����ѡA�L�ӵ����", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00012"));//�R�����ѡA�L�ӵ����
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00011"));//�R������
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00011"));//�R������
        }

        return resp;
    }

    /**
     * �d�ߤj�ӥN��
     * @param req
     * @return
     */
    public ResponseContext doGetBLD_NAME(RequestContext req) {
        try {
            resp.addOutputData("BLD_NAME", new EP_C10030().getBLD_NAME(req.getParameter("BLD_CD"), new EP_Z00030().getSUB_CPY_ID(user)));

        } catch (ErrorInputException eie) {
            log.debug(eie);
        } catch (DataNotFoundException dnfe) {
            log.debug("", dnfe);
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_0030_UI_003"));//�d�L���j�ӥN��
        }

        return resp;
    }

    /**
     * �������B/�o�����B���s��
     * @param req
     * @return
     */
    public ResponseContext doGetAMT(RequestContext req) {
        try {
            String TYPE = req.getParameter("type");

            if ("1".equals(TYPE)) {
                BigDecimal SAL_AMT = new BigDecimal(req.getParameter("AMT"));
                BigDecimal TAX_AMT = SAL_AMT.multiply(new BigDecimal("0.05")).setScale(0, BigDecimal.ROUND_HALF_UP);
                resp.addOutputData("TAX_AMT", TAX_AMT);
                resp.addOutputData("INV_AMT", SAL_AMT.add(TAX_AMT));
            } else if ("2".equals(TYPE)) {
                BigDecimal SAL_AMT = new BigDecimal(req.getParameter("AMT"));
                BigDecimal TAX_AMT = BigDecimal.ZERO;
                resp.addOutputData("TAX_AMT", TAX_AMT);
                resp.addOutputData("INV_AMT", SAL_AMT.add(TAX_AMT));
            } else if ("3".equals(TYPE)) {
                BigDecimal INV_AMT = new BigDecimal(req.getParameter("AMT"));
                BigDecimal SAL_AMT = INV_AMT.divide(new BigDecimal("1.05"), 0, BigDecimal.ROUND_HALF_UP);
                BigDecimal TAX_AMT = INV_AMT.subtract(SAL_AMT);
                resp.addOutputData("TAX_AMT", TAX_AMT);
                resp.addOutputData("SAL_AMT", SAL_AMT);
            }
        } catch (Exception e) {
            log.error("�s�ʥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_0030_UI_004"));//�s�ʥ���
        }

        return resp;
    }

    /**
     * �s�ʫ����N���B�Ȥ�Ǹ�
     * @param req
     * @return
     */
    public ResponseContext doChangeCRTorCUS(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            Map rtnMap = new EP_B10020().queryMap(reqMap);
            resp.addOutputData("BLD_CD", MapUtils.getString(rtnMap, "BLD_CD"));//�j�ӥN��
            resp.addOutputData("CUS_NAME", MapUtils.getString(rtnMap, "CUS_NAME"));//�Ȥ�W��
            resp.addOutputData("ID", MapUtils.getString(rtnMap, "ID"));//�Τ@�s��   
            resp.addOutputData("CUS_ID", MapUtils.getString(rtnMap, "CUS_ID"));//�Ȥ�s��   
            resp.addOutputData("TAX_TYPE", MapUtils.getString(rtnMap, "TAX_TYPE"));//�|�O
            resp.addOutputData("NEXT_PAY_DATE", MapUtils.getString(rtnMap, "NEXT_PAY_DATE"));//�U����ú��
            String INV_TRANS_TYPE = MapUtils.getString(rtnMap, "INV_TRANS_TYPE");
            resp.addOutputData("INV_TRANS_TYPE", INV_TRANS_TYPE);//�o����Τ覡
            resp.addOutputData("INV_TRANS_TYPE_NM", FieldOptionList.getName("EP", "TRANS_TYPE", INV_TRANS_TYPE));//�o����Τ覡

            logSecurity(rtnMap);
        } catch (ErrorInputException eie) {
            log.debug(eie);
        } catch (DataNotFoundException dnfe) {
            log.debug("", dnfe);
        } catch (Exception e) {
            log.error("�s�ʫ����N���B�Ȥ�Ǹ��@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "�s�ʧ@�~����");
        }
        return resp;
    }

    /**
     * �s�ʲΤ@�s��
     * @param req
     * @return
     */
    public ResponseContext doChangeID(RequestContext req) {
        try {
            String ID = req.getParameter("ID");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            Map reqMap = new HashMap();
            reqMap.put("ID", ID);
            reqMap.put("IS_EXACT", "Y");//�ǽT�j�M
            List<Map> rtnList = new EP_Z0B201().queryB201List(reqMap, SUB_CPY_ID);
            if (rtnList != null && !rtnList.isEmpty()) {
                resp.addOutputData("CUS_NAME", MapUtils.getString(rtnList.get(0), "CUS_NAME"));//�Ȥ�W��
                String INV_TRANS_TYPE = MapUtils.getString(rtnList.get(0), "TRANS_TYPE");
                resp.addOutputData("INV_TRANS_TYPE", INV_TRANS_TYPE);//�o����Τ覡
                resp.addOutputData("INV_TRANS_TYPE_NM", FieldOptionList.getName("EP", "TRANS_TYPE", INV_TRANS_TYPE));//�o����Τ覡
                resp.addOutputData("CUS_ID", MapUtils.getString(rtnList.get(0), "CUS_ID"));//�Ȥ�s��
            }

            logSecurity(rtnList);
        } catch (ErrorInputException eie) {
            log.debug(eie);
        } catch (DataNotFoundException dnfe) {
            log.debug("", dnfe);
        } catch (Exception e) {
            log.error("�s�ʲΤ@�s���@�~����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "�s�ʧ@�~����");
        }
        return resp;
    }
}
