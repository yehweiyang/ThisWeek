package com.cathay.ep.c1.trx;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.IConstantMap;
import com.cathay.ep.b1.module.EP_B10020;
import com.cathay.ep.c1.module.EPC1_2030_mod;
import com.cathay.ep.c1.module.EP_C12030;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date     Version Description Author
 * 2013/10/01   1.0 Created     Ĭ�f�g
 *
 * UCEPC1_2030_�޲z�O���u��J
 *
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �޲z�O���u��J
 * �{���W��    EPC1_2030
 * �@�~�覡    ONLINE
 * ���n����    (1) ��l
 *            (2) ���� �w �}�ҵ������ѨϥΪ̬d�߫�����ơA�I���a�^�A�����������C
 *            (3) �d�� �w ���ѨϥΪ̬d�ߺ޲z�O���u��ơC
 *            (4) �s�W �w ���ѨϥΪ̷s�W�޲z�O���u��ơC
 *            (5) �ק� �V ���ѨϥΪ̭ק�޲z�O���u��ơC
 *            (6) �R�� �w ���ѨϥΪ̧R���޲z�O���u��ơC
 *            (7) �M�� �w �M�ŵe���i��J���C
 * ���s���v    FUNC_ID = EPC12030
 * �����q���
 * �榡���js  �M��
 * �h��y�t    �M��
 * �h���d��      �L         v������          �u����
 * </pre>
 * @author ����[
 * @since  
 */
@SuppressWarnings("unchecked")
public class EPC1_2030 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC1_2030.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);

        try {
            resp.addOutputData("SUB_CPY_ID", new EP_Z00030().getSUB_CPY_ID(user));
        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            MessageUtil.setErrorMsg(msg, "EPC1_2030_ERRMSG_001");//���o�����q�O����
        }
        resp.addOutputData("BLD_CD", req.getParameter("BLD_CD"));
        resp.addOutputData("OP_STATUS", req.getParameter("OP_STATUS"));
        resp.addOutputData("INPUT_ID", req.getParameter("INPUT_ID"));

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");

            query(reqMap, SUB_CPY_ID, new EP_C12030());

            MessageUtil.setMsg(msg, "MEP00002");//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001");//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_2030_ERRMSG_OVERCOUNT");//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00003");//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     * �s�W
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");

            //�ˮֿ�J��ƥ��T��
            new EPC1_2030_mod().chkInsert(SUB_CPY_ID, reqMap);

            EP_C12030 theEP_C12030 = new EP_C12030();
            Transaction.begin();
            try {
                theEP_C12030.insertEPC103(SUB_CPY_ID, reqMap, user.getEmpID(), user.getEmpName(), user.getOpUnit());
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            try {
                query(reqMap, SUB_CPY_ID, theEP_C12030);
            } catch (DataNotFoundException e) {
                log.error("�d�L���", e);
            }

            MessageUtil.setMsg(msg, "MEP00004");//�s�W����
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00005");//�s�W����
            }
        } catch (Exception e) {
            log.error("�s�W����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00005");//�s�W����
        }

        return resp;
    }

    /**
     * �ק�
     * @param req
     * @return
     */
    public ResponseContext doUpdate(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");

            //�ˮֿ�J��ƥ��T��
            String updateType = new EPC1_2030_mod().chkUpdate(SUB_CPY_ID, reqMap);

            EP_C12030 theEP_C12030 = new EP_C12030();
            Transaction.begin();
            try {
                theEP_C12030.updateEPC103(SUB_CPY_ID, reqMap, user.getEmpID(), user.getEmpName(), user.getOpUnit(), updateType);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            try {
                query(reqMap, SUB_CPY_ID, theEP_C12030);
            } catch (DataNotFoundException e) {
                log.error("�d�L���", e);
            }

            MessageUtil.setMsg(msg, "MEP00007");//�ק粒��
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00008");//�ק異��
            }
        } catch (Exception e) {
            log.error("�ק異��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00008");//�ק異��
        }

        return resp;
    }

    /**
     * �R��
     * @param req
     * @return
     */
    public ResponseContext doDelete(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");

            //�ˮֿ�J��ƥ��T��
            new EPC1_2030_mod().chkDelete(SUB_CPY_ID, reqMap);

            EP_C12030 theEP_C12030 = new EP_C12030();
            Transaction.begin();
            try {
                theEP_C12030.deleteEPC103(SUB_CPY_ID, reqMap, user.getEmpID(), user.getEmpName(), user.getOpUnit());
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            try {
                query(reqMap, SUB_CPY_ID, theEP_C12030);
            } catch (DataNotFoundException e) {
                log.error("�d�L���", e);
            }

            MessageUtil.setMsg(msg, "MEP00010");//�R������
        } catch (ErrorInputException eie) {
            log.error(eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "MEP00011");//�R������
            }
        } catch (Exception e) {
            log.error("�R������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00011");//�R������
        }

        return resp;
    }

    /**
     *  �H�����N���B�Ǹ� ���o �Τ@�s���B�Ȥ�W��
     * @param req
     * @return
     */
    public ResponseContext doGetID(RequestContext req) {
        try {
            String CRT_NO = req.getParameter("CRT_NO");
            String CUS_NO = req.getParameter("CUS_NO");
            String SUB_CPY_ID = req.getParameter("SUB_CPY_ID");
            String ID = null;
            String CUS_NAME = null;

            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", SUB_CPY_ID);//�����q�O
            reqMap.put("CRT_NO", CRT_NO);//�����N��
            reqMap.put("CUS_NO", CUS_NO);//�Ȥ�Ǹ�
            try {
                Map rtnMap = new EP_B10020().queryList(reqMap).get(0);
                ID = MapUtils.getString(rtnMap, "ID");
                CUS_NAME = MapUtils.getString(rtnMap, "CUS_NAME");
            } catch (DataNotFoundException dnfe) {
                //�Y�d�L��ơA�h�H�Ȥ�Ǹ�=1�A�A�d�@��
                reqMap.put("CUS_NO", "1");
                try {
                    Map rtnMap = new EP_B10020().queryList(reqMap).get(0);
                    ID = MapUtils.getString(rtnMap, "ID");
                    CUS_NAME = MapUtils.getString(rtnMap, "CUS_NAME");
                } catch (DataNotFoundException dnfe2) {
                    //�d�L��Ƶ������`                    
                }
            }
            if (StringUtils.isNotBlank(ID)) {
                resp.addOutputData("ID", ID); //�Τ@�s��
            }
            if (StringUtils.isNotBlank(CUS_NAME)) {
                resp.addOutputData("CUS_NAME", CUS_NAME); //�Ȥ�m�W
            }
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
            }
        } catch (Exception e) {
            log.error("���o�Τ@�s���B�Ȥ�W�٥���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "MEP00003");//�d�ߥ���
        }

        return resp;
    }

    /**
     *  �H�P����B�p����~�|�B
     * @param req
     * @return
     */
    public ResponseContext doCalTax(RequestContext req) {
        try {
            BigDecimal SAL_AMT = new BigDecimal(req.getParameter("SAL_AMT")); //�P����B           
            BigDecimal TAX_AMT = SAL_AMT.multiply(new BigDecimal(0.05)).setScale(0, BigDecimal.ROUND_HALF_UP);

            resp.addOutputData("TAX_AMT", TAX_AMT); //��~�|�B

        } catch (Exception e) {
            log.error("�p����~�|�B", e);
        }

        return resp;
    }

    /**
     * �@�άd��
     * @param reqMap
     * @param SUB_CPY_ID
     * @param theEP_C12030
     * @throws ModuleException
     */
    private void query(Map reqMap, String SUB_CPY_ID, EP_C12030 theEP_C12030) throws ModuleException {

        List<Map> rtnList = theEP_C12030.query(SUB_CPY_ID, reqMap);

        BigDecimal SAL_TOT = BigDecimal.ZERO;
        BigDecimal TAX_TOT = BigDecimal.ZERO;
        BigDecimal RCV_TOT = BigDecimal.ZERO;

        int i = 1;
        for (Map rtnMap : rtnList) {
            rtnMap.put("NO", i++);
            if ("N".equals(MapUtils.getString(rtnMap, "DEL_CD"))) {
                SAL_TOT = SAL_TOT.add(getBigDecimal(rtnMap.get("SAL_AMT"), BigDecimal.ZERO));
                TAX_TOT = TAX_TOT.add(getBigDecimal(rtnMap.get("TAX_AMT"), BigDecimal.ZERO));
                RCV_TOT = RCV_TOT.add(getBigDecimal(rtnMap.get("RCV_AMT"), BigDecimal.ZERO));
            }
        }
        Map TOTMap = new HashMap();
        TOTMap.put("SAL_AMT", SAL_TOT);
        TOTMap.put("TAX_AMT", TAX_TOT);
        TOTMap.put("RCV_AMT", RCV_TOT);

        logSecurity(rtnList);
        resp.addOutputData("rtnList", rtnList);
        resp.addOutputData("TOTMap", TOTMap);

    }

    /**
     * �૬�A�M���w�]
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

}
