package com.cathay.ep.c1.trx;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.hr.WorkDate;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.c1.module.EPC1_0050_mod;
import com.cathay.ep.c1.module.EP_C10050;
import com.cathay.ep.vo.DTEPC101;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C101;
import com.cathay.rpt.CsvUtils;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date    Version Description Author
 * 2013/10/28  1.0 Created     �רK��
 * 2018/01/26  �W�[�����Ю֥\��  ����[
 * 
 * �@�B   �{���\�෧�n�����G
 * �{���\��  �������ӽT�{
 * �{���W��  EPC1_0050
 * �@�~�覡  ONLINE
 * ���n����    
 * (1) �d�ߡG�d�������ɸ�ơC 
 * (2) �T�{�G�j�Ӹg��i�ھ������~��B�j�ӡBú�ں����@�T�{�C
 * (3) �����T�{�G�j�Ӹg��i�N�w�T�{���Юָ�Ƨ@�����T�{�C
 * (4) �Ю֡G�b�ȸg��i�ھڤw�T�{��Ƨ@�Ю֡A�}�o��(By �����~��B�j�ӡBú�ں���)�C
 * (5) �b�ȽT�{�G�b�ȸg��i�ھڤw�}�o��������Ƨ@�b�ȽT�{���������b�Ȥ����C
 * (6) �����b�ȡG�b�ȸg��i�N�w�X�b(�|���ഫ�ǲ��ζǲ��w�h��)���������ӡA�@�����b�ȽT�{(�R�������b�Ȥ���)�C
 * (7) �����C�L�G�i�ھ������~��B�j�ӡBú�ں����@�����C�L�C
 * ���s���v  FUNC_ID = EPC10050
 * </pre>
 * 
 * [201800307] �ק��
 * ��ؾɤJ:���:�ץX�C����
 * 
 * @author �E�Ͷv
 * @since 2013-12-20
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC1_0050 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC1_0050.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l
     */
    public ResponseContext doPrompt(RequestContext req) {
        StringBuffer sb = new StringBuffer();
        String SUB_CPY_ID = null;
        try {
            SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
            resp.addOutputData("isCathayLife", new EP_Z00030().isAccountSubCpy(SUB_CPY_ID) ? "Y" : "N");// [201800307]�令EP_Z00030.isAccountSubCpy(SUB_CPY_ID)

            int iNEXT_YM = Integer.parseInt(DATE.getYearAndMonth((DATE.addDate(DATE.getDBDate(), 0, 1, 0))).toString()) - 191100;
            resp.addOutputData("RCV_YM", Integer.toString(iNEXT_YM));

        } catch (ErrorInputException e) {
            log.error("���o�����q�O����", e);
            sb.append(MessageUtil.getMessage("EPC1_0050_UI_MSG_001"));//���o�����q�O����
        }

        //���oú�ں���(�ȫO�d1�����B3�޲z�O�B4�X�����a�B5�H�����B7��L) 
        Map<String, Object> PAY_KIND_Map = FieldOptionList.getFieldOptions("EP", "PAY_KIND");
        Map PAY_KIND_List = new TreeMap();
        for (String key : PAY_KIND_Map.keySet()) {
            if ("1".equals(key) || "3".equals(key) || "4".equals(key) || "5".equals(key) || "7".equals(key) || "8".equals(key)) {
                PAY_KIND_List.put(key, PAY_KIND_Map.get(key));
            }
        }

        resp.addOutputData("PAY_KIND_List", PAY_KIND_List);

        //���o�f�֪��A
        Map<String, Object> OP_STATUS_Map = FieldOptionList.getFieldOptions("EPC", "OP_STATUS_C101");
        Map OP_STATUS_List = new TreeMap();
        for (String key : OP_STATUS_Map.keySet()) {
            if ("0".equals(key) || "10".equals(key) || "20".equals(key) || "30".equals(key) || "35".equals(key)) {
                OP_STATUS_List.put(key, OP_STATUS_Map.get(key));
            }
        }

        //���o�j�Ӹg��
        try {
            Map map = new HashMap();
            map.put("SUB_CPY_ID", SUB_CPY_ID);
            List<Map> BLD_USER_List = new EP_A10010().queryAgentList(map);
            resp.addOutputData("BLD_USER_List", BLD_USER_List);
        } catch (Exception e) {
            log.error("���o�j�Ӹg�쥢��", e);
            if (sb.length() > 0) {
                sb.append('�A');
            }
            sb.append(MessageUtil.getMessage("EPC1_0050_UI_MSG_019"));//���o�j�Ӹg�쥢��
        }
        //�b�Ⱥ����vACNT_TYPE_List  ��鲣�M��
        resp.addOutputData("ACNT_TYPE_List", FieldOptionList.getFieldOptions("EP", "ACNT_TYPE"));
        if (sb.length() > 0) {
            MessageUtil.setErrorMsg(msg, sb.toString());
        }

        //�q�l�o���}�l�ϥΤ�
        resp.addOutputData("ELE_INV_START_YM", FieldOptionList.getName("EP", "ELE_INV", "START_YM"));

        resp.addOutputData("OP_STATUS_List", OP_STATUS_List);
        resp.addOutputData("CURRENT_DATE", DATE.today());
        resp.addOutputData("EMP_ID", user.getEmpID());
        resp.addOutputData("EMP_NAME", user.getEmpName());
        resp.addOutputData("OP_UNIT", user.getOpUnit());

        return resp;
    }

    /**
     * �d��
     */
    public ResponseContext doQuery(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            this.query(reqMap, new EP_C10050());

            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002")); //�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, "MEP00001"); //�d�L���            
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028")); //�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003")); //�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003")); //�d�ߥ���
        }

        return resp;
    }

    /**
     * �T�{
     */
    public ResponseContext doConfirm(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            //[20200508] ���D��s�� 20191107-0012 �G�s�W�ˮ֡A�t�ζ}�߯�������ú�O�϶��O�_�P�W���۱�
            List<Map> reqList = VOTool.jsonAryToMaps(req.getParameter("reqList"));
            new EPC1_0050_mod().checkConfirm(reqList);

            List<DTEPC101> selectList = this.setVO(reqList, "EPC008", MapUtils.getString(reqMap, "SUB_CPY_ID"));

            EP_C10050 theEP_C10050 = new EP_C10050();

            Transaction.begin();
            try {
                //theEP_C10050.confirm(selectList, user);
                new EP_Z0C101().confirm(selectList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }
            MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_002"); //�T�{����

            //���d
            try {
                reqMap.put("OP_STATUS", "10");
                reqMap.put("isReQurey", "Y");
                this.query(reqMap, theEP_C10050);
            } catch (DataNotFoundException e) {
                log.error("�T�{�����A���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_003"); //�T�{�����A���d�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_0050_UI_MSG_004"); //�T�{����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_0050_UI_MSG_004"); //�T�{����
        }

        return resp;
    }

    /**
     * �����T�{
     */
    public ResponseContext doCancelConfirm(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<DTEPC101> selectList = this.setVO(VOTool.jsonAryToMaps(req.getParameter("reqList")), "EPC019", MapUtils.getString(reqMap, "SUB_CPY_ID")); //�������ӽT�{

            EP_C10050 theEP_C10050 = new EP_C10050();

            Transaction.begin();
            try {
                //theEP_C10050.cancelConfirm(selectList);
                new EP_Z0C101().cancelConfirm(selectList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_005"); //�����T�{����

            //���d
            try {
                reqMap.put("OP_STATUS", "0");
                reqMap.put("isReQurey", "Y");
                this.query(reqMap, theEP_C10050);
            } catch (DataNotFoundException e) {
                log.error("�����T�{�����A���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_006"); //�����T�{�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_0050_UI_MSG_007"); //�����T�{����
            }
        } catch (Exception e) {
            log.error("�����T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_0050_UI_MSG_007"); //�����T�{����
        }

        return resp;
    }

    /**
     * �Ю�
     */
    public ResponseContext doAprvConfirm(RequestContext req) {
        try {

            //List<DTEPC101> selectList = this.setVO(VOTool.jsonAryToMaps(req.getParameter("reqList")), "EPC018"); //�ЮֽT�{

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("LST_PROC_DIV", user.getOpUnit());
            reqMap.put("LST_PROC_DATE", DATE.currentTime());
            reqMap.put("LST_PROC_ID", user.getEmpID());
            reqMap.put("LST_PROC_NAME", user.getEmpName());
            reqMap.put("DIV_NO", user.getOpUnit());
            EP_C10050 theEP_C10050 = new EP_C10050();

            String rtnMsg;
            Transaction.begin();
            try {
                rtnMsg = theEP_C10050.aprvConfirm(reqMap, user);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            if (StringUtils.isNotBlank(rtnMsg)) { //��ةI�sws����
                throw new ModuleException(rtnMsg);
            } else {
                MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_008"); //�Ю֧���

                //���d
                try {
                    reqMap.put("OP_STATUS", "20");
                    reqMap.put("isReQurey", "Y");
                    this.query(reqMap, theEP_C10050);
                } catch (DataNotFoundException e) {
                    log.error("�Ю֧����A���d�d�L���", e);
                    MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_009"); //�Ю֧����A���d�d�L���
                }
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "�Ю֥���" + me.getMessage()); //�Ю֥���
            }
        } catch (Exception e) {
            log.error("�Ю֥���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_0050_UI_MSG_010"); //�Ю֥���
        }

        return resp;
    }

    /**
     * �����Ю�
     */
    public ResponseContext doCancelAprvConfirm(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("LST_PROC_DIV", user.getOpUnit());
            reqMap.put("LST_PROC_DATE", DATE.currentTime());
            reqMap.put("LST_PROC_ID", user.getEmpID());
            reqMap.put("LST_PROC_NAME", user.getEmpName());
            reqMap.put("DIV_NO", user.getOpUnit());
            EP_C10050 theEP_C10050 = new EP_C10050();

            List<Map> selectList = VOTool.jsonAryToMaps(req.getParameter("reqList"));

            Transaction.begin();
            try {
                theEP_C10050.cancelAprvConfirm(reqMap, selectList, user);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_020"); //�����Ю֧���

            //���d
            try {
                reqMap.put("OP_STATUS", "10");
                reqMap.put("isReQurey", "Y");
                this.query(reqMap, theEP_C10050);
            } catch (DataNotFoundException e) {
                log.error("�Ю֧����A���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_021"); //�����Ю֧����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "�����Ю֥���" + me.getMessage()); //�����Ю֥���
            }
        } catch (Exception e) {
            log.error("�Ю֥���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_0050_UI_MSG_022"); //�����Ю֥���
        }

        return resp;
    }

    /**
     * �b�ȽT�{
     */
    public ResponseContext doConfirmAcnt(RequestContext req) {
        try {

            //List<DTEPC101> selectList = this.setVO(VOTool.jsonAryToMaps(req.getParameter("reqList")), "EPC005"); //�ǲ����s

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("LST_PROC_DIV", user.getOpUnit());
            reqMap.put("LST_PROC_DATE", DATE.currentTime());
            reqMap.put("LST_PROC_ID", user.getEmpID());
            reqMap.put("LST_PROC_NAME", user.getEmpName());
            reqMap.put("DIV_NO", user.getOpUnit()); //�ӿ� ���

            //���o�ǲ����
            String SLIP_DATE = req.getParameter("SLIP_DATE");
            if (StringUtils.isBlank(SLIP_DATE)) {
                Date TODAY = DATE.today();
                String RCV_YM = MapUtils.getString(reqMap, "RCV_YM");
                Date ACNT_DATE = Date.valueOf(new StringBuilder().append(RCV_YM.substring(0, 4)).append("-").append(RCV_YM.substring(4, 6)).append("-").append("01").toString());

                if (!WorkDate.isWorkingDay(ACNT_DATE)) {
                    ACNT_DATE = new Date(WorkDate.getNextXWorkingDate(ACNT_DATE, 1).getTime());
                }

                if (ACNT_DATE.compareTo(TODAY) > 0) {
                    reqMap.put("ACNT_DATE", ACNT_DATE);
                } else {
                    if (WorkDate.isWorkingDay(TODAY)) {
                        reqMap.put("ACNT_DATE", TODAY);
                    } else {
                        reqMap.put("ACNT_DATE", new Date(WorkDate.getNextXWorkingDate(TODAY, 1).getTime()));
                    }
                }
            } else {
                reqMap.put("ACNT_DATE", SLIP_DATE);
            }

            //�ˮֶǲ���O�_���u�@��G
            new EPC1_0050_mod().checkAcntDate(reqMap);

            EP_C10050 theEP_C10050 = new EP_C10050();
            Transaction.setXAMode();
            Transaction.begin();
            try {
                Map rtnMap = theEP_C10050.confirmAcnt(reqMap, user);
                reqMap.put("ACNT_DATE", MapUtils.getString(rtnMap, "ACNT_DATE"));
                reqMap.put("SLIP_SET_NO", MapUtils.getString(rtnMap, "SLIP_SET_NO"));
                resp.addOutputData("rtnMap", rtnMap);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_011"); //�b�ȽT�{����

            //���d
            try {
                reqMap.put("OP_STATUS", "30");
                reqMap.put("isReQurey", "Y");
                this.query(reqMap, theEP_C10050);
            } catch (DataNotFoundException e) {
                log.error("�b�ȽT�{�����A���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_012"); //�b�ȽT�{�����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_0050_UI_MSG_013"); //�b�ȽT�{����
            }
        } catch (Exception e) {
            log.error("�b�ȽT�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_0050_UI_MSG_013"); //�b�ȽT�{����
        }

        return resp;
    }

    /**
     * �����b��
     */
    public ResponseContext doCancelConfirmAcnt(RequestContext req) {
        try {

            DTEPC101 C101VO = VOTool.jsonToVO(DTEPC101.class, req.getParameter("C101VO"));
            Map reqMap2 = VOTool.jsonToMap(req.getParameter("reqMap"));

            String ACNT_ID = user.getEmpID();
            Map reqMap = new HashMap();
            reqMap.put("LST_PROC_DIV", user.getOpUnit());
            reqMap.put("LST_PROC_DATE", DATE.currentTime());
            reqMap.put("LST_PROC_ID", user.getEmpID());
            reqMap.put("LST_PROC_NAME", user.getEmpName());
            reqMap.put("ACNT_DATE", C101VO.getACNT_DATE());
            reqMap.put("ACNT_DIV_NO", C101VO.getACNT_DIV_NO());
            reqMap.put("SLIP_SET_NO", C101VO.getSLIP_SET_NO());
            reqMap.put("SLIP_LOT_NO", C101VO.getSLIP_LOT_NO());
            reqMap.put("ACNT_ID", user.getEmpID());
            reqMap.put("ACNT_NAME", user.getEmpName());
            reqMap.put("SUB_CPY_ID", MapUtils.getString(reqMap2, "SUB_CPY_ID"));
            EPC1_0050_mod theEPC1_0050_mod = new EPC1_0050_mod();
            //CHECK�O�_�������b�H��
            theEPC1_0050_mod.checkAcntID(ACNT_ID, C101VO);
            //�ˮֶǲ��O�_���b�G�w���b���i�����T�{
            theEPC1_0050_mod.checkAcntData(C101VO);

            EP_C10050 theEP_C10050 = new EP_C10050();
            Transaction.setXAMode();
            Transaction.begin();
            try {
                //�R�������b�ȸ�Ƥζǲ���T
                theEP_C10050.cancelConfirmAcnt(reqMap);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_014"); //�����b�ȧ���

            //���d
            try {
                reqMap2.put("OP_STATUS", "20");
                reqMap2.put("ACNT_DATE", "");
                reqMap2.put("SLIP_SET_NO", "");
                reqMap.put("isReQurey", "Y");
                this.query(reqMap2, theEP_C10050);
            } catch (DataNotFoundException e) {
                log.error("�����b�ȧ����A���d�d�L���", e);
                MessageUtil.setMsg(msg, "EPC1_0050_UI_MSG_015"); //�����b�ȧ����A���d�d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_0050_UI_MSG_016"); //�����b�ȥ���
            }
        } catch (Exception e) {
            log.error("�����b�ȥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_0050_UI_MSG_016"); //�����b�ȥ���
        }

        return resp;
    }

    /**
     * �ץXEXCEL
     * @param req
     * @return
     */
    public ResponseContext doExportEXCEL(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("gridJSON", MapUtils.getString(reqMap, "gridJSON"));
            //�������Ӫ�
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM", "");
            String PAY_KIND_NM = MapUtils.getString(reqMap, "PAY_KIND_NM", "");
            StringBuilder sb = new StringBuilder();
            String fileName = sb.append(MessageUtil.getMessage("EPC1_0050_UI_MSG_017")).append(RCV_YM).append(PAY_KIND_NM).toString();
            reqMap.put("fileName", fileName);
            if ("30".equals(MapUtils.getString(reqMap, "OP_STATUS"))) {
                reqMap.put("ACNT_DIV_NO", user.getOpUnit()); //�b�ȳ��
            }
            reqMap.put("DIV_NO", user.getOpUnit()); //�ӿ� ���

            //�ץX
            List<Map> logSecurityList = new EP_C10050().exportXLS(reqMap, user, resp);
            logSecurity(logSecurityList);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_0050_UI_MSG_018");//�ɮפU������
            }
        } catch (Exception e) {
            log.error("�ɮפU������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_0050_UI_MSG_018");//�ɮפU������
        }
        return resp;
    }

    /**
     *  �ץXCsv [201800307]
     * @param req
     * @return
     */
    public ResponseContext doExportCsv(RequestContext req) {

        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("ACNT_DIV_NO", user.getOpUnit());
            List<Map> rtnList = new EP_C10050().queryForCsv(reqMap);

            //�������Ӫ�
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM", "");
            String PAY_KIND_NM = MapUtils.getString(reqMap, "PAY_KIND_NM", "");
            String ACNT_DATE = MapUtils.getString(reqMap, "ACNT_DATE", "");
            StringBuilder sb = new StringBuilder();
            //�ɦW:+�e��.�����~��+����������_��+�e��.ú�ں���(����)+�e��.�b��
            String fileName = sb.append(RCV_YM).append(MessageUtil.getMessage("EPC1_0050_UI_MSG_021")).append('_').append(PAY_KIND_NM).append(ACNT_DATE).toString();

            CsvUtils csvUtils = new CsvUtils(fileName, rtnList, resp);

            //�����D
            String[] colTitles = new String[] { "�����N��", "�Ȥ�W��", "�Τ@�s��", "�o�����X", "ú�ں���", "�o�����p", "�P���B", "��~�|�B", "�o�����B", "ú�کl��", "ú�ڲ״�", "�Ӽh�O", "�ǧO" };

            //���key
            String[] colKeys = new String[] { "CRT_NO", "CUS_NAME", "ID", "INV_NO", "PAY_KIND", "INV_CD", "SAL_AMT", "TAX_AMT", "INV_AMT", "PAY_S_DATE", "PAY_E_DATE", "FLD_NO", "ROOM_NO" };

            csvUtils.initExportSetting(colTitles, colKeys);

            //����ץX
            csvUtils.execute(new CsvUtils.ListProcessHandler() {
            });

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_0050_UI_MSG_018");//�ɮפU������
            }
        } catch (Exception e) {
            log.error("�ɮפU������", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_0050_UI_MSG_018");//�ɮפU������
        }
        return resp;
    }

    /**
     * �j�M����-�j�Ӹg��M��
     * @param req
     * @return
     */
    public ResponseContext doSuggestAGT(RequestContext req) {
        try {
            //�u�j�Ӹg���ĳ�M��v��ĳ���G 

            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_USR_NAME", req.getParameter("suggestValue"));

            List<Map> AGT_List = new EP_A10010().queryAgentList(reqMap);
            resp.addOutputData("suggestResult", AGT_List);
        } catch (DataNotFoundException dnfe) {
            log.debug("�j�Ӹg��j�M���ܬd�ߥ���");
        } catch (Exception e) {
            log.error("�j�Ӹg��j�M���ܬd�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_0050_MSG_019"); //�j�Ӹg��j�M���ܬd�ߥ���
        }
        return resp;
    }

    /**
     * �d��������
     */
    private void query(Map reqMap, EP_C10050 theEP_C10050) throws Exception {

        String OP_STATUS_reqMap = MapUtils.getString(reqMap, "OP_STATUS");
        if ("30".equals(OP_STATUS_reqMap) || "35".equals(OP_STATUS_reqMap)) {//�w�X�b �� �|�p�w�Ю� 
            reqMap.put("ACNT_DIV_NO", user.getOpUnit()); //�b�ȳ��
        }
        reqMap.put("DIV_NO", user.getOpUnit()); //�ӿ� ���
        // [20200204]�W�[�Ѽ�:UserObject user
        List<Map> resultList = theEP_C10050.query(reqMap, user);
        resp.addOutputData("resultList", resultList);

        //�p��X�p
        BigDecimal INV_AMT = BigDecimal.ZERO;
        BigDecimal TAX_AMT = BigDecimal.ZERO;
        BigDecimal SPR_AMT = BigDecimal.ZERO;
        BigDecimal SAL_AMT = BigDecimal.ZERO;
        BigDecimal RNT_AMT = BigDecimal.ZERO;
        BigDecimal PRP_AMT = BigDecimal.ZERO;
        List<Map> logSecurityList = new ArrayList<Map>();
        //�p�G�D�ɫȤ᪬�p(B102_PAY_CD)���G1.�����`�ΡG2.�������ʤ��A�h���֭p�X�p���
        for (Map resultMap : resultList) {
            //logSecurity
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", resultMap.get("ID"));
            logSecurityMap.put("CUS_NAME", resultMap.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);

            String B102_PAY_CD = MapUtils.getString(resultMap, "B102_PAY_CD");
            String OP_STATUS = MapUtils.getString(resultMap, "OP_STATUS");
            if ("99".equals(OP_STATUS)) {
                continue;
            }
            if (!"1".equals(B102_PAY_CD) && !"2".equals(B102_PAY_CD)) {
                INV_AMT = INV_AMT.add(this.obj2Big(resultMap.get("INV_AMT")));
                TAX_AMT = TAX_AMT.add(this.obj2Big(resultMap.get("TAX_AMT")));
                SPR_AMT = SPR_AMT.add(this.obj2Big(resultMap.get("SPR_AMT")));
                SAL_AMT = SAL_AMT.add(this.obj2Big(resultMap.get("SAL_AMT")));
                RNT_AMT = RNT_AMT.add(this.obj2Big(resultMap.get("RNT_AMT")));
                PRP_AMT = PRP_AMT.add(this.obj2Big(resultMap.get("PRP_AMT")));
            }
        }

        logSecurity(logSecurityList);

        Map TotalMap = new HashMap();
        //�o�����B(INV_AMT)
        TotalMap.put("INV_AMT", INV_AMT);
        //�P���B(SAL_AMT)
        TotalMap.put("SAL_AMT", SAL_AMT);
        //�����|�B(TAX_AMT)
        TotalMap.put("TAX_AMT", TAX_AMT);
        //�����l�B(SPR_AMT)
        TotalMap.put("SPR_AMT", SPR_AMT);
        //���믲��(RNT_AMT)
        TotalMap.put("RNT_AMT", RNT_AMT);
        //�w������(PRP_AMT)
        TotalMap.put("PRP_AMT", PRP_AMT);
        resp.addOutputData("TotalMap", TotalMap);
    }

    /**
     * �]�w������DTEPC101_VO
     * @param reqList �ǤJ�����ɸ��
     * @param TRN_KIND �������
     * @return �]�w�������ɸ��
     */
    private List<DTEPC101> setVO(List<Map> reqList, String TRN_KIND, String SUB_CPY_ID) {

        List<DTEPC101> selectList = new ArrayList<DTEPC101>();
        String EMP_ID = user.getEmpID();
        String EMP_NAME = user.getEmpName();
        String OP_UNIT = user.getOpUnit();
        boolean istrue = "EPC008".equals(TRN_KIND) || "EPC018".equals(TRN_KIND);

        for (Map reqMap : reqList) {
            DTEPC101 C101VO = VOTool.mapToVO(DTEPC101.class, reqMap);
            C101VO.setLST_PROC_ID(EMP_ID); //�@�~�H��ID 
            C101VO.setLST_PROC_NAME(EMP_NAME); //�@�~�H���m�W
            C101VO.setLST_PROC_DIV(OP_UNIT); //�@�~���
            String B102_PAY_CD = MapUtils.getString(reqMap, "B102_PAY_CD");
            if (istrue && StringUtils.isNotBlank(B102_PAY_CD)) {//����,�䥦�i��L�������,�קK�\��
                C101VO.setPAY_CD(MapUtils.getString(reqMap, "B102_PAY_CD")); //�Ȥ᪬�p
            }
            C101VO.setTRN_KIND(TRN_KIND); //�������
            C101VO.setSUB_CPY_ID(SUB_CPY_ID);
            selectList.add(C101VO);
        }

        return selectList;
    }

    /**
     * �N�����নBigDecimal
     * @param o ����
     * @return  
     * @throws ErrorInputException 
     */
    private BigDecimal obj2Big(Object o) {
        if (o != null) {
            if (o instanceof BigDecimal) {
                return (BigDecimal) o; //�Y�ǤJ����BigDecimal�A�h�Ǧ^BigDecimal
            }
            if (NumberUtils.isNumber(o.toString())) {
                return new BigDecimal(o.toString()); //�Y�ǤJ���󤧼Ʀr����BigDecimal�A�h�নBigDecimal�Ǧ^
            }
            return BigDecimal.ZERO; //�Y�ǤJ����D�Ʀr�A�h�^��0
        }
        return BigDecimal.ZERO; //�Y����null�h�^��0
    }

}
