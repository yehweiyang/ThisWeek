package com.cathay.ep.c1.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.c1.module.EP_C14030;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.rpt.RptUtils;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date Description Author
 * <pre>
 * 2013/8/12   Created �\�a�s

 * UCEPC1_4030_�H�Υd�дھP�b�@�~

 * �@�B  �{���\�෧�n�����G
 * �{���\��    �H�Υd�дھP�b�@�~
 * �{���W��    EPC1_4030
 * �@�~�覡    ONLINE
 * ���n����    
 * (1) �d�ߡG�d�߫H�Υd�дھP�b���
 * (2) �U���G�N�d�X������ഫ��txt����, �൹�Ȧ�
 * (3) �W�ǡG�N�Ȧ�^�Ǫ���ƤW��, ��X��e���W
 * (4) �P�b�G�N�W�Ǫ���ƾP�b
 *</pre>
 * @author �����@ 
 * @since 2013/12/20
 * 
 * [20200413]�ק�{���X
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC1_4030 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC1_4050.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);
        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        resp.addOutputData("DIV_NO", user.getDivNo());

        EP_Z00030 theEP_Z00030 = new EP_Z00030();
        try {

            String SUB_CPY_ID = theEP_Z00030.getSUB_CPY_ID(user);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);//�����q�O

            try {
                if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                    resp.addOutputData("CLCDVList", FieldOptionList.getFieldOptions("EPC", "CLCDV"));
                } else {
                    resp.addOutputData("CLCDVList", FieldOptionList.getFieldOptions("EP", "AGT_DIV_" + SUB_CPY_ID));
                }
            } catch (ErrorInputException e) {
                log.error("��l���~", e);
                MessageUtil.setErrorMsg(msg, "��l���~");
            }
        } catch (Exception e) {
            log.error("���o�����q�O����", e);
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            //�d�߸��
            List<Map> rtnList = new EP_C14030().queryList(reqMap);

            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map rtnMap : rtnList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("AUTH_ID", rtnMap.get("AUTH_ID"));
                logSecurityMap.put("CARD_NO", rtnMap.get("CARD_NO"));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);

            resp.addOutputData("rtnList", rtnList);//, user.getDivNo()));
            totalAMT(rtnList);
            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("MEP00002"));//�d�ߧ���

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPA1_0020_MSG_006"));//�@�~����
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPA1_0020_MSG_006"), e);//�@�~����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPA1_0020_MSG_006"));//�@�~����
        }

        return resp;
    }

    /**
     * �U��
     * @param req
     * @return
     */
    public ResponseContext doDownload(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> rtnList = new ArrayList<Map>();

            //�d�߸��
            rtnList = new EP_C14030().queryList(reqMap);//user.getDivNo());

            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map rtnMap : rtnList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("AUTH_ID", rtnMap.get("AUTH_ID"));
                logSecurityMap.put("CARD_NO", rtnMap.get("CARD_NO"));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);

            String Rptpath = RptUtils.createTempFile("53.txt").getAbsolutePath();

            // [20200413]�ק�{���X: �U������令�H�H
            // [20200430]�s�W�H�H�������Ҿ���
            reqMap.put("INPUT_ID", user.getEmpID());
            reqMap.put("INPUT_DIV_NO", user.getDivNo());
            // ���o�����ɮ�
            new EP_C14030().data2Rpt(rtnList, Rptpath, reqMap);

            MessageUtil.setReturnMessage(msg, ReturnCode.OK, MessageUtil.getMessage("EPC1_4030_MSG_004")); // ���ʹC���ɦ��\
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC1_4030_MSG_001")); // ���ʹC���ɥ���
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPC1_4030_MSG_001"), e); // ���ʹC���ɥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_4030_MSG_001")); // ���ʹC���ɥ���
        }

        return resp;
    }

    /**
     * �ץXEXCEL
     * @param req
     * @return
     */
    public ResponseContext doExportXLS(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            reqMap.put("gridJSON", MapUtils.getString(reqMap, "gridJSON"));
            reqMap.put(
                "fileName",
                new StringBuilder().append(MessageUtil.getMessage("EPC1_4030_MSG_003")).append('_')
                        .append(DATE.toDate_yyyyMMdd(DATE.getDBDate())).append(".xls").toString());//�H�Υd�дڤU��
            //�ץX
            List<Map> rtnList = new EP_C14030().export(reqMap, user, resp);

            //logSecurity
            List<Map> logSecurityList = new ArrayList<Map>();
            for (Map rtnMap : rtnList) {
                Map logSecurityMap = new HashMap();
                logSecurityMap.put("AUTH_ID", rtnMap.get("AUTH_ID"));
                logSecurityMap.put("CARD_NO", rtnMap.get("CARD_NO"));
                logSecurityList.add(logSecurityMap);
            }
            logSecurity(logSecurityList);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, dnfe.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error(me.getMessage(), me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, "EPC1_4030_MSG_002");//�ɮ׶ץX����
            }
        } catch (Exception e) {
            log.error("�ɮ׶ץX����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_4030_MSG_002");//�ɮ׶ץX����
        }
        return resp;
    }

    /**
     * �X�p��� SPR_AMT
     * @param rtnList
     */
    private void totalAMT(List<Map> rtnList) {
        BigDecimal SPR_AMT = BigDecimal.ZERO;
        for (Map map : rtnList) {
            SPR_AMT = SPR_AMT.add(getBigDecimal(map.get("SPR_AMT")));
        }
        Map TOTMap = new HashMap();
        TOTMap.put("SPR_AMT", SPR_AMT);
        resp.addOutputData("TOTMap", TOTMap);
    }

    /**
     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getBigDecimal(Object obj) {
        if (obj != null) {
            if (BigDecimal.class.isInstance(obj)) {
                return (BigDecimal) obj;
            }
            String value = obj.toString();
            if (NumberUtils.isNumber(value)) {
                return new BigDecimal(value);
            }
        }
        return BigDecimal.ZERO;
    }
}
