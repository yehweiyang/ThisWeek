package com.cathay.ep.c1.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.DATE;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.a1.module.EP_A10010;
import com.cathay.ep.c1.module.EP_C14010;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.util.ReturnCode;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * Date Description Author
 * 2013/8/2    Created �\�a�s

 * UCEPC1_4010_�ʦ����ӧ@�~

 * �@�B  �{���\�෧�n�����G
 * �{���\��    �ʦ����ӧ@�~
 * �{���W��    EPC1_4010
 * �@�~�覡    ONLINE
 * ���n����    
 * (1) �d�ߡG�ʦ����Ӹ�Ƭd��
 * (2) �ʦ���C�L�G�C�L�H�ʮ榡�ʦ���
 * (3) ��ú���Ӫ��G�C�L�����`/���ʤ��M��

 * @author �����@ 
 * @since 2014/1/3
 * 
 * 2019/07/15 �©s�� �ק�query��k
 * 
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC1_4010 extends UCBean {

    /* log */
    private static final Logger log = Logger.getLogger(EPC1_4010.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {
        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        resp.setResponseCode("success");
    }

    /**
     * ��l
     * @param req
     * @return
     * @throws ModuleException 
     */
    public ResponseContext doPrompt(RequestContext req) {

        //�u�Ȥ᪬�p�v�U�Կ��
        resp.addOutputData("CUS_STS_ONEList", FieldOptionList.getFieldOptions("EPC", "CUS_STS_ONE"));

        //�uú�ں����v�U�Կ��
        resp.addOutputData("PAY_KIND_ONEList", FieldOptionList.getFieldOptions("EPC", "PAY_KIND_THREE"));

        resp.addOutputData("CLCDVNO", user.getDivNo());

        resp.addOutputData("DCT_TYPEList", FieldOptionList.getFieldOptions("EP", "DCT_TYPE"));

        try {
            Map map = new HashMap();
            EP_Z00030 theEP_Z00030 = new EP_Z00030();
            String SUB_CPY_ID = theEP_Z00030.getSUB_CPY_ID(user);

            map.put("SUB_CPY_ID", SUB_CPY_ID);
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
            //�g��U�Կ��
            resp.addOutputData("BLD_USRList", new EP_A10010().queryAgentList(map));

            //�u�ӿ��O�v�U�Կ��
            if (theEP_Z00030.isAccountSubCpy(SUB_CPY_ID)) {
                resp.addOutputData("CLCDVList", FieldOptionList.getFieldOptions("EPC", "CLCDV"));
            } else {
                resp.addOutputData("CLCDVList", FieldOptionList.getFieldOptions("EP", "AGT_DIV_" + SUB_CPY_ID));
            }
        } catch (Exception e) {
            resp.addOutputData("BLD_USRList", new ArrayList());
        }
        return resp;
    }

    /**
     * �d��
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");

            //�B�zRCV_YM start
            BigDecimal RCV_YM_bd = null;
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM", "").trim();
            if (StringUtils.isNotBlank(RCV_YM) && StringUtils.isNumeric(RCV_YM) && DATE.isROCDate(RCV_YM + "01", false)) {
                RCV_YM_bd = new BigDecimal(RCV_YM);
            }
            String CUS_STS = MapUtils.getString(reqMap, "CUS_STS");

            List<Map> rtnList = new ArrayList<Map>();

            String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
            if ("A".equals(PAY_KIND)) {
                //[20190715] �p�GPAY_KIND�O"����"(value="A")�h��queryAllDuePayList
                rtnList = new EP_C14010().queryAllDuePayList(reqMap);
            } else {
                //[20190715] �Y���O�d�����h�έ쥻��queryList
                rtnList = new EP_C14010().queryList(SUB_CPY_ID, RCV_YM_bd, PAY_KIND, CUS_STS, MapUtils.getString(reqMap, "BLDUS"),
                    MapUtils.getString(reqMap, "BLDUSNM"), MapUtils.getString(reqMap, "CLCDV"), MapUtils.getString(reqMap, "DCT_TYPE"));
            }

            //�B�zRCV_YM end
            List<Map> logSecurityList = new ArrayList<Map>();
            if ("0".equals(CUS_STS)) {
                BigDecimal TOTAL_SPR_AMT = BigDecimal.ZERO;
                for (Map map : rtnList) {
                    Map logSecurityMap = new HashMap();
                    logSecurityMap.put("CUS_NAME", map.get("CUS_NAME"));
                    logSecurityList.add(logSecurityMap);

                    TOTAL_SPR_AMT = TOTAL_SPR_AMT.add(getBigDecimal(map.get("SPR_AMT"), BigDecimal.ZERO));
                }
                resp.addOutputData("SPR_AMT", TOTAL_SPR_AMT);
            } else {
                BigDecimal TOTAL_RNT_AMT = BigDecimal.ZERO;
                for (Map map : rtnList) {
                    Map logSecurityMap = new HashMap();
                    logSecurityMap.put("CUS_NAME", map.get("CUS_NAME"));
                    logSecurityList.add(logSecurityMap);

                    TOTAL_RNT_AMT = TOTAL_RNT_AMT.add(getBigDecimal(map.get("RNT_AMT"), BigDecimal.ZERO));
                    resp.addOutputData("RNT_AMT", TOTAL_RNT_AMT);
                }
            }
            logSecurity(logSecurityList);

            resp.addOutputData("rtnList", rtnList);
            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("MEP00003"), e);//�d�ߥ���
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �U��
     * @param req
     * @return
     */
    public ResponseContext doDownload(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            //�B�zRCV_YM start
            BigDecimal RCV_YM_bd = null;
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM", "").trim();
            if (StringUtils.isNotBlank(RCV_YM) && StringUtils.isNumeric(RCV_YM)) {
                RCV_YM_bd = new BigDecimal(RCV_YM);
            }
            //�B�zRCV_YM end

            //�����ɦW
            reqMap.put("fileName",
                new StringBuilder(MessageUtil.getMessage("EPC1_4010_MSG_011")).append("_").append(DATE.toDate_yyyyMMdd(DATE.getDBDate())));

            List<Map> rtnLogSecurityList = new EP_C14010().queryByAllforExcel(SUB_CPY_ID, RCV_YM_bd,
                MapUtils.getString(reqMap, "PAY_KIND"), MapUtils.getString(reqMap, "CUS_STS"), MapUtils.getString(reqMap, "BLDUS"),
                MapUtils.getString(reqMap, "BLDUSNM"), MapUtils.getString(reqMap, "CLCDV"), MapUtils.getString(reqMap, "DCT_TYPE"), reqMap,
                resp, user);
            logSecurity(rtnLogSecurityList);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC1_4010_MSG_009"));//�U�����󥢱�
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPC1_4010_MSG_009"), e);//�U�����󥢱�
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_4010_MSG_009"));//�U�����󥢱�
        }

        return resp;
    }

    /**
     * �ʦ���C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint1(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> checkList = VOTool.jsonAryToMaps(req.getParameter("checkList"));
            //�B�zRCV_YM start
            BigDecimal RCV_YM_bd = null;
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM", "").trim();
            if (StringUtils.isNotBlank(RCV_YM) && StringUtils.isNumeric(RCV_YM)) {
                RCV_YM_bd = new BigDecimal(RCV_YM);
            }
            //�B�zRCV_YM end
            EP_C14010 theEP_C14010 = new EP_C14010();

            Map prtMap = theEP_C14010.doFmtRpt1(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(reqMap, "BLDUS"),
                MapUtils.getString(reqMap, "BLDUSNM"), MapUtils.getString(reqMap, "CLCDV"), RCV_YM_bd, checkList);
            logSecurity(prtMap);
            theEP_C14010.prtRpt1(prtMap, resp);

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());

        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC1_4010_MSG_010"));//�C�L����

            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPC1_4010_MSG_010"), e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_4010_MSG_010"));//�C�L����
        }

        return resp;
    }

    /**
     * ��ú���Ӫ��C�L
     * @param req
     * @return
     */
    public ResponseContext doPrint2(RequestContext req) {

        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            EP_C14010 the_EP_C14010 = new EP_C14010();
            //�B�zRCV_YM start
            BigDecimal RCV_YM_bd = null;
            boolean defaultYM = false;
            String RCV_YM = MapUtils.getString(reqMap, "RCV_YM", "").trim();
            if (StringUtils.isNotBlank(RCV_YM) && StringUtils.isNumeric(RCV_YM)) {
                RCV_YM_bd = new BigDecimal(RCV_YM);
            } else {
                defaultYM = true;
            }
            //�B�zRCV_YM end
            String PAY_KIND = MapUtils.getString(reqMap, "PAY_KIND");
            if ("0".equals(MapUtils.getString(reqMap, "CUS_STS"))) {
                List<Map> rptList = the_EP_C14010.queryForRpt2(MapUtils.getString(reqMap, "SUB_CPY_ID"),
                    MapUtils.getString(reqMap, "CUS_STS"), PAY_KIND, RCV_YM_bd, MapUtils.getString(reqMap, "BLDUS"),
                    MapUtils.getString(reqMap, "BLDUSNM"), MapUtils.getString(reqMap, "CLCDV"));

                //logSecurity
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map rtnMap : rptList) {
                    Map logSecurityMap = new HashMap();
                    logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);

                Map map = the_EP_C14010.doFmtRpt2("1", rptList, PAY_KIND, user, defaultYM);
                the_EP_C14010.prtRpt2(map, resp, req);
            } else {
                Map map = the_EP_C14010.doFmtRpt22(MapUtils.getString(reqMap, "SUB_CPY_ID"), MapUtils.getString(reqMap, "CUS_STS"),
                    PAY_KIND, RCV_YM_bd, MapUtils.getString(reqMap, "BLDUS"), MapUtils.getString(reqMap, "BLDUSNM"),
                    MapUtils.getString(reqMap, "CLCDV"), user);

                //logSecurity
                List<Map> rtnList = (List<Map>) map.get("detail");
                List<Map> logSecurityList = new ArrayList<Map>();
                for (Map rtnMap : rtnList) {
                    Map logSecurityMap = new HashMap();
                    logSecurityMap.put("CUS_NAME", rtnMap.get("CUS_NAME"));
                    logSecurityList.add(logSecurityMap);
                }
                logSecurity(logSecurityList);

                the_EP_C14010.prtRpt22(map, resp);
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("EPC1_4010_MSG_010"));//�C�L����
            }
        } catch (Exception e) {
            log.error(MessageUtil.getMessage("EPC1_4010_MSG_010"), e);//�C�L����
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_4010_MSG_010"));//�C�L����
        }

        return resp;
    }

    /**
     * �j�M����-�j�Ӹg��M��
     * @param req
     * @return
     */
    public ResponseContext doSuggestAGT(RequestContext req) {
        try {
            //�u�j�Ӹg���ĳ�M��v��ĳ���G 

            Map reqMap = new HashMap();
            reqMap.put("SUB_CPY_ID", req.getParameter("SUB_CPY_ID"));
            reqMap.put("BLD_USR_NAME", req.getParameter("suggestValue"));

            List<Map> AGT_List = new EP_A10010().queryAgentList(reqMap);
            resp.addOutputData("suggestResult", AGT_List);
        } catch (DataNotFoundException dnfe) {
            log.debug("�j�Ӹg��j�M���ܬd�ߥ���");
        } catch (Exception e) {
            log.error("�j�Ӹg��j�M���ܬd�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, "EPC1_4010_MSG_013"); //�j�Ӹg��j�M���ܬd�ߥ���
        }
        return resp;
    }

    /**
     * �૬�A�M���w�]
     * 
     * @param obj
     * @return
     */
    private BigDecimal getBigDecimal(Object obj, BigDecimal defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }
        String str = obj.toString();
        if (NumberUtils.isNumber(str)) {
            return new BigDecimal(str);
        }
        return defaultValue;
    }

}
