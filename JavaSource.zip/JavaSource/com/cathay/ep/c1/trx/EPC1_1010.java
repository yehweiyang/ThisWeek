package com.cathay.ep.c1.trx;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.exception.OverCountLimitException;
import com.cathay.common.im.util.MessageUtil;
import com.cathay.common.im.util.VOTool;
import com.cathay.common.service.authenticate.UserObject;
import com.cathay.common.trx.UCBean;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.IConstantMap;
import com.cathay.common.util.NumberUtils;
import com.cathay.ep.c1.module.EPC1_1010_mod;
import com.cathay.ep.c1.module.EP_C11010;
import com.cathay.ep.c1.module.EP_C11011;
import com.cathay.ep.z0.module.EP_Z00030;
import com.cathay.ep.z0.module.EP_Z0C102;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.igsapp.common.trx.ServiceException;
import com.igsapp.common.trx.TxException;
import com.igsapp.wibc.dataobj.Context.RequestContext;
import com.igsapp.wibc.dataobj.Context.ResponseContext;

/**
 * <pre>
 * Date        Description  Author
 * 2013-08-08   Created     ���|��
 * 
 *  UCEPC1_1010_�կ��թ�B�z�@�~
 *
 *  �@�B  �{���\�෧�n�����G
 *  �{���\��    �կ��թ�B�z�@�~
 *  �{���W��    EPC1_1010
 *  �@�~�覡    ONLINE
 *  ���n����    ���\�ध�D�n�ت����N�C��C��կ��թ㫴����ƨöi��T�{�P�Ю֡C
 *  (1) �d�ߡG��ܿ�J���զ~��B�ӿ��O�B�կ��覡�B�կ������B�i�סB�����N���B�Ȥ�Ǹ��A�d�߽կ��թ��ơC
 *  (2) ���G�̿�J�����զ~�����կ��թ��ơC
 *  (3) �T�{�G�̤Ŀ諸�կ��թ��ƶi��T�{�C
 *  (4) �����T�{�G�̤Ŀ諸�կ��թ��ƶi������T�{�C
 *  (5) �Ю֡G�̤Ŀ諸�կ��թ��ƶi���Ю֡C
 *  (6) �C�L�����G���ͽկ��թ�����C
 *</pre>
 * @author ù�ΫT
 * @since 2013/12/31
 */
@SuppressWarnings("unchecked")
public class EPC1_1010 extends UCBean {

    /** �R�A�� log ���� **/
    private static final Logger log = Logger.getLogger(EPC1_1010.class);

    /** �� TxBean �{���X�@�Ϊ� ResponseContext */
    private ResponseContext resp;

    /** �� TxBean �{���X�@�Ϊ� ReturnMessage */
    private ReturnMessage msg;

    /** �� TxBean �{���X�@�Ϊ� UserObject */
    private UserObject user;

    /** �мg�����O�� start() �H�j���C�� Dispatcher �I�s method �ɳ�����{���۩w����l�ʧ@ **/
    public ResponseContext start(RequestContext req) throws TxException, ServiceException {
        super.start(req); //�@�w�n invoke super.start() �H�����v���ˮ�
        initApp(req); //�I�s�۩w����l�ʧ@
        return null;
    }

    /**
     * �{���۩w����l�ʧ@�A�q�`�����X ResponseContext, UserObject, 
     * �γ]�w ReturnMessage �� response code.
     * @throws TxException 
     */
    private void initApp(RequestContext req) throws TxException {

        // �إߦ� TxBean �q�Ϊ�����
        resp = this.newResponseContext();
        msg = new ReturnMessage();
        user = this.getUserObject(req);

        // ���N ReturnMessage �� reference �[�� response context
        resp.addOutputData(IConstantMap.ErrMsg, msg);

        // �b Cathay �q�`�u���@�� page �b�e�� display�A�ҥH�i�H���]�w
        // �]�w�^�Ǫ������W�١A�L�|��name�ۦP���ǤJ
        resp.setResponseCode("success");
    }

    /**
     * ��l����
     * @param req
     * @return
     */
    public ResponseContext doPrompt(RequestContext req) {
        VOTool.setParamsFromLP_JSON(req);

        resp.addOutputData("CRT_NO", req.getParameter("CRT_NO"));
        resp.addOutputData("CUS_NO", req.getParameter("CUS_NO"));

        resp.addOutputData("DIV_NO", user.getOpUnit());//��J�H�����
        StringBuilder sb = new StringBuilder();//�������~�T��

        try {
            String SUB_CPY_ID = new EP_Z00030().getSUB_CPY_ID(user); // �����q�O
            resp.addOutputData("SUB_CPY_ID", SUB_CPY_ID);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            sb.append(eie.getMessage());
        }

        //�կ��覡
        try {
            resp.addOutputData("ADJ_TYPE", FieldOptionList.getFieldOptions("EP", "ADJ_TYPE"));
        } catch (Exception e) {
            log.error("���o�u�կ��覡�v�U�Կ�楢��", e);
            sb.append(MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_LIST_ADJ_TYPE"));//���o�u�կ��覡�v�U�Կ�楢��
        }
        //�i��
        try {
            resp.addOutputData("OP_STATUS", FieldOptionList.getFieldOptions("EP", "OP_STATUS_C"));
        } catch (Exception e) {
            log.error("���o�u�i�סv�U�Կ�楢��", e);
            sb.append(MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_LIST_OP_STATUS"));//���o�u�i�סv�U�Կ�楢��
        }

        if (sb.length() > 0) {
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR, sb.toString());
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doQuery(RequestContext req) {
        try {
            //�d�ߩ㯲�����Ӹ��
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            this.query(reqMap);
            MessageUtil.setMsg(msg, MessageUtil.getMessage("MEP00002"));//�d�ߧ���
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * ��@�d��
     * @param reqMap
     * @return
     * @throws ModuleException
     * @throws Exception
     */
    private List<Map> query(Map reqMap) throws ModuleException, Exception {
        String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");//�����q�O

        EP_C11010 ep_c11010 = new EP_C11010();
        List<Map> resultList = null;
        List<Map> logSecurityList = null;
        if ("on".equals(MapUtils.getString(reqMap, "SELECT1"))) {
            String ADJ_YM_1 = MapUtils.getString(reqMap, "ADJ_YM_1");
            new EPC1_1010_mod().checkExt(SUB_CPY_ID, ADJ_YM_1);//�����q�O�B���զ~��
            resp.addOutputData("rtnList", ep_c11010.queryEPC105(SUB_CPY_ID, "2", ADJ_YM_1));
        } else if ("on".equals(MapUtils.getString(reqMap, "SELECT2"))) {
            resultList = ep_c11010.query1(SUB_CPY_ID, MapUtils.getString(reqMap, "ADJ_YM_2"), MapUtils.getString(reqMap, "DIV_NO"),
                MapUtils.getString(reqMap, "ADJ_TYPE"), MapUtils.getString(reqMap, "OP_STATUS"));
            resultList = ep_c11010.formateAddAmt(resultList);
            logSecurityList = culAMT(resultList);
            resp.addOutputData("rtnList", resultList);
            resp.addOutputData("isPrint", true);//�d�ߦ���ƫh�}��C�L�������s
        } else if ("on".equals(MapUtils.getString(reqMap, "SELECT3"))) {
            resultList = ep_c11010.query2(SUB_CPY_ID, MapUtils.getString(reqMap, "ADJ_YM_3"), MapUtils.getString(reqMap, "CRT_NO"),
                MapUtils.getString(reqMap, "CUS_NO"));
            resultList = ep_c11010.formateAddAmt(resultList);
            logSecurityList = culAMT(resultList);
            resp.addOutputData("rtnList", resultList);
            resp.addOutputData("isPrint", true);//�d�ߦ���ƫh�}��C�L�������s
        } else {
            throw new ErrorInputException(MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_CHECK_SELECT"));//�Цܤ��I��@��!
        }

        if (logSecurityList != null) {
            logSecurity(logSecurityList);
        }

        return resultList;

    }

    /**
     * ���B�X�p
     * @param resultList
     */
    private List<Map> culAMT(List<Map> resultList) {
        BigDecimal ART_AMT_SUM = BigDecimal.ZERO;
        BigDecimal APM_AMT_SUM = BigDecimal.ZERO;
        BigDecimal ADD_AMT_SUM = BigDecimal.ZERO;
        BigDecimal TARNT_AMT = BigDecimal.ZERO;
        BigDecimal TAPMS_AMT = BigDecimal.ZERO;

        List<Map> logSecurityList = new ArrayList<Map>();
        for (Map map : resultList) {
            Map logSecurityMap = new HashMap();
            logSecurityMap.put("ID", map.get("ID"));
            logSecurityMap.put("CUS_NAME", map.get("CUS_NAME"));
            logSecurityList.add(logSecurityMap);

            //�վ�᯲��
            BigDecimal ART_AMT = getBigDecimal(map, "ART_AMT");
            BigDecimal ARNT_AMT = ART_AMT.add(getBigDecimal(map, "RNT_AMT"));
            map.put("ARNT_AMT", ARNT_AMT);
            //�վ����
            BigDecimal APM_AMT = getBigDecimal(map, "APM_AMT");
            BigDecimal APMS_AMT = APM_AMT.add(getBigDecimal(map, "PMS_AMT"));
            map.put("APMS_AMT", APMS_AMT);

            ART_AMT_SUM = ART_AMT_SUM.add(ART_AMT);
            APM_AMT_SUM = APM_AMT_SUM.add(APM_AMT);
            ADD_AMT_SUM = ADD_AMT_SUM.add(getBigDecimal(map, "ADD_AMT"));
            TARNT_AMT = TARNT_AMT.add(ARNT_AMT);
            TAPMS_AMT = TAPMS_AMT.add(APMS_AMT);
        }

        resp.addOutputData("TARNT_AMT", TARNT_AMT);
        resp.addOutputData("TAPMS_AMT", TAPMS_AMT);
        resp.addOutputData("ART_AMT_SUM", ART_AMT_SUM);
        resp.addOutputData("APM_AMT_SUM", APM_AMT_SUM);
        resp.addOutputData("ADD_AMT_SUM", ADD_AMT_SUM);
        return logSecurityList;
    }

    /**
     * ���B�z
     * @param req
     * @return
     */
    public ResponseContext doInsert(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");//�����q�O
            String ADJ_YM_1 = MapUtils.getString(reqMap, "ADJ_YM_1");//���զ~��

            //�ˮ֬O�_�w���
            new EPC1_1010_mod().checkExt(SUB_CPY_ID, ADJ_YM_1);//�����q�O�B���զ~��
            //����w����b���
            List resultList = new EP_C11010().query3(SUB_CPY_ID, ADJ_YM_1, "", "");

            Transaction.begin();
            try {
                //���կ��թ���Ӽg��
                new EP_C11011().insert(resultList, ADJ_YM_1, user.getEmpID(), user.getEmpName(), user.getOpUnit(), "1", SUB_CPY_ID);
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_INSERT_COMPLETE"));//��󧹦�
            try {
                this.query(reqMap);
            } catch (DataNotFoundException e) {
                log.error("�d�L���", e);
                MessageUtil.setMsg(msg, "EPC1_1010_UI_ERRMSG_REVIEW_QUERY");//��󧹦��A�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil
                        .getMessage("EPC1_1010_UI_ERRMSG_INSERT_FAILED"));//��󥢱�
            }
        } catch (Exception e) {
            log.error("��󥢱�", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_INSERT_FAILED"));//��󥢱�
        }

        return resp;
    }

    /**
     * �T�{
     * @param req
     * @return
     * @throws ModuleException
     */
    public ResponseContext doConfirm(RequestContext req) throws ModuleException {
        try {
            List<Map> checklist = VOTool.jsonAryToMaps(req.getParameter("checklist"));

            //�կ��թ�T�{
            Transaction.begin();
            try {
                new EP_Z0C102().confirm(checklist, user.getEmpID(), user.getEmpName(), user.getOpUnit());
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_CONFIRM_COMPLETE"));//�T�{����

            //���s�d�߸��
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            try {
                this.query(reqMap);
            } catch (DataNotFoundException dnfe) {
                MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_CONFIRM_QUERY"));//�T�{����, ���d�d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil
                        .getMessage("EPC1_1010_UI_ERRMSG_CONFIRM_FAILED"));//�@�~����
            }
        } catch (Exception e) {
            log.error("�T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_CONFIRM_FAILED"));//�@�~����
        }

        return resp;
    }

    /**
     * �����B�z
     * @param req
     * @return
     */
    public ResponseContext doCancel(RequestContext req) {
        try {
            List<Map> checklist = VOTool.jsonAryToMaps(req.getParameter("checklist"));

            Transaction.begin();
            try {
                //�կ��թ�����T�{
                new EP_Z0C102().unconfirm(checklist, user.getEmpID(), user.getEmpName(), user.getOpUnit());
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_CANCEL_COMPLETE"));//�����T�{����

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            try {
                this.query(reqMap);
            } catch (DataNotFoundException dnfe) {
                MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_CANCEL_QUERY"));//�����T�{����, ���d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil
                        .getMessage("EPC1_1010_UI_ERRMSG_CANCEL_FAILED"));//�@�~����
            }
        } catch (Exception e) {
            log.error("�����T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_CANCEL_FAILED"));//�@�~����
        }

        return resp;
    }

    /**
     * �Ю�
     * @param req
     * @return
     */
    public ResponseContext doReview(RequestContext req) {
        try {
            List<Map> checklist = VOTool.jsonAryToMaps(req.getParameter("checklist"));

            Transaction.begin();
            String strMsg;
            try {
                //�կ��թ��Ю֨è��o�Юִ����T��
                strMsg = new EP_C11011().approve(checklist, user.getEmpID(), user.getEmpName(), user.getOpUnit());
                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_REVIEW_COMPLETE") + strMsg);//�Ю֧���

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            try {
                this.query(reqMap);
            } catch (DataNotFoundException dnfe) {
                MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_REVIEW_QUERY"));//�Ю֧���, ���d�L���
            }
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil
                        .getMessage("EPC1_1010_UI_ERRMSG_REVIEW_FAILED"));//�@�~����
            }
        } catch (Exception e) {
            log.error("�����T�{����", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_REVIEW_FAILED"));//�@�~����
        }

        return resp;
    }

    /**
     * �d��
     * @param req
     * @return
     */
    public ResponseContext doPrint(RequestContext req) {
        try {
            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));
            List<Map> resultList = this.query(reqMap);
            EP_C11010 ep_C11010 = new EP_C11010();
            //Call�կ��թ�B�z�d�߼Ҳ�
            Map printMap = ep_C11010.printFormat(user, resultList);
            //Call�կ��թ�B�z�d�߼Ҳ�.�C�L���ӲM���k
            ep_C11010.print(printMap, resp);
        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (DataNotFoundException dnfe) {
            log.error("", dnfe);
            MessageUtil.setReturnMessage(msg, ReturnCode.DATA_NOT_FOUND, MessageUtil.getMessage("MEP00001"));//�d�L���
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                if (me.getRootException() instanceof OverCountLimitException) {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00028"));//�d�ߵ��ƶW�X�t�έ���A���Y�p�d�߽d��
                } else {
                    MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
                }
            }
        } catch (Exception e) {
            log.error("�d�ߥ���", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("MEP00003"));//�d�ߥ���
        }

        return resp;
    }

    /**
     * �ഫBigDecimal�榡
     * @param obj �ǤJ����
     * @return
     */
    private BigDecimal getBigDecimal(Map map, String key) {
        Object obj = map.get(key);
        if (obj != null) {
            if (BigDecimal.class.isInstance(obj)) {
                return (BigDecimal) obj;
            }
            String value = obj.toString();
            if (NumberUtils.isNumber(value)) {
                return new BigDecimal(value);
            }
        }
        return BigDecimal.ZERO;
    }

    /**
     * ���ɩ�
     * @param req
     * @return
     */
    public ResponseContext doReInsert(RequestContext req) {
        try {

            Map reqMap = VOTool.jsonToMap(req.getParameter("reqMap"));

            EPC1_1010_mod theEPC1_1010_mod = new EPC1_1010_mod();
            EP_C11010 theEP_C11010 = new EP_C11010();
            EP_C11011 theEP_C11011 = new EP_C11011();

            String SUB_CPY_ID = MapUtils.getString(reqMap, "SUB_CPY_ID");
            String ADJ_YM1 = MapUtils.getString(reqMap, "ADJ_YM_1");
            String CRT_NO = MapUtils.getString(reqMap, "CRT_NO");
            String CUS_NO = MapUtils.getString(reqMap, "CUS_NO");

            //�ˮ֬O�_�w���
            theEPC1_1010_mod.checkExt2(SUB_CPY_ID, ADJ_YM1);//�����q�O�B���զ~��
            //���o��կ����
            List<Map> resultList;
            try {
                resultList = theEP_C11010.query2(SUB_CPY_ID, ADJ_YM1, CRT_NO, CUS_NO);
                //IF �����:�ˮָӵ������O�_�w�Ю�
                theEPC1_1010_mod.checkCrtNo(resultList);//�կ��թ����
            } catch (DataNotFoundException dnfe) {
                //IF �d�L��ơA�������`
                log.error("resultList,�d�L��Ƶ������`");
                resultList = Collections.EMPTY_LIST;
            }

            Transaction.begin();
            try {
                String empId = user.getEmpID();
                String opunit = user.getOpUnit();

                if (!resultList.isEmpty()) {
                    new EP_Z0C102().delete(resultList);
                }
                //����կ��թ���
                resultList = theEP_C11010.query3(SUB_CPY_ID, ADJ_YM1, CRT_NO, CUS_NO);

                //���կ��թ���Ӽg��
                theEP_C11011.insert(resultList, ADJ_YM1, empId, user.getEmpName(), opunit, "2", SUB_CPY_ID);

                Transaction.commit();
            } catch (Exception e) {
                Transaction.rollback();
                throw e;
            }

            MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_REINSERT_COMPLETE"));//���ɩ⧹��

            try {
                this.query(reqMap);
            } catch (DataNotFoundException dnfe) {
                MessageUtil.setMsg(msg, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_REINSERT_QUERY"));//���ɩ⧹��, ���d�L���
            }

        } catch (ErrorInputException eie) {
            log.error("", eie);
            MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_INPUT, eie.getMessage());
        } catch (ModuleException me) {
            if (me.getRootException() == null) {
                log.error("", me);
                MessageUtil.setReturnMessage(msg, ReturnCode.ERROR_MODULE, me.getMessage());
            } else {
                log.error(me.getMessage(), me.getRootException());
                MessageUtil.setReturnMessage(msg, me, req, ReturnCode.ERROR_MODULE, MessageUtil
                        .getMessage("EPC1_1010_UI_ERRMSG_REVIEW_FAILED"));//���ɩ⥢��
            }
        } catch (Exception e) {
            log.error("���ɩ⥢��", e);
            MessageUtil.setReturnMessage(msg, e, req, ReturnCode.ERROR, MessageUtil.getMessage("EPC1_1010_UI_ERRMSG_REVIEW_FAILED"));////���ɩ⥢��
        }

        return resp;
    }
}
