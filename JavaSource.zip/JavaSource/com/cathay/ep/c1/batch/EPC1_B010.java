package com.cathay.ep.c1.batch;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cathay.common.bo.ReturnMessage;
import com.cathay.common.exception.DataNotFoundException;
import com.cathay.common.exception.ErrorInputException;
import com.cathay.common.exception.ModuleException;
import com.cathay.common.util.DATE;
import com.cathay.common.util.EmptyTableHelper;
import com.cathay.common.util.FieldOptionList;
import com.cathay.common.util.LoginUtil;
import com.cathay.common.util.STRING;
import com.cathay.common.util.batch.BatchProcesser;
import com.cathay.common.util.batch.CountManager;
import com.cathay.common.util.batch.ErrorHandler;
import com.cathay.common.util.batch.ErrorLog;
import com.cathay.common.util.batch.GroupHandler;
import com.cathay.common.util.db.DBUtil;
import com.cathay.ep.b1.module.EP_B1Z002;
import com.cathay.ep.b3.module.EP_B30010;
import com.cathay.ep.module.EP_BatchBean;
import com.cathay.ep.vo.DTEPZ103;
import com.cathay.ep.z1.module.EP_Z10030;
import com.cathay.rz.s0.module.RZ_S00300;
import com.cathay.util.ReturnCode;
import com.cathay.util.Transaction;
import com.cathay.zz.x0.module.ZZ_X0Z004;
import com.igsapp.db.BatchQueryDataSet;
import com.igsapp.db.BatchUpdateDataSet;
import com.igsapp.db.DBException;
import com.igsapp.db.DataSet;

/** 
 * <pre>
 * Date    Version Description Author
 * 2013/11/26  1.0 Created ���|��
 * 2018/02/01  �t�X��ؽվ� ����[
 * 
 * �@�B  �{���\�෧�n�����G
 * �{���\��    �����������@�~
 * �{���W��    EPC1_B010.java
 * �@�~�覡    BATCH
 * ���n����    ��﫴���C�����������P�o����گ����O�_�@�P
 * �w����ƶq   
 * �@�~�W��    
 * �~�ȧO EP
 * ���t�ΦW��   C1
 * �B�z�g��    ��
 * ����B�z���  �w�]��
 * 
 * [20181105] Modified �H�H���~�B�z
 * </pre>
 * @author �¶��� 
 * @since 2013/12/19  
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EPC1_B010 extends EP_BatchBean { //�~��BatchBean

    /** log */
    private static final Logger log = Logger.getLogger(EPC1_B010.class);

    /**  �@�~�W�� */
    private static final String JOB_NAME = "EPC1_B010";

    /** �{���W�� */
    private static final String PROGRAM = "EPC1_B010";

    /** �~�ȧO */
    private static final String BUSINESS = "EP";

    /** ���t�ΦW�� */
    private static final String SUBSYSTEM = "C1";

    /** ����g�� */
    private static final String PERIOD = "��";

    /** �]�� true �Ѥ����O�p�Ƥμg���~�T��, false �Шϥ� ErrorLog ��CountManager �ۦ�g���~�T���έp�� */
    private static final boolean isAUTO_WRITELOG = false;

    private static final String INPUT_COUNT_1 = "IFRS�o���ɶ�����J���";

    private static final String INPUT_COUNT_2 = "IFRS�C������������J���";

    private static final String INPUT_COUNT_3 = "����J���";

    private static final String ERROR_COUNT = "���~���";

    private static final String ERR_CNT1 = "�������~����";

    private static final String DTEPC208_OUTPUT_COUNT = "DTEPC208��X���";

    private static final String DTEPC205_OUTPUT_COUNT = "DTEPC205��X���";

    private static final String SQL_query_001 = "com.cathay.ep.c1.batch.EPC1_B010.SQL_query_001";

    private static final String SQL_query_002 = "com.cathay.ep.c1.batch.EPC1_B010.SQL_query_002";

    private static final String SQL_query_003 = "com.cathay.ep.c1.batch.EPC1_B010.SQL_query_003";

    private static final String SQL_query_004 = "com.cathay.ep.c1.batch.EPC1_B010.SQL_query_004";

    private static final String SQL_insert_001 = "com.cathay.ep.c1.batch.EPC1_B010.SQL_insert_001";

    private static final String SQL_update_001 = "com.cathay.ep.c1.batch.EPC1_B010.SQL_update_001";

    private static final String tableNameDTEPC208 = "IFRS�ꦬ���Ȧs�ɡ]DTEPC208�^";

    private static final String tableNameDTEPC205 = " IFRS�o���ɡ]DTEPC205�^";

    private static final String actionNameByInsert = "�s�W";

    private static final String actionNameByUpdate = "�ק�";

    private static final BigDecimal BigDecimal_5 = new BigDecimal("5");;

    /** �d�ߪ����� */
    private BatchQueryDataSet bqds;

    private BatchUpdateDataSet buds_INSERT;

    /** �M�����O�@�Τ����~�T���O������ */
    private ErrorLog errorLog;

    /** �p�ƾ� */
    private CountManager countManager;

    /**�̿��~���h�Ũ��o���~�����*/
    private ErrorHandler errorHandler;

    /**�P�@�妸�h�� table ���� , �������~����� , �ñN���T����Ƽg�J*/
    private GroupHandler groupHandler;

    /**���s����*/
    private BatchProcesser batchProcesser;

    private StringBuffer sbf;

    /**�ˮ֥N�X*/
    private Map<String, String> CHK_TYPE_CODE;

    /** ���ˮֲM��*/
    private Map<String, String> noChkMap;

    /**���`��ƲM��*/
    private List<Map> chkList;

    /**ExitCode�O�_�g-1�P�_*/
    private boolean isCode101;

    /** ������ */
    private Date currentDate = DATE.today();

    private static final String SQL_insert_002 = "com.cathay.ep.c1.batch.EPC1_B010.SQL_insert_002";

    public EPC1_B010() throws Exception {

        //�]�w�����O���غc�l,�ǤJ true �Ѥ����O�p�Ƥμg���~�T��
        super(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD, log, isAUTO_WRITELOG);

        //���~�T���O������
        countManager = new CountManager(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM, PERIOD);

        errorLog = new ErrorLog(JOB_NAME, PROGRAM, BUSINESS, SUBSYSTEM);

        errorHandler = new ErrorHandler();

        sbf = new StringBuffer();

        chkList = new ArrayList();

        isCode101 = false;

        groupHandler = new GroupHandler();
        batchProcesser = new BatchProcesser();

        CHK_TYPE_CODE = new HashMap<String, String>();
        CHK_TYPE_CODE.put("2", "��ú���B���]�w");
        CHK_TYPE_CODE.put("3", "�d�L�ꦬ���B���");
        CHK_TYPE_CODE.put("4", "���B��藍��");
        CHK_TYPE_CODE.put("5", "��ú���B���]�w�B�d�L�ꦬ���B���");

        noChkMap = new HashMap<String, String>();
        noChkMap = FieldOptionList.getName("EP", "IFRS_CRT_CUS");
        //        noChkMap.put("A1921007561", "A1921007561");
        //        noChkMap.put("A1921066541", "A1921066541");

        initCountManager();
        bqds = getBatchQueryDataSet();
        buds_INSERT = getBatchUpdateDataSet();

    }

    public void execute(String args[]) throws Exception { //����妸�@�~      

        try {
            ZZ_X0Z004 theZZ_X0Z004 = new ZZ_X0Z004(PROGRAM);

            try {
                //[2019.03.28]�s�Wonline submit batch�\��
                String[] theArgs;
                //��online_batch�A���ܬOonline
                if (args.length > 0 && args[0].indexOf("online_batch") != -1) {
                    //�z�LZZ�Ҳը��o�ǻ��Ѽ�
                    //�]��online submit batch�ݭn2�ӰѼ� //��2�ӰѼ�:�ǻ��Ѽƪ��ƶq
                    /*String[] ZZ_X0Z007args = new ZZ_X0Z007(PROGRAM).retrieveParam(null, 0);

                    if (ZZ_X0Z007args == null) {
                        setExitCode(ERROR);
                        throw new ErrorInputException("�ǤJ�Ѽƿ��~");
                    }*/
                    theArgs = new String[] {};
                } else {
                    //�ǤJ�Ѽ�
                    theArgs = args;
                }

                //�z�L�u�W�妸����Ҳհ���A�ŧi�妸�}�l
                ReturnMessage rm = new ReturnMessage();
                theZZ_X0Z004.startBatch(rm);
                if (rm.getReturnCode() != ReturnCode.OK) {
                    String errorMsg = "��﫴���C�����������P�o����گ����O�_�@�P�o�Ϳ��~";
                    setExitCode(ERROR);
                    log.error(errorMsg);
                    throw new ModuleException(errorMsg);
                }

                this.theExecute(theArgs);
            } finally {

                try {
                    //�z�L�u�W�妸����Ҳհ���A�ŧi�妸����
                    ReturnMessage rm = new ReturnMessage();
                    theZZ_X0Z004.endBatch(rm);
                    if (rm.getReturnCode() != ReturnCode.OK) {
                        String errorMsg = "��﫴���C�����������P�o����گ����O�_�@�P�o�Ϳ��~";
                        setExitCode(ERROR);
                        log.error(errorMsg);
                        throw new ModuleException(errorMsg);
                    }
                } catch (Exception e) {
                    log.fatal("", e);
                }
            }

        } catch (Exception e) {
            log.fatal("����ɵo�Ϳ��~", e);
            setExitCode(isCode101 ? 101 : ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�

        } finally {

            log.fatal(countManager); //����

            if (countManager != null) {
                countManager.writeLog(); //�g�J��ưO����  
            }

            // �����Ҧ����s�u
            if (bqds != null) {
                bqds.close();
            }
            if (buds_INSERT != null) {
                buds_INSERT.close();
            }

            printExitCode(getExitCode()); //�^�ǵ� Control_M ���T���N�X , �{���פ�
        }
    }

    //  *********************************************** Private Method  ************************************************/

    private void theExecute(String args[]) throws Exception {
        String PAY_DATE; //ú�ڤ��
        String PAY_YYYYMM;//ú�ڦ~��
        String SUB_CPY_ID;//�����q�O
        try {

            //                if (args != null && args.length > 0 && StringUtils.isNotBlank(args[0])) {
            //                    PAY_DATE = args[0];
            //                    if (!DATE.isDate(PAY_DATE)) {
            //                        throw new ErrorInputException("�Ѽƿ��~");
            //                    }
            //                } else {
            //                    PAY_DATE = DATE.getLastMonthLastDate();//�W�Ӥ몺�̫�@��
            //                }
            if (args != null && args.length > 0) {
                if (StringUtils.isNotBlank(args[0])) {
                    PAY_DATE = args[0];
                    if (!DATE.isDate(PAY_DATE)) {
                        throw new ErrorInputException("�Ѽƿ��~");
                    }
                } else {
                    PAY_DATE = DATE.getLastMonthLastDate();//�W�Ӥ몺�̫�@��
                }
                if (args.length > 1) {
                    if (StringUtils.isNotBlank(args[1])) {
                        SUB_CPY_ID = args[1];
                    } else {
                        SUB_CPY_ID = "00";
                    }
                } else {
                    SUB_CPY_ID = "00";
                }

            } else {
                PAY_DATE = DATE.getLastMonthLastDate();//�W�Ӥ몺�̫�@��
                SUB_CPY_ID = "00";
            }

            PAY_YYYYMM = DATE.getYearAndMonth(PAY_DATE); //ú�ڦ~��

        } catch (Exception e) {
            String memo = "�Ѽƿ��~";
            log.fatal(memo, e);
            errorLog.addErrorLog(memo, e);
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            countManager.addCountNumber(ERR_CNT1, errorCount);
            throw e;
        }

        //�P�_IFRS�C��������粒���T�{�ɬO�_�w�g����
        //�ˮ�IFRS�C��������粒���T�{�ɬO�_�T�{����
        DataSet ds = Transaction.getDataSet();
        try {
            ds.clear();
            ds.setField("PAY_YYYYMM", PAY_YYYYMM);
            ds.setField("SUB_CPY_ID", SUB_CPY_ID);
            DBUtil.searchAndRetrieve(ds, SQL_query_004);
            ds.next();
            int CNT = (Integer) ds.getField("CNT");
            if (CNT > 0) {
                log.fatal("IFRS�C��������粒���T�{�ɤw����");
                return;
            }
        } catch (Exception e) {
            String memo = "�ˮ�IFRS�C��������粒���T�{�ɲ��`";
            log.fatal(memo, e);
            errorLog.addErrorLog(memo, e);
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            countManager.addCountNumber(ERROR_COUNT, errorCount);
            throw e;
        }

        //�M��DTEPC208(IFRS�ꦬ���Ȧs��)
        try {
            ds.clear();
            new EmptyTableHelper().alterWithEmptyTable("DBEP", "DTEPC208", ds);
        } catch (Exception e) {
            String memo = "�M��IFRS�ꦬ���Ȧs��(DTEPC208)���`";
            log.fatal(memo, e);
            errorLog.addErrorLog(memo, e);
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            countManager.addCountNumber(ERROR_COUNT, errorCount);
            throw e;
        }

        //�ǳ�IFRS�o���ɶ���諸���
        this.insertToTemp1(PAY_YYYYMM, SUB_CPY_ID);

        //�ǳ�IFRS�C����������諸��Ƽg�J�Ȧs��
        this.insertToTemp2(PAY_DATE, PAY_YYYYMM, SUB_CPY_ID);

        //���o�����
        int inputCnt = this.classifyandUpdateData(PAY_YYYYMM, SUB_CPY_ID);
        if (chkList.size() != 0) {
            this.sendMail(SUB_CPY_ID);
        } else if (inputCnt > 0) {
            try {
                //chkList ����:
                //�s�WDTEPC210 IFRS�C��������粒���T�{�ɬO�_�T�{
                Transaction.begin();
                try {
                    ds.clear();
                    ds.setField("RCV_YM", PAY_YYYYMM);//�����~��
                    ds.setField("INPUT_DATE", DATE.currentTime());//���ɧ�������ɶ�
                    ds.setField("SUB_CPY_ID", SUB_CPY_ID);
                    //�X�b��������ɶ� CFM_DATE null
                    DBUtil.executeUpdate(ds, SQL_insert_002);
                    Transaction.commit();
                } catch (Exception e) {
                    log.fatal("", e);
                    Transaction.rollback();
                    throw e;
                }
            } catch (Exception e) {
                String memo = "�s�WIFRS�C��������粒���T�{��(DTEPC210)���`";
                log.fatal(memo, e);
                errorLog.addErrorLog(memo, e);
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                countManager.addCountNumber(ERROR_COUNT, errorCount);
                throw e;
            }
        }
    }

    /**
     * ��l�p��
     * @throws ModuleException
     */
    private void initCountManager() throws ModuleException {
        countManager.createCountType("START");
        countManager.writeLog();
        countManager.clearCountTypeAndNumber();
        countManager.createCountType(INPUT_COUNT_1);
        countManager.createCountType(INPUT_COUNT_2);
        countManager.createCountType(INPUT_COUNT_3);
        countManager.createCountType(ERROR_COUNT);
        countManager.createCountType(ERR_CNT1);
        countManager.createCountType(DTEPC208_OUTPUT_COUNT);
        countManager.createCountType(DTEPC205_OUTPUT_COUNT);
    }

    /**
     * ����妸�ðO����X��ƥB�B�z���~��
     * @param action
     * @param buds
     * @param sql
     * @param tableName
     * @param executeStatusType
     * @return
     * @throws DBException
     */
    private int executeBatchByBatchUpdateDataSet(String action, BatchUpdateDataSet buds, String sql, String tableName, int executeStatusType)
            throws DBException {

        //�^�ǰ��檺���G , �i�Ѧҳ̤U�����N�X��
        int buds_Ret[] = buds.executeBatch();

        //���]���~���}�C
        Object errObject[][] = errorHandler.getErrorArray(buds.getBatchUpdateErrorArray(), buds_Ret, buds.getBatchMapsArray(),
            executeStatusType);

        //executebatch���~�B�z
        //�^�Ǫ����� �� Object[i][3] , 
        //Object[i][0] �N���ĴX�����~ , index �� 0 �}�l ,
        //Object[i][1] �� Map , ���ܿ��~�� key �� value
        //Object[i][2] ��SQLException , �i�� SQLSTATE �� CODE �P�_��ؿ��~
        if (errObject != null && errObject.length > 0) {

            for (int i = 0; i < errObject.length; i++) {

                Map errorDataMap = (Map) errObject[i][1];
                sbf.append(action).append(tableName).append("���`");
                if (actionNameByInsert.equals(action)) {
                    sbf.append("�F�����N�� = ").append(errorDataMap.get("CRT_NO"));
                    sbf.append("�B�Ȥ�Ǹ� = ").append(errorDataMap.get("CUS_NO"));
                    sbf.append("�B�����~�� = ").append(errorDataMap.get("RCV_YM"));
                    sbf.append("�B�ꦬ��� = ").append(errorDataMap.get("PAY_YYYYMM"));
                } else {
                    sbf.append("�F�o�����X  = ").append(errorDataMap.get("INV_NO"));
                }
                String message = sbf.toString();
                sbf.setLength(0);

                errorLog.addErrorLog(message, errObject[i][2]);

            }
        }

        //���XaddBatch�������
        int outputCount = buds_Ret.length;

        //�N��X��Ʀ�����Insert�ɵo�ͪ����~
        outputCount -= errObject.length;

        groupHandler.removeIndex(errObject, sql);

        return outputCount;

    }

    /**
     * 
     * @param buds
     * @param sql
     * @return
     * @throws DBException
     */
    private int reDoBatchByBatchUpdateDataSet(BatchUpdateDataSet buds, String sql) throws DBException {

        //���o���T�����
        List redoList = groupHandler.filterExecuteList(buds.getBatchMapsArray(), sql);

        //�]�w redo ���Ѽ�
        batchProcesser.setFields(redoList, buds);

        //���s����
        int output[] = buds.executeBatch();

        return output.length;

    }

    /**
     * �]�w�ǤJ IFRS�ꦬ���Ȧs�ɡ]DTEPC208�^���Ѽ�
     * @param nowRCV_YM
     * @param type
     */
    private void setbuds_INSERT_Fields(String nowRCV_YM, String type) {

        //�����N��
        buds_INSERT.setField("CRT_NO", bqds.getField("CRT_NO"));
        //�Ȥ�Ǹ�
        buds_INSERT.setField("CUS_NO", bqds.getField("CUS_NO"));
        //�����~��
        buds_INSERT.setField("RCV_YM", nowRCV_YM);
        buds_INSERT.setField("SUB_CPY_ID", bqds.getField("SUB_CPY_ID"));
        if ("1".equals(type)) {
            //�ꦬ���
            buds_INSERT.setField("PAY_YYYYMM", bqds.getField("PAY_S_DATE"));
            //�o�����X
            buds_INSERT.setField("INV_NO", bqds.getField("INV_NO"));
            //�ˮ֥N�X
            buds_INSERT.setField("CHK_TYPE", bqds.getField("CHK_TYPE"));

        } else {
            //�ꦬ���
            buds_INSERT.setField("PAY_YYYYMM", currentDate);
            //�o�����X
            buds_INSERT.setField("INV_NO", "");
            //�ˮ֥N�X
            buds_INSERT.setField("CHK_TYPE", null);
        }

    }

    /**
     *  �զ��o����T���
     * @param DTAKK035Map
     */
    private Map getInvNoMap() {
        Map<String, Object> invNoMap = new HashMap<String, Object>();
        invNoMap.put("INV_NO_C205", bqds.getField("INV_NO_C205")); //    �o�����X 
        invNoMap.put("INV_CD", bqds.getField("INV_CD"));// �o�����O
        invNoMap.put("SAL_AMT", bqds.getField("SAL_AMT"));//    �P����B
        invNoMap.put("TAX_AMT", bqds.getField("TAX_AMT"));//    �P���|�B
        invNoMap.put("TAX_TYPE", bqds.getField("TAX_TYPE"));//   �|�O
        invNoMap.put("SLIP_DATE", bqds.getField("SLIP_DATE_C205"));//  �����ǲ����
        invNoMap.put("CHK_TYP", bqds.getField("CHK_TYPE"));//   �ˮ֥N�X
        invNoMap.put("INV_NO_C207", bqds.getField("INV_NO_C207"));//    �w�X�b�o�����X
        invNoMap.put("RJT_AMT", bqds.getField("RJT_AMT"));//    �������B
        invNoMap.put("RCV_YM_C209", bqds.getField("RCV_YM_C209"));//    �w�X�b�����~��
        invNoMap.put("PAY_S_DATE", bqds.getField("PAY_S_DATE"));// ú�ڰ_��
        invNoMap.put("PAY_E_DATE", bqds.getField("PAY_E_DATE"));// ú�ڨ���
        invNoMap.put("MON_BRK", bqds.getField("MON_BRK"));//    �O�_���뵲��
        invNoMap.put("RNT_STR_DATE", bqds.getField("RNT_STR_DATE"));//   �����_��

        return invNoMap;
    }

    /**
     * EMAIL����]�w
     * @param titleList
     * @param FIELD
     * @param FIELD_NM
     * @param FIELD_SIZE
     */
    private void titleList(List<Map> titleList, String FIELD, String FIELD_NM, int FIELD_SIZE) {
        Map<String, Object> styleMap = new HashMap<String, Object>();
        styleMap.put("FIELD", FIELD);
        styleMap.put("FIELD_NM", FIELD_NM);
        styleMap.put("FIELD_SIZE", FIELD_SIZE);
        titleList.add(styleMap);
    }

    /**
     * ��l�s���ܼ�
     * @return
     */
    private Map<String, Object> initValueMap() {
        Map<String, Object> valueMap = new HashMap<String, Object>();
        valueMap.put("keyCRT_NO", bqds.getField("CRT_NO_C208"));
        valueMap.put("keyCUS_NO", bqds.getField("CUS_NO_C208"));
        valueMap.put("keyINV_NO", bqds.getField("INV_NO_C205"));
        valueMap.put("groupBLD_CD", bqds.getField("BLD_CD"));
        valueMap.put("groupCUS_NAME", bqds.getField("CUS_NAME"));
        valueMap.put("groupRCV_YM_C208", bqds.getField("RCV_YM_C208"));
        return valueMap;
    }

    /**
     * @throws DBException
     * @throws ModuleException
     */
    private void executeBatchUpdateDTEPC205() throws DBException, ModuleException {
        int countByUpdateDTEPC205 = executeBatchByBatchUpdateDataSet(actionNameByUpdate, buds_INSERT, SQL_update_001, tableNameDTEPC205,
            ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

        groupHandler.displayRevomeIndex();

        //�Y�S�����~�� index �s�b
        if (groupHandler.isSuccess()) {

            buds_INSERT.endTransaction();

            countManager.addCountNumber(DTEPC205_OUTPUT_COUNT, countByUpdateDTEPC205);

            //�Y�����~�� index �s�b
        } else {

            setExitCode(ERROR);

            buds_INSERT.rollbackTransaction();

            buds_INSERT.beginTransaction();

            int reDocountByUpdateDTEPC205 = reDoBatchByBatchUpdateDataSet(buds_INSERT, SQL_update_001);

            buds_INSERT.endTransaction();

            countManager.addCountNumber(DTEPC205_OUTPUT_COUNT, reDocountByUpdateDTEPC205);

        }
    }

    /**
     * �ǳ�IFRS�o���ɶ���諸���
     * @param PAY_YYYYMM
     * @throws Exception
     */
    private void insertToTemp1(String PAY_YYYYMM, String SUB_CPY_ID) throws Exception {

        try {
            bqds.clear();
            bqds.setField("PAY_YYYYMM", PAY_YYYYMM);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            searchAndRetrieve(bqds, SQL_query_001);

        } catch (Exception e) {
            String memo = "Ū�����`";
            log.fatal(memo, e);
            errorLog.addErrorLog(memo, e);
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            countManager.addCountNumber(ERROR_COUNT, errorCount);
            throw e;
        }

        int INPUT_CNT_1 = getInputCount();

        if (INPUT_CNT_1 == 0) {
            log.fatal("Ū��IFRS�o���ɶ�����Ƭd�L���");
            return;
        }
        countManager.addCountNumber(INPUT_COUNT_1, INPUT_CNT_1); //�]�w��X���

        EP_B1Z002 theEP_B1Z002 = new EP_B1Z002();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");

        buds_INSERT.preparedBatch(SQL_insert_001);
        for (prepareFetch(); fetchData(bqds); goNext()) { //�������

            buds_INSERT.beginTransaction(); //�������}�l

            try {

                // �v���B�z
                while (bqds.next()) {
                    //����l�ѼơG
                    Date PAY_S_DATE = (Date) bqds.getField("PAY_S_DATE");
                    Date PAY_E_DATE = (Date) bqds.getField("PAY_E_DATE");
                    Date RNT_STR_DATE = (Date) bqds.getField("RNT_STR_DATE");
                    if (PAY_S_DATE == null) {
                        sbf.append("�Bú�کl�� (PAY_S_DATE)���o���ŭ�");
                    }
                    if (PAY_E_DATE == null) {
                        sbf.append("�Bú�ڲ״� (PAY_E_DATE)���o���ŭ�");
                    }
                    if (RNT_STR_DATE == null) {
                        sbf.append("�B�_�����(RNT_STR_DATE)���o���ŭ�");
                    }

                    if (sbf.length() > 0) {
                        String chkMsg = sbf.substring(1).toString();
                        sbf.setLength(0);
                        throw new ErrorInputException(chkMsg);
                    }

                    //�O�_�}��
                    String strMonBrk = DATE.diffDay(RNT_STR_DATE, PAY_S_DATE) == 0 ? (String) bqds.getField("MON_BRK") : "";
                    //�`�����
                    int totMonth = theEP_B1Z002.getTotMonth(PAY_S_DATE.toString(), PAY_E_DATE.toString(), strMonBrk);
                    int cnt = 0;//�w�B�z�����

                    groupHandler.begin();

                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(PAY_S_DATE);
                    while (cnt < totMonth) {
                        //�����~��
                        String nowRCV_YM = sdf.format(calendar.getTime());
                        setbuds_INSERT_Fields(nowRCV_YM, "1");
                        calendar.add(Calendar.MONTH, 1);//�[�@�Ӥ�
                        cnt++;

                        buds_INSERT.addBatch();
                        groupHandler.joinGroup(SQL_insert_001);
                    }

                    groupHandler.end();

                }// while loop end

                int countByInsertDTEPC208 = executeBatchByBatchUpdateDataSet(actionNameByInsert, buds_INSERT, SQL_insert_001,
                    tableNameDTEPC208, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                groupHandler.displayRevomeIndex();

                //�Y�S�����~�� index �s�b
                if (groupHandler.isSuccess()) {

                    buds_INSERT.endTransaction();

                    countManager.addCountNumber(DTEPC208_OUTPUT_COUNT, countByInsertDTEPC208);

                    //�Y�����~�� index �s�b
                } else {

                    setExitCode(ERROR);

                    buds_INSERT.rollbackTransaction();

                    buds_INSERT.beginTransaction();

                    int reDocountByInsertDTEPC208 = reDoBatchByBatchUpdateDataSet(buds_INSERT, SQL_insert_001);

                    buds_INSERT.endTransaction();

                    countManager.addCountNumber(DTEPC208_OUTPUT_COUNT, reDocountByInsertDTEPC208);

                }

            } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                buds_INSERT.rollbackTransaction(); //�^�_��媺�@�~
                setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
                log.fatal("���榳�~", e);
                errorLog.addErrorLog("���榳�~", e);
                throw e; //�Y�o�Ϳ��~�h�{���X�פ�

            } finally {

                groupHandler.clear();
                //�g�X���~��ưO���� , �C�@�����@��               
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                //�������~���
                countManager.addCountNumber(ERROR_COUNT, errorCount);

            }

        } //for loop end
    }

    /**
     * �ǳ�IFRS�C����������諸��Ƽg�J�Ȧs��
     * @param PAY_YYYYMM
     * @throws Exception
     */
    private void insertToTemp2(String PAY_DATE, String PAY_YYYYMM, String SUB_CPY_ID) throws Exception {

        try {

            bqds.clear();
            bqds.setField("PAY_DATE", PAY_DATE);
            bqds.setField("PAY_YYYYMM", PAY_YYYYMM);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            searchAndRetrieve(bqds, SQL_query_002);

        } catch (Exception e) {
            String memo = "Ū�����`";
            log.fatal(memo, e);
            errorLog.addErrorLog(memo, e);
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            countManager.addCountNumber(ERROR_COUNT, errorCount);
            throw e;
        }

        int INPUT_CNT = getInputCount();

        if (INPUT_CNT == 0) {
            log.fatal("Ū��IFRS�C������������Ƭd�L���");
            return;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");

        countManager.addCountNumber(INPUT_COUNT_2, INPUT_CNT); //�]�w��X���

        buds_INSERT.clear();
        buds_INSERT.preparedBatch(SQL_insert_001);
        for (prepareFetch(); fetchData(bqds); goNext()) { //�������

            buds_INSERT.beginTransaction(); //�������}�l

            try {

                // �v���B�z
                while (bqds.next()) {

                    //����l�ѼơG
                    Date RNT_STR_DATE = (Date) bqds.getField("RNT_STR_DATE");
                    if (RNT_STR_DATE == null) {
                        sbf.append("�_�����(RNT_STR_DATE)���o���ŭ�");
                    }

                    if (sbf.length() > 0) {
                        String chkMsg = toString();
                        sbf.setLength(0);
                        throw new ErrorInputException(chkMsg);
                    }

                    groupHandler.begin();
                    int intPAY_YYYYMM = Integer.valueOf(PAY_YYYYMM);

                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(RNT_STR_DATE);
                    String nowRCV_YM = sdf.format(calendar.getTime());
                    while (Integer.valueOf(nowRCV_YM) <= intPAY_YYYYMM) {
                        setbuds_INSERT_Fields(nowRCV_YM, "2");

                        calendar.add(Calendar.MONTH, 1);//�[�@�Ӥ�
                        nowRCV_YM = sdf.format(calendar.getTime());

                        buds_INSERT.addBatch();
                        groupHandler.joinGroup(SQL_insert_001);
                    }

                    groupHandler.end();

                }// while loop end

                int countByInsertDTEPC208 = executeBatchByBatchUpdateDataSet(actionNameByInsert, buds_INSERT, SQL_insert_001,
                    tableNameDTEPC208, ErrorHandler.DATA_NOT_FOUND_FAIL_DUPLICATE_FAIL);

                groupHandler.displayRevomeIndex();

                //�Y�S�����~�� index �s�b
                if (groupHandler.isSuccess()) {

                    buds_INSERT.endTransaction();

                    countManager.addCountNumber(DTEPC208_OUTPUT_COUNT, countByInsertDTEPC208);

                    //�Y�����~�� index �s�b
                } else {

                    setExitCode(ERROR);

                    buds_INSERT.rollbackTransaction();

                    buds_INSERT.beginTransaction();

                    int reDocountByInsertDTEPC208 = reDoBatchByBatchUpdateDataSet(buds_INSERT, SQL_insert_001);

                    buds_INSERT.endTransaction();

                    countManager.addCountNumber(DTEPC208_OUTPUT_COUNT, reDocountByInsertDTEPC208);

                }

            } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                buds_INSERT.rollbackTransaction(); //�^�_��媺�@�~
                setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
                log.fatal("���榳�~", e);
                errorLog.addErrorLog("���榳�~", e);
                throw e; //�Y�o�Ϳ��~�h�{���X�פ�

            } finally {

                groupHandler.clear();
                //�g�X���~��ưO���� , �C�@�����@��               
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                //�������~���
                countManager.addCountNumber(ERROR_COUNT, errorCount);

            }

        } //for loop end
    }

    /**
     * ���o�����
     * @param PAY_YYYYMM
     * @throws Exception
     */
    private int classifyandUpdateData(String PAY_YYYYMM, String SUB_CPY_ID) throws Exception {

        try {

            bqds.clear();
            bqds.setField("PAY_YYYYMM", PAY_YYYYMM);
            bqds.setField("SUB_CPY_ID", SUB_CPY_ID);
            searchAndRetrieve(bqds, SQL_query_003);

        } catch (Exception e) {
            String memo = "Ū�����`";
            log.fatal(memo, e);
            errorLog.addErrorLog(memo, e);
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            countManager.addCountNumber(ERROR_COUNT, errorCount);
            throw e;
        }

        int INPUT_CNT = getInputCount();

        if (INPUT_CNT == 0) {
            log.fatal("Ū������Ƭd�L���");
            return 0;
        }
        countManager.addCountNumber(INPUT_COUNT_3, INPUT_CNT); //�]�w��X���

        MultiKeyMap mkm = new MultiKeyMap();

        buds_INSERT.clear();
        buds_INSERT.preparedBatch(SQL_update_001);
        for (prepareFetch(); fetchData(bqds); goNext()) { //�������

            buds_INSERT.beginTransaction(); //�������}�l
            try {

                // �v���B�z
                while (bqds.next()) {
                    //����l�ѼơG

                    String CRT_NO = (String) bqds.getField("CRT_NO_C208"); //�����s��
                    String CUS_NO = STRING.objToStr(bqds.getField("CUS_NO_C208")); //�Ȥ�Ǹ�
                    String INV_NO_C205 = (String) bqds.getField("INV_NO_C205");//�o�����X

                    if (!mkm.isEmpty() && !mkm.containsKey(CRT_NO, CUS_NO, INV_NO_C205)) {
                        //�s���ˮ֥N�X�����Χ�s��
                        this.doByGroupChange(PAY_YYYYMM, mkm, SUB_CPY_ID);
                    }

                    Map<BigDecimal, BigDecimal> B106Map;
                    List invType0List;
                    List invType2List;
                    List invType3List;
                    if (mkm.isEmpty()) {

                        //��l�s�հѼ�
                        Map<String, Object> valueMap = initValueMap();
                        B106Map = new HashMap<BigDecimal, BigDecimal>();
                        invType0List = new ArrayList();
                        invType2List = new ArrayList();
                        invType3List = new ArrayList();

                        valueMap.put("B106Map", B106Map);
                        valueMap.put("invType0List", invType0List);
                        valueMap.put("invType2List", invType2List);
                        valueMap.put("invType3List", invType3List);

                        mkm.put(CRT_NO, CUS_NO, INV_NO_C205, valueMap);

                    } else {
                        Map<String, Object> valueMap = (Map<String, Object>) mkm.get(CRT_NO, CUS_NO, INV_NO_C205);
                        B106Map = (Map) valueMap.get("B106Map");
                        invType0List = (List) valueMap.get("invType0List");
                        invType2List = (List) valueMap.get("invType2List");
                        invType3List = (List) valueMap.get("invType3List");
                    }

                    String CRT_NO_B106 = (String) bqds.getField("CRT_NO_B106");
                    String INV_CD = (String) bqds.getField("INV_CD");
                    if (StringUtils.isNotBlank(CRT_NO_B106) || (StringUtils.isBlank(CRT_NO_B106) && "P".equals(INV_CD))) {
                        B106Map.put((BigDecimal) bqds.getField("RCV_YM_C208"), (BigDecimal) bqds.getField("REC_AMT_B106"));
                    }

                    String RCV_YM_C209 = bqds.getField("RCV_YM_C209", "").toString();//�o�����X

                    if (StringUtils.isNotEmpty(INV_NO_C205) || (StringUtils.isNotEmpty(RCV_YM_C209) && StringUtils.isEmpty(INV_NO_C205))) {
                        Map invNoMap = getInvNoMap();
                        String inINV_CD = MapUtils.getString(invNoMap, "INV_CD");
                        if ("0".equals(inINV_CD) || "P".equals(inINV_CD)) {//���ĵo�� or �w����ꦬ
                            invType0List.add(invNoMap);
                        } else if ("2".equals(inINV_CD)) { //�����o��
                            invType2List.add(invNoMap);
                        } else {
                            invType3List.add(invNoMap);
                        }
                    }

                }// while loop end

                executeBatchUpdateDTEPC205();

            } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                buds_INSERT.rollbackTransaction(); //�^�_��媺�@�~
                setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
                log.fatal("���榳�~", e);
                errorLog.addErrorLog("���榳�~", e);
                throw e; //�Y�o�Ϳ��~�h�{���X�פ�

            } finally {

                groupHandler.clear();
                //�g�X���~��ưO���� , �C�@�����@��               
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                //�������~���
                countManager.addCountNumber(ERROR_COUNT, errorCount);

            }

        } //for loop end

        //�̫�@�s�ո��
        if (!mkm.isEmpty()) {
            buds_INSERT.beginTransaction(); //�������}�l
            try {

                this.doByGroupChange(PAY_YYYYMM, mkm, SUB_CPY_ID);
                executeBatchUpdateDTEPC205();

            } catch (Exception e) { //�Y����L�{���o�Ͳ��`���p
                buds_INSERT.rollbackTransaction(); //�^�_��媺�@�~
                setExitCode(ERROR); //�]�w�w�w�^�ǵ�Control_M���T�� , �Ш̻ݨD�վ�
                log.fatal("���榳�~", e);
                errorLog.addErrorLog("���榳�~", e);
                throw e; //�Y�o�Ϳ��~�h�{���X�פ�

            } finally {

                groupHandler.clear();
                //�g�X���~��ưO���� , �C�@�����@��               
                int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
                //�������~���
                countManager.addCountNumber(ERROR_COUNT, errorCount);

            }

        }
        return INPUT_CNT;
    }

    /**
     * �Hmail
     * @throws Exception
     */
    private void sendMail(String SUB_CPY_ID) throws Exception {

        //�N�ˮֲ��`���MAIL�q�������t�d�H
        log.debug("sendMail chkList: " + chkList);
        List<Map> mailList = new ArrayList();
        isCode101 = true;

        try {
            /*//���o����H�W��mailList
            Map aMap = new EP_Z10030().getMailList(SUB_CPY_ID, "EP_IB005"); //EP_IB005: IFRS������ﲧ�`�q��
            List<DTEPZ103> rtnMailList = (List<DTEPZ103>) aMap.get(SUB_CPY_ID);
            for (DTEPZ103 EPZ103VO : rtnMailList) {
                Map mailMap = new HashMap();
                mailMap.put("USER_NAME", EPZ103VO.getNAME());
                mailMap.put("USER_EMAIL", EPZ103VO.getEMAIL());
                //                    mailMap.put("DEFAULT_MAIL", MailSender.DEFAULT_MAIL);
                mailMap.put("USER_ID", EPZ103VO.getID());
                //                    mailMap.put("USER_DIVNO", EPZ103VO.getCHG_ID());
                //                    mailMap.put("USER_DIVNM", "���ʲ��Ƶ��q��");

                mailList.add(mailMap);
            }*/

            //[2019.03.29]
            if (LoginUtil.isProd()) { // EMAIL�H�X �q��������
                log.debug("EMAIL�������ұH�X");
                //���o����H�W��mailList
                Map aMap = new EP_Z10030().getMailList(SUB_CPY_ID, "EP_IB005"); //EP_IB005: IFRS������ﲧ�`�q��
                List<DTEPZ103> rtnMailList = (List<DTEPZ103>) aMap.get(SUB_CPY_ID);
                for (DTEPZ103 EPZ103VO : rtnMailList) {
                    Map mailMap = new HashMap();
                    mailMap.put("USER_NAME", EPZ103VO.getNAME());
                    mailMap.put("USER_EMAIL", EPZ103VO.getEMAIL());
                    mailMap.put("USER_ID", EPZ103VO.getID());
                    mailList.add(mailMap);
                }
            } else {
                log.debug("EMAIL�������ұH�X");
                Map testMailMap = new HashMap();
                testMailMap.put("USER_NAME", "��OO");
                testMailMap.put("USER_EMAIL", "yenhsieh@cathaylife.com.tw");
                testMailMap.put("USER_ID", "A28225703B");
                mailList.add(testMailMap);
            }
        } catch (DataNotFoundException dnfe) {
            //IF�d�L��ơA�������`�õ����{���C
            String memo = "���o����H�W��d�L���";
            log.fatal(memo, dnfe);
            errorLog.addErrorLog(memo, dnfe);
            errorLog.getErrorCountAndWriteErrorMessage();
            return;
        } catch (Exception e) {
            isCode101 = false;//�H�H���~����a
            String memo = "���oEMAIL�o�Ϳ��~";
            log.fatal(memo, e);
            errorLog.addErrorLog(memo, e);
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            countManager.addCountNumber(ERROR_COUNT, errorCount);
            throw e;
        }

        //����EMAIL���e            
        List<Map> crtInfoList = new ArrayList<Map>();
        try {
            for (Map tmpMap : chkList) {
                Map mailMap = new HashMap();
                mailMap.put("CRT_NO", MapUtils.getString(tmpMap, "CRT_NO", ""));
                mailMap.put("CUS_NO", MapUtils.getString(tmpMap, "CUS_NO", ""));
                mailMap.put("CUS_NAME", MapUtils.getString(tmpMap, "CUS_NAME", ""));
                mailMap.put("BLD_CD", MapUtils.getString(tmpMap, "BLD_CD", ""));
                mailMap.put("RCV_YM", MapUtils.getString(tmpMap, "RCV_YM", ""));
                mailMap.put("INV_NO", MapUtils.getString(tmpMap, "INV_NO", ""));
                sbf.append(MapUtils.getString(CHK_TYPE_CODE, MapUtils.getString(tmpMap, "CHK_TYPE"), ""));
                sbf.append(MapUtils.getString(tmpMap, "MEMO", ""));
                mailMap.put("CHK_MEMO", sbf.toString());
                sbf.setLength(0);
                crtInfoList.add(mailMap);
            }
        } catch (Exception e) {
            isCode101 = false;//�H�H���~����a
            String memo = "�զ�����o�Ϳ��~";
            log.fatal(memo, e);
            errorLog.addErrorLog(memo, e);
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            countManager.addCountNumber(ERROR_COUNT, errorCount);
            throw e;
        }
        log.debug("����EMAIL���e: " + crtInfoList);

        //�������TITLE: 
        List<Map> titleList = new ArrayList<Map>();
        titleList(titleList, "CRT_NO", "�����N��", 10);
        titleList(titleList, "CUS_NO", "�Ȥ�Ǹ�", 3);
        titleList(titleList, "CUS_NAME", "�Ȥ�W��", 20);
        titleList(titleList, "BLD_CD", "�j�ӥN��", 8);
        titleList(titleList, "RCV_YM", "��ú�~��", 6);
        titleList(titleList, "INV_NO", "�o�����X", 10);
        titleList(titleList, "CHK_MEMO", "�ˮֻ���(�o�����B-�]�w���B)", 60);

        //�H�oEMAIL:
        log.debug("�H�oEMAIL: " + mailList + ", title:" + titleList + ", crtInfoList:" + crtInfoList);
        try {
            String COMP_ID = new EP_B30010().getCOMP_IDfrSUB_CPY_ID(SUB_CPY_ID);
            //[20181105] Modified �H�H���~�B�z
            String ERR_MSG = new RZ_S00300().createRecordByDIV("EP_IB005", "EP", DATE.today(), mailList, titleList, crtInfoList, COMP_ID);
            if (StringUtils.isNotBlank(ERR_MSG)) {
                throw new ModuleException(ERR_MSG);
            }
        } catch (ModuleException me) {
            isCode101 = false;//�H�H���~����a
            String memo = "�o�eEMAIL�o�Ϳ��~";
            log.fatal(memo, me);
            errorLog.addErrorLog(memo, me);
            int errorCount = errorLog.getErrorCountAndWriteErrorMessage();
            countManager.addCountNumber(ERROR_COUNT, errorCount);
            throw me;
        }
        log.debug("SendMail Complete!");

    }

    /**
     * �s���ˮ֥N�X�����Χ�s��
     * @param PAY_YYYYMM
     * @param mkm
     * @throws DBException
     */
    private void doByGroupChange(String PAY_YYYYMM, MultiKeyMap mkm, String SUB_CPY_ID) throws DBException {
        try {

            Iterator iters = mkm.keySet().iterator();
            MultiKey mk = (MultiKey) iters.next();
            Map valueMap = (Map) mkm.get(mk);

            String keyCRT_NO = (String) valueMap.get("keyCRT_NO");
            String keyCUS_NO = ObjectUtils.toString(valueMap.get("keyCUS_NO"), null);
            String keyINV_NO = (String) valueMap.get("keyINV_NO");
            String groupBLD_CD = (String) valueMap.get("groupBLD_CD");
            String groupCUS_NAME = (String) valueMap.get("groupCUS_NAME");
            Map<BigDecimal, BigDecimal> B106Map = (Map) valueMap.get("B106Map");
            List<Map> invType0List = (List<Map>) valueMap.get("invType0List");
            List<Map> invType2List = (List<Map>) valueMap.get("invType2List");
            List<Map> invType3List = (List<Map>) valueMap.get("invType3List");

            //            if("A102103791".equals(keyCRT_NO) ){
            //            	log.debug("keyCUS_NO"+keyCUS_NO);
            //            	log.debug("keyINV_NO"+keyINV_NO);
            //            	log.debug("groupCUS_NAME:"+groupCUS_NAME);
            //            	log.debug("valueMap:"+valueMap);
            //            	log.debug("B106Map:"+B106Map);
            //            	log.debug("invType0List:"+invType0List);
            //            	log.debug("invType2List:"+invType2List);
            //            	log.debug("invType3List:"+invType3List);
            //            }
            int CHK_TYPE = -1;//�ˮ֥N�X
            String MEMO = null;//����

            if (invType2List.size() != 0) {
                CHK_TYPE = 8;
            } else if (B106Map.isEmpty()) {
                if (StringUtils.isBlank(keyINV_NO)) {
                    CHK_TYPE = 5;
                } else {
                    CHK_TYPE = 2;
                }
            } else if (invType0List.size() == 0) {
                if (invType3List.size() != 0) {//�@�o�o���M�椣����
                    CHK_TYPE = 1;
                } else {
                    //�v���B�z��ú�M��B106Map
                    Iterator iter = (Iterator) B106Map.entrySet().iterator();

                    while (iter.hasNext()) {

                        Map.Entry<BigDecimal, BigDecimal> entry = (Map.Entry) iter.next();
                        BigDecimal entryValue = entry.getValue();
                        if (entryValue == null) {
                            CHK_TYPE = 2;
                            Map chkMap = new HashMap();
                            chkMap.put("CRT_NO", keyCRT_NO);//�����s��
                            chkMap.put("CUS_NO", keyCUS_NO);//�Ȥ�Ǹ�
                            chkMap.put("BLD_CD", groupBLD_CD);//�j�ӥN��
                            chkMap.put("CUS_NAME", groupCUS_NAME);//�Ȥ�W��
                            chkMap.put("RCV_YM", entry.getKey());//�����~��
                            chkMap.put("INV_NO", keyINV_NO);//�o�����X                            
                            chkMap.put("CHK_TYPE", "2");
                            chkList.add(chkMap);

                        } else if (entryValue.compareTo(BigDecimal.ZERO) != 0) {
                            CHK_TYPE = 3;
                            Map chkMap = new HashMap();
                            chkMap.put("CRT_NO", keyCRT_NO);//�����s��
                            chkMap.put("CUS_NO", keyCUS_NO);//�Ȥ�Ǹ�
                            chkMap.put("BLD_CD", groupBLD_CD);//�j�ӥN��
                            chkMap.put("CUS_NAME", groupCUS_NAME);//�Ȥ�W��
                            chkMap.put("RCV_YM", entry.getKey());//�����~��
                            chkMap.put("INV_NO", keyINV_NO);//�o�����X
                            chkMap.put("CHK_TYPE", "3");
                            chkList.add(chkMap);

                        } else {
                            CHK_TYPE = 1;
                        }
                    }
                }
            } else {
                if (noChkMap.containsKey(keyCRT_NO + keyCUS_NO)) {
                    CHK_TYPE = 8;
                } else {
                    // ���o�ꦬ���:
                    Map invNoMap = invType0List.get(0);
                    if ("P".equals(MapUtils.getString(invNoMap, "INV_CD"))) {//�w����ꦬ
                        CHK_TYPE = 8;
                    } else {
                        //����������B�P�ꦬ���B�t��

                        Date inPAY_E_DATE = (Date) invNoMap.get("PAY_E_DATE");
                        Date inPAY_S_DATE = (Date) invNoMap.get("PAY_S_DATE");
                        String inMON_BRK = MapUtils.getString(invNoMap, "MON_BRK");
                        Date inRNT_STR_DATE = (Date) invNoMap.get("RNT_STR_DATE");
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
                        boolean isOK = true;// �ˮ֬O�_�L�~
                        BigDecimal B106Amt = BigDecimal.ZERO;//�������B

                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(inPAY_S_DATE);
                        Date tmpStrDate = inPAY_S_DATE;//�ثe�_��
                        String maxRcvYm = sdf.format(tmpStrDate); //�̤j��ú�~��
                        while (DATE.diffDay(tmpStrDate, inPAY_E_DATE) >= 0) {
                            maxRcvYm = sdf.format(tmpStrDate);
                            if (DATE.diffDay(tmpStrDate, inPAY_S_DATE) == 0 && "Y".equals(inMON_BRK)
                                    && DATE.diffDay(inPAY_S_DATE, inRNT_STR_DATE) == 0) {
                                calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));//�멳���
                                calendar.add(Calendar.DATE, 1);//+1��
                                tmpStrDate = new Date(calendar.getTimeInMillis());
                            } else {
                                calendar.add(Calendar.MONTH, 1);//�[�@�Ӥ�
                                tmpStrDate = new Date(calendar.getTimeInMillis());

                            }
                        }
                        //�[�`�������B
                        //�v���B�zB106Map:
                        Iterator<BigDecimal> iter = B106Map.keySet().iterator();

                        while (iter.hasNext()) {
                            BigDecimal key = iter.next();
                            log.debug("oo: " + key);
                            BigDecimal value = B106Map.get(key);
                            if (value == null) {
                                isOK = false;
                                Map chkMap = new HashMap();
                                chkMap.put("CRT_NO", keyCRT_NO);//�����s��
                                chkMap.put("CUS_NO", keyCUS_NO);//�Ȥ�Ǹ�
                                chkMap.put("BLD_CD", groupBLD_CD);//�j�ӥN��
                                chkMap.put("CUS_NAME", groupCUS_NAME);//�Ȥ�W��
                                chkMap.put("RCV_YM", key);//�����~��
                                chkMap.put("CHK_TYPE", "2");//�ˮ֥N�X
                                chkMap.put("INV_NO", keyINV_NO);//�o�����X
                                chkList.add(chkMap);

                            } else {
                                if (!(key.intValue() > Integer.valueOf(maxRcvYm))) {
                                    B106Amt = B106Amt.add(value);
                                }
                            }
                        }

                        //��������P�ꦬ���B�t�����b���t5����
                        BigDecimal invSAL_AMT = (BigDecimal) invNoMap.get("SAL_AMT");
                        if (isOK && invSAL_AMT.add(BigDecimal_5).compareTo(B106Amt) >= 0
                                && invSAL_AMT.subtract(BigDecimal_5).compareTo(B106Amt) <= 0) {
                            CHK_TYPE = 8;
                        } else {
                            CHK_TYPE = 4;
                            sbf.append("(").append(invSAL_AMT).append("-").append(B106Amt).append(")");
                            MEMO = sbf.toString();
                            sbf.setLength(0);
                        }

                    }
                }

            }

            if (StringUtils.isNotBlank(keyINV_NO)) {
                //��s�ˮ֥N�X
                groupHandler.begin();

                buds_INSERT.setField("CHK_TYPE", CHK_TYPE == -1 ? "" : CHK_TYPE);
                buds_INSERT.setField("INV_NO", keyINV_NO);
                buds_INSERT.setField("PAY_YYYYMM", PAY_YYYYMM);
                buds_INSERT.setField("SUB_CPY_ID", SUB_CPY_ID);
                buds_INSERT.addBatch();
                groupHandler.joinGroup(SQL_update_001);

                groupHandler.end();
            }

            if (!(CHK_TYPE == 1 || CHK_TYPE == 3 || CHK_TYPE == 8 || CHK_TYPE == 9)) {
                Map chkMap = new HashMap();
                chkMap.put("CRT_NO", keyCRT_NO);//�����s��
                chkMap.put("CUS_NO", keyCUS_NO);//�Ȥ�Ǹ�
                chkMap.put("BLD_CD", groupBLD_CD);//�j�ӥN��
                chkMap.put("CUS_NAME", groupCUS_NAME);//�Ȥ�W��
                chkMap.put("RCV_YM", valueMap.get("groupRCV_YM_C208"));//�����~��
                chkMap.put("INV_NO", keyINV_NO);//�o�����X
                chkMap.put("CHK_TYPE", CHK_TYPE);//�ˮ֥N�X
                chkMap.put("MEMO", MEMO);//����
                chkList.add(chkMap);

            }
        } finally {
            mkm.clear();
        }

    }

}
